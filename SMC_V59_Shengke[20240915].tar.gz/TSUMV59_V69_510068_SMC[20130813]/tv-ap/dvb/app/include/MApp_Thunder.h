////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
/// @file MApp_Thunder.h
/// @brief Thunder download kernel
/// @author MStar Semiconductor Inc.
///
/// Thunder download kernel provide a simple interface to let users implement
/// Thunder download on MStar chip.
///
///////////////////////////////////////////////////////////////////////////////

#if (ENABLE_THUNDER_DOWNLOAD)

#define MAPP_THUNDER_H

#ifdef MAPP_THUNDER_C
#define INTERFACE
#else
#define INTERFACE extern
#endif

#define MApp_BT_Task MApp_Thunder_Task

// MailBox HK(AEON)  <=> BEON
typedef enum
{
    // HK(Aeon)  => Beon
    MB_BTC_UNLOCKMEM_A          = 0x10,
    MB_BTC_LISTTORRENT          = 0x11,
    MB_BTC_SETMEMADDR1          = 0x12,
    MB_BTC_SETMEMADDR2          = 0x13,
    MB_BTC_SETDAEMONPARAM       = 0x14,
    MB_BTC_STOPDAEMON           = 0x15,
    MB_BTC_ADDTORRENT           = 0x16,
    MB_BTC_DELTORRENT           = 0x17,
    MB_BTC_DELTORDATA           = 0x18,
    MB_BTC_STARTDAEMON          = 0x19,
    MB_BTC_STARTTORRENT         = 0x1A,
    MB_BTC_STOPTORRENT          = 0x1B,
    MB_BTC_SETTORRENTSVR        = 0x1C,
    MB_BTC_HTTPCMD_TTOTAL       = 0x20,
    MB_BTC_HTTPCMD_TLIST        = 0x21,
    MB_BTC_HTTPCMD_TGET         = 0x22,
    MB_BTC_HTTPCMD_PGET         = 0x23,
    MB_BTC_HTTPCMD_DGET         = 0x24,
    MB_BTC_HTTPCMD_CPUT         = 0x25,
    MB_BTC_HTTPCMD_PPUT         = 0x26,
    MB_BTC_CHECK_NETWORK        = 0x27,
    MB_BTC_CHECK_STORAGE        = 0x28,
    MB_BTC_HTTPCMD_ALL         = 0x29,

    // Beon  => HK(Aeon)
    MB_BTC_UNLOCKMEM_M          = 0x80,
    MB_BTC_OK                   = 0x81,
    MB_BTC_FAIL                 = 0x82,
    MB_BTC_RESPONSE_NUM         = 0x83,
    MB_BTC_RESPONSE_LIST        = 0x84,
    MB_BTC_LISTTORRENT_RESPONSE = 0x85,
    MB_BTC_SENDIMGRAWDATA       = 0x86,
    MB_BTC_SENDDESTXT           =0x87,
    MB_BTC_SENDALL           = 0x88
} MB_BTC;


// MailBox BEON => HK(AEON) Error State.
typedef enum
{
    MB_BTC_ERR_NONE  = 0x00,          //

    MB_BTC_ERR_DN_TOR  = 0x01,          //Error while downloading the torrent file
    MB_BTC_ERR_DN_IMG = 0x02,           //Error while downloading the image file
    MB_BTC_ERR_DN_DES = 0x03,           //Error while downloading the description file
    MB_BTC_ERR_START_TOR = 0x04,        //Error while starting the torrent
    MB_BTC_ERR_STOP_TOR = 0x05,         //Error while stopping the torrent
    MB_BTC_ERR_ADD_TOR = 0x06,          //Error while adding the torrent
    MB_BTC_ERR_DEL_TOR = 0x07,          //Error while deleting the torrent
    MB_BTC_ERR_DEL_TORDATA  = 0x08, //Error while deleting the torrent and downloaded data
    MB_BTC_ERR_START_DAEM = 0x09,   //Error while starting the daemon
    MB_BTC_ERR_STOP_DAEM = 0x0A,        //Error while stopping the daemon
    MB_BTC_ERR_SET_PARAM = 0x0B,        //Error while setting the daemon parameters
    MB_BTC_ERR_NETWORK = 0x0C,          //Error for network
    MB_BTC_ERR_STORAGE = 0x0D,          //Error for storage
    MB_BTC_ERR_UNRESOLVED_HOST = 0x0E,  //Error while resolving the host name of the torrent server
    MB_BTC_ERR_DECODE_IMG = 0x0F,           //Error while decoding the image
    MB_BTC_ERR_NETWORK_PHY      = 0x10,
    MB_BTC_ERR_NETWORK_DHCP     = 0x11,
    MB_BTC_ERR_DN_ALL           = 0x12,

    MB_BTC_ERR_UNKNOWN  = 0xFF,              //Unknown error
} MB_BTC_ERROR;

typedef enum
{
    STATE_SYSTEM_INIT_NONE,
    STATE_SYSTEM_INIT_LOAD_BIN,
    STATE_SYSTEM_INIT_WAIT_LOAD_OK,
    STATE_SYSTEM_INIT_SET_PARAMETER,
    STATE_SYSTEM_INIT_CHECK_NETWORK,
    STATE_SYSTEM_INIT_OK,
} Thunder_Init_State;

typedef enum
{
    THUNDER_SEARCH_STATE_INIT,
    THUNDER_SEARCH_STATE_WAIT,
    THUNDER_SEARCH_STATE_TIME_OUT,
    THUNDER_SEARCH_STATE_NOTHING,
    THUNDER_SEARCH_STATE_SHOW,
    THUNDER_SEARCH_STATE_INPUT_ERROR,
} EN_THUNDER_SEARCH_STATE;


typedef enum
{
    STATE_THUNDER_JPEG_NONE,
    STATE_THUNDER_JPEG_INIT,
    STATE_THUNDER_JPEG_DECODE,
    STATE_THUNDER_JPEG_SHOW,

} THUNDER_JPEG_State;


typedef enum
{
    STATE_THUNDER_MAINLINK_NONE,
    STATE_THUNDER_MAINLINK_CMD_1,
    STATE_THUNDER_MAINLINK_WAIT_1,
    STATE_THUNDER_MAINLINK_CMD_2,
    STATE_THUNDER_MAINLINK_WAIT_2,
    STATE_THUNDER_MAINLINK_DONE,

} THUNDER_MAINLINK_State;

/// the MainLink0 status.
typedef struct
{
    BOOLEAN bLinkPicFile_Show;    // link Picture file can show or not
} ThunderMainLink0Status;

/// the MainLink1 status.
typedef struct
{
    BOOLEAN bLinkPicFile_Show;    // link Picture file can show or not
} ThunderMainLink1Status;


//*****************************************************************************
#define NUM_OF_ERROR     10

#define NUM_OF_SEARCH_LIST_PER_PAGE     5
#define NUM_OF_MAINLINK0_ITEM_PER_PAGE     6
#define NUM_OF_MAINLINK1_ITEM_PER_PAGE     6

#define THUNDER_SEARCH_WAIT_TIME     150 // (200ms)*150 = 30 S

//*****************************************************************************


//*****************************************************************************
//              Global variables
//*****************************************************************************
INTERFACE EN_THUNDER_SEARCH_STATE enThunderSearchState;

/////////////////////////////////////////////////////////////////////////////////////
INTERFACE BOOLEAN MApp_Thunder_GetAnyData(void);

INTERFACE THUNDER_MAINLINK_State MApp_GetThunderMainLinkState(void);
INTERFACE BOOLEAN MApp_Thunder_GetAnyData2( BOOLEAN IsTopMovieList);

INTERFACE BOOLEAN MApp_Thunder_GetAnySearch(char *skey,int num,int page);

typedef enum//ResultSet
{
    EN_BLOCKR=0,//FileInfo
    EN_CID,//Cid
    EN_TITLE,//Title
    EN_SIZE,//Size
    EN_FORMAT,//Format
    EN_PLAYTIME,//PlayTime
    EN_BITRATE,//BitRate
    EN_TORRENT,//Torrent
    EN_TONUM,//TorrentNum
    EN_MAX_FILEINFO,
} FILEINFO;

typedef enum//moviesets
{
    EN_BLOCKM=0,//movie
    EN_MID,//movie id="  "
    EN_NAME,//key
    EN_DESC,//desc
    EN_PIC,//pic
    EN_MAX_MOVEINFO,
} MOVEINFO;

typedef enum
{
    EN_START=0,
    EN_END,
    EN_MAX_POINTINFO,
} SPOINTER;

INTERFACE int strstrn(char **ppstringstart,char **ppstringend,char *psubstring);
INTERFACE int strnum(char *pstringstart,char *pstringend,char *pskeyword);
INTERFACE int strkeyn(char **ppstringstart,char **ppstringend,char *pskeyword,int counter);
INTERFACE int strdata(char **ppstringstart,char **ppstringend,char *pskeyword1,char *pskeyword2);

INTERFACE void CopyString(char *dst, char *s1, char *s2);
INTERFACE void PrintfInfo(char *s1,char *s2);

INTERFACE int DataParser(char *sInputBuffer, int iLength);

INTERFACE char * SearchResult[NUM_OF_SEARCH_LIST_PER_PAGE][EN_MAX_FILEINFO][EN_MAX_POINTINFO];
INTERFACE int ResultCounter;
INTERFACE char * MovieList[10][EN_MAX_MOVEINFO][EN_MAX_POINTINFO];
INTERFACE char * MoviePIC[10][EN_MAX_POINTINFO];
INTERFACE char * MovieKeyword[10][EN_MAX_POINTINFO];
////////////////////////////////////////////////////////////////////////////////

//*****************************************************************************
//              Function prototypes
//*****************************************************************************
INTERFACE BOOLEAN MApp_Thunder_MailBoxHandle(U32 u32WaitMs, U8 u8CommandIndex, MBX_Msg *pMsg);
INTERFACE MB_BTC_ERROR MApp_ThunderSystemErrorHandle(void);

INTERFACE void msAPI_MappinUCS2ToUTF8(U16 *pu16srcStr, U8 *pu8dstStr, U16 srcWideCharLen, U16 dstByteLen);

INTERFACE void MApp_Thunder_SetSystemInitState(Thunder_Init_State uState);
INTERFACE Thunder_Init_State MApp_Thunder_GetSystemInitState(void);

INTERFACE void MApp_SetThunderSearchSate(EN_THUNDER_SEARCH_STATE enState);
INTERFACE EN_THUNDER_SEARCH_STATE MApp_GetThunderSearchSate(void);
INTERFACE U32 MApp_GetThunderSearchResultCounter(void);

INTERFACE void MApp_Thunder_MainLink0_Init(void);
INTERFACE void MApp_Thunder_MainLink1_Init(void);

INTERFACE void MApp_Thunder_Task(void);

#undef INTERFACE

#undef MAPP_THUNDER_H

#endif

