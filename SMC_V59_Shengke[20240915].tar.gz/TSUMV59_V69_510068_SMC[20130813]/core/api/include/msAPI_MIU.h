////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (MStar Confidential Information!�L) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////



#ifndef MSAPI_MIU_H
#define MSAPI_MIU_H

#include "datatype.h"
#include "sysinfo.h"
#include "msAPI_Font.h"

#include "drvSERFLASH.h"
#include "SysInit.h"
#include "msAPI_OSD.h"
#include "msAPI_BDMA.h"

#ifdef MSAPI_MIU_C
#define INTERFACE
#else
#define INTERFACE extern
#endif

#define MIU_MCU_WRITE_BLK_ID 13
#define msAPI_MIU_GetW1StartAddress() 0xF000
#define msAPI_MIU_Set_DRAM2DRAM_Mode(mode)
////////////////////////////////////////////////////

INTERFACE void msAPI_MIU_Init(void);
void msAPI_MIU_Set_TTX_FontInfo(U8 charSize, U16 fontID);
INTERFACE FONTHANDLE msAPI_MIU_LoadFlashFont_TTX(U16 u16BinID, U8 u8GlyphSize,
    U16 u16char_num, U8 u8width, U8 u8height, FONTHANDLE fHandle);
INTERFACE BMPHANDLE msAPI_MIU_LoadFlashBitmap(U16 u16ID, U16 u16width, U16 u16height);
INTERFACE void msAPI_MIU_StoreDataBase2Flash(U8 u8Bank, U32 u32srcaddr, S32 s32size, BOOLEAN bErase);
INTERFACE void msAPI_MIU_WriteFlashDataBaseVersion(U8 u8Bank, U32 u16Offset, U8 u8Version);
INTERFACE S8 msAPI_MIU_ReadFlashDataBaseVersion(U8 u8Bank, U32 u16Offfset);
INTERFACE U32 msAPI_MIU_XData2SDRAMAddr(U32 u32addr);
INTERFACE void msAPI_MIU_LoadLogo(U32 u32Flashaddr, U32 u32Dstaddr, U32 u32Len);
INTERFACE void msAPI_MIU_Clear(U8 miu, U32 addr, U32 len, U8 clear_value);
//#define msAPI_MIU_Clear(a,x,y,z)    MDrv_GE_ClearFrameBuffer(x,y,z)

//INTERFACE void msAPI_MIU_Set_BinHeader_Addr(U32 addr);
//INTERFACE U32 msAPI_MIU_Get_BinHeader_Addr(void);

#define msAPI_MIU_Set_BinHeader_Addr(u32Addr) MDrv_MIU_Set_BinHeader_Addr(u32Addr)
#define msAPI_MIU_Get_BinHeader_Addr() MDrv_MIU_Get_BinHeader_Addr()

// u8XBase and u8XSize are xdata address and should be multiple of 1k bytes.
//INTERFACE void msAPI_MIU_MapSIData(U32 u32SdramBase);
//#define msAPI_MIU_MapSIData(u32MiuBase) MDrv_Sys_SetXdataWindow1Base((u32MiuBase)/4096)

INTERFACE void msAPI_MIU_SDRAM2Flash(U32 u32srcaddr, U32 u32desaddr, S32 s32size);
//INTERFACE void msAPI_MIU_Flash2Xdata(U32 u32srcaddr, U32 u32size, U8* pdat);
#define msAPI_MIU_Flash2Xdata(u32srcaddr, u32size, pdat) MDrv_FLASH_Read(u32srcaddr, u32size, pdat)
INTERFACE void msAPI_MIU_Copy(U32 u32srcaddr, U32 u32dstaddr, U32 u32len, MEMCOPYTYPE type);
//INTERFACE BOOLEAN msAPI_MIU_Get_BinInfo(BININFO *pBinInfo);
#define msAPI_MIU_Get_BinInfo(pBinInfo, pbResult) MDrv_Sys_Get_BinInfo(pBinInfo, pbResult)
INTERFACE void msAPI_MIU_CCS(void);

//OSDCOMPOSER
INTERFACE BMPHANDLE msAPI_MIU_LoadFlashBitmap_Osdcp(U32 u32addr, U16 u16width, U16 u16height);

#if ENABLE_SSC
INTERFACE void msAPI_MIU_SetSsc(U16 u16Periodx100Hz, U16 u16Percentx100, BOOLEAN bEnable);
#endif

INTERFACE void msAPI_MIU_SetRoundRobin(BOOLEAN bEnable);
//INTERFACE void msAPI_MIU_SetGEFlowControl(BOOLEAN bEnable);

INTERFACE void msAPI_MIU_XDataExtStackCheck(void);
INTERFACE U8 MDrv_USB_GetXDataExtStackCount(void);
INTERFACE U8 msAPI_FCtrl_GetXDataExtStackCount(void);

#if defined(__aeon__)
    #if CHIP_FAMILY_TYPE == CHIP_FAMILY_S4LE
        #define AUTO_DQS_DUMP(x) //x
        #define DQSN(step)  (1 - step / 16) // (step / 16)
        #define ENABLE_AUTO_DQS_Factory    1
        INTERFACE U8 u8DQSM0[3];
        INTERFACE U8 u8DQSM1[3];

        INTERFACE void MDrv_MIU_AutoDQS_Factory(void);
    #else
        #define ENABLE_AUTO_DQS_Factory    0
    #endif
#else
        #define ENABLE_AUTO_DQS_Factory    0
#endif

/*********************************************************************/

typedef enum
{
    MIU_SPEED_Unknown = 0x0,

    MIU_SPEED_DDR2_800MHz,

    MIU_SPEED_DDR2_960MHz,

    MIU_SPEED_DDR2_1066MHz,

//    MIU_SPEED_DDR3_1300MHz,

//    MIU_SPEED_DDR3_1600MHz,

} En_MIU_SPEED_Type;

INTERFACE En_MIU_SPEED_Type enMiuDDR_Speed;
INTERFACE void msAPI_MIU_GetMiuSpeed(void);

/*********************************************************************/
///////////////////////////////////////////////////////////////////////////////////////////////////

#undef INTERFACE
#endif

