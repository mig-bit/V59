////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MAPP_ZUI_ACTINSTALL_H
#define _MAPP_ZUI_ACTINSTALL_H

#ifdef __cplusplus
extern "C" {
#endif  /* __cplusplus */

#include "MApp_ZUI_APIgdi.h"

#ifdef MAPP_ZUI_ACTINSTALL_C
#define INTERFACE
#else
#define INTERFACE extern
#endif
typedef enum
{
    PAGE_INSTALL_OSD_LANGUAGE,
    PAGE_INSTALL_TUNING_COUNTRY,
#ifdef DVB_C_ENABLE
    PAGE_INSTALL_SELECT_DVBC,
#endif
} EN_INSTALL_GUIDE_PAGE;
/////////////////////////////////////////
// Cutomize Window Procedures...
//INTERFACE S32 MApp_ZUI_ACT_InstallGuideRootWinProc(HWND, PMSG);

//#define INSTALLGUIDEROOT_WINPROC MApp_ZUI_ACT_InstallGuideRootWinProc

/////////////////////////////////////////
// Event Handlers....
INTERFACE void MApp_ZUI_ACT_Set_InstallGuidePage(EN_INSTALL_GUIDE_PAGE enPageIndex);
EN_INSTALL_GUIDE_PAGE MApp_ZUI_ACT_Get_InstallGuidePage(void);
INTERFACE void MApp_ZUI_ACT_AppShowInstallGuide(void);
INTERFACE BOOLEAN MApp_ZUI_ACT_HandleInstallGuideKey(VIRTUAL_KEY_CODE key);
INTERFACE void MApp_ZUI_ACT_TerminateInstallGuide(void);
INTERFACE BOOLEAN MApp_ZUI_ACT_ExecuteInstallGuideAction(U16 act);
INTERFACE LPTSTR MApp_ZUI_ACT_GetInstallGuideDynamicText(HWND hwnd);
INTERFACE void MApp_ZUI_ACT_SetTuningCountryByOSDLanguage( void );
INTERFACE void MApp_ZUI_ACT_InstallPageSelect(U8 InstallPageID);
INTERFACE S16 MApp_ZUI_ACT_GetInstallPageDynamicValue(HWND hwnd);
INTERFACE GUI_ENUM_DYNAMIC_LIST_STATE MApp_ZUI_ACT_QueryIstallItemStatus(HWND hwnd);

//cus_xm:zb add at 2012-8-2
INTERFACE U16 MApp_ZUI_ACT_GetInstallDynamicBitmap(HWND hwnd,DRAWSTYLE_TYPE ds_type);

INTERFACE S32 MApp_ZUI_ACT_InstallGuideWinProc(HWND,PMSG);
#define INSTALL_GUIDE_WINPROC MApp_ZUI_ACT_InstallGuideWinProc

#undef INTERFACE

#ifdef __cplusplus
}
#endif  /* __cplusplus */

#endif /* _MAPP_ZUI_ACTINSTALL_H */

