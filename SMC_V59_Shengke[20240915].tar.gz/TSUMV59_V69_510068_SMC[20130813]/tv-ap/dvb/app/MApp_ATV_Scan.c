////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#define MAPP_ATV_SCAN_C

//******************************************************************************
//                    Header Files
//******************************************************************************
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Board.h"
#include "datatype.h"
#include "msAPI_Global.h"
#include "msAPI_IR.h"
#include "msAPI_Tuning.h"
#include "msAPI_audio.h"
#include "msAPI_VD.h"
#include "msAPI_Timer.h"
#include "apiXC.h"
#include "MApp_GlobalVar.h"
#include "MApp_GlobalSettingSt.h"
#include "MApp_Exit.h"
#include "MApp_Key.h"
#include "MApp_UiMenuDef.h"
#include "MApp_InputSource.h"
#include "MApp_ATVProc.h"

#include "ZUI_exefunc.h"
#include "MApp_ZUI_Main.h"

#include"MApp_BlockSys.h"
#include"MApp_MultiTasks.h"
#include "MApp_ATV_Scan.h"
#include "IF_Demodulator.h"

#if (ENABLE_DTV)
#include "mapp_demux.h"
#include "COFDM_Demodulator.h"
#endif

#include "MApp_SaveData.h"
#include "MApp_GlobalFunction.h"
#include "MApp_SignalMonitor.h"
#if ENABLE_TTX
#include "mapp_ttx.h"
#endif
#include "MApp_ChannelChange.h"
#include "MApp_TopStateMachine.h"
#include "MApp_ZUI_APIwindow.h"
#if ENABLE_SBTVD_BRAZIL_CM_APP
#include "msAPI_ChProc.h"
#endif
#if MHEG5_ENABLE
#include "MApp_MHEG5_Main.h"
#endif
extern EN_OSD_TUNE_TYPE_SETTING eTuneType;

#ifndef SCAN_TEST_MODE_ENABLE
#define SCAN_TEST_MODE_ENABLE 0
#endif
#define SCAN_FREQ_ATTIME    1

#if ENABLE_SBTVD_BRAZIL_APP
extern E_ANTENNA_SOURCE_TYPE enLastWatchAntennaType;
#endif

//********************************************************************************
//                     Macro
//********************************************************************************
#define ATV_SCAN_DBINFO(y)   //y


//********************************************************************************
//                     Local
//********************************************************************************
static EN_ATV_SCAN_STATE enATVScanState = STATE_ATV_SCAN_INIT;
static EN_ATV_SCAN_STATE enPreATVScanState = STATE_ATV_SCAN_INIT;
static BOOLEAN fReturnToPrevious=FALSE;
static BOOLEAN fEndHalt=FALSE;
static BOOLEAN fATVManualScanDetectProgram = FALSE; /*Creass.liu at 2012-07-12*/

#if SCAN_FREQ_ATTIME
static U16 PreATVScanPLL;
#else
static U8 PreATVScanPercent;
#endif

#if ( ENABLE_DVB_TAIWAN_APP || ENABLE_SBTVD_BRAZIL_APP)
static U8 PreATVScanChannel;
#endif
#if ENABLE_SZ_BLUESCREEN_FUNCTION
BOOL ATV_SEARCH_STATE=FALSE;  //truth.xu add 20100901
#endif

static void MApp_ATV_Scan_ProcessUserInput ( void );

#if((FRONTEND_IF_DEMODE_TYPE == MSTAR_VIF)||(FRONTEND_IF_DEMODE_TYPE == MSTAR_INTERN_VIF))
    extern BOOLEAN gbTVAutoScanChannelEnable;
#elif(FRONTEND_IF_DEMODE_TYPE == MSTAR_VIF_MSB1210)        // GEM_SYNC_0815
    #include "Tuner.h"
    #include "drvVIF_MSB1210.h"

    extern BOOLEAN gbTVAutoScanChannelEnable;
#endif

#if ENABLE_CUS_UI_SPEC
extern BOOLEAN MApp_ZUI_ACT_bIsCurrentOSDisAutoScanPage(void);
#endif

//********************************************************************************
//                     Functions
//********************************************************************************
EN_ATV_SCAN_STATE MApp_ATV_Scan_ScanState ( void )
{
    return enATVScanState;
}

void MApp_ATV_Scan_State_Init ( void )
{
    enATVScanState = STATE_ATV_SCAN_INIT;
}

void MApp_ATV_Scan_End ( void )
{
    if ( msAPI_Tuner_IsTuningProcessorBusy() == TRUE )
    {
        msAPI_Tuner_TuningProcessor(AFT_EXT_STEP_SEARCHSTOP);
    }

#if ENABLE_TTX
    MApp_TTX_EnableScan( 0 );
#endif
#if (ENABLE_DTV)
     devCOFDM_PassThroughI2C(DISABLE);
#endif
#if((FRONTEND_IF_DEMODE_TYPE == MSTAR_VIF)||(FRONTEND_IF_DEMODE_TYPE == MSTAR_INTERN_VIF))
    gbTVAutoScanChannelEnable=FALSE;
#elif(FRONTEND_IF_DEMODE_TYPE == MSTAR_VIF_MSB1210)     // GEM_SYNC_0815
    gbTVAutoScanChannelEnable=FALSE;
    MDrv_VIF_SetHandler(gbTVAutoScanChannelEnable, GAIN_DISTRIBUTION_THR);
#endif

#if ENABLE_SBTVD_BRAZIL_CM_APP
    if(ANT_AIR == msAPI_ATV_GetCurrentAntenna())
    {
        if(msAPI_ATV_GetActiveProgramCount())
            msAPI_CHPROC_CM_InitOridial();
          msAPI_ATV_SetCurrentProgramNumber(msAPI_ATV_GetFirstProgramNumber(FALSE));
    }
#endif
#if 0//( TV_FREQ_SHIFT_CLOCK )
    msAPI_Tuner_Patch_TVShiftClk(FALSE);
#endif
}


extern BOOLEAN MApp_ZUI_ACT_ExecuteAutoTuningAction(U16 act);
extern EN_VD_SIGNALTYPE g_ePreVideoSystem;

EN_RET MApp_ATV_Scan ( void )
{
    EN_RET enATVScanRetVal;
    BOOLEAN bIsAutoScanInProgress;
    BOOLEAN bIsOneProgramDetected;
    U8 u8ManProcess;
    static U8 u8ManProcessStart=0;

    static U16 _u16PreTunerPLL=0;
    enATVScanRetVal =EXIT_NULL;

    MApp_ATV_Scan_ProcessUserInput();

    switch ( enATVScanState )
    {
        case STATE_ATV_SCAN_INIT:
          #if((FRONTEND_IF_DEMODE_TYPE == MSTAR_VIF)||(FRONTEND_IF_DEMODE_TYPE == MSTAR_INTERN_VIF))
            gbTVAutoScanChannelEnable=TRUE;
          #elif(FRONTEND_IF_DEMODE_TYPE == MSTAR_VIF_MSB1210)
            gbTVAutoScanChannelEnable=TRUE;
            MDrv_VIF_SetHandler(gbTVAutoScanChannelEnable, GAIN_DISTRIBUTION_THR);
          #endif
			#if ENABLE_SZ_BLUESCREEN_FUNCTION		//SMC jayden.chen move it to here for flash screen 20130308
			//if ( stGenSetting.stScanMenuSetting.u8ScanType == SCAN_TYPE_AUTO )
			{
				//printf( "STATE_ATV_SCAN_INIT1>>\n" );
				ATV_SEARCH_STATE=TRUE;	//truth.xu add 20100901
				msAPI_Scaler_SetBlueScreen( DISABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
				msAPI_Timer_Delayms(1000);// Need Delay >1S  
			}
			#endif

          #if ENABLE_OFFLINE_SIGNAL_DETECTION
            MApp_OffLineInit();
          #endif

            u8ScanAtvChNum = 0;

        #if SCAN_FREQ_ATTIME
            PreATVScanPLL = msAPI_Tuner_GetCurrentChannelPLL();
        #else
            PreATVScanPercent = 0;
        #endif

        #if ( ENABLE_DVB_TAIWAN_APP || ENABLE_SBTVD_BRAZIL_APP )
            PreATVScanChannel=0;
        #endif

            ATV_SCAN_DBINFO( printf( "STATE_ATV_SCAN_INIT>>\n" ) );

        #if (ENABLE_DTV)
            if ( UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_DTV )
            {
            #if MHEG5_ENABLE
                MApi_MHEG5_Disable(EN_MHEG5_DM_DISABLE_AND_WAIT);
            #endif
            }
        #endif

            //PIP behavior: If PIP is enabled, close sub window and turn on ATV in the main window.
        #if (ENABLE_PIP)
            if(IsPIPEnable())
            {
                BOOLEAN bResetSrc = FALSE;

                if(IsSrcTypeScart(SYS_INPUT_SOURCE_TYPE(SUB_WINDOW))
                    || IsSrcTypeAV(SYS_INPUT_SOURCE_TYPE(SUB_WINDOW))
                    || IsSrcTypeSV(SYS_INPUT_SOURCE_TYPE(SUB_WINDOW)))
                {
                    bResetSrc = TRUE;
                }
                if(stGenSetting.g_stPipSetting.enPipSoundSrc==EN_PIP_SOUND_SRC_SUB)
                {
                    stGenSetting.g_stPipSetting.enPipSoundSrc=EN_PIP_SOUND_SRC_MAIN;
                    MApp_InputSource_PIP_ChangeAudioSource(MAIN_WINDOW);
                }
                E_UI_INPUT_SOURCE ePreSrc = UI_SUB_INPUT_SOURCE_TYPE;
                UI_SUB_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_NONE;
                MApp_InputSource_ChangeInputSource(SUB_WINDOW);
                UI_SUB_INPUT_SOURCE_TYPE = ePreSrc;
                stGenSetting.g_stPipSetting.enPipMode = EN_PIP_MODE_OFF;
                if(bResetSrc)
                {//Set sub window source type to 1st compatible src with the main window.
                    UI_SUB_INPUT_SOURCE_TYPE = MApp_InputSource_GetUIInputSourceType(MApp_InputSource_PIP_Get1stCompatibleSrc(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)));
                }
            }
        #endif

            MApp_ChannelChange_DisableChannel(TRUE, MAIN_WINDOW);

        #if ( ENABLE_DVB_TAIWAN_APP || ENABLE_SBTVD_BRAZIL_APP || (TV_SYSTEM == TV_NTSC) )
            stGenSetting.stScanMenuSetting.u8VideoSystem_Brazil=E_VIDEOSTANDARD_BRAZIL_AUTO;
        #else
            if ( UI_INPUT_SOURCE_TYPE != UI_INPUT_SOURCE_ATV )
        #endif
            {
                MApp_InputSource_RecordSource(UI_INPUT_SOURCE_TYPE);

            #if ENABLE_SBTVD_BRAZIL_APP
                if(MApp_TopStateMachine_GetTopState() == STATE_TOP_ATV_SCAN)
                {
                    enLastWatchAntennaType = ANTENNA_ATV_TYPE;
                    UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_ANTENNA;
                    msAPI_ATV_SetCurrentAntenna(ANT_AIR);
                    stGenSetting.stScanMenuSetting.u8Antenna =1;
                }
                else
                {
                    // STATE_TOP_CATV_SCAN
                    UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_ATV;
                    msAPI_ATV_SetCurrentAntenna(ANT_CATV);
                    stGenSetting.stScanMenuSetting.u8Antenna =0;
                }
            #else
                UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_ATV;
            #endif
                MApp_InputSource_ChangeInputSource(MAIN_WINDOW);
            }

        #if (ENABLE_DTV)
          if(TRUE == MApp_Get_ParentalBlock_state())
             {
                  MApp_ParentalControl_SetBlockStatus(FALSE);
                 MApp_Set_ParentalBlock_state(DISABLE);
             }
        #endif

            if ( UI_INPUT_SOURCE_TYPE != UI_INPUT_SOURCE_ATV )
            {
                UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_ATV;
                MApp_InputSource_SwitchSource( UI_INPUT_SOURCE_TYPE, MAIN_WINDOW );
            }

          #if ENABLE_TTX
            MApp_TTX_EnableScan( 1 );
          #endif

            //Cancel Freeze
            if(g_bIsImageFrozen)
            {
                g_bIsImageFrozen = FALSE;
                MApi_XC_FreezeImg(g_bIsImageFrozen, MAIN_WINDOW);
            }

            fATVManualScanDetectProgram = FALSE;

            if ( stGenSetting.stScanMenuSetting.u8ScanType == SCAN_TYPE_AUTO )
            {
            #if ENABLE_T_C_COMBO
                if(   (eTuneType == OSD_TUNE_TYPE_ATV_ONLY)
                    #if(!ENABLE_SBTVD_BRAZIL_APP)
                    ||(eTuneType == OSD_TUNE_TYPE_DTV_PLUS_ATV)
                    #endif
                  )
                {
                    MDrv_IFDM_Init();

                #if(FRONTEND_IF_DEMODE_TYPE == MSTAR_INTERN_VIF)
                    msAPI_ClearTunerFreq_Status();
                #endif
                }
            #endif

              #if ( ENABLE_DVB_TAIWAN_APP || ENABLE_SBTVD_BRAZIL_APP || (TV_SYSTEM == TV_NTSC) )
                msAPI_ATV_SetCurrentProgramNumber(msAPI_ATV_GetChannelMin()-1);
              #else
                ATV_SCAN_DBINFO( printf( "SCAN_TYPE_AUTO>> " ) );
                msAPI_Tuning_IsScanL(stGenSetting.stScanMenuSetting.u8LSystem);

                if ( stGenSetting.stScanMenuSetting.u8LSystem )
                {
                    ATV_SCAN_DBINFO( printf( "L System\n" ) );
                }
                else
                {
                    ATV_SCAN_DBINFO( printf( "BG System\n" ) );
                }

                #if ENABLE_CUS_UPDATE_SCAN
                if(g_bGotoUpdateScan)
                {
                    msAPI_ATV_SetCurrentProgramNumber(msAPI_ATV_GetActiveProgramCount());
                }
                else
                #endif
                {
                    msAPI_ATV_SetCurrentProgramNumber(0);
                }
              #endif

            #if (ENABLE_DTV)
                devCOFDM_PassThroughI2C(ENABLE);
            #endif

                msAPI_Tuner_TuningProcessor(AFT_EXT_STEP_SEARCHALL);
			#if 0//ENABLE_SZ_BLUESCREEN_FUNCTION		SMC jayden.chen move 20130308
			  ATV_SEARCH_STATE=TRUE;  //truth.xu add 20100901
			  msAPI_Scaler_SetBlueScreen( DISABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
			#endif
                enATVScanState = STATE_ATV_SCAN_WAIT;
            }
            else
            {
                ATV_SCAN_DBINFO( printf( "SCAN_TYPE_MANUAL>>\n" ) );

            #if (ENABLE_DTV)
                devCOFDM_PassThroughI2C(ENABLE);
            #endif

                if(stGenSetting.stScanMenuSetting.u8ATVManScanType==ATV_MAN_SCAN_TYPE_ONECH)
                {
                    ATV_SCAN_DBINFO( printf( "ATV_MAN_SCAN_TYPE_ONECH>>\n" ) );
                    if ( stGenSetting.stScanMenuSetting.u8ATVManScanDir == ATV_MAN_SCAN_UP )
                    {
                        ATV_SCAN_DBINFO( printf( "ATV_MAN_SCAN_UP>>\n" ) );
                        msAPI_Tuner_TuningProcessor(AFT_EXT_STEP_SEARCHONETOUP);
                    }
                    else
                    {
                        ATV_SCAN_DBINFO( printf( "ATV_MAN_SCAN_DOWN>>\n" ) );
                        msAPI_Tuner_TuningProcessor(AFT_EXT_STEP_SEARCHONETODOWN);
                    }
                 #if ENABLE_SZ_BLUESCREEN_FUNCTION
                   ATV_SEARCH_STATE=TRUE;  //truth.xu add 20100901
                   msAPI_Scaler_SetBlueScreen( DISABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
                 #endif
                    enATVScanState = STATE_ATV_SCAN_WAIT;
                }
                else
                {
                    enATVScanState = STATE_ATV_SCAN_END;
                }
                u8ManProcessStart = msAPI_Tuner_GetTuningProcessPercent();
            }
            break;

        case STATE_ATV_SCAN_WAIT:
            if ( stGenSetting.stScanMenuSetting.u8ScanType == SCAN_TYPE_AUTO )
            {
                bIsAutoScanInProgress = msAPI_Tuner_IsTuningProcessorBusy();

                if ( FALSE == bIsAutoScanInProgress )
                {
                    ATV_SCAN_DBINFO( printf( "Scan finished>>\n" ) );

                    enATVScanState = STATE_ATV_SCAN_END;

                    if(eTuneType == OSD_TUNE_TYPE_ATV_ONLY)
                    {
                        MApp_ZUI_ACT_ExecuteAutoTuningAction(EN_EXE_SCAN_CONFIRM_BTN_YES);
                    }
                    break;
                }

                bIsOneProgramDetected = msAPI_Tuner_IsOneProgramDetected();

                if ( TRUE == bIsOneProgramDetected )
                {
                    ATV_SCAN_DBINFO( printf( "One channel detected>>\n" ) );
                    enATVScanState = STATE_ATV_SCAN_SHOW_INFO;
                }

                if (msAPI_Tuner_PreProgramDeteted())
                {
                    if(_u16PreTunerPLL != msAPI_Tuner_GetCurrentChannelPLL())
                    {
                        MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_REPAINT_AUTOTUNING_PROGRESS);
                        _u16PreTunerPLL = msAPI_Tuner_GetCurrentChannelPLL();
                    }
                }
                else
                {
                #if ( ENABLE_DVB_TAIWAN_APP || ENABLE_SBTVD_BRAZIL_APP)
                    U8 u8Channel;
                    u8Channel = msAPI_ATV_GetCurrentProgramNumber()+1;
                    if ( PreATVScanChannel  != u8Channel)
                    {
                        PreATVScanChannel = u8Channel;
                        MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_REPAINT_AUTOTUNING_PROGRESS);
                    }
                #else

                  #if SCAN_FREQ_ATTIME
                    if ( PreATVScanPLL != msAPI_Tuner_GetCurrentChannelPLL())
                    {
                        PreATVScanPLL = msAPI_Tuner_GetCurrentChannelPLL();
                        MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_REPAINT_AUTOTUNING_PROGRESS);
                    }
                  #else
                    U8 u8Temp;

                    u8Temp = msAPI_Tuner_GetTuningProcessPercent();

                    if ( PreATVScanPercent  < u8Temp)
                    {
                        PreATVScanPercent = u8Temp;
                        MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_REPAINT_AUTOTUNING_PROGRESS);
                    }
                  #endif
                #endif
                }
            }
            else
            {
                if ( stGenSetting.stScanMenuSetting.u8ATVManScanType == ATV_MAN_SCAN_TYPE_ONECH )
                {
                    bIsOneProgramDetected = msAPI_Tuner_IsOneProgramDetected();

                    if ( TRUE == bIsOneProgramDetected )
                    {
                        u8ManProcessStart = msAPI_Tuner_GetTuningProcessPercent();
                        enATVScanState = STATE_ATV_SCAN_SHOW_INFO;
                        fATVManualScanDetectProgram = TRUE;
                    }
                    else
                    {
                        fATVManualScanDetectProgram = FALSE;
                        u8ManProcess = msAPI_Tuner_GetTuningProcessPercent();
                        if ( stGenSetting.stScanMenuSetting.u8ATVManScanDir == ATV_MAN_SCAN_UP )
                        {
                            if(u8ManProcessStart == 0)
                            {
                                if(u8ManProcess == 99)
                                {
                                    enATVScanState = STATE_ATV_SCAN_SHOW_INFO;
                                }
                            }
                            else
                            {

                                if((u8ManProcess == (u8ManProcessStart-1))
                                    #if ENABLE_CUS_UI_SPEC
                                    || (u8ManProcess == 100) // fix can't exit atv manual scan
                                    #endif
                                )
                                {
                                    enATVScanState = STATE_ATV_SCAN_SHOW_INFO;
                                }
                            }
                        }
                        else
                        {
                            if(u8ManProcessStart == 0)
                            {
                                if(u8ManProcess == 1)
                                {
                                    enATVScanState = STATE_ATV_SCAN_SHOW_INFO;
                                }
                            }
                            else
                            {
                                if(u8ManProcessStart == 100)
                                {
                                    if (u8ManProcess == 0)
                                    {
                                        enATVScanState = STATE_ATV_SCAN_SHOW_INFO;
                                    }
                                }
                                else if (u8ManProcess == (u8ManProcessStart+1))
                                {
                                    enATVScanState = STATE_ATV_SCAN_SHOW_INFO;
                                }
                            }
                        }

                        // Blink <<< or >>>
                        bIsAutoScanInProgress = msAPI_Tuner_IsTuningProcessorBusy();

                      #if ( ENABLE_DVB_TAIWAN_APP || ENABLE_SBTVD_BRAZIL_APP || (TV_SYSTEM == TV_NTSC) )
                        if(msAPI_ATV_GetDirectTuneFlag())
                        {
                            if ( FALSE == bIsAutoScanInProgress )
                            {
                                enATVScanState = STATE_ATV_SCAN_END;
                                break;
                            }
                            else
                                break;
                        }
                      #endif

                        if ( msAPI_Timer_DiffTimeFromNow( u32MonitorDiagnosticsSnrTimer )> DIAGNOSTICS_SNR_UPDATE_DELAY )
                        {
                            if ( stGenSetting.stScanMenuSetting.u8ATVManScanDir == ATV_MAN_SCAN_UP )
                            {
                              u32MonitorDiagnosticsSnrTimer = msAPI_Timer_GetTime0();
                            }
                            else
                            {
                              u32MonitorDiagnosticsSnrTimer = msAPI_Timer_GetTime0();
                            }
                        }
                    #if ( ENABLE_DVB_TAIWAN_APP || ENABLE_SBTVD_BRAZIL_APP )
                        MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_ATV_MANUAL_SCAN_SHOW_INFO);
                    #else
                      #if SCAN_FREQ_ATTIME
                        if ( PreATVScanPLL!= msAPI_Tuner_GetCurrentChannelPLL())
                        {
                            PreATVScanPLL = msAPI_Tuner_GetCurrentChannelPLL();
                            MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_ATV_MANUAL_SCAN_SHOW_INFO);
                        }
                      #else
                         MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_ATV_MANUAL_SCAN_SHOW_INFO);
                      #endif
                    #endif
                        if ( FALSE == bIsAutoScanInProgress )
                        {
                            enATVScanState = STATE_ATV_SCAN_END;
                            break;
                        }
                    }
                }
            }
            break;

        case STATE_ATV_SCAN_SHOW_INFO:
            ATV_SCAN_DBINFO( printf( "STATE_ATV_SCAN_SHOW_INFO>>\n" ) );

            if ( stGenSetting.stScanMenuSetting.u8ScanType == SCAN_TYPE_AUTO )
            {
              #if ( ENABLE_DVB_TAIWAN_APP || ENABLE_SBTVD_BRAZIL_APP || (TV_SYSTEM == TV_NTSC) )
                if(msAPI_ATV_IsProgramSearched(msAPI_ATV_GetCurrentProgramNumber()-1))
              #endif
                {
                    u8ScanAtvChNum++;
                }
                MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_REPAINT_AUTOTUNING_PROGRESS);
                enATVScanState = STATE_ATV_SCAN_WAIT;
            }
            else
            {
                // Update OSD to show station name, medium(CATV/Air), channel number and station name about detected channel.
                enATVScanState = STATE_ATV_SCAN_END;

            #if ( ENABLE_DVB_TAIWAN_APP || ENABLE_SBTVD_BRAZIL_APP || (TV_SYSTEM == TV_NTSC) )
               if(msAPI_ATV_GetDirectTuneFlag() == FALSE)
            #endif
            #if (ENABLE_CUS_UI_SPEC == FALSE)
                MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_ATV_MANUAL_SCAN_END);
            #endif
            }
            break;

        case STATE_ATV_SCAN_END:
        case STATE_ATV_SCAN_EXIT_2_MAIN_MENU:
        {
            AUDIOSTANDARD_TYPE u8CurAudioSystem;
            MApp_ATV_Scan_End();
 			#if ENABLE_SZ_BLUESCREEN_FUNCTION
			  ATV_SEARCH_STATE=FALSE; //truth.xu add 20100901
			  U8 u8TurnOffDestination = ENABLE;
			  MApi_XC_Mux_TriggerDestOnOffEvent(INPUT_SOURCE_TV,&u8TurnOffDestination);
			#endif

        #if ENABLE_SBTVD_BRAZIL_APP
          stGenSetting.stScanMenuSetting.u8Antenna = msAPI_ATV_GetCurrentAntenna();
        #endif

            if(enATVScanState == STATE_ATV_SCAN_EXIT_2_MAIN_MENU)
            {
                g_bCancelAutoscanByUser = TRUE;
            }
            else
            {
                g_bCancelAutoscanByUser = FALSE;
            }

            if ( stGenSetting.stScanMenuSetting.u8ScanType == SCAN_TYPE_AUTO )
            {
                if ( enATVScanState == STATE_ATV_SCAN_EXIT_2_MAIN_MENU ||(eTuneType == OSD_TUNE_TYPE_ATV_ONLY))
                {
                    enATVScanRetVal =EXIT_GOTO_PREVIOUS;
                    g_ePreVideoSystem = SIG_NONE;
                    msAPI_ATV_SetCurrentProgramNumber(msAPI_ATV_GetFirstProgramNumber(FALSE));
                    msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE_DURING_LIMITED_TIME, DELAY_FOR_STABLE_SIF, E_AUDIOMUTESOURCE_ACTIVESOURCE);
                    //BY 20090406 msAPI_VD_AdjustVideoFactor(E_ADJUST_VIDEOMUTE_DURING_LIMITED_TIME, DELAY_FOR_STABLE_TUNER);
                    msAPI_AVD_TurnOffAutoAV();
                    msAPI_Tuner_ChangeProgram();
                    //msAPI_VD_ClearSyncCheckCounter();
                    msAPI_AVD_ClearAspectRatio();
                    msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_INTERNAL_2_MUTEOFF, E_AUDIOMUTESOURCE_ACTIVESOURCE);
                    MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_AUTO_SCAN_FINISH);
                    ATV_SCAN_DBINFO( printf( "STATE_ATV_SCAN_EXIT_2_MAIN_MENU>>\n" ) );

                #if ENABLE_TTX
                    msAPI_TTX_VBIAcquireEnable(TRUE);
                #endif
                }
                else
                {
                #if ( ENABLE_DVB_TAIWAN_APP || ENABLE_SBTVD_BRAZIL_APP || (TV_SYSTEM == TV_NTSC) )
                    if(msAPI_ATV_GetCurrentAntenna() == ANT_CATV)
                    {
                        enATVScanRetVal =EXIT_GOTO_PREVIOUS;
                        //MApp_UiMenu_ExecuteKeyEvent( MIA_FINISH_SCAN );
                        g_ePreVideoSystem = SIG_NONE;
                        msAPI_ATV_SetCurrentProgramNumber(msAPI_ATV_GetFirstProgramNumber(FALSE));
                      #if ENABLE_SBTVD_BRAZIL_APP
                        MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_AUTO_SCAN_FINISH);
                      #endif
                        msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE_DURING_LIMITED_TIME, DELAY_FOR_STABLE_SIF, E_AUDIOMUTESOURCE_ACTIVESOURCE);
                        //BY 20090406 msAPI_VD_AdjustVideoFactor(E_ADJUST_VIDEOMUTE_DURING_LIMITED_TIME, DELAY_FOR_STABLE_TUNER);
                        msAPI_AVD_TurnOffAutoAV();
                        msAPI_Tuner_ChangeProgram();
                        //msAPI_VD_ClearSyncCheckCounter();
                        msAPI_AVD_ClearAspectRatio();

                        // to prevent sound when analog tuning is finished
                        msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_INTERNAL_2_MUTEOFF, E_AUDIOMUTESOURCE_ACTIVESOURCE);
                    }
                    else
                #endif
                    {
                    #if (SCAN_TEST_MODE_ENABLE==1)
                        if (AutoScanTest.u8State==TEST_MODE_ATV_SCAN_STATE_VERIFY)
                        {
                            AutoScanTest.u16VerifyCount++;
                            if (AutoScanTest.u16VerifyCount<10)
                            {
                                enATVScanState = STATE_ATV_SCAN_INIT;
                                return enATVScanRetVal;
                            }
                            else
                            {
                                AutoScanTest.u8State=TEST_MODE_ATV_SCAN_STATE_DISABLE;
                                AutoScanTest.u16VerifyCount=0;
                                AutoScanTest.u16Total_Lost_Channel=0;
                                AutoScanTest.u16Total_Ghost_Channel=0;
                            }
                        }

                     #if FRONTEND_TUNER_TYPE == XUGUANG_TDQ_6FT_W116H
                        enATVScanRetVal = EXIT_GOTO_PREVIOUS;//EXIT_ATV_SCAN_TRAN_PREVIOUS;
                     #else
                        if (eTuneType == OSD_TUNE_TYPE_ATV_ONLY)
                        {
                            MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_AUTO_SCAN_FINISH);

                        }
                      #if (ENABLE_DTV)
                        else
                        {
                            if( UI_INPUT_SOURCE_TYPE!= UI_INPUT_SOURCE_DTV)
                            {
                                UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_DTV;
                                MApp_InputSource_SwitchSource( UI_INPUT_SOURCE_TYPE, MAIN_WINDOW );
                                msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_INTERNAL_2_MUTEON, E_AUDIOMUTESOURCE_ACTIVESOURCE);
                            }

                          #if ENABLE_SBTVD_BRAZIL_APP
                            enATVScanRetVal =EXIT_GOTO_CATVSCAN;
                          #else
                            enATVScanRetVal =EXIT_GOTO_DTVSCAN;
                          #endif
                        }
                      #endif // #if (ENABLE_DTV)
                     #endif // #if FRONTEND_TUNER_TYPE == XUGUANG_TDQ_6FT_W116H
                    #else // #if (SCAN_TEST_MODE_ENABLE==1)
                      #if (ENABLE_DTV)
                        MApp_ChannelChange_DisableChannel(TRUE,MAIN_WINDOW);
                        if( UI_INPUT_SOURCE_TYPE!= UI_INPUT_SOURCE_DTV)
                        {
                            UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_DTV;
                            //MApp_InputSource_SwitchSource( UI_INPUT_SOURCE_TYPE, MAIN_WINDOW );
                            MApp_InputSource_ChangeInputSource(MAIN_WINDOW);
                            msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_INTERNAL_2_MUTEON, E_AUDIOMUTESOURCE_ACTIVESOURCE);
                        }

                        #if (ENABLE_PIP)
                        if(IsPIPEnable())
                        {
                            if(stGenSetting.g_stPipSetting.enPipSoundSrc==EN_PIP_SOUND_SRC_SUB)
                            {
                                stGenSetting.g_stPipSetting.enPipSoundSrc=EN_PIP_SOUND_SRC_MAIN;
                                MApp_InputSource_PIP_ChangeAudioSource(MAIN_WINDOW);
                            }
                            UI_SUB_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_NONE;
                            MApp_InputSource_ChangeInputSource(SUB_WINDOW);
                            stGenSetting.g_stPipSetting.enPipMode = EN_PIP_MODE_OFF;
                            UI_SUB_INPUT_SOURCE_TYPE = MApp_InputSource_GetUIInputSourceType(MApp_InputSource_PIP_Get1stCompatibleSrc(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)));
                        }
                        #endif
                        MApp_InputSource_ChangeInputSource(MAIN_WINDOW );
                      #if ENABLE_SBTVD_BRAZIL_APP
                        enATVScanRetVal =EXIT_GOTO_CATVSCAN;
                      #else
                        enATVScanRetVal =EXIT_GOTO_DTVSCAN;
                      #endif
                      #else // #if (ENABLE_DTV)
                        enATVScanRetVal =EXIT_GOTO_PREVIOUS;
                      #endif
                        //ATV_SCAN_DBINFO( printf( "STATE_ATV_SCAN_END>>\n" ) );
                      #endif // #if (SCAN_TEST_MODE_ENABLE==1)
                    }
                }
            }
            else
            {
            #if ENABLE_CUS_UI_SPEC
                enATVScanRetVal =EXIT_GOTO_PREVIOUS;
                g_ePreVideoSystem = SIG_NONE;
                u8CurAudioSystem=msAPI_AUD_GetAudioStandard();
                msAPI_ATV_SetCurrentProgramNumber(msAPI_ATV_GetCurrentProgramNumber());
                msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE_DURING_LIMITED_TIME, DELAY_FOR_STABLE_SIF, E_AUDIOMUTESOURCE_ACTIVESOURCE);
                //BY 20090406 msAPI_VD_AdjustVideoFactor(E_ADJUST_VIDEOMUTE_DURING_LIMITED_TIME, DELAY_FOR_STABLE_TUNER);
                msAPI_AVD_TurnOffAutoAV();
                msAPI_Tuner_ChangeProgram();
                //msAPI_VD_ClearSyncCheckCounter();
                msAPI_AVD_ClearAspectRatio();
                msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_INTERNAL_2_MUTEOFF, E_AUDIOMUTESOURCE_ACTIVESOURCE);
                if((fATVManualScanDetectProgram == FALSE) && (g_bCancelAutoscanByUser == FALSE))
                {
                    MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_ATV_MANUAL_SCAN_FINISH_EXIT_TO_CHANNEL_PAGE);

                }
                else
                {
                    MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_ATV_MANUAL_SCAN_FINISH);
                }
            #else
                enATVScanRetVal =EXIT_GOTO_PREVIOUS;
                g_ePreVideoSystem = SIG_NONE;
                u8CurAudioSystem=msAPI_AUD_GetAudioStandard();
                msAPI_AUD_SetAudioStandard(u8CurAudioSystem);
                msAPI_Tuner_SetIF();
            #endif
            #if ENABLE_TTX
                msAPI_TTX_VBIAcquireEnable(TRUE);
            #endif
            }
            enATVScanState = STATE_ATV_SCAN_INIT;
        }
        break;

        case STATE_ATV_SCAN_PAUSE:
            ATV_SCAN_DBINFO( printf( "STATE_ATV_SCAN_PAUSE>>\n" ) );
            if(fEndHalt)
            {
                ATV_SCAN_DBINFO( printf( "End Halt>>\n" ) );
                if(fReturnToPrevious)
                {
                    ATV_SCAN_DBINFO( printf( "Return to previous state>>\n" ) );
                    enATVScanState=enPreATVScanState;
                }
                else
                {
                    ATV_SCAN_DBINFO( printf( "Go to end>>\n" ) );
                        enATVScanState=STATE_ATV_SCAN_EXIT_2_MAIN_MENU;
                }
                fEndHalt=FALSE;
            }
            else
            {
                ATV_SCAN_DBINFO( printf( "Start halt>>\n" ) );
            }
            break;

        case STATE_ATV_SCAN_GOTO_STANDBY:
            MApp_ATV_Scan_End();
            if ( g_enScanType == SCAN_TYPE_AUTO )
            {
                MApp_ZUI_ACT_ShutdownOSD();
            }

            enATVScanRetVal =EXIT_GOTO_STANDBY;
            enATVScanState = STATE_ATV_SCAN_INIT;
            break;
    }

    return enATVScanRetVal;
}


//********************************************************************************
//            Static Functions
//********************************************************************************
static void MApp_ATV_Scan_ProcessUserInput( void )
{
    switch ( u8KeyCode )
    {
        case KEY_POWER:
        case DSC_KEY_PWROFF:
            enATVScanState = STATE_ATV_SCAN_GOTO_STANDBY;
            MApp_ZUI_ProcessKey(u8KeyCode);
            break;

        case KEY_EXIT:
        case KEY_MENU:
            if ( stGenSetting.stScanMenuSetting.u8ScanType == SCAN_TYPE_AUTO )
            {
                #if ENABLE_CUS_UI_SPEC
                if(MApp_ZUI_ACT_bIsCurrentOSDisAutoScanPage() && msAPI_Tuner_IsTuningProcessorBusy())
                {
                    enPreATVScanState = enATVScanState;
                    enATVScanState=STATE_ATV_SCAN_EXIT_2_MAIN_MENU;
                }
                else
                #endif
                {
                    if(enATVScanState ==STATE_ATV_SCAN_PAUSE )
                    {
                        u8KeyCode = NULL;
                    }
                    else
                    {
                        if(eTuneType == OSD_TUNE_TYPE_ATV_ONLY)
                        {
                            u8KeyCode = KEY_EXIT;
                        }

                        fEndHalt = FALSE;
                        fReturnToPrevious = FALSE;
                        enPreATVScanState = enATVScanState;
                        enATVScanState = STATE_ATV_SCAN_PAUSE;
                        MApp_ZUI_ProcessKey(u8KeyCode);
                    }
                }
            }
            else if( stGenSetting.stScanMenuSetting.u8ScanType == SCAN_TYPE_MANUAL )
            {
                #if ENABLE_CUS_UI_SPEC
                if(((KEY_EXIT == u8KeyCode) ||(KEY_MENU== u8KeyCode) )&& msAPI_Tuner_IsTuningProcessorBusy())
                {
                    enPreATVScanState = enATVScanState;
                    enATVScanState=STATE_ATV_SCAN_EXIT_2_MAIN_MENU;
                    //MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_ATV_MANUAL_SCAN_END);
                }
                #else
                if(KEY_EXIT == u8KeyCode && msAPI_Tuner_IsTuningProcessorBusy())
                {
                    enATVScanState = STATE_ATV_SCAN_END;
                    MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_ATV_MANUAL_SCAN_END);
                }
                #endif

            }
            u8KeyCode = NULL;
            break;

#if (ENABLE_CUS_UI_SPEC == DISABLE)
        case KEY_SELECT:
            if ( stGenSetting.stScanMenuSetting.u8ScanType == SCAN_TYPE_AUTO )
            {
                MApp_ZUI_ProcessKey(u8KeyCode);
            }
            break;

        case KEY_LEFT:
        case KEY_RIGHT:
            if ( stGenSetting.stScanMenuSetting.u8ScanType == SCAN_TYPE_AUTO )
            {
                MApp_ZUI_ProcessKey(u8KeyCode);
            }
            else if( stGenSetting.stScanMenuSetting.u8ScanType == SCAN_TYPE_MANUAL )
            {
                if(msAPI_Tuner_IsTuningProcessorBusy())
                {
                    if( (KEY_RIGHT == u8KeyCode && stGenSetting.stScanMenuSetting.u8ATVManScanDir == ATV_MAN_SCAN_DOWN) ||
                        (KEY_LEFT == u8KeyCode && stGenSetting.stScanMenuSetting.u8ATVManScanDir == ATV_MAN_SCAN_UP))
                    {
                        enATVScanState = STATE_ATV_SCAN_END;
                        MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_ATV_MANUAL_SCAN_END);
                    }
                }
            }
            break;
#endif
            default:
                break;
    }
    u8KeyCode = KEY_NULL;
}


void MApp_ATV_SetATVScanState(EN_ATV_SCAN_STATE atvScanState)
{
    enATVScanState = atvScanState;
}


void MApp_ATV_ExitATVScanPauseState(void)
{
    fEndHalt = TRUE;
    enATVScanState = enPreATVScanState;
    fReturnToPrevious =TRUE;
}

void MApp_ATV_ExitATVScanPause2Menu(void)
{
    fEndHalt = TRUE;
    enPreATVScanState = STATE_ATV_SCAN_EXIT_2_MAIN_MENU;
    fReturnToPrevious =TRUE;

}

void MApp_ATV_ExitATVScanPause2ScanEnd(void)
{
    fEndHalt = TRUE;
    enPreATVScanState = STATE_ATV_SCAN_END;
    fReturnToPrevious =TRUE;
}


#undef MAPP_ATV_SCAN_C



