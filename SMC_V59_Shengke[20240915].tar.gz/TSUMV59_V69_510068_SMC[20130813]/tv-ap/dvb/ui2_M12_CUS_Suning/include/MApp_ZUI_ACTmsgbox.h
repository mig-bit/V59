////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MAPP_ZUI_ACTMSGBOX_H
#define _MAPP_ZUI_ACTMSGBOX_H

#ifdef __cplusplus
extern "C" {
#endif  /* __cplusplus */

#include "MApp_ZUI_APIgdi.h"

#ifdef MAPP_ZUI_ACTMSGBOX_C
#define INTERFACE
#else
#define INTERFACE extern
#endif
/////////////////////////////////////////////////////////////////////

typedef enum _MSGBOX_MODE
{
    EN_MSGBOX_MODE_INVALID,
    EN_MSGBOX_MODE_FUNC_NOT_AVAIL    ,      ///< show function not availiable message box
    EN_MSGBOX_MODE_PING_MSGBOX,                     ///< show ping result message box
    EN_MSGBOX_MODE_MHEG5_SUBTITLE    ,      ///< show MHEG5 subtitle co-exist message box
    EN_MSGBOX_MODE_LOADING_MHEG5    ,       ///< show loading MHEG5 message box
    EN_MSGBOX_MODE_AUTO_ADJUSTING    ,      ///< show auto adjusting message box
    EN_MSGBOX_MODE_NO_TELETEXT   ,       ///< show no teletext message box
    EN_MSGBOX_MODE_NO_TTX_SUBTITLE_MSGBOX,             ///< show no teletext subtitle message box
    EN_MSGBOX_MODE_KEY_LOCK    ,            ///< show key lock message box
    EN_MSGBOX_MODE_KEY_LOCK_HOTEL_MODE ,    ///< show key lock message box for hotel mode
    EN_MSGBOX_MODE_KEY_UNLOCK_HOTEL_MODE,   ///< show key unlock message box for hotel mode
    EN_MSGBOX_MODE_SOURCE_KEY_LOCK_MSGBOX, ///< show source key lock message box :add for hotel menu @chuxu
    EN_MSGBOX_MODE_REMOTE_CONTROL_LOCK_MSGBOX,///< show remote control lock message box :add for hotel menu @chuxu
    EN_MSGBOX_MODE_OSD_DISPLAY_LOCK_MSGBOX,///< show osd display lock message box :add for hotel menu @chuxu
    EN_MSGBOX_MODE_CEC_DEVICE,              ///< show CEC device message
    EN_MSGBOX_MODE_POWER_OFF_COUNTDOWN,         ///< show power off countdown message box
    EN_MSGBOX_MODE_PASSWORD_INPUT,
    EN_MSGBOX_MODE_WRONG_PASSWORD,
} MSGBOX_MODE;
/////////////////////////////////////////
// Cutomize Window Procedures...
//INTERFACE S32 MApp_ZUI_ACT_MessageBoxWinProc(HWND, PMSG);

//#define MESSAGEBOX_WINPROC MApp_ZUI_ACT_MessageBoxWinProc

#if CUS_SMC_ENABLE_HOTEL_MODE
INTERFACE BOOLEAN bHotelKeyLock;
#endif

INTERFACE S32 MApp_ZUI_ACT_MsgBoxTextPaneWinProc(HWND, PMSG);
INTERFACE S32 MApp_ZUI_ACT_MsgBox_PasswordInputWinProc(HWND hwnd, PMSG msg);
#define MSGBOXTEXTPANE_WINPROC MApp_ZUI_ACT_MsgBoxTextPaneWinProc
#define MSGBOXPWDINPUT_WINPROC MApp_ZUI_ACT_MsgBox_PasswordInputWinProc
/////////////////////////////////////////
// Event Handlers....
INTERFACE void MApp_ZUI_ACT_AppShowMessageBox(void);
INTERFACE BOOLEAN MApp_ZUI_ACT_HandleMessageBoxKey(VIRTUAL_KEY_CODE key);
INTERFACE void MApp_ZUI_ACT_TerminateMessageBox(void);
INTERFACE BOOLEAN MApp_ZUI_ACT_ExecuteMessageBoxAction(U16 act);
INTERFACE LPTSTR MApp_ZUI_ACT_GetMessageBoxDynamicText(HWND hwnd);
//INTERFACE S16 MApp_ZUI_ACT_GetMessageBoxDynamicValue(HWND hwnd);
#if 1//(ENABLE_ATV_VCHIP)
INTERFACE MSGBOX_MODE MApp_ZUI_ACT_GetMessageBoxMode(void);
#endif

#define PASSWORD_INPUT_MASK 0xF

#undef INTERFACE

#ifdef __cplusplus
}
#endif  /* __cplusplus */

#endif /* _MAPP_ZUI_ACTMSGBOX_H */

