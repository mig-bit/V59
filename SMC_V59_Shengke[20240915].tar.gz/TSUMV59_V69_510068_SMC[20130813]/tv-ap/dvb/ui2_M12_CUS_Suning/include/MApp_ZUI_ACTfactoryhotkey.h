////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MAPP_ZUI_ACTFACTORYHOTKEY_H
#define _MAPP_ZUI_ACTFACTORYHOTKEY_H
#if ENABLE_CUS_FACTORY_HOTKEY_MENU

#ifdef __cplusplus
extern "C" {
#endif  /* __cplusplus */

#include "MApp_ZUI_APIgdi.h"

#ifdef MAPP_ZUI_ACTFACTORYHOTKEY_C
#define INTERFACE
#else
#define INTERFACE extern
#endif
//CUS_XM:xue add for show factory operation information 2012-7-6
typedef enum _FACTORY_HOTKEY_MODE
{
	EN_FACTORY_HOTKEY_MODE_INVALID,
	EN_FACTORY_HOTKEY_MODE_FACTORY_RC_RST,	
	EN_FACTORY_HOTKEY_MODE_FACTORY_RC_BURNIN,
	EN_FACTORY_HOTKEY_MODE_FACTORY_RC_AIRCABLE,
	EN_FACTORY_HOTKEY_MODE_FACTORY_RC_CTC,
	EN_FACTORY_HOTKEY_MODE_FACTORY_RC_PRE_CH,
	EN_FACTORY_HOTKEY_MODE_FACTORY_RC_VOL_MAX,
	EN_FACTORY_HOTKEY_MODE_FACTORY_RC_VOL_BUZZ,
	EN_FACTORY_HOTKEY_MODE_FACTORY_RC_VOL_LEFT,
	EN_FACTORY_HOTKEY_MODE_FACTORY_RC_VOL_RIGHT,
	EN_FACTORY_HOTKEY_MODE_FACTORY_RC_PICTURE,
	EN_FACTORY_HOTKEY_MODE_FACTORY_RC_AUDIO,
	EN_FACTORY_HOTKEY_MODE_FACTORY_RC_LOG_LED,
	EN_FACTORY_HOTKEY_MODE_FACTORY_RC_2D3D,		
	EN_FACTORY_HOTKEY_MODE_FACTORY_RC_ARC,
	EN_FACTORY_HOTKEY_MODE_FACTORY_RC_CI_ADD,
	EN_FACTORY_HOTKEY_MODE_FACTORY_RC_VIRG_IN,
	EN_FACTORY_HOTKEY_MODE_FACTORY_RC_REGIN,
	EN_FACTORY_HOTKEY_MODE_FACTORY_RC_CLONE,
	EN_FACTORY_HOTKEY_MODE_FACTORY_RC_CLK,
	EN_FACTORY_HOTKEY_MODE_FACTORY_RC_DCR,
	EN_FACTORY_HOTKEY_MODE_FACTORY_RC_ADC,
	EN_FACTORY_HOTKEY_MODE_FACTORY_RC_BLK,
	EN_FACTORY_HOTKEY_MODE_FACTORY_RC_WP,
	EN_FACTORY_HOTKEY_MODE_FACTORY_RC_LIGHT_SENSOR,
	EN_FACTORY_HOTKEY_MODE_FACTORY_RC_USB,
	EN_FACTORY_HOTKEY_MODE_FACTORY_RC_RJ45,
	EN_FACTORY_HOTKEY_MODE_FACTORY_RC_RS232,
	EN_FACTORY_HOTKEY_MODE_FACTORY_RC_NULL_KEY,
} FACTORY_HOTKEY_MODE;

/////////////////////////////////////////
// Cutomize Window Procedures...
//INTERFACE S32 MApp_ZUI_ACT_FactoryHotkeyOptionWinProc(HWND, PMSG);

//#define FactoryHotkeyOPTION_WINPROC MApp_ZUI_ACT_FactoryHotkeyOptionWinProc

/////////////////////////////////////////
// Event Handlers....
INTERFACE void MApp_ZUI_ACT_SetFactoryHotkeyMode(FACTORY_HOTKEY_MODE eFactoryHotkeyMode);
INTERFACE FACTORY_HOTKEY_MODE MApp_ZUI_ACT_GetFactoryHotkeyMode(void);
INTERFACE void MApp_ZUI_ACT_AppShowFactoryHotkeyOption(void);
INTERFACE BOOLEAN MApp_ZUI_ACT_HandleFactoryHotkeyOptionKey(VIRTUAL_KEY_CODE key);
INTERFACE void MApp_ZUI_ACT_TerminateFactoryHotkeyOption(void);
INTERFACE BOOLEAN MApp_ZUI_ACT_ExecuteFactoryHotkeyOptionAction(U16 act);
INTERFACE LPTSTR MApp_ZUI_ACT_GetFactoryHotkeyOptionDynamicText(HWND hwnd);
//INTERFACE S16 MApp_ZUI_ACT_GetFactoryHotkeyOptionDynamicValue(HWND hwnd);
//extern void Mapp_Factory_RC_ADCkey(void);
//cus_xm:xue add burnin&pattern function 2012-6-11
extern void Mapp_AdjustVolumeMax(void);
extern void Mapp_AdjustVolumeHalt(void);
extern void Mapp_BalanceVolLeft(void);
extern void Mapp_BalanceVolRight(void);
extern void Mapp_FactoryRCCTCKey(void);
extern void Mapp_BackLightAdjust50or100(U8 blvalue);
extern void Mapp_AdjustPictureMode(void);
extern void Mapp_AdjustAudioMode(void);
extern void Mapp_FactoryRCADC(void);
extern void Mapp_FactoryRCRST(void);
//extern void Mapp_FactoryRCCHScan(void);
extern void Mapp_SwitchDCRMode(void);
extern  BOOLEAN Mapp_SwitchRS232Mode(void);
//CUS_XM:xue add for ADC key vaild 2012-7-9

#if PANEL_TYPE==_1024x600_

INTERFACE void msAPI_Ajust_Vcom_value(void);
#endif



#undef INTERFACE

#ifdef __cplusplus
}
#endif  /* __cplusplus */
#endif
#endif /* _MAPP_ZUI_ACTHOTKEY_H */

