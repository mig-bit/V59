////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (MStar Confidential Information!�L) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef __API_FREQTABLE_CADTV_H__
#define __API_FREQTABLE_CADTV_H__
#if ENABLE_DTV
#if DVB_C_ENABLE
#include "MApp_GlobalSettingSt.h"


void msAPI_DCFT_SelectBuiltInFreqTableforCountry(EN_OSD_COUNTRY_SETTING eCountry);
U32 msAPI_DCFT_GetBuiltInNextFreq(U32 u32Freq);
BOOLEAN msAPI_DCFT_IsThisFreqInBuiltinFreqTbl(U32 u32Freq);
void msAPI_DCFT_ResetNITNewFreqTbl(void);
void msAPI_DCFT_SetFreqToNITNewFreqTbl(U32 u32Freq);
U32 msAPI_DCFT_GetNITNextFreq(void);
U8 msAPI_DCFT_CalculatePercentTbl(void);


#endif
#endif
#endif

