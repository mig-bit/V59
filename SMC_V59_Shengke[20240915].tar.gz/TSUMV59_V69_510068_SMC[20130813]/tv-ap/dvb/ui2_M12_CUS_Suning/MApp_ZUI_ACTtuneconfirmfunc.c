////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#define MAPP_ZUI_ACTTUNECONFIRMFUNC_C
#define _ZUI_INTERNAL_INSIDE_ //NOTE: for ZUI internal


//-------------------------------------------------------------------------------------------------
// Include Files
//-------------------------------------------------------------------------------------------------
#include "Board.h"
#include "datatype.h"
#include "MsCommon.h"
#include "apiXC.h"
#include "apiXC_Adc.h"
#include "MApp_GlobalSettingSt.h"
#include "MApp_ZUI_Main.h"
#include "MApp_ZUI_APIcommon.h"
#include "MApp_ZUI_APIstrings.h"
#include "MApp_ZUI_APIwindow.h"
#include "ZUI_tables_h.inl"
#include "MApp_ZUI_APIgdi.h"
#include "MApp_ZUI_APIcontrols.h"
#include "MApp_ZUI_ACTmainpage.h"
#include "MApp_ZUI_ACTeffect.h"
#include "MApp_ZUI_APIdraw.h"
#include "MApp_ZUI_ACTglobal.h"
#include "OSDcp_String_EnumIndex.h"
#include "ZUI_exefunc.h"

#include "MApp_GlobalFunction.h"
#include "MApp_UiMenuDef.h"
#include "MApp_RestoreToDefault.h"
#include "MApp_ChannelChange.h"
#if DVB_C_ENABLE
#include "MApp_Scan.h"
#endif
////////////////////////////////////////////////////
//NOTE: when we are selecting country, don't modify the real one!!
static EN_OSD_COUNTRY_SETTING _eTuningCountry;

#if ENABLE_DTV
#if ENABLE_SBTVD_BRAZIL_APP
EN_OSD_TUNE_TYPE_SETTING eTuneType = OSD_TUNE_TYPE_AIR_PLUS_CABLE;
#else
EN_OSD_TUNE_TYPE_SETTING eTuneType = OSD_TUNE_TYPE_DTV_PLUS_ATV;
#endif
#if ENABLE_DVBC_PLUS_DTMB_CHINA_APP
BOOLEAN _bNITScan = FALSE;
#endif
#else
EN_OSD_TUNE_TYPE_SETTING eTuneType = OSD_TUNE_TYPE_ATV_ONLY;
#endif

#if (ENABLE_CUS_UI_SPEC == FALSE)/*Creass.liu at 2012-06-27*/
BOOLEAN MApp_ZUI_ACT_ExecuteTuningConfirmDialogAction(U16 act)
{
    switch(act)
    {
        case EN_EXE_CLOSE_TUNING_CONFIRM:
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_TUNE_CONFIRM, SW_HIDE);

            #if ENABLE_T_C_COMBO
            extern EN_DVB_TYPE MApp_DVBType_GetCurrentType(void);
            if(MApp_DVBType_GetCurrentType() == EN_DVB_T_TYPE)
            {
                MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_DVB_SELECT_MENU, SW_SHOW);
                MApp_ZUI_API_SetFocus(HWND_SELECTED_DVBT_BG);
            }
            else
                MApp_ZUI_ACT_ShowDVBCScanPage();

            #else
            //MApp_ZUI_ACT_ShowMainMenuBackground(HWND_MENU_BOTTOM_BALL_FOCUS_CHANNEL);
            MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_PAGE, SW_SHOW);
            MApp_ZUI_API_SetFocus(HWND_MENU_CHANNEL_AUTOTUNE);
            #endif
            //MApp_ZUI_API_PostMessage(HWND_MENU_DLG_TUNE_CONFIRM, MSG_EFFECT_ROLLUP, 0);
            return TRUE;

#if ENABLE_T_C_COMBO
        case EN_EXE_CLOSE_DVB_SELECT:
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_DVB_SELECT_MENU, SW_HIDE);
            //MApp_ZUI_ACT_ShowMainMenuBackground(HWND_MENU_BOTTOM_BALL_FOCUS_CHANNEL);
            MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_PAGE, SW_SHOW);
            MApp_ZUI_API_SetFocus(HWND_MENU_CHANNEL_AUTOTUNE);
            if(IsDTVInUse())
            {
				MApp_DVBType_SetCurrentType(MApp_DVBType_GetPrevType());
                switch (MApp_DVBType_GetPrevType())
                {
                    case EN_DVB_T_TYPE:
                    {
                        if(msAPI_Tuner_GetDspStatus() != 0x01)//1: DVBT, 2:DVBC, 3:ATSC, 0xff: Null
                        {
                            MApp_ChannelChange_DisableChannel(TRUE,MAIN_WINDOW);
                            msAPI_Tuner_SwitchSource((EN_DVB_TYPE)stGenSetting.stScanMenuSetting.u8DVBCTvConnectionType, TRUE);
                            MApp_ChannelChange_EnableChannel(MAIN_WINDOW);
                            //Cancel Freeze
                            if(g_bIsImageFrozen)
                            {
                                g_bIsImageFrozen = FALSE;
                                MApi_XC_FreezeImg(g_bIsImageFrozen, MAIN_WINDOW);
                            }
                        }
                        break;
                   }
                    case EN_DVB_C_TYPE:
                    {
                        if(msAPI_Tuner_GetDspStatus() != 0x02)//1: DVBT, 2:DVBC, 3:ATSC, 0xff: Null
                        {
                            MApp_ChannelChange_DisableChannel(TRUE,MAIN_WINDOW);
                            msAPI_Tuner_SwitchSource((EN_DVB_TYPE)stGenSetting.stScanMenuSetting.u8DVBCTvConnectionType, TRUE);
                            MApp_ChannelChange_EnableChannel(MAIN_WINDOW);
                            //Cancel Freeze
                            if(g_bIsImageFrozen)
                            {
                                g_bIsImageFrozen = FALSE;
                                MApi_XC_FreezeImg(g_bIsImageFrozen, MAIN_WINDOW);
                            }
                        }
                        break;
                   }

                   default:
                    break;
                }
            }
            return TRUE;
#endif

        /*case EN_EXE_DEC_TEMP_COUNTRY:
        case EN_EXE_INC_TEMP_COUNTRY:
            //from case MAPP_UIMENUFUNC_ADJUSTE2COUNTRY:
            _eTuningCountry = (EN_OSD_COUNTRY_SETTING)MApp_ZUI_ACT_DecIncValue_Cycle(
                act==EN_EXE_INC_TEMP_COUNTRY,
                _eTuningCountry, OSD_COUNTRY_AUSTRALIA, OSD_COUNTRY_NUMS-1, 1);

            MApp_ZUI_API_InvalidateWindow(HWND_MENU_DLG_TUNE_CONFIRM_COUNTRY_GRID);
            return TRUE;*/
        case EN_EXE_DEC_TUNE_TYPE:
        case EN_EXE_INC_TUNE_TYPE:
            //from case MAPP_UIMENUFUNC_ADJUSTE2COUNTRY:
            #if ENABLE_SBTVD_BRAZIL_APP
               /*
               eTuneType = (EN_OSD_TUNE_TYPE_SETTING)MApp_ZUI_ACT_DecIncValue_Cycle(
                    act==EN_EXE_INC_TUNE_TYPE,
                    eTuneType, OSD_TUNE_TYPE_AIR_PLUS_CABLE, OSD_TUNE_TYPE_NUMS-1, 1);
                */
                eTuneType = OSD_TUNE_TYPE_AIR_PLUS_CABLE;
            #else
                eTuneType = (EN_OSD_TUNE_TYPE_SETTING)MApp_ZUI_ACT_DecIncValue_Cycle(
                    act==EN_EXE_INC_TUNE_TYPE,
                    eTuneType, OSD_TUNE_TYPE_DTV_PLUS_ATV, OSD_TUNE_TYPE_NUMS-1, 1);
            #endif
            MApp_ZUI_API_InvalidateWindow(HWND_MENU_DLG_TUNE_CONFIRM_TUNE_TYPE_OPTION);
            return TRUE;

        default:
            ZUI_DBG_FAIL(printf("[ZUI]CLOCKACT\n"));
            ABORT();


    }
    return FALSE;
}

///////////////////////////////////////////////////////////////////////////////
extern U16 _MApp_ZUI_ACT_GetCountryStringID(EN_OSD_COUNTRY_SETTING country);

LPTSTR MApp_ZUI_ACT_GetTuningConfirmDynamicText(HWND hwnd)
{
    U16 u16TempID = Empty;

    switch(hwnd)
    {
        case HWND_MENU_DLG_TUNE_CONFIRM_TUNE_TYPE_OPTION:
            switch(eTuneType)
            {
#if ENABLE_SBTVD_BRAZIL_APP
                case OSD_TUNE_TYPE_AIR_PLUS_CABLE:
                    u16TempID = en_str_Tune_Type_Air_Cable;
                    break;
                default :
                    u16TempID = en_str_Tune_Type_Air_Cable;
                    break;
#else
                case OSD_TUNE_TYPE_DTV_PLUS_ATV:
                    u16TempID = en_str_Tune_Type_DTV_ATV;
                    break;
                case OSD_TUNE_TYPE_DTV_ONLY:
                    u16TempID = en_strDTV;
                    break;
                case OSD_TUNE_TYPE_ATV_ONLY:
                    u16TempID = en_strInputSourceAtvText;
                    break;
 #if DVB_C_ENABLE
                /*case OSD_TUNE_TYPE_CADTV_ONLY:
                    u16TempID = en_strInputSourceCADTVText;
                    break;*/
#endif
                default :
                    u16TempID = en_str_Tune_Type_DTV_ATV;
                    break;
#endif
            }
            break;
    }

    if (u16TempID != Empty)
        return MApp_ZUI_API_GetString(u16TempID);
    return 0; //for empty string....
}
#endif

EN_OSD_COUNTRY_SETTING MApp_GetTuningCountry_DTG(void)
{
     if (_eTuningCountry >= OSD_COUNTRY_NUMS)
     {
        MS_DEBUG_MSG(printf("Get Country Overflow: %u\n", (U16)_eTuningCountry));
        _eTuningCountry = DEFAULT_TUNING_COUNTRY;
     }
     return _eTuningCountry;
}

void MApp_SetTuningMenuCountry(EN_OSD_COUNTRY_SETTING eCountry)
{
    if (eCountry >= OSD_COUNTRY_NUMS)
    {
        MS_DEBUG_MSG(printf("Set Country Overflow: %u\n", (U16)eCountry));
        eCountry = DEFAULT_TUNING_COUNTRY;
    }
    _eTuningCountry = (EN_OSD_COUNTRY_SETTING)eCountry;
}


EN_OSD_COUNTRY_SETTING MApp_ZUI_ACT_GetTuningCountry(void)
{
    return _eTuningCountry;
}

void MApp_ZUI_ACT_SetTuningCountry(EN_OSD_COUNTRY_SETTING TuningCountry)
{
    _eTuningCountry = TuningCountry;
}

#undef MAPP_ZUI_ACTTUNECONFIRMFUNC_C
