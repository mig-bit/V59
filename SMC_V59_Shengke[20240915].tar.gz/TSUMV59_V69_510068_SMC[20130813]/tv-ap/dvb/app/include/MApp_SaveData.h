////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef MAPP_SAVEDATA_H
#define MAPP_SAVEDATA_H

#include "Board.h"
#include "msAPI_Global.h"
#include "msAPI_ATVSystem.h"
#include "apiXC_ModeParse.h"

#if (ENABLE_DTV_EPG)
#include "MApp_EpgTimer.h"
#endif

#include "MApp_GlobalSettingSt.h" //ZUI
#include "MApp_EEPROM_Map.h"

#if ENABLE_CI
    #include "msAPI_CI.h"
#endif

#ifdef MAPP_SAVEDATA_C
    #define INTERFACE
#else
    #define INTERFACE                       extern
#endif

#if (RM_EEPROM_TYPE == RM_TYPE_24C512 )
    #define RM_MAX_ADDRESS                  (0xffff)
#elif (RM_EEPROM_TYPE == RM_TYPE_24C16 )
    #define RM_MAX_ADDRESS                  (0x07ff)
#elif (RM_EEPROM_TYPE == RM_TYPE_24C32 )
    #define RM_MAX_ADDRESS                  (0x0fff)
#elif (RM_EEPROM_TYPE == RM_TYPE_24C64)
    #define RM_MAX_ADDRESS                  (0x1fff)
#endif


//------ FLASH DB setting ------------------------------------------------------
#if (HDCP_KEY_TYPE == HDCP_KEY_IN_DB)
    #define HDCP_DB_BANK                    ( (FLASH_SIZE - CM_DATABASE_FLASH_SIZE)/FLASH_BLOCK_SIZE - 1 ) // 7B(8MB)  3B (4MB)
    #define HDCP_DB_SIZE                    ( FLASH_BLOCK_SIZE * 1 )
#endif

#if (EEPROM_DB_STORAGE == EEPROM_SAVE_NONE)
    #define QUICK_DB_GENSETTING_BANK        ( (FLASH_SIZE-CM_DATABASE_FLASH_SIZE)/FLASH_BLOCK_SIZE ) // 7C
    #define QUICK_DB_GENSETTING_SIZE        ( FLASH_BLOCK_SIZE * 2 )

    #define SYSTEM_BANK_DATABASE1           ( QUICK_DB_GENSETTING_BANK + QUICK_DB_GENSETTING_SIZE / FLASH_BLOCK_SIZE ) // 7E
    #define SYSTEM_BANK_DATABASE1_SIZE      ( FLASH_BLOCK_SIZE )
    #define SYSTEM_BANK_DATABASE0           ( SYSTEM_BANK_DATABASE1 + SYSTEM_BANK_DATABASE1_SIZE / FLASH_BLOCK_SIZE )  // 7F
    #define SYSTEM_BANK_DATABASE1_SIZE      ( FLASH_BLOCK_SIZE )

    #define OAD_DB_BANK                     ( QUICK_DB_GENSETTING_BANK - 1 )
#elif (EEPROM_DB_STORAGE == EEPROM_SAVE_WITHOUT_CH_DB)
    #define SYSTEM_BANK_DATABASE1           ( (FLASH_SIZE - CM_DATABASE_FLASH_SIZE) / FLASH_BLOCK_SIZE )// 7E
    #define SYSTEM_BANK_DATABASE1_SIZE      ( FLASH_BLOCK_SIZE )
    #define SYSTEM_BANK_DATABASE0           ( SYSTEM_BANK_DATABASE1 + SYSTEM_BANK_DATABASE1_SIZE / FLASH_BLOCK_SIZE ) // 7F
    #define SYSTEM_BANK_DATABASE1_SIZE      ( FLASH_BLOCK_SIZE )
#endif

// Check EEPROM ID
#define USR_EEPROM_ID                       ( (U8)((TV_SYSTEM<<6)+(MS_BOARD_TYPE_SEL)+(g_PNL_TypeSel)) )
#define SIZE_SYS_SETTING                    ( (U16)sizeof(MS_USER_SYSTEM_SETTING) )
#define SIZE_ADC_SETTING                    ( (U16)sizeof(MS_ADC_SETTING) )
#define SIZE_VIDEO_DATA                     ( (U16)sizeof(T_MS_VIDEO) )
#define SIZE_WHITEBALANCE_DATA              ( (U16)sizeof(T_MS_WHITEBALANCE) )
#define SIZE_SUBCOLOR_DATA                  ( (U16)sizeof(T_MS_SUB_COLOR) )
#define SIZE_SOUND_SETTING                  ( (U16)sizeof(stUserSoundSettingType) )
#define SIZE_TIME_DATA                      ( (U16)sizeof(MS_TIME) )
#define SIZE_SCANMENU_SETTING               ( (U16)sizeof(MS_SCANMENU_SETTING) )
#define SIZE_BLOCK_DATA                     ( (U16)sizeof(MS_BLOCKSYS_SETTING) )
#define SIZE_SSC_DATA                       ( (U16)sizeof(MS_SSC_SETTING) )
#if (ENABLE_NONLINEAR_CURVE)
    #define SIZE_NONLINER_CURVE_SETTING     ( (U16)sizeof(MS_NONLINEAR_CURVE_SETTING) )
#endif
#define SIZE_FACTORY_SETTING_DATA           ( (U16)sizeof(MS_FACTORY_SETTING))
#ifdef ENABLE_BT
    #define SIZE_BT_DATA                    ( (U16)sizeof(MS_TorrentSetupInfo) )
#endif
#if ENABLE_DRM
    #define SIZE_DRM_DATA                   ( (U16)sizeof(VDplayerDRMInfo) )
#endif
#if ENABLE_CUS_UI_SPEC
#define SIZE_VCHIP_SETTING_DATA           ( (U16)sizeof(MS_VCHIP_SETTING))
#endif

//#if (ENABLE_PIP)
#define SIZE_PIP_DATA                       ( (U16)sizeof(MS_PIP_SETTING) )
//#endif
#if (ENABLE_UPDATE_MULTIPLEX_VIA_NIT)
    #define SIZE_NETWORK_INFO_DATA          ( (U16)sizeof(MS_ALL_NETWORKID_INFO) )
#endif
#if ENABLE_CI
    #define SIZE_CI_DATA                    ( (U16)sizeof(MS_CI_SETTING) )
#endif
#if (ENABLE_LAST_MEMORY == 1) && (ENABLE_LAST_MEMORY_STORAGE_SAVE == 1)
    #define SIZE_MM_LASTMEMORY_SETTING      ( (U16)sizeof(MS_MM_LASTMEMORY_SETTING) )
#endif

#define XDATA_MAP(x)                        XD2PHY(x)

#define RM_64K_SIZE                         0x10000
#define RM_GEN_SIZE                         0x0800  // 2K, for GENSETTING

#if (ENABLE_SZ_FACTORY_OVER_SCAN_FUNCTION)
    #define SIZE_OVERSCAN_DATA              ( (U16)sizeof(MS_OVERSCAN_SETTING))
#endif

//========================================================
#define RM_ADC_SETTING_ADDRESS(i)           ( RM_GEN_USAGE  + (U16)(SIZE_ADC_SETTING*(i)) )
#define RM_ADC_SETTING_SIZE                 ( SIZE_ADC_SETTING * ADC_SET_NUMS )

#define RM_VIDEO_DATA_ADDRESS(i)            ( RM_ADC_SETTING_ADDRESS(0) + RM_ADC_SETTING_SIZE + (U16)(SIZE_VIDEO_DATA * (i)) )
#define RM_VIDEO_DATA_SIZE                  ( SIZE_VIDEO_DATA * DATA_INPUT_SOURCE_NUM )

#define RM_WHITEBALANCE_DATA_ADDRESS(i)     ( RM_VIDEO_DATA_ADDRESS(0) + RM_VIDEO_DATA_SIZE + (U16)(SIZE_WHITEBALANCE_DATA*(i)) )
#define RM_WHITEBALANCE_DATA_SIZE           ( SIZE_WHITEBALANCE_DATA * DATA_INPUT_SOURCE_NUM )

#ifdef ENABLE_CUS_SERIAL_NUMBER
// CUS_XM Sea 20120615: add SN
#define RM_SN_DATA_START_ADR       		( RM_WHITEBALANCE_DATA_ADDRESS(0) + RM_WHITEBALANCE_DATA_SIZE)
#define RM_SIZE_SN_DATA           			    (( (U16)sizeof(T_MS_SERIAL_NUM)))

#define RM_SUBCOLOR_DATA_ADDRESS(i)         ( RM_SN_DATA_START_ADR + RM_SIZE_SN_DATA + (U16)(SIZE_SUBCOLOR_DATA*(i)) )
#define RM_SUBCOLOR_DATA_SIZE               ( SIZE_SUBCOLOR_DATA * DATA_INPUT_SOURCE_NUM )
#else
#define RM_SUBCOLOR_DATA_ADDRESS(i)         ( RM_WHITEBALANCE_DATA_ADDRESS(0) + RM_WHITEBALANCE_DATA_SIZE + (U16)(SIZE_SUBCOLOR_DATA*(i)) )
#define RM_SUBCOLOR_DATA_SIZE               ( SIZE_SUBCOLOR_DATA * DATA_INPUT_SOURCE_NUM )
#endif

#if (ENABLE_DTV_EPG)
    #define RM_TIMER_MANUAL_EVENT_START_ADR ( RM_SUBCOLOR_DATA_ADDRESS(0) + RM_SUBCOLOR_DATA_SIZE )
    #define RM_SIZE_MANUAL_TIMER_EVENT      ( (U16)sizeof(MS_EPG_TIMER) * EPG_TIMER_MAX_NUM )

    #define RM_TIMER_CHECKSUM_START_ADR     ( RM_TIMER_MANUAL_EVENT_START_ADR + RM_SIZE_MANUAL_TIMER_EVENT )
    #define RM_SIZE_TIMER_CHECKSUM          ( (U16)sizeof(U16) )

    #define RM_TV_COMMON_DATA_START_ADR     ( RM_TIMER_CHECKSUM_START_ADR+RM_SIZE_TIMER_CHECKSUM )
    #define RM_SIZE_TV_COMMON_DATA          ( (U16)sizeof(COMMON_DATA_STRUCTURE) )
#else
    #define RM_TV_COMMON_DATA_START_ADR     ( RM_SUBCOLOR_DATA_ADDRESS(0) + RM_SUBCOLOR_DATA_SIZE )
    #define RM_SIZE_TV_COMMON_DATA          ( (U16)sizeof(COMMON_DATA_STRUCTURE) )
#endif

#define RM_ATV_CHSET_START_ADDR             ( RM_TV_COMMON_DATA_START_ADR + RM_SIZE_TV_COMMON_DATA )
#define RM_ATV_CHSET_SIZE                   ( sizeof(ATV_PROGRAM_DATA_STRUCTURE) )

#if ( ENABLE_DVB_TAIWAN_APP || ENABLE_SBTVD_BRAZIL_APP || (TV_SYSTEM == TV_NTSC) )
    #define RM_CATV_CHSET_START_ADDR        ( RM_ATV_CHSET_START_ADDR + RM_ATV_CHSET_SIZE )
    #define RM_CATV_CHSET_SIZE              ( sizeof(CATV_PROGRAM_DATA_STRUCTURE) )
  #if (ENABLE_SZ_FACTORY_OVER_SCAN_FUNCTION)
    #define RM_OVERSCAN_DATA_START_ADR      ( RM_CATV_CHSET_START_ADDR + RM_CATV_CHSET_SIZE )
    #define RM_SIZE_OVERSCAN_DATA           ( (U16)SIZE_OVERSCAN_DATA * EN_FACTORY_OverScan_NUM )
    #define RM_MODE_SETTING_START_ADR       ( RM_OVERSCAN_DATA_START_ADR + RM_SIZE_OVERSCAN_DATA )
  #else
    #define RM_MODE_SETTING_START_ADR       ( RM_CATV_CHSET_START_ADDR + RM_CATV_CHSET_SIZE )
  #endif
     //#define RM_MODE_SETTING_START_ADR           (RM_CATV_CHSET_START_ADDR + RM_CATV_CHSET_SIZE)
#else
  #if (ENABLE_SZ_FACTORY_OVER_SCAN_FUNCTION)
    #define RM_OVERSCAN_DATA_START_ADR      ( RM_ATV_CHSET_START_ADDR + RM_ATV_CHSET_SIZE )
    #define RM_SIZE_OVERSCAN_DATA           ( (U16)SIZE_OVERSCAN_DATA * EN_FACTORY_OverScan_NUM )
    #define RM_MODE_SETTING_START_ADR       ( RM_OVERSCAN_DATA_START_ADR + RM_SIZE_OVERSCAN_DATA )
  #else
    #define RM_MODE_SETTING_START_ADR       ( RM_ATV_CHSET_START_ADDR + RM_ATV_CHSET_SIZE )
  #endif
#endif
#define RM_SIZE_MODE_SETTING                ( sizeof(MS_PCADC_MODESETTING_TYPE) * MAX_MODE_NUM )

#if (ENABLE_DTV)
    #define RM_DTV_CHSET_START_ADDR         ( RM_MODE_SETTING_START_ADR+RM_SIZE_MODE_SETTING )
    #define RM_DTV_CHSET_SIZE               ( sizeof(DTV_CHANNEL_DATA_STRUCTURE) )
    #define RM_64K_USAGE                    MemAlign((RM_DTV_CHSET_START_ADDR-RM_GEN_USAGE+RM_DTV_CHSET_SIZE),8)
#else
    #define RM_DTV_CHSET_START_ADDR         (RM_MODE_SETTING_START_ADR+RM_SIZE_MODE_SETTING) //For delete warning only!
    #define RM_DTV_CHSET_SIZE               0 //For delete warning only!
    #define RM_64K_USAGE                    MemAlign((RM_MODE_SETTING_START_ADR-RM_GEN_USAGE+RM_SIZE_MODE_SETTING),8)
#endif

//Database version for flash case only
#define RM_DB_VERSION_START_ADDR            RM_64K_USAGE
#define RM_DB_VERSION_SIZE                  3 // DATABASE_ID(x2) + VERSION(x1)

//EEPROM ID for eeprom case only
#define RM_EEPROM_ID_ADDRESS                ( RM_MAX_ADDRESS )
#define RM_EEPROM_ID_SIZE                   1

#define DRAM_GEN_DB_START(db_start)         ( db_start )
#define DRAM_64K_DB_START(db_start)         ( (db_start) + RM_GEN_SIZE + RM_64K_SIZE - RM_64K_USAGE )

#if (EEPROM_DB_STORAGE != EEPROM_SAVE_NONE)
    INTERFACE void MApp_CheckEEPROM(void);
#endif
#if (EEPROM_DB_STORAGE != EEPROM_SAVE_ALL)
    INTERFACE void MApp_CheckFlash(void);
#endif


INTERFACE void MApp_InitGenSetting(void);
INTERFACE void MApp_LoadGenSetting(void);
INTERFACE void MApp_SaveGenSetting(void);

INTERFACE   void MApp_ResetGenUserSetting(void);

INTERFACE void MApp_InitChSetting(void);
INTERFACE void MApp_LoadChSetting(void);
INTERFACE void MApp_SaveChSetting(void);

INTERFACE void MApp_InitSysSetting(void);
INTERFACE void MApp_CheckSysSetting(void);
INTERFACE void MApp_LoadSysSetting(void);
INTERFACE void MApp_SaveSysSetting(void);

INTERFACE U16 MApp_CalCheckSum( BYTE *pBuf, U16 ucBufLen );

#if ENABLE_DRM
INTERFACE void MApp_InitDrmSetting(void);
INTERFACE void MApp_CheckDrmSetting(void);
INTERFACE void MApp_LoadDrmSetting(void);
INTERFACE void MApp_SaveDrmSetting(void);
#endif


#ifdef ENABLE_BT
INTERFACE void MApp_InitBtSetting(void);
INTERFACE void MApp_CheckBtSetting(void);
INTERFACE void MApp_LoadBtSetting(void);
INTERFACE void MApp_SaveBtSetting(void);
#endif
//#if (ENABLE_PIP)
INTERFACE void MApp_InitPipSetting(void);
INTERFACE void MApp_CheckPipSetting(void);
INTERFACE void MApp_LoadPipSetting(void);
INTERFACE void MApp_SavePipSetting(void);
//#endif

#if (ENABLE_UPDATE_MULTIPLEX_VIA_NIT)
INTERFACE void MApp_InitNetworkInfoSetting(void);
INTERFACE void MApp_CheckNetworkInfoSetting(void);
INTERFACE void MApp_LoadNetworkInfoSetting(void);
INTERFACE void MApp_SaveNetworkInfoSetting(void);
INTERFACE MS_NETWORKID_TS* MApp_GetNetworkInfo(U8 u8NetworkIndex);
#endif

#if ENABLE_CI && ENABLE_CI_PLUS
INTERFACE void MApp_InitCISetting(void);
INTERFACE void MApp_CheckCISetting(void);
INTERFACE void MApp_LoadCISetting(void);
INTERFACE void MApp_SaveCISetting(void);
#endif

INTERFACE void MApp_InitADCSetting(E_ADC_SET_INDEX eAdcIndex );
INTERFACE void MApp_LoadADCSetting(E_ADC_SET_INDEX eAdcIndex );
INTERFACE void MApp_SaveADCSetting(E_ADC_SET_INDEX eAdcIndex);
INTERFACE void MApp_CheckADCSetting(void);

INTERFACE void MApp_InitVideoSetting(E_DATA_INPUT_SOURCE enDataInputSource);
INTERFACE void MApp_CheckVideoSetting(void);
INTERFACE void MApp_SaveVideoSetting(E_DATA_INPUT_SOURCE enDataInputSource);
INTERFACE void MApp_LoadVideoSetting(E_DATA_INPUT_SOURCE enDataInputSource);

INTERFACE void MApp_InitWhiteBalanceSetting(E_DATA_INPUT_SOURCE enDataInputSource);
INTERFACE void MApp_SaveWhiteBalanceSetting(E_DATA_INPUT_SOURCE enDataInputSource);
INTERFACE void MApp_CopyWhiteBalanceSettingToAllInput(void);
INTERFACE void MApp_CheckWhiteBalanceSetting(void);
INTERFACE void MApp_LoadWhiteBalanceSetting(E_DATA_INPUT_SOURCE enDataInputSource);

INTERFACE void MApp_InitSubColorSetting(E_DATA_INPUT_SOURCE enDataInputSource);
INTERFACE void MApp_LoadSubColorSetting(E_DATA_INPUT_SOURCE enDataInputSource);
INTERFACE void MApp_CheckSubColorSetting(void);
INTERFACE void MApp_SaveSubColorSetting(E_DATA_INPUT_SOURCE enDataInputSource);
INTERFACE void MApp_CopySubColorDataToAllInput(void);
#ifdef ENABLE_CUS_SERIAL_NUMBER
INTERFACE void MApp_InitSerialNumberSetting(void);
INTERFACE void MApp_LoadSerialNumberSetting(void);
INTERFACE void MApp_CheckSerialNumberSetting(void);
INTERFACE void MApp_SaveSerialNumberSetting(void);
#endif

INTERFACE void MApp_InitSoundSetting(void);
INTERFACE void MApp_SaveSoundSetting(void);
INTERFACE void MApp_CheckSoundSetting(void);

INTERFACE void MApp_InitTimeData(void);
INTERFACE void MApp_SaveTimeData(void);
INTERFACE void MApp_CheckTimeData(void);
INTERFACE void MApp_LoadTimeData(void);

INTERFACE void MApp_InitBlockData(void);
INTERFACE void MApp_CheckBlockData(void);
INTERFACE void MApp_LoadBlockData(void);
INTERFACE void MApp_SaveBlockData(void);

#if ENABLE_SSC
INTERFACE void App_InitSSCData(void);
INTERFACE void MApp_CheckSSCData(void);
INTERFACE void MApp_LoadSSCData(void);
INTERFACE void MApp_SaveSSCData(void);
#endif

#if (ENABLE_NONLINEAR_CURVE)
INTERFACE void MApp_InitNonLinearCurveSetting(void);
INTERFACE void MApp_CheckNonLinearCurveSetting(void);
INTERFACE void MApp_SaveNonLinearCurveSetting(void);
#endif

INTERFACE void MApp_InitFactorySetting(void);
INTERFACE void MApp_CheckFactorySetting(void);
INTERFACE void MApp_SaveFactorySetting(void);

#if ENABLE_CUS_UI_SPEC
INTERFACE void MApp_InitVshipSetting(void);
INTERFACE void MApp_CheckVshipSetting(void);
INTERFACE void MApp_SaveVshipSetting(void);
#endif

INTERFACE void MApp_DoFactoryInit(void);

#if (ENABLE_LAST_MEMORY==1)&&(ENABLE_LAST_MEMORY_STORAGE_SAVE==1)
INTERFACE void MApp_InitMmLastMemorySetting(void);
INTERFACE void MApp_CheckMmLastMemorySetting(void);
INTERFACE void MApp_LoadMmLastMemorySetting(void);
INTERFACE void MApp_SaveMmLastMemorySetting(void);
#endif

INTERFACE void MApp_DataCheckHandler(void);
INTERFACE void MApp_DataSaveHandler(void);
INTERFACE void MApp_SetSaveModeDataFlag(void);
INTERFACE void MApp_DataInitVariable(void);

INTERFACE void MApp_DB_LoadModeSetting ( SCALER_WIN eWindow, U8 u8ModeIndex );
INTERFACE void MApp_DB_SaveModeSetting ( SCALER_WIN eWindow, U8 u8ModeIndex );

INTERFACE void MApp_RestoreAllModeTable(SCALER_WIN eWindow);
INTERFACE void MApp_DB_LoadDefaultTable( SCALER_WIN eWindow, U8 u8ModeIndex );
INTERFACE void MApp_RestorePCModeTable( SCALER_WIN eWindow );
INTERFACE void MApp_RestoreComponentModeTable(void);

INTERFACE void MApp_CheckScanMenuSetting(void);
INTERFACE void MApp_LoadScanMenuSetting(void);

INTERFACE void MApp_InitScanMenuSetting(void);
INTERFACE void MApp_SaveScanMenuSetting(void);

INTERFACE void MApp_ReadDatabase(U32 srcIndex, U8* dstAddr, U16 size);
INTERFACE void MApp_WriteDatabase(U32 dstIndex, U8* srcAddr, U16 size);
#if (ENABLE_SZ_FACTORY_OVER_SCAN_FUNCTION)
INTERFACE void MApp_LoadOverScanData (void);
INTERFACE void MApp_SaveOverScanData (void );
INTERFACE void MApp_InitOverScanData(void);
#endif
#if (ENABLE_SZ_FACTORY_USB_SAVE_DATABASE_FUNCTION == ENABLE)
INTERFACE void MApp_BackupDatabase(void);
INTERFACE void MApp_RestoreDatabase(void);
INTERFACE BOOLEAN USBDeviceDetectFlag;
#endif


#undef INTERFACE

#endif
