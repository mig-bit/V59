////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
/// @file  MApp_XC_PQ.h
/// @brief MIU header file
/// @author MStar Semiconductor Inc.
///
////////////////////////////////////////////////////////////////////////////////
#ifndef _APP_XC_PQ_H_
#define _APP_XC_PQ_H_

#ifdef _APP_XC_PQ_C_
#define INTERFACE
#else
#define INTERFACE extern
#endif

//-------------------------------------------------------------------------------------------------
//  Include Files
//-------------------------------------------------------------------------------------------------
#include "MApp_GlobalSettingSt_Common.h"

//-------------------------------------------------------------------------------------------------
//  Macro and Define
//-------------------------------------------------------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
// Adjust Color
////////////////////////////////////////////////////////////////////////////////
#define MAX_VIDEO_CONTRAST      0xA0
#define MIN_VIDEO_CONTRAST      0x00
#define MAX_PC_CONTRAST         0xA0
#define MIN_PC_CONTRAST         0x50

#define MAX_VIDEO_BRIHTNESS     0xFF
#define MIN_VIDEO_BRIHTNESS     0x00

#define MAX_PC_BRIGHTNESS       0xFE
#define MIN_PC_BRIGHTNESS       0x12

#define MAX_VIDEO_SATURATION    0xFF
#define MIN_VIDEO_SATURATION    0

#define MAX_VIDEO_HUE           100
#define MIN_VIDEO_HUE           0

#define MAX_VIDEO_SHARPNESS     0x3F
#define MIN_VIDEO_SHARPNESS     0

#define MAX_PC_SHARPNESS        0x3F
#define MIN_PC_SHARPNESS        0

#define MAX_VIDEO_BLACKLEVEL    0x2F
#define MIN_VIDEO_BLACKLEVEL    0x00

//-------------------------------------------------------------------------------------------------
//  Type and Structure
//-------------------------------------------------------------------------------------------------

//-------------------------------------------------------------------------------------------------
//  Function and Variable
//-------------------------------------------------------------------------------------------------

INTERFACE void MApp_PicSetNR(T_MS_NR_MODE * eNR, INPUT_SOURCE_TYPE_t enInputSourceType);
INTERFACE void MApp_Picture_Setting_SetColor( INPUT_SOURCE_TYPE_t enInputSourceType, SCALER_WIN eWindow );

INTERFACE U8 msAPI_Mode_PictureContrastN100toReallyValue ( U8 u8value );
INTERFACE U8 msAPI_Mode_PictureBrightnessN100toReallyValue ( U8 u8value );
INTERFACE U8 msAPI_Mode_PictureHueN100toReallyValue ( U8 u8value );
INTERFACE U8 msAPI_Mode_PictureSaturationN100toReallyValue ( U8 u8value );
INTERFACE U8 msAPI_Mode_PictureSharpnessN100toReallyValue ( U8 u8value );
INTERFACE U16 msAPI_Mode_PictureBackLightN100toReallyValue ( U8 u8value );


#undef INTERFACE
#endif /* _APP_XC_PQ_H_ */
