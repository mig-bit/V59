////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (�MStar Confidential Information�) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

//NOTE: modify for ZUI...
#if 0//OBA2

#if (UI_SKIN_SEL==UI_SKIN_1280X1024X565)
#include "../../res1280x1024x565_Obama/osdcomposer/include/ZUI_bitmap_EnumIndex.h"
#elif (UI_SKIN_SEL==UI_SKIN_1366X768X565)
#include "../../res1366x768x565_Obama/osdcomposer/include/ZUI_bitmap_EnumIndex.h"
#elif (UI_SKIN_SEL==UI_SKIN_1366X768X4444)
#include "../res1366x768x565_Obama/include/ZUI_bitmap_EnumIndex.h"
#elif (UI_SKIN_SEL==UI_SKIN_1366X768X8888)
#include "../res1366x768x8888_Obama/osdcomposer/include/ZUI_bitmap_EnumIndex.h"
#elif (UI_SKIN_SEL==UI_SKIN_1440X900X565)
#include "../res1440x900x565_Obama/osdcomposer/include/ZUI_bitmap_EnumIndex.h"
#endif

#else

#if (UI_SKIN_SEL==UI_SKIN_1280X1024X565)
#include "../../res1280x1024x565/osdcomposer/include/ZUI_bitmap_EnumIndex.h"
#elif (UI_SKIN_SEL==UI_SKIN_1366X768X565)
#include "../../res1366x768x565/osdcomposer/include/ZUI_bitmap_EnumIndex.h"
#elif (UI_SKIN_SEL==UI_SKIN_1366X768X565_SMC_India)
#include "../../res1366x768x565_SMC_India/osdcomposer/include/ZUI_bitmap_EnumIndex.h"
#elif (UI_SKIN_SEL==UI_SKIN_1366X768X565_HAIER_CN)
#include "../../res1366x768x565_HAIER_CN/osdcomposer/include/ZUI_bitmap_EnumIndex.h"
#elif (UI_SKIN_SEL==UI_SKIN_1366X768X4444)
#include "../res1366x768x565/include/ZUI_bitmap_EnumIndex.h"
#elif (UI_SKIN_SEL==UI_SKIN_1366X768X8888)
#include "../res1366x768x8888/osdcomposer/include/ZUI_bitmap_EnumIndex.h"
#elif (UI_SKIN_SEL==UI_SKIN_1440X900X565)
#include "../res1440x900x565/osdcomposer/include/ZUI_bitmap_EnumIndex.h"
#endif

#endif
