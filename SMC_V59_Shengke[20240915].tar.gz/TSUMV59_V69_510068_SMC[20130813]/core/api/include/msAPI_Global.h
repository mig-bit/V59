////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (MStar Confidential Information!�L) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef MSAPI_GLOBAL_H
#define MSAPI_GLOBAL_H

#include "MsCommon.h"
#include "drvXC_IOPort.h"
#include "apiXC.h"
#include "apiXC_Adc.h"
#include "cusModelSet.h"

#ifdef MSAPI_GLOBAL_C
#define INTERFACE
#else
#define INTERFACE extern
#endif

/********************************************************************************/
/*                     Macro                    */
/* ******************************************************************************/



//*************************************************************************
//          Enums
//*************************************************************************
typedef enum
{
    EN_SYS_INPUT_SOURCE_TYPE_NONE       = 0x0000,
    EN_SYS_INPUT_SOURCE_TYPE_DTV        = 0x0001,
    EN_SYS_INPUT_SOURCE_TYPE_ATV        = 0x0002,
    EN_SYS_INPUT_SOURCE_TYPE_SCART      = 0x0004,
    EN_SYS_INPUT_SOURCE_TYPE_CVBS       = 0x0008,
    EN_SYS_INPUT_SOURCE_TYPE_VGA        = 0x0010,
    EN_SYS_INPUT_SOURCE_TYPE_HDMI       = 0x0020,
    EN_SYS_INPUT_SOURCE_TYPE_YPBPR      = 0x0040,
    EN_SYS_INPUT_SOURCE_TYPE_SVIDEO     = 0x0080,
    EN_SYS_INPUT_SOURCE_TYPE_STORAGE    = 0x0100,
} EN_SYS_INPUT_SOURCE_TYPE;

/// Aspect Ratio Type ==========================================================
typedef enum
{
    /* general */
    VIDEOSCREEN_MIN,                        ///< Video Screen Min
    VIDEOSCREEN_PROGRAM = VIDEOSCREEN_MIN, ///< according AFD or WSS setting
    VIDEOSCREEN_NORMAL,                 ///< Video Screen Normal
    VIDEOSCREEN_FULL,                      ///< video full panel resolution
    VIDEOSCREEN_ZOOM,                   ///< Video Screen Zoom
    VIDEOSCREEN_CINEMA,                 ///< Video Screen Cinema
#ifdef ATSC_SYSTEM
    VIDEOSCREEN_WIDE1,
    VIDEOSCREEN_WIDE2,
#endif
    /* specific options for 4:3 panel */
    VIDEOSCREEN_LETTERBOX,          ///< Video Screen Letterbox
    /* specific options for wide panel */
    VIDEOSCREEN_16by9_SUBTITLE,     ///< Video Screen 16:9 subtitle
    VIDEOSCREEN_PANORAMA,           ///< Video Screen Panorama
    /* others */
    VIDEOSCREEN_14by9,                        ///< 14:9
    VIDEOSCREEN_WSS_16by9,                    ///< WSS 16:9
    VIDEOSCREEN_WSS_14by9_LETTERBOX_CENTER,   ///< WSS: 0001 14:9 Letterbox Center
    VIDEOSCREEN_WSS_14by9_LETTERBOX_TOP,      ///< WSS: 0010 14:9 Letterbox Top
    VIDEOSCREEN_WSS_16by9_LETTERBOX_CENTER,   ///< WSS: 1011 16:9 Letterbox Center
    VIDEOSCREEN_WSS_16by9_LETTERBOX_TOP,      ///< WSS: 0100 16:9 Letterbox Top
    VIDEOSCREEN_ZOOM1,                        ///< Video Screen Zoom1
    VIDEOSCREEN_ZOOM2,                        ///< Video Screen Zoom2
    VIDEOSCREEN_JUSTSCAN,                     ///< Video Screen Justscan
    VIDEOSCREEN_SCENE4_3to16_9,               ///< Video Screen Scene 4:3 to 16:9
    VIDEOSCREEN_SCENE16_9to4_3,               ///< Video Screen Scene 16:9 to 4:3
    VIDEOSCREEN_SCENE4_3to16_9_WITH_CCO,      ///< Video Screen Scene 4:3 to 16:9 with CCO
    VIDEOSCREEN_SCENE4_3to4_3_WITH_CCO,       ///< Video Screen Scene 4:3 to 4:3 with CCO
    VIDEOSCREEN_SCENE4_3to16_9_WITH_LB,       ///< Video Screen Scene 4:3 to 16:9 with LB
    VIDEOSCREEN_SCENE4_3to4_3_WITH_LB,        ///< Video Screen Scene 4:3 to 4:3 with LB
    VIDEOSCREEN_ORIGIN,
    VIDEOSCREEN_PROGRAM_16X9,
    VIDEOSCREEN_PROGRAM_4X3,
    VIDEOSCREEN_PROGRAM_14X9,

    VIDEOSCREEN_MM_KEEP_RATIO_AND_SCALE,    // Keep source H/V ratio and scale to fit panel
    VIDEOSCREEN_MM_FULL,    // H and V scale to fit panel
    VIDEOSCREEN_MM_1_1,     // Bypass scale
    VIDEOSCREEN_MM_16_9,    // Display window: H:V=16:9
    VIDEOSCREEN_MM_4_3,     // Display window: H:V=4:3
    VIDEOSCREEN_MM_ZOOM1,   // TO BE defined
    VIDEOSCREEN_MM_ZOOM2,   // TO BE defined
    VIDEOSCREEN_MM_CAL_BY_VIDEOPLAYER,
    VIDEOSCREEN_POINT_TO_POINT, //for pc and HDMI
    VIDEOSCREEN_NUMS,       //< numbers of video screen type
}EN_ASPECT_RATIO_TYPE;

//*************************************************************************
//          Structures
//*************************************************************************
// display system information
typedef struct
{
    INPUT_SOURCE_TYPE_t enInputSourceType; //< Input source type

    INPUT_SOURCE_TYPE_t enCVBS1OutSource;
  #if (INPUT_SCART_VIDEO_COUNT >= 2)
    INPUT_SOURCE_TYPE_t enCVBS2OutSource;
  #endif

    EN_ASPECT_RATIO_TYPE enAspectRatio;

    U8 u8PanelPowerStatus;

#ifdef SCART_OUT_NEW_METHOD
    U8 SCART_1_Mute;
    U8 SCART_2_Mute;
#endif
} MS_SYS_INFO;

typedef struct
{

INPUT_SOURCE_TYPE_t u8InputSource;
INPUT_SOURCE_TYPE_t u8CVBSOutVideoSource;
}CVBS_OUTPUT_INFO;

/********************************************************************************/
/*                   Function Prototypes                     */
/********************************************************************************/
#if (ENABLE_AUTOTEST || ENABLE_BOOTTIME)
INTERFACE U32 gU32BootTime;
INTERFACE U32 gU32BootStepTime;
INTERFACE U32 gU32BootTotalStepTime;
INTERFACE U32 gU32CompressStepTime;
INTERFACE U32 gU32CompressTotalStepTime;
INTERFACE BOOLEAN gbBootTimeFinish;
#endif

#if (ENABLE_USB_DOWNLOAD_BIN)
INTERFACE BOOLEAN gbPQUpdateFinish;
INTERFACE U32  gU32PQBootTimer;
#endif

#if (ENABLE_CHCHANGETIME)
INTERFACE BOOLEAN gbKeyPress;
INTERFACE U32 gU32ChChangeTime;
#endif

#if (ENABLE_SOURCECHANGETIME)
INTERFACE U32 gU32SourceChangeTime;
#endif

#if (ENABLE_SWITCH_CHANNEL_TIME)
INTERFACE U32 gU32SwitchChannelTime;
#endif

#if (ENABLE_AUTOTEST || ENABLE_BOOTTIME || ENABLE_CHCHANGETIME || ENABLE_SWITCH_CHANNEL_TIME)
INTERFACE U32 gU32TmpTime;
#endif

#if (ENABLE_MSTV_UART_DEBUG)
INTERFACE U8 msAPI_UART_DecodeCommand( void );
INTERFACE void dbgVersionMessage(void);
void MCUPause(char* pcStr, int i);
#define CPU_PAUSE()     MCUPause(__FILE__,__LINE__)
#define PRINT_CURRENT_LINE()    printf("%lu:%s\n", __LINE__, __FILE__);
#endif

#if ENABLE_DDCCI
INTERFACE void MDrv_DDC2BI_Init(void);
INTERFACE void MDrv_DDC2BI_CommandHandler(void);
#define  msAPI_DDC2BI_Init()                MDrv_DDC2BI_Init()
#define  msAPI_DDC2BI_CommandHandler()      MDrv_DDC2BI_CommandHandler()
#endif

INTERFACE void msAPI_InputSrcType_SetType(EN_SYS_INPUT_SOURCE_TYPE enInpSrcType);
INTERFACE EN_SYS_INPUT_SOURCE_TYPE msAPI_InputSrcType_GetType(void);
INTERFACE void msAPI_InputSrcType_ClrType(EN_SYS_INPUT_SOURCE_TYPE enClrType);
INTERFACE BOOLEAN msAPI_InputSrcType_InUsedType(EN_SYS_INPUT_SOURCE_TYPE enInpSrcType);

#define IsHDMIInUse()               (msAPI_InputSrcType_InUsedType(EN_SYS_INPUT_SOURCE_TYPE_HDMI))
#define IsVgaInUse()                (msAPI_InputSrcType_InUsedType(EN_SYS_INPUT_SOURCE_TYPE_VGA))
#define IsYPbPrInUse()              (msAPI_InputSrcType_InUsedType(EN_SYS_INPUT_SOURCE_TYPE_YPBPR))
#define IsAVInUse()                 (msAPI_InputSrcType_InUsedType(EN_SYS_INPUT_SOURCE_TYPE_CVBS))
#define IsSVInUse()                 (msAPI_InputSrcType_InUsedType(EN_SYS_INPUT_SOURCE_TYPE_SVIDEO))
#define IsATVInUse()                (msAPI_InputSrcType_InUsedType(EN_SYS_INPUT_SOURCE_TYPE_ATV))
#define IsDTVInUse()                (msAPI_InputSrcType_InUsedType(EN_SYS_INPUT_SOURCE_TYPE_DTV))
#define IsScartInUse()              (msAPI_InputSrcType_InUsedType(EN_SYS_INPUT_SOURCE_TYPE_SCART))
#define IsStorageInUse()            (msAPI_InputSrcType_InUsedType(EN_SYS_INPUT_SOURCE_TYPE_STORAGE))


#define CUS_CSM_SN_SIZE		19


//#if (ENABLE_PIP)
INTERFACE MS_SYS_INFO stSystemInfo[2];
//#else
//INTERFACE MS_SYS_INFO stSystemInfo[1];
//#endif

#define SYS_INPUT_SOURCE_TYPE(WIN) stSystemInfo[WIN].enInputSourceType

#define SYS_CVBS1_OUT_SOURCE_TYPE(WIN)  stSystemInfo[WIN].enCVBS1OutSource
#if (INPUT_SCART_VIDEO_COUNT >= 2)
#define SYS_CVBS2_OUT_SOURCE_TYPE(WIN)  stSystemInfo[WIN].enCVBS2OutSource
#endif

#ifdef ENABLE_KTV
INTERFACE BOOLEAN gbKTVFlag;
#endif


#undef INTERFACE

#endif /* MSAPI_GLOBAL_H */
