////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (MStar Confidential Information!�L) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef __API_DTVSYSTEM_H__
#define __API_DTVSYSTEM_H__
#define ENABLE_DTV_STORE_TTX_PAGE_INFO FALSE



#if (!ENABLE_DTV)
#include "msAPI_FreqTableCommon.h"
#define DTVDATA_ID                  0xA55A
typedef enum
{
    E_PROGACESS_INCLUDE_VISIBLE_ONLY        = 0x00,     ///< Program access include visible only
    E_PROGACESS_INCLUDE_NOT_VISIBLE_ALSO    = 0x01,      ///< Program access Also include Not visible
    E_PROGACESS_INCLUDE_ALL    = 0x02      ///< Program access Also include Not visible
} E_MEMBER_PROGRAM_ACCESSIBLE_BOUNDARY;

typedef struct
{
    WORD                wID;
    BYTE                bSerialNum;
    MEMBER_COUNTRY      eCountry;
} DTV_CHANNEL_DATA_STRUCTURE;

#else
#include "Board.h"
#include "msAPI_FreqTableCommon.h"
#include "msAPI_Global.h"
#include "msAPI_MW_GlobalSt.h"
#ifndef ATSC_SYSTEM
#include "mapp_si_if.h"
#endif
#include "msAPI_demux.h"
#include "MApp_GlobalSettingSt.h"

//------------------------------------------------------------------------------
// Version Check
//------------------------------------------------------------------------------
#define CM_VER()   'M','S','I','F',                   /* Version ID Header    */ \
                         '1','0',                           /* Info Class Code      */ \
                         0x66,0x66,                         /* Customer ID          */ \
                         0x66,0x66,                         /* Module ID            */ \
                         0xFF,0xFF,                         /* Chip ID              */ \
                         '1',                               /* CPU                  */ \
                         'C','M','_','_',                   /* Library Code         */ \
                         '0','0',                           /* Library Ver          */ \
                         '0','0','0','0',                   /* Build Number         */ \
                         '0','0','1','1','6','6','7','9',   /* P4 Change Number     */ \
                         '0'                                /* OS                   */ \

//------------------------------------------------------------------------------
// Public attributes.
//------------------------------------------------------------------------------

#if DVB_C_ENABLE
#define FREQ_OFFSET_RANGE               300     //unit: KHz
#define INVALID_FREQUENCY                   0x0
#define INVALID_SYMBRATE                    0x0
#define INVALID_QAMMODE                     0x0
#endif
#define INVALID_PROGRAM_POSITION            0xFFFF
#define INVALID_LOGICAL_CHANNEL_NUMBER      0xFFFF
#define INVALID_SIMULCAST_LOGICAL_CHANNEL_NUMBER      0x7FF
#define INVALID_PHYSICAL_CHANNEL_NUMBER     0xFF
#define UNCONFIRMED_PHYSICAL_CHANNEL_NUMBER     0xFE
#define INVALID_VIRTUAL_CHANNEL_NUMBER      0xFF
#define INVALID_PSI_SI_VERSION              0xFF
#define INVALID_PID                         MSAPI_DMX_INVALID_PID
#define INVALID_SERVICE_ID                  0xFFFF
#define INVALID_TS_ID                       0xFFFF
#define INVALID_ON_ID                       0xFFFF
#define INVALID_NID                  0xFFFF
#define INVALID_SELECTED_AUDIOSTREAM        0x00
#define INVALID_IDINDEX                     0x7F
#define INVALID_NETWORKINDEX                MAX_NETWOEK_NUMBER
#define INVALID_ALTERNATIVETIME             0
#define INVALID_PLPID                       0xFF
#define DEFAULT_REGION                       0
#if 0
#if (ENABLE_SBTVD_BRAZIL_APP)
#define MAX_AUD_LANG_NUM                   5//Brazil Prepare for 3 audio language: Eng Spa Por
#else
#define MAX_AUD_LANG_NUM                   8 //NZ default 16
#endif
#endif
#define MAX_AUD_ISOLANG_NUM                1 // 3
//#define MAX_AUD_LANG_LENGTH                3
#define MAX_ISO639CODE_LENGTH              3
#define MAX_UNSUPPORTED_ISO639CODE_NUM     20
#define UNSUPPORT_ISO639CODE_BASE_INDEX    0xE0
//#define MAX_AUD_PER_PROGRAM                5
#define DEFAULT_AUD_LANG_NUM                 1
//#define MAX_VC_PER_PHYSICAL                120//SI_MAX_VC_PER_PHYSICAL//67//62

#define MAX_NETWOEK_NUMBER               20
#define MAX_NETWORK_NAME                   32


#if ENABLE_SBTVD_BRAZIL_APP
#define MAX_DTVPROGRAM              320//370//400
#define MAX_SERVICE_NAME           20+1+2//Brazil only need 20 chars+0xE Char+2 char for 10.1 channel
#elif DVB_T_C_DIFF_DB
#define MAX_DTVPROGRAM              1000
#define MAX_SERVICE_NAME            20
#define MAX_DTV_C_PROGRAM           1000
#define MAX_DTV_C_SERVICE_NAME      20
#else
#if (EEPROM_DB_STORAGE == EEPROM_SAVE_ALL)
#define MAX_DTVPROGRAM              320//370//400
#elif ENABLE_T_C_CHANNEL_MIX
#define MAX_DTVPROGRAM              1000
#else

#if NTV_FUNCTION_ENABLE
#define MAX_DTVPROGRAM              480//370//400//600
#else

#if ENABLE_DVBT_1000_LCN  //20100707EL
#define MAX_DTVPROGRAM              1000
#else
#define MAX_DTVPROGRAM              480//510//570
#endif

#endif

#endif
#define MAX_SERVICE_NAME            32//48 //for HD Simulcast Logical Channel number
#endif
#if ENABLE_SAVE_MULTILINGUAL_SERVICE_NAME
#undef MAX_DTVPROGRAM
#define MAX_DTVPROGRAM              350//400
#undef MAX_SERVICE_NAME
#define MAX_SERVICE_NAME              24

#define MAX_MULTI_LINGUAL_SERVICE_NAME 1
#define INVALID_LANG_INDEX                       LANGUAGE_NONE
#endif

/// Program data member
typedef BYTE    PROGRAMDATA_MEMBER;
//----------------------------------
#define E_DATA_LCN                          0x01
#define E_DATA_PCN                          0x02
#define E_DATA_VERSION_PAT                  0x03
#define E_DATA_VERSION_PMT                  0x04
#define E_DATA_VERSION_NIT                  0x05
#define E_DATA_VERSION_SDT                  0x06
#define E_DATA_TS_ID                        0x07
#define E_DATA_ON_ID                        0x08
#define E_DATA_SERVICE_ID                   0x09
#define E_DATA_PCR_PID                      0x0A
#define E_DATA_VIDEO_PID                    0x0B
#define E_DATA_AUDIO_STREAM_INFO            0x0C
#define E_DATA_SERVICE_NAME                 0x0D
#define E_DATA_ORDER                        0x0E
#define E_DATA_MISC                         0x0F
#define E_DATA_SIMU_LCN                     0x10    //for HD Simulcast Logical Channel number
#define E_DATA_PMT_PID                      0x11
#define E_DATA_TTX_LIST                     0x12
#define E_DATA_ID_INDEX                     0x13
#define E_DATA_ID_TABLE                     0x14
#define E_DATA_NETWORK_ID                     0x15
#define E_DATA_CELL_ID                     0x16
#define E_DATA_PLP                         0x17
#define E_DATA_NETWORK_NAME                 0x18
#define E_DATA_NETWORK                      0x19
#define E_DATA_NETWORK_INDEX                      0x20
#define E_DATA_FREQ                         0x21
#define E_DATA_SYMB_RATE                0x22
#define E_DATA_QAM_MODE                 0x23
#define E_DATA_ORIGINAL_PCN                 0x24
#define E_DATA_ALTERNATIVE_TIME             0x25
#define E_DATA_TS_LCN                       0x26
#if ENABLE_SAVE_MULTILINGUAL_SERVICE_NAME
#define E_DATA_NAME_MULTILINGUAL_LANGUAGE   0x27
#define E_DATA_SERVICE_MULTILINGUAL_NAME                 0x28
#endif
#define E_DATA_REPLACE_SERVICE                       0x29

#define E_DATA_ALL                          0xFF

#if DVB_T_C_DIFF_DB
#define MAX_DTV_C_MUX_NUMBER                40
#endif
#if ENABLE_T_C_CHANNEL_MIX
#define MAX_MUX_NUMBER                      120
#else
#define MAX_MUX_NUMBER                      40
#endif

#if ENABLE_DTV_STORE_TTX_PAGE_INFO//(ENABLE_TTX || BLOADER)
#define MAX_LISTPAGE                4
#define MAX_LISTPAGE_SIZE           ((MAX_LISTPAGE*10)/8)
#endif


#define NZ_MAX_LCN                              799
#define START_ADDRESS_OF_DTVDATA_STRUCTURE      RM_DTV_CHSET_START_ADDR
#define FIRST_ORDER_OF_TV                       0
#define LAST_ORDER_OF_TV                        (MAX_DTVPROGRAM-1)
#define FIRST_ORDER_OF_RADIO                    (MAX_DTVPROGRAM-1)
#define LAST_ORDER_OF_RADIO                     0
#define FIRST_ORDER_OF_DATA                     (MAX_DTVPROGRAM-1)
#define LAST_ORDER_OF_DATA                      0
#define INVALID_PRINDEX                         0x1FFF
#define INVALID_ORDER                           0x3FFF

#ifdef AUSTRALIA
#define DEFAULT_COUNTRY                         E_AUSTRALIA
#elif  ENABLE_SBTVD_BRAZIL_APP
#define DEFAULT_COUNTRY                         E_BRAZIL
#elif (ENABLE_DTMB_CHINA_APP || ENABLE_ATV_CHINA_APP || ENABLE_DVBC_PLUS_DTMB_CHINA_APP)
#define DEFAULT_COUNTRY                         E_CHINA
#elif ( ENABLE_DVB_TAIWAN_APP )
#define DEFAULT_COUNTRY                         E_TAIWAN
#else
#define DEFAULT_COUNTRY                         E_UK
#endif

#define DEFAULT_PRINDEX                         INVALID_PRINDEX
#define DEFAULT_ORDER                           INVALID_ORDER

#define DEFAULT_LCN                             INVALID_LOGICAL_CHANNEL_NUMBER
#define DEFAULT_SIMU_LCN                             INVALID_SIMULCAST_LOGICAL_CHANNEL_NUMBER

#define DEFAULT_CELLID                          0x00
#define DEFAULT_PCN                             INVALID_PHYSICAL_CHANNEL_NUMBER
#define DEFAULT_VCN                             INVALID_VIRTUAL_CHANNEL_NUMBER

#define DEFAULT_VERSION                         INVALID_PSI_SI_VERSION
#define DEFAULT_VISIBLE_SERVICE_FLAG            0x01
#define DEFAULT_IS_SCRAMBLED                    0x00
#define DEFAULT_IS_STILL_PICTURE                0x00
#define DEFAULT_IS_SKIPPED                      0x00
#define DEFAULT_IS_LOCKED                       0x00
#define DEFAULT_IS_MOVED                        0x00
#define DEFAULT_IS_CABLE                        0x00
#define DEFAULT_IS_INVALID_CELL                 0x00
#define DEFAULT_IS_UNCONFIRMED_SERVICE          0x00
#define DEFAULT_IS_INVALID_SERVICE          0x00
#define DEFAULT_IS_DELETED                      0x00
#define DEFAULT_IS_REPLACE_DEL                    0x00
#define DEFAULT_IS_FAVORITE                     0x00
//#define DEFAULT_IS_MHEG_INCLUDED                0x00
#define DEFAULT_IS_REPLACE_SERVICE                0x00
#define DEFAULT_IS_SERVICE_ID_ONLY              0x01
#define DEFAULT_VIDEO_TYPE                   E_VIDEOTYPE_MPEG//0x00
#define DEFAULT_IS_DATA_SERVICE_AVAILABLE       0x00
#define DEFAULT_SIGNAL_STRENGTH                 0x0000
#define DEFAULT_LCN_VALID                 		1
#define DEFAULT_SERVICE_TYPE                    E_SERVICETYPE_INVALID
#define DEFAULT_SERVICE_TYPE_PRIO               E_SERVICETYPE_PRIORITY_NONE
#define DEFAULT_SPECIAL_SERVICE                 0x00
#define DEFAULT_SELECTED_AUDIO_STREAM           0x00
#define DEFAULT_TS_ID                           INVALID_TS_ID
#define DEFAULT_ON_ID                           INVALID_ON_ID
#define DEFAULT_SERVICE_ID                      INVALID_SERVICE_ID
#define DEFAULT_PMT_PID                         INVALID_PID
#define DEFAULT_PCR_PID                         INVALID_PID
#define DEFAULT_VIDEO_PID                       INVALID_PID
//#define DEFAULT_AUDIO_PID                       INVALID_PID
//#define DEFAULT_AUDIO_STREAM_TYPE               E_AUDIOSTREAM_INVALID
//#define DEFAULT_AUDIO_LANGUAGE_CODE             0x00
#define DEFAULT_CURRENT_SERVICETYPE             E_SERVICETYPE_DTV
#define DEFAULT_CURRENT_ORDER_TV                0x0000
#define DEFAULT_CURRENT_ORDER_RADIO             (MAX_DTVPROGRAM-1)
#define DEFAULT_CURRENT_ORDER_DATA             (MAX_DTVPROGRAM-1)
#define DEFAULT_LCN_ASSIGNMENT_TYPE             E_LCN_INVALID
// #define DEFAULT_PR_COUNTER_VALUE                0x0000
#define DEFAULT_NUMERIC_SELECTION_FLAG          0x01

#define ONID_NORWAY     0x2242


//move from $(ROOT)\chip\include\BaseType.h
typedef enum
{
    E_AUDIO_LANG_CODE_UNKNOWN              = 0x00,
    E_AUDIO_LANG_CODE_ENGLISH              = 0x01,
    E_AUDIO_LANG_CODE_FRENCH               = 0x02,
    E_AUDIO_LANG_CODE_GERMAN               = 0x03,
    E_AUDIO_LANG_CODE_SPANISH              = 0x04,
    E_AUDIO_LANG_CODE_ITALIAN              = 0x05,
    E_AUDIO_LANG_CODE_DUTCH                = 0x06,
    E_AUDIO_LANG_CODE_GREEK                = 0x07,
    E_AUDIO_LANG_CODE_PORTUGUESE           = 0x08,
    E_AUDIO_LANG_CODE_SEDISH               = 0x09,
    E_AUDIO_LANG_CODE_NORWEGIAN            = 0x0A,
    E_AUDIO_LANG_CODE_DANISH               = 0x0B,
    E_AUDIO_LANG_CODE_POLISH               = 0x0C,
    E_AUDIO_LANG_CODE_FINISH               = 0x0D,
    E_AUDIO_LANG_CODE_CZECH                = 0x0E,
    E_AUDIO_LANG_CODE_HUNGARIAN            = 0x0F,
    E_AUDIO_LANG_CODE_RUSSIAN              = 0x10,
    E_AUDIO_LANG_CODE_SLOVENIAN            = 0x11,
    E_AUDIO_LANG_CODE_ROMANIAN             = 0x12,
    E_AUDIO_LANG_CODE_SERBIAN              = 0x13,
    E_AUDIO_LANG_CODE_CROATIAN             = 0x14,
    E_AUDIO_LANG_CODE_BULGARIAN            = 0x15,
    E_AUDIO_LANG_CODE_WELSH                = 0x16,
    E_AUDIO_LANG_CODE_GALIC                = 0x17
} AUDIO_LANG_CODE;

#if (CM_MULTI_FAVORITE)
typedef enum
{
    E_FAVORITE_TYPE_1,
    E_FAVORITE_TYPE_2,
    E_FAVORITE_TYPE_3,
    E_FAVORITE_TYPE_4,
    E_FAVORITE_TYPE_ALL,
} E_FAVORITE_TYPE;
#endif

// Channel attribute member
typedef enum
{
    E_ATTRIBUTE_IS_SCRAMBLED,               ///< Attribute scrambled
    E_ATTRIBUTE_IS_STILL_PICTURE,           ///< Attribute still picture
    E_ATTRIBUTE_IS_VISIBLE,                 ///< Attribute visible
#if (CM_MULTI_FAVORITE)
    E_ATTRIBUTE_IS_FAVORITE1,               ///< Attribute favorite 1
    E_ATTRIBUTE_IS_FAVORITE2,               ///< Attribute favorite 2
    E_ATTRIBUTE_IS_FAVORITE3,               ///< Attribute favorite 3
    E_ATTRIBUTE_IS_FAVORITE4,               ///< Attribute favorite 4
#else
    E_ATTRIBUTE_IS_FAVORITE,                ///< Attribute favorite
#endif
    E_ATTRIBUTE_IS_NUMERIC_SELECTION,       ///< Attribute numberic selection
    E_ATTRIBUTE_IS_SKIPPED,                 ///< Attribute skipped
    E_ATTRIBUTE_IS_LOCKED,                  ///< Attribute locked
//    E_ATTRIBUTE_IS_MHEG_INCLUDED,           ///< Attribute mheg included
    E_ATTRIBUTE_IS_REPLACE_SERVICE,           ///< Attribute replacement service
    E_ATTRIBUTE_IS_SERVICE_ID_ONLY,         ///< Attribute service ID only
    E_ATTRIBUTE_IS_DELETED,                 ///< Attribute deleted
    E_ATTRIBUTE_VIDEO_TYPE,              ///< Attribute HD Service
    E_ATTRIBUTE_IS_REPLACE_DEL,             ///< Attribute Replace Del
    E_ATTRIBUTE_IS_MOVED,                    ///< Attribute moved
#if ENABLE_T_C_CHANNEL_MIX
    E_ATTRIBUTE_IS_TERRESTRIAL,             ///< Attribute demod type
#endif
    E_ATTRIBUTE_IS_SPECIAL_CH,              ///< Attribute special service

    E_ATTRIBUTE_IS_UNCONFIRMED_SERVICE,
    E_ATTRIBUTE_IS_INVALID_SERVICE,
    E_ATTRIBUTE_IS_LCN_VALID

} E_MEMBER_CHANNEL_ATTRIBUTE;

/// PSI/SI Version member
typedef enum
{
    E_VERSION_PMT,                          ///< PMT
    E_VERSION_PAT,                          ///< PAT
    E_VERSION_NIT,                          ///< NIT
    E_VERSION_SDT                           ///< SDT
} E_MEMBER_PSI_SI_VERSION;


/// ISO 639 Language
typedef struct __attribute__ ((__packed__))
{
    BYTE bISOLangIndex;                     ///< ISO Language index
    BYTE bISOLanguageInfo   : 2;            ///< 0x00: Stereo, 0x01: Mono right, 0x02: Mono left
    BYTE bAudType           : 3;            ///< 0x00: Undefined, 0x01: Clean effects, 0x02: Hearing impaired, 0x03: Visual impaired commentary, 0x04~0xFF: Reserved.
    BYTE bIsValid           : 1;            ///< Valid or not
    BYTE bBroadcastMixedAD  : 1;            ///< broadcast mixed AD
    BYTE bReserved          : 1;            ///< Reserved
} LANG_ISO639;

/// Audio information
typedef struct __attribute__ ((__packed__))
{
    LANG_ISO639 aISOLangInfo[MAX_AUD_ISOLANG_NUM];   ///< ISO Language Info
    WORD wAudType           : 3;            ///<  0x01: MPEG, 0x02: AC-3, 0x03: MPEG4_AUD
    WORD wAudPID            : 13;           ///< Audio PID
    //WORD Reserved           : 1;            ///< Reserved
#if 1//NTV_FUNCTION_ENABLE
    U8 u8ProfileAndLevel;
    U8 u8Component_AAC_Type;
#endif
}AUD_INFO;


typedef struct
{
    BYTE bPATVer;
    BYTE bPMTVer;
    BYTE bNITVer;
    BYTE bSDTVer;
} DVB_TABLE_VERSION;

typedef enum
{
    E_SERRUNSTA_UNDEFINED                  = 0x00,
    E_SERRUNSTA_NOT_RUNNING                = 0x01,
    E_SERRUNSTA_START_IN_A_FEW_SECOND     = 0x02,
    E_SERRUNSTA_PAUSING                     = 0x03,
    E_SERRUNSTA_RUNNING                     = 0x04
} E_MEMBER_SERVICE_RUNNING_STATUS;

typedef enum
{
    E_SERVICETYPE_PRIORITY_HIGH    = 0x00,
    E_SERVICETYPE_PRIORITY_MIDDLE  = 0x01,
    E_SERVICETYPE_PRIORITY_LOW     = 0x02,
    E_SERVICETYPE_PRIORITY_NONE    = 0x03
} SERVICETYPE_PRIORITY;


typedef enum
{
    E_VIDEOTYPE_MPEG    = 0x00,
    E_VIDEOTYPE_H264  = 0x01,
    E_VIDEOTYPE_AVS     = 0x02,
    E_VIDEOTYPE_VC1    = 0x03
} VIDEO_TYPE;
typedef struct __attribute__ ((__packed__))
{
    WORD bValidLCN				: 1;
    WORD wSignalStrength		: 15;
    BYTE bVisibleServiceFlag    : 1;
    BYTE bNumericSelectionFlag  : 1;    // Hidden but selectable through direct numeric entry
    BYTE bIsDelete              : 1;
    BYTE bIsMove                : 1;
    BYTE bIsScramble            : 1;    // 0=FTA, 1=Scramble
    BYTE bIsSkipped             : 1;    // for Channel Edit skip function.
    BYTE bIsLock                : 1;
    BYTE bIsStillPicture        : 1;    // for information from Video_stream_descriptor(0x02)

//    WORD bIsMHEGIncluded        : 1;
    WORD bReplaceService        : 1;
    WORD eVideoType           : 2;
    WORD bIsServiceIdOnly       : 1;    // If the program is not shown in PAT, set to TRUE
    //WORD bIsDataServiceAvailable: 1;  //useless data, remove  // If ttx or subtitle is available, the flag set to TRUE
    WORD bIsReplaceDel          : 1;
    WORD bServiceType           : 4;   //add service type 2 bit to 4 bit // for information from PMT for empty Video_PID
    WORD bIsSpecialService      : 1;
#ifdef HSS_TWO_DEMOD
    WORD bIsMultiCarrier        : 1;    // Use for distinguish the demod type.
#elif ENABLE_T_C_CHANNEL_MIX
    WORD bIsTerrestrial         : 1;    // Use for distinguish the demod type.
#else
    WORD reserved1              : 1;
#endif
#if ENABLE_TARGET_REGION
    WORD cRegion     : 4;
#else
	WORD reserved2	 : 4;

#endif
    WORD bInvalidService     : 1;
#if (CM_MULTI_FAVORITE)
    BYTE bIsFavorite            : 4;
    BYTE bServiceTypePrio       : 2;
    BYTE bInvalidCell           : 1;
    BYTE bUnconfirmedService    : 1;
#else
    BYTE bIsFavorite            : 1;
    BYTE bServiceTypePrio       : 2;
    BYTE bInvalidCell           : 1;
    BYTE bUnconfirmedService    : 1;
    BYTE reserved3              : 3;
#endif

} CHANNEL_ATTRIBUTE;

#if ENABLE_SBTVD_BRAZIL_APP
typedef struct
{
    BYTE bVirtualChannel;
    BYTE bPhysicalChannel;
} ST_LCN;

typedef union
{
    ST_LCN stLCN;
    WORD wLCN;
} LOGICAL_CHANNEL_NUMBER;
#endif

typedef struct
{
    BYTE cHpLp;//0=>HP, 1=>LP
    BYTE cRFChannelNumber;
    WORD wPCR_PID;
    WORD wVideo_PID;
    WORD wTransportStream_ID;
    WORD wOriginalNetwork_ID;
    WORD wNetwork_ID;
    WORD wCellID;
    WORD wOrder;
    union
    {
        #if ENABLE_SBTVD_BRAZIL_APP
        ST_LCN stLCN;
        #endif
        WORD wLCN;
    };
    WORD wPmt_PID;                          ///< PMT PID
    DVB_TABLE_VERSION stPSI_SI_Version;
    CHANNEL_ATTRIBUTE stCHAttribute;
    WORD wService_ID;
#if 1//NTV_FUNCTION_ENABLE
    WORD wTS_LCN;
#endif
    WORD wSimu_LCN;  //  for HD Simulcast Logical Channel number
    AUD_INFO stAudInfo[MAX_AUD_LANG_NUM];
} SHORT_DTV_CHANNEL_INFO;

/// DTV Channel info
typedef struct
{
    BYTE bIDIdex;                           // Index to Program ID table
    WORD wPCR_PID;                          ///< PCR PID
    WORD wVideo_PID;                        ///< Video PID
    WORD wOrder;                            ///< Order
    union
    {
        #if ENABLE_SBTVD_BRAZIL_APP
        ST_LCN stLCN;
        #endif
        WORD wLCN;
    };
    WORD wPmt_PID;                          ///< PMT PID
    DVB_TABLE_VERSION stPSI_SI_Version;     ///< PSI/SI Version
    CHANNEL_ATTRIBUTE stCHAttribute;        ///< Channel attribute
    WORD wService_ID;                       ///< Service ID
#if 1//NTV_FUNCTION_ENABLE
    WORD wTS_LCN;
#endif
    WORD wSimu_LCN;  //  for HD Simulcast Logical Channel number
    AUD_INFO stAudInfo[MAX_AUD_LANG_NUM];   ///< Audio info
#if ENABLE_SAVE_MULTILINGUAL_SERVICE_NAME
	BYTE bMultiLanguage[MAX_MULTI_LINGUAL_SERVICE_NAME];
	BYTE bMultiChannelName[MAX_MULTI_LINGUAL_SERVICE_NAME][MAX_SERVICE_NAME];	///< Channel name
#endif
    BYTE bChannelName[MAX_SERVICE_NAME];    ///< Channel name
    #if ENABLE_DTV_STORE_TTX_PAGE_INFO//(ENABLE_TTX || BLOADER)
    BYTE u8ListPage[MAX_LISTPAGE_SIZE];
    #endif
} DTV_CHANNEL_INFO;




typedef struct _DTV_SIMPLE_SERVICE_INFO
{
    BYTE bChannelName[MAX_SERVICE_NAME];
    WORD wNumber;
    DWORD dwPosition;
	BOOLEAN bServiceToSelect;
	BOOLEAN bVisible;
	BOOLEAN bCountryService;
    struct _DTV_SIMPLE_SERVICE_INFO* next;
} DTV_SIMPLE_SERVICE_INFO;

#if(ENABLE_LCN_CONFLICT)
typedef struct _DTV_LCN_CONFLICT_INFO
{
    BYTE bLcnConflictChannelName[MAX_SERVICE_NAME];
    DWORD dwLcnConflictPosition;
}DTV_LCN_CONFLICT_INFO;
#endif

/// Program accessible boundary
typedef enum
{
    E_PROGACESS_INCLUDE_VISIBLE_ONLY        = 0x00,     ///< Program access include visible only
    E_PROGACESS_INCLUDE_NOT_VISIBLE_ALSO    = 0x01,      ///< Program access Also include Not visible
    E_PROGACESS_INCLUDE_ALL    = 0x02      ///< Program access Also include Not visible
} E_MEMBER_PROGRAM_ACCESSIBLE_BOUNDARY;

#if DVB_T_C_DIFF_DB
#define MAX_DTV_C_CHANNELTABLE_MAP     ((MAX_DTV_C_PROGRAM+7)/8)
#define DTVDATA_ID                     0xA55A
#define MAX_DTV_C_IDTABLE_MAP          ((MAX_DTV_C_MUX_NUMBER+7)/8)
#endif

#define MAX_DTVCHANNELTABLE_MAP     ((MAX_DTVPROGRAM+7)/8)
#define DTVDATA_ID                  0xA55A

#define MAX_DTVIDTABLE_MAP     ((MAX_MUX_NUMBER+7)/8)
typedef struct
{
    WORD wTransportStream_ID;           // Transportstream ID
    WORD wOriginalNetwork_ID;           // Original Network ID
    WORD wNetwork_ID;           // Network ID
    WORD wCellID;                   //Cell ID
    BYTE cRFChannelNumber;              // RF Channel Number
    BYTE cPLPID;
#if (ENABLE_UPDATE_MULTIPLEX_VIA_NIT)
    BYTE cOriginal_RF;
    DWORD  dwAlternativeTime;
#endif
    #if DVB_C_ENABLE
    U32  u32Frequency;
    U32  u32SymbRate;
    BYTE QamMode;
    #endif
    BYTE cHpLp;//0=>HP, 1=>LP
} DTVPROGRAMID;

typedef struct
{
    WORD wTransportStream_ID;           // Transportstream ID
    WORD wOriginalNetwork_ID;           // Original Network ID
    WORD wCellID;                       // Cell ID
    BYTE cRFChannelNumber;              // RF Channel Number
    BYTE cPLPID;
#if (ENABLE_UPDATE_MULTIPLEX_VIA_NIT)
    BYTE cOriginal_RF;
    DWORD  dwAlternativeTime;
#endif
    #if DVB_C_ENABLE
    U32  u32Frequency;
    U32  u32SymbRate;
    BYTE QamMode;
    #endif
    BYTE cNetWorkIndex;
    BYTE cHpLp;//0=>HP, 1=>LP

} DTVPROGRAMID_M;

typedef struct
{
    WORD wNetwork_ID;                       // Network ID
    BYTE bNetworkName[MAX_NETWORK_NAME];    // Network name
} DTVNETWORK;

typedef struct
{
    WORD                wID;
    BYTE                bSerialNum;
    MEMBER_COUNTRY      eCountry;
    BOOLEAN             bIsLogicalChannelNumberArranged;
#if NTV_FUNCTION_ENABLE
    BYTE                bFavorite_Region;
#endif
#if (EEPROM_DB_STORAGE == EEPROM_SAVE_NONE)
    WORD                wCurOrderOfTV;
    WORD                wCurOrderOfRadio;
    WORD                wCurOrderOfData;
    MEMBER_SERVICETYPE  eDTVCurrentServiceType;
#endif
    BYTE                bDTVChannelTableMap[MAX_DTVCHANNELTABLE_MAP];
    DTV_CHANNEL_INFO    astDTVChannelTable[MAX_DTVPROGRAM];
    BYTE                bDTVIDtableMap[MAX_DTVIDTABLE_MAP];
    DTVPROGRAMID_M      astDtvIDTable[MAX_MUX_NUMBER];
    DTVNETWORK          astDtvNetwork[MAX_NETWOEK_NUMBER];

#if DVB_T_C_DIFF_DB
    BYTE                bDTV_C_ChannelTableMap[MAX_DTV_C_CHANNELTABLE_MAP];
    DTV_CHANNEL_INFO    astDTV_C_ChannelTable[MAX_DTV_C_PROGRAM];
    BYTE                bDTV_C_IDtableMap[MAX_DTV_C_IDTABLE_MAP];
    DTVPROGRAMID        astDtv_C_IDTable[MAX_DTV_C_MUX_NUMBER];
    DTVNETWORK          astDtv_C_Network[MAX_NETWOEK_NUMBER];
#endif
//    BYTE                bUnsupportedLangCode_Count;
 //   BYTE                abUnsupportedLangCode[MAX_UNSUPPORTED_ISO639CODE_NUM * MAX_ISO639CODE_LENGTH];
} DTV_CHANNEL_DATA_STRUCTURE;


typedef struct
{
    void (*pfNotify_CM_SwapProgram)(WORD wFromOrder, WORD wToOrder);
    void (*pfNotify_CM_MoveProgram)(U16 u16FromIndex, U16 u16ToIndex);
    void (*pfNotify_SrvPriorityHandler) (U16 u16MainlistIdx);
    void (*pfNotify_CM_RemoveProgram) (WORD wSrvOrder);
    void (*pfNotify_CM_ResetAllProgram) (void);
} DTV_CM_INIT_PARAMETER;


typedef enum // channel list type
{
    E_ATV_TYPE = E_SERVICETYPE_ATV,
    E_ALL_LIST = E_SERVICETYPE_UNITED_TV,
    E_DTV_LIST = E_SERVICETYPE_DTV,
    E_RADIO_LIST = E_SERVICETYPE_RADIO,
    E_DATA_LIST = E_SERVICETYPE_DATA
} CHANNEL_LIST_TYPE;

typedef enum
{
    E_LCN_TYPE_AUTO        = 0x00,
    E_LCN_TYPE_MANUAL    = 0x01,
    E_LCN_TYPE_MOVE        = 0x02,
    E_LCN_TYPE_DELETE    = 0x03
} E_MEMBER_LCN_TYPE;

typedef enum
{
    E_CM_SERVICE_POS_DTV = 0x00,
    E_CM_SERVICE_POS_RADIO = 0x01,
    E_CM_SERVICE_POS_DATA = 0x02,
}E_CM_SERVICE_POS;

#define IS_COUNTRY_SUPPORT_LCN(c)       ( (c==E_DENMARK)       ||  \
                                          (c==E_FRANCE)        ||  \
                                          (c==E_FINLAND)       ||  \
                                          (c==E_ITALY)         ||  \
                                          (c==E_NETHERLANDS)   ||  \
                                          (c==E_SWEDEN)        ||  \
                                          (c==E_UK)            ||  \
                                          (c==E_AUSTRALIA) )

#define IS_NORDIC_COUNTRY(c)            ( (c==E_FINLAND)       ||  \
                                          (c==E_SWEDEN)        ||  \
                                          (c==E_DENMARK)       ||  \
                                          (c==E_NORWAY) )

#define IS_BESTMUX_COUNTRY(c)            ( (c==E_FINLAND)      ||  \
                                          (c==E_SWEDEN)        ||  \
                                          (c==E_DENMARK)       ||  \
                                          (c==E_NORWAY)        ||  \
                                          (c==E_UK)            ||  \
                                          (c==E_IRELAND)            ||  \
                                          (c==E_NEWZEALAND))


#define IS_SID_UNIQUE_COUNTRY(c)            ( (c==E_NORWAY)      ||  \
                                          (c==E_UK)   || \
                                          (c==E_NEWZEALAND))

#define IS_NORDIC_NETWORK_UPDATE_COUNTRY(c)            ( (c==E_FINLAND)       ||  \
                                          (c==E_NORWAY) )

#ifdef API_DTVSYSTEM_C
#define INTERFACE
#else
#define INTERFACE extern
#endif
/******************************************************************************/
/*                       Global Variable Declarations                         */
/******************************************************************************/
#if(ENABLE_LCN_CONFLICT)
#define   MAX_SUPPORT_LCN_CONFLICT_NUM    5
INTERFACE DTV_LCN_CONFLICT_INFO g_ucLcnConflict[MAX_SUPPORT_LCN_CONFLICT_NUM];
#endif
//------------------------------------------------------------------------------
// Public functions.
//------------------------------------------------------------------------------

INTERFACE void msAPI_CM_Init(DTV_CM_INIT_PARAMETER* psNotify);
INTERFACE BOOLEAN msAPI_CM_GetServiceTypeAndPositionWithPCN(BYTE cPCN, WORD wService_ID, MEMBER_SERVICETYPE *peServiceType, WORD * pwPosition);
INTERFACE BYTE msAPI_CM_GetCountOfSameServiceWithIDs(WORD wTransportStream_ID, WORD wOriginalNetwork_ID, WORD wService_ID);
INTERFACE BOOLEAN msAPI_CM_GetServiceTypeAndPositionWithIDs(WORD wTransportStream_ID, WORD wOriginalNetwork_ID, WORD wService_ID, BYTE cOrdinal, MEMBER_SERVICETYPE * peServiceType, WORD * pwPosition, BOOLEAN bCheckTsID);
INTERFACE BOOLEAN msAPI_CM_MoveProgram(MEMBER_SERVICETYPE bServiceType, WORD wFromPosition, WORD wToPosition);
INTERFACE BYTE msAPI_CM_RemoveMismatchedProgram(BYTE cRFChannelNumber, WORD wTSID, BYTE cPLP_ID, BYTE cHpLp, WORD *pwService_ID, MEMBER_SERVICETYPE *peService_Type, BYTE cCountOfServiceID);
INTERFACE BOOLEAN msAPI_CM_FillProgramDataWithDefault(DTV_CHANNEL_INFO *pDTVProgramData);
INTERFACE void msAPI_CM_FillProgramDefaultDataWithoutSrvName(SHORT_DTV_CHANNEL_INFO *pstShortDtvPgmData);
INTERFACE MEMBER_SERVICETYPE msAPI_CM_GetCurrentServiceType(void);
INTERFACE BOOLEAN msAPI_CM_SetCurrentServiceType(MEMBER_SERVICETYPE bServiceType);
INTERFACE WORD msAPI_CM_GetCurrentPosition(MEMBER_SERVICETYPE bServiceType);
INTERFACE BOOLEAN msAPI_CM_SetCurrentPosition(MEMBER_SERVICETYPE bServiceType, WORD wPosition);
INTERFACE WORD msAPI_CM_CountProgram(MEMBER_SERVICETYPE bServiceType, E_MEMBER_PROGRAM_ACCESSIBLE_BOUNDARY eBoundary);
INTERFACE WORD msAPI_CM_GetFirstProgramPosition(MEMBER_SERVICETYPE bServiceType, BOOLEAN bIncludeSkipped);
INTERFACE WORD msAPI_CM_GetLastProgramPosition(MEMBER_SERVICETYPE bServiceType, BOOLEAN bIncludeSkipped);
INTERFACE WORD msAPI_CM_GetNextProgramPosition(MEMBER_SERVICETYPE bServiceType, WORD wBasePosition, BOOLEAN bIncludeSkipped, CHANNEL_LIST_TYPE bList_type, MEMBER_SERVICETYPE *bNewServiceType);
INTERFACE BOOLEAN msAPI_CM_ResetAllProgram(void);
INTERFACE WORD msAPI_CM_GetLogicalChannelNumber(MEMBER_SERVICETYPE bServiceType, WORD wPosition);
INTERFACE WORD msAPI_CM_GetOriginalLogicalChannelNumber(MEMBER_SERVICETYPE bServiceType, WORD wPosition);
INTERFACE WORD msAPI_CM_GetSimuLogicalChannelNumber(MEMBER_SERVICETYPE bServiceType, WORD wPosition);
INTERFACE BYTE msAPI_CM_GetPhysicalChannelNumber(MEMBER_SERVICETYPE bServiceType, WORD wPosition);
INTERFACE BYTE msAPI_CM_GetPSISIVersion(MEMBER_SERVICETYPE bServiceType, WORD wPosition, E_MEMBER_PSI_SI_VERSION eVersionMember);
INTERFACE BOOLEAN msAPI_CM_GetProgramAttribute(MEMBER_SERVICETYPE bServiceType, WORD wPosition, E_MEMBER_CHANNEL_ATTRIBUTE eAttributeMember);
INTERFACE VIDEO_TYPE msAPI_CM_GetProgramVideoType(MEMBER_SERVICETYPE bServiceType, WORD wPosition);
INTERFACE WORD msAPI_CM_GetPmtPID(MEMBER_SERVICETYPE bServiceType, WORD wPosition);
INTERFACE WORD msAPI_CM_GetPCR_PID(MEMBER_SERVICETYPE bServiceType, WORD wPosition);
INTERFACE WORD msAPI_CM_GetVideoPID(MEMBER_SERVICETYPE bServiceType, WORD wPosition);
INTERFACE BYTE msAPI_CM_GetAudioStreamCount(MEMBER_SERVICETYPE bServiceType, WORD wPosition);
INTERFACE BYTE msAPI_CM_GetSelectedAudioStream(MEMBER_SERVICETYPE bServiceType, WORD wPosition);
INTERFACE BOOLEAN msAPI_CM_GetAudioStreamInfo(MEMBER_SERVICETYPE bServiceType, WORD wPosition, AUD_INFO * pstAudioStreamInfo, BYTE cOrdinal);
INTERFACE BOOLEAN msAPI_CM_GetProgramInfo(MEMBER_SERVICETYPE bServiceType, WORD wPosition,DTV_CHANNEL_INFO *pChannelInfo);
INTERFACE BYTE msAPI_CM_GetNextAudioStreamOrdinal(MEMBER_SERVICETYPE bServiceType, WORD wPosition, BYTE cBaseOrdinal);
INTERFACE BYTE msAPI_CM_GetPrevAudioStreamOrdinal(MEMBER_SERVICETYPE bServiceType, WORD wPosition, BYTE cBaseOrdinal);
INTERFACE BOOLEAN msAPI_CM_GetServiceName(MEMBER_SERVICETYPE bServiceType, WORD wPosition, BYTE * bChannelName);
INTERFACE WORD msAPI_CM_GetService_ID(MEMBER_SERVICETYPE bServiceType, WORD wPosition);
INTERFACE WORD msAPI_CM_GetTS_ID(MEMBER_SERVICETYPE bServiceType, WORD wPosition);
INTERFACE WORD msAPI_CM_GetON_ID(MEMBER_SERVICETYPE bServiceType, WORD wPosition);
INTERFACE WORD msAPI_CM_GetNetwork_ID(MEMBER_SERVICETYPE bServiceType, WORD wPosition);
INTERFACE BOOLEAN msAPI_CM_GetCellIDByPosition(MEMBER_SERVICETYPE bServiceType, WORD wPosition, WORD *pwCellID);
INTERFACE BOOLEAN msAPI_CM_ServiceIDOnlyProgram(MEMBER_SERVICETYPE bServiceType, WORD wPosition,MS_U8 IsServiceIdOnly);
INTERFACE BOOLEAN msAPI_CM_ScrambleProgram(MEMBER_SERVICETYPE bServiceType, WORD wPosition,MS_U8 IsScramble);
INTERFACE BOOLEAN msAPI_CM_SetProgramVideoType(MEMBER_SERVICETYPE bServiceType, WORD wPosition,U8 u8VideoType);
INTERFACE BOOLEAN msAPI_CM_DeleteProgram(MEMBER_SERVICETYPE bServiceType, WORD wPosition,MS_U8 fIsDelete);
INTERFACE BOOLEAN msAPI_CM_ReplaceDelProgram(MEMBER_SERVICETYPE bServiceType, WORD wPosition,BOOLEAN bDel);
INTERFACE BOOLEAN msAPI_CM_RecoveryDelProgram(MEMBER_SERVICETYPE bServiceType, WORD wPosition);
INTERFACE BOOLEAN msAPI_CM_FavorProgram(MEMBER_SERVICETYPE bServiceType, WORD wPosition, BOOLEAN bFavorite);
INTERFACE BOOLEAN msAPI_CM_SkipProgram(MEMBER_SERVICETYPE bServiceType, WORD wPosition, BOOLEAN bSkip);
INTERFACE BOOLEAN msAPI_CM_UpdateProgramVisibleAndSelectable(MEMBER_SERVICETYPE bServiceType, WORD wPosition, BOOLEAN bVisible, BOOLEAN bSelectable);
INTERFACE BOOLEAN msAPI_CM_UpdateProgramSpecialService(MEMBER_SERVICETYPE bServiceType, WORD wPosition, BOOLEAN bSpecialService);
INTERFACE BOOLEAN msAPI_CM_LockProgram(MEMBER_SERVICETYPE bServiceType, WORD wPosition, BOOLEAN bLock);
INTERFACE BOOLEAN msAPI_CM_IsServiceExistWithIDsAndLCN(WORD wOriginalNetwork_ID, WORD wService_ID,  WORD wLCN);
INTERFACE BOOLEAN msAPI_CM_GetIDTable(BYTE bIDIndex, BYTE * pcBuffer,PROGRAMDATA_MEMBER eMember);
INTERFACE BOOLEAN msAPI_CM_SetIDTable(BYTE bIDIndex, BYTE * pcBuffer,PROGRAMDATA_MEMBER eMember);
INTERFACE void msAPI_CM_EnableStoreDataToFlash(BOOLEAN bEnable);//20090806
#if (ENABLE_UPDATE_MULTIPLEX_VIA_NIT)
INTERFACE BOOLEAN msAPI_CM_RemoveMismatchedMux(WORD wNID, WORD *pwTS_ID,  BYTE cCountOfTS,  U32 *u32NewTS, BOOLEAN bRemove);
INTERFACE BOOLEAN msAPI_CM_SetPhysicalChannelNumberAndCell(MEMBER_SERVICETYPE bServiceType, WORD wPosition, BYTE cRFChannelNumber, WORD wCellID);
INTERFACE BOOLEAN msAPI_CM_SetMismatchedCell(WORD wONID, WORD wTSID, WORD *pCellLsit, U8 u8CellNumber, BOOLEAN *bRemoved);
INTERFACE BOOLEAN msAPI_CM_IsServiceExistWithIDsAndLCN(WORD wOriginalNetwork_ID, WORD wService_ID,  WORD wLCN);
INTERFACE BOOLEAN msAPI_CM_CheckNetwork(WORD wNID, WORD *pwTS_ID,  BYTE cCountOfTS, U32 *u32NewTS, BOOLEAN *bRemove);
INTERFACE BOOLEAN msAPI_CM_GetCellIDByPosition(MEMBER_SERVICETYPE bServiceType, WORD wPosition, WORD *pwCellID);
INTERFACE BOOLEAN msAPI_CM_RemoveInvalidService(BOOLEAN *bCurCHIsRemoved);
INTERFACE BOOLEAN msAPI_CM_SetUnconfirmedServiceInvalid(WORD wONID, WORD wTSID, BOOLEAN *bGotService);
INTERFACE BYTE msAPI_CM_GetOriginalRFnumber(MEMBER_SERVICETYPE bServiceType, WORD wPosition);
INTERFACE BOOLEAN msAPI_CM_ResetOriginalRFnumber(MEMBER_SERVICETYPE bServiceType, WORD wPosition);
INTERFACE BOOLEAN msAPI_CM_ResetAlternativeTime(MEMBER_SERVICETYPE bServiceType, WORD wPosition);
INTERFACE U32 msAPI_CM_GetAlternativeTime(MEMBER_SERVICETYPE bServiceType, WORD wPosition);
#endif
#if (NTV_FUNCTION_ENABLE)
INTERFACE BOOLEAN msAPI_CM_IS_NorwegianNetwork(BYTE cNetworkIndex);
INTERFACE void msAPI_CM_Set_FavoriteNetwork(BYTE cNetworkIndex);
INTERFACE BYTE msAPI_CM_Get_FavoriteNetwork(void);
INTERFACE void msAPI_CM_RestoreProgramOrder(void);
INTERFACE void msAPI_CM_RestoreLCN(void);
#endif
INTERFACE BYTE msAPI_CM_GetPhysicalChannelNumberByID(WORD wONID, WORD wTSID);

#if ENABLE_SDT_OTHER_MONITOR
INTERFACE BOOLEAN msAPI_CM_Is_TSExist(WORD wONID, WORD wTSID, BYTE *pcRFChannelNumber);
INTERFACE BOOLEAN msAPI_CM_GetCEllID_WithID(WORD wTS_ID, WORD wON_ID, WORD *wCell_ID, BOOLEAN *bOverOneCell);
INTERFACE BOOLEAN msAPI_CM_GetSameServiceInOtherMux(MEMBER_SERVICETYPE bServiceType, WORD wLCN, WORD wSID, WORD *pPosition);
#endif
INTERFACE WORD msAPI_CM_GetPrevProgramPosition(MEMBER_SERVICETYPE bServiceType, WORD wBasePosition, BOOLEAN bIncludeSkipped, CHANNEL_LIST_TYPE bList_type, MEMBER_SERVICETYPE *bNewServiceType);
INTERFACE WORD msAPI_CM_CountFavoriteProgram(MEMBER_SERVICETYPE bServiceType);
INTERFACE WORD msAPI_CM_GetNextFavoriteProgramPosition(MEMBER_SERVICETYPE bServiceType, WORD wBasePosition, BOOLEAN bIncludeSkipped);
INTERFACE BOOLEAN msAPI_CM_AddProgram(DTV_CHANNEL_INFO *pDTVProgramData, BOOLEAN *bDBFull, BOOLEAN bSkipCheck);
INTERFACE DTV_SIMPLE_SERVICE_INFO* msAPI_CM_GetDuplicateService(MEMBER_SERVICETYPE bServiceType, WORD wStartLCN);
INTERFACE BOOLEAN msAPI_CM_SetSelectService(DWORD dwIndex);

INTERFACE BOOLEAN msAPI_CM_UpdateProgram(MEMBER_SERVICETYPE bServiceType, WORD wPosition, BYTE *pcBuffer, PROGRAMDATA_MEMBER eMember);
INTERFACE BOOLEAN msAPI_CM_ArrangeDataManager(BOOLEAN bReArrangeLcn, BOOLEAN bSkipDupSrvRemove);
INTERFACE BOOLEAN ddmArrangeLogicalChannelNumber(MEMBER_SERVICETYPE eServiceType, E_MEMBER_LCN_TYPE eLcnType);
INTERFACE BOOLEAN msAPI_CM_SortDataManager(void);
INTERFACE BOOLEAN msAPI_CM_GetFirstPositionInPCN(MEMBER_SERVICETYPE bServiceType, BYTE cPCN, WORD * pwPosition);
#if ENABLE_SBTVD_BRAZIL_APP
INTERFACE BOOLEAN msAPI_CM_GetFirstPositionInMajorNum(MEMBER_SERVICETYPE bServiceType, BYTE cMajorNum, WORD * pwPosition);
BYTE msAPI_CM_Get_FirstPhysicalChannelNumber(void);
#endif
INTERFACE WORD msAPI_CM_GetFirstFavoriteProgramPosition(MEMBER_SERVICETYPE bServiceType, BOOLEAN bIncludeSkipped);
INTERFACE WORD msAPI_CM_GetLastFavoriteProgramPosition(MEMBER_SERVICETYPE bServiceType, BOOLEAN bIncludeSkipped);
INTERFACE WORD msAPI_CM_GetPrevFavoriteProgramPosition(MEMBER_SERVICETYPE bServiceType, WORD wBasePosition, BOOLEAN bIncludeSkipped);
INTERFACE void msAPI_CM_PrintAllProgram(void);
INTERFACE void msAPI_CM_PrintProgram(MEMBER_SERVICETYPE bServiceType, WORD wPosition);
#if ENABLE_SZ_DTV_ADDCH_SCAN_FUNCTION
INTERFACE BOOLEAN msAPI_IsEmptyPhysicalChannelNumber(BYTE number);
INTERFACE BYTE msAPI_CM_GetNextEmptyPhysicalChannelNumber(BYTE cRFChannelNumber);
#endif
INTERFACE void msAPI_CM_Set_TS_Update(BOOLEAN bCheck, WORD wTS_ID);
#if 0
INTERFACE BOOLEAN msAPI_CM_UpdatePCN(BYTE cOldRFCH, BYTE cNewRFCH);
#endif

//INTERFACE void msAPI_CM_ResetUnsupportedIso639Code(void);
//INTERFACE void msAPI_CM_LoadUnsupportedIso639CodeByIndex(U8 *pBuf, U8 u8BufSize, U8 u8Index);
//INTERFACE U8 msAPI_CM_SaveUnsupportedIso639Code(U8 *pCode);
INTERFACE BOOLEAN msAPI_CM_ArrangeAudioStreamInfo(MEMBER_SERVICETYPE bServiceType, WORD wPosition, U16 cValidAudIndex);

INTERFACE void msAPI_CM_Reset_AudioValidIndex(void);
INTERFACE U16 msAPI_CM_Get_AudioValidIndex(void);
INTERFACE BOOLEAN msAPI_CM_Update_AudioValidInfo(U16 u16AudioValidIndex);
INTERFACE BYTE msAPI_CM_Get_RFChannelIndex(BYTE bRFChannel);
#if ENABLE_DTV_STORE_TTX_PAGE_INFO//ENABLE_TTX
INTERFACE BOOLEAN msAPI_CM_GetListPageNumber(BYTE u8ListIndex, WORD * pwListPageNumber,MEMBER_SERVICETYPE bServiceType,WORD wPosition);
INTERFACE BOOLEAN msAPI_CM_SetListPageNumber(BYTE u8ListIndex, WORD wListPageNumber,MEMBER_SERVICETYPE bServiceType,WORD wPosition);
#endif

INTERFACE void msAPI_CM_SetAudioStreamValidIndex(MEMBER_SERVICETYPE bServiceType, WORD wPosition,  WORD wType, BYTE bISOLangIndex,U16 *pu16Index);

INTERFACE BYTE msAPI_CM_AddProgramIDTable(DTVPROGRAMID *pstDtvIDTable,BOOLEAN bSave);
INTERFACE void msAPI_CM_GetLIBVerString(U8 *pVer);
INTERFACE WORD msAPI_CM_GetPLP_ID(MEMBER_SERVICETYPE bServiceType, WORD wPosition);
INTERFACE BYTE msAPI_CM_GetHpLp(MEMBER_SERVICETYPE bServiceType, WORD wPosition);
INTERFACE BOOLEAN msAPI_CM_GetPLPID_WithID(WORD wTS_ID, WORD wON_ID, U8* pu8PLP_ID);
INTERFACE BOOLEAN msAPI_CM_GetHpLP_WithID(WORD wTS_ID, WORD wON_ID, U8* pu8HpLp);
INTERFACE BOOLEAN msAPI_CM_GetNetworkName(BYTE bIndex, BYTE * bNetworkName);
INTERFACE BOOLEAN msAPI_CM_SetNetworkName(BYTE bIndex, BYTE * bNetworkName);
INTERFACE BOOLEAN msAPI_CM_UpdateNetworkNameWithNID(WORD wNID, BYTE *bNetworkName);
INTERFACE BOOLEAN msAPI_CM_SetCurrentNetworkName(U8 *bNetworkName, U8 u8NetworkLen);
INTERFACE BOOLEAN msAPI_CM_GetCurrentNetworkName(U8 *bNetworkName, U8 *u8NetworkLen, U8 u8MaxLen);
INTERFACE WORD msAPI_CM_CountNetworkProgram(MEMBER_SERVICETYPE bServiceType, U16 u16NetworkID);
INTERFACE WORD msAPI_CM_GetFirstNetworkProgramPosition(MEMBER_SERVICETYPE bServiceType, U16 u16NetworkID);
INTERFACE WORD msAPI_CM_GetLastNetworkProgramPosition(MEMBER_SERVICETYPE bServiceType);
INTERFACE WORD msAPI_CM_GetNextNetworkProgramPosition(MEMBER_SERVICETYPE bServiceType, WORD wBasePosition, U16 u16NetworkID);
INTERFACE BOOLEAN msAPI_CM_ResetAttribute(MEMBER_SERVICETYPE bServiceType, WORD wPosition);
WORD msAPI_CM_GetPrevNetworkProgramPosition(MEMBER_SERVICETYPE bServiceType,U16 wBasePosition, U16 u16NetworkID);
INTERFACE BOOLEAN msAPI_CM_IsLCNExit(MEMBER_SERVICETYPE bServiceType, WORD wLCN, WORD *pPosition);
#if DVB_C_ENABLE
INTERFACE BOOLEAN msAPI_CM_GetIDIndexWithFreq(U32 u32Freq, BYTE *cIDIndex);
INTERFACE BYTE msAPI_CM_RemoveQuickInstallMismatchedProgram(WORD *pwServiceID, U8 cCountOfServiceID, BYTE cRFChannelNumber, MEMBER_SERVICETYPE eServiceType);
INTERFACE void msAPI_CM_RemoveQuickInstallMismatchedTS(U16 *pu16TsIds, U8 u8TsIdNum);
#if ENABLE_T_C_CHANNEL_MIX
INTERFACE BOOLEAN msAPI_CM_RemoveDTVProgramOfAntenna(void);
#endif
#endif
#if ENABLE_TARGET_REGION
INTERFACE void msAPI_CM_SetRegion(WORD wONID, WORD wTSID, WORD wSID, BYTE cValue);
#endif
#if (ENABLE_LCN_CONFLICT)
INTERFACE void msAPI_CM_ResetLCNConflictParams(void);
#endif
INTERFACE void msAPI_CM_RemoveSameService(void);

INTERFACE BOOLEAN msAPI_CM_IS_SID_Unique_Country(void);
INTERFACE BOOLEAN msAPI_CM_IsAVCService(WORD wOriginalNetwork_ID, WORD wService_ID);
INTERFACE BOOLEAN msAPI_CM_RestLCNByRF(WORD* pServiceList, WORD wNumber, BYTE cRFNumber);
#if ENABLE_FAVORITE_NETWORK
INTERFACE void    msAPI_DTV_Program_Network_Info_Print(U8 u8Index);
#endif
INTERFACE BOOLEAN msAPI_CM_RemoveMux(WORD wNID, WORD *pwTS_ID,  BYTE cCountOfTS, BOOLEAN *bRemove);
INTERFACE BOOLEAN msAPI_CM_GetServiceIndex(WORD wOriginalNetwork_ID, WORD wTS_ID, WORD wService_ID, U32* pU32Index);
#if ENABLE_DVB_T2
INTERFACE BOOLEAN msAPI_CM_DVBT2_RemoveMux(BYTE cRFChannelNumber, BYTE *pu8PlpIDList,  BYTE cCountOfPlpID);
#endif
#undef INTERFACE
#endif//#if ENABLE_DTV
extern BOOLEAN msAPI_CM_ResetDTVDataManager(void);
extern BOOLEAN msAPI_CM_InitDTVDataManager(void);
extern MEMBER_COUNTRY msAPI_CM_GetCountry(void);
extern BOOLEAN msAPI_CM_SetCountry(MEMBER_COUNTRY eCountry);


#endif // __API_DTVSYSTEM_H__

