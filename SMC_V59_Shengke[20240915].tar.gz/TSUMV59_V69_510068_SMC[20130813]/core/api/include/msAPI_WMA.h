////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////
#ifndef _MSAPI_WMA_H
#define _MSAPI_WMA_H

// Include files
#include "datatype.h"

#include "msAPI_audio.h"
#include "drvMAD.h"

#ifdef MSAPI_WMA_C
#define INTERFACE
#else
#define INTERFACE extern
#endif

#define ENABLE_ASF_PARSING 1    //0: DSP parse everything

/// WMA deocde result
typedef enum
{
    WMA_RESULT_PASS = 0,       ///< Pass
    WMA_RESULT_TIMEOUT,        ///< DSP timeout
    WMA_RESULT_ABORT,          ///< User abort: Remote controller or card plugged out
    WMA_RESULT_DECODE_FAIL,    ///< Decode failed
    WMA_RESULT_FILE_ERROR,     ///< WMA file error
} WMA_RESULT;

/// WMA decode status
typedef enum
{
    WMA_DECODE_RUNNING = 0x00, ///< Keep decoding
    WMA_DECODE_ERROR1,         ///< Error # 1
    WMA_DECODE_ERROR2,         ///< Error # 2
    WMA_DECODE_ERROR3,         ///< Error # 3
    WMA_DECODE_ERROR4,         ///< Error # 4
    WMA_DECODE_ERROR5,         ///< Error # 5
    WMA_DECODE_ERROR6,         ///< Error # 6
    WMA_DECODE_DONE    = 0xFF  ///< Done
} WMA_DECODE_STATUS;

INTERFACE void msAPI_WMA_Init(En_DVB_decSystemType enDecSystem);
INTERFACE void msAPI_WMA_StartDecode(void);
INTERFACE void msAPI_WMA_StopDecode(void);
INTERFACE void msAPI_WMA_PauseDecode(void);
INTERFACE U8 msAPI_WMA_CheckPlayDone(void);
INTERFACE U8 msAPI_WMA_CheckInputRequest(U32 *pU32WrtAddr, U32 *pU32WrtBytes);
INTERFACE void msAPI_WMA_SetInput(void);
INTERFACE void msAPI_WMA_FileEndNotification(void);
INTERFACE void msAPI_WMA_FileEndDataHandle(U32 u32DataLeft);
INTERFACE U32 msAPI_WMA_GetPlayTick(void);
INTERFACE U16 msAPI_WMA_GetEsMEMCnt(void);
INTERFACE void msAPI_WMA_SetASFParm(WMA_ASF_PARMTYPE parm_type, U32 value);
INTERFACE U16 msAPI_WMA_GetResidualBufferSize(void);
INTERFACE U16 msAPI_WMA_GetPCMBufferSize(U32 u32BitRate,U32 u32SampleRate);
INTERFACE U16 msAPI_WMA_GetSampleRate(void);
INTERFACE U32 msAPI_WMA_GetBitRate(void);
INTERFACE void msAPI_WMA_CleanFileEndData(U32 StrAddr, U32 length, U32 ClearValue);

#undef INTERFACE
#endif
