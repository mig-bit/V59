////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// ("MStar Confidential Information") by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MAPP_ANALOGINPUTS_H
#define _MAPP_ANALOGINPUTS_H

#include "datatype.h"

typedef enum
{
    STATE_ANALOGINPUTS_INIT,
    STATE_ANALOGINPUTS_WAIT,
    STATE_ANALOGINPUTS_TV_SOURCE,
    STATE_ANALOGINPUTS_CARDRD,
 } EN_ANALOGINPUTS_STATE;

#ifdef _MAPP_ANALOGINPUTS_C
#define INTERFACE
#else
#define INTERFACE extern
#endif

INTERFACE void MApp_AnalogInputs_Init(SCALER_WIN eWindow);
INTERFACE EN_RET MApp_AnalogInputs(void);
INTERFACE void MApp_AnalogInputs_Force2MonitorWindows(SCALER_WIN eWindow);
INTERFACE BOOLEAN MApp_AnalogInputs_FunctionNotAvailableCheck(void);
INTERFACE BOOLEAN MApp_Analog_NoSignal_ExcludeATV(void);
INTERFACE void MApp_AnalogInputs_ResetTimer(SCALER_WIN eWindow);
INTERFACE void MApp_AnalogInputs_ExitAndGotoMenuState(void);
INTERFACE void MApp_AnalogInputs_NumWinProcDigitKey(U8 bKeyValue);
INTERFACE void MApp_AnalogInputs_DeleteWin(void);
#if (ATSC_CC == ATV_CC)
INTERFACE void MApp_Set_CCState(BOOLEAN bEnable);
INTERFACE BOOLEAN MApp_Get_CCState(void);
#endif

#undef INTERFACE

#endif
