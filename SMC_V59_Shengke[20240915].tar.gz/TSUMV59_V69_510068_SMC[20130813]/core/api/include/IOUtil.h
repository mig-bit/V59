#ifndef IOUTIL_H
#define    IOUTIL_H


#ifdef IOUTIL_C
#define INTERFACE
#else
#define    INTERFACE extern
#endif

//string ========================================================================================//
INTERFACE void ByteSwapCopy(U8 *pu8DesBuffer, U8 *pu8SrcBuffer, U16 TotalByte);
INTERFACE void ByteCopy(U8 *pu8DesBuffer, U8 *pu8SrcBuffer, U16 TotalByte);
INTERFACE S8 ByteComp(U8 *pu8DesBuffer, U8 *pu8SrcBuffer, U16 TotalByte);

INTERFACE char *msStrcat(char *pDst, const char *pSrc);
INTERFACE char *msStrncpy(char *pDst, const char *pSrc, U16 u16Len);

//path ==========================================================================================//
INTERFACE void SplitPath(S8 *ps8Path, S8 *ps8Dir, S8 *ps8FileName);
INTERFACE U8 IsFullPath(S8 *ps8Path);

//unicode utility ===============================================================================//
INTERFACE U8 UnicodeCmp(S8 *ps8LongName1, S8 *ps8LongName2);
INTERFACE void UnicodeCat(S8 *ps8DesName, S8 *ps8SrcName);
INTERFACE U8 UnicodeLen(S8 *ps8PathName);
INTERFACE S8 *UnicodeChr(S8 *ps8PathName, S8 s8Chr);
INTERFACE void UnicodeCpy(S8 *ps8DesName, S8 *ps8SrcName);
INTERFACE void UnicodeSplitPath(S8 *ps8PathName, S8 *ps8DirName, S8 *ps8FileName);
INTERFACE U8 UnicodeIsFullPath(S8 *ps8PathName);
INTERFACE void UnicodetoASCII(S8 *ps8FileName);
INTERFACE void ASCIItoUnicode(S8 *ps8FileName);
INTERFACE void ASCIItoUnicode2(S8 *ps8FileName,U8 len);

INTERFACE void strupr2(U8 *pu8Str,U8 len);
#undef INTERFACE
#endif

