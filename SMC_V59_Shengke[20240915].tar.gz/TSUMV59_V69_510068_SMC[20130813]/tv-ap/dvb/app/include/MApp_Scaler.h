////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef MAPP_SCALER_H
#define MAPP_SCALER_H

#include "MApp_Exit.h"
#include "MApp_Key.h"
#include "msAPI_Global.h"
#include "MApp_GlobalSettingSt_Common.h"
#include "MApp_GlobalSettingSt.h"

#ifdef MAPP_SCALER_C
#define INTERFACE
#else
#define INTERFACE extern
#endif

////////////////////////////////////////////////////////////////////////////////


//*************************************************************************
//          Defines
//*************************************************************************

//*************************************************************************
//          Enums
//*************************************************************************
typedef struct
{
    U16 u16VideoWidth;
    U16 u16VideoHeight;
    U8 u8AspectRate;
    U8 u8AFD;
    ///display width
    U32 u32SarWidth;
    ///display height
    U32 u32SarHeight;
} SRC_RATIO_INFO;


typedef struct
{
    MS_WINDOW_TYPE stCapWin;        ///<Capture window

    U8 u8HCrop_Left;    // H Crop Left
    U8 u8HCrop_Right;    // H crop Right
    U8 u8VCrop_Up;      // V Crop Up
    U8 u8VCrop_Down;      // V Crop Down

    U8 u8H_OverScanRatio; //H Crop for DTV,storage
    U8 u8V_OverScanRatio; //V Crop for DTV,storage

} MS_VIDEO_Window_Info_EXT;


//*************************************************************************
//          Global variables
//*************************************************************************

//*************************************************************************
//          Function prototypes
//*************************************************************************

typedef enum
{
    PICTURE_VALUE_CONTRAST,
    PICTURE_VALUE_BRIGHTNESS,
    PICTURE_VALUE_SHARPNESS,
    PICTURE_VALUE_HUE,
    PICTURE_VALUE_SATURATION,
} EN_PICTURE_VALUE;
#if ENABLE_3D_PROCESS
typedef enum
{
    E_3D_FULLSCREEN  = 0,
    E_3D_AUTOADAPT   = 1,
    E_3D_CENTER      = 2,
}EN_SC_3D_SIZE ;

typedef enum
{
    E_USER_3D_MODE_OFF   = 0x00,
//To line alternative
    E_USER_3D_MODE_FRAME_PACKING_2_LINE_ALTERNATIVE    = 0x01,
    E_USER_3D_MODE_SIDE_BY_SIDE_HALF_2_LINE_ALTERNATIVE    = 0x02,
    E_USER_3D_MODE_SIDE_BY_SIDE_HALF_INTERLACE_2_LINE_ALTERNATIVE    = 0x03,
    E_USER_3D_MODE_VERTICAL_LINE_ALTERNATIVE_2_VERTICAL_LINE_ALTERNATIVE    = 0x04,
    E_USER_3D_MODE_LINE_ALTERNATIVE_2_LINE_ALTERNATIVE    = 0x05,
    E_USER_3D_MODE_TOP_BOTTOM_2_LINE_ALTERNATIVE    = 0x6,
    E_USER_3D_MODE_FRAME_ALTERNATIVE_2_LINE_ALTERNATIVE    = 0x07,

    E_USER_3D_MODE_FRAME_PACKING_2_TOP_BOTTOM    = 0x10,
    E_USER_3D_MODE_TOP_BOTTOM_2_TOP_BOTTOM    = 0x11,
    E_USER_3D_MODE_FRAME_ALTERNATIVE_2_TOP_BOTTOM    = 0x12,

    E_USER_3D_MODE_FRAME_PACKING_2_SIDE_BY_SIDE_HALF    = 0x20,
    E_USER_3D_MODE_SIDE_BY_SIDE_HALF_2_SIDE_BY_SIDE_HALF    = 0x21,
    E_USER_3D_MODE_LINE_ALTERNATIVE_2_SIDE_BY_SIDE_HALF    = 0x22,
    E_USER_3D_MODE_TOP_BOTTOM_2_SIDE_BY_SIDE_HALF    = 0x23,

    E_USER_3D_MODE_FRAME_PACKING_2_FRAME_L    = 0x30,
    E_USER_3D_MODE_SIDE_BY_SIDE_HALF_2_FRAME_L    = 0x31,
    E_USER_3D_MODE_TOP_BOTTOM_2_FRAME_L    = 0x32,
    E_USER_3D_MODE_LINE_ALTERNATIVE_2_FRAME_L    = 0x33,
    E_USER_3D_MODE_FRAME_ALTERNATIVE_2_FRAME_L    = 0x34,

    E_USER_3D_MODE_FRAME_PACKING_2_FRAME_ALTERNATIVE_NOFRC    = 0x40,
    E_USER_3D_MODE_SIDE_BY_SIDE_HALF_2_FRAME_ALTERNATIVE_NOFRC    = 0x41,
    E_USER_3D_MODE_SIDE_BY_SIDE_HALF_INTERLACE_2_FRAME_ALTERNATIVE_NOFRC    = 0x42,
    E_USER_3D_MODE_LINE_ALTERNATIVE_2_FRAME_ALTERNATIVE_NOFRC    = 0x43,
    E_USER_3D_MODE_TOP_BOTTOM_2_FRAME_ALTERNATIVE_NOFRC    = 0x44,

    E_USER_3D_MODE_FRAME_PACKING_2_FRAME_ALTERNATIVE    = 0x50,
    E_USER_3D_MODE_SIDE_BY_SIDE_HALF_2_FRAME_ALTERNATIVE    = 0x51,
    E_USER_3D_MODE_LINE_ALTERNATIVE_2_FRAME_ALTERNATIVE    = 0x52,
    E_USER_3D_MODE_TOP_BOTTOM_2_FRAME_ALTERNATIVE    = 0x53,

    E_USER_3D_MODE_NORMAL_2D_2_LINE_ALTERNATIVE    = 0x60,// 2d-->3d, use HShift for shift
    E_USER_3D_MODE_NORMAL_2D_2_FRAME_ALTERNATIVE_NOFRC    = 0x61,// 2d-->3d, use HShift for shift

    E_USER_3D_MODE_80 = 0x80,
}EN_USER_3D_MODE ;

#endif
// MHEG must use crop align, other source dosen't need
#define DTV_CROP_ALIGN_X            2   // 8 byte alignment
#define DTV_CROP_ALIGN_Y            2
#define MEDIA_CROP_ALIGN_X          DTV_CROP_ALIGN_X
#define MEDIA_CROP_ALIGN_Y          DTV_CROP_ALIGN_Y
#define DIGITAL_CROP_ALIGN_X        1
#define DIGITAL_CROP_ALIGN_Y        2
#define ANALOG_CROP_ALIGN_X         1
#define ANALOG_CROP_ALIGN_Y         2
#define OVERSCAN_RATIO              1000

#if ENABLE_BACKLIGHT_PWM_SYNC_WITH_FRAMERATE
INTERFACE void SetPWMto2PanelVFreq(U8 ratio);
#endif
INTERFACE void MApp_PreInitPanelTiming(void);

INTERFACE U8 MApp_Scaler_FactoryAdjBrightness(U8 u8Brightness, U8 u8SubBrightness);
INTERFACE U8 MApp_Scaler_FactoryContrast(U8 u8Contrast, U8 u8SubContrast);
INTERFACE void MApp_Scaler_ResetZoomFactor(EN_MENU_AspectRatio enAspectratio);
INTERFACE BOOLEAN MApp_Scaler_IncLeftZoomfactor(S16 s16ZoomFator);
INTERFACE BOOLEAN MApp_Scaler_IncRightZoomfactor(S16 s16ZoomFator);
INTERFACE BOOLEAN MApp_Scaler_IncUpZoomfactor(S16 s16ZoomFator);
INTERFACE BOOLEAN MApp_Scaler_IncDownZoomfactor(S16 s16ZoomFator);
INTERFACE void MApp_Scaler_EnableOverScan(BOOLEAN bEnable);
INTERFACE void MApp_Scaler_Adjust_OverscanRatio(
                        INPUT_SOURCE_TYPE_t enInputSourceType,
                        XC_SETWIN_INFO *pstXC_SetWin_Info);
INTERFACE void MApp_Scaler_Adjust_OverscanRatio_RFBL(
                       INPUT_SOURCE_TYPE_t enInputSourceType,
                       XC_SETWIN_INFO *pstXC_SetWin_Info);

INTERFACE void MApp_Scaler_Adjust_AspectRatio(XC_SETWIN_INFO *pstXC_SetWin_Info,
                                                EN_ASPECT_RATIO_TYPE enVideoScreen,
                                                MS_WINDOW_TYPE *pstCropWin,
                                                MS_WINDOW_TYPE *pstDstWin,
                                                SRC_RATIO_INFO *pstSrcRatioInfo);
#if ENABLE_FBL_ASPECT_RATIO_BY_MVOP
INTERFACE void MApp_Scaler_SetFixVtotal(U8 u8Interlace, U16 u16FrameRate, U16 u16VDE);
INTERFACE void MApp_Scaler_SetFBLTimingForAspectRatio(EN_ASPECT_RATIO_TYPE enVideoScreen);
INTERFACE void MApp_Scaler_Adjust_AspectRatio_FBL(EN_ASPECT_RATIO_TYPE enVideoScreen, MS_WINDOW_TYPE *ptSrcWin);
#endif

INTERFACE void MApp_Scaler_SetWindow(MS_WINDOW_TYPE *ptSrcWin,
                                            MS_WINDOW_TYPE *ptCropWin,
                                            MS_WINDOW_TYPE *ptDstWin,
                                            EN_ASPECT_RATIO_TYPE enVideoScreen,
                                            INPUT_SOURCE_TYPE_t enInputSourceType,
                                            SCALER_WIN eWindow);
///
/// Make sure that the display window won't change by other function
///  implicitly
///
INTERFACE void MApp_Scaler_AlignWindow(MS_WINDOW_TYPE *pWindow, U16 u8AlignX, U16 u8AlignY);
INTERFACE void MApp_Scaler_Setting_SetVDScale (EN_MENU_AspectRatio eAspect, SCALER_WIN eWindow);
#if ENABLE_CUS_HDMI_MODE
INTERFACE void MApp_Scaler_Setting_ForceSetVDScale (EN_MENU_AspectRatio eAspect, SCALER_WIN eWindow);
#endif
INTERFACE EN_ASPECT_RATIO_TYPE MApp_Scaler_GetAspectRatio(EN_MENU_AspectRatio eAspect);
INTERFACE void MApp_Scaler_CalculateAspectRatio(XC_SETWIN_INFO *pstXC_SetWin_Info,
                                        EN_ASPECT_RATIO_TYPE enVideoScreen,
                                       MS_WINDOW_TYPE *pstCropWin,
                                       MS_WINDOW_TYPE *pstDstWin);
INTERFACE void MApp_Scaler_Setting_HDMI_PAR(void);

INTERFACE void MApp_Scaler_MainWindowSyncEventHandler(INPUT_SOURCE_TYPE_t src, void* para);
INTERFACE void MApp_Scaler_SubWindowSyncEventHandler(INPUT_SOURCE_TYPE_t src, void* para);
INTERFACE void MApp_Scaler_MainWindowOnOffEventHandler(INPUT_SOURCE_TYPE_t src, void* para);
INTERFACE void MApp_Scaler_SubWindowOnOffEventHandler(INPUT_SOURCE_TYPE_t src, void* para);
INTERFACE void MApp_Scaler_MainWindowPeriodicHandler(INPUT_SOURCE_TYPE_t src, BOOLEAN bRealTimeMonitorOnly);
INTERFACE void MApp_Scaler_SubWindowPeriodicHandler(INPUT_SOURCE_TYPE_t src, BOOLEAN bRealTimeMonitorOnly);
INTERFACE void MApp_Scaler_CVBS1OutSyncEventHandler(INPUT_SOURCE_TYPE_t src, void* para);
INTERFACE void MApp_Scaler_CVBS1OutOnOffEventHandler(INPUT_SOURCE_TYPE_t src, void* para);

INTERFACE void MApp_Scaler_CVBS2OutSyncEventHandler(INPUT_SOURCE_TYPE_t src, void* para);
INTERFACE void MApp_Scaler_CVBS2OutOnOffEventHandler(INPUT_SOURCE_TYPE_t src, void* para);

INTERFACE void MApp_Scaler_GetWinInfo(XC_SETWIN_INFO* pWindowInfo, SCALER_WIN eWindow);
INTERFACE void MApp_Scaler_GetVidWinInfo(MS_VIDEO_Window_Info_EXT *pstWindow_info, SCALER_WIN eWindow);
INTERFACE void MApp_Scaler_SetVidWinInfo(INPUT_SOURCE_TYPE_t src,MS_VIDEO_Window_Info_EXT *pstWindow_info, SCALER_WIN eWindow);
INTERFACE void MApp_Scaler_GetOverScan(INPUT_SOURCE_TYPE_t src, XC_SETWIN_INFO *pstXC_SetWin_Info);

INTERFACE void MApp_Scaler_SetTiming(INPUT_SOURCE_TYPE_t enInputSourceType, SCALER_WIN eWindow);
INTERFACE void MApp_Scaler_SetScalerDNRAddress(U32 mmap_s_adrress,U32 mmap_length);


#ifdef DVBT_MMBOX
INTERFACE void MApp_Scaler_SetDacOutputMode(E_DAC_OUTPUT_TIMING_TYPE eTiming);
#endif


#if(PATCH_FOR_V_RANGE)
INTERFACE void MApp_Scaler_SetCustomerWindow(MS_WINDOW_TYPE *ptSrcWin, MS_WINDOW_TYPE *ptCropWin, MS_WINDOW_TYPE *ptDstWin, SCALER_WIN eWindow);
#endif


#if ENABLE_3D_PROCESS
INTERFACE void MApp_Scaler_Adjust_3D_CropWin(MS_WINDOW_TYPE *pstCropWin);
INTERFACE BOOLEAN MAPP_Scaler_Is3DSubWin(SCALER_WIN eWindow);
INTERFACE E_XC_3D_INPUT_MODE MAPP_Scaler_MapUI3DModeToXC3DMode(EN_3D_TYPE eInputUI3DType);
INTERFACE BOOL MAPP_Scaler_MapUIDetectMode(EN_3D_DETECT_MODE eDetect3DMode);
INTERFACE U16 MAPP_Scaler_Map3DFormatTo3DUserMode(E_XC_3D_INPUT_MODE eInput3DFormat);
INTERFACE void MApp_Scaler_Set3DScene_CUS(void);
INTERFACE BOOLEAN MApp_Scaler_SetVideo3DMode(U16 u16_Video3Dmode);
INTERFACE void MApp_Scaler_EnableManualDetectTiming(BOOLEAN bEnable);
INTERFACE BOOLEAN MApp_Scaler_IsManualDetectTiming(void);
INTERFACE BOOLEAN MApp_Scaler_Set_3DMode(U16 u16_Video3Dmode);
INTERFACE void MApp_Scaler_Close3DFunction(void );
#endif


#if ENABLE_BACKLIGHT_PWM_SYNC_WITH_FRAMERATE
INTERFACE void SetPWMto2PanelVFreq(U8 ratio);
#endif


#if 0//VGA_HDMI_YUV_POINT_TO_POINT
INTERFACE BOOLEAN MApp_CheckHDMI_PCTiming_FBL(void);
#endif
#if ENABLE_CUS_HDMI_MODE
INTERFACE BOOLEAN MApp_Scaler_CheckHDMIModeAvailable(void);
#endif
#if ENABLE_CUS_UI_SPEC
INTERFACE BOOLEAN MApp_Scaler_CheckDBC_DLCAvailable(void);
#endif

//SMC jayden.chen add for set free run display window size when no singal 20130311
INTERFACE void MDrv_Scaler_SetFreeRunWindow(void);

////////////////////////////////////////////////////////////////////////////////
#undef INTERFACE
#endif

