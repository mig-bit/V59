#if (defined(USB_HEADPHONE) && defined(CHIP_T3))
#ifndef MAPP_USBHEADPHONE_H
#define MAPP_USBHEADPHONE_H

#include "MsCommon.h"

#ifdef MAPP_USBDOWNLOAD_C
#define INTERFACE
#else
#define INTERFACE extern
#endif


INTERFACE void MApp_UsbHeadphone_Enable(MS_BOOL bEnable);


#undef INTERFACE
#endif  //MAPP_USBHEADPHONE_H
#endif //#if (defined(USB_HEADPHONE) && defined(CHIP_T3))