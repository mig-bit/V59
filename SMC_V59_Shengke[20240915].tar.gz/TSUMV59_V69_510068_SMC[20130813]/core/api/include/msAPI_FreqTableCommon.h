////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (MStar Confidential Information!�L) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////
#ifndef __API_FREQTABLECOMMON_H__
#define __API_FREQTABLECOMMON_H__

#include "SW_Config.h"
#define ROM   //should be erased in 32 bit MCU
/// Country
typedef enum
{
    E_COUNTRY_MIN,
    // ------------------------------------
    E_AUSTRALIA = E_COUNTRY_MIN,    ///< Australia
    E_AUSTRIA,                      ///< Austria
    E_BELGIUM,                      ///< Belgium
    E_BULGARIA,                     ///< Bulgaria
    E_CROATIA,                      ///< Croatia
    E_CZECH,                        ///< Czech
    E_DENMARK,                      ///< Denmark
    E_FINLAND,                      ///< Finland
    E_FRANCE,                       ///< France
    E_GERMANY,                      ///< Germany
    E_GREECE,                       ///< Greece
    E_HUNGARY,                      ///< Hungary
    E_ITALY,                        ///< Italy
    E_LUXEMBOURG,                   ///< Luxembourg
    E_NETHERLANDS,                  ///< Netherland
    E_NORWAY,                       ///< Norway
    E_POLAND,                       ///< Poland
    E_PORTUGAL,                     ///< Portugal
    E_RUMANIA,                      ///< Rumania
    E_RUSSIA,                       ///< Russia
    E_SERBIA,                       ///< Serbia
    E_SLOVENIA,                     ///< Slovenia
    E_SPAIN,                        ///< Spain
    E_SWEDEN,                       ///< Sweden
    E_SWITZERLAND,                  ///< Switzerland
    E_UK,                           ///< UK
    E_UNITED_ARAB_EMIRATES,         ///< United Arab Emirates
    E_NEWZEALAND,                   ///< New Zealand
    E_CHINA,                        ///< China
    E_ESTONIA,                      ///< Estonia
    E_TURKEY,                       ///< Turkey
    E_MOROCCO,                      ///< Morocco
    E_TUNIS,                        ///< Tunis
    E_ALGERIA,                      ///< Algeria
    E_EGYPT,                        ///< Egypt
    E_SOUTH_AFRICA,                 ///< South Africa
    E_ISRAEL,                       ///< Israel
    E_IRAN,                         ///< Iran
    E_SLOVAKIA,                     ///< Slovakia
    
#if (ENABLE_DVB_TAIWAN_APP)
    E_TAIWAN,                       ///< Taiwan
#endif
#if ENABLE_SBTVD_BRAZIL_APP
    E_BRAZIL,                       ///< Brazil
#endif
    // ------------------------------------
    E_COUNTRY_NUM,
    E_IRELAND,                     ///< Ireland////TODO, wait UI

} MEMBER_COUNTRY;

#endif // __API_FREQTABLECOMMON_H__

