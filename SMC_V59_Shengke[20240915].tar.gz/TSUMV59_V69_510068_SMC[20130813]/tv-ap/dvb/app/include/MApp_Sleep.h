////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef MAPP_SLEEP_H
#define MAPP_SLEEP_H

#include "Board.h"
#include "datatype.h"

#ifdef MAPP_SLEEP_C
#define INTERFACE
#else
#define INTERFACE extern
#endif

typedef enum
{
    STATE_SLEEP_OFF,
    STATE_SLEEP_10MIN,
    STATE_SLEEP_20MIN,
    STATE_SLEEP_30MIN,
    STATE_SLEEP_40MIN,
    STATE_SLEEP_50MIN,
    STATE_SLEEP_60MIN,
    STATE_SLEEP_90MIN,
    STATE_SLEEP_120MIN,
    //STATE_SLEEP_180MIN,
    //STATE_SLEEP_240MIN,
    STATE_SLEEP_TOTAL,
}EN_SLEEP_TIME_STATE;

typedef enum
{
    STATE_SLEEP_OFFTIMER_OFF,
    STATE_SLEEP_OFFTIMER_ON,
    STATE_SLEEP_OFFTIMER_TRANSIT,
}EN_SLEEP_OFFTIMER_STATUS;

INTERFACE U32 u32SleepTimer;
INTERFACE BOOLEAN benableSleepTimer;

#if 1 //0
typedef enum
{
    TS_TYPE_NONE,
    TS_TYPE_SLEEPTIMER,
    TS_TYPE_OFFTIMER,
	TS_TYPE_AUTOSLEEPTIMER, 
    TS_TYPE_NUM,
}EN_TIMER_SOURCE_TYPE;

INTERFACE EN_TIMER_SOURCE_TYPE enIndicateTimerSource;  // indicate the source of Display Count
//ZUI: refine code: INTERFACE U32 u32OffTimeCheckTimer;
//ZUI: refine code: INTERFACE U32 u32OffTimeLastCounter;
#endif


INTERFACE U32 u32SleepTimeDur;
INTERFACE U32 u32OffTimeDur;
INTERFACE U8  benableOffTimer; //0: off, 1: On, 2:transit

INTERFACE EN_SLEEP_TIME_STATE enSleepTimeState ;
INTERFACE U32 u32AutoOnTime;
INTERFACE BOOLEAN benableAutoOn_OffTimer;
INTERFACE BOOLEAN g_bSleepCountDown;

#define SLEEP_TIMER_TIMEBASE 60000*10 // current timebase is 10 min

#define MINUTE_TO_MS    60000   // 1 minute = 60000 ms
#define FINAL_COUNT 60000
#define DISPLAY_COUNTER 61

#define ONEDAY_TIME    86400//24*60*60
#define MINUTE_TO_S        60
#define PROTECT_OFF_TIMER  5000

#define SLEEPTIMER_COUNTDOWN_TIME_PERIOD 950
#define TIME_AUTO_OFF_AFTER_AUTO_ON      7200000 // 2Hours

INTERFACE void MApp_Sleep_SetTime(void);
INTERFACE void MApp_Sleep_Monitor(void);
INTERFACE void MApp_NoSignalSleep_Monitor( void );
INTERFACE void MApp_Sleep_ReleaseSleepTimer(void);
INTERFACE EN_SLEEP_TIME_STATE MApp_Sleep_GetCurrentSleepState(void);
INTERFACE U32 MApp_Sleep_GetSleepTimeRemainTime(void);
INTERFACE void MApp_Sleep_SetCurrentSleepTime(U8 CurrentSleepTime);
INTERFACE void MApp_Sleep_SetOffTime(BOOLEAN bEnable);
INTERFACE void MApp_Sleep_TransitOffTime(void);
INTERFACE void MApp_Sleep_SetAutoOn_OffTime(BOOLEAN bEnable);
INTERFACE void MApp_NoSignal_SetAutoSleep(BOOLEAN benable);
INTERFACE EN_SLEEP_TIME_STATE MApp_GetCurSleepTime(BOOLEAN bDecInc);

INTERFACE void MApp_Sleep_SendKeyOffTimeDayOfWeek(void);
INTERFACE BOOLEAN MApp_OffTime_IsOffTimeInDayOfWeek(void);
INTERFACE U32 MApp_Sleep_DisplayCountDownTimer(void);
INTERFACE void MApp_Time_SetOnTime(void);
INTERFACE void MApp_InitRtcWakeUpTimer(void);
INTERFACE void MApp_Time_Tasks_Set_RTC_NextWakeUpTime(void);



#if (NO_SIGNAL_AUTO_SHUTDOWN==1)

    INTERFACE U32 u32NoSignal_MonitorStartTime;
    INTERFACE BOOLEAN benableNoSiganlSleepCheck;
    INTERFACE U32 u32No_Signal_SleepTimeDur;

    #if ENABLE_CUS_UI_SPEC
    #define NO_SIGNAL_SLEEP_TIMER       0xFFFFFFFF//60000*14 // current no siganl time is 10 min
    #else
    #define NO_SIGNAL_SLEEP_TIMER       60000*10 // current no siganl time is 10 min
    #endif

  #if ENABLE_POWER_SAVING_DPMS
    #define UNKNOW  -1
    INTERFACE S8 u8VGANoSignalSleepCheck;
    #if ENABLE_CUS_UI_SPEC
    #define NO_SIGNAL_VGA_SLEEP_TIMER   0xFFFFFFFF//60000 // VGA power saving secs unit:ms
    #else
    #define NO_SIGNAL_VGA_SLEEP_TIMER   60000*1 // VGA power saving secs unit:ms
    #endif
  #endif
#endif




INTERFACE void MApp_SleepSetWinShow(void);

////////////////////////////////////////////////////////////////////////////////
#undef INTERFACE

////////////////////////////////////////////////////////////////////////////////
#endif

