////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2008 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (MStar Confidential Information!�L) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef MSAPI_OSD_A_H
#define MSAPI_OSD_A_H

#include "datatype.h"
//#include "Board.h"
//#include "msAPI_Font.h"
//#include "drvge_if.h"
//#include "msAPI_cc_sysinfo.h"
#include "msAPI_OSD.h"  //20100512EL

#ifdef MSAPI_OSD_A_C
#define INTERFACE
#else
#define INTERFACE extern
#endif

INTERFACE void msAPI_GE_BitBlt(GEBitBltInfo *BitbltInfo, GEPitBaseInfo *PitBaseInfo);
INTERFACE BOOLEAN MApp_PhotoOSD_DecodeToBuf(MSAPI_JPEGPNGHANDLE* pJpegPngHandle);
INTERFACE void msAPI_OSD_DrawJpegPng(U8 u8Index, U16 u16PosX, U16 u16PosY, U16 u16Width, U16 u16Height, U8 u8Fbid, BOOLEAN bSrcAlphaReplaceDstAlpha, U8 u8JpegAlpha);
INTERFACE void MApp_DisplayPngOSD(U16 u16PosX, U16 u16PosY, U16 u16Width, U16 u16Height, U8 u8Fbid);

#undef INTERFACE

// end Optional special drawing function

#endif /* MSAPI_OSD_H */

