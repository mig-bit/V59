////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#define MAPP_ZUI_ACTAUDLANG_C
#define _ZUI_INTERNAL_INSIDE_ //NOTE: for ZUI internal


//-------------------------------------------------------------------------------------------------
// Include Files
//-------------------------------------------------------------------------------------------------
#include "Board.h"
#include "datatype.h"
#include "MsCommon.h"
#include "apiXC.h"
#include "apiXC_Adc.h"
#include "MApp_GlobalSettingSt.h"
#include "MApp_ZUI_Main.h"
#include "MApp_ZUI_APIcommon.h"
#include "MApp_ZUI_APIstrings.h"
#include "MApp_ZUI_APIwindow.h"
#include "ZUI_tables_h.inl"
#include "MApp_ZUI_APIgdi.h"
#include "MApp_ZUI_APIcontrols.h"
#include "MApp_ZUI_ACTmainpage.h"
#include "MApp_ZUI_ACTeffect.h"
#include "MApp_ZUI_ACTglobal.h"
#include "OSDcp_String_EnumIndex.h"
#include "OSDcp_Bitmap_EnumIndex.h"
#include "ZUI_exefunc.h"
#include "MApp_GlobalFunction.h"
#include "MApp_OSDPage_Main.h"
#include "MApp_GlobalSettingSt.h"
#include "MApp_SaveData.h"
#include "MApp_UiMenuDef.h"
#include "msAPI_Memory.h"
#include "MApp_SignalMonitor.h"

#if (ENABLE_DTV)
#include "mapp_demux.h"
#endif

#include "MApp_Audio.h"
//#include "drvMAD.h"

#if ENABLE_CI
//#include "MApp_CIMMI.h"
#include "msAPI_CI.h"

#include "mapp_si.h"
#include "MApp_Audio.h"

//extern unsigned char msAPI_CI_Polling(void);
#endif

#if ENABLE_PVR
#include "MApp_PVR.h"              //For pvr
#endif

/////////////////////////////////////////////////////////////////////
static EN_OSDPAGE_STATE _enTargetState;

/////////////////////////////////////////////////////////////////////

#define HKEY_AUDIO_LANG_PAGE_MAX_ITEM           10

/*
typedef struct _AUDIO_LANG_DATA_STRUCT
{
    U8 audioLangTotal;
    U8 curSelItemPage;
} AUDIO_LANG_DATA_STRUCT;

static AUDIO_LANG_DATA_STRUCT * pAudLangData = NULL;
*/
#if ENABLE_DTV
static U8 audioLangTotal;
static U8 curSelItemPage;

//note: current focus is "g_u8AudLangSelected"

////////////////////////////////////////////////////////////////////


static  HWND _ZUI_TBLSEG _AudioLanguageHwndList[HKEY_AUDIO_LANG_PAGE_MAX_ITEM]=
{
    HWND_AUDLANG_LIST_ITEM0,
    HWND_AUDLANG_LIST_ITEM1,
    HWND_AUDLANG_LIST_ITEM2,
    HWND_AUDLANG_LIST_ITEM3,
    HWND_AUDLANG_LIST_ITEM4,
    HWND_AUDLANG_LIST_ITEM5,
    HWND_AUDLANG_LIST_ITEM6,
    HWND_AUDLANG_LIST_ITEM7,
    HWND_AUDLANG_LIST_ITEM8,
    HWND_AUDLANG_LIST_ITEM9,
};

static U8 _MApp_ZUI_ACT_AudioLanguageWindowMapToIndex(HWND hwnd)
{
    U8 i;
    for (i = 0; i < HKEY_AUDIO_LANG_PAGE_MAX_ITEM; i++)
    {
        if (hwnd == _AudioLanguageHwndList[i] ||
            MApp_ZUI_API_IsSuccessor(_AudioLanguageHwndList[i], hwnd))
        {
            return i;
        }
    }
    return 0;
}

static HWND _MApp_ZUI_ACT_AudioLanguageIndexMapToWindow(U8 u8Index)
{
    if (u8Index >= HKEY_AUDIO_LANG_PAGE_MAX_ITEM)
        return HWND_INVALID;
    return _AudioLanguageHwndList[u8Index];

}

/////////////////////////////////////////////////////////////////////

static void _MApp_AudioLanguage_Init(void)
{
    //from case MIA_MTS_MODE:
    curSelItemPage = g_u8AudLangSelected/HKEY_AUDIO_LANG_PAGE_MAX_ITEM;

#if ENABLE_PVR
    if (MApp_PVR_IsPlaybacking())
    {
        audioLangTotal = MApp_PVR_PlaybackAudioGetLanguageTotal();
    }
    else
#endif
        audioLangTotal = msAPI_CM_GetAudioStreamCount(msAPI_CM_GetCurrentServiceType(), msAPI_CM_GetCurrentPosition(msAPI_CM_GetCurrentServiceType()));

#if ENABLE_CI
    if(audioLangTotal && !(msAPI_CM_GetProgramAttribute(msAPI_CM_GetCurrentServiceType(), msAPI_CM_GetCurrentPosition(msAPI_CM_GetCurrentServiceType()), E_ATTRIBUTE_IS_SCRAMBLED)&& !msAPI_CI_CardDetect()))
#else
    if(audioLangTotal && !(msAPI_CM_GetProgramAttribute(msAPI_CM_GetCurrentServiceType(), msAPI_CM_GetCurrentPosition(msAPI_CM_GetCurrentServiceType()), E_ATTRIBUTE_IS_SCRAMBLED)))
#endif
    {
        //draw items
    }
    else
    {
        audioLangTotal = 0; //draw nothing..
    }

    if (audioLangTotal)
    {
        MApp_ZUI_API_SetFocus(
            _MApp_ZUI_ACT_AudioLanguageIndexMapToWindow(
                g_u8AudLangSelected%HKEY_AUDIO_LANG_PAGE_MAX_ITEM));
    }
    else
    {
        MApp_ZUI_API_SetFocus(HWND_INVALID);
    }


}

extern U16 _MApp_ZUI_ACT_GetLanguageStringID(EN_LANGUAGE lang, BOOLEAN bDefaultEnglish);

static LPTSTR _MApp_ZUI_ACT_GetAudioLangItemText(U8 u8index)
{
    //from void MApp_UiMenu_DrawAudioLanguageItem(U8 u8index, U8 u8TotalIndex, U8 u8FocusedIndex)
    AUD_INFO stAudInfo;

    if (u8index >= audioLangTotal)
        return 0; //empty string

#if ENABLE_PVR
    if (MApp_PVR_IsPlaybacking())
    {
        if (!MApp_PVR_PlaybackAudioGetStreamInfo(&stAudInfo, u8index))
            return 0;
    }
    else
#endif
    {
        if( TRUE != msAPI_CM_GetAudioStreamInfo(msAPI_CM_GetCurrentServiceType(), msAPI_CM_GetCurrentPosition(msAPI_CM_GetCurrentServiceType()), &stAudInfo, u8index) )
            return 0; //empty string : u8IsNullItem =  TRUE;
    }

    if(TRUE == MApp_Scramble_GetCurStatus())
        return 0; //empty string

    //from case HOTKEYLAGTEXT:
    if ( IsDTVInUse() )
    {
        U16 u16TempID=_MApp_ZUI_ACT_GetLanguageStringID(//u8AudLangCodeIdx);
        MApp_GetLanguageBySILanguage((EN_SI_LANGUAGE)stAudInfo.aISOLangInfo[0].bISOLangIndex), FALSE);

        if (u16TempID == 0)
        {
            U8 au8Code[MAX_ISO639CODE_LENGTH];
            LPTSTR str = CHAR_BUFFER;

            /*if(MApp_Dmx_GetISOLangCodeFromIndex(    //u8AudLangCodeIdx,
                stAudInfo.aISOLangInfo[0].bISOLangIndex, au8Code) == TRUE)
*/
            if(msAPI_SI_GetISOLangCodeFromIndex(   //u8AudLangCodeIdx,
            (EN_SI_LANGUAGE)stAudInfo.aISOLangInfo[0].bISOLangIndex, au8Code) == TRUE)
            {
                str[0] = (U16)au8Code[0];
                str[1] = (U16)au8Code[1];
                str[2] = (U16)au8Code[2];
            }
            else
            {
                {
                    str[0] = 'U';
                    str[1] = 'N';
                    str[2] = 'D';
                }
            }
            str[3] = 0;

            return CHAR_BUFFER;
        }
        else
        {
            return MApp_ZUI_API_GetString(u16TempID);
        }
    }
    return 0; //empty string
}

static U16 _MApp_ZUI_ACT_GetAudioLangItemTypeBitmapID(U8 u8index, DRAWSTYLE_TYPE ds_type)
{
    //from void MApp_UiMenu_DrawAudioLanguageItem(U8 u8index, U8 u8TotalIndex, U8 u8FocusedIndex)
    AUD_INFO stAudInfo;

    if (u8index >= audioLangTotal)
        return 0xFFFF; //empty bitmap

    //u8TotalIndex = u8TotalIndex;    //reserve parameters for other UI need to draw different Top & Bottom items

#if ENABLE_PVR
    if (MApp_PVR_IsPlaybacking())
    {
        if (!MApp_PVR_PlaybackAudioGetStreamInfo(&stAudInfo, u8index))
            return 0xFFFF;
    }
    else
#endif
    {
        if( TRUE != msAPI_CM_GetAudioStreamInfo(msAPI_CM_GetCurrentServiceType(), msAPI_CM_GetCurrentPosition(msAPI_CM_GetCurrentServiceType()), &stAudInfo, u8index) )
            return 0xFFFF; //empty bitmap: u8IsNullItem =  TRUE;
    }

    if(TRUE == MApp_Scramble_GetCurStatus())
        return 0xFFFF; //empty bitmap

    //draw icon mpeg/dolby
    switch(stAudInfo.wAudType)
    {
        case E_AUDIOSTREAM_MPEG:
            //MApp_UiMenu_DrawBitmap_2(EN_BMP_AUDIO_LANG_MPEG, ComponentType);
            return  (ds_type == DS_FOCUS)? E_BMP_ICON_MPEG_F: E_BMP_ICON_MPEG_N;
        case E_AUDIOSTREAM_AC3:
            //MApp_UiMenu_DrawBitmap_2(EN_BMP_AUDIO_LANG_DOLBY, ComponentType);
            return  (ds_type == DS_FOCUS)? E_BMP_ICON_DOLBY_F: E_BMP_ICON_DOLBY_N;
        case E_AUDIOSTREAM_MPEG4:
        case E_AUDIOSTREAM_AAC:
            return  (ds_type == DS_FOCUS)? E_BMP_ICON_AUDIO_AAC_F: E_BMP_ICON_AUDIO_AAC_N;
        case E_AUDIOSTREAM_AC3P:
            return  (ds_type == DS_FOCUS)? E_BMP_ICON_AUDIO_AC3P_F: E_BMP_ICON_AUDIO_AC3P_N;
    }
    return 0xFFFF; //empty bitmap

}


static U16 _MApp_ZUI_ACT_GetAudioLangItemType2BitmapID(U8 u8index, DRAWSTYLE_TYPE ds_type)
{
    AUD_INFO stAudInfo;

    if (u8index >= audioLangTotal)
        return 0xFFFF; //empty bitmap

#if ENABLE_PVR
    if (MApp_PVR_IsPlaybacking())
    {
        if (!MApp_PVR_PlaybackAudioGetStreamInfo(&stAudInfo, u8index))
            return 0xFFFF;
    }
    else
#endif
    {
        if( TRUE != msAPI_CM_GetAudioStreamInfo(msAPI_CM_GetCurrentServiceType(), msAPI_CM_GetCurrentPosition(msAPI_CM_GetCurrentServiceType()), &stAudInfo, u8index) )
            return 0xFFFF; //empty bitmap: u8IsNullItem =  TRUE;
    }

    if(TRUE == MApp_Scramble_GetCurStatus())
        return 0xFFFF; //empty bitmap

    //draw icon stream info
    if(stAudInfo.aISOLangInfo[0].bBroadcastMixedAD)
    {
    	return  (ds_type == DS_FOCUS)? E_BMP_ICON_AUDIO_VI_F: E_BMP_ICON_AUDIO_VI_N;
    }
    switch(stAudInfo.aISOLangInfo[0].bAudType)
    {
        case 1: // clean effect
            return  (ds_type == DS_FOCUS)? E_BMP_ICON_AUDIO_CE_F: E_BMP_ICON_AUDIO_CE_N;
        case 2: // hearing impaired
            return  (ds_type == DS_FOCUS)? E_BMP_ICON_AUDIO_HI_F: E_BMP_ICON_AUDIO_HI_N;
        case 3: // visual impaired
            return  (ds_type == DS_FOCUS)? E_BMP_ICON_AUDIO_VI_F: E_BMP_ICON_AUDIO_VI_N;
        case 0: // undefined
        default:
        break;
    }
    return 0xFFFF; //empty bitmap

}

#endif
/////////////////////////////////////////////////////////////////////
extern BOOLEAN _MApp_ZUI_API_AllocateVarData(void);
//extern void _MApp_ZUI_API_DrawDynamicComponent(DRAWCOMPONENT component, const void * param, const GRAPHIC_DC * pdc, const RECT * rect);



void MApp_ZUI_ACT_AppShowAudioLanguage(void)
{
    HWND wnd;
    RECT rect;
    E_OSD_ID osd_id = E_OSD_AUDIO_LANGUAGE;

    g_GUI_WindowList = GetWindowListOfOsdTable(osd_id);
    g_GUI_WinDrawStyleList = GetWindowStyleOfOsdTable(osd_id);
    g_GUI_WindowPositionList = GetWindowPositionOfOsdTable(osd_id);
#if ZUI_ENABLE_ALPHATABLE
    g_GUI_WinAlphaDataList = GetWindowAlphaDataOfOsdTable(osd_id);
#endif
    HWND_MAX = GetWndMaxOfOsdTable(osd_id);
    OSDPAGE_BLENDING_ENABLE = IsBlendingEnabledOfOsdTable(osd_id);
    OSDPAGE_BLENDING_VALUE = GetBlendingValueOfOsdTable(osd_id);

    if (!_MApp_ZUI_API_AllocateVarData())
    {
        ZUI_DBG_FAIL(printf("[ZUI]ALLOC\n"));
        ABORT();
        return;
    }

    //RECT_SET(rect, ((g_IPanel.HStart()+3)&0xFFFC), 1, g_IPanel.Width(), g_IPanel.Height());
    RECT_SET(rect,
        ZUI_AUDIO_LANGUAGE_XSTART, ZUI_AUDIO_LANGUAGE_YSTART,
        ZUI_AUDIO_LANGUAGE_WIDTH, ZUI_AUDIO_LANGUAGE_HEIGHT);

    if (!MApp_ZUI_API_InitGDI(&rect))
    {
        ZUI_DBG_FAIL(printf("[ZUI]GDIINIT\n"));
        ABORT();
        return;
    }

    //////////////////////////////
    /*/ init internal data structre, before ZUI create message...
    _ZUI_FREE(pAudLangData);
    pAudLangData = (AUDIO_LANG_DATA_STRUCT*)_ZUI_MALLOC(
        sizeof(AUDIO_LANG_DATA_STRUCT));
    if (pAudLangData == 0)
    {
        ZUI_DBG_FAIL(printf("[ZUI]AAUDL\n"));
        ABORT();
        return;
    }
    *//////////////////////////////

    for (wnd = 0; wnd < HWND_MAX; wnd++)
    {
        //printf("create msg: %lu\n", (U32)wnd);
        MApp_ZUI_API_SendMessage(wnd, MSG_CREATE, 0);
    }

    MApp_ZUI_API_ShowWindow(HWND_MAINFRAME, SW_SHOW);
#if (ENABLE_DTV)
    _MApp_AudioLanguage_Init();
#endif
    MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_OPEN, E_ZUI_STATE_RUNNING);

}


//////////////////////////////////////////////////////////
// Key Handler


BOOLEAN MApp_ZUI_ACT_ExecuteAudioLanguageAction(U16 act)
{

    /*
    if (pAudLangData == 0)
    {
        ZUI_DBG_FAIL(printf("[ZUI]EAUDL\n"));
        ABORT();
        return TRUE;
    }*/
#if (!ENABLE_DTV)
    UNUSED(act);
#else
    switch(act)
    {

        case EN_EXE_CLOSE_CURRENT_OSD:
            MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
            _enTargetState = STATE_OSDPAGE_CLEAN_UP;
            return TRUE;

        case EN_EXE_POWEROFF:
            MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
            _enTargetState = STATE_OSDPAGE_GOTO_STANDBY;
            return TRUE;


        case EN_EXE_AUDIO_LANG_LEFT:                   ///< audio language left
        case EN_EXE_AUDIO_LANG_RIGHT:                    ///< audio language right
            //from case MIA_HKEY_AUDIO_LANG_LEFT:
            //from case MIA_HKEY_AUDIO_LANG_RIGHT:
            /*
            if(act == EN_EXE_AUDIO_LANG_LEFT)
            {
                if(g_u8LRAudioMode == 0)
                {
                    g_u8LRAudioMode = 2;
                }
                else
                {
                    g_u8LRAudioMode--;
                }
            }
            else
            {
                if(g_u8LRAudioMode == 2)
                {
                    g_u8LRAudioMode = 0;
                }
                else
                {
                    g_u8LRAudioMode++;
                }
            }
            if(g_u8LRAudioMode == 0)
            {
                MApi_AUDIO_SetCommAudioInfo(Audio_Comm_infoType_SoundMode, MSAPI_AUD_MODE_STEREO, 0);
            }
            else if(g_u8LRAudioMode == 1)
            {
                MApi_AUDIO_SetCommAudioInfo(Audio_Comm_infoType_SoundMode, MSAPI_AUD_MODE_RR, 0);
            }
            else if(g_u8LRAudioMode == 2)
            {
                MApi_AUDIO_SetCommAudioInfo(Audio_Comm_infoType_SoundMode, MSAPI_AUD_MODE_LL, 0);
            }
            MApp_ZUI_API_InvalidateWindow(MApp_ZUI_API_GetFocus());
            */
            return TRUE;

        case EN_EXE_AUDIO_LANG_UP:                   ///< audio language up
        case EN_EXE_AUDIO_LANG_DOWN:                    ///< audio language down
            //from case MIA_HKEY_AUDIO_LANG_UP:
            //from case MIA_HKEY_AUDIO_LANG_DOWN:
            {
                U8 u8CurrentItemIndex;
                U8 u8PrvItemPage, u8NewItemPage;
                AUD_INFO aAudioStreamInfo;
                BOOLEAN retval;

                if (audioLangTotal <= 1)
                    return TRUE;

                g_u8LRAudioMode = 0;
                u8CurrentItemIndex = g_u8AudLangSelected;

                u8PrvItemPage = u8CurrentItemIndex / HKEY_AUDIO_LANG_PAGE_MAX_ITEM;
#if ENABLE_PVR
                if (MApp_PVR_IsPlaybacking())
                    audioLangTotal = MApp_PVR_PlaybackAudioGetLanguageTotal();
                else
#endif
                    audioLangTotal = msAPI_CM_GetAudioStreamCount(msAPI_CM_GetCurrentServiceType(), msAPI_CM_GetCurrentPosition(msAPI_CM_GetCurrentServiceType()));

                //printf("audioLangTotal=%u \n",audioLangTotal);
#if ENABLE_CI
                if(!audioLangTotal || (msAPI_CM_GetProgramAttribute(msAPI_CM_GetCurrentServiceType(), msAPI_CM_GetCurrentPosition(msAPI_CM_GetCurrentServiceType()), E_ATTRIBUTE_IS_SCRAMBLED)&& !msAPI_CI_CardDetect()))
#else
                if(!audioLangTotal || (msAPI_CM_GetProgramAttribute(msAPI_CM_GetCurrentServiceType(), msAPI_CM_GetCurrentPosition(msAPI_CM_GetCurrentServiceType()), E_ATTRIBUTE_IS_SCRAMBLED)))
#endif
                {   //no items
                    audioLangTotal = 0; //break;
                    MApp_ZUI_API_SetFocus(HWND_INVALID);
                    return TRUE;
                }

                if (act==EN_EXE_AUDIO_LANG_UP) //menuAction == MIA_HKEY_AUDIO_LANG_UP)
                {
#if ENABLE_PVR
                    if (MApp_PVR_IsPlaybacking())
                        u8CurrentItemIndex = (g_u8AudLangSelected+(audioLangTotal-1))%audioLangTotal;//(g_u8AudLangSelected==0)?audioLangTotal-1: g_u8AudLangSelected-1;
                    else
#endif
                        u8CurrentItemIndex = msAPI_CM_GetPrevAudioStreamOrdinal(msAPI_CM_GetCurrentServiceType(), msAPI_CM_GetCurrentPosition(msAPI_CM_GetCurrentServiceType()), g_u8AudLangSelected);
                }
                else
                {
#if ENABLE_PVR
                    if (MApp_PVR_IsPlaybacking())
                        u8CurrentItemIndex = (g_u8AudLangSelected+1)% audioLangTotal; //((g_u8AudLangSelected+1) == audioLangTotal)?0: g_u8AudLangSelected+1;
                    else
#endif
                        u8CurrentItemIndex = msAPI_CM_GetNextAudioStreamOrdinal(msAPI_CM_GetCurrentServiceType(), msAPI_CM_GetCurrentPosition(msAPI_CM_GetCurrentServiceType()), g_u8AudLangSelected);
                }

                u8NewItemPage = u8CurrentItemIndex / HKEY_AUDIO_LANG_PAGE_MAX_ITEM;

#if ENABLE_PVR
                if ( MApp_PVR_IsPlaybacking())
                {
                    retval = MApp_PVR_PlaybackAudioGetStreamInfo(&aAudioStreamInfo, u8CurrentItemIndex);
                }
                else
#endif
                {
                    retval = msAPI_CM_GetAudioStreamInfo(msAPI_CM_GetCurrentServiceType(), msAPI_CM_GetCurrentPosition(msAPI_CM_GetCurrentServiceType()), &aAudioStreamInfo, u8CurrentItemIndex);
                }

                if(!retval)
                {
                    ASSERT(0);
                }

                g_u8LRAudioMode = aAudioStreamInfo.aISOLangInfo[0].bISOLanguageInfo;

                if (u8PrvItemPage != u8NewItemPage)
                {
                    //clear background
                    MApp_ZUI_API_InvalidateAllSuccessors(HWND_AUDLANG_LIST_PANE);
                    curSelItemPage = u8NewItemPage;
                }

                MApp_ZUI_API_SetFocus(
                    _MApp_ZUI_ACT_AudioLanguageIndexMapToWindow(
                        u8CurrentItemIndex%HKEY_AUDIO_LANG_PAGE_MAX_ITEM));

                if (audioLangTotal > DEFAULT_AUD_LANG_NUM)
                {   //printf("set audio languge %u \n",g_u8AudLangSelected);
                    MApp_Audio_SetAudioLanguage(u8CurrentItemIndex);

                }
            }
            return TRUE;

        case EN_EXE_GOTO_MAINMENU:
            MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
            _enTargetState = STATE_OSDPAGE_GOTO_MAIN_MENU;
            return TRUE;
        //case EN_EXE_SWITCH_AUDIOLANG:

    }
#endif
    return FALSE;
}

BOOLEAN MApp_ZUI_ACT_HandleAudioLanguageKey(VIRTUAL_KEY_CODE key)
{
    //note: this function will be called in running state

    //reset timer if any key
    MApp_ZUI_API_ResetTimer(HWND_AUDLANG_LIST_PANE, 0);

    switch(key)
    {
        case VK_MTS:
        case VK_EXIT:
            MApp_ZUI_ACT_ExecuteAudioLanguageAction(EN_EXE_CLOSE_CURRENT_OSD);
            return TRUE;
        case VK_POWER:
            MApp_ZUI_ACT_ExecuteAudioLanguageAction(EN_EXE_POWEROFF);
            return TRUE;
        case VK_SELECT:
            //MApp_ZUI_API_SetTimer(HWND_AUDLANG_BOTTOM_HALF_OK_BTN, 0, BUTTONANICLICK_PERIOD);
            //MApp_ZUI_API_InvalidateWindow(HWND_AUDLANG_BOTTOM_HALF_OK_BTN);
            break;
        /*case VK_EXIT:
            MApp_ZUI_API_SetTimer(HWND_MENU_BOTTOM_HALF_EXIT_BG, 0, BUTTONANICLICK_PERIOD);
            MApp_ZUI_API_InvalidateWindow(HWND_MENU_BOTTOM_HALF_EXIT_BG);
            break;*/
        case VK_UP:
            //MApp_ZUI_API_SetTimer(HWND_AUDLANG_BOTTOM_HALF_UP_BTN, 0, BUTTONANICLICK_PERIOD);
            //MApp_ZUI_API_InvalidateWindow(HWND_AUDLANG_BOTTOM_HALF_UP_BTN);
            break;
        case VK_DOWN:
            //MApp_ZUI_API_SetTimer(HWND_AUDLANG_BOTTOM_HALF_DOWN_BTN, 0, BUTTONANICLICK_PERIOD);
            //MApp_ZUI_API_InvalidateWindow(HWND_AUDLANG_BOTTOM_HALF_DOWN_BTN);
            break;
        case VK_LEFT:
            //MApp_ZUI_API_SetTimer(HWND_AUDLANG_BOTTOM_HALF_LEFT_BTN, 0, BUTTONANICLICK_PERIOD);
            //MApp_ZUI_API_InvalidateWindow(HWND_AUDLANG_BOTTOM_HALF_LEFT_BTN);
            break;
        case VK_RIGHT:
            //MApp_ZUI_API_SetTimer(HWND_AUDLANG_BOTTOM_HALF_RIGHT_BTN, 0, BUTTONANICLICK_PERIOD);
            //MApp_ZUI_API_InvalidateWindow(HWND_AUDLANG_BOTTOM_HALF_RIGHT_BTN);
            break;

        case VK_MENU:
            MApp_ZUI_ACT_ExecuteAudioLanguageAction(EN_EXE_GOTO_MAINMENU);
            break;

        default:
            break;
    }
    return FALSE;
}

void MApp_ZUI_ACT_TerminateAudioLanguage(void)
{
    ZUI_MSG(printf("[]term:audlang\n"));
    MApp_OSDPage_SetState(_enTargetState);
}


LPTSTR MApp_ZUI_ACT_GetAudioLanguageDynamicText(HWND hwnd)
{
    // Marked it by coverity_295
#if (!ENABLE_DTV)
    UNUSED(hwnd);
#else
    switch(hwnd)
    {
        case HWND_AUDLANG_ITEM0_LANG_TEXT:
        case HWND_AUDLANG_ITEM1_LANG_TEXT:
        case HWND_AUDLANG_ITEM2_LANG_TEXT:
        case HWND_AUDLANG_ITEM3_LANG_TEXT:
        case HWND_AUDLANG_ITEM4_LANG_TEXT:
        case HWND_AUDLANG_ITEM5_LANG_TEXT:
        case HWND_AUDLANG_ITEM6_LANG_TEXT:
        case HWND_AUDLANG_ITEM7_LANG_TEXT:
        case HWND_AUDLANG_ITEM8_LANG_TEXT:
        case HWND_AUDLANG_ITEM9_LANG_TEXT:
            {
                U8 idx = _MApp_ZUI_ACT_AudioLanguageWindowMapToIndex(hwnd)+
                    HKEY_AUDIO_LANG_PAGE_MAX_ITEM*curSelItemPage;
                return _MApp_ZUI_ACT_GetAudioLangItemText(idx);
            }

    }
#endif
    //if (u16TempID != Empty)
    //    return MApp_ZUI_API_GetString(u16TempID);
    return 0; //for empty string....
}

U16 MApp_ZUI_ACT_GetAudioLanguageDynamicBitmap(HWND hwnd, DRAWSTYLE_TYPE ds_type)
{
#if (!ENABLE_DTV)
    UNUSED(hwnd);
    UNUSED(ds_type);
#else
    U8 idx = _MApp_ZUI_ACT_AudioLanguageWindowMapToIndex(hwnd)+HKEY_AUDIO_LANG_PAGE_MAX_ITEM*curSelItemPage;

    if(idx>=audioLangTotal)
        return 0xFFFF; //empty bitmap

    switch(hwnd)
    {
        case HWND_AUDLANG_ITEM0_L_SOUND_ICON:
        case HWND_AUDLANG_ITEM1_L_SOUND_ICON:
        case HWND_AUDLANG_ITEM2_L_SOUND_ICON:
        case HWND_AUDLANG_ITEM3_L_SOUND_ICON:
        case HWND_AUDLANG_ITEM4_L_SOUND_ICON:
        case HWND_AUDLANG_ITEM5_L_SOUND_ICON:
        case HWND_AUDLANG_ITEM6_L_SOUND_ICON:
        case HWND_AUDLANG_ITEM7_L_SOUND_ICON:
        case HWND_AUDLANG_ITEM8_L_SOUND_ICON:
        case HWND_AUDLANG_ITEM9_L_SOUND_ICON:
            //from MApp_UiMenu_DrawAudioLanguageItem()
            if (ds_type == DS_FOCUS)
            {
                if (g_u8LRAudioMode == 0 || g_u8LRAudioMode == 2)
                    return E_BMP_ICON_AUDIO_L_F;
                if (g_u8LRAudioMode == 1)
                    return E_BMP_ICON_AUDIO_R_F;
            }
	    else
	    {
                if (g_u8LRAudioMode == 0 || g_u8LRAudioMode == 2)
                    return E_BMP_ICON_AUDIO_L_N;
                if (g_u8LRAudioMode == 1)
                    return E_BMP_ICON_AUDIO_R_N;
	    }
            break;

        case HWND_AUDLANG_ITEM0_R_SOUND_ICON:
        case HWND_AUDLANG_ITEM1_R_SOUND_ICON:
        case HWND_AUDLANG_ITEM2_R_SOUND_ICON:
        case HWND_AUDLANG_ITEM3_R_SOUND_ICON:
        case HWND_AUDLANG_ITEM4_R_SOUND_ICON:
        case HWND_AUDLANG_ITEM5_R_SOUND_ICON:
        case HWND_AUDLANG_ITEM6_R_SOUND_ICON:
        case HWND_AUDLANG_ITEM7_R_SOUND_ICON:
        case HWND_AUDLANG_ITEM8_R_SOUND_ICON:
        case HWND_AUDLANG_ITEM9_R_SOUND_ICON:
            //from MApp_UiMenu_DrawAudioLanguageItem()
            if (ds_type == DS_FOCUS)
            {
                if (g_u8LRAudioMode == 0 || g_u8LRAudioMode == 1)
                    return E_BMP_ICON_AUDIO_R_F;
                if (g_u8LRAudioMode == 2)
                    return E_BMP_ICON_AUDIO_L_F;
            }
	    else
	    {
                if (g_u8LRAudioMode == 0 || g_u8LRAudioMode == 1)
                    return E_BMP_ICON_AUDIO_R_N;
                if (g_u8LRAudioMode == 2)
                    return E_BMP_ICON_AUDIO_L_N;
	    }
            break;

        case HWND_AUDLANG_ITEM0_AUDIO_TYPE_ICON:
        case HWND_AUDLANG_ITEM1_AUDIO_TYPE_ICON:
        case HWND_AUDLANG_ITEM2_AUDIO_TYPE_ICON:
        case HWND_AUDLANG_ITEM3_AUDIO_TYPE_ICON:
        case HWND_AUDLANG_ITEM4_AUDIO_TYPE_ICON:
        case HWND_AUDLANG_ITEM5_AUDIO_TYPE_ICON:
        case HWND_AUDLANG_ITEM6_AUDIO_TYPE_ICON:
        case HWND_AUDLANG_ITEM7_AUDIO_TYPE_ICON:
        case HWND_AUDLANG_ITEM8_AUDIO_TYPE_ICON:
        case HWND_AUDLANG_ITEM9_AUDIO_TYPE_ICON:
                return _MApp_ZUI_ACT_GetAudioLangItemTypeBitmapID(idx, ds_type);


        case HWND_AUDLANG_ITEM0_AUDIO_TYPE2_ICON:
        case HWND_AUDLANG_ITEM1_AUDIO_TYPE2_ICON:
        case HWND_AUDLANG_ITEM2_AUDIO_TYPE2_ICON:
        case HWND_AUDLANG_ITEM3_AUDIO_TYPE2_ICON:
        case HWND_AUDLANG_ITEM4_AUDIO_TYPE2_ICON:
        case HWND_AUDLANG_ITEM5_AUDIO_TYPE2_ICON:
        case HWND_AUDLANG_ITEM6_AUDIO_TYPE2_ICON:
        case HWND_AUDLANG_ITEM7_AUDIO_TYPE2_ICON:
        case HWND_AUDLANG_ITEM8_AUDIO_TYPE2_ICON:
        case HWND_AUDLANG_ITEM9_AUDIO_TYPE2_ICON:
                return _MApp_ZUI_ACT_GetAudioLangItemType2BitmapID(idx, ds_type);

    }
#endif
    return 0xFFFF; //for empty bitmap....
}

#if (ENABLE_CUS_UI_SPEC == FALSE)/*Creass.liu at 2012-06-27*/
BOOLEAN MApp_ZUI_ACT_ExecuteSetAudLangDialogAction(U16 act)
{
#if (!ENABLE_DTV)
    UNUSED(act);
#else
    switch(act)
    {
        case EN_EXE_AUDIOLANG_SET:
            stGenSetting.g_SoundSetting.Primary_Flag= !stGenSetting.g_SoundSetting.Primary_Flag;
            MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_OPTION_AUDIOLANG_PRIMARY_OPTION);
            return true;

        default:
            ZUI_DBG_FAIL(printf("[ZUI]SetLangACT\n"));
            ABORT();
    }
#endif
    return FALSE;
}

LPTSTR MApp_ZUI_ACT_GetSetAudLangDynamicText(HWND hwnd)
{
    U16 u16TempID = Empty;

    switch(hwnd)
    {
        case HWND_MENU_OPTION_AUDIOLANG_PRIMARY_OPTION:
        {
            if(!stGenSetting.g_SoundSetting.Primary_Flag)
                u16TempID=en_str_Primary;
            else
                u16TempID=en_str_Secondary;
            break;
        }

    }

    if (u16TempID != Empty)
        return MApp_ZUI_API_GetString(u16TempID);
    return 0; //for empty string....
}
#endif
/////////////////////////////////////////////////////////
// Customize Window Procedures

/*
S32 MApp_ZUI_ACT_AudioLanguageListWinProc(HWND hwnd, PMSG msg)
{
    switch(msg->message)
    {
        case MSG_CREATE:
            {

                //setting AP timeout, auto close
                MApp_ZUI_API_SetTimer(hwnd, 0, HOT_MENU_TIME_OUT_3SEC);
            }
            break;

        case MSG_TIMER:
            {
                //if the time is up, kill the timer and then close AP!
                MApp_ZUI_API_KillTimer(hwnd, 0);
                MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_CLOSE_CURRENT_OSD);
            }
            break;

        case MSG_DESTROY:
            break;

    }

    return DEFAULTWINPROC(hwnd, msg);
}
*/

#undef MAPP_ZUI_ACTAUDLANG_C
