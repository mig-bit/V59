////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (MStar Confidential Information!�L) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef __FREQTABLEATV_H__
#define __FREQTABLEATV_H__

#include "msAPI_ATVSystem.h"
//****************************************************************************
// Public attributes.
//****************************************************************************

#define VHF_LOWMIN_PLL        (msAPI_CFT_VHFLowMinPLL())
#define VHF_LOWMAX_PLL        (msAPI_CFT_VHFHighMinPLL()-1)
#define VHF_HIGHMIN_PLL        (msAPI_CFT_VHFHighMinPLL())
#define VHF_HIGHMAX_PLL        (msAPI_CFT_UHFMinPLL()-1)
#define UHF_MIN_PLL            (msAPI_CFT_UHFMinPLL())
#define UHF_MAX_PLL            (msAPI_CFT_UHFMaxPLL())
#define DEFAULT_PLL         (UHF_MAX_PLL+10) //let the default PLL out of normal range for identification default PLL valume

//****************************************************************************
// Public functions.
//****************************************************************************

void msAPI_CFT_InitChannelFreqTable(void);
BOOLEAN msAPI_CFT_IsValidMediumAndChannel(MEDIUM eMedium, BYTE cChannelNumber);
MEDIUM msAPI_CFT_GetMedium(WORD wChannelPLLData);
BYTE msAPI_CFT_GetChannelNumber(WORD wChannelPLLData);
WORD msAPI_CFT_GetChannelPLLData(MEDIUM eMedium, BYTE cChannel);
void msAPI_CFT_GetMinMaxChannel(MEDIUM eMedium, BYTE * pcMin, BYTE * pcMax);

WORD msAPI_CFT_VHFLowMinPLL(void);
WORD msAPI_CFT_VHFHighMinPLL(void);
WORD msAPI_CFT_UHFMinPLL(void);
WORD msAPI_CFT_UHFMaxPLL(void);

WORD msAPI_CFT_ConvertPLLtoIntegerOfFrequency(WORD wPLL);
WORD msAPI_CFT_ConvertPLLtoFractionOfFrequency(WORD wPLL);
DWORD msAPI_CFT_ConvertPLLtoFrequency(WORD wPLL);
WORD msAPI_CFT_ConvertFrequncyToPLL(WORD wIntegerOfFreq, WORD wFractionOfFreq);

#endif // __FREQTABLEATV_H__
