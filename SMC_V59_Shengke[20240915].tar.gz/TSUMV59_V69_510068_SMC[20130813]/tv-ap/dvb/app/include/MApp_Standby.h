////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef MAPP_STANDBY_H
#define MAPP_STANDBY_H

#ifdef MAPP_STANDBY_C
#define INTERFACE
#else
#define INTERFACE extern
#endif

typedef enum
{
    STATE_STANDBY_INIT,
    STATE_STANDBY_WAIT,
    STATE_STANDBY_EXIT,
} EN_STANDBY_STATE;

//INTERFACE EN_RET MApp_Standby(void);
INTERFACE void MApp_Standby_Init(void);

INTERFACE void Init_LockIC(void);


/* typedef a 32 bit type */
typedef unsigned long int UINT4; 
/* Data structure for MD5 (Message Digest) computation */
typedef struct 
{
	unsigned int count[2];
	unsigned int state[4];
	unsigned char buffer[64];	
}MD5_CTX;


#define F(x,y,z) ((x & y) | (~x & z))
#define G(x,y,z) ((x & z) | (y & ~z))
#define H(x,y,z) (x^y^z)
#define I(x,y,z) (y ^ (x | ~z))

#define ROTATE_LEFT(x,n) ((x << n) | (x >> (32-n)))

#define FF(a,b,c,d,x,s,ac) \
          { \
          a += F(b,c,d) + x + ac; \
          a = ROTATE_LEFT(a,s); \
          a += b; \
          }
#define GG(a,b,c,d,x,s,ac) \
          { \
          a += G(b,c,d) + x + ac; \
          a = ROTATE_LEFT(a,s); \
          a += b; \
          }
#define HH(a,b,c,d,x,s,ac) \
          { \
          a += H(b,c,d) + x + ac; \
          a = ROTATE_LEFT(a,s); \
          a += b; \
          }
#define II(a,b,c,d,x,s,ac) \
          { \
          a += I(b,c,d) + x + ac; \
          a = ROTATE_LEFT(a,s); \
          a += b; \
          }                                            
void MD5Init(MD5_CTX *context);
void MD5Update(MD5_CTX *context,unsigned char *input,unsigned int inputlen);
void MD5Final(MD5_CTX *context,unsigned char digest[16]);
void MD5Transform(unsigned int state[4],unsigned char block[64]);
void MD5Encode(unsigned char *output,unsigned int *input,unsigned int len);
void MD5Decode(unsigned int *output,unsigned char *input,unsigned int len);
 
/* ********************************************************************** 
** End of md5.h                                                   
** ******************************* (cut) ******************************** */



////////////////////////////////////////////////////////////////////////////////
#undef INTERFACE

////////////////////////////////////////////////////////////////////////////////
#endif // #ifndef MAPP_STANDBY_H

