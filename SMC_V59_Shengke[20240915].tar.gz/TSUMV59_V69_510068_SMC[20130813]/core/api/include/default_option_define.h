
#ifndef _DEFAULT_OPTION_DEFINE_H_
#define _DEFAULT_OPTION_DEFINE_H_

/*************************************************************************************************************/

#ifndef DEBUG_AUDIO_DETECT_TIME
    #define DEBUG_AUDIO_DETECT_TIME                         0
#endif

#ifndef DTV_SCAN_AUTO_FINE_TUNE_ENABLE
    #define DTV_SCAN_AUTO_FINE_TUNE_ENABLE                  0
#endif

/*
    This function is that user can input any frequency point when DTV manual scan
*/
#ifndef ENABLE_SZ_DTV_OFFSET_FUNCTION
    #define ENABLE_SZ_DTV_OFFSET_FUNCTION                   0
#endif

/*
    This function is that user can input any frequency point when DTV manual scan
*/
#ifndef ENABLE_SZ_DTV_ADDCH_SCAN_FUNCTION
    #define ENABLE_SZ_DTV_ADDCH_SCAN_FUNCTION               0
#endif

#ifndef ENABLE_SZ_FACTORY_PICTURE_CURVE_FUNCTION
    #define ENABLE_SZ_FACTORY_PICTURE_CURVE_FUNCTION        0
#endif

#ifndef ENABLE_SZ_FACTORY_SOUND_CURVE_FUNCTION
    #define ENABLE_SZ_FACTORY_SOUND_CURVE_FUNCTION          0
#endif

#ifndef ENABLE_SZ_FACTORY_OVER_SCAN_FUNCTION
    #define ENABLE_SZ_FACTORY_OVER_SCAN_FUNCTION            0
#endif

#ifndef ENABLE_SZ_NEW_FACTORY_MEMU_FUNCTION
    #define ENABLE_SZ_NEW_FACTORY_MEMU_FUNCTION             0
#endif

#ifndef ENABLE_SZ_FACTORY_SOUND_MODE_FUNCTION
    #define ENABLE_SZ_FACTORY_SOUND_MODE_FUNCTION           0
#endif

#ifndef ENABLE_SZ_FACTORY_WB_ADJUST_FUNCTION
    #define ENABLE_SZ_FACTORY_WB_ADJUST_FUNCTION            0
#endif

#ifndef ENABLE_SZ_FACTORY_OTHER_SETTING_FUNCTION
    #define ENABLE_SZ_FACTORY_OTHER_SETTING_FUNCTION        0
#endif

#ifndef ENABLE_SZ_FACTORY_USB_SAVE_DATABASE_FUNCTION
    #define ENABLE_SZ_FACTORY_USB_SAVE_DATABASE_FUNCTION    1
#endif

#ifndef ENABLE_SZ_FACTORY_OSD_BLENDING_FUNCTION
    #define ENABLE_SZ_FACTORY_OSD_BLENDING_FUNCTION         0
#endif

#ifndef ENABLE_SZ_FACTORY_SOFTWARE_UPDATE_FUNCTION
    #define ENABLE_SZ_FACTORY_SOFTWARE_UPDATE_FUNCTION      0
#endif

#ifndef ENABLE_SZ_FACTORY_EQ_BAND_FUNCTION
    #define ENABLE_SZ_FACTORY_EQ_BAND_FUNCTION              0
#endif

#ifndef ENABLE_SZ_FACTORY_YPBPR_PHASE_FUNCTION
    #define ENABLE_SZ_FACTORY_YPBPR_PHASE_FUNCTION          0
#endif

#ifndef ENABLE_SZ_HDMI_AVMUTE_TEST_FUNCTION
    #define ENABLE_SZ_HDMI_AVMUTE_TEST_FUNCTION             0
#endif

#ifndef ENABLE_SZ_SCAN_LEFT_RIGHT_FUNCTION
    #define ENABLE_SZ_SCAN_LEFT_RIGHT_FUNCTION              0
#endif

#ifndef ENABLE_HIS_LVDS
    #define ENABLE_HIS_LVDS                                 0
#endif

#ifndef PANEL_SWAP_LVDS_POL
    #define PANEL_SWAP_LVDS_POL                             0
#endif


#ifndef ENABLE_HOTEL_MODE_FUNCTION
    #define  ENABLE_HOTEL_MODE_FUNCTION                     0
#endif

#ifndef ENABLE_SZ_BLUESCREEN_FUNCTION
    #define ENABLE_SZ_BLUESCREEN_FUNCTION                   0
#endif

#ifndef ADC_AUTO_GAIN_CABLICATION_WITHOUT_EXT_SIGNAL
    #define ADC_AUTO_GAIN_CABLICATION_WITHOUT_EXT_SIGNAL    0
#endif

#ifndef ENABLE_CH_VOLUME_COMP
    #define ENABLE_CH_VOLUME_COMP                           0
#endif

#ifndef ENABLE_SW_CH_FREEZE_SCREEN
    #define ENABLE_SW_CH_FREEZE_SCREEN                      0
#endif

#ifndef ENABLE_VGA_EIA_TIMING
#define ENABLE_VGA_EIA_TIMING             1
#endif

#ifndef ENABLE_DMP_POWERON
    #define ENABLE_DMP_POWERON                      1
#endif

#ifndef ENABLE_CH_FORCEVIDEOSTANDARD
    #define ENABLE_CH_FORCEVIDEOSTANDARD      0
#endif

#define NO_CC                               0   // No Closedcaption for CC608 and CC708
#define DTV_CC                              1   // CC608 and CC708
#define ATV_CC                              2   // Only CC608 on DVB
#define BRA_CC                              3  // Brazil CC have CC608 and Brazil CC

 #ifndef ATSC_CC
    #define ATSC_CC                             NO_CC
 #endif

 #define BRAZIL_PVR_CC      DISABLE
 #if (ATSC_CC == NO_CC)
    #define SUPPORT_KOREAN_CC                   0
    #define SUPPORT_INSERT_CC_TO_VE             0

 #elif (ATSC_CC == DTV_CC)
  #ifndef SUPPORT_KOREAN_CC
    #define SUPPORT_KOREAN_CC                   0
  #endif
  #ifndef SUPPORT_INSERT_CC_TO_VE
    #define SUPPORT_INSERT_CC_TO_VE             0
  #endif

 #elif(ATSC_CC == ATV_CC)
    #define SUPPORT_KOREAN_CC                   0
    #define SUPPORT_INSERT_CC_TO_VE             0
 // -----------ATSC CC -------------//

 #elif(ATSC_CC == BRA_CC)
 #define SUPPORT_KOREAN_CC                   0
#define SUPPORT_INSERT_CC_TO_VE             0

 // -----------BRAZIL CC -------------//
#define BRAZIL_PVR_CC      DISABLE

#if (ENABLE_SBTVD_BRAZIL_APP)
    #define BRAZIL_CC                           ENABLE
    #if ENABLE_PVR
    #undef BRAZIL_PVR_CC
    #define BRAZIL_PVR_CC                       ENABLE
    #endif
#else
    #define BRAZIL_CC                           DISABLE
#endif
// -----------BRAZIL CC -------------//
#endif

#ifndef  BRAZIL_CC
    #define BRAZIL_CC                           DISABLE
    #define BRAZIL_PVR_CC                       DISABLE
#endif

// ---- vchip---------------------------------------------------------------------
 #ifndef ATSC_VCHIP
    #define ATSC_VCHIP                             0
 #endif

#if (ATSC_VCHIP)
#define ENABLE_ATV_VCHIP                            ENABLE
#else
#define ENABLE_ATV_VCHIP                            DISABLE
#endif

#ifndef ENABLE_OFFLINE_SIGNAL_DETECTION
    #define ENABLE_OFFLINE_SIGNAL_DETECTION     0
#endif

#ifndef ENABLE_NEW_COLORTEMP_METHOD
    #define ENABLE_NEW_COLORTEMP_METHOD         0
#endif

#ifndef ENABLE_CEC
    #define ENABLE_CEC                          0
#endif

#ifndef ENABLE_MHL
    #define ENABLE_MHL                          0
#endif


//Macro comments: all below MACOR must be controlled by ENABLE_VE, it is the head gate.
//    ENABLE_MM_VE_OUTPUT---Enable MM video play output by VE
//    FORCE_ALL_OUTPUT_THROUGH_VE---Enable all input source output through VE, including AV/ATV.
//    ENABLE_OP2_TO_VE---Relative to IP to VE, this output type will output all the mainwindow display to VE, including OSD
#ifndef ENABLE_MM_VE_OUTPUT
    #define ENABLE_MM_VE_OUTPUT                 DISABLE
#endif

#ifndef FORCE_ALL_OUTPUT_THROUGH_VE
    #define FORCE_ALL_OUTPUT_THROUGH_VE         DISABLE
#endif //(ENABLE_VE)

#ifndef ENABLE_OP2_TO_VE
    #define ENABLE_OP2_TO_VE                    DISABLE
#endif

#if 0 //compiling error free -- check later
#ifndef ENABLE_CEC_INT
    #define ENABLE_CEC_INT                      0
#endif

#ifndef ENABLE_CUST01_CEC
    #define ENABLE_CUST01_CEC                   0
#endif

#ifndef ENABLE_SW_CEC_WAKEUP
    #define ENABLE_SW_CEC_WAKEUP                0
#endif
#endif

#ifndef ENABLE_PRECISE_RGBBRIGHTNESS
    #define ENABLE_PRECISE_RGBBRIGHTNESS        DISABLE//ENABLE
#endif

#ifndef ENABLE_FBL_ASPECT_RATIO_BY_MVOP
    #define ENABLE_FBL_ASPECT_RATIO_BY_MVOP     DISABLE//ENABLE
#endif

#ifndef ENABLE_BACKLIGHT_ADJUST
    #define ENABLE_BACKLIGHT_ADJUST             0
#endif

//------ PANEL RELATED ---------------------------------------------------------
#ifndef PANEL_PDP_10BIT
    #define PANEL_PDP_10BIT                     0
#endif

#ifndef LVDS_PN_SWAP_L
    #define LVDS_PN_SWAP_L                      0x00
#endif

#ifndef LVDS_PN_SWAP_H
    #define LVDS_PN_SWAP_H                      0x00
#endif

#ifndef PANEL_SWAP_LVDS_CH
    #define PANEL_SWAP_LVDS_CH                  0x00
#endif

#ifndef BD_LVDS_CONNECT_TYPE
    #define BD_LVDS_CONNECT_TYPE                0x00
#endif

//------ HDMI RELATED ---------------------------------------------------------
#ifndef HDCP_HPD_INVERSE
    #define HDCP_HPD_INVERSE                    ENABLE
#endif

#ifndef ENABLE_FACTORY_POWER_ON_MODE
    #define ENABLE_FACTORY_POWER_ON_MODE        DISABLE
#endif

#ifndef ENABLE_FACTORY_PANEL_SEL
    #define ENABLE_FACTORY_PANEL_SEL        DISABLE
#endif

//------ PACKAGE RELATED ---------------------------------------------------------
#ifndef SHARE_GND
    #define SHARE_GND                           ENABLE//DISABLE
#endif

//------  Board Related -----------------------------------------------------------
#ifndef SCART_ID_SEL
    #define SCART_ID_SEL                        0
#endif

#ifndef SCART2_ID_SEL
    #define SCART2_ID_SEL                       0
#endif

// ------ Demo Fine tune -----------------------------------------------------------
#ifndef ENABLE_DEMO_FINE_TUNE
    #define ENABLE_DEMO_FINE_TUNE               0
#endif

// ------ Flash control -----------------------------------------------------
#ifndef FLASH_WP_PIN_CONTROL
    #define FLASH_WP_PIN_CONTROL                DISABLE
#endif
// ATV vtotal change patch
#ifndef PATCH_FOR_V_RANGE
    #define PATCH_FOR_V_RANGE                   DISABLE
#endif

#ifndef ENABLE_ATV_MODE_SHOW_NO_SIGNAL
    #define ENABLE_ATV_MODE_SHOW_NO_SIGNAL     1
#endif

#ifndef _AutoNR_EN_
    #define _AutoNR_EN_                         0
#endif

#ifndef ENABLE_NEW_AUTO_NR
    #define ENABLE_NEW_AUTO_NR                  0
#endif

#ifndef ENABLE_TTX_SHOW_OFF_SIGNAL
    #define ENABLE_TTX_SHOW_OFF_SIGNAL			0
#endif

#ifndef ENABLE_EPGTIMER_RECORDER_TURNOFFPANEL
    #define ENABLE_EPGTIMER_RECORDER_TURNOFFPANEL			0
#endif

#ifndef ENABLE_SCART_YC_INPUT
    #define ENABLE_SCART_YC_INPUT               0
#endif

#ifndef MPEG_HD_PRE_SCAL_DOWN
     #define MPEG_HD_PRE_SCAL_DOWN    DISABLE
#endif

#ifndef ENABLE_PIU_UART1
     #define ENABLE_PIU_UART1    DISABLE
#endif
#ifndef ENABLE_FRANCE_DTV
     #define ENABLE_FRANCE_DTV         DISABLE
#endif

#ifndef ENABLE_TIMESHIT
     #define ENABLE_TIMESHIT         DISABLE
#endif

#ifndef ENABLE_SMOOTH_PANEL_OUTPUT
     #define ENABLE_SMOOTH_PANEL_OUTPUT    DISABLE
#endif

#ifndef ENABLE_BACKLIGHT_PWM_SYNC_WITH_FRAMERATE
     #define ENABLE_BACKLIGHT_PWM_SYNC_WITH_FRAMERATE DISABLE
#endif

#define RATIO_OF_BACKLIGHT_FREQ_OVER_FRAMERATE 2

#ifndef ENABLE_SZ_FACTORY_USB_SAVE_MAP_FUNCTION
    #define ENABLE_SZ_FACTORY_USB_SAVE_MAP_FUNCTION     DISABLE
#endif

#ifndef ENABLE_CHECK_WSS_INFO_CHANGE
#define ENABLE_CHECK_WSS_INFO_CHANGE      0
#endif


#ifndef COMPRESS_BIN_AUDIO_DEC
    #define COMPRESS_BIN_AUDIO_DEC  0
#endif

#ifndef DTV_COUNT_DOWN_TIMER_PATCH
    #define DTV_COUNT_DOWN_TIMER_PATCH  0
#endif

#ifndef ENABLE_DMP_DLC
    #define ENABLE_DMP_DLC      0
#endif

#ifndef LOAD_CCFONT_ONCE
    #define LOAD_CCFONT_ONCE    0
#endif
#ifndef ENABLE_ZOOM_AVOUT_NOTMUTE
    #define ENABLE_ZOOM_AVOUT_NOTMUTE                   0
#endif

#ifndef ENABLE_BACKLIGHT_USER_LIMIT
#define ENABLE_BACKLIGHT_USER_LIMIT                     1
#endif
#ifndef BOE_AC_UPDATE_RESET_CHPRESET
#define BOE_AC_UPDATE_RESET_CHPRESET   TRUE
#endif
#ifndef BOE_AC_UPDATE_RESERVE_WBADC
#define BOE_AC_UPDATE_RESERVE_WBADC   TRUE
#endif
#ifndef BOE_FACTORY_SETFOCUS_SWINFO
#define BOE_FACTORY_SETFOCUS_SWINFO   TRUE
#endif
#ifndef BOE_FACTORY_VERSION_IN_BOOT
#define BOE_FACTORY_VERSION_IN_BOOT   TRUE
#endif
#ifndef CHANNEL_PAGE_HIDE_MTS
#define CHANNEL_PAGE_HIDE_MTS   TRUE
#endif
#ifndef HOHEL_ENABLE_AQPQ_OPTION
#define HOHEL_ENABLE_AQPQ_OPTION  FALSE
#endif
#ifndef HOHEL_ENABLE_SOURCE_KEY_OPTION
#define HOHEL_ENABLE_SOURCE_KEY_OPTION FALSE
#endif
#ifndef HOTEL_ENABLE_POWER_ON_OPTION
#define HOHEL_ENABLE_POWER_ON_OPTION   FALSE
#endif
#ifndef ENABLE_INFOMENU_MODIFY
#define ENABLE_INFOMENU_MODIFY						ENABLE		
#endif
#ifndef ENABLE_NO_AUDIO_INPUT_AUTO_MUTE
#define ENABLE_NO_AUDIO_INPUT_AUTO_MUTE   DISABLE//ENABLE
#endif
#ifndef ENABLE_PLAYBACK_INFO_AUTO_CLOSE
#define ENABLE_PLAYBACK_INFO_AUTO_CLOSE   ENABLE
#endif
#ifndef ENABLE_MULTI_PANELS
#define ENABLE_MULTI_PANELS                           ENABLE//SOURCE+9+0X//06 IS HD_1920X1080,04 IS CM19_1400X900,03 IS 1366X768
#endif
#ifndef ENABLE_SZ_FACTORY_LVDS_MODE_FUNCTION
    #define ENABLE_SZ_FACTORY_LVDS_MODE_FUNCTION  1
#endif
#ifndef ENABLE_FACTORY_DRC
#define ENABLE_FACTORY_DRC                           ENABLE
#endif
//<<SMC jayden.chen mask
//#define ENABLE_SANYO_WB_JPG                             // smc-steven, 20120416

#ifndef ENABLE_FACTORY_GAMMA
#define ENABLE_FACTORY_GAMMA                           ENABLE
#endif
//<<SMC jayden.chen  add auto usb update when AC power on 20130927
#ifndef ENABLE_SMC_USB_AUTO_UPDATE 
    #define ENABLE_SMC_USB_AUTO_UPDATE  		    0 //1:�����ϵ��Զ�����    0:��
#endif

//<<SMC jayden.chen  add auto usb update reset all data 20130927
#ifndef ENABLE_SMC_USB_UPDATE_RESET_ALL_DATA 
    #define ENABLE_SMC_USB_UPDATE_RESET_ALL_DATA  	0 //1:����֮��λ�������� 0:��
#endif

#ifndef DEFAULT_SOURCE_TYPE
    #define DEFAULT_SOURCE_TYPE    1
 #endif
/*************************************************************************************************************/
#endif //#ifndef _DEFAULT_OPTION_DEFINE_H_
