////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#include "Board.h"
#include "debug.h"
#include "datatype.h"
#include "drvAUDIO.h"
#include "apiXC.h"
#include "apiXC_Adc.h"

#include "msAPI_Global.h"
#include "msAPI_Tuning.h"
#include "msAPI_ATVSystem.h"
#include "msAPI_FreqTableATV.h"
#include "msAPI_DTVSystem.h"
#include "msAPI_audio.h"
#include "msAPI_Timer.h"
#include "msAPI_VD.h"

#include "Panel.h"
#include "apiPNL.h"
#include "apiXC_PCMonitor.h"

#if ENABLE_TTX
#include "msAPI_TTX.h"
#include "mapp_ttx.h"
#endif
#include "MApp_ATVProc.h"
#include "MApp_VDMode.h"
#include "MApp_GlobalVar.h"
#include "MApp_GlobalSettingSt.h"
#include "MApp_PCMode.h"
#include "MApp_TopStateMachine.h"
#include "MApp_Scaler.h"
#include "MApp_UiMenuDef.h" //ZUI:
#include "MApp_ATV_Scan.h"
#include "MApp_ZUI_Main.h"
#include "ZUI_tables_h.inl"
#include "ZUI_exefunc.h"
#include "GPIO.h"
#include "drvUartDebug.h" //For OTHER_TUNER_DEBUG
#include "drvIPAUTH.h"

#if (ENABLE_ATV_VCHIP)
#include "MApp_VChip.h"
#include "MApp_ZUI_ACTmsgbox.h"
#endif

#define DEBUG_TVAVHANDLER        0xFF

#ifdef DEBUG_TVAVHANDLER
    #define debugTVAVHandlerPrint(a,b)    debugPrint(a,b)
#else
    #define debugTVAVHandlerPrint(a,b)
#endif

#if INPUT_SCART_USE_SV2
extern void MApp_InputSource_SwitchSource ( E_UI_INPUT_SOURCE enUiInputSourceType,SCALER_WIN eWindow );
U8 g_u8IsScartRGB;
#endif


extern unsigned char Customer_info[];
extern unsigned char Customer_hash[];
extern THR_TBL_TYPE code AuSifInitThreshold[];
//****************************************************************************
// Private attributes of this file.
//****************************************************************************

static DWORD            m_dwATVAVHandlerTimer;
static WORD             m_wTVAVTimer;
BOOLEAN bIsAtuneActive = FALSE;
//static VIDEOSOURCE_TYPE     m_eInitVideoSource;

//------------------------------------------------------------------------------
// Local Function Prototype
//------------------------------------------------------------------------------
static BOOLEAN _MApp_ATVProc_IsVideoSourceActive( SCALER_WIN eWindow );
//static void _MApp_ATVProc_ClearBuffer(BYTE *pcBuffer, BYTE cSize);
static void _MApp_ATVProc_NotifyToMainSystem( SCALER_WIN eWindow );
//static void _MApp_ATVProc_UpdateScanState(void); //ZUI:
static void _MApp_ATVProc_UpdateScanState( SCALER_WIN eWindow)
{
    static U8 LimitHandle=0;
    #if (ENABLE_DTMB_CHINA_APP || ENABLE_ATV_CHINA_APP || ENABLE_DVBC_PLUS_DTMB_CHINA_APP)
    EN_ATV_SYSTEM_TYPE u8AudioSystem =EN_ATV_SystemType_DK;
    #else
    EN_ATV_SYSTEM_TYPE u8AudioSystem =EN_ATV_SystemType_BG;
    #endif
    AUDIOSTANDARD_TYPE eAudioStandard;

  #if ( ENABLE_DVB_TAIWAN_APP || ENABLE_SBTVD_BRAZIL_APP || (TV_SYSTEM == TV_NTSC) )
	return;
  #endif

    if (!(IsSrcTypeATV(SYS_INPUT_SOURCE_TYPE(eWindow))))
        return;

    // Skip when auto search
    if( msAPI_Tuner_IsTuningProcessorBusy() == TRUE )
    {
        return;
    }

    #ifdef ENABLE_CUS_AUTO_AUDIO_SYSTEM_DETECT
    if(msAPI_AUD_ATV_IsBeginAudioSystemAutoDetect())
    {
        return;
    }
    #endif

    // Skip when manual tuning
    //if(  )
    {
        //return;
    }


    LimitHandle++;
    if(LimitHandle < 90) //900mSEC
        return;
    LimitHandle = 0;

    //Update System
    eAudioStandard = msAPI_AUD_GetAudioStandard();
    //printf(" <eAudioStandard=%u> ", eAudioStandard);
    u8AudioSystem = MApp_ATVProc_GetAudioSystem(eAudioStandard);
    if (u8AudioSystem != stGenSetting.stScanMenuSetting.u8SoundSystem)
    {
        stGenSetting.stScanMenuSetting.u8SoundSystem = u8AudioSystem;
        printf(" => stScanMenuSetting.u8SoundSystem=%u\n", stGenSetting.stScanMenuSetting.u8SoundSystem);

    #if ((FRONTEND_IF_DEMODE_TYPE == MSTAR_VIF_MSB1210)||(FRONTEND_IF_DEMODE_TYPE == MSTAR_VIF)||(FRONTEND_IF_DEMODE_TYPE == MSTAR_INTERN_VIF) )// GEM_SYNC_0815
        msAPI_Tuner_SetIF();
    #endif
    }
}


//------------------------------------------------------------------------------
/// What options is enabled for this ATV.
/// @param eOption \b IN:
//      E_ENABLE_SYSTEM_L: To enable BG/I/DK/L. If not, BG/I/DK/M.
//      E_ENABLE_RF_TABLE: To use RF frequency table of china & australia.
//      E_ENABLE_RT_AFT: To enable realtime AFT.
//      E_ENABLE_CH_NAME: To enable Channel Name for ATV.
//      E_ENABLE_TTX: To enable teletext function.
//      E_ENABLE_CARRIER_MUTE:
//      E_ENABLE_SAVING_DUAL: To save dual mode. It will be saved.
//      E_ENABLE_HI_DEVIATION: To enable HI-Deviation.
//      E_ENABLE_VOLUME_CURVE_SEL: To select the kind of volume curve.
//      E_ENABLE_MONO_ONLY: To use only mono.
//      E_ENABLE_SCART: To include SCART input.
//      E_ENABLE_WSS: To use WSS and SCART-ID for detecting aspect ratio of input signal.
/// @return TRUE/FALSE
//------------------------------------------------------------------------------
BOOLEAN MApp_ATVProc_IsThisATVOptionEnabled(THISATV_OPTION eOption)
{
    BOOLEAN bEnabled;

    bEnabled = FALSE;

    switch ( eOption )
    {
    case E_ENABLE_SYSTEM_L:
    #if ( ENABLE_DTMB_CHINA_APP || ENABLE_DVB_TAIWAN_APP || ENABLE_ATV_CHINA_APP || ENABLE_SBTVD_BRAZIL_APP || ENABLE_DVBC_PLUS_DTMB_CHINA_APP)
        bEnabled = FALSE;
    #else
        bEnabled = TRUE;
    #endif
        break;

    case E_ENABLE_RF_TABLE:
        bEnabled = FALSE;
        break;

    case E_ENABLE_RT_AFT:
#if (OTHER_TUNER_DEBUG==1)
        bEnabled = FALSE;
#else
        bEnabled = TRUE;
#endif
        break;

    case E_ENABLE_CH_NAME:
        bEnabled = TRUE;
        break;

    case E_ENABLE_TTX:
        bEnabled = TRUE;
        break;

    case E_ENABLE_CARRIER_MUTE:
        bEnabled = TRUE;
        break;

    case E_ENABLE_SAVING_DUAL:
        bEnabled = TRUE;
        break;

    case E_ENABLE_HI_DEVIATION:
        bEnabled = FALSE;
        break;

    case E_ENABLE_VOLUME_CURVE_SEL:
        bEnabled = FALSE;
        break;

    case E_ENABLE_MONO_ONLY:
        bEnabled = FALSE;
        break;

    case E_ENABLE_SCART:
        #if (INPUT_SCART_VIDEO_COUNT >= 1)
            bEnabled = TRUE;
        #else
            bEnabled = FALSE;
        #endif
        break;

    case E_ENABLE_WSS:
        bEnabled = TRUE;
        break;

    default:
        bEnabled = FALSE;
        break;
    }

    return bEnabled;
}

/**
 FUNCTION    : void MApp_ATVProc_Initialize(void)

 USAGE    : To initialize TV/AV module. This function should be called, if you want to use TV/AV module.

 INPUT    : None

 OUTPUT    : None

 GLOBALS: None

*/
void MApp_ATVProc_Initialize(void)
{
    CAL_TIME_FUNC_START();

#if ( ENABLE_DVB_TAIWAN_APP || ENABLE_SBTVD_BRAZIL_APP)
    msAPI_ATV_SetDirectTuneFlag(FALSE);

     if(stGenSetting.stScanMenuSetting.u8Antenna == 0)//CATV
        msAPI_ATV_SetCurrentAntenna(ANT_CATV);
    else //AIR
        msAPI_ATV_SetCurrentAntenna(ANT_AIR);
#endif

    MApi_AUTH_Process(Customer_info,Customer_hash);

    //printf("init MApp_ATVProc_Initialize\n");

    // Never change the following order.
    msAPI_ATV_InitATVDataManager();

    msAPI_AVD_InitVideoSystem();

    msAPI_AUD_InitAudioSystem(AuSifInitThreshold);

#if 0//(ENABLE_DTV==0)
    msAPI_Tuner_Init();
#endif

    msAPI_CFT_InitChannelFreqTable();


//    if(UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_ATV) //audio already init in msAPI_Tuner_Init()
//    {
//        msAPI_AUD_SetAudioStandard(msAPI_AUD_GetAudioStandard());
//    }
#if ENABLE_TTX
    #if ENABLE_DTV
    MApp_TTX_SetCountry(msAPI_CM_GetCountry());
    #else
    // FIXME:
    // there is no msAPI_CM_GetCountry( ) in ATV only mode.... this is a dirty patch
    MApp_TTX_SetCountry(E_UK);
    #endif

    // Both Logo & TTX use POOL_BUFFER and
    // to avoid writing POOL_BUFFER when showing logo, MApp_TTX_InitVBITeletext() is marked now.
    // This function will be called when changing input source
//    MApp_TTX_InitVBITeletext();
#endif

    debugTVAVHandlerPrint("finished atvav",0);
    bIsAtuneActive = FALSE;
    m_dwATVAVHandlerTimer = 0;
    m_wTVAVTimer = WAIT_0ms;

    CAL_TIME_FUNC_END();
}

/**
 FUNCTION    : void MApp_ATVProc_Exit(void)

 USAGE    : To exit TV/AV module.

 INPUT    : None

 OUTPUT    : None

 GLOBALS: None

*/
void MApp_ATVProc_Exit(void)
{
    debugTVAVHandlerPrint("exit atvav",0);

    if ( msAPI_Tuner_IsTuningProcessorBusy() == TRUE )
    {
        msAPI_Tuner_TuningProcessor(AFT_EXT_STEP_SEARCHSTOP);
    }

    MApi_AUDIO_ExitAudioSystem();
}

/**
 FUNCTION    : void void MApp_ATVProc_Handler(void)

 USAGE    : To make TV/AV module breathing. This function should be called under 10ms continuously.

 INPUT    : None

 OUTPUT    : None

 GLOBALS: None

*/
void MApp_ATVProc_Handler( SCALER_WIN eWindow )
{
    if(msAPI_Timer_DiffTimeFromNow(m_dwATVAVHandlerTimer) < MAIN_LOOP_INTERVAL)
    {
        return;
    }

    m_dwATVAVHandlerTimer = msAPI_Timer_GetTime0();

    #ifdef ENABLE_CUS_AUTO_AUDIO_SYSTEM_DETECT
    msAPI_AUD_ATV_AudioSystemAutoDetect(400);
    #endif

#if ENABLE_TTX_ACI
    if (enTTXACIState!=STATE_TTX_ACI_FINALIZE_EXIT) // if !processAci, we can change frequency!
#endif
    {
        if(MApp_ATV_Scan_ScanState() != STATE_ATV_SCAN_PAUSE)
            msAPI_Tuner_TuningProcessor(AFT_EXT_STEP_PERIODIC);
    }

    if (bIsAtuneActive == FALSE)
    {
       _MApp_ATVProc_UpdateScanState(eWindow);
    }
#if INPUT_SCART_USE_SV2
    if(IsSrcTypeScart(SYS_INPUT_SOURCE_TYPE(eWindow))
      #if (INPUT_SV_VIDEO_COUNT >= 2)
       || (SYS_INPUT_SOURCE_TYPE(eWindow) == INPUT_SOURCE_SVIDEO2
       )
      #endif //#if (INPUT_SV_VIDEO_COUNT >= 2)
       )
    {
            if(msAPI_AVD_IsScartRGB() != g_u8IsScartRGB)
        {
            #if ENABLE_TTX
            if(MApp_TTX_IsTeletextOn())     //80331  SCART & TT  BUG
                MApp_TTX_TeletextCommand(TTX_TV);
            #endif

            if(IsSrcTypeSV(SYS_INPUT_SOURCE_TYPE(eWindow))||IsSrcTypeScart(SYS_INPUT_SOURCE_TYPE(eWindow)))
            {
                MApp_InputSource_SwitchSource(UI_INPUT_SOURCE_SCART, eWindow);
            }
            return;
        }
    }
#endif
    msAPI_AVD_VideoProcessor();
  #if ENABLE_TTX
    #if( 0 == ENABLE_TTX_SHOW_OFF_SIGNAL)//Don't exit TTX mode when signal off
    if(msAPI_AVD_GetStandardDetection()==E_VIDEOSTANDARD_NOTSTANDARD)
    {
        if(MApp_TTX_IsTeletextOn())
            MApp_TTX_TeletextCommand(TTX_TV);
    }
 #endif
  #endif

    #if (ENABLE_PIP)
    if( (IsPIPEnable()==FALSE) || UI_IS_AUDIO_SOURCE_IN(eWindow) )
    #endif
    {
        MW_AUD_AudioProcessor();
    }
    //ZUI_TODO: MApp_UiMenu_UpdateAudioModeUI();

#if ENABLE_TTX
    MApp_TTX_VBIDataProcessor();
#endif

#if ENABLE_IP_AUTO_COAST
    msAPI_Scaler_IPAutoCoastHandler();
#endif

    m_wTVAVTimer++;
    if(m_wTVAVTimer >= WAIT_MAXms)
    {
        m_wTVAVTimer = WAIT_10ms;
    }

    if( (m_wTVAVTimer % WAIT_110ms) == 0 ) // if( (m_wTVAVTimer % WAIT_410ms) == 0 ) // <-<<< OPTIMIZE
    {
        _MApp_ATVProc_NotifyToMainSystem(eWindow);
    }
#if(PATCH_FOR_V_RANGE)
    MApp_VD_SyncRangeHandler();
#endif

}

//------------------------------------------------------------------------------
// Local Functions
//------------------------------------------------------------------------------
static BOOLEAN _MApp_ATVProc_IsVideoSourceActive(SCALER_WIN eWindow)
{
    if( IsSrcTypeDigitalVD(SYS_INPUT_SOURCE_TYPE(eWindow)))
    {
        return TRUE;
    }

    return FALSE;
}
/*
static void _MApp_ATVProc_ClearBuffer(BYTE *pcBuffer, BYTE cSize)
{
    BYTE i;

    for(i=0; i < cSize; i++)
    {
        pcBuffer[i] = 0x00;
    }
}
*/

#if(ENABLE_SW_CH_FREEZE_SCREEN)
extern BOOLEAN bVideoStandardChanged;
#endif
extern BOOLEAN MApp_UiMenuFunc_CheckInputLockAudioVideo(void);
extern void MApp_BlockSys_ResetMsgbox2ScreenSaverTimer(void);

static void _MApp_ATVProc_NotifyToMainSystem(SCALER_WIN eWindow)
{
    BOOLEAN bIsTuningProcessorBusy;
    #if ENABLE_CUS_3D_SOURCE_MEMORY
    static BOOLEAN bPreStatusHasSignal = FALSE;
    E_XC_3D_INPUT_MODE eInput3DMode;
    #endif

    if( _MApp_ATVProc_IsVideoSourceActive(eWindow) == FALSE )
    {
        return;
    }

    bIsTuningProcessorBusy = msAPI_Tuner_IsTuningProcessorBusy();

    // Send Signal Information.
    //if( FALSE == bIsTuningProcessorBusy && TRUE == msAPI_AVD_IsSyncChanged())
    //{
        if(IsVDHasSignal()==TRUE)
        {
            debugTVAVHandlerPrint("Send Message - Change Signal Info - Sync OK",0);
#if ENABLE_NO_AUDIO_INPUT_AUTO_MUTE
			if(1)//(IsAVInUse()||IsSVInUse()||IsATVInUse())
			{
				BYTE NR_status;
				//printf("\r\n-1-");
				NR_status = MApi_AUDIO_GetCommAudioInfo(Audio_Comm_infoType_getNR_Status) ;
				{
					if(!NR_status)
					{
					//printf("\r\n---NR_status==%d---NG---",NR_status);
						//msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_INTERNAL_1_MUTEOFF, E_AUDIOMUTESOURCE_ACTIVESOURCE); //minglin0111
						if(!msAPI_AUD_IsAudioMutedByUser()&&stGenSetting.g_SoundSetting.Volume)
							MUTE_Off();
						else
							MUTE_On();
					}
					else
					{
					//printf("\r\n---NR_status==%d---OK---",NR_status);
						//msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_INTERNAL_1_MUTEON, E_AUDIOMUTESOURCE_ACTIVESOURCE); //minglin0111
						MUTE_On();
					}
				}
			 }
#endif

            #if  (ENABLE_ATV_VCHIP)
            if (E_OSD_EMPTY == MApp_ZUI_GetActiveOSD())
            {
                if (MApp_VChip_GetCurVChipBlockStatus())
                {
                    // parental blocked
                    //printf("MSGBOX>> parental blocked\n");
                    MApp_ZUI_ACT_StartupOSD(E_OSD_MESSAGE_BOX);
                    MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_SHOW_PASSWORD_INPUT_MSGBOX);
                }
            }

            if (E_OSD_MESSAGE_BOX == MApp_ZUI_GetActiveOSD() && EN_MSGBOX_MODE_PASSWORD_INPUT == MApp_ZUI_ACT_GetMessageBoxMode())
            {
                 if (MApp_VChip_GetCurVChipBlockStatus())
                 {
                      if (MApp_VChip_GetRatingUpdateStatus())
                      {
                          MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_REPAINT_ALL);
                      }
                 }
                 else
                 {
                      MApp_ZUI_ACT_ShutdownOSD();
                 }
            }

            #endif
            #if ENABLE_CUS_3D_SOURCE_MEMORY
            if(bPreStatusHasSignal == FALSE)
            {
                bPreStatusHasSignal = TRUE;
            #if (ENABLE_6M30_3D_PROCESS)
                MDrv_Ursa_6M30_3D_MODE(ST_3D_TYPE);
            #endif
                eInput3DMode = MAPP_Scaler_MapUI3DModeToXC3DMode(ST_3D_TYPE);
                MApp_Scaler_EnableManualDetectTiming(TRUE);
                #if(ENABLE_SW_CH_FREEZE_SCREEN)
                if((msAPI_Scaler_GetScreenMute(MAIN_WINDOW) & E_SCREEN_MUTE_CHANNEL)&&(bVideoStandardChanged == FALSE))
                {
                    //Do Noting...
                }
                else
                #endif
                {
                    msAPI_Scaler_SetBlueScreen(ENABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
                }
                MApp_Scaler_SetVideo3DMode(MAPP_Scaler_Map3DFormatTo3DUserMode(eInput3DMode));

            #if ENABLE_UI_3D_PROCESS
                MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_CLOSE_CURRENT_OSD);
                stGenSetting.g_SysSetting.en3DUIMODE = E_UI_3D_UI_MODE_NUM;
            #else
                #if(ENABLE_SW_CH_FREEZE_SCREEN)
                if((msAPI_Scaler_GetScreenMute(MAIN_WINDOW) & E_SCREEN_MUTE_CHANNEL)&&(bVideoStandardChanged == FALSE))
                {
                    //Do Nothing...
                }
                else
                #endif
                {
                    msAPI_Scaler_SetBlueScreen(DISABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
                }
            #endif
            }
            #endif
        }
        else
        {
            #if (ENABLE_CUS_DBC && ENABLE_CUS_9WINDOWS_DETECT)
            MApi_XC_Sys_SetVideoPattern9WindowsFlag(FALSE);
            #endif
            debugTVAVHandlerPrint("Send Message - Change Signal Info - No Sync",0);
#if ENABLE_NO_AUDIO_INPUT_AUTO_MUTE
			MUTE_On();
#endif
        #if 0// (TV_FREQ_SHIFT_CLOCK)    //It will show tearing when changing to SHIFT_CLOCK freq
        if (IsSrcTypeATV(SYS_INPUT_SOURCE_TYPE(eWindow)))
        {
            msAPI_Tuner_Patch_TVShiftClk(DISABLE);
        }
        else
        {
            msAPI_Tuner_Patch_ResetTVShiftClk();
        }
        #endif
            #if (ENABLE_PIP)
            if(IsPIPEnable())
            {
                if( SYS_SCREEN_SAVER_TYPE(SUB_WINDOW) == EN_SCREENSAVER_NOSIGNAL || SYS_SCREEN_SAVER_TYPE(SUB_WINDOW) == EN_SCREENSAVER_NOSYNC || SYS_SCREEN_SAVER_TYPE(SUB_WINDOW) == EN_SCREENSAVER_NOSYNC_VD)
                {
                //  power saving TO DO : wait for API from ken.chang
                }
            }
            #endif

            #if (ENABLE_ATV_VCHIP)
            if (E_OSD_MESSAGE_BOX == MApp_ZUI_GetActiveOSD() && (EN_MSGBOX_MODE_PASSWORD_INPUT == MApp_ZUI_ACT_GetMessageBoxMode()))
            {
                MApp_ZUI_ACT_ShutdownOSD();
                stSystemInfo[eWindow].u8PanelPowerStatus |= PANEL_POWER_BLUESCREEN;//force snow noise for tv source?
            }
            #endif

        #if ENABLE_ATV_MODE_SHOW_NO_SIGNAL
            if(IsSrcTypeATV(SYS_INPUT_SOURCE_TYPE(eWindow)))
            {
                SYS_SCREEN_SAVER_TYPE(eWindow) = EN_SCREENSAVER_NOSYNC_VD;
            }
            if (MApp_ZUI_GetActiveOSD() == E_OSD_SCREEN_SAVER)
            {
                MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_REPAINT_ALL);
            }
            else if (MApp_ZUI_GetActiveOSD() == E_OSD_EMPTY)
            {
                if(MApp_UiMenuFunc_CheckInputLockAudioVideo())
                {
                    MApp_BlockSys_ResetMsgbox2ScreenSaverTimer();
                    MApp_ZUI_ACT_StartupOSD(E_OSD_MESSAGE_BOX);
                    MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_SHOW_PASSWORD_INPUT_MSGBOX);
                }
                else
                {
                    MApp_ZUI_ACT_StartupOSD(E_OSD_SCREEN_SAVER);
                }
            }
        #endif
        #if ENABLE_CUS_3D_SOURCE_MEMORY
            bPreStatusHasSignal = FALSE;
        #endif
        }
    //}


    // Video frequency is changed. So mode handler will change mode.
    #if 1 // BY 20090722
    if( TRUE == msAPI_AVD_IsVideoFormatChanged()&&(msAPI_AVD_CheckStdDetStableCnt()== VD_STABLE_COUNT)) //&& (msAPI_AVD_CheckStdDetStableCnt()!= 0 || (_eCurrentTuningState != AFT_IDLE)))
    #else
    if( TRUE == msAPI_AVD_IsVideoFormatChanged() && (msAPI_AVD_CheckStdDetStableCnt()!= 0 || msAPI_Tuner_IsTuningProcessorBusy()))
    #endif
    {
        AVD_VideoStandardType eVideoStandard;

        #if (ENABLE_CUS_DBC && ENABLE_CUS_9WINDOWS_DETECT)
        MApi_XC_Sys_SetVideoPattern9WindowsFlag(FALSE);
        #endif

        msAPI_AVD_SetIsVideoFormatChangedAsFalse();//20100330EL

        eVideoStandard = msAPI_AVD_GetVideoStandard();
 #if 0//(TV_FREQ_SHIFT_CLOCK)
        if (IsSrcTypeATV(SYS_INPUT_SOURCE_TYPE(eWindow)))
        {
            if (bIsTuningProcessorBusy)
                msAPI_Tuner_Patch_TVShiftClk(DISABLE);
            else
                msAPI_Tuner_Patch_TVShiftClk(ENABLE);
        }
        else
        {
            msAPI_Tuner_Patch_ResetTVShiftClk();
        }
#endif
#if ENABLE_VD_PACH_IN_CHINA
       if(stGenSetting.g_FactorySetting.COMBPATCH)
        {
            MApp_ATVProc_ResetPatch(eVideoStandard);
        }
#endif
        switch( eVideoStandard )
        {
           case E_VIDEOSTANDARD_PAL_BGHI:
                mvideo_vd_set_videosystem(SIG_PAL);
                break;
           case E_VIDEOSTANDARD_NTSC_M:
                mvideo_vd_set_videosystem(SIG_NTSC);
                break;
           case E_VIDEOSTANDARD_SECAM:
               mvideo_vd_set_videosystem(SIG_SECAM);
               break;
           case E_VIDEOSTANDARD_NTSC_44:
               mvideo_vd_set_videosystem(SIG_NTSC_443);
               break;
           case E_VIDEOSTANDARD_PAL_M:
               mvideo_vd_set_videosystem(SIG_PAL_M);
               break;
           case E_VIDEOSTANDARD_PAL_N:
               mvideo_vd_set_videosystem(SIG_PAL_NC);
               break;
           case E_VIDEOSTANDARD_PAL_60:
               mvideo_vd_set_videosystem(SIG_NTSC_443);
               break;
           default:
              mvideo_vd_set_videosystem(SIG_PAL);
              break;
        }

        MApp_VD_SetMode(eWindow);
        if (TRUE == msAPI_AVD_IsSyncLocked())
        {
          MApp_Scaler_SetWindow(NULL, NULL, NULL,
                MApp_Scaler_GetAspectRatio(ST_VIDEO.eAspectRatio), SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW), MAIN_WINDOW);
            if (MApp_ZUI_GetActiveOSD() == E_OSD_EMPTY)
            {
                MApp_ZUI_ACT_StartupOSD(E_OSD_CHANNEL_INFO);
                if (E_INPUT_SOURCE_ATV == msAPI_AVD_GetVideoSource())
                {
                    MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_SHOW_BRIEF_CH_INFO);
                }
                else
                {
                    MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_SHOW_SOURCE_BANNER);
                    #if (ENABLE_3D_PROCESS&&(ENABLE_CUS_3D_SOURCE_MEMORY == DISABLE))
                    MApp_Scaler_Close3DFunction();
                    #endif
                }
            }
            else  if (MApp_ZUI_GetActiveOSD() == E_OSD_CHANNEL_INFO)
            {
                if (E_INPUT_SOURCE_ATV == msAPI_AVD_GetVideoSource())
                {
                    MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_SHOW_BRIEF_CH_INFO);
                }
                else
                {
                  //  MApp_ZUI_API_ShowWindow(HWND_CHINFO_PIP_SRC1_INFO_AREA, SW_HIDE);
                    MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_SHOW_SOURCE_BANNER);
                }
            }
            else if (MApp_ZUI_GetActiveOSD() == E_OSD_MAIN_MENU)
            {
                if(MApp_ZUI_API_IsSuccessor(HWND_MENU_PICTURE_PAGE_LIST, MApp_ZUI_API_GetFocus()))
                {
                    HWND hwndTemp;
                    hwndTemp = MApp_ZUI_API_GetFocus();
                    MApp_ZUI_CTL_DynamicListRefreshContent(HWND_MENU_PICTURE_PAGE_LIST);
                    if((hwndTemp == HWND_MENU_PICTURE_ITEM_TINT) &&((mvideo_vd_get_videosystem() != SIG_NTSC) && (mvideo_vd_get_videosystem() != SIG_NTSC_443)))
                    {
                        MApp_ZUI_API_SetFocus(HWND_MENU_PICTURE_PICMODE);
                    }
                    else
                    {
                        MApp_ZUI_API_SetFocus(hwndTemp);
                    }
                }
                else if(MApp_ZUI_API_GetFocus() == HWND_MENU_TOP_ICON_PICTURE)
                {
                    MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_PICTURE,FALSE);
                    MApp_ZUI_CTL_DynamicListRefreshContent(HWND_MENU_PICTURE_PAGE_LIST);
                    MApp_ZUI_API_SetFocus(HWND_MENU_PICTURE_PICMODE);
                }
                else if(MApp_ZUI_API_GetFocus() == HWND_MENU_PICTURE_ADJUST_BAR)
                {
                    if(prePictureHWND == HWND_MENU_PICTURE_ITEM_TINT)
                    {
                        prePictureHWND = HWND_MENU_PICTURE_ITEM_BRIGHTNESS;

                    }
                    MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_PICTURE_ADJUST_BAR);
                }
            }
        }
        else
        {
          #if 0//(TV_FREQ_SHIFT_CLOCK)
            msAPI_Tuner_Patch_TVShiftClk(DISABLE);
          #endif
          #if (ENABLE_3D_PROCESS&&(ENABLE_CUS_3D_SOURCE_MEMORY == DISABLE))
            MApp_Scaler_Close3DFunction();
          #endif

        }

#if ENABLE_TTX
        msAPI_TTX_SetVideoStandard(eVideoStandard);
#endif
        #if (ENABLE_PIP)
        if( (IsPIPEnable()==FALSE) || UI_IS_AUDIO_SOURCE_IN(eWindow) )
        #endif
        {
            if(!MApi_XC_IsBlackVideoEnable(eWindow))
            {
                msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_PERMANENT_MUTEOFF, E_AUDIOMUTESOURCE_ACTIVESOURCE);
            }
        }
#if ENABLE_IP_AUTO_COAST
        MApi_XC_EnableIPCoastDebounce();
#endif
    }

    // Video input is changed.
    if( FALSE == bIsTuningProcessorBusy && TRUE == msAPI_AVD_IsVideoInputChanged() )
    {
        if( (E_INPUT_SOURCE_ATV == msAPI_AVD_GetVideoSource()
         || E_INPUT_SOURCE_ATV == msAPI_AVD_GetVideoSource())
         && (TRUE == msAPI_AVD_IsAutoAVActive(E_AUTOAV_SOURCE_ALL)) )
        {

        }
        else if( E_INPUT_SOURCE_CVBS1 == msAPI_AVD_GetVideoSource()
              || E_INPUT_SOURCE_CVBS2 == msAPI_AVD_GetVideoSource()
              || E_INPUT_SOURCE_SVIDEO1 == msAPI_AVD_GetVideoSource()
              || E_INPUT_SOURCE_SVIDEO2 == msAPI_AVD_GetVideoSource() )
        {

        }
    }
#if(PATCH_FOR_V_RANGE)
        if(IsSrcTypeATV(SYS_INPUT_SOURCE_TYPE(eWindow)))
            MApp_VD_StartRangeHandle();
#endif
#if ENABLE_TTX
    // Teletext is turned off suddenly.
    if( FALSE == bIsTuningProcessorBusy && TRUE == MApp_TTX_IsTeletextOffSuddenly() )
    {
        MApp_TTX_TeletextCommand(TTX_TV);
    }
#endif

    // Detect WSS (widescreen signalling) singal. Change ARC if WSS changed.
    if( FALSE == bIsTuningProcessorBusy
     && TRUE == msAPI_AVD_IsAspectRatioChanged()
     && EN_AspectRatio_Original == ST_VIDEO.eAspectRatio
     && IsSrcTypeDigitalVD( SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW) )
     ) //Support WSS only in original ARC of picture mode
    {
        EN_ASPECT_RATIO_TYPE eVideoARCType; //ARC type on "SCREEN" ( Result ARC )
        ASPECT_RATIO_TYPE     eWSSARCType;  //ARC type come from input source
        // Retrieve WSS type from Video decoder.
        eWSSARCType = msAPI_AVD_GetAspectRatioCode();

        //In channel edit screen, need to use FULL screen mode
        if (MApp_ZUI_GetActiveOSD()==E_OSD_PROGRAM_EDIT)
        {
            eVideoARCType = VIDEOSCREEN_FULL;
        }
        else if ((g_IPanel.AspectRatio()!=E_PNL_ASPECT_RATIO_WIDE) )
        {   //WSS only for wide panel
            eVideoARCType = VIDEOSCREEN_NORMAL;
        }
        else
        {
            switch(eWSSARCType)
            {
            case ARC4x3_FULL:
                eVideoARCType  =   VIDEOSCREEN_NORMAL;
                break;

            case ARC14x9_LETTERBOX_CENTER:
            case ARC14x9_FULL_CENTER:
                    eVideoARCType = VIDEOSCREEN_WSS_14by9_LETTERBOX_CENTER;
                    break;
                case ARC14x9_LETTERBOX_TOP:
                    eVideoARCType = VIDEOSCREEN_WSS_14by9_LETTERBOX_TOP;
                break;
            case ARC16x9_LETTERBOX_CENTER:
            case ARC_ABOVE16x9_LETTERBOX_CENTER:
                    eVideoARCType = VIDEOSCREEN_WSS_16by9_LETTERBOX_CENTER;
                    break;
                case ARC16x9_LETTERBOX_TOP:
                    eVideoARCType = VIDEOSCREEN_WSS_16by9_LETTERBOX_TOP;
                break;

            case ARC16x9_ANAMORPHIC:
                eVideoARCType = VIDEOSCREEN_FULL;
                break;

            case ARC_INVALID:
            default:
                eVideoARCType = VIDEOSCREEN_NORMAL;
                break;
            }
        }

       // if(IsSrcTypeATV(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)))
        {
            stSystemInfo[MAIN_WINDOW].enAspectRatio = eVideoARCType;
            MApp_Scaler_SetWindow(NULL, NULL, NULL,
                                           stSystemInfo[MAIN_WINDOW].enAspectRatio, SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW), MAIN_WINDOW);
        }

    }

    if( FALSE == bIsTuningProcessorBusy && TRUE == msAPI_AVD_IsScart1SourceTypeChanged() )
    {
    }
}

void MApp_ATVProc_ResetPatch(AVD_VideoStandardType eVideoStandard)
		{
   #if(COMB_2D3D_SWITCH_PATCH)  //For FT unstable Htotal channel in Shanghai 20101013        {
            g_ucComb3DSpModeEnable = 0;
            g_ucComb3DSpModeCnt = 0;
            g_ucComb3DSpModeDecCnt = 0;
            g_Comb1msCounter = 3500;

           if ( IsATVInUse() &&
            ((eVideoStandard==E_VIDEOSTANDARD_PAL_BGHI)||
             (eVideoStandard==E_VIDEOSTANDARD_NTSC_M)) )
           {
               //printf("~~~ Now is ATV and PAL or NTSC ~~~ \n");
               MDrv_WriteByte(0x1036C0, 0x6C);
               MDrv_WriteByte(0x1036C4, 0x81);
               MDrv_WriteByte(0x103610, 0x17);
           }
           MDrv_AVD_Set2D3DPatchOnOff(FALSE);  //enable auto 2D/3D switch
        //printf(">> MDrv_AVD_Set2D3DPatchOnOff OFF\n");
   #else
         eVideoStandard=eVideoStandard;
   #endif
		}

EN_ATV_SYSTEM_TYPE MApp_ATVProc_GetAudioSystem(AUDIOSTANDARD_TYPE eAudioStandard)
{
#if ( ENABLE_DVB_TAIWAN_APP || ENABLE_SBTVD_BRAZIL_APP || (TV_SYSTEM == TV_NTSC) )
    EN_ATV_SYSTEM_TYPE u8AudioSystem=EN_ATV_SystemType_M;
#elif (ENABLE_DTMB_CHINA_APP || ENABLE_ATV_CHINA_APP || ENABLE_DVBC_PLUS_DTMB_CHINA_APP)
    EN_ATV_SYSTEM_TYPE u8AudioSystem=EN_ATV_SystemType_DK;
#else
    EN_ATV_SYSTEM_TYPE u8AudioSystem=EN_ATV_SystemType_BG;
#endif
    switch (eAudioStandard)
    {
        case E_AUDIOSTANDARD_BG:
        case E_AUDIOSTANDARD_BG_A2:
        case E_AUDIOSTANDARD_BG_NICAM:
            u8AudioSystem = EN_ATV_SystemType_BG;
            break;

        case E_AUDIOSTANDARD_I:
            u8AudioSystem = EN_ATV_SystemType_I;
            break;

        case E_AUDIOSTANDARD_DK:
        case E_AUDIOSTANDARD_DK1_A2:
        case E_AUDIOSTANDARD_DK2_A2:
        case E_AUDIOSTANDARD_DK3_A2:
        case E_AUDIOSTANDARD_DK_NICAM:
            u8AudioSystem = EN_ATV_SystemType_DK;
            break;

    #if ( ENABLE_DTMB_CHINA_APP || ENABLE_DVB_TAIWAN_APP || ENABLE_ATV_CHINA_APP || ENABLE_SBTVD_BRAZIL_APP || ENABLE_DVBC_PLUS_DTMB_CHINA_APP || (TV_SYSTEM == TV_NTSC) )
        case E_AUDIOSTANDARD_M:
        case E_AUDIOSTANDARD_M_BTSC:
        case E_AUDIOSTANDARD_M_A2:
        case E_AUDIOSTANDARD_M_EIA_J:
            u8AudioSystem = EN_ATV_SystemType_M;
            break;
    #else
        case E_AUDIOSTANDARD_L:
            u8AudioSystem = EN_ATV_SystemType_L;
            break;
    #endif
        default:
            break;
    }
   return  u8AudioSystem;
}

