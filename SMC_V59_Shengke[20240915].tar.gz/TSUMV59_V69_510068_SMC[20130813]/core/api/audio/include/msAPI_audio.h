#ifndef _MSAPI_AUDIO_C_H
#define _MSAPI_AUDIO_C_H

#include "drvAUDIO.h"
#include "apiAUDIO.h"
#include "sys_sif_debug.h"
#include "msAPI_Global.h"

#ifdef _MSAPI_AUDIO_C_
#define INTERFACE
#else
#define INTERFACE extern
#endif

#define SUPPORT_PEQ_TOOL 0
#define PEQ_BANDS 3
#define MTS_NICAM_UNSTABLE 0    //For NICAM Unstable issue in Indonesia

typedef enum
{
    SOUND_MUTE_TV,             ///< SPEAKER/HP Sound Mute
    SOUND_MUTE_SPEAKER,   ///< SPEAKER Sound Mute
    SOUND_MUTE_HP,             ///< HP Sound Mute
    SOUND_MUTE_SCART,      ///< Scart1 Sound Mute
    SOUND_MUTE_SCART2,      ///< Scart2 Sound Mute
    SOUND_MUTE_MONITOR_OUT, ///< Monitor Sound Mute
    SOUND_MUTE_SPDIF,       ///< SPDIF Sound Mute
    SOUND_MUTE_AMP,        ///< Mute Amp
    SOUND_MUTE_ALL_EXCEPT_SCART,    ///< All Source Sound Mute except SCART
    SOUND_MUTE_ALL          ///< All Source Sound Mute
} SOUND_MUTE_SOURCE;

typedef enum
{
    E_MUTE_OFF, //Sound Mute Off
    E_MUTE_ON,  //Sound Mute On
} SOUND_MUTE_TYPE;

//-----------------------------------------------------------
//Adjust factor for TV/AV
typedef enum
{
//---Common interfaces for both Program storage type and Channel storage type---
    E_ADJUST_VIDEOMUTE,                             ///< Video mute
    E_ADJUST_VIDEOMUTE_DURING_LIMITED_TIME,       ///< Video mute during limited time
    E_ADJUST_BRIGHTNESS,                            ///< brightness
    E_ADJUST_CONTRAST,                              ///< contrast
    E_ADJUST_COLOR,                              ///< color
    E_ADJUST_HUE,                              ///< Hue
    E_ADJUST_SHARPNESS,                              ///< sharpness
    E_ADJUST_PSM,                              ///< PSM
    E_ADJUST_CSM,                              ///< CSM
//-- above items are non-used -----------------------------------------------------
    E_ADJUST_WRITE_MAILBOX,                ///< write mailbox (for MHEG5 Audio)
    E_ADJUST_INTERRUPT_MAD,                //< interrupt mad  (for MHEG5 Audio)
    E_ADJUST_AUDIOMUTE,                         ///< audio mute
    E_ADJUST_AUDIOMUTE_DURING_LIMITED_TIME,   ///< audio mute during limited time
    E_ADJUST_VOLUME,                        ///< volume
    E_ADJUST_VOLUME_IN_MUTE,
    E_ADJUST_SURROUND,                        ///< surround
    E_ADJUST_AVL,                        ///< AVL
    E_ADJUST_TREBLE,                        ///< Treble
    E_ADJUST_BASS,                        ///< Bass
    E_ADJUST_BALANCE,                        ///< Balance
    E_ADJUST_SET_AUDIOMODE,                ///< Set audio mode
    E_ADJUST_CHANGE_AUDIOMODE,             ///< Change Audio mode
    E_ADJUST_EQUALIZER_BAND,               ///< Equalizer band
    E_ADJUST_SRSWOW,                        ///< SRSWOW
    E_ADJUST_RESET_AUDIOMODE,              ///< Reset audio mode
    E_ADJUST_CHANGE_AUDIOSOURCE,          ///< change audio source
} ADJUST_TVAVFACTOR;

typedef enum
{
    E_AUDIO_PERMANENT_MUTEOFF                = 0x00,
    E_AUDIO_PERMANENT_MUTEON                 = 0x01,
    E_AUDIO_MOMENT_MUTEOFF                   = 0x10,
    E_AUDIO_MOMENT_MUTEON                    = 0x11,
    E_AUDIO_BYUSER_MUTEOFF                   = 0x20,
    E_AUDIO_BYUSER_MUTEON                    = 0x21,
    E_AUDIO_BYSYNC_MUTEOFF                   = 0x30,
    E_AUDIO_BYSYNC_MUTEON                    = 0x31,
    E_AUDIO_BYVCHIP_MUTEOFF                  = 0x40,
    E_AUDIO_BYVCHIP_MUTEON                   = 0x41,
    E_AUDIO_BYBLOCK_MUTEOFF                  = 0x50,
    E_AUDIO_BYBLOCK_MUTEON                   = 0x51,
    E_AUDIO_INTERNAL_1_MUTEOFF               = 0x60,
    E_AUDIO_INTERNAL_1_MUTEON                = 0x61,
    E_AUDIO_INTERNAL_2_MUTEOFF               = 0x70,
    E_AUDIO_INTERNAL_2_MUTEON                = 0x71,
    E_AUDIO_INTERNAL_3_MUTEOFF               = 0x80,
    E_AUDIO_INTERNAL_3_MUTEON                = 0x81,
    E_AUDIO_INTERNAL_4_MUTEOFF               = 0x82,
    E_AUDIO_INTERNAL_4_MUTEON                = 0x83,
    E_AUDIO_DURING_LIMITED_TIME_MUTEOFF      = 0x90,
    E_AUDIO_DURING_LIMITED_TIME_MUTEON       = 0x91,
    E_AUDIO_MHEGAP_MUTEOFF                   = 0xA0,
    E_AUDIO_MHEGAP_MUTEON                    = 0xA1,
    E_AUDIO_CI_MUTEOFF                      = 0xB0,
    E_AUDIO_CI_MUTEON                       = 0xB1
} AUDIOMUTETYPE;

// Audio source type
typedef enum
{
    E_AUDIOSOURCE_MPEG,            ///< Audio source MPEG
    E_AUDIOSOURCE_AC3,             ///< Audio source AC3
    E_AUDIOSOURCE_ATV,             ///< Audio source ATV
    E_AUDIOSOURCE_CVBS1,           ///< Audio source CVBS1
    E_AUDIOSOURCE_CVBS2,           ///< Audio source CVBS2
    E_AUDIOSOURCE_CVBS3,           ///< Audio source CVBS3
    E_AUDIOSOURCE_SVIDEO1,         ///< Audio source SVideo1
    E_AUDIOSOURCE_SVIDEO2,         ///< Audio source SVideo2
    E_AUDIOSOURCE_SCART1,          ///< Audio source SCART1
    E_AUDIOSOURCE_SCART2,          ///< Audio source SCART2
    E_AUDIOSOURCE_PC,              ///< Audio source PC
    E_AUDIOSOURCE_YPbPr,           ///< Audio source YPbPr
    E_AUDIOSOURCE_YPbPr2,          ///< Audio source YPbPr
    E_AUDIOSOURCE_HDMI,            ///< Audio source HDMI
    E_AUDIOSOURCE_HDMI2,           ///< Audio source HDMI
    E_AUDIOSOURCE_HDMI3,           ///< Audio source HDMI
    E_AUDIOSOURCE_DVI,             ///< Audio source HDMI
    E_AUDIOSOURCE_DVI2,            ///< Audio source HDMI
    E_AUDIOSOURCE_DVI3,            ///< Audio source HDMI

    E_AUDIOSOURCE_INVALID          ///< Invalid Audio source
} AUDIOSOURCE_TYPE;


typedef enum
{
    E_AUDIOMUTESOURCE_MPEG         = E_AUDIOSOURCE_MPEG,
    E_AUDIOMUTESOURCE_AC3          = E_AUDIOSOURCE_AC3,
    E_AUDIOMUTESOURCE_ATV          = E_AUDIOSOURCE_ATV,
    E_AUDIOMUTESOURCE_CVBS1        = E_AUDIOSOURCE_CVBS1,
    E_AUDIOMUTESOURCE_CVBS2        = E_AUDIOSOURCE_CVBS2,
    E_AUDIOMUTESOURCE_SVIDEO1      = E_AUDIOSOURCE_SVIDEO1,
    E_AUDIOMUTESOURCE_SVIDEO2      = E_AUDIOSOURCE_SVIDEO2,
    E_AUDIOMUTESOURCE_SCART1       = E_AUDIOSOURCE_SCART1,
    E_AUDIOMUTESOURCE_SCART2       = E_AUDIOSOURCE_SCART2,
    E_AUDIOMUTESOURCE_PC           = E_AUDIOSOURCE_PC,
    E_AUDIOMUTESOURCE_YPbPr        = E_AUDIOSOURCE_YPbPr,
    E_AUDIOMUTESOURCE_HDMI         = E_AUDIOSOURCE_HDMI,
    E_AUDIOMUTESOURCE_ACTIVESOURCE = 0xFF
} AUDIOMUTESOURCE_TYPE;


#define ENABLE_CHANNEL_CHANGE_MUTE_ON_OFF_DELAY 0

//****************************************************************************
// Public attributes.
//****************************************************************************
extern AUDIOSOURCE_TYPE m_eAudioSource;

//============================================================
// AUDIO_SYSTEM RELATIONAL API FUNCTION
//============================================================
//INTERFACE void msAPI_AuSetPowerOn(BOOLEAN bFlag);
INTERFACE void msAPI_AUD_InitAudioSystem(THR_TBL_TYPE code *ThrTbl);
INTERFACE void msAPI_AUD_AdjustAudioFactor(ADJUST_TVAVFACTOR eFactor, WORD wParam1, WORD wParam2);
INTERFACE BOOLEAN msAPI_AUD_IsAudioMuted(void);
INTERFACE BOOLEAN msAPI_AUD_IsAudioMutedByUser(void);
INTERFACE void msAPI_AUD_CheckExpirationOfAudioMute(void);
#if (ENABLE_CHANNEL_CHANGE_MUTE_ON_OFF_DELAY)
INTERFACE void msAPI_AUD_SetByPassDelayFlag(BOOLEAN flag);
#endif
INTERFACE void msAPI_AUD_SwitchAduioDSPSystem(AUDIO_DSP_SYSTEM eAudioDSPSystem);

//============================================================
// AUDIO_ATV RELATIONAL API FUNCTION
//============================================================
INTERFACE AUDIOSTANDARD_TYPE msAPI_AUD_GetAudioStandard(void);
INTERFACE void msAPI_AUD_SetAudioStandard(AUDIOSTANDARD_TYPE eStandard);
INTERFACE void msAPI_AUD_ForceAudioStandard(AUDIOSTANDARD_TYPE eStandard);
INTERFACE AUDIOSOURCE_TYPE msAPI_AUD_GetAudioSource(void);
INTERFACE AUDIOSTANDARD_TYPE msAPI_AUD_GetResultOfAutoStandardDetection(void);
INTERFACE void msAPI_AUD_ForceAudioMode(AUDIOMODE_TYPE eAudioMode);
INTERFACE AUDIOMODE_TYPE msAPI_AUD_ChangeAudioMode(void);
INTERFACE BOOLEAN msAPI_AUD_IsAudioModeChanged(void);
INTERFACE void msAPI_AUD_EnableRealtimeAudioDetection(BOOLEAN bEnable);
INTERFACE BOOLEAN msAPI_AUD_IsEnableRealtimeAudioDetection(void);
INTERFACE BOOLEAN msAPI_AUD_IsAudioDetected(void);

//=============================================================
// AUDIO_HDMI RELATIONAL API FUNCTION
//=============================================================
INTERFACE void msAPI_AUD_HDMI_SetNonpcm(BYTE nonPCM_en);


//=============================================================
// AUDIO_SPDIF RELATIONAL API FUNCTION
//=============================================================
INTERFACE void msAPI_AUD_SPDIF_SetSCMS(MS_U8 C_bit_en, MS_U8 L_bit_en);
INTERFACE MS_U8 msAPI_AUD_SPDIF_GetSCMS(void);

//=============================================================
// AUDIO_SOUND RELATIONAL API FUNCTION
//=============================================================
INTERFACE void MApi_AUDIO_SetMute( U8 u8Path, BOOLEAN EnMute);
INTERFACE void MApi_AUDIO_AseSetBinAddress(MS_U8 u8Index, MS_U32 BinAddr);
INTERFACE void MApi_AUDIO_SetNormalPath(AUDIO_PATH_TYPE path, AUDIO_INPUT_TYPE input, AUDIO_OUTPUT_TYPE output);

//=============================================================
// AUDIO_OTHERS FUNCTION (Temp)
//=============================================================
void msAPI_AUD_SetAudioSource(AUDIOSOURCE_TYPE eSource);
void msApi_AUD_SIF_Shift(En_AUD_VIF_Type type);

//=============================================================
// AUDIO_Miscellany FUNCTION
//=============================================================
void msAPI_AUD_I2S_Amp_Reset(void);
void msAPI_AUD_I2S_Amp_UnReset(void);
void msAPI_AUD_SW_Reset(void);

//=============================================================
// AUDIO_Miscellany FUNCTION
//=============================================================
INTERFACE void MW_AUD_AudioProcessor(void);
INTERFACE void MW_AUD_GetBinAddress(void);
INTERFACE void MW_AUD_SetSoundMute(SOUND_MUTE_SOURCE eSoundMuteSource, SOUND_MUTE_TYPE eOnOff);
INTERFACE void msAPI_AUD_SetPEQ(MS_U8 Band, MS_U8 Gain, MS_U8 Foh, MS_U8 Fol, MS_U8 QValue);

//=============================================================
#ifdef CUS_AUDIO_TREBLE_BASS_LIMIT
INTERFACE void MApi_AUDIO_SetBassLimit (MS_U8 u8Bass);
INTERFACE void MApi_AUDIO_SetTrebleLimit (MS_U8 u8Treble);
#endif
#ifdef ENABLE_CUS_AUTO_AUDIO_SYSTEM_DETECT
INTERFACE void msAPI_AUD_ATV_BeginAudioSystemAutoDetect(BOOLEAN bIsBegin);
INTERFACE BOOLEAN msAPI_AUD_ATV_IsBeginAudioSystemAutoDetect(void);
INTERFACE void msAPI_AUD_ATV_AudioSystemAutoDetect(U32 u32CheckDelay);
#endif

#undef INTERFACE
#endif
