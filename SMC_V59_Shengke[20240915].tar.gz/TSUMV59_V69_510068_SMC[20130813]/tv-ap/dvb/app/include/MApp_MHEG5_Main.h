////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MApp_MHEG5_MAIN_H_
#define _MApp_MHEG5_MAIN_H_

#include "datatype.h"
#include "MApp_GlobalVar.h"
#include "MApp_IR.h"
#include "MApp_Key.h"
#include "MApp_MultiTasks.h"
#include "apiGOP.h"
//ZUI_TODO: #include "MApp_UiMenu.h"
#include "msAPI_IR.h"
#include "mapp_iframe.h"
#include "msAPI_MHEG5.h"
#include "apiGOP.h"
#include "MApp_Exit.h"

#undef INTERFACE
#ifdef _MAPP_MHEG5_MAIN_C_
#define INTERFACE
#else
#define INTERFACE extern
#endif

#if MHEG5_ENABLE
typedef enum
{
    STATE_MHEG5_INIT,
    STATE_MHEG5_WAIT,
    STATE_MHEG5_CHANNEL_CHANGE,
    STATE_MHEG5_TO_MENU,
    STATE_MHEG5_WITH_OSD,
    STATE_MHEG5_EXIT,
    STATE_MHEG5_MENU_EXIT,
    STATE_MHEG5_NONE,
} EN_MHEG5_STATE;

typedef enum
{
    GE_CONTROL_BY_MUTEX,
    GE_CONTROL_BY_SEMAPHORE,
    GE_CONTROL_BY_NONE,
} EN_MHEG5_GE_RESOURCE_CONTROL;



typedef enum
{
    EN_MHEG5_EM_BACKGROUND_LOADING,
    EN_MHEG5_EM_AUTOBOOT,

}EN_MHEG5_ENABLE_MODE;

typedef enum
{
    EN_MHEG5_DM_DISABLE_AND_STOPDSMCC,
    EN_MHEG5_DM_DISABLE_WITH_AUTOBOOT_LATER,
    EN_MHEG5_DM_DISABLE,
    EN_MHEG5_DM_DISABLE_AND_WAIT

}EN_MHEG5_DISABLE_MODE;

#if INTERACTION_CHANNEL
#define MHEG5IC_CHECKSERVER_STATUS    1
#define MHEG5IC_GETDATA_BY_GET           2
#define MHEG5IC_GETDATA_BY_POST           3
#define DIGEST_LENGTH 20
#endif

#define MHEG_WAIT_AEON_TIMEOUT  300

#if (MHEG5_X_STRETCH_WAY == MHEG5_USE_GOP_STRETCH)
 #if GOP_SCALERATIO_FIXED
  #define MHEG_OS_FB_WIDTH    ((g_IPanel.Width()+7)& ~7)/2
 #elif GOP_SCALERATIO_FIXED2
  #define MHEG_OS_FB_WIDTH MHEG_XRES
 #else
  #define MHEG_OS_FB_WIDTH MHEG_XRES
 #endif
#else
  #define MHEG_OS_FB_WIDTH    g_IPanel.Width()
 #endif

 #if (MHEG5_Y_STRETCH_WAY == MHEG5_USE_GOP_STRETCH)
  #if GOP_SCALERATIO_FIXED2
   #define MHEG_OS_FB_HEIGHT   MHEG_YRES
  #else
   #define MHEG_OS_FB_HEIGHT   ((g_IPanel.Height()+7)& ~7)/2//MHEG_YRES
  #endif
 #else
  #define MHEG_OS_FB_HEIGHT   g_IPanel.Height()
#endif

#if INTERACTION_CHANNEL
typedef struct Digest
{
    U8 digest_type;
    U8 name_count;
    U8 digest_byte[DIGEST_LENGTH];
} Digest;

typedef struct HashName
{
    U8 NameLength;
    char NameByte[500];
} HashName;
#endif
#if ENABLE_PVR
INTERFACE BOOLEAN gbPVRSetModeWhenExitMheg5;
#endif
//prototype
INTERFACE BOOLEAN MApp_MHEG5_Init(void);
INTERFACE void MApp_MHEG5_Force_Exit(void);
INTERFACE void MApp_MHEG5_Update_Program(U16 video, U16 audio, U16 audioType, VDEC_CodecType eVideoType  );
INTERFACE void MApp_MHEG5_SignalMonitor(void);
INTERFACE void MApp_MHEG5_RestoreWindow(U8 u8DoScreenMute);
// do processing MHEG in multitask
INTERFACE void _MApp_MHEG5_Process(void);
INTERFACE void MApp_MHEG5_RestoreOriginalAV(void);
INTERFACE void MApp_MHEG5_SetGoMHEG5Process(BOOLEAN bEnable);
INTERFACE BOOLEAN MApp_MHEG5_CheckGoMHEG5Process(void);

INTERFACE void MApp_MHEG5_Set_Display(bool bEnable, bool bRestoreVideoWindowSize);
INTERFACE void MApp_MHEG5_SetGraphARCInfo(U8 u8Flag ,EN_ASPECT_RATIO_TYPE enVideoScreen);

//========================================
//MHEG5 API for other APP.
//========================================
INTERFACE BOOLEAN MApi_MHEG5_Enable(EN_MHEG5_ENABLE_MODE EnableMode);
INTERFACE BOOLEAN MApi_MHEG5_Disable(EN_MHEG5_DISABLE_MODE DisableMode);
//========================================
//MHEG5 CallBack function for other GOP re-arrange.
//========================================
INTERFACE void MApp_MHEG5_fpGOP_CB(MS_U32 u32EventID, void* reserved0);

#if INTERACTION_CHANNEL
INTERFACE U16 MApp_MHEG5_Init_Net(unsigned char *ICStrAddr, unsigned char *FullICStrAddr, U8 item);
U16 MApp_MHEG5_CheckServer_Status(char *ICStraddr);
U16 MApp_MHEG5_Connect_Server(char *ICStraddr, int *st);
U16 MApp_MHEG5_Send_And_Recv(char *dest, char *ReqStr, int *nRet, int *st, int RecvSize);
bool MApp_MHEG5_Get_ReturnStatus(unsigned char *tempstr, U16 *ReturnStatus);
#endif

#endif
#undef INTERFACE
#endif  // _MApp_MHEG5_MAIN_H_
