////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#define MAPP_ATV_MANUALTUNING_MAIN_C

/******************************************************************************/
/*                 Header Files                                               */
/* ****************************************************************************/
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "Board.h"
#include "datatype.h"
#include "MsCommon.h"
#include "apiXC.h"
#include "apiXC_Adc.h"
#include "msAPI_Global.h"

#include "MApp_Exit.h"
#include "MApp_Key.h"
#include "MApp_GlobalSettingSt.h"
#include "MApp_UiMenuDef.h"
#include "MApp_ZUI_Main.h"
#include "ZUI_tables_h.inl"
#include "MApp_ATV_ManualTuning_Main.h"

///////////////////////////////////////////////////////////

EN_ATV_MANUALTUNING_STATE enAtvManualTuningState;

//////////////////////////////////////////////////////////

EN_RET MApp_ATV_ManualTuning_Main(void)
{
    EN_RET enRetVal = EXIT_NULL;

    switch(enAtvManualTuningState)
    {
        case STATE_ATV_MANUALTUNING_INIT:
            MApp_ZUI_ACT_StartupOSD(E_OSD_ATV_MANUAL_TUNING);
            enAtvManualTuningState = STATE_ATV_MANUALTUNING_WAIT;
            break;

        case STATE_ATV_MANUALTUNING_WAIT:
            MApp_ZUI_ProcessKey(u8KeyCode);
            u8KeyCode = KEY_NULL;
            break;

        case STATE_ATV_MANUALTUNING_CLEAN_UP:
            MApp_ZUI_ACT_ShutdownOSD();
            enAtvManualTuningState = STATE_ATV_MANUALTUNING_INIT;
            enRetVal = EXIT_CLOSE;
            break;

        case STATE_ATV_MANUALTUNING_GOTO_STANDBY:
            MApp_ZUI_ACT_ShutdownOSD();
            u8KeyCode = KEY_POWER;
            enRetVal = EXIT_GOTO_STANDBY;
            break;

        case STATE_ATV_MANUALTUNING_GOTO_MAIN_MENU:
            MApp_ZUI_ACT_ShutdownOSD();
            enAtvManualTuningState = STATE_ATV_MANUALTUNING_INIT;
            enRetVal = EXIT_GOTO_MENU;
            break;

        case STATE_ATV_MANUALTUNING_GOTO_ATV_SCAN:
            enAtvManualTuningState = STATE_ATV_MANUALTUNING_WAIT;
            enRetVal = EXIT_GOTO_ATVSCAN;
            break;

        default:
            enAtvManualTuningState = STATE_ATV_MANUALTUNING_WAIT;
            break;
    }
    return enRetVal;
}

#undef MAPP_ATV_MANUALTUNING_MAIN_C

