////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2008 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#define _MSAPI_DATA_STREAM_IO_C_
///////////////////////////////////////////////////////////////////////////////
/// @file   msAPI_DataStreamIO.c
/// @author MStar Semiconductor Inc.
/// @brief  Data stream I/O Module
///////////////////////////////////////////////////////////////////////////////

//-------------------------------------------------------------------------------------------------
// Include Files
//-------------------------------------------------------------------------------------------------
#include "MsCommon.h"
#include "MsOS.h"

#include "msAPI_DataStreamIO.h"

#include "msAPI_FCtrl.h"
#include "msAPI_FSCommon.h"

//-------------------------------------------------------------------------------------------------
// Defines
//-------------------------------------------------------------------------------------------------


//-------------------------------------------------------------------------------------------------
// Type and Structure Declaration
//-------------------------------------------------------------------------------------------------


//-------------------------------------------------------------------------------------------------
// Macros
//-------------------------------------------------------------------------------------------------


//-------------------------------------------------------------------------------------------------
// Global Variables
//-------------------------------------------------------------------------------------------------


//-------------------------------------------------------------------------------------------------
// Local Variables
//-------------------------------------------------------------------------------------------------
static FN_DATA_STRM_IO _gStreamIOFunc, *_gpStreamIOFunc = NULL;

//-------------------------------------------------------------------------------------------------
// Local Function Prototypes
//-------------------------------------------------------------------------------------------------


//-------------------------------------------------------------------------------------------------
// Function Implementation
//-------------------------------------------------------------------------------------------------
U32 msAPI_DataStreamIO_Open(void *pPrivate, U8 u8Mode, E_DATA_STREAM_TYPE eType)
{
    U8 u8FileHdl;

    if (eType >= E_DATA_STREAM_TYPE_NUM)
    {
        return FALSE;
    }

    if (_gpStreamIOFunc == NULL)
    {
        // default
        u8FileHdl = msAPI_FCtrl_FileOpen((FileEntry *)pPrivate, u8Mode);
        return (u8FileHdl != INVALID_FILE_HANDLE ? (U32)u8FileHdl : INVALID_DATA_STREAM_HDL);
    }
    else
    {
        if (_gpStreamIOFunc->pfnOpen)
        {
            return _gpStreamIOFunc->pfnOpen(pPrivate, u8Mode, eType);
        }
    }

    return INVALID_DATA_STREAM_HDL;
}

BOOLEAN msAPI_DataStreamIO_Close(U32 u32Hdl)
{
    if (_gpStreamIOFunc == NULL)
    {
        // default
        return msAPI_FCtrl_FileClose((U8)u32Hdl) == FILE_CLOSE_RESULT_ERROR ? FALSE : TRUE;
    }
    else
    {
        if (_gpStreamIOFunc->pfnClose)
        {
            return _gpStreamIOFunc->pfnClose(u32Hdl);
        }
    }

    return FALSE;
}

U32 msAPI_DataStreamIO_Read(U32 u32Hdl, void *pBuffAddr, U32 u32Length)
{
    if (_gpStreamIOFunc == NULL)
    {
        // default
        return msAPI_FCtrl_FileRead((U8)u32Hdl, (U32)pBuffAddr, u32Length);
    }
    else
    {
        if (_gpStreamIOFunc->pfnRead)
        {
            return _gpStreamIOFunc->pfnRead(u32Hdl, pBuffAddr, u32Length);
        }
    }

    return u32Length;
}

BOOLEAN msAPI_DataStreamIO_Seek(U32 u32Hdl, U32 u32Pos, E_DATA_STREAM_SEEK_OPTION eOption)
{
    EN_FILE_SEEK_OPTION eFileSeekOpt;
    LongLong u64Pos;

    switch (eOption)
    {
        case E_DATA_STREAM_SEEK_SET:
        default:
            eFileSeekOpt = FILE_SEEK_SET;
            break;

        case E_DATA_STREAM_SEEK_CUR:
            eFileSeekOpt = FILE_SEEK_CUR;
            break;
    }

    if (_gpStreamIOFunc == NULL)
    {
        // default
        return msAPI_FCtrl_FileSeek((U8)u32Hdl, u32Pos, eFileSeekOpt);
    }
    else
    {
        u64Pos.Hi = 0;
        u64Pos.Lo = u32Pos;
        if (_gpStreamIOFunc->pfnSeek)
        {
            return _gpStreamIOFunc->pfnSeek(u32Hdl, u64Pos, eOption);
        }
    }

    return FALSE;
}

BOOLEAN msAPI_DataStreamIO_Seek_LongLong(U32 u32Hdl, LongLong u64Pos, E_DATA_STREAM_SEEK_OPTION eOption)
{
    EN_FILE_SEEK_OPTION eFileSeekOpt;

    switch (eOption)
    {
        case E_DATA_STREAM_SEEK_SET:
        default:
            eFileSeekOpt = FILE_SEEK_SET;
            break;

        case E_DATA_STREAM_SEEK_CUR:
            eFileSeekOpt = FILE_SEEK_CUR;
            break;
    }

    if (_gpStreamIOFunc == NULL)
    {
        // default
        return msAPI_FCtrl_FileSeek_LongLong((U8)u32Hdl, u64Pos, eFileSeekOpt);
    }
    else
    {
        if (_gpStreamIOFunc->pfnSeek)
        {
            return _gpStreamIOFunc->pfnSeek(u32Hdl, u64Pos, eOption);
        }
    }

    return FALSE;
}

U32 msAPI_DataStreamIO_Tell(U32 u32Hdl)
{
    LongLong u64Pos;

    if (_gpStreamIOFunc == NULL)
    {
        // default
        return msAPI_FCtrl_FileTell((U8)u32Hdl);
    }
    else
    {
        if (_gpStreamIOFunc->pfnTell)
        {
            u64Pos = _gpStreamIOFunc->pfnTell(u32Hdl);
            return u64Pos.Lo;
        }
    }

    return 0xFFFFFFFF;
}

LongLong msAPI_DataStreamIO_Tell_LongLong(U32 u32Hdl)
{
    LongLong u64Pos;

    if (_gpStreamIOFunc == NULL)
    {
        // default
        return msAPI_FCtrl_FileTell_LongLong((U8)u32Hdl);
    }
    else
    {
        if (_gpStreamIOFunc->pfnTell)
        {
            return _gpStreamIOFunc->pfnTell(u32Hdl);
        }
    }

    u64Pos.Hi = 0xFFFFFFFF;
    u64Pos.Lo = 0xFFFFFFFF;
    return u64Pos;
}

U32 msAPI_DataStreamIO_Length(U32 u32Hdl)
{
    LongLong u64Pos;

    if (_gpStreamIOFunc == NULL)
    {
        // default
        return msAPI_FCtrl_FileLength((U8)u32Hdl);
    }
    else
    {
        if (_gpStreamIOFunc->pfnLength)
        {
            u64Pos = _gpStreamIOFunc->pfnLength(u32Hdl);
            return u64Pos.Lo;
        }
    }

    return 0;
}

LongLong msAPI_DataStreamIO_Length_LongLong(U32 u32Hdl)
{
    LongLong u64Size;

    if (_gpStreamIOFunc == NULL)
    {
        // default
        return msAPI_FCtrl_FileLength_LongLong((U8)u32Hdl);
    }
    else
    {
        if (_gpStreamIOFunc->pfnLength)
        {
            return _gpStreamIOFunc->pfnLength(u32Hdl);
        }
    }

    u64Size.Hi = 0;
    u64Size.Lo = 0;
    return u64Size;
}

BOOLEAN msAPI_DataStreamIO_OptionRegistation(FN_DATA_STRM_IO *pfnIO)
{
    if (pfnIO == NULL)
    {
        _gpStreamIOFunc = NULL;
    }
    else
    {
        _gStreamIOFunc = *pfnIO;
        _gpStreamIOFunc = &_gStreamIOFunc;
    }

    return TRUE;
}

//-------------------------------------------------------------------------------------------------
// Local funcion -- misc functions
//-------------------------------------------------------------------------------------------------

#undef _MSAPI_DATA_STREAM_IO_C_

