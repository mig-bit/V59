////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#include "MApp_BT_config.h"

#if (ENABLE_THUNDER_DOWNLOAD)
#include "MApp_Thunder_Main.h"
#else

#ifndef _MAPP_BT_MAIN_H
#define _MAPP_BT_MAIN_H

#include "datatype.h"
#include "MApp_Exit.h"
#include "MApp_ZUI_APIcommon.h"

#ifdef MAPP_BT_MAIN_C
#define INTERFACE
#else
#define INTERFACE extern
#endif


typedef enum
{
    STATE_BT_INIT,
    STATE_BT_WAIT,
    STATE_BT_CLEAN_UP,
    STATE_BT_GOTO_STANDBY,
    STATE_BT_GOTO_MENU,
    STATE_BT_GOTO_INPUTSOURCE,
    STATE_BT_RETURN_FROM_MENU,
    STATE_BT_SEARCH_WAIT,
} EN_BT_STATE;

typedef enum
{
    TYPE_BT_TORRENT_SEARCH,
    TYPE_BT_TOP_10,
    TYPE_BT_NEW_10,
    TYPE_BT_DOWNLOAD_LIST,
    TYPE_BT_SETUP,
    TYPE_BT_INVALID=0xFF,
} EN_BT_PAGE_TYPE;

typedef enum
{
    E_BT_FLAG_NONE                     = 0,
    E_BT_FLAG_INITED                   = BIT0,
    E_BT_FLAG_LINK0PHOTO_MODE          = BIT1,
    E_BT_FLAG_LINK1PHOTO_MODE          = BIT2,
    E_BT_FLAG_FILE_DOWNLOADING         = BIT3,
} enumBTFlags;

typedef enum
{
    BT_SEARCH_STATE_INIT,
    BT_SEARCH_STATE_WAIT,
    BT_SEARCH_STATE_TIME_OUT,
    BT_SEARCH_STATE_NOTHING,
    BT_SEARCH_STATE_INPUT_SHOW,
    BT_SEARCH_STATE_INPUT_ERROR,
} EN_BT_SEARCH_STATE;

INTERFACE EN_BT_SEARCH_STATE enBTSearchState;
INTERFACE U32 u32MonitorBTSearchTimer;

INTERFACE EN_BT_STATE     enBTState;

INTERFACE EN_RET MApp_BT_Main(void);
INTERFACE void MApp_BT_SetLink0PhotoFlags(BOOLEAN bEnable);
INTERFACE void MApp_BT_SetLink1PhotoFlags(BOOLEAN bEnable);
INTERFACE enumBTFlags MApp_BT_GetBTFlags(void);
INTERFACE void MApp_BT_Main_Exit(void);
INTERFACE BOOLEAN MApp_BT_SearchWait_GetSearchResult(void);

#undef INTERFACE

#endif  // _MAPP_BT_MAIN_H

#endif //#if (ENABLE_THUNDER_DOWNLOAD)

