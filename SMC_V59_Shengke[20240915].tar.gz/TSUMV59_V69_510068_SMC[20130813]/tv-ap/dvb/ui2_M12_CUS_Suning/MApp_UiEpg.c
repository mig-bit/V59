////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#define MAPP_EPG_MAIN_C

/******************************************************************************/
/*                 Header Files                                               */
/* ****************************************************************************/
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#include "MsCommon.h"

#include "MApp_Exit.h"
#include "msAPI_Timer.h"
#if (ENABLE_DTV_EPG)

#include "apiXC.h"
#include "apiXC_Adc.h"
#include "MApp_GlobalSettingSt.h"

#include "MApp_Key.h"
#include "MApp_UiMenuDef.h"
#include "MApp_ZUI_Main.h"
#include "ZUI_tables_h.inl"
#include "MApp_UiEpg.h"

#include "ZUI_exefunc.h"
#include "MApp_EpgTimer.h"
#include "MApp_UiPvr.h"
//#if (ENABLE_PIP)
extern BOOLEAN MApp_ZUI_ACT_ExecuteMenuItemAction(U16 act);
//#endif
///////////////////////////////////////////////////////////
#if ENABLE_AUTOTEST
extern BOOLEAN g_bAutobuildDebug;
#endif
extern DWORD        m_dwEPGManualTimerMonitorTimer;
extern U32 u32LatestManualTimerStartDate;
extern U8           m_u8EpgNextStartUpIdx;
extern DWORD        m_u32EpgNextStartUpTime;
extern EN_EPG_TIMER_ACT_TYPE _TimerActType;
EN_EPG_STATE enEpgState;

EN_EPG_MODE _eEpgMode;

//////////////////////////////////////////////////////////

EN_RET MApp_Epg_Main(void)
{
    EN_RET enRetVal =EXIT_NULL;
    //U16 u16CurrPosiotion;
    //MEMBER_SERVICETYPE bServiceType;
    switch(enEpgState)
    {
        case STATE_EPG_INIT:
            #if ENABLE_AUTOTEST
            if(g_bAutobuildDebug)
            {
                printf("101_EPGGuide\n");
            }
            #endif
            MApp_ZUI_ACT_StartupOSD(E_OSD_EPG);
            MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_EPG_SHOW_PROGRAMMEGUIDE_TIME_PAGE);
            enEpgState = STATE_EPG_WAIT;
            break;

        case STATE_EPG_WAIT:
            MApp_ZUI_ProcessKey(u8KeyCode);
            u8KeyCode = KEY_NULL;
            break;

        //case STATE_EPG_EPGTIMER_WAIT:
            //MApp_UiMenu_EPGTimer_ProcessUserInput();
            //break;

        case STATE_EPG_CLEAN_UP:
            MApp_ZUI_ACT_ShutdownOSD();
            enEpgState = STATE_EPG_INIT;
            enRetVal =EXIT_CLOSE;
            break;

        case STATE_EPG_GOTO_STANDBY:
            MApp_ZUI_ACT_ShutdownOSD();
            u8KeyCode = KEY_POWER;
            enRetVal =EXIT_GOTO_STANDBY;
            break;
#if (ENABLE_PIP)
        case STATE_EPG_GOTO_PIP:
            if(IsPIPSupported())
            {
                MApp_ZUI_ACT_ShutdownOSD();
                enEpgState = STATE_EPG_ENABLE_PIP;
            }
            break;
        case STATE_EPG_ENABLE_PIP:
            if(IsPIPSupported())
            {
                MApp_ZUI_ACT_ExecuteMenuItemAction(EN_EXE_INC_PIPMODE);
                enEpgState = STATE_EPG_INIT;
                enRetVal =EXIT_CLOSE;
            }
            break;
#endif

        default:
            enEpgState = STATE_EPG_WAIT;
            break;
    }
    return enRetVal;
}

#endif  //#if (ENABLE_DTV_EPG)

#undef MAPP_EPG_MAIN_C

