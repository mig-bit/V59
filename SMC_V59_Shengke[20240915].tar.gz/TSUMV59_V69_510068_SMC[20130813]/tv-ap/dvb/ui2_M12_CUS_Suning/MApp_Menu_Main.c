////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#define MAPP_MENU_MAIN_C

/******************************************************************************/
/*                 Header Files                                               */
/* ****************************************************************************/
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "Board.h"
#include "datatype.h"
#include "MsCommon.h"

#include "apiXC.h"
#include "apiXC_Adc.h"
#include "MApp_GlobalSettingSt.h"

#include "MApp_Exit.h"
#include "MApp_Key.h"
#include "MApp_UiMenuDef.h"
#include "MApp_ZUI_Main.h"
#include "ZUI_tables_h.inl"
#include "MApp_Menu_Main.h"
#include "MApp_OSDPage_Main.h"
#include "ZUI_exefunc.h"
#include "MApp_TV.h"

#include "MApp_ChList_Main.h" //ZUI:
#include "msAPI_FreqTableDTV.h"
#include "MApp_SaveData.h"
#include "MApp_InputSource.h"
#if OBA2
#ifdef CHIP_S7LD
 #include "drvMIU.h"
#endif
#endif
#include "MApp_ZUI_ACTinstall.h"
#include "MApp_ZUI_ACTmenufunc.h"
///////////////////////////////////////////////////////////

EN_MENU_STATE enMainMenuState;

//////////////////////////////////////////////////////////
#if ENABLE_TTX
extern void MApp_TTX_SetChInfoOnOff(BOOLEAN val);
#endif
EN_RET MApp_Menu_Main(void)
{
    EN_RET enRetVal =EXIT_NULL;

    switch(enMainMenuState)
    {
        case STATE_MENU_INIT:
            MApp_ZUI_ACT_StartupOSD(E_OSD_MAIN_MENU);
            enMainMenuState = STATE_MENU_WAIT;
			#if ENABLE_TTX
			MApp_TTX_SetChInfoOnOff(FALSE);
			#endif
            if(g_bIsImageFrozen)
            {
                g_bIsImageFrozen = FALSE;
                MApi_XC_FreezeImg(g_bIsImageFrozen, MAIN_WINDOW);
            }
            break;

        case STATE_MENU_WAIT:
            MApp_ZUI_ProcessKey(u8KeyCode);
            u8KeyCode = KEY_NULL;
			#if DVB_C_ENABLE
			if(MApp_ZUI_ACT_Get_InstallGuidePage() == PAGE_INSTALL_SELECT_DVBC)
			{
				MApp_ZUI_ACT_Set_InstallGuidePage(PAGE_INSTALL_TUNING_COUNTRY);
				MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_GOTO_DVB_SELECT_INPUT_PASSWORD_DLG);
			}
			#endif
            MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_UPDATE_SIGNAL_INFORMAT);
            break;

        //case STATE_MENU_EPGTIMER_WAIT:
            //MApp_UiMenu_EPGTimer_ProcessUserInput();
            //break;

        case STATE_MENU_CLEAN_UP:
            MApp_ZUI_ACT_ShutdownOSD();
            enMainMenuState = STATE_MENU_INIT;
            #if ENABLE_CUS_BLOCK_SYS
            if(MApp_UiMenuFunc_CheckInputLockAudioVideo())
            {
               enRetVal = EXIT_GOTO_INFO;
            }
            else
            #endif
            {
                enRetVal =EXIT_CLOSE;
            }
            break;

        case STATE_MENU_GOTO_STANDBY:
            MApp_ZUI_ACT_ShutdownOSD();
            u8KeyCode = KEY_POWER;
            enRetVal =EXIT_GOTO_STANDBY;
            break;

        case STATE_MENU_GOTO_SCAN:
            printf("\r\n STATE_MENU_GOTO_SCAN ---");/*Creass.liu at 2012-06-06*/
            #if (ENABLE_CUS_UI_SPEC == FALSE)
            MApp_ZUI_ACT_ShutdownOSD();
            MApp_ZUI_ACT_StartupOSD(E_OSD_AUTO_TUNING);
            #endif
            enMainMenuState = STATE_MENU_INIT;
            enRetVal = EXIT_GOTO_SCAN;
            break;

        case STATE_MENU_GOTO_EPG:
            MApp_ZUI_ACT_ShutdownOSD();
            enMainMenuState = STATE_MENU_INIT;
            enRetVal =EXIT_GOTO_EPG;
            break;

#if ENABLE_DTV
        case STATE_MENU_GOTO_DTV_MANUALTUNING:
#if (ENABLE_T_C_COMBO || DVB_T_C_DIFF_DB)
            if(IsCATVInUse())//TODO need add DVB-C case
            {
            #if (!ENABLE_T_C_COMBO)
                msAPI_CM_ResetAllProgram();
            #endif
                stGenSetting.stScanMenuSetting.u8DVBCTvConnectionType=EN_DVB_T_TYPE;
                MApp_SaveScanMenuSetting();
                msAPI_Tuner_SwitchSource((EN_DVB_TYPE)stGenSetting.stScanMenuSetting.u8DVBCTvConnectionType, TRUE);
                stGenSetting.stScanMenuSetting.u8PreRFChannelNumber =INVALID_IDINDEX;
                stGenSetting.stScanMenuSetting.u8RFChannelNumber = msAPI_DFT_GetFirstPhysicalChannelNumber();
            }
    #if 0
            MApp_ZUI_ACT_StartupOSD(E_OSD_CADTV_MANUAL_TUNING);
            enMainMenuState = STATE_MENU_INIT;
            enRetVal = EXIT_GOTO_DTV_MANUALTUNING;
            break;
    #endif
#endif
            MApp_ZUI_ACT_ShutdownOSD();
            u16IdleInputValue = 0;
            u8IdleDigitCount = 0;
            /* make sure input source is dtv */

            /* make sure input source is dtv */

            MApp_ZUI_ACT_StartupOSD(E_OSD_DTV_MANUAL_TUNING);

            enMainMenuState = STATE_MENU_INIT;
            enRetVal = EXIT_GOTO_DTV_MANUALTUNING;
            break;
#endif

        case STATE_MENU_GOTO_ATV_MANUALTUNING:
            printf("\r\n STATE_MENU_GOTO_ATV_MANUALTUNING ---");/*Creass.liu at 2012-06-06*/
           #if (ENABLE_CUS_UI_SPEC == FALSE)
            MApp_ZUI_ACT_ShutdownOSD();
           #endif
            enMainMenuState = STATE_MENU_INIT;
            enRetVal = EXIT_GOTO_ATV_MANUALTUNING;
            break;

        case STATE_MENU_GOTO_CHANNELCHANGE:
            MApp_ZUI_ACT_ShutdownOSD();
            enMainMenuState = STATE_MENU_INIT;
            enRetVal = EXIT_GOTO_CHANNELCHANGE;
            break;

        case STATE_MENU_GOTO_CIMMI:
            MApp_ZUI_ACT_ShutdownOSD();
            enMainMenuState = STATE_MENU_INIT;
            enRetVal = EXIT_GOTO_MMI;
            break;

#if ENABLE_DMP
        case STATE_MENU_GOTO_DMP:
            MApp_ZUI_ACT_ShutdownOSD();
            enMainMenuState = STATE_MENU_INIT;
            enRetVal = EXIT_GOTO_DMP;
            break;
#endif

#ifdef ENABLE_BT
        case STATE_MENU_GOTO_BT:
            MApp_ZUI_ACT_ShutdownOSD();
            enMainMenuState = STATE_MENU_INIT;
            enRetVal = EXIT_GOTO_BT;
            break;
#endif
#ifdef ENABLE_KTV
        case STATE_MENU_GOTO_KTV:
            MApp_ZUI_ACT_ShutdownOSD();
            enMainMenuState = STATE_MENU_INIT;
            enRetVal = EXIT_GOTO_KTV;
            break;
#endif
#if(ENABLE_PVR ==1)
        case STATE_MENU_GOTO_PVR_CHECK_FS:
            MApp_ZUI_ACT_ShutdownOSD();
            enMainMenuState = STATE_MENU_INIT;
            enRetVal = EXIT_GOTO_PVR_CHECK_FS;
            break;
#endif
#if DVB_C_ENABLE
        case STATE_MENU_GOTO_CADTV_MANUALTUNING:
            MApp_ZUI_ACT_ShutdownOSD();
            enMainMenuState = STATE_MENU_INIT;
            enRetVal = EXIT_GOTO_CADTV_MANUALTUNING;
            break;
#endif

        case STATE_MENU_GOTO_OSDPAGE:
            MApp_ZUI_ACT_ShutdownOSD();
            enMainMenuState = STATE_MENU_INIT;
            enRetVal = EXIT_GOTO_OSDPAGE;
            break;

        case STATE_MENU_GOTO_INPUT_SOURCE:
            MApp_ZUI_ACT_ShutdownOSD();
            enMainMenuState = STATE_MENU_INIT;
            enRetVal = EXIT_GOTO_INPUTSOURCE;
            break;

        case STATE_MENU_GOTO_CHANNEL_LIST:
            MApp_ZUI_ACT_ShutdownOSD();
            enMainMenuState = STATE_MENU_INIT;
            enRetVal = EXIT_GOTO_OSDPAGE;
            MApp_OSDPage_SetOSDPage(E_OSD_CHANNEL_LIST);
            MApp_ChannelList_SetMode(MODE_CHLIST_TV);
            break;

        case STATE_MENU_GOTO_FAVORITE_LIST:
            MApp_ZUI_ACT_ShutdownOSD();
            enMainMenuState = STATE_MENU_INIT;
            enRetVal = EXIT_GOTO_OSDPAGE;
            MApp_OSDPage_SetOSDPage(E_OSD_CHANNEL_LIST);
            MApp_ChannelList_SetMode(MODE_CHLIST_TV_FAV);
            break;

        case STATE_MENU_GOTO_INFO:
            MApp_ZUI_ACT_ShutdownOSD();
            enMainMenuState = STATE_MENU_INIT;
            enRetVal = EXIT_GOTO_INFO;
            break;
#if OBA2
        case STATE_MENU_GOTO_APENGINE:
            MApp_ZUI_ACT_ShutdownOSD();
          #ifdef CHIP_S7LD
            if(E_GOP_APP)
            {
              MDrv_MIU_SelMIU(MIU_CLIENT_GOP1_R,MIU_SELTYPE_MIU1);
            }
            else
            {
              MDrv_MIU_SelMIU(MIU_CLIENT_GOP0_R,MIU_SELTYPE_MIU1);
            }
          #endif
            enMainMenuState = STATE_MENU_INIT;
            enRetVal = EXIT_GOTO_APENGINE;
            break;
#endif

#ifdef ENABLE_YOUTUBE
        case STATE_MENU_GOTO_YOUTUBE:
            MApp_ZUI_ACT_ShutdownOSD();
           enMainMenuState = STATE_MENU_INIT;
            enRetVal =EXIT_GOTO_YOUTUBE;
            break;
#endif
#ifdef ENABLE_RSS
        case STATE_MENU_GOTO_RSS:
            MApp_ZUI_ACT_ShutdownOSD();
            enMainMenuState = STATE_MENU_INIT;
            enRetVal =EXIT_GOTO_RSS;
            break;
#endif
//#ifdef ENABLE_NETFLIX
//        case STATE_MENU_GOTO_NETFLIX:
//            MApp_ZUI_ACT_ShutdownOSD();
//            enMainMenuState = STATE_MENU_INIT;
//            enRetVal =EXIT_GOTO_NETFLIX;
//            break;
//#endif
#if (ENABLE_GAME)
        case STATE_MENU_GOTO_GAME:
        {
            extern EN_GAME_STATE enGameState;
            MApp_ZUI_ACT_ShutdownOSD();
            enMainMenuState = STATE_MENU_INIT;
            enGameState=STATE_GAME_INIT;
            enRetVal =EXIT_GOTO_GAME;
         }
        break;
#endif
#ifdef ENABLE_EXTENSION
        case STATE_MENU_GOTO_EXTENSION:
        {
            MApp_ZUI_ACT_ShutdownOSD();
            enMainMenuState = STATE_MENU_INIT;
            enRetVal =EXIT_GOTO_EXTENSION;
        }
        break;
#endif
#if BOE_USB_UPGRADE_FACTROY//minglin1206
case STATE_MENU_USB_UPDATE:
	  printf("\r\nUSB UPDATE1111111111111111\n",0);
	 
	  MApp_ZUI_ACT_StartupOSD(E_OSD_MAIN_MENU);
       MApp_ZUI_API_ShowWindow(HWND_MENU_PICTURE_PAGE, SW_HIDE);
	   MApp_ZUI_API_ShowWindow(HWND_MENU_MASK_BACKGROUND, SW_HIDE);
	   MApp_ZUI_API_ShowWindow(HWND_MENU_BACKGROUND, SW_HIDE);//minglin1224
	  // MApp_ZUI_API_ShowWindow(HWND_MENU_TRANSPARENT_BG, SW_SHOW);
	 // MApp_ZUI_API_ShowWindow(HWND_MENU_TRANSPARENT_BG, SW_HIDE);
	   MApp_ZUI_API_ShowWindow(HWND_MENU_PICTURE_MODE_PAGE, SW_HIDE);
	   //MApp_ZUI_API_ShowWindow(HWND_MENU_PICTURE_MODE_PAGE, SW_SHOW);
	   //MApp_ZUI_API_SetFocus(HWND_MENU_PICMODE_PICMODE);
	 	enMainMenuState = STATE_MENU_USB_UPDATE2;
	   break;
   case STATE_MENU_USB_UPDATE2:
	  printf("\r\nUSB UPDATE22222222\n",0);
	   MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_SW_USB_UPDATE2);
	   enMainMenuState = STATE_MENU_WAIT;
	   break;

#endif
        default:
            enMainMenuState = STATE_MENU_WAIT;
            break;
    }
    return enRetVal;
}
#if BOE_USB_UPGRADE_FACTROY//minglin1206
void MApp_Usb_UpDate_Init(void)
{
    enMainMenuState = STATE_MENU_USB_UPDATE;
}

#endif
#undef MAPP_MENU_MAIN_C

