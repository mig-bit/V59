////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#define MAPP_DATABASE_C


/******************************************************************************/
/*                            Header Files                                    */
/******************************************************************************/
#include <stdlib.h>
#include <string.h>

#include "debug.h"

// Common Definition
#include "Board.h"
#include "datatype.h"
#include "MsCommon.h"
#include "apiXC.h"
#include "apiXC_Adc.h"

#include "msAPI_ATVSystem.h"
#include "msAPI_DTVSystem.h"
#include "msAPI_MIU.h"
#include "msAPI_Flash.h"
#include "msAPI_Ram.h"
#include "msAPI_Timer.h"
#include "apiXC_Sys.h"
#include "apiXC_ModeParse.h"
#include "apiXC_Cus.h"

#include "MApp_GlobalSettingSt.h"
#include "MApp_GlobalVar.h"
#include "MApp_DataBase.h"
#include "MApp_Scan.h"
#include "MApp_SaveData.h"
#include "MApp_RestoreToDefault.h"
#include "MApp_GlobalSettingSt.h"
#include "MApp_Main.h"
#include "MApp_Key.h"
#include "MsOS.h"
#if (OBA2)
#include "p_misc.h"
#endif

#include "ZUI_tables_h.inl"
#if (EEPROM_DB_STORAGE!=EEPROM_SAVE_ALL)
#include "msAPI_DTVSystem.h"
#include "MApp_ChannelList.h"

#define QUICK_DATABASE_MONITOR_PERIOD 1000
U32 u32QuickDatabaseTimer=0;

#ifndef MemAlign
#define MemAlign(n, unit)           ((((n)+(unit)-1)/(unit))*(unit))
#endif

#endif

#define DB_MSG(x)              MS_DEBUG_MSG(x)
//void MApp_DB_ResetGenSettingExt(void)
void MApp_DB_ResetGenSettingExt(U8 u8RestoreMask)
{
    BYTE i;
	
	if (u8RestoreMask&RESTORE_DATABASE_INCLUDE_ADC)
	{
		for( i = 0; i < ADC_SET_NUMS; i++ )
		{
		    MApp_InitADCSetting((E_ADC_SET_INDEX)i);
		}
	}
    for( i = 0; i < DATA_INPUT_SOURCE_NUM; i++ )
    {
        MApp_InitVideoSetting((E_DATA_INPUT_SOURCE)i);
		if (u8RestoreMask&RESTORE_DATABASE_INCLUDE_ADC)
		{
            MApp_InitWhiteBalanceSetting((E_DATA_INPUT_SOURCE)i);
            MApp_InitSubColorSetting((E_DATA_INPUT_SOURCE)i);
		}
    }
}

void MApp_DB_LoadGenSettingExt(void)
{
    BYTE i;

    for( i = 0; i < ADC_SET_NUMS; i++ )
    {
        MApp_LoadADCSetting((E_ADC_SET_INDEX)i);
    }

    for( i = 0; i < DATA_INPUT_SOURCE_NUM; i++ )
    {
        MApp_LoadVideoSetting((E_DATA_INPUT_SOURCE)i);
        MApp_LoadWhiteBalanceSetting((E_DATA_INPUT_SOURCE)i);
        MApp_LoadSubColorSetting((E_DATA_INPUT_SOURCE)i);
    }

    #ifdef ENABLE_CUS_SERIAL_NUMBER
    MApp_LoadSerialNumberSetting();
    #endif
}

#if (HDCP_KEY_TYPE==HDCP_KEY_IN_DB)
//*************************************************************************
//Function name:        MApp_DB_LoadHDCP_KEY
//Passing parameter:    none
//Return parameter:     none
//Description:          Dump hdcp key
//*************************************************************************

extern MS_U8 _u8HdcpKey[HDCP_KEY_SIZE];

void MApp_DB_LoadHDCP_KEY(MS_U8 *u8HdcpKey)
{
    U32 dst;
#if 0
    U16 i;
#endif

    dst = (SYSTEM_BANK_SIZE * HDCP_DB_BANK) ;

    MDrv_FLASH_Read(dst, HDCP_KEY_SIZE, u8HdcpKey);

#if 0
    printf("MApp_DB_LoadHDCP_KEY\n");
    printf("HDCP_DB_BANK 0x%x\n", HDCP_DB_BANK);

    for(i=0; i<HDCP_KEY_SIZE; i++)
    {
        printf("%x ", u8HdcpKey[i]);
        if(i%16==15) printf("\n");
    }

    printf("\n");
#endif
}

void MApp_DB_SaveHDCP_KEY( U32 u16Offset)
{
    U32 dst;

    MDrv_FLASH_WriteProtect_Disable_Range_Set(SYSTEM_BANK_SIZE * HDCP_DB_BANK, SYSTEM_BANK_SIZE); // MDrv_FLASH_WriteProtect(DISABLE); // <-@@@

    dst = (SYSTEM_BANK_SIZE * HDCP_DB_BANK) + u16Offset;

    MDrv_FLASH_AddressErase(dst, SYSTEM_BANK_SIZE, TRUE);

    MDrv_FLASH_Write(dst, HDCP_KEY_SIZE, _u8HdcpKey);

#if 0
    printf("MApp_DB_SaveHDCP_KEY 000 \n");
    printf("HDCP_DB_BANK 0x%x\n", HDCP_DB_BANK);
    printf("dst 0x%x\n", dst);
    printf("u16Offset 0x%x\n", u16Offset);
#endif

    MDrv_FLASH_WriteProtect(ENABLE);

}

#endif
#if (EEPROM_DB_STORAGE!=EEPROM_SAVE_ALL)
//*************************************************************************
//Function name:        MApp_DB_SaveDataBase
//Passing parameter:    none
//Return parameter:     none
//Description:          Save database from SDRAM to EEPROM
//*************************************************************************
void MApp_DB_SaveDataBase(void)
{
  #if ENABLE_DUAL_DATABASE
    u8DataBaseSerialNumber = (u8DataBaseSerialNumber + 1) & 0x7F;
    //printf("\n u8DataBaseSerialNumber(%bu)", u8DataBaseSerialNumber);
    u8DataBaseBank = !u8DataBaseBank;
    msAPI_MIU_StoreDataBase2Flash(u8DataBaseBank ? SYSTEM_BANK_DATABASE1 : SYSTEM_BANK_DATABASE0, DRAM_64K_DB_START(((DATABASE_START_MEMORY_TYPE & MIU1) ? (DATABASE_START_ADR | MIU_INTERVAL) : (DATABASE_START_ADR))), RM_64K_USAGE, TRUE);
    msAPI_MIU_WriteFlashDataBaseVersion(u8DataBaseBank ? SYSTEM_BANK_DATABASE1 : SYSTEM_BANK_DATABASE0, RM_DB_VERSION_START_ADDR, u8DataBaseSerialNumber);
  #else
    msAPI_MIU_StoreDataBase2Flash(SYSTEM_BANK_DATABASE0, DRAM_64K_DB_START(((DATABASE_START_MEMORY_TYPE & MIU1) ? (DATABASE_START_ADR | MIU_INTERVAL) : (DATABASE_START_ADR))), RM_64K_USAGE, TRUE);
    msAPI_MIU_WriteFlashDataBaseVersion(SYSTEM_BANK_DATABASE0, RM_DB_VERSION_START_ADDR, u8DataBaseSerialNumber);
  #endif
}

void MApp_DB_QuickDatabaseMonitor(void)
{
    if(msAPI_Timer_DiffTimeFromNow(u32QuickDatabaseTimer) < QUICK_DATABASE_MONITOR_PERIOD)
        return;

    /* To avoid access flash frequently */
    if ((g_u8QuickDataBase & QUICK_DB_GENSTEXT_MODIFIED) && !(g_u8QuickDataBase & QUICK_DB_UPDATE))
    {
        if (E_OSD_MAIN_MENU == MApp_ZUI_GetActiveOSD() || E_OSD_FACTORY_MENU == MApp_ZUI_GetActiveOSD())
            return;
        else
            g_u8QuickDataBase = (g_u8QuickDataBase & ~QUICK_DB_GENSTEXT_MODIFIED) | QUICK_DB_UPDATE;
    }

    if ((g_u8QuickDataBase & QUICK_DB_UPDATE) == QUICK_DB_UPDATE)
    {
        U8 u8Status;

        u8Status = (g_u8QuickDataBase & QUICK_DB_MASK);


        switch(u8Status)
        {
            case QUICK_DB_READY:
                #if ENABLE_DUAL_DATABASE
                u8DataBaseBank = !u8DataBaseBank;
                msAPI_MIU_QuickDataBaseErase(u8DataBaseBank ? SYSTEM_BANK_DATABASE1 : SYSTEM_BANK_DATABASE0);
                #else
                msAPI_MIU_QuickDataBaseErase(SYSTEM_BANK_DATABASE0);
                #endif
                g_u8QuickDataBase = ((g_u8QuickDataBase & ~QUICK_DB_MASK) | QUICK_DB_ERASE_IN_PROGRESS);
                break;

            case QUICK_DB_ERASE_IN_PROGRESS:
               if (msAPI_MIU_QuickDataBaseCheck() == TRUE)
                {
                    g_u8QuickDataBase = ((g_u8QuickDataBase & ~QUICK_DB_MASK) | QUICK_DB_ERASE_DONE);
                }
                break;

            case QUICK_DB_ERASE_DONE:
                u8DataBaseSerialNumber = (u8DataBaseSerialNumber + 1) & 0x7F;
                #if ENABLE_DUAL_DATABASE
                msAPI_MIU_StoreDataBase2Flash(u8DataBaseBank ? SYSTEM_BANK_DATABASE1 : SYSTEM_BANK_DATABASE0, DRAM_64K_DB_START(((DATABASE_START_MEMORY_TYPE & MIU1) ? (DATABASE_START_ADR | MIU_INTERVAL) : (DATABASE_START_ADR))), RM_64K_USAGE, (!((g_u8QuickDataBase & (QUICK_DB_UPDATE | QUICK_DB_MASK)) == (QUICK_DB_UPDATE | QUICK_DB_ERASE_DONE))));
                msAPI_MIU_WriteFlashDataBaseVersion(u8DataBaseBank ? SYSTEM_BANK_DATABASE1 : SYSTEM_BANK_DATABASE0, RM_DB_VERSION_START_ADDR, u8DataBaseSerialNumber);
                #else
                msAPI_MIU_StoreDataBase2Flash(SYSTEM_BANK_DATABASE0, DRAM_64K_DB_START(((DATABASE_START_MEMORY_TYPE & MIU1) ? (DATABASE_START_ADR | MIU_INTERVAL) : (DATABASE_START_ADR))), RM_64K_USAGE, (!((g_u8QuickDataBase & (QUICK_DB_UPDATE | QUICK_DB_MASK)) == (QUICK_DB_UPDATE | QUICK_DB_ERASE_DONE))));
                msAPI_MIU_WriteFlashDataBaseVersion(SYSTEM_BANK_DATABASE0, RM_DB_VERSION_START_ADDR, u8DataBaseSerialNumber);
                #endif
                g_u8QuickDataBase = ((g_u8QuickDataBase & ~QUICK_DB_MASK) | QUICK_DB_READY);
                g_u8QuickDataBase &= (~(QUICK_DB_UPDATE|QUICK_DB_GENSTEXT_MODIFIED));

                if ((g_u8QuickDataBase & QUICK_DB_GENST_UPDATE) == 0)
                    u32QuickDatabaseTimer = msAPI_Timer_GetTime0();
                break;
        }
    }
    #if (EEPROM_DB_STORAGE==EEPROM_SAVE_NONE)
    else
    {
	    MApp_DB_QuickGenSettingMonitor();
    }
    #endif
}

#if 1 // unused func
//*************************************************************************
//Function name:        MApp_DB_LoadDataBase
//Passing parameter:    none
//Return parameter:     none
//Description:          Load database from EEPROM to SDRAM if using 24C512,
//                      otherwise from Flash to SDRAM as usual.
//*************************************************************************
S8 MApp_DB_CheckDataBase(U8 u8Bank)
{
    U32 u32Base, u32srcaddr;
    U16 verify;
    U8 serNo;

    u32Base = SYSTEM_BANK_SIZE * u8Bank;

    #if (DB_IN_NAND)
    {
        U32 u32BufLen = MemAlign(MAX((U32)&(((DTV_CHANNEL_DATA_STRUCTURE*)0)->wID), (U32)&(((DTV_CHANNEL_DATA_STRUCTURE*)0)->bSerialNum))+2, 8);
        U32 u32DramAddr = DRAM_64K_DB_START(((DATABASE_START_MEMORY_TYPE & MIU1) ? (DATABASE_START_ADR | MIU_INTERVAL) : (DATABASE_START_ADR)));
        msAPI_ReadNandDB(u8Bank, u32Base, u32BufLen, (U8*)_PA2VA(u32DramAddr));
    }
    #else
    msAPI_MIU_Copy(u32Base, DRAM_64K_DB_START(((DATABASE_START_MEMORY_TYPE & MIU1) ? (DATABASE_START_ADR | MIU_INTERVAL) : (DATABASE_START_ADR))),
                MemAlign(MAX((U32)&(((DTV_CHANNEL_DATA_STRUCTURE*)0)->wID), (U32)&(((DTV_CHANNEL_DATA_STRUCTURE*)0)->bSerialNum))+2, 8),
                MIU_FLASH2SDRAM);
    #endif

    u32srcaddr = DRAM_64K_DB_START(((DATABASE_START_MEMORY_TYPE & MIU1) ? (DATABASE_START_ADR | MIU_INTERVAL) : (DATABASE_START_ADR)))+(U32)&(((DTV_CHANNEL_DATA_STRUCTURE*)0)->wID);
    memcpy((void*)(&verify), (void*)_PA2VA(u32srcaddr), 2);
    u32srcaddr = DRAM_64K_DB_START(((DATABASE_START_MEMORY_TYPE & MIU1) ? (DATABASE_START_ADR | MIU_INTERVAL) : (DATABASE_START_ADR)))+(U32)&(((DTV_CHANNEL_DATA_STRUCTURE*)0)->bSerialNum);
    memcpy((void*)(&serNo), (void*)_PA2VA(u32srcaddr), 1);

    //printf("\n verify(0x%x) serNo(0x%bx)", verify, serNo);
    if( DTVDATA_ID != verify)
    {
        return -1;
    }

    return serNo;
}
#endif // unused func

void MApp_DB_LoadChDataBase(void)
{
    S8 s8SN0 = -1;
    S8 s8SN1 = -1;
	BOOL bXCopyFWStatus= MApi_BDMA_XCopyGetFWStatus();

    s8SN0 = msAPI_MIU_ReadFlashDataBaseVersion((U8)SYSTEM_BANK_DATABASE0, RM_DB_VERSION_START_ADDR);

    #if ENABLE_DUAL_DATABASE
    u8DataBaseBank = 0;
    u8DataBaseSerialNumber = 0;
    s8SN1 = msAPI_MIU_ReadFlashDataBaseVersion((U8)SYSTEM_BANK_DATABASE1, RM_DB_VERSION_START_ADDR);
    #endif

	MApi_BDMA_XCopySetFWStatus(0);//caucy.niu 090921 for hisense DB Save in flash
    DB_MSG(printf("\n s8SN0(%x) s8SN1(%x)\n", (U16)s8SN0, (U16)s8SN1));

    if ( (s8SN0<0) && (s8SN1<0) )
    {
        #if (ENABLE_DTV)
        msAPI_CM_ResetDTVDataManager();
        #endif
        #if (!BLOADER)
        msAPI_ATV_ResetATVDataManager();
        g_bFactoryResetMode=TRUE;/*Creass.liu at 2012-07-18*/
        MApp_DB_ResetGenSettingExt(RESTORE_DATABASE);
        #endif //(!BLOADER)
    }
    else
    {
#if ENABLE_DUAL_DATABASE
        u8DataBaseBank = (s8SN0 >= 0 && s8SN1 >= 0) ? (s8SN1 == ((s8SN0 + 1) & 0x7F)) : (s8SN1 >= 0);
        u8DataBaseSerialNumber = u8DataBaseBank ? s8SN1 : s8SN0;
        #if (DB_IN_NAND)
        {
            U32 u32SrcAddr = (SYSTEM_BANK_SIZE * (u8DataBaseBank ? SYSTEM_BANK_DATABASE1 : SYSTEM_BANK_DATABASE0));
            U32 u32DramAddr = (DRAM_64K_DB_START(((DATABASE_START_MEMORY_TYPE & MIU1) ? (DATABASE_START_ADR | MIU_INTERVAL) : (DATABASE_START_ADR))));
            msAPI_ReadNandDB((u8DataBaseBank ? SYSTEM_BANK_DATABASE1 : SYSTEM_BANK_DATABASE0), u32SrcAddr, RM_64K_USAGE, (U8*)_PA2VA(u32DramAddr));
        }
        #else
        msAPI_MIU_Copy(SYSTEM_BANK_SIZE * (u8DataBaseBank ? SYSTEM_BANK_DATABASE1 : SYSTEM_BANK_DATABASE0),
                DRAM_64K_DB_START(((DATABASE_START_MEMORY_TYPE & MIU1) ? (DATABASE_START_ADR | MIU_INTERVAL) : (DATABASE_START_ADR))),
                RM_64K_USAGE,
                MIU_FLASH2SDRAM);
        #endif
#else // #else ENABLE_DUAL_DATABASE
        #if (DB_IN_NAND)
        {
            U32 u32SrcAddr = (SYSTEM_BANK_SIZE*SYSTEM_BANK_DATABASE0);
            U32 u32DramAddr = (DRAM_64K_DB_START(((DATABASE_START_MEMORY_TYPE & MIU1) ? (DATABASE_START_ADR | MIU_INTERVAL) : (DATABASE_START_ADR))));
            msAPI_ReadNandDB(SYSTEM_BANK_DATABASE0, u32SrcAddr, RM_64K_USAGE, (U8*)_PA2VA(u32DramAddr));
        }
        #else
        msAPI_MIU_Copy(SYSTEM_BANK_SIZE*SYSTEM_BANK_DATABASE0,
                DRAM_64K_DB_START(((DATABASE_START_MEMORY_TYPE & MIU1) ? (DATABASE_START_ADR | MIU_INTERVAL) : (DATABASE_START_ADR))),
                RM_64K_USAGE,
                MIU_FLASH2SDRAM);
        #endif
#endif //ENABLE_DUAL_DATABASE

        #if (ENABLE_DTV)
        msAPI_CM_InitDTVDataManager();
        #endif
        #if (!BLOADER)		
	    MApp_DB_LoadGenSettingExt();
        #endif
        //msAPI_ATV_InitATVDataManager();

    }

	MApi_BDMA_XCopySetFWStatus(bXCopyFWStatus);//caucy.niu 090921 for hisense DB Save in flash

}
#endif

#undef MAPP_DATABASE_C
