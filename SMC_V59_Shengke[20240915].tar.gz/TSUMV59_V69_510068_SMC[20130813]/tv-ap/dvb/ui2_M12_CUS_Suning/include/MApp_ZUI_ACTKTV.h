////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MAPP_ZUI_ACTKTV_H
#define _MAPP_ZUI_ACTKTV_H

#ifdef __cplusplus
extern "C" {
#endif  /* __cplusplus */

#include "MApp_ZUI_APIgdi.h"

#ifdef MAPP_ZUI_ACTKTV_C
#define INTERFACE
#else
#define INTERFACE extern
#endif

typedef enum
{
    E_KTV_UI_MAIN_PAGE,
    E_KTV_UI_SELECT_SONG_PAGE,
    E_KTV_UI_SELECTED_SONG_SUBPAGE,
    E_KTV_UI_CUT_SONG_SUBPAGE,
    E_KTV_UI_AAC_SUBPAGE,
    E_KTV_UI_SETTING_SUBPAGE,
    E_KTV_UI_EXIT_SUBPAGE,
    E_KTV_UI_LRC_SUBPAGE,

    E_KTV_UI_NONE,
} EN_KTV_UI_TYPE;

typedef enum
{
    E_KTV_MSG_CUTSONG,
    E_KTV_MSG_ACC,
    E_KTV_MSG_EXIT,

    E_KTV_MSG_NONE,
} EN_KTV_MSG_TYPE;

typedef enum
{
    E_KTV_PLAY_NONE,
    E_KTV_PLAY_LOADING,
    E_KTV_PLAY_NOW,
} EN_KTV_PLAY_STATE;
/////////////////////////////////////////
// Cutomize Window Procedures...


/////////////////////////////////////////
// Event Handlers....
INTERFACE void MApp_ZUI_ACT_AppShowKTV(void);
INTERFACE void MApp_ZUI_ACT_TerminateKTV(void);
INTERFACE BOOLEAN MApp_ZUI_ACT_HandleKTVKey(VIRTUAL_KEY_CODE key);
INTERFACE BOOLEAN MApp_ZUI_ACT_ExecuteKTVAction(U16 act);
INTERFACE LPTSTR MApp_ZUI_ACT_GetKTVDynamicText(HWND hwnd);
INTERFACE U16 MApp_ZUI_ACT_GetKTVDynamicBitmap(HWND hwnd,DRAWSTYLE_TYPE ds_type);
INTERFACE S16 MApp_ZUI_ACT_GetKTVDynamicValue(HWND hwnd);
INTERFACE GUI_ENUM_DYNAMIC_LIST_STATE MApp_ZUI_ACT_QueryKTVItemStatus(HWND hwnd);



#undef INTERFACE

#ifdef __cplusplus
}
#endif  /* __cplusplus */

#endif /* _MAPP_ZUI_ACTKTV_H */

