////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MAPP_ZUI_ACTDMP_H
#define _MAPP_ZUI_ACTDMP_H

#ifdef __cplusplus
extern "C" {
#endif  /* __cplusplus */

#include "MApp_ZUI_APIgdi.h"
#include "MApp_ZUI_APIcommon.h"
#include "MApp_ZUI_APItables.h"
#include "mapp_mplayer.h"
#include "MApp_DMP_Main.h"
#include "MApp_TopStateMachine.h"
#ifdef MAPP_ZUI_ACTDMP_C
#define INTERFACE
#else
#define INTERFACE extern
#endif

/////////////////////////////////////////
// Cutomize Window Procedures...
#define DMP_PROGRESS_WINPROC MApp_ZUI_ACT_DmpProgressWinProc
#define DMP_PLAY_STATUS_WINPROC MApp_ZUI_ACT_DmpPlayStatusWinProc
#define DMP_FILE_SELECT_THUMBNAIL_WINPROC MApp_ZUI_ACT_DmpFileSelectThumbnailWinProc
#define DMP_VOLUME_WINPROC MApp_ZUI_ACT_DMPVolumeWinProc
#define DMP_EQ_PLAY_WINPROC MApp_ZUI_ACT_DmpEqPlayWinProc
#define DMP_PREVIEW_WINPROC MApp_ZUI_ACT_DmpPreviewWinProc
#define DMP_ALERT_WINPROC MApp_ZUI_ACT_DmpAlertWinProc
#define DMP_MARQUEE_WINPROC MApp_ZUI_ACT_DMPMarqueeTextWinProc
#define DMP_MOVIERESUME_WINPROC MApp_ZUI_ACT_DMPMovieResumeWinProc

/////////////////////////////////////////
// Event Handlers....
INTERFACE void MApp_ZUI_ACT_AppShowDmp(void);
INTERFACE BOOLEAN MApp_ZUI_ACT_HandleDmpKey(VIRTUAL_KEY_CODE key);
INTERFACE void MApp_ZUI_ACT_TerminateDmp(void);
INTERFACE BOOLEAN MApp_ZUI_ACT_ExecuteDmpAction(U16 act);
INTERFACE LPTSTR MApp_ZUI_ACT_GetDmpDynamicText(HWND hwnd);
INTERFACE U16 MApp_ZUI_ACT_GetDmpDynamicBitmap(HWND hwnd, DRAWSTYLE_TYPE ds_type);
INTERFACE S16 MApp_ZUI_ACT_GetDmpDynamicValue(HWND hwnd);
INTERFACE S32 MApp_ZUI_ACT_DmpProgressWinProc(HWND hwnd, PMSG msg);
INTERFACE S32 MApp_ZUI_ACT_DmpPlayStatusWinProc(HWND hwnd, PMSG msg);
INTERFACE S32 MApp_ZUI_ACT_DmpAlertWinProc(HWND hwnd, PMSG msg);
INTERFACE S32 MApp_ZUI_ACT_DmpFileSelectThumbnailWinProc(HWND hwnd, PMSG msg);
INTERFACE S32 MApp_ZUI_ACT_DMPVolumeWinProc(HWND hwnd, PMSG msg);
INTERFACE S32 MApp_ZUI_ACT_DmpEqPlayWinProc(HWND hwnd, PMSG msg);
INTERFACE S32 MApp_ZUI_ACT_DmpPreviewWinProc(HWND hwnd, PMSG msg);
INTERFACE S32 MApp_ZUI_ACT_DMPMarqueeTextWinProc(HWND hWnd, PMSG pMsg);
INTERFACE U8 MApp_ZUI_ACT_GetCurrentUARTMode(void);
INTERFACE S32 MApp_ZUI_ACT_DMPMovieResumeWinProc(HWND hwnd, PMSG msg);
INTERFACE BOOLEAN MApp_ACTdmp_IsSubtitleOFF(void);
INTERFACE void MApp_ZUI_ACT_FunctionHotkeyUIMapping(VIRTUAL_KEY_CODE VK_KEY);
INTERFACE S32 MApp_ZUI_CTL_DMP_BARTIMER_WinProc(HWND hwnd, PMSG msg);

INTERFACE void MApp_TopStateMachine_SetTopState(EN_TOP_STATE enSetTopState); //MIG ADD  FOR  ON MENU OF SOUCE SWITCH
/////////////////////////////////////////
// Middleware callback function
INTERFACE BOOLEAN MApp_UiMediaPlayer_Notify(enumMPlayerNotifyType eNotify, void *pInfo);
INTERFACE void MApp_DMP_NotifyUiState(EN_DMP_UI_STATE enDmpUiState);
#if (DMP_PHOTO_THUMBNAIL || DMP_MOVIE_THUMBNAIL || DMP_MUSIC_THUMBNAIL)
INTERFACE void MApp_ZUI_ACT_ExitThumbnailMode(void);
#endif


INTERFACE void MApp_ZUI_ACT_DmpShowCountDownWin(void);
INTERFACE void MApp_ZUI_ACT_DmpHideCountDownWin(void);
INTERFACE void MApp_ZUI_ACT_GetDmpVolumeState(HWND hwnd);
// CUS_XM Xue 20120808:
INTERFACE U8 _MAPP_EQBarTrantToTen(U8 data);
INTERFACE   U8 _Mapp_EqShow(U8 BandNum,U8 EQBar ,U8 k,U8 j,U16 HWND_DMP_PLAYBACK_MUSIC_EQ_BAR, U16 HWND_DMP_PLAYBACK_MUSIC_EQ_GROUP_ALL);

INTERFACE void MApp_DMP_MuteState(BOOLEAN bSwitch);
INTERFACE U8 MApp_ZUI_ACT_GetCurrentMediaPlayingFlag(void); //smc.chy 2010/03/29
INTERFACE E_UI_INPUT_SOURCE _MApp_ZUI_ACT_DmpGetSourceType(void);
#undef INTERFACE

#ifdef __cplusplus
}
#endif  /* __cplusplus */

#endif /* _MAPP_ZUI_ACTDMP_H */

