////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////
#define _APP_XC_PQ_C_

//-------------------------------------------------------------------------------------------------
//  Include Files
//-------------------------------------------------------------------------------------------------
// Common Definition
#include "MsCommon.h"
#include "Board.h"

// Common Definition
#include "MsCommon.h"
#include "apiXC.h"

// Driver
#include "drvXC_HDMI_if.h"
#include "drvPQ.h"
#include "drvPWM.h"

// API
#include "apiXC_Ace.h"
#include "msAPI_VD.h"
#include "apiXC_Adc.h"
#include "apiXC_Hdmi.h"
#include "apiXC_Sys.h"
#include "apiXC_Dlc.h"

#include "msAPI_NR.h"
// APP
#include "MApp_GlobalSettingSt.h"           // for ST_VIDEO
#include "MApp_GlobalFunction.h"

#if ENABLE_DMP
#include "mapp_mplayer.h"
#endif

#include "MApp_XC_PQ.h"
#include "QualityEx_Default.h"
#include "MApp_Scaler.h"
#ifdef ENABLE_CUS_COLOR_DEPEND_ON_PANEL
#include "DemoFineTune.h"
#endif

#if MWE_FUNCTION
#include "drvMWE.h"
#endif

#if (XC_BRINGUP == 1)
#include "color_reg.h"
#endif
#if VGA_HDMI_YUV_POINT_TO_POINT
#include "drvGlobal.h"
#endif
#include "drvPWM.h"

//-------------------------------------------------------------------------------------------------
//  Driver Compiler Options
//-------------------------------------------------------------------------------------------------

#if defined(ATSC_SYSTEM)
#define MDrv_WRAP_BW_LoadTableByContext(x)
#else
#define MDrv_WRAP_BW_LoadTableByContext(x)   MDrv_BW_LoadTableByContext(x)
#endif

extern void MApp_ZUI_ACT_AdjustEngineSetting(void);
//-------------------------------------------------------------------------------------------------
//  Local Defines
//-------------------------------------------------------------------------------------------------

#define PQMSG(x)    //x

//-------------------------------------------------------------------------------------------------
//  Local Structurs
//-------------------------------------------------------------------------------------------------
// Set different color setting according to each input

//
// Contrast
//
//OSD    0        90        100        200
//Gain    0.3000  0.9000  1.0000  2.0000

#if 1//(ENABLE_PICTURE_NONLINEAR_CURVE == FALSE)
T_MS_NONLINEAR_CURVE code stContrastCurveTblForHDTV =
{
    {0,     (ACE_Contrast_DefaultValue_HDTV * 30 / 100 ) },
    {90,    (ACE_Contrast_DefaultValue_HDTV * 90 / 100 ) },
    {99,    (ACE_Contrast_DefaultValue_HDTV - 1  ) },
    {100,   (ACE_Contrast_DefaultValue_HDTV      ) },
};

T_MS_NONLINEAR_CURVE code stContrastCurveTblForSDTV =
{
    {0,     (ACE_Contrast_DefaultValue_SDTV * 30 / 100 ) },
    {90,    (ACE_Contrast_DefaultValue_SDTV * 90 / 100) },
    {99,    (ACE_Contrast_DefaultValue_SDTV - 1  ) },
    {100,   (ACE_Contrast_DefaultValue_SDTV      ) },
};

T_MS_NONLINEAR_CURVE code stContrastCurveTblForATV =
{
    {0,     (ACE_Contrast_DefaultValue_ATV * 30 / 100 ) },
    {90,    (ACE_Contrast_DefaultValue_ATV * 90 / 100) },
    {99,    (ACE_Contrast_DefaultValue_ATV - 1  ) },
    {100,   (ACE_Contrast_DefaultValue_ATV      ) },
};

T_MS_NONLINEAR_CURVE code stContrastCurveTblForAV =
{
    {0,     (ACE_Contrast_DefaultValue_AV * 30 / 100 ) },
    {90,    (ACE_Contrast_DefaultValue_AV * 90 / 100) },
    {99,    (ACE_Contrast_DefaultValue_AV - 1  ) },
    {100,   (ACE_Contrast_DefaultValue_AV      ) },
};

T_MS_NONLINEAR_CURVE code stContrastCurveTblForSV =
{
    {0,     (ACE_Contrast_DefaultValue_SV * 30 / 100 ) },
    {90,    (ACE_Contrast_DefaultValue_SV * 90 / 100 ) },
    {99,    (ACE_Contrast_DefaultValue_SV - 1  ) },
    {100,   (ACE_Contrast_DefaultValue_SV      ) },
};

T_MS_NONLINEAR_CURVE code stContrastCurveTblForYPBPR_HD =
{
    {0,     (ACE_Contrast_DefaultValue_YPBPR_HD * 30 / 100 ) },
    {90,    (ACE_Contrast_DefaultValue_YPBPR_HD * 90 / 100) },
    {99,    (ACE_Contrast_DefaultValue_YPBPR_HD - 1  ) },
    {100,   (ACE_Contrast_DefaultValue_YPBPR_HD      ) },
};

T_MS_NONLINEAR_CURVE code stContrastCurveTblForYPBPR_SD =
{
    {0,     (ACE_Contrast_DefaultValue_YPBPR_SD * 30 / 100 ) },
    {90,    (ACE_Contrast_DefaultValue_YPBPR_SD * 90 / 100) },
    {99,    (ACE_Contrast_DefaultValue_YPBPR_SD - 1  ) },
    {100,   (ACE_Contrast_DefaultValue_YPBPR_SD      ) },
};

T_MS_NONLINEAR_CURVE code stContrastCurveTblForHDMI_HD =
{
    {0,     (ACE_Contrast_DefaultValue_HDMI_HD * 30 / 100 ) },
    {90,    (ACE_Contrast_DefaultValue_HDMI_HD * 90 / 100) },
    {99,    (ACE_Contrast_DefaultValue_HDMI_HD - 1  ) },
    {100,   (ACE_Contrast_DefaultValue_HDMI_HD      ) },
};

T_MS_NONLINEAR_CURVE code stContrastCurveTblForHDMI_SD =
{
    {0,     (ACE_Contrast_DefaultValue_HDMI_SD * 30 / 100 ) },
    {90,    (ACE_Contrast_DefaultValue_HDMI_SD * 90 / 100) },
    {99,    (ACE_Contrast_DefaultValue_HDMI_SD - 1  ) },
    {100,   (ACE_Contrast_DefaultValue_HDMI_SD      ) },
};

//T_MS_NONLINEAR_CURVE code stContrastCurveTblForVGA =
//{
//    {0,     (ACE_Contrast_DefaultValue_VGA_DVI * 30 / 100 ) },
//    {90,    (ACE_Contrast_DefaultValue_VGA_DVI     ) },
//    {99,    (ACE_Contrast_DefaultValue_VGA_DVI + 9 ) },
//    {100,   (ACE_Contrast_DefaultValue_VGA_DVI + 10) },
//};

T_MS_NONLINEAR_CURVE code stContrastCurveTblForVGA =
{
    {0,     (ACE_Contrast_DefaultValue_VGA_DVI * 30 / 100 ) },
    {90,    (ACE_Contrast_DefaultValue_VGA_DVI * 90 / 100) },
    {99,    (ACE_Contrast_DefaultValue_VGA_DVI - 1  ) },
    {100,   (ACE_Contrast_DefaultValue_VGA_DVI      ) },
};

//===================================================
//OSD        0    40    50    100    200
//Offset    -64 0    2    64    128

T_MS_NONLINEAR_CURVE code stBrightnessCurveTbl =
{
    {0,     (126-64) },
    {40,    (126)    },
    {50,    (126+2)  },
    {100,   (126+64) },
};

//
// Saturation
//
//OSD  0         50         70         100
//Gain 0.3000  1.0000  1.2000  1.5000
T_MS_NONLINEAR_CURVE code stSaturationCurveTblForHDTV =
{
    {0,     (ACE_Saturation_DefaultValue_HDTV * 1 / 100 ) },
    {50,    (ACE_Saturation_DefaultValue_HDTV    )},
    {70,    (ACE_Saturation_DefaultValue_HDTV * 120 / 100 )},
    {100,   (ACE_Saturation_DefaultValue_HDTV * 150 / 100 )},
};

T_MS_NONLINEAR_CURVE code stSaturationCurveTblForSDTV =
{
    {0,     (ACE_Saturation_DefaultValue_SDTV * 1 / 100 ) },
    {50,    (ACE_Saturation_DefaultValue_SDTV    )},
    {70,    (ACE_Saturation_DefaultValue_SDTV * 120 / 100 )},
    {100,   (ACE_Saturation_DefaultValue_SDTV * 150 / 100 )},
};

T_MS_NONLINEAR_CURVE code stSaturationCurveTblForATV =
{
    {0,     (ACE_Saturation_DefaultValue_ATV * 1 / 100 ) },
    {50,    (ACE_Saturation_DefaultValue_ATV    )},
    {70,    (ACE_Saturation_DefaultValue_ATV * 120 / 100 )},
    {100,   (ACE_Saturation_DefaultValue_ATV * 150 / 100 ) },
};

T_MS_NONLINEAR_CURVE code stSaturationCurveTblForAV =
{
    {0,     (ACE_Saturation_DefaultValue_AV * 1 / 100 ) },
    {50,    (ACE_Saturation_DefaultValue_AV    )},
    {70,    (ACE_Saturation_DefaultValue_AV * 120 / 100 )},
    {100,   (ACE_Saturation_DefaultValue_AV * 150 / 100 ) },
};

T_MS_NONLINEAR_CURVE code stSaturationCurveTblForSV =
{
    {0,     (ACE_Saturation_DefaultValue_SV * 1 / 100 ) },
    {50,    (ACE_Saturation_DefaultValue_SV    )},
    {70,    (ACE_Saturation_DefaultValue_SV * 120 / 100 )},
    {100,   (ACE_Saturation_DefaultValue_SV * 150 / 100 ) },
};

T_MS_NONLINEAR_CURVE code stSaturationCurveTblForYPBPR_HD =
{
    {0,     (ACE_Saturation_DefaultValue_YPBPR_HD * 1 / 100 ) },
    {50,    (ACE_Saturation_DefaultValue_YPBPR_HD    )},
    {70,    (ACE_Saturation_DefaultValue_YPBPR_HD * 120 / 100 )},
    {100,   (ACE_Saturation_DefaultValue_YPBPR_HD * 150 / 100 ) },
};

T_MS_NONLINEAR_CURVE code stSaturationCurveTblForYPBPR_SD =
{
    {0,     (ACE_Saturation_DefaultValue_YPBPR_SD * 1 / 100 ) },
    {50,    (ACE_Saturation_DefaultValue_YPBPR_SD    )},
    {70,    (ACE_Saturation_DefaultValue_YPBPR_SD * 120 / 100 )},
    {100,   (ACE_Saturation_DefaultValue_YPBPR_SD * 150 / 100 ) },
};

T_MS_NONLINEAR_CURVE code stSaturationCurveTblForHDMI_HD =
{
    {0,     (ACE_Saturation_DefaultValue_HDMI_HD * 1 / 100 ) },
    {50,    (ACE_Saturation_DefaultValue_HDMI_HD    )},
    {70,    (ACE_Saturation_DefaultValue_HDMI_HD * 120 / 100 )},
    {100,   (ACE_Saturation_DefaultValue_HDMI_HD * 150 / 100 ) },
};

T_MS_NONLINEAR_CURVE code stSaturationCurveTblForHDMI_SD =
{
    {0,     (ACE_Saturation_DefaultValue_HDMI_SD * 1 / 100 ) },
    {50,    (ACE_Saturation_DefaultValue_HDMI_SD    )},
    {70,    (ACE_Saturation_DefaultValue_HDMI_SD * 120 / 100 )},
    {100,   (ACE_Saturation_DefaultValue_HDMI_SD * 150 / 100 ) },
};

T_MS_NONLINEAR_CURVE code stSaturationCurveTblForVGA =
{
    {0,     (ACE_Saturation_DefaultValue_VGA_DVI * 1 / 100 ) },
    {50,    (ACE_Saturation_DefaultValue_VGA_DVI    )},
    {70,    (ACE_Saturation_DefaultValue_VGA_DVI * 120 / 100 )},
    {100,   (ACE_Saturation_DefaultValue_VGA_DVI * 150 / 100 ) },
};


//
// Sharpness
//

T_MS_NONLINEAR_CURVE code stSharpnessCurveTblForHDTV =
{
    {0,     (0x00)},
    {50,    (ACE_Sharpness_DefaultValue_HDTV - 8)},
    {70,    (ACE_Sharpness_DefaultValue_HDTV    )},
    {100,   (0x3F)},
};

T_MS_NONLINEAR_CURVE code stSharpnessCurveTblForSDTV =
{
    {0,     (0x00)},
    {50,    (ACE_Sharpness_DefaultValue_SDTV - 8)},
    {70,    (ACE_Sharpness_DefaultValue_SDTV    )},
    {100,   (0x3F)},
};

T_MS_NONLINEAR_CURVE code stSharpnessCurveTblForATV =
{
    {0,     (0x00)},
    {50,    (ACE_Sharpness_DefaultValue_ATV - 8)},
    {70,    (ACE_Sharpness_DefaultValue_ATV    )},
    {100,   (0x3F)},
};

T_MS_NONLINEAR_CURVE code stSharpnessCurveTblForAV =
{
    {0,     (0x00)},
    {50,    (ACE_Sharpness_DefaultValue_AV - 8)},
    {70,    (ACE_Sharpness_DefaultValue_AV    )},
    {100,   (0x3F)},
};

T_MS_NONLINEAR_CURVE code stSharpnessCurveTblForSV =
{
    {0,     (0x00)},
    {50,    (ACE_Sharpness_DefaultValue_SV - 8)},
    {70,    (ACE_Sharpness_DefaultValue_SV    )},
    {100,   (0x3F)},
};

T_MS_NONLINEAR_CURVE code stSharpnessCurveTblForYPBPR_HD =
{
    {0,     (0x00)},
    {50,    (ACE_Sharpness_DefaultValue_YPBPR_HD - 8)},
    {70,    (ACE_Sharpness_DefaultValue_YPBPR_HD    )},
    {100,   (0x3F)},
};

T_MS_NONLINEAR_CURVE code stSharpnessCurveTblForYPBPR_SD =
{
    {0,     (0x00)},
    {50,    (ACE_Sharpness_DefaultValue_YPBPR_SD - 8)},
    {70,    (ACE_Sharpness_DefaultValue_YPBPR_SD    )},
    {100,   (0x3F)},
};

T_MS_NONLINEAR_CURVE code stSharpnessCurveTblForHDMI_HD =
{
    {0,     (0x00)},
    {50,    (ACE_Sharpness_DefaultValue_HDMI_HD - 8)},
    {70,    (ACE_Sharpness_DefaultValue_HDMI_HD    )},
    {100,   (0x3F)},
};

T_MS_NONLINEAR_CURVE code stSharpnessCurveTblForHDMI_SD =
{
    {0,     (0x00)},
    {50,    (ACE_Sharpness_DefaultValue_HDMI_SD - 8)},
    {70,    (ACE_Sharpness_DefaultValue_HDMI_SD    )},
    {100,   (0x3F)},
};

T_MS_NONLINEAR_CURVE code stSharpnessCurveTblForVGA =
{
    {0,     (ACE_Sharpness_DefaultValue_VGA_DVI - 20)},
    {50,    (ACE_Sharpness_DefaultValue_VGA_DVI - 10)},
    {70,    (ACE_Sharpness_DefaultValue_VGA_DVI     )},
    {100,   (ACE_Sharpness_DefaultValue_VGA_DVI + 10)},
};

//==============================================================
//OSD -50 0 50
//Angle[radian] -0.349 0 0.349
//Angle[degree] -20 0 20

T_MS_NONLINEAR_CURVE code stHueCurveTbl =
{
    {0,     (ACE_Hue_DefaultValue_ATV - 15) },
    {50,    (ACE_Hue_DefaultValue_ATV) },
    {99,    (ACE_Hue_DefaultValue_ATV + 14) },
    {100,   (ACE_Hue_DefaultValue_ATV + 15) },
};

T_MS_NONLINEAR_CURVE code stHueCurveTblForHDMI =
{
    {0,     (ACE_Hue_DefaultValue_ATV - 20) },
    {50,    (ACE_Hue_DefaultValue_ATV) },
    {99,    (ACE_Hue_DefaultValue_ATV + 19) },
    {100,   (ACE_Hue_DefaultValue_ATV + 20) },
};
#endif

typedef enum{
    ePictureItem_Brightness=0,
    ePictureItem_Contrast,
    ePictureItem_Saturation,
    ePictureItem_Sharpness
} ePictureItem;

//-------------------------------------------------------------------------------------------------
//  Global Variables
//-------------------------------------------------------------------------------------------------
extern MS_S16 S16DACColorCorrectionMatrix[32];

//-------------------------------------------------------------------------------------------------
//  Local Variables
//-------------------------------------------------------------------------------------------------
#define OffsetValForSECAM_Brightness    0
#define OffsetValForSECAM_Contras       -2
#define OffsetValForSECAM_Saturation    6
#define OffsetValForSECAM_Sharpness     0

#define IsHDMIColorRangeLimitFormat(width,height,interlace) ((720 == width) && (240 == height) && (FALSE == interlace)) \
    || ((720 == width) && (288 == height) && (FALSE == interlace)) \
    || ((720 == width) && (480 == height) && (FALSE == interlace)) \
    || ((720 == width) && (576 == height) && (FALSE == interlace)) \
    || ((1440 == width) && (240 == height) && (FALSE == interlace)) \
    || ((1440 == width) && (288 == height) && (FALSE == interlace)) \
    || ((1440 == width) && (480 == height) && (FALSE == interlace)) \
    || ((1440 == width) && (576 == height) && (FALSE == interlace)) \
    || ((1280 == width) && (720 == height) && (FALSE == interlace)) \
    || ((1920 == width) && (1080 == height) && (FALSE == interlace)) \
    || ((2880 == width) && (240 == height) && (FALSE == interlace)) \
    || ((2880 == width) && (288 == height) && (FALSE == interlace)) \
    || ((2880 == width) && (480 == height) && (FALSE == interlace)) \
    || ((2880 == width) && (576 == height) && (FALSE == interlace)) \
    || ((720 == width) && (480 == height) && (TRUE == interlace)) \
    || ((720 == width) && (576 == height) && (TRUE == interlace)) \
    || ((1440 == width) && (480 == height) && (TRUE == interlace)) \
    || ((1440 == width) && (576 == height) && (TRUE == interlace)) \
    || ((1920 == width) && (1080 == height) && (TRUE == interlace)) \
    || ((2880 == width) && (480 == height) && (TRUE == interlace)) \
    || ((2880 == width) && (576 == height) && (TRUE == interlace))
//#define SATURATION_CURVE_START


//-------------------------------------------------------------------------------------------------
//  Debug Functions
//-------------------------------------------------------------------------------------------------


//-------------------------------------------------------------------------------------------------
//  Local Functions
//-------------------------------------------------------------------------------------------------


//-------------------------------------------------------------------------------------------------
//  Global Functions
//-------------------------------------------------------------------------------------------------

void MApp_PicSetNR(T_MS_NR_MODE * eNRMode, INPUT_SOURCE_TYPE_t enInputSourceType)
{
    UNUSED(enInputSourceType);

    switch(eNRMode -> eNR)
    {
        case MS_NR_OFF:
            MApi_XC_Sys_PQ_SetNR( E_XC_PQ_3D_NR_OFF, MAIN_WINDOW );
        break;
        case MS_NR_LOW:
            MApi_XC_Sys_PQ_SetNR( E_XC_PQ_3D_NR_LOW, MAIN_WINDOW );
        break;
        case MS_NR_MIDDLE:
            MApi_XC_Sys_PQ_SetNR( E_XC_PQ_3D_NR_MID, MAIN_WINDOW );
        break;
        case MS_NR_HIGH:
            MApi_XC_Sys_PQ_SetNR( E_XC_PQ_3D_NR_HIGH, MAIN_WINDOW );
        break;
        case MS_NR_DEFAULT:
            MApi_XC_Sys_PQ_SetNR( E_XC_PQ_3D_NR_DEFAULT, MAIN_WINDOW );
        break;
        default:
        case MS_NR_AUTO:
            MApi_XC_Sys_PQ_SetNR( E_XC_PQ_3D_NR_AUTO, MAIN_WINDOW );
        break;
    }
}

//////////////////////////////////////////////////////////////////
// Set user(UI) PQ settings
// including: DLC/ACE 3x3 matrix/NR/
//            HUE/Saturation/Brightness/Contrast/black level/Gamma
// parameter:
//    [IN]  enInputSourceType
//////////////////////////////////////////////////////////////////

static void MApp_Picture_ColorCtrl(INPUT_SOURCE_TYPE_t enInputSourceType, SCALER_WIN eWindow)
{
    PQ_WIN enPQWin = PQ_MAIN_WINDOW;
    PQ_DISPLAY_TYPE enDisplaType = PQ_DISPLAY_ONE;

  #if (ENABLE_PIP)
    switch(eWindow)
    {
        default:
        case MAIN_WINDOW:
            enPQWin = PQ_MAIN_WINDOW;
            break;
        case SUB_WINDOW:
            enPQWin = PQ_SUB_WINDOW;
            break;
    }
  #endif

    if(U16PQSrcType!= MDrv_PQ_GetSrcType(enPQWin))
    {
    #if (ENABLE_PIP)
        if(IsPIPSupported())
        {
            switch(stGenSetting.g_stPipSetting.enPipMode)
            {
                case EN_PIP_MODE_PIP:
                    enDisplaType = PQ_DISPLAY_PIP;
                    //printf("PQ_DISPLAY_PIP\n");
                break;
                case EN_PIP_MODE_POP_FULL:
                case EN_PIP_MODE_POP:
                    enDisplaType = PQ_DISPLAY_POP;
                    //printf("PQ_DISPLAY_POP\n");
                break;
                case EN_PIP_MODE_OFF:
                case EN_PIP_MODE_INVALID:
                    enDisplaType = PQ_DISPLAY_ONE;
                    //printf("PQ_DISPLAY_ONE\n");
                break;
            }
        }
    #endif
        MDrv_PQ_Set_DisplayType(g_IPanel.Width(), enDisplaType);
        MDrv_PQ_LoadSettings(enPQWin);

        U16PQSrcType = MDrv_PQ_GetSrcType(enPQWin);

        if(MDrv_PQ_Get_PointToPoint(PQ_MAIN_WINDOW))
        {
          MDrv_PQ_LoadPTPTable(PQ_MAIN_WINDOW, PQ_PTP_PTP);
        }

    }

    //Regarding software detection of RGB Quantization Range
    //check information of AVI InfoFrame that is sent from HDMI source together with HDMI video/audio signal.
    if ((enInputSourceType >= INPUT_SOURCE_HDMI)  && (enInputSourceType < INPUT_SOURCE_HDMI_MAX)) //check source type
    {

        MS_U16 u16InputWidth = MDrv_PQ_GetHsize(enPQWin);
        MS_U16 u16InputHeight = MDrv_PQ_GetVsize(enPQWin);
        MS_BOOL bIsInterlaced = MDrv_PQ_IsInterlace(enPQWin);
        // check whether received AVI info
        if ((BIT(3) == MApi_XC_HDMI_GetPacketInfo()->enPKT_Value.PKT_AVI_VALUE)
            && (E_AVI_INFOFRAME_VERSION2 == MDrv_HDMI_Get_AVIInfoFrameVer()))
        {
            if (E_HDMI_COLOR_RANGE_LIMIT == MDrv_HDMI_Get_ColorRange()) //color range limit and version 2
            {
                stGenSetting.g_SysSetting.fCOLORRANGE = FALSE;
            }
            else if (E_HDMI_COLOR_RANGE_FULL == MDrv_HDMI_Get_ColorRange()) //color range full and version 2
            {
                stGenSetting.g_SysSetting.fCOLORRANGE = TRUE;
            }
            else // color range default
            {
                if (TRUE == IsHDMIColorRangeLimitFormat(u16InputWidth, u16InputHeight, bIsInterlaced))
                {
                    stGenSetting.g_SysSetting.fCOLORRANGE = FALSE;
                }
                else
                {
                    stGenSetting.g_SysSetting.fCOLORRANGE = TRUE;
                }
            }
        }
        else // no avi info or not version 2
        {
            // check whether color range limit format
            if (TRUE == IsHDMIColorRangeLimitFormat(u16InputWidth, u16InputHeight, bIsInterlaced))
            {
                stGenSetting.g_SysSetting.fCOLORRANGE = FALSE;
            }
            else
            {
                stGenSetting.g_SysSetting.fCOLORRANGE = TRUE;
            }
        }
    }
    else if ((enInputSourceType >= INPUT_SOURCE_DVI) && (enInputSourceType < INPUT_SOURCE_DVI_MAX))
    {
        stGenSetting.g_SysSetting.fCOLORRANGE = TRUE;
    }

#if ENABLE_DBC
    if(eWindow == MAIN_WINDOW)
    {
        MApi_XC_Sys_DLC_DBC_YCGainInit();
    }
#else
  #if ENABLE_DLC
    if(eWindow == MAIN_WINDOW)
    {
        MApi_XC_DLC_CGC_Init();
    }
  #endif
#endif

    if(IsSrcTypeATV(enInputSourceType))
    {
        MApi_XC_ACE_DMS(MAIN_WINDOW, TRUE) ;
    }
    else
    {
        MApi_XC_ACE_DMS(MAIN_WINDOW, FALSE) ;
    }

#if (ENABLE_DLC)
#if 0
    if( MApi_XC_DLC_GetLumaCurveStatus())
    {
        #if ENABLE_CUS_HDMI_MODE
        if(MApp_Scaler_CheckDBC_DLCAvailable() == FALSE)
        {
            g_bEnableDLC = FALSE;		
			ST_PICTURE.bDLCStatus = (EN_DLC_STATUS)g_bEnableDLC;
        }
        else
        #endif
        {
            #if ENABLE_CUS_DLC
            g_bEnableDLC = ST_PICTURE.bDLCStatus;
            MApi_XC_DLC_SetOnOff(g_bEnableDLC, MAIN_WINDOW);
            #else
            if (!g_bEnableDLC)
            {
                g_bEnableDLC = TRUE;
				
				ST_PICTURE.bDLCStatus = g_bEnableDLC;
                MApi_XC_DLC_SetOnOff(ENABLE, MAIN_WINDOW);
            }
            #endif
        }
    }
    else
    {
        g_bEnableDLC = FALSE;
		ST_PICTURE.bDLCStatus = (EN_DLC_STATUS)g_bEnableDLC;
    }
#else
g_bEnableDLC = ST_PICTURE.bDLCStatus;
MApi_XC_DLC_SetOnOff(ST_PICTURE.bDLCStatus, MAIN_WINDOW);
#endif
#endif

#if (ENABLE_DBC)
    if( MApi_XC_DLC_GetLumaCurveStatus())
    {
        MApi_XC_Sys_DLC_DBC_OnOff(ENABLE);
    }
    else
    {
        MApi_XC_Sys_DLC_DBC_OnOff(DISABLE);
    }
#endif
}

code short  tBypassColorCorrectionMatrix[] =
{
   0x0400, 0x0000, 0x0000, 0x0000, 0x0400, 0x0000, 0x0000, 0x0000,
   0x0400,-0x02E6, 0x0288,-0x05BB, 0x07A4,-0x062C, 0x06F3,-0x073C,
  -0x0024, 0x01BF, 0x07EF,-0x0116, 0x01EE, 0x052C,-0x03BB, 0x00B1,
  -0x0831, 0x0100,-0x0000, 0x0000,-0x0000, 0x0000, 0x0000, 0x0000,
};

void MApp_Picture_Setting_SetColor( INPUT_SOURCE_TYPE_t enInputSourceType, SCALER_WIN eWindow )
{
    PQ_WIN ePQWin;

    switch(eWindow)
    {
        default:
        case MAIN_WINDOW:
            ePQWin = PQ_MAIN_WINDOW;
            break;
        case SUB_WINDOW:
            ePQWin = PQ_SUB_WINDOW;
            break;
    }

    //printf("%s Set Color\n", (ePQWin == PQ_MAIN_WINDOW)?("Main win"):("Sub win"));
    // bandwidth setting

    MDrv_WRAP_BW_LoadTableByContext(ePQWin);

    // ACE related
    MApp_Picture_ColorCtrl(enInputSourceType, eWindow);

    if(MDrv_PQ_Get_PointToPoint(PQ_MAIN_WINDOW))
    {
        MApi_XC_ACE_ColorCorrectionTable( MAIN_WINDOW, (S16*)tBypassColorCorrectionMatrix);
    }
    else
    {
        MApi_XC_ACE_ColorCorrectionTable( MAIN_WINDOW, (S16*)tVideoColorCorrectionMatrix);
    }

    // Color Range setting
    #if 0//VGA_HDMI_YUV_POINT_TO_POINT
	 //if(IsHDMIInUse()&&MDrv_PQ_Get_HDMIPCMode()&&(MDrv_PQ_GetUserColorMode()==FALSE))
        if(IsHDMIInUse()&&MDrv_PQ_Check_PointToPoint_Mode())
        {
		//ptp do nothing
        }
	else
    #endif
    {
        if(IsVgaInUse())
        {
            MDrv_PQ_SetColorRange(PQ_MAIN_WINDOW, 1);
        }
        else if(IsHDMIInUse())
        {
            MDrv_PQ_SetColorRange(PQ_MAIN_WINDOW, stGenSetting.g_SysSetting.fCOLORRANGE);
        }
    }

    if(MApi_XC_IsYUVSpace(eWindow))
    {
    #if 0//VGA_HDMI_YUV_POINT_TO_POINT
       if(IsHDMIInUse()&&MDrv_PQ_Get_HDMIPCMode())//&&(MDrv_PQ_GetUserColorMode()))
        {
            MApi_XC_ACE_SetPCYUV2RGB( eWindow, FALSE);
        }
       else
    #endif
       {
            MApi_XC_ACE_SetPCYUV2RGB( eWindow, TRUE);
            if((IsDigitalSourceInUse() && ((mvideo_vd_get_videosystem() == SIG_NTSC) || (mvideo_vd_get_videosystem() == SIG_NTSC_443))))
            {
                MApi_XC_ACE_PicSetHue( eWindow, MApi_XC_IsYUVSpace(eWindow), msAPI_Mode_PictureHueN100toReallyValue( ST_VIDEO.astPicture[ST_VIDEO.ePicture].u8Hue) );
            }
            else
            {
                MApi_XC_ACE_PicSetHue( eWindow, MApi_XC_IsYUVSpace(eWindow), msAPI_Mode_PictureHueN100toReallyValue(50) );
            }

            #if ENABLE_CUS_UI_SPEC
            if((IsHDMIInUse()&&(g_HdmiPollingStatus.bIsHDMIMode == TRUE) && (ST_VIDEO.eAspectRatio == EN_AspectRatio_point_to_point))
                #if VGA_HDMI_YUV_POINT_TO_POINT
                || (IsHDMIInUse()&&MDrv_PQ_Check_PointToPoint_Mode() && (ST_VIDEO.eAspectRatio == EN_AspectRatio_point_to_point))
                #endif
            )
            {
                MApi_XC_ACE_PicSetSaturation( eWindow, MApi_XC_IsYUVSpace(eWindow), msAPI_Mode_PictureSaturationN100toReallyValue( 50) );
            }
            else
            #endif
            {
                MApi_XC_ACE_PicSetSaturation( eWindow, MApi_XC_IsYUVSpace(eWindow), msAPI_Mode_PictureSaturationN100toReallyValue( ST_VIDEO.astPicture[ST_VIDEO.ePicture].u8Saturation) );
            }

          {
                if(MApi_XC_Sys_IsSrcHD(eWindow))
                {
                    MApi_XC_ACE_SelectYUVtoRGBMatrix( eWindow, E_XC_ACE_YUV_TO_RGB_MATRIX_HDTV, NULL);
                }
                else
                {
                    MApi_XC_ACE_SelectYUVtoRGBMatrix( eWindow, E_XC_ACE_YUV_TO_RGB_MATRIX_SDTV, NULL);
                }
            }
        }
    }
    else
    {
        MApi_XC_ACE_SetPCYUV2RGB( eWindow, FALSE);
    }
#if 0//VGA_HDMI_YUV_POINT_TO_POINT
    if(IsHDMIInUse()&&MDrv_PQ_Get_HDMIPCMode())//&&(MDrv_PQ_GetUserColorMode()))
    {
         printf("-PicSetSharpness nothing-\n");//do thing
    }
    else
#endif
    {
        MApi_XC_ACE_PicSetSharpness( MAIN_WINDOW, msAPI_Mode_PictureSharpnessN100toReallyValue(ST_VIDEO.astPicture[ST_VIDEO.ePicture].u8Sharpness) );
    }

    MApi_XC_ACE_PicSetBrightnessInVsync(MAIN_WINDOW, MApi_XC_Sys_ACE_transfer_Bri((MApp_Scaler_FactoryAdjBrightness(msAPI_Mode_PictureBrightnessN100toReallyValue(ST_PICTURE.u8Brightness),ST_SUBCOLOR.u8SubBrightness)), BRIGHTNESS_R), MApi_XC_Sys_ACE_transfer_Bri((MApp_Scaler_FactoryAdjBrightness(msAPI_Mode_PictureBrightnessN100toReallyValue(ST_PICTURE.u8Brightness),ST_SUBCOLOR.u8SubBrightness)), BRIGHTNESS_G), MApi_XC_Sys_ACE_transfer_Bri((MApp_Scaler_FactoryAdjBrightness(msAPI_Mode_PictureBrightnessN100toReallyValue(ST_PICTURE.u8Brightness),ST_SUBCOLOR.u8SubBrightness)), BRIGHTNESS_B));
#if 0//VGA_HDMI_YUV_POINT_TO_POINT
    if(IsHDMIInUse()&&MDrv_PQ_Get_HDMIPCMode())//&&(MDrv_PQ_GetUserColorMode()))
    {
#if ENABLE_PRECISE_RGBBRIGHTNESS
           MApi_XC_ACE_PicSetColorTemp( eWindow, FALSE, (XC_ACE_color_temp_ex *) &ST_WHITEBALANCE.astColorTemp[ST_VIDEO.astPicture[ST_VIDEO.ePicture].eColorTemp] );
#else
           MApi_XC_ACE_PicSetColorTemp( eWindow, FALSE, (XC_ACE_color_temp *) &ST_WHITEBALANCE.astColorTemp[ST_VIDEO.astPicture[ST_VIDEO.ePicture].eColorTemp] );
           MApi_XC_ACE_PicSetBrightnessInVsync(MAIN_WINDOW, MApi_XC_Sys_ACE_transferRGB_Bri(ST_WHITEBALANCE.astColorTemp[ST_VIDEO.astPicture[ST_VIDEO.ePicture].eColorTemp].cRedOffset, BRIGHTNESS_R ), MApi_XC_Sys_ACE_transferRGB_Bri(ST_WHITEBALANCE.astColorTemp[ST_VIDEO.astPicture[ST_VIDEO.ePicture].eColorTemp].cGreenOffset, BRIGHTNESS_G), MApi_XC_Sys_ACE_transferRGB_Bri(ST_WHITEBALANCE.astColorTemp[ST_VIDEO.astPicture[ST_VIDEO.ePicture].eColorTemp].cBlueOffset, BRIGHTNESS_B));
#endif
           MApi_XC_ACE_PicSetContrast(MAIN_WINDOW, FALSE, MApp_Scaler_FactoryContrast(msAPI_Mode_PictureContrastN100toReallyValue(ST_PICTURE.u8Contrast),ST_SUBCOLOR.u8SubContrast));

          // MApp_PicSetNR( (T_MS_NR_MODE*) &ST_VIDEO.eNRMode, enInputSourceType );
    }
    else
#endif
    {
#if ENABLE_PRECISE_RGBBRIGHTNESS
        MApi_XC_ACE_PicSetColorTemp( eWindow, MApi_XC_IsYUVSpace(eWindow), (XC_ACE_color_temp_ex *) &ST_WHITEBALANCE.astColorTemp[ST_VIDEO.astPicture[ST_VIDEO.ePicture].eColorTemp] );
#else
        MApi_XC_ACE_PicSetColorTemp( eWindow, MApi_XC_IsYUVSpace(eWindow), (XC_ACE_color_temp *) &ST_WHITEBALANCE.astColorTemp[ST_VIDEO.astPicture[ST_VIDEO.ePicture].eColorTemp] );
        MApi_XC_ACE_PicSetBrightnessInVsync(MAIN_WINDOW, MApi_XC_Sys_ACE_transferRGB_Bri(ST_WHITEBALANCE.astColorTemp[ST_VIDEO.astPicture[ST_VIDEO.ePicture].eColorTemp].cRedOffset, BRIGHTNESS_R ), MApi_XC_Sys_ACE_transferRGB_Bri(ST_WHITEBALANCE.astColorTemp[ST_VIDEO.astPicture[ST_VIDEO.ePicture].eColorTemp].cGreenOffset, BRIGHTNESS_G), MApi_XC_Sys_ACE_transferRGB_Bri(ST_WHITEBALANCE.astColorTemp[ST_VIDEO.astPicture[ST_VIDEO.ePicture].eColorTemp].cBlueOffset, BRIGHTNESS_B));
#endif

        MApi_XC_ACE_PicSetContrast(MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), MApp_Scaler_FactoryContrast(msAPI_Mode_PictureContrastN100toReallyValue(ST_PICTURE.u8Contrast),ST_SUBCOLOR.u8SubContrast));

    // NR
    #if ENABLE_CUS_HDMI_MODE
        if(MApp_Scaler_CheckDBC_DLCAvailable() == FALSE)
        {
            /*
            T_MS_NR_MODE tempeNRMode;
            tempeNRMode.eNR = MS_NR_OFF;
            tempeNRMode.eMPEG_NR = MS_MPEG_NR_OFF;
            MApp_PicSetNR( (T_MS_NR_MODE*) &tempeNRMode, enInputSourceType );
            */
            MApi_XC_Sys_PQ_SetNR( E_XC_PQ_3D_NR_OFF, MAIN_WINDOW );
        }
        else
    #endif
        {
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
             MApp_PicSetNR( (T_MS_NR_MODE*) &ST_PICTURE.eNRMode, enInputSourceType );
            #else
             MApp_PicSetNR( (T_MS_NR_MODE*) &ST_VIDEO.eNRMode, enInputSourceType );
            #endif
        }
        mAPI_DynamicNR_GetGuassinSNR();
        msAPI_DynamicNR_GetSharpness();
        msAPI_DynamicNR_GetCoring();
    }

#if ENABLE_3D_PROCESS
    MDrv_PQ_3DCloneforPIP(TRUE);
#endif

#if (ENABLE_CUS_DBC)
    MApi_XC_Sys_DLC_DBC_OnOff( );
#endif
    // ADC related
    if(IsSrcTypeScart(enInputSourceType) && msAPI_AVD_IsScartRGB())
    {
        MApi_XC_ADC_AdjustGainOffset(&stGenSettingExt.g_AdcSetting[ADC_SET_SCART_RGB].stAdcGainOffsetSetting);
    }

    // DLC related
#if ENABLE_DLC
    if(!IsSrcTypeHDMI(SYS_INPUT_SOURCE_TYPE(eWindow)))
    {
        if (MApi_XC_IsYUVSpace(eWindow))
        {
        #if ENABLE_DMP
            if(IsSrcTypeStorage(enInputSourceType) &&
               (MApp_MPlayer_QueryCurrentMediaType() == E_MPLAYER_TYPE_PHOTO))
            {
                #if 1//(defined(S3PLUS)) fix luminance changed during Photo display
                MApi_XC_DLC_SetOnOff(DISABLE, eWindow);
                #endif
            }
        #endif
        }
    }
#endif

    // DBC related
#if ENABLE_DBC
    if(!IsSrcTypeHDMI(SYS_INPUT_SOURCE_TYPE(eWindow)))
    {
        if (MApi_XC_IsYUVSpace(eWindow))
        {
        #if ENABLE_DMP
            if(IsSrcTypeStorage(enInputSourceType) &&
               (MApp_MPlayer_QueryCurrentMediaType() == E_MPLAYER_TYPE_PHOTO))
            {
                MApi_XC_Sys_DLC_DBC_OnOff(DISABLE);
            }
        #endif
        }
    }
#endif

#ifdef ENABLE_GAMMA_FOR_COLORTEMP
    MApi_XC_Sys_AdjustGammaTbl(NORMAL_SET_VALUE);
#endif

#if ENABLE_TCON
    MApi_XC_SetGammaOnOff(0);
#elif( CHIP_FAMILY_TYPE == CHIP_FAMILY_A7 )
    MApi_XC_SetGammaOnOff(0);
#else
    MApi_XC_SetGammaOnOff(1);
#endif

#if ENABLE_CUS_DBC //ENABLE_CUS_UI_SPEC
    if(ST_PICTURE.bDBCStatus == DBC_STATUS_OFF)
    {
        Panel_Backlight_PWM_ADJ(msAPI_Mode_PictureBackLightN100toReallyValue(ST_PICTURE.u8Backlight));
    }
#endif
#if 0//MWE_FUNCTION
    if ((IsVgaInUse())||((!g_HdmiPollingStatus.bIsHDMIMode)&&IsHDMIInUse()&&( g_HdmiPollingStatus.u8ColorFormat == MS_HDMI_COLOR_RGB)))
    {
         U8 u8EngineSettingMode = stGenSetting.g_SysSetting.u8EngineSetting;
         stGenSetting.g_SysSetting.u8EngineSetting = EN_MWE_OFF;
         MApp_ZUI_ACT_AdjustEngineSetting();
         stGenSetting.g_SysSetting.u8EngineSetting = u8EngineSettingMode;
    }
    else
    {
         MDrv_MWE_GetMWEQuality();
         MApp_ZUI_ACT_AdjustEngineSetting();
    }
#endif
#if 0//VGA_HDMI_YUV_POINT_TO_POINT
    if(IsHDMIInUse()&&MDrv_PQ_Get_HDMIPCMode()&&(MDrv_PQ_GetUserColorMode()==FALSE))
    {
        {
            T_MS_NR_MODE eNRModeTmp;
            eNRModeTmp.eNR = MS_NR_OFF;
            eNRModeTmp.eMPEG_NR =MS_MPEG_NR_OFF;
            MDrv_PQ_SetColorRange(PQ_MAIN_WINDOW, TRUE);
            MDrv_PQ_SetPointToPonitMode(ENABLE);
            MApp_PicSetNR( (T_MS_NR_MODE*) &eNRModeTmp, SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW) );
           MApi_XC_ACE_PicSetContrast(MAIN_WINDOW, FALSE, MApp_Scaler_FactoryContrast(msAPI_Mode_PictureContrastN100toReallyValue(ST_PICTURE.u8Contrast),ST_SUBCOLOR.u8SubContrast));
        }
    }
    else if((ST_VIDEO.eAspectRatio != EN_AspectRatio_point_to_point))
    {
       MDrv_PQ_LoadVIPTable();
    }
#endif

    Panel_Backlight_PWM_ADJ(msAPI_Mode_PictureBackLightN100toReallyValue(ST_PICTURE.u8Backlight));
#if ENABLE_3D_PROCESS
    MDrv_PQ_3DCloneforPIP(TRUE);
#endif
}


U8 _msAPI_Mode_GetPictureOffsetValForSECAM(ePictureItem PictureItem, U8 u8value)
{
    char _u8OffsetTmp=0;

    if (/*IsSrcTypeATV(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)) ||*/ IsSrcTypeAV(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW))||
        IsSrcTypeScart(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)) || IsSrcTypeSV(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)))
    {
        if(mvideo_vd_get_videosystem() == SIG_SECAM )
        {
            switch(PictureItem)
            {
                case ePictureItem_Brightness:   _u8OffsetTmp = OffsetValForSECAM_Brightness;    break;
                case ePictureItem_Contrast:     _u8OffsetTmp = OffsetValForSECAM_Contras;       break;
                case ePictureItem_Saturation:   _u8OffsetTmp = OffsetValForSECAM_Saturation;    break;
                case ePictureItem_Sharpness:    _u8OffsetTmp = OffsetValForSECAM_Sharpness;     break;
                default:                        _u8OffsetTmp = 0;   break;
            }
            if(u8value == 0)
                _u8OffsetTmp = 0;
            if(u8value == 100)
                _u8OffsetTmp = 0;
        }
    }
    return (u8value+_u8OffsetTmp)>=100 ? 100:((u8value+_u8OffsetTmp)<=0? 0:(u8value+_u8OffsetTmp));
}

/******************************************************************************/
///-This function will get true value of contrast for picture mode
///@param u8value: scaled value
///@return true value of contrast
//*************************************************************************
U8 msAPI_Mode_PictureContrastN100toReallyValue ( U8 u8value )
{
    u8value =_msAPI_Mode_GetPictureOffsetValForSECAM(ePictureItem_Contrast,u8value);

#if(ENABLE_PICTURE_NONLINEAR_CURVE)
    return MApp_NonLinearCalculate(MApp_GetNonLinearCurve(NONLINEAR_CURVE_CONTRAST),u8value);
#else
    return N100toReallyValue( u8value, MIN_VIDEO_CONTRAST, MAX_VIDEO_CONTRAST );
#endif
}

/******************************************************************************/
///-This function will get true value of Brightness for picture mode
///@param u8value: scaled value
///@return true value of Brightness
//*************************************************************************
U8 msAPI_Mode_PictureBrightnessN100toReallyValue ( U8 u8value )
{
    u8value = _msAPI_Mode_GetPictureOffsetValForSECAM(ePictureItem_Brightness,u8value);
#if(ENABLE_PICTURE_NONLINEAR_CURVE)
    return MApp_NonLinearCalculate(MApp_GetNonLinearCurve(NONLINEAR_CURVE_BRIGHTNESS),u8value);
#else
    return N100toReallyValue( u8value, MIN_VIDEO_BRIHTNESS, MAX_VIDEO_BRIHTNESS );
#endif
    //return msAPI_CalNonLinearCurve(u8value, &stBrightnessCurveTbl );
}

/******************************************************************************/
///-This function will get true value of Brightness for picture mode
///@param u8value: scaled value
///@return true value of Brightness
//*************************************************************************

/******************************************************************************/
///-This function will get true value of hue for picture mode
///@param u8value: scaled value
///@return  true value of hue true value of hue
//*************************************************************************
U8 msAPI_Mode_PictureHueN100toReallyValue ( U8 u8value )
{
#if(ENABLE_PICTURE_NONLINEAR_CURVE)
    return MApp_NonLinearCalculate(MApp_GetNonLinearCurve(NONLINEAR_CURVE_HUE),u8value);
#else
    if(MApi_XC_HDMI_GetHdmiType(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)) == E_HDMI_STATUS_HDMI)
    {
        return msAPI_CalNonLinearCurve(u8value, &stHueCurveTblForHDMI );
    }
    else
    {
        return msAPI_CalNonLinearCurve(u8value, &stHueCurveTbl );
    }
#endif
}

/******************************************************************************/
///-This function will get true value of saturation for picture mode
///@param u8value: scaled saturation
///@return true value of saturation
//*************************************************************************
U8 msAPI_Mode_PictureSaturationN100toReallyValue ( U8 u8value )
{
    T_MS_NONLINEAR_CURVE* pCurve;

    u8value = _msAPI_Mode_GetPictureOffsetValForSECAM(ePictureItem_Saturation,u8value);

#if(ENABLE_PICTURE_NONLINEAR_CURVE)

    pCurve = NULL;//fix uncall warning.

    return MApp_NonLinearCalculate(MApp_GetNonLinearCurve(NONLINEAR_CURVE_SATURATION),u8value);

#else

    if (IsSrcTypeDTV(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)))
    {
        if (MApi_XC_Sys_IsSrcHD(MAIN_WINDOW))
        {
            pCurve = &stSaturationCurveTblForHDTV;
        }
        else
        {
            pCurve = &stSaturationCurveTblForSDTV;
        }
    }
    else if (IsSrcTypeATV(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)))
    {
        pCurve = &stSaturationCurveTblForATV;
    }
    else if (IsSrcTypeAV(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW))
    #if (INPUT_SCART_VIDEO_COUNT > 0)
             || IsSrcTypeScart(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW))
    #endif
            )
    {
        pCurve = &stSaturationCurveTblForAV;
    }
    else if (IsSrcTypeSV(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)))
    {
        pCurve = &stSaturationCurveTblForSV;
    }
    else if (IsSrcTypeYPbPr(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)))
    {
        if (MApi_XC_Sys_IsSrcHD(MAIN_WINDOW))
        {
            pCurve = &stSaturationCurveTblForYPBPR_HD;
        }
        else
        {
            pCurve = &stSaturationCurveTblForYPBPR_SD;
        }
    }
  #if (INPUT_HDMI_VIDEO_COUNT > 0)
    else if(MApi_XC_HDMI_GetHdmiType(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)) == E_HDMI_STATUS_HDMI)
    {
        if (MApi_XC_Sys_IsSrcHD(MAIN_WINDOW))
        {
            pCurve = &stSaturationCurveTblForHDMI_HD;
        }
        else
        {
            pCurve = &stSaturationCurveTblForHDMI_SD;
        }
    }
  #endif
    else /* VGA & DVI */
    {
        pCurve = &stSaturationCurveTblForVGA;
    }

    return msAPI_CalNonLinearCurve(u8value, pCurve);
#endif
}

/******************************************************************************/
///-This function will get true value of sharpness for picture mode
///@param u8value: scaled sharpness
///@return true value of sharpness
//*************************************************************************
U8 msAPI_Mode_PictureSharpnessN100toReallyValue ( U8 u8value )
{
    T_MS_NONLINEAR_CURVE* pCurve;

    u8value = _msAPI_Mode_GetPictureOffsetValForSECAM(ePictureItem_Sharpness,u8value);

#if(ENABLE_PICTURE_NONLINEAR_CURVE)
    pCurve = NULL;//fix uncall warning.
    return MApp_NonLinearCalculate(MApp_GetNonLinearCurve(NONLINEAR_CURVE_SHARPNESS),u8value);
#else
    if (IsSrcTypeDTV(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)))
    {
        if (MApi_XC_Sys_IsSrcHD(MAIN_WINDOW))
        {
            pCurve = &stSharpnessCurveTblForHDTV;
        }
        else
        {
            pCurve = &stSharpnessCurveTblForSDTV;
        }
    }
    else if (IsSrcTypeATV(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)))
    {
        pCurve = &stSharpnessCurveTblForATV;
    }
    else if (IsSrcTypeAV(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW))
    #if (INPUT_SCART_VIDEO_COUNT > 0)
            || IsSrcTypeScart(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW))
    #endif
            )
    {
        pCurve = &stSharpnessCurveTblForAV;
    }
    else if (IsSrcTypeSV(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)))
    {
        pCurve = &stSharpnessCurveTblForSV;
    }
    else if (IsSrcTypeYPbPr(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)))
    {
        if (MApi_XC_Sys_IsSrcHD(MAIN_WINDOW))
        {
            pCurve = &stSharpnessCurveTblForYPBPR_HD;
        }
        else
        {
            pCurve = &stSharpnessCurveTblForYPBPR_SD;
        }
    }
    #if (INPUT_HDMI_VIDEO_COUNT > 0)
    else if(MApi_XC_HDMI_GetHdmiType(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)) == E_HDMI_STATUS_HDMI)
    {
        if (MApi_XC_Sys_IsSrcHD(MAIN_WINDOW))
        {
            pCurve = &stSharpnessCurveTblForHDMI_HD;
        }
        else
        {
            pCurve = &stSharpnessCurveTblForHDMI_SD;
        }
    }
    #endif
    else /* VGA & DVI */
    {
        pCurve = &stSharpnessCurveTblForVGA;
    }

    return msAPI_CalNonLinearCurve(u8value, pCurve);
#endif
}


#undef _APP_XC_PQ_C_

