////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
//
// @file
// @brief
// @author MStarSemi Inc.
//
//-
//-
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MAPP_MASSSTORAGE_H
#define    _MAPP_MASSSTORAGE_H

#include "datatype.h"
#include "debug.h"

#include "msAPI_MSDCtrl.h"


/*enumeration ===================================================================================*/
enum MS_ERROR_CODE
{
    MS_ERROR_CODE_FAIL                  = 0,
    MS_ERROR_CODE_TRUE                  = 1,
    MS_ERROR_CODE_NO_SYS                = 2,
    MS_ERROR_CODE_NO_ROOT               = 3
};

/*definition ====================================================================================*/
#define MS_MAX_DRIVE_SUPPORT        2

#define MS_USB_CONNECTED            BIT0
#define MS_USB2_CONNECTED           BIT1
#if ENABLE_CARDREADER
#define MS_CREAD_CONNECTED          BIT2
#endif
#define MS_DEVICE_AUTO_DETECT       BIT3
#define MS_PLAYALL                  BIT4
#define MPLAYER_MUSIC_WITH_LYRIC    BIT5  // 1: with lyric    0: no lyric
#define MPLAYER_PAUSE_DECODE_PHOTO  BIT6

/*function ======================================================================================*/
#ifdef MAPP_MASSSTORAGE
#define MASSSTORAGE_INTERFACE
#else
#define MASSSTORAGE_INTERFACE extern
#endif

//init/deinit ===================================================================================//
//MASSSTORAGE_INTERFACE BOOLEAN MApp_MassStorage_Init(U8 u8DriveLetter, MSDCtrl_Drive * pstConnectDrive);   //<---non public
//MASSSTORAGE_INTERFACE void MApp_MassStorage_DeInit(U8 u8DriveLetter);                                     //<---non public

//device monitor ================================================================================//
MASSSTORAGE_INTERFACE U8 MApp_MassStorage_DeviceConnectionDetect(void);
MASSSTORAGE_INTERFACE BOOLEAN MApp_MassStorage_DeviceStatusCheck(void);
MASSSTORAGE_INTERFACE BOOLEAN MApp_MassStorage_DeviceChangeStatusCheck(void);
MASSSTORAGE_INTERFACE BOOLEAN MApp_MassStorage_DeviceGetStatus(U8 u8DeviceIndex, U8 u8DriveIndex);
MASSSTORAGE_INTERFACE BOOLEAN MApp_MassStorage_DeviceDisconnect(void);
MASSSTORAGE_INTERFACE U8 MApp_MassStorage_GetCurrentDeviceIndex(void);
MASSSTORAGE_INTERFACE U8 MApp_MassStorage_GetDriveDevice(U8 drvIndex);

//drive monitor ================================================================================//
MASSSTORAGE_INTERFACE BOOLEAN MApp_MassStorage_DriveConnect(U8 u8DriveIndex);
MASSSTORAGE_INTERFACE BOOLEAN MApp_MassStorage_DriveDisconnect(U8 u8DriveIndex);
MASSSTORAGE_INTERFACE U8 MApp_MassStorage_GetTotalDriveNum(void);
MASSSTORAGE_INTERFACE U8 MApp_MassStorage_GetTotalDriveNumPerPort(EN_MSD_PORT port);
MASSSTORAGE_INTERFACE EN_MSD_PORT MApp_MassStorage_GetDrivePort(U8 drvIndex);
MASSSTORAGE_INTERFACE U8 MApp_MassStorage_GetCurrentDriveIndex(void);
MASSSTORAGE_INTERFACE U8 MApp_MassStorage_GetNextDriveIndexByDevice(U8 u8Port, U8 u8CurrentDriveIndex);
MASSSTORAGE_INTERFACE U8 MApp_MassStorage_GetPrevDriveIndexByDevice(U8 u8Port, U8 u8CurrentDriveIndex);
MASSSTORAGE_INTERFACE U8 MApp_MassStorage_GetFirstDriveByPort(EN_MSD_PORT port);
/*===============================================================================================*/
MASSSTORAGE_INTERFACE U16 MApp_MassStorage_GetValidDevice(void);
MASSSTORAGE_INTERFACE void MApp_MassStorage_Init(void);

#endif//_MAPP_MASSSTORAGE_H

