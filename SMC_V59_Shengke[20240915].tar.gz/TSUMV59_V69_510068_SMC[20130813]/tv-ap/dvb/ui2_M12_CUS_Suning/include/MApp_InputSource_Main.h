////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MAPP_INPUTSOURCE_MAIN_H
#define _MAPP_INPUTSOURCE_MAIN_H

#include "datatype.h"
#include "MApp_Exit.h"

#ifdef MAPP_INPUTSOURCE_MAIN_C
#define INTERFACE
#else
#define INTERFACE extern
#endif

typedef enum
{
    STATE_INPUTSOURCE_INIT,
    STATE_INPUTSOURCE_WAIT,
    STATE_INPUTSOURCE_CLEAN_UP,
    STATE_INPUTSOURCE_GOTO_STANDBY,
    STATE_INPUTSOURCE_GOTO_MAIN_MENU,
#if ENABLE_DMP
    STATE_INPUTSOURCE_GOTO_DMP,
#endif
    STATE_INPUTSOURCE_GOTO_CH_INFO,

#ifdef ENABLE_BT
    STATE_INPUTSOURCE_GOTO_BT,
#endif
#ifdef ENABLE_EXTENSION
    STATE_INPUTSOURCE_GOTO_EXTENSION,
#endif
#ifdef ENABLE_KTV
    STATE_INPUTSOURCE_GOTO_KTV,
#endif

#ifdef ENABLE_YOUTUBE
    STATE_INPUTSOURCE_GOTO_YOUTUBE,
#endif

#ifdef ENABLE_RSS
    STATE_INPUTSOURCE_GOTO_RSS,
#endif
#if (ENABLE_GAME)
    STATE_INPUTSOURCE_GOTO_GAME,
#endif
    STATE_INPUTSOURCE_GOTO_OSDPAGE,
} EN_INPUTSOURCE_STATE;

#if (ENABLE_GAME)
typedef enum
{
    STATE_GAME_INIT,
    STATE_GAME_WAIT,
    STATE_GAME_CLEAN_UP,
    STATE_GAME_GOTO_STANDBY,
    STATE_GAME_GOTO_MAIN_MENU,
    STATE_GAME_APP_RUNING
} EN_GAME_STATE;
#endif

INTERFACE EN_RET MApp_InputSource_Main(void);
INTERFACE void MApp_InputSource_SetStateFromUSB(void);

#undef INTERFACE

#endif  // _MAPP_INPUTSOURCE_MAIN_H

