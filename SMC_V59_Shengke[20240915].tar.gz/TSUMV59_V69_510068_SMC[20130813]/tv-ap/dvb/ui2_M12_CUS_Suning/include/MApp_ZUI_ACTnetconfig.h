////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MAPP_ZUI_ACTNETCONFIG_H
#ifdef NETWORK_CONFIG
#define _MAPP_ZUI_ACTNETCONFIG_H

#ifdef __cplusplus
extern "C" {
#endif  /* __cplusplus */

#ifdef MAPP_ZUI_ACTNETCONFIG_C
#define INTERFACE
#else
#define INTERFACE extern
#endif

/////////////////////////////////////////
// Event Handlers....

INTERFACE BOOLEAN MApp_ZUI_ACT_ExecuteNetConfigDialogAction(U16 act);
INTERFACE BOOLEAN MApp_ZUI_ACT_ExecuteNetIPDialogAction(U16 act);
INTERFACE BOOLEAN MApp_ZUI_ACT_ExecuteNetNetmaskDialogAction(U16 act);
INTERFACE BOOLEAN MApp_ZUI_ACT_ExecuteNetGatewayDialogAction(U16 act);
INTERFACE BOOLEAN MApp_ZUI_ACT_ExecuteNetDNSDialogAction(U16 act);


INTERFACE LPTSTR MApp_ZUI_ACT_GetNetConfigDynamicText(HWND hwnd);
INTERFACE LPTSTR MApp_ZUI_ACT_GetNetIPDynamicText(HWND hwnd);
INTERFACE LPTSTR MApp_ZUI_ACT_GetNetNetmaskDynamicText(HWND hwnd);
INTERFACE LPTSTR MApp_ZUI_ACT_GetNetGatewayDynamicText(HWND hwnd);
INTERFACE LPTSTR MApp_ZUI_ACT_GetNetDNSDynamicText(HWND hwnd);



//INTERFACE LPTSTR MApp_ZUI_ACT_GetNetworkItemText(HWND hwnd);


#undef INTERFACE

#ifdef __cplusplus
}
#endif  /* __cplusplus */

#endif
#endif /* _MAPP_ZUI_ACTNETCONFIG_H */

