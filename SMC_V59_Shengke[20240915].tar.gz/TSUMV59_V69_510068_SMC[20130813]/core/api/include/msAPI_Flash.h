////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (MStar Confidential Information!�L) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef MSAPI_FLASH_H
#define    MSAPI_FLASH_H

#include "datatype.h"
#include "msFlash.h"
#include "drvSERFLASH.h"
#include "MApp_SaveData.h"
#include "msAPI_Memory.h"
#include "msAPI_BDMA.h"
#ifdef MSAPI_FLASH_C
#define INTERFACE
#else
#define INTERFACE extern
#endif

typedef enum
{
    E_FLASH_CHIP_SELECT_0 = 0,
    E_FLASH_CHIP_SELECT_1 = 1,
    E_FLASH_CHIP_SELECT_2 = 2,
    E_FLASH_CHIP_SELECT_3 = 3,
}FLASH_CHIP_SELECT;

INTERFACE BOOLEAN g_bGenSettingStoreUseNewMethod;

INTERFACE BOOLEAN msAPI_Flash_ChipSelect(FLASH_CHIP_SELECT eFlashChipSel);
INTERFACE BOOLEAN msAPI_Flash_WriteProtect(BOOL bEnable);
INTERFACE BOOLEAN msAPI_Flash_AddressErase(U32 u32StartAddr,U32 u32EraseSize,BOOL bWait);
INTERFACE BOOLEAN msAPI_Flash_BlockErase(U32 u32StartBlock, U32 u32EndBlock, BOOL bWait);
INTERFACE BOOLEAN msAPI_Flash_Write(U32 u32StartAddr, U32 u32WriteSize, U8 * user_buffer);
INTERFACE BOOLEAN msAPI_Flash_Read(U32 u32StartAddr, U32 u32ReadSize, U8 * user_buffer);
INTERFACE BOOLEAN msAPI_Flash_DetectType(void);
INTERFACE BOOLEAN msAPI_Flash_AddressToBlock(U32 u32FlashAddr, U32 * pu32BlockIndex);
INTERFACE BOOLEAN msAPI_Flash_BlockToAddress(U32 u32BlockIndex, U32 *pu32FlashAddr);
INTERFACE BOOLEAN msAPI_Flash_CheckWriteDone(void);
INTERFACE void msAPI_Flash_WriteProtect_SetBPStatus(void);
INTERFACE BOOLEAN msAPI_Flash_WriteProtect_GetBPStatus(void);
INTERFACE void msAPI_MIU_QuickDataBaseErase(U8 u8Bank);
INTERFACE BOOLEAN msAPI_MIU_QuickDataBaseCheck(void);
INTERFACE void msAPI_MIU_QuickGenSettingLoad(U8 u8Bank);
INTERFACE void msAPI_MIU_QuickGenSettingErase(U8 u8Bank, U8 u8Wait);
INTERFACE void msAPI_MIU_QuickGenSettingWrite(U8 u8Bank, U32 u32srcaddr, S32 s32size);
INTERFACE void msAPI_MIU_XCopy_SetFWStatus(BOOLEAN bFWStatus);
#if (EEPROM_DB_STORAGE==EEPROM_SAVE_NONE)
INTERFACE void MApp_DB_SaveGenSetting(void);
#endif
INTERFACE void MApp_DB_QuickGenSettingMonitor(void);
INTERFACE void msAPI_Flash_EraseGensettingBank(void);
INTERFACE void msAPI_Flash_CheckFlash(void);
INTERFACE void MApp_Printf_Flash_Variable(void);
INTERFACE U16  msAPI_Flash_GetVersion(void);
INTERFACE void MApp_DB_SaveNowGenSetting(void);


#define QUICK_DB_GENST_EMPTY        0xFF
#define QUICK_DB_GENST_WRITING      0x7F
#define QUICK_DB_GENST_GOOD         0x3F
#define QUICK_DB_GENST_OBSOLETE     0x1F
#define QUICK_DB_GENST_SIZE         (4*1024)
#define QUICK_DB_GENST_NUM          (32)
#define QUICK_DB_GENST_INVALID_IDX  0xFF
INTERFACE U8 g_u8QuickDataBase;
INTERFACE U16 g_u16QuickGenSettingIdx;

typedef enum
{
	ERASE_BANK0 = 0,
	ERASE_BANK1 = 1,
	ERASE_NUM   = 2
}ERASE_GENSETTING_BANK;
INTERFACE ERASE_GENSETTING_BANK g_u8EraseGenSettingBank;

/////////////////////////////////////////////////////////////////////////////////
INTERFACE BOOLEAN g_bOpenGenstStoreDBG;
INTERFACE BOOLEAN g_ENABLE_DVBT_1000_LCN;
INTERFACE BOOLEAN g_DB_IN_NAND;
INTERFACE U32 g_SYSTEM_BANK_SIZE;
INTERFACE U32  g_FLASH_SIZE;
INTERFACE U8 g_QUICK_DB_GENSETTING_BANK;
INTERFACE U8 g_u8EEPROM_DB_STORAGE;
INTERFACE U8 g_EEPROM_SAVE_ALL;
INTERFACE U32 g_u32DataBaseAddr;
INTERFACE U32 g_RM_GENSET_START_ADR;
INTERFACE U8 g_QUICK_DB_GENST_NUM;
INTERFACE U32 g_RM_GEN_USAGE;
INTERFACE EN_BUFFER_ID g_BUF_ID_FLASH;
INTERFACE U8 g_QUICK_DB_GENST_INVALID_IDX;
INTERFACE U8 g_QUICK_DB_GENST_GOOD;
INTERFACE U8 g_QUICK_DB_GENST_OBSOLETE;
INTERFACE MEMCOPYTYPE g_MEMCOPYTYPE;
INTERFACE U32 g_RM_SIZE_GENSET;
INTERFACE U16 g_QUICK_DB_GENST_SIZE;
INTERFACE U8 g_QUICK_DB_GENST_MASK;
INTERFACE U8 g_QUICK_DB_GENST_READY;
INTERFACE U8 g_QUICK_DB_GENST_UPDATE;
INTERFACE U8 g_QUICK_DB_GENST_MODIFIED;
INTERFACE U8 g_QUICK_DB_GENST_ERASE_DONE;
INTERFACE U8 g_QUICK_DB_GENST_ERASE_IN_PROGRESS;
/////////////////////////////////////////////////////////////////////////////////

#undef INTERFACE

#endif

