////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef MAPP_IR_H
#define MAPP_IR_H

#ifdef  MAPP_IR_C
#define INTERFACE
#else
#define INTERFACE extern
#endif

typedef struct
{
    BOOLEAN empty;
    U16     keydata;
    U8      repeat;
    U8      flag;

} ST_MBIR;

INTERFACE void MApp_ProcessUserInput(void);
INTERFACE void MApp_Key_Initial_Status(void);
INTERFACE BOOLEAN MApp_GetCurrentKeyType(void);
INTERFACE BOOLEAN MApp_KeyIsReapeatStatus(void);

INTERFACE void MApp_FillMBIR(U8 keycode, U8 repeat);
INTERFACE void MApp_ClearMBIR(void);
INTERFACE void MApp_SetMBIRFlag(U8 val);
INTERFACE U8 MApp_GetMBIRFlag(void);
INTERFACE void MApp_GetMBIR(ST_MBIR* pMBIR);

#define KEY_TYPE_KEYPAD         0
#define KEY_TYPE_IR             1

typedef struct
{
    U8 keydown:1;
    U8 keyrepeat:1;
    U8 RepeatEnable:1;
    U8 keytype:1;               //0:  Key Pad  1: IR Key
    U8 KeyFilterPower:1;
    U8 Reserved:3;
    U8 keydata  ;
#if CUS_SMC_ENABLE_HOTEL_MODE
	U8 prekeydata;
#endif	
#if CUS_SK_ENABLE_MODE
    U8 KeydataCnt;
#endif
} KEYSTAT;

#undef INTERFACE

#endif

