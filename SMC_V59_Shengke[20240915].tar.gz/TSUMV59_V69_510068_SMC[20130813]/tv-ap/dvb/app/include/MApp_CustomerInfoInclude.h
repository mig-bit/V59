////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#define CUSTOMER_INFO_START_TAG                     0
#define CUSTOMER_INFO_START_CLASS                   4
#define CUSTOMER_INFO_START_CID                     6
#define CUSTOMER_INFO_START_MID                     8
#define CUSTOMER_INFO_START_CHIP                    10
#define CUSTOMER_INFO_START_SW_PROJECT              12
#define CUSTOMER_INFO_START_SW_PROJECT_GENERATION   13
#define CUSTOMER_INFO_START_PRODUCT                 14
#define CUSTOMER_INFO_START_TV_SYSTEM               15
#define CUSTOMER_INFO_START_LABEL                   16
#define CUSTOMER_INFO_START_CL                      19
#define CUSTOMER_INFO_START_RELEASE_PURPOSE         22
#define CUSTOMER_INFO_START_CPU_TYPE                23


#define CUSTOMER_INFO_BUF_START_CID                 0
#define CUSTOMER_INFO_BUF_START_MID                 4
#define CUSTOMER_INFO_BUF_START_CHIP                8
#define CUSTOMER_INFO_BUF_START_RESERVED            12
#define CUSTOMER_INFO_BUF_START_IP_MAPPING_0        16
#define CUSTOMER_INFO_BUF_START_IP_MAPPING_1        24
#define CUSTOMER_INFO_BUF_START_IP_MAPPING_2        32
#define CUSTOMER_INFO_BUF_START_IP_MAPPING_3        40



extern unsigned char code CID_Buf[];
extern unsigned char Customer_info[];




