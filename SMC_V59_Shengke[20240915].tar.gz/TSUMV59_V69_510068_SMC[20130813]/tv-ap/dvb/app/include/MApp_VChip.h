////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef MAPP_VCHIP_H
#define MAPP_VCHIP_H

#include "datatype.h"

#include "msAPI_vbi.h"
#include "MApp_GlobalSettingSt.h"


#ifdef MAPP_VCHIP_C
#define INTERFACE
#else
#define INTERFACE extern
#endif

//==============================================================================
/*                    Enum                                                      */
//==============================================================================
typedef enum
{
    //TV-Y: 1
    VCHIP_TV_Y_ALL,
    //TV-Y7 : 2
    VCHIP_TV_Y7_ALL,
    VCHIP_TV_Y7_FV,
    //TV-G: 1
    VCHIP_TV_G_ALL,
    //TV-PG: 5
    VCHIP_TV_PG_ALL,
    VCHIP_TV_PG_V,
    VCHIP_TV_PG_S,
    VCHIP_TV_PG_L,
    VCHIP_TV_PG_D,
    //TV-14: 5
    VCHIP_TV_14_ALL,
    VCHIP_TV_14_V,
    VCHIP_TV_14_S,
    VCHIP_TV_14_L,
    VCHIP_TV_14_D,
    //TV-MA: 4
    VCHIP_TV_MA_ALL,
    VCHIP_TV_MA_V,
    VCHIP_TV_MA_S,
    VCHIP_TV_MA_L,
    VCHIP_TV_NUM,
    VCHIP_TV_FVSLD_MIN_LEVEL = VCHIP_TV_Y_ALL,
    VCHIP_TV_FVSLD_MAX_LEVEL = VCHIP_TV_MA_L
} EN_VCHIP_TV_FVSLD_ITEM;

typedef enum
{
    VCHIP_RATING_REGION_NONE,
    VCHIP_RATING_REGION_US,
    VCHIP_RATING_REGION_CANADA,
    VCHIP_RATING_REGION_REG5,
    VCHIP_RATING_REGION_NUM
} EN_VCHIP_RATING_REGION;

typedef enum
{
    VCHIP_RATING_TYPE_NONE,
    VCHIP_RATING_TYPE_TV,
    VCHIP_RATING_TYPE_MPAA,
    VCHIP_RATING_TYPE_CANADA_ENG,
    VCHIP_RATING_TYPE_CANADA_FRE,
    VCHIP_RATING_TYPE_REG5,
    VCHIP_RATING_TYPE_NUM
} EN_VCHIP_RATING_TYPE;

typedef enum
{
    VCHIP_TVRATING_NONE,
    VCHIP_TVRATING_TV_Y,
    VCHIP_TVRATING_TV_Y7,
    VCHIP_TVRATING_TV_G,
    VCHIP_TVRATING_TV_PG,
    VCHIP_TVRATING_TV_14,
    VCHIP_TVRATING_TV_MA,
    VCHIP_TVRATING_NUM,
    VCHIP_TVRATING_MAX_LEVEL = VCHIP_TVRATING_TV_MA
} EnuVChipTVRating;

typedef enum
{
    VCHIP_MPAARATING_NA, //not applicable
    VCHIP_MPAARATING_G,
    VCHIP_MPAARATING_PG,
    VCHIP_MPAARATING_PG_13,
    VCHIP_MPAARATING_R,
    VCHIP_MPAARATING_NC_17,
    VCHIP_MPAARATING_X,

    VCHIP_MPAARATING_NOT_RATED, // EIA-608B: indicates a motion picture that did not receive a rating for a variety of possible reasons.

    VCHIP_MPAARATING_NUM,
    VCHIP_MPAARATING_MAX_LEVEL = VCHIP_MPAARATING_X
} EnuVChipMPAARating;

typedef enum
{
    VCHIP_ENGRATING_EXEMPT,
    VCHIP_ENGRATING_C,
    VCHIP_ENGRATING_C8Plus,
    VCHIP_ENGRATING_G,
    VCHIP_ENGRATING_PG,
    VCHIP_ENGRATING_14Plus,
    VCHIP_ENGRATING_18Plus,
    VCHIP_ENGRATING_NUM,
    VCHIP_ENGRATING_MAX_LEVEL = VCHIP_ENGRATING_18Plus
} EnuENGLISHRating;

typedef enum
{
    VCHIP_FRERATING_EXEMPT,
    VCHIP_FRERATING_G,
    VCHIP_FRERATING_8ansPlus,
    VCHIP_FRERATING_13ansPlus,
    VCHIP_FRERATING_16ansPlus,
    VCHIP_FRERATING_18ansPlus,
    VCHIP_FRERATING_NUM,
    VCHIP_FRERATING_MAX_LEVEL = VCHIP_FRERATING_18ansPlus
} EnuFRENCHRating;

#if ( ENABLE_ATV_VCHIP)
//==============================================================================
/*                    Global                                                    */
//==============================================================================
INTERFACE MS_U8 fVChipPassWordEntered;
INTERFACE MS_VCHIP_RATING_INFO g_stVChipRatingInfo;


//==============================================================================
/*                    Function Prototype                                        */
//==============================================================================
INTERFACE void MApp_VChip_Init(void);
INTERFACE void MApp_VChip_SetBlockStatus(BOOLEAN bVChipBlockStatus);
INTERFACE void MApp_VChip_MonitorVChip(void);
INTERFACE BOOLEAN MApp_VChip_GetCurVChipBlockStatus(void);
INTERFACE BOOLEAN MApp_VChip_GetRatingUpdateStatus(void);
//INTERFACE void MApp_VChip_EPGRating2RatingInfo(MS_EPG_RATING *pstCurEvn, MS_VCHIP_RATING_INFO *pstVChipRatingInfo);
INTERFACE BOOLEAN MApp_VChip_CompareRating(MS_VCHIP_RATING_INFO *pstVChipRatingInfo, MS_VCHIP_SETTING *pstVChipSetting);
#ifdef LOCK_USE_BLACK_VIDEO
INTERFACE void MApp_MuteAvByLock(U8 u8ScreenMute, BOOLEAN bMuteEnable);
#else
INTERFACE void MApp_MuteAvByLock(BOOLEAN bEnableMute);
#endif
#endif//ENABLE_ATV_VCHIP



#undef INTERFACE
#endif
