////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#define MAPP_PVR_MAIN_C

/******************************************************************************/
/*                 Header Files                                               */
/* ****************************************************************************/
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "Board.h"
#include "datatype.h"
#include "MsCommon.h"
#include "apiXC.h"
#include "apiXC_Adc.h"
#include "MApp_GlobalSettingSt.h"

#include "debug.h"

#include "MApp_Exit.h"
#include "MApp_Key.h"
#include "MApp_UiMenuDef.h"
#include "MApp_ZUI_Main.h"
#include "ZUI_tables_h.inl"
#include "MApp_PVR_Main.h"
//////////////////////////////////////////////////////////

EN_RET MApp_PVR_Main(void)
{
    EN_RET enRetVal =EXIT_NULL;

    switch(enPvrState)
    {
        case STATE_PVR_CHECK_FS_INIT:
            MApp_ZUI_ACT_StartupOSD(E_OSD_PVR);
            enPvrState = STATE_PVR_CHECK_FS_WAIT;
            break;

        case STATE_PVR_CHECK_FS_WAIT:
            MApp_ZUI_ProcessKey(u8KeyCode);
            u8KeyCode = KEY_NULL;
            break;

       case STATE_PVR_MENU_CLEAN_UP:
            enPvrState = STATE_PVR_NULL;
            enRetVal = EXIT_CLOSE;
            break;

       case STATE_PVR_MENU_GOTO_MAIN_MENU:
            enPvrState = STATE_PVR_NULL;
            enRetVal = EXIT_GOTO_MENU;
            break;

       case STATE_PVR_MENU_GOTO_STANDBY:
            enPvrState = STATE_PVR_NULL;
            enRetVal = EXIT_GOTO_STANDBY;
            break;
       default:
            MS_DEBUG_MSG(printf("[PVR]STATE_ERR\n"));
            break;
    }
    return enRetVal;
}

#undef MAPP_PVR_MAIN_C

