////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
/// @file  MApp_XC_SYS.h
/// @brief MIU header file
/// @author MStar Semiconductor Inc.
///
////////////////////////////////////////////////////////////////////////////////
#ifndef _APP_XC_SYS_H_
#define _APP_XC_SYS_H_

#ifdef _APP_XC_SYS_C_
#define INTERFACE
#else
#define INTERFACE extern
#endif

//-------------------------------------------------------------------------------------------------
//  Include Files
//-------------------------------------------------------------------------------------------------

//-------------------------------------------------------------------------------------------------
//  Macro and Define
//-------------------------------------------------------------------------------------------------

//-------------------------------------------------------------------------------------------------
//  Type and Structure
//-------------------------------------------------------------------------------------------------

//-------------------------------------------------------------------------------------------------
//  Function and Variable
//-------------------------------------------------------------------------------------------------

INTERFACE BOOLEAN msAPI_Picture_isCurrentAFDVaild(U8 tmpAFD);
INTERFACE BOOLEAN msAPI_Picture_isAFDEnable(EN_ASPECT_RATIO_TYPE enVideoScreen);

void msAPI_Picture_CalculateAFDWindow(XC_SETWIN_INFO *pstXC_SetWin_Info,
                                                EN_ASPECT_RATIO_TYPE enVideoScreen,
                                              MS_WINDOW_TYPE *pstCropWin,
                                              MS_WINDOW_TYPE *pstDstWin,
                                              SRC_RATIO_INFO *pstSrcRatioInfo);

INTERFACE void MApp_Picture_AFDMonitor(void);

#undef INTERFACE
#endif /* _APP_XC_SYS_H_ */
