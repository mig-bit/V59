////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#define MAPP_RESTORETODEFAULT_C

//*************************************************************************
//              Include files
//*************************************************************************
#include <string.h>

#include "Board.h"
#include "MsTypes.h"
#include "Panel.h"
#include "datatype.h"
#include "apiXC.h"

#include "DemoFineTune.h"
#include "QualityEx_Default.h"

#include "drvPQ.h"
#include "drvpower_if.h"
#include "apiGOP.h"
#include "apiXC.h"
#include "apiXC_Adc.h"
#include "apiXC_Ace.h"
#if ENABLE_DBC
#include "apiXC_Sys.h"
#endif

#include "msAPI_Memory.h"
#include "msAPI_MIU.h"
#include "msAPI_Flash.h"
#include "msAPI_Mode.h"
#include "msAPI_DTVSystem.h"
#include "msAPI_audio.h"

#include "MApp_GlobalSettingSt.h"
#include "MApp_GlobalVar.h"
#include "MApp_GlobalFunction.h"
#include "MApp_RestoreToDefault.h"
#include "MApp_Scaler.h"
#include "MApp_DataBase.h"
#include "MApp_Scan.h"

#if (ENABLE_DTV)
#include "mapp_demux.h"
#endif

#include "MApp_ATVProc.h"
#include "MApp_UiMenuDef.h"
#include "MApp_SaveData.h"
#include "MApp_Audio.h"

#if ENABLE_PVR
#include "MApp_UiPvr.h"
#endif

#if (OBA2)
#include "MApp_ZUI_APIcommon.h"
#include "ZUI_tables_h.inl"
#include "MApp_ZUI_ACTmenufunc.h"
#endif
#include "drvUART.h"

#if ENABLE_CI
#include "msAPI_CI.h"
#endif
#if ENABLE_VD_PACH_IN_CHINA
#include "drvVIFInitial_MST.h"
#include "msAPI_VD.h"
#endif
#include "msAPI_FreqTableDTV.h"

#include "msAPI_Timer.h"
#include"msAPI_DrvInit.h"

//*************************************************************************
//              Local variables
//*************************************************************************
#ifdef ENABLE_CUS_COLOR_DEPEND_ON_PANEL
#define USE_CUS_DEFAULT_ADC 1
#else
#define USE_CUS_DEFAULT_ADC 0
#endif

#if USE_CUS_DEFAULT_ADC
#ifdef ENABLE_CUS_COLOR_DEPEND_ON_PANEL
static code APIXC_AdcGainOffsetSetting tADCSetting[ADC_SET_NUMS] =
tDefaultADCSettingTable;

#else
static code APIXC_AdcGainOffsetSetting tADCSetting[ADC_SET_NUMS] =
{
    {
         INIT_ADC_RGB_RED_GAIN,
         INIT_ADC_RGB_GREEN_GAIN,
         INIT_ADC_RGB_BLUE_GAIN,

         INIT_ADC_RGB_RED_OFFSET,
         INIT_ADC_RGB_GREEN_OFFSET,
         INIT_ADC_RGB_BLUE_OFFSET,
    }, // VGA

    {
        INIT_ADC_YPBPR_RED_GAIN_SD,
        INIT_ADC_YPBPR_GREEN_GAIN_SD,
        INIT_ADC_YPBPR_BLUE_GAIN_SD,

        INIT_ADC_YPBPR_RED_OFFSET,
        INIT_ADC_YPBPR_GREEN_OFFSET,
        INIT_ADC_YPBPR_BLUE_OFFSET,

    }, // YPBPR_SD

    {
        INIT_ADC_YPBPR_RED_GAIN_HD,
        INIT_ADC_YPBPR_GREEN_GAIN_HD,
        INIT_ADC_YPBPR_BLUE_GAIN_HD,

        INIT_ADC_YPBPR_RED_OFFSET,
        INIT_ADC_YPBPR_GREEN_OFFSET,
        INIT_ADC_YPBPR_BLUE_OFFSET,

    }, // YPBPR_HD

    {
         INIT_ADC_RGB_RED_GAIN,
         INIT_ADC_RGB_GREEN_GAIN,
         INIT_ADC_RGB_BLUE_GAIN,

         INIT_ADC_RGB_RED_OFFSET,
         INIT_ADC_RGB_GREEN_OFFSET,
         INIT_ADC_RGB_BLUE_OFFSET,
    }, // Scart_RGB
};
#endif
#endif

//////////////////////////////////////////////////////////////////////////////////////////
// Default Sound Mode Setting
///////////////////////////////////////////////////////////////////////////////////////////
#if ENABLE_CUS_UI_SPEC


static code stSoundModeSeting astDefaultSoundModeSeting[EN_SoundMode_Num] =
{
    /*
         To use simple sound mode setting, let SIMPLE_EQ_SETTING = 1.
         Simple sound mode setting can only set bass & treble.
    */
    //bass,treble,u8120HZ,u8500HZ,u8_1_dot_5_KHZ,u8_5KHZ,u810KHZ,Usermode

    //Standard,
    {50,
      50,
      SOUND_MODE_STANDARD_BAND1,
      SOUND_MODE_STANDARD_BAND2,
      SOUND_MODE_STANDARD_BAND3,
      SOUND_MODE_STANDARD_BAND4,
      SOUND_MODE_STANDARD_BAND5,
     // SOUND_MODE_STANDARD_BAND6,
    //  SOUND_MODE_STANDARD_BAND7,
      FALSE, 0, AUD_MODE_LR
#if (ENABLE_CUS_SURROUND_FOLLOW_SNDMODE)
      ,
      SURROUND_SYSTEM_OFF
#endif
    },
    //Music
    {80,
      80,
      SOUND_MODE_MUSIC_BAND1,
      SOUND_MODE_MUSIC_BAND2,
      SOUND_MODE_MUSIC_BAND3,
      SOUND_MODE_MUSIC_BAND4,
      SOUND_MODE_MUSIC_BAND5,
      //SOUND_MODE_MUSIC_BAND6,
     // SOUND_MODE_MUSIC_BAND7,
      FALSE, 0, AUD_MODE_LR
#if (ENABLE_CUS_SURROUND_FOLLOW_SNDMODE)
      ,
      SURROUND_SYSTEM_OFF
#endif
     },
    //Sports
    {20,
      20,
      SOUND_MODE_SPORTS_BAND1,
      SOUND_MODE_SPORTS_BAND2,
      SOUND_MODE_SPORTS_BAND3,
      SOUND_MODE_SPORTS_BAND4,
      SOUND_MODE_SPORTS_BAND5,
     // SOUND_MODE_SPORTS_BAND6,
    //  SOUND_MODE_SPORTS_BAND7,
      FALSE, 0, AUD_MODE_LR
#if (ENABLE_CUS_SURROUND_FOLLOW_SNDMODE)
      ,
      SURROUND_SYSTEM_OFF
#endif
      },
      //User
      {50,
      50,
      SOUND_MODE_STANDARD_BAND1,
      SOUND_MODE_STANDARD_BAND2,
      SOUND_MODE_STANDARD_BAND3,
      SOUND_MODE_STANDARD_BAND4,
      SOUND_MODE_STANDARD_BAND5,
     // SOUND_MODE_STANDARD_BAND6,
     // SOUND_MODE_STANDARD_BAND7,
      FALSE, 0, AUD_MODE_LR
#if (ENABLE_CUS_SURROUND_FOLLOW_SNDMODE)
      ,
      SURROUND_SYSTEM_OFF
#endif
      },

};
#else
static code stSoundModeSeting astDefaultSoundModeSeting[EN_SoundMode_Num] =
{
    /*
         To use simple sound mode setting, let SIMPLE_EQ_SETTING = 1.
         Simple sound mode setting can only set bass & treble.
    */
    #define SIMPLE_EQ_SETTING 1
    //bass,treble,u8120HZ,u8500HZ,u8_1_dot_5_KHZ,u8_5KHZ,u810KHZ,Usermode

    //Standard,
    {50,
      50,
      SOUND_MODE_STANDARD_BAND1,
      SOUND_MODE_STANDARD_BAND2,
      SOUND_MODE_STANDARD_BAND3,
      SOUND_MODE_STANDARD_BAND4,
      SOUND_MODE_STANDARD_BAND5,
     // SOUND_MODE_STANDARD_BAND6,
    //  SOUND_MODE_STANDARD_BAND7,
      FALSE, 0, AUD_MODE_LR
#if (ENABLE_CUS_SURROUND_FOLLOW_SNDMODE)
      ,
      SURROUND_SYSTEM_OFF
#endif
    },
    //Music
    {75,
      75,
      #if (SIMPLE_EQ_SETTING == 0)
      SOUND_MODE_MUSIC_BAND1,
      SOUND_MODE_MUSIC_BAND2,
      SOUND_MODE_MUSIC_BAND3,
      SOUND_MODE_MUSIC_BAND4,
      SOUND_MODE_MUSIC_BAND5,
      //SOUND_MODE_MUSIC_BAND6,
     // SOUND_MODE_MUSIC_BAND7,
      FALSE, 0, AUD_MODE_LR
#if (ENABLE_CUS_SURROUND_FOLLOW_SNDMODE)
      ,
      SURROUND_SYSTEM_OFF
#endif
      #else
      SOUND_MODE_STANDARD_BAND1,
      SOUND_MODE_STANDARD_BAND2,
      SOUND_MODE_STANDARD_BAND3,
      SOUND_MODE_STANDARD_BAND4,
      SOUND_MODE_STANDARD_BAND5,
      //SOUND_MODE_STANDARD_BAND6,
     // SOUND_MODE_STANDARD_BAND7,
      FALSE, 0, AUD_MODE_LR
#if (ENABLE_CUS_SURROUND_FOLLOW_SNDMODE)
      ,
      SURROUND_SYSTEM_OFF
#endif
      #endif
     },
     //Move
    {90,
      75,
      #if SIMPLE_EQ_SETTING == 0
      SOUND_MODE_MOVIE_BAND1,
      SOUND_MODE_MOVIE_BAND2,
      SOUND_MODE_MOVIE_BAND3,
      SOUND_MODE_MOVIE_BAND4,
      SOUND_MODE_MOVIE_BAND5,
     // SOUND_MODE_MOVIE_BAND6,
     // SOUND_MODE_MOVIE_BAND7,
      FALSE, 0, AUD_MODE_LR
#if (ENABLE_CUS_SURROUND_FOLLOW_SNDMODE)
      ,
      SURROUND_SYSTEM_OFF
#endif
      #else
      SOUND_MODE_STANDARD_BAND1,
      SOUND_MODE_STANDARD_BAND2,
      SOUND_MODE_STANDARD_BAND3,
      SOUND_MODE_STANDARD_BAND4,
      SOUND_MODE_STANDARD_BAND5,
     // SOUND_MODE_STANDARD_BAND6,
     // SOUND_MODE_STANDARD_BAND7,
      FALSE, 0, AUD_MODE_LR
#if (ENABLE_CUS_SURROUND_FOLLOW_SNDMODE)
      ,
      SURROUND_SYSTEM_OFF
#endif
      #endif

    },
    //Sports
    {35,
      35,
      #if SIMPLE_EQ_SETTING == 0
      SOUND_MODE_SPORTS_BAND1,
      SOUND_MODE_SPORTS_BAND2,
      SOUND_MODE_SPORTS_BAND3,
      SOUND_MODE_SPORTS_BAND4,
      SOUND_MODE_SPORTS_BAND5,
     // SOUND_MODE_SPORTS_BAND6,
    //  SOUND_MODE_SPORTS_BAND7,
      FALSE, 0, AUD_MODE_LR
#if (ENABLE_CUS_SURROUND_FOLLOW_SNDMODE)
      ,
      SURROUND_SYSTEM_OFF
#endif
      #else
      SOUND_MODE_STANDARD_BAND1,
      SOUND_MODE_STANDARD_BAND2,
      SOUND_MODE_STANDARD_BAND3,
      SOUND_MODE_STANDARD_BAND4,
      SOUND_MODE_STANDARD_BAND5,
     // SOUND_MODE_STANDARD_BAND6,
     // SOUND_MODE_STANDARD_BAND7,
      FALSE, 0, AUD_MODE_LR
#if (ENABLE_CUS_SURROUND_FOLLOW_SNDMODE)
      ,
      SURROUND_SYSTEM_OFF
#endif
      #endif
      },
      //User
      {50,
      50,
      SOUND_MODE_STANDARD_BAND1,
      SOUND_MODE_STANDARD_BAND2,
      SOUND_MODE_STANDARD_BAND3,
      SOUND_MODE_STANDARD_BAND4,
      SOUND_MODE_STANDARD_BAND5,
     // SOUND_MODE_STANDARD_BAND6,
     // SOUND_MODE_STANDARD_BAND7,
      FALSE, 0, AUD_MODE_LR
#if (ENABLE_CUS_SURROUND_FOLLOW_SNDMODE)
      ,
      SURROUND_SYSTEM_OFF
#endif
      },
};
#endif

//////////////////////////////////////////////////////////////////////////////////////////
// Default Time Data
///////////////////////////////////////////////////////////////////////////////////////////
static code MS_TIME stDefaultTimeData =
{
    0, //wTimeDataCS;

    DEFAULT_D_ONTIME_CH,//cOnTimerChannel;
    0,//u16OffTimer_Info_Hour;
    0,//u16OffTimer_Info_Min;
    0,//u16OffTimer_Info_Sec;
    0,//u16OnTimer_Info_Hour;
    0, //u16OnTimer_Info_Min;
    0,//u16OnTimer_Info_Sec;
    0,//u32ElapsedTimeCnt++;
    0, // s32Offset_Time
#if ENABLE_SBTVD_BRAZIL_APP
    TIMEZONE_BRASILIA,
    EN_Clock_TimeZone_18,
#else
    TIMEZONE_CANARY,
    EN_Clock_TimeZone_24,
#endif
    EN_ClockMode_Auto,
    EN_Time_OffTimer_Off,
    EN_Time_OnTimer_Off,
    #if(ENABLE_DTV)
    EN_Time_OnTimer_Source_DTV,
    #else
    EN_Time_OnTimer_Source_MEMORY,
    #endif
    EN_Time_AutoOff_Off,
    30,//cOnTimerVolume;
    0, //NVRAM_g_u8TimeInfo_Flag
};

#ifdef ENABLE_CUS_COLOR_DEPEND_ON_PANEL
static T_MS_VIDEO code astDefaultVideoDataTbl[DATA_INPUT_SOURCE_NUM] ={
    #if ENABLE_DTV
        astDefaultVideoDataTbl_DTV,                      /*DTV*/
    #endif
        astDefaultVideoDataTbl_ATV,                      /*ATV*/
    #if (INPUT_AV_VIDEO_COUNT >= 1)
        astDefaultVideoDataTbl_AV,                       /*AV*/
    #endif
    #if (INPUT_AV_VIDEO_COUNT >= 2)
        astDefaultVideoDataTbl_AV,                       /*AV2*/
    #endif
    #if (INPUT_AV_VIDEO_COUNT >= 3)
        astDefaultVideoDataTbl_AV,                       /*AV3*/
    #endif
    #if (INPUT_YPBPR_VIDEO_COUNT >= 1)
        astDefaultVideoDataTbl_YPBPR,                    /*YPBPR*/
    #endif
    #if (INPUT_YPBPR_VIDEO_COUNT >= 2)
        astDefaultVideoDataTbl_YPBPR,                    /*YPBPR2*/
    #endif
        astDefaultVideoDataTbl_VGA,                      /*VGA*/
    #if (INPUT_HDMI_VIDEO_COUNT > 0)
        astDefaultVideoDataTbl_HDMI,                     /*HDMI1*/
    #endif
    #if (INPUT_HDMI_VIDEO_COUNT >= 2)
        astDefaultVideoDataTbl_HDMI,                     /*HDMI2*/
    #endif
    #if (INPUT_HDMI_VIDEO_COUNT >= 3)
        astDefaultVideoDataTbl_HDMI,                     /*HDMI3*/
    #endif
    #if (INPUT_HDMI_VIDEO_COUNT >= 4)
        astDefaultVideoDataTbl_HDMI,                     /*HDMI4*/
    #endif
    #if (INPUT_SCART_VIDEO_COUNT >= 1)
        astDefaultVideoDataTbl_AV,                       /*SCART*/
    #endif
    #if (INPUT_SCART_VIDEO_COUNT >= 2)
        astDefaultVideoDataTbl_AV,                       /*SCART2*/
    #endif
    #if (INPUT_SV_VIDEO_COUNT >= 1)
        astDefaultVideoDataTbl_YPBPR,                    /*SVIDEO*/
    #endif
    #if (INPUT_SV_VIDEO_COUNT >= 2)
        astDefaultVideoDataTbl_YPBPR,                   /*SVIDEO*/
    #endif
    #if ENABLE_DMP
        astDefaultVideoDataTbl_USB,                      /*USB*/
    #endif
};
static T_MS_WHITEBALANCE code astDefaultWhiteBalanceDataTbl[DATA_INPUT_SOURCE_NUM] =
{
#if ENABLE_DTV
    astDefaultWhiteBalanceDataTbl_DTV,
#endif
    astDefaultWhiteBalanceDataTbl_ATV,
#if (INPUT_AV_VIDEO_COUNT >= 1)
    astDefaultWhiteBalanceDataTbl_AV,
#endif
#if (INPUT_AV_VIDEO_COUNT >= 2)
    astDefaultWhiteBalanceDataTbl_AV,
#endif
#if (INPUT_AV_VIDEO_COUNT >= 3)
    astDefaultWhiteBalanceDataTbl_AV,
#endif
#if (INPUT_YPBPR_VIDEO_COUNT >= 1)
    astDefaultWhiteBalanceDataTbl_YPBPR,
#endif
#if (INPUT_YPBPR_VIDEO_COUNT >= 2)
    astDefaultWhiteBalanceDataTbl_YPBPR,
#endif

    astDefaultWhiteBalanceDataTbl_VGA,

#if (INPUT_HDMI_VIDEO_COUNT > 0)
    astDefaultWhiteBalanceDataTbl_HDMI,
#endif
#if (INPUT_HDMI_VIDEO_COUNT >= 2)
    astDefaultWhiteBalanceDataTbl_HDMI,
#endif
#if (INPUT_HDMI_VIDEO_COUNT >= 3)
    astDefaultWhiteBalanceDataTbl_HDMI,
#endif
#if (INPUT_HDMI_VIDEO_COUNT >= 4)
    astDefaultWhiteBalanceDataTbl_HDMI,
#endif
#if (INPUT_SCART_VIDEO_COUNT >= 1)
    astDefaultWhiteBalanceDataTbl_AV,
#endif
#if (INPUT_SCART_VIDEO_COUNT >= 2)
    astDefaultWhiteBalanceDataTbl_AV,
#endif
#if (INPUT_SV_VIDEO_COUNT >= 1)
    astDefaultWhiteBalanceDataTbl_YPBPR,
#endif
#if (INPUT_SV_VIDEO_COUNT >= 2)
    astDefaultWhiteBalanceDataTbl_YPBPR,
#endif
#if ENABLE_DMP
    astDefaultWhiteBalanceDataTbl_USB,
#endif
};

#if (ENABLE_NONLINEAR_CURVE)
#if (BOE_VOLUME_CURVE)
#define DEFAULT_NONLINEAR_CURVE_VOLUME_0          0
#define DEFAULT_NONLINEAR_CURVE_VOLUME_1          1
#define DEFAULT_NONLINEAR_CURVE_VOLUME_10        10
#define DEFAULT_NONLINEAR_CURVE_VOLUME_20        20
#define DEFAULT_NONLINEAR_CURVE_VOLUME_30        30
#define DEFAULT_NONLINEAR_CURVE_VOLUME_40        40
#define DEFAULT_NONLINEAR_CURVE_VOLUME_50        50
#define DEFAULT_NONLINEAR_CURVE_VOLUME_60        60
#define DEFAULT_NONLINEAR_CURVE_VOLUME_70        70
#define DEFAULT_NONLINEAR_CURVE_VOLUME_80        80
#define DEFAULT_NONLINEAR_CURVE_VOLUME_90        90
#define DEFAULT_NONLINEAR_CURVE_VOLUME_100      100
#endif

#if ENABLE_SOUND_NONLINEAR_CURVE_TEN
#if 0// SMC test
#define DEFAULT_NONLINEAR_CURVE_VOLUME_ATV_0               284

#define DEFAULT_NONLINEAR_CURVE_VOLUME_ATV_10          354

#define DEFAULT_NONLINEAR_CURVE_VOLUME_ATV_20            402

#define DEFAULT_NONLINEAR_CURVE_VOLUME_ATV_30           450

#define DEFAULT_NONLINEAR_CURVE_VOLUME_ATV_40            478

#define DEFAULT_NONLINEAR_CURVE_VOLUME_ATV_50           498

#define DEFAULT_NONLINEAR_CURVE_VOLUME_ATV_60             521

#define DEFAULT_NONLINEAR_CURVE_VOLUME_ATV_70             537

#define DEFAULT_NONLINEAR_CURVE_VOLUME_ATV_85            561

#define DEFAULT_NONLINEAR_CURVE_VOLUME_ATV_100         589

#define DEFAULT_NONLINEAR_CURVE_VOLUME_ATV_PRESCALE   124//  66 //minglin0130

#define DEFAULT_NONLINEAR_CURVE_VOLUME_ATV_AVC         47

 

#define DEFAULT_NONLINEAR_CURVE_VOLUME_AV_0                245

#define DEFAULT_NONLINEAR_CURVE_VOLUME_AV_10            314

#define DEFAULT_NONLINEAR_CURVE_VOLUME_AV_20           382

#define DEFAULT_NONLINEAR_CURVE_VOLUME_AV_30          410

#define DEFAULT_NONLINEAR_CURVE_VOLUME_AV_40            438

#define DEFAULT_NONLINEAR_CURVE_VOLUME_AV_50            458

#define DEFAULT_NONLINEAR_CURVE_VOLUME_AV_60             481

#define DEFAULT_NONLINEAR_CURVE_VOLUME_AV_70             497

#define DEFAULT_NONLINEAR_CURVE_VOLUME_AV_85           522

#define DEFAULT_NONLINEAR_CURVE_VOLUME_AV_100         549

#define DEFAULT_NONLINEAR_CURVE_VOLUME_AV_PRESCALE     124

#define DEFAULT_NONLINEAR_CURVE_VOLUME_AV_AVC         47

 

#define DEFAULT_NONLINEAR_CURVE_VOLUME_SV_0                245

#define DEFAULT_NONLINEAR_CURVE_VOLUME_SV_10            314

#define DEFAULT_NONLINEAR_CURVE_VOLUME_SV_20           382

#define DEFAULT_NONLINEAR_CURVE_VOLUME_SV_30          410

#define DEFAULT_NONLINEAR_CURVE_VOLUME_SV_40            438

#define DEFAULT_NONLINEAR_CURVE_VOLUME_SV_50            458

#define DEFAULT_NONLINEAR_CURVE_VOLUME_SV_60             481

#define DEFAULT_NONLINEAR_CURVE_VOLUME_SV_70             497

#define DEFAULT_NONLINEAR_CURVE_VOLUME_SV_85           522

#define DEFAULT_NONLINEAR_CURVE_VOLUME_SV_100         549

#define DEFAULT_NONLINEAR_CURVE_VOLUME_SV_PRESCALE            124 // 24

#define DEFAULT_NONLINEAR_CURVE_VOLUME_SV_AVC         47

 

#define DEFAULT_NONLINEAR_CURVE_VOLUME_YPBPR_0                245

#define DEFAULT_NONLINEAR_CURVE_VOLUME_YPBPR_10            314

#define DEFAULT_NONLINEAR_CURVE_VOLUME_YPBPR_20           382

#define DEFAULT_NONLINEAR_CURVE_VOLUME_YPBPR_30          410

#define DEFAULT_NONLINEAR_CURVE_VOLUME_YPBPR_40            438

#define DEFAULT_NONLINEAR_CURVE_VOLUME_YPBPR_50            458

#define DEFAULT_NONLINEAR_CURVE_VOLUME_YPBPR_60             481

#define DEFAULT_NONLINEAR_CURVE_VOLUME_YPBPR_70             497

#define DEFAULT_NONLINEAR_CURVE_VOLUME_YPBPR_85           522

#define DEFAULT_NONLINEAR_CURVE_VOLUME_YPBPR_100         549

#define DEFAULT_NONLINEAR_CURVE_VOLUME_YPBPR_PRESCALE            124 // 24

#define DEFAULT_NONLINEAR_CURVE_VOLUME_YPBPR_AVC         47

 

#define DEFAULT_NONLINEAR_CURVE_VOLUME_HDMI_0                 203

#define DEFAULT_NONLINEAR_CURVE_VOLUME_HDMI_10              273

#define DEFAULT_NONLINEAR_CURVE_VOLUME_HDMI_20              321

#define DEFAULT_NONLINEAR_CURVE_VOLUME_HDMI_30             369

#define DEFAULT_NONLINEAR_CURVE_VOLUME_HDMI_40            397

#define DEFAULT_NONLINEAR_CURVE_VOLUME_HDMI_50            417

#define DEFAULT_NONLINEAR_CURVE_VOLUME_HDMI_60               440

#define DEFAULT_NONLINEAR_CURVE_VOLUME_HDMI_70               456

#define DEFAULT_NONLINEAR_CURVE_VOLUME_HDMI_85             480

#define DEFAULT_NONLINEAR_CURVE_VOLUME_HDMI_100          508

#define DEFAULT_NONLINEAR_CURVE_VOLUME_HDMI_PRESCALE    0x6F // 19// 1 //minglin0130

#define DEFAULT_NONLINEAR_CURVE_VOLUME_HDMI_AVC         47

 

#define DEFAULT_NONLINEAR_CURVE_VOLUME_PC_0                245

#define DEFAULT_NONLINEAR_CURVE_VOLUME_PC_10            314

#define DEFAULT_NONLINEAR_CURVE_VOLUME_PC_20           382

#define DEFAULT_NONLINEAR_CURVE_VOLUME_PC_30          410

#define DEFAULT_NONLINEAR_CURVE_VOLUME_PC_40            438

#define DEFAULT_NONLINEAR_CURVE_VOLUME_PC_50            458

#define DEFAULT_NONLINEAR_CURVE_VOLUME_PC_60             481

#define DEFAULT_NONLINEAR_CURVE_VOLUME_PC_70             497

#define DEFAULT_NONLINEAR_CURVE_VOLUME_PC_85           522

#define DEFAULT_NONLINEAR_CURVE_VOLUME_PC_100         549

#define DEFAULT_NONLINEAR_CURVE_VOLUME_PC_PRESCALE     124 //25//29 //minglin0130

#define DEFAULT_NONLINEAR_CURVE_VOLUME_PC_AVC         47

 

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_0              203

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_10             273

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_20            321

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_30             369

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_40            397

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_50              417

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_60              440

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_70              456

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_85               480

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_100             508

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_PRESCALE        0x6F//  50 //minglin0125

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_AVC             15
#elif 0// SMC-BOE-test
#define DEFAULT_NONLINEAR_CURVE_VOLUME_ATV_0               210
#define DEFAULT_NONLINEAR_CURVE_VOLUME_ATV_10          370
#define DEFAULT_NONLINEAR_CURVE_VOLUME_ATV_20            423
#define DEFAULT_NONLINEAR_CURVE_VOLUME_ATV_30           461
#define DEFAULT_NONLINEAR_CURVE_VOLUME_ATV_40            519
#define DEFAULT_NONLINEAR_CURVE_VOLUME_ATV_50           542
#define DEFAULT_NONLINEAR_CURVE_VOLUME_ATV_60             561
#define DEFAULT_NONLINEAR_CURVE_VOLUME_ATV_70             578
#define DEFAULT_NONLINEAR_CURVE_VOLUME_ATV_85            591
#define DEFAULT_NONLINEAR_CURVE_VOLUME_ATV_100         599
#define DEFAULT_NONLINEAR_CURVE_VOLUME_ATV_PRESCALE   73//  66 //minglin0130
#define DEFAULT_NONLINEAR_CURVE_VOLUME_ATV_AVC         47

#define DEFAULT_NONLINEAR_CURVE_VOLUME_AV_0                210
#define DEFAULT_NONLINEAR_CURVE_VOLUME_AV_10            370
#define DEFAULT_NONLINEAR_CURVE_VOLUME_AV_20           423
#define DEFAULT_NONLINEAR_CURVE_VOLUME_AV_30          461
#define DEFAULT_NONLINEAR_CURVE_VOLUME_AV_40            519
#define DEFAULT_NONLINEAR_CURVE_VOLUME_AV_50            542
#define DEFAULT_NONLINEAR_CURVE_VOLUME_AV_60             561
#define DEFAULT_NONLINEAR_CURVE_VOLUME_AV_70             578
#define DEFAULT_NONLINEAR_CURVE_VOLUME_AV_85           591
#define DEFAULT_NONLINEAR_CURVE_VOLUME_AV_100         599
#define DEFAULT_NONLINEAR_CURVE_VOLUME_AV_PRESCALE     24
#define DEFAULT_NONLINEAR_CURVE_VOLUME_AV_AVC         47

#define DEFAULT_NONLINEAR_CURVE_VOLUME_SV_0                210
#define DEFAULT_NONLINEAR_CURVE_VOLUME_SV_10            370
#define DEFAULT_NONLINEAR_CURVE_VOLUME_SV_20           423
#define DEFAULT_NONLINEAR_CURVE_VOLUME_SV_30          461
#define DEFAULT_NONLINEAR_CURVE_VOLUME_SV_40            519
#define DEFAULT_NONLINEAR_CURVE_VOLUME_SV_50            542
#define DEFAULT_NONLINEAR_CURVE_VOLUME_SV_60             561
#define DEFAULT_NONLINEAR_CURVE_VOLUME_SV_70             578
#define DEFAULT_NONLINEAR_CURVE_VOLUME_SV_85           591
#define DEFAULT_NONLINEAR_CURVE_VOLUME_SV_100         599
#define DEFAULT_NONLINEAR_CURVE_VOLUME_SV_PRESCALE            24
#define DEFAULT_NONLINEAR_CURVE_VOLUME_SV_AVC         47

#define DEFAULT_NONLINEAR_CURVE_VOLUME_YPBPR_0                210
#define DEFAULT_NONLINEAR_CURVE_VOLUME_YPBPR_10            370
#define DEFAULT_NONLINEAR_CURVE_VOLUME_YPBPR_20           423
#define DEFAULT_NONLINEAR_CURVE_VOLUME_YPBPR_30          461
#define DEFAULT_NONLINEAR_CURVE_VOLUME_YPBPR_40            519
#define DEFAULT_NONLINEAR_CURVE_VOLUME_YPBPR_50            542
#define DEFAULT_NONLINEAR_CURVE_VOLUME_YPBPR_60             561
#define DEFAULT_NONLINEAR_CURVE_VOLUME_YPBPR_70             578
#define DEFAULT_NONLINEAR_CURVE_VOLUME_YPBPR_85           591
#define DEFAULT_NONLINEAR_CURVE_VOLUME_YPBPR_100         599
#define DEFAULT_NONLINEAR_CURVE_VOLUME_YPBPR_PRESCALE            24
#define DEFAULT_NONLINEAR_CURVE_VOLUME_YPBPR_AVC         47

#define DEFAULT_NONLINEAR_CURVE_VOLUME_HDMI_0                 210
#define DEFAULT_NONLINEAR_CURVE_VOLUME_HDMI_10              366
#define DEFAULT_NONLINEAR_CURVE_VOLUME_HDMI_20              420
#define DEFAULT_NONLINEAR_CURVE_VOLUME_HDMI_30             454
#define DEFAULT_NONLINEAR_CURVE_VOLUME_HDMI_40            514
#define DEFAULT_NONLINEAR_CURVE_VOLUME_HDMI_50            536
#define DEFAULT_NONLINEAR_CURVE_VOLUME_HDMI_60               554
#define DEFAULT_NONLINEAR_CURVE_VOLUME_HDMI_70               571
#define DEFAULT_NONLINEAR_CURVE_VOLUME_HDMI_85             586
#define DEFAULT_NONLINEAR_CURVE_VOLUME_HDMI_100          591
#define DEFAULT_NONLINEAR_CURVE_VOLUME_HDMI_PRESCALE    19//1 //minglin0130
#define DEFAULT_NONLINEAR_CURVE_VOLUME_HDMI_AVC         47

#define DEFAULT_NONLINEAR_CURVE_VOLUME_PC_0                210
#define DEFAULT_NONLINEAR_CURVE_VOLUME_PC_10            370
#define DEFAULT_NONLINEAR_CURVE_VOLUME_PC_20           423
#define DEFAULT_NONLINEAR_CURVE_VOLUME_PC_30          461
#define DEFAULT_NONLINEAR_CURVE_VOLUME_PC_40            519
#define DEFAULT_NONLINEAR_CURVE_VOLUME_PC_50            542
#define DEFAULT_NONLINEAR_CURVE_VOLUME_PC_60             561
#define DEFAULT_NONLINEAR_CURVE_VOLUME_PC_70             578
#define DEFAULT_NONLINEAR_CURVE_VOLUME_PC_85           591
#define DEFAULT_NONLINEAR_CURVE_VOLUME_PC_100         599
#define DEFAULT_NONLINEAR_CURVE_VOLUME_PC_PRESCALE     25//29 //minglin0130
#define DEFAULT_NONLINEAR_CURVE_VOLUME_PC_AVC         47

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_0              210
#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_10             348
#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_20            416
#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_30             452
#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_40            510
#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_50              532
#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_60              552
#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_70              569
#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_85               584
#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_100             599
#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_PRESCALE        18//  50 //minglin0125
#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_AVC             15 

#elif 0 //BOE test_20130404
#define DEFAULT_NONLINEAR_CURVE_VOLUME_ATV_0               284

#define DEFAULT_NONLINEAR_CURVE_VOLUME_ATV_10          379

#define DEFAULT_NONLINEAR_CURVE_VOLUME_ATV_20            415

#define DEFAULT_NONLINEAR_CURVE_VOLUME_ATV_30           456

#define DEFAULT_NONLINEAR_CURVE_VOLUME_ATV_40            481

#define DEFAULT_NONLINEAR_CURVE_VOLUME_ATV_50           500

#define DEFAULT_NONLINEAR_CURVE_VOLUME_ATV_60             526

#define DEFAULT_NONLINEAR_CURVE_VOLUME_ATV_70             540

#define DEFAULT_NONLINEAR_CURVE_VOLUME_ATV_85            568

#define DEFAULT_NONLINEAR_CURVE_VOLUME_ATV_100         590

#define DEFAULT_NONLINEAR_CURVE_VOLUME_ATV_PRESCALE   116//124//  66 //minglin0130

#define DEFAULT_NONLINEAR_CURVE_VOLUME_ATV_AVC         36

 

#define DEFAULT_NONLINEAR_CURVE_VOLUME_AV_0                245

#define DEFAULT_NONLINEAR_CURVE_VOLUME_AV_10            336

#define DEFAULT_NONLINEAR_CURVE_VOLUME_AV_20           371

#define DEFAULT_NONLINEAR_CURVE_VOLUME_AV_30          411

#define DEFAULT_NONLINEAR_CURVE_VOLUME_AV_40            439

#define DEFAULT_NONLINEAR_CURVE_VOLUME_AV_50            459

#define DEFAULT_NONLINEAR_CURVE_VOLUME_AV_60             480

#define DEFAULT_NONLINEAR_CURVE_VOLUME_AV_70             493

#define DEFAULT_NONLINEAR_CURVE_VOLUME_AV_85           519

#define DEFAULT_NONLINEAR_CURVE_VOLUME_AV_100         544

#define DEFAULT_NONLINEAR_CURVE_VOLUME_AV_PRESCALE     124

#define DEFAULT_NONLINEAR_CURVE_VOLUME_AV_AVC         25

 

#define DEFAULT_NONLINEAR_CURVE_VOLUME_SV_0                245

#define DEFAULT_NONLINEAR_CURVE_VOLUME_SV_10            336

#define DEFAULT_NONLINEAR_CURVE_VOLUME_SV_20           371

#define DEFAULT_NONLINEAR_CURVE_VOLUME_SV_30          411

#define DEFAULT_NONLINEAR_CURVE_VOLUME_SV_40            439

#define DEFAULT_NONLINEAR_CURVE_VOLUME_SV_50            459

#define DEFAULT_NONLINEAR_CURVE_VOLUME_SV_60             480

#define DEFAULT_NONLINEAR_CURVE_VOLUME_SV_70             493

#define DEFAULT_NONLINEAR_CURVE_VOLUME_SV_85           519

#define DEFAULT_NONLINEAR_CURVE_VOLUME_SV_100         544

#define DEFAULT_NONLINEAR_CURVE_VOLUME_SV_PRESCALE            124 // 24

#define DEFAULT_NONLINEAR_CURVE_VOLUME_SV_AVC         25

 

#define DEFAULT_NONLINEAR_CURVE_VOLUME_YPBPR_0                245

#define DEFAULT_NONLINEAR_CURVE_VOLUME_YPBPR_10            336

#define DEFAULT_NONLINEAR_CURVE_VOLUME_YPBPR_20           371

#define DEFAULT_NONLINEAR_CURVE_VOLUME_YPBPR_30          411

#define DEFAULT_NONLINEAR_CURVE_VOLUME_YPBPR_40            439

#define DEFAULT_NONLINEAR_CURVE_VOLUME_YPBPR_50            459

#define DEFAULT_NONLINEAR_CURVE_VOLUME_YPBPR_60             480

#define DEFAULT_NONLINEAR_CURVE_VOLUME_YPBPR_70             493

#define DEFAULT_NONLINEAR_CURVE_VOLUME_YPBPR_85           519

#define DEFAULT_NONLINEAR_CURVE_VOLUME_YPBPR_100         544

#define DEFAULT_NONLINEAR_CURVE_VOLUME_YPBPR_PRESCALE            124 // 24

#define DEFAULT_NONLINEAR_CURVE_VOLUME_YPBPR_AVC         25

 

#define DEFAULT_NONLINEAR_CURVE_VOLUME_HDMI_0                 203

#define DEFAULT_NONLINEAR_CURVE_VOLUME_HDMI_10              336

#define DEFAULT_NONLINEAR_CURVE_VOLUME_HDMI_20              371

#define DEFAULT_NONLINEAR_CURVE_VOLUME_HDMI_30             412

#define DEFAULT_NONLINEAR_CURVE_VOLUME_HDMI_40            439

#define DEFAULT_NONLINEAR_CURVE_VOLUME_HDMI_50            458

#define DEFAULT_NONLINEAR_CURVE_VOLUME_HDMI_60               480

#define DEFAULT_NONLINEAR_CURVE_VOLUME_HDMI_70               493

#define DEFAULT_NONLINEAR_CURVE_VOLUME_HDMI_85             519

#define DEFAULT_NONLINEAR_CURVE_VOLUME_HDMI_100          542

#define DEFAULT_NONLINEAR_CURVE_VOLUME_HDMI_PRESCALE    107//111 // 19// 1 //minglin0130

#define DEFAULT_NONLINEAR_CURVE_VOLUME_HDMI_AVC         25

 

#define DEFAULT_NONLINEAR_CURVE_VOLUME_PC_0                245

#define DEFAULT_NONLINEAR_CURVE_VOLUME_PC_10            336

#define DEFAULT_NONLINEAR_CURVE_VOLUME_PC_20           370

#define DEFAULT_NONLINEAR_CURVE_VOLUME_PC_30          411

#define DEFAULT_NONLINEAR_CURVE_VOLUME_PC_40            437

#define DEFAULT_NONLINEAR_CURVE_VOLUME_PC_50            457

#define DEFAULT_NONLINEAR_CURVE_VOLUME_PC_60             479

#define DEFAULT_NONLINEAR_CURVE_VOLUME_PC_70             492

#define DEFAULT_NONLINEAR_CURVE_VOLUME_PC_85           517

#define DEFAULT_NONLINEAR_CURVE_VOLUME_PC_100         544

#define DEFAULT_NONLINEAR_CURVE_VOLUME_PC_PRESCALE     124 //25//29 //minglin0130

#define DEFAULT_NONLINEAR_CURVE_VOLUME_PC_AVC         25

 
#if 1 // -9db
#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_0              206

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_10             282//214

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_20            330//282

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_30             389//330

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_40            406//389

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_50              427//406

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_60              449//427

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_70              465//449

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_85               489//465

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_100             512//489

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_PRESCALE        111//111//  50 //minglin0125

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_AVC             25
#else // -12db
#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_0              203

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_10             336

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_20            371

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_30             412

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_40            439

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_50              458

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_60              480

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_70              493

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_85               519

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_100             542

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_PRESCALE        106//111//  50 //minglin0125

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_AVC             25
#endif

#elif 0//BOE_TEST_20130408
#define DEFAULT_NONLINEAR_CURVE_VOLUME_ATV_0               284

#define DEFAULT_NONLINEAR_CURVE_VOLUME_ATV_10          344

#define DEFAULT_NONLINEAR_CURVE_VOLUME_ATV_20            406

#define DEFAULT_NONLINEAR_CURVE_VOLUME_ATV_30           454

#define DEFAULT_NONLINEAR_CURVE_VOLUME_ATV_40            494

#define DEFAULT_NONLINEAR_CURVE_VOLUME_ATV_50           518

#define DEFAULT_NONLINEAR_CURVE_VOLUME_ATV_60             534

#define DEFAULT_NONLINEAR_CURVE_VOLUME_ATV_70             548

#define DEFAULT_NONLINEAR_CURVE_VOLUME_ATV_85            575

#define DEFAULT_NONLINEAR_CURVE_VOLUME_ATV_100         599

#define DEFAULT_NONLINEAR_CURVE_VOLUME_ATV_PRESCALE   94//114//124//  66 //minglin0130

#define DEFAULT_NONLINEAR_CURVE_VOLUME_ATV_AVC         36

 

#define DEFAULT_NONLINEAR_CURVE_VOLUME_AV_0                245

#define DEFAULT_NONLINEAR_CURVE_VOLUME_AV_10            288

#define DEFAULT_NONLINEAR_CURVE_VOLUME_AV_20           350

#define DEFAULT_NONLINEAR_CURVE_VOLUME_AV_30          398

#define DEFAULT_NONLINEAR_CURVE_VOLUME_AV_40            439

#define DEFAULT_NONLINEAR_CURVE_VOLUME_AV_50            462

#define DEFAULT_NONLINEAR_CURVE_VOLUME_AV_60             478

#define DEFAULT_NONLINEAR_CURVE_VOLUME_AV_70             492

#define DEFAULT_NONLINEAR_CURVE_VOLUME_AV_85           519

#define DEFAULT_NONLINEAR_CURVE_VOLUME_AV_100         543

#define DEFAULT_NONLINEAR_CURVE_VOLUME_AV_PRESCALE     124

#define DEFAULT_NONLINEAR_CURVE_VOLUME_AV_AVC         25

 

#define DEFAULT_NONLINEAR_CURVE_VOLUME_SV_0                245

#define DEFAULT_NONLINEAR_CURVE_VOLUME_SV_10            288

#define DEFAULT_NONLINEAR_CURVE_VOLUME_SV_20           350

#define DEFAULT_NONLINEAR_CURVE_VOLUME_SV_30          398

#define DEFAULT_NONLINEAR_CURVE_VOLUME_SV_40            439

#define DEFAULT_NONLINEAR_CURVE_VOLUME_SV_50            462

#define DEFAULT_NONLINEAR_CURVE_VOLUME_SV_60             478

#define DEFAULT_NONLINEAR_CURVE_VOLUME_SV_70             492

#define DEFAULT_NONLINEAR_CURVE_VOLUME_SV_85           519

#define DEFAULT_NONLINEAR_CURVE_VOLUME_SV_100         543

#define DEFAULT_NONLINEAR_CURVE_VOLUME_SV_PRESCALE            124 // 24

#define DEFAULT_NONLINEAR_CURVE_VOLUME_SV_AVC         25

 

#define DEFAULT_NONLINEAR_CURVE_VOLUME_YPBPR_0                245

#define DEFAULT_NONLINEAR_CURVE_VOLUME_YPBPR_10            288

#define DEFAULT_NONLINEAR_CURVE_VOLUME_YPBPR_20           350

#define DEFAULT_NONLINEAR_CURVE_VOLUME_YPBPR_30          398

#define DEFAULT_NONLINEAR_CURVE_VOLUME_YPBPR_40            439

#define DEFAULT_NONLINEAR_CURVE_VOLUME_YPBPR_50            462

#define DEFAULT_NONLINEAR_CURVE_VOLUME_YPBPR_60             478

#define DEFAULT_NONLINEAR_CURVE_VOLUME_YPBPR_70             492

#define DEFAULT_NONLINEAR_CURVE_VOLUME_YPBPR_85           519

#define DEFAULT_NONLINEAR_CURVE_VOLUME_YPBPR_100         543

#define DEFAULT_NONLINEAR_CURVE_VOLUME_YPBPR_PRESCALE            124 // 24

#define DEFAULT_NONLINEAR_CURVE_VOLUME_YPBPR_AVC         25

 

#define DEFAULT_NONLINEAR_CURVE_VOLUME_HDMI_0                 203

#define DEFAULT_NONLINEAR_CURVE_VOLUME_HDMI_10              287

#define DEFAULT_NONLINEAR_CURVE_VOLUME_HDMI_20              350

#define DEFAULT_NONLINEAR_CURVE_VOLUME_HDMI_30             397

#define DEFAULT_NONLINEAR_CURVE_VOLUME_HDMI_40            438

#define DEFAULT_NONLINEAR_CURVE_VOLUME_HDMI_50            461

#define DEFAULT_NONLINEAR_CURVE_VOLUME_HDMI_60               477

#define DEFAULT_NONLINEAR_CURVE_VOLUME_HDMI_70               492

#define DEFAULT_NONLINEAR_CURVE_VOLUME_HDMI_85             519

#define DEFAULT_NONLINEAR_CURVE_VOLUME_HDMI_100          542

#define DEFAULT_NONLINEAR_CURVE_VOLUME_HDMI_PRESCALE    107//111 // 19// 1 //minglin0130

#define DEFAULT_NONLINEAR_CURVE_VOLUME_HDMI_AVC         25

 

#define DEFAULT_NONLINEAR_CURVE_VOLUME_PC_0                245

#define DEFAULT_NONLINEAR_CURVE_VOLUME_PC_10            288

#define DEFAULT_NONLINEAR_CURVE_VOLUME_PC_20           350

#define DEFAULT_NONLINEAR_CURVE_VOLUME_PC_30          398

#define DEFAULT_NONLINEAR_CURVE_VOLUME_PC_40            439

#define DEFAULT_NONLINEAR_CURVE_VOLUME_PC_50            462

#define DEFAULT_NONLINEAR_CURVE_VOLUME_PC_60             478

#define DEFAULT_NONLINEAR_CURVE_VOLUME_PC_70             492

#define DEFAULT_NONLINEAR_CURVE_VOLUME_PC_85           519

#define DEFAULT_NONLINEAR_CURVE_VOLUME_PC_100         543

#define DEFAULT_NONLINEAR_CURVE_VOLUME_PC_PRESCALE     124 //25//29 //minglin0130

#define DEFAULT_NONLINEAR_CURVE_VOLUME_PC_AVC         25

 
#if 1 // -9db
#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_0              206

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_10             260//214

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_20            321//282

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_30             369//330

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_40            409//389

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_50              433//406

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_60              449//427

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_70              464//449

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_85               490//465

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_100             514//489

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_PRESCALE        111//111//  50 //minglin0125

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_AVC             25
#else // -12db
#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_0              203

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_10             336

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_20            371

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_30             412

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_40            439

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_50              458

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_60              480

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_70              493

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_85               519

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_100             542

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_PRESCALE        106//111//  50 //minglin0125

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_AVC             25
#endif
#else //BOE_TEST_20130502
#define DEFAULT_NONLINEAR_CURVE_VOLUME_ATV_0               284

#define DEFAULT_NONLINEAR_CURVE_VOLUME_ATV_10          362

#define DEFAULT_NONLINEAR_CURVE_VOLUME_ATV_20            441

#define DEFAULT_NONLINEAR_CURVE_VOLUME_ATV_30           472

#define DEFAULT_NONLINEAR_CURVE_VOLUME_ATV_40            494

#define DEFAULT_NONLINEAR_CURVE_VOLUME_ATV_50           518

#define DEFAULT_NONLINEAR_CURVE_VOLUME_ATV_60             534

#define DEFAULT_NONLINEAR_CURVE_VOLUME_ATV_70             548

#define DEFAULT_NONLINEAR_CURVE_VOLUME_ATV_85            575

#define DEFAULT_NONLINEAR_CURVE_VOLUME_ATV_100         599

#define DEFAULT_NONLINEAR_CURVE_VOLUME_ATV_PRESCALE   94//114//124//  66 //minglin0130

#define DEFAULT_NONLINEAR_CURVE_VOLUME_ATV_AVC         36

 

#define DEFAULT_NONLINEAR_CURVE_VOLUME_AV_0                245

#define DEFAULT_NONLINEAR_CURVE_VOLUME_AV_10            321

#define DEFAULT_NONLINEAR_CURVE_VOLUME_AV_20           398

#define DEFAULT_NONLINEAR_CURVE_VOLUME_AV_30          433

#define DEFAULT_NONLINEAR_CURVE_VOLUME_AV_40            453

#define DEFAULT_NONLINEAR_CURVE_VOLUME_AV_50            468

#define DEFAULT_NONLINEAR_CURVE_VOLUME_AV_60             483

#define DEFAULT_NONLINEAR_CURVE_VOLUME_AV_70             492

#define DEFAULT_NONLINEAR_CURVE_VOLUME_AV_85           519

#define DEFAULT_NONLINEAR_CURVE_VOLUME_AV_100         543

#define DEFAULT_NONLINEAR_CURVE_VOLUME_AV_PRESCALE     124

#define DEFAULT_NONLINEAR_CURVE_VOLUME_AV_AVC         25

 

#define DEFAULT_NONLINEAR_CURVE_VOLUME_SV_0                245

#define DEFAULT_NONLINEAR_CURVE_VOLUME_SV_10            321

#define DEFAULT_NONLINEAR_CURVE_VOLUME_SV_20           398

#define DEFAULT_NONLINEAR_CURVE_VOLUME_SV_30          433

#define DEFAULT_NONLINEAR_CURVE_VOLUME_SV_40            453

#define DEFAULT_NONLINEAR_CURVE_VOLUME_SV_50            468

#define DEFAULT_NONLINEAR_CURVE_VOLUME_SV_60             483

#define DEFAULT_NONLINEAR_CURVE_VOLUME_SV_70             492

#define DEFAULT_NONLINEAR_CURVE_VOLUME_SV_85           519

#define DEFAULT_NONLINEAR_CURVE_VOLUME_SV_100         543

#define DEFAULT_NONLINEAR_CURVE_VOLUME_SV_PRESCALE            124 // 24

#define DEFAULT_NONLINEAR_CURVE_VOLUME_SV_AVC         25

 

#define DEFAULT_NONLINEAR_CURVE_VOLUME_YPBPR_0                245

#define DEFAULT_NONLINEAR_CURVE_VOLUME_YPBPR_10            321

#define DEFAULT_NONLINEAR_CURVE_VOLUME_YPBPR_20           398

#define DEFAULT_NONLINEAR_CURVE_VOLUME_YPBPR_30          433

#define DEFAULT_NONLINEAR_CURVE_VOLUME_YPBPR_40            453

#define DEFAULT_NONLINEAR_CURVE_VOLUME_YPBPR_50            468

#define DEFAULT_NONLINEAR_CURVE_VOLUME_YPBPR_60             483

#define DEFAULT_NONLINEAR_CURVE_VOLUME_YPBPR_70             492

#define DEFAULT_NONLINEAR_CURVE_VOLUME_YPBPR_85           519

#define DEFAULT_NONLINEAR_CURVE_VOLUME_YPBPR_100         543

#define DEFAULT_NONLINEAR_CURVE_VOLUME_YPBPR_PRESCALE            124 // 24

#define DEFAULT_NONLINEAR_CURVE_VOLUME_YPBPR_AVC         25

 

#define DEFAULT_NONLINEAR_CURVE_VOLUME_HDMI_0                 203

#define DEFAULT_NONLINEAR_CURVE_VOLUME_HDMI_10              322

#define DEFAULT_NONLINEAR_CURVE_VOLUME_HDMI_20              399

#define DEFAULT_NONLINEAR_CURVE_VOLUME_HDMI_30             434

#define DEFAULT_NONLINEAR_CURVE_VOLUME_HDMI_40            455

#define DEFAULT_NONLINEAR_CURVE_VOLUME_HDMI_50            469

#define DEFAULT_NONLINEAR_CURVE_VOLUME_HDMI_60               482

#define DEFAULT_NONLINEAR_CURVE_VOLUME_HDMI_70               492

#define DEFAULT_NONLINEAR_CURVE_VOLUME_HDMI_85             519

#define DEFAULT_NONLINEAR_CURVE_VOLUME_HDMI_100          542

#define DEFAULT_NONLINEAR_CURVE_VOLUME_HDMI_PRESCALE    107//111 // 19// 1 //minglin0130

#define DEFAULT_NONLINEAR_CURVE_VOLUME_HDMI_AVC         25

 

#define DEFAULT_NONLINEAR_CURVE_VOLUME_PC_0                245

#define DEFAULT_NONLINEAR_CURVE_VOLUME_PC_10            321

#define DEFAULT_NONLINEAR_CURVE_VOLUME_PC_20           398

#define DEFAULT_NONLINEAR_CURVE_VOLUME_PC_30          433

#define DEFAULT_NONLINEAR_CURVE_VOLUME_PC_40            453

#define DEFAULT_NONLINEAR_CURVE_VOLUME_PC_50            468

#define DEFAULT_NONLINEAR_CURVE_VOLUME_PC_60             483

#define DEFAULT_NONLINEAR_CURVE_VOLUME_PC_70             492

#define DEFAULT_NONLINEAR_CURVE_VOLUME_PC_85           519

#define DEFAULT_NONLINEAR_CURVE_VOLUME_PC_100         543

#define DEFAULT_NONLINEAR_CURVE_VOLUME_PC_PRESCALE     124 //25//29 //minglin0130

#define DEFAULT_NONLINEAR_CURVE_VOLUME_PC_AVC         25

 
#if 1 // -9db
#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_0              206

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_10             294//214

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_20            371//282

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_30             406//330

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_40            426//389

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_50              442//406

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_60              454//427

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_70              464//449

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_85               490//465

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_100             514//489

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_PRESCALE        111//111//  50 //minglin0125

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_AVC             25
#else // -12db
#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_0              203

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_10             336

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_20            371

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_30             412

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_40            439

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_50              458

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_60              480

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_70              493

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_85               519

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_100             542

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_PRESCALE        106//111//  50 //minglin0125

#define DEFAULT_NONLINEAR_CURVE_VOLUME_USB_AVC             25
#endif

#endif

#endif

static code MS_NONLINEAR_CURVE_SETTING tNonLinearCurveSetting =
{
    0,       // check sum

#if(ENABLE_PICTURE_NONLINEAR_CURVE)
//NONLINEAR_CURVE_CONTRAST,
//NONLINEAR_CURVE_BRIGHTNESS,
//NONLINEAR_CURVE_SATURATION,
//NONLINEAR_CURVE_SHARPNESS,
//NONLINEAR_CURVE_HUE,
#if ENABLE_DTV
    // DTV
    tNonLinearCurveSetting_DTV,
#endif
    // ATV
    tNonLinearCurveSetting_ATV,
    // AV
    tNonLinearCurveSetting_AV,
    // SV
    tNonLinearCurveSetting_SV,
    // YPbPr
    tNonLinearCurveSetting_YPBPR,
    // HDMI
    tNonLinearCurveSetting_HDMI,
    // PC
    tNonLinearCurveSetting_VGA,
    // Storage
    tNonLinearCurveSetting_USB,
#endif
#if(!BOE_VOLUME_CURVE)
#if(ENABLE_SOUND_NONLINEAR_CURVE)
#if ENABLE_SOUND_NONLINEAR_CURVE_TEN

#if ENABLE_DTV
    // DTV
    {
      DEFAULT_NONLINEAR_CURVE_VOLUME_DTV_0,
      DEFAULT_NONLINEAR_CURVE_VOLUME_DTV_10,
      DEFAULT_NONLINEAR_CURVE_VOLUME_DTV_20,
      DEFAULT_NONLINEAR_CURVE_VOLUME_DTV_30,
      DEFAULT_NONLINEAR_CURVE_VOLUME_DTV_40,
      DEFAULT_NONLINEAR_CURVE_VOLUME_DTV_50,
      DEFAULT_NONLINEAR_CURVE_VOLUME_DTV_60,
      DEFAULT_NONLINEAR_CURVE_VOLUME_DTV_70 ,
      DEFAULT_NONLINEAR_CURVE_VOLUME_DTV_85 ,
      DEFAULT_NONLINEAR_CURVE_VOLUME_DTV_100,
    },    // Volume
#endif
       // ATV_
    {
      DEFAULT_NONLINEAR_CURVE_VOLUME_ATV_0,
      DEFAULT_NONLINEAR_CURVE_VOLUME_ATV_10,
      DEFAULT_NONLINEAR_CURVE_VOLUME_ATV_20,
      DEFAULT_NONLINEAR_CURVE_VOLUME_ATV_30,
      DEFAULT_NONLINEAR_CURVE_VOLUME_ATV_40,
      DEFAULT_NONLINEAR_CURVE_VOLUME_ATV_50,
      DEFAULT_NONLINEAR_CURVE_VOLUME_ATV_60,
      DEFAULT_NONLINEAR_CURVE_VOLUME_ATV_70 ,
      DEFAULT_NONLINEAR_CURVE_VOLUME_ATV_85 ,
      DEFAULT_NONLINEAR_CURVE_VOLUME_ATV_100,
      DEFAULT_NONLINEAR_CURVE_VOLUME_ATV_PRESCALE,
	  DEFAULT_NONLINEAR_CURVE_VOLUME_ATV_AVC,//52,
    },    // Volume
    // AV_
    {
		DEFAULT_NONLINEAR_CURVE_VOLUME_AV_0,
		DEFAULT_NONLINEAR_CURVE_VOLUME_AV_10,
		DEFAULT_NONLINEAR_CURVE_VOLUME_AV_20,
		DEFAULT_NONLINEAR_CURVE_VOLUME_AV_30,
		DEFAULT_NONLINEAR_CURVE_VOLUME_AV_40,
		DEFAULT_NONLINEAR_CURVE_VOLUME_AV_50,
		DEFAULT_NONLINEAR_CURVE_VOLUME_AV_60,
		DEFAULT_NONLINEAR_CURVE_VOLUME_AV_70 ,
		DEFAULT_NONLINEAR_CURVE_VOLUME_AV_85 ,
		DEFAULT_NONLINEAR_CURVE_VOLUME_AV_100,
		DEFAULT_NONLINEAR_CURVE_VOLUME_AV_PRESCALE,
		DEFAULT_NONLINEAR_CURVE_VOLUME_AV_AVC,//52,
	  },	// Volume
 
    // STORAGE_
		{
		  DEFAULT_NONLINEAR_CURVE_VOLUME_SV_0,
		  DEFAULT_NONLINEAR_CURVE_VOLUME_SV_10,
		  DEFAULT_NONLINEAR_CURVE_VOLUME_SV_20,
		  DEFAULT_NONLINEAR_CURVE_VOLUME_SV_30,
		  DEFAULT_NONLINEAR_CURVE_VOLUME_SV_40,
		  DEFAULT_NONLINEAR_CURVE_VOLUME_SV_50,
		  DEFAULT_NONLINEAR_CURVE_VOLUME_SV_60,
		  DEFAULT_NONLINEAR_CURVE_VOLUME_SV_70 ,
		  DEFAULT_NONLINEAR_CURVE_VOLUME_SV_85 ,
		  DEFAULT_NONLINEAR_CURVE_VOLUME_SV_100,
		  DEFAULT_NONLINEAR_CURVE_VOLUME_SV_PRESCALE,
		  DEFAULT_NONLINEAR_CURVE_VOLUME_SV_AVC,//52,
		},	  // Volume

		  {
			DEFAULT_NONLINEAR_CURVE_VOLUME_YPBPR_0,
			DEFAULT_NONLINEAR_CURVE_VOLUME_YPBPR_10,
			DEFAULT_NONLINEAR_CURVE_VOLUME_YPBPR_20,
			DEFAULT_NONLINEAR_CURVE_VOLUME_YPBPR_30,
			DEFAULT_NONLINEAR_CURVE_VOLUME_YPBPR_40,
			DEFAULT_NONLINEAR_CURVE_VOLUME_YPBPR_50,
			DEFAULT_NONLINEAR_CURVE_VOLUME_YPBPR_60,
			DEFAULT_NONLINEAR_CURVE_VOLUME_YPBPR_70 ,
			DEFAULT_NONLINEAR_CURVE_VOLUME_YPBPR_85 ,
			DEFAULT_NONLINEAR_CURVE_VOLUME_YPBPR_100,
			DEFAULT_NONLINEAR_CURVE_VOLUME_YPBPR_PRESCALE,
			DEFAULT_NONLINEAR_CURVE_VOLUME_YPBPR_AVC,//52,
		  },	// Volume

			{
			  DEFAULT_NONLINEAR_CURVE_VOLUME_HDMI_0,
			  DEFAULT_NONLINEAR_CURVE_VOLUME_HDMI_10,
			  DEFAULT_NONLINEAR_CURVE_VOLUME_HDMI_20,
			  DEFAULT_NONLINEAR_CURVE_VOLUME_HDMI_30,
			  DEFAULT_NONLINEAR_CURVE_VOLUME_HDMI_40,
			  DEFAULT_NONLINEAR_CURVE_VOLUME_HDMI_50,
			  DEFAULT_NONLINEAR_CURVE_VOLUME_HDMI_60,
			  DEFAULT_NONLINEAR_CURVE_VOLUME_HDMI_70 ,
			  DEFAULT_NONLINEAR_CURVE_VOLUME_HDMI_85 ,
			  DEFAULT_NONLINEAR_CURVE_VOLUME_HDMI_100,
			  DEFAULT_NONLINEAR_CURVE_VOLUME_HDMI_PRESCALE,
			  DEFAULT_NONLINEAR_CURVE_VOLUME_HDMI_AVC,//52,
			},	  // Volume

			  {
				DEFAULT_NONLINEAR_CURVE_VOLUME_PC_0,
				DEFAULT_NONLINEAR_CURVE_VOLUME_PC_10,
				DEFAULT_NONLINEAR_CURVE_VOLUME_PC_20,
				DEFAULT_NONLINEAR_CURVE_VOLUME_PC_30,
				DEFAULT_NONLINEAR_CURVE_VOLUME_PC_40,
				DEFAULT_NONLINEAR_CURVE_VOLUME_PC_50,
				DEFAULT_NONLINEAR_CURVE_VOLUME_PC_60,
				DEFAULT_NONLINEAR_CURVE_VOLUME_PC_70 ,
				DEFAULT_NONLINEAR_CURVE_VOLUME_PC_85 ,
				DEFAULT_NONLINEAR_CURVE_VOLUME_PC_100,
				DEFAULT_NONLINEAR_CURVE_VOLUME_PC_PRESCALE,
				DEFAULT_NONLINEAR_CURVE_VOLUME_PC_AVC,//52,
			  },	// Volume

				{
				  DEFAULT_NONLINEAR_CURVE_VOLUME_USB_0,
				  DEFAULT_NONLINEAR_CURVE_VOLUME_USB_10,
				  DEFAULT_NONLINEAR_CURVE_VOLUME_USB_20,
				  DEFAULT_NONLINEAR_CURVE_VOLUME_USB_30,
				  DEFAULT_NONLINEAR_CURVE_VOLUME_USB_40,
				  DEFAULT_NONLINEAR_CURVE_VOLUME_USB_50,
				  DEFAULT_NONLINEAR_CURVE_VOLUME_USB_60,
				  DEFAULT_NONLINEAR_CURVE_VOLUME_USB_70 ,
				  DEFAULT_NONLINEAR_CURVE_VOLUME_USB_85 ,
				  DEFAULT_NONLINEAR_CURVE_VOLUME_USB_100,
    			 #if ENABLE_SOUND_NEW_NONLINEAR//rong_usb_audio
    			  DEFAULT_NONLINEAR_CURVE_VOLUME_USB_PRESCALE,
    			  DEFAULT_NONLINEAR_CURVE_VOLUME_USB_AVC,//52,
    			 #else
    			  DEFAULT_NONLINEAR_CURVE_VOLUME_USB_PRESCALE,
    			  DEFAULT_NONLINEAR_CURVE_VOLUME_USB_AVC,//52,
    			 #endif		  
				},	  // Volume	
#else

#if ENABLE_DTV
    // DTV
    {0, 25, 50, 75, 100},   // Volume
#endif
    // TV
    {20, 40, 50, 75, 100},   // Volume //minglin1231
    // AV
    {20, 40, 50, 75, 100},   // Volume //minglin1231
    // Storage
    {20, 40, 50, 75, 100},   // Volume //minglin1231
#endif
#endif
#endif
};
#endif

#else

//This value will be set depend on UI initial value. It is not related with picture quality.
static T_MS_VIDEO code astDefaultVideoDataTbl[DATA_INPUT_SOURCE_NUM] =
{
#if ENABLE_DTV
    {// DTV
        0,//CS
        PICTURE_NORMAL, // default Picture mode
        {
            {//Dynamic
                DYNAMIC_BACKLIGHT,
                DYNAMIC_CONTRAST,
                DYNAMIC_BRIGHTNESS,
                DYNAMIC_SATURATION,
                DYNAMIC_SHARPNESS,
                DYNAMIC_HUE,
                DYNAMIC_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                DYNAMIC_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_MIDDLE,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            {//Standard
                STANDARD_BACKLIGHT,
                STANDARD_CONTRAST,
                STANDARD_BRIGHTNESS,
                STANDARD_SATURATION,
                STANDARD_SHARPNESS,
                STANDARD_HUE,
                STANDARD_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                STANDARD_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_MIDDLE,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            {//Mild
                MILD_BACKLIGHT,
                MILD_CONTRAST,
                MILD_BRIGHTNESS,
                MILD_SATURATION,
                MILD_SHARPNESS,
                MILD_HUE,
                MILD_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                MILD_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_MIDDLE,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            #if ENABLE_PICTURE_MODE_ENERGY_SAVING
            {//Energy saving
                DYNAMIC_BACKLIGHT,
                DYNAMIC_CONTRAST,
                DYNAMIC_BRIGHTNESS,
                DYNAMIC_SATURATION,
                DYNAMIC_SHARPNESS,
                DYNAMIC_HUE,
                DYNAMIC_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                DYNAMIC_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_ON,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_MIDDLE,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            #endif
            {//USER
                DYNAMIC_BACKLIGHT,
                DYNAMIC_CONTRAST,
                DYNAMIC_BRIGHTNESS,
                DYNAMIC_SATURATION,
                DYNAMIC_SHARPNESS,
                DYNAMIC_HUE,
                DYNAMIC_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                DYNAMIC_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_MIDDLE,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            #if PICTURE_USER_2
            {//USER2
                DYNAMIC_BACKLIGHT,
                DYNAMIC_CONTRAST,
                DYNAMIC_BRIGHTNESS,
                DYNAMIC_SATURATION,
                DYNAMIC_SHARPNESS,
                DYNAMIC_HUE,
                DYNAMIC_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                DYNAMIC_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_MIDDLE,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            #endif
        },
        #if (ENABLE_CUS_NR_MODE_FOLLOW_PICMODE == DISABLE)
        {
            MS_NR_MIDDLE,//MS_NR_AUTO,
            MS_MPEG_NR_LOW,
        },
        #endif

        MS_BLACK_LEVEL_HIGH,
        EN_AspectRatio_16X9
    },
#endif
    {// ATV
        0,//CS
	 PICTURE_DYNAMIC,
        {
            {//Dynamic
                DYNAMIC_BACKLIGHT,
                DYNAMIC_CONTRAST,
                DYNAMIC_BRIGHTNESS,
                DYNAMIC_SATURATION,
                DYNAMIC_SHARPNESS,
                DYNAMIC_HUE,
                DYNAMIC_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                DYNAMIC_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_ON,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_HIGH,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            {//Standard
                STANDARD_ATV_BACKLIGHT,
                STANDARD_ATV_CONTRAST,
                STANDARD_ATV_BRIGHTNESS,
                STANDARD_ATV_SATURATION,
                STANDARD_ATV_SHARPNESS,
                STANDARD_ATV_HUE,
                STANDARD_COLOR_ATV_TEMP,
            #if ENABLE_FLESH_TONE
                STANDARD_ATV_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_ON,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_HIGH,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            {//Mild
                MILD_BACKLIGHT,
                MILD_CONTRAST,
                MILD_BRIGHTNESS,
                MILD_SATURATION,
                MILD_SHARPNESS,
                MILD_HUE,
                MILD_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                MILD_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_ON,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_HIGH,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            #if ENABLE_PICTURE_MODE_ENERGY_SAVING
            {//Energy saving
                DYNAMIC_ENERGYSAVING_BACKLIGHT,
                DYNAMIC_ENERGYSAVING_CONTRAST,
                DYNAMIC_ENERGYSAVING_BRIGHTNESS,
                DYNAMIC_ENERGYSAVING_SATURATION,
                DYNAMIC_ENERGYSAVING_SHARPNESS,
                DYNAMIC_ENERGYSAVING_HUE,
                DYNAMIC_ENERGYSAVING_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                DYNAMIC_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_ON,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_HIGH,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            #endif
            {//USER
                DYNAMIC_USER_BACKLIGHT,
                DYNAMIC_USER_CONTRAST,
                DYNAMIC_USER_BRIGHTNESS,
                DYNAMIC_USER_SATURATION,
                DYNAMIC_USER_SHARPNESS,
                DYNAMIC_USER_HUE,
                DYNAMIC_USER_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                DYNAMIC_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_ON,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_HIGH,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            #if PICTURE_USER_2
            {//USER2
                DYNAMIC_BACKLIGHT,
                DYNAMIC_CONTRAST,
                DYNAMIC_BRIGHTNESS,
                DYNAMIC_SATURATION,
                DYNAMIC_SHARPNESS,
                DYNAMIC_HUE,
                DYNAMIC_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                DYNAMIC_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_HIGH,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            #endif
        },
        #if (ENABLE_CUS_NR_MODE_FOLLOW_PICMODE == DISABLE)
        {
            MS_NR_HIGH,//MS_NR_AUTO,
            MS_MPEG_NR_LOW,
        },
        #endif
        MS_BLACK_LEVEL_HIGH,
        EN_AspectRatio_16X9

    },
#if (INPUT_AV_VIDEO_COUNT >= 1)
    {// VIDEO
        0,//CS
        PICTURE_DYNAMIC, // Picture mode
        {
            {//Dynamic
                DYNAMIC_BACKLIGHT,
                DYNAMIC_CONTRAST,
                DYNAMIC_BRIGHTNESS,
                DYNAMIC_SATURATION,
                DYNAMIC_SHARPNESS,
                DYNAMIC_HUE,
                DYNAMIC_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                DYNAMIC_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_MIDDLE,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            {//Standard
             STANDARD_AV_BACKLIGHT,
                STANDARD_AV_CONTRAST,
                STANDARD_AV_BRIGHTNESS,
                STANDARD_AV_SATURATION,
                STANDARD_AV_SHARPNESS,
                STANDARD_AV_HUE,
                STANDARD_COLOR_AV_TEMP,
            #if ENABLE_FLESH_TONE
                STANDARD_AV_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_MIDDLE,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            {//Mild
                MILD_BACKLIGHT,
                MILD_CONTRAST,
                MILD_BRIGHTNESS,
                MILD_SATURATION,
                MILD_SHARPNESS,
                MILD_HUE,
                MILD_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                MILD_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_MIDDLE,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            #if ENABLE_PICTURE_MODE_ENERGY_SAVING
            {//Energy saving
                DYNAMIC_ENERGYSAVING_BACKLIGHT,
                DYNAMIC_ENERGYSAVING_CONTRAST,
                DYNAMIC_ENERGYSAVING_BRIGHTNESS,
                DYNAMIC_ENERGYSAVING_SATURATION,
                DYNAMIC_ENERGYSAVING_SHARPNESS,
                DYNAMIC_ENERGYSAVING_HUE,
                DYNAMIC_ENERGYSAVING_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                DYNAMIC_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_ON,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_MIDDLE,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            #endif
            {//USER
                DYNAMIC_BACKLIGHT,
                DYNAMIC_CONTRAST,
                DYNAMIC_BRIGHTNESS,
                DYNAMIC_SATURATION,
                DYNAMIC_SHARPNESS,
                DYNAMIC_HUE,
                DYNAMIC_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                DYNAMIC_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_MIDDLE,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            #if PICTURE_USER_2
            {//USER2
                DYNAMIC_BACKLIGHT,
                DYNAMIC_CONTRAST,
                DYNAMIC_BRIGHTNESS,
                DYNAMIC_SATURATION,
                DYNAMIC_SHARPNESS,
                DYNAMIC_HUE,
                DYNAMIC_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                DYNAMIC_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_MIDDLE,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            #endif
        },
        #if (ENABLE_CUS_NR_MODE_FOLLOW_PICMODE == DISABLE)
        {
            MS_NR_MIDDLE,//MS_NR_AUTO,
            MS_MPEG_NR_LOW,
        },
        #endif
        MS_BLACK_LEVEL_HIGH,
        EN_AspectRatio_16X9
    },
#endif
#if (INPUT_AV_VIDEO_COUNT >= 2)
    {// VIDEO2
        0,//CS
        PICTURE_DYNAMIC, // Picture mode
        {
            {//Dynamic
                DYNAMIC_BACKLIGHT,
                DYNAMIC_CONTRAST,
                DYNAMIC_BRIGHTNESS,
                DYNAMIC_SATURATION,
                DYNAMIC_SHARPNESS,
                DYNAMIC_HUE,
                DYNAMIC_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                DYNAMIC_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_MIDDLE,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            {//Standard
                STANDARD_BACKLIGHT,
                STANDARD_CONTRAST,
                STANDARD_BRIGHTNESS,
                STANDARD_SATURATION,
                STANDARD_SHARPNESS,
                STANDARD_HUE,
                STANDARD_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                STANDARD_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_MIDDLE,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            {//Mild
                MILD_BACKLIGHT,
                MILD_CONTRAST,
                MILD_BRIGHTNESS,
                MILD_SATURATION,
                MILD_SHARPNESS,
                MILD_HUE,
                MILD_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                MILD_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_MIDDLE,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            #if ENABLE_PICTURE_MODE_ENERGY_SAVING
            {//Energy saving
                DYNAMIC_ENERGYSAVING_BACKLIGHT,
                DYNAMIC_ENERGYSAVING_CONTRAST,
                DYNAMIC_ENERGYSAVING_BRIGHTNESS,
                DYNAMIC_ENERGYSAVING_SATURATION,
                DYNAMIC_ENERGYSAVING_SHARPNESS,
                DYNAMIC_ENERGYSAVING_HUE,
                DYNAMIC_ENERGYSAVING_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                DYNAMIC_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_ON,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_MIDDLE,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            #endif
            {//USER
                DYNAMIC_BACKLIGHT,
                DYNAMIC_CONTRAST,
                DYNAMIC_BRIGHTNESS,
                DYNAMIC_SATURATION,
                DYNAMIC_SHARPNESS,
                DYNAMIC_HUE,
                DYNAMIC_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                DYNAMIC_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_MIDDLE,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            #if PICTURE_USER_2
            {//USER2
                DYNAMIC_BACKLIGHT,
                DYNAMIC_CONTRAST,
                DYNAMIC_BRIGHTNESS,
                DYNAMIC_SATURATION,
                DYNAMIC_SHARPNESS,
                DYNAMIC_HUE,
                DYNAMIC_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                DYNAMIC_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_MIDDLE,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            #endif
        },
        #if (ENABLE_CUS_NR_MODE_FOLLOW_PICMODE == DISABLE)
        {
            MS_NR_MIDDLE,//MS_NR_AUTO,
            MS_MPEG_NR_LOW,
        },
        #endif
        MS_BLACK_LEVEL_HIGH,
        EN_AspectRatio_16X9
    },
#endif
#if (INPUT_AV_VIDEO_COUNT >= 3)
    {// VIDEO3
        0,//CS
        PICTURE_DYNAMIC, // Picture mode
        {
            {//Dynamic
                DYNAMIC_BACKLIGHT,
                DYNAMIC_CONTRAST,
                DYNAMIC_BRIGHTNESS,
                DYNAMIC_SATURATION,
                DYNAMIC_SHARPNESS,
                DYNAMIC_HUE,
                DYNAMIC_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                DYNAMIC_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_MIDDLE,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            {//Standard
                STANDARD_BACKLIGHT,
                STANDARD_CONTRAST,
                STANDARD_BRIGHTNESS,
                STANDARD_SATURATION,
                STANDARD_SHARPNESS,
                STANDARD_HUE,
                STANDARD_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                STANDARD_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_MIDDLE,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            {//Mild
                MILD_BACKLIGHT,
                MILD_CONTRAST,
                MILD_BRIGHTNESS,
                MILD_SATURATION,
                MILD_SHARPNESS,
                MILD_HUE,
                MILD_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                MILD_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_MIDDLE,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            #if ENABLE_PICTURE_MODE_ENERGY_SAVING
            {//Energy saving
                DYNAMIC_ENERGYSAVING_BACKLIGHT,
                DYNAMIC_ENERGYSAVING_CONTRAST,
                DYNAMIC_ENERGYSAVING_BRIGHTNESS,
                DYNAMIC_ENERGYSAVING_SATURATION,
                DYNAMIC_ENERGYSAVING_SHARPNESS,
                DYNAMIC_ENERGYSAVING_HUE,
                DYNAMIC_ENERGYSAVING_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                DYNAMIC_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_ON,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_MIDDLE,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            #endif
            {//USER
                DYNAMIC_BACKLIGHT,
                DYNAMIC_CONTRAST,
                DYNAMIC_BRIGHTNESS,
                DYNAMIC_SATURATION,
                DYNAMIC_SHARPNESS,
                DYNAMIC_HUE,
                DYNAMIC_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                DYNAMIC_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_MIDDLE,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            #if PICTURE_USER_2
            {//USER2
                DYNAMIC_BACKLIGHT,
                DYNAMIC_CONTRAST,
                DYNAMIC_BRIGHTNESS,
                DYNAMIC_SATURATION,
                DYNAMIC_SHARPNESS,
                DYNAMIC_HUE,
                DYNAMIC_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                DYNAMIC_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_MIDDLE,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            #endif
        },
        #if (ENABLE_CUS_NR_MODE_FOLLOW_PICMODE == DISABLE)
        {
            MS_NR_MIDDLE,//MS_NR_AUTO,
            MS_MPEG_NR_LOW,
        },
        #endif
        MS_BLACK_LEVEL_HIGH,
        EN_AspectRatio_16X9
    },
#endif
#if (INPUT_YPBPR_VIDEO_COUNT >= 1)
    {// YPBPR
        0,//CS
        PICTURE_DYNAMIC, // Picture mode
        {
            {//Dynamic
                DYNAMIC_BACKLIGHT,
                DYNAMIC_CONTRAST,
                DYNAMIC_BRIGHTNESS,
                DYNAMIC_SATURATION,
                DYNAMIC_SHARPNESS,
                DYNAMIC_HUE,
                DYNAMIC_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                DYNAMIC_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_LOW,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            {//Standard
                STANDARD_YPBPR_BACKLIGHT,
                STANDARD_YPBPR_CONTRAST,
                STANDARD_YPBPR_BRIGHTNESS,
                STANDARD_YPBPR_SATURATION,
                STANDARD_YPBPR_SHARPNESS,
                STANDARD_YPBPR_HUE,
                STANDARD_COLOR_YPBPR_TEMP,
            #if ENABLE_FLESH_TONE
                STANDARD_YPBPR_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_LOW,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            {//Mild
                MILD_BACKLIGHT,
                MILD_CONTRAST,
                MILD_BRIGHTNESS,
                MILD_SATURATION,
                MILD_SHARPNESS,
                MILD_HUE,
                MILD_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                MILD_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_LOW,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            #if ENABLE_PICTURE_MODE_ENERGY_SAVING
            {//Energy saving
                DYNAMIC_ENERGYSAVING_BACKLIGHT,
                DYNAMIC_ENERGYSAVING_CONTRAST,
                DYNAMIC_ENERGYSAVING_BRIGHTNESS,
                DYNAMIC_ENERGYSAVING_SATURATION,
                DYNAMIC_ENERGYSAVING_SHARPNESS,
                DYNAMIC_ENERGYSAVING_HUE,
                DYNAMIC_ENERGYSAVING_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                DYNAMIC_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_ON,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_LOW,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            #endif
            {//USER
                DYNAMIC_BACKLIGHT,
                DYNAMIC_CONTRAST,
                DYNAMIC_BRIGHTNESS,
                DYNAMIC_SATURATION,
                DYNAMIC_SHARPNESS,
                DYNAMIC_HUE,
                DYNAMIC_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                DYNAMIC_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_LOW,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            #if PICTURE_USER_2
            {//USER2
                DYNAMIC_BACKLIGHT,
                DYNAMIC_CONTRAST,
                DYNAMIC_BRIGHTNESS,
                DYNAMIC_SATURATION,
                DYNAMIC_SHARPNESS,
                DYNAMIC_HUE,
                DYNAMIC_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                DYNAMIC_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_LOW,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            #endif
        },
        #if (ENABLE_CUS_NR_MODE_FOLLOW_PICMODE == DISABLE)
        {
            MS_NR_LOW,//MS_NR_AUTO,
            MS_MPEG_NR_LOW,
        },
        #endif
        MS_BLACK_LEVEL_HIGH,
        EN_AspectRatio_16X9
    },
#endif
#if (INPUT_YPBPR_VIDEO_COUNT >= 2)
    {// YPBPR
        0,//CS
        PICTURE_DYNAMIC, // Picture mode
        {
            {//Dynamic
                DYNAMIC_BACKLIGHT,
                DYNAMIC_CONTRAST,
                DYNAMIC_BRIGHTNESS,
                DYNAMIC_SATURATION,
                DYNAMIC_SHARPNESS,
                DYNAMIC_HUE,
                DYNAMIC_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                DYNAMIC_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_LOW,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode

            },
            {//Standard
                STANDARD_BACKLIGHT,
                STANDARD_CONTRAST,
                STANDARD_BRIGHTNESS,
                STANDARD_SATURATION,
                STANDARD_SHARPNESS,
                STANDARD_HUE,
                STANDARD_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                STANDARD_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_LOW,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            {//Mild
                MILD_BACKLIGHT,
                MILD_CONTRAST,
                MILD_BRIGHTNESS,
                MILD_SATURATION,
                MILD_SHARPNESS,
                MILD_HUE,
                MILD_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                MILD_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_LOW,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            #if ENABLE_PICTURE_MODE_ENERGY_SAVING
            {//Energy saving
                DYNAMIC_ENERGYSAVING_BACKLIGHT,
                DYNAMIC_ENERGYSAVING_CONTRAST,
                DYNAMIC_ENERGYSAVING_BRIGHTNESS,
                DYNAMIC_ENERGYSAVING_SATURATION,
                DYNAMIC_ENERGYSAVING_SHARPNESS,
                DYNAMIC_ENERGYSAVING_HUE,
                DYNAMIC_ENERGYSAVING_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                DYNAMIC_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_LOW,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            #endif
            {//USER
                DYNAMIC_BACKLIGHT,
                DYNAMIC_CONTRAST,
                DYNAMIC_BRIGHTNESS,
                DYNAMIC_SATURATION,
                DYNAMIC_SHARPNESS,
                DYNAMIC_HUE,
                DYNAMIC_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                DYNAMIC_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_LOW,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            #if PICTURE_USER_2
            {//USER2
                DYNAMIC_BACKLIGHT,
                DYNAMIC_CONTRAST,
                DYNAMIC_BRIGHTNESS,
                DYNAMIC_SATURATION,
                DYNAMIC_SHARPNESS,
                DYNAMIC_HUE,
                DYNAMIC_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                DYNAMIC_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_LOW,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            #endif
        },
        #if (ENABLE_CUS_NR_MODE_FOLLOW_PICMODE == DISABLE)
        {
            MS_NR_LOW,//MS_NR_AUTO,
            MS_MPEG_NR_LOW,
        },
        #endif
        MS_BLACK_LEVEL_HIGH,
        EN_AspectRatio_16X9
    },
#endif
    {// RGB
        0,//CS
        PICTURE_DYNAMIC, // Picture mode
        {
            {//Dynamic
                DYNAMIC_BACKLIGHT,
                DYNAMIC_CONTRAST,
                DYNAMIC_BRIGHTNESS,
                DYNAMIC_SATURATION,
                DYNAMIC_SHARPNESS,
                DYNAMIC_HUE,
                DYNAMIC_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                DYNAMIC_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_OFF,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            {//Standard
                STANDARD_BACKLIGHT,
                STANDARD_CONTRAST,
                STANDARD_BRIGHTNESS,
                STANDARD_SATURATION,
                STANDARD_SHARPNESS,
                STANDARD_HUE,
                STANDARD_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                STANDARD_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_OFF,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            {//Mild
                MILD_BACKLIGHT,
                MILD_CONTRAST,
                MILD_BRIGHTNESS,
                MILD_SATURATION,
                MILD_SHARPNESS,
                MILD_HUE,
                MILD_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                MILD_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_OFF,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            #if ENABLE_PICTURE_MODE_ENERGY_SAVING
            {//Energy saving
                DYNAMIC_ENERGYSAVING_BACKLIGHT,
                DYNAMIC_ENERGYSAVING_CONTRAST,
                DYNAMIC_ENERGYSAVING_BRIGHTNESS,
                DYNAMIC_ENERGYSAVING_SATURATION,
                DYNAMIC_ENERGYSAVING_SHARPNESS,
                DYNAMIC_ENERGYSAVING_HUE,
                DYNAMIC_ENERGYSAVING_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                DYNAMIC_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_ON,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_OFF,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            #endif
            {//USER
                DYNAMIC_BACKLIGHT,
                DYNAMIC_CONTRAST,
                DYNAMIC_BRIGHTNESS,
                DYNAMIC_SATURATION,
                DYNAMIC_SHARPNESS,
                DYNAMIC_HUE,
                DYNAMIC_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                DYNAMIC_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_OFF,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            #if PICTURE_USER_2
            {//USER2
                DYNAMIC_BACKLIGHT,
                DYNAMIC_CONTRAST,
                DYNAMIC_BRIGHTNESS,
                DYNAMIC_SATURATION,
                DYNAMIC_SHARPNESS,
                DYNAMIC_HUE,
                DYNAMIC_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                DYNAMIC_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_OFF,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            #endif
        },
        #if (ENABLE_CUS_NR_MODE_FOLLOW_PICMODE == DISABLE)
        {
            MS_NR_OFF,//MS_NR_AUTO,
            MS_MPEG_NR_LOW,
        },
        #endif
        MS_BLACK_LEVEL_HIGH,
        EN_AspectRatio_16X9 //EN_AspectRatio_16X9,
    },
#if (INPUT_HDMI_VIDEO_COUNT > 0)
    {// HDMI1
        0,//CS
        PICTURE_DYNAMIC, // Picture mode
        {
            {//Dynamic
                DYNAMIC_BACKLIGHT,
                DYNAMIC_CONTRAST,
                DYNAMIC_BRIGHTNESS,
                DYNAMIC_SATURATION,
                DYNAMIC_SHARPNESS,
                DYNAMIC_HUE,
                DYNAMIC_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                DYNAMIC_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_LOW,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            {//Standard
             STANDARD_HDMI_BACKLIGHT,
                STANDARD_HDMI_CONTRAST,
                STANDARD_HDMI_BRIGHTNESS,
                STANDARD_HDMI_SATURATION,
                STANDARD_HDMI_SHARPNESS,
                STANDARD_HDMI_HUE,
                STANDARD_COLOR_HDMI_TEMP,
            #if ENABLE_FLESH_TONE
                STANDARD_HDMI_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_LOW,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            {//Mild
                MILD_BACKLIGHT,
                MILD_CONTRAST,
                MILD_BRIGHTNESS,
                MILD_SATURATION,
                MILD_SHARPNESS,
                MILD_HUE,
                MILD_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                MILD_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_LOW,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            #if ENABLE_PICTURE_MODE_ENERGY_SAVING
            {//Energy saving
                DYNAMIC_ENERGYSAVING_BACKLIGHT,
                DYNAMIC_ENERGYSAVING_CONTRAST,
                DYNAMIC_ENERGYSAVING_BRIGHTNESS,
                DYNAMIC_ENERGYSAVING_SATURATION,
                DYNAMIC_ENERGYSAVING_SHARPNESS,
                DYNAMIC_ENERGYSAVING_HUE,
                DYNAMIC_ENERGYSAVING_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                DYNAMIC_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_LOW,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            #endif
            {//USER
                DYNAMIC_BACKLIGHT,
                DYNAMIC_CONTRAST,
                DYNAMIC_BRIGHTNESS,
                DYNAMIC_SATURATION,
                DYNAMIC_SHARPNESS,
                DYNAMIC_HUE,
                DYNAMIC_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                DYNAMIC_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_LOW,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            #if PICTURE_USER_2
            {//USER2
                DYNAMIC_BACKLIGHT,
                DYNAMIC_CONTRAST,
                DYNAMIC_BRIGHTNESS,
                DYNAMIC_SATURATION,
                DYNAMIC_SHARPNESS,
                DYNAMIC_HUE,
                DYNAMIC_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                DYNAMIC_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_LOW,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            #endif
        },
        #if (ENABLE_CUS_NR_MODE_FOLLOW_PICMODE == DISABLE)
        {
            MS_NR_LOW,//MS_NR_AUTO,
            MS_MPEG_NR_LOW,
        },
        #endif
        MS_BLACK_LEVEL_HIGH,
        EN_AspectRatio_16X9
    },
#endif
#if (INPUT_HDMI_VIDEO_COUNT >= 2)
    {// HDMI2
        0,//CS
        PICTURE_DYNAMIC, // Picture mode
        {
            {//Dynamic
                DYNAMIC_BACKLIGHT,
                DYNAMIC_CONTRAST,
                DYNAMIC_BRIGHTNESS,
                DYNAMIC_SATURATION,
                DYNAMIC_SHARPNESS,
                DYNAMIC_HUE,
                DYNAMIC_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                DYNAMIC_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_LOW,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            {//Standard
                STANDARD_BACKLIGHT,
                STANDARD_CONTRAST,
                STANDARD_BRIGHTNESS,
                STANDARD_SATURATION,
                STANDARD_SHARPNESS,
                STANDARD_HUE,
                STANDARD_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                STANDARD_HDMI_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_LOW,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            {//Mild
                MILD_BACKLIGHT,
                MILD_CONTRAST,
                MILD_BRIGHTNESS,
                MILD_SATURATION,
                MILD_SHARPNESS,
                MILD_HUE,
                MILD_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                MILD_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_LOW,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            #if ENABLE_PICTURE_MODE_ENERGY_SAVING
            {//Energy saving
                DYNAMIC_ENERGYSAVING_BACKLIGHT,
                DYNAMIC_ENERGYSAVING_CONTRAST,
                DYNAMIC_ENERGYSAVING_BRIGHTNESS,
                DYNAMIC_ENERGYSAVING_SATURATION,
                DYNAMIC_ENERGYSAVING_SHARPNESS,
                DYNAMIC_ENERGYSAVING_HUE,
                DYNAMIC_ENERGYSAVING_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                DYNAMIC_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_LOW,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            #endif
            {//USER
                DYNAMIC_BACKLIGHT,
                DYNAMIC_CONTRAST,
                DYNAMIC_BRIGHTNESS,
                DYNAMIC_SATURATION,
                DYNAMIC_SHARPNESS,
                DYNAMIC_HUE,
                DYNAMIC_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                DYNAMIC_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_LOW,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            #if PICTURE_USER_2
            {//USER2
                DYNAMIC_BACKLIGHT,
                DYNAMIC_CONTRAST,
                DYNAMIC_BRIGHTNESS,
                DYNAMIC_SATURATION,
                DYNAMIC_SHARPNESS,
                DYNAMIC_HUE,
                DYNAMIC_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                DYNAMIC_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_LOW,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            #endif
        },
        #if (ENABLE_CUS_NR_MODE_FOLLOW_PICMODE == DISABLE)
        {
            MS_NR_LOW,//MS_NR_AUTO,
            MS_MPEG_NR_LOW,
        },
        #endif
        MS_BLACK_LEVEL_HIGH,
        EN_AspectRatio_16X9
    },
#endif
#if (INPUT_HDMI_VIDEO_COUNT >= 3)
    {// HDMI3
        0,//CS
        PICTURE_DYNAMIC, // Picture mode
        {
            {//Dynamic
                DYNAMIC_BACKLIGHT,
                DYNAMIC_CONTRAST,
                DYNAMIC_BRIGHTNESS,
                DYNAMIC_SATURATION,
                DYNAMIC_SHARPNESS,
                DYNAMIC_HUE,
                DYNAMIC_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                DYNAMIC_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_LOW,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            {//Standard
                STANDARD_BACKLIGHT,
                STANDARD_CONTRAST,
                STANDARD_BRIGHTNESS,
                STANDARD_SATURATION,
                STANDARD_SHARPNESS,
                STANDARD_HUE,
                STANDARD_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                STANDARD_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_LOW,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            {//Mild
                MILD_BACKLIGHT,
                MILD_CONTRAST,
                MILD_BRIGHTNESS,
                MILD_SATURATION,
                MILD_SHARPNESS,
                MILD_HUE,
                MILD_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                MILD_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_LOW,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            #if ENABLE_PICTURE_MODE_ENERGY_SAVING
            {//Energy saving
                DYNAMIC_ENERGYSAVING_BACKLIGHT,
                DYNAMIC_ENERGYSAVING_CONTRAST,
                DYNAMIC_ENERGYSAVING_BRIGHTNESS,
                DYNAMIC_ENERGYSAVING_SATURATION,
                DYNAMIC_ENERGYSAVING_SHARPNESS,
                DYNAMIC_ENERGYSAVING_HUE,
                DYNAMIC_ENERGYSAVING_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                DYNAMIC_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_LOW,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            #endif
            {//USER
                DYNAMIC_BACKLIGHT,
                DYNAMIC_CONTRAST,
                DYNAMIC_BRIGHTNESS,
                DYNAMIC_SATURATION,
                DYNAMIC_SHARPNESS,
                DYNAMIC_HUE,
                DYNAMIC_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                DYNAMIC_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_LOW,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            #if PICTURE_USER_2
            {//USER2
                DYNAMIC_BACKLIGHT,
                DYNAMIC_CONTRAST,
                DYNAMIC_BRIGHTNESS,
                DYNAMIC_SATURATION,
                DYNAMIC_SHARPNESS,
                DYNAMIC_HUE,
                DYNAMIC_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                DYNAMIC_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_LOW,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            #endif
        },
        #if (ENABLE_CUS_NR_MODE_FOLLOW_PICMODE == DISABLE)
        {
            MS_NR_LOW,//MS_NR_AUTO,
            MS_MPEG_NR_LOW,
        },
        #endif
        MS_BLACK_LEVEL_HIGH,
        EN_AspectRatio_16X9
    },
#endif
#if (INPUT_HDMI_VIDEO_COUNT >= 4)
    {// HDMI4
        0,//CS
        PICTURE_DYNAMIC, // Picture mode
        {
            {//Dynamic
                DYNAMIC_BACKLIGHT,
                DYNAMIC_CONTRAST,
                DYNAMIC_BRIGHTNESS,
                DYNAMIC_SATURATION,
                DYNAMIC_SHARPNESS,
                DYNAMIC_HUE,
                DYNAMIC_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                DYNAMIC_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_LOW,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            {//Standard
                STANDARD_BACKLIGHT,
                STANDARD_CONTRAST,
                STANDARD_BRIGHTNESS,
                STANDARD_SATURATION,
                STANDARD_SHARPNESS,
                STANDARD_HUE,
                STANDARD_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                STANDARD_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_LOW,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            {//Mild
                MILD_BACKLIGHT,
                MILD_CONTRAST,
                MILD_BRIGHTNESS,
                MILD_SATURATION,
                MILD_SHARPNESS,
                MILD_HUE,
                MILD_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                MILD_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_LOW,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            #if ENABLE_PICTURE_MODE_ENERGY_SAVING
            {//Energy saving
                DYNAMIC_ENERGYSAVING_BACKLIGHT,
                DYNAMIC_ENERGYSAVING_CONTRAST,
                DYNAMIC_ENERGYSAVING_BRIGHTNESS,
                DYNAMIC_ENERGYSAVING_SATURATION,
                DYNAMIC_ENERGYSAVING_SHARPNESS,
                DYNAMIC_ENERGYSAVING_HUE,
                DYNAMIC_ENERGYSAVING_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                DYNAMIC_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_LOW,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            #endif
            {//USER
                DYNAMIC_BACKLIGHT,
                DYNAMIC_CONTRAST,
                DYNAMIC_BRIGHTNESS,
                DYNAMIC_SATURATION,
                DYNAMIC_SHARPNESS,
                DYNAMIC_HUE,
                DYNAMIC_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                DYNAMIC_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_LOW,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            #if PICTURE_USER_2
            {//USER2
                DYNAMIC_BACKLIGHT,
                DYNAMIC_CONTRAST,
                DYNAMIC_BRIGHTNESS,
                DYNAMIC_SATURATION,
                DYNAMIC_SHARPNESS,
                DYNAMIC_HUE,
                DYNAMIC_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                DYNAMIC_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_LOW,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            #endif
        },
        #if (ENABLE_CUS_NR_MODE_FOLLOW_PICMODE == DISABLE)
        {
            MS_NR_LOW,//MS_NR_AUTO,
            MS_MPEG_NR_LOW,
        },
        #endif
        MS_BLACK_LEVEL_HIGH,
        EN_AspectRatio_16X9
    },
#endif

#if (INPUT_SCART_VIDEO_COUNT >= 1)
    {// SCART
        0,//CS
        PICTURE_NORMAL, // Picture mode
        {
            {//Dynamic
                DYNAMIC_BACKLIGHT,
                DYNAMIC_CONTRAST,
                DYNAMIC_BRIGHTNESS,
                DYNAMIC_SATURATION,
                DYNAMIC_SHARPNESS,
                DYNAMIC_HUE,
                DYNAMIC_COLOR_TEMP,
                0, //PicUserMode
            },
            {//Standard
                STANDARD_BACKLIGHT,
                STANDARD_CONTRAST,
                STANDARD_BRIGHTNESS,
                STANDARD_SATURATION,
                STANDARD_SHARPNESS,
                STANDARD_HUE,
                STANDARD_COLOR_TEMP,
                0, //PicUserMode
            },
            {//Mild
                MILD_BACKLIGHT,
                MILD_CONTRAST,
                MILD_BRIGHTNESS,
                MILD_SATURATION,
                MILD_SHARPNESS,
                MILD_HUE,
                MILD_COLOR_TEMP,
                0, //PicUserMode
            },
            #if ENABLE_PICTURE_MODE_ENERGY_SAVING
            {//Energy saving
                DYNAMIC_ENERGYSAVING_BACKLIGHT,
                DYNAMIC_ENERGYSAVING_CONTRAST,
                DYNAMIC_ENERGYSAVING_BRIGHTNESS,
                DYNAMIC_ENERGYSAVING_SATURATION,
                DYNAMIC_ENERGYSAVING_SHARPNESS,
                DYNAMIC_ENERGYSAVING_HUE,
                DYNAMIC_ENERGYSAVING_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                DYNAMIC_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_MIDDLE,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            #endif
            {//USER
                DYNAMIC_BACKLIGHT,
                DYNAMIC_CONTRAST,
                DYNAMIC_BRIGHTNESS,
                DYNAMIC_SATURATION,
                DYNAMIC_SHARPNESS,
                DYNAMIC_HUE,
                DYNAMIC_COLOR_TEMP,
                0, //PicUserMode
            },
            #if PICTURE_USER_2
            {//USER2
                DYNAMIC_BACKLIGHT,
                DYNAMIC_CONTRAST,
                DYNAMIC_BRIGHTNESS,
                DYNAMIC_SATURATION,
                DYNAMIC_SHARPNESS,
                DYNAMIC_HUE,
                DYNAMIC_COLOR_TEMP,
                0, //PicUserMode
            },
            #endif
        },
        #if (ENABLE_CUS_NR_MODE_FOLLOW_PICMODE == DISABLE)
        {
            MS_NR_MIDDLE,//MS_NR_AUTO,
            MS_MPEG_NR_LOW,
        },
        #endif
        MS_BLACK_LEVEL_HIGH,
        EN_AspectRatio_16X9
    },
#endif
#if (INPUT_SCART_VIDEO_COUNT >= 2)
    {// SCART2
        0,//CS
        PICTURE_NORMAL, // Picture mode
        {
            {//Dynamic
                DYNAMIC_BACKLIGHT,
                DYNAMIC_CONTRAST,
                DYNAMIC_BRIGHTNESS,
                DYNAMIC_SATURATION,
                DYNAMIC_SHARPNESS,
                DYNAMIC_HUE,
                DYNAMIC_COLOR_TEMP,
                0, //PicUserMode
            },
            {//Standard
                STANDARD_BACKLIGHT,
                STANDARD_CONTRAST,
                STANDARD_BRIGHTNESS,
                STANDARD_SATURATION,
                STANDARD_SHARPNESS,
                STANDARD_HUE,
                STANDARD_COLOR_TEMP,
                0, //PicUserMode
            },
            {//Mild
                MILD_BACKLIGHT,
                MILD_CONTRAST,
                MILD_BRIGHTNESS,
                MILD_SATURATION,
                MILD_SHARPNESS,
                MILD_HUE,
                MILD_COLOR_TEMP,
                0, //PicUserMode
            },
            #if ENABLE_PICTURE_MODE_ENERGY_SAVING
            {//Energy saving
                DYNAMIC_ENERGYSAVING_BACKLIGHT,
                DYNAMIC_ENERGYSAVING_CONTRAST,
                DYNAMIC_ENERGYSAVING_BRIGHTNESS,
                DYNAMIC_ENERGYSAVING_SATURATION,
                DYNAMIC_ENERGYSAVING_SHARPNESS,
                DYNAMIC_ENERGYSAVING_HUE,
                DYNAMIC_ENERGYSAVING_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                DYNAMIC_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_MIDDLE,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            #endif
            {//USER
                DYNAMIC_BACKLIGHT,
                DYNAMIC_CONTRAST,
                DYNAMIC_BRIGHTNESS,
                DYNAMIC_SATURATION,
                DYNAMIC_SHARPNESS,
                DYNAMIC_HUE,
                DYNAMIC_COLOR_TEMP,
                0, //PicUserMode
            },
            #if PICTURE_USER_2
            {//USER2
                DYNAMIC_BACKLIGHT,
                DYNAMIC_CONTRAST,
                DYNAMIC_BRIGHTNESS,
                DYNAMIC_SATURATION,
                DYNAMIC_SHARPNESS,
                DYNAMIC_HUE,
                DYNAMIC_COLOR_TEMP,
                0, //PicUserMode
            },
            #endif
        },
        #if (ENABLE_CUS_NR_MODE_FOLLOW_PICMODE == DISABLE)
        {
            MS_NR_MIDDLE,//MS_NR_AUTO,
            MS_MPEG_NR_LOW,
        },
        #endif
        MS_BLACK_LEVEL_HIGH,
        EN_AspectRatio_16X9
    },
#endif
#if (INPUT_SV_VIDEO_COUNT >= 1)
    {// S-VIDEO
        0,//CS
        PICTURE_NORMAL,// Picture mode
        {
            {//Dynamic
                DYNAMIC_BACKLIGHT,
                DYNAMIC_CONTRAST,
                DYNAMIC_BRIGHTNESS,
                DYNAMIC_SATURATION,
                DYNAMIC_SHARPNESS,
                DYNAMIC_HUE,
                DYNAMIC_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                DYNAMIC_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_MIDDLE,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            {//Standard
          STANDARD_SV_BACKLIGHT,
             STANDARD_SV_CONTRAST,
             STANDARD_SV_BRIGHTNESS ,
             STANDARD_SV_SATURATION ,
             STANDARD_SV_SHARPNESS    ,
             STANDARD_SV_HUE   ,
             STANDARD_COLOR_SV_TEMP ,
            #if ENABLE_FLESH_TONE
             STANDARD_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_MIDDLE,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
             0, //PicUserMode
            },
            {//Mild
                MILD_BACKLIGHT,
                MILD_CONTRAST,
                MILD_BRIGHTNESS,
                MILD_SATURATION,
                MILD_SHARPNESS,
                MILD_HUE,
                MILD_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                MILD_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_MIDDLE,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            #if ENABLE_PICTURE_MODE_ENERGY_SAVING
            {//Energy saving
                DYNAMIC_ENERGYSAVING_BACKLIGHT,
                DYNAMIC_ENERGYSAVING_CONTRAST,
                DYNAMIC_ENERGYSAVING_BRIGHTNESS,
                DYNAMIC_ENERGYSAVING_SATURATION,
                DYNAMIC_ENERGYSAVING_SHARPNESS,
                DYNAMIC_ENERGYSAVING_HUE,
                DYNAMIC_ENERGYSAVING_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                DYNAMIC_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_MIDDLE,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            #endif
            {//USER
                DYNAMIC_BACKLIGHT,
                DYNAMIC_CONTRAST,
                DYNAMIC_BRIGHTNESS,
                DYNAMIC_SATURATION,
                DYNAMIC_SHARPNESS,
                DYNAMIC_HUE,
                DYNAMIC_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                DYNAMIC_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_MIDDLE,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            #if PICTURE_USER_2
            {//USER2
                DYNAMIC_BACKLIGHT,
                DYNAMIC_CONTRAST,
                DYNAMIC_BRIGHTNESS,
                DYNAMIC_SATURATION,
                DYNAMIC_SHARPNESS,
                DYNAMIC_HUE,
                DYNAMIC_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                DYNAMIC_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_MIDDLE,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            #endif
        },
        #if (ENABLE_CUS_NR_MODE_FOLLOW_PICMODE == DISABLE)
        {
            MS_NR_MIDDLE,//MS_NR_AUTO,
            MS_MPEG_NR_LOW,
        },
        #endif
        MS_BLACK_LEVEL_HIGH,
        EN_AspectRatio_16X9
    },
#endif
#if (INPUT_SV_VIDEO_COUNT >= 2)
    {// S-VIDEO2
        0,//CS
        PICTURE_NORMAL,// Picture mode
        {
            {//Dynamic
                DYNAMIC_BACKLIGHT,
                DYNAMIC_CONTRAST,
                DYNAMIC_BRIGHTNESS,
                DYNAMIC_SATURATION,
                DYNAMIC_SHARPNESS,
                DYNAMIC_HUE,
                DYNAMIC_COLOR_TEMP,
                0, //PicUserMode
            },
            {//Standard
                STANDARD_BACKLIGHT,
                STANDARD_CONTRAST,
                STANDARD_BRIGHTNESS,
                STANDARD_SATURATION,
                STANDARD_SHARPNESS,
                STANDARD_HUE,
                STANDARD_COLOR_TEMP,
                0, //PicUserMode
            },
            {//Mild
                MILD_BACKLIGHT,
                MILD_CONTRAST,
                MILD_BRIGHTNESS,
                MILD_SATURATION,
                MILD_SHARPNESS,
                MILD_HUE,
                MILD_COLOR_TEMP,
                0, //PicUserMode
            },
            #if ENABLE_PICTURE_MODE_ENERGY_SAVING
            {//Energy saving
                DYNAMIC_ENERGYSAVING_BACKLIGHT,
                DYNAMIC_ENERGYSAVING_CONTRAST,
                DYNAMIC_ENERGYSAVING_BRIGHTNESS,
                DYNAMIC_ENERGYSAVING_SATURATION,
                DYNAMIC_ENERGYSAVING_SHARPNESS,
                DYNAMIC_ENERGYSAVING_HUE,
                DYNAMIC_ENERGYSAVING_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                DYNAMIC_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_MIDDLE,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            #endif
            {//USER
                DYNAMIC_BACKLIGHT,
                DYNAMIC_CONTRAST,
                DYNAMIC_BRIGHTNESS,
                DYNAMIC_SATURATION,
                DYNAMIC_SHARPNESS,
                DYNAMIC_HUE,
                DYNAMIC_COLOR_TEMP,
                0, //PicUserMode
            },
            #if PICTURE_USER_2
            {//USER2
                DYNAMIC_BACKLIGHT,
                DYNAMIC_CONTRAST,
                DYNAMIC_BRIGHTNESS,
                DYNAMIC_SATURATION,
                DYNAMIC_SHARPNESS,
                DYNAMIC_HUE,
                DYNAMIC_COLOR_TEMP,
                0, //PicUserMode
            },
            #endif
        },
        #if (ENABLE_CUS_NR_MODE_FOLLOW_PICMODE == DISABLE)
        {
            MS_NR_MIDDLE,//MS_NR_AUTO,
            MS_MPEG_NR_LOW,
        },
        #endif
        MS_BLACK_LEVEL_HIGH,
        EN_AspectRatio_16X9
    },
#endif
#if ENABLE_DMP
    {// Storage
        0,//CS
        PICTURE_NORMAL, // default Picture mode
        {
            {//Dynamic
                DYNAMIC_BACKLIGHT,
                DYNAMIC_CONTRAST,
                DYNAMIC_BRIGHTNESS,
                DYNAMIC_SATURATION,
                DYNAMIC_SHARPNESS,
                DYNAMIC_HUE,
                DYNAMIC_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                DYNAMIC_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_LOW,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            {//Standard
                STANDARD_BACKLIGHT,
                STANDARD_CONTRAST,
                STANDARD_BRIGHTNESS,
                STANDARD_SATURATION,
                STANDARD_SHARPNESS,
                STANDARD_HUE,
                STANDARD_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                STANDARD_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_LOW,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            {//Mild
                MILD_BACKLIGHT,
                MILD_CONTRAST,
                MILD_BRIGHTNESS,
                MILD_SATURATION,
                MILD_SHARPNESS,
                MILD_HUE,
                MILD_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                MILD_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_LOW,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            #if ENABLE_PICTURE_MODE_ENERGY_SAVING
            {//Energy saving
                DYNAMIC_ENERGYSAVING_BACKLIGHT,
                DYNAMIC_ENERGYSAVING_CONTRAST,
                DYNAMIC_ENERGYSAVING_BRIGHTNESS,
                DYNAMIC_ENERGYSAVING_SATURATION,
                DYNAMIC_ENERGYSAVING_SHARPNESS,
                DYNAMIC_ENERGYSAVING_HUE,
                DYNAMIC_ENERGYSAVING_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                DYNAMIC_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_ON,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_LOW,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            #endif
            {//USER
                DYNAMIC_BACKLIGHT,
                DYNAMIC_CONTRAST,
                DYNAMIC_BRIGHTNESS,
                DYNAMIC_SATURATION,
                DYNAMIC_SHARPNESS,
                DYNAMIC_HUE,
                DYNAMIC_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                DYNAMIC_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_LOW,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            #if PICTURE_USER_2
            {//USER2
                DYNAMIC_BACKLIGHT,
                DYNAMIC_CONTRAST,
                DYNAMIC_BRIGHTNESS,
                DYNAMIC_SATURATION,
                DYNAMIC_SHARPNESS,
                DYNAMIC_HUE,
                DYNAMIC_COLOR_TEMP,
            #if ENABLE_FLESH_TONE
                DYNAMIC_FLESH_TONE,
            #endif
            #if ENABLE_CUS_DBC
                DBC_STATUS_OFF,
            #endif
            #if ENABLE_CUS_DLC
                DLC_STATUS_ON,
            #endif
            #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
                {
                    MS_NR_LOW,//MS_NR_AUTO,
                    MS_MPEG_NR_LOW,
                },
            #endif
                0, //PicUserMode
            },
            #endif
        },
        #if (ENABLE_CUS_NR_MODE_FOLLOW_PICMODE == DISABLE)
        {
            MS_NR_LOW,//MS_NR_AUTO,
            MS_MPEG_NR_LOW,
        },
        #endif

        MS_BLACK_LEVEL_HIGH,
        EN_AspectRatio_16X9

    },
#endif
};

static T_MS_WHITEBALANCE code astDefaultWhiteBalanceDataTbl[DATA_INPUT_SOURCE_NUM] =
{
#if ENABLE_DTV
    {// DTV
        0,//CS
        {
            {
                INIT_VIDEO_COLOR_BRIGHTNESS_COOL_R,
                INIT_VIDEO_COLOR_BRIGHTNESS_COOL_G,
                INIT_VIDEO_COLOR_BRIGHTNESS_COOL_B,

                INIT_VIDEO_COLOR_TEMP_COOL_R,
                INIT_VIDEO_COLOR_TEMP_COOL_G,
                INIT_VIDEO_COLOR_TEMP_COOL_B,

                0x32,
                0x32,
                0x32,
            },
            {
                INIT_VIDEO_COLOR_BRIGHTNESS_NORMAL_R,
                INIT_VIDEO_COLOR_BRIGHTNESS_NORMAL_G,
                INIT_VIDEO_COLOR_BRIGHTNESS_NORMAL_B,

                INIT_VIDEO_COLOR_TEMP_NORMAL_R,
                INIT_VIDEO_COLOR_TEMP_NORMAL_G,
                INIT_VIDEO_COLOR_TEMP_NORMAL_B,

                0x32,
                0x32,
                0x32,
            },
            {
                INIT_VIDEO_COLOR_BRIGHTNESS_WARM_R,
                INIT_VIDEO_COLOR_BRIGHTNESS_WARM_G,
                INIT_VIDEO_COLOR_BRIGHTNESS_WARM_B,

                INIT_VIDEO_COLOR_TEMP_WARM_R,
                INIT_VIDEO_COLOR_TEMP_WARM_G,
                INIT_VIDEO_COLOR_TEMP_WARM_B,

                0x32,
                0x32,
                0x32,
            },
        #if (MS_COLOR_TEMP_COUNT == 4)
            {
                INIT_VIDEO_COLOR_BRIGHTNESS_USER_R,
                INIT_VIDEO_COLOR_BRIGHTNESS_USER_G,
                INIT_VIDEO_COLOR_BRIGHTNESS_USER_B,

                INIT_VIDEO_COLOR_TEMP_USER_R,
                INIT_VIDEO_COLOR_TEMP_USER_G,
                INIT_VIDEO_COLOR_TEMP_USER_B,

                0x32,
                0x32,
                0x32,
            },
        #endif
        }
    },
#endif
    {// ATV
        0,//CS
        {
            {
                INIT_VIDEO_COLOR_BRIGHTNESS_COOL_R,
                INIT_VIDEO_COLOR_BRIGHTNESS_COOL_G,
                INIT_VIDEO_COLOR_BRIGHTNESS_COOL_B,

                INIT_VIDEO_COLOR_TEMP_COOL_R,
                INIT_VIDEO_COLOR_TEMP_COOL_G,
                INIT_VIDEO_COLOR_TEMP_COOL_B,

                0x32,
                0x32,
                0x32,
            },
            {
                INIT_VIDEO_COLOR_BRIGHTNESS_NORMAL_R,
                INIT_VIDEO_COLOR_BRIGHTNESS_NORMAL_G,
                INIT_VIDEO_COLOR_BRIGHTNESS_NORMAL_B,

                INIT_VIDEO_COLOR_TEMP_NORMAL_R,
                INIT_VIDEO_COLOR_TEMP_NORMAL_G,
                INIT_VIDEO_COLOR_TEMP_NORMAL_B,

                0x32,
                0x32,
                0x32,
            },
            {
                INIT_VIDEO_COLOR_BRIGHTNESS_WARM_R,
                INIT_VIDEO_COLOR_BRIGHTNESS_WARM_G,
                INIT_VIDEO_COLOR_BRIGHTNESS_WARM_B,

                INIT_VIDEO_COLOR_TEMP_WARM_R,
                INIT_VIDEO_COLOR_TEMP_WARM_G,
                INIT_VIDEO_COLOR_TEMP_WARM_B,

                0x32,
                0x32,
                0x32,
            },
        #if (MS_COLOR_TEMP_COUNT == 4)
            {
                INIT_VIDEO_COLOR_BRIGHTNESS_USER_R,
                INIT_VIDEO_COLOR_BRIGHTNESS_USER_G,
                INIT_VIDEO_COLOR_BRIGHTNESS_USER_B,

                INIT_VIDEO_COLOR_TEMP_USER_R,
                INIT_VIDEO_COLOR_TEMP_USER_G,
                INIT_VIDEO_COLOR_TEMP_USER_B,

                0x32,
                0x32,
                0x32,
            },
        #endif
        }
    },
#if (INPUT_AV_VIDEO_COUNT >= 1)
    {// VIDEO
        0,//CS
        {
            {
                INIT_VIDEO_COLOR_BRIGHTNESS_COOL_R,
                INIT_VIDEO_COLOR_BRIGHTNESS_COOL_G,
                INIT_VIDEO_COLOR_BRIGHTNESS_COOL_B,

                INIT_VIDEO_COLOR_TEMP_COOL_R,
                INIT_VIDEO_COLOR_TEMP_COOL_G,
                INIT_VIDEO_COLOR_TEMP_COOL_B,

                0x32,
                0x32,
                0x32,
            },
            {
                INIT_VIDEO_COLOR_BRIGHTNESS_NORMAL_R,
                INIT_VIDEO_COLOR_BRIGHTNESS_NORMAL_G,
                INIT_VIDEO_COLOR_BRIGHTNESS_NORMAL_B,

                INIT_VIDEO_COLOR_TEMP_NORMAL_R,
                INIT_VIDEO_COLOR_TEMP_NORMAL_G,
                INIT_VIDEO_COLOR_TEMP_NORMAL_B,

                0x32,
                0x32,
                0x32,
            },
            {
                INIT_VIDEO_COLOR_BRIGHTNESS_WARM_R,
                INIT_VIDEO_COLOR_BRIGHTNESS_WARM_G,
                INIT_VIDEO_COLOR_BRIGHTNESS_WARM_B,

                INIT_VIDEO_COLOR_TEMP_WARM_R,
                INIT_VIDEO_COLOR_TEMP_WARM_G,
                INIT_VIDEO_COLOR_TEMP_WARM_B,

                0x32,
                0x32,
                0x32,
            },
        #if (MS_COLOR_TEMP_COUNT == 4)
            {
                INIT_VIDEO_COLOR_BRIGHTNESS_USER_R,
                INIT_VIDEO_COLOR_BRIGHTNESS_USER_G,
                INIT_VIDEO_COLOR_BRIGHTNESS_USER_B,

                INIT_VIDEO_COLOR_TEMP_USER_R,
                INIT_VIDEO_COLOR_TEMP_USER_G,
                INIT_VIDEO_COLOR_TEMP_USER_B,

                0x32,
                0x32,
                0x32,
            },
        #endif
        }
    },
#endif
#if (INPUT_AV_VIDEO_COUNT >= 2)
    {// VIDEO2
        0,//CS
        {
            {
                INIT_VIDEO_COLOR_BRIGHTNESS_COOL_R,
                INIT_VIDEO_COLOR_BRIGHTNESS_COOL_G,
                INIT_VIDEO_COLOR_BRIGHTNESS_COOL_B,

                INIT_VIDEO_COLOR_TEMP_COOL_R,
                INIT_VIDEO_COLOR_TEMP_COOL_G,
                INIT_VIDEO_COLOR_TEMP_COOL_B,

                0x32,
                0x32,
                0x32,
            },
            {
                INIT_VIDEO_COLOR_BRIGHTNESS_NORMAL_R,
                INIT_VIDEO_COLOR_BRIGHTNESS_NORMAL_G,
                INIT_VIDEO_COLOR_BRIGHTNESS_NORMAL_B,

                INIT_VIDEO_COLOR_TEMP_NORMAL_R,
                INIT_VIDEO_COLOR_TEMP_NORMAL_G,
                INIT_VIDEO_COLOR_TEMP_NORMAL_B,

                0x32,
                0x32,
                0x32,
            },
            {
                INIT_VIDEO_COLOR_BRIGHTNESS_WARM_R,
                INIT_VIDEO_COLOR_BRIGHTNESS_WARM_G,
                INIT_VIDEO_COLOR_BRIGHTNESS_WARM_B,

                INIT_VIDEO_COLOR_TEMP_WARM_R,
                INIT_VIDEO_COLOR_TEMP_WARM_G,
                INIT_VIDEO_COLOR_TEMP_WARM_B,

                0x32,
                0x32,
                0x32,
            },
        #if (MS_COLOR_TEMP_COUNT == 4)
            {
                INIT_VIDEO_COLOR_BRIGHTNESS_USER_R,
                INIT_VIDEO_COLOR_BRIGHTNESS_USER_G,
                INIT_VIDEO_COLOR_BRIGHTNESS_USER_B,

                INIT_VIDEO_COLOR_TEMP_USER_R,
                INIT_VIDEO_COLOR_TEMP_USER_G,
                INIT_VIDEO_COLOR_TEMP_USER_B,

                0x32,
                0x32,
                0x32,
            },
        #endif
        }
    },
#endif
#if (INPUT_AV_VIDEO_COUNT >= 3)
    {// VIDEO3
        0,//CS
        {
            {
                INIT_VIDEO_COLOR_BRIGHTNESS_COOL_R,
                INIT_VIDEO_COLOR_BRIGHTNESS_COOL_G,
                INIT_VIDEO_COLOR_BRIGHTNESS_COOL_B,

                INIT_VIDEO_COLOR_TEMP_COOL_R,
                INIT_VIDEO_COLOR_TEMP_COOL_G,
                INIT_VIDEO_COLOR_TEMP_COOL_B,

                0x32,
                0x32,
                0x32,
            },
            {
                INIT_VIDEO_COLOR_BRIGHTNESS_NORMAL_R,
                INIT_VIDEO_COLOR_BRIGHTNESS_NORMAL_G,
                INIT_VIDEO_COLOR_BRIGHTNESS_NORMAL_B,

                INIT_VIDEO_COLOR_TEMP_NORMAL_R,
                INIT_VIDEO_COLOR_TEMP_NORMAL_G,
                INIT_VIDEO_COLOR_TEMP_NORMAL_B,

                0x32,
                0x32,
                0x32,
            },
            {
                INIT_VIDEO_COLOR_BRIGHTNESS_WARM_R,
                INIT_VIDEO_COLOR_BRIGHTNESS_WARM_G,
                INIT_VIDEO_COLOR_BRIGHTNESS_WARM_B,

                INIT_VIDEO_COLOR_TEMP_WARM_R,
                INIT_VIDEO_COLOR_TEMP_WARM_G,
                INIT_VIDEO_COLOR_TEMP_WARM_B,

                0x32,
                0x32,
                0x32,
            },
        #if (MS_COLOR_TEMP_COUNT == 4)
            {
                INIT_VIDEO_COLOR_BRIGHTNESS_USER_R,
                INIT_VIDEO_COLOR_BRIGHTNESS_USER_G,
                INIT_VIDEO_COLOR_BRIGHTNESS_USER_B,

                INIT_VIDEO_COLOR_TEMP_USER_R,
                INIT_VIDEO_COLOR_TEMP_USER_G,
                INIT_VIDEO_COLOR_TEMP_USER_B,

                0x32,
                0x32,
                0x32,
            },
        #endif
        }
    },
#endif
#if (INPUT_YPBPR_VIDEO_COUNT >= 1)
    {// YPBPR
        0,//CS
        {
            {
                INIT_VIDEO_COLOR_BRIGHTNESS_COOL_R,
                INIT_VIDEO_COLOR_BRIGHTNESS_COOL_G,
                INIT_VIDEO_COLOR_BRIGHTNESS_COOL_B,

                INIT_VIDEO_COLOR_TEMP_COOL_R,
                INIT_VIDEO_COLOR_TEMP_COOL_G,
                INIT_VIDEO_COLOR_TEMP_COOL_B,

                0x32,
                0x32,
                0x32,
            },
            {
                INIT_VIDEO_COLOR_BRIGHTNESS_NORMAL_R,
                INIT_VIDEO_COLOR_BRIGHTNESS_NORMAL_G,
                INIT_VIDEO_COLOR_BRIGHTNESS_NORMAL_B,

                INIT_VIDEO_COLOR_TEMP_NORMAL_R,
                INIT_VIDEO_COLOR_TEMP_NORMAL_G,
                INIT_VIDEO_COLOR_TEMP_NORMAL_B,

                0x32,
                0x32,
                0x32,
            },
            {
                INIT_VIDEO_COLOR_BRIGHTNESS_WARM_R,
                INIT_VIDEO_COLOR_BRIGHTNESS_WARM_G,
                INIT_VIDEO_COLOR_BRIGHTNESS_WARM_B,

                INIT_VIDEO_COLOR_TEMP_WARM_R,
                INIT_VIDEO_COLOR_TEMP_WARM_G,
                INIT_VIDEO_COLOR_TEMP_WARM_B,

                0x32,
                0x32,
                0x32,
            },
        #if (MS_COLOR_TEMP_COUNT == 4)
            {
                INIT_VIDEO_COLOR_BRIGHTNESS_USER_R,
                INIT_VIDEO_COLOR_BRIGHTNESS_USER_G,
                INIT_VIDEO_COLOR_BRIGHTNESS_USER_B,

                INIT_VIDEO_COLOR_TEMP_USER_R,
                INIT_VIDEO_COLOR_TEMP_USER_G,
                INIT_VIDEO_COLOR_TEMP_USER_B,

                0x32,
                0x32,
                0x32,
            },
        #endif
        }
    },
#endif
#if (INPUT_YPBPR_VIDEO_COUNT >= 2)
    {// YPBPR2
        0,//CS
        {
            {
                INIT_VIDEO_COLOR_BRIGHTNESS_COOL_R,
                INIT_VIDEO_COLOR_BRIGHTNESS_COOL_G,
                INIT_VIDEO_COLOR_BRIGHTNESS_COOL_B,

                INIT_VIDEO_COLOR_TEMP_COOL_R,
                INIT_VIDEO_COLOR_TEMP_COOL_G,
                INIT_VIDEO_COLOR_TEMP_COOL_B,

                0x32,
                0x32,
                0x32,
            },
            {
                INIT_VIDEO_COLOR_BRIGHTNESS_NORMAL_R,
                INIT_VIDEO_COLOR_BRIGHTNESS_NORMAL_G,
                INIT_VIDEO_COLOR_BRIGHTNESS_NORMAL_B,

                INIT_VIDEO_COLOR_TEMP_NORMAL_R,
                INIT_VIDEO_COLOR_TEMP_NORMAL_G,
                INIT_VIDEO_COLOR_TEMP_NORMAL_B,

                0x32,
                0x32,
                0x32,
            },
            {
                INIT_VIDEO_COLOR_BRIGHTNESS_WARM_R,
                INIT_VIDEO_COLOR_BRIGHTNESS_WARM_G,
                INIT_VIDEO_COLOR_BRIGHTNESS_WARM_B,

                INIT_VIDEO_COLOR_TEMP_WARM_R,
                INIT_VIDEO_COLOR_TEMP_WARM_G,
                INIT_VIDEO_COLOR_TEMP_WARM_B,

                0x32,
                0x32,
                0x32,
            },
        #if (MS_COLOR_TEMP_COUNT == 4)
            {
                INIT_VIDEO_COLOR_BRIGHTNESS_USER_R,
                INIT_VIDEO_COLOR_BRIGHTNESS_USER_G,
                INIT_VIDEO_COLOR_BRIGHTNESS_USER_B,

                INIT_VIDEO_COLOR_TEMP_USER_R,
                INIT_VIDEO_COLOR_TEMP_USER_G,
                INIT_VIDEO_COLOR_TEMP_USER_B,

                0x32,
                0x32,
                0x32,
            },
        #endif
        }
    },
#endif

    {// RGB
        0,//CS
        {
            {
                INIT_VIDEO_COLOR_BRIGHTNESS_COOL_R,
                INIT_VIDEO_COLOR_BRIGHTNESS_COOL_G,
                INIT_VIDEO_COLOR_BRIGHTNESS_COOL_B,

                INIT_VIDEO_COLOR_TEMP_COOL_R,
                INIT_VIDEO_COLOR_TEMP_COOL_G,
                INIT_VIDEO_COLOR_TEMP_COOL_B,

                0x32,
                0x32,
                0x32,
            },
            {
                INIT_VIDEO_COLOR_BRIGHTNESS_NORMAL_R,
                INIT_VIDEO_COLOR_BRIGHTNESS_NORMAL_G,
                INIT_VIDEO_COLOR_BRIGHTNESS_NORMAL_B,

                INIT_VIDEO_COLOR_TEMP_NORMAL_R,
                INIT_VIDEO_COLOR_TEMP_NORMAL_G,
                INIT_VIDEO_COLOR_TEMP_NORMAL_B,

                0x32,
                0x32,
                0x32,
            },
            {
                INIT_VIDEO_COLOR_BRIGHTNESS_WARM_R,
                INIT_VIDEO_COLOR_BRIGHTNESS_WARM_G,
                INIT_VIDEO_COLOR_BRIGHTNESS_WARM_B,

                INIT_VIDEO_COLOR_TEMP_WARM_R,
                INIT_VIDEO_COLOR_TEMP_WARM_G,
                INIT_VIDEO_COLOR_TEMP_WARM_B,

                0x32,
                0x32,
                0x32,
            },
        #if (MS_COLOR_TEMP_COUNT == 4)
            {
                INIT_VIDEO_COLOR_BRIGHTNESS_USER_R,
                INIT_VIDEO_COLOR_BRIGHTNESS_USER_G,
                INIT_VIDEO_COLOR_BRIGHTNESS_USER_B,

                INIT_VIDEO_COLOR_TEMP_USER_R,
                INIT_VIDEO_COLOR_TEMP_USER_G,
                INIT_VIDEO_COLOR_TEMP_USER_B,

                0x32,
                0x32,
                0x32,
            },
        #endif
        }
    },

#if (INPUT_HDMI_VIDEO_COUNT > 0)
    {// HDMI1
        0,//CS
        {
            {
                INIT_VIDEO_COLOR_BRIGHTNESS_COOL_R,
                INIT_VIDEO_COLOR_BRIGHTNESS_COOL_G,
                INIT_VIDEO_COLOR_BRIGHTNESS_COOL_B,

                INIT_VIDEO_COLOR_TEMP_COOL_R,
                INIT_VIDEO_COLOR_TEMP_COOL_G,
                INIT_VIDEO_COLOR_TEMP_COOL_B,

                0x32,
                0x32,
                0x32,
            },
            {
                INIT_VIDEO_COLOR_BRIGHTNESS_NORMAL_R,
                INIT_VIDEO_COLOR_BRIGHTNESS_NORMAL_G,
                INIT_VIDEO_COLOR_BRIGHTNESS_NORMAL_B,

                INIT_VIDEO_COLOR_TEMP_NORMAL_R,
                INIT_VIDEO_COLOR_TEMP_NORMAL_G,
                INIT_VIDEO_COLOR_TEMP_NORMAL_B,

                0x32,
                0x32,
                0x32,
            },
            {
                INIT_VIDEO_COLOR_BRIGHTNESS_WARM_R,
                INIT_VIDEO_COLOR_BRIGHTNESS_WARM_G,
                INIT_VIDEO_COLOR_BRIGHTNESS_WARM_B,

                INIT_VIDEO_COLOR_TEMP_WARM_R,
                INIT_VIDEO_COLOR_TEMP_WARM_G,
                INIT_VIDEO_COLOR_TEMP_WARM_B,

                0x32,
                0x32,
                0x32,
            },
        #if (MS_COLOR_TEMP_COUNT == 4)
            {
                INIT_VIDEO_COLOR_BRIGHTNESS_USER_R,
                INIT_VIDEO_COLOR_BRIGHTNESS_USER_G,
                INIT_VIDEO_COLOR_BRIGHTNESS_USER_B,

                INIT_VIDEO_COLOR_TEMP_USER_R,
                INIT_VIDEO_COLOR_TEMP_USER_G,
                INIT_VIDEO_COLOR_TEMP_USER_B,

                0x32,
                0x32,
                0x32,
            },
        #endif
        }
    },
#endif
#if (INPUT_HDMI_VIDEO_COUNT >= 2)
    {// HDMI2
        0,//CS
        {
            {
                INIT_VIDEO_COLOR_BRIGHTNESS_COOL_R,
                INIT_VIDEO_COLOR_BRIGHTNESS_COOL_G,
                INIT_VIDEO_COLOR_BRIGHTNESS_COOL_B,

                INIT_VIDEO_COLOR_TEMP_COOL_R,
                INIT_VIDEO_COLOR_TEMP_COOL_G,
                INIT_VIDEO_COLOR_TEMP_COOL_B,

                0x32,
                0x32,
                0x32,
            },
            {
                INIT_VIDEO_COLOR_BRIGHTNESS_NORMAL_R,
                INIT_VIDEO_COLOR_BRIGHTNESS_NORMAL_G,
                INIT_VIDEO_COLOR_BRIGHTNESS_NORMAL_B,

                INIT_VIDEO_COLOR_TEMP_NORMAL_R,
                INIT_VIDEO_COLOR_TEMP_NORMAL_G,
                INIT_VIDEO_COLOR_TEMP_NORMAL_B,

                0x32,
                0x32,
                0x32,
            },
            {
                INIT_VIDEO_COLOR_BRIGHTNESS_WARM_R,
                INIT_VIDEO_COLOR_BRIGHTNESS_WARM_G,
                INIT_VIDEO_COLOR_BRIGHTNESS_WARM_B,

                INIT_VIDEO_COLOR_TEMP_WARM_R,
                INIT_VIDEO_COLOR_TEMP_WARM_G,
                INIT_VIDEO_COLOR_TEMP_WARM_B,

                0x32,
                0x32,
                0x32,
            },
        #if (MS_COLOR_TEMP_COUNT == 4)
            {
                INIT_VIDEO_COLOR_BRIGHTNESS_USER_R,
                INIT_VIDEO_COLOR_BRIGHTNESS_USER_G,
                INIT_VIDEO_COLOR_BRIGHTNESS_USER_B,

                INIT_VIDEO_COLOR_TEMP_USER_R,
                INIT_VIDEO_COLOR_TEMP_USER_G,
                INIT_VIDEO_COLOR_TEMP_USER_B,

                0x32,
                0x32,
                0x32,
            },
        #endif
        }
    },
#endif
#if (INPUT_HDMI_VIDEO_COUNT >= 3)
    {// HDMI3
        0,//CS
        {
            {
                INIT_VIDEO_COLOR_BRIGHTNESS_COOL_R,
                INIT_VIDEO_COLOR_BRIGHTNESS_COOL_G,
                INIT_VIDEO_COLOR_BRIGHTNESS_COOL_B,

                INIT_VIDEO_COLOR_TEMP_COOL_R,
                INIT_VIDEO_COLOR_TEMP_COOL_G,
                INIT_VIDEO_COLOR_TEMP_COOL_B,

                0x32,
                0x32,
                0x32,
            },
            {
                INIT_VIDEO_COLOR_BRIGHTNESS_NORMAL_R,
                INIT_VIDEO_COLOR_BRIGHTNESS_NORMAL_G,
                INIT_VIDEO_COLOR_BRIGHTNESS_NORMAL_B,

                INIT_VIDEO_COLOR_TEMP_NORMAL_R,
                INIT_VIDEO_COLOR_TEMP_NORMAL_G,
                INIT_VIDEO_COLOR_TEMP_NORMAL_B,

                0x32,
                0x32,
                0x32,
            },
            {
                INIT_VIDEO_COLOR_BRIGHTNESS_WARM_R,
                INIT_VIDEO_COLOR_BRIGHTNESS_WARM_G,
                INIT_VIDEO_COLOR_BRIGHTNESS_WARM_B,

                INIT_VIDEO_COLOR_TEMP_WARM_R,
                INIT_VIDEO_COLOR_TEMP_WARM_G,
                INIT_VIDEO_COLOR_TEMP_WARM_B,

                0x32,
                0x32,
                0x32,
            },
        #if (MS_COLOR_TEMP_COUNT == 4)
            {
                INIT_VIDEO_COLOR_BRIGHTNESS_USER_R,
                INIT_VIDEO_COLOR_BRIGHTNESS_USER_G,
                INIT_VIDEO_COLOR_BRIGHTNESS_USER_B,

                INIT_VIDEO_COLOR_TEMP_USER_R,
                INIT_VIDEO_COLOR_TEMP_USER_G,
                INIT_VIDEO_COLOR_TEMP_USER_B,

                0x32,
                0x32,
                0x32,
            },
        #endif
        }
    },
#endif
#if (INPUT_HDMI_VIDEO_COUNT >= 4)
    {// HDMI4
        0,//CS
        {
            {
                INIT_VIDEO_COLOR_BRIGHTNESS_COOL_R,
                INIT_VIDEO_COLOR_BRIGHTNESS_COOL_G,
                INIT_VIDEO_COLOR_BRIGHTNESS_COOL_B,

                INIT_VIDEO_COLOR_TEMP_COOL_R,
                INIT_VIDEO_COLOR_TEMP_COOL_G,
                INIT_VIDEO_COLOR_TEMP_COOL_B,

                0x32,
                0x32,
                0x32,
            },
            {
                INIT_VIDEO_COLOR_BRIGHTNESS_NORMAL_R,
                INIT_VIDEO_COLOR_BRIGHTNESS_NORMAL_G,
                INIT_VIDEO_COLOR_BRIGHTNESS_NORMAL_B,

                INIT_VIDEO_COLOR_TEMP_NORMAL_R,
                INIT_VIDEO_COLOR_TEMP_NORMAL_G,
                INIT_VIDEO_COLOR_TEMP_NORMAL_B,

                0x32,
                0x32,
                0x32,
            },
            {
                INIT_VIDEO_COLOR_BRIGHTNESS_WARM_R,
                INIT_VIDEO_COLOR_BRIGHTNESS_WARM_G,
                INIT_VIDEO_COLOR_BRIGHTNESS_WARM_B,

                INIT_VIDEO_COLOR_TEMP_WARM_R,
                INIT_VIDEO_COLOR_TEMP_WARM_G,
                INIT_VIDEO_COLOR_TEMP_WARM_B,

                0x32,
                0x32,
                0x32,
            },
        #if (MS_COLOR_TEMP_COUNT == 4)
            {
                INIT_VIDEO_COLOR_BRIGHTNESS_USER_R,
                INIT_VIDEO_COLOR_BRIGHTNESS_USER_G,
                INIT_VIDEO_COLOR_BRIGHTNESS_USER_B,

                INIT_VIDEO_COLOR_TEMP_USER_R,
                INIT_VIDEO_COLOR_TEMP_USER_G,
                INIT_VIDEO_COLOR_TEMP_USER_B,

                0x32,
                0x32,
                0x32,
            },
        #endif
        }
    },
#endif
#if (INPUT_SCART_VIDEO_COUNT >= 1)
    {// SCART0
        0,//CS
        {
            {
                INIT_VIDEO_COLOR_BRIGHTNESS_COOL_R,
                INIT_VIDEO_COLOR_BRIGHTNESS_COOL_G,
                INIT_VIDEO_COLOR_BRIGHTNESS_COOL_B,

                INIT_VIDEO_COLOR_TEMP_COOL_R,
                INIT_VIDEO_COLOR_TEMP_COOL_G,
                INIT_VIDEO_COLOR_TEMP_COOL_B,

                0x32,
                0x32,
                0x32,
            },
            {
                INIT_VIDEO_COLOR_BRIGHTNESS_NORMAL_R,
                INIT_VIDEO_COLOR_BRIGHTNESS_NORMAL_G,
                INIT_VIDEO_COLOR_BRIGHTNESS_NORMAL_B,

                INIT_VIDEO_COLOR_TEMP_NORMAL_R,
                INIT_VIDEO_COLOR_TEMP_NORMAL_G,
                INIT_VIDEO_COLOR_TEMP_NORMAL_B,

                0x32,
                0x32,
                0x32,
            },
            {
                INIT_VIDEO_COLOR_BRIGHTNESS_WARM_R,
                INIT_VIDEO_COLOR_BRIGHTNESS_WARM_G,
                INIT_VIDEO_COLOR_BRIGHTNESS_WARM_B,

                INIT_VIDEO_COLOR_TEMP_WARM_R,
                INIT_VIDEO_COLOR_TEMP_WARM_G,
                INIT_VIDEO_COLOR_TEMP_WARM_B,

                0x32,
                0x32,
                0x32,
            },
        #if (MS_COLOR_TEMP_COUNT == 4)
            {
                INIT_VIDEO_COLOR_BRIGHTNESS_USER_R,
                INIT_VIDEO_COLOR_BRIGHTNESS_USER_G,
                INIT_VIDEO_COLOR_BRIGHTNESS_USER_B,

                INIT_VIDEO_COLOR_TEMP_USER_R,
                INIT_VIDEO_COLOR_TEMP_USER_G,
                INIT_VIDEO_COLOR_TEMP_USER_B,

                0x32,
                0x32,
                0x32,
            },
        #endif
        }
    },
#endif
#if (INPUT_SCART_VIDEO_COUNT >= 2)
    {// SCART2
        0,//CS
        {
            {
                INIT_VIDEO_COLOR_BRIGHTNESS_COOL_R,
                INIT_VIDEO_COLOR_BRIGHTNESS_COOL_G,
                INIT_VIDEO_COLOR_BRIGHTNESS_COOL_B,

                INIT_VIDEO_COLOR_TEMP_COOL_R,
                INIT_VIDEO_COLOR_TEMP_COOL_G,
                INIT_VIDEO_COLOR_TEMP_COOL_B,

                0x32,
                0x32,
                0x32,
            },
            {
                INIT_VIDEO_COLOR_BRIGHTNESS_NORMAL_R,
                INIT_VIDEO_COLOR_BRIGHTNESS_NORMAL_G,
                INIT_VIDEO_COLOR_BRIGHTNESS_NORMAL_B,

                INIT_VIDEO_COLOR_TEMP_NORMAL_R,
                INIT_VIDEO_COLOR_TEMP_NORMAL_G,
                INIT_VIDEO_COLOR_TEMP_NORMAL_B,

                0x32,
                0x32,
                0x32,
            },
            {
                INIT_VIDEO_COLOR_BRIGHTNESS_WARM_R,
                INIT_VIDEO_COLOR_BRIGHTNESS_WARM_G,
                INIT_VIDEO_COLOR_BRIGHTNESS_WARM_B,

                INIT_VIDEO_COLOR_TEMP_WARM_R,
                INIT_VIDEO_COLOR_TEMP_WARM_G,
                INIT_VIDEO_COLOR_TEMP_WARM_B,

                0x32,
                0x32,
                0x32,
            },
        #if (MS_COLOR_TEMP_COUNT == 4)
            {
                INIT_VIDEO_COLOR_BRIGHTNESS_USER_R,
                INIT_VIDEO_COLOR_BRIGHTNESS_USER_G,
                INIT_VIDEO_COLOR_BRIGHTNESS_USER_B,

                INIT_VIDEO_COLOR_TEMP_USER_R,
                INIT_VIDEO_COLOR_TEMP_USER_G,
                INIT_VIDEO_COLOR_TEMP_USER_B,

                0x32,
                0x32,
                0x32,
            },
        #endif
        }
    },
#endif
#if (INPUT_SV_VIDEO_COUNT >= 1)
    {// S-VIDEO
        0,//CS
        {
            {
                INIT_VIDEO_COLOR_BRIGHTNESS_COOL_R,
                INIT_VIDEO_COLOR_BRIGHTNESS_COOL_G,
                INIT_VIDEO_COLOR_BRIGHTNESS_COOL_B,

                INIT_VIDEO_COLOR_TEMP_COOL_R,
                INIT_VIDEO_COLOR_TEMP_COOL_G,
                INIT_VIDEO_COLOR_TEMP_COOL_B,

                0x32,
                0x32,
                0x32,
            },
            {
                INIT_VIDEO_COLOR_BRIGHTNESS_NORMAL_R,
                INIT_VIDEO_COLOR_BRIGHTNESS_NORMAL_G,
                INIT_VIDEO_COLOR_BRIGHTNESS_NORMAL_B,

                INIT_VIDEO_COLOR_TEMP_NORMAL_R,
                INIT_VIDEO_COLOR_TEMP_NORMAL_G,
                INIT_VIDEO_COLOR_TEMP_NORMAL_B,

                0x32,
                0x32,
                0x32,
            },
            {
                INIT_VIDEO_COLOR_BRIGHTNESS_WARM_R,
                INIT_VIDEO_COLOR_BRIGHTNESS_WARM_G,
                INIT_VIDEO_COLOR_BRIGHTNESS_WARM_B,

                INIT_VIDEO_COLOR_TEMP_WARM_R,
                INIT_VIDEO_COLOR_TEMP_WARM_G,
                INIT_VIDEO_COLOR_TEMP_WARM_B,

                0x32,
                0x32,
                0x32,
            },
        #if (MS_COLOR_TEMP_COUNT == 4)
            {
                INIT_VIDEO_COLOR_BRIGHTNESS_USER_R,
                INIT_VIDEO_COLOR_BRIGHTNESS_USER_G,
                INIT_VIDEO_COLOR_BRIGHTNESS_USER_B,

                INIT_VIDEO_COLOR_TEMP_USER_R,
                INIT_VIDEO_COLOR_TEMP_USER_G,
                INIT_VIDEO_COLOR_TEMP_USER_B,

                0x32,
                0x32,
                0x32,
            },
        #endif
        }
    },
#endif
#if (INPUT_SV_VIDEO_COUNT >= 2)
    {// S-VIDEO2
        0,//CS
        {
            {
                INIT_VIDEO_COLOR_BRIGHTNESS_COOL_R,
                INIT_VIDEO_COLOR_BRIGHTNESS_COOL_G,
                INIT_VIDEO_COLOR_BRIGHTNESS_COOL_B,

                INIT_VIDEO_COLOR_TEMP_COOL_R,
                INIT_VIDEO_COLOR_TEMP_COOL_G,
                INIT_VIDEO_COLOR_TEMP_COOL_B,

                0x32,
                0x32,
                0x32,
            },
            {
                INIT_VIDEO_COLOR_BRIGHTNESS_NORMAL_R,
                INIT_VIDEO_COLOR_BRIGHTNESS_NORMAL_G,
                INIT_VIDEO_COLOR_BRIGHTNESS_NORMAL_B,

                INIT_VIDEO_COLOR_TEMP_NORMAL_R,
                INIT_VIDEO_COLOR_TEMP_NORMAL_G,
                INIT_VIDEO_COLOR_TEMP_NORMAL_B,

                0x32,
                0x32,
                0x32,
            },
            {
                INIT_VIDEO_COLOR_BRIGHTNESS_WARM_R,
                INIT_VIDEO_COLOR_BRIGHTNESS_WARM_G,
                INIT_VIDEO_COLOR_BRIGHTNESS_WARM_B,

                INIT_VIDEO_COLOR_TEMP_WARM_R,
                INIT_VIDEO_COLOR_TEMP_WARM_G,
                INIT_VIDEO_COLOR_TEMP_WARM_B,

                0x32,
                0x32,
                0x32,
            },
        #if (MS_COLOR_TEMP_COUNT == 4)
            {
                INIT_VIDEO_COLOR_BRIGHTNESS_USER_R,
                INIT_VIDEO_COLOR_BRIGHTNESS_USER_G,
                INIT_VIDEO_COLOR_BRIGHTNESS_USER_B,

                INIT_VIDEO_COLOR_TEMP_USER_R,
                INIT_VIDEO_COLOR_TEMP_USER_G,
                INIT_VIDEO_COLOR_TEMP_USER_B,

                0x32,
                0x32,
                0x32,
            },
        #endif
        }
    },
#endif
#if ENABLE_DMP
    {// Storage
        0,//CS
        {
            {
                INIT_VIDEO_COLOR_BRIGHTNESS_COOL_R,
                INIT_VIDEO_COLOR_BRIGHTNESS_COOL_G,
                INIT_VIDEO_COLOR_BRIGHTNESS_COOL_B,

                INIT_VIDEO_COLOR_TEMP_COOL_R,
                INIT_VIDEO_COLOR_TEMP_COOL_G,
                INIT_VIDEO_COLOR_TEMP_COOL_B,

                0x32,
                0x32,
                0x32,
            },
            {
                INIT_VIDEO_COLOR_BRIGHTNESS_NORMAL_R,
                INIT_VIDEO_COLOR_BRIGHTNESS_NORMAL_G,
                INIT_VIDEO_COLOR_BRIGHTNESS_NORMAL_B,

                INIT_VIDEO_COLOR_TEMP_NORMAL_R,
                INIT_VIDEO_COLOR_TEMP_NORMAL_G,
                INIT_VIDEO_COLOR_TEMP_NORMAL_B,

                0x32,
                0x32,
                0x32,
            },
            {
                INIT_VIDEO_COLOR_BRIGHTNESS_WARM_R,
                INIT_VIDEO_COLOR_BRIGHTNESS_WARM_G,
                INIT_VIDEO_COLOR_BRIGHTNESS_WARM_B,

                INIT_VIDEO_COLOR_TEMP_WARM_R,
                INIT_VIDEO_COLOR_TEMP_WARM_G,
                INIT_VIDEO_COLOR_TEMP_WARM_B,

                0x32,
                0x32,
                0x32,
            },
        #if (MS_COLOR_TEMP_COUNT == 4)
            {
                INIT_VIDEO_COLOR_BRIGHTNESS_USER_R,
                INIT_VIDEO_COLOR_BRIGHTNESS_USER_G,
                INIT_VIDEO_COLOR_BRIGHTNESS_USER_B,

                INIT_VIDEO_COLOR_TEMP_USER_R,
                INIT_VIDEO_COLOR_TEMP_USER_G,
                INIT_VIDEO_COLOR_TEMP_USER_B,

                0x32,
                0x32,
                0x32,
            },
        #endif
        }
    },
#endif
};

#if (ENABLE_NONLINEAR_CURVE)
static code MS_NONLINEAR_CURVE_SETTING tNonLinearCurveSetting =
{
    0,       // check sum

#if(ENABLE_PICTURE_NONLINEAR_CURVE)
//NONLINEAR_CURVE_CONTRAST,
//NONLINEAR_CURVE_BRIGHTNESS,
//NONLINEAR_CURVE_SATURATION,
//NONLINEAR_CURVE_SHARPNESS,
//NONLINEAR_CURVE_HUE,
#if ENABLE_DTV
    // DTV
    {
        {80, 111, 128, 143, 196},   // Contrast
        {80, 103, 128, 152, 178},   // Brightness
        {0,  68,  148, 180, 200},   // Color
        {0,  12,  25,  30,  63},   // Sharpness
        {30, 40, 50, 60, 70},   // Tint
    },
#endif
    // TV
    {
        {80, 109, 128, 143, 199},   // Contrast
        {80, 104, 128, 153, 178},   // Brightness
        {0,  68,  138, 168, 192},   // Color
        {0,  12,  20,  28,  63},   // Sharpness
        {30, 40, 50, 60, 70},   // Tint
    },
    // AV
    {
        {80, 109, 128, 143, 199},   // Contrast
        {80, 104, 128, 153, 178},   // Brightness
        {0,  68,  138, 168, 192},   // Color
        {0,  16,  25,  32,  63},   // Sharpness
        {30, 40, 50, 60, 70},   // Tint
    },
    // SV
    {
        {80, 109, 128, 143, 199},   // Contrast
        {80, 104, 128, 153, 178},   // Brightness
        {0,  68,  138, 168, 192},   // Color
        {0,  16,  25,  32,  63},   // Sharpness
        {30, 40, 50, 60, 70},   // Tint
    },
    // YPbPr
    {
        {80, 109, 128, 143, 199},   // Contrast
        {80, 104, 128, 153, 178},   // Brightness
        {0,  68,  138, 168, 192},   // Color
        {0,  16,  30,  40,  63},   // Sharpness
        {30, 40, 50, 60, 70},   // Tint
    },
    // HDMI
    {
        {80, 106, 128, 143, 190},   // Contrast
        {80, 104, 128, 149, 170},   // Brightness
        {0,  80,  128, 158, 190},   // Color
        {0,  10,  32,  42,  63},   // Sharpness
        {30, 40, 50, 60, 70},   // Tint
    },
    // PC
    {
        {80, 106, 128, 143, 190},   // Contrast
        {80, 104, 128, 149, 170},   // Brightness
        {0,  80,  128, 158, 190},   // Color
        {0,  16,  22,  35,  63},   // Sharpness
        {30, 40, 50, 60, 70},   // Tint
    },
    // Storage
    {
        {80, 108, 128, 143, 196},   // Contrast
        {80, 104, 128, 153, 178},   // Brightness
        {0,  68,  148, 184, 200},   // Color
        {0,  10,  26,  40,  63},   // Sharpness
        {30, 40, 50, 60, 70},   // Tint
    },
#endif

#if(ENABLE_SOUND_NONLINEAR_CURVE)
#if ENABLE_DTV
    // DTV
    {0, 25, 50, 75, 100},   // Volume
#endif
    // TV
    {0, 25, 50, 75, 100},   // Volume
    // AV
    {0, 25, 50, 75, 100},   // Volume
    // Storage
    {0, 25, 50, 75, 100},   // Volume
#endif
};
#endif
#endif

#define INIT_SUB_BRIGHTNESS_DATA_DTV    128
#define INIT_SUB_CONTRAST_DATA_DTV      128

static T_MS_SUB_COLOR code astDefaultSubBriConTbl[DATA_INPUT_SOURCE_NUM] =
{
#if ENABLE_DTV
    {//DTV
        0,  //u16SubColorDataCS;
        INIT_SUB_BRIGHTNESS_DATA_DTV,
        INIT_SUB_CONTRAST_DATA_DTV,
    },
#endif
    {//ATV
        0,  //u16SubColorDataCS;
        INIT_SUB_BRIGHTNESS_DATA_DTV,
        INIT_SUB_CONTRAST_DATA_DTV,
    },
#if (INPUT_AV_VIDEO_COUNT >= 1)
    {//AV
        0,  //u16SubColorDataCS;
        INIT_SUB_BRIGHTNESS_DATA_DTV,
        INIT_SUB_CONTRAST_DATA_DTV,
    },
#endif
#if (INPUT_AV_VIDEO_COUNT >= 2)
    {//AV2
        0,  //u16SubColorDataCS;
        INIT_SUB_BRIGHTNESS_DATA_DTV,
        INIT_SUB_CONTRAST_DATA_DTV,
    },
#endif
#if (INPUT_AV_VIDEO_COUNT >= 3)
    {//AV3
        0,  //u16SubColorDataCS;
        INIT_SUB_BRIGHTNESS_DATA_DTV,
        INIT_SUB_CONTRAST_DATA_DTV,
    },
#endif
#if (INPUT_YPBPR_VIDEO_COUNT >= 1)
    {//COMPONENT
        0,  //u16SubColorDataCS;
        INIT_SUB_BRIGHTNESS_DATA_DTV,
        INIT_SUB_CONTRAST_DATA_DTV,
    },
#endif
#if (INPUT_YPBPR_VIDEO_COUNT >= 2)
    {//COMPONENT2
        0,  //u16SubColorDataCS;
        INIT_SUB_BRIGHTNESS_DATA_DTV,
        INIT_SUB_CONTRAST_DATA_DTV,
    },
#endif
    {//RGB
        0,  //u16SubColorDataCS;
        INIT_SUB_BRIGHTNESS_DATA_DTV,
        INIT_SUB_CONTRAST_DATA_DTV,
    },

#if (INPUT_HDMI_VIDEO_COUNT > 0)

    {//HDMI1
        0,  //u16SubColorDataCS;
        INIT_SUB_BRIGHTNESS_DATA_DTV,
        INIT_SUB_CONTRAST_DATA_DTV,
    },
#endif
#if (INPUT_HDMI_VIDEO_COUNT >= 2)
    {//HDMI2
        0,  //u16SubColorDataCS;
        INIT_SUB_BRIGHTNESS_DATA_DTV,
        INIT_SUB_CONTRAST_DATA_DTV,
    },
#endif
#if (INPUT_HDMI_VIDEO_COUNT >= 3)
    {//HDMI3
        0,  //u16SubColorDataCS;
        INIT_SUB_BRIGHTNESS_DATA_DTV,
        INIT_SUB_CONTRAST_DATA_DTV,
    },
#endif
#if (INPUT_HDMI_VIDEO_COUNT >= 4)
    {//HDMI4
        0,  //u16SubColorDataCS;
        INIT_SUB_BRIGHTNESS_DATA_DTV,
        INIT_SUB_CONTRAST_DATA_DTV,
    },
#endif

#if (INPUT_SCART_VIDEO_COUNT >= 1)
    {//SCART
        0,  //u16SubColorDataCS;
        INIT_SUB_BRIGHTNESS_DATA_DTV,
        INIT_SUB_CONTRAST_DATA_DTV,
    },
#endif

#if (INPUT_SCART_VIDEO_COUNT >= 2)
    {//SCART2
        0,  //u16SubColorDataCS;
        INIT_SUB_BRIGHTNESS_DATA_DTV,
        INIT_SUB_CONTRAST_DATA_DTV,
    },
#endif

#if (INPUT_SV_VIDEO_COUNT >= 1)
    {//SVIDEO
        0,  //u16SubColorDataCS;
        INIT_SUB_BRIGHTNESS_DATA_DTV,
        INIT_SUB_CONTRAST_DATA_DTV,
    },
#endif

#if (INPUT_SV_VIDEO_COUNT >= 2)
    {//SVIDEO2
        0,  //u16SubColorDataCS;
        INIT_SUB_BRIGHTNESS_DATA_DTV,
        INIT_SUB_CONTRAST_DATA_DTV,
    },
#endif

#if ENABLE_DMP
    {//DTV
        0,  //u16SubColorDataCS;
        INIT_SUB_BRIGHTNESS_DATA_DTV,
        INIT_SUB_CONTRAST_DATA_DTV,
    },
#endif
};



//*************************************************************************
//              Functions
//*************************************************************************

//*************************************************************************
//Function name:        MApp_DataBase_VersionCheck
//Passing parameter:    none
//Return parameter: BOOLEAN fError
//Description:          Check data base version and integrity
//*************************************************************************
BOOLEAN MApp_DataBase_VersionCheck(void)
{
    if(stGenSetting.u8VersionCheck == DEFAULT_DATABASE_VERSION &&
        stGenSetting.u8VersionCheckCom == DEFAULT_DATABASE_VERSION_COM)
    {
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}

//*************************************************************************
//Function name:        MApp_DataBase_RestoreDefaultSystem
//Passing parameter:    none
//Return parameter:     none
//Description:          Restore default system value to data base
//*************************************************************************
#if ENABLE_CUS_USB_OSD
extern void MApp_DMP_ResetStatus(void);
#endif
void MApp_DataBase_RestoreDefaultSystem(U16 u16KeepSetting)
{
#if (ENABLE_3D_PROCESS&&ENABLE_CUS_3D_SOURCE_MEMORY)
    U8 i;
#endif
//#if(ENABLE_DTV == FALSE)
//    UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_ATV;
//    UI_PREV_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_ATV;
//#else
//    UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_DTV;
//    UI_PREV_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_DTV;
//#endif
		  UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_AV;
		  UI_PREV_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_AV;

    if (!(RESTORE_KEEP_SYSTEM_LANGUAGE & u16KeepSetting))
    {
        //SET_VCOM_VAULE(220);
        SET_OSD_MENU_LANGUAGE(LANGUAGE_DEFAULT); // menu language
      #if (OBA2)
        MApp_ZUI_ACT_SetEnvLanguage(LANGUAGE_DEFAULT);
      #endif
    }

#if (ENABLE_CEC)
    stGenSetting.g_SysSetting.g_enHDMICEC = CUS_HDMI_CEC_STATUS;		// CUS_XM Sea 20120730:
    stGenSetting.g_SysSetting.g_bHdmiCecDeviceAutoStandby = CUS_HEMI_CEC_DEVICE_AUTO_STANDBY;
#endif

    stGenSetting.g_SysSetting.NextNewRamIndex = 0; // user mode index

#if ENABLE_DTV
  #if (ENABLE_SBTVD_BRAZIL_APP==0)
    if(IS_NORDIC_COUNTRY(OSD_COUNTRY_SETTING))
    {
        stGenSetting.g_SysSetting.fEnableSubTitle = 1;
        stGenSetting.g_SysSetting.fEnableTTXSubTitle = 1;
    }
    else
  #endif
#endif
    {
        stGenSetting.g_SysSetting.fEnableSubTitle = 0;
        stGenSetting.g_SysSetting.fEnableTTXSubTitle = 0;
    }
#if ENABLE_TTX // helen add for TTX
	stGenSetting.g_SysSetting.TTX_Language= TT_Charset_Group_West;
#endif
    stGenSetting.g_SysSetting.SubtitleDefaultLanguage             = LANGUAGE_ENGLISH;
    stGenSetting.g_SysSetting.SubtitleDefaultLanguage_2           = LANGUAGE_ENGLISH;
    stGenSetting.g_SysSetting.Last_Select_HotKey_SubtitleLanguage = LANGUAGE_ENGLISH;
#if 0//BOE_MT_NEW_IR_KEY_VALUE//minglin1217
stGenSetting.g_SysSetting.u8Backlight = 50;
#else
stGenSetting.g_SysSetting.u8Backlight = 100;
#endif
stGenSetting.g_SysSetting.bPanelVcom = 115;//150;
stGenSetting.g_SysSetting.gId693FailCnt=0;
//stGenSetting.g_SysSetting.gId693Cnt=0;
  #if ENABLE_PVR
     stGenSetting.g_SysSetting.u32PVR_RecordMaxTime = PVR_CHECKFS_MAX_RECORD_TIME;      //second, the max record time of free record
     stGenSetting.g_SysSetting.u8PVR_IsRecordAllChannel = 0;   //0:off  1:record all channel
  #endif
#if !ENABLE_MULTI_PANELS
    stGenSetting.g_SysSetting.enPanelResType = PANEL_DEFAULT_TYPE_SEL;
#endif
  #ifdef DVBT_MMBOX
    stGenSetting.g_SysSetting.fOutput_System = 1;
    stGenSetting.g_SysSetting.enPALResType = DEFAULT_PAL_RES;
    stGenSetting.g_SysSetting.enNTSCResType = DEFAULT_NTSC_RES;
  #endif

  #if ENABLE_OFFLINE_SIGNAL_DETECTION
    stGenSetting.g_SysSetting.bAIS = AIS_OFF;
  #endif

  #if (ENABLE_SW_CH_FREEZE_SCREEN)
    stGenSetting.g_SysSetting.u8SwitchMode = ATV_SWITCH_CH_DEFAULT;//ATV_SWITCH_CH_FREEZE_SCREEN;
  #endif

  #if ENABLE_SZ_BLUESCREEN_FUNCTION
  #if BOE_BLUE_INIT_ON
  stGenSetting.g_SysSetting.bIsBluescreenOn =ENABLE;//DISABLE;
  #else
  stGenSetting.g_SysSetting.bIsBluescreenOn =DISABLE;//ATV_SWITCH_CH_FREEZE_SCREEN;//minglin0220
  #endif
  #endif
  #if BOE_FACTORY_CHANNEL
	stGenSetting.g_SysSetting.uFactoryChannelFlag =FALSE;
    stGenSetting.g_SysSetting.uFactoryChannelFlag2=TRUE;
#endif
#ifdef ENABLE_CUS_FACTORY_ATV_CH_PRSET
	  stGenSetting.g_SysSetting.uFactoryChannelFlag =FALSE;
#endif

  #if ENABLE_DBC
    stGenSetting.g_SysSetting.fDCR = 0;
    MApi_XC_Sys_DLC_DBC_OnOff(stGenSetting.g_SysSetting.fDCR);
  #endif

    stGenSetting.g_SysSetting.fSCARTInputSel = EN_SCART_SEL_AV;
    stGenSetting.g_SysSetting.fCOLORRANGE= 1;

#if ENABLE_CUS_HDMI_MODE
    stGenSetting.g_SysSetting.bIsHDMIVideoMode = TRUE;
#endif
#ifdef ENABLE_CUS_AV_COLOR_SYSTEM
    stGenSetting.g_SysSetting.enAVColorSystem = ATV_COLOR_AUTO;
#endif

#if 0//ENABLE_DMP
    stGenSetting.g_SysSetting.UsrLogo = POWERON_LOGO_DEFAULT;
    stGenSetting.g_SysSetting.u8UsrLogoCnt= 0;
    stGenSetting.g_SysSetting.u8UsrLogoIdx = 0;
    stGenSetting.g_SysSetting.UsrPowerOnMusic = POWERON_MUSIC_DEFAULT;
  #endif
  //cus_xm gary 20120710  add for ebony style
    if(CUS_OSD_STYLE==CUS_OSD_EBONY_ONEUX_LIKE)
        stGenSetting.g_SysSetting.OsdBlending = EN_OSD_TRAN_LOW;
    else
        stGenSetting.g_SysSetting.OsdBlending = EN_OSD_TRAN_OFF; // 2012-07-07 ZHIQIN CHANGE FOR SMC SPEC

    stGenSetting.g_FactorySetting.u8PowerOnMode = POWERON_MODE_ON;//POWERON_MODE_OFF;//2012-07-05 ZHIQIN CHANGE FOR SMC SPEC

  #if ENABLE_CUS_OSD_TIMEOUT
    stGenSetting.g_SysSetting.OsdDuration = EN_OSD_TIME_20;
  #else
    stGenSetting.g_SysSetting.OsdDuration = EN_OSD_TIME_ALWAYS;
  #endif

  #if (ATSC_CC == ATV_CC)
    stGenSetting.g_SysSetting.enATVCaptionType = ATV_CAPTION_TYPE_OFF;
  #endif

  #if ENABLE_3D_PROCESS
    #if ENABLE_CUS_3D_SOURCE_MEMORY
    for(i = 0; i < DATA_INPUT_SOURCE_NUM; i++)
    {
        #if (INPUT_HDMI_VIDEO_COUNT >= 4)
        if(i>=DATA_INPUT_SOURCE_HDMI && i<=DATA_INPUT_SOURCE_HDMI4)
        #elif (INPUT_HDMI_VIDEO_COUNT >= 3)
        if(i>=DATA_INPUT_SOURCE_HDMI && i<=DATA_INPUT_SOURCE_HDMI3)
        #elif (INPUT_HDMI_VIDEO_COUNT >= 2)
        if(i>=DATA_INPUT_SOURCE_HDMI && i<=DATA_INPUT_SOURCE_HDMI2)
        #else
        if(i == DATA_INPUT_SOURCE_HDMI)
        #endif
        {
            stGenSetting.g_3DType_UserSetting[i].en3DType= EN_3D_FRAME_PARKING;
        }
        else
        {
            stGenSetting.g_3DType_UserSetting[i].en3DType= EN_3D_BYPASS;
        }
        stGenSetting.g_3DType_UserSetting[i].en3DLRMode= EN_3D_LR_L;
        #if ENABLE_CUS_3D_SETTING
        stGenSetting.g_3DType_UserSetting[i].u83DScene = 5; //8;
        #endif
    }
    #else
    stGenSetting.g_SysSetting.en3DType= EN_3D_FRAME_PARKING;
    stGenSetting.g_SysSetting.en3DLRMode= EN_3D_LR_L;
    #if ENABLE_CUS_3D_SETTING
    stGenSetting.g_SysSetting.u83DScene = 5;
    #endif
    #endif
    stGenSetting.g_SysSetting.en3DDetectMode= EN_3D_DETECT_AUTO;
  #endif

  #if ENABLE_UI_3D_PROCESS
    stGenSetting.g_SysSetting.en3DUIMODE= E_UI_3D_UI_MODE_NONE;
  #endif

#if GENSETTING_STORE_USE_NEW_METHOD
    stGenSetting.g_SysSetting.u8ATVProgramNumber = MIN_ATVPROGRAM-1;//MIN_ATVPROGRAM  SMC jayden.chen modify for init channer number 20130308
  #if (ENABLE_DTV)
    stGenSetting.g_SysSetting.u16DTVRFChannelOrder = DEFAULT_CURRENT_ORDER_TV;
    stGenSetting.g_SysSetting.u16DATARFChannelOrder = DEFAULT_CURRENT_ORDER_DATA;
    stGenSetting.g_SysSetting.u16RADIORFChannelOrder = DEFAULT_CURRENT_ORDER_RADIO;
    stGenSetting.g_SysSetting.eCurrentServiceType = DEFAULT_CURRENT_SERVICETYPE;
  #endif
#endif

//<<SMC jayden.chen init uUartPortConect 20130812
#if BOE_UART_FAC_COMMAND
	stGenSetting.g_SysSetting.uUartPortConect = 0;//0:OpenUart
#endif
//>>SMC jayden.chen init uUartPortConect 20130812

    msAPI_Timer_SetSystemTime(631152000);    //CUS SMC INDIA 2000-01-01 00:00
#if ENABLE_CUS_USB_OSD
    MApp_DMP_ResetStatus();
#endif
    MApp_DataBase_RestoreDefaultTime();
    MApp_Sleep_ReleaseSleepTimer();
    MApp_DataBase_RestoreDefaultTime();

}

void MApp_DataBase_RestoreDefaultADC(E_ADC_SET_INDEX eAdcIndex )
{
#if USE_CUS_DEFAULT_ADC

    if( eAdcIndex == ADC_SET_YPBPR_SD )
    {
        stGenSettingExt.g_AdcSetting[ADC_SET_YPBPR_SD].stAdcGainOffsetSetting = tADCSetting[ADC_SET_YPBPR_SD];
    }
    else if( eAdcIndex == ADC_SET_YPBPR_HD )
    {
        stGenSettingExt.g_AdcSetting[ADC_SET_YPBPR_HD].stAdcGainOffsetSetting = tADCSetting[ADC_SET_YPBPR_HD];
    }
    else if( eAdcIndex == ADC_SET_SCART_RGB)
    {
        stGenSettingExt.g_AdcSetting[ADC_SET_SCART_RGB].stAdcGainOffsetSetting = tADCSetting[ADC_SET_SCART_RGB];
    }
    else
    {
        stGenSettingExt.g_AdcSetting[eAdcIndex].stAdcGainOffsetSetting = tADCSetting[ADC_SET_VGA];
    }

#else

    APIXC_AdcGainOffsetSetting Adc_GainOffset;

    if ( eAdcIndex == ADC_SET_YPBPR_SD || eAdcIndex == ADC_SET_YPBPR_HD )
    {
        // Get Ypbpr default setting
        MApi_XC_ADC_GetDefaultGainOffset(INPUT_SOURCE_YPBPR,&Adc_GainOffset);
    }
    else // VGA / Scart-RGB / Others
    {
        // Get RGB default setting
        MApi_XC_ADC_GetDefaultGainOffset(INPUT_SOURCE_VGA,&Adc_GainOffset);
    }

    memcpy(&(stGenSettingExt.g_AdcSetting[eAdcIndex].stAdcGainOffsetSetting) , &Adc_GainOffset , sizeof(APIXC_AdcGainOffsetSetting) );

#endif
}

//*************************************************************************
//Function name:        MApp_DataBase_RestoreDefaultVideo
//Passing parameter:    none
//Return parameter:     none
//Description:          Restore default video value to data base
//*************************************************************************

void MApp_DataBase_RestoreDefaultVideo(E_DATA_INPUT_SOURCE enDataInputSource)
{
    U8 i;

//    printf("=============> MApp_DataBase_RestoreDefaultVideo\n");

    if( enDataInputSource >= DATA_INPUT_SOURCE_NUM )
    {
        for(i = 0; i < DATA_INPUT_SOURCE_NUM; i++)
        {
            stGenSettingExt.g_astVideo[i] = astDefaultVideoDataTbl[i];
        }
    }
    else
    {
        stGenSettingExt.g_astVideo[enDataInputSource] = astDefaultVideoDataTbl[enDataInputSource];
    }
    //reset Film mode
   // MDrv_PQ_SetFilmMode(PQ_MAIN_WINDOW, DEFAULT_ENABLE_CINEMA);
}

void MApp_DataBase_RestoreDefaultWhiteBalance(E_DATA_INPUT_SOURCE enDataInputSource)
{
    U8 i;

    if( enDataInputSource >= DATA_INPUT_SOURCE_NUM )
    {
        for(i = 0; i < DATA_INPUT_SOURCE_NUM; i++)
        {
            stGenSettingExt.g_astWhiteBalance[i] = astDefaultWhiteBalanceDataTbl[i];
        }
    }
    else
    {
        stGenSettingExt.g_astWhiteBalance[enDataInputSource] = astDefaultWhiteBalanceDataTbl[enDataInputSource];
    }
}

void MApp_DataBase_PictureResetWhiteBalance(E_DATA_INPUT_SOURCE enDataInputSource)
{
#if ENABLE_CUS_UI_SPEC
    enDataInputSource = enDataInputSource;
#else
    U8 i;
#if ENABLE_PRECISE_RGBBRIGHTNESS
    XC_ACE_color_temp_ex stColorTemp =
#else
    XC_ACE_color_temp stColorTemp =
#endif
    {
        INIT_VIDEO_COLOR_BRIGHTNESS_USER_R,
        INIT_VIDEO_COLOR_BRIGHTNESS_USER_G,
        INIT_VIDEO_COLOR_BRIGHTNESS_USER_B,

        INIT_VIDEO_COLOR_TEMP_USER_R,
        INIT_VIDEO_COLOR_TEMP_USER_G,
        INIT_VIDEO_COLOR_TEMP_USER_B,

        0x32, //0,
        0x32, //0,
        0x32, //0,
    };  //24Byte

    if( enDataInputSource >= DATA_INPUT_SOURCE_NUM )
    {
        for(i = 0; i < DATA_INPUT_SOURCE_NUM; i++)
        {
            //stGenSettingExt.g_astWhiteBalance[i] = astDefaultWhiteBalanceDataTbl[i];
            stGenSettingExt.g_astWhiteBalance[i].astColorTemp[MS_COLOR_TEMP_MAX].cRedOffset       =  stColorTemp.cRedOffset;
            stGenSettingExt.g_astWhiteBalance[i].astColorTemp[MS_COLOR_TEMP_MAX].cGreenOffset     =  stColorTemp.cGreenOffset;
            stGenSettingExt.g_astWhiteBalance[i].astColorTemp[MS_COLOR_TEMP_MAX].cBlueOffset      =  stColorTemp.cBlueOffset;
            stGenSettingExt.g_astWhiteBalance[i].astColorTemp[MS_COLOR_TEMP_MAX].cRedColor        =  stColorTemp.cRedColor;
            stGenSettingExt.g_astWhiteBalance[i].astColorTemp[MS_COLOR_TEMP_MAX].cGreenColor      =  stColorTemp.cGreenColor;
            stGenSettingExt.g_astWhiteBalance[i].astColorTemp[MS_COLOR_TEMP_MAX].cBlueColor       =  stColorTemp.cBlueColor;
            stGenSettingExt.g_astWhiteBalance[i].astColorTemp[MS_COLOR_TEMP_MAX].cRedScaleValue   =  stColorTemp.cRedScaleValue;
            stGenSettingExt.g_astWhiteBalance[i].astColorTemp[MS_COLOR_TEMP_MAX].cGreenScaleValue =  stColorTemp.cGreenScaleValue;
            stGenSettingExt.g_astWhiteBalance[i].astColorTemp[MS_COLOR_TEMP_MAX].cBlueScaleValue  =  stColorTemp.cBlueScaleValue;
        }
    }
    else
    {
        //stGenSettingExt.g_astWhiteBalance[enDataInputSource] = astDefaultWhiteBalanceDataTbl[enDataInputSource];
        stGenSettingExt.g_astWhiteBalance[enDataInputSource].astColorTemp[MS_COLOR_TEMP_MAX].cRedOffset       =  stColorTemp.cRedOffset;
        stGenSettingExt.g_astWhiteBalance[enDataInputSource].astColorTemp[MS_COLOR_TEMP_MAX].cGreenOffset     =  stColorTemp.cGreenOffset;
        stGenSettingExt.g_astWhiteBalance[enDataInputSource].astColorTemp[MS_COLOR_TEMP_MAX].cBlueOffset      =  stColorTemp.cBlueOffset;
        stGenSettingExt.g_astWhiteBalance[enDataInputSource].astColorTemp[MS_COLOR_TEMP_MAX].cRedColor        =  stColorTemp.cRedColor;
        stGenSettingExt.g_astWhiteBalance[enDataInputSource].astColorTemp[MS_COLOR_TEMP_MAX].cGreenColor      =  stColorTemp.cGreenColor;
        stGenSettingExt.g_astWhiteBalance[enDataInputSource].astColorTemp[MS_COLOR_TEMP_MAX].cBlueColor       =  stColorTemp.cBlueColor;
        stGenSettingExt.g_astWhiteBalance[enDataInputSource].astColorTemp[MS_COLOR_TEMP_MAX].cRedScaleValue   =  stColorTemp.cRedScaleValue;
        stGenSettingExt.g_astWhiteBalance[enDataInputSource].astColorTemp[MS_COLOR_TEMP_MAX].cGreenScaleValue =  stColorTemp.cGreenScaleValue;
        stGenSettingExt.g_astWhiteBalance[enDataInputSource].astColorTemp[MS_COLOR_TEMP_MAX].cBlueScaleValue  =  stColorTemp.cBlueScaleValue;
    }
#endif
}

void MApp_DataBase_RestoreDefaultSubColor(E_DATA_INPUT_SOURCE enDataInputSource)
{
    U8 i;

    if( enDataInputSource >= DATA_INPUT_SOURCE_NUM )
    {
        for(i = 0; i < DATA_INPUT_SOURCE_NUM; i++)
        {
            stGenSettingExt.g_astSubColor[i] = astDefaultSubBriConTbl[i];
        }
    }
    else
    {
        stGenSettingExt.g_astSubColor[enDataInputSource] = astDefaultSubBriConTbl[enDataInputSource];
    }
}

//*************************************************************************
//Function name:        MApp_DataBase_RestoreDefaultAudio
//Passing parameter:    none
//Return parameter:     none
//Description:          Restore default audio value to data base
//*************************************************************************
void MApp_DataBase_RestoreDefaultAudio(void)
{
    stGenSetting.g_SoundSetting.SoundMode = SOUND_MODE_STANDARD;

    /* Update the default sound mode. All default sound modes are stored in astDefaultSoundModeSeting*/
    memcpy(stGenSetting.g_SoundSetting.astSoundModeSetting, astDefaultSoundModeSeting, sizeof(astDefaultSoundModeSeting));

    g_u8AudLangSelected = SOUND_MTS_STEREO;
	#if ENABLE_SOUND_NONLINEAR_CURVE_TEN//minglin0125
    stGenSetting.g_SoundSetting.bEnableAVC = ENABLE;
	#else
    stGenSetting.g_SoundSetting.bEnableAVC = DISABLE;
	#endif
    stGenSetting.g_SoundSetting.Surround = SURROUND_MODE_MOUNTAIN;
	//add for hotel menu volume default @chuxu 2012-08-08 @modify 2012-08-20
#if CUS_SMC_ENABLE_HOTEL_MODE
    if (stGenSetting.g_FactorySetting.HotelMenuHotelModeOperationEnable == ENABLE)
	{
		stGenSetting.g_SoundSetting.Volume = stGenSetting.g_FactorySetting.HotelMenuVolumeDefault;
	}
	else
		stGenSetting.g_SoundSetting.Volume = DEFAULT_VOLUME_SETTING;
#else
    {
		stGenSetting.g_SoundSetting.Volume = DEFAULT_VOLUME_SETTING;
	}
#endif
    msAPI_AUD_AdjustAudioFactor(E_ADJUST_VOLUME, stGenSetting.g_SoundSetting.Volume, 0);//XM CUS ZHIQIN ADD
    // set default AD value
    stGenSetting.g_SoundSetting.bEnableAD = DISABLE;
    stGenSetting.g_SoundSetting.ADVolume = DEFAULT_VOLUME_SETTING;

    stGenSetting.g_SoundSetting.ADOutput = AD_SPEAKER;
#if ENABLE_CUS_AUDIO_DELAY
    stGenSetting.g_SoundSetting.LipSyncDelayTime = 100;
#endif

    stGenSetting.g_SoundSetting.Balance = DEFAULT_BALANCE_SETTING;
    stGenSetting.g_SoundSetting.enSoundAudioLan1 = LANGUAGE_ENGLISH;
    stGenSetting.g_SoundSetting.enSoundAudioLan2 = LANGUAGE_ENGLISH;
#if (ENABLE_CUS_SURROUND_FOLLOW_SNDMODE == DISABLE)
    stGenSetting.g_SoundSetting.SurroundSoundMode = SURROUND_SYSTEM_OFF;
#endif
    stGenSetting.g_SysSetting.fAutoVolume = DEFAULT_AUTO_VOLUME;

    MApi_AUDIO_SetBalance(stGenSetting.g_SoundSetting.Balance);

#ifdef ENABLE_KTV
    stGenSetting.g_SoundSetting.KTVBGVolume = DEFAULT_VOLUME_SETTING;
    stGenSetting.g_SoundSetting.KTVMicVolume = DEFAULT_VOLUME_SETTING;
    stGenSetting.g_SoundSetting.KTVMixVolume = DEFAULT_VOLUME_SETTING;
#endif

    /* Set the surround mode */
#if (ENABLE_CUS_SURROUND_FOLLOW_SNDMODE == DISABLE)
    MApp_Aud_SetSurroundMode(stGenSetting.g_SoundSetting.SurroundSoundMode);
#else
    MApp_Aud_SetSurroundMode(stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].SurroundSoundMode);
#endif

    // add AVL function
    //msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_MOMENT_MUTEON, E_AUDIOMUTESOURCE_ACTIVESOURCE);
   // MApi_AUDIO_EnableAutoVolume((BOOLEAN)stGenSetting.g_SysSetting.fAutoVolume);
   // msAPI_AUD_AdjustAudioFactor(E_ADJUST_VOLUME, stGenSetting.g_SoundSetting.Volume, 0);
   // msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_MOMENT_MUTEOFF, E_AUDIOMUTESOURCE_ACTIVESOURCE);
}

void MApp_DataBase_RestoreDefaultScanMenu(void)
{
    //*************************************************************************
    // Restore default ScanMenuSetting
    //*************************************************************************
    stGenSetting.stScanMenuSetting.u8RFChannelNumber = DEFAULT_RF_CHANNEL;
    stGenSetting.stScanMenuSetting.u8ChType = CH_TYPE_DTV;
    stGenSetting.stScanMenuSetting.u8Antenna = ANT_AIR;
    stGenSetting.stScanMenuSetting.u8ATVManScanDir=ATV_MAN_SCAN_UP;
    stGenSetting.stScanMenuSetting.u8ATVManScanType=ATV_MAN_SCAN_TYPE_ONECH;
    stGenSetting.stScanMenuSetting.u8ATVMediumType=MEDIUM_AIR;
    stGenSetting.stScanMenuSetting.u8LSystem=FALSE;
    stGenSetting.stScanMenuSetting.u8ScanType=SCAN_TYPE_AUTO;
    stGenSetting.stScanMenuSetting.u8BandWidth = E_RF_CH_BAND_8MHz;

#if ENABLE_DTV
    msAPI_DFT_SetBandwidth(stGenSetting.stScanMenuSetting.u8BandWidth);
#endif

#if (ENABLE_T_C_COMBO || DVB_T_C_DIFF_DB)
    stGenSetting.stScanMenuSetting.u8DVBCTvConnectionType=EN_DVB_T_TYPE;
    msAPI_Tuner_SwitchSource((EN_DVB_TYPE)stGenSetting.stScanMenuSetting.u8DVBCTvConnectionType, TRUE);
#endif

#if ( ENABLE_DVB_TAIWAN_APP || ENABLE_SBTVD_BRAZIL_APP || (TV_SYSTEM == TV_NTSC) )
    stGenSetting.stScanMenuSetting.u8SoundSystem=EN_ATV_SystemType_M;
#elif (ENABLE_DTMB_CHINA_APP || ENABLE_ATV_CHINA_APP || ENABLE_DVBC_PLUS_DTMB_CHINA_APP)
#if (CUS_AREA_ID == AREA_ID_INDIA)
    stGenSetting.stScanMenuSetting.u8SoundSystem=EN_ATV_SystemType_BG;
#else
    stGenSetting.stScanMenuSetting.u8SoundSystem=EN_ATV_SystemType_DK;
#endif
#else
    stGenSetting.stScanMenuSetting.u8SoundSystem=EN_ATV_SystemType_BG;
#endif
}
void MApp_DataBase_RestoreDefaultTime(void)
{
    stGenSetting.g_Time = stDefaultTimeData;
}

void App_DataBase_RestoreDefaultBlock(void)
{
    stGenSetting.g_BlockSysSetting.u8BlockSysLockMode = DISABLE;
    stGenSetting.g_BlockSysSetting.u8ParentalControl = EN_F4_LockSystem_Min;
    //stGenSetting.g_BlockSysSetting.u8ParentalControl = EN_F4_LockSystem_Max; //Mediaset 2.4.3 test 5.5 default needs 18.
}

void MApp_DataBase_RestoreDefaultSSC(void)
{
#if ENABLE_SSC
    stGenSetting.g_SSCSetting.SscMIUEnable = DISABLE;
    stGenSetting.g_SSCSetting.MIUSscSpanKHzx10= MIU_SSC_SPAN_DEFAULT;
    stGenSetting.g_SSCSetting.MIUSscStepPercentagex100= MIU_SSC_STEP_DEFAULT;
//CUS_XM gary modify by always enable ssc at china area
#if(CUS_AREA_ID==AREA_ID_CHINA)
    stGenSetting.g_SSCSetting.SscLVDSEnale = ENABLE;
#else
    stGenSetting.g_SSCSetting.SscLVDSEnale = DISABLE;
#endif
    stGenSetting.g_SSCSetting.LVDSSscSpanKHzx10= LVDS_SSC_SPAN_DEFAULT;
    stGenSetting.g_SSCSetting.LVDSSscStepPercentagex100= LVDS_SSC_STEP_DEFAULT;
#endif
}

#if (ENABLE_NONLINEAR_CURVE)
void MApp_DataBase_RestoreDefaultNonLinearCurve(void)
{
    stGenSetting.g_NonLinearCurveSetting = tNonLinearCurveSetting;
}
#endif

void MApp_DataBase_RestoreDefaultFactorySetting(void)
{
#if ENABLE_VD_PACH_IN_CHINA
    stGenSetting.g_FactorySetting.u8AFEC_D4 =BK_AFEC_D4_DEFAULT;
    stGenSetting.g_FactorySetting.u8AFEC_D5_Bit2    =0;
    stGenSetting.g_FactorySetting.u8AFEC_D8_Bit3210    =0x00;
    stGenSetting.g_FactorySetting.u8AFEC_D9_Bit0    =0;
    stGenSetting.g_FactorySetting.u16AFEC_A0_A1     =0x1020;
    stGenSetting.g_FactorySetting.u8AFEC_66_Bit76   =0;
    stGenSetting.g_FactorySetting.u8AFEC_6E_Bit7654 =0x08;
    stGenSetting.g_FactorySetting.u8AFEC_6E_Bit3210 =0x08;
    stGenSetting.g_FactorySetting.u8AFEC_43=0x14;
    stGenSetting.g_FactorySetting.u8AFEC_44=0x90;
    stGenSetting.g_FactorySetting.u8AFEC_D7_LOW_BOUND=VD_COLOR_KILL_LOW_BOUND;
    stGenSetting.g_FactorySetting.u8AFEC_D7_HIGH_BOUND=VD_COLOR_KILL_HIGH_BOUND;
    stGenSetting.g_FactorySetting.u8AFEC_CB=0x00;
    stGenSetting.g_FactorySetting.u8AFEC_CF_BIT2=0X01;
    stGenSetting.g_FactorySetting.u8AFEC_4E_BIT7=0x00;
    stGenSetting.g_FactorySetting.u8AFEC_4F=0x68;

//VIF setting
    stGenSetting.g_FactorySetting.Vif_TOP=VIF_TOP;
    stGenSetting.g_FactorySetting.Vif_VGA_MAXIMUM=VIF_VGA_MAXIMUM;
    stGenSetting.g_FactorySetting.Vif_CR_KP_KI=VIF_CR_KP<<8|VIF_CR_KI;
    stGenSetting.g_FactorySetting.Vif_CR_THR      =VIF_CR_THR;
    stGenSetting.g_FactorySetting.Vif_CR_LOCK_THR=VIF_CR_LOCK_THR;
    stGenSetting.g_FactorySetting.Vif_CR_KP_KI_ADJUST=VIF_CR_KP_KI_ADJUST;
    stGenSetting.g_FactorySetting.Vif_CHINA_DESCRAMBLER_BOX=CHINA_DESCRAMBLER_BOX;
    stGenSetting.g_FactorySetting.Vif_OVER_MODULATION =VIF_OVER_MODULATION;
    stGenSetting.g_FactorySetting.Vif_CLAMPGAIN_GAIN_OV_NEGATIVE=VIF_CLAMPGAIN_GAIN_OV_NEGATIVE;
    stGenSetting.g_FactorySetting.Vif_ASIA_SIGNAL_OPTION=VIF_ASIA_SIGNAL_OPTION;
    stGenSetting.g_FactorySetting.Vif_AGCREFNEGATIVE=VIF_CHANEL_SCAN_AGC_REF;
    stGenSetting.g_FactorySetting.Vif_SERIOUS_ACIDETECT=VIF_SERIOUS_ACI_DETECTION;
    stGenSetting.g_FactorySetting.AUDIO_HIDEV=E_AUDIO_HIDEV_BW_L1;
#if ENABLE_NO_AUDIO_INPUT_AUTO_MUTE
	stGenSetting.g_FactorySetting.AUDIO_NR=0x68;
#else
	stGenSetting.g_FactorySetting.AUDIO_NR=AUDIO_NR_THRESHOLD;
#endif
    //stGenSetting.g_FactorySetting.AUDIO_NR = AUDIO_NR_THRESHOLD;		// CUS_XM Sea 20120730:
    stGenSetting.g_FactorySetting.SCAN_DELAY=0x00;
    stGenSetting.g_FactorySetting.COMBPATCH=0;
    stGenSetting.g_FactorySetting.NOTSTANDARDPATCH=0;
#endif

#if (ENABLE_FACTORY_POWER_ON_MODE)
    stGenSetting.g_FactorySetting.u8PowerOnMode = POWERON_MODE_ON;//POWERON_MODE_OFF;//2012-07-05 ZHIQIN CHANGE FOR SMC SPEC
    stGenSetting.g_FactorySetting.g_u8DCOnOff   = EN_POWER_DC_ON;
#endif
#if ENABLE_CUS_BURNING_MODE
#if BOE_ACPOERON_BURINGMODE
   stGenSetting.g_FactorySetting.fBuringMode = ENABLE;
#else
    stGenSetting.g_FactorySetting.fBuringMode = DISABLE;
#endif
#endif

//add for hotel menu setting:initial data @chuxu 2012-08-02
#if CUS_SMC_ENABLE_HOTEL_MODE
	stGenSetting.g_FactorySetting.HotelMenuHotelModeOperationEnable = DISABLE; //item1@initial data: off
	stGenSetting.g_FactorySetting.HotelMenuMaxVolumeSetting = 0x64; //item2@initial data: 100
	stGenSetting.g_FactorySetting.HotelMenuVolumeDefault = 70;//0x14; //item3@initial data: 20
	stGenSetting.g_FactorySetting.HotelMenuOSDDisplayEnable = ENABLE; //item4@initial data: on
	stGenSetting.g_FactorySetting.HotelMenuOSDDisplayEnableBack = ENABLE; //back@initial data: on
	stGenSetting.g_FactorySetting.HotelMenuLocalKeyLockEnable = DISABLE; //item5@initial data: off
	stGenSetting.g_FactorySetting.HotelMenuRometeControlLockEnable = DISABLE; //item6@initial data: off
	stGenSetting.g_FactorySetting.HotelMenuRometeControlLockEnableBack = DISABLE;//back@initial data: off
	stGenSetting.g_FactorySetting.HotelMenuChannelDefault = 0x01; //item7@initial data: 1
	stGenSetting.g_FactorySetting.HotelMenuInputSourceChange = HOTEL_MODE_INPUT_SOURCE_ATV;//HOTEL_MODE_INPUT_SOURCE_AUTO;//DATA_INPUT_SOURCE_AUTO;//item7@initial data: auto
	stGenSetting.g_FactorySetting.HotelMenuUSBCloneMode = HotelMenuUsbCloneModeOFF; //item9@initial data: off	
	stGenSetting.g_FactorySetting.HotelMenuAQPQRestoreEnable = ENABLE; //item10@initial data: off
	stGenSetting.g_FactorySetting.HotelMenuInstallation = 0x00; //item11@initial data: 1
	stGenSetting.g_FactorySetting.HotelMenuSourceKeyLockEnable = DISABLE; //item12@initial data: off
	stGenSetting.g_FactorySetting.HotelCaptureLogo= DISABLE; //item12@initial data: off
	stGenSetting.g_FactorySetting.HotelMenuLanguage= LANGUAGE_DEFAULT; //item12@initial data: off
	stGenSetting.g_FactorySetting.HotelMenuUSBCloneUsedFlag=FALSE;
	stGenSetting.g_FactorySetting.HotelMenuMenuKeyPressFlag=0x00;
	stGenSetting.g_FactorySetting.HotelMenuMenuKeyPressTime=0x00;
	stGenSetting.g_SysSetting.UsrLogo=2;
#endif
#if ENABLE_DMP
    stGenSetting.g_SysSetting.UsrLogo = POWERON_LOGO_DEFAULT;
    stGenSetting.g_SysSetting.u8UsrLogoCnt= 1;
    stGenSetting.g_SysSetting.u8UsrLogoIdx = 1;
    stGenSetting.g_SysSetting.UsrPowerOnMusic = POWERON_MUSIC_DEFAULT;
  #endif
#if ENABLE_SZ_FACTORY_LVDS_MODE_FUNCTION
  //<<SMC jayden.chen add for Panel Adjust 20130812
  stGenSetting.g_SysSetting.uLvdsTiMode    = GetPanelLvdsTiModeByName(PANEL_DEFAULT_TYPE_SEL);//1; 
  stGenSetting.g_SysSetting.uLvdsDepth     = GetPanelTiBitModeByName(PANEL_DEFAULT_TYPE_SEL); 
  stGenSetting.g_SysSetting.uLvdsPortSwap  = GetPanelLvdsSwapByName(PANEL_DEFAULT_TYPE_SEL);//PANEL_SWAP_PORT;
  stGenSetting.g_SysSetting.uLvdsPolSwap   = GetPanelLvdsPolByName(PANEL_DEFAULT_TYPE_SEL);//PANEL_SWAP_LVDS_POL;
  //>>SMC jayden.chen add for Panel Adjust 20130812
#endif
#if ENABLE_MULTI_PANELS
	stGenSetting.g_SysSetting.enPanelResType = PANEL_DEFAULT_TYPE_SEL;
#endif

}
#if ENABLE_DRM
void MApp_Drm_RestoreDefaultSetupInfo(void)
{
    int i;
    for(i = 0; i < 10; i++)
        stGenSetting.g_VDplayerDRMInfo.u8RegistrationCode[i] = 0;
    for(i = 0; i < 8; i++)
        stGenSetting.g_VDplayerDRMInfo.u8DeActivationCode[i] = 0;
    for(i = 0; i < 48; i++)
        stGenSetting.g_VDplayerDRMInfo.u8DRM_Data[i] = 0;

    stGenSetting.g_VDplayerDRMInfo.bIsKeyGenerated = 0;
    stGenSetting.g_VDplayerDRMInfo.bIsActivated = 0;
    stGenSetting.g_VDplayerDRMInfo.bIsDeactivated = 0;
}
#endif

#ifdef ENABLE_BT
MS_TorrentSetupInfo code TorrentSetupDefault =
{// must be unicode
        0,
        10,
        {"Http://www.mstarsemi.com/BTServer"},
        808,
        100,
        30
};

void MApp_BT_RestoreDefaultTorrentSetupInfo(void)
{
    stGenSetting.TorrentSetupInfo.u8MaxSession = TorrentSetupDefault.u8MaxSession;
    stGenSetting.TorrentSetupInfo.u16port = TorrentSetupDefault.u16port;
    stGenSetting.TorrentSetupInfo.u16DownloadLimit = TorrentSetupDefault.u16DownloadLimit;
    stGenSetting.TorrentSetupInfo.u16UploadLimit = TorrentSetupDefault.u16UploadLimit;
    memcpy(stGenSetting.TorrentSetupInfo.u8ServerName, TorrentSetupDefault.u8ServerName, sizeof(TorrentSetupDefault.u8ServerName));
    stGenSetting.TorrentSetupInfo.TorrentSetupInfoCS = MApp_CalCheckSum((BYTE *)&(stGenSetting.TorrentSetupInfo), SIZE_BT_DATA );
}
#endif

#if (ENABLE_PIP)
void MApp_DataBase_RestoreDefaultPIP(void)
{
    if(IsPIPDBCheck())
    {
        stGenSetting.g_stPipSetting.enPipMode = EN_PIP_MODE_OFF;
        stGenSetting.g_stPipSetting.enSubInputSourceType = UI_INPUT_SOURCE_RGB;
        stGenSetting.g_stPipSetting.enPipSize = EN_PIP_SIZE_SMALL;
        stGenSetting.g_stPipSetting.enPipPosition = EN_PIP_POSITION_RIGHT_BOTTOM;
        stGenSetting.g_stPipSetting.bBolderEnable = FALSE;
        stGenSetting.g_stPipSetting.enPipSoundSrc = EN_PIP_SOUND_SRC_MAIN;
        stGenSetting.g_stPipSetting.u8BorderWidth = 0x01;
        stGenSetting.g_stPipSetting.bPipEnable = TRUE;
        stGenSetting.g_stPipSetting.PIPSetupInfoCS = MApp_CalCheckSum((BYTE *)&(stGenSetting.g_stPipSetting), SIZE_PIP_DATA );
    }
}
#endif

void MApp_DataBase_RestoreDefaultInstallGuide(BOOLEAN bRunInstallationGuide)
{
	#if (ENABLE_DTV)
	    stGenSetting.fRunInstallationGuide = bRunInstallationGuide;
	#else
	    stGenSetting.fRunInstallationGuide = bRunInstallationGuide;//FALSE;
	#endif
}

void MApp_DataBase_RestoreDefaultVChip(void)
{
    memset(&stGenSetting.g_VChipSetting, 0, sizeof(MS_VCHIP_SETTING));
    stGenSetting.g_VChipSetting.u16VChipPassword = 0x0000; // 0x1234;
    #if ( ENABLE_ATV_VCHIP)
    stGenSetting.g_VChipSetting.u8VChipLockMode = 1;
    #endif
    stGenSetting.g_VChipSetting.u8InputBlockItem = 0;
}

//*************************************************************************
//Function name:        MApp_DataBase_RestoreDefaultValue
//Passing parameter:    none
//Return parameter:     none
//Description:          Restore default value to data base
//*************************************************************************
void MApp_DataBase_RestoreDefaultValue(U16 u16KeepSetting)
{
    EN_LANGUAGE eLanguge = GET_OSD_MENU_LANGUAGE();

    /* Set entire database to 0 */
    if (!(RESTORE_KEEP_SYSTEM_PASSWORD& u16KeepSetting))
    {
        //memset(&stGenSetting, 0, RM_SIZE_GENSET);
        MApp_DataBase_RestoreDefaultVChip();
/*
        #ifdef ENABLE_BUTTON_LOCK
        stGenSetting.g_SysSetting.g_enKeyPadLock = EN_E5_KeyLock_Off;
        #endif
 */
    //add for initialize hotel menu's local key lock @chuxu 2012-08-08 @modify 2012-08-20
	#ifdef ENABLE_BUTTON_LOCK
		#if CUS_SMC_ENABLE_HOTEL_MODE
		if(stGenSetting.g_FactorySetting.HotelMenuHotelModeOperationEnable == ENABLE)
		{
			stGenSetting.g_SysSetting.g_enKeyPadLock = EN_E5_KeyLock_Off;
		}
		else
			stGenSetting.g_SysSetting.g_enKeyPadLock = EN_E5_KeyLock_Off;
        #else
        {
            stGenSetting.g_SysSetting.g_enKeyPadLock = EN_E5_KeyLock_Off;
        }
		#endif
    #endif

    }

    // keep OSD language
    SET_OSD_MENU_LANGUAGE(eLanguge);

    /* Restore default database version and check byte */
    stGenSetting.u8VersionCheck = DEFAULT_DATABASE_VERSION;
    stGenSetting.u8VersionCheckCom = DEFAULT_DATABASE_VERSION_COM;

    //*************************************************************************
    // Restore default scan menu setting
    //*************************************************************************
    MApp_DataBase_RestoreDefaultScanMenu();

    //*************************************************************************
    // Restore default SystemSetting
    //*************************************************************************
    MApp_DataBase_RestoreDefaultSystem(u16KeepSetting);

    //*************************************************************************
    // Restore default AudioSetting
    //*************************************************************************
    MApp_DataBase_RestoreDefaultAudio();

    //*************************************************************************
    // Restore default TimeSetting
    //*************************************************************************
    MApp_DataBase_RestoreDefaultTime();

    //*************************************************************************
    // Restore default TimeSetting
    //*************************************************************************
    MApp_DataBase_RestoreDefaultSSC();

  #if (ENABLE_NONLINEAR_CURVE)
    //*************************************************************************
    // Restore default NonLinerCurveSetting
    //*************************************************************************
    MApp_DataBase_RestoreDefaultNonLinearCurve();
  #if(BOE_VOLUME_CURVE)	
    MApp_DataBase_RestoreDefaultNonLinearVOLCurve();
  #endif
  #endif

  #if (ENABLE_SZ_FACTORY_OVER_SCAN_FUNCTION)
      //*************************************************************************
    // Restore default Overscan setting
    //*************************************************************************
    MApp_InitOverScanData();
  #endif

    //*************************************************************************
    // Restore default Block Settings
    //*************************************************************************
    App_DataBase_RestoreDefaultBlock();

	//*************************************************************************
	// Restore default Factory Settings
	//*************************************************************************
    MApp_DataBase_RestoreDefaultFactorySetting();

  #ifdef ENABLE_BT
    //*************************************************************************
    // Restore default BT Settings
    //*************************************************************************
     MApp_BT_RestoreDefaultTorrentSetupInfo();
  #endif

  #if (ENABLE_PIP)
    //*************************************************************************
    // Restore default PIP Settings
    //*************************************************************************
    if(IsPIPSupported())
    {
        MApp_DataBase_RestoreDefaultPIP();
    }
  #endif

    #if (ENABLE_LAST_MEMORY==1)&&(ENABLE_LAST_MEMORY_STORAGE_SAVE==1)
    //*************************************************************************
    // Restore default MM Last Memory Settings
    //*************************************************************************
    MApp_DataBase_RestoreDefaultMmLastMemorySetting();
    #endif

  #if ENABLE_DRM
        MApp_LoadDrmSetting();
  #endif

	MApp_DataBase_RestoreDefaultInstallGuide(DISABLE);

    //Clear UI display date
    g_u8TimeInfo_Flag = 0;
}

//*************************************************************************
//Function name:        MApp_DataBase_RestoreUserSettingDefaultValue
//Passing parameter:    none
//Return parameter:     none
//Description:          Restore user default value to data base
//*************************************************************************
void MApp_DataBase_RestoreUserSettingDefaultValue(U16 u16KeepSetting)
{
    EN_LANGUAGE eLanguge = GET_OSD_MENU_LANGUAGE();

    /* Set entire database to 0 */
    if (!(RESTORE_KEEP_SYSTEM_PASSWORD & u16KeepSetting))
    {
        //memset(&stGenSetting, 0, RM_SIZE_GENSET);
        MApp_DataBase_RestoreDefaultVChip();
		/*
        #ifdef ENABLE_BUTTON_LOCK
        stGenSetting.g_SysSetting.g_enKeyPadLock = EN_E5_KeyLock_Off;
        #endif
      */
	//add for initialize hotel menu's local key lock @chuxu 2012-08-08
	#ifdef ENABLE_BUTTON_LOCK
        #if CUS_SMC_ENABLE_HOTEL_MODE
        if(stGenSetting.g_FactorySetting.HotelMenuHotelModeOperationEnable == ENABLE)
        {
            stGenSetting.g_SysSetting.g_enKeyPadLock = EN_E5_KeyLock_Off;
        }
		else
			stGenSetting.g_SysSetting.g_enKeyPadLock = EN_E5_KeyLock_Off;
        #else
        {
            stGenSetting.g_SysSetting.g_enKeyPadLock = EN_E5_KeyLock_Off;
        }
        #endif
	#endif

    }
    // keep OSD language
    SET_OSD_MENU_LANGUAGE(eLanguge);

    //*************************************************************************
    // Restore default SystemSetting
    //*************************************************************************
    MApp_DataBase_RestoreDefaultSystem(u16KeepSetting);

    //*************************************************************************
    // Restore default AudioSetting
    //*************************************************************************
    MApp_DataBase_RestoreDefaultAudio();
}

//*************************************************************************
//Function name:        MApp_DataBase_RestoreUserSettingDefault
//Passing parameter:    u8RestoreMask
//Return parameter:     none
//Description:          Restore user default value
//*************************************************************************
void MApp_DataBase_RestoreUserSettingDefault(U8 u8RestoreMask)
{
    if(u8RestoreMask&RESTORE_USERSETTING)
    {
        //reset general user setting structure
        MApp_ResetGenUserSetting();

#if (ENABLE_CUS_UI_SPEC == FALSE) // DON'T reset channel database for CUS
    #if (ENABLE_DTV)
        msAPI_CM_ResetDTVDataManager();
    #endif
        msAPI_ATV_ResetATVDataManager();
#endif

    #if (EEPROM_DB_STORAGE != EEPROM_SAVE_ALL)
        //store to flash immediately
        MApp_DB_SaveDataBase();
    #endif
    }
}
extern void msAPI_Tuner_ChangeProgram(void);
extern void msAPI_ATV_Factory_CH_Preset(void);
void MApp_DataBase_RestoreFactoryDefault(U8 u8RestoreMask)
{
    if(u8RestoreMask&RESTORE_GENSETTING)
    {
        //reset general setting structure
        MApp_InitGenSetting();

    #if (EEPROM_DB_STORAGE == EEPROM_SAVE_NONE)
        //store to flash immediately
      #if GENSETTING_STORE_USE_NEW_METHOD
        msAPI_Flash_EraseGensettingBank();
      #else
        if(g_u16QuickGenSettingIdx == (QUICK_DB_GENST_NUM - 1))
        {
            msAPI_MIU_QuickGenSettingErase(QUICK_DB_GENSETTING_BANK, TRUE);
            msAPI_MIU_QuickGenSettingErase(QUICK_DB_GENSETTING_BANK+1, FALSE);
            g_u16QuickGenSettingIdx = 0;
        }
      #endif
	  MApp_DB_SaveNowGenSetting();
    #endif
    }

    if(u8RestoreMask&(RESTORE_DATABASE|RESTORE_DATABASE_EXCEPT_WB_ADC))
    {
        //reset 64K database
    #if (ENABLE_DTV)
        msAPI_CM_ResetDTVDataManager();
    #endif
       // msAPI_ATV_ResetATVDataManager();
		if (u8RestoreMask&RESTORE_DATABASE)
		{
		    #if BOE_AC_UPDATE_RESET_CHPRESET
			#if DEFAULT_SOURCE_TYPE
			UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_HDMI;
			#else
			UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_AV;//UI_INPUT_SOURCE_RGB;//minglin1113
			#endif
			#else
			UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_AV;//UI_INPUT_SOURCE_RGB;//minglin1113
			#endif
			//stGenSetting.g_FactorySetting.u8PowerOnMode = POWERON_MODE_ON;
#if BOE_FACTORY_CHANNEL
			//stGenSetting.g_SysSetting.uFactoryChannelFlag = 0;
			msAPI_InstallFactoryChannelTab(1);
			stGenSetting.g_SysSetting.uFactoryChannelFlag = TRUE;
		    stGenSetting.g_SysSetting.uFactoryChannelFlag2= TRUE;	
			msAPI_ATV_SetCurrentProgramNumber(msAPI_ATV_GetChannelMin()-1);//set first channel num					
			msAPI_Tuner_ChangeProgram();

#endif
			stGenSetting.g_FactorySetting.u8PowerOnMode = POWERON_MODE_ON;//POWERON_MODE_OFF;//2012-07-05 ZHIQIN CHANGE FOR SMC SPEC
#if 0
#if (ENABLE_NONLINEAR_CURVE)
			  //*************************************************************************
			  // Restore default NonLinerCurveSetting
			  //*************************************************************************
			  MApp_DataBase_RestoreDefaultNonLinearCurve();
#if(BOE_VOLUME_CURVE) 
			  MApp_DataBase_RestoreDefaultNonLinearVOLCurve();
#endif
#endif
#endif

			MApp_SaveSysSetting();
			MApp_SaveGenSetting();
			MApp_DB_SaveGenSetting();
		}
		else if (u8RestoreMask&RESTORE_DATABASE_EXCEPT_WB_ADC)
		{
		  UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_AV;//UI_INPUT_SOURCE_ATV;
#if BOE_FACTORY_CHANNEL
		  //stGenSetting.g_SysSetting.uFactoryChannelFlag = TRUE;
		  stGenSetting.g_SysSetting.uFactoryChannelFlag = FALSE;
          stGenSetting.g_SysSetting.uFactoryChannelFlag2= FALSE;
		  // msAPI_ATV_ResetATVDataManager();
		  //msAPI_Tuner_ChangeProgram();
#endif
		  MApp_SaveSysSetting();
		  MApp_SaveGenSetting();
		  MApp_DB_SaveGenSetting();
#if BOE_ACUPDADE_FACRESET_POWERON
		  MApp_RestoreAllModeTable(MAIN_WINDOW);
		  MApp_DB_ResetGenSettingExt(u8RestoreMask);
	#if (EEPROM_DB_STORAGE != EEPROM_SAVE_ALL)
		  //store to flash immediately
		  MApp_DB_SaveDataBase();
	#endif
		  msAPI_Power_PowerDown_EXEC();		   
#endif
		}

      
    #if (ENABLE_PIP)
        if(IsPIPEnable()&&(IsSrcTypeVga(SYS_INPUT_SOURCE_TYPE(SUB_WINDOW))&&IsSrcTypeYPbPr(SYS_INPUT_SOURCE_TYPE(SUB_WINDOW))))
        {
            MApp_RestoreAllModeTable(SUB_WINDOW);
        }
        else
    #endif
        {
            MApp_RestoreAllModeTable(MAIN_WINDOW);
        }
        MApp_DB_ResetGenSettingExt(u8RestoreMask);
    #if (EEPROM_DB_STORAGE != EEPROM_SAVE_ALL)
        //store to flash immediately
        MApp_DB_SaveDataBase();
    #endif
    }
}

#if ENABLE_CUS_RS232_FUNC
///////////////////////////////////////////////////////////////////////////////
 ///  public  MApp_DataBase_RestoreDefaultPictureSettingForRS232
 ///DESCRIPTION: -set pictutre setting for after change source by RS232 CMD
 ///    enDataInputSource:input source datatype
 ///    u8extraAct:
 ///    - 0: change source only, no extra action
///     - 1: when change source finished, do pre-setting job for next coming auto color procedure
///     - 2: when change source finished, do pre-setting job for next coming white balance alignment procedure
 ///  return
 ///
///   author  Creass.liu 07-08-2012 written
///////////////////////////////////////////////////////////////////////////////
void MApp_RestoreDefaultPictureSettingForRS232(E_DATA_INPUT_SOURCE enDataInputSource,U8 u8extraAct,EN_MS_PICTURE enFollowPicmodeValue)
{
    if(enDataInputSource >= DATA_INPUT_SOURCE_NUM)
    {
        return;
    }

    if(u8extraAct == 1) //for ADC
    {
        //do nothing;
    }
    else if(u8extraAct == 2) //for WB
    {
        memcpy(&stGenSettingExt.g_astVideo[enDataInputSource].astPicture[PICTURE_USER],
            &stGenSettingExt.g_astVideo[enDataInputSource].astPicture[enFollowPicmodeValue],
            sizeof(T_MS_PICTURE));
            stGenSettingExt.g_astVideo[enDataInputSource].astPicture[PICTURE_USER].u8Backlight = 100;
            stGenSettingExt.g_astVideo[enDataInputSource].astPicture[PICTURE_USER].bDBCStatus = DBC_STATUS_OFF;
            stGenSettingExt.g_astVideo[enDataInputSource].astPicture[PICTURE_USER].bDLCStatus = DLC_STATUS_OFF;
            stGenSettingExt.g_astVideo[enDataInputSource].ePicture = PICTURE_USER;
    }
    else if(u8extraAct == 3) //set all source's picture mode to vivid
    {
        U8 i;
        for( i = 0; i < DATA_INPUT_SOURCE_NUM; i++ )
        {
            MApp_InitVideoSetting((E_DATA_INPUT_SOURCE)i);
        }
    }
}
#endif
#if (ENABLE_UPDATE_MULTIPLEX_VIA_NIT)
void MApp_DataBase_RestoreDefaultNetworkInfo(void)
{
    U8 i,j;
    for(i=0;i<SI_MAX_NETWORK;i++)
    {
        stGenSetting.g_Network_TS.astNetworkInfo[i].u16Network_ID = 0;
        stGenSetting.g_Network_TS.astNetworkInfo[i].bInValidNetwork = FALSE;
        for (j=0;j<SI_MAX_TS_IN_NETWORK;j++)
        {
            memset(stGenSetting.g_Network_TS.astNetworkInfo[i].astTSRFList[j].au8RF, 0, sizeof(U8)*SI_MAX_FREQUENCY_LIST);
            stGenSetting.g_Network_TS.astNetworkInfo[i].astTSRFList[j].wTransportStream_ID = INVALID_TS_ID;
        }
        stGenSetting.g_Network_TS.astNetworkInfo[i].bNewTS = 0;
        stGenSetting.g_Network_TS.astNetworkInfo[i].bNewService = 0;
    }
}
#endif

#if ENABLE_CI && ENABLE_CI_PLUS
void MApp_DataBase_RestoreDefaultCI(void)
{
    memset((void *)&stGenSetting.g_CIKeySetting, 0, sizeof(MS_CI_SETTING));
}
#endif

#if (ENABLE_LAST_MEMORY==1)&&(ENABLE_LAST_MEMORY_STORAGE_SAVE==1)
void MApp_DataBase_RestoreDefaultMmLastMemorySetting(void)
{
    memset((void *)&stGenSetting.g_MmLastMemorySetting.MmLastMemorySettignCS, 0, sizeof(MS_MM_LASTMEMORY_SETTING));
}
#endif

#undef MAPP_RESTORETODEFAULT_C
