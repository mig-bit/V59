////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef MSAPI_TIMER_H
#define MSAPI_TIMER_H


//******************************************************************************
//              Function prototypes
//******************************************************************************
#ifdef MSAPI_TIMER_C
#define INTERFACE
#else
#define INTERFACE extern
#endif
#include "datatype.h"
//custom control
#define DELAY_FOR_ENTERING_MUTE     150
#define DELAY_FOR_LEAVING_MUTE      10
#define DELAY_FOR_STABLE_VIDEO      500
#define DELAY_FOR_STABLE_TUNER      700
#define DELAY_FOR_STABLE_SIF        500
#define DELAY_FOR_STABLE_MPEG       1500
#define DELAY_FOR_CHANNELCHANGE       1500

INTERFACE BOOLEAN msAPI_Timer_IsSystemTimeValid(void);
INTERFACE void msAPI_Timer_DisableSystemTime(void);
INTERFACE void msAPI_Timer_SyncToPmRTC(void);

INTERFACE U32 msAPI_Timer_GetTime0(void); // tick counter of timer 0
INTERFACE void msAPI_Timer_Delayms(U32 u32DelayTime); //unit = ms
INTERFACE U32 msAPI_Timer_GetDownTimer0(void);
INTERFACE void msAPI_Timer_SetDownTimer0(U32 u32Timer);
INTERFACE U32 msAPI_Timer_GetSystemTime(void);
INTERFACE S32 msAPI_Timer_GetOffsetTime(void);
INTERFACE U32 msAPI_Timer_GetWakeupTime(void);
INTERFACE void msAPI_Timer_SetSystemTime(U32 u32SystemTime);
INTERFACE void msAPI_Timer_SetOffsetTime(S32 s32OffsetTime);
INTERFACE void msAPI_Timer_SetWakeupTime(U32 u32Time);
INTERFACE U32 msAPI_Timer_DiffTime(U32 u32Timer, U32 u32TaskTimer); //unit = tick
INTERFACE U32 msAPI_Timer_DiffTimeFromNow(U32 u32TaskTimer);

INTERFACE S32 msAPI_Timer_Load_OffsetTime(void);

//WDT
INTERFACE void msAPI_Timer_ResetWDT(void);
//RTC
INTERFACE void msAPI_Timer_SetRTCWakeUpTime(U32 u32SystemTime); //unit = sec
INTERFACE U32 msAPI_Timer_GetRTCWakeUpTime(void); //unit = sec
INTERFACE void msAPI_Timer_EnableRTCWakeUp(BOOLEAN bEnable);
INTERFACE U32 msAPI_Timer_GetRTCSystemTime(void);
INTERFACE void msAPI_Timer_SetTimeOfChange(U32 u32TimeOfChg);
INTERFACE void msAPI_Timer_SetNextTimeOffset(S32 s32OffsetTime);
#undef INTERFACE

#endif

