////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef MAPP_CHAR_TABLE_H
#define MAPP_CHAR_TABLE_H

/********************************************************************************/
/*                           Macro                                              */
/********************************************************************************/
#ifdef MAPP_CHAR_TABLE_C
#define INTERFACE
#else
#define INTERFACE extern
#endif

/********************************************************************************/
/*                           Enum                                               */
/********************************************************************************/
typedef enum
{
    ISO_6937 = 0x0,
    ISO_8859_01,
    ISO_8859_02,
    ISO_8859_03,
    ISO_8859_04,
    ISO_8859_05,
    ISO_8859_06,
    ISO_8859_07,
    ISO_8859_08,
    ISO_8859_09,
    ISO_8859_10,
    ISO_8859_11,
    ISO_8859_13,
    ISO_8859_14,
    ISO_8859_15,
    #if 0
    ISO_8859_16,
    #endif
    WINDOWS_DEFAULT = 0x40,
    WINDOWS_CP874,
    WINDOWS_CP1250,
    WINDOWS_CP1251,
    WINDOWS_CP1252,
    WINDOWS_CP1253,
    WINDOWS_CP1254,
    WINDOWS_CP1255,
    WINDOWS_CP1256,
    WINDOWS_CP1257,
    WINDOWS_CP1258,
    WINDOWS_CROATIAN_MAC,
    UNSUPPORT_CHAR_TABLE = 0xFF
} EN_CHARACTER_CODE_TABLE;

#define REMOVE_NONE             0x0000
#define REMOVE_00AD_SOFT_HYPHEN 0x0001

/********************************************************************************/
/*                           Function prototypes                                */
/********************************************************************************/
INTERFACE U16 MApp_CharTable_MappingDVBTextToUCS2(U8 *pu8Str, U16 *pu16Str, U16 srcByteLen, U16 dstWideCharLen, U16 filterCtrl);
INTERFACE U16 MApp_CharTable_MappingIsoToUCS2(EN_CHARACTER_CODE_TABLE enTable, U8 *pu8Str, U16 *pu16Str, U16 u16SrcLen, U16 u16DestLen);
#if ENABLE_DMP
INTERFACE U16 MApp_CharTable_MappingKor2Unicode(U16 u16Korcode);
INTERFACE U16 MApp_Transfer2Unicode(U16 u16Code);
#endif
INTERFACE U16 MApp_CharTable_MappingCharToUCS2(EN_CHARACTER_CODE_TABLE enTable, U8 u8Str);

#undef INTERFACE
#endif  /*MAPP_CHAR_TABLE_H*/
