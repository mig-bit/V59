////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef MAPP_SIGNAL_MONITOR_H
#define MAPP_SIGNAL_MONITOR_H

#include "datatype.h"

#define SWWDT           0

#ifdef MAPP_SIGNAL_MONITOR_C
#define INTERFACE
#else
#define INTERFACE extern
#endif

typedef enum
{
    SIGNAL_UNKNOWN,
    SIGNAL_LOCK,
    SIGNAL_UNLOCK
} EN_SIGNAL_LOCK_STATUS;

typedef enum
{
    FRONTEND_UNKNOWN,
    FRONTEND_LOCK,
    FRONTEND_UNLOCK
} EN_FRONTEND_LOCK_STATUS;
INTERFACE EN_FRONTEND_LOCK_STATUS enFrotEndLockStatus;

INTERFACE BOOLEAN fEnableSignalMonitor;
INTERFACE U32 u32ChkTry2ChgMpeg2Time;

INTERFACE void MApp_SignalMonitor_Init(void);
INTERFACE void MApp_SignalMonitor(void);
#if ENABLE_DTV
INTERFACE void MApp_AudioMuteMonitor(void);
#endif
INTERFACE void MApp_Set_Audio_Mute_Timer(BOOLEAN bStartTimer);
#if SWWDT
INTERFACE void MApp_Monitor_CoOperators(void);
#endif

INTERFACE EN_SIGNAL_LOCK_STATUS MApp_GetSignalStatus(void);
INTERFACE EN_SIGNAL_LOCK_STATUS MApp_GetSignalStatus_UnCheckMHEG5(void);
INTERFACE BOOLEAN MApp_Scramble_GetCurStatus(void);

#undef INTERFACE
#endif
