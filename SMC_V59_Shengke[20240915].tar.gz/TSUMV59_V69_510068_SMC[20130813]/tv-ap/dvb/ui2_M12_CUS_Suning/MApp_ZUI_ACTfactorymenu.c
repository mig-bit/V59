////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#define MAPP_ZUI_ACTFACTORYMENU_C
#define _ZUI_INTERNAL_INSIDE_ //NOTE: for ZUI internal


//-------------------------------------------------------------------------------------------------
// Include Files
//-------------------------------------------------------------------------------------------------
#include <string.h>
#include "Board.h"
#include "datatype.h"
#include "MsCommon.h"
#include "apiXC.h"
#include "apiXC_Adc.h"
#include "apiAUDIO.h"

#include "MApp_ZUI_Main.h"
#include "MApp_ZUI_APIcommon.h"
#include "MApp_ZUI_APIstrings.h"
#include "MApp_ZUI_APIwindow.h"
#include "ZUI_tables_h.inl"
#include "MApp_ZUI_APIgdi.h"
#include "MApp_ZUI_APIcontrols.h"
#include "MApp_GlobalSettingSt.h"
#include "MApp_GlobalSettingSt_Common.h"/////////////////

#include "MApp_ZUI_ACTmainpage.h"
#include "MApp_ZUI_ACTeffect.h"
#include "OSDcp_String_EnumIndex.h"
#include "ZUI_exefunc.h"
#include "MApp_OSDPage_Main.h"

#include "MApp_ZUI_ACTfactorymenu.h"

#include "MApp_UiMenuDef.h"
#include "SysInit.h"
#include "MApp_ChannelChange.h"
#include "MApp_InputSource.h"
#include "MApp_ZUI_ACTglobal.h"
#include "MApp_CustomerInfoInclude.h"
#include "MApp_SaveData.h"
#include "apiXC_Sys.h"
#include "MApp_Version.h"
#include "MApp_ZUI_ACTmenufunc.h"
#include "MApp_PCMode.h"
#include "apiXC_Ace.h"
#include "drvPQ.h"
#include "MApp_XC_PQ.h"
#include "drvAVD.h"
#include"msAPI_VD.h"
#include "IF_Demodulator.h"
#include "MApp_ATVProc.h"

//cus_xm zb 2012-6-15 add for load hdcp data
#if (HDCP_KEY_TYPE==HDCP_KEY_IN_DB)
#include "MApp_DataBase.h"
#include "drvPWM.h"
#endif

#include "msAPI_Video.h"
#include "MApp_MVDMode.h"
#include "MApp_Scaler.h"
#include "msAPI_MIU.h"
#include "MApp_GlobalFunction.h"
#include "drvUART.h"
#include "drvPWM.h"// CUS_XM Gary 20120611 add for backlight adjust
#include "MApp_ZUI_ACTmenudlgfunc.h"
#if (ENABLE_SZ_FACTORY_OVER_SCAN_FUNCTION)
#include"apiXC_Cus.h"
#include"MApp_ZUI_ACTmenufunc.h"
#endif

#if ENABLE_AUTOTEST
#include "autotest.h"
#endif
#if ENABLE_PVR
#include"MApp_Record.h"
#include "MApp_UiPvr.h"
#endif
#if( ENABLE_USB_DOWNLOAD_BIN )
#include "MApp_USBDownload.h"
#include "mapp_swupdate.h"
#include "msAPI_Timer.h"
#endif
#include "MApp_MultiTasks.h"
#include "msAPI_ChProc.h"
#include "MApp_TV.h"
#include "MApp_ChannelList.h"
#include "msAPI_Timer.h"
#include "mapp_mplayer.h"

#include "drvUrsa6M30.h"
#if BOE_USB_UPGRADE_FACTROY//minglin1206
#include "MApp_TopStateMachine.h"
#include "MApp_USBDownload.h"
#include "MApp_DMP_Main.h"
#include "drvUSB.h"
#include "MApp_ZUI_ACTmainpage.h"

extern BOOLEAN MDrv_UsbDeviceConnect(void);
extern BOOLEAN MDrv_UsbDeviceConnect_Port2(void);
extern LPTSTR MApp_ZUI_ACT_GetAppDynamicText(HWND hwnd);
extern void MApp_ZUI_SwUpdate_ProgressBar(U8 percent);
extern U8 MDrv_USBGetPortEnableStatus(void);
extern void msAPI_BLoader_Reboot(void);
extern void MDrv_USBSetPortAutoSwitchStatus(BOOLEAN bEnable);
extern U16 GetFlashChecksum(void);
extern U8 _u8USBDownloadStatus; 
#endif

#ifdef ENABLE_CUS_FACTORY_ATV_CH_PRSET
extern void msAPI_Tuner_ChangeProgram(void);
#endif
#if ENABLE_SZ_FACTORY_USB_SAVE_MAP_FUNCTION
#include "Utl.h"
#include "IOUtil.h"
#include "msAPI_FCtrl.h"
#include "mw_usbdownload.h"
#include "MApp_ZUI_ACTdmp.h"
#define H_MSG(x)  x
U8 u8SubDigitCount;
U8 u8MainDigitCount;
U32 u32SubBankValue;
U32 u32MainBankValue;
static BOOLEAN Dflag = FALSE;
static BOOLEAN ResultFlag = FALSE;
static BOOLEAN g_DatabaseSaveResult;
static U32 MainBank;
static U32 SubBank;
BOOLEAN AllBank = FALSE;
static BOOLEAN LoadNewfile=FALSE;
static BOOLEAN LoadScript = FALSE;

extern void msAPI_Timer_Delayms(U32 u32DelayTime);
extern BOOLEAN MApp_UsbSaveData_SearchFileInRoot(U8* pu8FileName, FileEntry* pFileEntry);
#endif

#if CUS_SMC_ENABLE_HOTEL_MODE
#include <MApp_RestoreToDefault.h>
#include <MApp_XC_PQ.h>
#include <msAPI_Flash.h>

#include <msAPI_ATVSystem.h>
#include <MApp_ZUI_GlobalFunction.h>
#endif
#include "MApp_DMP_Main.h"

static U8 u8Capturelogo;
static U8 u8CapturelogoNG;
#define LOG_FACTORYMENU_SHOWITEM                    1 // Steven.Xu add 2010-08-25 Change Dislpay Factorymenu Mode
#if ENABLE_FACTORY_DRC
static BOOL BDrcEnable=0;
static U8 BDrcValue=0x10;
#endif
#if ENABLE_FACTORY_GAMMA
static BOOL GammaEnable=0;
#endif
#if (PADS_PWM1_MODE != Unknown_pad_mux)
static U16 PwmPeriod=PWM0_PERIOD;
static U16 PwmDiv=PWM0_DIV;
static U8 Pwmduty;
#endif
typedef struct _FACTORY_BAR_INFO
{
    HWND pre_item;
    HWND cur_item;
} FACTORY_BAR_INFO;

static FACTORY_BAR_INFO _eFactoryBarInfo;
#if ENABLE_AUTO_DQS_Factory

typedef enum _BIST_TEST_UI
{
    EN_BIST_TEST_UI_START,
    EN_BIST_TEST_UI_PROCESSING,
    EN_BIST_TEST_UI_END,
} BIST_TEST_UI;

static BIST_TEST_UI _BIST_TEST_MODE;
#define FACTORY_MENU_CURRENT_TEXT_DISABLE_COLOR     0xFFFF0000
#endif

#if ENABLE_CUS_AUTO_SLEEP_MODE
extern void _MApp_ZUI_ACT_GetAutosleepString(LPTSTR str);
#endif
/////////////////////////////////////////////////////////////////////

typedef enum _FACTORY_MENU_PAGE
{
    EN_FACTORY_PAGE_ROOT,
    EN_FACTORY_PAGE_ADC_ADJUST,
    EN_FACTORY_PAGE_PICTURE_MODE,
    EN_FACTORY_PAGE_WHITE_BALANCE,
    EN_FACTORY_PAGE_SSC,
    EN_FACTORY_PAGE_SPECIAL_SET,
    EN_FACTORY_PAGE_VIF,
    EN_FACTORY_PAGE_VIF1,
    EN_FACTORY_PAGE_VIF2,
    EN_FACTORY_PAGE_VIF3,
    EN_FACTORY_PAGE_QMAP_PAGE,
    EN_FACTORY_PAGE_SW_INFO_PAGE,
#if ENABLE_AUTOTEST
    EN_FACTORY_PAGE_BMTEST_PAGE,
#endif
#if ENABLE_AUTO_DQS_Factory
    EN_FACTORY_PAGE_BIST_TEST,
#endif
    #if (ENABLE_PIP)
    EN_FACTORY_PAGE_PIP_POP,
    #endif
    EN_FACTORY_PAGE_UART_DBG,
    EN_FACTORY_PAGE_PEQ,
#if (ENABLE_SZ_FACTORY_OVER_SCAN_FUNCTION)
    EN_FACTORY_PAGE_OVERSCAN,
#endif
#if ENABLE_PICTURE_NONLINEAR_CURVE
      EN_FACTORY_PAGE_NONLINEAR_CURVE,
      EN_FACTORY_PAGE_BRIGHTNESS_CURVE,
      EN_FACTORY_PAGE_CONTRAST_CURVE,
      EN_FACTORY_PAGE_SATURATION_CURVE,
      EN_FACTORY_PAGE_HUE_CURVE,
      EN_FACTORY_PAGE_SHARPNESS_CURVE,
      EN_FACTORY_PAGE_VOLUME_CURVE,
 #endif
      EN_FACTORY_RESTORE_DEFAULT,
	  EN_FACTORY_RESTORE_DEFAULT_ALL,
 #if (ENABLE_FACTORY_PANEL_SEL)
      EN_FACTORY_PAGE_PANEL_SELECTION,
 #endif

 #if  ENABLE_SZ_FACTORY_USB_SAVE_MAP_FUNCTION
      EN_FACTORY_PAGE_REGISTER_MAP,
 #endif
      EN_FACTORY_PAGE_CUSMENU,
      EN_FACTORY_PAGE_CUSCSMMENU,
 #if  CUS_SMC_ENABLE_HOTEL_MODE
      EN_HOTEL_MENU_PAGE,
 #endif
      EN_FACTORY_PAGE_VCOM,//MIG ADD ON 2019 0325
} FACTORY_MENU_PAGE;

#define PEQ_FO_MIN 100
#define PEQ_FO_MAX 16000
#define PEQ_FO_COARSE_STEP 100
#define PEQ_FO_FINE_STEP 1
#define PEQ_GAIN_MIN 0
#define PEQ_GAIN_MAX 240
#define PEQ_GAIN_STEP 1
#define PEQ_Q_MIN 5
#define PEQ_Q_MAX 160
#define PEQ_Q_STEP 1

static FACTORY_MENU_PAGE _eFactoryMenuPage;

static void _MApp_ZUI_ACT_FactoryMenuInitPage(FACTORY_MENU_PAGE page);
static U8 _u8IPNumber;
static U8 _u8IPIndex;
static U8 uart_tmp;
typedef enum
{
    MS_UART_TYPE_MIN,
    MS_UART_TYPE_HK = MS_UART_TYPE_MIN,
    MS_UART_TYPE_AEON,
    MS_UART_TYPE_VDEC,
    MS_UART_TYPE_NONE,
    MS_UART_TYPE_MAX = MS_UART_TYPE_NONE
} EN_MS_UART_TYPE;
#if ENABLE_VD_PACH_IN_CHINA
#define VIF_KP_KI_ADJUST_NUM 7
#define AFEC_A0_A1_ADJUST_NUM 6
static U16 VIF_KP_KI_DATA[VIF_KP_KI_ADJUST_NUM]=
{
    0x0104,0x0205,0x0306,0x0407,0x0508,0x0609,0x070A,
};
static U16 AFEC_A0_A1_DATA[AFEC_A0_A1_ADJUST_NUM]=
{
    0xBC6A,0xAE5E,0x9A35,0x9020,0x8204,0x1020,
};

#endif
/////////////////////////////////////////////////////////////////////

static const char SWVersionName[]      = _CODE_MAIN_VERSION_;
static const char SWCompileDate[]      = {_CODE_DATE_};
static const char SWCompileTime[]      = {_CODE_TIME_};

static const char SWBrandName[]      = CUS_BRAND_NAME;
static const char SWMainMCUVer[]      = CUS_MAIN_MCU_VER;
static const char SWBootLoaderVer[]      = CUS_BOOT_LOADER_VER;
#if !ENABLE_6M30_3D_PROCESS
static const char SWSubMCUVer[]      = CUS_SUB_MCU_VER;
#endif
static const char SWEEPROMVer[]      = CUS_EEPROM_VER;

static const char SWModeName[]      = CUS_MODEL_NAME;
static const char SWScalerType[]      = CUS_SCALER_TYPE;
static const char SWPanelType[]      = CUS_PANEL_TYPE_NAME;

/////////////////////////////////////////////////////////////////////

static EN_OSDPAGE_STATE _enTargetOSDPageState;

static U16 _u16ScalerAdjLaunchKeys;

extern BOOLEAN _MApp_ZUI_API_AllocateVarData(void);
extern BOOLEAN _MApp_ZUI_API_WindowProcOnIdle(void);
//////////////////////////////////////////////////////////////////////
//hdx
#if 0 /*Creass.liu at 2012-06-07*/
static  HWND _ZUI_TBLSEG _FactoryCsmRsHwndList[]=
{
    HWND_CSM_RS232,
//    HWND_CSM_TV_REGION,
};
#endif
//hdx----

static  HWND _ZUI_TBLSEG _FactoryMenuItemHwndList[]=
{
    HWND_FACTORY_MENU_ITEM0,
    HWND_FACTORY_MENU_ITEM1,
    HWND_FACTORY_MENU_ITEM2,
    HWND_FACTORY_MENU_ITEM3,
    HWND_FACTORY_MENU_ITEM4,
    HWND_FACTORY_MENU_ITEM5,
    HWND_FACTORY_MENU_ITEM6,
    HWND_FACTORY_MENU_ITEM7,
    HWND_FACTORY_MENU_ITEM8,
    HWND_FACTORY_MENU_ITEM9,
    HWND_FACTORY_MENU_ITEM10,
    HWND_FACTORY_MENU_ITEM11,
    HWND_FACTORY_MENU_ITEM12,
    HWND_FACTORY_MENU_ITEM13,
    HWND_FACTORY_MENU_ITEM14,
    HWND_FACTORY_MENU_ITEM15,
};

static  HWND _ZUI_TBLSEG _FactoryMenuItemCUSHwndList[]=
{
    HWND_FACTORY_MENU_CUS_LIST_ITEM0_NAME,
    HWND_FACTORY_MENU_CUS_LIST_ITEM1_NAME,
    HWND_FACTORY_MENU_CUS_LIST_ITEM2_NAME,
    HWND_FACTORY_MENU_CUS_LIST_ITEM3_NAME,
    HWND_FACTORY_MENU_CUS_LIST_ITEM4_NAME,

    HWND_FACTORY_MENU_CUS_LIST_ITEM5_NAME,
    HWND_FACTORY_MENU_CUS_LIST_ITEM6_NAME,

    HWND_FACTORY_MENU_CUS_LIST_ITEM7_NAME,
    HWND_FACTORY_MENU_CUS_LIST_ITEM8_NAME,
    HWND_FACTORY_MENU_CUS_LIST_ITEM9_NAME,
    HWND_FACTORY_MENU_CUS_LIST_ITEM10_NAME,
    HWND_FACTORY_MENU_CUS_LIST_ITEM11_NAME,
    HWND_FACTORY_MENU_CUS_LIST_ITEM12_NAME,
    HWND_FACTORY_MENU_CUS_LIST_ITEM13_NAME,
    HWND_FACTORY_MENU_CUS_LIST_ITEM14_NAME,

    HWND_FACTORY_MENU_CUS_LIST_ITEM15_NAME,
    HWND_FACTORY_MENU_CUS_LIST_ITEM16_NAME,

    HWND_FACTORY_MENU_CUS_LIST_ITEM17_NAME,
    HWND_FACTORY_MENU_CUS_LIST_ITEM17_NAME_1,
    HWND_FACTORY_MENU_CUS_LIST_ITEM17_NAME_2,
    HWND_FACTORY_MENU_CUS_LIST_ITEM17_NAME_3,
    HWND_FACTORY_MENU_CUS_LIST_ITEM18_NAME,
    HWND_FACTORY_MENU_CUS_LIST_ITEM18_NAME_1,
    HWND_FACTORY_MENU_CUS_LIST_ITEM18_NAME_2,
    HWND_FACTORY_MENU_CUS_LIST_ITEM18_NAME_3,
    HWND_FACTORY_MENU_CUS_LIST_ITEM19_NAME,
    HWND_FACTORY_MENU_CUS_LIST_ITEM20_NAME,
    HWND_FACTORY_MENU_CUS_LIST_ITEM21_NAME,
    HWND_FACTORY_MENU_CUS_LIST_ITEM21_NAME_1,
    HWND_FACTORY_MENU_CUS_LIST_ITEM21_NAME_2,
    HWND_FACTORY_MENU_CUS_LIST_ITEM21_NAME_3,
    HWND_FACTORY_MENU_CUS_LIST_ITEM22_NAME,
    HWND_FACTORY_MENU_CUS_LIST_ITEM22_NAME_1,
    HWND_FACTORY_MENU_CUS_LIST_ITEM22_NAME_2,
    HWND_FACTORY_MENU_CUS_LIST_ITEM22_NAME_3,
    HWND_FACTORY_MENU_CUS_LIST_ITEM23_NAME,
    HWND_FACTORY_MENU_CUS_LIST_ITEM24_NAME,
    HWND_FACTORY_MENU_CUS_LIST_ITEM25_NAME,
    HWND_FACTORY_MENU_CUS_LIST_ITEM26_NAME,
    HWND_FACTORY_MENU_CUS_LIST_ITEM27_NAME,
    HWND_FACTORY_MENU_CUS_LIST_ITEM28_NAME,
    HWND_FACTORY_MENU_CUS_LIST_ITEM29_NAME,
    HWND_FACTORY_MENU_CUS_LIST_ITEM30_NAME,
};


//cus_xm:chuxu.su add at 2012-07-24  enter hotel mode
#if CUS_SMC_ENABLE_HOTEL_MODE
static  HWND _ZUI_TBLSEG _FactoryMenuItemHotelHwndList[]=
{
	HWND_HOTEL_MENU_BACKGROUND,
	HWND_HOTEL_MENU_ITEM_PAGE,
	HWND_HOTEL_MENU_ITEM,

	HWND_HOTEL_MENU_ITEM_HOTEL_MODE_OPERATION,
	HWND_HOTEL_MENU_ITEM_MAX_VOLUME_SETTING,
	HWND_HOTEL_MENU_ITEM_VOLUME_DEFAULT,
	HWND_HOTEL_MENU_ITEM_OSD_DISPLAY,
	HWND_HOTEL_MENU_ITEM_LOCAL_KEY_LOCK,
	HWND_HOTEL_MENU_ITEM_REMOTE_CONTROL_LOCK,
	HWND_HOTEL_MENU_ITEM_CHANNEL_DEFAULT,
	HWND_HOTEL_MENU_ITEM_INPUT_SOURCE_CHANGE,

	HWND_HOTEL_MENU_ITEM2,

	HWND_HOTEL_MENU_ITEM_USB_CLONE,
#if HOHEL_ENABLE_AQPQ_OPTION
	HWND_HOTEL_MENU_ITEM_AQ_PQ_RESTORE,
#endif
	HWND_HOTEL_MENU_ITEM_INSTALLATION,
#if HOHEL_ENABLE_SOURCE_KEY_OPTION
	HWND_HOTEL_MENU_ITEM_SOURCE_KEY_LOCK,
#endif
#if HOHEL_ENABLE_POWER_ON_OPTION
	HWND_HOTEL_MENU_ITEM_POWER_ON,
#endif
	
	HWND_HOTEL_MENU_ITEM_CAPTURE_LOGO,
	//HWND_HOTEL_MENU_ITEM_POWERON_LOGO,
	HWND_HOTEL_MENU_ITEM_DEFAULT_LANGUAGE,
	HWND_HOTEL_MENU_ITEM_PW_CHANGE,
	
	HWND_HOTEL_MENU_VOLUME_SUBPAGE,
	HWND_HOTEL_MENU_VOLUME_SUBPAGE_BG,
	HWND_HOTEL_MENU_VOLUME_SUBPAGE_BAR,
};
#endif


static  HWND _ZUI_TBLSEG _FactoryMenuItemHwndNameList[]=
{
    HWND_FACTORY_MENU_ITEM0_NAME,
    HWND_FACTORY_MENU_ITEM1_NAME,
    HWND_FACTORY_MENU_ITEM2_NAME,
    HWND_FACTORY_MENU_ITEM3_NAME,
    HWND_FACTORY_MENU_ITEM4_NAME,
    HWND_FACTORY_MENU_ITEM5_NAME,
    HWND_FACTORY_MENU_ITEM6_NAME,
    HWND_FACTORY_MENU_ITEM7_NAME,
    HWND_FACTORY_MENU_ITEM8_NAME,
    HWND_FACTORY_MENU_ITEM9_NAME,
    HWND_FACTORY_MENU_ITEM10_NAME,
    HWND_FACTORY_MENU_ITEM11_NAME,
    HWND_FACTORY_MENU_ITEM12_NAME,
    HWND_FACTORY_MENU_ITEM13_NAME,
    HWND_FACTORY_MENU_ITEM14_NAME,
    HWND_FACTORY_MENU_ITEM15_NAME,

};


static  HWND _ZUI_TBLSEG _FactoryMenuItemHwndValueList[]=
{
    HWND_FACTORY_MENU_ITEM0_VALUE,
    HWND_FACTORY_MENU_ITEM1_VALUE,
    HWND_FACTORY_MENU_ITEM2_VALUE,
    HWND_FACTORY_MENU_ITEM3_VALUE,
    HWND_FACTORY_MENU_ITEM4_VALUE,
    HWND_FACTORY_MENU_ITEM5_VALUE,
    HWND_FACTORY_MENU_ITEM6_VALUE,
    HWND_FACTORY_MENU_ITEM7_VALUE,
    HWND_FACTORY_MENU_ITEM8_VALUE,
    HWND_FACTORY_MENU_ITEM9_VALUE,
    HWND_FACTORY_MENU_ITEM10_VALUE,
    HWND_FACTORY_MENU_ITEM11_VALUE,
    HWND_FACTORY_MENU_ITEM12_VALUE,
    HWND_FACTORY_MENU_ITEM13_VALUE,
    HWND_FACTORY_MENU_ITEM14_VALUE,
    HWND_FACTORY_MENU_ITEM15_VALUE,

};

// xm_cus cms hand add by zb 2012-6-20
static  HWND _ZUI_TBLSEG _FactoryMenuItemCUSCSMHwndList[]=
{
    HWND_FACT_CSM_TITTLE,
    HWND_CSM_SET_TYPE,
    HWND_CSM_SET_TYPE_DT,
    HWND_CSM_PROD_CODE,
    HWND_CSM_PROD_CODE_DT,
    HWND_CSM_KEY,
    HWND_CSM_KEY_VALID,
    HWND_CSM_NVM_NAME,
    HWND_CSM_NVM_NAME_DT,
    HWND_CSM_SOFT_VERSION ,
    HWND_CSM_SOFT_VERSION_DT,
    HWND_CSM_RS232,
    HWND_CSM_TV_REGION,
};

//xm_cus add hdcp key is valid fun  by zb 2012-6-20

BOOL MApp_ZUI_ACT_isHdcpValid(void)
{

	int i;
	UINT8 j,cnt=0;
	UINT8 data[5];
	UINT8 compare[8] = {0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80};
	BOOL b_isHdcpValid = FALSE;
    MS_U8 u8HdcpKey[HDCP_KEY_SIZE];

#if (HDCP_KEY_TYPE==HDCP_KEY_IN_CODE)
    MS_U8 _u8HdcpKey[HDCP_KEY_SIZE] =
    {
       0x89,0x38,0xAE,0x0D,0xED,0x40,0xE6,0xBB,0xFA,0x4E,0xDE,0x51,0xFB,0x8E,0xD9,0xAA,
       0x34,0xA8,0xC4,0xEA,0xD8,0x6C,0xDC,0x5C,0x91,0x5C,0xB1,0xA6,0x13,0x2B,0x8B,0x8B,
       0xF7,0x46,0xCC,0x1C,0x88,0x20,0xA3,0x27,0x0E,0xE1,0x28,0x84,0x89,0x39,0xA3,0xE2,
       0x36,0x86,0xCE,0x67,0xEB,0xA0,0xF2,0x35,0x6B,0x86,0xF5,0x21,0x71,0x95,0x8A,0x77,
       0xA1,0x28,0x77,0x97,0xD3,0x7B,0xEF,0x5C,0x15,0x48,0xAA,0x9E,0x97,0x39,0xCD,0x98,
       0x40,0x5E,0x68,0x56,0x66,0xEF,0xC1,0x3C,0xE1,0x8F,0x2A,0x82,0xDE,0x8F,0x52,0xCC,
       0xA8,0x1F,0x37,0xD9,0xD4,0xC6,0x24,0x16,0x7E,0x42,0xFF,0x57,0xCD,0x6B,0xE0,0x86,
       0x00,0x1A,0xF1,0x19,0x5A,0xAF,0x37,0x97,0x86,0xBA,0x83,0x29,0xFE,0x41,0xA8,0xD5,
       0xF4,0x73,0x43,0x03,0x23,0x22,0xC5,0x28,0x96,0x9E,0x35,0x0D,0x67,0xA8,0x8B,0xDD,
       0x7A,0x89,0x38,0xE0,0x94,0xF0,0xFF,0xF5,0x8F,0xF3,0x4E,0x5C,0x82,0x09,0xF3,0x97,
       0xEB,0x01,0x52,0xEC,0xD8,0x98,0x5C,0x4F,0x43,0x2E,0xE7,0x9F,0xF5,0x85,0x6D,0x15,
       0xB1,0x83,0x20,0xF8,0x5E,0xD0,0x33,0x4F,0xF0,0xC1,0x8F,0x65,0x77,0x3D,0x31,0xB2,
       0xFB,0xA1,0x6E,0xCA,0xA6,0xD3,0xA2,0x35,0x1D,0x16,0x41,0xC3,0x89,0x86,0x98,0x78,
       0x8E,0x3E,0xC1,0x64,0x01,0x79,0x05,0x21,0x47,0xAF,0x6A,0x6F,0x5B,0xE1,0x4D,0x2B,
       0x2F,0xCC,0x18,0x8E,0x42,0xDC,0x9A,0xF8,0x3C,0xD0,0xD0,0x57,0x04,0xFB,0x14,0x42,
       0x8C,0x54,0x9D,0xA9,0x06,0xEB,0xE7,0x48,0xE2,0x29,0xEF,0x7E,0xFD,0xF6,0x45,0x12,
       0xAC,0xE4,0xBC,0x45,0x67,0xA3,0x9B,0x65,0xA1,0x0E,0xED,0x1A,0x84,0xAD,0x49,0x87,
       0xA2,0x77,0x3F,0x11,0xA7,0x1B,0xD1,0x7F,0x25,0x36,0x6c,0x6f,0xd3,0xdf,0x25,0xd0,
       0xFB,
    };
	memcpy(u8HdcpKey, _u8HdcpKey, HDCP_KEY_SIZE);
#elif (HDCP_KEY_TYPE==HDCP_KEY_IN_DB)  // readkey from db
	MApp_DB_LoadHDCP_KEY((MS_U8 *)u8HdcpKey);
#else
	msAPI_hdcpkeyBurstReadBytes(HDCP_KEY_ADDR, (MS_U8 *)&u8HdcpKey, HDCP_KEY_SIZE);
#endif

	b_isHdcpValid = FALSE;


	for (i=0;i<5;i++)
	{
		data[i] = u8HdcpKey[i];

		for(j=0; j<8; j++)
		{
			if (data[i] & compare[j])
			{
				cnt++;
			}
		}
	}

	if (cnt == 20)
	{
		b_isHdcpValid = TRUE;
		printf("HdmiTable_Init:check BKSV bit pass(cnt=%d)\n",cnt);
	}
	else
	{
		printf("HdmiTable_Init:check BKSV bit error(cnt=%d)\n",cnt);
	}

	return b_isHdcpValid;
}




static U8 _MApp_ZUI_ACT_FactoryMenuWindowMapToIndex(HWND hwnd)
{
    U8 i;
	if(g_bGotoCUSMenu ==0)
		{
    for (i = 0; i < COUNTOF(_FactoryMenuItemHwndList); i++)
    {
        if (hwnd == _FactoryMenuItemHwndList[i] ||
            MApp_ZUI_API_IsSuccessor(_FactoryMenuItemHwndList[i], hwnd))
        {
            return i;
        }
    }
}
else if(g_bGotoCUSMenu ==2)
{
    for (i = 0; i < COUNTOF(_FactoryMenuItemCUSHwndList); i++)
    {
        if (hwnd == _FactoryMenuItemCUSHwndList[i] ||
            MApp_ZUI_API_IsSuccessor(_FactoryMenuItemCUSHwndList[i], hwnd))
        {
            return i;
        }
    }

}
#if CUS_SMC_ENABLE_HOTEL_MODE
//cus_xm chuxu.su add for hotel menu 2012-07-24
	else if(g_bGotoCUSMenu ==3)
	{
	    for (i = 0; i < COUNTOF(_FactoryMenuItemHotelHwndList); i++)
	    {
	        if (hwnd == _FactoryMenuItemHotelHwndList[i] ||
	            MApp_ZUI_API_IsSuccessor(_FactoryMenuItemHotelHwndList[i], hwnd))
	        {
	            return i;
	        }
	    }

	}
#endif
//cus_xm zb add for CSM menu 2012-6-20
else if(g_bGotoCUSMenu ==1)
{
    for (i = 0; i < COUNTOF(_FactoryMenuItemCUSCSMHwndList); i++)
    {
        if (hwnd == _FactoryMenuItemCUSCSMHwndList[i] ||
            MApp_ZUI_API_IsSuccessor(_FactoryMenuItemCUSCSMHwndList[i], hwnd))
        {
            return i;
        }
    }

}
else
{
;
}

    return 0;
}

static HWND _MApp_ZUI_ACT_FactoryMenuIndexMapToWindow(U8 u8Index)
{

	if(g_bGotoCUSMenu == 1)						//add hdx 20120605
	{
	 if (u8Index >= COUNTOF(_FactoryMenuItemHwndList))
      		  return HWND_INVALID;
//    	return _FactoryCsmRsHwndList[u8Index]; 		//add
		return _FactoryMenuItemHwndList[u8Index];
	}
	else if(g_bGotoCUSMenu == 2)
		{
		 	 if (u8Index >= COUNTOF(_FactoryMenuItemCUSHwndList))
      				  return HWND_INVALID;
			return _FactoryMenuItemCUSHwndList[u8Index];
		}
#if CUS_SMC_ENABLE_HOTEL_MODE
	else if(g_bGotoCUSMenu == 3) //cus_xm chuxu.su add for hotel menu 2012-07-24
		{
		 	 if (u8Index >= COUNTOF(_FactoryMenuItemHotelHwndList))
      				  return HWND_INVALID;
			return _FactoryMenuItemHotelHwndList[u8Index];
		}
#endif
	else
	{
	  if (u8Index >= COUNTOF(_FactoryMenuItemHwndList))
       		 return HWND_INVALID;
	    return _FactoryMenuItemHwndList[u8Index];
	}

}

////////////////////////////////////////////////////////////////////

void MApp_ZUI_ACT_AppShowFactoryMenu(void)
{
    HWND wnd;
    RECT rect;
    E_OSD_ID osd_id = E_OSD_FACTORY_MENU;

    g_GUI_WindowList = GetWindowListOfOsdTable(osd_id);
    g_GUI_WinDrawStyleList = GetWindowStyleOfOsdTable(osd_id);
    g_GUI_WindowPositionList = GetWindowPositionOfOsdTable(osd_id);
#if ZUI_ENABLE_ALPHATABLE
    g_GUI_WinAlphaDataList = GetWindowAlphaDataOfOsdTable(osd_id);
#endif
    HWND_MAX = GetWndMaxOfOsdTable(osd_id);
    OSDPAGE_BLENDING_ENABLE = IsBlendingEnabledOfOsdTable(osd_id);
    OSDPAGE_BLENDING_VALUE = GetBlendingValueOfOsdTable(osd_id);

    if (!_MApp_ZUI_API_AllocateVarData())
    {
        ZUI_DBG_FAIL(printf("[ZUI]ALLOC\n"));
        ABORT();
        return;
    }

    RECT_SET(rect,
        ZUI_FACTORY_MENU_XSTART, ZUI_FACTORY_MENU_YSTART,
        ZUI_FACTORY_MENU_WIDTH, ZUI_FACTORY_MENU_HEIGHT);

    if (!MApp_ZUI_API_InitGDI(&rect))
    {
        ZUI_DBG_FAIL(printf("[ZUI]GDIINIT\n"));
        ABORT();
        return;
    }

    for (wnd = 0; wnd < HWND_MAX; wnd++)
    {
        //printf("create msg: %lu\n", (U32)wnd);
        MApp_ZUI_API_SendMessage(wnd, MSG_CREATE, 0);
    }
    _u8IPIndex = 0;
    _u8IPNumber = (U8)MDrv_PQ_GetIPNum(PQ_MAIN_WINDOW);
    //printf("------- Init _u8IPIndex [%bu] _u8IPNumber [%bu] --------\n", _u8IPIndex, _u8IPNumber);

    MApp_ZUI_API_ShowWindow(HWND_MAINFRAME, SW_SHOW);
    //MApp_ZUI_API_SetFocus(HWND_FACTORY_MENU_ITEM0);
    MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BG_TRANSPARENT, SW_HIDE);
    MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_INPUT_INFO, SW_HIDE);
    MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_HOT_KEY_HELP1, SW_HIDE);
    MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_HOT_KEY_HELP2, SW_HIDE);
    MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BAR_TRANS, SW_HIDE);
//add hdx//gary

	if(g_bGotoCUSMenu == 1)
    	{
//        printf("!!!!!!!g_bGotoCUSMenu");
        MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_LIST, SW_HIDE);
        MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_CUS_LIST, SW_HIDE);
        MApp_ZUI_API_ShowWindow(HWND_FACTORY_SW_INFO, SW_HIDE);
        MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BG_PANE, SW_HIDE);
        MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BOARD_INFO, SW_HIDE);
        MApp_ZUI_API_ShowWindow(HWND_FACT_CSM_BG_MENU, SW_SHOW);
#if CUS_SMC_ENABLE_HOTEL_MODE
		MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_BACKGROUND, SW_HIDE);//hide hotel menu
		MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM_PAGE, SW_HIDE);//hide hotel menu
		MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_VOLUME_SUBPAGE, SW_HIDE);//hide hotel menu
		MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_CLONE_CONFIRM_COMPLETE, SW_HIDE);//cus_xm zhihe  20120820 add for usb clone
		MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_CLONE_CONFIRM_WAITTING, SW_HIDE);//cus_xm zhihe  20120820 add for usb clone
		MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_CLONE_ERROR_MSGBOX,SW_HIDE);//add for hotel mode's usb clone @chuxu
		MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_CHANGE_PW,SW_HIDE);//add for hotel mode's usb clone @chuxu
#endif
	_MApp_ZUI_ACT_FactoryMenuInitPage(EN_FACTORY_PAGE_CUSCSMMENU);
    	}
	else if(g_bGotoCUSMenu == 2)
	{
	//CUS_XM:xue add for valid burnin ,if open burnin =off 2012-6-26
		#ifdef CUS_ENTER_FACTORY_MENU_DISABLE_BURN_IN		// CUS_XM Sea 20120728:
		if(stGenSetting.g_FactorySetting.fBuringMode)
		{
			stGenSetting.g_FactorySetting.fBuringMode = FALSE;
			MApp_MultiTasks_AdjustBurningMode(DISABLE);
			MApp_SaveFactorySetting();
		}
		#endif

// cus_xm gary 20120717 modify by refresh factory menu
		stGenSettingExt.g_AdcSetting[ADC_SET_VGA].u8AdcCalOK = 0xFF;
		stGenSettingExt.g_AdcSetting[ADC_SET_YPBPR_HD].u8AdcCalOK = 0xFF;
 		stGenSettingExt.g_AdcSetting[ADC_SET_YPBPR_SD].u8AdcCalOK = 0xFF;

		MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_LIST, SW_HIDE);
		MApp_ZUI_API_ShowWindow(HWND_FACT_CSM_BG_MENU, SW_HIDE);
		MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BG_PANE, SW_HIDE);

		MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BOARD_INFO, SW_HIDE);

#if CUS_SMC_ENABLE_HOTEL_MODE
		MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_BACKGROUND, SW_HIDE);//hide hotel menu
		MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM_PAGE, SW_HIDE);//hide hotel menu
		MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_VOLUME_SUBPAGE, SW_HIDE);//hide hotel menu
		MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_CLONE_CONFIRM_WAITTING, SW_HIDE);//cus_xm zhihe add for  usb clone 20120820
		MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_CLONE_CONFIRM_COMPLETE, SW_HIDE);//cus_xm zhihe add for  usb clone 20120820
		MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_CLONE_ERROR_MSGBOX,SW_HIDE);//add for hotel mode's usb clone @chuxu
		MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_CHANGE_PW,SW_HIDE);//add for hotel mode's usb clone @chuxu
#endif

		//MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BOARD_INFO, SW_HIDE);

		//MApp_ZUI_API_SetFocus(HWND_FACTORY_MENU_CUS_LIST_ITEM0_NAME);
	_MApp_ZUI_ACT_FactoryMenuInitPage(EN_FACTORY_PAGE_CUSMENU);
	}

#if CUS_SMC_ENABLE_HOTEL_MODE
	else if(g_bGotoCUSMenu == 3)//cus_xm:chuxu.su add at 2012-07-24  enter hotel mode
		{
			_MApp_ZUI_ACT_FactoryMenuInitPage(EN_HOTEL_MENU_PAGE);
		}
#endif

	else
		{
	      MApp_ZUI_API_ShowWindow(HWND_FACT_CSM_BG_MENU, SW_HIDE);
		MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_CUS_LIST, SW_HIDE);
	#if CUS_SMC_ENABLE_HOTEL_MODE
		MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_BACKGROUND, SW_HIDE);//hide hotel menu
		MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM_PAGE, SW_HIDE);//hide hotel menu
		MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_VOLUME_SUBPAGE, SW_HIDE);//hide hotel menu
		MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_CLONE_CONFIRM_WAITTING, SW_HIDE);//cus_xm zhihe add for  usb clone 20120820
		MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_CLONE_CONFIRM_COMPLETE, SW_HIDE);//cus_xm zhihe add for  usb clone 20120820
		MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_CLONE_ERROR_MSGBOX,SW_HIDE);//add for hotel mode's usb clone @chuxu
		MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_CHANGE_PW,SW_HIDE);//add for hotel mode's usb clone @chuxu
	#endif
		_MApp_ZUI_ACT_FactoryMenuInitPage(EN_FACTORY_PAGE_ROOT);
		}
   	MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_OPEN, E_ZUI_STATE_RUNNING);

}
		// CUS_XM Xue 20120721: modify factory reset undo PM issue

void Mapp_FactoryRCRST(void)
{
	printf("handle FactoryRC RST key/r/n");


    if(MApp_ZUI_ACT_ExecuteMenuCommonDialogAction(EN_EXE_FACTORY_SYSTEM_RESET))
    {
	EN_RET enRetVal;
	MApp_ZUI_ACT_ShutdownOSD();
	u8KeyCode = KEY_POWER;
	enRetVal =EXIT_GOTO_STANDBY;
	printf("factory reset OK");
    }
    else
    {
        printf("factory reset fail");
    }


}


//////////////////////////////////////////////////////////
// Key Handler
#if CUS_SMC_ENABLE_HOTEL_MODE
static void _MApp_ZUI_ACT_HotelPasswordHandler(VIRTUAL_KEY_CODE key)
{
    HWND hwnd = MApp_ZUI_API_GetFocus();
	#if(UI_SKIN_SEL==UI_SKIN_1366X768X565_HAIER_CN)  // CUS_xm zHIHE 20120807 modify
    if(HWND_MENU_LOCK_ENTER_PASSWORD == hwnd||
		HWND_MENU_LOCK_NEWPSW == hwnd||
		HWND_MENU_LOCK_CONFIMNEWPSW == hwnd
        ||HWND_MENU_LOCK_ENTER_PASSWORD_OPTION==hwnd
        ||HWND_MENU_LOCK_ENTER_PASSWORD_OPTION_1==hwnd
        ||HWND_MENU_LOCK_ENTER_PASSWORD_OPTION_2==hwnd
        ||HWND_MENU_LOCK_ENTER_PASSWORD_OPTION_3==hwnd
	)
	#else
	if(HWND_HOTEL_MENU_OLD_PW == hwnd||
		HWND_HOTEL_MENU_NEW_PW == hwnd ||
		HWND_HOTEL_MENU_CHECK_NEW_PW ==hwnd
	)
	#endif
    {
        printf("Position:%d\n",g_u8PasswordPosition);
        g_u8PasswordCount++;
        g_u8PasswordPosition++;
        g_u16Password = (g_u16Password<<4)|(key-VK_NUM_0);
        if (g_u8PasswordCount == PASSWORD_SIZE)
        {
            #if(UI_SKIN_SEL==UI_SKIN_1366X768X565_HAIER_CN)  // CUS_xm zHIHE 20120807 modify
			if(HWND_MENU_LOCK_ENTER_PASSWORD == hwnd||HWND_MENU_LOCK_ENTER_PASSWORD_OPTION_3==hwnd)
            #else
            if(HWND_HOTEL_MENU_OLD_PW == hwnd)
		    #endif
     //       MApp_ZUI_API_IsSuccessor(HWND_MENU_LOCK_CHANGEPWSUBPAGE_ITEM_OLDPW, hwnd))
            {
				U16 u16SuperPassword = 0;
				U16 u16SuperPassword_1 = 0;
				U32 u32SuperPassword_Macro = SUPER_PASSWORD;
				U32 u32SuperPassword_Macro_1 = SUPER_PASSWORD_1;
				u16SuperPassword = (u32SuperPassword_Macro/1000)<<12;
				u16SuperPassword = u16SuperPassword | (((u32SuperPassword_Macro%1000)/100)<<8);
				u16SuperPassword = u16SuperPassword | (((u32SuperPassword_Macro%100)/10)<<4);
				u16SuperPassword = u16SuperPassword | ((u32SuperPassword_Macro%10));
				
				u16SuperPassword_1= (u32SuperPassword_Macro_1/1000)<<12;
				u16SuperPassword_1= u16SuperPassword_1| (((u32SuperPassword_Macro_1%1000)/100)<<8);
				u16SuperPassword_1= u16SuperPassword_1| (((u32SuperPassword_Macro_1%100)/10)<<4);
				u16SuperPassword_1= u16SuperPassword_1| ((u32SuperPassword_Macro_1%10));
				
				if ((g_u16Password == stGenSetting.g_VChipSetting.u16VChipPassword) ||
					(g_u16Password == u16SuperPassword) || (g_u16Password == u16SuperPassword_1))
                {
                    #if(UI_SKIN_SEL==UI_SKIN_1366X768X565_HAIER_CN)  // CUS_xm zHIHE 20120807 modify
					if(HWND_MENU_LOCK_ENTER_PASSWORD == hwnd||HWND_MENU_LOCK_ENTER_PASSWORD_OPTION_3==hwnd)
                    #else
                    if(HWND_HOTEL_MENU_OLD_PW == hwnd )
				    #endif
                    {
                        g_u8PasswordPosition = 0;
                        MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_NEW_PW,ENABLE);
                        MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_CHECK_NEW_PW,ENABLE);
						MApp_ZUI_API_SetFocus(HWND_HOTEL_MENU_NEW_PW);
                    }
                    else //HWND_MENU_LOCK_CHANGEPWSUBPAGE_ITEM_OLDPW
                    {

           //             MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_CHANGEPWSUBPAGE_ITEM_OLDPW, FALSE);
                   //     MApp_ZUI_API_SetFocus(HWND_MENU_LOCK_CHANGEPWSUBPAGE_PW1_1);
                    }
                }
                else
                {
                    g_u8PasswordPosition = 0;
					#if(UI_SKIN_SEL==UI_SKIN_1366X768X565_HAIER_CN)  // CUS_xm zHIHE 20120807 modify
					if(HWND_MENU_LOCK_ENTER_PASSWORD == hwnd||HWND_MENU_LOCK_ENTER_PASSWORD_OPTION_3==hwnd)
					 {
                        MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_PAGE_CHECKPWD_ERROR_MSG, SW_SHOW);
                        MApp_ZUI_API_SetTimer(HWND_MENU_LOCK_PAGE_CHECKPWD_ERROR_MSG,1, 3000);
                        g_u8PasswordPosition = 4;
    					MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_LOCK_ENTER_PASSWORD);
						MApp_ZUI_API_SetFocus(HWND_MENU_LOCK_ENTER_PASSWORD);
                    }
                    #else
                    if(HWND_HOTEL_MENU_OLD_PW == hwnd )

                    {
                        g_u8PasswordPosition = 4;
    					MApp_ZUI_API_InvalidateAllSuccessors(HWND_HOTEL_MENU_OLD_PW);
                    }
					#endif
                    else
                    {
					;
					}
                }
            }
            else if(HWND_HOTEL_MENU_NEW_PW== hwnd)
            {
                g_u16PasswordTemp = g_u16Password;
                MApp_ZUI_API_SetFocus(HWND_HOTEL_MENU_CHECK_NEW_PW);

            }
            else if(HWND_HOTEL_MENU_CHECK_NEW_PW== hwnd)
            {
               if(g_u16PasswordTemp == g_u16Password)
               	{
				stGenSetting.g_VChipSetting.u16VChipPassword = g_u16Password;
				g_u8PasswordPosition = 0;
				MApp_SaveVshipSetting();
				MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_CHANGE_PW,SW_HIDE);
				MApp_ZUI_API_SetFocus(HWND_HOTEL_MENU_ITEM_PW_CHANGE);
               	}
			   else
			   	{
				   g_u8PasswordPosition = 4;
				   MApp_ZUI_API_InvalidateAllSuccessors(HWND_HOTEL_MENU_CHECK_NEW_PW);
			    }
            }
            g_u16Password = 0;
            g_u8PasswordCount = 0;
        }
        else
        {;
        }
		MApp_ZUI_API_InvalidateAllSuccessors(hwnd);
		MApp_ZUI_API_ResetTimer(HWND_HOTEL_MENU_CHANGE_PW,1);
}
}
#endif
BOOLEAN MApp_ZUI_ACT_HandleFactoryMenuKey(VIRTUAL_KEY_CODE key)
{
    //note: this function will be called in running state

    //reset timer if any key
    //MApp_ZUI_API_ResetTimer(HWND_AUDLANG_LIST_PANE, 0);
#if  ENABLE_SZ_FACTORY_USB_SAVE_MAP_FUNCTION
    ResultFlag = FALSE;
#endif
    switch(key)
    {
    #if CUS_SMC_ENABLE_HOTEL_MODE
        case VK_UP:
		case VK_DOWN:
			if(MApp_ZUI_API_GetFocus() ==HWND_HOTEL_MENU_OLD_PW)
				{
				MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_NEW_PW,DISABLE);
				MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_CHECK_NEW_PW,DISABLE);
				}
			break;
	#endif
        case VK_EXIT:
		   #if CUS_SMC_ENABLE_HOTEL_MODE
	        if((g_bGotoCUSMenu == 3)&&(stGenSetting.g_FactorySetting.HotelMenuUSBCloneUsedFlag==TRUE))
				stGenSetting.g_FactorySetting.HotelMenuUSBCloneUsedFlag=FALSE;
			else if((g_bGotoCUSMenu == 3)&&(MApp_ZUI_API_GetFocus() != HWND_HOTEL_MENU_VOLUME_SUBPAGE_BAR))
				stGenSetting.g_FactorySetting.HotelMenuUSBCloneMode = HotelMenuUsbCloneModeOFF;//reset usb clone mode
				MApp_SaveFactorySetting();
		   #endif
            MApp_ZUI_ACT_ExecuteFactoryMenuAction(EN_EXE_CLOSE_CURRENT_OSD);
            return TRUE;
        case VK_POWER:
            if(g_bGotoCUSMenu == 1) //cus_xm zb 2012-7-10 add for  power off when show CSM Menu
            {
                printf("\npower off when show csm menu !");
                MApp_ZUI_ACT_ExecuteFactoryMenuAction(EN_EXE_POWEROFF);
                return TRUE;
            }
            else
            {
                MApp_ZUI_ACT_ExecuteFactoryMenuAction(EN_EXE_CLOSE_CURRENT_OSD);//cus_xm  gary 20120606 modify by factory menu exit function //EN_EXE_POWEROFF
                return TRUE;
            }

         case VK_MENU:
            if(((UI_SKIN_SEL == UI_SKIN_1366X768X565_SMC_India)||(UI_SKIN_SEL==UI_SKIN_1366X768X565_HAIER_CN))&&(g_bGotoCUSMenu == 1)) //cus_xm zb 2012-7-9 add for  exit SMC CSM Menu
            {
                printf("\nexit csm menu by menu key!");
                MApp_ZUI_ACT_ExecuteFactoryMenuAction(EN_EXE_CLOSE_CURRENT_OSD);
                return TRUE;
            }
			//add for exit hotel menu: @chuxu  2012-08-02
			#if CUS_SMC_ENABLE_HOTEL_MODE
			//cus_xm zhihe add for  usb clone 20120820
	        else if((g_bGotoCUSMenu == 3)&&(stGenSetting.g_FactorySetting.HotelMenuUSBCloneUsedFlag==TRUE))
				{

					stGenSetting.g_FactorySetting.HotelMenuUSBCloneUsedFlag=FALSE;
					MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_CLONE_CONFIRM_WAITTING, SW_HIDE);
					MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_CLONE_CONFIRM_COMPLETE, SW_HIDE);
					MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_CLONE_ERROR_MSGBOX,SW_HIDE);//add for hotel mode's usb clone @chuxu
					MApp_ZUI_API_SetFocus(HWND_HOTEL_MENU_ITEM_USB_CLONE);
					return TRUE;
				}
			
			else if(MApp_ZUI_API_GetFocus() == HWND_HOTEL_MENU_OLD_PW || MApp_ZUI_API_GetFocus() == HWND_HOTEL_MENU_NEW_PW \
				|| MApp_ZUI_API_GetFocus() == HWND_HOTEL_MENU_CHECK_NEW_PW)
			   {
			   PasswordInput1=PasswordInput2=0;
			   g_u8PasswordPosition = 0;
			   g_u16Password = 0;
			   g_u8PasswordCount = 0;
			   MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_CHANGE_PW,SW_HIDE);
			   MApp_ZUI_API_SetFocus(HWND_HOTEL_MENU_ITEM_PW_CHANGE);
			   return TRUE;
			   }
			else if((g_bGotoCUSMenu == 3)&&(MApp_ZUI_API_GetFocus() != HWND_HOTEL_MENU_VOLUME_SUBPAGE_BAR))
				{
					stGenSetting.g_FactorySetting.HotelMenuRometeControlLockEnable = stGenSetting.g_FactorySetting.HotelMenuRometeControlLockEnableBack;
					stGenSetting.g_FactorySetting.HotelMenuOSDDisplayEnable = stGenSetting.g_FactorySetting.HotelMenuOSDDisplayEnableBack;
					stGenSetting.g_FactorySetting.HotelMenuUSBCloneMode = HotelMenuUsbCloneModeOFF;//reset usb clone mode
					MApp_SaveFactorySetting();

					MApp_ZUI_ACT_ExecuteFactoryMenuAction(EN_EXE_CLOSE_CURRENT_OSD);
					/*
					/////////////////////////////////////////////////////////////////////////////////////////////////////////
					#if CUS_SMC_ENABLE_HOTEL_MODE
					//add for hotel menu AQ/PQ restore : if off and quit hotel menu, initial AQ and PQ setting, if on and quit hotel menu, save AQ and PQ setting @chuxu 2012-08-07
				    if(stGenSetting.g_FactorySetting.HotelMenuHotelModeOperationEnable == ENABLE)
					{
						if(stGenSetting.g_FactorySetting.HotelMenuAQPQRestoreEnable == ENABLE)
						{
							//don't  restore AQ and PQ setting = AQ and PQ setting initialize
						}
						else if(stGenSetting.g_FactorySetting.HotelMenuAQPQRestoreEnable == DISABLE)
						{
							//add for reset audio
							MApp_DataBase_RestoreDefaultAudio();

							//add for reset video
							MApp_DataBase_RestoreDefaultVideo(DATA_INPUT_SOURCE_TYPE(MAIN_WINDOW));
							MApp_DataBase_PictureResetWhiteBalance(DATA_INPUT_SOURCE_TYPE(MAIN_WINDOW));
							MApp_Picture_Setting_SetColor(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW), MAIN_WINDOW);  //MApp_PicSetVideo(SYS_INPUT_SOURCE_TYPE, &ST_VIDEO );
							MApp_Scaler_Setting_SetVDScale(ST_VIDEO.eAspectRatio, MAIN_WINDOW);

							//store to flash immediately
							MApp_DB_SaveNowGenSetting();
						}
					}
					else if(stGenSetting.g_FactorySetting.HotelMenuHotelModeOperationEnable == DISABLE)
					{
						//don't execute any action
					}
					#endif
					/////////////////////////////////////////////////////////////////////////////////////////////////////////
					*/
					return TRUE;
				}
			#endif

        case VK_SELECT:
            if(MApp_ZUI_API_GetFocus() == HWND_FACTORY_MENU_CUS_LIST_ITEM30_NAME)
            {
                MApp_ZUI_ACT_ExecuteFactoryMenuAction(EN_EXE_CLOSE_CURRENT_OSD);//cus_xm  gary 20120606 modify by factory menu exit function //EN_EXE_POWEROFF
                return TRUE;
            }
            else if(MApp_ZUI_API_GetFocus() == HWND_FACTORY_MENU_CUS_LIST_ITEM29_NAME)
            {
                extern COMMON_DLG_MODE _eCommonDlgMode;
                MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
                //cus_xm gary 20120715 modify by factory reset enter standby
				#if(ENABLE_CUS_UI_SPEC==ENABLE)
                 _enTargetOSDPageState =STATE_OSDPAGE_GOTO_STANDBY ;
				#else
				 _enTargetOSDPageState = STATE_OSDPAGE_CLEAN_UP;
				#endif
				_eCommonDlgMode = EN_COMMON_DLG_MODE_FACTORY_RESET;

                MApp_ZUI_ACT_ExecuteMenuCommonDialogAction(EN_EXE_FACTORY_RESET); //shipment

                return TRUE;
            }
            else if(MApp_ZUI_API_GetFocus() == HWND_FACTORY_MENU_CUS_LIST_ITEM24_NAME)
            {
                extern COMMON_DLG_MODE _eCommonDlgMode;
                MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
                //cus_xm gary 20120715 modify by factory reset enter standby
  				#if(ENABLE_CUS_UI_SPEC==ENABLE)
               		 _enTargetOSDPageState =STATE_OSDPAGE_GOTO_STANDBY ;
				#else
				  _enTargetOSDPageState = STATE_OSDPAGE_CLEAN_UP;
				#endif

                _eCommonDlgMode = EN_COMMON_DLG_MODE_FACTORY_RESET;
                MApp_ZUI_ACT_ExecuteMenuCommonDialogAction(EN_EXE_FACTORY_RESET_ALL); //eeprom init
                return TRUE;
            }

                break;

            default:
                break;
    }

    //launch code for Scaler Adjust item
    if (VK_NUM_0 <= key && key <= VK_NUM_9)
    {
        _u16ScalerAdjLaunchKeys = (_u16ScalerAdjLaunchKeys<<4)|(key-VK_NUM_0);
        if (_u16ScalerAdjLaunchKeys == 0x9999)
        {
            MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_ITEM7, SW_SHOW);
        }
#if ENABLE_SZ_FACTORY_USB_SAVE_MAP_FUNCTION
        if(_eFactoryMenuPage==EN_FACTORY_PAGE_REGISTER_MAP)
        {
            MApp_ZUI_ACT_HandleDatabaseMenuKey(key);
        }
#endif

#if CUS_SMC_ENABLE_HOTEL_MODE
       _MApp_ZUI_ACT_HotelPasswordHandler(key);
#endif
    }
    else
    {
        _u16ScalerAdjLaunchKeys = 0xFFFF;
    }

    return FALSE;
}

#if      ENABLE_SZ_FACTORY_USB_SAVE_MAP_FUNCTION
void MApp_ZUI_ACT_HandleDatabaseMenuKey(VIRTUAL_KEY_CODE Dkey)
{

    if (Dflag==FALSE)
    {
         u8MainDigitCount = 0;
         u8SubDigitCount =0;
         u32MainBankValue =0;
         u32SubBankValue = 0;
    }

    if(MApp_ZUI_API_GetFocus() == HWND_FACTORY_MENU_ITEM0)
    {
        Dflag=TRUE;
        if (u32MainBankValue == 0)
        {
            u32MainBankValue = (Dkey - VK_NUM_0);
            u8MainDigitCount = 1;
        }
        else if ( u8MainDigitCount<4 )
        {
            u32MainBankValue = (u32MainBankValue<<4)|(Dkey-VK_NUM_0);
            u8MainDigitCount++;
        }
        else
        {
            u32MainBankValue = (Dkey - VK_NUM_0);
            u8MainDigitCount = 1;
        }

    }
    else if(MApp_ZUI_API_GetFocus() == HWND_FACTORY_MENU_ITEM1)
    {
        Dflag=TRUE;
        if (u32SubBankValue == 0)
        {
            u32SubBankValue = (Dkey - VK_NUM_0);
            u8SubDigitCount = 1;
        }
        else if ( u8SubDigitCount<2 && u32SubBankValue<16)
        {
            u32SubBankValue = (u32SubBankValue<<4)|(Dkey-VK_NUM_0);
            u8SubDigitCount++;
        }
        else
        {
            u32SubBankValue = (Dkey - VK_NUM_0);
            u8SubDigitCount = 1;
        }

    }
    else
    {
        printf("Invalid Digital!!!!!\n\n");
    }
    MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_REPAINT_ALL);
    MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_RESET_AUTO_CLOSE_TIMER);
}
#endif

void MApp_ZUI_ACT_TerminateFactoryMenu(void)
{
    ZUI_MSG(printf("[]term:facmenu\n");)
    MApp_OSDPage_SetState(_enTargetOSDPageState);
}

////////////////////////////////////////////////////////////


typedef struct _FACTORY_MENU_ITEM
{
    FACTORY_MENU_PAGE eCurPage;
    FACTORY_MENU_PAGE ePrevPage;
    FACTORY_MENU_PAGE eNextPage;
    U8 u8ShowItem;
    U16 u16StringID;
    BOOLEAN bDisable;
} FACTORY_MENU_ITEM;

static  FACTORY_MENU_ITEM _ZUI_TBLSEG _FactoryMenuItem[]=
{
    //==root============================================
    {
        EN_FACTORY_PAGE_ROOT,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_ADC_ADJUST,
        0, en_strADCADJUSTText, FALSE
    },
    {
        EN_FACTORY_PAGE_ROOT,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_PICTURE_MODE,
       1, en_strSUBBCADJUSTText, FALSE
    },
    {
        EN_FACTORY_PAGE_ROOT,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_WHITE_BALANCE,
        2, en_strWBAdjustText, FALSE
    },
    {
        EN_FACTORY_PAGE_ROOT,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_SSC,
#if ENABLE_SSC
        3, en_str_SSC, FALSE
#else
        3, en_str_SSC, TRUE
#endif
    },
    {
        EN_FACTORY_PAGE_ROOT,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_SPECIAL_SET,
        4, en_str_SPECIAL_SET, FALSE
    },
    {
        EN_FACTORY_PAGE_ROOT,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_VIF,
#if ENABLE_VD_PACH_IN_CHINA
        5, en_str_VIF1, FALSE
#else
        5, en_str_VIF1, TRUE
#endif
    },
#if 0
    {
        EN_FACTORY_PAGE_ROOT,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_QMAP_PAGE,
        6, en_str_QMAP_ADJUST, FALSE
    },
    {
        EN_FACTORY_PAGE_ROOT,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_PEQ,
        7, en_str_PEQ, FALSE
    },
#endif
    {
        EN_FACTORY_PAGE_ROOT,
#if BOE_FAC_RESET//minglin0125
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_RESTORE_DEFAULT,
        6, en_str_SystemReset, FALSE
    },
    {
        EN_FACTORY_PAGE_ROOT,
#endif
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_SW_INFO_PAGE,
        8, en_str_SW_info, FALSE
    },
    #if ENABLE_AUTO_DQS_Factory
    {
        EN_FACTORY_PAGE_ROOT,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_BIST_TEST,
        9, en_str_BIST_TEST, FALSE
    },
    #endif
    {
        EN_FACTORY_PAGE_ROOT,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_UART_DBG,
        10, en_str_uart_dbg, FALSE
    },
#if (ENABLE_SZ_FACTORY_OVER_SCAN_FUNCTION)
   {
        EN_FACTORY_PAGE_ROOT,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_OVERSCAN,
        11, en_str_OverScan, FALSE
    },
#endif
#if ENABLE_PICTURE_NONLINEAR_CURVE
{
        EN_FACTORY_PAGE_ROOT,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_NONLINEAR_CURVE,
#if (ENABLE_NONLINEAR_CURVE)
        12, en_str_NONLINEAR, FALSE
#else
        12, en_str_NONLINEAR, TRUE
#endif
    },
#endif
#if ENABLE_AUTOTEST
    {
        EN_FACTORY_PAGE_ROOT,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_BMTEST_PAGE,
        13, en_str_BMTEST, FALSE
    },
#endif
#if BOE_USB_UPGRADE_FACTROY//minglin1206
    {
        EN_FACTORY_PAGE_ROOT,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_ROOT,
        14, en_str_SW_USB_Upgrade, FALSE
    },
#endif
 //   vcom  20220920
{
	EN_FACTORY_PAGE_ROOT,
	EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_VCOM,
	15, en_str_PanelControl, FALSE
},

#if (ENABLE_PIP)
    {
        EN_FACTORY_PAGE_ROOT,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_PIP_POP,
        12, en_str_PIP_POP, FALSE // original is 14
    },
#endif
 #if (ENABLE_FACTORY_PANEL_SEL)
     {
        EN_FACTORY_PAGE_ROOT,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_PANEL_SELECTION,
        13, en_str_PanelControl, FALSE
    },
 #endif

#if ENABLE_SZ_FACTORY_USB_SAVE_MAP_FUNCTION
    {
        EN_FACTORY_PAGE_ROOT,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_REGISTER_MAP,
        14, en_str_Register_Map, FALSE
    },
#endif

    //==ADC ADJUST======================================
    {
        EN_FACTORY_PAGE_ADC_ADJUST,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_ADC_ADJUST,
        0, en_strModeText, FALSE
    },
    {
        EN_FACTORY_PAGE_ADC_ADJUST,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_ADC_ADJUST,
        2, en_strR_GainText, FALSE
    },
    {
        EN_FACTORY_PAGE_ADC_ADJUST,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_ADC_ADJUST,
        3, en_strG_GainText, FALSE
    },
    {
        EN_FACTORY_PAGE_ADC_ADJUST,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_ADC_ADJUST,
        4, en_strB_GainText, FALSE
    },
    {
        EN_FACTORY_PAGE_ADC_ADJUST,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_ADC_ADJUST,
        6, en_strR_OffsetText, FALSE
    },
    {
        EN_FACTORY_PAGE_ADC_ADJUST,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_ADC_ADJUST,
        7, en_strG_OffsetText, FALSE
    },
    {
        EN_FACTORY_PAGE_ADC_ADJUST,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_ADC_ADJUST,
        8, en_strB_OffsetText, FALSE
    },
    {
        EN_FACTORY_PAGE_ADC_ADJUST,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_ADC_ADJUST,
        10, en_strSubAUTOADCText, FALSE
    },

    //==PICTURE MODE======================================
    {
        EN_FACTORY_PAGE_PICTURE_MODE,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_PICTURE_MODE,
        0, en_strModeText, FALSE
    },
    {
        EN_FACTORY_PAGE_PICTURE_MODE,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_PICTURE_MODE,
        2, en_strSubBrightnesText, FALSE
    },
    {
        EN_FACTORY_PAGE_PICTURE_MODE,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_PICTURE_MODE,
        3, en_strSubContrastText, FALSE
    },
    {
        EN_FACTORY_PAGE_PICTURE_MODE,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_PICTURE_MODE,
        4, en_strSubColorText, FALSE
    },
    {
        EN_FACTORY_PAGE_PICTURE_MODE,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_PICTURE_MODE,
        5, en_strSubSharpnessText, FALSE
    },
    {
        EN_FACTORY_PAGE_PICTURE_MODE,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_PICTURE_MODE,
        6, en_strSubTintText, FALSE
    },
#if (!BOE_FAC_RESET)//minglin0125
    {
        EN_FACTORY_PAGE_PICTURE_MODE,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_PICTURE_MODE,
        7, en_strSubCopyAllText, FALSE
    },
#endif
    //==WHITE BALANCE======================================
    {
        EN_FACTORY_PAGE_WHITE_BALANCE,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_WHITE_BALANCE,
        0, en_strModeText, FALSE
    },
    {
        EN_FACTORY_PAGE_WHITE_BALANCE,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_WHITE_BALANCE,
        2, en_strWBTemperatureText, FALSE
    },
    {
        EN_FACTORY_PAGE_WHITE_BALANCE,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_WHITE_BALANCE,
        3, en_strR_GainText, FALSE
    },
    {
        EN_FACTORY_PAGE_WHITE_BALANCE,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_WHITE_BALANCE,
        4, en_strG_GainText, FALSE
    },
    {
        EN_FACTORY_PAGE_WHITE_BALANCE,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_WHITE_BALANCE,
        5, en_strB_GainText, FALSE
    },
    {
        EN_FACTORY_PAGE_WHITE_BALANCE,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_WHITE_BALANCE,
        7, en_strR_OffsetText, FALSE
    },
    {
        EN_FACTORY_PAGE_WHITE_BALANCE,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_WHITE_BALANCE,
        8, en_strG_OffsetText, FALSE
    },
    {
        EN_FACTORY_PAGE_WHITE_BALANCE,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_WHITE_BALANCE,
        9, en_strB_OffsetText, FALSE
    },
    {
        EN_FACTORY_PAGE_WHITE_BALANCE,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_WHITE_BALANCE,
        10, en_strSubCopyAllText, FALSE
    },
    //===PEQ=============================================

    {
        EN_FACTORY_PAGE_PEQ,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_PEQ,
        0, en_str_FO1_Coarse, FALSE
    },
        {
        EN_FACTORY_PAGE_PEQ,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_PEQ,
        1, en_str_FO1_Fine, FALSE
    },
    {
        EN_FACTORY_PAGE_PEQ,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_PEQ,
        2, en_str_FO2_Coarse, FALSE
    },
        {
        EN_FACTORY_PAGE_PEQ,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_PEQ,
        3, en_str_FO2_Fine, FALSE
    },
    {
        EN_FACTORY_PAGE_PEQ,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_PEQ,
        4, en_str_FO3_Coarse, FALSE
    },
        {
        EN_FACTORY_PAGE_PEQ,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_PEQ,
        5, en_str_FO3_Fine, FALSE
    },
    {
        EN_FACTORY_PAGE_PEQ,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_PEQ,
        6, en_str_Gain1, FALSE
    },
    {
        EN_FACTORY_PAGE_PEQ,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_PEQ,
        7, en_str_Gain2, FALSE
    },
        {
        EN_FACTORY_PAGE_PEQ,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_PEQ,
        8, en_str_Gain3, FALSE
    },
    {
        EN_FACTORY_PAGE_PEQ,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_PEQ,
        9, en_str_Q1, FALSE
    },
    {
        EN_FACTORY_PAGE_PEQ,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_PEQ,
        10, en_str_Q2, FALSE
    },
    {
        EN_FACTORY_PAGE_PEQ,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_PEQ,
        11, en_str_Q3, FALSE
    },

    //==QMAP ADJUST======================================
    //==QMAP PAGE
    {
        EN_FACTORY_PAGE_QMAP_PAGE,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_QMAP_PAGE,
        0, Empty, FALSE
    },
    {
        EN_FACTORY_PAGE_QMAP_PAGE,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_QMAP_PAGE,
        1, Empty, FALSE
    },
    {
        EN_FACTORY_PAGE_QMAP_PAGE,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_QMAP_PAGE,
        2, Empty, FALSE
    },
    {
        EN_FACTORY_PAGE_QMAP_PAGE,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_QMAP_PAGE,
        3, Empty, FALSE
    },
    {
        EN_FACTORY_PAGE_QMAP_PAGE,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_QMAP_PAGE,
        4, Empty, FALSE
    },
    {
        EN_FACTORY_PAGE_QMAP_PAGE,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_QMAP_PAGE,
        5, Empty, FALSE
    },
    {
        EN_FACTORY_PAGE_QMAP_PAGE,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_QMAP_PAGE,
        6, Empty, FALSE
    },
    {
        EN_FACTORY_PAGE_QMAP_PAGE,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_QMAP_PAGE,
        7, Empty, FALSE
    },
    {
        EN_FACTORY_PAGE_QMAP_PAGE,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_QMAP_PAGE,
        8, Empty, FALSE
    },
    {
        EN_FACTORY_PAGE_QMAP_PAGE,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_QMAP_PAGE,
        9, Empty, FALSE
    },
    {
        EN_FACTORY_PAGE_QMAP_PAGE,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_QMAP_PAGE,
        10, Empty, FALSE
    },
    {
        EN_FACTORY_PAGE_QMAP_PAGE,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_QMAP_PAGE,
        11, Empty, FALSE
    },
    {
        EN_FACTORY_PAGE_QMAP_PAGE,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_QMAP_PAGE,
        12, Empty, FALSE
    },
    {
        EN_FACTORY_PAGE_QMAP_PAGE,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_QMAP_PAGE,
        13, Empty, FALSE
    },
    {
        EN_FACTORY_PAGE_QMAP_PAGE,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_QMAP_PAGE,
        14, Empty, FALSE
    },
    {
        EN_FACTORY_PAGE_QMAP_PAGE,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_QMAP_PAGE,
        15, Empty, FALSE
    },

    #if ENABLE_PIP
    //==PIP/POP Settings=====================================
    {
        EN_FACTORY_PAGE_PIP_POP,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_PIP_POP,
        0, en_str_PIP_POP, FALSE
    },
    {
        EN_FACTORY_PAGE_PIP_POP,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_PIP_POP,
        1, en_str_PIP_Border_Width, FALSE
    },
    #endif
    //==Software Information=================================
    {
        EN_FACTORY_PAGE_SW_INFO_PAGE,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_SW_INFO_PAGE,
        1, en_str_build_time, FALSE
    },
#if ENABLE_SHOW_PHASE_FACTORY
    {
        EN_FACTORY_PAGE_SW_INFO_PAGE,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_SW_INFO_PAGE,
        2, en_str_MIU0_DQS0, FALSE
    },
      {
        EN_FACTORY_PAGE_SW_INFO_PAGE,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_SW_INFO_PAGE,
        3, en_str_MIU0_DQS1, FALSE
    },
     #if(ENABLE_MIU_1)
      {
        EN_FACTORY_PAGE_SW_INFO_PAGE,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_SW_INFO_PAGE,
        4, en_str_MIU1_DQS0, FALSE
    },
      {
        EN_FACTORY_PAGE_SW_INFO_PAGE,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_SW_INFO_PAGE,
       5, en_str_MIU1_DQS1, FALSE
    },
    #endif
    #endif
    #if ENABLE_AUTOTEST
    //==Benchmark test Information=================================
    {
        EN_FACTORY_PAGE_BMTEST_PAGE,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_BMTEST_PAGE,
        0, en_str_BMTEST_AeonDhrystone, FALSE
    },
    {
        EN_FACTORY_PAGE_BMTEST_PAGE,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_BMTEST_PAGE,
        1, en_str_BMTEST_MipsDhrystone, FALSE
    },
    {
        EN_FACTORY_PAGE_BMTEST_PAGE,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_BMTEST_PAGE,
        2, en_str_BMTEST_AeonMM, FALSE
    },
    {
        EN_FACTORY_PAGE_BMTEST_PAGE,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_BMTEST_PAGE,
        3, en_str_BMTEST_MipsMM, FALSE
    },
    #endif
#if ENABLE_AUTO_DQS_Factory
    //==Run-Time BIST TEST===================================
    {
        EN_FACTORY_PAGE_BIST_TEST,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_BIST_TEST,
        0, en_str_BIST_TEST, FALSE
    },
    {
        EN_FACTORY_PAGE_BIST_TEST,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_BIST_TEST,
        1, en_str_MIU0_Phase_Plus_2, TRUE
    },
    {
        EN_FACTORY_PAGE_BIST_TEST,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_BIST_TEST,
        2, en_str_MIU0_Phase_Plus_1, TRUE
    },
    {
        EN_FACTORY_PAGE_BIST_TEST,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_BIST_TEST,
        3, en_str_MIU0_Phase_Plus_0, TRUE
    },
    {
        EN_FACTORY_PAGE_BIST_TEST,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_BIST_TEST,
        4, en_str_MIU0_Phase_Minus_1, TRUE
    },
    {
        EN_FACTORY_PAGE_BIST_TEST,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_BIST_TEST,
        5, en_str_MIU0_Phase_Minus_2, TRUE
    },
    #if(ENABLE_MIU_1)
    {
        EN_FACTORY_PAGE_BIST_TEST,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_BIST_TEST,
        6, en_str_MIU1_Phase_Plus_2, TRUE
    },
    {
        EN_FACTORY_PAGE_BIST_TEST,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_BIST_TEST,
        7, en_str_MIU1_Phase_Plus_1, TRUE
    },
    {
        EN_FACTORY_PAGE_BIST_TEST,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_BIST_TEST,
        8, en_str_MIU1_Phase_Plus_0, TRUE
    },
    {
        EN_FACTORY_PAGE_BIST_TEST,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_BIST_TEST,
        9, en_str_MIU1_Phase_Minus_1, TRUE
    },
    {
        EN_FACTORY_PAGE_BIST_TEST,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_BIST_TEST,
        10, en_str_MIU1_Phase_Minus_2, TRUE
    },
    #endif
#endif
    //==SSC=============================================
    {
        EN_FACTORY_PAGE_SSC,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_SSC,
        0, en_strMIUEnable, FALSE
    },
    {
        EN_FACTORY_PAGE_SSC,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_SSC,
        1, en_strMIUSpan, FALSE
    },
    {
        EN_FACTORY_PAGE_SSC,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_SSC,
        2, en_strMIUStep, FALSE
    },
    {
        EN_FACTORY_PAGE_SSC,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_SSC,
        4, en_strLVDSEnable, FALSE
    },
    {
        EN_FACTORY_PAGE_SSC,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_SSC,
        5, en_strLVDSSpan, FALSE
    },
    {
        EN_FACTORY_PAGE_SSC,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_SSC,
        6, en_strLVDSStep, FALSE
    },
    //==SPECIAL SET=============================================
    {
        EN_FACTORY_PAGE_SPECIAL_SET,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_SPECIAL_SET,
        0, en_strHourOffText, FALSE
    },
    {
        EN_FACTORY_PAGE_SPECIAL_SET,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_SPECIAL_SET,
        1, en_str_wdt, FALSE
    },
    {
        EN_FACTORY_PAGE_SPECIAL_SET,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_SPECIAL_SET,
        2, en_strWhitePatternText, FALSE
    },
#if (!BOE_FAC_RESET)//minglin0125
    {
        EN_FACTORY_PAGE_SPECIAL_SET,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_RESTORE_DEFAULT,
        3, en_str_FactoryDefault, FALSE
    },
#endif
    #if ENABLE_PVR
    {
        EN_FACTORY_PAGE_SPECIAL_SET,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_SPECIAL_SET,
       4, en_str_PVR_Record_All, FALSE
    },
    #endif
    #if (ENABLE_FACTORY_POWER_ON_MODE)
    {
        EN_FACTORY_PAGE_SPECIAL_SET,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_SPECIAL_SET,
        5, en_str_Powermode, FALSE
    },
    #endif
    #if ENABLE_USB_DOWNLOAD_BIN
    {
        EN_FACTORY_PAGE_SPECIAL_SET,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_SPECIAL_SET,
        6, en_str_PQ_Bin_Update, FALSE
    },
    #endif
	
#ifdef ENABLE_CUS_FACTORY_ATV_CH_PRSET
	{
		EN_FACTORY_PAGE_SPECIAL_SET,
		EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_SPECIAL_SET,
		7, en_str_FACTAB_Text, FALSE
	},
#endif
#if ENABLE_CUS_BURNING_MODE
	{
		EN_FACTORY_PAGE_SPECIAL_SET,
		EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_SPECIAL_SET,
		8, en_str_Burnin, FALSE
	},
#endif

#if BOE_FAC_RESET//minglin0125
/*
    {
        EN_FACTORY_PAGE_SPECIAL_SET,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_SPECIAL_SET,
        7, en_str_Channel_Default, FALSE
    },
*/
    {
        EN_FACTORY_PAGE_SPECIAL_SET,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_RESTORE_DEFAULT_ALL,
        9, en_str_EEPROMInit, FALSE
    },
#endif
#if (PADS_PWM1_MODE != Unknown_pad_mux)
	{
		EN_FACTORY_PAGE_SPECIAL_SET,
		EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_SPECIAL_SET,
		10, en_str_PWM_Period, FALSE
	},
	{
		EN_FACTORY_PAGE_SPECIAL_SET,
		EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_SPECIAL_SET,
		11, en_str_PWM_duty, FALSE
	},
	{
		EN_FACTORY_PAGE_SPECIAL_SET,
		EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_SPECIAL_SET,
		12, en_str_PWM_Div, FALSE
	},
#endif
#if ENABLE_FACTORY_GAMMA
	{
		EN_FACTORY_PAGE_SPECIAL_SET,
		EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_SPECIAL_SET,
		13, en_str_gamma, FALSE
	},
#endif

    //==VIF=============================================
    {
        EN_FACTORY_PAGE_VIF,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_VIF1,
        0, en_str_VIF1, FALSE
    },
    {
        EN_FACTORY_PAGE_VIF,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_VIF2,
        1, en_str_VIF2, FALSE
    },
    {
        EN_FACTORY_PAGE_VIF,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_VIF3,
        2, en_str_VIF3, FALSE
    },

    //==VIF1=============================================
    {
        EN_FACTORY_PAGE_VIF1,
        EN_FACTORY_PAGE_VIF, EN_FACTORY_PAGE_VIF1,
        0, en_str_AFEC_D4, FALSE
    },
    {
        EN_FACTORY_PAGE_VIF1,
        EN_FACTORY_PAGE_VIF, EN_FACTORY_PAGE_VIF1,
        1, en_str_AFEC_D5_Bit2, FALSE
    },
    {
        EN_FACTORY_PAGE_VIF1,
        EN_FACTORY_PAGE_VIF, EN_FACTORY_PAGE_VIF1,
        2, en_str_AFEC_D8_Bit3210, FALSE
    },
    {
        EN_FACTORY_PAGE_VIF1,
        EN_FACTORY_PAGE_VIF, EN_FACTORY_PAGE_VIF1,
        3, en_str_AFEC_D9_Bit0, FALSE
    },
    {
        EN_FACTORY_PAGE_VIF1,
        EN_FACTORY_PAGE_VIF, EN_FACTORY_PAGE_VIF1,
        4, en_str_AFEC_A0_A1, FALSE
    },
    {
        EN_FACTORY_PAGE_VIF1,
        EN_FACTORY_PAGE_VIF, EN_FACTORY_PAGE_VIF1,
        5, en_str_AFEC_66_Bit76, FALSE
    },
    {
        EN_FACTORY_PAGE_VIF1,
        EN_FACTORY_PAGE_VIF, EN_FACTORY_PAGE_VIF1,
        6, en_str_AFEC_6E_Bit7654, FALSE
    },
    {
        EN_FACTORY_PAGE_VIF1,
        EN_FACTORY_PAGE_VIF, EN_FACTORY_PAGE_VIF1,
        7, en_str_AFEC_6E_Bit3210, FALSE
    },
    {
        EN_FACTORY_PAGE_VIF1,
        EN_FACTORY_PAGE_VIF, EN_FACTORY_PAGE_VIF1,
        8, en_str_AFEC_D7_Bit3210, FALSE
    },
    {
        EN_FACTORY_PAGE_VIF1,
        EN_FACTORY_PAGE_VIF, EN_FACTORY_PAGE_VIF1,
        9, en_str_AFEC_D7_Bit7654, FALSE
    },
    {
        EN_FACTORY_PAGE_VIF1,
        EN_FACTORY_PAGE_VIF, EN_FACTORY_PAGE_VIF1,
        10, en_str_AFEC_43, FALSE
    },
    {
        EN_FACTORY_PAGE_VIF1,
        EN_FACTORY_PAGE_VIF, EN_FACTORY_PAGE_VIF1,
        11, en_str_AFEC_44, FALSE
    },
    {
        EN_FACTORY_PAGE_VIF1,
        EN_FACTORY_PAGE_VIF, EN_FACTORY_PAGE_VIF1,
        12, en_str_AFEC_CB, FALSE
    },
    {
        EN_FACTORY_PAGE_VIF1,
        EN_FACTORY_PAGE_VIF, EN_FACTORY_PAGE_VIF1,
        13, en_str_AFEC_CF_BIT2, FALSE
    },
    {
        EN_FACTORY_PAGE_VIF1,
        EN_FACTORY_PAGE_VIF, EN_FACTORY_PAGE_VIF1,
        14, en_str_AFEC_4E_BIT7, FALSE
    },
    {
        EN_FACTORY_PAGE_VIF1,
        EN_FACTORY_PAGE_VIF, EN_FACTORY_PAGE_VIF1,
        15, en_str_AFEC_4F, FALSE
    },
    //==VIF2=============================================
    {
        EN_FACTORY_PAGE_VIF2,
        EN_FACTORY_PAGE_VIF, EN_FACTORY_PAGE_VIF2,
        0, en_str_VIF_TOP, FALSE
    },
    {
        EN_FACTORY_PAGE_VIF2,
        EN_FACTORY_PAGE_VIF, EN_FACTORY_PAGE_VIF2,
        1, en_str_VIF_VGAMAXIMUM, FALSE
    },
    {
        EN_FACTORY_PAGE_VIF2,
        EN_FACTORY_PAGE_VIF, EN_FACTORY_PAGE_VIF2,
        2, en_str_VIF_China_DESCRAMBLER_BOX, FALSE
    },
    {
        EN_FACTORY_PAGE_VIF2,
        EN_FACTORY_PAGE_VIF, EN_FACTORY_PAGE_VIF2,
        3, en_str_VIF_CR_KP_KI, FALSE
    },
    {
        EN_FACTORY_PAGE_VIF2,
        EN_FACTORY_PAGE_VIF, EN_FACTORY_PAGE_VIF2,
        4, en_str_VIF_CR_THR, FALSE
    },
    {
        EN_FACTORY_PAGE_VIF2,
        EN_FACTORY_PAGE_VIF, EN_FACTORY_PAGE_VIF2,
        5, en_str_VIF_CR_KP_KI_ADJUST, FALSE
    },
    {
        EN_FACTORY_PAGE_VIF2,
        EN_FACTORY_PAGE_VIF, EN_FACTORY_PAGE_VIF2,
        6, en_str_VIF_CLAMPGAIN_GAIN_OV_NEGATIVE, FALSE
    },
    {
        EN_FACTORY_PAGE_VIF2,
        EN_FACTORY_PAGE_VIF, EN_FACTORY_PAGE_VIF2,
        7, en_str_VIF_OVER_MODULATION, FALSE
    },
    {
        EN_FACTORY_PAGE_VIF2,
        EN_FACTORY_PAGE_VIF, EN_FACTORY_PAGE_VIF2,
        8, en_str_VIF_ASIA_SIGNAL_OPTION, FALSE
    },
    {
        EN_FACTORY_PAGE_VIF2,
        EN_FACTORY_PAGE_VIF, EN_FACTORY_PAGE_VIF2,
        9, en_str_VIF_CR_LOCK_THR, FALSE
    },
    {
        EN_FACTORY_PAGE_VIF2,
        EN_FACTORY_PAGE_VIF, EN_FACTORY_PAGE_VIF2,
        10, en_str_VIF_AGC_VGA_BASE, FALSE
    },
    {
        EN_FACTORY_PAGE_VIF2,
        EN_FACTORY_PAGE_VIF, EN_FACTORY_PAGE_VIF2,
        11, en_str_VIF_SERIOUS_ACIDETECT, FALSE
    },

    //==VIF3=============================================
    {
        EN_FACTORY_PAGE_VIF3,
        EN_FACTORY_PAGE_VIF, EN_FACTORY_PAGE_VIF3,
        0, en_str_Audio_HIDEV_MODE, FALSE
    },
    {
        EN_FACTORY_PAGE_VIF3,
        EN_FACTORY_PAGE_VIF, EN_FACTORY_PAGE_VIF3,
        1, en_str_AUDIO_NR_THR, FALSE
    },
    {
        EN_FACTORY_PAGE_VIF3,
        EN_FACTORY_PAGE_VIF, EN_FACTORY_PAGE_VIF3,
        2, en_str_SCAN_DELAY, FALSE
    },
    {
        EN_FACTORY_PAGE_VIF3,
        EN_FACTORY_PAGE_VIF, EN_FACTORY_PAGE_VIF3,
        3, en_str_COMBPATCH, FALSE
    },
    {
        EN_FACTORY_PAGE_VIF3,
        EN_FACTORY_PAGE_VIF, EN_FACTORY_PAGE_VIF3,
        4, en_str_NONSTANDRDPATCH, FALSE
    },
    {
        EN_FACTORY_PAGE_VIF3,
        EN_FACTORY_PAGE_VIF, EN_FACTORY_PAGE_VIF3,
        5, en_str_SW_version, FALSE
    },

    {
        EN_FACTORY_PAGE_VIF3,
        EN_FACTORY_PAGE_VIF, EN_FACTORY_PAGE_VIF3,
        6, en_str_AFEC_DSP_Version, FALSE
    },

    //==Uart Debug=============================================
    {
        EN_FACTORY_PAGE_UART_DBG,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_UART_DBG,
        0, en_str_uart_dbg, FALSE
    },
#if (ENABLE_SZ_FACTORY_OVER_SCAN_FUNCTION)
  //==Over Scan===============================================
  {
        EN_FACTORY_PAGE_OVERSCAN,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_OVERSCAN,
        0, en_str_overscan_reslution, FALSE
    },
    {
        EN_FACTORY_PAGE_OVERSCAN,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_OVERSCAN,
        2, en_str_overscan_hPosition, FALSE
    },
    {
        EN_FACTORY_PAGE_OVERSCAN,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_OVERSCAN,
        3, en_str_overscan_hsize, FALSE
    },
    {
        EN_FACTORY_PAGE_OVERSCAN,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_OVERSCAN,
        4, en_str_overscan_VPosition, FALSE
    },
    {
        EN_FACTORY_PAGE_OVERSCAN,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_OVERSCAN,
        5, en_str_overscan_Vsize, FALSE
    },
#endif
#if ENABLE_NONLINEAR_CURVE
 //==NONLINEAR CURVE======================================
    {
        EN_FACTORY_PAGE_NONLINEAR_CURVE,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_NONLINEAR_CURVE,
        0, en_strModeText, FALSE
    },
    {
        EN_FACTORY_PAGE_NONLINEAR_CURVE,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_NONLINEAR_CURVE,
        1, en_strSUBBCADJUSTText, FALSE
    },
    {
        EN_FACTORY_PAGE_NONLINEAR_CURVE,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_BRIGHTNESS_CURVE,
        2, en_str_BrightnessCurve, FALSE
    },
    {
        EN_FACTORY_PAGE_NONLINEAR_CURVE,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_CONTRAST_CURVE,
        3, en_str_ContrastCurve, FALSE
    },
    {
        EN_FACTORY_PAGE_NONLINEAR_CURVE,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_SATURATION_CURVE,
        4, en_str_ColorCurve, FALSE
    },
    {
        EN_FACTORY_PAGE_NONLINEAR_CURVE,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_HUE_CURVE,
        5, en_str_TintCurve, FALSE
    },
    {
        EN_FACTORY_PAGE_NONLINEAR_CURVE,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_SHARPNESS_CURVE,
        6, en_str_SharpnessCurve, FALSE
    },
    {
        EN_FACTORY_PAGE_NONLINEAR_CURVE,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_VOLUME_CURVE,
        7, en_str_VolumeCurve, FALSE
    },
    //==BRIGHTNESS CURVE =====================================
    {
        EN_FACTORY_PAGE_BRIGHTNESS_CURVE,
        EN_FACTORY_PAGE_NONLINEAR_CURVE, EN_FACTORY_PAGE_BRIGHTNESS_CURVE,
        0, en_str_0_Text, FALSE
    },
    {
        EN_FACTORY_PAGE_BRIGHTNESS_CURVE,
        EN_FACTORY_PAGE_NONLINEAR_CURVE, EN_FACTORY_PAGE_BRIGHTNESS_CURVE,
        1, en_str_25_Text, FALSE
    },
    {
        EN_FACTORY_PAGE_BRIGHTNESS_CURVE,
        EN_FACTORY_PAGE_NONLINEAR_CURVE, EN_FACTORY_PAGE_BRIGHTNESS_CURVE,
        2, en_str_50_Text, FALSE
    },
    {
        EN_FACTORY_PAGE_BRIGHTNESS_CURVE,
        EN_FACTORY_PAGE_NONLINEAR_CURVE, EN_FACTORY_PAGE_BRIGHTNESS_CURVE,
        3, en_str_75_Text, FALSE
    },
    {
        EN_FACTORY_PAGE_BRIGHTNESS_CURVE,
        EN_FACTORY_PAGE_NONLINEAR_CURVE, EN_FACTORY_PAGE_BRIGHTNESS_CURVE,
        4, en_str_100_Text, FALSE
    },
    //==CONTRAST CURVE =====================================
    {
        EN_FACTORY_PAGE_CONTRAST_CURVE,
        EN_FACTORY_PAGE_NONLINEAR_CURVE, EN_FACTORY_PAGE_CONTRAST_CURVE,
        0, en_str_0_Text, FALSE
    },
    {
        EN_FACTORY_PAGE_CONTRAST_CURVE,
        EN_FACTORY_PAGE_NONLINEAR_CURVE, EN_FACTORY_PAGE_CONTRAST_CURVE,
        1, en_str_25_Text, FALSE
    },
    {
        EN_FACTORY_PAGE_CONTRAST_CURVE,
        EN_FACTORY_PAGE_NONLINEAR_CURVE, EN_FACTORY_PAGE_CONTRAST_CURVE,
        2, en_str_50_Text, FALSE
    },
    {
        EN_FACTORY_PAGE_CONTRAST_CURVE,
        EN_FACTORY_PAGE_NONLINEAR_CURVE, EN_FACTORY_PAGE_CONTRAST_CURVE,
        3, en_str_75_Text, FALSE
    },
    {
        EN_FACTORY_PAGE_CONTRAST_CURVE,
        EN_FACTORY_PAGE_NONLINEAR_CURVE, EN_FACTORY_PAGE_CONTRAST_CURVE,
        4, en_str_100_Text, FALSE
    },
    //==SATURATION CURVE =====================================
    {
        EN_FACTORY_PAGE_SATURATION_CURVE,
        EN_FACTORY_PAGE_NONLINEAR_CURVE, EN_FACTORY_PAGE_SATURATION_CURVE,
        0, en_str_0_Text, FALSE
    },
    {
        EN_FACTORY_PAGE_SATURATION_CURVE,
        EN_FACTORY_PAGE_NONLINEAR_CURVE, EN_FACTORY_PAGE_SATURATION_CURVE,
        1, en_str_25_Text, FALSE
    },
    {
        EN_FACTORY_PAGE_SATURATION_CURVE,
        EN_FACTORY_PAGE_NONLINEAR_CURVE, EN_FACTORY_PAGE_SATURATION_CURVE,
        2, en_str_50_Text, FALSE
    },
    {
        EN_FACTORY_PAGE_SATURATION_CURVE,
        EN_FACTORY_PAGE_NONLINEAR_CURVE, EN_FACTORY_PAGE_SATURATION_CURVE,
        3, en_str_75_Text, FALSE
    },
    {
        EN_FACTORY_PAGE_SATURATION_CURVE,
        EN_FACTORY_PAGE_NONLINEAR_CURVE, EN_FACTORY_PAGE_SATURATION_CURVE,
        4, en_str_100_Text, FALSE
    },
    //==HUE CURVE =====================================
    {
        EN_FACTORY_PAGE_HUE_CURVE,
        EN_FACTORY_PAGE_NONLINEAR_CURVE, EN_FACTORY_PAGE_HUE_CURVE,
        0, en_str_0_Text, FALSE
    },
    {
        EN_FACTORY_PAGE_HUE_CURVE,
        EN_FACTORY_PAGE_NONLINEAR_CURVE, EN_FACTORY_PAGE_HUE_CURVE,
        1, en_str_25_Text, FALSE
    },
    {
        EN_FACTORY_PAGE_HUE_CURVE,
        EN_FACTORY_PAGE_NONLINEAR_CURVE, EN_FACTORY_PAGE_HUE_CURVE,
        2, en_str_50_Text, FALSE
    },
    {
        EN_FACTORY_PAGE_HUE_CURVE,
        EN_FACTORY_PAGE_NONLINEAR_CURVE, EN_FACTORY_PAGE_HUE_CURVE,
        3, en_str_75_Text, FALSE
    },
    {
        EN_FACTORY_PAGE_HUE_CURVE,
        EN_FACTORY_PAGE_NONLINEAR_CURVE, EN_FACTORY_PAGE_HUE_CURVE,
        4, en_str_100_Text, FALSE
    },
    //==SHARPNESS CURVE =====================================
    {
        EN_FACTORY_PAGE_SHARPNESS_CURVE,
        EN_FACTORY_PAGE_NONLINEAR_CURVE, EN_FACTORY_PAGE_SHARPNESS_CURVE,
        0, en_str_0_Text, FALSE
    },
    {
        EN_FACTORY_PAGE_SHARPNESS_CURVE,
        EN_FACTORY_PAGE_NONLINEAR_CURVE, EN_FACTORY_PAGE_SHARPNESS_CURVE,
        1, en_str_25_Text, FALSE
    },
    {
        EN_FACTORY_PAGE_SHARPNESS_CURVE,
        EN_FACTORY_PAGE_NONLINEAR_CURVE, EN_FACTORY_PAGE_SHARPNESS_CURVE,
        2, en_str_50_Text, FALSE
    },
    {
        EN_FACTORY_PAGE_SHARPNESS_CURVE,
        EN_FACTORY_PAGE_NONLINEAR_CURVE, EN_FACTORY_PAGE_SHARPNESS_CURVE,
        3, en_str_75_Text, FALSE
    },
    {
        EN_FACTORY_PAGE_SHARPNESS_CURVE,
        EN_FACTORY_PAGE_NONLINEAR_CURVE, EN_FACTORY_PAGE_SHARPNESS_CURVE,
        4, en_str_100_Text, FALSE
    },

    //==VOLUME CURVE======================================
    #if ENABLE_SOUND_NONLINEAR_CURVE_TEN
    {
        EN_FACTORY_PAGE_VOLUME_CURVE,
        EN_FACTORY_PAGE_NONLINEAR_CURVE, EN_FACTORY_PAGE_VOLUME_CURVE,
        0, en_str_0_Text, FALSE
    },
    {
        EN_FACTORY_PAGE_VOLUME_CURVE,
        EN_FACTORY_PAGE_NONLINEAR_CURVE, EN_FACTORY_PAGE_VOLUME_CURVE,
        1, en_str_10_Text, FALSE
    },
    {
        EN_FACTORY_PAGE_VOLUME_CURVE,
        EN_FACTORY_PAGE_NONLINEAR_CURVE, EN_FACTORY_PAGE_VOLUME_CURVE,
        2, en_str_20_Text, FALSE
    },
    {
        EN_FACTORY_PAGE_VOLUME_CURVE,
        EN_FACTORY_PAGE_NONLINEAR_CURVE, EN_FACTORY_PAGE_VOLUME_CURVE,
        3, en_str_30_Text, FALSE
    },
    {
        EN_FACTORY_PAGE_VOLUME_CURVE,
        EN_FACTORY_PAGE_NONLINEAR_CURVE, EN_FACTORY_PAGE_VOLUME_CURVE,
        4, en_str_40_Text, FALSE
    },
        {
        EN_FACTORY_PAGE_VOLUME_CURVE,
        EN_FACTORY_PAGE_NONLINEAR_CURVE, EN_FACTORY_PAGE_VOLUME_CURVE,
        5, en_str_50_Text, FALSE
    },
    {
        EN_FACTORY_PAGE_VOLUME_CURVE,
        EN_FACTORY_PAGE_NONLINEAR_CURVE, EN_FACTORY_PAGE_VOLUME_CURVE,
        6, en_str_60_Text, FALSE
    },
    {
        EN_FACTORY_PAGE_VOLUME_CURVE,
        EN_FACTORY_PAGE_NONLINEAR_CURVE, EN_FACTORY_PAGE_VOLUME_CURVE,
        7, en_str_70_Text, FALSE
    },
    {
        EN_FACTORY_PAGE_VOLUME_CURVE,
        EN_FACTORY_PAGE_NONLINEAR_CURVE, EN_FACTORY_PAGE_VOLUME_CURVE,
        8, en_str_85_Text, FALSE
    },
    {
        EN_FACTORY_PAGE_VOLUME_CURVE,
        EN_FACTORY_PAGE_NONLINEAR_CURVE, EN_FACTORY_PAGE_VOLUME_CURVE,
        9, en_str_100_Text, FALSE
    },
	{
		EN_FACTORY_PAGE_VOLUME_CURVE,
		EN_FACTORY_PAGE_NONLINEAR_CURVE, EN_FACTORY_PAGE_VOLUME_CURVE,
		10, en_str_SCALER_ADJUST, FALSE
	},
	{
		EN_FACTORY_PAGE_VOLUME_CURVE,
		EN_FACTORY_PAGE_NONLINEAR_CURVE, EN_FACTORY_PAGE_VOLUME_CURVE,
		11, en_str_AutoVolume, FALSE
	},
#if 1
	{
		EN_FACTORY_PAGE_VOLUME_CURVE,
		EN_FACTORY_PAGE_NONLINEAR_CURVE, EN_FACTORY_PAGE_VOLUME_CURVE,
		12, en_str_AVC, FALSE
	},
#endif
#if ENABLE_FACTORY_DRC
    {
	EN_FACTORY_PAGE_VOLUME_CURVE,
	EN_FACTORY_PAGE_NONLINEAR_CURVE, EN_FACTORY_PAGE_VOLUME_CURVE,
	13, en_str_DRC, FALSE
    },
    {
	EN_FACTORY_PAGE_VOLUME_CURVE,
	EN_FACTORY_PAGE_NONLINEAR_CURVE, EN_FACTORY_PAGE_VOLUME_CURVE,
	14, en_str_DRC, FALSE
    },
#endif
    #else
	{
        EN_FACTORY_PAGE_VOLUME_CURVE,
        EN_FACTORY_PAGE_NONLINEAR_CURVE, EN_FACTORY_PAGE_VOLUME_CURVE,
        0, en_str_0_Text, FALSE
    },
    {
        EN_FACTORY_PAGE_VOLUME_CURVE,
        EN_FACTORY_PAGE_NONLINEAR_CURVE, EN_FACTORY_PAGE_VOLUME_CURVE,
        1, en_str_25_Text, FALSE
    },
    {
        EN_FACTORY_PAGE_VOLUME_CURVE,
        EN_FACTORY_PAGE_NONLINEAR_CURVE, EN_FACTORY_PAGE_VOLUME_CURVE,
        2, en_str_50_Text, FALSE
    },
    {
        EN_FACTORY_PAGE_VOLUME_CURVE,
        EN_FACTORY_PAGE_NONLINEAR_CURVE, EN_FACTORY_PAGE_VOLUME_CURVE,
        3, en_str_75_Text, FALSE
    },
    {
        EN_FACTORY_PAGE_VOLUME_CURVE,
        EN_FACTORY_PAGE_NONLINEAR_CURVE, EN_FACTORY_PAGE_VOLUME_CURVE,
        4, en_str_100_Text, FALSE
    },
 #endif
 #endif
 //==============vcom===============================
    {
        // test pattern
        EN_FACTORY_PAGE_VCOM,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_VCOM,
        0, en_str_PanelControl, FALSE
    },
 //==PANEL_SEL======================================
 #if (ENABLE_FACTORY_PANEL_SEL)
     {
        EN_FACTORY_PAGE_PANEL_SELECTION,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_PANEL_SELECTION,
        0, en_str_PanelControl, FALSE
    },
    {
        EN_FACTORY_PAGE_PANEL_SELECTION,
        EN_FACTORY_PAGE_ROOT, EN_FACTORY_PAGE_PANEL_SELECTION,
        1, en_str_PanelControl, TRUE
    },
 #endif

 #if    ENABLE_SZ_FACTORY_USB_SAVE_MAP_FUNCTION
//===DATABASE SAVE=========================================

    {
        EN_FACTORY_PAGE_REGISTER_MAP,
       EN_FACTORY_PAGE_ROOT,EN_FACTORY_PAGE_REGISTER_MAP,
       0,en_str_register_BANK,FALSE
    },
    {
        EN_FACTORY_PAGE_REGISTER_MAP,
       EN_FACTORY_PAGE_ROOT,EN_FACTORY_PAGE_REGISTER_MAP,
       1,en_str_register_BankBranch,FALSE
    },
    {
        EN_FACTORY_PAGE_REGISTER_MAP,
       EN_FACTORY_PAGE_ROOT,EN_FACTORY_PAGE_REGISTER_MAP,
       2,en_str_register_RESULT,FALSE
    },
    {
        EN_FACTORY_PAGE_REGISTER_MAP,
       EN_FACTORY_PAGE_ROOT,EN_FACTORY_PAGE_REGISTER_MAP,
       3,en_str_register_Script,FALSE
    },
    {
        EN_FACTORY_PAGE_REGISTER_MAP,
       EN_FACTORY_PAGE_ROOT,EN_FACTORY_PAGE_REGISTER_MAP,
       4,en_str_register_ALL,FALSE
    },

#endif

};

#if(LOG_FACTORYMENU_SHOWITEM)
#define GET_FACTORYMENU_SHOWITEM(stuMenuItem)            GetFactoryMenuItemIndex(stuMenuItem)

// ----------------------------------------------------------
// ����˵��: ��ȡ�����˵��������
// ����˵��:
//    stuMenuItem: �����˵���ĿFACTORY_MENU_ITEM
// ����˵��:
//    ���ز˵����0��ʼ������ֵ
// ����˵��:
//    Լ��: ��ҳ�������������Ϊ0
// ----------------------------------------------------------
static U8 GetFactoryMenuItemIndex(FACTORY_MENU_ITEM stuMenuItem)
{
    U8 i = 0;
    U8 ucMenuIndex = 0;
    //printf("GetFactoryMenuItemIndex(%bu)\n", (U8)stuMenuItem.u8ShowItem);

    for (i = 0; i < COUNTOF(_FactoryMenuItem); i++)
    {
        if (_FactoryMenuItem[i].u8ShowItem == 0) //    Լ��: ��ҳ�������������Ϊ0
            ucMenuIndex = 0;
        else
            ucMenuIndex ++;

        // ����ҳ���ڴ������⴦��
        if(_FactoryMenuItem[i].eCurPage == EN_FACTORY_PAGE_SW_INFO_PAGE && _FactoryMenuItem[i].u8ShowItem == 1)
            ucMenuIndex = 1; // EN_FACTORY_PAGE_SW_INFO_PAGEҳ��: ��1��ʼ�ģ�����ԭ���Ѿ�����ʾ����.

        if (_FactoryMenuItem[i].eCurPage == stuMenuItem.eCurPage && _FactoryMenuItem[i].u8ShowItem == stuMenuItem.u8ShowItem)
        {
            // printf("ucMenuIndex = %bu\n", ucMenuIndex);
            return ucMenuIndex;
        }
    }

    printf("--WARNING--: FACTORY_MENU_ITEM inexistence!\n", (U8)0);
    return 0xFF; // �����ڵ�ҳ��
}

// ----------------------------------------------------------
// ����˵��: ��ȡ_FactoryMenuItem�����u8ShowItemֵ
// ����˵��:
//    enuCurPage: ��ǰҳ�����FACTORY_MENU_PAGE
//    ucItemIndex: �˵����0��ʼ������
// ����˵��:
//    ����_FactoryMenuItem�����u8ShowItemֵ
// ����˵��:
//    Լ��: ��ҳ�������������Ϊ0
// ----------------------------------------------------------
static U16 GetFactoryMenuItemu8ShowItem(FACTORY_MENU_PAGE enuCurPage, U8 ucItemIndex)
{
    U8 i = 0;
    U8 ucMenuItemuIndex = 0;

    // ����ҳ���ڴ������⴦��
    if(enuCurPage == EN_FACTORY_PAGE_SW_INFO_PAGE)
        ucMenuItemuIndex = 1; // EN_FACTORY_PAGE_SW_INFO_PAGEҳ��: ��1��ʼ�ģ���������ʾ����.

    for (i = 0; i < COUNTOF(_FactoryMenuItem); i++)
    {
        if(_FactoryMenuItem[i].eCurPage == enuCurPage)
        {
            if (ucMenuItemuIndex == ucItemIndex)
            {
                return _FactoryMenuItem[i].u8ShowItem;
            }
            ucMenuItemuIndex ++;
        }
    }

    printf("--WARNING--: FACTORY_MENU_PAGE or ucItemIndex inexistence!\n", (U8)0);
    return 0xFF; // �����ڵ�ҳ��
}

// ----------------------------------------------------------
// ����˵��: ��ȡ�����˵���ҳ��ǰһҳ�˵��Ĳ˵��������
// ����˵��:
//    enuCurPage: ��ǰҳ�����FACTORY_MENU_PAGE
// ����˵��:
//    ���ر�ҳ����ǰһҳ��Ĳ˵����0��ʼ������ֵ
// ����˵��:
//    Լ��: ��ҳ�������������Ϊ0
// ----------------------------------------------------------
static U8 GetFactoryPreMenuItemIndex(FACTORY_MENU_PAGE enuCurPage)
{
    U8 i = 0;
    U8 ucMenuIndex = 0;
   // printf("GetFactoryPreMenuItemIndex(%bu)\n", (U8)enuCurPage);

    for (i = 0; i < COUNTOF(_FactoryMenuItem); i++)
    {
        if (_FactoryMenuItem[i].u8ShowItem == 0) //    Լ��: ��ҳ�������������Ϊ0
            ucMenuIndex = 0;
        else
            ucMenuIndex ++;

        // ����ҳ���ڴ������⴦��
        if(_FactoryMenuItem[i].eCurPage == EN_FACTORY_PAGE_SW_INFO_PAGE && _FactoryMenuItem[i].u8ShowItem == 1)
            ucMenuIndex = 1; // EN_FACTORY_PAGE_SW_INFO_PAGEҳ��: ��1��ʼ�ģ�����ԭ���Ѿ�����ʾ����.

        if (_FactoryMenuItem[i].eNextPage == enuCurPage)
        {
            // printf("ucMenuIndex = %bu\n", ucMenuIndex);
            return ucMenuIndex;
        }
    }

    printf("--WARNING--: ePrevPage inexistence!\n", (U8)0);
    return 0xFF; // ������ǰһҳ��
}
#endif
#if ENABLE_VD_PACH_IN_CHINA
static U8 Get_VIF_KP_KI_MapToIndex(U16 KP_KI_DATA)
{
    U8 i;
    for (i = 0; i < COUNTOF(VIF_KP_KI_DATA); i++)
    {
        if (KP_KI_DATA == VIF_KP_KI_DATA[i])
        {
            return i;
        }
    }
    return 0;
}
static U8 Get_AFEC_A0_A1_MapToIndex(U16 A0_A1_DATA)
{
    U8 i;
    for (i = 0; i < COUNTOF(AFEC_A0_A1_DATA); i++)
    {
        if (A0_A1_DATA == AFEC_A0_A1_DATA[i])
        {
            return i;
        }
    }
    return 0;
}

#endif
static void _MApp_ZUI_ACT_FactoryMenuInitPage(FACTORY_MENU_PAGE page)
{
    BOOLEAN bFirst = TRUE;
    U8 i;
	
#if (PADS_PWM1_MODE != Unknown_pad_mux)
	Pwmduty=stGenSetting.g_SysSetting.bPanelVcom;
#endif
  #if ENABLE_AUTO_DQS_Factory
    if(page == EN_FACTORY_PAGE_BIST_TEST)
    {
        _BIST_TEST_MODE = EN_BIST_TEST_UI_START;
    }
  #endif
    MApp_ZUI_API_InvalidateWindow(HWND_FACTORY_MENU_TITLE);
    MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_LIST, SW_HIDE);
    MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BAR, SW_HIDE);
    if(page == EN_FACTORY_PAGE_QMAP_PAGE)
    {
        MApp_ZUI_API_ShowWindow(HWND_FACTORY_SW_INFO, SW_HIDE);
        MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_INPUT_INFO, SW_HIDE);
        MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_HOT_KEY_HELP1, SW_HIDE);
        MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_HOT_KEY_HELP2, SW_HIDE);
        MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BOARD_INFO, SW_HIDE);
    }
    else if(page == EN_FACTORY_PAGE_PEQ)
    {
        MApp_ZUI_API_ShowWindow(HWND_FACTORY_SW_INFO, SW_HIDE);
    //    MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_INPUT_INFO, SW_SHOW);
        MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_HOT_KEY_HELP1, SW_HIDE);
        MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_HOT_KEY_HELP2, SW_HIDE);
        MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BOARD_INFO, SW_HIDE);
    }
    else if (page == EN_FACTORY_PAGE_SW_INFO_PAGE)
    {
        MApp_ZUI_API_ShowWindow(HWND_FACTORY_SW_INFO, SW_SHOW);
        MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_INPUT_INFO, SW_HIDE);
        MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_HOT_KEY_HELP1, SW_HIDE);
        MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_HOT_KEY_HELP2, SW_HIDE);
        MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BOARD_INFO, SW_HIDE);
    }
    else if (page == EN_FACTORY_RESTORE_DEFAULT)
    {
        extern BOOLEAN MApp_ZUI_ACT_ExecuteMenuCommonDialogAction(U16 act);
        extern COMMON_DLG_MODE _eCommonDlgMode;
        MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
        _enTargetOSDPageState = STATE_OSDPAGE_CLEAN_UP;
        _eCommonDlgMode = EN_COMMON_DLG_MODE_FACTORY_RESET;
        MApp_ZUI_ACT_ExecuteMenuCommonDialogAction(EN_EXE_FACTORY_RESET);
        return;
    }
    else if (page == EN_FACTORY_RESTORE_DEFAULT_ALL)
    {
        extern BOOLEAN MApp_ZUI_ACT_ExecuteMenuCommonDialogAction(U16 act);
        extern COMMON_DLG_MODE _eCommonDlgMode;
        MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
        _enTargetOSDPageState = STATE_OSDPAGE_CLEAN_UP;
        _eCommonDlgMode = EN_COMMON_DLG_MODE_FACTORY_RESET;
        MApp_ZUI_ACT_ExecuteMenuCommonDialogAction(EN_EXE_FACTORY_RESET_ALL);
        return;
    }
	else if(page == EN_FACTORY_PAGE_CUSMENU)
	{
		MApp_ZUI_API_ShowWindow(HWND_FACTORY_SW_INFO, SW_HIDE);
		MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_INPUT_INFO, SW_HIDE);
		MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_HOT_KEY_HELP1, SW_HIDE);
		MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_HOT_KEY_HELP2, SW_HIDE);
		MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BOARD_INFO, SW_HIDE);

	}
#if CUS_SMC_ENABLE_HOTEL_MODE//hotel menu initial display @chuxu 2012-08-02
	else if(page == EN_HOTEL_MENU_PAGE)//hotel menu
	{
		MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BG_TRANSPARENT, SW_SHOW);
		MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM2, SW_HIDE);
	#if !HOHEL_ENABLE_AQPQ_OPTION
		MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM_AQ_PQ_RESTORE, SW_HIDE);
	#endif
	#if !HOHEL_ENABLE_SOURCE_KEY_OPTION
		MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM_SOURCE_KEY_LOCK, SW_HIDE);
	#endif
	#if !HOHEL_ENABLE_POWER_ON_OPTION
		MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM_POWER_ON, SW_HIDE);
	#endif
		MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_VOLUME_SUBPAGE, SW_HIDE);
		MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_CLONE_CONFIRM_WAITTING, SW_HIDE);//cus_xm zhihe  20120820 add for usb clone
		MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_CLONE_CONFIRM_COMPLETE, SW_HIDE);
		MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_CLONE_ERROR_MSGBOX,SW_HIDE);//add for hotel mode's usb clone @chuxu
		MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_CHANGE_PW,SW_HIDE);//add for hotel mode's usb clone @chuxu
		MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BG_PANE, SW_HIDE);
		MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_CUS_LIST, SW_HIDE);
		MApp_ZUI_API_ShowWindow(HWND_FACT_CSM_BG_MENU, SW_HIDE);
		MApp_ZUI_API_ShowWindow(HWND_FACTORY_SW_INFO, SW_HIDE);
		MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_INPUT_INFO, SW_HIDE);
		MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_HOT_KEY_HELP1, SW_HIDE);
		MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_HOT_KEY_HELP2, SW_HIDE);
		MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BOARD_INFO, SW_HIDE);
		//hotel mode operation setting:DISABLE for enable windows; DISABLE for disable windows
		if(stGenSetting.g_FactorySetting.HotelMenuHotelModeOperationEnable == DISABLE)//action state
		{
			MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_ITEM_HOTEL_MODE_OPERATION,TRUE);
			MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_ITEM_MAX_VOLUME_SETTING,FALSE);
			MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_ITEM_VOLUME_DEFAULT,FALSE);
			MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_ITEM_OSD_DISPLAY,FALSE);
			MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_ITEM_LOCAL_KEY_LOCK,FALSE);
			MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_ITEM_REMOTE_CONTROL_LOCK,FALSE);
			MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_ITEM_CHANNEL_DEFAULT,FALSE);
			MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_ITEM_INPUT_SOURCE_CHANGE,FALSE);
			MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_ITEM_USB_CLONE,FALSE);
		#if HOHEL_ENABLE_AQPQ_OPTION
			MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_ITEM_AQ_PQ_RESTORE,FALSE);
		#endif
			MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_ITEM_INSTALLATION,FALSE);
		#if HOHEL_ENABLE_SOURCE_KEY_OPTION
			MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_ITEM_SOURCE_KEY_LOCK,FALSE);
		#endif
		#if HOHEL_ENABLE_POWER_ON_OPTION
			MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_ITEM_POWER_ON,FALSE);
		#endif
			MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_ITEM_CAPTURE_LOGO,FALSE);
			MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_ITEM_POWERON_LOGO,FALSE);
			MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_ITEM_DEFAULT_LANGUAGE,FALSE);
			MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_ITEM_PW_CHANGE,FALSE);
		}
		else if(stGenSetting.g_FactorySetting.HotelMenuHotelModeOperationEnable == ENABLE)//action state
		{
			MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_ITEM_HOTEL_MODE_OPERATION,TRUE);
			MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_ITEM_MAX_VOLUME_SETTING,TRUE);
			MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_ITEM_VOLUME_DEFAULT,TRUE);
			MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_ITEM_OSD_DISPLAY,TRUE);
			MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_ITEM_LOCAL_KEY_LOCK,TRUE);
			MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_ITEM_REMOTE_CONTROL_LOCK,TRUE);
			MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_ITEM_CHANNEL_DEFAULT,TRUE);
			MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_ITEM_INPUT_SOURCE_CHANGE,TRUE);
			MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_ITEM_USB_CLONE,TRUE);
		#if HOHEL_ENABLE_AQPQ_OPTION
			MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_ITEM_AQ_PQ_RESTORE,TRUE);
		#endif
			MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_ITEM_INSTALLATION,TRUE);
		#if HOHEL_ENABLE_SOURCE_KEY_OPTION
			MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_ITEM_SOURCE_KEY_LOCK,TRUE);
		#endif
		#if HOHEL_ENABLE_POWER_ON_OPTION
			MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_ITEM_POWER_ON,TRUE);
		#endif
		if(MApp_DMP_GetDmpUiState()==DMP_UI_STATE_PLAYING_STAGE && MApp_MPlayer_QueryCurrentMediaType()==E_MPLAYER_TYPE_PHOTO)
			MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_ITEM_CAPTURE_LOGO,TRUE);
		else
			MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_ITEM_CAPTURE_LOGO,FALSE);
		
			MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_ITEM_POWERON_LOGO,FALSE);
			MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_ITEM_DEFAULT_LANGUAGE,TRUE);
			MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_ITEM_PW_CHANGE,TRUE);
		}
	}
#endif
    else
    {
        MApp_ZUI_API_ShowWindow(HWND_FACTORY_SW_INFO, SW_HIDE);
        MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_INPUT_INFO, SW_HIDE);
        MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_HOT_KEY_HELP1, SW_HIDE);
        MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_HOT_KEY_HELP2, SW_HIDE);
        if(page == EN_FACTORY_PAGE_ROOT)
        {
		#if BOE_USB_UPGRADE_FACTROY//minglin1206
            _u8USBDownloadStatus = 0; 
		#endif	
            MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BOARD_INFO, SW_SHOW);
       }
        else
        {
            MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BOARD_INFO, SW_HIDE);
        }
    }

	if(g_bGotoCUSMenu==1)
		MApp_ZUI_API_SetFocus(HWND_CSM_RS232);
	else if(g_bGotoCUSMenu==2)
		{
		MApp_ZUI_API_SetFocus(HWND_FACTORY_MENU_CUS_LIST_ITEM9_NAME);
			if ( UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_RGB )
    					stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE =EN_FacAdj_AdcMode_RGB;
                       		else if( UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_COMPONENT)
                       			{
                       			if(MApp_IsSrcHasSignal(MAIN_WINDOW) )
                       				{
	                       				if(MApi_XC_Sys_IsSrcHD(MAIN_WINDOW))
									{
										stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE =EN_FacAdj_AdcMode_Ypbpr_HD;
	                       					}
								else
									{
											stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE =EN_FacAdj_AdcMode_Ypbpr_SD;
									}
							}
							else
							{
								stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE =EN_FacAdj_AdcMode_Ypbpr_SD;
							}

                       			}
						else
							stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE =EN_FacAdj_AdcMode_Ypbpr_SD;



		}
#if CUS_SMC_ENABLE_HOTEL_MODE
	else if(g_bGotoCUSMenu==3)//hotel menu:Set  First Focus @chuxu 2012-07-24
		{
			MApp_ZUI_API_SetFocus(HWND_HOTEL_MENU_ITEM_HOTEL_MODE_OPERATION);//set first focus
		}
#endif
	else
		{
		    for (i = 0; i < COUNTOF(_FactoryMenuItem); i++)
		    {
		        if (_FactoryMenuItem[i].eCurPage == page)
		        {
		          #if(LOG_FACTORYMENU_SHOWITEM)
		            HWND hwnd = _MApp_ZUI_ACT_FactoryMenuIndexMapToWindow(GET_FACTORYMENU_SHOWITEM(_FactoryMenuItem[i]));
		          #else
		            HWND hwnd = _MApp_ZUI_ACT_FactoryMenuIndexMapToWindow(_FactoryMenuItem[i].u8ShowItem);
		          #endif
		            MApp_ZUI_API_ShowWindow(hwnd, SW_SHOW);
		            if (_FactoryMenuItem[i].bDisable)
		            {
		                MApp_ZUI_API_EnableWindow(hwnd, FALSE);
		            }
		            else
		            {
		                MApp_ZUI_API_EnableWindow(hwnd, TRUE);
						/////////////////////////////////////////////////////////////////////////////////////////////////
						if (IsStorageInUse()&& _FactoryMenuItem[i].eCurPage==EN_FACTORY_PAGE_SPECIAL_SET)
						{
							if(_FactoryMenuItem[i].u8ShowItem==2 || _FactoryMenuItem[i].u8ShowItem==8)
								MApp_ZUI_API_EnableWindow(hwnd, FALSE);
						}
						/////////////////////////////////////////////////////////////////////////////////////////////////
		                if (bFirst)
		                {
                #if BOE_FACTORY_SETFOCUS_SWINFO
                  if(_FactoryMenuItem[i].eCurPage == EN_FACTORY_PAGE_ROOT)
                  	{
                  	 if(_FactoryMenuItem[i].eNextPage==EN_FACTORY_PAGE_SW_INFO_PAGE)
                  	 	{
					  	 bFirst = FALSE;
					 	 MApp_ZUI_API_SetFocus(hwnd);
                  	 	}
				    }
				  else
				#endif
				#if BOE_FACTORY_SETFOCUS_SWINFO
				  	{
				#endif
                    bFirst = FALSE;
                    MApp_ZUI_API_SetFocus(hwnd);
				#if BOE_FACTORY_SETFOCUS_SWINFO
				  	}
				#endif
		                }
		            }
		        }
		    }
		    if (bFirst)
		    {
		        MApp_ZUI_API_SetFocus(HWND_INVALID); //no focus...
		    }
}
    _eFactoryMenuPage = page;
}
/*
static void _MApp_ZUI_ACT_FactoryMenuPrePageFocusItem(FACTORY_MENU_PAGE prePage, FACTORY_MENU_PAGE curPage)
{
    U8 i;
    MApp_ZUI_API_InvalidateWindow(HWND_FACTORY_MENU_TITLE);
    MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_LIST, SW_HIDE);

    for (i = 0; i < COUNTOF(_FactoryMenuItem); i++)
    {
        if (_FactoryMenuItem[i].eCurPage == prePage)
        {
          #if (LOG_FACTORYMENU_SHOWITEM)
            HWND hwnd = _MApp_ZUI_ACT_FactoryMenuIndexMapToWindow(GET_FACTORYMENU_SHOWITEM(_FactoryMenuItem[i].eCurPage));
          #else
            HWND hwnd = _MApp_ZUI_ACT_FactoryMenuIndexMapToWindow( _FactoryMenuItem[i].u8ShowItem);
          #endif
            MApp_ZUI_API_ShowWindow(hwnd, SW_SHOW);
            if (_FactoryMenuItem[i].bDisable)
            {
                MApp_ZUI_API_EnableWindow(hwnd, FALSE);
            }
            else
            {
                MApp_ZUI_API_EnableWindow(hwnd, TRUE);
                if (_FactoryMenuItem[i].eNextPage== curPage)
                {
                    MApp_ZUI_API_SetFocus(hwnd);
                }
            }
        }
    }
    _eFactoryMenuPage = prePage;
}
*/
static void _MApp_ZUI_ACT_FactoryMenuNextPage(U8 u8Item)
{
    U8 i;
    for (i = 0; i < COUNTOF(_FactoryMenuItem); i++)
    {
      #if(LOG_FACTORYMENU_SHOWITEM)
        if (_FactoryMenuItem[i].eCurPage == _eFactoryMenuPage && GET_FACTORYMENU_SHOWITEM(_FactoryMenuItem[i]) == u8Item)
      #else
        if (_FactoryMenuItem[i].eCurPage == _eFactoryMenuPage &&
            _FactoryMenuItem[i].u8ShowItem == u8Item)
      #endif
        {
            if (_eFactoryMenuPage != _FactoryMenuItem[i].eNextPage)
            {
                if( _FactoryMenuItem[i].eNextPage == EN_FACTORY_PAGE_PEQ)
                {
                    if( !ST_AUDIO_PEQ.u8_PEQOnOff)
                    {
                        return;
                    }
                }
                else if(_FactoryMenuItem[i].eNextPage == EN_FACTORY_RESTORE_DEFAULT)
                {
                    _eFactoryMenuPage = EN_FACTORY_RESTORE_DEFAULT;
                    return;
                }
                else if(_FactoryMenuItem[i].eNextPage == EN_FACTORY_RESTORE_DEFAULT_ALL)
                {
                    _eFactoryMenuPage = EN_FACTORY_RESTORE_DEFAULT_ALL;
                    return;
                }
                _MApp_ZUI_ACT_FactoryMenuInitPage(_FactoryMenuItem[i].eNextPage);
            }
            return;
        }
    }
}

static void _MApp_ZUI_ACT_FactoryMenuPrevPage(U8 u8Item)
{
    U8 i;
    for (i = 0; i < COUNTOF(_FactoryMenuItem); i++)
    {
      #if(LOG_FACTORYMENU_SHOWITEM)
        if (_FactoryMenuItem[i].eCurPage == _eFactoryMenuPage && GET_FACTORYMENU_SHOWITEM(_FactoryMenuItem[i]) == u8Item)
      #else
        if (_FactoryMenuItem[i].eCurPage == _eFactoryMenuPage &&
            _FactoryMenuItem[i].u8ShowItem == u8Item)
      #endif
        {
            if (_eFactoryMenuPage != _FactoryMenuItem[i].ePrevPage)
            {
                _MApp_ZUI_ACT_FactoryMenuInitPage(_FactoryMenuItem[i].ePrevPage);
               // _MApp_ZUI_ACT_FactoryMenuPrePageFocusItem(_FactoryMenuItem[i].ePrevPage, _FactoryMenuItem[i].eCurPage);
            }
            return;
        }
    }
}

static void _MApp_ZUI_ACT_QMAPPrevPage(void)
{

    FACTORY_MENU_PAGE _ePrevPage = EN_FACTORY_PAGE_QMAP_PAGE;
    U8 u8ShowItem = 0;

    if(_u8IPIndex == (_u8IPNumber-1))
    {
        u8ShowItem = _u8IPIndex%(COUNTOF(_FactoryMenuItemHwndList));
    }
    else
    {
        u8ShowItem = (COUNTOF(_FactoryMenuItemHwndList)-1);
    }

    _MApp_ZUI_ACT_FactoryMenuInitPage(_ePrevPage);
    MApp_ZUI_API_SetFocus(_FactoryMenuItemHwndList[u8ShowItem]);
    return;
}

static void _MApp_ZUI_ACT_QMAPNextPage(void)
{
    FACTORY_MENU_PAGE _eNextPage = EN_FACTORY_PAGE_QMAP_PAGE;

    _MApp_ZUI_ACT_FactoryMenuInitPage(_eNextPage);
    return;
}

//static BOOLEAN g_ADCCalibrationResult=FALSE;
BOOLEAN g_ADCCalibrationResult=FALSE;

static BOOLEAN g_CopyALLResult=FALSE;
#if( ENABLE_USB_DOWNLOAD_BIN )
static EnuUsbDlErrCode g_PQUpdateResult;
#endif

static void _MApp_ZUI_ACT_FactoryMenu_ChangeDataInputSource(E_DATA_INPUT_SOURCE eDataInputSource)
{
    //from function MApp_UiMenuFunc_ChangeDataInputSource()
    switch(eDataInputSource)
    {
        default:
  #if ENABLE_DTV
        case DATA_INPUT_SOURCE_DTV:
            UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_DTV;
            break;
  #endif
        case DATA_INPUT_SOURCE_ATV:
            UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_ATV;
            break;
    #if (INPUT_AV_VIDEO_COUNT >= 1)
        case DATA_INPUT_SOURCE_AV:
            UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_AV;
            break;
    #endif
    #if (INPUT_AV_VIDEO_COUNT >= 2)
        case DATA_INPUT_SOURCE_AV2:
            UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_AV2;
            break;
    #endif
    #if (INPUT_AV_VIDEO_COUNT >= 3)
        case DATA_INPUT_SOURCE_AV3:
            UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_AV3;
            break;
    #endif
    #if (INPUT_SCART_VIDEO_COUNT >= 1)
        case DATA_INPUT_SOURCE_SCART:
            UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_SCART;
            break;
    #endif
    #if (INPUT_SCART_VIDEO_COUNT >= 2)
        case DATA_INPUT_SOURCE_SCART2:
            UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_SCART2;
            break;
    #endif
    #if    (INPUT_SV_VIDEO_COUNT >= 1)
        case DATA_INPUT_SOURCE_SVIDEO:
            UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_SVIDEO;
            break;
    #endif

    #if ((INPUT_SCART_USE_SV2 == 0) && (INPUT_SV_VIDEO_COUNT >= 2))
        case DATA_INPUT_SOURCE_SVIDEO2:
            UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_SVIDEO2;
            break;
    #endif
    #if    (INPUT_YPBPR_VIDEO_COUNT >= 1)
        case DATA_INPUT_SOURCE_COMPONENT:
            UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_COMPONENT;
            break;
    #endif

    #if    (INPUT_YPBPR_VIDEO_COUNT >= 2)
        case DATA_INPUT_SOURCE_COMPONENT2:
            UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_COMPONENT2;
            break;
    #endif

        case DATA_INPUT_SOURCE_RGB:
            UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_RGB;
            break;

    #if (INPUT_HDMI_VIDEO_COUNT > 0)
        case DATA_INPUT_SOURCE_HDMI:
            UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_HDMI;
            break;
    #endif
    #if    (INPUT_HDMI_VIDEO_COUNT >= 2)
        case DATA_INPUT_SOURCE_HDMI2:
            UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_HDMI2;
            break;
    #endif
    #if    (INPUT_HDMI_VIDEO_COUNT >= 3)
        case DATA_INPUT_SOURCE_HDMI3:
            UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_HDMI3;
            break;
    #endif
    #if    (INPUT_HDMI_VIDEO_COUNT >= 4)
        case DATA_INPUT_SOURCE_HDMI4:
            UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_HDMI4;
            break;
    #endif
    }
    MApp_InputSource_ChangeInputSource(MAIN_WINDOW);

}

typedef enum
{
    EN_REDRAW_NONE,
    EN_REDRAW_ITEM,
    EN_REDRAW_LIST,
} REDRAW_TYPE;

//add for hotel menu :show volume bar @chuxu 2012-08-01
#if CUS_SMC_ENABLE_HOTEL_MODE
S16 MApp_ZUI_ACT_GetHotelMenuVolumeDynamicValue(HWND hwnd)
{
    switch(hwnd)
    {
		case HWND_HOTEL_MENU_VOLUME_SUBPAGE_OPTION:
			switch (prePictureHWND)
			{
				case HWND_HOTEL_MENU_ITEM_MAX_VOLUME_SETTING:
					return (stGenSetting.g_FactorySetting.HotelMenuMaxVolumeSetting);
				case HWND_HOTEL_MENU_ITEM_VOLUME_DEFAULT:
					return (stGenSetting.g_FactorySetting.HotelMenuVolumeDefault);
				default:
					break;
			}
		#if(UI_SKIN_SEL==UI_SKIN_1366X768X565_SMC_India) // cus_xm helen add 20120814
        case HWND_HOTEL_MENU_VERTICAL_SLIDER_SUBPAGE_OPTION:
                return stGenSetting.g_FactorySetting.HotelMenuVerticalSliderBarSetting;
        break;
		#endif
    }
    return 0; //for empty  data
}
#endif
static REDRAW_TYPE _MApp_ZUI_ACT_FactoryMenuDecIncValue(U8 u8Item, BOOLEAN bInc)
{
  #if(LOG_FACTORYMENU_SHOWITEM)
    u8Item = GetFactoryMenuItemu8ShowItem(_eFactoryMenuPage, u8Item);
  printf("xue trace u8Item %d",u8Item);
  #endif

    switch(_eFactoryMenuPage)
    {
        case EN_FACTORY_PAGE_ROOT:
            switch(u8Item)
            {
                case 7:
                    ST_AUDIO_PEQ.u8_PEQOnOff = !ST_AUDIO_PEQ.u8_PEQOnOff;
                    return EN_REDRAW_ITEM;
				//<<SMC jayden.chen add for USB update factory! 20130813	
				#if BOE_USB_UPGRADE_FACTROY
				case 14:
					
					printf("14xue trace u8Item %d",0);
					MApp_ZUI_ACT_ExecuteFactoryMenuAction(EN_EXE_SW_USB_UPDATE);
					return EN_REDRAW_ITEM;
				#endif	
				//>>SMC jayden.chen add for USB update factory! 20130813	

            }
            break;

        case EN_FACTORY_PAGE_ADC_ADJUST:

            switch(u8Item)
            {
                case 0: //from case MAPP_UIMENUFUNC_ADJUSTADC_MODE:
                    stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE =
                        (EN_FACTORY_ADC_ADJUST_MODE)MApp_ZUI_ACT_DecIncValue_Cycle(bInc, (U16)stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE, 0, (U16)EN_FacAdj_AdcMode_Ypbpr_Num-1, 1);
                    return EN_REDRAW_LIST;

                case 2: //from case MAPP_UIMENUFUNC_ADJUSTADC_REDGAIN:
                    stGenSettingExt.g_AdcSetting[stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE].stAdcGainOffsetSetting.u16RedGain =
                       (EN_FACTORY_ADC_ADJUST_MODE) MApp_ZUI_ACT_DecIncValue_Cycle(bInc, (U16)stGenSettingExt.g_AdcSetting[stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE].stAdcGainOffsetSetting.u16RedGain, 0, MApi_XC_ADC_GetMaximalGainValue(), 1);
                    MApp_SaveADCSetting((E_ADC_SET_INDEX)stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE);
                    //if(DATA_INPUT_SOURCE_TYPE == stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE)
                    if( ( UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_RGB && stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_RGB )
                    #if (INPUT_YPBPR_VIDEO_COUNT >= 1)
                            ||( UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_COMPONENT && stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_Ypbpr_SD )
                            ||( UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_COMPONENT && stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_Ypbpr_HD )
                    #endif
                    #if (INPUT_SCART_VIDEO_COUNT >= 1)
                            ||( UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_SCART && stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_ScartRGB)
                    #endif
                        )
                    {
                        MApi_XC_ADC_AdjustGainOffset(&stGenSettingExt.g_AdcSetting[stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE].stAdcGainOffsetSetting);
                    }
                    return EN_REDRAW_ITEM;

                case 3: //from case MAPP_UIMENUFUNC_ADJUSTADC_GREENGAIN:
                    stGenSettingExt.g_AdcSetting[stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE].stAdcGainOffsetSetting.u16GreenGain =
                       (EN_FACTORY_ADC_ADJUST_MODE) MApp_ZUI_ACT_DecIncValue_Cycle(bInc, (U16)stGenSettingExt.g_AdcSetting[stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE].stAdcGainOffsetSetting.u16GreenGain, 0, MApi_XC_ADC_GetMaximalGainValue(), 1);
                    MApp_SaveADCSetting((E_ADC_SET_INDEX)stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE);
                    //if(DATA_INPUT_SOURCE_TYPE == stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE)
                    if( ( UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_RGB && stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_RGB )
                    #if (INPUT_YPBPR_VIDEO_COUNT >= 1)
                            ||( UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_COMPONENT && stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_Ypbpr_SD )
                            ||( UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_COMPONENT && stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_Ypbpr_HD )
                    #endif
                    #if (INPUT_SCART_VIDEO_COUNT >= 1)
                            ||( UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_SCART && stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_ScartRGB)
                    #endif
                        )
                    {
                        MApi_XC_ADC_AdjustGainOffset(&stGenSettingExt.g_AdcSetting[stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE].stAdcGainOffsetSetting);
                    }
                    return EN_REDRAW_ITEM;

                case 4: //from case MAPP_UIMENUFUNC_ADJUSTADC_BLUEGAIN:
                    stGenSettingExt.g_AdcSetting[stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE].stAdcGainOffsetSetting.u16BlueGain =
                        (EN_FACTORY_ADC_ADJUST_MODE)MApp_ZUI_ACT_DecIncValue_Cycle(bInc, (U16)stGenSettingExt.g_AdcSetting[stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE].stAdcGainOffsetSetting.u16BlueGain, 0, MApi_XC_ADC_GetMaximalGainValue(), 1);
                    MApp_SaveADCSetting((E_ADC_SET_INDEX)stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE);
                    //if(DATA_INPUT_SOURCE_TYPE == stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE)
                    if( ( UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_RGB && stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_RGB )
                    #if (INPUT_YPBPR_VIDEO_COUNT >= 1)
                            ||( UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_COMPONENT && stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_Ypbpr_SD )
                            ||( UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_COMPONENT && stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_Ypbpr_HD )
                    #endif
                    #if (INPUT_SCART_VIDEO_COUNT >= 1)
                            ||( UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_SCART && stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_ScartRGB)
                    #endif
                        )
                    {
                        MApi_XC_ADC_AdjustGainOffset(&stGenSettingExt.g_AdcSetting[stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE].stAdcGainOffsetSetting);
                    }
                    return EN_REDRAW_ITEM;

                case 6: //from case MAPP_UIMENUFUNC_ADJUSTADC_REDOFFSET:
                    stGenSettingExt.g_AdcSetting[stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE].stAdcGainOffsetSetting.u16RedOffset =
                        (EN_FACTORY_ADC_ADJUST_MODE)MApp_ZUI_ACT_DecIncValue_Cycle(bInc, (U16)stGenSettingExt.g_AdcSetting[stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE].stAdcGainOffsetSetting.u16RedOffset, 0, MApi_XC_ADC_GetMaximalOffsetValue(), 1);
                    MApp_SaveADCSetting((E_ADC_SET_INDEX)stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE);
                    //if(DATA_INPUT_SOURCE_TYPE == stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE)
                    if( ( UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_RGB && stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_RGB )
                    #if (INPUT_YPBPR_VIDEO_COUNT >= 1)
                            ||( UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_COMPONENT && stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_Ypbpr_SD )
                            ||( UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_COMPONENT && stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_Ypbpr_HD )
                    #endif
                    #if (INPUT_SCART_VIDEO_COUNT >= 1)
                            ||( UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_SCART && stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_ScartRGB)
                    #endif
                        )
                    {
                        MApi_XC_ADC_AdjustGainOffset(&stGenSettingExt.g_AdcSetting[stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE].stAdcGainOffsetSetting);
                    }
                    return EN_REDRAW_ITEM;

                case 7: //from case MAPP_UIMENUFUNC_ADJUSTADC_GREENOFFSET:
                    stGenSettingExt.g_AdcSetting[stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE].stAdcGainOffsetSetting.u16GreenOffset =
                        (EN_FACTORY_ADC_ADJUST_MODE)MApp_ZUI_ACT_DecIncValue_Cycle(bInc,(U16) stGenSettingExt.g_AdcSetting[stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE].stAdcGainOffsetSetting.u16GreenOffset, 0, MApi_XC_ADC_GetMaximalOffsetValue(), 1);
                    MApp_SaveADCSetting((E_ADC_SET_INDEX)stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE);
                    //if(DATA_INPUT_SOURCE_TYPE == stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE)
                    if( ( UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_RGB && stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_RGB )
                    #if (INPUT_YPBPR_VIDEO_COUNT >= 1)
                            ||( UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_COMPONENT && stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_Ypbpr_SD )
                            ||( UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_COMPONENT && stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_Ypbpr_HD )
                    #endif
                    #if (INPUT_SCART_VIDEO_COUNT >= 1)
                            ||( UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_SCART && stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_ScartRGB)
                    #endif
                        )
                    {
                        MApi_XC_ADC_AdjustGainOffset(&stGenSettingExt.g_AdcSetting[stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE].stAdcGainOffsetSetting);
                    }
                    return EN_REDRAW_ITEM;

                case 8: //from case MAPP_UIMENUFUNC_ADJUSTADC_BLUEOFFSET:

                    stGenSettingExt.g_AdcSetting[stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE].stAdcGainOffsetSetting.u16BlueOffset =
                        (EN_FACTORY_ADC_ADJUST_MODE)MApp_ZUI_ACT_DecIncValue_Cycle(bInc, (U16)stGenSettingExt.g_AdcSetting[stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE].stAdcGainOffsetSetting.u16BlueOffset, 0, MApi_XC_ADC_GetMaximalOffsetValue(), 1);

                    MApp_SaveADCSetting((E_ADC_SET_INDEX)stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE);
                    //if(DATA_INPUT_SOURCE_TYPE == stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE)
                    if( ( UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_RGB && stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_RGB )
                    #if (INPUT_YPBPR_VIDEO_COUNT >= 1)
                            ||( UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_COMPONENT && stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_Ypbpr_SD )
                            ||( UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_COMPONENT && stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_Ypbpr_HD )
                    #endif
                    #if (INPUT_SCART_VIDEO_COUNT >= 1)
                            ||( UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_SCART && stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_ScartRGB)
                    #endif
                        )
                    {
                        MApi_XC_ADC_AdjustGainOffset(&stGenSettingExt.g_AdcSetting[stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE].stAdcGainOffsetSetting);
                    }
                    return EN_REDRAW_ITEM;

                case 10: // from case MAPP_UIMENUFUNC_ADJUSTADC_CALIBRATION:
                    if(IsVgaInUse())
                        g_ADCCalibrationResult = MApp_RGB_Setting_Auto(E_XC_EXTERNAL_CALIBRATION,MAIN_WINDOW);
                    else if(IsYPbPrInUse())
                        g_ADCCalibrationResult = MApp_YPbPr_Setting_Auto(E_XC_EXTERNAL_CALIBRATION,MAIN_WINDOW);
                #if (INPUT_SCART_VIDEO_COUNT >= 1)
                    else if(IsScartInUse())
                        g_ADCCalibrationResult = MApp_SCART_RGB_Setting_Auto(E_XC_EXTERNAL_CALIBRATION,MAIN_WINDOW);
                #endif
                    else
                        g_ADCCalibrationResult = FALSE;
                    return EN_REDRAW_ITEM;

            }

            break;

        case EN_FACTORY_PAGE_PICTURE_MODE:
            switch(u8Item)
            {
                case 0: //from case MAPP_UIMENUFUNC_SUB_BC_ADJUST_MODE:
                    ST_VIDEO.ePicture = (EN_MS_PICTURE)MApp_ZUI_ACT_DecIncValue_Cycle(bInc, ST_VIDEO.ePicture, PICTURE_MIN, PICTURE_NUMS-1, 1);
           #if 0//VGA_HDMI_YUV_POINT_TO_POINT
                     MDrv_PQ_SetUserColorMode(ENABLE);
           #endif
                     MApp_Picture_Setting_SetColor(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW), MAIN_WINDOW);  //MApp_PicSetPicture( (T_MS_PICTURE *) &ST_PICTURE, SYS_INPUT_SOURCE_TYPE);
           #if 0//VGA_HDMI_YUV_POINT_TO_POINT
                     MDrv_PQ_SetUserColorMode(DISABLE);
           #endif
                    return EN_REDRAW_LIST;

                case 2: //from case MAPP_UIMENUFUNC_SUB_BC_ADJUST_SUB_BRIGHTNES:
                    ST_SUBCOLOR.u8SubBrightness =
                        (U8)MApp_ZUI_ACT_DecIncValue(bInc, ST_SUBCOLOR.u8SubBrightness, SUB_BRIGHTNESS_MIN, SUB_BRIGHTNESS_MAX, 1);

                    MApp_SaveSubColorSetting(DATA_INPUT_SOURCE_TYPE(MAIN_WINDOW));

                    //msAPI_ACE_PicSetBrightness( msAPI_Mode_PictureBrightnessN100toReallyValue(ST_PICTURE.u8Brightness), ST_SUBCOLOR.u8SubBrightness );
                    //msAPI_ACE_PicSetBrightness(MApp_Scaler_FactoryAdjBrightness(ST_PICTURE.u8Brightness,ST_SUBCOLOR.u8SubBrightness));
                    MApi_XC_ACE_PicSetBrightnessInVsync(MAIN_WINDOW, MApi_XC_Sys_ACE_transfer_Bri((MApp_Scaler_FactoryAdjBrightness(msAPI_Mode_PictureBrightnessN100toReallyValue(ST_PICTURE.u8Brightness),ST_SUBCOLOR.u8SubBrightness)), BRIGHTNESS_R),
                                                              MApi_XC_Sys_ACE_transfer_Bri((MApp_Scaler_FactoryAdjBrightness(msAPI_Mode_PictureBrightnessN100toReallyValue(ST_PICTURE.u8Brightness),ST_SUBCOLOR.u8SubBrightness)), BRIGHTNESS_G),
                                                              MApi_XC_Sys_ACE_transfer_Bri((MApp_Scaler_FactoryAdjBrightness(msAPI_Mode_PictureBrightnessN100toReallyValue(ST_PICTURE.u8Brightness),ST_SUBCOLOR.u8SubBrightness)), BRIGHTNESS_B));

                    return EN_REDRAW_ITEM;

                case 3: //from case MAPP_UIMENUFUNC_SUB_BC_ADJUST_SUB_CONTRAST:

                    ST_SUBCOLOR.u8SubContrast =
                       (U8) MApp_ZUI_ACT_DecIncValue(bInc, ST_SUBCOLOR.u8SubContrast, SUB_CONTRAST_MIN, SUB_CONTRAST_MAX, 1);

                    MApp_SaveSubColorSetting(DATA_INPUT_SOURCE_TYPE(MAIN_WINDOW));

                    //msAPI_ACE_PicSetContrast( msAPI_Mode_PictureContrastN100toReallyValue(ST_PICTURE.u8Contrast), ST_SUBCOLOR.u8SubContrast );
               #if 0//VGA_HDMI_YUV_POINT_TO_POINT
                   if(IsHDMIInUse()&&MDrv_PQ_Get_HDMIPCMode())
                   {
                        MApi_XC_ACE_SetPCYUV2RGB(MAIN_WINDOW, FALSE);
                        MApi_XC_ACE_PicSetContrast(MAIN_WINDOW, FALSE, MApp_Scaler_FactoryContrast(msAPI_Mode_PictureContrastN100toReallyValue(ST_PICTURE.u8Contrast),ST_SUBCOLOR.u8SubContrast));
                   }
                   else
              #endif
                   {
                       MApi_XC_ACE_PicSetContrast(MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), MApp_Scaler_FactoryContrast(msAPI_Mode_PictureContrastN100toReallyValue(ST_PICTURE.u8Contrast),ST_SUBCOLOR.u8SubContrast));
                   }
                    return EN_REDRAW_ITEM;

                case 4:

                    ST_PICTURE.u8Saturation = MApp_ZUI_ACT_DecIncValue(
                        bInc,ST_PICTURE.u8Saturation, 0, 100, 1);
                  #if 0//VGA_HDMI_YUV_POINT_TO_POINT
                    if(IsHDMIInUse()&&MDrv_PQ_Get_HDMIPCMode())
                   {
                      ;// do nothing
                   }
                  else
                  #endif
                  {
                      MApi_XC_ACE_PicSetSaturation(MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW),  msAPI_Mode_PictureSaturationN100toReallyValue(ST_PICTURE.u8Saturation) );
                  }
                    return EN_REDRAW_ITEM;
                case 5:

                    ST_PICTURE.u8Sharpness = MApp_ZUI_ACT_DecIncValue(
                        bInc,ST_PICTURE.u8Sharpness, 0, 100, 1);
                    MApi_XC_ACE_PicSetSharpness( MAIN_WINDOW, msAPI_Mode_PictureSharpnessN100toReallyValue(ST_PICTURE.u8Sharpness) );

                    return EN_REDRAW_ITEM;
                case 6:

                    ST_PICTURE.u8Hue = MApp_ZUI_ACT_DecIncValue(
                        bInc,ST_PICTURE.u8Hue, 0, 100, 1);
                    MApi_XC_ACE_PicSetHue( MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), msAPI_Mode_PictureHueN100toReallyValue(ST_PICTURE.u8Hue) );

                    return EN_REDRAW_ITEM;
                case 7: //from case MAPP_UIMENUFUNC_SUB_BC_ADJUST_COPY_ALL:
                    MApp_CopySubColorDataToAllInput();

                    return EN_REDRAW_LIST;
            }
            break;
			case EN_FACTORY_PAGE_VCOM:
				switch(u8Item)
				{ 
				  case 0:
					  stGenSetting.g_SysSetting.bPanelVcom=MApp_ZUI_ACT_DecIncValue_Cycle(bInc,
							  (U16)stGenSetting.g_SysSetting.bPanelVcom,0,0xff,1);
			#if PANEL_TYPE==_1024x600_
				   msAPI_Ajust_Vcom_value();
			#endif
				return EN_REDRAW_ITEM;
				break;
			
			
				   
			
				}
				break;

        case EN_FACTORY_PAGE_WHITE_BALANCE:
            switch(u8Item)
            {
                case 0: //from case MAPP_UIMENUFUNC_WB_ADJUST_MODE:
                    DATA_INPUT_SOURCE_TYPE(MAIN_WINDOW) =
                    #if(ENABLE_DTV == 0)
                       (E_DATA_INPUT_SOURCE) MApp_ZUI_ACT_DecIncValue_Cycle(bInc,(U16) DATA_INPUT_SOURCE_TYPE(MAIN_WINDOW), DATA_INPUT_SOURCE_MIN, DATA_INPUT_SOURCE_NUM-2, 1);
                    #else
                       (E_DATA_INPUT_SOURCE) MApp_ZUI_ACT_DecIncValue_Cycle(bInc,(U16) DATA_INPUT_SOURCE_TYPE(MAIN_WINDOW), DATA_INPUT_SOURCE_MIN, DATA_INPUT_SOURCE_NUM-1, 1);
                    #endif
                #if ENABLE_PVR
					if( MApp_PVR_IsPlaybacking())
					{
						MApp_UiPvr_PlaybackStop();
					}
					if( MApp_PVR_IsRecording() )
					{
						MApp_UiPvr_RecordStop();
					}
				#endif
                #if ENABLE_DMP
					if( IsStorageInUse())
					{
						MApp_MPlayer_Stop();
					}
                 #endif
                    _MApp_ZUI_ACT_FactoryMenu_ChangeDataInputSource(DATA_INPUT_SOURCE_TYPE(MAIN_WINDOW));

                    return EN_REDRAW_LIST;

                case 2: //from case MAPP_UIMENUFUNC_WB_ADJUST_TEMPERATURE:
                    ST_PICTURE.eColorTemp =
                       (EN_MS_COLOR_TEMP)MApp_ZUI_ACT_DecIncValue_Cycle(bInc,(U16) ST_PICTURE.eColorTemp, MS_COLOR_TEMP_MIN, MS_COLOR_TEMP_MAX, 1);
               #if 0//VGA_HDMI_YUV_POINT_TO_POINT
                    if(IsHDMIInUse()&&MDrv_PQ_Get_HDMIPCMode())
                    {
                         MApi_XC_ACE_SetPCYUV2RGB(MAIN_WINDOW, FALSE);

                       #if ENABLE_NEW_COLORTEMP_METHOD
                            #if ENABLE_PRECISE_RGBBRIGHTNESS
                               MApi_XC_ACE_PicSetColorTemp(MAIN_WINDOW, FALSE, (XC_ACE_color_temp_ex *) &ST_COLOR_TEMP);
                            #else
                               MApi_XC_ACE_PicSetColorTemp(MAIN_WINDOW, FALSE, (XC_ACE_color_temp *) &ST_COLOR_TEMP);
                            #endif
                      #else
                            #if ENABLE_PRECISE_RGBBRIGHTNESS
                               MApi_XC_ACE_PicSetColorTemp( MAIN_WINDOW, FALSE, (XC_ACE_color_temp_ex *) &ST_COLOR_TEMP );
                               MApi_XC_ACE_PicSetBrightnessPreciseInVsync(MAIN_WINDOW, MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cRedOffset, BRIGHTNESS_R ), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cGreenOffset, BRIGHTNESS_G), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cBlueOffset, BRIGHTNESS_B));
                            #else
                               MApi_XC_ACE_PicSetColorTemp( MAIN_WINDOW, FALSE, (XC_ACE_color_temp *) &ST_COLOR_TEMP );
                               MApi_XC_ACE_PicSetBrightnessInVsync(MAIN_WINDOW, MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cRedOffset, BRIGHTNESS_R ), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cGreenOffset, BRIGHTNESS_G), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cBlueOffset, BRIGHTNESS_B));
                            #endif
                      #endif
                  }
                  else
                 #endif
                  {
                    #if ENABLE_NEW_COLORTEMP_METHOD
                        #if ENABLE_PRECISE_RGBBRIGHTNESS
                            MApi_XC_ACE_PicSetColorTemp(MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), (XC_ACE_color_temp_ex *) &ST_COLOR_TEMP);
                        #else
                            MApi_XC_ACE_PicSetColorTemp(MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), (XC_ACE_color_temp *) &ST_COLOR_TEMP);
                        #endif
                    #else
                        #if ENABLE_PRECISE_RGBBRIGHTNESS
                            MApi_XC_ACE_PicSetColorTemp( MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), (XC_ACE_color_temp_ex *) &ST_COLOR_TEMP );
                            MApi_XC_ACE_PicSetBrightnessPreciseInVsync(MAIN_WINDOW, MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cRedOffset, BRIGHTNESS_R ), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cGreenOffset, BRIGHTNESS_G), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cBlueOffset, BRIGHTNESS_B));
                        #else
                            MApi_XC_ACE_PicSetColorTemp( MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), (XC_ACE_color_temp *) &ST_COLOR_TEMP );
                            MApi_XC_ACE_PicSetBrightnessInVsync(MAIN_WINDOW, MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cRedOffset, BRIGHTNESS_R ), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cGreenOffset, BRIGHTNESS_G), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cBlueOffset, BRIGHTNESS_B));
                        #endif
                    #endif
                    #ifdef ENABLE_GAMMA_FOR_COLORTEMP
                        MApi_XC_Sys_AdjustGammaTbl(FORCE_SET_VALUE);
                    #endif
                   }
                    return EN_REDRAW_ITEM;

                case 3: //from case MAPP_UIMENUFUNC_WB_ADJUST_REDGAIN:
                    ST_COLOR_TEMP.cRedColor =(U8) MApp_ZUI_ACT_DecIncValue_Cycle(bInc, (U16)ST_COLOR_TEMP.cRedColor, 0, 0xFF, 1);
                #if 0//VGA_HDMI_YUV_POINT_TO_POINT
                    if(IsHDMIInUse()&&MDrv_PQ_Get_HDMIPCMode())
                    {
                         MApi_XC_ACE_SetPCYUV2RGB(MAIN_WINDOW, FALSE);

                       #if ENABLE_NEW_COLORTEMP_METHOD
                            #if ENABLE_PRECISE_RGBBRIGHTNESS
                               MApi_XC_ACE_PicSetColorTemp(MAIN_WINDOW, FALSE, (XC_ACE_color_temp_ex *) &ST_COLOR_TEMP);
                            #else
                               MApi_XC_ACE_PicSetColorTemp(MAIN_WINDOW, FALSE, (XC_ACE_color_temp *) &ST_COLOR_TEMP);
                            #endif
                      #else
                            #if ENABLE_PRECISE_RGBBRIGHTNESS
                               MApi_XC_ACE_PicSetColorTemp( MAIN_WINDOW, FALSE, (XC_ACE_color_temp_ex *) &ST_COLOR_TEMP );
                               MApi_XC_ACE_PicSetBrightnessPreciseInVsync(MAIN_WINDOW, MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cRedOffset, BRIGHTNESS_R ), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cGreenOffset, BRIGHTNESS_G), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cBlueOffset, BRIGHTNESS_B));
                            #else
                               MApi_XC_ACE_PicSetColorTemp( MAIN_WINDOW, FALSE, (XC_ACE_color_temp *) &ST_COLOR_TEMP );
                               MApi_XC_ACE_PicSetBrightnessInVsync(MAIN_WINDOW, MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cRedOffset, BRIGHTNESS_R ), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cGreenOffset, BRIGHTNESS_G), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cBlueOffset, BRIGHTNESS_B));
                            #endif
                      #endif
                  }
                  else
                 #endif
                  {
                    #if ENABLE_NEW_COLORTEMP_METHOD
                        #if ENABLE_PRECISE_RGBBRIGHTNESS
                            MApi_XC_ACE_PicSetColorTemp(MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), (XC_ACE_color_temp_ex *) &ST_COLOR_TEMP);
                        #else
                            MApi_XC_ACE_PicSetColorTemp(MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), (XC_ACE_color_temp *) &ST_COLOR_TEMP);
                        #endif
                    #else
                        #if ENABLE_PRECISE_RGBBRIGHTNESS
                            MApi_XC_ACE_PicSetColorTemp( MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), (XC_ACE_color_temp_ex *) &ST_COLOR_TEMP );
                            MApi_XC_ACE_PicSetBrightnessPreciseInVsync(MAIN_WINDOW, MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cRedOffset, BRIGHTNESS_R ), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cGreenOffset, BRIGHTNESS_G), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cBlueOffset, BRIGHTNESS_B));
                        #else
                            MApi_XC_ACE_PicSetColorTemp( MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), (XC_ACE_color_temp *) &ST_COLOR_TEMP );
                            MApi_XC_ACE_PicSetBrightnessInVsync(MAIN_WINDOW, MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cRedOffset, BRIGHTNESS_R ), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cGreenOffset, BRIGHTNESS_G), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cBlueOffset, BRIGHTNESS_B));
                        #endif
                    #endif
                    }
                    MApp_SaveWhiteBalanceSetting(DATA_INPUT_SOURCE_TYPE(MAIN_WINDOW));
                    return EN_REDRAW_ITEM;

                case 4: //from case MAPP_UIMENUFUNC_WB_ADJUST_GREENGAIN:
                    ST_COLOR_TEMP.cGreenColor = (U8)MApp_ZUI_ACT_DecIncValue_Cycle(bInc,(U16) ST_COLOR_TEMP.cGreenColor, 0, 0xFF, 1);
               #if 0//VGA_HDMI_YUV_POINT_TO_POINT
                    if(IsHDMIInUse()&&MDrv_PQ_Get_HDMIPCMode())
                    {
                         MApi_XC_ACE_SetPCYUV2RGB(MAIN_WINDOW, FALSE);

                       #if ENABLE_NEW_COLORTEMP_METHOD
                            #if ENABLE_PRECISE_RGBBRIGHTNESS
                               MApi_XC_ACE_PicSetColorTemp(MAIN_WINDOW, FALSE, (XC_ACE_color_temp_ex *) &ST_COLOR_TEMP);
                            #else
                               MApi_XC_ACE_PicSetColorTemp(MAIN_WINDOW, FALSE, (XC_ACE_color_temp *) &ST_COLOR_TEMP);
                            #endif
                      #else
                            #if ENABLE_PRECISE_RGBBRIGHTNESS
                               MApi_XC_ACE_PicSetColorTemp( MAIN_WINDOW, FALSE, (XC_ACE_color_temp_ex *) &ST_COLOR_TEMP );
                               MApi_XC_ACE_PicSetBrightnessPreciseInVsync(MAIN_WINDOW, MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cRedOffset, BRIGHTNESS_R ), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cGreenOffset, BRIGHTNESS_G), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cBlueOffset, BRIGHTNESS_B));
                            #else
                               MApi_XC_ACE_PicSetColorTemp( MAIN_WINDOW, FALSE, (XC_ACE_color_temp *) &ST_COLOR_TEMP );
                               MApi_XC_ACE_PicSetBrightnessInVsync(MAIN_WINDOW, MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cRedOffset, BRIGHTNESS_R ), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cGreenOffset, BRIGHTNESS_G), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cBlueOffset, BRIGHTNESS_B));
                            #endif
                      #endif
                  }
                  else
                 #endif
                  {
                    #if ENABLE_NEW_COLORTEMP_METHOD
                        #if ENABLE_PRECISE_RGBBRIGHTNESS
                            MApi_XC_ACE_PicSetColorTemp(MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), (XC_ACE_color_temp_ex *) &ST_COLOR_TEMP);
                        #else
                            MApi_XC_ACE_PicSetColorTemp(MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), (XC_ACE_color_temp *) &ST_COLOR_TEMP);
                        #endif
                    #else
                        #if ENABLE_PRECISE_RGBBRIGHTNESS
                            MApi_XC_ACE_PicSetColorTemp( MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), (XC_ACE_color_temp_ex *) &ST_COLOR_TEMP );
                            MApi_XC_ACE_PicSetBrightnessPreciseInVsync(MAIN_WINDOW, MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cRedOffset, BRIGHTNESS_R ), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cGreenOffset, BRIGHTNESS_G), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cBlueOffset, BRIGHTNESS_B));
                        #else
                            MApi_XC_ACE_PicSetColorTemp( MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), (XC_ACE_color_temp *) &ST_COLOR_TEMP );
                            MApi_XC_ACE_PicSetBrightnessInVsync(MAIN_WINDOW, MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cRedOffset, BRIGHTNESS_R ), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cGreenOffset, BRIGHTNESS_G), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cBlueOffset, BRIGHTNESS_B));
                        #endif
                    #endif
                    }
                    MApp_SaveWhiteBalanceSetting(DATA_INPUT_SOURCE_TYPE(MAIN_WINDOW));
                    return EN_REDRAW_ITEM;

                case 5: //from case MAPP_UIMENUFUNC_WB_ADJUST_BLUEGAIN:
                    ST_COLOR_TEMP.cBlueColor = (U8)MApp_ZUI_ACT_DecIncValue_Cycle(bInc, (U16)ST_COLOR_TEMP.cBlueColor, 0, 0xFF, 1);
               #if 0//VGA_HDMI_YUV_POINT_TO_POINT
                    if(IsHDMIInUse()&&MDrv_PQ_Get_HDMIPCMode())
                    {
                         MApi_XC_ACE_SetPCYUV2RGB(MAIN_WINDOW, FALSE);

                       #if ENABLE_NEW_COLORTEMP_METHOD
                            #if ENABLE_PRECISE_RGBBRIGHTNESS
                               MApi_XC_ACE_PicSetColorTemp(MAIN_WINDOW, FALSE, (XC_ACE_color_temp_ex *) &ST_COLOR_TEMP);
                            #else
                               MApi_XC_ACE_PicSetColorTemp(MAIN_WINDOW, FALSE, (XC_ACE_color_temp *) &ST_COLOR_TEMP);
                            #endif
                      #else
                            #if ENABLE_PRECISE_RGBBRIGHTNESS
                               MApi_XC_ACE_PicSetColorTemp( MAIN_WINDOW, FALSE, (XC_ACE_color_temp_ex *) &ST_COLOR_TEMP );
                               MApi_XC_ACE_PicSetBrightnessPreciseInVsync(MAIN_WINDOW, MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cRedOffset, BRIGHTNESS_R ), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cGreenOffset, BRIGHTNESS_G), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cBlueOffset, BRIGHTNESS_B));
                            #else
                               MApi_XC_ACE_PicSetColorTemp( MAIN_WINDOW, FALSE, (XC_ACE_color_temp *) &ST_COLOR_TEMP );
                               MApi_XC_ACE_PicSetBrightnessInVsync(MAIN_WINDOW, MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cRedOffset, BRIGHTNESS_R ), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cGreenOffset, BRIGHTNESS_G), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cBlueOffset, BRIGHTNESS_B));
                            #endif
                      #endif
                  }
                  else
                 #endif
                    {
                    #if ENABLE_NEW_COLORTEMP_METHOD
                        #if ENABLE_PRECISE_RGBBRIGHTNESS
                            MApi_XC_ACE_PicSetColorTemp(MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), (XC_ACE_color_temp_ex *) &ST_COLOR_TEMP);
                        #else
                            MApi_XC_ACE_PicSetColorTemp(MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), (XC_ACE_color_temp *) &ST_COLOR_TEMP);
                        #endif
                    #else
                        #if ENABLE_PRECISE_RGBBRIGHTNESS
                            MApi_XC_ACE_PicSetColorTemp( MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), (XC_ACE_color_temp_ex *) &ST_COLOR_TEMP );
                            MApi_XC_ACE_PicSetBrightnessPreciseInVsync(MAIN_WINDOW, MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cRedOffset, BRIGHTNESS_R ), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cGreenOffset, BRIGHTNESS_G), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cBlueOffset, BRIGHTNESS_B));
                        #else
                            MApi_XC_ACE_PicSetColorTemp( MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), (XC_ACE_color_temp *) &ST_COLOR_TEMP );
                            MApi_XC_ACE_PicSetBrightnessInVsync(MAIN_WINDOW, MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cRedOffset, BRIGHTNESS_R ), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cGreenOffset, BRIGHTNESS_G), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cBlueOffset, BRIGHTNESS_B));
                        #endif
                    #endif
                    }
                    MApp_SaveWhiteBalanceSetting(DATA_INPUT_SOURCE_TYPE(MAIN_WINDOW));
                    return EN_REDRAW_ITEM;

                case 7: //from case MAPP_UIMENUFUNC_WB_ADJUST_REDOFFSET:
                    ST_COLOR_TEMP.cRedOffset = MApp_ZUI_ACT_DecIncValue_Cycle(bInc, ST_COLOR_TEMP.cRedOffset, 0, 0x7FF, 1);
               #if 0//VGA_HDMI_YUV_POINT_TO_POINT
                    if(IsHDMIInUse()&&MDrv_PQ_Get_HDMIPCMode())
                    {
                         MApi_XC_ACE_SetPCYUV2RGB(MAIN_WINDOW, FALSE);

                       #if ENABLE_NEW_COLORTEMP_METHOD
                            #if ENABLE_PRECISE_RGBBRIGHTNESS
                               MApi_XC_ACE_PicSetColorTemp(MAIN_WINDOW, FALSE, (XC_ACE_color_temp_ex *) &ST_COLOR_TEMP);
                            #else
                               MApi_XC_ACE_PicSetColorTemp(MAIN_WINDOW, FALSE, (XC_ACE_color_temp *) &ST_COLOR_TEMP);
                            #endif
                      #else
                            #if ENABLE_PRECISE_RGBBRIGHTNESS
                               MApi_XC_ACE_PicSetColorTemp( MAIN_WINDOW, FALSE, (XC_ACE_color_temp_ex *) &ST_COLOR_TEMP );
                               MApi_XC_ACE_PicSetBrightnessPreciseInVsync(MAIN_WINDOW, MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cRedOffset, BRIGHTNESS_R ), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cGreenOffset, BRIGHTNESS_G), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cBlueOffset, BRIGHTNESS_B));
                            #else
                               MApi_XC_ACE_PicSetColorTemp( MAIN_WINDOW, FALSE, (XC_ACE_color_temp *) &ST_COLOR_TEMP );
                               MApi_XC_ACE_PicSetBrightnessInVsync(MAIN_WINDOW, MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cRedOffset, BRIGHTNESS_R ), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cGreenOffset, BRIGHTNESS_G), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cBlueOffset, BRIGHTNESS_B));
                            #endif
                      #endif
                  }
                  else
                 #endif
                    {
                    #if ENABLE_NEW_COLORTEMP_METHOD
                        #if ENABLE_PRECISE_RGBBRIGHTNESS
                            MApi_XC_ACE_PicSetColorTemp(MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), (XC_ACE_color_temp_ex *) &ST_COLOR_TEMP);
                        #else
                            MApi_XC_ACE_PicSetColorTemp(MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), (XC_ACE_color_temp *) &ST_COLOR_TEMP);
                        #endif
                    #else
                        #if ENABLE_PRECISE_RGBBRIGHTNESS
                            MApi_XC_ACE_PicSetColorTemp( MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), (XC_ACE_color_temp_ex *) &ST_COLOR_TEMP );
                            MApi_XC_ACE_PicSetBrightnessPreciseInVsync(MAIN_WINDOW, MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cRedOffset, BRIGHTNESS_R ), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cGreenOffset, BRIGHTNESS_G), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cBlueOffset, BRIGHTNESS_B));
                        #else
                            MApi_XC_ACE_PicSetColorTemp( MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), (XC_ACE_color_temp *) &ST_COLOR_TEMP );
                            MApi_XC_ACE_PicSetBrightnessInVsync(MAIN_WINDOW, MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cRedOffset, BRIGHTNESS_R ), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cGreenOffset, BRIGHTNESS_G), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cBlueOffset, BRIGHTNESS_B));
                        #endif
                    #endif
                    }
                    MApp_SaveWhiteBalanceSetting(DATA_INPUT_SOURCE_TYPE(MAIN_WINDOW));
                    return EN_REDRAW_ITEM;

                case 8: //from case MAPP_UIMENUFUNC_WB_ADJUST_GREENOFFSET:
                    ST_COLOR_TEMP.cGreenOffset = MApp_ZUI_ACT_DecIncValue_Cycle(bInc, ST_COLOR_TEMP.cGreenOffset, 0, 0x7FF, 1);
               #if 0//VGA_HDMI_YUV_POINT_TO_POINT
                    if(IsHDMIInUse()&&MDrv_PQ_Get_HDMIPCMode())
                    {
                         MApi_XC_ACE_SetPCYUV2RGB(MAIN_WINDOW, FALSE);

                       #if ENABLE_NEW_COLORTEMP_METHOD
                            #if ENABLE_PRECISE_RGBBRIGHTNESS
                               MApi_XC_ACE_PicSetColorTemp(MAIN_WINDOW, FALSE, (XC_ACE_color_temp_ex *) &ST_COLOR_TEMP);
                            #else
                               MApi_XC_ACE_PicSetColorTemp(MAIN_WINDOW, FALSE, (XC_ACE_color_temp *) &ST_COLOR_TEMP);
                            #endif
                      #else
                            #if ENABLE_PRECISE_RGBBRIGHTNESS
                               MApi_XC_ACE_PicSetColorTemp( MAIN_WINDOW, FALSE, (XC_ACE_color_temp_ex *) &ST_COLOR_TEMP );
                               MApi_XC_ACE_PicSetBrightnessPreciseInVsync(MAIN_WINDOW, MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cRedOffset, BRIGHTNESS_R ), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cGreenOffset, BRIGHTNESS_G), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cBlueOffset, BRIGHTNESS_B));
                            #else
                               MApi_XC_ACE_PicSetColorTemp( MAIN_WINDOW, FALSE, (XC_ACE_color_temp *) &ST_COLOR_TEMP );
                               MApi_XC_ACE_PicSetBrightnessInVsync(MAIN_WINDOW, MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cRedOffset, BRIGHTNESS_R ), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cGreenOffset, BRIGHTNESS_G), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cBlueOffset, BRIGHTNESS_B));
                            #endif
                      #endif
                  }
                  else
                 #endif
                    {
                    #if ENABLE_NEW_COLORTEMP_METHOD
                        #if ENABLE_PRECISE_RGBBRIGHTNESS
                            MApi_XC_ACE_PicSetColorTemp(MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), (XC_ACE_color_temp_ex *) &ST_COLOR_TEMP);
                        #else
                            MApi_XC_ACE_PicSetColorTemp(MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), (XC_ACE_color_temp *) &ST_COLOR_TEMP);
                        #endif
                    #else
                        #if ENABLE_PRECISE_RGBBRIGHTNESS
                            MApi_XC_ACE_PicSetColorTemp( MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), (XC_ACE_color_temp_ex *) &ST_COLOR_TEMP );
                            MApi_XC_ACE_PicSetBrightnessPreciseInVsync(MAIN_WINDOW, MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cRedOffset, BRIGHTNESS_R ), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cGreenOffset, BRIGHTNESS_G), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cBlueOffset, BRIGHTNESS_B));
                        #else
                            MApi_XC_ACE_PicSetColorTemp( MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), (XC_ACE_color_temp *) &ST_COLOR_TEMP );
                            MApi_XC_ACE_PicSetBrightnessInVsync(MAIN_WINDOW, MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cRedOffset, BRIGHTNESS_R ), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cGreenOffset, BRIGHTNESS_G), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cBlueOffset, BRIGHTNESS_B));
                        #endif
                    #endif
                    }
                    MApp_SaveWhiteBalanceSetting(DATA_INPUT_SOURCE_TYPE(MAIN_WINDOW));
                    return EN_REDRAW_ITEM;

                case 9: //from case MAPP_UIMENUFUNC_WB_ADJUST_BLUEOFFSET:
                    ST_COLOR_TEMP.cBlueOffset = MApp_ZUI_ACT_DecIncValue_Cycle(bInc, ST_COLOR_TEMP.cBlueOffset, 0, 0x7FF, 1);
               #if 0//VGA_HDMI_YUV_POINT_TO_POINT
                    if(IsHDMIInUse()&&MDrv_PQ_Get_HDMIPCMode())
                    {
                         MApi_XC_ACE_SetPCYUV2RGB(MAIN_WINDOW, FALSE);

                       #if ENABLE_NEW_COLORTEMP_METHOD
                            #if ENABLE_PRECISE_RGBBRIGHTNESS
                               MApi_XC_ACE_PicSetColorTemp(MAIN_WINDOW, FALSE, (XC_ACE_color_temp_ex *) &ST_COLOR_TEMP);
                            #else
                               MApi_XC_ACE_PicSetColorTemp(MAIN_WINDOW, FALSE, (XC_ACE_color_temp *) &ST_COLOR_TEMP);
                            #endif
                      #else
                            #if ENABLE_PRECISE_RGBBRIGHTNESS
                               MApi_XC_ACE_PicSetColorTemp( MAIN_WINDOW, FALSE, (XC_ACE_color_temp_ex *) &ST_COLOR_TEMP );
                               MApi_XC_ACE_PicSetBrightnessPreciseInVsync(MAIN_WINDOW, MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cRedOffset, BRIGHTNESS_R ), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cGreenOffset, BRIGHTNESS_G), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cBlueOffset, BRIGHTNESS_B));
                            #else
                               MApi_XC_ACE_PicSetColorTemp( MAIN_WINDOW, FALSE, (XC_ACE_color_temp *) &ST_COLOR_TEMP );
                               MApi_XC_ACE_PicSetBrightnessInVsync(MAIN_WINDOW, MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cRedOffset, BRIGHTNESS_R ), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cGreenOffset, BRIGHTNESS_G), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cBlueOffset, BRIGHTNESS_B));
                            #endif
                      #endif
                  }
                  else
                 #endif
                    {
                    #if ENABLE_NEW_COLORTEMP_METHOD
                        #if ENABLE_PRECISE_RGBBRIGHTNESS
                            MApi_XC_ACE_PicSetColorTemp(MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), (XC_ACE_color_temp_ex *) &ST_COLOR_TEMP);
                        #else
                            MApi_XC_ACE_PicSetColorTemp(MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), (XC_ACE_color_temp *) &ST_COLOR_TEMP);
                        #endif
                    #else
                        #if ENABLE_PRECISE_RGBBRIGHTNESS
                            MApi_XC_ACE_PicSetColorTemp( MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), (XC_ACE_color_temp_ex *) &ST_COLOR_TEMP );
                            MApi_XC_ACE_PicSetBrightnessPreciseInVsync(MAIN_WINDOW, MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cRedOffset, BRIGHTNESS_R ), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cGreenOffset, BRIGHTNESS_G), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cBlueOffset, BRIGHTNESS_B));
                        #else
                            MApi_XC_ACE_PicSetColorTemp( MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), (XC_ACE_color_temp *) &ST_COLOR_TEMP );
                            MApi_XC_ACE_PicSetBrightnessInVsync(MAIN_WINDOW, MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cRedOffset, BRIGHTNESS_R ), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cGreenOffset, BRIGHTNESS_G), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cBlueOffset, BRIGHTNESS_B));
                        #endif
                    #endif
                    }
                    MApp_SaveWhiteBalanceSetting(DATA_INPUT_SOURCE_TYPE(MAIN_WINDOW));
                    return EN_REDRAW_ITEM;

                case 10: //from case MAPP_UIMENUFUNC_WB_ADJUST_COPYALL:
                    MApp_CopyWhiteBalanceSettingToAllInput();
                    g_CopyALLResult= TRUE;

                    return EN_REDRAW_ITEM;
            }
            break;

            case EN_FACTORY_PAGE_QMAP_PAGE:
            {
                U8 u8IPIdx, u8TabIdx, u8IPNum, u8TabNum;

                u8IPIdx = _u8IPIndex;
                u8IPNum = _u8IPNumber;
                if(u8IPIdx < u8IPNum)
                {
                    u8TabNum = (U8)MDrv_PQ_GetTableNum(PQ_MAIN_WINDOW, (U16)u8IPIdx);
                    //printf("IP:%u [%s], tabnum=%u\n", u8IPIdx, MDrv_PQ_GetIPName(u8IPIdx), u8TabNum);

                    u8TabIdx = (U8)MDrv_PQ_GetCurrentTableIndex(PQ_MAIN_WINDOW, (U16)u8IPIdx);
                    //printf(">>> TAB[%bu] <<<\n", u8TabIdx);
                    if(bInc)
                    {
                        u8TabIdx++;
                        if(u8TabIdx >= u8TabNum)
                        {
                            u8TabIdx = 0;
                        }
                    }
                    else
                    {
                        if(u8TabIdx == 0)
                        {
                            u8TabIdx = u8TabNum - 1;
                        }
                        else
                        {
                            u8TabIdx--;
                        }
                    }
                    //printf(">>>=== ID[%bu]  TAB[%bu] ===<<<\n", u8IPIdx, u8TabIdx);
                    MDrv_PQ_LoadTable(PQ_MAIN_WINDOW, (U16)u8TabIdx, (U16)u8IPIdx);
                    return EN_REDRAW_ITEM;
                    //printf("TAB:%u [%s]\n", u8TabIdx,
                    //(u8TabIdx == PQ_IP_NULL) ? "null" : MDrv_PQ_GetTableName(u8IPIdx, u8TabIdx));
                }
            }
            break;

            #if ENABLE_PIP
            case EN_FACTORY_PAGE_PIP_POP:
                switch(u8Item)
                {
                    case 0:
                    {
                        if(stGenSetting.g_stPipSetting.bPipEnable)
                        {
                            if(stGenSetting.g_stPipSetting.enPipSoundSrc==EN_PIP_SOUND_SRC_SUB)
                            {
                                stGenSetting.g_stPipSetting.enPipSoundSrc=EN_PIP_SOUND_SRC_MAIN;
                                MApp_InputSource_PIP_ChangeAudioSource(MAIN_WINDOW);
                            }
                            UI_SUB_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_NONE;
                            MApp_InputSource_ChangeInputSource(SUB_WINDOW);
                            if((stGenSetting.g_stPipSetting.enPipMode==EN_PIP_MODE_POP) ||(stGenSetting.g_stPipSetting.enPipMode==EN_PIP_MODE_POP_FULL))
                            {
                                MS_WINDOW_TYPE stPOPMainWin;
                                stPOPMainWin.x = 0;
                                stPOPMainWin.y = 0;
                                stPOPMainWin.width = PANEL_WIDTH;
                                stPOPMainWin.height = PANEL_HEIGHT;
                                msAPI_Scaler_SetScreenMute(E_SCREEN_MUTE_FREERUN, ENABLE, 0, MAIN_WINDOW);
                                msAPI_Scaler_SetScreenMute(E_SCREEN_MUTE_FREERUN, ENABLE, 0, SUB_WINDOW);
                                MApp_Scaler_SetWindow(
                                NULL,
                                NULL,
                                NULL,
                                stSystemInfo[MAIN_WINDOW].enAspectRatio,
                                SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW),
                                MAIN_WINDOW);
                                msAPI_Scaler_SetScreenMute(E_SCREEN_MUTE_FREERUN, DISABLE, 0, MAIN_WINDOW);
                                msAPI_Scaler_SetScreenMute(E_SCREEN_MUTE_FREERUN, DISABLE, 0, SUB_WINDOW);
                            }
                        }
                        stGenSetting.g_stPipSetting.enPipMode = EN_PIP_MODE_OFF;
                        stGenSetting.g_stPipSetting.bPipEnable = (BOOLEAN)!stGenSetting.g_stPipSetting.bPipEnable;
                        return EN_REDRAW_ITEM;
                    }
                    break;
                    case 1:
                    {
                        stGenSetting.g_stPipSetting.u8BorderWidth =
                            (U16)MApp_ZUI_ACT_DecIncValue_Cycle(bInc,
                                (U16)stGenSetting.g_stPipSetting.u8BorderWidth, 0x1, 0xA, 1);
                        //set sub window border color as yellow temporarily
                        MApi_XC_SetBorderFormat( stGenSetting.g_stPipSetting.u8BorderWidth, stGenSetting.g_stPipSetting.u8BorderWidth<<4, stGenSetting.g_stPipSetting.u8BorderWidth, stGenSetting.g_stPipSetting.u8BorderWidth<<4, 0xFC, SUB_WINDOW );
                        return EN_REDRAW_ITEM;
                    }
                    break;
                }
            break;
            #endif
            case EN_FACTORY_PAGE_SW_INFO_PAGE:
                switch(u8Item)
                {

                }
            break;
            #if ENABLE_AUTOTEST
            case EN_FACTORY_PAGE_BMTEST_PAGE:
               switch(u8Item)
                {

                }
            break;
            #endif

          #if ENABLE_AUTO_DQS_Factory
            case EN_FACTORY_PAGE_BIST_TEST:
                switch(u8Item)
                {

                }
            break;
          #endif

            case EN_FACTORY_PAGE_PEQ:
                // TODO: fix me
                switch(u8Item)
                {
                    case EN_FacAdj_FO1_Coarse:
                        ST_AUDIO_PEQ.u16_Fo1Value = MApp_ZUI_ACT_DecIncValue_Cycle(bInc,ST_AUDIO_PEQ.u16_Fo1Value, PEQ_FO_MIN, PEQ_FO_MAX, PEQ_FO_COARSE_STEP);
                        msAPI_AUD_SetPEQ(0, ST_AUDIO_PEQ.u8_Gain1Value, (U8)(ST_AUDIO_PEQ.u16_Fo1Value/100), (U8)(ST_AUDIO_PEQ.u16_Fo1Value%100), ST_AUDIO_PEQ.u8_Q1Value);
                        return EN_REDRAW_ITEM;

                    case EN_FacAdj_FO1_Fine:
                        ST_AUDIO_PEQ.u16_Fo1Value = MApp_ZUI_ACT_DecIncValue_Cycle(bInc,ST_AUDIO_PEQ.u16_Fo1Value, PEQ_FO_MIN, PEQ_FO_MAX, PEQ_FO_FINE_STEP);
                        msAPI_AUD_SetPEQ(0, ST_AUDIO_PEQ.u8_Gain1Value, (U8)(ST_AUDIO_PEQ.u16_Fo1Value/100), (U8)(ST_AUDIO_PEQ.u16_Fo1Value%100), ST_AUDIO_PEQ.u8_Q1Value);
                        return EN_REDRAW_ITEM;

                    case EN_FacAdj_FO2_Coarse:
                        ST_AUDIO_PEQ.u16_Fo2Value = MApp_ZUI_ACT_DecIncValue_Cycle(bInc,ST_AUDIO_PEQ.u16_Fo2Value, PEQ_FO_MIN, PEQ_FO_MAX, PEQ_FO_COARSE_STEP);
                        msAPI_AUD_SetPEQ(1, ST_AUDIO_PEQ.u8_Gain2Value, (U8)(ST_AUDIO_PEQ.u16_Fo2Value/100), (U8)(ST_AUDIO_PEQ.u16_Fo2Value%100), ST_AUDIO_PEQ.u8_Q2Value);
                        return EN_REDRAW_ITEM;

                    case EN_FacAdj_FO2_Fine:
                        ST_AUDIO_PEQ.u16_Fo2Value = MApp_ZUI_ACT_DecIncValue_Cycle(bInc,ST_AUDIO_PEQ.u16_Fo2Value, PEQ_FO_MIN, PEQ_FO_MAX, PEQ_FO_FINE_STEP);
                        msAPI_AUD_SetPEQ(1, ST_AUDIO_PEQ.u8_Gain2Value, (U8)(ST_AUDIO_PEQ.u16_Fo2Value/100), (U8)(ST_AUDIO_PEQ.u16_Fo2Value%100), ST_AUDIO_PEQ.u8_Q2Value);
                        return EN_REDRAW_ITEM;

                    case EN_FacAdj_FO3_Coarse:
                        ST_AUDIO_PEQ.u16_Fo3Value = MApp_ZUI_ACT_DecIncValue_Cycle(bInc,ST_AUDIO_PEQ.u16_Fo3Value, PEQ_FO_MIN, PEQ_FO_MAX, PEQ_FO_COARSE_STEP);
                        msAPI_AUD_SetPEQ(2, ST_AUDIO_PEQ.u8_Gain3Value, (U8)(ST_AUDIO_PEQ.u16_Fo3Value/100), (U8)(ST_AUDIO_PEQ.u16_Fo3Value%100), ST_AUDIO_PEQ.u8_Q3Value);
                        return EN_REDRAW_ITEM;

                    case EN_FacAdj_FO3_Fine:
                        ST_AUDIO_PEQ.u16_Fo3Value = MApp_ZUI_ACT_DecIncValue_Cycle(bInc,ST_AUDIO_PEQ.u16_Fo3Value, PEQ_FO_MIN, PEQ_FO_MAX, PEQ_FO_FINE_STEP);
                        msAPI_AUD_SetPEQ(2, ST_AUDIO_PEQ.u8_Gain3Value, (U8)(ST_AUDIO_PEQ.u16_Fo3Value/100), (U8)(ST_AUDIO_PEQ.u16_Fo3Value%100), ST_AUDIO_PEQ.u8_Q3Value);
                        return EN_REDRAW_ITEM;

                    case  EN_FacAdj_Gain1:
                        ST_AUDIO_PEQ.u8_Gain1Value = MApp_ZUI_ACT_DecIncValue_Cycle(bInc,ST_AUDIO_PEQ.u8_Gain1Value, PEQ_GAIN_MIN, PEQ_GAIN_MAX, PEQ_GAIN_STEP);
                        msAPI_AUD_SetPEQ(0, ST_AUDIO_PEQ.u8_Gain1Value, (U8)(ST_AUDIO_PEQ.u16_Fo1Value/100), (U8)(ST_AUDIO_PEQ.u16_Fo1Value%100), ST_AUDIO_PEQ.u8_Q1Value);
                        return EN_REDRAW_ITEM;

                    case EN_FacAdj_Gain2:
                        ST_AUDIO_PEQ.u8_Gain2Value = MApp_ZUI_ACT_DecIncValue_Cycle(bInc,ST_AUDIO_PEQ.u8_Gain2Value, PEQ_GAIN_MIN, PEQ_GAIN_MAX, PEQ_GAIN_STEP);
                        msAPI_AUD_SetPEQ(1, ST_AUDIO_PEQ.u8_Gain2Value, (U8)(ST_AUDIO_PEQ.u16_Fo2Value/100), (U8)(ST_AUDIO_PEQ.u16_Fo2Value%100), ST_AUDIO_PEQ.u8_Q2Value);
                        return EN_REDRAW_ITEM;

                    case EN_FacAdj_Gain3:
                        ST_AUDIO_PEQ.u8_Gain3Value = MApp_ZUI_ACT_DecIncValue_Cycle(bInc,ST_AUDIO_PEQ.u8_Gain3Value, PEQ_GAIN_MIN, PEQ_GAIN_MAX, PEQ_GAIN_STEP);
                        msAPI_AUD_SetPEQ(2, ST_AUDIO_PEQ.u8_Gain3Value, (U8)(ST_AUDIO_PEQ.u16_Fo3Value/100), (U8)(ST_AUDIO_PEQ.u16_Fo3Value%100), ST_AUDIO_PEQ.u8_Q3Value);
                        return EN_REDRAW_ITEM;

                    case EN_FacAdj_Q1:
                        ST_AUDIO_PEQ.u8_Q1Value = MApp_ZUI_ACT_DecIncValue_Cycle(bInc,ST_AUDIO_PEQ.u8_Q1Value, PEQ_Q_MIN, PEQ_Q_MAX, PEQ_Q_STEP);
                        msAPI_AUD_SetPEQ(0, ST_AUDIO_PEQ.u8_Gain1Value, (U8)(ST_AUDIO_PEQ.u16_Fo1Value/100), (U8)(ST_AUDIO_PEQ.u16_Fo1Value%100), ST_AUDIO_PEQ.u8_Q1Value);
                        return EN_REDRAW_ITEM;

                    case EN_FacAdj_Q2:
                        ST_AUDIO_PEQ.u8_Q2Value = MApp_ZUI_ACT_DecIncValue_Cycle(bInc,ST_AUDIO_PEQ.u8_Q2Value, PEQ_Q_MIN, PEQ_Q_MAX, PEQ_Q_STEP);
                        msAPI_AUD_SetPEQ(1, ST_AUDIO_PEQ.u8_Gain2Value, (U8)(ST_AUDIO_PEQ.u16_Fo2Value/100), (U8)(ST_AUDIO_PEQ.u16_Fo2Value%100), ST_AUDIO_PEQ.u8_Q2Value);
                        return EN_REDRAW_ITEM;

                    case EN_FacAdj_Q3:
                        ST_AUDIO_PEQ.u8_Q3Value = MApp_ZUI_ACT_DecIncValue_Cycle(bInc,ST_AUDIO_PEQ.u8_Q3Value, PEQ_Q_MIN, PEQ_Q_MAX, PEQ_Q_STEP);
                        msAPI_AUD_SetPEQ(2, ST_AUDIO_PEQ.u8_Gain3Value, (U8)(ST_AUDIO_PEQ.u16_Fo3Value/100), (U8)(ST_AUDIO_PEQ.u16_Fo3Value%100), ST_AUDIO_PEQ.u8_Q3Value);
                        return EN_REDRAW_ITEM;

                }
                break;

            case EN_FACTORY_PAGE_SSC:
              #if(ENABLE_SSC)
                switch(u8Item)
                {
                    /* Enable/Disable MIU SSC */
                    case 0:
                        /* switching between enable and disbale */
                        stGenSetting.g_SSCSetting.SscMIUEnable = MApp_ZUI_ACT_DecIncValue_Cycle(bInc, stGenSetting.g_SSCSetting.SscMIUEnable, DISABLE, ENABLE, 1);
                        /* Set MIU SSC */
                        msAPI_MIU_SetSsc(stGenSetting.g_SSCSetting.MIUSscSpanKHzx10, stGenSetting.g_SSCSetting.MIUSscStepPercentagex100, stGenSetting.g_SSCSetting.SscMIUEnable );
                        MApp_SaveSSCData();
                        return EN_REDRAW_ITEM;

                    /* Increase/Decrease MIU SSC Span*/
                    case 1:
                        /* Increase/Decrease MIU SSC Span */
                        stGenSetting.g_SSCSetting.MIUSscSpanKHzx10 = MApp_ZUI_ACT_DecIncValue_Cycle(bInc, stGenSetting.g_SSCSetting.MIUSscSpanKHzx10, 20, MIU_SSC_SPAN_MAX, 1);
                        /* Set MIU SSC */
                        msAPI_MIU_SetSsc(stGenSetting.g_SSCSetting.MIUSscSpanKHzx10, stGenSetting.g_SSCSetting.MIUSscStepPercentagex100, stGenSetting.g_SSCSetting.SscMIUEnable );
                        MApp_SaveSSCData();
                        return EN_REDRAW_ITEM;

                    /* Increase/Decrease MIU SSC Step*/
                    case 2:
                        /* Increase/Decrease MIU SSC Step */
                       stGenSetting.g_SSCSetting.MIUSscStepPercentagex100 = MApp_ZUI_ACT_DecIncValue_Cycle(bInc, stGenSetting.g_SSCSetting.MIUSscStepPercentagex100, 1, MIU_SSC_STEP_MAX, 1);
                        /* Set MIU SSC */
                        msAPI_MIU_SetSsc(stGenSetting.g_SSCSetting.MIUSscSpanKHzx10, stGenSetting.g_SSCSetting.MIUSscStepPercentagex100, stGenSetting.g_SSCSetting.SscMIUEnable );
                        MApp_SaveSSCData();
                        return EN_REDRAW_ITEM;

                    /* Enable/Disable LVDS SSC */
                    case 4:
                        /* switching between enable and disbale */
                        stGenSetting.g_SSCSetting.SscLVDSEnale = MApp_ZUI_ACT_DecIncValue_Cycle(bInc, stGenSetting.g_SSCSetting.SscLVDSEnale, DISABLE, ENABLE, 1);
                        /* Set LVDS SSC */
                      #if (ENABLE_LVDSTORGB_CONVERTER == ENABLE)
                        g_IPanel.SetSSC( SSC_SPAN_PERIOD, SSC_STEP_PERCENT, DISABLE );
                      #else
                        g_IPanel.SetSSC( stGenSetting.g_SSCSetting.LVDSSscSpanKHzx10,
                                            stGenSetting.g_SSCSetting.LVDSSscStepPercentagex100,
                                            stGenSetting.g_SSCSetting.SscLVDSEnale);
                      #endif
                        MApp_SaveSSCData();
                        return EN_REDRAW_ITEM;

                    /* Increase/Descrease LVDS Span */
                    case 5:
                        stGenSetting.g_SSCSetting.LVDSSscSpanKHzx10= MApp_ZUI_ACT_DecIncValue_Cycle(bInc, stGenSetting.g_SSCSetting.LVDSSscSpanKHzx10, 0, LVDS_SSC_SPAN_MAX, 1);
                        /* Set LVDS SSC */
                      #if (ENABLE_LVDSTORGB_CONVERTER == ENABLE)
                        g_IPanel.SetSSC( SSC_SPAN_PERIOD, SSC_STEP_PERCENT, DISABLE );
                      #else
                        g_IPanel.SetSSC( stGenSetting.g_SSCSetting.LVDSSscSpanKHzx10,
                                            stGenSetting.g_SSCSetting.LVDSSscStepPercentagex100,
                                            stGenSetting.g_SSCSetting.SscLVDSEnale);
                      #endif
                        MApp_SaveSSCData();
                        return EN_REDRAW_ITEM;

                    /* Increase/Descrease LVDS Step */
                    case 6:
                        /* Increase/Decrease LVDS SSC Step */
                        stGenSetting.g_SSCSetting.LVDSSscStepPercentagex100= MApp_ZUI_ACT_DecIncValue_Cycle(bInc, stGenSetting.g_SSCSetting.LVDSSscStepPercentagex100, 0, LVDS_SSC_STEP_MAX, 1);
                        /* Set LVDS SSC */
                      #if (ENABLE_LVDSTORGB_CONVERTER == ENABLE)
                        g_IPanel.SetSSC( SSC_SPAN_PERIOD, SSC_STEP_PERCENT, DISABLE );
                      #else
                        g_IPanel.SetSSC( stGenSetting.g_SSCSetting.LVDSSscSpanKHzx10,
                                            stGenSetting.g_SSCSetting.LVDSSscStepPercentagex100,
                                            stGenSetting.g_SSCSetting.SscLVDSEnale);
                      #endif
                        MApp_SaveSSCData();
                        return EN_REDRAW_ITEM;
                }
              #endif
                break;

            case EN_FACTORY_PAGE_SPECIAL_SET:
                switch(u8Item)
                {
                case 0: //hour off
                #if ENABLE_CUS_AUTO_SLEEP_MODE
                    stGenSetting.g_Time.cAutoSleepFlag =
                        (EN_MENU_TIME_AutoOff)MApp_ZUI_ACT_DecIncValue_Cycle(bInc,
                        (U16)stGenSetting.g_Time.cAutoSleepFlag, 0,EN_Time_AutoOff_Num-1,1);
                #else
                    stGenSetting.g_Time.cAutoSleepFlag =
                        (EN_MENU_TIME_AutoOff)MApp_ZUI_ACT_DecIncValue_Cycle(bInc,
                            (U16)stGenSetting.g_Time.cAutoSleepFlag, 0,EN_FacAdj_2HourOff_Num-1,1);
                #endif
                    if( stGenSetting.g_Time.cAutoSleepFlag != EN_Time_AutoOff_Off)
                    {
                        MApp_Sleep_SetAutoOn_OffTime(ENABLE);
                    }
                    else
                    {
                        MApp_Sleep_SetAutoOn_OffTime(DISABLE);
                    }
                    return EN_REDRAW_ITEM;

                case 1: //WDT
                    if (!MDrv_Sys_IsWatchDogEnabled())
                        MDrv_Sys_EnableWatchDog();
                    else
                        MDrv_Sys_DisableWatchDog();

                    return EN_REDRAW_ITEM;
                case 2:  //from case MAPP_UIMENUFUNC_ADJUSTADC_WHITE_PATTERN:
                    stLMGenSetting.stMFactory_Adjust.enTMP_WHITE_PATTERN =
                        (EN_FACTORY_WHITE_PATTERN)MApp_ZUI_ACT_DecIncValue_Cycle(bInc,
                            (U16)stLMGenSetting.stMFactory_Adjust.enTMP_WHITE_PATTERN,0,(U16)(EN_FacAdj_WhitePattern_Num-1),1);

                    msAPI_Scaler_SetTestPattern(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW), (EN_TEST_COLOR) stLMGenSetting.stMFactory_Adjust.enTMP_WHITE_PATTERN);

                    return EN_REDRAW_ITEM;
              #if ENABLE_PVR
                 case 4:
                    stGenSetting.g_SysSetting.u8PVR_IsRecordAllChannel = (stGenSetting.g_SysSetting.u8PVR_IsRecordAllChannel > 0)? 0:1;

                    if(stGenSetting.g_SysSetting.u8PVR_IsRecordAllChannel)
                    {
                        MApp_Record_RecordAllEnable();
                    }
                    else
                    {
                        MApp_Record_RecordAllDisable();
                    }
                    return EN_REDRAW_ITEM;
              #endif // #if ENABLE_PVR

              #if (ENABLE_FACTORY_POWER_ON_MODE)
                 case 5:
                    stGenSetting.g_FactorySetting.u8PowerOnMode =
                        (POWERON_MODE_TYPE)MApp_ZUI_ACT_DecIncValue_Cycle(bInc,
                            (U16)stGenSetting.g_FactorySetting.u8PowerOnMode,POWERON_MODE_SAVE,(U16)(POWERON_MODE_NUMS-1),1);
                    MApp_SaveFactorySetting();
                 return EN_REDRAW_ITEM;
              #endif // #if ENABLE_FACTORY_POWER_ON_MODE

              #if (ENABLE_USB_DOWNLOAD_BIN&&ENABLE_PQ_BIN)
                 case 6:
                      g_PQUpdateResult = MApp_Usb_Download_PQBin();
                      gU32PQBootTimer=msAPI_Timer_GetTime0();
                      gbPQUpdateFinish=TRUE;
                     return EN_REDRAW_ITEM;
              #endif // #if ENABLE_USB_DOWNLOAD_BIN
#ifdef ENABLE_CUS_FACTORY_ATV_CH_PRSET
		  case 7:
			  if (stGenSetting.g_SysSetting.uFactoryChannelFlag)
			  {
				  stGenSetting.g_SysSetting.uFactoryChannelFlag = FALSE;
				  msAPI_ATV_ResetATVDataManager();
				  if(IsATVInUse())
				  msAPI_Tuner_ChangeProgram();		  
			  }
			  else
			  {
				  msAPI_ATV_Factory_CH_Preset();
				  stGenSetting.g_SysSetting.uFactoryChannelFlag = TRUE;
				  //printf("\nMin chan num	%d \n", msAPI_ATV_GetChannelMin());   
				  msAPI_ATV_SetCurrentProgramNumber(msAPI_ATV_GetChannelMin()-1);//set first channel num		
				  if(IsATVInUse())
				  msAPI_Tuner_ChangeProgram();
			  }
			  return EN_REDRAW_ITEM;
#endif
#if ENABLE_CUS_BURNING_MODE
case 8:
	if(stGenSetting.g_FactorySetting.fBuringMode)
	{
	stGenSetting.g_FactorySetting.fBuringMode = FALSE;
	MApp_MultiTasks_AdjustBurningMode(DISABLE);
	}
	else
	{
	stGenSetting.g_FactorySetting.fBuringMode = TRUE;
	}
	MApp_SaveFactorySetting();
	return EN_REDRAW_ITEM;

#endif
#if (PADS_PWM1_MODE != Unknown_pad_mux)
    case 10:
		PwmPeriod =
			(POWERON_MODE_TYPE)MApp_ZUI_ACT_DecIncValue_Cycle(bInc,
				PwmPeriod,0,0xffff,1);
		MDrv_PWM_Period(E_PWM_CH1, (U32)PwmPeriod);
    	return EN_REDRAW_ITEM;
 	case 11:
		Pwmduty=
			(POWERON_MODE_TYPE)MApp_ZUI_ACT_DecIncValue_Cycle(bInc,
				Pwmduty,0,0xff,1);
		MDrv_PWM_DutyCycle(E_PWM_CH1, (U32)Pwmduty);
		stGenSetting.g_SysSetting.bPanelVcom=Pwmduty;
		
		printf("\nstGenSetting.g_SysSetting.bPanelVcom	%d \n",stGenSetting.g_SysSetting.bPanelVcom);  
		MApp_SaveSysSetting();
 		return EN_REDRAW_ITEM;
	case 12:
		PwmDiv=
			(POWERON_MODE_TYPE)MApp_ZUI_ACT_DecIncValue_Cycle(bInc,
				PwmDiv,0,0xffff,1);
		MDrv_PWM_Div(E_PWM_CH1, PwmDiv);
		return EN_REDRAW_ITEM;
#endif
#if ENABLE_FACTORY_GAMMA
case 13:
	 	GammaEnable=!GammaEnable;
	 	MApi_XC_SetGammaOnOff(GammaEnable);
	 	return EN_REDRAW_ITEM;
#endif
                }
            break;

            case EN_FACTORY_PAGE_VIF1:
              #if ENABLE_VD_PACH_IN_CHINA
                switch(u8Item)
                {
                case 0:
                    stGenSetting.g_FactorySetting.u8AFEC_D4 = (U8)MApp_ZUI_ACT_DecIncValue_Cycle(bInc,
                        (U16)stGenSetting.g_FactorySetting.u8AFEC_D4, 0, 0xFF, 1);
                    MDrv_WriteByte(BK_AFEC_D4_ADDRESS, stGenSetting.g_FactorySetting.u8AFEC_D4);
                    MApp_SaveFactorySetting();
                    return EN_REDRAW_ITEM;

                case 1:
                    stGenSetting.g_FactorySetting.u8AFEC_D5_Bit2 = (U8)MApp_ZUI_ACT_DecIncValue_Cycle(bInc,
                        (U16)stGenSetting.g_FactorySetting.u8AFEC_D5_Bit2, 0, 1, 1);
                    MDrv_WriteByteMask(BK_AFEC_D5_ADDRESS, (stGenSetting.g_FactorySetting.u8AFEC_D5_Bit2<<2), BIT2);
                    MApp_SaveFactorySetting();
                    return EN_REDRAW_ITEM;
                case 2:
                    stGenSetting.g_FactorySetting.u8AFEC_D8_Bit3210 = (U8)MApp_ZUI_ACT_DecIncValue_Cycle(bInc,
                        (U16)stGenSetting.g_FactorySetting.u8AFEC_D8_Bit3210, 0, 0x0F, 1);
                    MDrv_WriteByteMask(BK_AFEC_D8_ADDRESS, stGenSetting.g_FactorySetting.u8AFEC_D8_Bit3210, 0x0F);
                    MApp_SaveFactorySetting();
                    return EN_REDRAW_ITEM;
                case 3:
                    stGenSetting.g_FactorySetting.u8AFEC_D9_Bit0 = (U8)MApp_ZUI_ACT_DecIncValue_Cycle(bInc,
                        (U16)stGenSetting.g_FactorySetting.u8AFEC_D9_Bit0, 0, 1, 1);
                    MDrv_WriteByteMask(BK_AFEC_D9_ADDRESS, stGenSetting.g_FactorySetting.u8AFEC_D9_Bit0, BIT0);
                    MApp_SaveFactorySetting();
                    return EN_REDRAW_ITEM;
                case 4:
                    {
                      U8 Index;
                      Index=Get_AFEC_A0_A1_MapToIndex(stGenSetting.g_FactorySetting.u16AFEC_A0_A1);
                      Index = (U8)MApp_ZUI_ACT_DecIncValue_Cycle(bInc, (U16)Index, 0, AFEC_A0_A1_ADJUST_NUM-1, 1);
                      stGenSetting.g_FactorySetting.u16AFEC_A0_A1=AFEC_A0_A1_DATA[Index];
                      MDrv_WriteByte(BK_AFEC_A0_ADDRESS, stGenSetting.g_FactorySetting.u16AFEC_A0_A1>>8);
                      MDrv_WriteByte(BK_AFEC_A1_ADDRESS, stGenSetting.g_FactorySetting.u16AFEC_A0_A1&0XFF);
                    MApp_SaveFactorySetting();
                    }
                    return EN_REDRAW_ITEM;
                case 5:
                    stGenSetting.g_FactorySetting.u8AFEC_66_Bit76 = (U8)MApp_ZUI_ACT_DecIncValue_Cycle(bInc,
                        (U16)stGenSetting.g_FactorySetting.u8AFEC_66_Bit76, 0, 3, 1);
                    MDrv_WriteByteMask(BK_AFEC_66_ADDRESS, (stGenSetting.g_FactorySetting.u8AFEC_66_Bit76<<6), (BIT7|BIT6));
                    MApp_SaveFactorySetting();
                    return EN_REDRAW_ITEM;
                case 6:
                    stGenSetting.g_FactorySetting.u8AFEC_6E_Bit7654 = (U8)MApp_ZUI_ACT_DecIncValue_Cycle(bInc,
                        (U16)stGenSetting.g_FactorySetting.u8AFEC_6E_Bit7654, 0, 0x0F, 1);
                    MDrv_WriteByteMask(BK_AFEC_6E_ADDRESS, (stGenSetting.g_FactorySetting.u8AFEC_6E_Bit7654<<4),0xF0);
                    MApp_SaveFactorySetting();
                    return EN_REDRAW_ITEM;
                case 7:
                    stGenSetting.g_FactorySetting.u8AFEC_6E_Bit3210 = (U8)MApp_ZUI_ACT_DecIncValue_Cycle(bInc,
                        (U16)stGenSetting.g_FactorySetting.u8AFEC_6E_Bit3210, 0, 0x0F, 1);
                    MDrv_WriteByteMask(BK_AFEC_6E_ADDRESS, stGenSetting.g_FactorySetting.u8AFEC_6E_Bit3210,0x0F);
                    MApp_SaveFactorySetting();
                    return EN_REDRAW_ITEM;
                case 8:
                    stGenSetting.g_FactorySetting.u8AFEC_D7_LOW_BOUND= (U8)MApp_ZUI_ACT_DecIncValue_Cycle(bInc,
                        (U16)stGenSetting.g_FactorySetting.u8AFEC_D7_LOW_BOUND, 0, 0xFF, 1);
                    MDrv_WriteByte(BK_AFEC_D7_ADDRESS, stGenSetting.g_FactorySetting.u8AFEC_D7_LOW_BOUND);
                    MApp_SaveFactorySetting();
                    return EN_REDRAW_ITEM;

                case 9:
                    stGenSetting.g_FactorySetting.u8AFEC_D7_HIGH_BOUND= (U8)MApp_ZUI_ACT_DecIncValue_Cycle(bInc,
                        (U16)stGenSetting.g_FactorySetting.u8AFEC_D7_HIGH_BOUND, 0, 0xFF, 1);
                    MDrv_WriteByte(BK_AFEC_D7_ADDRESS, stGenSetting.g_FactorySetting.u8AFEC_D7_HIGH_BOUND);
                    MApp_SaveFactorySetting();
                    return EN_REDRAW_ITEM;
                case 10:
                    if(stGenSetting.g_FactorySetting.u8AFEC_43==0x14)
                        stGenSetting.g_FactorySetting.u8AFEC_43=0x74;//fix gain
                    else
                        stGenSetting.g_FactorySetting.u8AFEC_43=0x14;//auto gain
                    MDrv_WriteByteMask(BK_AFEC_43_ADDRESS, stGenSetting.g_FactorySetting.u8AFEC_43, 0xFF);
                    MDrv_WriteByteMask(BK_AFEC_44_ADDRESS, stGenSetting.g_FactorySetting.u8AFEC_44, 0xFF);
                    MDrv_WriteByteMask(BK_AFEC_55_ADDRESS, 0x04, 0x04);
                    MsOS_DelayTask(1);
                    MDrv_WriteByteMask(BK_AFEC_55_ADDRESS, 0x00, 0x04);
                    MApp_SaveFactorySetting();
                    return EN_REDRAW_ITEM;
                case 11:
                    stGenSetting.g_FactorySetting.u8AFEC_44 = (U8)MApp_ZUI_ACT_DecIncValue_Cycle(bInc,
                        (U16)stGenSetting.g_FactorySetting.u8AFEC_44, 0, 0XFF, 1);
                    MDrv_WriteByteMask(BK_AFEC_44_ADDRESS, stGenSetting.g_FactorySetting.u8AFEC_44, 0xFF);
                    MDrv_WriteByteMask(BK_AFEC_55_ADDRESS, 0x04, 0x04);
                    MsOS_DelayTask(1);
                    MDrv_WriteByteMask(BK_AFEC_55_ADDRESS, 0x00, 0x04);
                    MApp_SaveFactorySetting();
                    return EN_REDRAW_ITEM;
                case 12:
                   stGenSetting.g_FactorySetting.u8AFEC_CB= (U8)MApp_ZUI_ACT_DecIncValue_Cycle(bInc,
                        (U16)stGenSetting.g_FactorySetting.u8AFEC_CB, 0, 0XFF, 1);
                    MDrv_WriteByteMask(BK_AFEC_CB_ADDRESS, stGenSetting.g_FactorySetting.u8AFEC_CB, 0xFF);
                    MApp_SaveFactorySetting();
                    return EN_REDRAW_ITEM;
                case 13:
                   stGenSetting.g_FactorySetting.u8AFEC_CF_BIT2= (U8)MApp_ZUI_ACT_DecIncValue_Cycle(bInc,
                        (U16)stGenSetting.g_FactorySetting.u8AFEC_CF_BIT2, 0, 1, 1);
                    MDrv_WriteByteMask(BK_AFEC_CF_ADDRESS, stGenSetting.g_FactorySetting.u8AFEC_CF_BIT2<<2, BIT2);
                    MApp_SaveFactorySetting();
                    return EN_REDRAW_ITEM;
                case 14:
                   stGenSetting.g_FactorySetting.u8AFEC_4E_BIT7= (U8)MApp_ZUI_ACT_DecIncValue_Cycle(bInc,
                        (U16)stGenSetting.g_FactorySetting.u8AFEC_4E_BIT7, 0, 1, 1);
                    MDrv_AVD_BackPorchWindowPositon(stGenSetting.g_FactorySetting.u8AFEC_4E_BIT7,stGenSetting.g_FactorySetting.u8AFEC_4F);
                    MApp_SaveFactorySetting();
                    return EN_REDRAW_ITEM;
                case 15:
                   stGenSetting.g_FactorySetting.u8AFEC_4F= (U8)MApp_ZUI_ACT_DecIncValue_Cycle(bInc,
                        (U16)stGenSetting.g_FactorySetting.u8AFEC_4F, 0x55, 0x68, 1);
                    MDrv_AVD_BackPorchWindowPositon(stGenSetting.g_FactorySetting.u8AFEC_4E_BIT7,stGenSetting.g_FactorySetting.u8AFEC_4F);
                    MApp_SaveFactorySetting();
                    return EN_REDRAW_ITEM;
                default:
                    return EN_REDRAW_NONE;
                }
              #endif // #if ENABLE_VD_PACH_IN_CHINA
                break;

            case EN_FACTORY_PAGE_VIF2:
              #if ENABLE_VD_PACH_IN_CHINA
                switch(u8Item)
                {
                case 0:
                    stGenSetting.g_FactorySetting.Vif_TOP = (U8)MApp_ZUI_ACT_DecIncValue_Cycle(bInc,
                        (U16)stGenSetting.g_FactorySetting.Vif_TOP, 0, 0x0F, 1);
                    MApp_SaveFactorySetting();
                    return EN_REDRAW_ITEM;
                case 1:
                    stGenSetting.g_FactorySetting.Vif_VGA_MAXIMUM = ((U16)MApp_ZUI_ACT_DecIncValue_Cycle(bInc,
                        (U16)stGenSetting.g_FactorySetting.Vif_VGA_MAXIMUM/0x10, 0, 0xFFF, 0x80)*0x10);
                    MApp_SaveFactorySetting();
                    return EN_REDRAW_ITEM;
                case 2:
                    stGenSetting.g_FactorySetting.Vif_CHINA_DESCRAMBLER_BOX= (U8)MApp_ZUI_ACT_DecIncValue_Cycle(bInc,
                        (U16)stGenSetting.g_FactorySetting.Vif_CHINA_DESCRAMBLER_BOX, 0, 5, 1);
                    MApp_SaveFactorySetting();
                    return EN_REDRAW_ITEM;
                case 3:
                   {
                      U8 Index;
                      Index=Get_VIF_KP_KI_MapToIndex(stGenSetting.g_FactorySetting.Vif_CR_KP_KI);
                      Index= (U16)MApp_ZUI_ACT_DecIncValue_Cycle(bInc, (U16)Index, 0, VIF_KP_KI_ADJUST_NUM-1, 1);
                      stGenSetting.g_FactorySetting.Vif_CR_KP_KI = VIF_KP_KI_DATA[Index];
                    MApp_SaveFactorySetting();
                    }
                    return EN_REDRAW_ITEM;
                case 4:
                    stGenSetting.g_FactorySetting.Vif_CR_THR = ((U16)MApp_ZUI_ACT_DecIncValue_Cycle(bInc,
                        (U16)stGenSetting.g_FactorySetting.Vif_CR_THR/0x10, 0, 0x3FF, 0x10)*0x10);
                    MApp_SaveFactorySetting();
                    return EN_REDRAW_ITEM;
                case 5:
                    stGenSetting.g_FactorySetting.Vif_CR_KP_KI_ADJUST = (U8)MApp_ZUI_ACT_DecIncValue_Cycle(bInc,
                        (U16)stGenSetting.g_FactorySetting.Vif_CR_KP_KI_ADJUST, 0, 1, 1);
                    MApp_SaveFactorySetting();
                    return EN_REDRAW_ITEM;
                case 6:
                    stGenSetting.g_FactorySetting.Vif_CLAMPGAIN_GAIN_OV_NEGATIVE= MApp_ZUI_ACT_DecIncValue_Cycle(bInc,
                    stGenSetting.g_FactorySetting.Vif_CLAMPGAIN_GAIN_OV_NEGATIVE, 0, 0xFFFF, 1);
                    MApp_SaveFactorySetting();
                    return EN_REDRAW_ITEM;
                case 7:
                    stGenSetting.g_FactorySetting.Vif_OVER_MODULATION = (U8)MApp_ZUI_ACT_DecIncValue_Cycle(bInc,
                        (U16)stGenSetting.g_FactorySetting.Vif_OVER_MODULATION, 0, 1, 1);
                    MApp_SaveFactorySetting();
                    return EN_REDRAW_ITEM;
                case 8:
                    stGenSetting.g_FactorySetting.Vif_ASIA_SIGNAL_OPTION= (U8)MApp_ZUI_ACT_DecIncValue_Cycle(bInc,
                        (U16)stGenSetting.g_FactorySetting.Vif_ASIA_SIGNAL_OPTION, 0, 1, 1);
                    MApp_SaveFactorySetting();
                    return EN_REDRAW_ITEM;
                case 9:
                    stGenSetting.g_FactorySetting.Vif_CR_LOCK_THR= (U8)MApp_ZUI_ACT_DecIncValue_Cycle(bInc,
                        (U16)stGenSetting.g_FactorySetting.Vif_CR_LOCK_THR, 0x10, 0x30, 0x10);
                    MApp_SaveFactorySetting();
                    return EN_REDRAW_ITEM;
                case 10:
                    stGenSetting.g_FactorySetting.Vif_AGCREFNEGATIVE= (U8)MApp_ZUI_ACT_DecIncValue_Cycle(bInc,
                        (U16)stGenSetting.g_FactorySetting.Vif_AGCREFNEGATIVE, 0x00, 0xFF, 1);
                    MApp_SaveFactorySetting();
                    return EN_REDRAW_ITEM;
                case 11:
                    stGenSetting.g_FactorySetting.Vif_SERIOUS_ACIDETECT= (U8)MApp_ZUI_ACT_DecIncValue_Cycle(bInc,
                        (U16)stGenSetting.g_FactorySetting.Vif_SERIOUS_ACIDETECT, 0x00, 0x01, 1);
                    MApp_SaveFactorySetting();
                    return EN_REDRAW_ITEM;
                default:
                    return EN_REDRAW_NONE;

                }
              #endif // #if ENABLE_VD_PACH_IN_CHINA
             break;

            case EN_FACTORY_PAGE_VIF3:
              #if ENABLE_VD_PACH_IN_CHINA
                switch(u8Item)
                {
                case 0:
                   stGenSetting.g_FactorySetting.AUDIO_HIDEV= (AUDIO_HIDEV_TYPE)MApp_ZUI_ACT_DecIncValue_Cycle(bInc,
                     (U16)stGenSetting.g_FactorySetting.AUDIO_HIDEV, E_AUDIO_HIDEV_OFF, E_AUDIO_HIDEV_BW_NUMS-1, 1);
                    if(stGenSetting.g_FactorySetting.AUDIO_HIDEV==E_AUDIO_HIDEV_BW_L1)
                    {
                        MApi_AUDIO_SIF_SendCmd(MSAPI_AUD_SIF_CMD_ENABLE_HIDEV, TRUE, NULL);
                        MApi_AUDIO_SIF_SendCmd(MSAPI_AUD_SIF_CMD_SET_HIDEV_FILTER_BW_LEVEL, MSAPI_AUD_SIF_HIDEV_FILTER_BW_L1, NULL);
                    }
                    else if(stGenSetting.g_FactorySetting.AUDIO_HIDEV==E_AUDIO_HIDEV_BW_L2)
                    {
                        MApi_AUDIO_SIF_SendCmd(MSAPI_AUD_SIF_CMD_ENABLE_HIDEV, TRUE, NULL);
                        MApi_AUDIO_SIF_SendCmd(MSAPI_AUD_SIF_CMD_SET_HIDEV_FILTER_BW_LEVEL, MSAPI_AUD_SIF_HIDEV_FILTER_BW_L2, NULL);
                    }
                    else if(stGenSetting.g_FactorySetting.AUDIO_HIDEV==E_AUDIO_HIDEV_BW_L3)
                    {
                        MApi_AUDIO_SIF_SendCmd(MSAPI_AUD_SIF_CMD_ENABLE_HIDEV, TRUE, NULL);
                        MApi_AUDIO_SIF_SendCmd(MSAPI_AUD_SIF_CMD_SET_HIDEV_FILTER_BW_LEVEL, MSAPI_AUD_SIF_HIDEV_FILTER_BW_L3, NULL);
                    }
                    else
                    {
                        MApi_AUDIO_SIF_SendCmd(MSAPI_AUD_SIF_CMD_ENABLE_HIDEV, FALSE, NULL);
                    }
                    MApp_SaveFactorySetting();
                    return EN_REDRAW_ITEM;
                case 1:
                    stGenSetting.g_FactorySetting.AUDIO_NR= MApp_ZUI_ACT_DecIncValue_Cycle(bInc,
                        (U16)stGenSetting.g_FactorySetting.AUDIO_NR, 0, 0xFF, 1);
                    MApi_AUDIO_SetCommAudioInfo(Audio_Comm_infoType_setNR_Threshold, stGenSetting.g_FactorySetting.AUDIO_NR,0X00);//should finetune
                    MApp_SaveFactorySetting();
                    return EN_REDRAW_ITEM;
                case 2:
                    stGenSetting.g_FactorySetting.SCAN_DELAY= MApp_ZUI_ACT_DecIncValue_Cycle(bInc,
                   (U16)stGenSetting.g_FactorySetting.SCAN_DELAY, 0, 0xFFFF, 10);
                    MApp_SaveFactorySetting();
                    return EN_REDRAW_ITEM;
                case 3:
                    stGenSetting.g_FactorySetting.COMBPATCH= MApp_ZUI_ACT_DecIncValue_Cycle(bInc,
                   (U16)stGenSetting.g_FactorySetting.COMBPATCH, 0, 1, 1);

                    if(IsATVInUse()&&!stGenSetting.g_FactorySetting.COMBPATCH)
                     {
                          MApp_ATVProc_ResetPatch(msAPI_AVD_GetVideoStandard());
                     }
                    MApp_SaveFactorySetting();
                    return EN_REDRAW_ITEM;
                case 4:
                    stGenSetting.g_FactorySetting.NOTSTANDARDPATCH= MApp_ZUI_ACT_DecIncValue_Cycle(bInc,
                   (U16)stGenSetting.g_FactorySetting.NOTSTANDARDPATCH, 0, 1, 1);

                    if(IsATVInUse())
                     {
                        #if (CHIP_FAMILY_TYPE==CHIP_FAMILY_M10)
                        MDrv_AVD_SetNonStandardPatchOnOff(stGenSetting.g_FactorySetting.NOTSTANDARDPATCH);
                        #endif
                     }
                    MApp_SaveFactorySetting();
                default:
                    return EN_REDRAW_ITEM;
                }
              #endif
             break;

           case EN_FACTORY_PAGE_UART_DBG:
                switch(u8Item)
                {
                case 0:
                    uart_tmp = (U8)MApp_ZUI_ACT_DecIncValue_Cycle(bInc,(U16) uart_tmp, MS_UART_TYPE_MIN, MS_UART_TYPE_MAX, 1);
                    if(uart_tmp == MS_UART_TYPE_HK )
                    {
                        stGenSetting.g_SysSetting.uUartPortConect= MS_UART_TYPE_HK; 
                        MDrv_UART_Init(E_UART_AEON_R2, 115200);
                      #if (CHIP_FAMILY_TYPE == CHIP_FAMILY_M10) || (CHIP_FAMILY_TYPE == CHIP_FAMILY_M12)
                        mdrv_uart_connect(E_UART_PORT0, E_UART_AEON_R2);
                      #else
                        mdrv_uart_connect(E_UART_PORT0, E_UART_PIU_UART0);
                      #endif
                     }
                    else if(uart_tmp == MS_UART_TYPE_AEON )
                     {
                        stGenSetting.g_SysSetting.uUartPortConect= MS_UART_TYPE_AEON; 
                        MDrv_UART_Init(E_UART_AEON_R2, 115200);
                        mdrv_uart_connect(E_UART_PORT0, E_UART_AEON);
                     }
                    else if(uart_tmp == MS_UART_TYPE_VDEC)
                     {
                         stGenSetting.g_SysSetting.uUartPortConect= MS_UART_TYPE_VDEC; 
                         MDrv_UART_Init(E_UART_AEON_R2, 115200);
                         mdrv_uart_connect(E_UART_PORT0, E_UART_VDEC);
                     }
                    else //wing
                      {
						 stGenSetting.g_SysSetting.uUartPortConect= MS_UART_TYPE_NONE; 
                          MDrv_UART_Init(E_UART_AEON_R2, 115200);
                          mdrv_uart_connect(E_UART_PORT0, E_UART_OFF);
                      }
                    return EN_REDRAW_ITEM;
                }
                break;
        #if (ENABLE_SZ_FACTORY_OVER_SCAN_FUNCTION)
           case  EN_FACTORY_PAGE_OVERSCAN:
                switch(u8Item)
                {
                case 0://reslution
                    return EN_REDRAW_ITEM;
                case 2: // osOffsetX: h-position
                    if(MApp_IsSrcHasSignal(MAIN_WINDOW))
                    {
                        msAPI_Scaler_SetBlueScreen( ENABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
                        g_OverScan.osOffsetX = MApp_ZUI_ACT_DecIncS8Value(bInc, g_OverScan.osOffsetX, -50, 50, 1);
                        MApp_SaveOverScanData();
                        if( MApi_XC_IsCurrentFrameBufferLessMode()||MApi_XC_IsCurrentRequest_FrameBufferLessMode())
                        {
                              msAPI_Scaler_SetBlueScreen(ENABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
                              MApp_Scaler_SetWindow(NULL, NULL, NULL, stSystemInfo[MAIN_WINDOW].enAspectRatio,
                             SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW), MAIN_WINDOW);
                             MApp_Scaler_SetTiming(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW), MAIN_WINDOW);
                             msAPI_Scaler_SetBlueScreen(DISABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
                        }
                         else
                        {
                             MApp_Scaler_SetWindow(NULL, NULL, NULL, stSystemInfo[MAIN_WINDOW].enAspectRatio,
                             SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW), MAIN_WINDOW);
                        }
                         msAPI_Scaler_SetBlueScreen( DISABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
                    }
                    return EN_REDRAW_ITEM;
                case 3: // osOffsetWidth: h-size
                    if(MApp_IsSrcHasSignal(MAIN_WINDOW))
                    {
                        msAPI_Scaler_SetBlueScreen( ENABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
                        g_OverScan.osOffsetWidth = MApp_ZUI_ACT_DecIncS8Value(bInc, g_OverScan.osOffsetWidth, -100, 100, 1);
                        MApp_SaveOverScanData();
                        if( MApi_XC_IsCurrentFrameBufferLessMode()||MApi_XC_IsCurrentRequest_FrameBufferLessMode())
                        {
                              msAPI_Scaler_SetBlueScreen(ENABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
                              MApp_Scaler_SetWindow(NULL, NULL, NULL, stSystemInfo[MAIN_WINDOW].enAspectRatio,
                             SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW), MAIN_WINDOW);
                             MApp_Scaler_SetTiming(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW), MAIN_WINDOW);
                             msAPI_Scaler_SetBlueScreen(DISABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
                        }
                         else
                        {
                             MApp_Scaler_SetWindow(NULL, NULL, NULL, stSystemInfo[MAIN_WINDOW].enAspectRatio,
                             SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW), MAIN_WINDOW);
                        }
                         msAPI_Scaler_SetBlueScreen( DISABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
                    }
                    return EN_REDRAW_ITEM;
                case 4:// osOffsetY: v-position
                     if(MApp_IsSrcHasSignal(MAIN_WINDOW))
                    {
                        msAPI_Scaler_SetBlueScreen( ENABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
                        g_OverScan.osOffsetY = MApp_ZUI_ACT_DecIncS8Value(bInc, g_OverScan.osOffsetY, -50, 50, 1);
                        MApp_SaveOverScanData();
                        if( MApi_XC_IsCurrentFrameBufferLessMode()||MApi_XC_IsCurrentRequest_FrameBufferLessMode())
                        {
                              msAPI_Scaler_SetBlueScreen(ENABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
                              MApp_Scaler_SetWindow(NULL, NULL, NULL, stSystemInfo[MAIN_WINDOW].enAspectRatio,
                             SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW), MAIN_WINDOW);
                             MApp_Scaler_SetTiming(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW), MAIN_WINDOW);
                             msAPI_Scaler_SetBlueScreen(DISABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
                        }
                         else
                        {
                             MApp_Scaler_SetWindow(NULL, NULL, NULL, stSystemInfo[MAIN_WINDOW].enAspectRatio,
                             SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW), MAIN_WINDOW);
                        }
                        msAPI_Scaler_SetBlueScreen( DISABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
                    }
                    return EN_REDRAW_ITEM;
                 case 5:// osOffsetHeight: v-size
                     if(MApp_IsSrcHasSignal(MAIN_WINDOW))
                    {
                        msAPI_Scaler_SetBlueScreen( ENABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
                        g_OverScan.osOffsetHeight = MApp_ZUI_ACT_DecIncS8Value(bInc, g_OverScan.osOffsetHeight, -100, 100, 1);
                        MApp_SaveOverScanData();
                        if( MApi_XC_IsCurrentFrameBufferLessMode()||MApi_XC_IsCurrentRequest_FrameBufferLessMode())
                        {
                              msAPI_Scaler_SetBlueScreen(ENABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
                              MApp_Scaler_SetWindow(NULL, NULL, NULL, stSystemInfo[MAIN_WINDOW].enAspectRatio,
                             SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW), MAIN_WINDOW);
                             MApp_Scaler_SetTiming(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW), MAIN_WINDOW);
                             msAPI_Scaler_SetBlueScreen(DISABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
                        }
                         else
                        {
                             MApp_Scaler_SetWindow(NULL, NULL, NULL, stSystemInfo[MAIN_WINDOW].enAspectRatio,
                             SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW), MAIN_WINDOW);
                        }
                        msAPI_Scaler_SetBlueScreen( DISABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
                    }
                    return EN_REDRAW_ITEM;
                }
                break;
        #endif

        #if (ENABLE_NONLINEAR_CURVE)
            case EN_FACTORY_PAGE_NONLINEAR_CURVE:
                switch(u8Item)
                {
                    case 0:
                    DATA_INPUT_SOURCE_TYPE(MAIN_WINDOW) =
                       (E_DATA_INPUT_SOURCE) MApp_ZUI_ACT_DecIncValue_Cycle(bInc,(U16) DATA_INPUT_SOURCE_TYPE(MAIN_WINDOW), DATA_INPUT_SOURCE_MIN, DATA_INPUT_SOURCE_NUM-1, 1);

                    _MApp_ZUI_ACT_FactoryMenu_ChangeDataInputSource(DATA_INPUT_SOURCE_TYPE(MAIN_WINDOW));
                    return EN_REDRAW_LIST;

                    case 1:
                    ST_VIDEO.ePicture = (EN_MS_PICTURE)MApp_ZUI_ACT_DecIncValue_Cycle(bInc, ST_VIDEO.ePicture, PICTURE_MIN, PICTURE_NUMS-1, 1);
                #if 0//VGA_HDMI_YUV_POINT_TO_POINT
                    MDrv_PQ_SetUserColorMode(ENABLE);
                #endif
                    MApp_Picture_Setting_SetColor(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW), MAIN_WINDOW);  //MApp_PicSetPicture( (T_MS_PICTURE *) &ST_PICTURE, SYS_INPUT_SOURCE_TYPE);
                #if 0//VGA_HDMI_YUV_POINT_TO_POINT
                    MDrv_PQ_SetUserColorMode(DISABLE);
                #endif
                    return EN_REDRAW_ITEM;
                }

                break;

            case EN_FACTORY_PAGE_BRIGHTNESS_CURVE:
            case EN_FACTORY_PAGE_CONTRAST_CURVE:
            case EN_FACTORY_PAGE_SATURATION_CURVE:
            case EN_FACTORY_PAGE_HUE_CURVE:
            case EN_FACTORY_PAGE_SHARPNESS_CURVE:
            case EN_FACTORY_PAGE_VOLUME_CURVE:

            {
                P_MS_USER_NONLINEAR_CURVE pNonLinearCurve = NULL;
		#if ENABLE_SOUND_NONLINEAR_CURVE_TEN
		P_MS_USER_NONLINEAR_CURVE_TEN pNonLinearCurveTen= NULL;
		#endif
                U16 u16MaxValue = 255;

#if(ENABLE_PICTURE_NONLINEAR_CURVE)
                if(EN_FACTORY_PAGE_BRIGHTNESS_CURVE == _eFactoryMenuPage)
                {
                    pNonLinearCurve = MApp_GetNonLinearCurve(NONLINEAR_CURVE_BRIGHTNESS);
                }
                else if(EN_FACTORY_PAGE_CONTRAST_CURVE == _eFactoryMenuPage)
                {
                    pNonLinearCurve = MApp_GetNonLinearCurve(NONLINEAR_CURVE_CONTRAST);
                }
                else if(EN_FACTORY_PAGE_SATURATION_CURVE == _eFactoryMenuPage)
                {
                    pNonLinearCurve = MApp_GetNonLinearCurve(NONLINEAR_CURVE_SATURATION);
                }
                else if(EN_FACTORY_PAGE_SHARPNESS_CURVE == _eFactoryMenuPage)
                {
                    pNonLinearCurve = MApp_GetNonLinearCurve(NONLINEAR_CURVE_SHARPNESS);
                    u16MaxValue = 0x3F;
                }
                else if(EN_FACTORY_PAGE_HUE_CURVE == _eFactoryMenuPage)
                {
                    pNonLinearCurve = MApp_GetNonLinearCurve(NONLINEAR_CURVE_HUE);
                    u16MaxValue = 100;
                }
#endif
#if(ENABLE_SOUND_NONLINEAR_CURVE)
                if(EN_FACTORY_PAGE_VOLUME_CURVE == _eFactoryMenuPage)
                {
                #if ENABLE_SOUND_NONLINEAR_CURVE_TEN
                    pNonLinearCurveTen = MApp_GetNonLinearCurveTen(NONLINEAR_CURVE_VOLUME);
		#else
                    pNonLinearCurve = MApp_GetNonLinearCurve(NONLINEAR_CURVE_VOLUME);
		#endif
		
#if ENABLE_SOUND_NEW_NONLINEAR
					u16MaxValue  = 599; //minglin0516
#else
                    u16MaxValue = 100;
#endif
                }
#endif

#if(ENABLE_SOUND_NONLINEAR_CURVE_TEN)
#if ENABLE_SOUND_NEW_NONLINEAR
	   if(EN_FACTORY_PAGE_VOLUME_CURVE == _eFactoryMenuPage)
		   {
switch(u8Item)
	   {
		   case 0:
			   pNonLinearCurveTen->u8OSD_0 = MApp_ZUI_ACT_DecIncValue_Cycle(bInc,
				   (U16)pNonLinearCurveTen->u8OSD_0, 0, u16MaxValue, 1);
			   break;

		   case 1:
			   pNonLinearCurveTen->u8OSD_10 = MApp_ZUI_ACT_DecIncValue_Cycle(bInc,
				   (U16)pNonLinearCurveTen->u8OSD_10, 0, u16MaxValue, 1);
			   break;

		   case 2:
			   pNonLinearCurveTen->u8OSD_20 = MApp_ZUI_ACT_DecIncValue_Cycle(bInc,
				   (U16)pNonLinearCurveTen->u8OSD_20, 0, u16MaxValue, 1);
			   break;

		   case 3:
			   pNonLinearCurveTen->u8OSD_30 = MApp_ZUI_ACT_DecIncValue_Cycle(bInc,
				   (U16)pNonLinearCurveTen->u8OSD_30, 0, u16MaxValue, 1);
			   break;

		   case 4:
			   pNonLinearCurveTen->u8OSD_40 = MApp_ZUI_ACT_DecIncValue_Cycle(bInc,
				   (U16)pNonLinearCurveTen->u8OSD_40, 0, u16MaxValue, 1);
			   break;
			case 5:
			   pNonLinearCurveTen->u8OSD_50 = MApp_ZUI_ACT_DecIncValue_Cycle(bInc,
				   (U16)pNonLinearCurveTen->u8OSD_50, 0, u16MaxValue, 1);
			   break;

		   case 6:
			   pNonLinearCurveTen->u8OSD_60 = MApp_ZUI_ACT_DecIncValue_Cycle(bInc,
				   (U16)pNonLinearCurveTen->u8OSD_60, 0, u16MaxValue, 1);
			   break;

		   case 7:
			   pNonLinearCurveTen->u8OSD_70 = MApp_ZUI_ACT_DecIncValue_Cycle(bInc,
				   (U16)pNonLinearCurveTen->u8OSD_70, 0, u16MaxValue, 1);
			   break;

		   case 8:
			   pNonLinearCurveTen->u8OSD_85 = MApp_ZUI_ACT_DecIncValue_Cycle(bInc,
				   (U16)pNonLinearCurveTen->u8OSD_85, 0, u16MaxValue, 1);
			   break;

		   case 9:
			   pNonLinearCurveTen->u8OSD_100 = MApp_ZUI_ACT_DecIncValue_Cycle(bInc,
				   (U16)pNonLinearCurveTen->u8OSD_100, 0, u16MaxValue, 1);
			   break;
           case 10:
			   pNonLinearCurveTen->Prescale= (U8)MApp_ZUI_ACT_DecIncValue_Cycle(bInc,
				   (U16)pNonLinearCurveTen->Prescale, 0, 255, 1);
		       break;
           case 11:
			   pNonLinearCurveTen->u8AVC_Value= (U8)MApp_ZUI_ACT_DecIncValue_Cycle(bInc,
				   (U16)pNonLinearCurveTen->u8AVC_Value, 0, 80, 1);
			   break;
#if 1
		   case 12:
                stGenSetting.g_SysSetting.fAutoVolume = !(stGenSetting.g_SysSetting.fAutoVolume);
				
				 msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_MOMENT_MUTEON, E_AUDIOMUTESOURCE_ACTIVESOURCE);
				 MApi_AUDIO_EnableAutoVolume((BOOLEAN)stGenSetting.g_SysSetting.fAutoVolume);
				 msAPI_Timer_Delayms(256);
				 msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_MOMENT_MUTEOFF, E_AUDIOMUTESOURCE_ACTIVESOURCE);
			   break;
#endif
#if ENABLE_FACTORY_DRC
    case 13:
	    BDrcEnable = !BDrcEnable;
		MApi_SND_ProcessEnable(Sound_ENABL_Type_DRC, BDrcEnable); // DRC		// CUS_XM Sea 20120709:
		break;

    case 14:
		BDrcValue = (U8)MApp_ZUI_ACT_DecIncValue_Cycle(bInc,BDrcValue, 0, 255, 1);
		MApi_SND_SetParam1(Sound_SET_PARAM_Drc_Threshold, BDrcValue, 0); // -8 dBFS
		break;
#endif
		   default:
			   return EN_REDRAW_NONE;
	   }
		   }
else

#else
                if(EN_FACTORY_PAGE_VOLUME_CURVE == _eFactoryMenuPage)
                	{
		 switch(u8Item)
                {
                    case 0:
                        pNonLinearCurveTen->u8OSD_0 = (U8)MApp_ZUI_ACT_DecIncValue_Cycle(bInc,
                            (U16)pNonLinearCurveTen->u8OSD_0, 0, u16MaxValue, 1);
                        break;

                    case 1:
                        pNonLinearCurveTen->u8OSD_10 = (U8)MApp_ZUI_ACT_DecIncValue_Cycle(bInc,
                            (U16)pNonLinearCurveTen->u8OSD_10, 0, u16MaxValue, 1);
                        break;

                    case 2:
                        pNonLinearCurveTen->u8OSD_20 = (U8)MApp_ZUI_ACT_DecIncValue_Cycle(bInc,
                            (U16)pNonLinearCurveTen->u8OSD_20, 0, u16MaxValue, 1);
                        break;

                    case 3:
                        pNonLinearCurveTen->u8OSD_30 = (U8)MApp_ZUI_ACT_DecIncValue_Cycle(bInc,
                            (U16)pNonLinearCurveTen->u8OSD_30, 0, u16MaxValue, 1);
                        break;

                    case 4:
                        pNonLinearCurveTen->u8OSD_40 = (U8)MApp_ZUI_ACT_DecIncValue_Cycle(bInc,
                            (U16)pNonLinearCurveTen->u8OSD_40, 0, u16MaxValue, 1);
                        break;
                     case 5:
                        pNonLinearCurveTen->u8OSD_50 = (U8)MApp_ZUI_ACT_DecIncValue_Cycle(bInc,
                            (U16)pNonLinearCurveTen->u8OSD_50, 0, u16MaxValue, 1);
                        break;

                    case 6:
                        pNonLinearCurveTen->u8OSD_60 = (U8)MApp_ZUI_ACT_DecIncValue_Cycle(bInc,
                            (U16)pNonLinearCurveTen->u8OSD_60, 0, u16MaxValue, 1);
                        break;

                    case 7:
                        pNonLinearCurveTen->u8OSD_70 = (U8)MApp_ZUI_ACT_DecIncValue_Cycle(bInc,
                            (U16)pNonLinearCurveTen->u8OSD_70, 0, u16MaxValue, 1);
                        break;

                    case 8:
                        pNonLinearCurveTen->u8OSD_85 = (U8)MApp_ZUI_ACT_DecIncValue_Cycle(bInc,
                            (U16)pNonLinearCurveTen->u8OSD_85, 0, u16MaxValue, 1);
                        break;

                    case 9:
                        pNonLinearCurveTen->u8OSD_100 = (U8)MApp_ZUI_ACT_DecIncValue_Cycle(bInc,
                            (U16)pNonLinearCurveTen->u8OSD_100, 0, u16MaxValue, 1);
                        break;

                    default:
                        return EN_REDRAW_NONE;
                }
                	}
else
#endif
#endif
{
                switch(u8Item)
                {
                    case 0:
                        pNonLinearCurve->u8OSD_0 = (U8)MApp_ZUI_ACT_DecIncValue_Cycle(bInc,
                            (U16)pNonLinearCurve->u8OSD_0, 0, u16MaxValue, 1);
                        break;

                    case 1:
                        pNonLinearCurve->u8OSD_25 = (U8)MApp_ZUI_ACT_DecIncValue_Cycle(bInc,
                            (U16)pNonLinearCurve->u8OSD_25, 0, u16MaxValue, 1);
                        break;

                    case 2:
                        pNonLinearCurve->u8OSD_50 = (U8)MApp_ZUI_ACT_DecIncValue_Cycle(bInc,
                            (U16)pNonLinearCurve->u8OSD_50, 0, u16MaxValue, 1);
                        break;

                    case 3:
                        pNonLinearCurve->u8OSD_75 = (U8)MApp_ZUI_ACT_DecIncValue_Cycle(bInc,
                            (U16)pNonLinearCurve->u8OSD_75, 0, u16MaxValue, 1);
                        break;

                    case 4:
                        pNonLinearCurve->u8OSD_100 = (U8)MApp_ZUI_ACT_DecIncValue_Cycle(bInc,
                            (U16)pNonLinearCurve->u8OSD_100, 0, u16MaxValue, 1);
                        break;

                    default:
                        return EN_REDRAW_NONE;
                }
}
                if(EN_FACTORY_PAGE_BRIGHTNESS_CURVE == _eFactoryMenuPage)
                {
                    MApi_XC_ACE_PicSetBrightnessInVsync(MAIN_WINDOW,
                                                MApi_XC_Sys_ACE_transfer_Bri((MApp_Scaler_FactoryAdjBrightness(msAPI_Mode_PictureBrightnessN100toReallyValue(ST_PICTURE.u8Brightness),ST_SUBCOLOR.u8SubBrightness)), BRIGHTNESS_R),
                                                MApi_XC_Sys_ACE_transfer_Bri((MApp_Scaler_FactoryAdjBrightness(msAPI_Mode_PictureBrightnessN100toReallyValue(ST_PICTURE.u8Brightness),ST_SUBCOLOR.u8SubBrightness)), BRIGHTNESS_G),
                                                MApi_XC_Sys_ACE_transfer_Bri((MApp_Scaler_FactoryAdjBrightness(msAPI_Mode_PictureBrightnessN100toReallyValue(ST_PICTURE.u8Brightness),ST_SUBCOLOR.u8SubBrightness)), BRIGHTNESS_B));
                }
                else if(EN_FACTORY_PAGE_CONTRAST_CURVE == _eFactoryMenuPage)
                {
               #if 0//VGA_HDMI_YUV_POINT_TO_POINT
                   if(IsHDMIInUse()&&MDrv_PQ_Get_HDMIPCMode())
                   {
                        MApi_XC_ACE_SetPCYUV2RGB(MAIN_WINDOW, FALSE);
                        MApi_XC_ACE_PicSetContrast(MAIN_WINDOW, FALSE, MApp_Scaler_FactoryContrast(msAPI_Mode_PictureContrastN100toReallyValue(ST_PICTURE.u8Contrast),ST_SUBCOLOR.u8SubContrast));
                   }
                   else
              #endif
                   {
                       MApi_XC_ACE_PicSetContrast(MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), MApp_Scaler_FactoryContrast(msAPI_Mode_PictureContrastN100toReallyValue(ST_PICTURE.u8Contrast),ST_SUBCOLOR.u8SubContrast));
                   }
                }
                else if(EN_FACTORY_PAGE_SATURATION_CURVE == _eFactoryMenuPage)
                {
                  #if 0//VGA_HDMI_YUV_POINT_TO_POINT
                     if(IsHDMIInUse()&&MDrv_PQ_Get_HDMIPCMode())
                    {
                       ;// do nothing
                    }
                    else
                  #endif
                    {
                        MApi_XC_ACE_PicSetSaturation(MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW),  msAPI_Mode_PictureSaturationN100toReallyValue(ST_PICTURE.u8Saturation) );
                    }
                }
                else if(EN_FACTORY_PAGE_SHARPNESS_CURVE == _eFactoryMenuPage)
                {
                    MApi_XC_ACE_PicSetSharpness( MAIN_WINDOW, msAPI_Mode_PictureSharpnessN100toReallyValue(ST_PICTURE.u8Sharpness) );
                }
                else if(EN_FACTORY_PAGE_HUE_CURVE == _eFactoryMenuPage)
                {
                    MApi_XC_ACE_PicSetHue( MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), msAPI_Mode_PictureHueN100toReallyValue(ST_PICTURE.u8Hue) );
                }
                else if(EN_FACTORY_PAGE_VOLUME_CURVE == _eFactoryMenuPage)
                {
                    msAPI_AUD_AdjustAudioFactor(E_ADJUST_VOLUME, stGenSetting.g_SoundSetting.Volume, 0);
                }

                MApp_SaveNonLinearCurveSetting();
                return EN_REDRAW_ITEM;
            }
#endif

        #if (ENABLE_FACTORY_PANEL_SEL)
           case  EN_FACTORY_PAGE_PANEL_SELECTION:
                switch(u8Item)
                {
                   case 0:
                      MApp_ZUI_ACT_FactoryAdjustProjectID(bInc);
                      return EN_REDRAW_ITEM;
                   case 1:
                   {
                      return EN_REDRAW_ITEM;
                   }
                }
                break;
        #endif

#if      ENABLE_SZ_FACTORY_USB_SAVE_MAP_FUNCTION
            case EN_FACTORY_PAGE_REGISTER_MAP:
           {
               g_DatabaseSaveResult = FALSE;
              switch(u8Item)
               {
                    case 0:
                        u32MainBankValue=MApp_ZUI_ACT_DecIncValue(bInc, u32MainBankValue, 0, 0xFFFF, 1);
                        ResultFlag = FALSE;
                        break;

                    case 1:
                        u32SubBankValue=MApp_ZUI_ACT_DecIncValue(bInc, u32SubBankValue, 0, 0xFF, 1);
                        if(u32SubBankValue >=16)
                        {
                            u8SubDigitCount = 2;
                        }
                        ResultFlag = FALSE;
                        break;

                    case 2:
                        ResultFlag = FALSE;
                        LoadScript = FALSE;
                        MainBank = u32MainBankValue;
                        SubBank = u32SubBankValue;

                        if(MApp_SaveRegister_Database())
                        {
                                ResultFlag = TRUE;
                                g_DatabaseSaveResult = TRUE;
                         }
                        else
                        {
                                ResultFlag = TRUE;
                                g_DatabaseSaveResult = FALSE;
                        }

                        break;

                     case 3:
                        MainBank = u32MainBankValue;
                        SubBank = u32SubBankValue;
                        LoadScript = TRUE;
                        ResultFlag = FALSE;
                        if(MApp_SaveRegister_Database())
                        {
                                ResultFlag = TRUE;
                                g_DatabaseSaveResult = TRUE;
                         }
                        else
                        {
                                ResultFlag = TRUE;
                                g_DatabaseSaveResult = FALSE;
                        }

                        break;

                     case 4:
                     {
                         MainBank = u32MainBankValue;
                         SubBank = u32SubBankValue;
                         LoadScript = FALSE;
                         ResultFlag = FALSE;
                         AllBank = TRUE;
                         if(MApp_SaveRegister_Database())
                         {
                                ResultFlag = TRUE;
                                g_DatabaseSaveResult = TRUE;
                          }
                          else
                          {
                                ResultFlag = TRUE;
                                g_DatabaseSaveResult = FALSE;
                          }

                     }
                     break;

                     default:
                          break;

                  }
              }

              return EN_REDRAW_ITEM;
#endif

        default:
            break;
    }
    return EN_REDRAW_NONE;
}
//CUS_XM:xue add for factory RC ADC key 2012-6-13
void Mapp_FactoryRCADC(void)
{
	printf("xue trace Mapp_FactoryRC ADC ");
	_eFactoryMenuPage=EN_FACTORY_PAGE_ADC_ADJUST;
	REDRAW_TYPE unusevalue;
	unusevalue=_MApp_ZUI_ACT_FactoryMenuDecIncValue(7, FALSE);
}


static U16 _MApp_ZUI_ACT_GetDataInputSourceStringID(E_DATA_INPUT_SOURCE src)
{
    U16 u16TempID = Empty;
    {
        switch(src)
        {
            case DATA_INPUT_SOURCE_RGB:
                u16TempID= en_strInputSource_RGB_PC;
                break;
         #if ENABLE_DTV
            case DATA_INPUT_SOURCE_DTV:
                u16TempID=en_strInputSourceDtvText;
                break;
         #endif
            case DATA_INPUT_SOURCE_ATV:
                u16TempID=en_strInputSourceAtvText;
                break;

            #if (INPUT_AV_VIDEO_COUNT == 1)
            case DATA_INPUT_SOURCE_AV:
                u16TempID=en_strInputSourceAvText;
                break;
            #elif (INPUT_AV_VIDEO_COUNT >= 2)
            case DATA_INPUT_SOURCE_AV:
                u16TempID=en_strInputSourceAv1Text;
                break;
            case DATA_INPUT_SOURCE_AV2:
                u16TempID=en_strInputSourceAv2Text;
                break;
            #endif
            #if (INPUT_AV_VIDEO_COUNT >= 3)
            case DATA_INPUT_SOURCE_AV3:
                u16TempID=en_strInputSourceAv3Text;
                break;
            #endif

            #if (INPUT_SV_VIDEO_COUNT == 1)
            case DATA_INPUT_SOURCE_SVIDEO:
                u16TempID=en_strInputSourceSvText;
                break;
            #elif (INPUT_SV_VIDEO_COUNT == 2)
            case DATA_INPUT_SOURCE_SVIDEO:
                u16TempID=en_strInputSourceSv1Text;
                break;
            case DATA_INPUT_SOURCE_SVIDEO2:
                u16TempID=en_strInputSourceSv2Text;
                break;
            #endif

            #if (INPUT_YPBPR_VIDEO_COUNT >= 1)
            case DATA_INPUT_SOURCE_COMPONENT:
                u16TempID = en_str_InputSource_Component;
                break;
            #endif
            #if (INPUT_YPBPR_VIDEO_COUNT >= 2)
            case DATA_INPUT_SOURCE_COMPONENT2:
                u16TempID=en_strYPbPr2Text;
                break;
            #endif
            #if   (INPUT_SCART_VIDEO_COUNT == 1)
            case DATA_INPUT_SOURCE_SCART:
                u16TempID=en_strInputSourceScartText;
                break;
            #elif (INPUT_SCART_VIDEO_COUNT == 2)
            case DATA_INPUT_SOURCE_SCART:
                u16TempID=en_strInputSourceScart1Text;
                break;
            case DATA_INPUT_SOURCE_SCART2:
                u16TempID=en_strInputSourceScart2Text;
                break;
            #endif
        #if (INPUT_HDMI_VIDEO_COUNT == 1)
            case DATA_INPUT_SOURCE_HDMI:
                u16TempID=en_strInputSourceHdmiText;
                break;
        #endif
        #if (INPUT_HDMI_VIDEO_COUNT >= 2)
            case DATA_INPUT_SOURCE_HDMI:
                u16TempID=en_strInputSourceHdmi1Text;
                break;

            case DATA_INPUT_SOURCE_HDMI2:
                u16TempID=en_strInputSourceHdmi2Text;
                break;
        #endif
        #if (INPUT_HDMI_VIDEO_COUNT >= 3)
            case DATA_INPUT_SOURCE_HDMI3:
                u16TempID=en_strInputSourceHdmi3Text;
                break;
        #endif
        #if (INPUT_HDMI_VIDEO_COUNT >= 4)
            case DATA_INPUT_SOURCE_HDMI4:
                u16TempID=en_strInputSourceHdmi4Text;
                break;
        #endif
/*
		#if CUS_SMC_ENABLE_HOTEL_MODE
			case DATA_INPUT_SOURCE_AUTO:
				u16TempID=en_str_Hotel_Menu_Input_Source_Change_Auto;
				break;
		#endif
*/
            default:
            #if ENABLE_DTV
                u16TempID=en_strInputSourceDtvText;
            #else
                u16TempID=en_strInputSourceAtvText;
            #endif
                break;
        }
    }
    return u16TempID;
}

//---------------------------------------------------------------------------------------------
//cus_xm zhihe 20120818  add for input source  of hotel mode to get dynamictext
//---------------------------------------------------------------------------------------------
#if CUS_SMC_ENABLE_HOTEL_MODE
static U16 _MApp_ZUI_ACT_GetHOTELMODEINPUTSourceStringID(E_HOTEL_MODE_INPUT_SOURCE src)
{
    U16 u16TempID = Empty;
    {
        switch(src)
        {
            case HOTEL_MODE_INPUT_SOURCE_AUTO:
				u16TempID=en_str_AUTO;
				break;
            case HOTEL_MODE_INPUT_SOURCE_RGB:
                u16TempID= en_strInputSource_RGB_PC;
                break;
            case HOTEL_MODE_INPUT_SOURCE_ATV:
                u16TempID=en_strInputSourceAtvText;
                break;

            #if (INPUT_AV_VIDEO_COUNT == 1)
            case HOTEL_MODE_INPUT_SOURCE_AV:
                u16TempID=en_strInputSourceAvText;
                break;
            #elif (INPUT_AV_VIDEO_COUNT >= 2)
            case HOTEL_MODE_INPUT_SOURCE_AV:
                u16TempID=en_strInputSourceAv1Text;
                break;
            case HOTEL_MODE_INPUT_SOURCE_AV2:
                u16TempID=en_strInputSourceAv2Text;
                break;
            #endif
            #if (INPUT_AV_VIDEO_COUNT >= 3)
            case HOTEL_MODE_INPUT_SOURCE_AV3:
                u16TempID=en_strInputSourceAv3Text;
                break;
            #endif

            #if (INPUT_SV_VIDEO_COUNT == 1)
            case HOTEL_MODE_INPUT_SOURCE_SVIDEO:
                u16TempID=en_strInputSourceSvText;
                break;
            #elif (INPUT_SV_VIDEO_COUNT == 2)
            case HOTEL_MODE_INPUT_SOURCE_SVIDEO:
                u16TempID=en_strInputSourceSv1Text;
                break;
            case HOTEL_MODE_INPUT_SOURCE_SVIDEO2:
                u16TempID=en_strInputSourceSv2Text;
                break;
            #endif

            #if (INPUT_YPBPR_VIDEO_COUNT >= 1)
            case HOTEL_MODE_INPUT_SOURCE_COMPONENT:
                u16TempID = en_str_InputSource_Component;
                break;
            #endif
            #if (INPUT_YPBPR_VIDEO_COUNT >= 2)
            case HOTEL_MODE_INPUT_SOURCE_COMPONENT2:
                u16TempID=en_strYPbPr2Text;
                break;
            #endif
            #if   (INPUT_SCART_VIDEO_COUNT == 1)
            case HOTEL_MODE_INPUT_SOURCE_SCART:
                u16TempID=en_strInputSourceScartText;
                break;
            #elif (INPUT_SCART_VIDEO_COUNT == 2)
            case HOTEL_MODE_INPUT_SOURCE_SCART:
                u16TempID=en_strInputSourceScart1Text;
                break;
            case HOTEL_MODE_INPUT_SOURCE_SCART2:
                u16TempID=en_strInputSourceScart2Text;
                break;
            #endif
        #if (INPUT_HDMI_VIDEO_COUNT == 1)
            case HOTEL_MODE_INPUT_SOURCE_HDMI:
                u16TempID=en_strInputSourceHdmiText;
                break;
        #endif
        #if (INPUT_HDMI_VIDEO_COUNT >= 2)
            case HOTEL_MODE_INPUT_SOURCE_HDMI:
                u16TempID=en_strInputSourceHdmi1Text;
                break;

            case HOTEL_MODE_INPUT_SOURCE_HDMI2:
                u16TempID=en_strInputSourceHdmi2Text;
                break;
        #endif
        #if (INPUT_HDMI_VIDEO_COUNT >= 3)
            case HOTEL_MODE_INPUT_SOURCE_HDMI3:
                u16TempID=en_strInputSourceHdmi3Text;
                break;
        #endif
        #if (INPUT_HDMI_VIDEO_COUNT >= 4)
            case HOTEL_MODE_INPUT_SOURCE_HDMI4:
                u16TempID=en_strInputSourceHdmi4Text;
                break;
        #endif

#if (ENABLE_DMP)
  #if( ENABLE_DMP_SWITCH )
 #ifndef ENABLE_DMP_ONE_PORT
			case HOTEL_MODE_INPUT_SOURCE_DMP1:
				u16TempID=en_str_USB1;
				break;
		  #endif
			case HOTEL_MODE_INPUT_SOURCE_DMP2:
				u16TempID=en_str_USB2;
				break;
 #endif
 #endif
            default:

                break;
        }
    }
    return u16TempID;
}
//---------------------------------------------------------------------------------------------
//cus_xm zhihe 20120818  add for input source  of hotel mode to get dynamictext
//---------------------------------------------------------------------------------------------

//==================================================
//Function name:    _MApp_HotelMode_Load_InputSourceChange
//Passing parameter:    none
//Return parameter:     none
//Description:      E_DATA_INPUT_SOURCE  convert  E_UI_INPUT_SOURCE
//==================================================
//cus_xm  20120818  modify by zhihe
void _MApp_HotelMode_Load_InputSourceChange(void)
{

	switch(stGenSetting.g_FactorySetting.HotelMenuInputSourceChange)
		{

				case HOTEL_MODE_INPUT_SOURCE_ATV:			UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_ATV;			break;
			#if (INPUT_AV_VIDEO_COUNT >= 1)
				case HOTEL_MODE_INPUT_SOURCE_AV:			UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_AV;			break;
			#endif
			#if (INPUT_AV_VIDEO_COUNT >= 2)
				case HOTEL_MODE_INPUT_SOURCE_AV2:			UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_AV2;			break;
			#endif
			#if (INPUT_AV_VIDEO_COUNT >= 3)
				case HOTEL_MODE_INPUT_SOURCE_AV3:			UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_AV3;			break;
			#endif
			#if (INPUT_YPBPR_VIDEO_COUNT >= 1)
				case HOTEL_MODE_INPUT_SOURCE_COMPONENT:	UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_COMPONENT;	break;
			#endif
			#if (INPUT_YPBPR_VIDEO_COUNT >= 2)
				case HOTEL_MODE_INPUT_SOURCE_COMPONENT2:	UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_COMPONENT2;	break;
			#endif
				case HOTEL_MODE_INPUT_SOURCE_RGB:			UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_RGB;			break;
			#if (INPUT_HDMI_VIDEO_COUNT >= 1)
				case HOTEL_MODE_INPUT_SOURCE_HDMI:		UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_HDMI;		break;
			#endif
			#if (INPUT_HDMI_VIDEO_COUNT >= 2)
				case HOTEL_MODE_INPUT_SOURCE_HDMI2:		UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_HDMI2;		break;
			#endif
			#if (INPUT_HDMI_VIDEO_COUNT >= 3)
				case HOTEL_MODE_INPUT_SOURCE_HDMI3:		UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_HDMI3;		break;
			#endif
			#if (INPUT_HDMI_VIDEO_COUNT >= 4)
				case HOTEL_MODE_INPUT_SOURCE_HDMI4:		UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_HDMI4;		break;
			#endif
			#if (INPUT_SCART_VIDEO_COUNT >= 1)
				case HOTEL_MODE_INPUT_SOURCE_SCART:		UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_SCART;		break;
			#endif
			#if (INPUT_SCART_VIDEO_COUNT >= 2)
				case HOTEL_MODE_INPUT_SOURCE_SCART2:		UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_SCART2;		break;
			#endif
			#if (INPUT_SV_VIDEO_COUNT >= 1)
				case HOTEL_MODE_INPUT_SOURCE_SVIDEO:		UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_SVIDEO;		break;
			#endif
			#if (INPUT_SV_VIDEO_COUNT >= 2)
				case HOTEL_MODE_INPUT_SOURCE_SVIDEO2:		UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_SVIDEO2;		break;
			#endif
#if (ENABLE_DMP)
#if( ENABLE_DMP_SWITCH )
#ifndef ENABLE_DMP_ONE_PORT		// CUS_XM Sea 20120629:
				case HOTEL_MODE_INPUT_SOURCE_DMP1:      UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_DMP1;  	    break;
#endif

				case HOTEL_MODE_INPUT_SOURCE_DMP2:      UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_DMP2;  	    break;
#endif
#endif

				case HOTEL_MODE_INPUT_SOURCE_AUTO:	    UI_INPUT_SOURCE_TYPE =UI_INPUT_SOURCE_TYPE;         break;
				default:
					break;
		}


}
//cus_xm  20120818  modify by zhihe
//---------------------------------------------------------------------------------------------------------------
#endif

static LPTSTR _MApp_ZUI_ACT_GetQText(U8 u8Q)
{
    u8Q += 5;
    LPTSTR a;
    // 0~156 map to 0.5~16
    a = MApp_ZUI_API_GetU16String(u8Q);
    U8 digit = MApp_GetNoOfDigit(u8Q);
    if(digit == 3)
    {
        a[4] = 0;
        a[3] = a[2];
        a[2] = '.';
    }
    else if(digit == 2)
    {
        a[3] = 0;
        a[2] = a[1];
        a[1] = '.';
    }
    else
    {
        a[3] = 0;
        a[2] = a[0];
        a[1] = '.';
        a[0] = '0';
    }

    return a;
}


static LPTSTR _MApp_ZUI_ACT_GetGainText(U8 u8Gain)
{
    LPTSTR a;
    // 0~240 map to -12.0~12.0
    if(u8Gain >= 120) //120~240
    {
        u8Gain -= 120;
        a = MApp_ZUI_API_GetU16String(u8Gain);
        U8 digit = MApp_GetNoOfDigit(u8Gain);
        if(digit == 3)
        {
            a[4] = 0;
            a[3] = a[2];
            a[2] = '.';
        }
        else if(digit == 2)
        {
            a[3] = 0;
            a[2] = a[1];
            a[1] = '.';
        }
        else
        {
            a[3] = 0;
            a[2] = a[0];
            a[1] = '.';
            a[0] = '0';
        }
    }
    else // 0~119
    {
        u8Gain = 120 - u8Gain;
        a = MApp_ZUI_API_GetU16String(u8Gain);
        U8 digit = MApp_GetNoOfDigit(u8Gain);
        if(digit == 3)
        {
            a[5] = 0;
            a[4] = a[2];
            a[3] = '.';
            a[2] = a[1];
            a[1] = a[0];
            a[0] = '-';
        }
        else if(digit == 2)
        {
            a[4] = 0;
            a[3] = a[1];
            a[2] = '.';
            a[1] = a[0];
            a[0] = '-';
        }
        else
        {
            a[4] = 0;
            a[3] = a[0];
            a[2] = '.';
            a[1] = '0';
            a[0] = '-';
        }
    }
    return a;
}

static LPTSTR _MApp_ZUI_ACT_GetFactoryMenuValueText(U8 u8Item)
{
    U16 u16TempID = Empty;
  #if(LOG_FACTORYMENU_SHOWITEM)
      u8Item = GetFactoryMenuItemu8ShowItem(_eFactoryMenuPage, u8Item);
  #endif

    switch(_eFactoryMenuPage)
    {
        case EN_FACTORY_PAGE_ROOT:
            switch(u8Item)
            {
                case 0: //TBD for Resolution show, use WHITE_PATTERN temporary
                case 1:
                case 2:
                case 3:
                case 4:
                case 5:
                case 6:
#if !BOE_FACTORY_VERSION_IN_BOOT
                case 8:
#endif
                case 9:
                case 10:
                case 11:
                    break;
		#if BOE_FACTORY_VERSION_IN_BOOT
			    case 8:
					{
						  char *ptr;
						  char ptr_head[128];
					
						  ptr = ptr_head;
	  #if 0
						  strcpy(ptr, SWCompileDate );
						  strcat(ptr, ", ");
						  strcat(ptr, SWCompileTime);
	 #else // Modified by coverity_683
						  strncpy(ptr, SWCompileDate, sizeof(SWCompileDate) );
						  strncat(ptr, ", ", 2);
						  strncat(ptr, SWCompileTime, sizeof(SWCompileTime));
	 #endif
					
						  return MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, (U8 *)ptr_head, strlen(ptr_head));
					}
					break;
		#endif

		#if BOE_USB_UPGRADE_FACTROY//minglin1206			
              
                case 14:
                    if (_u8USBDownloadStatus == 1)
                    {
                        u16TempID = en_strUsbNotDetected;
                    }
                    else if (_u8USBDownloadStatus == 2)
                    {
                        u16TempID = en_strSwFileNotDetected;
                    }
                    else
                    {
                        u16TempID = Empty;
                    }
                    break;
		#endif			
                case 7:
                    if(ST_AUDIO_PEQ.u8_PEQOnOff)
                    {
                        u16TempID = en_strON;
                    }
                    else
                    {
                        u16TempID = en_strOFF;
                    }
                    break;
            }
            break;

        case EN_FACTORY_PAGE_ADC_ADJUST:
            switch(u8Item)
            {
                case 0: //from case FACTORY_ADC_ADJUST_MODE_TEXT:
                {
                    if (stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_RGB)
                        u16TempID=en_strRGB;
                    else if (stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_Ypbpr_SD)
                        u16TempID=en_strYPbPrSD;
                    else if (stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_Ypbpr_HD)
                        u16TempID=en_strYPbPrHD;
                #if (INPUT_SCART_VIDEO_COUNT >= 1)
                    else if (stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_ScartRGB)
                        u16TempID=en_str_ScartRGB;
                #endif
                    //else
                    //    return strNUll;
                }
                break;

                case 2: //from case EN_DNUM_GetADC_RedGainValue:
                {
                    if (stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_RGB)
                    {
                        return MApp_ZUI_API_GetU16String(stGenSettingExt.g_AdcSetting[ADC_SET_VGA].stAdcGainOffsetSetting.u16RedGain);
                    }
                    else if (stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_Ypbpr_SD)
                    {
                        return MApp_ZUI_API_GetU16String(stGenSettingExt.g_AdcSetting[ADC_SET_YPBPR_SD].stAdcGainOffsetSetting.u16RedGain);
                    }
                    else if (stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_Ypbpr_HD)
                    {
                        return MApp_ZUI_API_GetU16String(stGenSettingExt.g_AdcSetting[ADC_SET_YPBPR_HD].stAdcGainOffsetSetting.u16RedGain);
                    }
                #if (INPUT_SCART_VIDEO_COUNT >= 1)
                    else if (stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_ScartRGB)
                    {
                        return MApp_ZUI_API_GetU16String(stGenSettingExt.g_AdcSetting[ADC_SET_SCART_RGB].stAdcGainOffsetSetting.u16RedGain);
                    }
                #endif
                }
                break;

                case 3: //from case EN_DNUM_GetADC_GreenGainValue:
                {
                    if (stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_RGB)
                    {
                        return MApp_ZUI_API_GetU16String(stGenSettingExt.g_AdcSetting[ADC_SET_VGA].stAdcGainOffsetSetting.u16GreenGain);
                    }
                    else if (stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_Ypbpr_SD)
                    {
                        return MApp_ZUI_API_GetU16String(stGenSettingExt.g_AdcSetting[ADC_SET_YPBPR_SD].stAdcGainOffsetSetting.u16GreenGain);
                    }
                    else if (stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_Ypbpr_HD)
                    {
                        return MApp_ZUI_API_GetU16String(stGenSettingExt.g_AdcSetting[ADC_SET_YPBPR_HD].stAdcGainOffsetSetting.u16GreenGain);
                    }
                #if (INPUT_SCART_VIDEO_COUNT >= 1)
                    else if (stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_ScartRGB)
                    {
                        return MApp_ZUI_API_GetU16String(stGenSettingExt.g_AdcSetting[ADC_SET_SCART_RGB].stAdcGainOffsetSetting.u16GreenGain);
                    }
                #endif
                }
                break;

                case 4: //from case EN_DNUM_GetADC_BlueGainValue:
                {
                    if (stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_RGB)
                    {
                        return MApp_ZUI_API_GetU16String(stGenSettingExt.g_AdcSetting[ADC_SET_VGA].stAdcGainOffsetSetting.u16BlueGain);
                    }
                    else if (stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_Ypbpr_SD)
                    {
                        return MApp_ZUI_API_GetU16String(stGenSettingExt.g_AdcSetting[ADC_SET_YPBPR_SD].stAdcGainOffsetSetting.u16BlueGain);
                    }
                    else if (stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_Ypbpr_HD)
                    {
                        return MApp_ZUI_API_GetU16String(stGenSettingExt.g_AdcSetting[ADC_SET_YPBPR_HD].stAdcGainOffsetSetting.u16BlueGain);
                    }
                #if (INPUT_SCART_VIDEO_COUNT >= 1)
                    else if (stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_ScartRGB)
                    {
                        return MApp_ZUI_API_GetU16String(stGenSettingExt.g_AdcSetting[ADC_SET_SCART_RGB].stAdcGainOffsetSetting.u16BlueGain);
                    }
                #endif
                } break;

                case 6: //from case EN_DNUM_GetADC_RedOffsetValue:
                {
                    if (stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_RGB)
                    {
                        return MApp_ZUI_API_GetU16String(stGenSettingExt.g_AdcSetting[ADC_SET_VGA].stAdcGainOffsetSetting.u16RedOffset);
                    }
                    else if (stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_Ypbpr_SD)
                    {
                        return MApp_ZUI_API_GetU16String(stGenSettingExt.g_AdcSetting[ADC_SET_YPBPR_SD].stAdcGainOffsetSetting.u16RedOffset);
                    }
                    else if (stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_Ypbpr_HD)
                    {
                        return MApp_ZUI_API_GetU16String(stGenSettingExt.g_AdcSetting[ADC_SET_YPBPR_HD].stAdcGainOffsetSetting.u16RedOffset);
                    }
                #if (INPUT_SCART_VIDEO_COUNT >= 1)
                    else if (stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_ScartRGB)
                    {
                        return MApp_ZUI_API_GetU16String(stGenSettingExt.g_AdcSetting[ADC_SET_SCART_RGB].stAdcGainOffsetSetting.u16RedOffset);
                    }
                #endif
                }
                break;

                case 7: //from case EN_DNUM_GetADC_GreenOffsetValue:
                {
                    if (stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_RGB)
                    {
                        return MApp_ZUI_API_GetU16String(stGenSettingExt.g_AdcSetting[ADC_SET_VGA].stAdcGainOffsetSetting.u16GreenOffset);
                    }
                    else if (stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_Ypbpr_SD)
                    {
                        return MApp_ZUI_API_GetU16String(stGenSettingExt.g_AdcSetting[ADC_SET_YPBPR_SD].stAdcGainOffsetSetting.u16GreenOffset);
                    }
                    else if (stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_Ypbpr_HD)
                    {
                        return MApp_ZUI_API_GetU16String(stGenSettingExt.g_AdcSetting[ADC_SET_YPBPR_HD].stAdcGainOffsetSetting.u16GreenOffset);
                    }
                #if (INPUT_SCART_VIDEO_COUNT >= 1)
                    else if (stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_ScartRGB)
                    {
                        return MApp_ZUI_API_GetU16String(stGenSettingExt.g_AdcSetting[ADC_SET_SCART_RGB].stAdcGainOffsetSetting.u16GreenOffset);
                    }
                #endif
                }
                break;

                case 8: //from case EN_DNUM_GetADC_BlueOffsetValue:
                {
                    if (stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_RGB)
                    {
                        return MApp_ZUI_API_GetU16String(stGenSettingExt.g_AdcSetting[ADC_SET_VGA].stAdcGainOffsetSetting.u16BlueOffset);
                    }
                    else if (stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_Ypbpr_SD)
                    {
                        return MApp_ZUI_API_GetU16String(stGenSettingExt.g_AdcSetting[ADC_SET_YPBPR_SD].stAdcGainOffsetSetting.u16BlueOffset);
                    }
                    else if (stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_Ypbpr_HD)
                    {
                        return MApp_ZUI_API_GetU16String(stGenSettingExt.g_AdcSetting[ADC_SET_YPBPR_HD].stAdcGainOffsetSetting.u16BlueOffset);
                    }
                #if (INPUT_SCART_VIDEO_COUNT >= 1)
                    else if (stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_ScartRGB)
                    {
                        return MApp_ZUI_API_GetU16String(stGenSettingExt.g_AdcSetting[ADC_SET_SCART_RGB].stAdcGainOffsetSetting.u16BlueOffset);
                    }
                #endif
                }
                break;

                case 10: //from case SUCCESSORFAIL_TEXT:
                {
                      if (stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_RGB)
                    {
                        if(stGenSettingExt.g_AdcSetting[ADC_SET_VGA].u8AdcCalOK)
                            u16TempID=en_strSUCCESS;
                        else
                            u16TempID=en_strFAIL;
                    }
                    else if (stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_Ypbpr_SD)
                    {
                        if(stGenSettingExt.g_AdcSetting[ADC_SET_YPBPR_SD].u8AdcCalOK)
                            u16TempID=en_strSUCCESS;
                        else
                            u16TempID=en_strFAIL;
                    }
                    else if (stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_Ypbpr_HD)
                    {
                        if(stGenSettingExt.g_AdcSetting[ADC_SET_YPBPR_HD].u8AdcCalOK)
                            u16TempID=en_strSUCCESS;
                        else
                            u16TempID=en_strFAIL;
                    }
                #if (INPUT_SCART_VIDEO_COUNT >= 1)
                    else if (stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_ScartRGB)
                    {
                        if(stGenSettingExt.g_AdcSetting[ADC_SET_SCART_RGB].u8AdcCalOK)
                            u16TempID=en_strSUCCESS;
                        else
                            u16TempID=en_strFAIL;
                    }
                #endif
                    /*
                    if(g_ADCCalibrationResult)
                        u16TempID=en_strSUCCESS;
                    else
                        u16TempID=en_strFAIL;
                        */
                }
                break;
            }
            break;

        case EN_FACTORY_PAGE_PICTURE_MODE:
            switch(u8Item)
            {
                case 0:
                    u16TempID = _MApp_ZUI_ACT_GetPictureModeStringID();
                    break;

                case 2: //from case EN_DNUM_GetSubBCAdjustBrightnesValue:
                    return MApp_ZUI_API_GetU16String(ST_SUBCOLOR.u8SubBrightness + 50 - SUB_BRIGHTNESS_BYPASS);

                case 3: //from case EN_DNUM_GetSubBCAdjustContrastValue:
                    return MApp_ZUI_API_GetU16String(ST_SUBCOLOR.u8SubContrast + 50 - SUB_CONTRAST_BYPASS);

                case 4:
                    return MApp_ZUI_API_GetU16String(ST_PICTURE.u8Saturation);

                case 5:
                    return MApp_ZUI_API_GetU16String(ST_PICTURE.u8Sharpness);

                case 6:
                    return MApp_ZUI_API_GetU16String(ST_PICTURE.u8Hue);

                case 7:
		default:
                    break;


            }
            break;

        case EN_FACTORY_PAGE_PEQ:
            // TODO: fix me
            switch(u8Item)
            {
                case EN_FacAdj_FO1_Coarse:
                    return MApp_ZUI_API_GetU16String(ST_AUDIO_PEQ.u16_Fo1Value);
                case EN_FacAdj_FO1_Fine:
                    return MApp_ZUI_API_GetU16String(ST_AUDIO_PEQ.u16_Fo1Value);;
                case EN_FacAdj_FO2_Coarse:
                    return MApp_ZUI_API_GetU16String(ST_AUDIO_PEQ.u16_Fo2Value);
                case EN_FacAdj_FO2_Fine:
                    return MApp_ZUI_API_GetU16String(ST_AUDIO_PEQ.u16_Fo2Value);;
                case EN_FacAdj_FO3_Coarse:
                    return MApp_ZUI_API_GetU16String(ST_AUDIO_PEQ.u16_Fo3Value);
                case EN_FacAdj_FO3_Fine:
                    return MApp_ZUI_API_GetU16String(ST_AUDIO_PEQ.u16_Fo3Value);;
                    //gain :-12.0~12.0
                case EN_FacAdj_Gain1:
                    return _MApp_ZUI_ACT_GetGainText(ST_AUDIO_PEQ.u8_Gain1Value);
                case EN_FacAdj_Gain2:
                    return _MApp_ZUI_ACT_GetGainText(ST_AUDIO_PEQ.u8_Gain2Value);
                case EN_FacAdj_Gain3:
                    return _MApp_ZUI_ACT_GetGainText(ST_AUDIO_PEQ.u8_Gain3Value);
                    // 0.5~16
                case EN_FacAdj_Q1:
                    return _MApp_ZUI_ACT_GetQText(ST_AUDIO_PEQ.u8_Q1Value);
                case EN_FacAdj_Q2:
                    return _MApp_ZUI_ACT_GetQText(ST_AUDIO_PEQ.u8_Q2Value);
                case EN_FacAdj_Q3:
                    return _MApp_ZUI_ACT_GetQText(ST_AUDIO_PEQ.u8_Q3Value);
            }
            break;

        case EN_FACTORY_PAGE_WHITE_BALANCE:
            switch(u8Item)
            {
                case 0:
                    u16TempID = _MApp_ZUI_ACT_GetDataInputSourceStringID(DATA_INPUT_SOURCE_TYPE(MAIN_WINDOW));
                    break;

                case 2: //from case WB_TEMPERATURE_TEXT:
                    {
                        if (ST_PICTURE.eColorTemp == MS_COLOR_TEMP_COOL)
                            u16TempID=en_str_ColorTemp_Cool;
                        else if (ST_PICTURE.eColorTemp == MS_COLOR_TEMP_MEDIUM)
                            u16TempID=en_str_ColorTemp_Medium;
                        else if (ST_PICTURE.eColorTemp == MS_COLOR_TEMP_WARM)
                            u16TempID=en_str_ColorTemp_Warm;
                      #if(MS_COLOR_TEMP_COUNT ==4)
                        else if (ST_PICTURE.eColorTemp == MS_COLOR_TEMP_USER)
                            u16TempID=en_str_ColorTemp_User;
                      #endif
                    }
                    break;

                case 3: //from case EN_DNUM_GetWBRedGainValue:
                    return MApp_ZUI_API_GetU16String(ST_COLOR_TEMP.cRedColor);

                case 4: //from case EN_DNUM_GetWBGreenGainValue:
                    return MApp_ZUI_API_GetU16String(ST_COLOR_TEMP.cGreenColor);

                case 5: //from case EN_DNUM_GetWBBlueGainValue:
                    return MApp_ZUI_API_GetU16String(ST_COLOR_TEMP.cBlueColor);

                case 7: //from case EN_DNUM_GetWBRedOffsetValue:
                    return MApp_ZUI_API_GetU16String(ST_COLOR_TEMP.cRedOffset);

                case 8: //from case EN_DNUM_GetWBGreenOffsetValue:
                    return MApp_ZUI_API_GetU16String(ST_COLOR_TEMP.cGreenOffset);

                case 9: //from case EN_DNUM_GetWBBlueOffsetValue:
                    return MApp_ZUI_API_GetU16String(ST_COLOR_TEMP.cBlueOffset);
		case 10:
		     if(g_CopyALLResult)
                       u16TempID=en_strSUCCESS;
                    else
                        u16TempID=en_strFAIL;
                    break;
            }
            break;
			case EN_FACTORY_PAGE_VCOM:
				switch(u8Item)
				{
				  case 0:
				 
				 return  MApp_ZUI_API_GetU16String(stGenSetting.g_SysSetting.bPanelVcom);

				
			
				}
				break;

        case EN_FACTORY_PAGE_QMAP_PAGE:
            {
                U8 u8IPIdx, u8TabIdx, u8IPNum;

                u8IPIdx = ((_u8IPIndex)/(COUNTOF(_FactoryMenuItemHwndList)))*(COUNTOF(_FactoryMenuItemHwndList))+u8Item;
                u8IPNum = _u8IPNumber;

                //printf("=======IP[%bu / %bu] = %s\n", u8IPIdx, u8IPNum, MDrv_PQ_GetIPName(u8IPIdx));
                if(u8IPIdx < u8IPNum)
                {
                     u8TabIdx = (U8)MDrv_PQ_GetCurrentTableIndex(PQ_MAIN_WINDOW, (U16)u8IPIdx);

                    //printf("===TAB[%bu] = ", u8TabIdx);
                    if(u8TabIdx != 0xFF)
                    {
                        //printf("%s\n", MDrv_PQ_GetTableName(u8IPIdx, u8TabIdx));
                        return MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, (U8*)MDrv_PQ_GetTableName(u8IPIdx, u8TabIdx), 255);
                    }
                }
            }
        break;

        #if ENABLE_PIP
        case EN_FACTORY_PAGE_PIP_POP:
            switch(u8Item)
            {
                case 0: //PIP/POP : On/Off
                {
                    if(stGenSetting.g_stPipSetting.bPipEnable)
                    {
                        u16TempID = en_strON;
                    }
                    else
                    {
                        u16TempID = en_strOFF;
                    }
                }
                break;

                case 1: //PIP Border Width
                {
                    return MApp_ZUI_API_GetU16String(stGenSetting.g_stPipSetting.u8BorderWidth);
                }
                break;
            }
        break;
        #endif
        case EN_FACTORY_PAGE_SW_INFO_PAGE:
            switch(u8Item)
            {
                case 1:
                {
                      char *ptr;
                      char ptr_head[128];

                      ptr = ptr_head;
                      #if 0
                      strcpy(ptr, SWCompileDate );
                      strcat(ptr, ", ");
                      strcat(ptr, SWCompileTime);
                     #else // Modified by coverity_683
                      strncpy(ptr, SWCompileDate, sizeof(SWCompileDate) );
                      strncat(ptr, ", ", 2);
                      strncat(ptr, SWCompileTime, sizeof(SWCompileTime));
                     #endif

                      return MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, (U8 *)ptr_head, strlen(ptr_head));
                }
       #if ENABLE_SHOW_PHASE_FACTORY
                case 2:
                  {

                     U16 i, Miu0_Dqs0,Miu0_Dqs0_PhaseNum=0;
                     Miu0_Dqs0=g_u16Miu0_Dqs0;
                     for(i=0;i<16;i++)
                      {
                        if((Miu0_Dqs0&0x01)==1)
                       Miu0_Dqs0_PhaseNum++;
                        Miu0_Dqs0=Miu0_Dqs0>>1;
                       }
             return MApp_ZUI_API_GetU16String(Miu0_Dqs0_PhaseNum);
                   }
                  case 3:
                  {
                     U16 i,Miu0_Dqs1,Miu0_Dqs0_PhaseNum=0;
                     Miu0_Dqs1=g_u16Miu0_Dqs1;
                     for(i=0;i<16;i++)
                      {
                        if((Miu0_Dqs1&0x01)==1)
                       Miu0_Dqs0_PhaseNum++;
                        Miu0_Dqs1=Miu0_Dqs1>>1;
                       }
                     return MApp_ZUI_API_GetU16String(Miu0_Dqs0_PhaseNum);
                   }
         #if(ENABLE_MIU_1)
                   case 4:
                  {
                     int i,Miu1_Dqs1,Miu0_Dqs1_PhaseNum=0;
                     Miu1_Dqs1=g_u16Miu1_Dqs0;
                     for(i=0;i<16;i++)
                      {
                        if((Miu1_Dqs1&0x01)==1)
                       Miu0_Dqs1_PhaseNum++;
                        Miu1_Dqs1=Miu1_Dqs1>>1;
                       }
             return MApp_ZUI_API_GetU16String(Miu0_Dqs1_PhaseNum);
                   }
                  case 5:
                  {
                     int i,Miu1_Dqs1,Miu0_Dqs1_PhaseNum=0;
                     Miu1_Dqs1=g_u16Miu1_Dqs1;
                    for(i=0;i<16;i++)
                      {
                        if((Miu1_Dqs1&0x01)==1)
                       Miu0_Dqs1_PhaseNum++;
                        Miu1_Dqs1=Miu1_Dqs1>>1;
                       }
                     return MApp_ZUI_API_GetU16String(Miu0_Dqs1_PhaseNum);
                   }
           #endif
        #endif
            }
        break;
        #if ENABLE_AUTOTEST
        case EN_FACTORY_PAGE_BMTEST_PAGE:
        {
            //printf("==================================================\n\n");
            static int i=0;
            //static char aeon_dhrystone[10];
            static char mips_dhrystone[10]={};
            static char aeon_dhrystone[10]={};
            static char mips_mmtest[10]={};
            static char aeon_mmtest[10]={};

            if(i==0)
            {
                // Do benchmark
                CPU_BENCHMARK_TEST(mips_dhrystone,aeon_dhrystone,mips_mmtest,aeon_mmtest);

                i++;
            }
            #if 1
            switch(u8Item)
            {
                case 0:
                {
                      char *ptr;
                      char ptr_head[128];

                      ptr = ptr_head;
                      strcpy(ptr,aeon_dhrystone);
                      strcat(ptr, "  Dhrystones/sec");
                      return MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, (U8 *)ptr_head, strlen(ptr_head));
                }
                case 1:
                {
                      char *ptr;
                      char ptr_head[128]={0};

                      ptr = ptr_head;

                      strcpy(ptr,mips_dhrystone);
                      strcat(ptr, "  Dhrystones/sec");
                      return MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, (U8 *)ptr_head, strlen(ptr_head));
                }
                case 2:
                {
                      char *ptr;
                      char ptr_head[128]={0};

                      ptr = ptr_head;

                      strcpy(ptr,aeon_mmtest);
                      strcat(ptr, "  micro second");
                      return MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, (U8 *)ptr_head, strlen(ptr_head));
                }
                case 3:
                {
                      char *ptr;
                      char ptr_head[128]={0};

                      ptr = ptr_head;

                      strcpy(ptr,mips_mmtest);
                      strcat(ptr, "  micro second");
                      return MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, (U8 *)ptr_head, strlen(ptr_head));
                }
            }
            #endif
        break;
     }
     #endif
#if ENABLE_AUTO_DQS_Factory
        case EN_FACTORY_PAGE_BIST_TEST:
            switch(u8Item)
            {
                case 0:
                    if(_BIST_TEST_MODE == EN_BIST_TEST_UI_PROCESSING)
                        u16TempID = en_str_Testing;
                    else
                        u16TempID = en_str_Start_Txt;
                    break;
                case 1:
                    if((u8DQSM0[0] == 0x00)||(_BIST_TEST_MODE == EN_BIST_TEST_UI_START))
                    {
                        u16TempID = en_strLL;
                    }
                    else if(_BIST_TEST_MODE == EN_BIST_TEST_UI_PROCESSING)
                    {
                        u16TempID = en_str_Testing;
                    }
                    else if(u8DQSM0[2] >= (u8DQSM0[0]+0x22))
                    {
                        u16TempID = en_strSUCCESS;
                    }
                    else
                    {
                        u16TempID = en_strFAIL;
                    }
                    break;
                case 2:
                    if((u8DQSM0[0] == 0x00)||(_BIST_TEST_MODE == EN_BIST_TEST_UI_START))
                    {
                        u16TempID = en_strLL;
                    }
                    else if(_BIST_TEST_MODE == EN_BIST_TEST_UI_PROCESSING)
                    {
                        u16TempID = en_str_Testing;
                    }
                    else if(u8DQSM0[2] >= (u8DQSM0[0]+0x11))
                    {
                        u16TempID = en_strSUCCESS;
                    }
                    else
                    {
                        u16TempID = en_strFAIL;
                    }
                    break;
                case 3:
                    if((u8DQSM0[0] == 0x00)||(_BIST_TEST_MODE == EN_BIST_TEST_UI_START))
                    {
                        u16TempID = en_strLL;
                    }
                    else if(_BIST_TEST_MODE == EN_BIST_TEST_UI_PROCESSING)
                    {
                        u16TempID = en_str_Testing;
                    }
                    else if(u8DQSM0[2] >= (u8DQSM0[0]+0x00))
                    {
                        u16TempID = en_strSUCCESS;
                    }
                    else
                    {
                        u16TempID = en_strFAIL;
                    }
                    break;
                case 4:
                    if((u8DQSM0[0] == 0x00)||(_BIST_TEST_MODE == EN_BIST_TEST_UI_START))
                    {
                        u16TempID = en_strLL;
                    }
                    else if(_BIST_TEST_MODE == EN_BIST_TEST_UI_PROCESSING)
                    {
                        u16TempID = en_str_Testing;
                    }
                    else if(u8DQSM0[0] >= (u8DQSM0[1]+0x11))
                    {
                        u16TempID = en_strSUCCESS;
                    }
                    else
                    {
                        u16TempID = en_strFAIL;
                    }
                    break;
                case 5:
                    if((u8DQSM0[0] == 0x00)||(_BIST_TEST_MODE == EN_BIST_TEST_UI_START))
                    {
                        u16TempID = en_strLL;
                    }
                    else if(_BIST_TEST_MODE == EN_BIST_TEST_UI_PROCESSING)
                    {
                        u16TempID = en_str_Testing;
                    }
                    else if(u8DQSM0[0] >= (u8DQSM0[1]+0x22))
                    {
                        u16TempID = en_strSUCCESS;
                    }
                    else
                    {
                        u16TempID = en_strFAIL;
                    }
                    break;
            #if ENABLE_MIU_1
                case 6:
                    if((u8DQSM1[0] == 0x00)||(_BIST_TEST_MODE == EN_BIST_TEST_UI_START))
                    {
                        u16TempID = en_strLL;
                    }
                    else if(_BIST_TEST_MODE == EN_BIST_TEST_UI_PROCESSING)
                    {
                        u16TempID = en_str_Testing;
                    }
                    else if(u8DQSM1[2] >= (u8DQSM1[0]+0x22))
                    {
                        u16TempID = en_strSUCCESS;
                    }
                    else
                    {
                        u16TempID = en_strFAIL;
                    }
                    break;
                case 7:
                    if((u8DQSM1[0] == 0x00)||(_BIST_TEST_MODE == EN_BIST_TEST_UI_START))
                    {
                        u16TempID = en_strLL;
                    }
                    else if(_BIST_TEST_MODE == EN_BIST_TEST_UI_PROCESSING)
                    {
                        u16TempID = en_str_Testing;
                    }
                    else if(u8DQSM1[2] >= (u8DQSM1[0]+0x11))
                    {
                        u16TempID = en_strSUCCESS;
                    }
                    else
                    {
                        u16TempID = en_strFAIL;
                    }
                    break;
                case 8:
                    if((u8DQSM1[0] == 0x00)||(_BIST_TEST_MODE == EN_BIST_TEST_UI_START))
                    {
                        u16TempID = en_strLL;
                    }
                    else if(_BIST_TEST_MODE == EN_BIST_TEST_UI_PROCESSING)
                    {
                        u16TempID = en_str_Testing;
                    }
                    else if(u8DQSM1[2] >= (u8DQSM1[0]+0x00))
                    {
                        u16TempID = en_strSUCCESS;
                    }
                    else
                    {
                        u16TempID = en_strFAIL;
                    }
                    break;
                case 9:
                    if((u8DQSM1[0] == 0x00)||(_BIST_TEST_MODE == EN_BIST_TEST_UI_START))
                    {
                        u16TempID = en_strLL;
                    }
                    else if(_BIST_TEST_MODE == EN_BIST_TEST_UI_PROCESSING)
                    {
                        u16TempID = en_str_Testing;
                    }
                    else if(u8DQSM1[0] >= (u8DQSM1[1]+0x11))
                    {
                        u16TempID = en_strSUCCESS;
                    }
                    else
                    {
                        u16TempID = en_strFAIL;
                    }
                    break;
                case 10:
                    if((u8DQSM1[0] == 0x00)||(_BIST_TEST_MODE == EN_BIST_TEST_UI_START))
                    {
                        u16TempID = en_strLL;
                    }
                    else if(_BIST_TEST_MODE == EN_BIST_TEST_UI_PROCESSING)
                    {
                        u16TempID = en_str_Testing;
                    }
                    else if(u8DQSM1[0] >= (u8DQSM1[1]+0x22))
                    {
                        u16TempID = en_strSUCCESS;
                    }
                    else
                    {
                        u16TempID = en_strFAIL;
                    }
                    break;
            #endif
                default:
                    break;
            }
        break;
    #endif
        case EN_FACTORY_PAGE_SSC:
#if ENABLE_SSC
            switch(u8Item)
            {
                case 0:
                    return MApp_ZUI_API_GetU16String(stGenSetting.g_SSCSetting.SscMIUEnable);

                case 1:
                    {
                        CHAR_BUFFER[0] = ((stGenSetting.g_SSCSetting.MIUSscSpanKHzx10/10) == 0) ? ' ' : '0'+(stGenSetting.g_SSCSetting.MIUSscSpanKHzx10/10);
                        CHAR_BUFFER[1] = '0'+((stGenSetting.g_SSCSetting.MIUSscSpanKHzx10%10));
                        CHAR_BUFFER[2] = CHAR_SPACE;
                        CHAR_BUFFER[3] = CHAR_K;
                        CHAR_BUFFER[4] = CHAR_H;
                        CHAR_BUFFER[5] = CHAR_z;
                        CHAR_BUFFER[6] = 0;
                return CHAR_BUFFER;
                //return MApp_ZUI_API_GetU16String(stGenSetting.g_SSCSetting.MIUSscSpanKHzx10);
                    }
                case 2:
                    {
                        CHAR_BUFFER[0] = '0'+(stGenSetting.g_SSCSetting.MIUSscStepPercentagex100/10);
                        CHAR_BUFFER[1] = '.';
                        CHAR_BUFFER[2] = '0'+(stGenSetting.g_SSCSetting.MIUSscStepPercentagex100%10);
                        CHAR_BUFFER[3] = CHAR_SPACE;
                        CHAR_BUFFER[4] = '%';
                        CHAR_BUFFER[5] = 0;
                return CHAR_BUFFER;
                        //return MApp_ZUI_API_GetU16String(stGenSetting.g_SSCSetting.MIUSscStepPercentagex100);
                    }
                case 4:
                    return MApp_ZUI_API_GetU16String(stGenSetting.g_SSCSetting.SscLVDSEnale);

                case 5:
                    {
                        CHAR_BUFFER[0] = ((stGenSetting.g_SSCSetting.LVDSSscSpanKHzx10/100) == 0) ? ' ' : '0'+(stGenSetting.g_SSCSetting.LVDSSscSpanKHzx10/100);
                        CHAR_BUFFER[1] = '0'+((stGenSetting.g_SSCSetting.LVDSSscSpanKHzx10%100)/10);
                        CHAR_BUFFER[2] = '.';
                        CHAR_BUFFER[3] = '0'+(stGenSetting.g_SSCSetting.LVDSSscSpanKHzx10%10);
                        CHAR_BUFFER[4] = CHAR_SPACE;
                        CHAR_BUFFER[5] = CHAR_K;
                        CHAR_BUFFER[6] = CHAR_H;
                        CHAR_BUFFER[7] = CHAR_z;
                        CHAR_BUFFER[8] = 0;
                return CHAR_BUFFER;
                //return MApp_ZUI_API_GetU16String(stGenSetting.g_SSCSetting.LVDSSscSpanKHzx10);
                    }
                case 6:
                    {
                        CHAR_BUFFER[0] = '0'+((stGenSetting.g_SSCSetting.LVDSSscStepPercentagex100/100));
                        CHAR_BUFFER[1] = '.';
                	     CHAR_BUFFER[2] = '0'+((stGenSetting.g_SSCSetting.LVDSSscStepPercentagex100%100)/10);
                        CHAR_BUFFER[3] = '0'+(stGenSetting.g_SSCSetting.LVDSSscStepPercentagex100%10);
                        CHAR_BUFFER[4] = CHAR_SPACE;
                        CHAR_BUFFER[5] = '%';
                        CHAR_BUFFER[6] = 0;
                return CHAR_BUFFER;
                      //  return MApp_ZUI_API_GetU16String(stGenSetting.g_SSCSetting.LVDSSscStepPercentagex100);
                    }
            }
#endif
            break;
        case EN_FACTORY_PAGE_SPECIAL_SET:
            switch(u8Item)
            {
                case 0: //
                #if ENABLE_CUS_AUTO_SLEEP_MODE
                    _MApp_ZUI_ACT_GetAutosleepString(CHAR_BUFFER);
                    return CHAR_BUFFER;
                #else
                    if (stGenSetting.g_Time.cAutoSleepFlag == EN_Time_AutoOff_Off)
                        u16TempID=en_strOFF;
                    else if (stGenSetting.g_Time.cAutoSleepFlag == EN_Time_AutoOff_On)
                        u16TempID=en_strON;
                    break;
                #endif
                case 1: //
                    if (!MDrv_Sys_IsWatchDogEnabled())
                        u16TempID=en_strOFF;
                    else
                        u16TempID=en_strON;
                    break;
                case 2: //
                    {
                        if (stLMGenSetting.stMFactory_Adjust.enTMP_WHITE_PATTERN == EN_FacAdj_WhitePattern_Off)
                            u16TempID=en_strOFF;
                        else if (stLMGenSetting.stMFactory_Adjust.enTMP_WHITE_PATTERN == EN_FacAdj_WhitePattern_White)
                            u16TempID=en_strCCWhiteText;
                        else if (stLMGenSetting.stMFactory_Adjust.enTMP_WHITE_PATTERN == EN_FacAdj_WhitePattern_Red)
                            u16TempID=en_strCCRedText;
                        else if (stLMGenSetting.stMFactory_Adjust.enTMP_WHITE_PATTERN == EN_FacAdj_WhitePattern_Green)
                            u16TempID=en_strCCGreenText;
                        else if (stLMGenSetting.stMFactory_Adjust.enTMP_WHITE_PATTERN == EN_FacAdj_WhitePattern_Blue)
                            u16TempID=en_strCCBlueText;
                        else if (stLMGenSetting.stMFactory_Adjust.enTMP_WHITE_PATTERN == EN_FacAdj_WhitePattern_Black)
                            u16TempID=en_strCCBlackText;
                    }
                    break;
            #if ENABLE_PVR
                case 4: // Record All Function
                    {
                        if (stGenSetting.g_SysSetting.u8PVR_IsRecordAllChannel)
                            u16TempID=en_strON;
                        else
                            u16TempID=en_strOFF;
                    }
                    break;
            #endif
            #if (ENABLE_FACTORY_POWER_ON_MODE)
                case 5: //
                    if (stGenSetting.g_FactorySetting.u8PowerOnMode == POWERON_MODE_OFF)
                        u16TempID=en_strOFF;
                    else if (stGenSetting.g_FactorySetting.u8PowerOnMode == POWERON_MODE_ON)
                        u16TempID=en_strON;
                    else
                        u16TempID=en_str_last;
                    break;
            #endif
            #if (ENABLE_USB_DOWNLOAD_BIN)
                case 6:
                {
                    if(g_PQUpdateResult==E_USB_DL__OK)
                        u16TempID=en_strSUCCESS;
                    else
                        u16TempID=en_strFAIL;
                }
                break;
            #endif
#ifdef ENABLE_CUS_FACTORY_ATV_CH_PRSET
		case 7:
			if(stGenSetting.g_SysSetting.uFactoryChannelFlag)
			{
				u16TempID = en_strON;
			}
			else
			{
				u16TempID = en_strOFF;
			}
			break;
#endif
#if ENABLE_CUS_BURNING_MODE
		case 8:
			if(stGenSetting.g_FactorySetting.fBuringMode)
			{
				u16TempID = en_strON;
			}
			else
			{
				u16TempID = en_strOFF;
			}
		break;
#endif
#if (PADS_PWM1_MODE != Unknown_pad_mux)
	case 10:
		return MApp_ZUI_API_GetU16HexString(PwmPeriod);
		break;
	case 11:
		return MApp_ZUI_API_GetU16HexString((U16)Pwmduty);
		break;
	case 12:
		return MApp_ZUI_API_GetU16HexString(PwmDiv);
		break;
#endif
#if ENABLE_FACTORY_GAMMA
	case 13:
		if(GammaEnable)
		{
			u16TempID = en_strON;
		}
		else
		{
			u16TempID = en_strOFF;
		}
		break;
#endif

            }
        break;
    case EN_FACTORY_PAGE_VIF1:
#if ENABLE_VD_PACH_IN_CHINA
            switch(u8Item)
            {
                case 0:
                    return MApp_ZUI_API_GetU16HexString(stGenSetting.g_FactorySetting.u8AFEC_D4);
                    break;
                case 1:
                    return MApp_ZUI_API_GetU16HexString(stGenSetting.g_FactorySetting.u8AFEC_D5_Bit2);
                    break;
                case 2:
                    return MApp_ZUI_API_GetU16HexString(stGenSetting.g_FactorySetting.u8AFEC_D8_Bit3210);
                    break;
                case 3:
                    return MApp_ZUI_API_GetU16HexString(stGenSetting.g_FactorySetting.u8AFEC_D9_Bit0);
                    break;
                case 4:
                    return MApp_ZUI_API_GetU16HexString(stGenSetting.g_FactorySetting.u16AFEC_A0_A1);
                    break;
                case 5: //
                    return MApp_ZUI_API_GetU16HexString(stGenSetting.g_FactorySetting.u8AFEC_66_Bit76);
                    break;
                case 6: //
                    return MApp_ZUI_API_GetU16HexString(stGenSetting.g_FactorySetting.u8AFEC_6E_Bit7654);
                    break;
                case 7: //
                    return MApp_ZUI_API_GetU16HexString(stGenSetting.g_FactorySetting.u8AFEC_6E_Bit3210);
                        break;
                case 8: //
                    return MApp_ZUI_API_GetU16HexString(stGenSetting.g_FactorySetting.u8AFEC_D7_LOW_BOUND);
                    break;
                case 9: //
                    return MApp_ZUI_API_GetU16HexString(stGenSetting.g_FactorySetting.u8AFEC_D7_HIGH_BOUND);
                        break;
                case 10: //
                    return MApp_ZUI_API_GetU16HexString(stGenSetting.g_FactorySetting.u8AFEC_43);
                        break;
                case 11: //
                    return MApp_ZUI_API_GetU16HexString(stGenSetting.g_FactorySetting.u8AFEC_44);
                        break;
                case 12: //
                    return MApp_ZUI_API_GetU16HexString(stGenSetting.g_FactorySetting.u8AFEC_CB);
                    break;
                case 13: //
                    return MApp_ZUI_API_GetU16HexString(stGenSetting.g_FactorySetting.u8AFEC_CF_BIT2);
                    break;
                case 14: //
                    return MApp_ZUI_API_GetU16HexString(stGenSetting.g_FactorySetting.u8AFEC_4E_BIT7);
                    break;
                case 15: //
                    return MApp_ZUI_API_GetU16HexString(stGenSetting.g_FactorySetting.u8AFEC_4F);
                    break;

                default:
                        break;
            }
    #endif
        break;
        case EN_FACTORY_PAGE_VIF2:
#if ENABLE_VD_PACH_IN_CHINA
            switch(u8Item)
            {
                case 0: //
                        return MApp_ZUI_API_GetU16HexString(stGenSetting.g_FactorySetting.Vif_TOP);
                        break;
                case 1: //
                        return MApp_ZUI_API_GetU16HexString(stGenSetting.g_FactorySetting.Vif_VGA_MAXIMUM);
                        break;
                case 2: //
                        return MApp_ZUI_API_GetU16HexString(stGenSetting.g_FactorySetting.Vif_CHINA_DESCRAMBLER_BOX);
                        break;
                case 3: //
                        return MApp_ZUI_API_GetU16HexString(stGenSetting.g_FactorySetting.Vif_CR_KP_KI);
                        break;
                case 4: //
                        return MApp_ZUI_API_GetU16HexString(stGenSetting.g_FactorySetting.Vif_CR_THR);
                        break;
                case 5: //
                        return MApp_ZUI_API_GetU16HexString(stGenSetting.g_FactorySetting.Vif_CR_KP_KI_ADJUST);
                        break;
                case 6: //
                        return MApp_ZUI_API_GetU16HexString(stGenSetting.g_FactorySetting.Vif_CLAMPGAIN_GAIN_OV_NEGATIVE);
                        break;
                case 7: //
                        return MApp_ZUI_API_GetU16HexString(stGenSetting.g_FactorySetting.Vif_OVER_MODULATION);
                        break;
                case 8: //
                        return MApp_ZUI_API_GetU16HexString(stGenSetting.g_FactorySetting.Vif_ASIA_SIGNAL_OPTION);
                        break;
                case 9: //
                        return MApp_ZUI_API_GetU16HexString(stGenSetting.g_FactorySetting.Vif_CR_LOCK_THR);
                        break;
                case 10: //
                        return MApp_ZUI_API_GetU16HexString(stGenSetting.g_FactorySetting.Vif_AGCREFNEGATIVE);
                        break;
                case 11: //
                        return MApp_ZUI_API_GetU16HexString(stGenSetting.g_FactorySetting.Vif_SERIOUS_ACIDETECT);
                        break;
                default: //
                        break;
            }
    #endif
        break;
        case EN_FACTORY_PAGE_VIF3:
#if ENABLE_VD_PACH_IN_CHINA
            switch(u8Item)
            {
                case 0:
                {
                    if(stGenSetting.g_FactorySetting.AUDIO_HIDEV==E_AUDIO_HIDEV_BW_L1)
                    {
                         u16TempID=en_str_HIDEVL1;
                    }
                    else  if(stGenSetting.g_FactorySetting.AUDIO_HIDEV==E_AUDIO_HIDEV_BW_L2)
                    {
                         u16TempID=en_str_HIDEVL2;
                    }
                    else if(stGenSetting.g_FactorySetting.AUDIO_HIDEV==E_AUDIO_HIDEV_BW_L3)
                    {
                         u16TempID=en_str_HIDEVL3;
                    }
                    else
                     {
                       u16TempID=en_str_Off;
                     }
                  }
                  break;
                case 1: //
                        return MApp_ZUI_API_GetU16HexString(stGenSetting.g_FactorySetting.AUDIO_NR);
                        break;
                case 2: //
                        return MApp_ZUI_API_GetU16HexString(stGenSetting.g_FactorySetting.SCAN_DELAY);
                        break;
                case 3: //
                        return MApp_ZUI_API_GetU16HexString(stGenSetting.g_FactorySetting.COMBPATCH);
                        break;
                case 4: //
                        return MApp_ZUI_API_GetU16HexString(stGenSetting.g_FactorySetting.NOTSTANDARDPATCH);
                        break;
                case 5: //
                       {
                          char ptr_head[30];
                          MDrv_IFDM_SetParameter(VIF_PARA_GET_VERSION, ptr_head, sizeof(ptr_head));
                          return MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, (U8 *)ptr_head, strlen(ptr_head));
                       }
                        break;
                case 6: //
                     {
                         U16 Dspversion;
                         Dspversion=MDrv_Read2Byte(BK_AFEC_D0_ADDRESS);
                         return MApp_ZUI_API_GetU16HexString(Dspversion);
                    }
                        break;
           default:
               break;
            }
    #endif
        break;

        case EN_FACTORY_PAGE_UART_DBG: //wing
            switch(u8Item)
            {
                case 0:
                 if(mdrv_uart_get_connection(E_UART_PORT0) == E_UART_AEON_R2)
                 {
                    u16TempID=en_str_uart_dbg_HK;
                 }
                 else if(mdrv_uart_get_connection(E_UART_PORT0) == E_UART_AEON)
                 {
                    u16TempID=en_str_uart_dbg_AEON;
                 }
                 else if(mdrv_uart_get_connection(E_UART_PORT0) == E_UART_VDEC )
                 {
                    u16TempID=en_str_uart_dbg_VDEC;
                 }
                 else
                 {
                    u16TempID=en_str_DMP_AB_NONE; //avoid string table to large
                 }
                break;
            }
            break;
    #if (ENABLE_SZ_FACTORY_OVER_SCAN_FUNCTION)
        case EN_FACTORY_PAGE_OVERSCAN:
            switch(u8Item)
            {
                case 0: //reslution
                {
                    U16 u16H, u16V, u16F;
                    LPTSTR str = CHAR_BUFFER; //iu8Buffer_i = 0;

                    if ( IsYPbPrInUse() )
                    {
                        if(g_PcadcModeSetting[MAIN_WINDOW].u8ModeIndex >= MApi_XC_GetTotalModeCount() )
                        {
                            return NULL;
                        }

                        u16V = MApp_PCMode_Get_VResolution( MAIN_WINDOW ,TRUE);

                        if( u16V == 0 )//not get resolution yet , so return 0 , to avoid kill timer
                            return NULL;

                        __MApp_UlongToString( ( U32 )u16V, str, MApp_GetNoOfDigit( u16V ) );
                        str += MApp_ZUI_API_Strlen(str); //iu8Buffer_i = __strlen( p_string_buffer );
                        if (MApi_XC_PCMonitor_GetSyncStatus(MAIN_WINDOW) & XC_MD_INTERLACE_BIT)
                        {
                            *str++ = CHAR_i;
                        }
                        else
                        {
                            *str++ = CHAR_p;
                        }

                        u16F = (MApi_XC_PCMonitor_Get_VFreqx10( MAIN_WINDOW ) + 5) / 10;
                        if(u16F > 56 && u16F < 62)
                        {
                            u16F= 60;
                        }
                        else if(u16F > 46 && u16F < 52)
                        {
                            u16F= 50;
                        }
                        else if(u16F > 22 && u16F < 26)
                        {
                            u16F = 24;
                        }
                        else if(u16F > 28 && u16F < 32)
                        {
                            u16F = 30;
                        }
                        else
                        {
                            u16F= 60;
                        }
                        *str++ = CHAR_AT;
                        __MApp_UlongToString( ( U32 )u16F, str, MApp_GetNoOfDigit( u16F ) );
                        str += MApp_ZUI_API_Strlen(str);
                        *str++ = CHAR_H;
                        *str++ = CHAR_z;
                        *str = 0;
                        return (MApp_IsSrcHasSignal(MAIN_WINDOW) == FALSE) ? NULL : CHAR_BUFFER;
                    }
                    else if ( IsVgaInUse() )
                    {
                        if(MApp_PCMode_GetCurrentState(MAIN_WINDOW) != E_PCMODE_STABLE_SUPPORT_MODE)    //(MApp_PCMode_SyncLossFlag() || g_bUnsupportMode || (g_bInputTimingStable!=TRUE))
                        {
                            return NULL;
                        }
                        else
                        {
                            u16H = MApp_PCMode_Get_HResolution( MAIN_WINDOW , TRUE);
                            u16V = MApp_PCMode_Get_VResolution( MAIN_WINDOW , TRUE);
                            u16F = MApi_XC_GetVerticalFrequency(MApp_PCMode_Get_Mode_Idx(MAIN_WINDOW)) / 10;
                           if(u16F > 58 && u16F < 61)
                            {
                                u16F= 60;
                            }
                            if(u16F > 63 && u16F < 66)
                            {
                                u16F= 65;
                            }
                            else if(u16F > 68 && u16F < 71)
                            {
                                u16F= 70;
                            }
                            else if( u16F > 73 && u16F < 76)
                            {
                                u16F= 75;
                            }
                            __MApp_UlongToString( ( U32 )u16H, str, MApp_GetNoOfDigit( u16H ) );
                            str += MApp_ZUI_API_Strlen(str); //iu8Buffer_i = __strlen( p_string_buffer );
                            *str++ = CHAR_x;
                            __MApp_UlongToString( ( U32 )u16V, str, MApp_GetNoOfDigit( u16V ) );
                            str += MApp_ZUI_API_Strlen(str); //iu8Buffer_i = __strlen( p_string_buffer );
                            *str++ = CHAR_AT;
                            __MApp_UlongToString( ( U32 )u16F, str, MApp_GetNoOfDigit( u16F ) );
                            str += MApp_ZUI_API_Strlen(str); //iu8Buffer_i = __strlen( p_string_buffer );
                            *str++ = CHAR_H;
                            *str++ = CHAR_z;
                            *str = 0;

                            return CHAR_BUFFER;
                        }
                    }
                    else if ( IsHDMIInUse() )
                    {
                        if (MApp_IsSrcHasSignal(MAIN_WINDOW) == FALSE)
                            return NULL;

                        u16V = MApp_PCMode_Get_VResolution(MAIN_WINDOW,FALSE);
                        u16H = MApp_PCMode_Get_HResolution(MAIN_WINDOW,FALSE);
                        if((u16V==0)||(u16H==0))
                        {
                            return NULL;
                        }

                        if ((u16H >= 710 && u16H <= 1540) && (u16V >= 470 && u16V <= 490))
                        {
                            u16V = 480;
                        }
                        else if ((u16H>=710 && u16H<=1540)&&(u16V > 566 && u16V < 586))
                        {
                            u16V = 576;
                        }
                        // 1280x720
                        else if((u16V > 710 && u16V < 730) && (u16H> 1270 && u16H < 1290))
                        {
                            u16V = 720;
                        }
                        // 1920x1080
                        else if((u16V > 1070 && u16V < 1090) && (u16H > 1910 && u16H < 1930))
                        {
                            u16V = 1080;
                        }
                        else
                        {
                            u16F = MApi_XC_PCMonitor_Get_VFreqx10( MAIN_WINDOW );
                            if ((u16H >= 620&& u16H <= 670) && (u16V >= 470 && u16V <= 490))
                            {
                                u16V = 480;
                                u16H = 640;
                            }
                            else if ((u16H >= 780&& u16H <= 840) && (u16V >= 580&& u16V <= 620))
                            {
                                u16V = 600;
                                u16H = 800;
                            }
                            else if ((u16H >= 1000&& u16H <= 1050) && (u16V >= 740&& u16V <= 790))
                            {
                                u16V = 768;
                                u16H = 1024;
                            }
                            else if( (u16H> 1270 && u16H < 1300)&&(u16V > 740 && u16V < 790))
                            {
                                u16V = 768;
                                u16H = 1280;
                            }
                            else if( (u16H> 1300 && u16H < 1390)&&(u16V > 740 && u16V < 790))
                            {
                                u16V = 768;
                                u16H = 1360;
                            }
                            else if ((u16H >= 1260&& u16H <= 1300) && (u16V >= 1000&& u16V <= 1250))
                            {
                                u16V = 1024;
                                u16H = 1280;
                            }
                            else if ((u16H >= 1580&& u16H <= 1620) && (u16V >= 1180&& u16V <= 1220))
                            {
                                u16V = 1200;
                                u16H = 1600;
                            }
                            else
                            {
                                ;
                            }

                            if(u16F > 560 && u16F < 620)
                            {
                                u16F= 60;
                            }
                            else if(u16F > 670 && u16F < 710)
                            {
                                u16F= 70;
                            }
                            else if(u16F >= 710 && u16F < 730)
                            {
                                u16F= 72;
                            }
                            else if( u16F > 730 && u16F < 770)
                            {
                                u16F= 75;
                            }
                            else if( u16F > 800 && u16F < 850)
                            {
                                u16F= 85;
                            }
                            else
                            {
                                u16F = (u16F+5)/10;
                            }

                            __MApp_UlongToString( ( U32 )u16H, str, MApp_GetNoOfDigit( u16H ) );
                            str += MApp_ZUI_API_Strlen(str);
                            *str++ = CHAR_x;
                            __MApp_UlongToString( ( U32 )u16V, str, MApp_GetNoOfDigit( u16V ) );
                            str += MApp_ZUI_API_Strlen(str);
                            *str++ = CHAR_AT;
                            __MApp_UlongToString( ( U32 )u16F, str, MApp_GetNoOfDigit( u16F ) );
                                str += MApp_ZUI_API_Strlen(str);
                            *str++ = CHAR_H;
                            *str++ = CHAR_z;
                            *str = 0;
                            return CHAR_BUFFER;
                        }

                        {
                            __MApp_UlongToString( ( U32 )u16V, str, MApp_GetNoOfDigit( u16V ) );
                            str += MApp_ZUI_API_Strlen(str);
                        }

                        if (MApi_XC_PCMonitor_GetSyncStatus(MAIN_WINDOW) & XC_MD_INTERLACE_BIT)
                        {
                            *str++ = CHAR_i;
                        }
                        else
                        {
                            *str++ = CHAR_p;
                        }
                        u16F=MApi_XC_PCMonitor_Get_VFreqx10(MAIN_WINDOW);
                        if( u16F > 550 )
                        {// (60)
                            u16F = 60;
                        }
                        else if( u16F > 450 )
                        {// (50)
                            u16F =50;
                        }
                        else if( u16F > 275 )
                        {// (30)
                            u16F = 30;
                        }
                        else if( u16F > 240 )
                        {//(25P)
                            u16F = 25;
                        }
                        else if( u16F > 230 )
                        {//(24P)
                            u16F = 24;
                        }
                        else if( u16F > 200 )
                        {//(23P)
                            u16F = 23;
                        }
                        *str++ = CHAR_AT;
                        __MApp_UlongToString( ( U32 )u16F, str, MApp_GetNoOfDigit( u16F ) );
                        str += MApp_ZUI_API_Strlen(str);
                        *str++ = CHAR_H;
                        *str++ = CHAR_z;
                        *str = 0;
                        return CHAR_BUFFER;
                    }
                    else if(IsDTVInUse())
                    {
                        VDEC_DispInfo pinfo;
                        BOOLEAN bRet = msAPI_VID_GetVidInfo(&pinfo);

                        u16V = pinfo.u16VerSize;

                        if (u16V >= 470 && u16V <= 490)
                        {
                            u16V = 480;
                        }
                        else if (u16V > 566 && u16V < 586)
                        {
                            u16V = 576;
                        }
                        else if(u16V > 710 && u16V < 730)
                        {
                            u16V = 720;
                        }
                        else if(u16V > 1070 && u16V < 1090)
                        {
                            u16V = 1080;
                        }

                        if(MApp_IsSrcHasSignal(MAIN_WINDOW) && bRet )//if(u16V > 0)
                        {
                            __MApp_UlongToString( ( U32 )u16V, str, MApp_GetNoOfDigit( u16V ) );
                            str += MApp_ZUI_API_Strlen(str); //iu8Buffer_i = __strlen( p_string_buffer );

                            if(pinfo.u8Interlace == 1)
                                *str++ = CHAR_i;
                            else
                                *str++ = CHAR_p;

                            *str = 0;

                            return CHAR_BUFFER;
                        }
                        else
                            return NULL;
                    }
                    else
                    {
                         if (MApp_IsSrcHasSignal(MAIN_WINDOW) == FALSE)
                              return NULL;
                    #if 1
                        switch ( mvideo_vd_get_videosystem() )
                        {
                            case SIG_NTSC:
                                *str++ = 'N';
                                *str++ = 'T';
                                *str++ = 'S';
                                *str++ = 'C';
                                *str = 0;
                                break;

                            case SIG_NTSC_443:
                                *str++ = 'N';
                                *str++ = 'T';
                                *str++ = 'S';
                                *str++ = 'C';
                                *str++ = '4';
                                *str++ = '4';
                                *str++ = '3';
                                *str = 0;
                                break;

                            case SIG_PAL:
                                *str++ = 'P';
                                *str++ = 'A';
                                *str++ = 'L';
                                *str = 0;
                                break;

                            case SIG_PAL_M:
                                *str++ = 'P';
                                *str++ = 'A';
                                *str++ = 'L';
                                *str++ = '-';
                                *str++ = 'M';
                                *str = 0;
                                break;

                            case SIG_PAL_NC:
                                *str++ = 'P';
                                *str++ = 'A';
                                *str++ = 'L';
                                *str++ = '-';
                                *str++ = 'N';
                                *str++ = 'c';
                                *str = 0;
                                break;

                            case SIG_SECAM:
                                *str++ = 'S';
                                *str++ = 'E';
                                *str++ = 'C';
                                *str++ = 'A';
                                *str++ = 'M';
                                *str = 0;
                                break;

                            default:
                                return NULL;
                        }
                    #else
                        switch ( mvideo_vd_get_videosystem() )
                        {
                            case SIG_NTSC:
                            case SIG_NTSC_443:
                                //u16TempID = en_str_resolution_480i;
                                *str++ = '4';
                                *str++ = '8';
                                *str++ = '0';
                                *str++ = CHAR_i;
                                *str = 0;
                                break;
                            case SIG_PAL:
                            case SIG_PAL_M:
                            case SIG_PAL_NC:
                            case SIG_SECAM:
                                //u16TempID = en_str_resolution_576i;
                                *str++ = '5';
                                *str++ = '7';
                                *str++ = '6';
                                *str++ = CHAR_i;
                                *str = 0;
                                break;
                            default:
                                return NULL;
                        }
                    #endif
                        return CHAR_BUFFER;
                    }

                    return NULL;
                }
                //u16TempID=en_str_overscan_reslution;
                break;

                case 2: // osOffsetX: h-position
                    return MApp_ZUI_API_GetS16SignString((S16)(g_OverScan.osOffsetX));

                case 3: // osOffsetWidth: h-size
                    return MApp_ZUI_API_GetS16SignString((S16)(g_OverScan.osOffsetWidth));

                case 4: // osOffsetY: v-position
                    return MApp_ZUI_API_GetS16SignString((S16)(g_OverScan.osOffsetY));

                case 5: // osOffsetHeight: v-size
                     return MApp_ZUI_API_GetS16SignString((S16)(g_OverScan.osOffsetHeight));

            }
            break;
    #endif

 #if (ENABLE_NONLINEAR_CURVE)

            case EN_FACTORY_PAGE_NONLINEAR_CURVE:
                switch(u8Item)
                {
                    case 0:
                        u16TempID = _MApp_ZUI_ACT_GetDataInputSourceStringID(DATA_INPUT_SOURCE_TYPE(MAIN_WINDOW));
                        break;

                    case 1:
                        u16TempID = _MApp_ZUI_ACT_GetPictureModeStringID();
                        break;
                }
            break;
             case EN_FACTORY_PAGE_BRIGHTNESS_CURVE:
            case EN_FACTORY_PAGE_CONTRAST_CURVE:
            case EN_FACTORY_PAGE_SATURATION_CURVE:
            case EN_FACTORY_PAGE_HUE_CURVE:
            case EN_FACTORY_PAGE_SHARPNESS_CURVE:
            case EN_FACTORY_PAGE_VOLUME_CURVE:
            {
                P_MS_USER_NONLINEAR_CURVE pNonLinearCurve = NULL;
              #if ENABLE_SOUND_NONLINEAR_CURVE_TEN
		P_MS_USER_NONLINEAR_CURVE_TEN pNonLinearCurveTen= NULL;
		#endif

#if(ENABLE_PICTURE_NONLINEAR_CURVE)
                if(EN_FACTORY_PAGE_BRIGHTNESS_CURVE == _eFactoryMenuPage)
                {
                    pNonLinearCurve = MApp_GetNonLinearCurve(NONLINEAR_CURVE_BRIGHTNESS);
                }
                else if(EN_FACTORY_PAGE_CONTRAST_CURVE == _eFactoryMenuPage)
                {
                    pNonLinearCurve = MApp_GetNonLinearCurve(NONLINEAR_CURVE_CONTRAST);
                }
                else if(EN_FACTORY_PAGE_SATURATION_CURVE == _eFactoryMenuPage)
                {
                    pNonLinearCurve = MApp_GetNonLinearCurve(NONLINEAR_CURVE_SATURATION);
                }
                else if(EN_FACTORY_PAGE_SHARPNESS_CURVE == _eFactoryMenuPage)
                {
                    pNonLinearCurve = MApp_GetNonLinearCurve(NONLINEAR_CURVE_SHARPNESS);
                }
                else if(EN_FACTORY_PAGE_HUE_CURVE == _eFactoryMenuPage)
                {
                    pNonLinearCurve = MApp_GetNonLinearCurve(NONLINEAR_CURVE_HUE);
                }
#endif
#if(ENABLE_SOUND_NONLINEAR_CURVE)
                if(EN_FACTORY_PAGE_VOLUME_CURVE == _eFactoryMenuPage)
                {
                  #if ENABLE_SOUND_NONLINEAR_CURVE_TEN
		   pNonLinearCurveTen = MApp_GetNonLinearCurveTen(NONLINEAR_CURVE_VOLUME);
		 #else
                    pNonLinearCurve = MApp_GetNonLinearCurve(NONLINEAR_CURVE_VOLUME);
		 #endif
                }
#endif
    #if ENABLE_SOUND_NONLINEAR_CURVE_TEN
	  if(EN_FACTORY_PAGE_VOLUME_CURVE == _eFactoryMenuPage)
	  	{
	switch(u8Item)
                {
                    case 0:
                        return MApp_ZUI_API_GetU16String(pNonLinearCurveTen->u8OSD_0);

                    case 1:
                        return MApp_ZUI_API_GetU16String(pNonLinearCurveTen->u8OSD_10);

                    case 2:
                        return MApp_ZUI_API_GetU16String(pNonLinearCurveTen->u8OSD_20);

                    case 3:
                        return MApp_ZUI_API_GetU16String(pNonLinearCurveTen->u8OSD_30);

                    case 4:
                        return MApp_ZUI_API_GetU16String(pNonLinearCurveTen->u8OSD_40);
			case 5:
                        return MApp_ZUI_API_GetU16String(pNonLinearCurveTen->u8OSD_50);

                    case 6:
                        return MApp_ZUI_API_GetU16String(pNonLinearCurveTen->u8OSD_60);

                    case 7:
                        return MApp_ZUI_API_GetU16String(pNonLinearCurveTen->u8OSD_70);

                    case 8:
                        return MApp_ZUI_API_GetU16String(pNonLinearCurveTen->u8OSD_85);

                    case 9:
                        return MApp_ZUI_API_GetU16String(pNonLinearCurveTen->u8OSD_100);
						
					case 10:
						return MApp_ZUI_API_GetU16String(pNonLinearCurveTen->Prescale);
					case 11:
						return MApp_ZUI_API_GetU16String(pNonLinearCurveTen->u8AVC_Value);
                 #if 1
				    case 12:
						if(stGenSetting.g_SysSetting.fAutoVolume)
							u16TempID=en_str_On;
						else
							u16TempID=en_str_Off;
						return MApp_ZUI_API_GetString(u16TempID);
				 #endif
                    #if ENABLE_FACTORY_DRC
                    case 13:
						if(BDrcEnable)
							u16TempID=en_str_On;
						else
							u16TempID=en_str_Off;
                    break;
                    
                    case 14:
						return MApp_ZUI_API_GetU16String(BDrcValue);
                    break;
                    #endif
                }
	  	}
	  else
	#endif
    	{
                switch(u8Item)
                {
                    case 0:
                        return MApp_ZUI_API_GetU16String(pNonLinearCurve->u8OSD_0);

                    case 1:
                        return MApp_ZUI_API_GetU16String(pNonLinearCurve->u8OSD_25);

                    case 2:
                        return MApp_ZUI_API_GetU16String(pNonLinearCurve->u8OSD_50);

                    case 3:
                        return MApp_ZUI_API_GetU16String(pNonLinearCurve->u8OSD_75);

                    case 4:
                        return MApp_ZUI_API_GetU16String(pNonLinearCurve->u8OSD_100);
                }
                }
            }
            break;
#endif
#if (ENABLE_FACTORY_PANEL_SEL)
        case EN_FACTORY_PAGE_PANEL_SELECTION:
            switch(u8Item)
            {
                case 0:
                    return MApp_ZUI_API_GetU16String(g_ProjectID);
                case 1:
                {
                    U8 str[20] ;
                    MApp_ZUI_ACT_GetProjectName(g_ProjectID,str);

                   return  MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, str,20);
                }
            }
            break;
#endif


#if      ENABLE_SZ_FACTORY_USB_SAVE_MAP_FUNCTION
            case EN_FACTORY_PAGE_REGISTER_MAP:
            {
                switch(u8Item)
                {
                    case 0:
                        return MApp_ZUI_API_GetU16HexString(u32MainBankValue);
                        break;
                    case 1:
                        return MApp_ZUI_API_GetU16HexString(u32SubBankValue);
                        break;
                    case 2:
                    {
                        if(ResultFlag == FALSE)
                        {
                            u16TempID=en_str_DMP_AB_NONE;
                        }
                        else
                        {
                             if(g_DatabaseSaveResult)
                             {
                                u16TempID=en_strSUCCESS;
                             }
                            else
                             {
                                u16TempID=en_strFAIL;
                             }
                         }
                    }
                    break;
                    case 3:
                    {
                        if(ResultFlag == FALSE)
                        {
                             u16TempID=en_str_DMP_AB_NONE;
                        }
                        else
                        {
                             if(g_DatabaseSaveResult)
                             {
                                 u16TempID=en_strSUCCESS;
                             }
                             else
                             {
                                 u16TempID=en_strFAIL;
                             }
                         }
                    }
                    break;
                    case 4:
                    {
                        if(ResultFlag == FALSE)
                        {
                             u16TempID=en_str_DMP_AB_NONE;
                        }
                        else
                        {
                             if(g_DatabaseSaveResult)
                             {

                                 u16TempID=en_strSUCCESS;
                             }
                             else
                             {

                                 u16TempID=en_strFAIL;
                             }
                         }
                    }
                    break;
                }
            }
            break;
#endif

        default:
            break;
    }

    if (u16TempID != Empty)
        return MApp_ZUI_API_GetString(u16TempID);
    return NULL; //for empty string
}

////////////////////////////////////////////////////////
//CUS_XM:xue add forfactory RC Backlight aadjust 2012-6-13
void Mapp_BackLightAdjust50or100(U8 blvalue)
{
	printf("handle Factory B/L key");
	stGenSetting.g_SysSetting.u8Backlight=blvalue;
	Panel_Backlight_PWM_ADJ(msAPI_Mode_PictureBackLightN100toReallyValue(stGenSetting.g_SysSetting.u8Backlight));
	MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_ADVANCE_PICTURE_PC_BACKLIGHT);
}

BOOLEAN Mapp_SwitchRS232Mode(void)
{
	printf("handle Factory RS232 key");
	if(mdrv_uart_get_connection(E_UART_PORT0) == E_UART_OFF)
		 {
			printf("xue trace open RS232");
			MDrv_UART_Init(E_UART_AEON_R2, 115200);
			mdrv_uart_connect(E_UART_PORT0,E_UART_AEON_R2);
			return TRUE;
		 }
	else
		 {
		 	printf("xue trace close RS232");
			MDrv_UART_Init(E_UART_AEON_R2, 115200);
			mdrv_uart_connect(E_UART_PORT0, E_UART_OFF);
			return FALSE;
		 }
	MApp_ZUI_API_InvalidateAllSuccessors(HWND_CSM_RS232);
	return FALSE;
}

BOOLEAN MApp_ZUI_ACT_ExecuteFactoryMenuAction(U16 act)
{
	HWND hwnd;
	switch(act)
    {
        case EN_EXE_FACTORY_MENU_GOTO_BAR_ADJUST:

            if((_eFactoryMenuPage == EN_FACTORY_PAGE_SW_INFO_PAGE)||(_eFactoryMenuPage == EN_FACTORY_PAGE_ADC_ADJUST)||
              ( _eFactoryMenuPage == EN_FACTORY_PAGE_PICTURE_MODE)|| (_eFactoryMenuPage == EN_FACTORY_PAGE_WHITE_BALANCE)||(_eFactoryMenuPage == EN_FACTORY_PAGE_VCOM))
            {
               if(MApp_ZUI_API_GetFocus() == HWND_FACTORY_MENU_ITEM0)
               {
                  return TRUE;
               }
            }
   #if  ENABLE_SZ_FACTORY_USB_SAVE_MAP_FUNCTION
            if(_eFactoryMenuPage == EN_FACTORY_PAGE_REGISTER_MAP)
            {
                _eFactoryBarInfo.pre_item = MApp_ZUI_API_GetFocus();
                _eFactoryBarInfo.cur_item = MApp_ZUI_API_GetFocus();
                return TRUE;
            }

  #endif
            //skip resolution bar setting
            if((_eFactoryMenuPage == EN_FACTORY_PAGE_ROOT) &&  (MApp_ZUI_API_GetFocus() == HWND_FACTORY_MENU_ITEM0))
            {
               return TRUE;
            }
        #if ENABLE_AUTO_DQS_Factory
            if(_eFactoryMenuPage == EN_FACTORY_PAGE_BIST_TEST)
            {
               return TRUE;
            }
        #endif
	       _eFactoryBarInfo.pre_item = MApp_ZUI_API_GetFocus();

            if(_MApp_ZUI_ACT_GetFactoryMenuValueText(_MApp_ZUI_ACT_FactoryMenuWindowMapToIndex(MApp_ZUI_API_GetFocus())) == NULL)
            {
               return TRUE;
            }
            _eFactoryBarInfo.cur_item = HWND_FACTORY_MENU_BAR_TEXT;
            MApp_ZUI_API_ShowWindow(HWND_MAINFRAME, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BG_TRANSPARENT, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BAR_TRANS, SW_SHOW);
            MApp_ZUI_API_SetFocus(HWND_FACTORY_MENU_BAR);
            return TRUE;

        case EN_EXE_FACTORY_MENU_EXIT_BAR_ADJUST:
            MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BAR_TRANS, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BG_PANE, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_LIST, SW_SHOW);
            if(_eFactoryMenuPage == EN_FACTORY_PAGE_QMAP_PAGE)
            {
                  MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_HOT_KEY_HELP1, SW_SHOW);
                  MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_HOT_KEY_HELP2, SW_SHOW);
                  MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_INPUT_INFO, SW_SHOW);
                  MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BOARD_INFO, SW_HIDE);

            }
            _MApp_ZUI_ACT_FactoryMenuInitPage(_eFactoryMenuPage);
            MApp_ZUI_API_SetFocus(_eFactoryBarInfo.pre_item);
            return TRUE;

        case EN_EXE_BIST_TEST:
        #if ENABLE_AUTO_DQS_Factory
            if(_eFactoryMenuPage == EN_FACTORY_PAGE_BIST_TEST)
            {
                _BIST_TEST_MODE = EN_BIST_TEST_UI_PROCESSING;
                MApp_ZUI_API_InvalidateWindow(HWND_FACTORY_MENU_ITEM0_VALUE);
                _MApp_ZUI_API_WindowProcOnIdle();
                MDrv_MIU_AutoDQS_Factory();
                _BIST_TEST_MODE = EN_BIST_TEST_UI_END;
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_FACTORY_MENU_LIST);
            }
        #endif
            return TRUE;

        case EN_EXE_CLOSE_CURRENT_OSD:
		g_bGotoCUSMenu = 0;
            MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
            _enTargetOSDPageState = STATE_OSDPAGE_CLEAN_UP;

            #if ENABLE_DMP
            if(UI_INPUT_SOURCE_DMP == UI_INPUT_SOURCE_TYPE)
            {
                _enTargetOSDPageState = STATE_OSDPAGE_GOTO_DMP;
            }
     #if( ENABLE_DMP_SWITCH )
            else if(UI_INPUT_SOURCE_DMP1 == UI_INPUT_SOURCE_TYPE)
            {
                _enTargetOSDPageState = STATE_OSDPAGE_GOTO_DMP;
            }
           else if(UI_INPUT_SOURCE_DMP2 == UI_INPUT_SOURCE_TYPE)
            {
                _enTargetOSDPageState = STATE_OSDPAGE_GOTO_DMP;
            }
     #endif
            #endif

            #ifdef ENABLE_BT
            if(UI_INPUT_SOURCE_BT == UI_INPUT_SOURCE_TYPE)
            {
                _enTargetOSDPageState = STATE_OSDPAGE_GOTO_BT;
            }
            #endif

            #ifdef ENABLE_KTV
            if(UI_INPUT_SOURCE_KTV == UI_INPUT_SOURCE_TYPE)
            {
                _enTargetOSDPageState = STATE_OSDPAGE_GOTO_KTV;
            }
            #endif

            return TRUE;

        case EN_EXE_POWEROFF:
            MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
            _enTargetOSDPageState = STATE_OSDPAGE_GOTO_STANDBY;
            return TRUE;

        case EN_EXE_FACTORY_MENU_PREV_PAGE:
           #if(LOG_FACTORYMENU_SHOWITEM)
             {// Steven 20100825 for ������һҳʱ����ѡ�е�һ���Bug
                U8 u8Index = GetFactoryPreMenuItemIndex(_eFactoryMenuPage);
                _MApp_ZUI_ACT_FactoryMenuPrevPage(_MApp_ZUI_ACT_FactoryMenuWindowMapToIndex(MApp_ZUI_API_GetFocus()));
                _MApp_ZUI_ACT_FactoryMenuInitPage(_eFactoryMenuPage);
                if(u8Index!=0xFF)
                    MApp_ZUI_API_SetFocus(_FactoryMenuItemHwndList[u8Index]);
             }
           #else
             _MApp_ZUI_ACT_FactoryMenuPrevPage(_MApp_ZUI_ACT_FactoryMenuWindowMapToIndex(MApp_ZUI_API_GetFocus()));
             _MApp_ZUI_ACT_FactoryMenuInitPage(_eFactoryMenuPage);
           #endif
            return TRUE;

        case EN_EXE_FACTORY_MENU_NEXT_PAGE:
            if(_eFactoryMenuPage == EN_FACTORY_PAGE_QMAP_PAGE)
            {
                //printf("========== Get Focus [%u] ==========\n", (U16)MApp_ZUI_API_GetFocus());
                if(MApp_ZUI_API_GetFocus() != HWND_FACTORY_MENU_BG_TRANSPARENT)
                {
                    MApp_ZUI_API_ShowWindow(HWND_MAINFRAME, SW_HIDE);
                    MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BG_TRANSPARENT, SW_SHOW);
                    MApp_ZUI_API_SetFocus(HWND_FACTORY_MENU_BG_TRANSPARENT);
                }
                else
                {
                    FACTORY_MENU_PAGE _ePrevPage = EN_FACTORY_PAGE_QMAP_PAGE;
                    U8 u8ShowItem = 0;

                    MApp_ZUI_API_ShowWindow(HWND_MAINFRAME, SW_SHOW);
                    MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BG_TRANSPARENT, SW_HIDE);
                    u8ShowItem = _u8IPIndex%(COUNTOF(_FactoryMenuItemHwndList));
                    _MApp_ZUI_ACT_FactoryMenuInitPage(_ePrevPage);
                    MApp_ZUI_API_SetFocus(_FactoryMenuItemHwndList[u8ShowItem]);
                }
            }
            else
            {
                _MApp_ZUI_ACT_FactoryMenuNextPage(
                    _MApp_ZUI_ACT_FactoryMenuWindowMapToIndex(MApp_ZUI_API_GetFocus()));
                    _MApp_ZUI_ACT_FactoryMenuInitPage(_eFactoryMenuPage);
            }
            return TRUE;

        case EN_EXE_QMAP_PREV_PAGE:
            if(_eFactoryMenuPage == EN_FACTORY_PAGE_QMAP_PAGE)
             {
                BOOLEAN _bChangePage;
                 _bChangePage = FALSE;

                 if(_u8IPIndex == 0)
                 {
                     _u8IPIndex = _u8IPNumber - 1;
                 }
                 else
                 {
                     _u8IPIndex--;
                 }
                //printf("-------- PREV _u8IPIndex [%bu] --------\n", _u8IPIndex);
                 if(MApp_ZUI_API_GetFocus() == HWND_FACTORY_MENU_ITEM0)
                 {
                     _MApp_ZUI_ACT_QMAPPrevPage();
                     return TRUE;
                 }
             }
             return FALSE;

        case EN_EXE_QMAP_NEXT_PAGE:
            if(_eFactoryMenuPage == EN_FACTORY_PAGE_QMAP_PAGE)
             {
                 BOOLEAN _bChangePage;
                 _bChangePage = FALSE;
                 if((_u8IPIndex != 0) && (((_u8IPIndex+1)%(COUNTOF(_FactoryMenuItemHwndList))) == 0))
                 {
                     _bChangePage = TRUE;
                 }
                 if(_u8IPIndex == (_u8IPNumber-1))
                 {
                     _u8IPIndex = 0;
                     _bChangePage = TRUE;
                 }
                 else
                 {
                     _u8IPIndex++;
                 }
                 //printf("-------- NEXT _u8IPIndex [%bu] --------\n", _u8IPIndex);
                 if(_bChangePage)
                 {
                     _MApp_ZUI_ACT_QMAPNextPage();
                     return TRUE;
                 }
             }
             return FALSE;

        case EN_EXE_QMAP_PAGE_DOWN:
            if(_eFactoryMenuPage == EN_FACTORY_PAGE_QMAP_PAGE)
            {
                FACTORY_MENU_PAGE _ePrevPage = EN_FACTORY_PAGE_QMAP_PAGE;
                U8 u8ShowItem = 0;

                if(_u8IPIndex == (_u8IPNumber-1))
                {
                    _u8IPIndex = 0;
                }
                else if((_u8IPIndex + (U8)(COUNTOF(_FactoryMenuItemHwndList))) > (_u8IPNumber-1))
                {
                    _u8IPIndex = (_u8IPNumber - 1);
                }
                else
                {
                    _u8IPIndex = _u8IPIndex + (COUNTOF(_FactoryMenuItemHwndList));
                }
                u8ShowItem = _u8IPIndex%(COUNTOF(_FactoryMenuItemHwndList));
                _MApp_ZUI_ACT_FactoryMenuInitPage(_ePrevPage);
                MApp_ZUI_API_SetFocus(_FactoryMenuItemHwndList[u8ShowItem]);
            }
            return FALSE;

        case EN_EXE_QMAP_PAGE_UP:
            if(_eFactoryMenuPage == EN_FACTORY_PAGE_QMAP_PAGE)
            {
                FACTORY_MENU_PAGE _ePrevPage = EN_FACTORY_PAGE_QMAP_PAGE;
                U8 u8ShowItem = 0;

                if(_u8IPIndex == 0)
                {
                    _u8IPIndex = (_u8IPNumber - 1);
                }
                else if(_u8IPIndex < (COUNTOF(_FactoryMenuItemHwndList)))
                {
                    _u8IPIndex = 0;
                }
                else
                {
                    _u8IPIndex = _u8IPIndex - (COUNTOF(_FactoryMenuItemHwndList));
                }
                u8ShowItem = _u8IPIndex%(COUNTOF(_FactoryMenuItemHwndList));
                _MApp_ZUI_ACT_FactoryMenuInitPage(_ePrevPage);
                MApp_ZUI_API_SetFocus(_FactoryMenuItemHwndList[u8ShowItem]);
            }
            return FALSE;
//cus_xm 20120613 gary modify by cus_factory menu ADC/WB function satrt
        case EN_EXE_FACTORY_MENU_ADJ_DEC:
        case EN_EXE_FACTORY_MENU_ADJ_INC:
        {

if(g_bGotoCUSMenu==0)
	{
 #if    ENABLE_SZ_FACTORY_USB_SAVE_MAP_FUNCTION
            if((MApp_ZUI_API_GetFocus() == HWND_FACTORY_MENU_ITEM0)||(_eFactoryMenuPage ==  EN_FACTORY_PAGE_REGISTER_MAP))
 #else
            if(MApp_ZUI_API_GetFocus() == HWND_FACTORY_MENU_ITEM0)
  #endif
            {

 #if    ENABLE_SZ_FACTORY_USB_SAVE_MAP_FUNCTION
                 if(_eFactoryMenuPage ==  EN_FACTORY_PAGE_ROOT ||EN_FACTORY_PAGE_SW_INFO_PAGE||EN_FACTORY_PAGE_ADC_ADJUST||
                                                             EN_FACTORY_PAGE_PICTURE_MODE||EN_FACTORY_PAGE_WHITE_BALANCE||EN_FACTORY_PAGE_REGISTER_MAP)

 #else
                if(_eFactoryMenuPage == EN_FACTORY_PAGE_ROOT || EN_FACTORY_PAGE_SW_INFO_PAGE||EN_FACTORY_PAGE_ADC_ADJUST||
                  EN_FACTORY_PAGE_PICTURE_MODE||EN_FACTORY_PAGE_WHITE_BALANCE||EN_FACTORY_PAGE_VCOM)

  #endif
                 {
                        REDRAW_TYPE eRedraw = _MApp_ZUI_ACT_FactoryMenuDecIncValue(
                       _MApp_ZUI_ACT_FactoryMenuWindowMapToIndex(
                        MApp_ZUI_API_GetFocus()),
                        act==EN_EXE_FACTORY_MENU_ADJ_INC);

                       if (eRedraw == EN_REDRAW_ITEM)
                       {
                               MApp_ZUI_API_InvalidateAllSuccessors(MApp_ZUI_API_GetFocus());
                       }
                       else if (eRedraw == EN_REDRAW_LIST)
                       {
                               MApp_ZUI_API_InvalidateAllSuccessors(HWND_FACTORY_MENU_LIST);
                       }
                 }
              else
              {
                   return TRUE;
              }
            }
            else
            {
                    REDRAW_TYPE eRedraw = _MApp_ZUI_ACT_FactoryMenuDecIncValue(
                   _MApp_ZUI_ACT_FactoryMenuWindowMapToIndex(
                    _eFactoryBarInfo.pre_item),
                    act==EN_EXE_FACTORY_MENU_ADJ_INC);

                   if (eRedraw == EN_REDRAW_ITEM)
                   {
                         MApp_ZUI_API_InvalidateAllSuccessors(HWND_FACTORY_MENU_BAR);
                   }
                   else if (eRedraw == EN_REDRAW_LIST)
                   {
                         MApp_ZUI_API_InvalidateAllSuccessors(HWND_FACTORY_MENU_LIST);
                   }
            }
            return TRUE;
        }
else if(g_bGotoCUSMenu==2) //(g_bGotoCUSMenu==2)
	{
	if(MApp_ZUI_API_GetFocus() == HWND_FACTORY_MENU_CUS_LIST_ITEM17_NAME_1)
			{
			//printf("(U16)stGenSettingExt.g_AdcSetting[stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE].stAdcGainOffsetSetting.u16GreenGain===%d\n",(U16)stGenSettingExt.g_AdcSetting[stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE].stAdcGainOffsetSetting.u16GreenGain);
			stGenSettingExt.g_AdcSetting[stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE].stAdcGainOffsetSetting.u16RedGain =
                       (EN_FACTORY_ADC_ADJUST_MODE) MApp_ZUI_ACT_DecIncValue_Cycle(act==EN_EXE_FACTORY_MENU_ADJ_INC, (U16)stGenSettingExt.g_AdcSetting[stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE].stAdcGainOffsetSetting.u16RedGain, 0, MApi_XC_ADC_GetMaximalGainValue(), 1);
                    MApp_SaveADCSetting((E_ADC_SET_INDEX)stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE);

                    //if(DATA_INPUT_SOURCE_TYPE == stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE)
                    if( ( UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_RGB && stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_RGB )
                    #if (INPUT_YPBPR_VIDEO_COUNT >= 1)
                            ||( UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_COMPONENT && stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_Ypbpr_SD )
                            ||( UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_COMPONENT && stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_Ypbpr_HD )
                    #endif
                    #if (INPUT_SCART_VIDEO_COUNT >= 1)
                            ||( UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_SCART && stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_ScartRGB)
                    #endif
                        )
                    {
                        MApi_XC_ADC_AdjustGainOffset(&stGenSettingExt.g_AdcSetting[stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE].stAdcGainOffsetSetting);
                    }
				MApp_ZUI_API_InvalidateAllSuccessors(HWND_FACTORY_MENU_CUS_LIST_ITEM17_NAME_1);
			 	return TRUE;
			}
		else	if(MApp_ZUI_API_GetFocus() == HWND_FACTORY_MENU_CUS_LIST_ITEM17_NAME_2)
			{
			 //from case MAPP_UIMENUFUNC_ADJUSTADC_GREENGAIN:
                    stGenSettingExt.g_AdcSetting[stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE].stAdcGainOffsetSetting.u16GreenGain =
                       (EN_FACTORY_ADC_ADJUST_MODE) MApp_ZUI_ACT_DecIncValue_Cycle(act==EN_EXE_FACTORY_MENU_ADJ_INC, (U16)stGenSettingExt.g_AdcSetting[stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE].stAdcGainOffsetSetting.u16GreenGain, 0, MApi_XC_ADC_GetMaximalGainValue(), 1);
                    MApp_SaveADCSetting((E_ADC_SET_INDEX)stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE);
                    //if(DATA_INPUT_SOURCE_TYPE == stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE)
                    if( ( UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_RGB && stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_RGB )
                    #if (INPUT_YPBPR_VIDEO_COUNT >= 1)
                            ||( UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_COMPONENT && stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_Ypbpr_SD )
                            ||( UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_COMPONENT && stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_Ypbpr_HD )
                    #endif
                    #if (INPUT_SCART_VIDEO_COUNT >= 1)
                            ||( UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_SCART && stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_ScartRGB)
                    #endif
                        )
                    {
                        MApi_XC_ADC_AdjustGainOffset(&stGenSettingExt.g_AdcSetting[stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE].stAdcGainOffsetSetting);
                    }

				MApp_ZUI_API_InvalidateAllSuccessors(HWND_FACTORY_MENU_CUS_LIST_ITEM17_NAME_2);
			 	return TRUE;
			}
		else	if(MApp_ZUI_API_GetFocus() == HWND_FACTORY_MENU_CUS_LIST_ITEM17_NAME_3)
			{
			   //from case MAPP_UIMENUFUNC_ADJUSTADC_BLUEGAIN:
                    stGenSettingExt.g_AdcSetting[stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE].stAdcGainOffsetSetting.u16BlueGain =
                        (EN_FACTORY_ADC_ADJUST_MODE)MApp_ZUI_ACT_DecIncValue_Cycle(act==EN_EXE_FACTORY_MENU_ADJ_INC, (U16)stGenSettingExt.g_AdcSetting[stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE].stAdcGainOffsetSetting.u16BlueGain, 0, MApi_XC_ADC_GetMaximalGainValue(), 1);
                    MApp_SaveADCSetting((E_ADC_SET_INDEX)stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE);
                    //if(DATA_INPUT_SOURCE_TYPE == stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE)
                    if( ( UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_RGB && stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_RGB )
                    #if (INPUT_YPBPR_VIDEO_COUNT >= 1)
                            ||( UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_COMPONENT && stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_Ypbpr_SD )
                            ||( UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_COMPONENT && stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_Ypbpr_HD )
                    #endif
                    #if (INPUT_SCART_VIDEO_COUNT >= 1)
                            ||( UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_SCART && stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_ScartRGB)
                    #endif
                        )
                    {
                        MApi_XC_ADC_AdjustGainOffset(&stGenSettingExt.g_AdcSetting[stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE].stAdcGainOffsetSetting);
                    }

				MApp_ZUI_API_InvalidateAllSuccessors(HWND_FACTORY_MENU_CUS_LIST_ITEM17_NAME_3);
			 	return TRUE;
			}
		else	if(MApp_ZUI_API_GetFocus() == HWND_FACTORY_MENU_CUS_LIST_ITEM18_NAME_1)
			{
	//from case MAPP_UIMENUFUNC_ADJUSTADC_REDOFFSET:
                    stGenSettingExt.g_AdcSetting[stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE].stAdcGainOffsetSetting.u16RedOffset =
                        (EN_FACTORY_ADC_ADJUST_MODE)MApp_ZUI_ACT_DecIncValue_Cycle(act==EN_EXE_FACTORY_MENU_ADJ_INC, (U16)stGenSettingExt.g_AdcSetting[stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE].stAdcGainOffsetSetting.u16RedOffset, 0, MApi_XC_ADC_GetMaximalOffsetValue(), 1);
                    MApp_SaveADCSetting((E_ADC_SET_INDEX)stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE);
                    //if(DATA_INPUT_SOURCE_TYPE == stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE)
                    if( ( UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_RGB && stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_RGB )
                    #if (INPUT_YPBPR_VIDEO_COUNT >= 1)
                            ||( UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_COMPONENT && stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_Ypbpr_SD )
                            ||( UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_COMPONENT && stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_Ypbpr_HD )
                    #endif
                    #if (INPUT_SCART_VIDEO_COUNT >= 1)
                            ||( UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_SCART && stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_ScartRGB)
                    #endif
                        )
                    {
                        MApi_XC_ADC_AdjustGainOffset(&stGenSettingExt.g_AdcSetting[stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE].stAdcGainOffsetSetting);
                    }

				MApp_ZUI_API_InvalidateAllSuccessors(HWND_FACTORY_MENU_CUS_LIST_ITEM18_NAME_1);
			 	return TRUE;
			}
		else	if(MApp_ZUI_API_GetFocus() == HWND_FACTORY_MENU_CUS_LIST_ITEM18_NAME_2)
			{ //from case MAPP_UIMENUFUNC_ADJUSTADC_GREENOFFSET:
                    stGenSettingExt.g_AdcSetting[stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE].stAdcGainOffsetSetting.u16GreenOffset =
                        (EN_FACTORY_ADC_ADJUST_MODE)MApp_ZUI_ACT_DecIncValue_Cycle(act==EN_EXE_FACTORY_MENU_ADJ_INC,(U16) stGenSettingExt.g_AdcSetting[stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE].stAdcGainOffsetSetting.u16GreenOffset, 0, MApi_XC_ADC_GetMaximalOffsetValue(), 1);
                    MApp_SaveADCSetting((E_ADC_SET_INDEX)stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE);
                    //if(DATA_INPUT_SOURCE_TYPE == stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE)
                    if( ( UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_RGB && stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_RGB )
                    #if (INPUT_YPBPR_VIDEO_COUNT >= 1)
                            ||( UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_COMPONENT && stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_Ypbpr_SD )
                            ||( UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_COMPONENT && stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_Ypbpr_HD )
                    #endif
                    #if (INPUT_SCART_VIDEO_COUNT >= 1)
                            ||( UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_SCART && stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_ScartRGB)
                    #endif
                        )
                    {
                        MApi_XC_ADC_AdjustGainOffset(&stGenSettingExt.g_AdcSetting[stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE].stAdcGainOffsetSetting);
                    }


				MApp_ZUI_API_InvalidateAllSuccessors(HWND_FACTORY_MENU_CUS_LIST_ITEM18_NAME_2);
			 	return TRUE;
			}
		else	if(MApp_ZUI_API_GetFocus() == HWND_FACTORY_MENU_CUS_LIST_ITEM18_NAME_3)
			{     //from case MAPP_UIMENUFUNC_ADJUSTADC_BLUEOFFSET:

                    stGenSettingExt.g_AdcSetting[stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE].stAdcGainOffsetSetting.u16BlueOffset =
                        (EN_FACTORY_ADC_ADJUST_MODE)MApp_ZUI_ACT_DecIncValue_Cycle(act==EN_EXE_FACTORY_MENU_ADJ_INC, (U16)stGenSettingExt.g_AdcSetting[stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE].stAdcGainOffsetSetting.u16BlueOffset, 0, MApi_XC_ADC_GetMaximalOffsetValue(), 1);

                    MApp_SaveADCSetting((E_ADC_SET_INDEX)stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE);
                    //if(DATA_INPUT_SOURCE_TYPE == stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE)
                    if( ( UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_RGB && stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_RGB )
                    #if (INPUT_YPBPR_VIDEO_COUNT >= 1)
                            ||( UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_COMPONENT && stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_Ypbpr_SD )
                            ||( UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_COMPONENT && stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_Ypbpr_HD )
                    #endif
                    #if (INPUT_SCART_VIDEO_COUNT >= 1)
                            ||( UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_SCART && stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_ScartRGB)
                    #endif
                        )
                    {
                        MApi_XC_ADC_AdjustGainOffset(&stGenSettingExt.g_AdcSetting[stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE].stAdcGainOffsetSetting);
                    }


				MApp_ZUI_API_InvalidateAllSuccessors(HWND_FACTORY_MENU_CUS_LIST_ITEM18_NAME_3);
			 	return TRUE;
			}
//////////W/B//////////////////////////////////////////////////////////////////////////////////////////////
		else if(MApp_ZUI_API_GetFocus() == HWND_FACTORY_MENU_CUS_LIST_ITEM21_NAME_1)
			{
				           ST_COLOR_TEMP.cRedColor =(U8) MApp_ZUI_ACT_DecIncValue_Cycle(act==EN_EXE_FACTORY_MENU_ADJ_INC, (U16)ST_COLOR_TEMP.cRedColor, 0, 0xFF, 1);
                    #if ENABLE_NEW_COLORTEMP_METHOD
                        #if ENABLE_PRECISE_RGBBRIGHTNESS
                            MApi_XC_ACE_PicSetColorTemp(MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), (XC_ACE_color_temp_ex *) &ST_COLOR_TEMP);
                        #else
                            MApi_XC_ACE_PicSetColorTemp(MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), (XC_ACE_color_temp *) &ST_COLOR_TEMP);
                        #endif
                    #else
                        #if ENABLE_PRECISE_RGBBRIGHTNESS
                            MApi_XC_ACE_PicSetColorTemp( MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), (XC_ACE_color_temp_ex *) &ST_COLOR_TEMP );
                            MApi_XC_ACE_PicSetBrightnessPreciseInVsync(MAIN_WINDOW, MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cRedOffset, BRIGHTNESS_R ), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cGreenOffset, BRIGHTNESS_G), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cBlueOffset, BRIGHTNESS_B));
                        #else
                            MApi_XC_ACE_PicSetColorTemp( MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), (XC_ACE_color_temp *) &ST_COLOR_TEMP );
                            MApi_XC_ACE_PicSetBrightnessInVsync(MAIN_WINDOW, MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cRedOffset, BRIGHTNESS_R ), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cGreenOffset, BRIGHTNESS_G), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cBlueOffset, BRIGHTNESS_B));
                        #endif
                    #endif

                    MApp_SaveWhiteBalanceSetting(DATA_INPUT_SOURCE_TYPE(MAIN_WINDOW));

				MApp_ZUI_API_InvalidateAllSuccessors(HWND_FACTORY_MENU_CUS_LIST_ITEM21_NAME_1);
			 	return TRUE;
			}
		else	if(MApp_ZUI_API_GetFocus() == HWND_FACTORY_MENU_CUS_LIST_ITEM21_NAME_2)
			{
				  ST_COLOR_TEMP.cGreenColor = (U8)MApp_ZUI_ACT_DecIncValue_Cycle(act==EN_EXE_FACTORY_MENU_ADJ_INC,(U16) ST_COLOR_TEMP.cGreenColor, 0, 0xFF, 1);

                  {
                    #if ENABLE_NEW_COLORTEMP_METHOD
                        #if ENABLE_PRECISE_RGBBRIGHTNESS
                            MApi_XC_ACE_PicSetColorTemp(MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), (XC_ACE_color_temp_ex *) &ST_COLOR_TEMP);
                        #else
                            MApi_XC_ACE_PicSetColorTemp(MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), (XC_ACE_color_temp *) &ST_COLOR_TEMP);
                        #endif
                    #else
                        #if ENABLE_PRECISE_RGBBRIGHTNESS
                            MApi_XC_ACE_PicSetColorTemp( MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), (XC_ACE_color_temp_ex *) &ST_COLOR_TEMP );
                            MApi_XC_ACE_PicSetBrightnessPreciseInVsync(MAIN_WINDOW, MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cRedOffset, BRIGHTNESS_R ), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cGreenOffset, BRIGHTNESS_G), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cBlueOffset, BRIGHTNESS_B));
                        #else
                            MApi_XC_ACE_PicSetColorTemp( MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), (XC_ACE_color_temp *) &ST_COLOR_TEMP );
                            MApi_XC_ACE_PicSetBrightnessInVsync(MAIN_WINDOW, MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cRedOffset, BRIGHTNESS_R ), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cGreenOffset, BRIGHTNESS_G), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cBlueOffset, BRIGHTNESS_B));
                        #endif
                    #endif
                    }
                    MApp_SaveWhiteBalanceSetting(DATA_INPUT_SOURCE_TYPE(MAIN_WINDOW));
				MApp_ZUI_API_InvalidateAllSuccessors(HWND_FACTORY_MENU_CUS_LIST_ITEM21_NAME_2);
			 	return TRUE;
			}
		else	if(MApp_ZUI_API_GetFocus() == HWND_FACTORY_MENU_CUS_LIST_ITEM21_NAME_3)
			{
 			ST_COLOR_TEMP.cBlueColor = (U8)MApp_ZUI_ACT_DecIncValue_Cycle(act==EN_EXE_FACTORY_MENU_ADJ_INC, (U16)ST_COLOR_TEMP.cBlueColor, 0, 0xFF, 1);
                    {
                    #if ENABLE_NEW_COLORTEMP_METHOD
                        #if ENABLE_PRECISE_RGBBRIGHTNESS
                            MApi_XC_ACE_PicSetColorTemp(MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), (XC_ACE_color_temp_ex *) &ST_COLOR_TEMP);
                        #else
                            MApi_XC_ACE_PicSetColorTemp(MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), (XC_ACE_color_temp *) &ST_COLOR_TEMP);
                        #endif
                    #else
                        #if ENABLE_PRECISE_RGBBRIGHTNESS
                            MApi_XC_ACE_PicSetColorTemp( MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), (XC_ACE_color_temp_ex *) &ST_COLOR_TEMP );
                            MApi_XC_ACE_PicSetBrightnessPreciseInVsync(MAIN_WINDOW, MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cRedOffset, BRIGHTNESS_R ), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cGreenOffset, BRIGHTNESS_G), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cBlueOffset, BRIGHTNESS_B));
                        #else
                            MApi_XC_ACE_PicSetColorTemp( MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), (XC_ACE_color_temp *) &ST_COLOR_TEMP );
                            MApi_XC_ACE_PicSetBrightnessInVsync(MAIN_WINDOW, MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cRedOffset, BRIGHTNESS_R ), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cGreenOffset, BRIGHTNESS_G), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cBlueOffset, BRIGHTNESS_B));
                        #endif
                    #endif
                    }
                    MApp_SaveWhiteBalanceSetting(DATA_INPUT_SOURCE_TYPE(MAIN_WINDOW));
				MApp_ZUI_API_InvalidateAllSuccessors(HWND_FACTORY_MENU_CUS_LIST_ITEM21_NAME_3);
			 	return TRUE;
			}
		else	if(MApp_ZUI_API_GetFocus() == HWND_FACTORY_MENU_CUS_LIST_ITEM22_NAME_1)
			{
				   ST_COLOR_TEMP.cRedOffset = MApp_ZUI_ACT_DecIncValue_Cycle(act==EN_EXE_FACTORY_MENU_ADJ_INC, ST_COLOR_TEMP.cRedOffset, 0, 0x7FF, 1);
                    {
                    #if ENABLE_NEW_COLORTEMP_METHOD
                        #if ENABLE_PRECISE_RGBBRIGHTNESS
                            MApi_XC_ACE_PicSetColorTemp(MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), (XC_ACE_color_temp_ex *) &ST_COLOR_TEMP);
                        #else
                            MApi_XC_ACE_PicSetColorTemp(MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), (XC_ACE_color_temp *) &ST_COLOR_TEMP);
                        #endif
                    #else
                        #if ENABLE_PRECISE_RGBBRIGHTNESS
                            MApi_XC_ACE_PicSetColorTemp( MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), (XC_ACE_color_temp_ex *) &ST_COLOR_TEMP );
                            MApi_XC_ACE_PicSetBrightnessPreciseInVsync(MAIN_WINDOW, MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cRedOffset, BRIGHTNESS_R ), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cGreenOffset, BRIGHTNESS_G), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cBlueOffset, BRIGHTNESS_B));
                        #else
                            MApi_XC_ACE_PicSetColorTemp( MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), (XC_ACE_color_temp *) &ST_COLOR_TEMP );
                            MApi_XC_ACE_PicSetBrightnessInVsync(MAIN_WINDOW, MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cRedOffset, BRIGHTNESS_R ), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cGreenOffset, BRIGHTNESS_G), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cBlueOffset, BRIGHTNESS_B));
                        #endif
                    #endif
                    }
                    	MApp_SaveWhiteBalanceSetting(DATA_INPUT_SOURCE_TYPE(MAIN_WINDOW));
				MApp_ZUI_API_InvalidateAllSuccessors(HWND_FACTORY_MENU_CUS_LIST_ITEM22_NAME_1);
			 	return TRUE;
			}
		else	if(MApp_ZUI_API_GetFocus() == HWND_FACTORY_MENU_CUS_LIST_ITEM22_NAME_2)
			{
			 //from case MAPP_UIMENUFUNC_WB_ADJUST_GREENOFFSET:
                    ST_COLOR_TEMP.cGreenOffset = MApp_ZUI_ACT_DecIncValue_Cycle(act==EN_EXE_FACTORY_MENU_ADJ_INC, ST_COLOR_TEMP.cGreenOffset, 0, 0x7FF, 1);
                    {
                    #if ENABLE_NEW_COLORTEMP_METHOD
                        #if ENABLE_PRECISE_RGBBRIGHTNESS
                            MApi_XC_ACE_PicSetColorTemp(MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), (XC_ACE_color_temp_ex *) &ST_COLOR_TEMP);
                        #else
                            MApi_XC_ACE_PicSetColorTemp(MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), (XC_ACE_color_temp *) &ST_COLOR_TEMP);
                        #endif
                    #else
                        #if ENABLE_PRECISE_RGBBRIGHTNESS
                            MApi_XC_ACE_PicSetColorTemp( MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), (XC_ACE_color_temp_ex *) &ST_COLOR_TEMP );
                            MApi_XC_ACE_PicSetBrightnessPreciseInVsync(MAIN_WINDOW, MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cRedOffset, BRIGHTNESS_R ), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cGreenOffset, BRIGHTNESS_G), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cBlueOffset, BRIGHTNESS_B));
                        #else
                            MApi_XC_ACE_PicSetColorTemp( MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), (XC_ACE_color_temp *) &ST_COLOR_TEMP );
                            MApi_XC_ACE_PicSetBrightnessInVsync(MAIN_WINDOW, MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cRedOffset, BRIGHTNESS_R ), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cGreenOffset, BRIGHTNESS_G), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cBlueOffset, BRIGHTNESS_B));
                        #endif
                    #endif
                    }
                    MApp_SaveWhiteBalanceSetting(DATA_INPUT_SOURCE_TYPE(MAIN_WINDOW));

				MApp_ZUI_API_InvalidateAllSuccessors(HWND_FACTORY_MENU_CUS_LIST_ITEM22_NAME_2);
			 	return TRUE;
			}
		else	if(MApp_ZUI_API_GetFocus() == HWND_FACTORY_MENU_CUS_LIST_ITEM22_NAME_3)
			{
   			//from case MAPP_UIMENUFUNC_WB_ADJUST_BLUEOFFSET:
                    ST_COLOR_TEMP.cBlueOffset = MApp_ZUI_ACT_DecIncValue_Cycle(act==EN_EXE_FACTORY_MENU_ADJ_INC, ST_COLOR_TEMP.cBlueOffset, 0, 0x7FF, 1);
                    {
                    #if ENABLE_NEW_COLORTEMP_METHOD
                        #if ENABLE_PRECISE_RGBBRIGHTNESS
                            MApi_XC_ACE_PicSetColorTemp(MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), (XC_ACE_color_temp_ex *) &ST_COLOR_TEMP);
                        #else
                            MApi_XC_ACE_PicSetColorTemp(MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), (XC_ACE_color_temp *) &ST_COLOR_TEMP);
                        #endif
                    #else
                        #if ENABLE_PRECISE_RGBBRIGHTNESS
                            MApi_XC_ACE_PicSetColorTemp( MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), (XC_ACE_color_temp_ex *) &ST_COLOR_TEMP );
                            MApi_XC_ACE_PicSetBrightnessPreciseInVsync(MAIN_WINDOW, MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cRedOffset, BRIGHTNESS_R ), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cGreenOffset, BRIGHTNESS_G), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cBlueOffset, BRIGHTNESS_B));
                        #else
                            MApi_XC_ACE_PicSetColorTemp( MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), (XC_ACE_color_temp *) &ST_COLOR_TEMP );
                            MApi_XC_ACE_PicSetBrightnessInVsync(MAIN_WINDOW, MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cRedOffset, BRIGHTNESS_R ), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cGreenOffset, BRIGHTNESS_G), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cBlueOffset, BRIGHTNESS_B));
                        #endif
                    #endif
                    }
                    MApp_SaveWhiteBalanceSetting(DATA_INPUT_SOURCE_TYPE(MAIN_WINDOW));
				MApp_ZUI_API_InvalidateAllSuccessors(HWND_FACTORY_MENU_CUS_LIST_ITEM22_NAME_3);
			 	return TRUE;
			}

	}//
	else
		{
				 	return TRUE;
		}
 }
	 case EN_EXE_SPECIAL_CASE:
		if(MApp_ZUI_API_GetFocus() == HWND_FACTORY_MENU_CUS_LIST_ITEM17_NAME_1||MApp_ZUI_API_GetFocus() == HWND_FACTORY_MENU_CUS_LIST_ITEM17_NAME_2||MApp_ZUI_API_GetFocus() == HWND_FACTORY_MENU_CUS_LIST_ITEM17_NAME_3)
			{
			MApp_ZUI_API_SetFocus(HWND_FACTORY_MENU_CUS_LIST_ITEM17_NAME);
			}
		else if(MApp_ZUI_API_GetFocus() == HWND_FACTORY_MENU_CUS_LIST_ITEM18_NAME_1||MApp_ZUI_API_GetFocus() == HWND_FACTORY_MENU_CUS_LIST_ITEM18_NAME_2||MApp_ZUI_API_GetFocus() == HWND_FACTORY_MENU_CUS_LIST_ITEM18_NAME_3)
			{
			MApp_ZUI_API_SetFocus(HWND_FACTORY_MENU_CUS_LIST_ITEM18_NAME);
			}
		else if(MApp_ZUI_API_GetFocus() == HWND_FACTORY_MENU_CUS_LIST_ITEM21_NAME_1||MApp_ZUI_API_GetFocus() == HWND_FACTORY_MENU_CUS_LIST_ITEM21_NAME_2||MApp_ZUI_API_GetFocus() == HWND_FACTORY_MENU_CUS_LIST_ITEM21_NAME_3)
			{
			MApp_ZUI_API_SetFocus(HWND_FACTORY_MENU_CUS_LIST_ITEM21_NAME);
			}
		else if(MApp_ZUI_API_GetFocus() == HWND_FACTORY_MENU_CUS_LIST_ITEM22_NAME_1||MApp_ZUI_API_GetFocus() == HWND_FACTORY_MENU_CUS_LIST_ITEM22_NAME_2||MApp_ZUI_API_GetFocus() == HWND_FACTORY_MENU_CUS_LIST_ITEM22_NAME_3)
			{
			MApp_ZUI_API_SetFocus(HWND_FACTORY_MENU_CUS_LIST_ITEM22_NAME);
			}
#if CUS_SMC_ENABLE_HOTEL_MODE
         //cus_xm zhihe add for  usb clone 20120820
		else if(MApp_ZUI_API_GetFocus() ==HWND_HOTEL_MENU_ITEM_USB_CLONE)
			{
			   if(stGenSetting.g_FactorySetting.HotelMenuUSBCloneMode != HotelMenuUsbCloneModeOFF)
			   	{
                    MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_CLONE_CONFIRM_WAITTING,SW_SHOW);
					MApp_ZUI_API_SetTimer(HWND_HOTEL_MENU_CLONE_CONFIRM_WAITTING,1,1000);
					stGenSetting.g_FactorySetting.HotelMenuUSBCloneUsedFlag=FALSE;

			   	}
			}
		//cus_xm zhihe add for  usb clone 20120820
		else if(MApp_ZUI_API_GetFocus() ==HWND_HOTEL_MENU_ITEM_PW_CHANGE)
			{
			MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_CHANGE_PW,SW_SHOW);
			MApp_ZUI_API_SetTimer(HWND_HOTEL_MENU_CHANGE_PW,1,5000);
            MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_NEW_PW,DISABLE);
            MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_CHECK_NEW_PW,DISABLE);
			MApp_ZUI_API_SetFocus(HWND_HOTEL_MENU_OLD_PW);
			}
		else if(MApp_ZUI_API_GetFocus()==HWND_HOTEL_MENU_ITEM_CAPTURE_LOGO)
			{
              u8Capturelogo=10;
			  MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_CLONE_CONFIRM_WAITTING,SW_SHOW);
			  MApp_ZUI_API_SetTimer(HWND_HOTEL_MENU_CLONE_CONFIRM_WAITTING,1,5000);
		    }
#endif
		else{
			    ;
			}

			return TRUE;

	//add for hotel menu,chuxu.su2012-07-26
#if CUS_SMC_ENABLE_HOTEL_MODE
	//cus_xm zhihe add for	usb clone 20120820
    case EN_EXE_HOTEL_USB_CLONE:
		{
			if((stGenSetting.g_FactorySetting.HotelMenuUSBCloneMode == HotelMenuUsbCloneModeUSBTOTV)
				&&(stGenSetting.g_FactorySetting.HotelMenuUSBCloneUsedFlag==FALSE))
				{
				    MApp_RestoreDatabase();
					if(USBDeviceDetectFlag == FALSE)
						{
							MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_CLONE_ERROR_MSGBOX,SW_SHOW);//add for hotel mode's usb clone @chuxu
						}
					else
						{
							MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_CLONE_CONFIRM_COMPLETE,SW_SHOW);
						}
					//printf("USBDeviceDetectFlag111 = %d\n",USBDeviceDetectFlag);
					//MApp_ZUI_API_SetTimer(HWND_HOTEL_MENU_CLONE_CONFIRM_COMPLETE,1,2000);
					//printf("usbclone is complete\n");
					stGenSetting.g_FactorySetting.HotelMenuUSBCloneUsedFlag=TRUE;
				}
			else if((stGenSetting.g_FactorySetting.HotelMenuUSBCloneMode == HotelMenuUsbCloneModeTVTOUSB)
				   &&(stGenSetting.g_FactorySetting.HotelMenuUSBCloneUsedFlag==FALSE))
				{
				    MApp_BackupDatabase();
					if(USBDeviceDetectFlag == FALSE)
						{
							MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_CLONE_ERROR_MSGBOX,SW_SHOW);//add for hotel mode's usb clone @chuxu
						}
					else
						{
							MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_CLONE_CONFIRM_COMPLETE,SW_SHOW);
						}
					//printf("USBDeviceDetectFlag222 = %d\n",USBDeviceDetectFlag);
					//MApp_ZUI_API_SetTimer(HWND_HOTEL_MENU_CLONE_CONFIRM_COMPLETE,1,2000);
					//printf("usbclone is complete\n");
					stGenSetting.g_FactorySetting.HotelMenuUSBCloneUsedFlag=TRUE;
				}

		}
		break;
	//cus_xm zhihe add for  usb clone 20120820
	case EN_EXE_HOTEL_MENU_UP:
		{
			#if CUS_SMC_ENABLE_HOTEL_MODE
				if(stGenSetting.g_FactorySetting.HotelMenuHotelModeOperationEnable == ENABLE)//action switch
					{

                    //stGenSetting.g_FactorySetting.HotelMenuVerticalSliderBarSetting=MApp_ZUI_ACT_DecIncValue_Cycle(FALSE,stGenSetting.g_FactorySetting.HotelMenuVerticalSliderBarSetting, 0, 120, 10);
                    //MApp_ZUI_API_InvalidateAllSuccessors(HWND_HOTEL_MENU_ITEM_PAGE);

						hwnd = MApp_ZUI_API_GetFocus();
						if(hwnd == HWND_HOTEL_MENU_ITEM_HOTEL_MODE_OPERATION)//item1
							{
							#if 1
								MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BG_TRANSPARENT, SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM, SW_HIDE);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM2, SW_SHOW);
								MApp_ZUI_API_SetFocus(HWND_HOTEL_MENU_ITEM_PW_CHANGE);
								stGenSetting.g_FactorySetting.HotelMenuVerticalSliderBarSetting=120;
							#else
								MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BG_TRANSPARENT, SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM, SW_HIDE);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM2, SW_SHOW);
								MApp_ZUI_API_SetFocus(HWND_HOTEL_MENU_ITEM_POWER_ON);
							#endif
							}
						else if(hwnd == HWND_HOTEL_MENU_ITEM_CAPTURE_LOGO)//item1
							{
	#if 0
								MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BG_TRANSPARENT, SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM, SW_HIDE);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM2, SW_SHOW);
								MApp_ZUI_API_SetFocus(HWND_HOTEL_MENU_ITEM_CAPTURE_LOGO);
	#else
	#if HOHEL_ENABLE_POWER_ON_OPTION
								MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BG_TRANSPARENT, SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM, SW_HIDE);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM2, SW_SHOW);
								MApp_ZUI_API_SetFocus(HWND_HOTEL_MENU_ITEM_POWER_ON);
	#else
								MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BG_TRANSPARENT, SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM, SW_HIDE);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM2, SW_SHOW);
								MApp_ZUI_API_SetFocus(HWND_HOTEL_MENU_ITEM_INSTALLATION);
								stGenSetting.g_FactorySetting.HotelMenuVerticalSliderBarSetting=90;
	#endif
	#endif
							}
						else if(hwnd == HWND_HOTEL_MENU_ITEM_PW_CHANGE)//item1
							{
#if 0
								MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BG_TRANSPARENT, SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM, SW_HIDE);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM2, SW_SHOW);
								MApp_ZUI_API_SetFocus(HWND_HOTEL_MENU_ITEM_CAPTURE_LOGO);
#else
								MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BG_TRANSPARENT, SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM, SW_HIDE);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM2, SW_SHOW);
								MApp_ZUI_API_SetFocus(HWND_HOTEL_MENU_ITEM_DEFAULT_LANGUAGE);
								stGenSetting.g_FactorySetting.HotelMenuVerticalSliderBarSetting=110;
#endif
							}
						else if(hwnd == HWND_HOTEL_MENU_ITEM_DEFAULT_LANGUAGE)//item1
							{
#if 0
								MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BG_TRANSPARENT, SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM, SW_HIDE);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM2, SW_SHOW);
								MApp_ZUI_API_SetFocus(HWND_HOTEL_MENU_ITEM_CAPTURE_LOGO);
#else
								MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BG_TRANSPARENT, SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM, SW_HIDE);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM2, SW_SHOW);
								MApp_ZUI_API_SetFocus(HWND_HOTEL_MENU_ITEM_CAPTURE_LOGO);
								stGenSetting.g_FactorySetting.HotelMenuVerticalSliderBarSetting=100;
#endif
							}
						/*
						else if(hwnd == HWND_HOTEL_MENU_ITEM_POWERON_LOGO)//item1
							{
#if 0
								MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BG_TRANSPARENT, SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM, SW_HIDE);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM2, SW_SHOW);
								MApp_ZUI_API_SetFocus(HWND_HOTEL_MENU_ITEM_CAPTURE_LOGO);
#else
								MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BG_TRANSPARENT, SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM, SW_HIDE);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM2, SW_SHOW);
								MApp_ZUI_API_SetFocus(HWND_HOTEL_MENU_ITEM_CAPTURE_LOGO);
#endif
							}
							*/
						else if(hwnd == HWND_HOTEL_MENU_ITEM_MAX_VOLUME_SETTING)//item2
							{
								MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BG_TRANSPARENT, SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM, SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM2, SW_HIDE);
								MApp_ZUI_API_SetFocus(HWND_HOTEL_MENU_ITEM_HOTEL_MODE_OPERATION);
								stGenSetting.g_FactorySetting.HotelMenuVerticalSliderBarSetting=0;
							}
						else if(hwnd == HWND_HOTEL_MENU_ITEM_VOLUME_DEFAULT)//item3
							{
								MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BG_TRANSPARENT, SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM, SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM2, SW_HIDE);
								MApp_ZUI_API_SetFocus(HWND_HOTEL_MENU_ITEM_MAX_VOLUME_SETTING);
								stGenSetting.g_FactorySetting.HotelMenuVerticalSliderBarSetting=10;
							}
						else if(hwnd == HWND_HOTEL_MENU_ITEM_OSD_DISPLAY)//item4
							{
								MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BG_TRANSPARENT, SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM, SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM2, SW_HIDE);
								MApp_ZUI_API_SetFocus(HWND_HOTEL_MENU_ITEM_VOLUME_DEFAULT);
								stGenSetting.g_FactorySetting.HotelMenuVerticalSliderBarSetting=20;
							}
						else if(hwnd == HWND_HOTEL_MENU_ITEM_LOCAL_KEY_LOCK)//item5
							{
								MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BG_TRANSPARENT, SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM, SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM2, SW_HIDE);
								MApp_ZUI_API_SetFocus(HWND_HOTEL_MENU_ITEM_OSD_DISPLAY);
								stGenSetting.g_FactorySetting.HotelMenuVerticalSliderBarSetting=30;
							}
						else if(hwnd == HWND_HOTEL_MENU_ITEM_REMOTE_CONTROL_LOCK)//item6
							{
								MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BG_TRANSPARENT, SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM, SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM2, SW_HIDE);
								MApp_ZUI_API_SetFocus(HWND_HOTEL_MENU_ITEM_LOCAL_KEY_LOCK);
								stGenSetting.g_FactorySetting.HotelMenuVerticalSliderBarSetting=40;
							}
						else if(hwnd == HWND_HOTEL_MENU_ITEM_CHANNEL_DEFAULT)//item7
							{
								MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BG_TRANSPARENT, SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM, SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM2, SW_HIDE);
								MApp_ZUI_API_SetFocus(HWND_HOTEL_MENU_ITEM_REMOTE_CONTROL_LOCK);
								stGenSetting.g_FactorySetting.HotelMenuVerticalSliderBarSetting=50;
							}
						else if(hwnd == HWND_HOTEL_MENU_ITEM_INPUT_SOURCE_CHANGE)//item8
							{
								MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BG_TRANSPARENT, SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM, SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM2, SW_HIDE);
								MApp_ZUI_API_SetFocus(HWND_HOTEL_MENU_ITEM_CHANNEL_DEFAULT);
								stGenSetting.g_FactorySetting.HotelMenuVerticalSliderBarSetting=60;
							}
						else if(hwnd == HWND_HOTEL_MENU_ITEM_USB_CLONE)//item9
							{

								MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BG_TRANSPARENT, SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_CLONE_CONFIRM_WAITTING, SW_HIDE);//cus_xm zhihe add for  usb clone 20120820
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_CLONE_CONFIRM_COMPLETE, SW_HIDE);//cus_xm zhihe add for  usb clone 20120820
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_CLONE_ERROR_MSGBOX,SW_HIDE);//add for hotel mode's usb clone @chuxu
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM, SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM2, SW_HIDE);
								MApp_ZUI_API_SetFocus(HWND_HOTEL_MENU_ITEM_INPUT_SOURCE_CHANGE);
								stGenSetting.g_FactorySetting.HotelMenuVerticalSliderBarSetting=70;
							}
				#if 0//HOHEL_ENABLE_AQPQ_OPTION || HOHEL_ENABLE_SOURCE_KEY_OPTION || HOHEL_ENABLE_POWER_ON_OPTION
						else if(hwnd == HWND_HOTEL_MENU_ITEM_AQ_PQ_RESTORE)//item10
							{
								MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BG_TRANSPARENT, SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM, SW_HIDE);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM2, SW_SHOW);
								MApp_ZUI_API_SetFocus(HWND_HOTEL_MENU_ITEM_USB_CLONE);
							}
						else if(hwnd == HWND_HOTEL_MENU_ITEM_INSTALLATION)//item11
							{
								MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BG_TRANSPARENT, SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM, SW_HIDE);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM2, SW_SHOW);
								MApp_ZUI_API_SetFocus(HWND_HOTEL_MENU_ITEM_AQ_PQ_RESTORE);
							}
						else if(hwnd == HWND_HOTEL_MENU_ITEM_SOURCE_KEY_LOCK)//item12
							{
								MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BG_TRANSPARENT, SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM, SW_HIDE);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM2, SW_SHOW);
								MApp_ZUI_API_SetFocus(HWND_HOTEL_MENU_ITEM_INSTALLATION);
							}
						else if(hwnd == HWND_HOTEL_MENU_ITEM_POWER_ON)//item13
							{
								MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BG_TRANSPARENT, SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM, SW_HIDE);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM2, SW_SHOW);
								MApp_ZUI_API_SetFocus(HWND_HOTEL_MENU_ITEM_SOURCE_KEY_LOCK);
							}
				#else
				       else if(hwnd == HWND_HOTEL_MENU_ITEM_INSTALLATION)//item11
						   {
							   MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BG_TRANSPARENT, SW_SHOW);
							   MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM, SW_HIDE);
							   MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM2, SW_SHOW);
							   MApp_ZUI_API_SetFocus(HWND_HOTEL_MENU_ITEM_USB_CLONE);
							   stGenSetting.g_FactorySetting.HotelMenuVerticalSliderBarSetting=80;
						   }
				#endif
					}
				else if(stGenSetting.g_FactorySetting.HotelMenuHotelModeOperationEnable == DISABLE)//action switch
					{
						//do not execute any actions
					}
#if !HOHEL_ENABLE_AQPQ_OPTION
					MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM_AQ_PQ_RESTORE, SW_HIDE);
#endif
#if !HOHEL_ENABLE_SOURCE_KEY_OPTION
					MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM_SOURCE_KEY_LOCK, SW_HIDE);
#endif
#if !HOHEL_ENABLE_POWER_ON_OPTION
					MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM_POWER_ON, SW_HIDE);
#endif
			        MApp_ZUI_API_InvalidateAllSuccessors(HWND_HOTEL_MENU_ITEM_PAGE);

			#endif
		}
	break;

	//add for hotel menu,chuxu.su2012-07-26
	case EN_EXE_HOTEL_MENU_DOWN:
		{
			#if CUS_SMC_ENABLE_HOTEL_MODE
				if(stGenSetting.g_FactorySetting.HotelMenuHotelModeOperationEnable == ENABLE)//action switch
					{

                    //stGenSetting.g_FactorySetting.HotelMenuVerticalSliderBarSetting=MApp_ZUI_ACT_DecIncValue_Cycle(TRUE,stGenSetting.g_FactorySetting.HotelMenuVerticalSliderBarSetting, 0, 120, 10);
                    //MApp_ZUI_API_InvalidateAllSuccessors(HWND_HOTEL_MENU_ITEM_PAGE);


						hwnd = MApp_ZUI_API_GetFocus();
						if(hwnd == HWND_HOTEL_MENU_ITEM_HOTEL_MODE_OPERATION)//item1
							{
								MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BG_TRANSPARENT, SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM, SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM2, SW_HIDE);
								MApp_ZUI_API_SetFocus(HWND_HOTEL_MENU_ITEM_MAX_VOLUME_SETTING);
								stGenSetting.g_FactorySetting.HotelMenuVerticalSliderBarSetting=10;
							}
						else if(hwnd == HWND_HOTEL_MENU_ITEM_MAX_VOLUME_SETTING)//item2
							{
								MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BG_TRANSPARENT, SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM, SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM2, SW_HIDE);
								MApp_ZUI_API_SetFocus(HWND_HOTEL_MENU_ITEM_VOLUME_DEFAULT);
								stGenSetting.g_FactorySetting.HotelMenuVerticalSliderBarSetting=20;
							}
						else if(hwnd == HWND_HOTEL_MENU_ITEM_VOLUME_DEFAULT)//item3
							{
								MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BG_TRANSPARENT, SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM, SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM2, SW_HIDE);
								MApp_ZUI_API_SetFocus(HWND_HOTEL_MENU_ITEM_OSD_DISPLAY);
								stGenSetting.g_FactorySetting.HotelMenuVerticalSliderBarSetting=30;
							}
						else if(hwnd == HWND_HOTEL_MENU_ITEM_OSD_DISPLAY)//item4
							{
								MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BG_TRANSPARENT, SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM, SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM2, SW_HIDE);
								MApp_ZUI_API_SetFocus(HWND_HOTEL_MENU_ITEM_LOCAL_KEY_LOCK);
								stGenSetting.g_FactorySetting.HotelMenuVerticalSliderBarSetting=40;
							}
						else if(hwnd == HWND_HOTEL_MENU_ITEM_LOCAL_KEY_LOCK)//item5
							{
								MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BG_TRANSPARENT, SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM, SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM2, SW_HIDE);
								MApp_ZUI_API_SetFocus(HWND_HOTEL_MENU_ITEM_REMOTE_CONTROL_LOCK);
								stGenSetting.g_FactorySetting.HotelMenuVerticalSliderBarSetting=50;
							}
						else if(hwnd == HWND_HOTEL_MENU_ITEM_REMOTE_CONTROL_LOCK)//item6
							{
								MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BG_TRANSPARENT, SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM, SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM2, SW_HIDE);
								MApp_ZUI_API_SetFocus(HWND_HOTEL_MENU_ITEM_CHANNEL_DEFAULT);
								stGenSetting.g_FactorySetting.HotelMenuVerticalSliderBarSetting=60;
							}
						else if(hwnd == HWND_HOTEL_MENU_ITEM_CHANNEL_DEFAULT)//item7
							{
								MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BG_TRANSPARENT, SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM, SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM2, SW_HIDE);
								MApp_ZUI_API_SetFocus(HWND_HOTEL_MENU_ITEM_INPUT_SOURCE_CHANGE);
								stGenSetting.g_FactorySetting.HotelMenuVerticalSliderBarSetting=70;
							}
						else if(hwnd == HWND_HOTEL_MENU_ITEM_INPUT_SOURCE_CHANGE)//item8
							{
								MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BG_TRANSPARENT, SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM, SW_HIDE);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM2, SW_SHOW);
								MApp_ZUI_API_SetFocus(HWND_HOTEL_MENU_ITEM_USB_CLONE);
								stGenSetting.g_FactorySetting.HotelMenuVerticalSliderBarSetting=80;
							}
						else if(hwnd == HWND_HOTEL_MENU_ITEM_USB_CLONE)//item9
							{
								MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BG_TRANSPARENT, SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_CLONE_CONFIRM_WAITTING, SW_HIDE);//cus_xm zhihe add for  usb clone 20120820
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_CLONE_CONFIRM_COMPLETE, SW_HIDE);//cus_xm zhihe add for  usb clone 20120820
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_CLONE_ERROR_MSGBOX,SW_HIDE);//add for hotel mode's usb clone @chuxu
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM, SW_HIDE);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM2, SW_SHOW);
#if 0//HOHEL_ENABLE_AQPQ_OPTION || HOHEL_ENABLE_SOURCE_KEY_OPTION || HOHEL_ENABLE_POWER_ON_OPTION
								MApp_ZUI_API_SetFocus(HWND_HOTEL_MENU_ITEM_AQ_PQ_RESTORE);
#else
								MApp_ZUI_API_SetFocus(HWND_HOTEL_MENU_ITEM_INSTALLATION);
stGenSetting.g_FactorySetting.HotelMenuVerticalSliderBarSetting=90;

#endif
							}
#if 0//HOHEL_ENABLE_AQPQ_OPTION || HOHEL_ENABLE_SOURCE_KEY_OPTION || HOHEL_ENABLE_POWER_ON_OPTION
						else if(hwnd == HWND_HOTEL_MENU_ITEM_AQ_PQ_RESTORE)//item10
							{
								MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BG_TRANSPARENT, SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM, SW_HIDE);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM2, SW_SHOW);
								MApp_ZUI_API_SetFocus(HWND_HOTEL_MENU_ITEM_INSTALLATION);
							}
#endif
						else if(hwnd == HWND_HOTEL_MENU_ITEM_INSTALLATION)//item11
							{
								MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BG_TRANSPARENT, SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM, SW_HIDE);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM2, SW_SHOW);
#if 0//HOHEL_ENABLE_AQPQ_OPTION || HOHEL_ENABLE_SOURCE_KEY_OPTION || HOHEL_ENABLE_POWER_ON_OPTION
								MApp_ZUI_API_SetFocus(HWND_HOTEL_MENU_ITEM_SOURCE_KEY_LOCK);
#else
								MApp_ZUI_API_SetFocus(HWND_HOTEL_MENU_ITEM_CAPTURE_LOGO);
stGenSetting.g_FactorySetting.HotelMenuVerticalSliderBarSetting=100;

#endif
							}
#if 0//HOHEL_ENABLE_AQPQ_OPTION || HOHEL_ENABLE_SOURCE_KEY_OPTION || HOHEL_ENABLE_POWER_ON_OPTION
						else if(hwnd == HWND_HOTEL_MENU_ITEM_SOURCE_KEY_LOCK)//item12
							{
								MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BG_TRANSPARENT, SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM, SW_HIDE);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM2, SW_SHOW);
								MApp_ZUI_API_SetFocus(HWND_HOTEL_MENU_ITEM_POWER_ON);
							}
						else if(hwnd == HWND_HOTEL_MENU_ITEM_POWER_ON)//item13
							{
							#if 1
								MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BG_TRANSPARENT, SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM, SW_HIDE);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM2, SW_SHOW);
								MApp_ZUI_API_SetFocus(HWND_HOTEL_MENU_ITEM_CAPTURE_LOGO);
							#else
								MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BG_TRANSPARENT, SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM, SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM2, SW_HIDE);
								MApp_ZUI_API_SetFocus(HWND_HOTEL_MENU_ITEM_HOTEL_MODE_OPERATION);
							#endif
							}
#endif
/*
						else if(hwnd == HWND_HOTEL_MENU_ITEM_POWERON_LOGO)//item13
							{
#if 0
								MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BG_TRANSPARENT, SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM, SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM2, SW_HIDE);
								MApp_ZUI_API_SetFocus(HWND_HOTEL_MENU_ITEM_CAPTURE_LOGO);
#else
								MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BG_TRANSPARENT, SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM, SW_HIDE);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM2, SW_SHOW);
								MApp_ZUI_API_SetFocus(HWND_HOTEL_MENU_ITEM_DEFAULT_LANGUAGE);
#endif
							}
*/
						else if(hwnd == HWND_HOTEL_MENU_ITEM_CAPTURE_LOGO)//item13
							{
	#if 0
								MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BG_TRANSPARENT, SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM, SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM2, SW_HIDE);
								MApp_ZUI_API_SetFocus(HWND_HOTEL_MENU_ITEM_CAPTURE_LOGO);
	#else
								MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BG_TRANSPARENT, SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM, SW_HIDE);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM2, SW_SHOW);
								MApp_ZUI_API_SetFocus(HWND_HOTEL_MENU_ITEM_DEFAULT_LANGUAGE);
								stGenSetting.g_FactorySetting.HotelMenuVerticalSliderBarSetting=110;
	#endif
							}
						else if(hwnd == HWND_HOTEL_MENU_ITEM_DEFAULT_LANGUAGE)//item13
							{
#if 0
								MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BG_TRANSPARENT, SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM, SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM2, SW_HIDE);
								MApp_ZUI_API_SetFocus(HWND_HOTEL_MENU_ITEM_CAPTURE_LOGO);
#else
								MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BG_TRANSPARENT, SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM, SW_HIDE);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM2, SW_SHOW);
								MApp_ZUI_API_SetFocus(HWND_HOTEL_MENU_ITEM_PW_CHANGE);
								stGenSetting.g_FactorySetting.HotelMenuVerticalSliderBarSetting=120;
#endif
							}
						else if(hwnd == HWND_HOTEL_MENU_ITEM_PW_CHANGE)//item13
							{
#if 0
								MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BG_TRANSPARENT, SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM, SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM2, SW_HIDE);
								MApp_ZUI_API_SetFocus(HWND_HOTEL_MENU_ITEM_CAPTURE_LOGO);
#else
								MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BG_TRANSPARENT, SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM, SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM2, SW_HIDE);
								MApp_ZUI_API_SetFocus(HWND_HOTEL_MENU_ITEM_HOTEL_MODE_OPERATION);
								stGenSetting.g_FactorySetting.HotelMenuVerticalSliderBarSetting=0;
#endif
							}
					}
				else if(stGenSetting.g_FactorySetting.HotelMenuHotelModeOperationEnable == DISABLE)//action switch
					{
						//do not execute any actions
					}
#if !HOHEL_ENABLE_AQPQ_OPTION
					MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM_AQ_PQ_RESTORE, SW_HIDE);
#endif
#if !HOHEL_ENABLE_SOURCE_KEY_OPTION
					MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM_SOURCE_KEY_LOCK, SW_HIDE);
#endif
#if !HOHEL_ENABLE_POWER_ON_OPTION
					MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM_POWER_ON, SW_HIDE);
#endif
			MApp_ZUI_API_InvalidateAllSuccessors(HWND_HOTEL_MENU_ITEM_PAGE);

			#endif
		}
	break;

	//add for hotel menu,chuxu.su2012-07-25
	case EN_EXE_HOTEL_MENU_DEC_VALUE:

	case EN_EXE_HOTEL_MENU_INC_VALUE:
		#if CUS_SMC_ENABLE_HOTEL_MODE
			if(MApp_ZUI_API_GetFocus() == HWND_HOTEL_MENU_ITEM_HOTEL_MODE_OPERATION)///item1 ok
				{
					stGenSetting.g_FactorySetting.HotelMenuHotelModeOperationEnable = MApp_ZUI_ACT_DecIncValue_Cycle(act==EN_EXE_HOTEL_MENU_INC_VALUE, stGenSetting.g_FactorySetting.HotelMenuHotelModeOperationEnable, DISABLE, ENABLE, 1);
					//hotel mode operation setting:DISABLE for enable windows; DISABLE for disable windows @chuxu 2012-08-02
					if(stGenSetting.g_FactorySetting.HotelMenuHotelModeOperationEnable == DISABLE)//action state
						{
						    stGenSetting.g_FactorySetting.HotelCaptureLogo=FALSE;
							//stGenSetting.g_SysSetting.UsrLogo=1;
							
							MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_ITEM_HOTEL_MODE_OPERATION,TRUE);
							MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_ITEM_MAX_VOLUME_SETTING,FALSE);
							MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_ITEM_VOLUME_DEFAULT,FALSE);
							MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_ITEM_OSD_DISPLAY,FALSE);
							MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_ITEM_LOCAL_KEY_LOCK,FALSE);
							MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_ITEM_REMOTE_CONTROL_LOCK,FALSE);
							MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_ITEM_CHANNEL_DEFAULT,FALSE);
							MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_ITEM_INPUT_SOURCE_CHANGE,FALSE);
							MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_ITEM_USB_CLONE,FALSE);
						#if HOHEL_ENABLE_AQPQ_OPTION
							MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_ITEM_AQ_PQ_RESTORE,FALSE);
						#endif
							MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_ITEM_INSTALLATION,FALSE);
						#if HOHEL_ENABLE_SOURCE_KEY_OPTION
							MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_ITEM_SOURCE_KEY_LOCK,FALSE);
						#endif
						#if HOHEL_ENABLE_POWER_ON_OPTION
							MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_ITEM_POWER_ON,FALSE);
						#endif
							MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_ITEM_CAPTURE_LOGO,FALSE);
							MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_ITEM_POWERON_LOGO,FALSE);
							MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_ITEM_DEFAULT_LANGUAGE,FALSE);
							MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_ITEM_PW_CHANGE,FALSE);
						}
					else if(stGenSetting.g_FactorySetting.HotelMenuHotelModeOperationEnable == ENABLE)//action state
						{
						    //if(stGenSetting.g_SysSetting.u8UsrLogoCnt)
							//	stGenSetting.g_SysSetting.UsrLogo=2;
							//else
							//	stGenSetting.g_SysSetting.UsrLogo=1;
							
							MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_ITEM_HOTEL_MODE_OPERATION,TRUE);
							MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_ITEM_MAX_VOLUME_SETTING,TRUE);
							MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_ITEM_VOLUME_DEFAULT,TRUE);
							MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_ITEM_OSD_DISPLAY,TRUE);
							MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_ITEM_LOCAL_KEY_LOCK,TRUE);
							MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_ITEM_REMOTE_CONTROL_LOCK,TRUE);
							MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_ITEM_CHANNEL_DEFAULT,TRUE);
							MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_ITEM_INPUT_SOURCE_CHANGE,TRUE);
							MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_ITEM_USB_CLONE,TRUE);
					#if HOHEL_ENABLE_AQPQ_OPTION
							MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_ITEM_AQ_PQ_RESTORE,TRUE);
					#endif
							MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_ITEM_INSTALLATION,TRUE);
					#if HOHEL_ENABLE_SOURCE_KEY_OPTION
							MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_ITEM_SOURCE_KEY_LOCK,TRUE);
					#endif
					#if HOHEL_ENABLE_POWER_ON_OPTION
							MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_ITEM_POWER_ON,TRUE);
					#endif
					
					if(MApp_DMP_GetDmpUiState()==DMP_UI_STATE_PLAYING_STAGE && MApp_MPlayer_QueryCurrentMediaType()==E_MPLAYER_TYPE_PHOTO)
							MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_ITEM_CAPTURE_LOGO,TRUE);
					else
						    MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_ITEM_CAPTURE_LOGO,TRUE);
					
							MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_ITEM_POWERON_LOGO,TRUE);
							MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_ITEM_DEFAULT_LANGUAGE,TRUE);
							MApp_ZUI_API_EnableWindow(HWND_HOTEL_MENU_ITEM_PW_CHANGE,TRUE);
						}
					MApp_ZUI_API_InvalidateAllSuccessors(HWND_HOTEL_MENU_ITEM_HOTEL_MODE_OPERATION);
					return TRUE;
				}
			else if(MApp_ZUI_API_GetFocus() == HWND_HOTEL_MENU_ITEM_MAX_VOLUME_SETTING)///item2 ==ok 2012-08-07
				{
					stGenSetting.g_FactorySetting.HotelMenuMaxVolumeSetting = MApp_ZUI_ACT_DecIncValue_Cycle(act==EN_EXE_HOTEL_MENU_INC_VALUE, stGenSetting.g_FactorySetting.HotelMenuMaxVolumeSetting, stGenSetting.g_FactorySetting.HotelMenuVolumeDefault, 100, 1);
					//SMC jayden.chen
					g_u8HotelVolMax = stGenSetting.g_FactorySetting.HotelMenuMaxVolumeSetting;
					MApp_ZUI_API_InvalidateAllSuccessors(HWND_HOTEL_MENU_ITEM_MAX_VOLUME_SETTING);
					return TRUE;
				}
			else if(MApp_ZUI_API_GetFocus() == HWND_HOTEL_MENU_ITEM_VOLUME_DEFAULT)///item3 ==ok  2012-08-08
				{
					stGenSetting.g_FactorySetting.HotelMenuVolumeDefault = MApp_ZUI_ACT_DecIncValue_Cycle(act==EN_EXE_HOTEL_MENU_INC_VALUE, stGenSetting.g_FactorySetting.HotelMenuVolumeDefault, 0, stGenSetting.g_FactorySetting.HotelMenuMaxVolumeSetting, 1);
					MApp_ZUI_API_InvalidateAllSuccessors(HWND_HOTEL_MENU_ITEM_VOLUME_DEFAULT);
					return TRUE;
				}
			else if(MApp_ZUI_API_GetFocus() == HWND_HOTEL_MENU_ITEM_OSD_DISPLAY)///item4 ok
				{
					stGenSetting.g_FactorySetting.HotelMenuOSDDisplayEnableBack = MApp_ZUI_ACT_DecIncValue_Cycle(act==EN_EXE_HOTEL_MENU_INC_VALUE, stGenSetting.g_FactorySetting.HotelMenuOSDDisplayEnableBack, DISABLE, ENABLE, 1);
					stGenSetting.g_FactorySetting.HotelMenuOSDDisplayEnable = stGenSetting.g_FactorySetting.HotelMenuOSDDisplayEnableBack;
					MApp_ZUI_API_InvalidateAllSuccessors(HWND_HOTEL_MENU_ITEM_OSD_DISPLAY);
					return TRUE;
				}
			else if(MApp_ZUI_API_GetFocus() == HWND_HOTEL_MENU_ITEM_LOCAL_KEY_LOCK)///item5 ok 2012-08-08
				{
					stGenSetting.g_SysSetting.g_enKeyPadLock = (EN_MENU_E5_KeyLock)MApp_ZUI_ACT_DecIncValue_Cycle(TRUE,(U16)stGenSetting.g_SysSetting.g_enKeyPadLock,EN_E5_KeyLock_Off,(U16)(EN_E5_KeyLock_Num-1),1);
					//stGenSetting.g_FactorySetting.HotelMenuLocalKeyLockEnable = MApp_ZUI_ACT_DecIncValue_Cycle(act==EN_EXE_HOTEL_MENU_INC_VALUE, stGenSetting.g_FactorySetting.HotelMenuLocalKeyLockEnable, DISABLE, ENABLE, 1);
					MApp_ZUI_API_InvalidateAllSuccessors(HWND_HOTEL_MENU_ITEM_LOCAL_KEY_LOCK);
					MApp_ZUI_API_InvalidateWindow(HWND_MENU_LOCK_MAINSUBPAGE_ITEM_KEYBDLOCK_OPTION);//it's very important
					return TRUE;
				}
			else if(MApp_ZUI_API_GetFocus() == HWND_HOTEL_MENU_ITEM_REMOTE_CONTROL_LOCK)///item6 ok
				{
					stGenSetting.g_FactorySetting.HotelMenuRometeControlLockEnableBack = MApp_ZUI_ACT_DecIncValue_Cycle(act==EN_EXE_HOTEL_MENU_INC_VALUE, stGenSetting.g_FactorySetting.HotelMenuRometeControlLockEnableBack, DISABLE, ENABLE, 1);
					stGenSetting.g_FactorySetting.HotelMenuRometeControlLockEnable = stGenSetting.g_FactorySetting.HotelMenuRometeControlLockEnableBack;
					MApp_ZUI_API_InvalidateAllSuccessors(HWND_HOTEL_MENU_ITEM_REMOTE_CONTROL_LOCK);
					return TRUE;
				}
			else if(MApp_ZUI_API_GetFocus() == HWND_HOTEL_MENU_ITEM_CHANNEL_DEFAULT)///item7  ===2012-08-04
				{
					stGenSetting.g_FactorySetting.HotelMenuChannelDefault = MApp_ZUI_ACT_DecIncValue_Cycle(act==EN_EXE_HOTEL_MENU_INC_VALUE, stGenSetting.g_FactorySetting.HotelMenuChannelDefault, 1, 200, 1);
					MApp_ZUI_API_InvalidateAllSuccessors(HWND_HOTEL_MENU_ITEM_CHANNEL_DEFAULT);
					return TRUE;
				}
			//cus_xm zhihe 20120818 modify input source of power on
			else if(MApp_ZUI_API_GetFocus() == HWND_HOTEL_MENU_ITEM_INPUT_SOURCE_CHANGE)///item8 ====2012-08-17
				{
					stGenSetting.g_FactorySetting.HotelMenuInputSourceChange =
	                (E_HOTEL_MODE_INPUT_SOURCE) MApp_ZUI_ACT_DecIncValue_Cycle(act==EN_EXE_HOTEL_MENU_INC_VALUE,stGenSetting.g_FactorySetting.HotelMenuInputSourceChange, HOTEL_MODE_INPUT_SOURCE_MIN, HOTEL_MODE_INPUT_SOURCE_AUTO-1, 1);
					MApp_ZUI_API_InvalidateAllSuccessors(HWND_HOTEL_MENU_ITEM_INPUT_SOURCE_CHANGE);
					return TRUE;
				}
			//cus_xm zhihe 20120818 modify input source of power on
			else if(MApp_ZUI_API_GetFocus() == HWND_HOTEL_MENU_ITEM_USB_CLONE)///item9 ****ok
				{
				    MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_CLONE_CONFIRM_WAITTING, SW_HIDE);//cus_xm zhihe add for  usb clone 20120820
					MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_CLONE_CONFIRM_COMPLETE, SW_HIDE);//cus_xm zhihe add for  usb clone 20120820
					MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_CLONE_ERROR_MSGBOX,SW_HIDE);//add for hotel mode's usb clone @chuxu
					stGenSetting.g_FactorySetting.HotelMenuUSBCloneMode = (HOTEL_MENU_USB_CLONE_MODE) MApp_ZUI_ACT_DecIncValue_Cycle(act==EN_EXE_HOTEL_MENU_INC_VALUE, stGenSetting.g_FactorySetting.HotelMenuUSBCloneMode, HotelMenuUsbCloneModeOFF, HotelMenuUsbCloneModeUSBTOTV, 1);
					MApp_ZUI_API_InvalidateAllSuccessors(HWND_HOTEL_MENU_ITEM_USB_CLONE);
					return TRUE;
				}
			else if(MApp_ZUI_API_GetFocus() == HWND_HOTEL_MENU_ITEM_AQ_PQ_RESTORE)///item10 ok
				{
					stGenSetting.g_FactorySetting.HotelMenuAQPQRestoreEnable = MApp_ZUI_ACT_DecIncValue_Cycle(act==EN_EXE_HOTEL_MENU_INC_VALUE, stGenSetting.g_FactorySetting.HotelMenuAQPQRestoreEnable, DISABLE, ENABLE, 1);
					MApp_ZUI_API_InvalidateAllSuccessors(HWND_HOTEL_MENU_ITEM_AQ_PQ_RESTORE);
					return TRUE;
				}
			else if(MApp_ZUI_API_GetFocus() == HWND_HOTEL_MENU_ITEM_INSTALLATION)///item11 ==ok
				{
					stGenSetting.g_FactorySetting.HotelMenuInstallation = MApp_ZUI_ACT_DecIncValue_Cycle(act==EN_EXE_HOTEL_MENU_INC_VALUE, stGenSetting.g_FactorySetting.HotelMenuInstallation, 0, 1/*3*/, 1);
					MApp_ZUI_API_InvalidateAllSuccessors(HWND_HOTEL_MENU_ITEM_INSTALLATION);
					return TRUE;
				}
			else if(MApp_ZUI_API_GetFocus() == HWND_HOTEL_MENU_ITEM_SOURCE_KEY_LOCK)///item12 ok
				{
					stGenSetting.g_FactorySetting.HotelMenuSourceKeyLockEnable= MApp_ZUI_ACT_DecIncValue_Cycle(act==EN_EXE_HOTEL_MENU_INC_VALUE, stGenSetting.g_FactorySetting.HotelMenuSourceKeyLockEnable, DISABLE, ENABLE, 1);
					MApp_ZUI_API_InvalidateAllSuccessors(HWND_HOTEL_MENU_ITEM_SOURCE_KEY_LOCK);
					return TRUE;
				}
			else if(MApp_ZUI_API_GetFocus() == HWND_HOTEL_MENU_ITEM_POWER_ON)///item13 ****ok
				{
					stGenSetting.g_FactorySetting.u8PowerOnMode = (POWERON_MODE_TYPE)MApp_ZUI_ACT_DecIncValue_Cycle(act==EN_EXE_HOTEL_MENU_INC_VALUE,(U16)stGenSetting.g_FactorySetting.u8PowerOnMode,POWERON_MODE_SAVE,(U16)(POWERON_MODE_NUMS-1),1);
                    MApp_SaveFactorySetting();
					MApp_ZUI_API_InvalidateAllSuccessors(HWND_HOTEL_MENU_ITEM_POWER_ON);
					return TRUE;
				}
			//else if(MApp_ZUI_API_GetFocus() == HWND_HOTEL_MENU_ITEM_CAPTURE_LOGO)///item13 ****ok
			//	{
			//		stGenSetting.g_FactorySetting.HotelCaptureLogo= (POWERON_MODE_TYPE)MApp_ZUI_ACT_DecIncValue_Cycle(act==EN_EXE_HOTEL_MENU_INC_VALUE,(U16)stGenSetting.g_FactorySetting.HotelCaptureLogo,DISABLE,ENABLE,1);
             //       MApp_SaveFactorySetting();
			//		MApp_ZUI_API_InvalidateAllSuccessors(HWND_HOTEL_MENU_ITEM_CAPTURE_LOGO);
			//		return TRUE;
			//	}
			else if(MApp_ZUI_API_GetFocus() == HWND_HOTEL_MENU_ITEM_POWERON_LOGO)///item13 ****ok
				{
#if (ENABLE_DMP)
				 {
					 stGenSetting.g_SysSetting.UsrLogo=
						 MApp_ZUI_ACT_DecIncValue_Cycle(
							 act==EN_EXE_INC_POWER_ON_LOGO,
							 stGenSetting.g_SysSetting.UsrLogo, POWERON_LOGO_OFF, (POWERON_LOGO_DEFAULT + stGenSetting.g_SysSetting.u8UsrLogoCnt), 1);
				 }
#endif
				 MApp_ZUI_API_InvalidateAllSuccessors(HWND_HOTEL_MENU_ITEM_POWERON_LOGO);
					return TRUE;
				}
			else if(MApp_ZUI_API_GetFocus() == HWND_HOTEL_MENU_ITEM_DEFAULT_LANGUAGE)///item8 ====2012-08-17
				{
#if ENABLE_CUS_OSD_LANGUAGE
#if 0
					 if(stGenSetting.g_FactorySetting.HotelMenuLanguage == LANGUAGE_ENGLISH)
					 {
						 stGenSetting.g_FactorySetting.HotelMenuLanguage = LANGUAGE_RUSSIAN;
					 g_bFactoryLanguageBack=LANGUAGE_RUSSIAN;
					 }
					 else if(stGenSetting.g_FactorySetting.HotelMenuLanguage == LANGUAGE_RUSSIAN)
					 {
						 stGenSetting.g_FactorySetting.HotelMenuLanguage = LANGUAGE_GERMAN;
					 g_bFactoryLanguageBack=LANGUAGE_GERMAN;
					 }
					 else if(stGenSetting.g_FactorySetting.HotelMenuLanguage == LANGUAGE_GERMAN)
					 {
						 stGenSetting.g_FactorySetting.HotelMenuLanguage = LANGUAGE_ITALIAN;
					 g_bFactoryLanguageBack=LANGUAGE_ITALIAN;
					 }
					 else if(stGenSetting.g_FactorySetting.HotelMenuLanguage == LANGUAGE_ITALIAN)
					 {
						 stGenSetting.g_FactorySetting.HotelMenuLanguage = LANGUAGE_FRENCH;
					 g_bFactoryLanguageBack=LANGUAGE_FRENCH;
					 }
					 else if(stGenSetting.g_FactorySetting.HotelMenuLanguage == LANGUAGE_FRENCH)
					 {
						 stGenSetting.g_FactorySetting.HotelMenuLanguage = LANGUAGE_CHINESE;
					 g_bFactoryLanguageBack=LANGUAGE_CHINESE;
					 }
					 else
					 {
						 stGenSetting.g_FactorySetting.HotelMenuLanguage = LANGUAGE_ENGLISH;
						 g_bFactoryLanguageBack=LANGUAGE_ENGLISH;
					 }
#endif					 
                   	stGenSetting.g_FactorySetting.HotelMenuLanguage = LANGUAGE_ENGLISH;
				    g_bFactoryLanguageBack=LANGUAGE_ENGLISH;
#else
					 stGenSetting.g_FactorySetting.HotelMenuLanguage =
					 (EN_LANGUAGE) MApp_ZUI_ACT_DecIncValue_Cycle(act==EN_EXE_HOTEL_MENU_INC_VALUE,stGenSetting.g_FactorySetting.HotelMenuLanguage, LANGUAGE_MENU_MIN, LANGUAGE_MENU_MAX, 1);
#endif
					MApp_ZUI_API_InvalidateAllSuccessors(HWND_HOTEL_MENU_ITEM_DEFAULT_LANGUAGE);
					return TRUE;
				}
		#endif
	break;

	//add for hotel menu,chuxu.su2012-07-31
	case EN_EXE_HOTEL_MENU_GOTO_HOTEL_MENU://go back hotel menu
		#if CUS_SMC_ENABLE_HOTEL_MODE
			hwnd = MApp_ZUI_API_GetFocus();
			switch(hwnd)
				{
					case HWND_HOTEL_MENU_VOLUME_SUBPAGE_BAR:
						if(prePictureHWND == HWND_HOTEL_MENU_ITEM_MAX_VOLUME_SETTING)
							{
								MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BG_TRANSPARENT, SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_BACKGROUND, SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM_PAGE, SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM2, SW_HIDE);
	                       		MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_VOLUME_SUBPAGE, SW_HIDE);

								MApp_ZUI_API_SetFocus(HWND_HOTEL_MENU_ITEM_MAX_VOLUME_SETTING);

							}
						else if(prePictureHWND == HWND_HOTEL_MENU_ITEM_VOLUME_DEFAULT)
							{
								MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BG_TRANSPARENT, SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_BACKGROUND, SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM_PAGE, SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM2, SW_HIDE);
	                       		MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_VOLUME_SUBPAGE, SW_HIDE);

								MApp_ZUI_API_SetFocus(HWND_HOTEL_MENU_ITEM_VOLUME_DEFAULT);
							}
					break;
				}
		#endif
	break;

	//add for hotel menu,chuxu.su2012-07-31
	case EN_EXE_HOTEL_MENU_GOTO_VOLUME_SUBPAGE:
		#if CUS_SMC_ENABLE_HOTEL_MODE
			hwnd = MApp_ZUI_API_GetFocus();
			switch(hwnd)
				{
					case HWND_HOTEL_MENU_ITEM_MAX_VOLUME_SETTING:
					case HWND_HOTEL_MENU_ITEM_VOLUME_DEFAULT:
						prePictureHWND = hwnd;
						MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BG_TRANSPARENT, SW_SHOW);
						MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_BACKGROUND, SW_HIDE);
						MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_ITEM_PAGE, SW_HIDE);
                        MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_VOLUME_SUBPAGE, SW_SHOW);

						MApp_ZUI_API_SetFocus(HWND_HOTEL_MENU_VOLUME_SUBPAGE_BAR);
						//MApp_ZUI_API_KillTimer(HWND_MENU_BACKGROUND, 0);
						//MApp_ZUI_API_SetTimer(HWND_HOTEL_MENU_VOLUME_SUBPAGE, 0, PICTURE_SETTING_TIME_OUT_MS);//set time = 20ms
					break;
				}
		#endif
	break;

	//add for hotel menu,chuxu.su2012-07-31
	case EN_EXE_VOLUME_BAR_DEC_VALUE:
	case EN_EXE_VOLUME_BAR_INC_VALUE://increase or decrease volume subpage bar's value
		#if CUS_SMC_ENABLE_HOTEL_MODE
		{
			hwnd = MApp_ZUI_API_GetFocus();
			switch(hwnd)
				{
					case HWND_HOTEL_MENU_VOLUME_SUBPAGE_BAR:
						{
							switch(prePictureHWND)
								{
									case HWND_HOTEL_MENU_ITEM_MAX_VOLUME_SETTING://2012-08-07
										{
											stGenSetting.g_FactorySetting.HotelMenuMaxVolumeSetting = MApp_ZUI_ACT_DecIncValue(act==EN_EXE_VOLUME_BAR_INC_VALUE,stGenSetting.g_FactorySetting.HotelMenuMaxVolumeSetting, stGenSetting.g_FactorySetting.HotelMenuVolumeDefault, 100, 1);
											//SMC jayden.chen
											g_u8HotelVolMax = stGenSetting.g_FactorySetting.HotelMenuMaxVolumeSetting;
											#if 0 //SMC jayen.chen mask
                                            if(stGenSetting.g_FactorySetting.HotelMenuMaxVolumeSetting<=stGenSetting.g_SoundSetting.Volume)
												msAPI_AUD_AdjustAudioFactor(E_ADJUST_VOLUME, stGenSetting.g_FactorySetting.HotelMenuMaxVolumeSetting, 0);//max volume setting synchronize
											#endif 
											MApp_ZUI_API_InvalidateAllSuccessors(HWND_HOTEL_MENU_VOLUME_SUBPAGE_BAR);
											return TRUE;
										}
									break;

									case HWND_HOTEL_MENU_ITEM_VOLUME_DEFAULT://2012-08-08
										{
											stGenSetting.g_FactorySetting.HotelMenuVolumeDefault = MApp_ZUI_ACT_DecIncValue(act==EN_EXE_VOLUME_BAR_INC_VALUE,stGenSetting.g_FactorySetting.HotelMenuVolumeDefault, 0, stGenSetting.g_FactorySetting.HotelMenuMaxVolumeSetting, 1);
											#if 0 //SMC jayen.chen mask
										 	if(stGenSetting.g_FactorySetting.HotelMenuVolumeDefault<=stGenSetting.g_SoundSetting.Volume)
												msAPI_AUD_AdjustAudioFactor(E_ADJUST_VOLUME, stGenSetting.g_FactorySetting.HotelMenuVolumeDefault, 0);//volume default synchronize
										    #endif 
											MApp_ZUI_API_InvalidateAllSuccessors(HWND_HOTEL_MENU_VOLUME_SUBPAGE_BAR);
											return TRUE;
										}
									break;
								}
						}
					break;
				}
		}
		#endif
	break;

#endif

//cus_xm 20120613 gary modify by cus_factory menu ADC/WB function satrt
//cus_xm gary modify by cus_factory menu function satrt
        case EN_EXE_DEC_VALUE:
        case EN_EXE_INC_VALUE:
// cus_xm gary 20120717 modify by refresh factory menu
       	stGenSettingExt.g_AdcSetting[ADC_SET_VGA].u8AdcCalOK = 0xFF;
		stGenSettingExt.g_AdcSetting[ADC_SET_YPBPR_HD].u8AdcCalOK = 0xFF;
 		stGenSettingExt.g_AdcSetting[ADC_SET_YPBPR_SD].u8AdcCalOK = 0xFF;

			if(MApp_ZUI_API_GetFocus() == HWND_FACTORY_MENU_CUS_LIST_ITEM9_NAME)
				{

  			 	 DATA_INPUT_SOURCE_TYPE(MAIN_WINDOW) =
	                    #if(ENABLE_DTV == 0)
	                       (E_DATA_INPUT_SOURCE) MApp_ZUI_ACT_DecIncValue_Cycle(act==EN_EXE_INC_VALUE,(U16) DATA_INPUT_SOURCE_TYPE(MAIN_WINDOW), DATA_INPUT_SOURCE_MIN, DATA_INPUT_SOURCE_NUM-2, 1);
	                    #else
	                       (E_DATA_INPUT_SOURCE) MApp_ZUI_ACT_DecIncValue_Cycle(act==EN_EXE_INC_VALUE,(U16) DATA_INPUT_SOURCE_TYPE(MAIN_WINDOW), DATA_INPUT_SOURCE_MIN, DATA_INPUT_SOURCE_NUM-1, 1);
	                    #endif
	                    _MApp_ZUI_ACT_FactoryMenu_ChangeDataInputSource(DATA_INPUT_SOURCE_TYPE(MAIN_WINDOW));
				MApp_ZUI_API_InvalidateAllSuccessors(HWND_FACTORY_MENU_CUS_LIST_ITEM9_NAME);

				if ( UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_RGB )
    					stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE =EN_FacAdj_AdcMode_RGB;
                       		else if( UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_COMPONENT)
                       			{
                       			if(MApp_IsSrcHasSignal(MAIN_WINDOW) )
                       				{
	                       				if(MApi_XC_Sys_IsSrcHD(MAIN_WINDOW))
									{
										stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE =EN_FacAdj_AdcMode_Ypbpr_HD;
	                       					}
								else
									{
											stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE =EN_FacAdj_AdcMode_Ypbpr_SD;
									}
							}
							else
							{
								stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE =EN_FacAdj_AdcMode_Ypbpr_SD;
							}

                       			}
						else
							stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE =EN_FacAdj_AdcMode_Ypbpr_SD;

			//	if( ( UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_RGB )
                        //    ||( UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_COMPONENT))
				//	{
				//change source refresh adc gain&offset
				MApp_ZUI_API_InvalidateAllSuccessors(HWND_FACTORY_MENU_CUS_LIST_ITEM10_NAME);// cus_xm gary 20120717 modify by refresh factory menu

				MApp_ZUI_API_InvalidateAllSuccessors(HWND_FACTORY_MENU_CUS_LIST_ITEM16_NAME);
				MApp_ZUI_API_InvalidateAllSuccessors(HWND_FACTORY_MENU_CUS_LIST_ITEM17_NAME_1);
				MApp_ZUI_API_InvalidateAllSuccessors(HWND_FACTORY_MENU_CUS_LIST_ITEM17_NAME_2);
				MApp_ZUI_API_InvalidateAllSuccessors(HWND_FACTORY_MENU_CUS_LIST_ITEM17_NAME_3);

				MApp_ZUI_API_InvalidateAllSuccessors(HWND_FACTORY_MENU_CUS_LIST_ITEM18_NAME_1);
				MApp_ZUI_API_InvalidateAllSuccessors(HWND_FACTORY_MENU_CUS_LIST_ITEM18_NAME_2);
				MApp_ZUI_API_InvalidateAllSuccessors(HWND_FACTORY_MENU_CUS_LIST_ITEM18_NAME_3);
			//		}

				MApp_ZUI_API_InvalidateAllSuccessors(HWND_FACTORY_MENU_CUS_LIST_ITEM19_NAME);
				//change colortemp refresh gain&offset
				MApp_ZUI_API_InvalidateAllSuccessors(HWND_FACTORY_MENU_CUS_LIST_ITEM21_NAME_1);
				MApp_ZUI_API_InvalidateAllSuccessors(HWND_FACTORY_MENU_CUS_LIST_ITEM21_NAME_2);
				MApp_ZUI_API_InvalidateAllSuccessors(HWND_FACTORY_MENU_CUS_LIST_ITEM21_NAME_3);

				MApp_ZUI_API_InvalidateAllSuccessors(HWND_FACTORY_MENU_CUS_LIST_ITEM22_NAME_1);
				MApp_ZUI_API_InvalidateAllSuccessors(HWND_FACTORY_MENU_CUS_LIST_ITEM22_NAME_2);
				MApp_ZUI_API_InvalidateAllSuccessors(HWND_FACTORY_MENU_CUS_LIST_ITEM22_NAME_3);
					return TRUE;
			}
//auto color
			else if(MApp_ZUI_API_GetFocus() == HWND_FACTORY_MENU_CUS_LIST_ITEM10_NAME)
				{
				 if(MApp_IsSrcHasSignal(MAIN_WINDOW) )
		                  {
			                  if(IsVgaInUse())
			                        g_ADCCalibrationResult = MApp_RGB_Setting_Auto(E_XC_EXTERNAL_CALIBRATION,MAIN_WINDOW);
			                    else if(IsYPbPrInUse())
			                        g_ADCCalibrationResult = MApp_YPbPr_Setting_Auto(E_XC_EXTERNAL_CALIBRATION,MAIN_WINDOW);
			                #if (INPUT_SCART_VIDEO_COUNT >= 1)
			                    else if(IsScartInUse())
			                        g_ADCCalibrationResult = MApp_SCART_RGB_Setting_Auto(E_XC_EXTERNAL_CALIBRATION,MAIN_WINDOW);
			                #endif
			                    else
			                        g_ADCCalibrationResult = FALSE;
				 	}
				 	else
				 		{
							 g_ADCCalibrationResult = FALSE;
							 stGenSettingExt.g_AdcSetting[ADC_SET_VGA].u8AdcCalOK = 0x00;
							 stGenSettingExt.g_AdcSetting[ADC_SET_YPBPR_HD].u8AdcCalOK = 0x00;
							 stGenSettingExt.g_AdcSetting[ADC_SET_YPBPR_SD].u8AdcCalOK = 0x00;
				 		}
 				MApp_ZUI_API_InvalidateAllSuccessors(HWND_FACTORY_MENU_CUS_LIST_ITEM10_NAME);

			     MApp_ZUI_API_InvalidateAllSuccessors(HWND_FACTORY_MENU_CUS_LIST_ITEM17_NAME_1);
		    	     MApp_ZUI_API_InvalidateAllSuccessors(HWND_FACTORY_MENU_CUS_LIST_ITEM17_NAME_2);
		     	     MApp_ZUI_API_InvalidateAllSuccessors(HWND_FACTORY_MENU_CUS_LIST_ITEM17_NAME_3);

			     MApp_ZUI_API_InvalidateAllSuccessors(HWND_FACTORY_MENU_CUS_LIST_ITEM18_NAME_1);
		    	     MApp_ZUI_API_InvalidateAllSuccessors(HWND_FACTORY_MENU_CUS_LIST_ITEM18_NAME_2);
		     	     MApp_ZUI_API_InvalidateAllSuccessors(HWND_FACTORY_MENU_CUS_LIST_ITEM18_NAME_3);

				return TRUE;
				}
// ssc
			else if(MApp_ZUI_API_GetFocus() == HWND_FACTORY_MENU_CUS_LIST_ITEM13_NAME)
    					{
    				   #if ENABLE_SSC
                        stGenSetting.g_SSCSetting.SscLVDSEnale = MApp_ZUI_ACT_DecIncValue_Cycle(act==EN_EXE_INC_VALUE, stGenSetting.g_SSCSetting.SscLVDSEnale, DISABLE, ENABLE, 1);
                        /* Set LVDS SSC */
                      #if (ENABLE_LVDSTORGB_CONVERTER == ENABLE)
                        g_IPanel.SetSSC( SSC_SPAN_PERIOD, SSC_STEP_PERCENT, DISABLE );
                      #else
                        g_IPanel.SetSSC( stGenSetting.g_SSCSetting.LVDSSscSpanKHzx10,
                                            stGenSetting.g_SSCSetting.LVDSSscStepPercentagex100,
                                            stGenSetting.g_SSCSetting.SscLVDSEnale);
                      #endif
                        MApp_SaveSSCData();
					 #endif
			     MApp_ZUI_API_InvalidateAllSuccessors(HWND_FACTORY_MENU_CUS_LIST_ITEM13_NAME);
					 return TRUE;
					}
			else if(MApp_ZUI_API_GetFocus() == HWND_FACTORY_MENU_CUS_LIST_ITEM14_NAME)
				{
			 #if ENABLE_SSC
                        stGenSetting.g_SSCSetting.LVDSSscSpanKHzx10= MApp_ZUI_ACT_DecIncValue_Cycle( act==EN_EXE_INC_VALUE, stGenSetting.g_SSCSetting.LVDSSscSpanKHzx10, 0, LVDS_SSC_SPAN_MAX, 1);
                        /* Set LVDS SSC */
	                      #if (ENABLE_LVDSTORGB_CONVERTER == ENABLE)
	                        g_IPanel.SetSSC( SSC_SPAN_PERIOD, SSC_STEP_PERCENT, DISABLE );
	                      #else
	                        g_IPanel.SetSSC( stGenSetting.g_SSCSetting.LVDSSscSpanKHzx10,
	                                            stGenSetting.g_SSCSetting.LVDSSscStepPercentagex100,
	                                            stGenSetting.g_SSCSetting.SscLVDSEnale);
	                      #endif
                        MApp_SaveSSCData();
				#endif
    			 MApp_ZUI_API_InvalidateAllSuccessors(HWND_FACTORY_MENU_CUS_LIST_ITEM14_NAME);
				return TRUE;
				}

			else if(MApp_ZUI_API_GetFocus() == HWND_FACTORY_MENU_CUS_LIST_ITEM15_NAME)
				{
    			#if ENABLE_SSC
                        stGenSetting.g_SSCSetting.LVDSSscStepPercentagex100= MApp_ZUI_ACT_DecIncValue_Cycle(act==EN_EXE_INC_VALUE, stGenSetting.g_SSCSetting.LVDSSscStepPercentagex100, 0, LVDS_SSC_STEP_MAX, 1);
                        /* Set LVDS SSC */
                      #if (ENABLE_LVDSTORGB_CONVERTER == ENABLE)
                        g_IPanel.SetSSC( SSC_SPAN_PERIOD, SSC_STEP_PERCENT, DISABLE );
                      #else
                        g_IPanel.SetSSC( stGenSetting.g_SSCSetting.LVDSSscSpanKHzx10,
                                            stGenSetting.g_SSCSetting.LVDSSscStepPercentagex100,
                                            stGenSetting.g_SSCSetting.SscLVDSEnale);
                      #endif
                        MApp_SaveSSCData();
			#endif

    			 	MApp_ZUI_API_InvalidateAllSuccessors(HWND_FACTORY_MENU_CUS_LIST_ITEM15_NAME);
				return TRUE;
				}
// cus_xm gary 20120717 modify by refresh factory menu
/*
		else if(MApp_ZUI_API_GetFocus() == HWND_FACTORY_MENU_CUS_LIST_ITEM16_NAME)

			{
			     stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE =
                        (EN_FACTORY_ADC_ADJUST_MODE)MApp_ZUI_ACT_DecIncValue_Cycle(act==EN_EXE_INC_VALUE, (U16)stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE, 0, (U16)EN_FacAdj_AdcMode_Ypbpr_Num-1, 1);

			     MApp_ZUI_API_InvalidateAllSuccessors(HWND_FACTORY_MENU_CUS_LIST_ITEM16_NAME);
			     MApp_ZUI_API_InvalidateAllSuccessors(HWND_FACTORY_MENU_CUS_LIST_ITEM10_NAME);
			     MApp_ZUI_API_InvalidateAllSuccessors(HWND_FACTORY_MENU_CUS_LIST_ITEM17_NAME_1);
		    	     MApp_ZUI_API_InvalidateAllSuccessors(HWND_FACTORY_MENU_CUS_LIST_ITEM17_NAME_2);
		     	     MApp_ZUI_API_InvalidateAllSuccessors(HWND_FACTORY_MENU_CUS_LIST_ITEM17_NAME_3);

			     MApp_ZUI_API_InvalidateAllSuccessors(HWND_FACTORY_MENU_CUS_LIST_ITEM18_NAME_1);
		    	     MApp_ZUI_API_InvalidateAllSuccessors(HWND_FACTORY_MENU_CUS_LIST_ITEM18_NAME_2);
		     	     MApp_ZUI_API_InvalidateAllSuccessors(HWND_FACTORY_MENU_CUS_LIST_ITEM18_NAME_3);
			    return TRUE;
			}
*/
		else if(MApp_ZUI_API_GetFocus() == HWND_FACTORY_MENU_CUS_LIST_ITEM19_NAME)
				{
				    ST_PICTURE.eColorTemp = (EN_MS_COLOR_TEMP)MApp_ZUI_ACT_DecIncValue_Cycle(
		                act==EN_EXE_INC_COLOR_TEMP,
		                ST_PICTURE.eColorTemp, MS_COLOR_TEMP_MIN, MS_COLOR_TEMP_MAX, 1);

				#if ENABLE_NEW_COLORTEMP_METHOD
		                #if ENABLE_PRECISE_RGBBRIGHTNESS
		                    MApi_XC_ACE_PicSetColorTemp(MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), (XC_ACE_color_temp_ex *) &ST_COLOR_TEMP);
		                #else
		                    MApi_XC_ACE_PicSetColorTemp(MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), (XC_ACE_color_temp *) &ST_COLOR_TEMP);
		                #endif
		            #else
			        #if ENABLE_PRECISE_RGBBRIGHTNESS
			            MApi_XC_ACE_PicSetColorTemp( MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), (XC_ACE_color_temp_ex *) &ST_COLOR_TEMP );
			            MApi_XC_ACE_PicSetBrightnessPreciseInVsync(MAIN_WINDOW, MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cRedOffset, BRIGHTNESS_R ), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cGreenOffset, BRIGHTNESS_G), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cBlueOffset, BRIGHTNESS_B));
			        #else
			            MApi_XC_ACE_PicSetColorTemp( MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), (XC_ACE_color_temp *) &ST_COLOR_TEMP );
			            MApi_XC_ACE_PicSetBrightnessInVsync(MAIN_WINDOW, MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cRedOffset, BRIGHTNESS_R ), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cGreenOffset, BRIGHTNESS_G), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cBlueOffset, BRIGHTNESS_B));
			        #endif
		            #endif
                    #ifdef ENABLE_GAMMA_FOR_COLORTEMP
                        MApi_XC_Sys_AdjustGammaTbl(FORCE_SET_VALUE);
                    #endif
				 MApp_ZUI_API_InvalidateAllSuccessors(HWND_FACTORY_MENU_CUS_LIST_ITEM19_NAME);
				//change colortemp refresh gain&offset
				MApp_ZUI_API_InvalidateAllSuccessors(HWND_FACTORY_MENU_CUS_LIST_ITEM21_NAME_1);
				MApp_ZUI_API_InvalidateAllSuccessors(HWND_FACTORY_MENU_CUS_LIST_ITEM21_NAME_2);
				MApp_ZUI_API_InvalidateAllSuccessors(HWND_FACTORY_MENU_CUS_LIST_ITEM21_NAME_3);

				MApp_ZUI_API_InvalidateAllSuccessors(HWND_FACTORY_MENU_CUS_LIST_ITEM22_NAME_1);
				MApp_ZUI_API_InvalidateAllSuccessors(HWND_FACTORY_MENU_CUS_LIST_ITEM22_NAME_2);
				MApp_ZUI_API_InvalidateAllSuccessors(HWND_FACTORY_MENU_CUS_LIST_ITEM22_NAME_3);
				return TRUE;
		           }
			else if(MApp_ZUI_API_GetFocus() == HWND_FACTORY_MENU_CUS_LIST_ITEM23_NAME)
					{
					//CUS_XM:xue add for factory menu burn in function 2012-6-26

				if(stGenSetting.g_FactorySetting.fBuringMode)
				{
					stGenSetting.g_FactorySetting.fBuringMode = FALSE;
					MApp_MultiTasks_AdjustBurningMode(DISABLE);
				}
				else
				{
					stGenSetting.g_FactorySetting.fBuringMode = TRUE;
				}
				MApp_SaveFactorySetting();

					// function need to be add
					MApp_ZUI_API_InvalidateAllSuccessors(HWND_FACTORY_MENU_CUS_LIST_ITEM23_NAME);
					return TRUE;
					}
			else if(MApp_ZUI_API_GetFocus() == HWND_FACTORY_MENU_CUS_LIST_ITEM27_NAME)
				{
				 	 stGenSetting.g_SysSetting.u8Backlight= MApp_ZUI_ACT_DecIncValue(act==EN_EXE_INC_VALUE,
             		  	stGenSetting.g_SysSetting.u8Backlight, 0, 100, 1);
           				 Panel_Backlight_PWM_ADJ(msAPI_Mode_PictureBackLightN100toReallyValue(stGenSetting.g_SysSetting.u8Backlight));
					 MApp_ZUI_API_InvalidateAllSuccessors(HWND_FACTORY_MENU_CUS_LIST_ITEM27_NAME);
					return TRUE;
				}
			else if(MApp_ZUI_API_GetFocus() == HWND_FACTORY_MENU_CUS_LIST_ITEM28_NAME)
	            	{
	               #if ENABLE_CUS_OSD_LANGUAGE
		                if(stGenSetting.g_SysSetting.Language == LANGUAGE_ENGLISH)
		                {
		                    stGenSetting.g_SysSetting.Language = LANGUAGE_CHINESE;
						g_bFactoryLanguageBack=LANGUAGE_CHINESE;
		                }
		                else
		                {
		                    stGenSetting.g_SysSetting.Language = LANGUAGE_ENGLISH;
							g_bFactoryLanguageBack=LANGUAGE_ENGLISH;
		                }
	               #else
		                stGenSetting.g_SysSetting.Language =
		                (EN_LANGUAGE)MApp_ZUI_ACT_DecIncValue(act == EN_EXE_INC_OSD_LAN , stGenSetting.g_SysSetting.Language,LANGUAGE_MENU_MIN, LANGUAGE_MENU_MAX, 1);
	               #endif
		                SET_OSD_MENU_LANGUAGE(GET_OSD_MENU_LANGUAGE());
		                MApp_ZUI_API_InvalidateAllSuccessors(HWND_FACTORY_MENU_CUS_LIST_ITEM28_NAME);
				    return TRUE;
			}
			//cus_xm zb add for csm rs232&region action 2012-6-20
			else if(MApp_ZUI_API_GetFocus() == HWND_CSM_RS232)
			{
					if(mdrv_uart_get_connection(E_UART_PORT0) == E_UART_OFF)
					 {

					       MDrv_UART_Init(E_UART_AEON_R2, 115200);
      						mdrv_uart_connect(E_UART_PORT0,E_UART_AEON_R2);
						//g_bRS232Enable = TRUE;
					 }
					else
					 {
					       MDrv_UART_Init(E_UART_AEON_R2, 115200);
                                          mdrv_uart_connect(E_UART_PORT0, E_UART_OFF);
						//g_bRS232Enable = FALSE;

					 }
					// function need to be add
					MApp_ZUI_API_InvalidateAllSuccessors(HWND_CSM_RS232);
					return TRUE;
			}

			  else if(MApp_ZUI_API_GetFocus() == HWND_CSM_TV_REGION)
			{
					if(g_bRegionEnable == FALSE)
						g_bRegionEnable = TRUE;
					else
						g_bRegionEnable = FALSE;
					// function need to be add
					MApp_ZUI_API_InvalidateAllSuccessors(HWND_CSM_TV_REGION);
					return TRUE;
			}
			else
				{
					return TRUE;
				}

//cus_xm gary modify by cus_factory menu function end
#if BOE_USB_UPGRADE_FACTROY//minglin1206
	 case EN_EXE_SW_USB_UPDATE://smc.chy 2010/05/07
            //printf("\r\nGOTO MAIN");
#if 0
             {
    #if ( (ENABLE_USB||ENABLE_USB_2) && ENABLE_FILESYSTEM )
        #ifndef MSOS_TYPE_LINUX
                extern U8 MDrv_USBGetPortEnableStatus(void);
                extern void MApp_ZUI_SwUpdate_ProgressBar(U8 percent);
                extern void msAPI_BLoader_Reboot(void);
                U8 u8PortEnStatus = 0;

                printf("USB SW Update!\n");
                u8PortEnStatus = MDrv_USBGetPortEnableStatus();
                if((u8PortEnStatus & BIT0) == BIT0)
                {
                    MApp_UsbDownload_Init(BIT0, MApp_ZUI_SwUpdate_ProgressBar);
                }
                else if((u8PortEnStatus & BIT1) == BIT1)
                {
                    MApp_UsbDownload_Init(BIT1, MApp_ZUI_SwUpdate_ProgressBar);
                }
                else
                {
                    printf("Error> Unknown USB port\n");
                    return FALSE;
                }

                if(!MW_UsbDownload_Search())
                {
                    break;
                }

                if (MW_UsbDownload_Start())
                {
                    msAPI_BLoader_Reboot();
                }
        #else
            printf("Un-support USB Update\n");
        #endif
        #endif
    }
#else
        printf("\r\nUSB UPDATE");
        {
            USBPowerOn();
#if 0 //(ENABLE_CHAOYE_FUNCTION)
        MDrv_USBSetPortSwitch(1);
#else
        MDrv_USBSetPortAutoSwitchStatus(TRUE);//smc.chy 2011/01/07
#endif

        #if ( ENABLE_SW_UPGRADE && ENABLE_FILESYSTEM )
            U8 u8PortEnStatus = 0;
            u8PortEnStatus = MDrv_USBGetPortEnableStatus();
            //MApp_ZUI_API_StoreFocusCheckpoint();
            
            if((u8PortEnStatus & BIT0) == BIT0)
            {
                if (!MDrv_UsbDeviceConnect())
                {
                    MsOS_DelayTask(1000);
                }

                if (!MDrv_UsbDeviceConnect())
                {
                    if((u8PortEnStatus & BIT1) != BIT1)
                    {
                        _u8USBDownloadStatus = 1;
                        MApp_ZUI_API_InvalidateAllSuccessors(MApp_ZUI_API_GetFocus());
                        //_MApp_ZUI_ACT_OpenCommonDialog(EN_COMMON_DLG_MODE_USB_NOT_DETECTED);
                        //MApp_ZUI_API_SetTimer(HWND_MENU_DLG_COMMON,0,6000);
                        return TRUE;
                    }
                }
                else
                {
                    MApp_UsbDownload_Init(BIT0, MApp_ZUI_SwUpdate_ProgressBar);

                    if (MW_UsbDownload_Search())
                    {
                        //MApp_ZUI_API_StoreFocusCheckpoint();
                        /*
                        if (MW_UsbDownload_Start())
                        {
                            msAPI_BLoader_Reboot();
                        }
                        */
                        _u8USBDownloadStatus = 0;
                        MApp_ZUI_API_InvalidateAllSuccessors(MApp_ZUI_API_GetFocus());

                          MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
                         _enTargetOSDPageState = STATE_OSDPAGE_GOTO_UPDATE_MENU;
                        //_MApp_ZUI_ACT_OpenCommonDialog(EN_COMMON_DLG_MODE_USB_UPDATE_CONFIRM);
                        return TRUE;
                    }
                    else //no sw file detected
                    {
                        {
                            MS_VE_Output_Ctrl OutputCtrl;
                            // enable VE
                            OutputCtrl.bEnable = ENABLE;
                            msAPI_VE_SetOutputCtrl(&OutputCtrl);
                            // enable DNR buffer
                            MApi_XC_DisableInputSource(FALSE, MAIN_WINDOW);
                            MW_AUD_SetSoundMute(SOUND_MUTE_ALL, E_MUTE_OFF);
                        }
                        if((u8PortEnStatus & BIT1) != BIT1)
                        {
                            _u8USBDownloadStatus = 2;
                  
                            //_MApp_ZUI_ACT_OpenCommonDialog(EN_COMMON_DLG_MODE_SW_FILE_NOT_DETECTED);
                            //MApp_ZUI_API_SetTimer(HWND_MENU_DLG_COMMON,0,6000);
                            return TRUE;
                        }

                        MApp_ZUI_API_InvalidateAllSuccessors(MApp_ZUI_API_GetFocus());
                        printf("\r\nNO FILE2",0);
                    }
                }
            }

            if((u8PortEnStatus & BIT1) == BIT1)
            {
                if (!MDrv_UsbDeviceConnect_Port2())
                {
                    MsOS_DelayTask(1000);
                }

                if (!MDrv_UsbDeviceConnect_Port2())
                {
                    _u8USBDownloadStatus = 1;
                    MApp_ZUI_API_InvalidateAllSuccessors(MApp_ZUI_API_GetFocus());
                    //_MApp_ZUI_ACT_OpenCommonDialog(EN_COMMON_DLG_MODE_USB_NOT_DETECTED);
                    MApp_ZUI_API_SetTimer(HWND_MENU_DLG_COMMON,0,6000);
                }
                else
                {
                    MApp_UsbDownload_Init(BIT1, MApp_ZUI_SwUpdate_ProgressBar);

                    if (MW_UsbDownload_Search())
                    {
                        /*
                        //MApp_ZUI_API_StoreFocusCheckpoint();
                        if (MW_UsbDownload_Start())
                        {
                            msAPI_BLoader_Reboot();
                        }
                        */
                        _u8USBDownloadStatus = 0;
                        MApp_ZUI_API_InvalidateAllSuccessors(MApp_ZUI_API_GetFocus());

                          MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
                         _enTargetOSDPageState = STATE_OSDPAGE_GOTO_UPDATE_MENU;
                        //_MApp_ZUI_ACT_OpenCommonDialog(EN_COMMON_DLG_MODE_USB_UPDATE_CONFIRM);
                    }
                    else //no sw file detected
                    {
                        {
                            MS_VE_Output_Ctrl OutputCtrl;
                            // enable VE
                            OutputCtrl.bEnable = ENABLE;
                            msAPI_VE_SetOutputCtrl(&OutputCtrl);
                            // enable DNR buffer
                            MApi_XC_DisableInputSource(FALSE, MAIN_WINDOW);
                            MW_AUD_SetSoundMute(SOUND_MUTE_ALL, E_MUTE_OFF);
                        }
                        _u8USBDownloadStatus = 2;
                        MApp_ZUI_API_InvalidateAllSuccessors(MApp_ZUI_API_GetFocus());
                        //_MApp_ZUI_ACT_OpenCommonDialog(EN_COMMON_DLG_MODE_SW_FILE_NOT_DETECTED);
                        //MApp_ZUI_API_SetTimer(HWND_MENU_DLG_COMMON,0,6000);
                    }
                }
            }
            return TRUE;
            #endif // #if ( ENABLE_SW_UPGRADE && ENABLE_FILESYSTEM )
        }
            //MApp_OSDPage_SetState(STATE_OSDPAGE_GOTO_UPDATE_MENU);
#endif
            break;
#endif

    }
    return FALSE;
}

#if CUS_SMC_ENABLE_HOTEL_MODE
extern U16 _MApp_ZUI_ACT_GetLanguageStringID(EN_LANGUAGE lang, BOOLEAN bDefaultEnglish);
#endif

LPTSTR MApp_ZUI_ACT_GetFactoryMenuDynamicText(HWND hwnd)
{
    U16 u16TempID = Empty;

    U8 u8Item;
    U8 i;

    //step1: special cases: title
    if (hwnd == HWND_FACTORY_MENU_TITLE)
    {
        switch(_eFactoryMenuPage)
        {
            case EN_FACTORY_PAGE_ROOT:
                u16TempID = en_strFactorySettingText;
                break;

            case EN_FACTORY_PAGE_ADC_ADJUST:
                u16TempID = en_strADCADJUSTText;
                break;

            case EN_FACTORY_PAGE_PICTURE_MODE:
                u16TempID = en_strSUBBCADJUSTText;
                break;

            case EN_FACTORY_PAGE_WHITE_BALANCE:
                u16TempID = en_strWBAdjustText;
                break;

            case EN_FACTORY_PAGE_QMAP_PAGE:
                u16TempID = en_str_QMAP_ADJUST;
                break;
            #if ENABLE_PIP
            case EN_FACTORY_PAGE_PIP_POP:
                u16TempID = en_str_PIP_POP_Settings;
                break;
            #endif
            case EN_FACTORY_PAGE_SW_INFO_PAGE:
                u16TempID = en_str_SW_info;
                break;
            #if ENABLE_AUTOTEST
            case EN_FACTORY_PAGE_BMTEST_PAGE:
                u16TempID = en_str_BMTEST;
                break;
            #endif
#if ENABLE_AUTO_DQS_Factory
            case EN_FACTORY_PAGE_BIST_TEST:
                u16TempID = en_str_BIST_TEST;
                break;
#endif
            case EN_FACTORY_PAGE_PEQ:
                u16TempID = en_str_PEQ;
                break;
            case EN_FACTORY_PAGE_SSC:
                u16TempID = en_str_SSC;
                break;
            case EN_FACTORY_PAGE_SPECIAL_SET:
                u16TempID = en_str_SPECIAL_SET;
                break;
            case EN_FACTORY_PAGE_VIF1:
                u16TempID = en_str_VIF1;
                break;
            case EN_FACTORY_PAGE_VIF2:
                u16TempID = en_str_VIF2;
                break;
            case EN_FACTORY_PAGE_VIF3:
                u16TempID = en_str_VIF3;
                break;
            case EN_FACTORY_PAGE_UART_DBG:
                u16TempID = en_str_uart_dbg;
                break;
        #if (ENABLE_SZ_FACTORY_OVER_SCAN_FUNCTION)
            case EN_FACTORY_PAGE_OVERSCAN:
                u16TempID = en_str_overscan_reslution;
                break;
        #endif

#if ENABLE_NONLINEAR_CURVE
 case EN_FACTORY_PAGE_NONLINEAR_CURVE:
                u16TempID = en_str_NONLINEAR;
                break;
            case EN_FACTORY_PAGE_BRIGHTNESS_CURVE:
                u16TempID = en_str_BrightnessCurve;
                break;
            case EN_FACTORY_PAGE_CONTRAST_CURVE:
                u16TempID = en_str_ContrastCurve;
                break;
            case EN_FACTORY_PAGE_SATURATION_CURVE:
                u16TempID = en_str_ColorCurve;
                break;
            case EN_FACTORY_PAGE_HUE_CURVE:
                u16TempID = en_str_TintCurve;
                break;
            case EN_FACTORY_PAGE_SHARPNESS_CURVE:
                u16TempID = en_str_SharpnessCurve;
                break;
            case EN_FACTORY_PAGE_VOLUME_CURVE:
                u16TempID = en_str_VolumeCurve;
                break;
 #endif

#if ENABLE_SZ_FACTORY_USB_SAVE_MAP_FUNCTION
            case EN_FACTORY_PAGE_REGISTER_MAP:
                 u16TempID = en_str_Register_Map;
                 break;
#endif
		case EN_FACTORY_PAGE_VCOM:
				u16TempID = en_str_PanelControl;

        default:
            break;
        }
        goto END;

    }

    u8Item = _MApp_ZUI_ACT_FactoryMenuWindowMapToIndex(hwnd);

        //special case: board type in item name...

    if( hwnd == HWND_FACTORY_MENU_BOARD_INFO)
    {
        U8 VersionName[] = BOARD_NAME;
        return MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, VersionName,255);
    }

    //step2: value windows
    if (_FactoryMenuItemHwndValueList[u8Item] == hwnd) //is value window...
    {
        return _MApp_ZUI_ACT_GetFactoryMenuValueText(u8Item);
    }
    if(hwnd == HWND_FACTORY_MENU_BAR_TEXT)
    {
        u8Item = _MApp_ZUI_ACT_FactoryMenuWindowMapToIndex(_eFactoryBarInfo.pre_item);
        return MApp_ZUI_ACT_GetFactoryMenuDynamicText(_FactoryMenuItemHwndNameList[u8Item]);
    }
    if(hwnd == HWND_FACTORY_MENU_BAR_OPTION)
    {
        u8Item = _MApp_ZUI_ACT_FactoryMenuWindowMapToIndex(_eFactoryBarInfo.pre_item);
        return _MApp_ZUI_ACT_GetFactoryMenuValueText(u8Item);
    }
    if (hwnd == HWND_FACTORY_MENU_INPUT_TYPE)
    {
        //printf("MApp_ZUI_ACTfactorymenu.c Line %d : %s\n", __LINE__, MDrv_PQ_GetSrcTypeName(MAIN_WINDOW));
        return MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, (U8*)MDrv_PQ_GetSrcTypeName(PQ_MAIN_WINDOW), 255);
    }
    if (hwnd == HWND_FACTORY_SW_INFO_TEXT)
    {
                #if 1
                    {
                    char *ptr;
                    char ptr_head[128];
                    unsigned char * pu8Temp;
                    U8 u8Data,u8Temp_i,u8Temp_j;
                    U8 u8ASCII_Mapping[16] = {'0','1','2','3','4','5','6','7','8','9','A',
                        'B','C','D','E','F'};
                    unsigned char Customer_info_others[48];
                    U32 u32Temp;
                    ptr = ptr_head;
                    //<1>.For Customer ID
                    //ptr = strcpy(ptr, "CID:" );
                    //ptr +=4;

                    ptr = memcpy(ptr, &Customer_info[0],4);
                    ptr +=4;
                    *ptr = '-';
                    ptr++;

                    //<2>.For Customer ID
                    //ptr = strcpy(ptr, "MID:" );
                    //ptr +=4;
                    ptr = memcpy(ptr, &Customer_info[4],4);
                    ptr +=4;
                    *ptr = '-';
                    ptr++;

                    //<3>.For Customer ID
                    //ptr = strcpy(ptr, "Chip:" );
                    //ptr +=5;

                    ptr = memcpy(ptr, &Customer_info[8],4);
                    ptr +=4;
                    *ptr = '-';
                    ptr++;

                    //<3>.To prepare the Customer Info Others
                    u8Temp_i=0;
                    //Get SW Project Name:01 => Chakra
                    pu8Temp = &CID_Buf[CUSTOMER_INFO_START_SW_PROJECT];
                    u8Data = ((*(pu8Temp))>> 4);
                    Customer_info_others[u8Temp_i++] = u8ASCII_Mapping[u8Data];
                    u8Data = (*(pu8Temp) & 0x0F);
                    Customer_info_others[u8Temp_i++] =  u8ASCII_Mapping[u8Data];
                    Customer_info_others[u8Temp_i++] =  '-';

                   //Get SW Project Generation:01 => 1.0
                    pu8Temp = &CID_Buf[CUSTOMER_INFO_START_SW_PROJECT_GENERATION];
                    u8Data = ((*(pu8Temp))>> 4);
                    Customer_info_others[u8Temp_i++] = u8ASCII_Mapping[u8Data];
                    u8Data = (*(pu8Temp) & 0x0F);
                    Customer_info_others[u8Temp_i++] =  u8ASCII_Mapping[u8Data];
                    Customer_info_others[u8Temp_i++] =  '-';

                    //Get Product Type:TV-01
                    pu8Temp = &CID_Buf[CUSTOMER_INFO_START_PRODUCT];
                    u8Data = ((*(pu8Temp))>> 4);
                    Customer_info_others[u8Temp_i++] = u8ASCII_Mapping[u8Data];
                    u8Data = (*(pu8Temp) & 0x0F);
                    Customer_info_others[u8Temp_i++] =  u8ASCII_Mapping[u8Data];
                    Customer_info_others[u8Temp_i++] =  '-';

                    //Get TV System
                    pu8Temp = &CID_Buf[CUSTOMER_INFO_START_TV_SYSTEM];
                    u8Data = ((*(pu8Temp))>> 4);
                    Customer_info_others[u8Temp_i++] = u8ASCII_Mapping[u8Data];
                    u8Data = (*(pu8Temp) & 0x0F);
                    Customer_info_others[u8Temp_i++] =  u8ASCII_Mapping[u8Data];
                    Customer_info_others[u8Temp_i++] =  '-';

                    pu8Temp = &CID_Buf[CUSTOMER_INFO_START_LABEL];
                    u32Temp = ((*(pu8Temp+2))<<16)|((*(pu8Temp+1))<<8)|((*(pu8Temp+0)));

                    for (u8Temp_j=0;u8Temp_j<6;u8Temp_j++)
                    {
                        u8Data = u32Temp%10;
                        u32Temp = u32Temp/10;
                        Customer_info_others[u8Temp_i+5-u8Temp_j] = u8ASCII_Mapping[u8Data];
                    }
                    u8Temp_i +=6;
                    Customer_info_others[u8Temp_i++] =  '-';


                    pu8Temp = &CID_Buf[CUSTOMER_INFO_START_CL];
                    u32Temp = ((*(pu8Temp+2))<<16)|((*(pu8Temp+1))<<8)|((*(pu8Temp+0)));
                    for (u8Temp_j=0;u8Temp_j<8;u8Temp_j++)
                    {
                        u8Data = u32Temp%10;
                        u32Temp = u32Temp/10;
                        Customer_info_others[u8Temp_i+7-u8Temp_j] = u8ASCII_Mapping[u8Data];
                    }
                    u8Temp_i +=8;
                    Customer_info_others[u8Temp_i++] =  '-';

                    //Get SW Release Purpose:01 => 1.0
                    pu8Temp = &CID_Buf[CUSTOMER_INFO_START_RELEASE_PURPOSE];
                    u8Data = ((*(pu8Temp))>> 4);
                    Customer_info_others[u8Temp_i++] = u8ASCII_Mapping[u8Data];
                    u8Data = (*(pu8Temp) & 0x0F);
                    Customer_info_others[u8Temp_i++] =  u8ASCII_Mapping[u8Data];
                    Customer_info_others[u8Temp_i++] =  '-';

                    //Get CUP type
                    pu8Temp = &CID_Buf[CUSTOMER_INFO_START_CPU_TYPE];
                    u8Data = ((*(pu8Temp))>> 4);
                    Customer_info_others[u8Temp_i++] = u8ASCII_Mapping[u8Data];
                    u8Data = (*(pu8Temp) & 0x0F);
                    Customer_info_others[u8Temp_i++] =  u8ASCII_Mapping[u8Data];

                    ptr = memcpy(ptr, &Customer_info_others[0],(u8Temp_i));
                    ptr +=(u8Temp_i);
                    *ptr = 0;
            return MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, (U8 *)ptr_head, strlen(ptr_head));
                }
        #else
                {
                  #if 0
                    char *ptr;
                    char ptr_head[128];

                    ptr = ptr_head;
                    ptr = strcpy(ptr, SWVersionName );
                    return MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, (U8 *)ptr_head, strlen(ptr_head));
                  #else // Modifed it by coverity_0544
                    char ptr_head[128];
                    strcpy(ptr_head, SWVersionName );
                    return MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, (U8 *)ptr_head, strlen(ptr_head));
                  #endif
                }
                break;
        #endif
    }
// cus_xm gary 201206011 modify by factory menu source start

if( hwnd == HWND_FACTORY_MENU_CUS_LIST_ITEM0_VALUE)
    	{
 		       char ptr_head[128];
                    strcpy(ptr_head, SWBrandName);
                    return MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, (U8 *)ptr_head, strlen(ptr_head));
    	}
if( hwnd == HWND_FACTORY_MENU_CUS_LIST_ITEM1_VALUE)
    {
        char ptr_head[128];
    #if 0
        strcpy(ptr_head, SWMainMCUVer );
    #else
        snprintf(ptr_head, 128, "%s-%cM%c%s", SWModeName, 'S', 'P', SWMainMCUVer);
    #endif
        return MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, (U8 *)ptr_head, strlen(ptr_head));
    }
if( hwnd == HWND_FACTORY_MENU_CUS_LIST_ITEM2_VALUE)
    	{
 				 char ptr_head[128];
                    strcpy(ptr_head, SWBootLoaderVer );
                    return MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, (U8 *)ptr_head, strlen(ptr_head));
    	}
if( hwnd == HWND_FACTORY_MENU_CUS_LIST_ITEM3_VALUE)
    	{
                #if ENABLE_6M30_3D_PROCESS
			char ptr_head[7];
			U16 u16Version = MDrv_Ursa_6M30_GetFwVersion();
                    snprintf(ptr_head, 7, "V%x.%02x", (u16Version >> 8), (u16Version&0xFF));
                #else
			char ptr_head[128];
                    strcpy(ptr_head, SWSubMCUVer );
                #endif
                    return MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, (U8 *)ptr_head, strlen(ptr_head));
    	}
if( hwnd == HWND_FACTORY_MENU_CUS_LIST_ITEM4_VALUE)
    	{
 				 char ptr_head[128];
                    strcpy(ptr_head, SWEEPROMVer );
                    return MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, (U8 *)ptr_head, strlen(ptr_head));
    	}
if( hwnd == HWND_FACTORY_MENU_CUS_LIST_ITEM5_VALUE)
    	{
 		         char *ptr;
                      char ptr_head[128];
                      ptr = ptr_head;
                      strncpy(ptr, SWCompileDate, sizeof(SWCompileDate) );
                      return MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, (U8 *)ptr_head, strlen(ptr_head));;
    	}
if( hwnd == HWND_FACTORY_MENU_CUS_LIST_ITEM6_VALUE)
    	{
 		  	char ptr_head[128];
                    strcpy(ptr_head, SWModeName );
                    return MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, (U8 *)ptr_head, strlen(ptr_head));

    	}
if( hwnd == HWND_FACTORY_MENU_CUS_LIST_ITEM7_VALUE)
    	{
 		  	 char ptr_head[128];
                   strcpy(ptr_head, SWScalerType);
                  return MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, (U8 *)ptr_head, strlen(ptr_head));


    	}
if( hwnd == HWND_FACTORY_MENU_CUS_LIST_ITEM8_VALUE)
    	{
 		 	 char ptr_head[128];
                    strcpy(ptr_head, SWPanelType);
                    return MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, (U8 *)ptr_head, strlen(ptr_head));

    	}
 if( hwnd == HWND_FACTORY_MENU_CUS_LIST_ITEM9_VALUE)
    {
                    u16TempID = _MApp_ZUI_ACT_GetDataInputSourceStringID(DATA_INPUT_SOURCE_TYPE(MAIN_WINDOW));

    }
// cus_xm gary 20120717 modify by refresh factory menu
if( hwnd == HWND_FACTORY_MENU_CUS_LIST_ITEM10_VALUE)
    	{
  	 if (stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_RGB)
                    {
                        if(stGenSettingExt.g_AdcSetting[ADC_SET_VGA].u8AdcCalOK== 0xAA)
                            u16TempID=en_strSUCCESS;
                        else if(stGenSettingExt.g_AdcSetting[ADC_SET_VGA].u8AdcCalOK== 0x00)
                            u16TempID=en_strFAIL;
				     else
					  u16TempID=en_strGO;
                    }
                    else if (stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_Ypbpr_SD)
                    {
                        if(stGenSettingExt.g_AdcSetting[ADC_SET_YPBPR_SD].u8AdcCalOK== 0xAA)
                            u16TempID=en_strSUCCESS;
                        else if(stGenSettingExt.g_AdcSetting[ADC_SET_YPBPR_SD].u8AdcCalOK== 0x00)
                               u16TempID=en_strFAIL;
				     else
					  u16TempID=en_strGO;

                    }
                    else if (stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_Ypbpr_HD)
                    {
                        if(stGenSettingExt.g_AdcSetting[ADC_SET_YPBPR_HD].u8AdcCalOK== 0xAA)
                            u16TempID=en_strSUCCESS;
                         else if(stGenSettingExt.g_AdcSetting[ADC_SET_YPBPR_HD].u8AdcCalOK== 0x00)
                                   u16TempID=en_strFAIL;
				     else
					  u16TempID=en_strGO;
                    }
                #if (INPUT_SCART_VIDEO_COUNT >= 1)
                    else if (stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_ScartRGB)
                    {
                        if(stGenSettingExt.g_AdcSetting[ADC_SET_SCART_RGB].u8AdcCalOK== 0xAA)
                            u16TempID=en_strSUCCESS;
                        else if(stGenSettingExt.g_AdcSetting[ADC_SET_SCART_RGB].u8AdcCalOK== 0x00)
                                   u16TempID=en_strFAIL;
				     else
					  u16TempID=en_strGO;
                    }
                #endif
                    /*
                    if(g_ADCCalibrationResult)
                        u16TempID=en_strSUCCESS;
                    else
                        u16TempID=en_strFAIL;
                        */

    	}
if( hwnd == HWND_FACTORY_MENU_CUS_LIST_ITEM11_VALUE)
    	{
 		u16TempID = en_str75;
    	}
if( hwnd == HWND_FACTORY_MENU_CUS_LIST_ITEM13_VALUE)
    	{
    	#if ENABLE_SSC
		if(stGenSetting.g_SSCSetting.SscLVDSEnale == FALSE)
 			u16TempID = en_strOFF;
		else
			u16TempID = en_strON;
	#else
	 		u16TempID = en_strOFF;
	#endif
    	}
if( hwnd == HWND_FACTORY_MENU_CUS_LIST_ITEM14_VALUE)
    	{
    	    	#if ENABLE_SSC
                        CHAR_BUFFER[0] = ((stGenSetting.g_SSCSetting.LVDSSscSpanKHzx10/100) == 0) ? ' ' : '0'+(stGenSetting.g_SSCSetting.LVDSSscSpanKHzx10/100);
                        CHAR_BUFFER[1] = '0'+((stGenSetting.g_SSCSetting.LVDSSscSpanKHzx10%100)/10);
                        CHAR_BUFFER[2] = '.';
                        CHAR_BUFFER[3] = '0'+(stGenSetting.g_SSCSetting.LVDSSscSpanKHzx10%10);
                        CHAR_BUFFER[4] = CHAR_SPACE;
                        CHAR_BUFFER[5] = CHAR_K;
                        CHAR_BUFFER[6] = CHAR_H;
                        CHAR_BUFFER[7] = CHAR_z;
                        CHAR_BUFFER[8] = 0;
                return CHAR_BUFFER;
		#endif
    	}
if( hwnd == HWND_FACTORY_MENU_CUS_LIST_ITEM15_VALUE)
    	{
    	#if ENABLE_SSC
 		           CHAR_BUFFER[0] = '0'+((stGenSetting.g_SSCSetting.LVDSSscStepPercentagex100/100));
                        CHAR_BUFFER[1] = '.';
                	     CHAR_BUFFER[2] = '0'+((stGenSetting.g_SSCSetting.LVDSSscStepPercentagex100%100)/10);
                        CHAR_BUFFER[3] = '0'+(stGenSetting.g_SSCSetting.LVDSSscStepPercentagex100%10);
                        CHAR_BUFFER[4] = CHAR_SPACE;
                        CHAR_BUFFER[5] = '%';
                        CHAR_BUFFER[6] = 0;
                return CHAR_BUFFER;
	#endif
    	}
if( hwnd == HWND_FACTORY_MENU_CUS_LIST_ITEM16_VALUE)
	{
		if (stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_RGB)
                        u16TempID=en_strRGB;
                    else if (stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_Ypbpr_SD)
                        u16TempID=en_strYPbPrSD;
                    else if (stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_Ypbpr_HD)
                        u16TempID=en_strYPbPrHD;
                #if (INPUT_SCART_VIDEO_COUNT >= 1)
                    else if (stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_ScartRGB)
                        u16TempID=en_str_ScartRGB;
                #endif
	}

if( hwnd == HWND_FACTORY_MENU_CUS_LIST_ITEM17_VALUE_1)
    	{
    	//from case EN_DNUM_GetADC_RedGainValue
    			//printf("stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE===%d\n",stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE);
                    if (stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_RGB)
                    {
                        return MApp_ZUI_API_GetU16String(stGenSettingExt.g_AdcSetting[ADC_SET_VGA].stAdcGainOffsetSetting.u16RedGain);
                    }
                    else if (stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_Ypbpr_SD)
                    {
                        return MApp_ZUI_API_GetU16String(stGenSettingExt.g_AdcSetting[ADC_SET_YPBPR_SD].stAdcGainOffsetSetting.u16RedGain);
                    }
                    else if (stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_Ypbpr_HD)
                    {
                        return MApp_ZUI_API_GetU16String(stGenSettingExt.g_AdcSetting[ADC_SET_YPBPR_HD].stAdcGainOffsetSetting.u16RedGain);
                    }
                #if (INPUT_SCART_VIDEO_COUNT >= 1)
                    else if (stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_ScartRGB)
                    {
                        return MApp_ZUI_API_GetU16String(stGenSettingExt.g_AdcSetting[ADC_SET_SCART_RGB].stAdcGainOffsetSetting.u16RedGain);
                    }
                #endif
    	}
if( hwnd == HWND_FACTORY_MENU_CUS_LIST_ITEM17_VALUE_2)
    	{
    	 //from case EN_DNUM_GetADC_GreenGainValue
     			 if (stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_RGB)
                    {
                        return MApp_ZUI_API_GetU16String(stGenSettingExt.g_AdcSetting[ADC_SET_VGA].stAdcGainOffsetSetting.u16GreenGain);
                    }
                    else if (stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_Ypbpr_SD)
                    {
                        return MApp_ZUI_API_GetU16String(stGenSettingExt.g_AdcSetting[ADC_SET_YPBPR_SD].stAdcGainOffsetSetting.u16GreenGain);
                    }
                    else if (stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_Ypbpr_HD)
                    {
                        return MApp_ZUI_API_GetU16String(stGenSettingExt.g_AdcSetting[ADC_SET_YPBPR_HD].stAdcGainOffsetSetting.u16GreenGain);
                    }
                #if (INPUT_SCART_VIDEO_COUNT >= 1)
                    else if (stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_ScartRGB)
                    {
                        return MApp_ZUI_API_GetU16String(stGenSettingExt.g_AdcSetting[ADC_SET_SCART_RGB].stAdcGainOffsetSetting.u16GreenGain);
                    }
                #endif
                }
if( hwnd == HWND_FACTORY_MENU_CUS_LIST_ITEM17_VALUE_3)
    	{

               	 //from case EN_DNUM_GetADC_BlueGainValue
                    if (stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_RGB)
                    {
                        return MApp_ZUI_API_GetU16String(stGenSettingExt.g_AdcSetting[ADC_SET_VGA].stAdcGainOffsetSetting.u16BlueGain);
                    }
                    else if (stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_Ypbpr_SD)
                    {
                        return MApp_ZUI_API_GetU16String(stGenSettingExt.g_AdcSetting[ADC_SET_YPBPR_SD].stAdcGainOffsetSetting.u16BlueGain);
                    }
                    else if (stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_Ypbpr_HD)
                    {
                        return MApp_ZUI_API_GetU16String(stGenSettingExt.g_AdcSetting[ADC_SET_YPBPR_HD].stAdcGainOffsetSetting.u16BlueGain);
                    }
                #if (INPUT_SCART_VIDEO_COUNT >= 1)
                    else if (stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_ScartRGB)
                    {
                        return MApp_ZUI_API_GetU16String(stGenSettingExt.g_AdcSetting[ADC_SET_SCART_RGB].stAdcGainOffsetSetting.u16BlueGain);
                    }
                #endif
    	}
if( hwnd == HWND_FACTORY_MENU_CUS_LIST_ITEM18_VALUE_1)
    	{
	 //from case EN_DNUM_GetADC_RedOffsetValue:

                    if (stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_RGB)
                    {
                        return MApp_ZUI_API_GetU16String(stGenSettingExt.g_AdcSetting[ADC_SET_VGA].stAdcGainOffsetSetting.u16RedOffset);
                    }
                    else if (stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_Ypbpr_SD)
                    {
                        return MApp_ZUI_API_GetU16String(stGenSettingExt.g_AdcSetting[ADC_SET_YPBPR_SD].stAdcGainOffsetSetting.u16RedOffset);
                    }
                    else if (stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_Ypbpr_HD)
                    {
                        return MApp_ZUI_API_GetU16String(stGenSettingExt.g_AdcSetting[ADC_SET_YPBPR_HD].stAdcGainOffsetSetting.u16RedOffset);
                    }
                #if (INPUT_SCART_VIDEO_COUNT >= 1)
                    else if (stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_ScartRGB)
                    {
                        return MApp_ZUI_API_GetU16String(stGenSettingExt.g_AdcSetting[ADC_SET_SCART_RGB].stAdcGainOffsetSetting.u16RedOffset);
                    }
                #endif
    	}
if( hwnd == HWND_FACTORY_MENU_CUS_LIST_ITEM18_VALUE_2)
    	{
 //from case EN_DNUM_GetADC_GreenOffsetValue:

                    if (stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_RGB)
                    {
                        return MApp_ZUI_API_GetU16String(stGenSettingExt.g_AdcSetting[ADC_SET_VGA].stAdcGainOffsetSetting.u16GreenOffset);
                    }
                    else if (stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_Ypbpr_SD)
                    {
                        return MApp_ZUI_API_GetU16String(stGenSettingExt.g_AdcSetting[ADC_SET_YPBPR_SD].stAdcGainOffsetSetting.u16GreenOffset);
                    }
                    else if (stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_Ypbpr_HD)
                    {
                        return MApp_ZUI_API_GetU16String(stGenSettingExt.g_AdcSetting[ADC_SET_YPBPR_HD].stAdcGainOffsetSetting.u16GreenOffset);
                    }
                #if (INPUT_SCART_VIDEO_COUNT >= 1)
                    else if (stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_ScartRGB)
                    {
                        return MApp_ZUI_API_GetU16String(stGenSettingExt.g_AdcSetting[ADC_SET_SCART_RGB].stAdcGainOffsetSetting.u16GreenOffset);
                    }
                #endif
         }

if( hwnd == HWND_FACTORY_MENU_CUS_LIST_ITEM18_VALUE_3)
    	{

          //from case EN_DNUM_GetADC_BlueOffsetValue:
                    if (stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_RGB)
                    {
                        return MApp_ZUI_API_GetU16String(stGenSettingExt.g_AdcSetting[ADC_SET_VGA].stAdcGainOffsetSetting.u16BlueOffset);
                    }
                    else if (stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_Ypbpr_SD)
                    {
                        return MApp_ZUI_API_GetU16String(stGenSettingExt.g_AdcSetting[ADC_SET_YPBPR_SD].stAdcGainOffsetSetting.u16BlueOffset);
                    }
                    else if (stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_Ypbpr_HD)
                    {
                        return MApp_ZUI_API_GetU16String(stGenSettingExt.g_AdcSetting[ADC_SET_YPBPR_HD].stAdcGainOffsetSetting.u16BlueOffset);
                    }
                #if (INPUT_SCART_VIDEO_COUNT >= 1)
                    else if (stLMGenSetting.stMFactory_Adjust.enH1_ADC_ADJUST_MODE == EN_FacAdj_AdcMode_ScartRGB)
                    {
                        return MApp_ZUI_API_GetU16String(stGenSettingExt.g_AdcSetting[ADC_SET_SCART_RGB].stAdcGainOffsetSetting.u16BlueOffset);
                    }
                #endif
 	}


if( hwnd == HWND_FACTORY_MENU_CUS_LIST_ITEM21_VALUE_1)
    	{
			//from case EN_DNUM_GetWBRedGainValue:
                    return MApp_ZUI_API_GetU16String(ST_COLOR_TEMP.cRedColor);


    	}
if( hwnd == HWND_FACTORY_MENU_CUS_LIST_ITEM21_VALUE_2)
    	{
				   //from case EN_DNUM_GetWBGreenGainValue:
                    return MApp_ZUI_API_GetU16String(ST_COLOR_TEMP.cGreenColor);


    	}
if( hwnd == HWND_FACTORY_MENU_CUS_LIST_ITEM21_VALUE_3)
    	{
		   //from case EN_DNUM_GetWBBlueGainValue:
                    return MApp_ZUI_API_GetU16String(ST_COLOR_TEMP.cBlueColor);


    	}
if( hwnd == HWND_FACTORY_MENU_CUS_LIST_ITEM22_VALUE_1)
    	{
			//from case EN_DNUM_GetWBRedOffsetValue:
                    return MApp_ZUI_API_GetU16String(ST_COLOR_TEMP.cRedOffset);


    	}
if( hwnd == HWND_FACTORY_MENU_CUS_LIST_ITEM22_VALUE_2)
    	{
		   //from case EN_DNUM_GetWBGreenOffsetValue:
                    return MApp_ZUI_API_GetU16String(ST_COLOR_TEMP.cGreenOffset);


    	}
if( hwnd == HWND_FACTORY_MENU_CUS_LIST_ITEM22_VALUE_3)
    	{
			//from case EN_DNUM_GetWBBlueOffsetValue:
                    return MApp_ZUI_API_GetU16String(ST_COLOR_TEMP.cBlueOffset);
    	}

if( hwnd == HWND_FACTORY_MENU_CUS_LIST_ITEM23_VALUE)
    	{
    	//cus_xm:xue add 2012-6-26
 		    	if(stGenSetting.g_FactorySetting.fBuringMode)
 				u16TempID = en_strON;
			else
				u16TempID = en_strOFF;
    	}

	if(hwnd == HWND_FACTORY_MENU_CUS_LIST_ITEM19_VALUE)
	{
	           switch( ST_PICTURE.eColorTemp )
            {
                default:
                case MS_COLOR_TEMP_COOL:

                    u16TempID=en_str_ColorTemp_Cool;
                    break;
                case MS_COLOR_TEMP_MEDIUM:
                    u16TempID=en_str_ColorTemp_Medium;
                    break;
                case MS_COLOR_TEMP_WARM:
                    u16TempID=en_str_ColorTemp_Warm;
                    break;
            #if(MS_COLOR_TEMP_COUNT ==4)
                case MS_COLOR_TEMP_USER:
                    u16TempID=en_str_ColorTemp_User;
                    break;
            #endif
            }

	}

	if(hwnd == HWND_FACTORY_MENU_CUS_LIST_ITEM25_VALUE)
		{
			gFactoryBLTBackLITtimeback=gFactoryBLTBackLITtime+msAPI_Timer_DiffTimeFromNow(gFactoryBLTBackLITtimeback1)/1000;

			      CHAR_BUFFER[0] = '0'+(gFactoryBLTBackLITtimeback/3600/10000);
                 		CHAR_BUFFER[1] = '0'+(gFactoryBLTBackLITtimeback/3600/1000%10);
                 		CHAR_BUFFER[2] = '0'+(gFactoryBLTBackLITtimeback/3600/100%10);
                 		CHAR_BUFFER[3] = '0'+(gFactoryBLTBackLITtimeback/3600/10%10);
                 		CHAR_BUFFER[4] = '0'+(gFactoryBLTBackLITtimeback/3600%10);
                		CHAR_BUFFER[5] = '.';
                 		CHAR_BUFFER[6] = '0'+(gFactoryBLTBackLITtimeback/60%60/10*1.5);
			      CHAR_BUFFER[7] = 'H';
			      CHAR_BUFFER[8] = 'r';
			      CHAR_BUFFER[9] = 's';
			      CHAR_BUFFER[10] = 0;
				return CHAR_BUFFER;
		}
if(hwnd == HWND_FACTORY_MENU_CUS_LIST_ITEM26_VALUE)
		{
	//gFactoryTotaltime=gFactoryTotaltimeback1+msAPI_Timer_GetTime0()/1000;
      				CHAR_BUFFER[0] = '0'+((gFactoryTotaltime+msAPI_Timer_GetTime0()/1000)/3600/10000);
                		CHAR_BUFFER[1] = '0'+((gFactoryTotaltime+msAPI_Timer_GetTime0()/1000)/3600/1000%10);
                		CHAR_BUFFER[2] = '0'+((gFactoryTotaltime+msAPI_Timer_GetTime0()/1000)/3600/100%10);
                		CHAR_BUFFER[3] = '0'+((gFactoryTotaltime+msAPI_Timer_GetTime0()/1000)/3600/10%10);
                		CHAR_BUFFER[4] = '0'+((gFactoryTotaltime+msAPI_Timer_GetTime0()/1000)/3600%10);
                		CHAR_BUFFER[5] = '.';
                 		CHAR_BUFFER[6] = '0'+((gFactoryTotaltime+msAPI_Timer_GetTime0()/1000)/60%60/10*1.5);
			      CHAR_BUFFER[7] = 'H';
			      CHAR_BUFFER[8] = 'r';
			      CHAR_BUFFER[9] = 's';
			      CHAR_BUFFER[10] = 0;
				return CHAR_BUFFER;
		}
if( hwnd == HWND_FACTORY_MENU_CUS_LIST_ITEM27_VALUE)
		{
           MApp_UlongToU16String(stGenSetting.g_SysSetting.u8Backlight, CHAR_BUFFER, (S8)MApp_GetNoOfDigit(stGenSetting.g_SysSetting.u8Backlight));
           return CHAR_BUFFER;
		}
if(hwnd == HWND_FACTORY_MENU_CUS_LIST_ITEM28_VALUE)
		{
			if(g_bFactoryLanguageBack==LANGUAGE_ENGLISH)
	  			 u16TempID=en_strMenuLanguageEnglishText;
	   		else
	   	         u16TempID=en_strMenuLanguageChineseText;
		}
// cus_xm gary 201206011 modify by factory menu source end

//======================================================
// cus_xm chuxu.su 20120725 add for hotel menu items value
#if CUS_SMC_ENABLE_HOTEL_MODE
	if( hwnd == HWND_HOTEL_MENU_NEW_PW)///value1 0K
		{
		U8 u16Value = 0;
		for(u16Value = 0; u16Value < PASSWORD_SIZE; u16Value++)
		{
			if(u16Value < g_u8PasswordCount)
				CHAR_BUFFER[u16Value] = '*';
			else
				CHAR_BUFFER[u16Value] = ' ';
		}
		CHAR_BUFFER[PASSWORD_SIZE] = 0;
		return CHAR_BUFFER;
		}
	if( hwnd == HWND_HOTEL_MENU_OLD_PW)///value1 0K
		{
		U8 u16Value = 0;
		for(u16Value = 0; u16Value < PASSWORD_SIZE; u16Value++)
		{
			if(u16Value < g_u8PasswordCount)
				CHAR_BUFFER[u16Value] = '*';
			else
				CHAR_BUFFER[u16Value] = ' ';
		}
		CHAR_BUFFER[PASSWORD_SIZE] = 0;
		return CHAR_BUFFER;
		}
	
	if( hwnd == HWND_HOTEL_MENU_CHECK_NEW_PW)///value1 0K
		{
		U8 u16Value = 0;
		for(u16Value = 0; u16Value < PASSWORD_SIZE; u16Value++)
		{
			if(u16Value < g_u8PasswordCount)
				CHAR_BUFFER[u16Value] = '*';
			else
				CHAR_BUFFER[u16Value] = ' ';
		}
		CHAR_BUFFER[PASSWORD_SIZE] = 0;
		return CHAR_BUFFER;
		}
	if( hwnd == HWND_HOTEL_MENU_ITEM_HOTEL_MODE_OPERATION_VALUE)///value1 0K
	    {
			if(stGenSetting.g_FactorySetting.HotelMenuHotelModeOperationEnable == DISABLE)
	 			u16TempID = en_str_Off;
			else if(stGenSetting.g_FactorySetting.HotelMenuHotelModeOperationEnable == ENABLE)
				u16TempID = en_str_On;
	    }
	if( hwnd == HWND_HOTEL_MENU_ITEM_MAX_VOLUME_SETTING_VALUE)///value2 ==ok
		{
			return MApp_ZUI_API_GetU16String(stGenSetting.g_FactorySetting.HotelMenuMaxVolumeSetting);
		}
	if( hwnd == HWND_HOTEL_MENU_ITEM_VOLUME_DEFAULT_VALUE)///value3 ==ok
	    {
			return MApp_ZUI_API_GetU16String(stGenSetting.g_FactorySetting.HotelMenuVolumeDefault);
	    }
	if( hwnd == HWND_HOTEL_MENU_ITEM_OSD_DISPLAY_VALUE)///value4 ok
	    {
			if(stGenSetting.g_FactorySetting.HotelMenuOSDDisplayEnableBack == DISABLE)
	 			u16TempID = en_str_On;
			else if(stGenSetting.g_FactorySetting.HotelMenuOSDDisplayEnableBack == ENABLE)
				u16TempID = en_str_Off;
	    }
	if( hwnd == HWND_HOTEL_MENU_ITEM_LOCAL_KEY_LOCK_VALUE)///value5 ok 2012-08-08
	    {
			if(stGenSetting.g_SysSetting.g_enKeyPadLock == EN_E5_KeyLock_Off)
			//if(stGenSetting.g_FactorySetting.HotelMenuLocalKeyLockEnable == DISABLE)
	 			u16TempID = en_str_Off;
			else if(stGenSetting.g_SysSetting.g_enKeyPadLock== EN_E5_KeyLock_On)
			//else if(stGenSetting.g_FactorySetting.HotelMenuLocalKeyLockEnable == ENABLE)
				u16TempID = en_str_On;
	    }
	if( hwnd == HWND_HOTEL_MENU_ITEM_REMOTE_CONTROL_LOCK_VALUE)///value6 ok
	    {
			if(stGenSetting.g_FactorySetting.HotelMenuRometeControlLockEnableBack == DISABLE)
	 			u16TempID = en_str_Off;
			else if(stGenSetting.g_FactorySetting.HotelMenuRometeControlLockEnableBack == ENABLE)
				u16TempID = en_str_On;
	    }
	if( hwnd == HWND_HOTEL_MENU_ITEM_CHANNEL_DEFAULT_VALUE)///value7 ==ok
	    {
			return MApp_ZUI_API_GetU16String(stGenSetting.g_FactorySetting.HotelMenuChannelDefault);
	    }
	if( hwnd == HWND_HOTEL_MENU_ITEM_INPUT_SOURCE_CHANGE_VALUE)///value8*****ok 2012-08-03
		{
			u16TempID = _MApp_ZUI_ACT_GetHOTELMODEINPUTSourceStringID(stGenSetting.g_FactorySetting.HotelMenuInputSourceChange);
		}
	if( hwnd == HWND_HOTEL_MENU_ITEM_USB_CLONE_VALUE)///value9 *****ok
	    {
			if(stGenSetting.g_FactorySetting.HotelMenuUSBCloneMode == HotelMenuUsbCloneModeOFF)
	 			u16TempID = en_str_Off;
			else if(stGenSetting.g_FactorySetting.HotelMenuUSBCloneMode == HotelMenuUsbCloneModeUSBTOTV)
				u16TempID = en_str_Hotel_Menu_USB_Clone_Mode_USBTOTV;
			else if(stGenSetting.g_FactorySetting.HotelMenuUSBCloneMode == HotelMenuUsbCloneModeTVTOUSB)
				u16TempID = en_str_Hotel_Menu_USB_Clone_Mode_TVTOUSB;
	    }
	if( hwnd == HWND_HOTEL_MENU_ITEM_AQ_PQ_RESTORE_VALUE)///value10 ok
	    {
			if(stGenSetting.g_FactorySetting.HotelMenuAQPQRestoreEnable== DISABLE)
	 			u16TempID = en_str_Off;
			else if(stGenSetting.g_FactorySetting.HotelMenuAQPQRestoreEnable== ENABLE)
				u16TempID = en_str_On;
	    }
	if( hwnd == HWND_HOTEL_MENU_ITEM_INSTALLATION_VALUE)///value11 ==ok
	    {
			//return MApp_ZUI_API_GetU16String(stGenSetting.g_FactorySetting.HotelMenuInstallation);
			if(stGenSetting.g_FactorySetting.HotelMenuInstallation== DISABLE)
	 			u16TempID = en_str_Off;
			else if(stGenSetting.g_FactorySetting.HotelMenuInstallation== ENABLE)
				u16TempID = en_str_On;
	    }
	if( hwnd == HWND_HOTEL_MENU_ITEM_SOURCE_KEY_LOCK_VALUE)///value12 ok
	    {
			if(stGenSetting.g_FactorySetting.HotelMenuSourceKeyLockEnable== DISABLE)
	 			u16TempID = en_str_Off;
			else if(stGenSetting.g_FactorySetting.HotelMenuSourceKeyLockEnable== ENABLE)
				u16TempID = en_str_On;
	    }
	if( hwnd == HWND_HOTEL_MENU_ITEM_POWERON_LOGO_VALUE)
		{
   #if (ENABLE_DMP)
		switch(stGenSetting.g_SysSetting.UsrLogo)
		{
			 case POWERON_LOGO_OFF:
				 u16TempID = en_str_DMP_AB_NONE;
				break;
			 case POWERON_LOGO_DEFAULT:
				  u16TempID = en_str_DEFAULT;
				break;
			 case POWERON_LOGO_USER:
				 u16TempID = en_str_Capture_Logo1;
				break;
			 default:
				 u16TempID = en_str_Off;
				break;
		}
   #endif
		}
	if( hwnd == HWND_HOTEL_MENU_ITEM_CAPTURE_LOGO_VALUE)///value12 ok
	    {
	       if(u8CapturelogoNG)
		   	u16TempID = en_str_USB_capture_NG;
		   else
		   	u16TempID = en_str_Button_OK;

		   u8CapturelogoNG=0;
			//if(stGenSetting.g_FactorySetting.HotelCaptureLogo== DISABLE)
	 		//	u16TempID = en_str_Off;
			//else if(stGenSetting.g_FactorySetting.HotelCaptureLogo== ENABLE)
			//	u16TempID = en_str_On;
	    }
	
	if( hwnd == HWND_HOTEL_MENU_ITEM_DEFAULT_LANGUAGE_VALUE)///value8*****ok 2012-08-03
		{
		u16TempID = _MApp_ZUI_ACT_GetLanguageStringID(stGenSetting.g_FactorySetting.HotelMenuLanguage, TRUE);
		}
	
	if( hwnd == HWND_HOTEL_MENU_ITEM_POWER_ON_VALUE)///value13 ***0k 2012-08-03
		{
			if(stGenSetting.g_FactorySetting.u8PowerOnMode == POWERON_MODE_OFF)//standby
				{
					u16TempID=en_str_Hotel_Menu_Power_On_Mode_Standby;
				}
			else if(stGenSetting.g_FactorySetting.u8PowerOnMode == POWERON_MODE_ON)//on
				{
					u16TempID=en_str_Hotel_Menu_Power_On_Mode_On;
				}
			else if(stGenSetting.g_FactorySetting.u8PowerOnMode == POWERON_MODE_SAVE)//last status
				{
					u16TempID=en_str_Hotel_Menu_Power_On_Mode_Last_Status;
				}
		}
	if(hwnd == HWND_HOTEL_MENU_VOLUME_SUBPAGE_TEXT)//volume setting:return HOTEL_MENU_VOLUME_SUBPAGE_TEXT ===ok
		{
			if(prePictureHWND == HWND_HOTEL_MENU_ITEM_MAX_VOLUME_SETTING)
				{
					u16TempID = en_str_Max_Volume_Setting;
				}
			else if(prePictureHWND == HWND_HOTEL_MENU_ITEM_VOLUME_DEFAULT)
				{
					u16TempID = en_str_Volume_Default;
				}
		}
	if(hwnd == HWND_HOTEL_MENU_VOLUME_SUBPAGE_VALUE)//volume setting:return HOTEL_MENU_VOLUME_SUBPAGE_VALUE ===ok
		{
			if(prePictureHWND == HWND_HOTEL_MENU_ITEM_MAX_VOLUME_SETTING)
				{
					return MApp_ZUI_API_GetU16String(stGenSetting.g_FactorySetting.HotelMenuMaxVolumeSetting);
				}
			else if(prePictureHWND == HWND_HOTEL_MENU_ITEM_VOLUME_DEFAULT)
				{
					return MApp_ZUI_API_GetU16String(stGenSetting.g_FactorySetting.HotelMenuVolumeDefault);
				}
		}
#endif
// cus_xm chuxu.su 20120725 add for hotel menu items value end
//=======================================================

//cus_xm zb add get CSM menu items value

if( hwnd == HWND_CSM_SET_TYPE_DT)
    	{
 	 	char ptr_head[128];
         	strcpy(ptr_head, SWModeName);
         	return MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, (U8 *)ptr_head, strlen(ptr_head));
    	}
if( hwnd == HWND_CSM_PROD_CODE_DT)
    	{
    	 	char ptr_head[19];
            #ifdef ENABLE_CUS_SERIAL_NUMBER
         	strcpy(ptr_head, (char *)stGenSettingExt.g_astSerialNumber.u8SerialNumber);
            #endif
         	return MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, (U8 *)ptr_head, strlen(ptr_head));
 		//u16TempID=en_str_CSM_DATA;
    	}

if( hwnd == HWND_CSM_KEY_VALID)
    	{
         //MS_U8 HDCPKey[HDCP_KEY_SIZE];
	  BOOL isValid;

         //HDCPKey=GetHDCPKey();
	  isValid=MApp_ZUI_ACT_isHdcpValid();
	  if(isValid==TRUE)
	  	u16TempID=en_str_CSM_KEY_VALID;
	  else
	  	u16TempID=en_str_CSM_KEY_INVALID;

    	}

if( hwnd == HWND_CSM_NVM_NAME_DT)
    	{
 		  	char ptr_head[128];
                    strcpy(ptr_head, SWPanelType);
                    return MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, (U8 *)ptr_head, strlen(ptr_head));
}
if( hwnd == HWND_CSM_SOFT_VERSION_DT)
    	{
 		  	char ptr_head[128];
                    strcpy(ptr_head, SWMainMCUVer );
                    return MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, (U8 *)ptr_head, strlen(ptr_head));
}

if( hwnd == HWND_CSM_RS232_OFF)
    	{
 		    	if(mdrv_uart_get_connection(E_UART_PORT0) == E_UART_OFF)
 				u16TempID = en_str_CSM_RS232_OFF;
			else
				u16TempID = en_str_CSM_RS232_ON;
    	}

if( hwnd == HWND_CSM_TV_REGION_CT)
    	{
 		    	if(g_bRegionEnable == FALSE)
 				u16TempID = en_str_CSM_TV_REGION_CT;
			else
				u16TempID = en_str_CSM_TV_REGION_CT;
    	}

//cus_xm zb add get CSM menu items value  end

    //step3: item name
    if(_eFactoryMenuPage == EN_FACTORY_PAGE_QMAP_PAGE )
    {
        U8 u8IPIdx, u8IPNum;

        u8IPIdx = ((_u8IPIndex/(COUNTOF(_FactoryMenuItemHwndList)))*(COUNTOF(_FactoryMenuItemHwndList)))+u8Item;
        u8IPNum = _u8IPNumber;
        if(u8IPIdx < u8IPNum)
        {
            //printf("================= IP:%u [%s]\n", u8IPIdx, MDrv_PQ_GetIPName(u8IPIdx));
            return MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, (U8*)MDrv_PQ_GetIPName(u8IPIdx), 255);
        }
    }
    else
    {
        for (i = 0; i < COUNTOF(_FactoryMenuItem); i++)
        {
          #if(LOG_FACTORYMENU_SHOWITEM)
            if ((_FactoryMenuItem[i].eCurPage == _eFactoryMenuPage) && GET_FACTORYMENU_SHOWITEM(_FactoryMenuItem[i]) == u8Item)
          #else
            if (_FactoryMenuItem[i].eCurPage == _eFactoryMenuPage &&
                _FactoryMenuItem[i].u8ShowItem == u8Item)
          #endif
            {
                u16TempID = _FactoryMenuItem[i].u16StringID;
                break;
            }
        }
    }

END:
    if (u16TempID != Empty)
        return MApp_ZUI_API_GetString(u16TempID);
    return NULL; //for empty string
}

OSD_COLOR MApp_ZUI_ACT_GetFactorymenuDynamicColor(HWND hwnd, DRAWSTYLE_TYPE type, OSD_COLOR colorOriginal)
{
    UNUSED(type);
 #if ENABLE_AUTO_DQS_Factory
    BOOLEAN BIST_TEST_COLOR = FALSE;
    if(_eFactoryMenuPage == EN_FACTORY_PAGE_BIST_TEST)
    {
        if((_BIST_TEST_MODE == EN_BIST_TEST_UI_START)||
        ((u8DQSM0[0]==0x00)&&(_MApp_ZUI_ACT_FactoryMenuWindowMapToIndex(hwnd)<=5))
        ||((u8DQSM1[0]==0x00)&&(_MApp_ZUI_ACT_FactoryMenuWindowMapToIndex(hwnd)>5)))
            return colorOriginal;

        switch((U16)_MApp_ZUI_ACT_FactoryMenuWindowMapToIndex(hwnd))
        {
            case 1:
                if(u8DQSM0[2] < (u8DQSM0[0]+0x22))
                    BIST_TEST_COLOR = TRUE;
                break;
            case 2:
                if(u8DQSM0[2] < (u8DQSM0[0]+0x11))
                    BIST_TEST_COLOR = TRUE;
                break;
            case 3:
                if(u8DQSM0[2] < (u8DQSM0[0]+0x00))
                    BIST_TEST_COLOR = TRUE;
                break;
            case 4:
                if(u8DQSM0[0] < (u8DQSM0[1]+0x11))
                    BIST_TEST_COLOR = TRUE;
                break;
            case 5:
                if(u8DQSM0[0] < (u8DQSM0[1]+0x22))
                    BIST_TEST_COLOR = TRUE;
                break;
       #if ENABLE_MIU_1
            case 6:
                if(u8DQSM1[2] < (u8DQSM1[0]+0x22))
                    BIST_TEST_COLOR = TRUE;
                break;
            case 7:
                if(u8DQSM1[2] < (u8DQSM1[0]+0x11))
                    BIST_TEST_COLOR = TRUE;
                break;
            case 8:
                if(u8DQSM1[2] < (u8DQSM1[0]+0x00))
                    BIST_TEST_COLOR = TRUE;
                break;
            case 9:
                if(u8DQSM1[0] < (u8DQSM1[1]+0x11))
                    BIST_TEST_COLOR = TRUE;
                break;
            case 10:
                if(u8DQSM1[0] < (u8DQSM1[1]+0x22))
                    BIST_TEST_COLOR = TRUE;
                break;
       #endif
            default:
                break;
        }

        if(BIST_TEST_COLOR)
        {
            return FACTORY_MENU_CURRENT_TEXT_DISABLE_COLOR;
        }
        else
        {
            return colorOriginal;
        }
    }
#else
    UNUSED(hwnd);
#endif
    return colorOriginal;
}

/////////////////////////////////////////////////////////
// Customize Window Procedures
/////////////////////////////////////////////////////////

//*************************************************************************
//Function name:     MApp_ZUI_ACT_FactoryAdjustPanelSel
//Passing parameter: none
//Return parameter:  none
//Description:
//*************************************************************************
#if (ENABLE_FACTORY_PANEL_SEL)

void MApp_ZUI_ACT_FactoryAdjustPanelSel(BOOLEAN bInc)
{
     bInc = bInc;
     return;
}
void MApp_ZUI_ACT_FactoryAdjustProjectID(BOOLEAN bInc)
{
    g_ProjectID = (PROJECT_ID_TYPE)MApp_ZUI_ACT_DecIncValue_Cycle(
                        bInc,g_ProjectID, 0, PJ_MAX_PROJECT_ID - 1, 1);
    g_PNL_TypeSel = (PANEL_RESOLUTION_TYPE)PJ_PanelID;
    stGenSetting.g_SysSetting.enPanelResType = (PANEL_RESOLUTION_TYPE)g_ProjectID;
    //MApp_SaveSysSetting();

    return;
}

void MApp_ZUI_ACT_GetProjectName(BYTE ProjectID, BYTE * buffer)
{
    BYTE i;

    if (buffer == NULL)
       return;

    for (i = 0; i < PROJECT_NAME_LENGTH; i++)
        buffer[i] = tProjectData[ProjectID].ProjectName[i];

}
#endif // ENABLE_FACTORY_PANEL_SEL

#if  ENABLE_SZ_FACTORY_USB_SAVE_MAP_FUNCTION
#define BankAddr   "BANK.txt"
U16 u16ScriptPos=0;
U8 newfiname[50]={0};
U8 u8ScripData [MPLAYER_TEXT_PLAYLIST_LEN]= {0};

BOOLEAN MApp_SaveRegister_LoadScript(U16 *pu16Data)
{

    U32 Msbank=0;
    U32 fileBank=0;
    U32 u16ScriptLen=0;
    U32 ScriptDelayms=0;
    U8 u8stringNum = 0;
    U8 u8RegisterString[20] = {0};
    U16 BankNum =0;
    U16 Map_Bankaddr=0;
    U16* u16singalWord=0;
    U16 u16readBytedata=0;
    BOOLEAN flag=FALSE;
    LoadNewfile=FALSE;

    u16ScriptLen= strlen((char*)pu16Data);
    memcpy((void*)u8ScripData, (void*)pu16Data, u16ScriptLen);
    memset(pu16Data, 0, MP4_SUBTITLE_BUFFER_LEN);
    for(u16ScriptPos=0; u16ScriptPos<u16ScriptLen; u16ScriptPos++)
    {
        MAPP_SaveRegister_SaveNotWord(u16ScriptLen, pu16Data);

        for(u8stringNum=0; (u16ScriptPos<u16ScriptLen) && (((u8ScripData[u16ScriptPos]>=48) && (u8ScripData[u16ScriptPos]<=57)) || ((u8ScripData[u16ScriptPos]>=65) && (u8ScripData[u16ScriptPos]<=90)) || ((u8ScripData[u16ScriptPos]>=97) && (u8ScripData[u16ScriptPos]<=122))); u8stringNum++, u16ScriptPos++)
        {

            *u16singalWord = u8ScripData[u16ScriptPos];
            strcat((char *)pu16Data, (char*)u16singalWord);
            u8RegisterString[u8stringNum] = u8ScripData[u16ScriptPos];
        }
        if (UTL_strncmp( (char*)u8RegisterString, "rriu", u8stringNum)==0 )
        {

            for(flag=FALSE; (flag==FALSE) && (u16ScriptPos < u16ScriptLen); u16ScriptPos++)
            {

                if((u8ScripData[u16ScriptPos] == 45)||((u8ScripData[u16ScriptPos]>=48) && (u8ScripData[u16ScriptPos]<=57)) || ((u8ScripData[u16ScriptPos]>=65) && (u8ScripData[u16ScriptPos]<=90)) || ((u8ScripData[u16ScriptPos]>=97) && (u8ScripData[u16ScriptPos]<=122)))//if(u8ScripData[u16ScriptPos]!=32 && u16ScriptPos<u16ScriptLen &&u8ScripData[u16ScriptPos]!=13 && u8ScripData[u16ScriptPos]!=10)//(u8ScripData[u16ScriptPos]>=48)||(u8ScripData[u16ScriptPos]<=57)||(u8ScripData[u16ScriptPos]>=65)||(u8ScripData[u16ScriptPos]<=90)||(u8ScripData[u16ScriptPos]>=97)||(u8ScripData[u16ScriptPos]<=122)
                {
                    flag = TRUE;
                    u16ScriptPos--;
                }
                else
                {
                    *u16singalWord = u8ScripData[u16ScriptPos];
                    strcat((char *)pu16Data, (char*)u16singalWord);
                }
            }

            for(u8stringNum=0;(u16ScriptPos<u16ScriptLen) && (u8ScripData[u16ScriptPos]==45 || ((u8ScripData[u16ScriptPos]>=48) && (u8ScripData[u16ScriptPos]<=57)) || ((u8ScripData[u16ScriptPos]>=65) && (u8ScripData[u16ScriptPos]<=90)) || ((u8ScripData[u16ScriptPos]>=97) && (u8ScripData[u16ScriptPos]<=122))); u8stringNum++, u16ScriptPos++)
            {
                *u16singalWord = u8ScripData[u16ScriptPos];
                strcat((char *)pu16Data, (char*)u16singalWord);
                u8RegisterString[u8stringNum] = u8ScripData[u16ScriptPos];
            }
            if(UTL_strncmp( (char*)u8RegisterString, "-c", u8stringNum)==0)
            {
                printf("Enter rriu -c!!\n\n\n");
                MAPP_SaveRegister_SaveNotWord(u16ScriptLen, pu16Data);
                for(u8stringNum=0; (u16ScriptPos<u16ScriptLen) && (((u8ScripData[u16ScriptPos]>=48) && (u8ScripData[u16ScriptPos]<=57)) || ((u8ScripData[u16ScriptPos]>=65) && (u8ScripData[u16ScriptPos]<=90)) || ((u8ScripData[u16ScriptPos]>=97) && (u8ScripData[u16ScriptPos]<=122))); u8stringNum++, u16ScriptPos++)
                {
                    *u16singalWord = u8ScripData[u16ScriptPos];
                    strcat((char *)pu16Data, (char*)u16singalWord);
                    u8RegisterString[u8stringNum] = u8ScripData[u16ScriptPos];
                }
			     if((u8stringNum ==10) &&  u8RegisterString[0] == '0'  && u8RegisterString[1] == 'x' )
				 {
                MAPP_SaveRegister_ASCIIToBankadr(u8RegisterString);
                MAPP_SaveRegister_SaveNotWord(u16ScriptLen, pu16Data);

	                for(u8stringNum=0;(u16ScriptPos<u16ScriptLen) && (((u8ScripData[u16ScriptPos]>=48) && (u8ScripData[u16ScriptPos]<=57)) || ((u8ScripData[u16ScriptPos]>=65) && (u8ScripData[u16ScriptPos]<=90)) || ((u8ScripData[u16ScriptPos]>=97) && (u8ScripData[u16ScriptPos]<=122))); u8stringNum++, u16ScriptPos++)
                {
                    *u16singalWord = u8ScripData[u16ScriptPos];
                    strcat((char *)pu16Data, (char*)u16singalWord);
                    u8RegisterString[u8stringNum] = u8ScripData[u16ScriptPos];
                }

                 for(Map_Bankaddr = 0, BankNum=0; (u8stringNum)>0; u8stringNum--)
                 {

                      fileBank=MAPP_SaveRegister_ASCIIToU16string(u8RegisterString[u8stringNum-1]);
                      for(Msbank=0;Msbank<BankNum;Msbank++)
                      {
                          fileBank *= 10;
                      }
                      Map_Bankaddr = Map_Bankaddr + fileBank;
                      BankNum++;
                 }
                 BankNum = Map_Bankaddr;
                 strcat((char *)pu16Data, "  Value: 0x");
                 MainBank = (MainBank<<8);
                 MDrv_WriteByte(MainBank, (SubBank>>8));
                 Msbank = ((SubBank<<24)>>24);

                 for(;(BankNum>=1) && (Msbank <0xFF);BankNum--, Msbank++)
                 {

                     u16readBytedata = MDrv_ReadByte((MainBank) |Msbank );
                     strcat((char *)pu16Data, (char*)(MApp_ZUI_API_GetU16HexString(u16readBytedata>>4)));
                     u16readBytedata = u16readBytedata<<12;
                     u16singalWord=MApp_ZUI_API_GetU16HexString(u16readBytedata);
                     strcat((char *)pu16Data, (char*)u16singalWord);
                 }

                 MainBank = (MainBank>>8);
                 SubBank = (SubBank>>8);
                 strcat((char *)pu16Data, "\r\n");
	              }
				    else
				    {
				        strcat((char *)pu16Data, "\r\nError Word!");
				        return TRUE;
				    }
                 printf("====End to rriu -c!!====\n\n\n");
            }
            else if(UTL_strncmp( (char*)u8RegisterString, "-d", u8stringNum)==0)
            {
                printf("Enter rriu -d!!\n\n\n");
                MAPP_SaveRegister_SaveNotWord(u16ScriptLen, pu16Data);

                for(u8stringNum=0; (u16ScriptPos<u16ScriptLen) && (((u8ScripData[u16ScriptPos]>=48) && (u8ScripData[u16ScriptPos]<=57)) || ((u8ScripData[u16ScriptPos]>=65) && (u8ScripData[u16ScriptPos]<=90)) || ((u8ScripData[u16ScriptPos]>=97) && (u8ScripData[u16ScriptPos]<=122))); u8stringNum++, u16ScriptPos++)
                {

                    *u16singalWord = u8ScripData[u16ScriptPos];
                    strcat((char *)pu16Data, (char*)u16singalWord);
                    u8RegisterString[u8stringNum] = u8ScripData[u16ScriptPos];
                }
			     if((u8stringNum ==10) &&  u8RegisterString[0] == '0'  && u8RegisterString[1] == 'x' )
				 {
                MAPP_SaveRegister_ASCIIToBankadr(u8RegisterString);
                MAPP_SaveRegister_SaveNotWord(u16ScriptLen, pu16Data);
	                for(u8stringNum=0 ; (u16ScriptPos<u16ScriptLen) && (((u8ScripData[u16ScriptPos]>=48) && (u8ScripData[u16ScriptPos]<=57)) || ((u8ScripData[u16ScriptPos]>=65) && (u8ScripData[u16ScriptPos]<=90)) || ((u8ScripData[u16ScriptPos]>=97) && (u8ScripData[u16ScriptPos]<=122))); u8stringNum++, u16ScriptPos++)
                {

                    *u16singalWord = u8ScripData[u16ScriptPos];
                    strcat((char *)pu16Data, (char*)u16singalWord);
                    u8RegisterString[u8stringNum] = u8ScripData[u16ScriptPos];
                    printf("u8RegisterString[%d] = %d\n", u8stringNum, u8RegisterString[u8stringNum] );
                }
                    if(u8RegisterString[0] == '0'  && u8RegisterString[1] == 'x' )
					  {
                 u8stringNum--;
                 for(Map_Bankaddr = 0, BankNum=0; u8stringNum>=2; u8stringNum--)
                 {

                      fileBank=MAPP_SaveRegister_ASCIIToU16string(u8RegisterString[u8stringNum]);
                      for(Msbank=0;Msbank<BankNum;Msbank++)
                      {
                          fileBank *= 16;
                      }
                      Map_Bankaddr = Map_Bankaddr + fileBank;
                      BankNum++;
                 }
                 BankNum = Map_Bankaddr;
                 printf("BankNum=%d\n", BankNum);
                 MainBank = (MainBank<<8);
                 MDrv_WriteByte(MainBank, (SubBank>>8));
                 //MainBank = (MainBank>>8);                             //????  modify
                 Msbank = ((SubBank<<24)>>24);
                 //MainBank = MainBank<<8;                                //????  modify
                 for(fileBank=0; (BankNum>=1) && (Msbank <=0xFF); BankNum--, Msbank++, fileBank++)
                 {
                     if(fileBank%16==0)
                     {
                         strcat((char *)pu16Data, "\r\n-0x");
                         if(fileBank!=0)
                             SubBank+=0x10;
                         MainBank = MainBank>>8;
                         for(u8stringNum=4;u8stringNum>=1;u8stringNum--)
                         {

                             Map_Bankaddr = (((U16)MainBank>>((u8stringNum-1)*4))<<12);
                             strcat((char *)pu16Data, (char*)(MApp_ZUI_API_GetU16HexString(Map_Bankaddr)));

                         }
                         MainBank = MainBank<<8;
                         for(u8stringNum=4;u8stringNum>=1;u8stringNum--)
                         {
                             Map_Bankaddr =(((U16)SubBank>>((u8stringNum-1)*4))<<12);
                             strcat((char *)pu16Data, (char*)(MApp_ZUI_API_GetU16HexString(Map_Bankaddr)));

                         }
                     }
                     strcat((char *)pu16Data, " 0x");
                     u16readBytedata = MDrv_ReadByte((MainBank) |Msbank );
                     strcat((char *)pu16Data, (char*)(MApp_ZUI_API_GetU16HexString(u16readBytedata>>4)));
                     u16readBytedata = u16readBytedata<<12;
                     u16singalWord=MApp_ZUI_API_GetU16HexString(u16readBytedata);
                     strcat((char *)pu16Data, (char*)u16singalWord);

                 }
                 MainBank = MainBank >>8;
                 strcat((char *)pu16Data, "\r\n");
	                 }
				       else
				       {
				           strcat((char *)pu16Data, "\r\nError Word!");
				           return TRUE;
				       }
	              }
				    else
				    {
				        strcat((char *)pu16Data, "\r\nError Word!");
				        return TRUE;
				    }
                 printf("====End to rriu -d!!====\n\n\n");

            }
            else if(u8RegisterString[0]==48)
            {
                 printf("u8RegisterString[0]==48!\n");
			       if((u8stringNum ==10) &&  u8RegisterString[0] == '0'  && u8RegisterString[1] == 'x' )
			 	   {
                 MAPP_SaveRegister_ASCIIToBankadr(u8RegisterString);
                 strcat((char *)pu16Data, "   Value: 0x");
                 MainBank = (MainBank<<8);
                 MDrv_WriteByte(MainBank, (SubBank>>8));
                 Msbank = ((SubBank<<24)>>24);
                 u16readBytedata = MDrv_ReadByte((MainBank) |Msbank );
                 strcat((char *)pu16Data, (char*)(MApp_ZUI_API_GetU16HexString(u16readBytedata>>4)));
                 u16readBytedata = u16readBytedata<<12;
                 u16singalWord=MApp_ZUI_API_GetU16HexString(u16readBytedata);
                 strcat((char *)pu16Data, (char*)u16singalWord);
                 MainBank = (MainBank>>8);
                 strcat((char *)pu16Data, "\r\n");
					}
				    else
				    {
				        strcat((char *)pu16Data, "\r\nError Word!");
				        return TRUE;
				    }
                 printf("====End to rriu u8RegisterString!!====\n\n\n");
            }
            else
            {
				  strcat((char *)pu16Data, "\r\nError Word!");
                printf("Error sigal!\n");
                return TRUE;
            }
            SubBank = (SubBank>>8);          //////////????
        }
        else if(UTL_strncmp( (char*)u8RegisterString, "rsdr", u8stringNum)==0 )
        {
            printf("strcmp(u8RegisterString, rsdr)==0!\n");
            LoadNewfile=MApp_SaveRegister_NewFile(pu16Data,u16ScriptLen);
            printf("====End to rsdr!!====\n\n\n");
            strcat((char *)pu16Data, "\r\n");
        }
        else if(UTL_strncmp( (char*)u8RegisterString, "wriu", u8stringNum)==0 )
        {
            printf("strcmp(u8RegisterString, wriu)==0!\n");
            for(flag=FALSE; (flag==FALSE) && (u16ScriptPos < u16ScriptLen); u16ScriptPos++)
            {

                if((u8ScripData[u16ScriptPos] == 45)||((u8ScripData[u16ScriptPos]>=48) && (u8ScripData[u16ScriptPos]<=57)) || ((u8ScripData[u16ScriptPos]>=65) && (u8ScripData[u16ScriptPos]<=90)) || ((u8ScripData[u16ScriptPos]>=97) && (u8ScripData[u16ScriptPos]<=122)))//if(u8ScripData[u16ScriptPos]!=32 && u16ScriptPos<u16ScriptLen &&u8ScripData[u16ScriptPos]!=13 && u8ScripData[u16ScriptPos]!=10)//(u8ScripData[u16ScriptPos]>=48)||(u8ScripData[u16ScriptPos]<=57)||(u8ScripData[u16ScriptPos]>=65)||(u8ScripData[u16ScriptPos]<=90)||(u8ScripData[u16ScriptPos]>=97)||(u8ScripData[u16ScriptPos]<=122)
                {
                    flag = TRUE;
                    u16ScriptPos--;
                }
                else
                {
                    *u16singalWord = u8ScripData[u16ScriptPos];
                    strcat((char *)pu16Data, (char*)u16singalWord);
                }
            }
            for(u8stringNum=0;(u16ScriptPos<u16ScriptLen) && ((u8ScripData[u16ScriptPos]==45) ||((u8ScripData[u16ScriptPos]>=48) && (u8ScripData[u16ScriptPos]<=57)) || ((u8ScripData[u16ScriptPos]>=65) && (u8ScripData[u16ScriptPos]<=90)) || ((u8ScripData[u16ScriptPos]>=97) && (u8ScripData[u16ScriptPos]<=122))); u8stringNum++, u16ScriptPos++)
            {
                *u16singalWord = u8ScripData[u16ScriptPos];
                strcat((char *)pu16Data, (char*)u16singalWord);
                u8RegisterString[u8stringNum] = u8ScripData[u16ScriptPos];
            }

            if(UTL_strncmp( (char*)u8RegisterString, "-b", u8stringNum)==0 )
            {
                printf("strcmp((char*)u8RegisterString, -b, u8stringNum)==0!\n");
                if(!MApp_WriteRegister_byte(pu16Data, u16ScriptLen))
                    return TRUE;
                printf("====End to wriu -b!!====\n\n\n");
            }
            else if(UTL_strncmp( (char*)u8RegisterString, "-m", u8stringNum)==0 )
            {
                printf("strcmp(UTL_strncmp( (char*)u8RegisterString, -m, u8stringNum)==0!\n");
                if(!MApp_WriteRegister_multibyte(pu16Data,u16ScriptLen))
                    return TRUE;
                printf("====End to wriu -m!!====\n\n\n");

            }
            else if(UTL_strncmp( (char*)u8RegisterString, "-w", u8stringNum)==0 )
            {
                printf("strcmp( (char*)u8RegisterString, -w, u8stringNum)==0!\n");
                if(!MApp_WriteRegister_WordData(pu16Data, u16ScriptLen))
                    return TRUE;
                printf("====End to wriu -w!!====\n\n\n");
            }
            else if(u8RegisterString[0]==48)
            {
                printf("u8RegisterString[0]==48!\n");
                if((u8stringNum ==10) &&  u8RegisterString[0] == '0'  && u8RegisterString[1] == 'x' )
	             {

                MAPP_SaveRegister_ASCIIToBankadr(u8RegisterString);
                MAPP_SaveRegister_SaveNotWord(u16ScriptLen, pu16Data);

	                for(u8stringNum=0; (u16ScriptPos<u16ScriptLen) && (((u8ScripData[u16ScriptPos]>=48) && (u8ScripData[u16ScriptPos]<=57)) || ((u8ScripData[u16ScriptPos]>=65) && (u8ScripData[u16ScriptPos]<=90)) || ((u8ScripData[u16ScriptPos]>=97) && (u8ScripData[u16ScriptPos]<=122))); u8stringNum++, u16ScriptPos++)
                {
                    *u16singalWord = u8ScripData[u16ScriptPos];
                    strcat((char *)pu16Data, (char*)u16singalWord);
                    u8RegisterString[u8stringNum] = u8ScripData[u16ScriptPos];
                }
                   if((u8stringNum ==4) && u8RegisterString[0] == '0'  && u8RegisterString[1] == 'x' )
                   {
                 for(u8stringNum=2,Map_Bankaddr=0; u8stringNum<=3; u8stringNum++)
                 {
                     if(u8stringNum==2)
                         Map_Bankaddr = MAPP_SaveRegister_ASCIIToU16string(u8RegisterString[u8stringNum]);
                     else
                         Map_Bankaddr = (Map_Bankaddr <<4)|MAPP_SaveRegister_ASCIIToU16string(u8RegisterString[u8stringNum]);
                 }
                //read first value
                strcat((char *)pu16Data, "   Before Value: 0x");
                MainBank = (MainBank<<8);
                MDrv_WriteByte(MainBank, (SubBank>>8));
                Msbank = ((SubBank<<24)>>24);
                u16readBytedata = MDrv_ReadByte((MainBank) |Msbank );
                strcat((char *)pu16Data, (char*)(MApp_ZUI_API_GetU16HexString(u16readBytedata>>4)));
                u16readBytedata = u16readBytedata<<12;
                u16singalWord=MApp_ZUI_API_GetU16HexString(u16readBytedata);
                strcat((char *)pu16Data, (char*)u16singalWord);
                //write
		                strcat((char *)pu16Data, "   Final Value: 0x");
                fileBank = (MainBank | ((SubBank<<24)>>24));
                MDrv_WriteByte(fileBank, Map_Bankaddr);
                //read again
                u16readBytedata = MDrv_ReadByte((MainBank) | ((SubBank<<24)>>24));
                strcat((char *)pu16Data, (char*)(MApp_ZUI_API_GetU16HexString(u16readBytedata>>4)));
                u16readBytedata = u16readBytedata<<12;
                u16singalWord=MApp_ZUI_API_GetU16HexString(u16readBytedata);
                strcat((char *)pu16Data, (char*)u16singalWord);
                printf("End  to  u8RegisterString[0]==48!\n\n\n");
                MainBank = (MainBank>>8);
                SubBank = (SubBank>>8);
                    }
				     else
				     {
				         strcat((char *)pu16Data, "\r\nError Word!");
				         return TRUE;
				     }
	            }
			     else
			     {

			         strcat((char *)pu16Data, "\r\nError Word!");
			         return TRUE;
			     }
           }
	        else
	        {
	            strcat((char *)pu16Data, "\r\nEEROR WORD!");
	            printf("With Some Error words !\n");
	            return TRUE;
	        }
            printf("====End to wriu!!====\n\n\n");
            strcat((char *)pu16Data, "\r\n");

        }
        else if(UTL_strncmp( (char*)u8RegisterString, "wait", u8stringNum)==0 )
        {
            printf("strcmp(u8RegisterString, wait)==0!\n");
            MAPP_SaveRegister_SaveNotWord(u16ScriptLen, pu16Data);

            for(u8stringNum=0;(u16ScriptPos<u16ScriptLen) && (((u8ScripData[u16ScriptPos]>=48) && (u8ScripData[u16ScriptPos]<=57)) || ((u8ScripData[u16ScriptPos]>=65) && (u8ScripData[u16ScriptPos]<=90)) || ((u8ScripData[u16ScriptPos]>=97) && (u8ScripData[u16ScriptPos]<=122))); u8stringNum++, u16ScriptPos++)
            {

                *u16singalWord = u8ScripData[u16ScriptPos];
                strcat((char *)pu16Data, (char*)u16singalWord);
                u8RegisterString[u8stringNum] = u8ScripData[u16ScriptPos];

            }
		     if(u8RegisterString[0] != '0')
			 {
            for(BankNum=0; BankNum<u8stringNum; BankNum++)
            {
                if(BankNum==0)
                    ScriptDelayms = MAPP_SaveRegister_ASCIIToU16string(u8RegisterString[BankNum]);
                else
                    ScriptDelayms = ScriptDelayms*10+(MAPP_SaveRegister_ASCIIToU16string(u8RegisterString[BankNum]));

            }
            printf("ScriptDelayms=%d, %x\n\n", ScriptDelayms, ScriptDelayms);
            msAPI_Timer_Delayms(ScriptDelayms);
            printf("====End to wait!!====\n\n\n");
	            strcat((char *)pu16Data, "   Success!\r\n");
	        }
	        else
	        {
	            strcat((char *)pu16Data, "\r\nEEROR WORD!");
	            printf("With Some Error words !\n");
	            return TRUE;

	        }
        }

        else
        {
            strcat((char *)pu16Data, "\r\n\r\n");
            strcat((char *)pu16Data, "EEROR WORD!");
            printf("With Some Error words !\n");
            return TRUE;

        }

        for(flag=FALSE; flag==FALSE && u16ScriptPos < u16ScriptLen; u8stringNum++, u16ScriptPos++)
        {
            if(((u8ScripData[u16ScriptPos]>=48) && (u8ScripData[u16ScriptPos]<=57)) || ((u8ScripData[u16ScriptPos]>=65) && (u8ScripData[u16ScriptPos]<=90)) || ((u8ScripData[u16ScriptPos]>=97) && (u8ScripData[u16ScriptPos]<=122)))//(u8ScripData[u16ScriptPos]!=32 && u16ScriptPos<u16ScriptLen &&u8ScripData[u16ScriptPos]!=13 && u8ScripData[u16ScriptPos]!=10)//(u8ScripData[u16ScriptPos]>=48)||(u8ScripData[u16ScriptPos]<=57)||(u8ScripData[u16ScriptPos]>=65)||(u8ScripData[u16ScriptPos]<=90)||(u8ScripData[u16ScriptPos]>=97)||(u8ScripData[u16ScriptPos]<=122)
            {
                flag = TRUE;
            }
            else
            {
                *u16singalWord = u8ScripData[u16ScriptPos];
                strcat((char *)pu16Data, (char*)u16singalWord);
            }
        }

        if(u16ScriptPos==u16ScriptLen)
            return TRUE;
        else
            u16ScriptPos=u16ScriptPos-2;

    }
    if(u16ScriptPos>=u16ScriptLen)
        return TRUE;
    else
        return FALSE;
    strcat((char *)pu16Data, "\r\n");
    printf("==End script!!!==\n\n\n");

}

void MAPP_SaveRegister_SaveNotWord(U16 u16ScriptLen, U16* pu16Data)
{
    BOOLEAN flag;
    U16 *u16singalWord = 0;
    for(flag=FALSE; (flag==FALSE) && (u16ScriptPos<u16ScriptLen); u16ScriptPos++)
    {

        if(((u8ScripData[u16ScriptPos]>=48) && (u8ScripData[u16ScriptPos]<=57)) || ((u8ScripData[u16ScriptPos]>=65) && (u8ScripData[u16ScriptPos]<=90)) || ((u8ScripData[u16ScriptPos]>=97) && (u8ScripData[u16ScriptPos]<=122)))//if(u8ScripData[u16ScriptPos]!=32 && u16ScriptPos<u16ScriptLen &&u8ScripData[u16ScriptPos]!=13 && u8ScripData[u16ScriptPos]!=10)//(u8ScripData[u16ScriptPos]>=48)||(u8ScripData[u16ScriptPos]<=57)||(u8ScripData[u16ScriptPos]>=65)||(u8ScripData[u16ScriptPos]<=90)||(u8ScripData[u16ScriptPos]>=97)||(u8ScripData[u16ScriptPos]<=122)
        {
            flag = TRUE;
            u16ScriptPos--;
         }
         else
         {
             *u16singalWord = u8ScripData[u16ScriptPos];
             strcat((char *)pu16Data, (char*)u16singalWord);
         }
    }
}

U16 MAPP_SaveRegister_ASCIIToU16string(U16 Value)
{
    if((Value>=48 && Value<=57)||(Value>=65 && Value<=90)||(Value>=97 && Value<=122))
    {
         if(Value>=48 && Value<=57)
         {
             Value=Value-0x30;
         }
         else if(Value>=65 && Value<=90)
         {
             Value=Value - 'A' + 0x0A;
         }
         else if(Value>=97 && Value<=122)
         {
             Value=Value - 'a' + 0x0A;
         }
         else
             printf("Error word !=-c=\n");

          return Value;
    }
    else
        return FALSE;

}

void MAPP_SaveRegister_ASCIIToBankadr(U8* u8RegisterString)
{

    U8 u8stringNum;
    U16 Map_Bankaddr;
    for(u8stringNum=2, Map_Bankaddr=0; u8stringNum<=9; u8stringNum++)
    {
        if(u8stringNum<=5)
        {
            if(u8stringNum==2)
                Map_Bankaddr = MAPP_SaveRegister_ASCIIToU16string(u8RegisterString[u8stringNum]);
            else
                Map_Bankaddr = (Map_Bankaddr<<4)|(MAPP_SaveRegister_ASCIIToU16string(u8RegisterString[u8stringNum]));
            MainBank=Map_Bankaddr;

         }
         else
         {
             if(u8stringNum==6)
                 Map_Bankaddr = MAPP_SaveRegister_ASCIIToU16string(u8RegisterString[u8stringNum]);
             else
                 Map_Bankaddr = (Map_Bankaddr<<4)|(MAPP_SaveRegister_ASCIIToU16string(u8RegisterString[u8stringNum]));
             SubBank=Map_Bankaddr;

          }
    }

}

BOOLEAN MApp_SaveRegister_NewFile(U16 *pu16Data, U32 filelen)
{
    U8 u8stringNum = 0;
    U8 u8RegisterString[20] = {0};
    U16 Msbank=0;
    U16 fileBank=0;
    U16 BankNum =0;
    U16* u16singalWord=0;
    U16 Map_Bankaddr=0;
    U16 u16readBytedata=0;

    printf("Enter rsdr!!\n\n\n");
    MAPP_SaveRegister_SaveNotWord(filelen, pu16Data);

    for(u8stringNum=0;(u16ScriptPos<filelen) && (((u8ScripData[u16ScriptPos]>=48) && (u8ScripData[u16ScriptPos]<=57)) || ((u8ScripData[u16ScriptPos]>=65) && (u8ScripData[u16ScriptPos]<=90)) || ((u8ScripData[u16ScriptPos]>=97) && (u8ScripData[u16ScriptPos]<=122))); u8stringNum++, u16ScriptPos++)
    {

        *u16singalWord = u8ScripData[u16ScriptPos];
        strcat((char *)pu16Data, (char*)u16singalWord);
        u8RegisterString[u8stringNum] = u8ScripData[u16ScriptPos];
    }
	 if((u8stringNum ==10) &&  u8RegisterString[0] == '0'  && u8RegisterString[1] == 'x' )
	 {
    MAPP_SaveRegister_ASCIIToBankadr(u8RegisterString);
    MAPP_SaveRegister_SaveNotWord(filelen, pu16Data);

	    for(u8stringNum=0;(u16ScriptPos<filelen) && (((u8ScripData[u16ScriptPos]>=48) && (u8ScripData[u16ScriptPos]<=57)) || ((u8ScripData[u16ScriptPos]>=65) && (u8ScripData[u16ScriptPos]<=90)) || ((u8ScripData[u16ScriptPos]>=97) && (u8ScripData[u16ScriptPos]<=122))); u8stringNum++, u16ScriptPos++)  ///2.16
    {

        *u16singalWord = u8ScripData[u16ScriptPos];
        strcat((char *)pu16Data, (char*)u16singalWord);
        u8RegisterString[u8stringNum] = u8ScripData[u16ScriptPos];

    }
	     if(u8RegisterString[0] != '0' )
		 {
     for(Map_Bankaddr = 0, BankNum=0; u8stringNum>0; u8stringNum--)
     {

          fileBank=MAPP_SaveRegister_ASCIIToU16string(u8RegisterString[u8stringNum-1]);
          for(Msbank=0;Msbank<BankNum;Msbank++)
          {
              fileBank *= 10;
          }
          Map_Bankaddr = Map_Bankaddr + fileBank;
          BankNum++;

     }

     MainBank = (MainBank<<8);
     MDrv_WriteByte(MainBank, (SubBank>>8));
     printf("MainBank = %d, %x\n", MainBank, MainBank);
     MainBank = (MainBank>>8);         //????
     Msbank = ((SubBank<<24)>>24);
     MainBank = MainBank<<8;           //????
     printf("MainBank = %d, %x\n", MainBank, MainBank);
     BankNum = Map_Bankaddr;
     for(fileBank=0;(BankNum>=1) && (Msbank <=0xFF);BankNum--, Msbank++, fileBank++)
     {
         if(fileBank%16==0)
         {
             strcat((char *)pu16Data, "\r\n-0x");
             if(fileBank!=0)
                SubBank+=0x10;
             MainBank = MainBank>>8;
             for(u8stringNum=4;u8stringNum>=1;u8stringNum--)
             {
                 Map_Bankaddr = (((U16)MainBank>>((u8stringNum-1)*4))<<12);
                 strcat((char *)pu16Data, (char*)(MApp_ZUI_API_GetU16HexString(Map_Bankaddr)));
             }

             for(u8stringNum=4;u8stringNum>=1;u8stringNum--)
             {
                 Map_Bankaddr =(((U16)SubBank>>((u8stringNum-1)*4))<<12);
                 strcat((char *)pu16Data, (char*)(MApp_ZUI_API_GetU16HexString(Map_Bankaddr)));
             }
             MainBank = MainBank<<8;
         }

         strcat((char *)pu16Data, " 0x");
         u16readBytedata = MDrv_ReadByte((MainBank) |Msbank );
         strcat((char *)pu16Data, (char*)(MApp_ZUI_API_GetU16HexString(u16readBytedata>>4)));
         u16readBytedata = u16readBytedata<<12;
         u16singalWord = MApp_ZUI_API_GetU16HexString(u16readBytedata);
         strcat((char *)pu16Data, (char*)u16singalWord);
     }

    strcat((char *)pu16Data, "\r\n");
    MAPP_SaveRegister_SaveNotWord(filelen, pu16Data);

    memset(newfiname, 0, sizeof(newfiname));
		    for(u8stringNum=0 ;(u16ScriptPos<filelen) && ((u8ScripData[u16ScriptPos]==46) || ((u8ScripData[u16ScriptPos]>=48) && (u8ScripData[u16ScriptPos]<=57)) || ((u8ScripData[u16ScriptPos]>=65) && (u8ScripData[u16ScriptPos]<=90)) || ((u8ScripData[u16ScriptPos]>=97) && (u8ScripData[u16ScriptPos]<=122))); u8stringNum++, u16ScriptPos++)
    {

        *u16singalWord = u8ScripData[u16ScriptPos];
        strcat((char *)pu16Data, (char*)u16singalWord);
        u8RegisterString[u8stringNum] = u8ScripData[u16ScriptPos];
        newfiname[u8stringNum]=u8ScripData[u16ScriptPos];

    }
     MAPP_SaveRegister_SaveNotWord(filelen, pu16Data);
     MainBank = MainBank >>8;
     SubBank = SubBank>>8;
	     }
        else
        {
            strcat((char *)pu16Data, "\r\nError Word!");
            return FALSE;
        }
	  }
      else
      {
          strcat((char *)pu16Data, "\r\nError Word!");
          return FALSE;
      }

     printf("End to rsdr !!\n\n\n");
     return TRUE;

}

BOOLEAN MApp_WriteRegister_byte(U16 *pu16Data, U32 filelen)
{
    U8 Rmask;
    U8 Rvalue;
    U8 Msbank=0;
    U8 u8stringNum = 0;
    U8 u8RegisterString[20] = {0};
    U16 fileBank=0;
    U16 *u16singalWord=0;
    U16 u16readBytedata=0;

     printf("MApp_WriteRegister_byte!\n");
     MAPP_SaveRegister_SaveNotWord(filelen, pu16Data);
     for(u8stringNum=0;(u16ScriptPos<filelen) && (((u8ScripData[u16ScriptPos]>=48) && (u8ScripData[u16ScriptPos]<=57)) || ((u8ScripData[u16ScriptPos]>=65) && (u8ScripData[u16ScriptPos]<=90)) || ((u8ScripData[u16ScriptPos]>=97) && (u8ScripData[u16ScriptPos]<=122))); u8stringNum++, u16ScriptPos++)
     {

         *u16singalWord = u8ScripData[u16ScriptPos];
         strcat((char *)pu16Data, (char*)u16singalWord);
         u8RegisterString[u8stringNum] = u8ScripData[u16ScriptPos];
      }
      if((u8stringNum ==10) &&  u8RegisterString[0] == '0'  && u8RegisterString[1] == 'x' )
	  {
      MAPP_SaveRegister_ASCIIToBankadr(u8RegisterString);
      MAPP_SaveRegister_SaveNotWord(filelen, pu16Data);

	      for(u8stringNum=0;(u16ScriptPos<filelen) &&  (((u8ScripData[u16ScriptPos]>=48) && (u8ScripData[u16ScriptPos]<=57)) || ((u8ScripData[u16ScriptPos]>=65) && (u8ScripData[u16ScriptPos]<=90)) || ((u8ScripData[u16ScriptPos]>=97) && (u8ScripData[u16ScriptPos]<=122))); u8stringNum++, u16ScriptPos++)
     {

         *u16singalWord = u8ScripData[u16ScriptPos];
         strcat((char *)pu16Data, (char*)u16singalWord);
         u8RegisterString[u8stringNum] = u8ScripData[u16ScriptPos];
      }
		  if((u8stringNum ==4) &&  u8RegisterString[0] == '0'  && u8RegisterString[1] == 'x' )
	     {
     for(u8stringNum=2,Rmask=0; u8stringNum<=3; u8stringNum++)
     {
         fileBank=MAPP_SaveRegister_ASCIIToU16string(u8RegisterString[u8stringNum]);
         if(u8stringNum==2)
             Rmask=fileBank;
         else
             Rmask = (Rmask<<4)|fileBank;
     }
     MAPP_SaveRegister_SaveNotWord(filelen, pu16Data);

		     for(u8stringNum=0;(u16ScriptPos<filelen) &&  (((u8ScripData[u16ScriptPos]>=48) && (u8ScripData[u16ScriptPos]<=57)) || ((u8ScripData[u16ScriptPos]>=65) && (u8ScripData[u16ScriptPos]<=90)) || ((u8ScripData[u16ScriptPos]>=97) && (u8ScripData[u16ScriptPos]<=122))); u8stringNum++, u16ScriptPos++)
     {

         *u16singalWord = u8ScripData[u16ScriptPos];
         strcat((char *)pu16Data, (char*)u16singalWord);
         u8RegisterString[u8stringNum] = u8ScripData[u16ScriptPos];
      }
            if((u8stringNum == 4) &&  u8RegisterString[0] == '0'  && u8RegisterString[1] == 'x' )
	        {
     for(u8stringNum=2,Rvalue=0; u8stringNum<=3; u8stringNum++)
     {

         fileBank=MAPP_SaveRegister_ASCIIToU16string(u8RegisterString[u8stringNum]);
         if(u8stringNum==2)
             Rvalue=fileBank;
         else
             Rvalue= (Rvalue<<4)|fileBank;

     }
     strcat((char *)pu16Data, "   Before Value: 0x");
     MainBank = (MainBank<<8);
     MDrv_WriteByte(MainBank, (SubBank>>8));
     Msbank = ((SubBank<<24)>>24);
     u16readBytedata = MDrv_ReadByte((MainBank) |Msbank );
     strcat((char *)pu16Data, (char*)(MApp_ZUI_API_GetU16HexString(u16readBytedata>>4)));
     u16readBytedata = u16readBytedata<<12;
     u16singalWord=MApp_ZUI_API_GetU16HexString(u16readBytedata);
     strcat((char *)pu16Data, (char*)u16singalWord);

    MDrv_WriteByteMask((MainBank|Msbank), Rmask, Rvalue);
     strcat((char *)pu16Data, "   Final Value: 0x");
     u16readBytedata = MDrv_ReadByte((MainBank) |Msbank );
     strcat((char *)pu16Data, (char*)(MApp_ZUI_API_GetU16HexString(u16readBytedata>>4)));
     u16readBytedata = u16readBytedata<<12;
     u16singalWord=MApp_ZUI_API_GetU16HexString(u16readBytedata);
     strcat((char *)pu16Data, (char*)u16singalWord);
     printf("End  to  MApp_WriteRegister_byte!\n\n\n");
     MainBank = (MainBank>>8);
     SubBank = (SubBank>>8);
	         }
            else
            {

                strcat((char *)pu16Data, "\r\nError Word!");
                return FALSE;
            }
	     }
	     else
	     {

	         strcat((char *)pu16Data, "\r\nError Word!");
	         return FALSE;
	     }
	 }
     else
     {

         strcat((char *)pu16Data, "\r\nError Word!");
         return FALSE;
     }
     return TRUE;
}

BOOLEAN MApp_WriteRegister_multibyte(U16 *pu16Data, U32 filelen)
{
    U8 temp;
    U8 Rvalue;
    U8 Msbank=0;
    U8 u8stringNum = 0;
    U8 u8RegisterString[20] = {0};
    U32 fileBank=0;
    U16 BankNum =0;
    U16 Map_Bankaddr;
    U16 *u16singalWord=0;
    U16 u16readBytedata=0;

     printf("\nMApp_WriteRegister_multibyte!\n\n");
     MAPP_SaveRegister_SaveNotWord(filelen, pu16Data);
     for(u8stringNum=0;(u16ScriptPos<filelen) && (((u8ScripData[u16ScriptPos]>=48) && (u8ScripData[u16ScriptPos]<=57)) || ((u8ScripData[u16ScriptPos]>=65) && (u8ScripData[u16ScriptPos]<=90)) || ((u8ScripData[u16ScriptPos]>=97) && (u8ScripData[u16ScriptPos]<=122))); u8stringNum++, u16ScriptPos++)
     {

         *u16singalWord= u8ScripData[u16ScriptPos];
         strcat((char *)pu16Data, (char*)u16singalWord);
         u8RegisterString[u8stringNum] = u8ScripData[u16ScriptPos];
      }
     if((u8stringNum ==10) &&  u8RegisterString[0] == '0'  && u8RegisterString[1] == 'x' )
 	 {
      MAPP_SaveRegister_ASCIIToBankadr(u8RegisterString);

     MainBank = (MainBank<<8);
     MDrv_WriteByte(MainBank, (SubBank>>8));
     Msbank = ((SubBank<<24)>>24);

     MAPP_SaveRegister_SaveNotWord(filelen, pu16Data);
	     for(u8stringNum=0;(u16ScriptPos<filelen) && (((u8ScripData[u16ScriptPos]>=48) && (u8ScripData[u16ScriptPos]<=57)) || ((u8ScripData[u16ScriptPos]>=65) && (u8ScripData[u16ScriptPos]<=90)) || ((u8ScripData[u16ScriptPos]>=97) && (u8ScripData[u16ScriptPos]<=122))); u8stringNum++, u16ScriptPos++)
     {

         *u16singalWord = u8ScripData[u16ScriptPos];
         strcat((char *)pu16Data, (char*)u16singalWord);
         u8RegisterString[u8stringNum] = u8ScripData[u16ScriptPos];
     }

      for(BankNum=0,*u16singalWord=0;u8stringNum>0;u8stringNum--, (*u16singalWord)++)
      {
          fileBank=MAPP_SaveRegister_ASCIIToU16string(u8RegisterString[u8stringNum-1]);
          if(*u16singalWord==0)
              BankNum = fileBank;
          else
              BankNum += fileBank*10;
      }
	     MAPP_SaveRegister_SaveNotWord(filelen, pu16Data);

	     for(; BankNum>0 && ((SubBank<<24)>>24)<=0xFF; BankNum--, Msbank++)        //modify by chj 0503
     {
         strcat((char *)pu16Data, "\r\n");
	          strcat((char *)pu16Data, "0x");
	          MainBank = MainBank >> 8;
				for(temp=4;temp>=1;temp--)
				{
				    Map_Bankaddr = (((U16)MainBank>>((temp-1)*4))<<12);
				    strcat((char *)pu16Data, (char*)(MApp_ZUI_API_GetU16HexString(Map_Bankaddr)));

				}
	          MainBank = MainBank << 8;
				for(temp=4;temp>=1;temp--)
				{
				    Map_Bankaddr =(((U16)SubBank>>((temp-1)*4))<<12);
				    strcat((char *)pu16Data, (char*)(MApp_ZUI_API_GetU16HexString(Map_Bankaddr)));

				}
	           strcat((char *)pu16Data, "   ");

              for(u8stringNum=0;(u16ScriptPos<filelen) && (((u8ScripData[u16ScriptPos]>=48) && (u8ScripData[u16ScriptPos]<=57)) || ((u8ScripData[u16ScriptPos]>=65) && (u8ScripData[u16ScriptPos]<=90)) || ((u8ScripData[u16ScriptPos]>=97) && (u8ScripData[u16ScriptPos]<=122))); u8stringNum++, u16ScriptPos++)
         {

             *u16singalWord= u8ScripData[u16ScriptPos];
             strcat((char *)pu16Data, (char*)u16singalWord);
             u8RegisterString[u8stringNum] = u8ScripData[u16ScriptPos];
          }
	          if((u8stringNum ==4) &&  u8RegisterString[0] == '0'  && u8RegisterString[1] == 'x')
	          {
	             printf("u8stringNum ==4");
          for(u8stringNum=2,Rvalue=0; u8stringNum<=3; u8stringNum++)
          {
              fileBank=MAPP_SaveRegister_ASCIIToU16string(u8RegisterString[u8stringNum]);
              if(u8stringNum==2)
                  Rvalue=fileBank;
              else
                  Rvalue= (Rvalue<<4)|fileBank;
          }

          strcat((char *)pu16Data, "   Before Value: 0x");
          MDrv_WriteByte(MainBank, (SubBank>>8));
          u16readBytedata = MDrv_ReadByte((MainBank) |Msbank );
          strcat((char *)pu16Data, (char*)(MApp_ZUI_API_GetU16HexString(u16readBytedata>>4)));
          u16readBytedata = u16readBytedata<<12;
          u16singalWord=MApp_ZUI_API_GetU16HexString(u16readBytedata);
          strcat((char *)pu16Data, (char*)u16singalWord);

          fileBank = (MainBank | ((SubBank<<24)>>24));
          MDrv_WriteByte(fileBank, Rvalue);
		          msAPI_Timer_Delayms(5);
          strcat((char *)pu16Data, "    Final Value: 0x");
          u16readBytedata = MDrv_ReadByte((MainBank) |Msbank );//////
          strcat((char *)pu16Data, (char*)(MApp_ZUI_API_GetU16HexString(u16readBytedata>>4)));
          u16readBytedata = u16readBytedata<<12;
          u16singalWord=MApp_ZUI_API_GetU16HexString(u16readBytedata);
          strcat((char *)pu16Data, (char*)u16singalWord);
          strcat((char *)pu16Data, "\r\n");
          SubBank+=0x01;
	             MAPP_SaveRegister_SaveNotWord(filelen, pu16Data);
		          printf("SubBank=%d,%x\n", SubBank, SubBank);
	          }
			   else
			   {
			       strcat((char *)pu16Data, "\r\nError Word!");
			       return FALSE;
			   }
       }

      MainBank = (MainBank>>8);
      SubBank = (SubBank>>8);
      }
      else
      {
          strcat((char *)pu16Data, "\r\nError Word!");
          return FALSE;
      }
      return TRUE;
      printf("End  to  MApp_WriteRegister_multibyte!\n\n\n");
}


BOOLEAN MApp_WriteRegister_WordData(U16 *pu16Data, U32 filelen)
{

    U8 temp;
    U8 Msbank=0;
    U8 u8stringNum = 0;
    U8 u8RegisterString[20] = {0};
    U16 Rmask;
    U16 Rvalue;
    U16 BankNum =0;
    U16 Map_Bankaddr;
    U8  *u8singalWord = 0;
    U16 *u16singalWord=0;
    U16 u16readBytedata=0;
    U32 fileBank=0;

    printf("\nMApp_WriteRegister_WordData!\n\n");
    MAPP_SaveRegister_SaveNotWord(filelen, pu16Data);

    for(u8stringNum=0;(u16ScriptPos<filelen) && (((u8ScripData[u16ScriptPos]>=48) && (u8ScripData[u16ScriptPos]<=57)) || ((u8ScripData[u16ScriptPos]>=65) && (u8ScripData[u16ScriptPos]<=90)) || ((u8ScripData[u16ScriptPos]>=97) && (u8ScripData[u16ScriptPos]<=122))); u8stringNum++, u16ScriptPos++)
    {
       //printf("u8ScripData[%d] = %d, u8stringNum=%d\n", u16ScriptPos, u8ScripData[u16ScriptPos], u8stringNum);
       *u8singalWord = u8ScripData[u16ScriptPos];
       strcat((char *)pu16Data, (char*)u8singalWord);
       u8RegisterString[u8stringNum] = u8ScripData[u16ScriptPos];

    }
    if((u8stringNum ==10) &&  u8RegisterString[0] == '0'  && u8RegisterString[1] == 'x' )
	 {
	    printf("u8stringNum ==10\n");
    MAPP_SaveRegister_ASCIIToBankadr(u8RegisterString);
    MainBank = (MainBank<<8);
    MDrv_WriteByte(MainBank, (SubBank>>8));

    Msbank = ((SubBank<<24)>>24);
    MAPP_SaveRegister_SaveNotWord(filelen, pu16Data);

	    for(u8stringNum=0;(u16ScriptPos<filelen) && (((u8ScripData[u16ScriptPos]>=48) && (u8ScripData[u16ScriptPos]<=57)) || ((u8ScripData[u16ScriptPos]>=65) && (u8ScripData[u16ScriptPos]<=90)) || ((u8ScripData[u16ScriptPos]>=97) && (u8ScripData[u16ScriptPos]<=122))); u8stringNum++, u16ScriptPos++)
    {
           printf("u8ScripData[%d] = %d, u8stringNum=%d\n", u16ScriptPos, u8ScripData[u16ScriptPos], u8stringNum);
	        *u8singalWord = u8ScripData[u16ScriptPos];
	        strcat((char *)pu16Data, (char*)u8singalWord);
        u8RegisterString[u8stringNum] = u8ScripData[u16ScriptPos];
     }
        if((u8stringNum == 6) &&  (u8RegisterString[0] == '0')  && (u8RegisterString[1] == 'x') )
	     {

     for(u8stringNum=2,Rvalue=0; u8stringNum<=5; u8stringNum++)
     {

         if(u8stringNum==2)
             Rvalue=MAPP_SaveRegister_ASCIIToU16string(u8RegisterString[u8stringNum]);
         else
             Rvalue= (Rvalue<<4)|MAPP_SaveRegister_ASCIIToU16string(u8RegisterString[u8stringNum]);
     }
     strcat((char *)pu16Data, "\r\n");
     MDrv_WriteByte(MainBank, (SubBank>>8));
		     for(BankNum=0; BankNum<2 && ((SubBank<<24)>>24)<=0xFF; BankNum++)
		     {

					strcat((char *)pu16Data, "0x");
		          MainBank = MainBank >> 8;
		         for(temp=4;temp>=1;temp--)
		         {
					   Map_Bankaddr = (((U16)MainBank>>((temp-1)*4))<<12);
					   strcat((char *)pu16Data, (char*)(MApp_ZUI_API_GetU16HexString(Map_Bankaddr)));

		         }
		         MainBank = MainBank << 8;
		         for(temp=4;temp>=1;temp--)
     {
					   Map_Bankaddr =(((U16)SubBank>>((temp-1)*4))<<12);
					   strcat((char *)pu16Data, (char*)(MApp_ZUI_API_GetU16HexString(Map_Bankaddr)));

		         }
		         strcat((char *)pu16Data, " ");

         strcat((char *)pu16Data, "  Before Value: 0x");
         u16readBytedata = MDrv_ReadByte((MainBank) |Msbank );
         strcat((char *)pu16Data, (char*)(MApp_ZUI_API_GetU16HexString(u16readBytedata>>4)));
         u16readBytedata = u16readBytedata<<12;
         u16singalWord=MApp_ZUI_API_GetU16HexString(u16readBytedata);
         strcat((char *)pu16Data, (char*)u16singalWord);
         fileBank = (MainBank | ((SubBank<<24)>>24));
         Rmask = ((Rvalue<<8)>>8);
         MDrv_WriteByte(fileBank, Rmask);
         strcat((char *)pu16Data, "   Final Value: 0x");
                msAPI_Timer_Delayms(10);
         u16readBytedata = MDrv_ReadByte((MainBank) |Msbank );
         strcat((char *)pu16Data, (char*)(MApp_ZUI_API_GetU16HexString(u16readBytedata>>4)));
         u16readBytedata = u16readBytedata<<12;
         u16singalWord=MApp_ZUI_API_GetU16HexString(u16readBytedata);
         strcat((char *)pu16Data, (char*)u16singalWord);
         strcat((char *)pu16Data, "\r\n");
         Msbank+=0x01;
         SubBank+=0x01;
         Rvalue=(Rvalue>>8);
      }
	      }
          else
          {
              printf("-----1-----ERROR !\n");
              strcat((char *)pu16Data, "\r\nError Word!");
              return FALSE;
          }
      MainBank = (MainBank>>8);
      SubBank = (SubBank>>8);
	   }
      else
      {
          printf("-----2-----ERROR !\n");
          strcat((char *)pu16Data, "\r\nError Word!");
          return FALSE;
      }
      return TRUE;
      printf("End  to  MApp_WriteRegister_WordData!\n\n\n");

}

void MApp_SaveRegisger_OneBank(U16 *pu16Data)
{
    U8 Map_addr = 0;
    U16 Map_Bankaddr=0;
    U16 *u16singalWord=0;
    U16 u16readBytedata=0;

    strcat((char *)pu16Data, "BANK 0x");
    for(u16ScriptPos=4;u16ScriptPos>=1;u16ScriptPos--)
    {
        Map_Bankaddr = (((U16)MainBank>>((u16ScriptPos-1)*4))<<12);
        strcat((char *)pu16Data, (char*)(MApp_ZUI_API_GetU16HexString(Map_Bankaddr)));

    }

    if(AllBank==1 && LoadScript==FALSE)
       strcat((char *)pu16Data, "\r\nSub-BANK 0x");

    for(u16ScriptPos=2;u16ScriptPos>=1;u16ScriptPos--)
    {
        Map_Bankaddr =(((U16)SubBank>>((u16ScriptPos-1)*4))<<12);
        strcat((char *)pu16Data, (char*)(MApp_ZUI_API_GetU16HexString(Map_Bankaddr)));

    }
    strcat((char *)pu16Data, "\r\n");

    for(u16ScriptPos=0; u16ScriptPos<=5; u16ScriptPos++)
    {
         *u16singalWord = '-';
         strcat((char *)pu16Data, (char*)u16singalWord);
    }

    for(Map_addr=0; Map_addr<=15; Map_addr++)
    {
        strcat((char *)pu16Data, "0");
        strcat((char *)pu16Data, (char*)(MApp_ZUI_API_GetU16HexString(Map_addr)));
        *u16singalWord = '-';
        strcat((char *)pu16Data, (char*)u16singalWord);
        if(Map_addr==7 )
            strcat((char *)pu16Data, "|");
        if(Map_addr!=15)
            strcat((char *)pu16Data, (char*)u16singalWord);
    }
    strcat((char *)pu16Data, "\r\n");
    for(u16ScriptPos=0; u16ScriptPos<=69; u16ScriptPos++)
    {
        *u16singalWord = '-';
        strcat((char *)pu16Data, (char*)u16singalWord);
    }
    strcat((char *)pu16Data, "\r\n");
    MainBank = (MainBank<<8);
    MDrv_WriteByte(MainBank, SubBank);
    Map_addr = 0;
    for(u16ScriptPos=0;u16ScriptPos<=255;u16ScriptPos++)
    {
        if(u16ScriptPos%16 == 0)
        {
            if(u16ScriptPos != 0)
                strcat((char *)pu16Data, "\r\n");
             strcat((char *)pu16Data, "-");
             strcat((char *)pu16Data, (char*)(MApp_ZUI_API_GetU16HexString(Map_addr)));
             strcat((char *)pu16Data, "0-");
             Map_addr ++;
         }
         strcat((char *)pu16Data, " ");
         if(u16ScriptPos%8==0 && u16ScriptPos%16!=0 )
             strcat((char *)pu16Data, "|");
         strcat((char *)pu16Data, " ");
         u16readBytedata = MDrv_ReadByte((MainBank) | (u16ScriptPos));
         strcat((char *)pu16Data, (char*)(MApp_ZUI_API_GetU16HexString(u16readBytedata>>4)));
         u16readBytedata = u16readBytedata<<12;
         u16singalWord=MApp_ZUI_API_GetU16HexString(u16readBytedata);
         strcat((char *)pu16Data, (char*)u16singalWord);

      }
      strcat((char *)pu16Data, "\r\n");
}

BOOLEAN MApp_SaveRegister_Database(void)
{
    U16 *pu16Data;
    U16 u16FileName[50];
    U16 Map_Bankaddr=0;
    U16 *u16singalWord=0;
    U8 u8HandleNo;
    U8 u8DFileName[50] = {0};
    U8 u8FileName[10] = BankAddr;
    static FileEntry g_fileEntry;
    LoadNewfile = FALSE;

    while (!MDrv_UsbDeviceConnect())
    {
        H_MSG(printf("\n init USB__fail \n"););
        LoadNewfile = FALSE;
        LoadScript = FALSE;
        AllBank = FALSE;
        return FALSE;
    }
    U8 u8PortEnStatus = MDrv_USBGetPortEnableStatus();
    if((u8PortEnStatus & BIT0) == BIT0)
    {
        H_MSG( printf("u8PortEnStatus=%d  BIT0!",u8PortEnStatus););
        MApp_UsbSaveData_SetPort(BIT0);
    }
    else if((u8PortEnStatus & BIT1) == BIT1)
    {
        H_MSG(printf("u8PortEnStatus=%d  BIT1!",u8PortEnStatus););
        MApp_UsbSaveData_SetPort(BIT1);
    }
    else
    {
        H_MSG(printf("Error> Unknown USB port\n"););
        LoadNewfile = FALSE;
        LoadScript = FALSE;
        AllBank = FALSE;
        return FALSE;
    }

    if (!MApp_UsbSaveData_InitFileSystem())
    {
        MApp_UsbSaveData_Exit();
        LoadNewfile = FALSE;
        LoadScript = FALSE;
        AllBank = FALSE;
        H_MSG(printf("Exit"););
        return FALSE;
    }

    pu16Data = (U16*)_PA2VA(((MP4_SUBTITLE_BUFFER_MEMORY_TYPE & MIU1) ? (MP4_SUBTITLE_BUFFER_ADR | MIU_INTERVAL) : (MP4_SUBTITLE_BUFFER_ADR)));

    memset(pu16Data, 0, MP4_SUBTITLE_BUFFER_LEN);
    if(LoadScript==TRUE)
    {
  	    if (MApp_UsbSaveData_SearchFileInRoot((U8 *)u8FileName, &g_fileEntry))
	    {
		     u8HandleNo = msAPI_FCtrl_FileOpen(&g_fileEntry, OPEN_MODE_FOR_READ);

            if(u8HandleNo != FCTRL_INVALID_FILE_HANDLE)
            {
                msAPI_FCtrl_FileRead(u8HandleNo, _PA2VA(((MP4_SUBTITLE_BUFFER_MEMORY_TYPE & MIU1) ? (MP4_SUBTITLE_BUFFER_ADR | MIU_INTERVAL) : (MP4_SUBTITLE_BUFFER_ADR))), MP4_SUBTITLE_BUFFER_LEN);
                msAPI_FCtrl_FileClose(u8HandleNo);
                if(!MApp_SaveRegister_LoadScript( pu16Data))
                {
                    LoadNewfile = FALSE;
                    LoadScript = FALSE;
                    return FALSE;
                }
                strcat((char *)pu16Data, "\r\n");

            }
            else
            {
                LoadScript = FALSE;
                H_MSG(printf("Open file fail\n"));
    		      return FALSE;
            }

	    }
	    else
	    {
	       LoadScript = FALSE;
		    H_MSG(printf("database file is not exist\r\n"));
		    return FALSE;
	    }
   }

    u8DFileName[0] = 48;
    *u16singalWord = 'x';
    strcat((char *)u8DFileName, (char*)u16singalWord);
    for(u16ScriptPos=4;u16ScriptPos>=1;u16ScriptPos--)
    {
        Map_Bankaddr = (((U16)MainBank>>((u16ScriptPos-1)*4))<<12);
        strcat((char *)u8DFileName, (char*)(MApp_ZUI_API_GetU16HexString(Map_Bankaddr)));
    }
    for(u16ScriptPos=2;u16ScriptPos>=1;u16ScriptPos--)
    {
        Map_Bankaddr =(((U16)SubBank>>((u16ScriptPos-1)*4))<<12);
        strcat((char *)u8DFileName, (char*)(MApp_ZUI_API_GetU16HexString(Map_Bankaddr)));
    }
    strcat((char *)u8DFileName, ".txt");

    if (LoadNewfile==TRUE && LoadScript==TRUE)       //if (LoadNewfile==TRUE && LoadNewfile==TRUE)        modify by chj 0503
    {
        U8 filelen= strlen((char*)u8DFileName);
        memset(u8DFileName, 0, sizeof(u8DFileName));
        filelen= strlen((char*)newfiname);
        for(;filelen>=1;filelen--)
        {
            u8DFileName[filelen-1]=newfiname[filelen-1];
        }
        filelen= strlen((char*)u8DFileName);

    }
    else if(LoadScript==TRUE && LoadNewfile==FALSE)
    {
        memset(u8DFileName, 0, sizeof(u8DFileName));
        strcpy((char*)u8DFileName, "Script.txt");
    }
    else if(AllBank==TRUE && LoadScript==FALSE)
    {
        memset(u8DFileName, 0, sizeof(u8DFileName));
        strcpy((char*)u8DFileName, "Scaler Register.txt");
    }
    else
        printf("LoadScript is FALSE!\n");

    if(MApp_UsbSaveData_SearchFileInRoot((U8 *)u8DFileName, &g_fileEntry))
    {
        msAPI_FCtrl_FileDelete(&g_fileEntry);
        H_MSG(printf("Found and Deleted\n"););
    }
    else
    {
        H_MSG(printf("Not Found\n"););
    }

    ASCIItoUnicode2((S8*)u8DFileName, strlen((char *)u8DFileName));
    memset(u16FileName, 0, sizeof(u16FileName));
    memcpy(u16FileName, u8DFileName, sizeof(u16FileName));
    u8HandleNo = MApp_UsbSaveData_OpenNewFileForWrite((U16 *)u16FileName, UnicodeLen((S8*)u16FileName));
    H_MSG(printf("OpenForWrite Passed\n"););

    if(u8HandleNo != FCTRL_INVALID_FILE_HANDLE)
    {
        if(AllBank==FALSE && LoadScript==FALSE)
        {
            MApp_SaveRegisger_OneBank(pu16Data);
        }
        if(AllBank==TRUE)
        {
            for(MainBank=0x102F, SubBank=0x00; SubBank<=0x05; SubBank++)
            {
                strcat((char *)pu16Data, "Scaler Register \r\nBASE Address: ");
                MApp_SaveRegisger_OneBank(pu16Data);
                MainBank = (MainBank>>8);
                strcat((char *)pu16Data, "\r\n\r\n");
            }
        }
        msAPI_FCtrl_FileWrite(u8HandleNo, _PA2VA(((MP4_SUBTITLE_BUFFER_MEMORY_TYPE & MIU1) ? (MP4_SUBTITLE_BUFFER_ADR | MIU_INTERVAL) : (MP4_SUBTITLE_BUFFER_ADR))), strlen((char *)pu16Data));
        msAPI_FCtrl_FileClose(u8HandleNo);
        LoadNewfile = FALSE;
        LoadScript = FALSE;
        AllBank = FALSE;
        return TRUE;
    }
    else
    {
        printf("return false!\n");
        LoadNewfile = FALSE;
        LoadScript = FALSE;
        AllBank = FALSE;
        return FALSE;
    }
}

#endif   //ENABLE_SZ_FACTORY_USB_SAVE_MAP_FUNCTION

#ifdef ENABLE_CUS_FACTORY_ATV_CH_PRSET
#define MAX_PRESET_CH_NUM       100
typedef struct
{
    U32 u32Freq;
    U8  u8CHNum;
    AUDIOSTANDARD_TYPE     eAudioStandard;
    AVD_VideoStandardType  eVideoStandard;
} ATV_FACTORY_CH_PRESET;
//CUS_XM:xue add for preset channel table 2012-7-5
ATV_FACTORY_CH_PRESET code ATVFactoryCHPreset[] =
{
#if BOE_EDID_SET
   {
       49750, // 49.75MHz
       1,
       E_AUDIOSTANDARD_I,
       E_VIDEOSTANDARD_PAL_BGHI,
   },
   {
      61250, // 61.25MHz
       2,
   E_AUDIOSTANDARD_M,
   E_VIDEOSTANDARD_NTSC_M,
   
   },
   {
       85250, // 85.25MHz
       3,
       E_AUDIOSTANDARD_DK,
       E_VIDEOSTANDARD_PAL_BGHI,
   },
	{
		224250, // 224.25MHz
		4,
		E_AUDIOSTANDARD_BG,
		E_VIDEOSTANDARD_PAL_BGHI,
	},
	{
		253250, // 253.25MHz
		5,
	E_AUDIOSTANDARD_M,
	E_VIDEOSTANDARD_NTSC_M,

	},
	{
		294250, // 294.25MHz
		6,
		E_AUDIOSTANDARD_BG,
		E_VIDEOSTANDARD_PAL_BGHI,
	},
     {
       471250, // 471.25MHz
       7,
       E_AUDIOSTANDARD_DK,
       E_VIDEOSTANDARD_PAL_BGHI,
       },
      {
       695250, // 695.25MHz
       8,
	   E_AUDIOSTANDARD_DK,
	   E_VIDEOSTANDARD_SECAM,
      },
      {
       751250, // 751.25MHz
       9,
       E_AUDIOSTANDARD_I,
       E_VIDEOSTANDARD_PAL_BGHI,
      },
	 {
	  863250, // 863.25MHz
	   10,
	  E_AUDIOSTANDARD_DK,
	  E_VIDEOSTANDARD_PAL_BGHI,
	 },
#else
#if CUS_BRAND_ID == BRAND_ID_FOX
    {
        85250, // 85.25MHz
        1,
        E_AUDIOSTANDARD_DK,
        E_VIDEOSTANDARD_PAL_BGHI,
    },
    {
        471250, // 471.25MHz
        2,
        E_AUDIOSTANDARD_I,
        E_VIDEOSTANDARD_PAL_BGHI,
    },
    {
        735250, // 735.25MHz
        3,
        E_AUDIOSTANDARD_DK,
        E_VIDEOSTANDARD_PAL_BGHI,
    },
 #else
	//FQ
    {
        49750,//49.75Mhz
        1,
        E_AUDIOSTANDARD_DK,
        E_VIDEOSTANDARD_PAL_BGHI,
    },
    {
        119250,// 119.25Mhz
        2,
        E_AUDIOSTANDARD_BG,
        E_VIDEOSTANDARD_PAL_BGHI,
    },
    {
        184000,//184Mhz
        3,
        E_AUDIOSTANDARD_L,
        E_VIDEOSTANDARD_SECAM,
    },
    {
        217250,//217.25Mhz
        4,
        E_AUDIOSTANDARD_BG,
        E_VIDEOSTANDARD_PAL_BGHI,
    },
    {
        224250,//			224.25 PAL B/G
        5,
		E_AUDIOSTANDARD_BG,
		E_VIDEOSTANDARD_PAL_BGHI,

    },
    {
        280250,//			280.25 SECAM D/K
        6,
		E_AUDIOSTANDARD_DK,
		E_VIDEOSTANDARD_SECAM,

    },
    {
        304250,//304.25 PAL D/K
        7,
        E_AUDIOSTANDARD_DK,
        E_VIDEOSTANDARD_PAL_BGHI,
    },
    {
        335250,//335.25 PAL B/G
        8,
		E_AUDIOSTANDARD_BG,
		E_VIDEOSTANDARD_PAL_BGHI,

    },
    {
        360250,//360.25 SECAM D/K
        9,
		E_AUDIOSTANDARD_DK,
		E_VIDEOSTANDARD_SECAM,

    },
    {
        448250,//448.25 PAL D/K
        10,
		E_AUDIOSTANDARD_DK,
		E_VIDEOSTANDARD_PAL_BGHI,

    },
	{
		448250,//448.25 PAL D/K
		10,
		E_AUDIOSTANDARD_DK,
		E_VIDEOSTANDARD_PAL_BGHI,

	},
	{
		503250,//503.25 PAL I
		11,
		E_AUDIOSTANDARD_I,
		E_VIDEOSTANDARD_PAL_BGHI,

	},
	{
		527250,//527.25 PAL I
		12,
		E_AUDIOSTANDARD_I,
		E_VIDEOSTANDARD_PAL_BGHI,

	},
	{
		783250,//	783.25 PAL D/K
		13,
		E_AUDIOSTANDARD_DK,
		E_VIDEOSTANDARD_PAL_BGHI,

	},
	//SZ ZJ
	{
		55750,//55.75 SECAM L
		21,
		E_AUDIOSTANDARD_L,
		E_VIDEOSTANDARD_SECAM,

	},
	{
		64250,//64.25 PAL B/G
		22,
		E_AUDIOSTANDARD_BG,
		E_VIDEOSTANDARD_PAL_BGHI,

	},
	{
		119250,//119.25 PAL B/G
		23,
		E_AUDIOSTANDARD_BG,
		E_VIDEOSTANDARD_PAL_BGHI,

	},
	{
		184250,//184.25 PAL D/K
		24,
		E_AUDIOSTANDARD_DK,
		E_VIDEOSTANDARD_PAL_BGHI,

	},
	{
		209250,//209.25 PAL B/G
		25,
		E_AUDIOSTANDARD_BG,
		E_VIDEOSTANDARD_PAL_BGHI,
	},
	{
		223250,//223.25 SECAM D
		26,
		E_AUDIOSTANDARD_DK,
		E_VIDEOSTANDARD_SECAM,

	},
	{
		343250,//343.25 PAL I
		27,
		E_AUDIOSTANDARD_I,
		E_VIDEOSTANDARD_PAL_BGHI,

	},
	{
		471250,//		471.25 PAL D/K
		28,
		E_AUDIOSTANDARD_DK,
		E_VIDEOSTANDARD_PAL_BGHI,

	},
	{
		503250,//503.25 PAL I
		29,
		E_AUDIOSTANDARD_I,
		E_VIDEOSTANDARD_PAL_BGHI,

	},
	{
		527250,//527.25 PAL B/G
		30,
		E_AUDIOSTANDARD_BG,
		E_VIDEOSTANDARD_PAL_BGHI,

	},
	{
		548250,//548.25 SECAM B/G
		31,
		E_AUDIOSTANDARD_BG,
		E_VIDEOSTANDARD_SECAM,

	},
	{
		783250,//783.25 PAL D/K
		32,
		E_AUDIOSTANDARD_DK,
		E_VIDEOSTANDARD_PAL_BGHI,

	},
	//SZ SS
	{
		49750,//49.75 PAL D
		41,
		E_AUDIOSTANDARD_DK,
		E_VIDEOSTANDARD_PAL_BGHI,

	},
	{
		64250,//64.25 PAL D
		42,
		E_AUDIOSTANDARD_DK,
		E_VIDEOSTANDARD_PAL_BGHI,

	},
	{
		176250,//176.25 SECAM D
		43,
		E_AUDIOSTANDARD_DK,
		E_VIDEOSTANDARD_SECAM,

	},
	{
		196250,//196.25 PAL D
		44,
		E_AUDIOSTANDARD_DK,
		E_VIDEOSTANDARD_PAL_BGHI,

	},
	{
		209250,//209.25 PAL B
		45,
		E_AUDIOSTANDARD_BG,
		E_VIDEOSTANDARD_PAL_BGHI,

	},
	{
		223250,//223.25 SECAM D
		46,
		E_AUDIOSTANDARD_DK,
		E_VIDEOSTANDARD_SECAM,

	},
	{
		343250,//343.25 PAL D/K
		47,
		E_AUDIOSTANDARD_DK,
		E_VIDEOSTANDARD_PAL_BGHI,

	},
	{
		471250,//471.25 PAL D
		48,
		E_AUDIOSTANDARD_DK,
		E_VIDEOSTANDARD_PAL_BGHI,

	},
	{
		548250,//548.25 SECAM B/G
		49,
		E_AUDIOSTANDARD_BG,
		E_VIDEOSTANDARD_SECAM,

	},
	{
		590250,//590.25 PAL G
		50,
		E_AUDIOSTANDARD_BG,
		E_VIDEOSTANDARD_PAL_BGHI,

	},
	{
		783250,//783.25 PAL D/K
		51,
		E_AUDIOSTANDARD_DK,
		E_VIDEOSTANDARD_PAL_BGHI,

	},
	//����
	{
		615250,//615.25 PAL D/K
		88,
		E_AUDIOSTANDARD_DK,
		E_VIDEOSTANDARD_PAL_BGHI,

	},
	{
		231250,//231.25 PAL B/G
		89,
		E_AUDIOSTANDARD_BG,
		E_VIDEOSTANDARD_PAL_BGHI,

	},
	{
		455250,//455.25 PAL B/G
		90,
		E_AUDIOSTANDARD_BG,
		E_VIDEOSTANDARD_PAL_BGHI,

	},
	//NTSC
	{
		61250,//61.25MHz
		61,
		E_AUDIOSTANDARD_M,
		E_VIDEOSTANDARD_NTSC_M,

	},
	{
		77250,//77.25MHz
		62,
		E_AUDIOSTANDARD_M,
		E_VIDEOSTANDARD_NTSC_M,

	},
	{
		83250,//83.25MHz
		63,
		E_AUDIOSTANDARD_M,
		E_VIDEOSTANDARD_NTSC_M,

	},
	{
		91250,//91.25MHz
		64,
		E_AUDIOSTANDARD_M,
		E_VIDEOSTANDARD_NTSC_M,

	},
	{
		109250,//109.25MHz
		65,
		E_AUDIOSTANDARD_M,
		E_VIDEOSTANDARD_NTSC_M,

	},
	{
		126006,//126.0063MHz
		66,
		E_AUDIOSTANDARD_M,
		E_VIDEOSTANDARD_NTSC_M,

	},
	{
		177250,//177.25MHz �ձ�
		67,
		E_AUDIOSTANDARD_M,
		E_VIDEOSTANDARD_NTSC_M,

	},
	{
		187250,//187.25MHz
		68,
		E_AUDIOSTANDARD_M,
		E_VIDEOSTANDARD_NTSC_M,

	},
	{
		193250,//193.25MHz
		69,
		E_AUDIOSTANDARD_M,
		E_VIDEOSTANDARD_NTSC_M,

	},
	{
		199250,//199.25MHz
		70,
		E_AUDIOSTANDARD_M,
		E_VIDEOSTANDARD_NTSC_M,

	},
	{
		205250,//205.25MHz
		71,
		E_AUDIOSTANDARD_M,
		E_VIDEOSTANDARD_NTSC_M,

	},
	{
		211250,//211.25MHz
		72,
		E_AUDIOSTANDARD_M,
		E_VIDEOSTANDARD_NTSC_M,

	},
	{
		241250,//241.25MHz
		73,
		E_AUDIOSTANDARD_M,
		E_VIDEOSTANDARD_NTSC_M,

	},
	{
		463260,//463.26MHzz
		74,
		E_AUDIOSTANDARD_M,
		E_VIDEOSTANDARD_NTSC_M,

	},
	{
		471250,//471.25MHz
		75,
		E_AUDIOSTANDARD_M,
		E_VIDEOSTANDARD_NTSC_M,

	},
	{
		477250,//477.25MHz
		76,
		E_AUDIOSTANDARD_M,
		E_VIDEOSTANDARD_NTSC_M,

	},
	{
		495250,//495.25MHz
		77,
		E_AUDIOSTANDARD_M,
		E_VIDEOSTANDARD_NTSC_M,

	},
	{
		499250,//499.25MHz PAL M(6M)
		78,
		E_AUDIOSTANDARD_M,
		E_VIDEOSTANDARD_PAL_M,

	},
	{
		549250,//549.25MHz
		79,
		E_AUDIOSTANDARD_M,
		E_VIDEOSTANDARD_NTSC_M,

	},
	{
		555250,//555.25MHz PAL N(6M)
		80,
		E_AUDIOSTANDARD_M,
		E_VIDEOSTANDARD_PAL_N,

	},
	{
		607250,//607.25MHz
		81,
		E_AUDIOSTANDARD_M,
		E_VIDEOSTANDARD_NTSC_M,

	},
	{
		633250,//633.25MHz
		82,
		E_AUDIOSTANDARD_M,
		E_VIDEOSTANDARD_NTSC_M,

	},
	{
		643250,//643.25MHz
		83,
		E_AUDIOSTANDARD_M,
		E_VIDEOSTANDARD_NTSC_M,

	},
	{
		759250,//759.25MHz
		84,
		E_AUDIOSTANDARD_M,
		E_VIDEOSTANDARD_NTSC_M,

	},
	{
		765250,//765.25MHz
		85,
		E_AUDIOSTANDARD_M,
		E_VIDEOSTANDARD_NTSC_M,

	},
	{
		801250,//801.25MHz
		86,
		E_AUDIOSTANDARD_M,
		E_VIDEOSTANDARD_NTSC_M,

	},
#endif
#endif
};
void msAPI_ATV_Factory_CH_Preset(void)
{
    U8 u8ChNum;
    U8 i;
    WORD wPLL;
    BYTE sStationName[MAX_STATION_NAME] = " ";

    printf("\r\n msAPI_ATV_Factory_CH_Preset ---Begin---");/*Creass.liu at 2012-07-05*/
    msAPI_ATV_ResetATVDataManager();

    for(u8ChNum = 0;u8ChNum< MAX_PRESET_CH_NUM;u8ChNum++)
    {
        for(i = 0;i< sizeof(ATVFactoryCHPreset)/sizeof(ATV_FACTORY_CH_PRESET);i++)
        {
            if(u8ChNum == (ATVFactoryCHPreset[i].u8CHNum-1))
            {
                //printf("\r\n [%bu],Preset CH[%bu] --",i,u8ChNum);/*Creass.liu at 2012-07-05*/
                msAPI_ATV_SetCurrentProgramNumber(u8ChNum);
                msAPI_ATV_NeedAFT(u8ChNum, FALSE);
                msAPI_ATV_SkipProgram(u8ChNum, FALSE);
                msAPI_ATV_SetFavoriteProgram(u8ChNum, FALSE);
                msAPI_ATV_LockProgram(u8ChNum, FALSE);
            #if ENABLE_DVBC_PLUS_DTMB_CHINA_APP
                msAPI_ATV_SetProgramAntenna(u8ChNum, (!IsCATVInUse()));
            #endif
            #if ENABLE_SBTVD_BRAZIL_APP
                msAPI_ATV_SetSearchedProgram(u8ChNum,TRUE);
            #endif
                msAPI_ATV_EnableRealtimeAudioDetection(u8ChNum, FALSE);
                msAPI_ATV_SetStationName(u8ChNum, sStationName);

                msAPI_ATV_SetAudioStandard(u8ChNum, ATVFactoryCHPreset[i].eAudioStandard);

                msAPI_ATV_SetVideoStandardOfProgram(u8ChNum, ATVFactoryCHPreset[i].eVideoStandard);
            #if ENABLE_CH_FORCEVIDEOSTANDARD
               msAPI_ATV_SetForceVideoStandardFlag(u8ChNum, FALSE);
            #endif

            #if TN_FREQ_STEP == FREQ_STEP_62_5KHz
                wPLL = (WORD) ((ATVFactoryCHPreset[i].u32Freq * 10) / 625);
            #elif TN_FREQ_STEP == FREQ_STEP_50KHz
                wPLL = (WORD) ((ATVFactoryCHPreset[i].u32Freq * 1) / 50);
            #else
                wPLL = (WORD) ((ATVFactoryCHPreset[i].u32Freq * 100) / 3125);
            #endif // TN_FREQ_STEP
                msAPI_ATV_SetProgramPLLData(u8ChNum, wPLL);

                msAPI_ATV_SetMediumAndChannelNumber(u8ChNum, MEDIUM_AIR, u8ChNum);
                msAPI_ATV_SetFineTune(u8ChNum,0);

            }
        }
    }
	msAPI_ATV_SetCurrentProgramNumber(0);
	#if 0
    {
        U16 u16Ordinal;

        #if ENABLE_SBTVD_BRAZIL_APP
        u16Ordinal = MApp_TV_SBTVD_DigitKeyVerifyInputValue(u8IdleMajorValue, u8IdleMinorValue);
        #else
        u16Ordinal = MApp_TV_NumWinVerifyInputValue(1);
        #endif

        if (u16Ordinal != INVALID_ORDINAL /*&& u16Ordinal != msAPI_CHPROC_CM_GetCurrentOrdinal(E_SERVICETYPE_UNITED_TV, E_PROGACESS_INCLUDE_VISIBLE_ONLY)*/)
        {

            #if ENABLE_PVR
            if (MApp_ZUI_ACT_PVR_Check_Switch_Channel(msAPI_CM_GetCurrentServiceType(), u16Ordinal) == FALSE)
            {
                #if ( ENABLE_DVB_TAIWAN_APP || ENABLE_SBTVD_BRAZIL_APP || (TV_SYSTEM == TV_NTSC) )
                msAPI_ATV_SetDirectTuneFlag(FALSE);
                #endif
                return;
            }
            #endif

        _MApp_ChannelList_ChannelChange(u16Ordinal, SERVICE_TYPE_TV, TRUE, E_PROGACESS_INCLUDE_NOT_VISIBLE_ALSO);

        #if ( ENABLE_DVB_TAIWAN_APP && (ENABLE_SBTVD_BRAZIL_APP == 0))
        if (IsATVInUse() && (msAPI_ATV_IsProgramSearched(msAPI_ATV_GetCurrentProgramNumber())==FALSE))
        {
            stGenSetting.stScanMenuSetting.u8ScanType = SCAN_TYPE_MANUAL;
            stGenSetting.stScanMenuSetting.u8ATVManScanType=ATV_MAN_SCAN_TYPE_ONECH;
            stGenSetting.stScanMenuSetting.u8ATVManScanDir=ATV_MAN_SCAN_UP;
            enTVRetVal = EXIT_GOTO_SCAN;
        }
        #endif
        }

        #if ( ENABLE_DVB_TAIWAN_APP || ENABLE_SBTVD_BRAZIL_APP || (TV_SYSTEM == TV_NTSC) )
        msAPI_ATV_SetDirectTuneFlag(FALSE);
        #endif
        //Cancel Freeze
        if (g_bIsImageFrozen)
        {
            g_bIsImageFrozen = FALSE;
            MApi_XC_FreezeImg(g_bIsImageFrozen, MAIN_WINDOW);
        }
// CUS_XM Xue 20120724: show preset channel tabel
      //  MApp_ZUI_ACT_StartupOSD(E_OSD_CHANNEL_INFO);
      //  MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_SHOW_BRIEF_CH_INFO);
    }
	#endif
    printf("\r\n msAPI_ATV_Factory_CH_Preset ---End---");/*Creass.liu at 2012-07-05*/
}

#endif
#if BOE_UART_FAC_COMMAND//minglin0118
void MApp_UartPort_Conect(void)
{
    if( stGenSetting.g_SysSetting.uUartPortConect== MS_UART_TYPE_HK )
#if (CHIP_FAMILY_TYPE == CHIP_FAMILY_M10)|| (CHIP_FAMILY_TYPE == CHIP_FAMILY_M12)
        mdrv_uart_connect(E_UART_PORT0, E_UART_AEON_R2);
#else
        mdrv_uart_connect(E_UART_PORT0, E_UART_PIU_UART0);
#endif
    else if(stGenSetting.g_SysSetting.uUartPortConect == MS_UART_TYPE_AEON )
        mdrv_uart_connect(E_UART_PORT0, E_UART_AEON);
    else if(stGenSetting.g_SysSetting.uUartPortConect == MS_UART_TYPE_VDEC)
        mdrv_uart_connect(E_UART_PORT0, E_UART_VDEC);
    else //wing
        mdrv_uart_connect(E_UART_PORT0, E_UART_OFF); 
}

BOOLEAN MApp_ZUI_ACT_AutoADC(void)
{
#if (!BOE_UART_FAC_COMMAND)
     MApp_ZUI_API_ShowWindow(HWND_MAINFRAME, SW_HIDE);
    MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BG_TRANSPARENT, SW_SHOW);
    MApp_ZUI_API_ShowWindow(HWND_FACTORY_MENU_BAR_TRANS, SW_SHOW);
    MApp_ZUI_API_SetFocus(HWND_FACTORY_MENU_BAR);
#endif
    if(IsVgaInUse())
        g_ADCCalibrationResult = MApp_RGB_Setting_Auto(E_XC_EXTERNAL_CALIBRATION,MAIN_WINDOW);
    else if(IsYPbPrInUse())
        g_ADCCalibrationResult = MApp_YPbPr_Setting_Auto(E_XC_EXTERNAL_CALIBRATION,MAIN_WINDOW);
    else
        g_ADCCalibrationResult = FALSE;
	if(g_ADCCalibrationResult)
		return TRUE;
	else
		return FALSE;
}

#endif
extern BOOLEAN _MApp_ZUI_API_WindowProcOnTimer(void);
void MApp_ZUI_FactoryAutoRun(void)
{
    if(u8Capturelogo)
    {
     u8Capturelogo--;
     if(!u8Capturelogo)
     {
#if (DISPLAY_LOGO)
		 if(MApp_MPlayer_CaptureLogo() != E_MPLAYER_RET_OK)
		 {		
		  _MApp_ZUI_API_WindowProcOnTimer();
		  u8CapturelogoNG=1;
		 }
		 else
		 {
		  u8CapturelogoNG=0;
		  stGenSetting.g_SysSetting.UsrLogo=2;
		  MApp_SaveSysSetting();
		  _MApp_ZUI_API_WindowProcOnTimer();
		  MApp_ZUI_API_InvalidateAllSuccessors(HWND_HOTEL_MENU_ITEM_CAPTURE_LOGO);
		  MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_CLONE_CONFIRM_COMPLETE,SW_SHOW);
		  MApp_ZUI_API_SetTimer(HWND_HOTEL_MENU_CLONE_CONFIRM_COMPLETE,2,3000);
		  MApp_ZUI_API_ResetTimer(HWND_HOTEL_MENU_CLONE_CONFIRM_COMPLETE,2);
		 }
 #else
       u8CapturelogoNG=1;
 #endif
	 }
    }
}

#undef MAPP_ZUI_ACTFACTORYMENU_C
