////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2008 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (MStar Confidential Information!�L) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef MAPP_EEPROM_MAP_H
#define MAPP_EEPROM_MAP_H

//#include "msAPI_Bootloader.h"
#include "MApp_GlobalSettingSt.h" //ZUI

#if (RM_EEPROM_TYPE == RM_TYPE_24C512 )
    #define MAX_LIMITED_EEPROM_SIZE             0x10000
#elif (RM_EEPROM_TYPE == RM_TYPE_24C16 )
    #define MAX_LIMITED_EEPROM_SIZE             0x800
#elif (RM_EEPROM_TYPE == RM_TYPE_24C32 )
    #define MAX_LIMITED_EEPROM_SIZE             0x1000
#elif (RM_EEPROM_TYPE == RM_TYPE_24C64)
    #define MAX_LIMITED_EEPROM_SIZE             0x2000
#endif

//HDCP Key
#if (HDCP_KEY_TYPE == HDCP_KEY_IN_24C04) || (HDCP_KEY_TYPE == HDCP_KEY_IN_DB)
    #define HDCP_KEY_ADDR                       (0)
#else
    #define HDCP_KEY_ADDR                       (RM_HDCP_KEY_ADDR)
#endif
#define HDCP_KEY_SIZE                           304


// ================EPPROM MAP ====================
#define RM_BOOTLOADER_ADDR                      (0)   // Must be at 0. Otherwise not backward compatible with previously released bootloader
#define RM_SIZE_BOOTLOADER                      RM_SIZE_BOOTLOADER_INIT

#define RM_HDCP_KEY_ADDR                        (RM_BOOTLOADER_ADDR + RM_SIZE_BOOTLOADER)
#define RM_SIZE_HDCP_KEY                        (HDCP_KEY_SIZE)

#if ( ENABLE_DVB_TAIWAN_APP || ENABLE_SBTVD_BRAZIL_APP || (TV_SYSTEM == TV_NTSC) )
    #define RM_CATV_LAST_START_ADR              (RM_HDCP_KEY_ADDR+RM_SIZE_HDCP_KEY)
    #define RM_SIZE_CATV_LAST_DATA              ((U8)sizeof(U8))
    #define RM_ATV_LAST_START_ADR               (RM_CATV_LAST_START_ADR+RM_SIZE_CATV_LAST_DATA)
#else
    #define RM_ATV_LAST_START_ADR               (RM_HDCP_KEY_ADDR+RM_SIZE_HDCP_KEY)
#endif
#define RM_SIZE_ATV_LAST_DATA                   ((U8)sizeof(U8))


#if ( ENABLE_DTV )
    #define RM_DTV_LAST_START_ADR               (RM_ATV_LAST_START_ADR+RM_SIZE_ATV_LAST_DATA)
    #define RM_SIZE_DTV_LAST_DATA               (sizeof(WORD))
    #define RM_RADIO_LAST_START_ADR             (RM_DTV_LAST_START_ADR+RM_SIZE_DTV_LAST_DATA)
    #define RM_SIZE_RADIO_LAST_DATA             (sizeof(WORD))
    #define RM_DATA_LAST_START_ADR              (RM_RADIO_LAST_START_ADR+RM_SIZE_RADIO_LAST_DATA)
    #define RM_SIZE_DATA_LAST_DATA              (sizeof(WORD))
    #define RM_SERVICETYPE_LAST_START_ADR       (RM_DATA_LAST_START_ADR+RM_SIZE_DATA_LAST_DATA)
    #define RM_SIZE_SERVICETYPE_LAST_DATA       (sizeof(MEMBER_SERVICETYPE))

    #define RM_GENSET_START_ADR                 (RM_SERVICETYPE_LAST_START_ADR + RM_SIZE_SERVICETYPE_LAST_DATA)
#else
    #define RM_GENSET_START_ADR                 (RM_ATV_LAST_START_ADR + RM_SIZE_ATV_LAST_DATA)
#endif

#define RM_SYS_SETTING_ADDRESS                  (RM_GENSET_START_ADR + (U32)&(((MS_GENSETTING*)0)->g_SysSetting))
#define RM_SOUND_SETTING_ADDRESS                (RM_GENSET_START_ADR + (U32)&(((MS_GENSETTING*)0)->g_SoundSetting))
#define RM_TIME_DATA_ADDRESS                    (RM_GENSET_START_ADR + (U32)&(((MS_GENSETTING*)0)->g_Time))
#define RM_SCANMENU_SETTING_ADDRESS             (RM_GENSET_START_ADR + (U32)&(((MS_GENSETTING*)0)->stScanMenuSetting))
#define RM_BLOCK_DATA_ADDRESS                   (RM_GENSET_START_ADR + (U32)&(((MS_GENSETTING*)0)->g_BlockSysSetting))

#if ENABLE_SSC
    #define RM_SSC_DATA_ADDRESS                 (RM_GENSET_START_ADR + (U32)&(((MS_GENSETTING*)0)->g_SSCSetting))
#endif

#if (ENABLE_NONLINEAR_CURVE)
    #define RM_NONLINER_SETTING_ADDRESS         (RM_GENSET_START_ADR + (U32)&(((MS_GENSETTING*)0)->g_NonLinearCurveSetting))
#endif

#define RM_FACTORY_SETTING_DATA_ADDRESS         (RM_GENSET_START_ADR + (U32)&(((MS_GENSETTING*)0)->g_FactorySetting))

#if ENABLE_CUS_UI_SPEC
#define RM_VCHIP_SETTING_DATA_ADDRESS           (RM_GENSET_START_ADR + (U32)&(((MS_GENSETTING*)0)->g_VChipSetting))
#endif

#ifdef ENABLE_BT
    #define RM_BT_DATA_ADDRESS                  (RM_GENSET_START_ADR + (U32)&(((MS_GENSETTING*)0)->TorrentSetupInfo))
#endif

#if ENABLE_DRM
    #define RM_DRM_DATA_ADDRESS                 (RM_GENSET_START_ADR + (U32)&(((MS_GENSETTING*)0)->g_VDplayerDRMInfo))
#endif

//#if (ENABLE_PIP)
#define RM_PIP_DATA_ADDRESS                     (RM_GENSET_START_ADR + (U32)&(((MS_GENSETTING*)0)->g_stPipSetting))
//#endif

#if (ENABLE_UPDATE_MULTIPLEX_VIA_NIT)
    #define RM_NETWORK_INFO_DATA_ADDRESS        (RM_GENSET_START_ADR + (U16)&(((MS_GENSETTING*)0)->g_Network_TS))
#endif

#if ENABLE_CI
    #define RM_CI_DATA_ADDRESS                  (RM_GENSET_START_ADR + (U32)&(((MS_GENSETTING*)0)->g_CIKeySetting))
#endif

#if (ENABLE_LAST_MEMORY==1)&&(ENABLE_LAST_MEMORY_STORAGE_SAVE==1)
    #define RM_MM_LASTMEMORY_SETTING_ADDRESS    (RM_GENSET_START_ADR + (U32)&(((MS_GENSETTING*)0)->g_MmLastMemorySetting))
#endif

#define RM_SIZE_GENSET                          ((U16)sizeof(MS_GENSETTING))

#define RM_GEN_USAGE                            MemAlign( (RM_GENSET_START_ADR - RM_BOOTLOADER_ADDR + RM_SIZE_GENSET), 8 ) //4K, for GENSETTING

////////////////////////////////////////////////////////////////////////////////
#endif // #ifndef MAPP_EEPROM_MAP_H

