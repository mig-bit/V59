////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (MStar Confidential Information!�L) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////
#define MSAPI_TUNING_C

#include <string.h>
#include "Board.h"
#include "msAPI_Global.h"
#include "msAPI_Tuning.h"
#include "msAPI_VD.h"
#include "msAPI_audio.h"
#if ENABLE_TTX
#include "msAPI_TTX.h"
#endif
#include "msAPI_FreqTableATV.h"
#include "msAPI_Memory.h"
#include "msAPI_Timer.h"

#include "Tuner.h"
#include "IF_Demodulator.h"
#include "GPIO.h"
#include "drvAVD.h"
#include "drvVIFInitial_MST.h"
#include "MApp_GlobalSettingSt.h"
#include "MApp_ATVProc.h"
#include "MApp_UiMenuDef.h"



#define debugTuningPrint(a,b)    //printf(a,b)
#define L_SEARCH_DBG(x)          //x

//#define AUTO_TUNING_DEBUG                   // enable (define) or disable (undefine) debug code
#define AUTO_SCAN_TIME_PRINT        1

#if defined(AUTO_TUNING_DEBUG)
    #define AUTO_TUNING_PRINT(x)    x
#else
    #define AUTO_TUNING_PRINT(x)
#endif

#if ENABLE_AUTOTEST
    extern BOOLEAN g_bAutobuildDebug;
#endif
//------------------------------------------------------------------------------
// Locals
//------------------------------------------------------------------------------
typedef enum
{
    E_AUTO_SEARCH_TYPE_STOPED,
    E_AUTO_SEARCH_TYPE_ALLWAYUP,
    E_AUTO_SEARCH_TYPE_ALLWAYDOWN,
    E_AUTO_SEARCH_TYPE_ONETOUP,
    E_AUTO_SEARCH_TYPE_ONETODOWN
} AUTO_SEARCH_TYPE;

typedef enum
{
    E_TUNING_RANGE_CENTER,
    E_TUNING_RANGE_LOWER,
    E_TUNING_RANGE_UPPER,
    E_TUNING_RANGE_NEXTCHANNEL
} TUNING_RANGE;

typedef enum
{
    E_TUNING_STATUS_GOOD,
    E_TUNING_STATUS_OVER,
    E_TUNING_STATUS_UNDER,
    E_TUNING_STATUS_OVER_LITTLE,
    E_TUNING_STATUS_UNDER_LITTLE,
    E_TUNING_STATUS_OVER_MORE,
    E_TUNING_STATUS_UNDER_MORE,
    E_TUNING_STATUS_OUT_OF_AFCWIN,
} TUNING_STATUS;

typedef enum
{
    E_AGC_TUNING_STATUS_START,
    E_AGC_TUNING_STATUS_STOP
} AGC_TUNING_STATUS;


// AFT internal states
#if (AUTO_TUNING_TYPE_SEL  == AUTO_TUNING_ALG_PAL_NEW)
#define AFT_IDLE                        0x10

#define AFT_GOTO_CHECK_VIFLOCK          0x11
#define AFT_CHECK_VIFLOCK               0x12
#define AFT_GOTO_CHECK_VDLOCK           0x13
#define AFT_CHECK_VDLOCK                0x14
#define AFT_JUMPFAR                     0x15    // <-<<<
#define AFT_JUMPNEAR                    0x16
#define AFT_JUMPNEARHALF                0x17
#define AFT_TUNING                      0x18
#define AFT_SHOWTIME1                   0x19
#define AFT_SHOWTIME2                   0x1A

#define AFT_DETECTVIDEO                 0x1B
#define AFT_DETECTAUDIO                 0x1C
#define AFT_CHECK_CNI                   0x1D

#define AFT_MEMORIZECHDATA              0x1E
#define AFT_MEMORIZEPRDATA              0x1F
#define AFT_INCREASEPRNUMBER            0x20
#define AFT_COMPLETE                    0x21
#define AFT_CHANGEPROGRAM               0x22
#define AFT_CHANGECHANNEL               0x23
#define AFT_ONECHANNEL_AFT              0x24
#define AFT_STABILIZE                   0x25
#if (ENABLE_DTMB_CHINA_APP || ENABLE_ATV_CHINA_APP || ENABLE_DVBC_PLUS_DTMB_CHINA_APP)
#define AFT_SWITCHIF                    0x26
#endif
#define AFT_SIGNAL_WEAK                 0x27
#define AFT_L_SEARCH_CHECK              0x28
#define AFT_CHECK_FALSESIGNAL           0x29

#else

#define AFT_IDLE                        0x10
#define AFT_CHECKSYNC                   0x11
#define AFT_JUMPNEXT                    0x12    // <-<<<
#define AFT_JUMPFAR                     0x13    // <-<<<
#define AFT_JUMPNEAR                    0x14
#define AFT_JUMPNEARHALF                0x15
#define AFT_TUNING                      0x16
#define AFT_SHOWTIME1                   0x17
#define AFT_SHOWTIME2                   0x18
#define AFT_DETECTVIDEO                 0x19
#define AFT_DETECTAUDIO                 0x1A
#define AFT_MEMORIZECHDATA              0x1B
#define AFT_MEMORIZEPRDATA              0x1C
#define AFT_INCREASEPRNUMBER            0x1D
#define AFT_COMPLETE                    0x1E
#define AFT_CHANGEPROGRAM               0x1F
#define AFT_CHANGECHANNEL               0x20
#define AFT_ONECHANNEL_AFT              0x21
#define AFT_STABILIZE                   0x22
#if (ENABLE_DTMB_CHINA_APP || ENABLE_ATV_CHINA_APP || ENABLE_DVBC_PLUS_DTMB_CHINA_APP)
#define AFT_SWITCHIF                    0x23
#endif
#define AFT_SIGNAL_WEAK                 0x24
#define AFT_L_SEARCH_CHECK              0x26
#define AFT_CHECK_FALSESIGNAL           0x28

#endif

// Never change the following values and sequence.
#define AFT_SYNCOK_1                    0x51
#define AFT_SYNCOK_2                    0x52
#define AFT_SYNCOK_3                    0x53
#define AFT_SYNCOK_4                    0x54
#define AFT_SYNCOK_5                    0x55
#define AFT_NOSYNC_1                    0x61
#define AFT_NOSYNC_2                    0x62
#define AFT_NOSYNC_3                    0x63
#define AFT_NOSYNC_4                    0x64
#define AFT_NOSYNC_5                    0x65

// PLL steps
#define PLLSTEP(x)                      (_u16TunerPLL+(x))

#define TUNER_PLL_REFRESH               0
#define TUNER_PLL_PLUS_37p5KHz          ( (TN_FREQ_STEP==FREQ_STEP_62_5KHz)?(0):((TN_FREQ_STEP==FREQ_STEP_50KHz)?(0):(1)) )
#define TUNER_PLL_PLUS_62p5KHz          ( (TN_FREQ_STEP==FREQ_STEP_62_5KHz)?(1):((TN_FREQ_STEP==FREQ_STEP_50KHz)?(1):(2)) )
#define TUNER_PLL_PLUS_87p5KHz          ( (TN_FREQ_STEP==FREQ_STEP_62_5KHz)?(1):((TN_FREQ_STEP==FREQ_STEP_50KHz)?(2):(3)) )
#define TUNER_PLL_PLUS_112p5KHz         ( (TN_FREQ_STEP==FREQ_STEP_62_5KHz)?(2):((TN_FREQ_STEP==FREQ_STEP_50KHz)?(2):(4)) )
#define TUNER_PLL_PLUS_137p5KHz         ( (TN_FREQ_STEP==FREQ_STEP_62_5KHz)?(2):((TN_FREQ_STEP==FREQ_STEP_50KHz)?(3):(4)) )
#define TUNER_PLL_PLUS_162p5KHz         ( (TN_FREQ_STEP==FREQ_STEP_62_5KHz)?(2):((TN_FREQ_STEP==FREQ_STEP_50KHz)?(3):(5)) )
#define TUNER_PLL_PLUS_187p5KHz         ( (TN_FREQ_STEP==FREQ_STEP_62_5KHz)?(3):((TN_FREQ_STEP==FREQ_STEP_50KHz)?(4):(6)) )
#define TUNER_PLL_PLUS_0p2MHz           ( (TN_FREQ_STEP==FREQ_STEP_62_5KHz)?(3):((TN_FREQ_STEP==FREQ_STEP_50KHz)?(4):(6)) )
#define TUNER_PLL_PLUS_0p25MHz          ( (TN_FREQ_STEP==FREQ_STEP_62_5KHz)?(4):((TN_FREQ_STEP==FREQ_STEP_50KHz)?(5):(8)) )
#define TUNER_PLL_PLUS_0p5MHz           ( (TN_FREQ_STEP==FREQ_STEP_62_5KHz)?(8):((TN_FREQ_STEP==FREQ_STEP_50KHz)?(10):(16)) )
#define TUNER_PLL_PLUS_0p75MHz          ( (TN_FREQ_STEP==FREQ_STEP_62_5KHz)?(12):((TN_FREQ_STEP==FREQ_STEP_50KHz)?(15):(24)) )
#define TUNER_PLL_PLUS_1MHz             ( (TN_FREQ_STEP==FREQ_STEP_62_5KHz)?(16):((TN_FREQ_STEP==FREQ_STEP_50KHz)?(20):(32)) )
#define TUNER_PLL_PLUS_1p25MHz          ( (TN_FREQ_STEP==FREQ_STEP_62_5KHz)?(20):((TN_FREQ_STEP==FREQ_STEP_50KHz)?(25):(40)) )
#define TUNER_PLL_PLUS_1p5MHz           ( (TN_FREQ_STEP==FREQ_STEP_62_5KHz)?(24):((TN_FREQ_STEP==FREQ_STEP_50KHz)?(30):(48)) )
#define TUNER_PLL_PLUS_1p75MHz          ( (TN_FREQ_STEP==FREQ_STEP_62_5KHz)?(28):((TN_FREQ_STEP==FREQ_STEP_50KHz)?(35):(56)) )
#define TUNER_PLL_PLUS_2MHz             ( (TN_FREQ_STEP==FREQ_STEP_62_5KHz)?(32):((TN_FREQ_STEP==FREQ_STEP_50KHz)?(40):(64)) )
#define TUNER_PLL_PLUS_2p25MHz          ( (TN_FREQ_STEP==FREQ_STEP_62_5KHz)?(36):((TN_FREQ_STEP==FREQ_STEP_50KHz)?(45):(72)) )
#define TUNER_PLL_PLUS_2p5MHz           ( (TN_FREQ_STEP==FREQ_STEP_62_5KHz)?(40):((TN_FREQ_STEP==FREQ_STEP_50KHz)?(50):(80)) )
#define TUNER_PLL_PLUS_2p75MHz          ( (TN_FREQ_STEP==FREQ_STEP_62_5KHz)?(44):((TN_FREQ_STEP==FREQ_STEP_50KHz)?(55):(88)) )
#define TUNER_PLL_PLUS_3MHz             ( (TN_FREQ_STEP==FREQ_STEP_62_5KHz)?(48):((TN_FREQ_STEP==FREQ_STEP_50KHz)?(60):(96)) )
#define TUNER_PLL_PLUS_4MHz             ( (TN_FREQ_STEP==FREQ_STEP_62_5KHz)?(64):((TN_FREQ_STEP==FREQ_STEP_50KHz)?(80):(128)) )
#define TUNER_PLL_PLUS_4p5MHz           ( (TN_FREQ_STEP==FREQ_STEP_62_5KHz)?(72):((TN_FREQ_STEP==FREQ_STEP_50KHz)?(90):(144)) )
#define TUNER_PLL_PLUS_5MHz             ( (TN_FREQ_STEP==FREQ_STEP_62_5KHz)?(80):((TN_FREQ_STEP==FREQ_STEP_50KHz)?(100):(160)) )
#define TUNER_PLL_PLUS_5p25MHz          ( (TN_FREQ_STEP==FREQ_STEP_62_5KHz)?(84):((TN_FREQ_STEP==FREQ_STEP_50KHz)?(105):(168)) )
#define TUNER_PLL_PLUS_6p5MHz          ( (TN_FREQ_STEP==FREQ_STEP_62_5KHz)?(104):((TN_FREQ_STEP==FREQ_STEP_50KHz)?(130):(208)) )

#define TUNER_PLL_MINUS_37p5KHz         ( (TN_FREQ_STEP==FREQ_STEP_62_5KHz)?(0):((TN_FREQ_STEP==FREQ_STEP_50KHz)?(0):(-1)) )
#define TUNER_PLL_MINUS_62p5KHz         ( (TN_FREQ_STEP==FREQ_STEP_62_5KHz)?(-1):((TN_FREQ_STEP==FREQ_STEP_50KHz)?(-1):(-2)) )
#define TUNER_PLL_MINUS_87p5KHz         ( (TN_FREQ_STEP==FREQ_STEP_62_5KHz)?(-1):((TN_FREQ_STEP==FREQ_STEP_50KHz)?(-2):(-3)) )
#define TUNER_PLL_MINUS_112p5KHz        ( (TN_FREQ_STEP==FREQ_STEP_62_5KHz)?(-2):((TN_FREQ_STEP==FREQ_STEP_50KHz)?(-2):(-4)) )
#define TUNER_PLL_MINUS_137p5KHz        ( (TN_FREQ_STEP==FREQ_STEP_62_5KHz)?(-2):((TN_FREQ_STEP==FREQ_STEP_50KHz)?(-3):(-4)) )
#define TUNER_PLL_MINUS_162p5KHz        ( (TN_FREQ_STEP==FREQ_STEP_62_5KHz)?(-2):((TN_FREQ_STEP==FREQ_STEP_50KHz)?(-3):(-5)) )
#define TUNER_PLL_MINUS_187p5KHz        ( (TN_FREQ_STEP==FREQ_STEP_62_5KHz)?(-3):((TN_FREQ_STEP==FREQ_STEP_50KHz)?(-4):(-6)) )
#define TUNER_PLL_MINUS_0p2MHz          ( (TN_FREQ_STEP==FREQ_STEP_62_5KHz)?(-3):((TN_FREQ_STEP==FREQ_STEP_50KHz)?(-4):(-6)) )
#define TUNER_PLL_MINUS_0p25MHz         ( (TN_FREQ_STEP==FREQ_STEP_62_5KHz)?(-4):((TN_FREQ_STEP==FREQ_STEP_50KHz)?(-5):(-8)) )
#define TUNER_PLL_MINUS_0p5MHz          ( (TN_FREQ_STEP==FREQ_STEP_62_5KHz)?(-8):((TN_FREQ_STEP==FREQ_STEP_50KHz)?(-10):(-16)) )
#define TUNER_PLL_MINUS_0p75MHz         ( (TN_FREQ_STEP==FREQ_STEP_62_5KHz)?(-12):((TN_FREQ_STEP==FREQ_STEP_50KHz)?(-15):(-24)) )
#define TUNER_PLL_MINUS_1MHz            ( (TN_FREQ_STEP==FREQ_STEP_62_5KHz)?(-16):((TN_FREQ_STEP==FREQ_STEP_50KHz)?(-20):(-32)) )
#define TUNER_PLL_MINUS_1p25MHz         ( (TN_FREQ_STEP==FREQ_STEP_62_5KHz)?(-20):((TN_FREQ_STEP==FREQ_STEP_50KHz)?(-25):(-40)) )
#define TUNER_PLL_MINUS_1p5MHz          ( (TN_FREQ_STEP==FREQ_STEP_62_5KHz)?(-24):((TN_FREQ_STEP==FREQ_STEP_50KHz)?(-30):(-48)) )
#define TUNER_PLL_MINUS_1p75MHz         ( (TN_FREQ_STEP==FREQ_STEP_62_5KHz)?(-28):((TN_FREQ_STEP==FREQ_STEP_50KHz)?(-35):(-56)) )
#define TUNER_PLL_MINUS_2MHz            ( (TN_FREQ_STEP==FREQ_STEP_62_5KHz)?(-32):((TN_FREQ_STEP==FREQ_STEP_50KHz)?(-40):(-64)) )
#define TUNER_PLL_MINUS_2p25MHz         ( (TN_FREQ_STEP==FREQ_STEP_62_5KHz)?(-36):((TN_FREQ_STEP==FREQ_STEP_50KHz)?(-45):(-72)) )
#define TUNER_PLL_MINUS_2p5MHz          ( (TN_FREQ_STEP==FREQ_STEP_62_5KHz)?(-40):((TN_FREQ_STEP==FREQ_STEP_50KHz)?(-50):(-80)) )
#define TUNER_PLL_MINUS_2p75MHz         ( (TN_FREQ_STEP==FREQ_STEP_62_5KHz)?(-44):((TN_FREQ_STEP==FREQ_STEP_50KHz)?(-55):(-88)) )
#define TUNER_PLL_MINUS_3MHz            ( (TN_FREQ_STEP==FREQ_STEP_62_5KHz)?(-48):((TN_FREQ_STEP==FREQ_STEP_50KHz)?(-60):(-96)) )
#define TUNER_PLL_MINUS_4MHz            ( (TN_FREQ_STEP==FREQ_STEP_62_5KHz)?(-64):((TN_FREQ_STEP==FREQ_STEP_50KHz)?(-80):(-128)) )
#define TUNER_PLL_MINUS_5MHz            ( (TN_FREQ_STEP==FREQ_STEP_62_5KHz)?(-80):((TN_FREQ_STEP==FREQ_STEP_50KHz)?(-100):(-160)) )
#define TUNER_PLL_MINUS_5p25MHz         ( (TN_FREQ_STEP==FREQ_STEP_62_5KHz)?(-84):((TN_FREQ_STEP==FREQ_STEP_50KHz)?(-105):(-168)) )

#define FINE_TUNE_STEP                  1
#define NO_SYNC_COUNT_THRESHOLD         3
#define L_PRIME_BOUNDARY_FREQ           66500L // KHz
#define L_PRIME_FA_PLL                  ( (TN_FREQ_STEP==FREQ_STEP_62_5KHz)?(764):((TN_FREQ_STEP==FREQ_STEP_50KHz)?(955):(1528)) )    // 47.75 MHz
#define L_PRIME_FB_PLL                  ( (TN_FREQ_STEP==FREQ_STEP_62_5KHz)?(892):((TN_FREQ_STEP==FREQ_STEP_50KHz)?(1115):(1784)) )    // 55.75 MHz
#define L_PRIME_FC1_PLL                 ( (TN_FREQ_STEP==FREQ_STEP_62_5KHz)?(968):((TN_FREQ_STEP==FREQ_STEP_50KHz)?(1210):(1936)) )    // 60.5 MHz
#define L_PRIME_FC_PLL                  ( (TN_FREQ_STEP==FREQ_STEP_62_5KHz)?(1020):((TN_FREQ_STEP==FREQ_STEP_50KHz)?(1275):(2040)) )// 63.75 MHz

static eAFTSTEP     _eCurrentTuningState = AFT_IDLE;
static MEDIUM _eMedium;
static U8 _u8ChannelNumber;
static U16 _u16TunerPLL;
static U32 s_u32CurTunerFreq;
static U16 _u16TuningWaitTimer;
static U16 _u16AFTIdleTimer;
static U16 _u16RealtimeAFTBaseTunerPLL;
#if(FRONTEND_TUNER_TYPE == FRESCO_FM2150A_TUNER)
static U8  _u8RealtimeAFTBaseOffset;
#endif
#ifdef ENABLE_SUPPORT_ATV_STATION_NAME
static U16 _u16UpdateStationNameTimer;
#endif
static U8 _sCurrentStationName[MAX_STATION_NAME];
static BOOLEAN _bChangeProgram;
static BOOLEANS _BOOLEANS;
static BOOLEAN _IsTuningSuspend;
static U8 u8ScanAFTCount = 0;
#ifdef ENABLE_CUS_AUTO_AUDIO_SYSTEM_DETECT
static U8 _bAutoDetectAudioMode = AUDIO_AUTO_STATUS_EXIT;
#endif




#if (TV_SYSTEM == TV_PAL)
static U8 u8ScanAFTFlag = 0;
static U8 _u8TVScanStepDownCount;
#endif

#define _bIsAFTNeeded               _BOOLEANS.bBOOL_0
#define _bIsLSearch                 _BOOLEANS.bBOOL_1
#define _bIsOneProgramDetected      _BOOLEANS.bBOOL_2
#define _bIsSpeedUp                 _BOOLEANS.bBOOL_3
#define _bIsPreProgramDetected      _BOOLEANS.bBOOL_4

// In the AFT_SHOWTIME2 State, sometimes it will goto Sync-Unloc
// Here we create the configurations for user to adjust
//<1>.Configuration-A: 60% LOCK = PASS
//<2>.Configuration-B: 20% LOCK = PASS
//<3>.Configuration-C: ALL PASS
//PS: Before tye this configuration, please try the VD-Sensitivit first
//     in the drvVD.c #define HSEN_NORMAL_...

#define VD_SYNC_CRITERION_CONFIG_ENABLE   0 //Default = Disable

#if (VD_SYNC_CRITERION_CONFIG_ENABLE)
  #if 1 //<1>.Configuration-A: 60% LOCK = PASS
    #define SYNC_LOCKED_PASS_NUM             3
    #define SYNC_LOCKED_BASE_NUM             5
    #define SYNC_DETECTED_PASS_NUM          3
    #define SYNC_DETECTED_BASE_NUM          5
  #endif

  #if 0 //<2>.Configuration-B:20% LOCK = PASS
    #define SYNC_LOCKED_PASS_NUM             1
    #define SYNC_LOCKED_BASE_NUM             5
    #define SYNC_DETECTED_PASS_NUM          1
    #define SYNC_DETECTED_BASE_NUM          5
  #endif

  #if 0 //<3>.Configuration-C: ALL PASS
    #define SYNC_LOCKED_PASS_NUM             0
    #define SYNC_LOCKED_BASE_NUM             5
    #define SYNC_DETECTED_PASS_NUM          0
    #define SYNC_DETECTED_BASE_NUM          5
  #endif
#endif
//------------------------------------------------------------------------------
// Adjustment-3 => <1>For frequency offset  issue (for example:+-50KHz)
//------------------------------------------------------------------------------
//** Description:     To avoid the frequency offset  issue,
//** When to use?:  if you found that you can't get the correct frequency after scan, you can try it.
//                          for example: The Correct Frequency = 55.25MhZ
//                                            You got 55.25MHz (+-)50KHz
//**How to use?      Define it (SPECIFIC_AFC_GOOD_VALUE) in your board define.
//                          Value = 1 => 62p5KHz
//                          Value = 0 => 37p5KHz (Default)


//------------------------------------------------------------------------------
// Local functions
//------------------------------------------------------------------------------
static void _RomStringCopy(char *sDestination, char ROM *sSource, U8 u8Size);
static RFBAND _GetBand(U16 u16PLL);
static void _SetTunerPLL(U16 u16PLL);
static BOOLEAN _IsTunerStable(void);
static void _OneChannelAFT(void);
static BOOLEAN _IsLPrime(void);

#if 1//TV_SCAN_PAL_SECAM_ONCE//Define function _CheckLPrimeBoundary
static BOOLEAN _CheckLPrimeBoundary(void);
#endif

static void _SetDefaultStationName(BYTE *sStationName);
#ifdef ENABLE_SUPPORT_ATV_STATION_NAME
static void _DetectStationName(void);
#endif

#if((FRONTEND_IF_DEMODE_TYPE == MSTAR_VIF_MSB1210)||(FRONTEND_IF_DEMODE_TYPE == MSTAR_VIF)||(FRONTEND_IF_DEMODE_TYPE == MSTAR_INTERN_VIF))
static BOOLEAN _SetVifIfFreq(void);
#endif



//------------------------------------------------------------------------------
// Local Functions.
//------------------------------------------------------------------------------
static void msAPI_ConvertFrequencyToString(WORD wIntegerOfFreq, WORD wFractionOfFreq, char *pcBuffer)
{
    pcBuffer[0] = ((wIntegerOfFreq/100) == 0) ? ' ' : '0'+(wIntegerOfFreq/100);
    pcBuffer[1] = '0'+((wIntegerOfFreq%100)/10);
    pcBuffer[2] = '0'+(wIntegerOfFreq%10);
    pcBuffer[3] = '.';
    pcBuffer[4] = '0'+(wFractionOfFreq/100);
    pcBuffer[5] = '0'+((wFractionOfFreq%100)/10);
    pcBuffer[6] = 'M';
    pcBuffer[7] = 'H';
    pcBuffer[8] = 'z';
}

static BOOLEAN _IsTunerStable(void)
{
    if ( _u16TuningWaitTimer == 0 )
    {
        return TRUE;
    }

    _u16TuningWaitTimer--;


    if ( _bIsSpeedUp )
    {
        if (_u16TuningWaitTimer > AUTO_TUNING_DEFAULT_ALG_WAIT_TIME_SPEEP_UP)
        {
            _u16TuningWaitTimer = AUTO_TUNING_DEFAULT_ALG_WAIT_TIME_SPEEP_UP;
        }
    }

    return FALSE;
}

#if((FRONTEND_IF_DEMODE_TYPE == MSTAR_VIF) || (FRONTEND_IF_DEMODE_TYPE == MSTAR_INTERN_VIF))
static void _OneChannelAFT(void)
{
    return;
}
#elif (FRONTEND_TUNER_TYPE == NXP_FQD1136_TUNER)
static void _OneChannelAFT(void)
{
    WORD wUpperLimitPLL;
    WORD wLowerLimitPLL;
    WORD wBasePLL;
    WORD wOriginalPLL;
    TUNING_RANGE eNextTuningRange;
    BYTE i;

    wOriginalPLL = _u16TunerPLL;

    if ( _GetTuningStatus() != E_TUNING_STATUS_GOOD )
    {

        debugTuningPrint("One Channel AFT: Start\n", 0);

        eNextTuningRange = E_TUNING_RANGE_CENTER;

        while ( eNextTuningRange != E_TUNING_RANGE_NEXTCHANNEL )
        {
            switch ( eNextTuningRange )
            {
            case E_TUNING_RANGE_CENTER:
                wBasePLL = wOriginalPLL;
                wUpperLimitPLL = wOriginalPLL + TUNER_PLL_PLUS_1p75MHz;
                wLowerLimitPLL = wOriginalPLL + TUNER_PLL_MINUS_1p75MHz;
                eNextTuningRange = E_TUNING_RANGE_LOWER;
                break;

            case E_TUNING_RANGE_LOWER:
                wBasePLL = wOriginalPLL + TUNER_PLL_MINUS_1p75MHz;
                wUpperLimitPLL = wOriginalPLL + TUNER_PLL_PLUS_0p2MHz;
                wLowerLimitPLL = wOriginalPLL + TUNER_PLL_MINUS_2p25MHz;
                eNextTuningRange = E_TUNING_RANGE_UPPER;
                break;

            case E_TUNING_RANGE_UPPER:
                wBasePLL = wOriginalPLL + TUNER_PLL_PLUS_1p75MHz;
                wUpperLimitPLL = wOriginalPLL + TUNER_PLL_PLUS_2p25MHz;
                wLowerLimitPLL = wOriginalPLL + TUNER_PLL_MINUS_0p2MHz;
                eNextTuningRange = E_TUNING_RANGE_NEXTCHANNEL;
                break;

            default:
                debugTuningPrint("One Channel AFT: Fail\n", 0);

                _SetTunerPLL( wOriginalPLL );
                return;
            }

            _SetTunerPLL( wBasePLL );

            while ( _IsTunerStable() == FALSE )
            {
                msAPI_Timer_Delayms(MAIN_LOOP_INTERVAL);

                msAPI_AVD_UpdateAutoAVState();
            }

            if ( msAPI_AVD_IsSyncLocked() == FALSE )
            {
                msAPI_Timer_Delayms(MAIN_LOOP_INTERVAL);

                if ( msAPI_AVD_IsSyncLocked() == FALSE )
                {
                    msAPI_Timer_Delayms(MAIN_LOOP_INTERVAL);

                    if ( msAPI_AVD_IsSyncLocked() == FALSE )
                    {
                        continue;
                    }
                }
            }

            for ( i = 0; i < TUNER_PLL_PLUS_2MHz; i++ )
            {
                msAPI_AVD_UpdateAutoAVState();

                if ( _GetTuningStatus() == E_TUNING_STATUS_GOOD )
                {
                    if ( msAPI_AVD_IsSyncLocked() == TRUE )
                    {
                        debugTuningPrint("One Channel AFT: OK\n", 0);
                        return;
                    }
                }

                switch( MDrv_IFDM_GetFreqDev() )
                {
                case E_AFC_BELOW_MINUS_125pKHz:
                    _SetTunerPLL( PLLSTEP(2) );
                    break;

                case E_AFC_MINUS_62p5KHz:
                    _SetTunerPLL( PLLSTEP(1) );
                    break;

                case E_AFC_PLUS_62p5KHz:
                    _SetTunerPLL( PLLSTEP(-1) );
                    break;

                case E_AFC_ABOVE_PLUS_125pKHz:
                    _SetTunerPLL( PLLSTEP(-2) );
                    break;
                }

                if ( (_u16TunerPLL <= wLowerLimitPLL) || (wUpperLimitPLL <= _u16TunerPLL) )
                {
                    break;
                }
            }
        }

        debugTuningPrint("One Channel AFT: Fail\n", 0);

        _SetTunerPLL( wOriginalPLL );
    }
}
#else

static void _OneChannelAFT(void)
{
    WORD wUpperLimitPLL;
    WORD wLowerLimitPLL;
    WORD wBasePLL;
    WORD wOriginalPLL;
    TUNING_RANGE eNextTuningRange;
    BYTE i;

    wOriginalPLL = _u16TunerPLL;

    if ( _IsLPrime() == TRUE )
    {
        for ( i=0; i <= TUNER_PLL_PLUS_4MHz ; i++ )
        {
            msAPI_AVD_UpdateAutoAVState();

            switch ( MDrv_IFDM_GetFreqDev() )
            {
            case E_AFC_BELOW_MINUS_187p5KHz:
                _SetTunerPLL( PLLSTEP(8) );
                break;

            case E_AFC_MINUS_162p5KHz:
                _SetTunerPLL( PLLSTEP(5) );
                break;

            case E_AFC_MINUS_137p5KHz:
                _SetTunerPLL( PLLSTEP(4) );
                break;

            case E_AFC_MINUS_112p5KHz:
                _SetTunerPLL( PLLSTEP(3) );
                break;

            case E_AFC_MINUS_87p5KHz:
                _SetTunerPLL( PLLSTEP(3) );
                break;

            case E_AFC_MINUS_62p5KHz:
                _SetTunerPLL( PLLSTEP(2) );
                return;

            case E_AFC_MINUS_37p5KHz:
                _SetTunerPLL( PLLSTEP(1) );
                return;

            case E_AFC_MINUS_12p5KHz:
                return;

            case E_AFC_PLUS_12p5KHz:
                return;

            case E_AFC_PLUS_37p5KHz:
                _SetTunerPLL( PLLSTEP(-1) );
                return;

            case E_AFC_PLUS_62p5KHz:
                _SetTunerPLL( PLLSTEP(-2) );
                return;

            case E_AFC_PLUS_87p5KHz:
                _SetTunerPLL( PLLSTEP(-3) );
                break;

            case E_AFC_PLUS_112p5KHz:
                _SetTunerPLL( PLLSTEP(-3) );
                break;

            case E_AFC_PLUS_137p5KHz:
                _SetTunerPLL( PLLSTEP(-4) );
                break;

            case E_AFC_PLUS_162p5KHz:
                _SetTunerPLL( PLLSTEP(-5) );
                break;

            case E_AFC_ABOVE_PLUS_187p5KHz:
                _SetTunerPLL( PLLSTEP(-8) );
                break;

            default:
                _SetTunerPLL(wOriginalPLL);
                return;
            }

            if ( DIFFERENCE(wOriginalPLL,_u16TunerPLL) > TUNER_PLL_PLUS_2MHz )
            {
                if ( _u16TunerPLL < wOriginalPLL )
                {
                    _SetTunerPLL( wOriginalPLL + TUNER_PLL_PLUS_2MHz );
                }
                else
                {
                    _SetTunerPLL( wOriginalPLL + TUNER_PLL_MINUS_2MHz );
                }
            }
        }

        _SetTunerPLL(wOriginalPLL);

        return;
    }

    if ( _GetTuningStatus() != E_TUNING_STATUS_GOOD )
    {

        debugTuningPrint("One Channel AFT: Start\n", 0);

        eNextTuningRange = E_TUNING_RANGE_CENTER;

        while ( eNextTuningRange != E_TUNING_RANGE_NEXTCHANNEL )
        {
            switch ( eNextTuningRange )
            {
            case E_TUNING_RANGE_CENTER:
                wBasePLL = wOriginalPLL;
                wUpperLimitPLL = wOriginalPLL + TUNER_PLL_PLUS_1p75MHz;
                wLowerLimitPLL = wOriginalPLL + TUNER_PLL_MINUS_1p75MHz;
                eNextTuningRange = E_TUNING_RANGE_LOWER;
                break;

            case E_TUNING_RANGE_LOWER:
                wBasePLL = wOriginalPLL + TUNER_PLL_MINUS_1p75MHz;
                wUpperLimitPLL = wOriginalPLL + TUNER_PLL_PLUS_0p2MHz;
                wLowerLimitPLL = wOriginalPLL + TUNER_PLL_MINUS_2p25MHz;
                eNextTuningRange = E_TUNING_RANGE_UPPER;
                break;

            case E_TUNING_RANGE_UPPER:
                wBasePLL = wOriginalPLL + TUNER_PLL_PLUS_1p75MHz;
                wUpperLimitPLL = wOriginalPLL + TUNER_PLL_PLUS_2p25MHz;
                wLowerLimitPLL = wOriginalPLL + TUNER_PLL_MINUS_0p2MHz;
                eNextTuningRange = E_TUNING_RANGE_NEXTCHANNEL;
                break;

            default:
                debugTuningPrint("One Channel AFT: Fail\n", 0);

                _SetTunerPLL( wOriginalPLL );
                return;
            }

            _SetTunerPLL( wBasePLL );

            while ( _IsTunerStable() == FALSE )
            {
                msAPI_Timer_Delayms(MAIN_LOOP_INTERVAL);

                msAPI_AVD_UpdateAutoAVState();
            }

            if ( msAPI_AVD_IsSyncLocked() == FALSE )
            {
                msAPI_Timer_Delayms(MAIN_LOOP_INTERVAL);

                if ( msAPI_AVD_IsSyncLocked() == FALSE )
                {
                    msAPI_Timer_Delayms(MAIN_LOOP_INTERVAL);

                    if ( msAPI_AVD_IsSyncLocked() == FALSE )
                    {
                        continue;
                    }
                }
            }

            for ( i = 0; i < TUNER_PLL_PLUS_2MHz; i++ )
            {
                msAPI_AVD_UpdateAutoAVState();

                if ( _GetTuningStatus() == E_TUNING_STATUS_GOOD )
                {
                    if ( msAPI_AVD_IsSyncLocked() == TRUE )
                    {
                        debugTuningPrint("One Channel AFT: OK\n", 0);
                        return;
                    }
                }

                switch( MDrv_IFDM_GetFreqDev() )
                {
                case E_AFC_BELOW_MINUS_187p5KHz:
                    _SetTunerPLL( PLLSTEP(3) );
                    break;

                case E_AFC_MINUS_162p5KHz:
                    _SetTunerPLL( PLLSTEP(3) );
                    break;

                case E_AFC_MINUS_137p5KHz:
                    _SetTunerPLL( PLLSTEP(2) );
                    break;

                case E_AFC_MINUS_112p5KHz:
                    _SetTunerPLL( PLLSTEP(2) );
                    break;

                case E_AFC_MINUS_87p5KHz:
                    _SetTunerPLL( PLLSTEP(2) );
                    break;

                case E_AFC_MINUS_62p5KHz:
                    _SetTunerPLL( PLLSTEP(1) );
                    break;

                case E_AFC_MINUS_37p5KHz:
                    _SetTunerPLL( PLLSTEP(1) );
                    break;

                case E_AFC_PLUS_37p5KHz:
                    _SetTunerPLL( PLLSTEP(-1) );
                    break;

                case E_AFC_PLUS_62p5KHz:
                    _SetTunerPLL( PLLSTEP(-1) );
                    break;

                case E_AFC_PLUS_87p5KHz:
                    _SetTunerPLL( PLLSTEP(-2) );
                    break;

                case E_AFC_PLUS_112p5KHz:
                    _SetTunerPLL( PLLSTEP(-2) );
                    break;

                case E_AFC_PLUS_137p5KHz:
                    _SetTunerPLL( PLLSTEP(-2) );
                    break;

                case E_AFC_PLUS_162p5KHz:
                    _SetTunerPLL( PLLSTEP(-3) );
                    break;

                case E_AFC_ABOVE_PLUS_187p5KHz:
                    _SetTunerPLL( PLLSTEP(-3) );
                    break;

                default:
                    break;
                }

                if ( (_u16TunerPLL <= wLowerLimitPLL) || (wUpperLimitPLL <= _u16TunerPLL) )
                {
                    break;
                }
            }
        }

        debugTuningPrint("One Channel AFT: Fail\n", 0);

        _SetTunerPLL( wOriginalPLL );
    }
}

#endif

static void _RomStringCopy(char *sDestination, char ROM *sSource, U8 u8Size)
{
    U8 i;

    for ( i = 0; i < u8Size; i++ )
    {
        sDestination[i] = sSource[i];
    }
}


static RFBAND _GetBand(U16 u16PLL)
{
    if ( u16PLL < VHF_HIGHMIN_PLL )
    {
        return E_RFBAND_VHF_LOW;
    }

    if ( u16PLL < UHF_MIN_PLL )
    {
        return E_RFBAND_VHF_HIGH;
    }

    return E_RFBAND_UHF;
}

static U32 _TunerPllStepToRealFreq(U16 u16TunerPll)
{
#if (TN_FREQ_STEP == FREQ_STEP_62_5KHz)
    return (U32)u16TunerPll * 62500;
#elif (TN_FREQ_STEP == FREQ_STEP_50KHz)
    return (U32)u16TunerPll * 50000;
#else
    #error "unknown tuner step"
#endif
}

#if 1//TV_SCAN_PAL_SECAM_ONCE//Only check Prime L Boundary, do not check  (msAPI_AUD_GetAudioStandard() == E_AUDIOSTANDARD_L)
static BOOLEAN _CheckLPrimeBoundary(void)
{
    U32 u32TunerFreq = _TunerPllStepToRealFreq(_u16TunerPLL);
/*
    WORD wLPrimeBoundaryPLL;

#if TN_FREQ_STEP == FREQ_STEP_62_5KHz
    wLPrimeBoundaryPLL = (WORD)((L_PRIME_BOUNDARY_FREQ * 10) / 625);
#elif TN_FREQ_STEP == FREQ_STEP_50KHz
    wLPrimeBoundaryPLL = (WORD)(L_PRIME_BOUNDARY_FREQ / 50);
#else
    wLPrimeBoundaryPLL = (WORD)((L_PRIME_BOUNDARY_FREQ * 100) / 3125);
#endif // TN_FREQ_STEP
*/

    //if (_u16TunerPLL < wLPrimeBoundaryPLL)
    if( (u32TunerFreq/1000) < L_PRIME_BOUNDARY_FREQ )
        return TRUE;
    else
        return FALSE;
}
#endif

static void _SetDefaultStationName(BYTE *sStationName)
{
#if ENABLE_CUS_UI_SPEC
    int i;
    for ( i = 0; i < (MAX_STATION_NAME-1); i++ )
    {
        sStationName[i] = 0;
    }
    sStationName[MAX_STATION_NAME-1] = '\0';
#else
    int i;
    for ( i = 0; i < (MAX_STATION_NAME-1); i++ )
    {
        sStationName[i] = '-';
    }
    sStationName[MAX_STATION_NAME-1] = '\0';
#endif
}


static BOOLEAN _IsLPrime(void)
{
    /*
    WORD wLPrimeBoundaryPLL;

#if TN_FREQ_STEP == FREQ_STEP_62_5KHz
    wLPrimeBoundaryPLL = (WORD)((L_PRIME_BOUNDARY_FREQ * 10) / 625);
#elif TN_FREQ_STEP == FREQ_STEP_50KHz
    wLPrimeBoundaryPLL = (WORD)(L_PRIME_BOUNDARY_FREQ / 50);
#else
    wLPrimeBoundaryPLL = (WORD)((L_PRIME_BOUNDARY_FREQ * 100) / 3125);
#endif // TN_FREQ_STEP
*/

    //printf(" _u16TunerPLL=%lu, %lu;", _u16TunerPLL,_u16TunerPLL*50);
    //printf(" msAPI_AUD_GetAudioStandard()=%lu;", msAPI_AUD_GetAudioStandard());

    if ( (msAPI_AUD_GetAudioStandard() == E_AUDIOSTANDARD_L)
         //(_u16TunerPLL < wLPrimeBoundaryPLL)
       &&_CheckLPrimeBoundary()
       )
    {
        //printf(" _IsLPrime()=1; ");
        return TRUE;
    }
    else
    {
        //printf(" _IsLPrime()=0; ");
        return FALSE;
    }
}


#if((FRONTEND_IF_DEMODE_TYPE == MSTAR_VIF_MSB1210)||(FRONTEND_IF_DEMODE_TYPE == MSTAR_VIF)||(FRONTEND_IF_DEMODE_TYPE == MSTAR_INTERN_VIF))

static void _SetTunerPLL(U16 u16PLL);

U16 u16IfFreqPre = TUNER_IF_FREQ_KHz;

void msAPI_ClearTunerFreq_Status(void)
{
    u16IfFreqPre =0;
}

void msAPI_SetTunerPLL(void)
{
    _SetTunerPLL(msAPI_ATV_GetProgramPLLData(msAPI_ATV_GetCurrentProgramNumber()));
}

void msAPI_SetTunerPLL_KeepFreq(void)
{
    _SetTunerPLL(_u16TunerPLL);
}

static BOOLEAN _SetVifIfFreq(void)
{
    U16 u16IfFreq;
//    static U16 u16IfFreqPre=TUNER_IF_FREQ_KHz;
    if ( FALSE == _IsLPrime() )
    {
        u16IfFreq = TUNER_IF_FREQ_KHz;
    }
    else
    {
        u16IfFreq = TUNER_L_PRIME_IF_FREQ_KHz;
    }
    if ( u16IfFreqPre != u16IfFreq )
    {
        /*if( u16IfFreq == TUNER_IF_FREQ_KHz )
            printf("[DK IF]");
        else
            printf("[L IF]");*/

        MDrv_IFDM_SetVifIfFreq(u16IfFreq) ;
        //MDrv_WriteRegBit(0x1121C0,0,BIT2); //Mantis 0237841 ,Thomas patch for ATV sound in picture 20120416
        u16IfFreqPre = u16IfFreq;
    }
    return TRUE;
}
#endif
U32 g_u32Freq = 0;
#if (TV_FREQ_SHIFT_CLOCK)
void _TVShiftClk(AVD_ATV_CLK_TYPE u8Mode)
{
    //printf("\r\n _TVShiftClk=%x, %x\n",u8Mode, g_u8_ShiftClk_LastMode);

    if( u8Mode != g_u8_ShiftClk_LastMode )
    {
        printf("\r\n_TVShiftClk=%d", g_u32Freq);
        printf("\r\nTv shift Clk=%d\n", u8Mode);
        switch (u8Mode)
        {
            case E_ATV_CLK_TYPE1_42MHZ:
                //printf("--E_ATV_CLK_TYPE1_42MHZ---\n");
                #if 0
                #if ENABLE_SW_CH_FREEZE_SCREEN
                if((stGenSetting.g_SysSetting.u8SwitchMode != ATV_SWITCH_CH_FREEZE_SCREEN) || (g_bChangeChannelAtTVsource == FALSE))
                #endif
                {
                    msAPI_Scaler_SetScreenMute(E_SCREEN_MUTE_TEMPORARY, ENABLE, 1000, MAIN_WINDOW);
                }
                #endif
                msApi_AUD_SIF_Shift(MSAPI_AUD_SIF_42M);
                DRV_VIF_ShiftClk((U8)u8Mode);
                msAPI_AVD_ShiftClk(E_ATV_CLK_TYPE1_42MHZ);
                break;
            case E_ATV_CLK_TYPE2_44P4MHZ:
                //printf("--E_ATV_CLK_TYPE1_44p4MHZ---\n");
                #if 0
                #if ENABLE_SW_CH_FREEZE_SCREEN
                if((stGenSetting.g_SysSetting.u8SwitchMode != ATV_SWITCH_CH_FREEZE_SCREEN) || (g_bChangeChannelAtTVsource == FALSE))
                #endif
                {
                    msAPI_Scaler_SetScreenMute(E_SCREEN_MUTE_TEMPORARY, ENABLE, 1000, MAIN_WINDOW);
                }
                #endif
                msApi_AUD_SIF_Shift(MSAPI_AUD_SIF_44M);
                DRV_VIF_ShiftClk((U8)u8Mode);
                msAPI_AVD_ShiftClk(E_ATV_CLK_TYPE2_44P4MHZ);
                break;
            case E_ATV_CLK_ORIGIN_43P2MHZ:
            default:
                //printf("--E_ATV_CLK_TYPE1_43.2MHZ--\n");
                msApi_AUD_SIF_Shift(MSAPI_AUD_SIF_43M);
                DRV_VIF_ShiftClk((U8)u8Mode);
                msAPI_AVD_ShiftClk(E_ATV_CLK_ORIGIN_43P2MHZ);
                break;
        }
        //msAPI_Tuner_SetIF();
        g_u8_ShiftClk_LastMode = (U8)u8Mode;
    }

}
static AVD_ATV_CLK_TYPE _Get_Shift_Mode(U32 u32Freq)
{
    U32 u32Freq_KHz = u32Freq / 1000;
   // printf("\r\nEnable SW Patch Freq= %d", u32Freq_KHz);

    if (u32Freq_KHz <= 237000)   // 0~237MHz
    {
        if (((u32Freq_KHz >= 85250)&&(u32Freq_KHz <= 87650)) ||
            ((u32Freq_KHz >= 127250)&&(u32Freq_KHz <= 130850)) ||
            ((u32Freq_KHz >= 169250)&&(u32Freq_KHz <= 174050)) ||
            ((u32Freq_KHz >= 211250)&&(u32Freq_KHz <= 217250)))
        {
            return E_ATV_CLK_TYPE1_42MHZ;
        }
        else if (((u32Freq_KHz >= 81400)&&(u32Freq_KHz <= 83800)) ||
            ((u32Freq_KHz >= 124600)&&(u32Freq_KHz <= 127000)) ||
            ((u32Freq_KHz >= 167800)&&(u32Freq_KHz <= 169000)))
        {
            return E_ATV_CLK_TYPE2_44P4MHZ;
        }
    }
    else if (u32Freq_KHz <= 453000)   // 237~453MHz
    {
        if (((u32Freq_KHz >= 253250)&&(u32Freq_KHz <= 260450)) ||
            ((u32Freq_KHz >= 295250)&&(u32Freq_KHz <= 303650)) ||
            ((u32Freq_KHz >= 340600)&&(u32Freq_KHz <= 346850)) ||
            ((u32Freq_KHz >= 383800)&&(u32Freq_KHz <= 390050)) ||
            ((u32Freq_KHz >= 427000)&&(u32Freq_KHz <= 433250)))
        {
            return E_ATV_CLK_TYPE1_42MHZ;
        }
    }
    else if (u32Freq_KHz <= 669000)   // 453~669MHz
    {
        if (((u32Freq_KHz >= 470200)&&(u32Freq_KHz <= 476450)) ||
            ((u32Freq_KHz >= 513400)&&(u32Freq_KHz <= 519650)) ||
            ((u32Freq_KHz >= 556600)&&(u32Freq_KHz <= 562850)) ||
            ((u32Freq_KHz >= 599800)&&(u32Freq_KHz <= 606050)) ||
            ((u32Freq_KHz >= 643000)&&(u32Freq_KHz <= 649250)))
        {
            return E_ATV_CLK_TYPE1_42MHZ;
        }
    }
    else
    {
        if (((u32Freq_KHz >= 686200)&&(u32Freq_KHz <= 692450)) ||
            ((u32Freq_KHz >= 729400)&&(u32Freq_KHz <= 735650)) ||
            ((u32Freq_KHz >= 772600)&&(u32Freq_KHz <= 778850)) ||
            ((u32Freq_KHz >= 815800)&&(u32Freq_KHz <= 822050)) ||
            ((u32Freq_KHz >= 859000)&&(u32Freq_KHz <= 865250)))
        {
            return E_ATV_CLK_TYPE1_42MHZ;
        }
    }
    return E_ATV_CLK_ORIGIN_43P2MHZ;

}
static void _Set_Shift_Freq(U32 u32Freq)
{
    AVD_ATV_CLK_TYPE u8FreqShiftMode = E_ATV_CLK_ORIGIN_43P2MHZ;
#if((FRONTEND_IF_DEMODE_TYPE == MSTAR_VIF) ||(FRONTEND_IF_DEMODE_TYPE == MSTAR_INTERN_VIF) ||(FRONTEND_IF_DEMODE_TYPE == MSTAR_VIF_MSB1210)    )
    if ( msAPI_Tuner_IsTuningProcessorBusy() == TRUE )
#endif
    {
        _TVShiftClk(E_ATV_CLK_ORIGIN_43P2MHZ);
        return;
    }
    g_u32Freq = u32Freq;
    u8FreqShiftMode=_Get_Shift_Mode(u32Freq);
    _TVShiftClk(u8FreqShiftMode);
}
void msAPI_Tuner_Patch_TVShiftClk(BOOL bEnable)
{
    U32 u32TunerFreq;

//    printf("\r\nmsAPI_Tuner_Patch_TVShiftClk=%x",(U16)bEnable);

    if (bEnable)
    {
      #if (TN_FREQ_STEP == FREQ_STEP_62_5KHz)
        u32TunerFreq = (U32)_u16TunerPLL * 62500;
      #elif (TN_FREQ_STEP == FREQ_STEP_50KHz)
        u32TunerFreq = (U32)_u16TunerPLL * 50000;
      #else
        #error "unknown step"
      #endif
        _Set_Shift_Freq(u32TunerFreq);
    }
    else
    {
        _TVShiftClk(E_ATV_CLK_ORIGIN_43P2MHZ);
    }
}
void msAPI_Tuner_Patch_ResetTVShiftClk(void)
{
    g_u8_ShiftClk_LastMode = 0xFF;
}
void msAPI_Tuner_Patch_TVShiftVDClk(BOOL bEnable)
{
    U32 u32Freq;
    AVD_ATV_CLK_TYPE u8FreqShiftMode = E_ATV_CLK_ORIGIN_43P2MHZ;
    printf("msAPI_Tuner_Patch_TVShiftVDClk=%x\n",(U16)bEnable);

    if (bEnable)
    {
      #if (TN_FREQ_STEP == FREQ_STEP_62_5KHz)
        u32Freq= (U32)_u16TunerPLL * 62500;
      #elif (TN_FREQ_STEP == FREQ_STEP_50KHz)
        u32Freq = (U32)_u16TunerPLL * 50000;
      #else
        #error "unknown step"
      #endif
      //printf("\r\nEnable VD shift Patch Freq= %d", u32Freq);
        u8FreqShiftMode=_Get_Shift_Mode(u32Freq);
        msAPI_AVD_ShiftClk(u8FreqShiftMode);
    }
    else
    {
        msAPI_AVD_ShiftClk(E_ATV_CLK_ORIGIN_43P2MHZ);
    }
}

BOOLEAN msAPI_Tuner_Patch_IsTVShiftVDClk(void)
{
    U32 u32TunerFreq;
    U16 u16TunerPLL;

    u16TunerPLL = msAPI_ATV_GetProgramPLLData(msAPI_ATV_GetCurrentProgramNumber());
    #if (TN_FREQ_STEP == FREQ_STEP_62_5KHz)
        u32TunerFreq = (U32)u16TunerPLL * 62500;
    #elif (TN_FREQ_STEP == FREQ_STEP_50KHz)
        u32TunerFreq = (U32)u16TunerPLL * 50000;
    #else
        #error "unknown step"
    #endif
    //printf("---u32TunerFreq:%ld!---\n",u32TunerFreq);
    if(_Get_Shift_Mode(u32TunerFreq) == E_ATV_CLK_TYPE1_42MHZ || _Get_Shift_Mode(u32TunerFreq) == E_ATV_CLK_TYPE2_44P4MHZ)
    {
        printf("msAPI_Tuner_Patch_IsTVShiftVDClk True!\n");
        return TRUE;
    }

    //printf("msAPI_Tuner_Patch_IsTVShiftVDClk False!\n");
    return FALSE;
}

#endif

static void _SetTunerPLL(U16 u16PLL)
{
    static U32 s_u32PreTunerFreq = 0;


    _bIsPreProgramDetected = FALSE;

    if ( u16PLL < VHF_LOWMIN_PLL )
    {
        u16PLL = VHF_LOWMIN_PLL;
    }
    else if ( UHF_MAX_PLL < u16PLL )
    {
        if(u16PLL == DEFAULT_PLL) //DEFAULT_PLL
            ; //keep original Default PLL
        else
            u16PLL = UHF_MAX_PLL;
    }

#if(AUTO_TUNING_TYPE_SEL==AUTO_TUNING_ALG_PAL_NEW)

       _u16TuningWaitTimer = WAIT_110ms;
      #if ENABLE_VD_PACH_IN_CHINA
        _u16TuningWaitTimer+=stGenSetting.g_FactorySetting.SCAN_DELAY;
      #endif

#else
    if  ( DIFFERENCE(_u16TunerPLL, u16PLL) < TUNER_PLL_PLUS_0p25MHz )
    {
      #if TV_SCAN_PAL_SECAM_ONCE//For L Search, From BG to SCEAM-L, Step=0, u16TuningWaitTimer = WAIT_230ms;
        if ((_bIsLSearch))
            _u16TuningWaitTimer = AUTO_TUNING_DEFAULT_ALG_WAIT_TIME_0P25MHZ_STEP_L;
        else
      #endif
            _u16TuningWaitTimer = AUTO_TUNING_DEFAULT_ALG_WAIT_TIME_0P25MHZ_STEP;
    }
    else if ( DIFFERENCE(_u16TunerPLL, u16PLL) < TUNER_PLL_PLUS_0p5MHz )
    {
        _u16TuningWaitTimer = AUTO_TUNING_DEFAULT_ALG_WAIT_TIME_0P5MHZ_STEP;
    }
    else if ( DIFFERENCE(_u16TunerPLL, u16PLL) < TUNER_PLL_PLUS_4MHz )
    {
        _u16TuningWaitTimer = AUTO_TUNING_DEFAULT_ALG_WAIT_TIME_4MHZ_STEP;
      #if ENABLE_VD_PACH_IN_CHINA
        _u16TuningWaitTimer+=stGenSetting.g_FactorySetting.SCAN_DELAY;
      #endif
    }
    else
    {
        _u16TuningWaitTimer = AUTO_TUNING_DEFAULT_ALG_WAIT_TIME_MAX_STEP;
      #if ENABLE_VD_PACH_IN_CHINA
        _u16TuningWaitTimer+=stGenSetting.g_FactorySetting.SCAN_DELAY;
      #endif
    }

    if ( _GetBand(_u16TunerPLL) != _GetBand(u16PLL) )
    {
        _u16TuningWaitTimer = AUTO_TUNING_DEFAULT_ALG_WAIT_TIME_CROSS_BAND_STEP;
    }
#endif

    _u16TunerPLL = u16PLL;

    {
        AUTO_TUNING_PRINT( printf("<_u16TunerPLL=%d.%d MHz>",
                                  msAPI_CFT_ConvertPLLtoIntegerOfFrequency(_u16TunerPLL),
                                  msAPI_CFT_ConvertPLLtoFractionOfFrequency(_u16TunerPLL)) );
    }

#if ENABLE_AUTOTEST
    if(g_bAutobuildDebug && (msAPI_CFT_ConvertPLLtoIntegerOfFrequency(_u16TunerPLL) == 850))
    {
        printf("31_ATV_Failed\n");
    }
#endif

    s_u32CurTunerFreq = _TunerPllStepToRealFreq(_u16TunerPLL);

   // printf("\r\n_SetTunerPLL=%d\n", s_u32CurTunerFreq);

#if ( (FRONTEND_TUNER_TYPE == MxL_601SI_TUNER)     \
   || (FRONTEND_TUNER_TYPE == SILAB_2158_TUNER)    \
   || (FRONTEND_TUNER_TYPE == NUTUNE_FK1602_TUNER) \
   || (FRONTEND_TUNER_TYPE == NXP_TDA18273_TUNER)  \
   )
    devTunerSetFreq( s_u32CurTunerFreq );
#else
    devTunerSetPLLData( _u16TunerPLL+msAPI_Tuner_GetIF(), _GetBand(_u16TunerPLL) );
#endif


#if ( (FRONTEND_IF_DEMODE_TYPE == MSTAR_VIF_MSB1210)    \
    ||(FRONTEND_IF_DEMODE_TYPE == MSTAR_VIF)             \
    ||(FRONTEND_IF_DEMODE_TYPE == MSTAR_INTERN_VIF) )
    MDrv_IFDM_SetFreqBand(_GetBand(_u16TunerPLL));

    _SetVifIfFreq();
#endif

#if (TV_FREQ_SHIFT_CLOCK)
    _Set_Shift_Freq(s_u32CurTunerFreq);
#endif

    s_u32PreTunerFreq = s_u32CurTunerFreq;

}

#ifdef ENABLE_SUPPORT_ATV_STATION_NAME
static void _DetectStationName(void)
{
#if ENABLE_TTX
    if ( TRUE != msAPI_TTX_GetStationNameFromTeletext(_sCurrentStationName, MAX_STATION_NAME, NULL) )
#endif
    {
        msAPI_Tuner_ConvertMediumAndChannelNumberToString(_eMedium, _u8ChannelNumber, _sCurrentStationName);
    }

    _u16UpdateStationNameTimer = WAIT_1970ms;
}
#endif

/******************************************************************************/
///- This function will initialize tuner
/* ****************************************************************************/
void msAPI_Tuner_Init(void)
{
    CAL_TIME_FUNC_START();

    devTunerInit();

#if(FRONTEND_IF_DEMODE_TYPE == MSTAR_INTERN_VIF)
    //for reduce the boot time,it will be execute in MApp_InputSource_SetInputSource() later;
    //MDrv_IFDM_Init();
#else
    MDrv_IFDM_Init();
    msAPI_Tuner_SetIF();
#endif

    _eCurrentTuningState = AFT_IDLE;

    _SetTunerPLL(msAPI_ATV_GetProgramPLLData(msAPI_ATV_GetCurrentProgramNumber()));

    _bIsOneProgramDetected = FALSE;

//#if(FRONTEND_IF_DEMODE_TYPE == MSTAR_VIF_MSB1210)
    //AUDIOSTANDARD_TYPE msAPI_ATV_GetAudioStandard(msAPI_ATV_GetCurrentProgramNumber());
    //printf("##DB Audio=%bx \n",(U8)msAPI_ATV_GetAudioStandard(msAPI_ATV_GetCurrentProgramNumber()));
    msAPI_AUD_SetAudioStandard( msAPI_ATV_GetAudioStandard(msAPI_ATV_GetCurrentProgramNumber()) );
//#endif


    _u16TuningWaitTimer = WAIT_0ms;

    _u16AFTIdleTimer = WAIT_0ms;

#if( (FRONTEND_TUNER_TYPE == NXP_TD1616EF_TUNER)     \
  || (FRONTEND_TUNER_TYPE == LG_TDTC_G001D_TUNER)    \
  || (FRONTEND_TUNER_TYPE == SILICON_R620D_TUNER)    \
  || (FRONTEND_TUNER_TYPE == FRESCO_FM2150A_TUNER)    \
   )
    _bIsAFTNeeded = TRUE;
#else
    _bIsAFTNeeded = FALSE;
#endif

    msAPI_Tuner_SetRealtimeAFTBaseTunerPLL(_u16TunerPLL);
    #if 0//(FRONTEND_TUNER_TYPE == FRESCO_FM2150A_TUNER)
    _u8RealtimeAFTBaseOffset=msAPI_ATV_GetAutoFineTuneOffset(msAPI_ATV_GetCurrentProgramNumber());
    #endif

    msAPI_ATV_GetMediumAndChannelNumber(msAPI_ATV_GetCurrentProgramNumber(), &_eMedium, &_u8ChannelNumber);

    _SetDefaultStationName(_sCurrentStationName);
    #ifdef ENABLE_SUPPORT_ATV_STATION_NAME
    _u16UpdateStationNameTimer = WAIT_0ms;
    #endif

    _bChangeProgram = TRUE;

    _IsTuningSuspend = FALSE;

    _bIsPreProgramDetected = FALSE;

    CAL_TIME_FUNC_END();
#if (TV_FREQ_SHIFT_CLOCK)
    msAPI_Tuner_Patch_ResetTVShiftClk();
#endif

}

/******************************************************************************/
///- This function will check whether Tuning module is busy or not
/// @return TRUE: tuning module is busy.
/* ****************************************************************************/
BOOLEAN msAPI_Tuner_IsTuningProcessorBusy(void)
{
    if ( _eCurrentTuningState == AFT_IDLE )
    {
        return FALSE;
    }

    return TRUE;
}

/******************************************************************************/
///- This function will check whether one program is detected or not when search.
/// @return TRUE: if one program is detected.
/* ****************************************************************************/
BOOLEAN msAPI_Tuner_IsOneProgramDetected(void)
{
    if ( _bIsOneProgramDetected == TRUE )
    {
        _bIsOneProgramDetected = FALSE;

        return TRUE;
    }

    return FALSE;
}

BOOLEAN msAPI_Tuner_PreProgramDeteted(void)
{
    return (BOOLEAN) _bIsPreProgramDetected ;
}

/******************************************************************************/
///- This API will set tuner PLL of center frequnecy which will be used in realtime AFT.
/// @param wTunerPLL \b IN: Tuner PLL
/******************************************************************************/
void msAPI_Tuner_SetRealtimeAFTBaseTunerPLL(U16 u16TunerPLL)
{
    _u16RealtimeAFTBaseTunerPLL = u16TunerPLL;
    u8ScanAFTCount = 0;
}

/******************************************************************************/
///- This function will check if sync is locked or NOT
/// @return BOOLEAN:
/// - TRUE: Sync is locked
/// - FALSE: Sync is not locked
/******************************************************************************/
BOOLEAN msAPI_Tuner_VD_IsSyncLocked(U8 u8CheckBaseCount, U8 u8PassCount)
{
    U8 bCount,bLockCount;

    if (u8CheckBaseCount<u8PassCount)
        return FALSE;
    if (u8PassCount==0)
        return TRUE;

    bCount=0;
    bLockCount=0;
    do
    {
        if (msAPI_AVD_IsSyncLocked() == TRUE )
            bLockCount++;
        bCount++;
     }while (bCount<u8CheckBaseCount);

    if (bLockCount >= u8PassCount)
        return TRUE;
    else
        return FALSE;
}

/******************************************************************************/
///- This function will check if sync is detected or NOT
/// @return BOOLEAN:
/// - TRUE: Sync is detected
/// - FALSE: Sync is not detected
/******************************************************************************/
BOOLEAN msAPI_Tuner_VD_IsSyncDetected(U8 u8CheckBaseCount, U8 u8PassCount)
{
    U8 bCount,bLockCount;

    if (u8CheckBaseCount<u8PassCount)
        return FALSE;
    if (u8PassCount==0)
        return TRUE;

    bCount=0;
    bLockCount=0;
    do
    {
        if (msAPI_AVD_IsSyncLocked() == TRUE )
            bLockCount++;
        bCount++;
     }while (bCount<u8CheckBaseCount);

    if (bLockCount >= u8PassCount)
        return TRUE;
    else
        return FALSE;
}


/******************************************************************************/
///- This API is called by MApp_ATVProc_Handler to keep tuning work.
/// @param eState \b IN: AFT_EXT_STEP_PERIODIC - This enum is called by ATVProc_Handler(). Don't call any other place except ATVProc_Handler().
///                  IN: AFT_EXT_STEP_SEARCHALL - This enum will start auto-tuning from VHF low to UHF max.
///                  IN: AFT_EXT_STEP_SEARCHONETOUP - This enum will search up for next one available channel.
///                  IN: AFT_EXT_STEP_SEARCHONETODOWN - This enum will search up for next one available channel.
///                  IN: AFT_EXT_STEP_SEARCH_STOP - This enum will stop searching.
/******************************************************************************/

#if (AUTO_TUNING_TYPE_SEL == AUTO_TUNING_ALG_NTSC) //Search NTSC ANT_AIR and ANT_CATV
    #if (ENABLE_SBTVD_BRAZIL_APP == 1)
    #include "msAPI_Tuning_BRAZIL.c"
    #else
    #include "msAPI_Tuning_NTSC.c"
    #endif
#elif (AUTO_TUNING_TYPE_SEL == AUTO_TUNING_ALG_DEFAULT)   //-- AUTO_TUNING_TYPE_SEL --------------------------------------------------------------------------//
#include "msAPI_Tuning_PAL.c"
#elif (AUTO_TUNING_TYPE_SEL == AUTO_TUNING_ALG_TST)   //-- AUTO_TUNING_TYPE_SEL --------------------------------------------------------------------------//
#include "msAPI_Tuning_PAL_Tst.c"
#elif(AUTO_TUNING_TYPE_SEL == AUTO_TUNING_ALG_PAL_NEW)
#include "msAPI_Tuning_PAL_NEW.c"
#else
#error "No valid AUTO_TUNING_TYPE_SEL!!"
#endif

#if ( ENABLE_DVB_TAIWAN_APP || ENABLE_SBTVD_BRAZIL_APP || (TV_SYSTEM == TV_NTSC) )
extern BOOLEAN g_bIsProgramAutoColorSystem;
#endif

/******************************************************************************/
///- This API is called by change program.
/******************************************************************************/
void msAPI_Tuner_ChangeProgram(void)
{
  #if (ENABLE_SWITCH_CHANNEL_TIME)
    #define PT_MApp_TCP_SetBeginTime()      u32TimeBegin = msAPI_Timer_GetTime0()
    #define PT_MApp_TCP_PrintfTime(x)       u32TimeEnd = msAPI_Timer_DiffTimeFromNow(u32TimeBegin);\
                                            printf(x, u32TimeEnd);\
                                            u32TimeBegin = msAPI_Timer_GetTime0()

    U32 u32TimeBegin = 0x00;
    U32 u32TimeEnd   = 0x00;
  #else
    #define PT_MApp_TCP_SetBeginTime()
    #define PT_MApp_TCP_PrintfTime(x)
  #endif

    AUDIOSTANDARD_TYPE eAudioStandard;
    AUDIOMODE_TYPE eSavedAudioMode;
    U8 u8CurrentProgramNumber;
    #if (ENABLE_DTMB_CHINA_APP || ENABLE_ATV_CHINA_APP || ENABLE_DVBC_PLUS_DTMB_CHINA_APP)
    EN_ATV_SYSTEM_TYPE u8AudioSystem =EN_ATV_SystemType_DK;
    #else
    EN_ATV_SYSTEM_TYPE u8AudioSystem =EN_ATV_SystemType_BG;
    #endif
    #if ENABLE_CUS_BURNING_MODE
    g_bDisableBurninMode = TRUE;
    #endif
    PT_MApp_TCP_SetBeginTime();
    u8CurrentProgramNumber = msAPI_ATV_GetCurrentProgramNumber();
    PT_MApp_TCP_PrintfTime("\n[TCP]msAPI_ATV_GetCurrentProgramNumber() -- %ld\n");

   #if (ENABLE_SW_CH_FREEZE_SCREEN)
      msAPI_ChannelChange_UnFreezeManager();
  #endif
  #if (TV_FREQ_SHIFT_CLOCK)
     msAPI_Tuner_Patch_ResetTVShiftClk();
  #endif

    _bIsAFTNeeded = msAPI_ATV_IsAFTNeeded(u8CurrentProgramNumber);

    #if ENABLE_CUS_UI_SPEC //for CUS channel info change
    msAPI_ATV_ChannelInfoEdit_SetAFT(_bIsAFTNeeded);
    #endif

    PT_MApp_TCP_PrintfTime("[TCP]msAPI_ATV_IsAFTNeeded() -- %ld\n");

#if((FRONTEND_IF_DEMODE_TYPE == MSTAR_VIF_MSB1210)||(FRONTEND_IF_DEMODE_TYPE == MSTAR_VIF)) //must;;AAA
    msAPI_AUD_SetAudioStandard( msAPI_ATV_GetAudioStandard(u8CurrentProgramNumber) );
    PT_MApp_TCP_PrintfTime("[TCP]msAPI_AUD_SetAudioStandard() -- %ld\n");
#endif
    eAudioStandard = msAPI_ATV_GetAudioStandard(u8CurrentProgramNumber);
    PT_MApp_TCP_PrintfTime("[TCP]msAPI_ATV_GetAudioStandard() -- %ld\n");
    msAPI_Tuner_UserSetIF(eAudioStandard);
#if ENABLE_DVBC_PLUS_DTMB_CHINA_APP
    if( msAPI_ATV_IsProgrambIsTerrestrial(u8CurrentProgramNumber) == IsCATVInUse() )
    {
        stGenSetting.stScanMenuSetting.u8DVBCTvConnectionType ^= 1;
        msAPI_Tuner_SwitchSource((EN_DVB_TYPE)stGenSetting.stScanMenuSetting.u8DVBCTvConnectionType, FALSE);
        msAPI_Tuner_SetAntenna(IsCATVInUse());
    }
#endif

//    MDrv_IFDM_Reset();   //Brian 20101215  modify vif Initial to Reset fucntion to confirm vif clock only setting once in vif Initial function
#if(FRONTEND_IF_DEMODE_TYPE == MSTAR_INTERN_VIF)
    msAPI_ClearTunerFreq_Status();
#endif

    _SetTunerPLL( msAPI_ATV_GetProgramPLLData(u8CurrentProgramNumber) );
    PT_MApp_TCP_PrintfTime("[TCP]_SetTunerPLL() -- %ld\n");

   // msAPI_Timer_Delayms(300);
    MDrv_IFDM_Reset();
   // msAPI_Tuner_SetIF();

    PT_MApp_TCP_PrintfTime("[TCP]msAPI_Tuner_SetIF() -- %ld\n");

#if ENABLE_TTX
    msAPI_TTX_ResetAcquisition();
#endif

    msAPI_Tuner_SetRealtimeAFTBaseTunerPLL(_u16TunerPLL);
    #if 0//(FRONTEND_TUNER_TYPE == FRESCO_FM2150A_TUNER)
    _u8RealtimeAFTBaseOffset=msAPI_ATV_GetAutoFineTuneOffset(msAPI_ATV_GetCurrentProgramNumber());
    #endif

    PT_MApp_TCP_PrintfTime("[TCP]msAPI_Tuner_SetRealtimeAFTBaseTunerPLL() -- %ld\n");

    if ( _bIsAFTNeeded == FALSE )
    {
        _SetTunerPLL( PLLSTEP( msAPI_ATV_GetFineTune(u8CurrentProgramNumber)*FINE_TUNE_STEP ) );
        PT_MApp_TCP_PrintfTime("[TCP]_SetTunerPLL() -- %ld\n");
    }
#if (ENABLE_SBTVD_BRAZIL_APP||ENABLE_SBTVD_BRAZIL_CM_APP)
    {
        AVD_VideoStandardType eVideoStandard;
        eVideoStandard=msAPI_ATV_GetVideoStandardOfProgram(u8CurrentProgramNumber);
        //printf("\r\n -----------eVideoStandard=%bu",eVideoStandard);
        if(eVideoStandard != E_VIDEOSTANDARD_NTSC_M&&eVideoStandard != E_VIDEOSTANDARD_PAL_M&&eVideoStandard != E_VIDEOSTANDARD_PAL_N)
        {
           // printf("\r\n =-=-=1-=-=-=");
            msAPI_AVD_StartAutoStandardDetection();
            msAPI_AVD_GetResultOfAutoStandardDetection();
        }
        else
        {
            //printf("\r\n =-=-=2-=-=-=");
            msAPI_AVD_SetVideoStandard(eVideoStandard);
        }
//    msAPI_AVD_SetVideoStandard( msAPI_ATV_GetVideoStandardOfProgram(u8CurrentProgramNumber) );
        PT_MApp_TCP_PrintfTime("[TCP]msAPI_AVD_SetVideoStandard() -- %ld\n");
   }
#else
    {
        AVD_VideoStandardType eVideoStandard;
        eVideoStandard=msAPI_ATV_GetVideoStandardOfProgram(u8CurrentProgramNumber);
        PT_MApp_TCP_PrintfTime("[TCP]msAPI_ATV_GetVideoStandardOfProgram() -- %ld\n");

        if(eVideoStandard == E_VIDEOSTANDARD_AUTO)
        {
            msAPI_AVD_StartAutoStandardDetection();
            PT_MApp_TCP_PrintfTime("[TCP]msAPI_AVD_StartAutoStandardDetection() -- %ld\n");
            msAPI_AVD_GetResultOfAutoStandardDetection();
            PT_MApp_TCP_PrintfTime("[TCP]msAPI_AVD_StartAutoStandardDetection() -- %ld\n");
        }
        else
        {
            AVD_VideoStandardType tmpAVD_VideoStandardType;

            tmpAVD_VideoStandardType = msAPI_ATV_GetVideoStandardOfProgram(u8CurrentProgramNumber);
            PT_MApp_TCP_PrintfTime("[TCP]msAPI_ATV_GetVideoStandardOfProgram() -- %ld\n");
            msAPI_AVD_SetVideoStandard( tmpAVD_VideoStandardType );
            PT_MApp_TCP_PrintfTime("[TCP]msAPI_AVD_SetVideoStandard() -- %ld\n");
          #if( ENABLE_CH_FORCEVIDEOSTANDARD==FALSE)
            msAPI_AVD_ForceVideoStandard( tmpAVD_VideoStandardType);
          #endif
        }
    }
#endif

    u8AudioSystem=MApp_ATVProc_GetAudioSystem(eAudioStandard);
    if (u8AudioSystem != stGenSetting.stScanMenuSetting.u8SoundSystem)
    {
        stGenSetting.stScanMenuSetting.u8SoundSystem = u8AudioSystem;
    }
    msAPI_ATV_GetAudioMode(E_AUDIOSOURCE_ATV, &eSavedAudioMode);
    PT_MApp_TCP_PrintfTime("[TCP]msAPI_ATV_GetAudioMode() -- %ld\n");

    msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE_DURING_LIMITED_TIME, 1200, E_AUDIOMUTESOURCE_ACTIVESOURCE); //C.P.Chen 2007/12/06
    PT_MApp_TCP_PrintfTime("[TCP]msAPI_AUD_AdjustAudioFactor() -- %ld\n");
    msAPI_AUD_SetAudioStandard( eAudioStandard );
    PT_MApp_TCP_PrintfTime("[TCP]msAPI_AUD_SetAudioStandard() -- %ld\n");
//    MDrv_IFDM_Init();
    PT_MApp_TCP_PrintfTime("[TCP]MDrv_IFDM_Reset() -- %ld\n");
    msAPI_Tuner_SetIF();
    PT_MApp_TCP_PrintfTime("[TCP]msAPI_Tuner_SetIF() -- %ld\n");

    msAPI_AUD_ForceAudioMode(eSavedAudioMode);
    PT_MApp_TCP_PrintfTime("[TCP]msAPI_AUD_ForceAudioMode() -- %ld\n");

    msAPI_AUD_EnableRealtimeAudioDetection(msAPI_ATV_IsRealtimeAudioDetectionEnabled(u8CurrentProgramNumber));
    PT_MApp_TCP_PrintfTime("[TCP]msAPI_AUD_EnableRealtimeAudioDetection() -- %ld\n");

    msAPI_AVD_UpdateAutoAVState();
    PT_MApp_TCP_PrintfTime("[TCP]msAPI_AVD_UpdateAutoAVState() -- %ld\n");

    if ( _bIsAFTNeeded == TRUE )
    {
        _OneChannelAFT();
        PT_MApp_TCP_PrintfTime("[TCP]_OneChannelAFT() -- %ld\n");
    }

    if ( msAPI_AVD_IsAutoAVActive(E_AUTOAV_SOURCE_ALL) == TRUE )
    {
        msAPI_AVD_SwitchAutoAV();
        PT_MApp_TCP_PrintfTime("[TCP]msAPI_AVD_SwitchAutoAV() -- %ld\n");

        msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE,E_AUDIO_BYSYNC_MUTEOFF,E_AUDIOMUTESOURCE_ATV);
        PT_MApp_TCP_PrintfTime("[TCP]msAPI_AUD_AdjustAudioFactor() -- %ld\n");
    }
    else
    {
        if(IsVDHasSignal()==FALSE)
        {
            // msAPI_VD_EnableAutoGainControl(TRUE); // <-<<< USELESS
            msAPI_AVD_SetForcedFreeRun(TRUE);
            PT_MApp_TCP_PrintfTime("[TCP] msAPI_AVD_SetForcedFreeRun() -- %ld\n");
            msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_BYSYNC_MUTEON, E_AUDIOMUTESOURCE_ATV);
            PT_MApp_TCP_PrintfTime("[TCP] msAPI_AUD_AdjustAudioFactor() -- %ld\n");
        }
        else
        {
            // msAPI_VD_EnableAutoGainControl(FALSE); // <-<<< USELESS
            msAPI_AVD_SetForcedFreeRun(FALSE);
            PT_MApp_TCP_PrintfTime("[TCP] msAPI_AVD_SetForcedFreeRun() -- %ld\n");
            msAPI_AVD_WaitForVideoSyncLock();
            PT_MApp_TCP_PrintfTime("[TCP] msAPI_AVD_WaitForVideoSyncLock() -- %ld\n");
            msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE,E_AUDIO_BYSYNC_MUTEOFF,E_AUDIOMUTESOURCE_ATV);
            PT_MApp_TCP_PrintfTime("[TCP] msAPI_AUD_AdjustAudioFactor() -- %ld\n");
        }
    }

    msAPI_ATV_GetMediumAndChannelNumber(u8CurrentProgramNumber, &_eMedium, &_u8ChannelNumber);
    PT_MApp_TCP_PrintfTime("[TCP] msAPI_ATV_GetMediumAndChannelNumber() -- %ld\n");

    msAPI_ATV_GetStationName(u8CurrentProgramNumber, _sCurrentStationName);
    PT_MApp_TCP_PrintfTime("[TCP] msAPI_ATV_GetStationName() -- %ld\n");
    #if ENABLE_SW_CH_FREEZE_SCREEN
    msApi_VD_ChannelChangeStatus_State();
    #endif
    _u16AFTIdleTimer = 0;	// reset timer, so AFT will be re-active

    #ifdef ENABLE_CUS_AUTO_AUDIO_SYSTEM_DETECT
    //msAPI_AUD_ATV_BeginAudioSystemAutoDetect(msAPI_ATV_IsRealtimeAudioDetectionEnabled(u8CurrentProgramNumber));
    if(msAPI_ATV_IsRealtimeAudioDetectionEnabled(u8CurrentProgramNumber))
    {
        msAPI_AUD_ATV_BeginAudioSystemAutoDetect(TRUE);
    }
    #endif
}

#if 0
/******************************************************************************/
// This API is called to change program without waiting for sync to be stable
/******************************************************************************/
void msAPI_Tuner_ChangeProgramWithoutStable(void)
{
    AUDIOSTANDARD_TYPE eAudioStandard;
    AUDIOMODE_TYPE eSavedAudioMode;
    BYTE cCurrentProgramNumber;

    _bIsAFTNeeded = msAPI_ATV_IsAFTNeeded(cCurrentProgramNumber);

    _SetTunerPLL( msAPI_ATV_GetProgramPLLData(cCurrentProgramNumber) );

    msAPI_TTX_ResetAcquisition();

    msAPI_Tuner_SetRealtimeAFTBaseTunerPLL(_u16TunerPLL);

    if ( _bIsAFTNeeded == FALSE )
    {
        _SetTunerPLL( PLLSTEP( msAPI_ATV_GetFineTune(cCurrentProgramNumber)*FINE_TUNE_STEP ) );
    }

    eAudioStandard = msAPI_ATV_GetAudioStandard(cCurrentProgramNumber);

    msAPI_ATV_GetAudioMode(E_AUDIOSOURCE_ATV, &eSavedAudioMode);

    msAPI_AUD_SetAudioStandard( eAudioStandard );

    msAPI_Tuner_SetIF();

    msAPI_AUD_ForceAudioMode(eSavedAudioMode);

    msAPI_AUD_EnableRealtimeAudioDetection(msAPI_ATV_IsRealtimeAudioDetectionEnabled(cCurrentProgramNumber));

    msAPI_AVD_SetVideoStandard( msAPI_ATV_GetVideoStandardOfProgram(cCurrentProgramNumber) );

    msAPI_AVD_UpdateAutoAVState();

    if ( FALSE == msAPI_AVD_IsSyncLocked() )
    {
        msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_BYSYNC_MUTEON, E_AUDIOMUTESOURCE_ATV);
    }
    else
    {
        msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE,E_AUDIO_BYSYNC_MUTEOFF,E_AUDIOMUTESOURCE_ATV);
    }

    msAPI_ATV_GetMediumAndChannelNumber(cCurrentProgramNumber, &_eMedium, &_u8ChannelNumber);

    msAPI_ATV_GetStationName(cCurrentProgramNumber, _sCurrentStationName);
}
#endif

/******************************************************************************/
///- This function is called to get current tuning interface.
/// @return MEDIUM: MEDIUM_CABLE or MEDIUM_AIR.
/******************************************************************************/
MEDIUM msAPI_Tuner_GetMedium(void)
{
    return _eMedium;
}

/******************************************************************************/
///- This API is called to set different tuning interface.
/// @param eMedium \b IN: MEDIUM_CABLE - cable.
///                   IN: MEDIUM_AIR - air.
/******************************************************************************/
void msAPI_Tuner_SetMedium(MEDIUM eMedium)
{
    _eMedium = eMedium;

    msAPI_Tuner_SetChannelNumber(_u8ChannelNumber);
}

/******************************************************************************/
///- This function is called to get current channel number.
/// @return U8: channel number.
/* ****************************************************************************/
U8 msAPI_Tuner_GetChannelNumber(void)
{
    return _u8ChannelNumber;
}

/******************************************************************************/
///- This function is called to set current channel number.
/// @param cChannelNumber \b IN: channel number
/******************************************************************************/
void msAPI_Tuner_SetChannelNumber(U8 u8ChannelNumber)
{
    U8 u8MinChannel, u8MaxChannel;

    msAPI_CFT_GetMinMaxChannel( _eMedium, &u8MinChannel, &u8MaxChannel );

    if ( u8ChannelNumber < u8MinChannel )
    {
        _u8ChannelNumber = u8MinChannel;
    }
    else if ( u8MaxChannel < u8ChannelNumber )
    {
        _u8ChannelNumber = u8MaxChannel;
    }
    else
    {
        _u8ChannelNumber = u8ChannelNumber;
    }

    _SetTunerPLL( msAPI_CFT_GetChannelPLLData(_eMedium, _u8ChannelNumber) );

#if ENABLE_TTX
    msAPI_TTX_ResetAcquisition();
#endif
    msAPI_Tuner_SetIF();

    msAPI_AVD_UpdateAutoAVState();

    _OneChannelAFT();

    _bIsAFTNeeded = TRUE;

    msAPI_Tuner_SetRealtimeAFTBaseTunerPLL(_u16TunerPLL);
    #if 0//(FRONTEND_TUNER_TYPE == FRESCO_FM2150A_TUNER)
    _u8RealtimeAFTBaseOffset=msAPI_ATV_GetAutoFineTuneOffset(msAPI_ATV_GetCurrentProgramNumber());
    #endif

    if ( msAPI_AVD_IsAutoAVActive(E_AUTOAV_SOURCE_ALL) == TRUE )
    {
        msAPI_AVD_SwitchAutoAV();

        msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE,E_AUDIO_BYSYNC_MUTEOFF,E_AUDIOMUTESOURCE_ATV);
    }
    else
    {
        if(IsVDHasSignal()==FALSE)
        {
            // msAPI_VD_EnableAutoGainControl(TRUE); // <-<<< USELESS

            msAPI_AVD_SetForcedFreeRun(TRUE);

            msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_BYSYNC_MUTEON, E_AUDIOMUTESOURCE_ATV);
        }
        else
        {
            // msAPI_VD_EnableAutoGainControl(FALSE); // <-<<< USELESS

            msAPI_AVD_SetForcedFreeRun(FALSE);

            msAPI_AVD_WaitForVideoSyncLock();

            msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE,E_AUDIO_BYSYNC_MUTEOFF,E_AUDIOMUTESOURCE_ATV);
        }
    }

#ifdef ENABLE_SUPPORT_ATV_STATION_NAME
    _DetectStationName();
#endif

}

/******************************************************************************/
///- This function is called to adjust fine-tune.
/// @param eDirection \b IN: Direction to adjust tuner PLL.
/******************************************************************************/
void msAPI_Tuner_AdjustUnlimitedFineTune(DIRECTION eDirection)
{
#if (FRONTEND_IF_DEMODE_TYPE  == MSTAR_INTERN_VIF)
    U8 u8Ksel;
    MDrv_IFDM_SetParameter(VIF_PARA_GET_K_SEL, &u8Ksel, sizeof(u8Ksel));
#endif

    _bIsAFTNeeded = FALSE;

    msAPI_AUD_EnableRealtimeAudioDetection(FALSE);

#if (FRONTEND_IF_DEMODE_TYPE  == MSTAR_INTERN_VIF)
    {
       if(u8Ksel==1)
       {
           DWORD kSel=0;
           DWORD hwKpKi=0x11;
           MDrv_IFDM_SetParameter(VIF_PARA_K_SEL, &kSel, sizeof(kSel));
           MDrv_IFDM_SetParameter(VIF_PARA_SET_HW_KPKI, &hwKpKi, sizeof(hwKpKi));
       }
     }
#endif

    if ( eDirection == DIRECTION_UP )
    {
        if(msAPI_Tuner_GetCurrentChannelPLL() >= UHF_MAX_PLL)
            _u16TunerPLL = VHF_LOWMIN_PLL;

         _SetTunerPLL( PLLSTEP(1));
    }
    else
    {
        if(msAPI_Tuner_GetCurrentChannelPLL() <= VHF_LOWMIN_PLL)
            _u16TunerPLL = UHF_MAX_PLL;

        _SetTunerPLL( PLLSTEP(-1));
    }

#if (FRONTEND_IF_DEMODE_TYPE  == MSTAR_INTERN_VIF)
    {
       if(u8Ksel==1)
       {
           DWORD kSel=1;
           DWORD hwKpKi=(VIF_CR_KI1<<4)|VIF_CR_KP1;
           MDrv_IFDM_SetParameter(VIF_PARA_K_SEL, &kSel, sizeof(kSel));
           MDrv_IFDM_SetParameter(VIF_PARA_SET_HW_KPKI, &hwKpKi, sizeof(hwKpKi));
       }
    }
#endif
    #ifdef ENABLE_SUPPORT_ATV_STATION_NAME
    _DetectStationName();
    #endif
}
/******************************************************************************/
///- This function is called to set search manual-tune.
/// @param wTunerPLL \b IN: Tuner PLL
/// @return U16: The u16InterFreq nearest PLL of frequency table
/******************************************************************************/
U16 msAPI_Tuner_SetSearchManualTune(U16 u16InterFreq)
{
    U16 i,InterPLL,MinDiffPLL,OutputPLL;

    InterPLL = msAPI_CFT_ConvertFrequncyToPLL(u16InterFreq,0);

    OutputPLL = InterPLL;
    MinDiffPLL = 0xFFFF;

    for (i=msAPI_ATV_GetChannelMin(); i<msAPI_ATV_GetChannelMax(); i++)
    {
        if( msAPI_ATV_GetProgramPLLData(i) != DEFAULT_PLL)
        {
            if((msAPI_ATV_GetProgramPLLData(i) >= InterPLL) &&
                ((msAPI_ATV_GetProgramPLLData(i) - InterPLL) < MinDiffPLL))
            {
                MinDiffPLL = msAPI_ATV_GetProgramPLLData(i) - InterPLL;
                OutputPLL = msAPI_ATV_GetProgramPLLData(i);
            }
            else if((msAPI_ATV_GetProgramPLLData(i) < InterPLL) &&
                     ((InterPLL - msAPI_ATV_GetProgramPLLData(i)) < MinDiffPLL))
            {
                MinDiffPLL = InterPLL - msAPI_ATV_GetProgramPLLData(i);
                OutputPLL = msAPI_ATV_GetProgramPLLData(i);
            }
        }
    }

    _SetTunerPLL(OutputPLL);

    return     msAPI_CFT_ConvertPLLtoIntegerOfFrequency(OutputPLL);
}

/******************************************************************************/
///- This function is called to check demodulator's setting. It depends on audio standard.
/******************************************************************************/
#if (VIF_TUNER_TYPE==1)
extern BOOLEAN gbTVAutoScanChannelEnable;
#endif

void msAPI_Tuner_SetIF(void)
{
    //printf("msAPI_Tuner_SetIF()\n");

    if ( _IsLPrime() == TRUE )
    {
      #if ( (FRONTEND_IF_DEMODE_TYPE == MSTAR_VIF_MSB1210)  \
          ||(FRONTEND_IF_DEMODE_TYPE == MSTAR_VIF)          \
          ||(FRONTEND_IF_DEMODE_TYPE == MSTAR_INTERN_VIF)   )
        SECAM_L_PRIME_ON();
      #endif

        MDrv_IFDM_SetIF(IF_FREQ_L_PRIME);
    }
    else
    {
      #if( (FRONTEND_IF_DEMODE_TYPE == MSTAR_VIF_MSB1210)   \
         ||(FRONTEND_IF_DEMODE_TYPE == MSTAR_VIF)           \
         ||(FRONTEND_IF_DEMODE_TYPE == MSTAR_INTERN_VIF) )
         SECAM_L_PRIME_OFF();
      #endif

        #if (ENABLE_SBTVD_BRAZIL_APP == 1)
            MDrv_IFDM_SetIF(IF_FREQ_MN);
        #else
            {
                switch(MApi_AUDIO_SIF_ConvertToBasicAudioStandard(msAPI_AUD_GetAudioStandard()))
                {
                case E_AUDIOSTANDARD_BG:
                    MDrv_IFDM_SetIF(IF_FREQ_B);
                    #if (SILICON_R620D_TUNER==FRONTEND_TUNER_TYPE)
                    MDrv_IFDM_SetIF(IF_FREQ_G);
                    #endif
                    break;

                case E_AUDIOSTANDARD_I:
                    MDrv_IFDM_SetIF(IF_FREQ_I);
                    break;

                case E_AUDIOSTANDARD_DK:
                    MDrv_IFDM_SetIF(IF_FREQ_DK);
                    break;

                case E_AUDIOSTANDARD_L:
                    MDrv_IFDM_SetIF(IF_FREQ_L);
                    break;

                case E_AUDIOSTANDARD_M:
                    MDrv_IFDM_SetIF(IF_FREQ_MN);
                    break;

                default:
                    return;
                }
            }
        #endif
    }
}
void msAPI_Tuner_UserSetIF(AUDIOSTANDARD_TYPE  AudioStandard)
{
       switch(MApi_AUDIO_SIF_ConvertToBasicAudioStandard(AudioStandard))
       {
                case E_AUDIOSTANDARD_BG:
                    MDrv_IFDM_UserSetIF(IF_FREQ_B);
                    #if (SILICON_R620D_TUNER==FRONTEND_TUNER_TYPE)
                    MDrv_IFDM_UserSetIF(IF_FREQ_G);
                    #endif
                    break;
                case E_AUDIOSTANDARD_I:
                    MDrv_IFDM_UserSetIF(IF_FREQ_I);
                    break;
                case E_AUDIOSTANDARD_DK:
                    MDrv_IFDM_UserSetIF(IF_FREQ_DK);
                    break;
                case E_AUDIOSTANDARD_L:
                    MDrv_IFDM_UserSetIF(IF_FREQ_L);
                    break;
                case E_AUDIOSTANDARD_M:
                    MDrv_IFDM_UserSetIF(IF_FREQ_MN);
                    break;
                default:
                    MDrv_IFDM_UserSetIF(IF_FREQ_MN);
                    break;
     }
}
/******************************************************************************/
///- This function is called to get current channel PLL.
/// @return U16: current PLL value of tuner.
/******************************************************************************/
U16 msAPI_Tuner_GetCurrentChannelPLL(void)
{
    return _u16TunerPLL;
}

U16 msAPI_Tuner_GetCurrentChannelPLL2UiStr(void)
{
#if((AUTO_TUNING_TYPE_SEL==AUTO_TUNING_ALG_TST)&&(TV_SCAN_PAL_SECAM_ONCE==1))
    return _MenualScanPLL();
#else
    return _u16TunerPLL;
#endif
}

BOOLEAN msAPI_Tuner_IsCurrentChannelAndSavedChannelSame(void)
{
    U16 u16SavedTunerPLL;

    u16SavedTunerPLL = msAPI_ATV_GetProgramPLLData(msAPI_ATV_GetCurrentProgramNumber());

    if ( (msAPI_CFT_GetMedium(u16SavedTunerPLL) == msAPI_CFT_GetMedium(_u16TunerPLL)) &&
         (msAPI_CFT_GetChannelNumber(u16SavedTunerPLL) == msAPI_CFT_GetChannelNumber(_u16TunerPLL)) )
    {
        return TRUE;
    }

    return FALSE;
}

void msAPI_Tuner_ConvertMediumAndChannelNumberToString(MEDIUM eMedium, U8 u8ChannelNumber, BYTE * sStationName)
{
    if ( eMedium == MEDIUM_AIR )
    {
        sStationName[0] = 'C';    // Air
    }
    else
    {
        sStationName[0] = 'S';    // Cable
    }

    sStationName[1] = '-';
    sStationName[2] = (u8ChannelNumber / 10) + '0';
    sStationName[3] = (u8ChannelNumber % 10) + '0';
    sStationName[4] = ' ';
    sStationName[5] = '\0';
}


void msAPI_Tuner_GetCurrentStationName(BYTE *sName)
{
    U8 i;

    for ( i = 0; i < MAX_STATION_NAME; i++ )
    {
        sName[i] = _sCurrentStationName[i];
    }
}

void msAPI_Tuner_ChangeCurrentStationName(BYTE cStationNameChar, U8 u8Position)
{
    if ( u8Position >= strlen((char*)_sCurrentStationName))
    {
        return;
    }

    _sCurrentStationName[u8Position] = cStationNameChar;
}

BOOLEAN msAPI_Tuner_IsAFTNeeded(void)
{
    return _bIsAFTNeeded;
}

void msAPI_Tuner_SetAFTNeeded(BOOLEAN IsAFT)
{
    _bIsAFTNeeded=IsAFT;
}

void msAPI_Tuner_UpdateMediumAndChannelNumber(void)
{
    _eMedium = msAPI_CFT_GetMedium(_u16TunerPLL);

    _u8ChannelNumber = msAPI_CFT_GetChannelNumber(_u16TunerPLL);
}

//------------------------------------------------------------------------------
// Start of test function. Use the following functions to test.
// If you do not need the following functions, remove it.
//------------------------------------------------------------------------------
#if 1 //


#define MAX_VIDEOSTANDARDSTRING         8

typedef struct
{
    AVD_VideoStandardType eVideoStandard;
    BYTE sStandardSting[MAX_VIDEOSTANDARDSTRING];
} VIDEOSTANDARDINFO;

#define MAX_VIDEOSTANDARDINFO           7

static ROM VIDEOSTANDARDINFO m_VideoStandardInfo[MAX_VIDEOSTANDARDINFO] =
{
    {E_VIDEOSTANDARD_PAL_BGHI,          "PAL    "},
    {E_VIDEOSTANDARD_SECAM,             "SECAM  "},
    {E_VIDEOSTANDARD_PAL_N,             "PAL N  "},
    {E_VIDEOSTANDARD_PAL_M,             "PAL M  "},
    {E_VIDEOSTANDARD_PAL_60,            "PAL 60 "},
    {E_VIDEOSTANDARD_NTSC_M,            "NTSC M "},
    {E_VIDEOSTANDARD_NTSC_44,           "NTSC 44"}
};

static void msAPI_ConvertVideoStandardToString(AVD_VideoStandardType eVideoStandard, char *pcBuffer)
{
    BYTE i;

    for ( i = 0; i < MAX_VIDEOSTANDARDINFO; i++ )
    {
        if ( eVideoStandard == m_VideoStandardInfo[i].eVideoStandard )
        {
            _RomStringCopy(pcBuffer, (char ROM *)m_VideoStandardInfo[i].sStandardSting, MAX_VIDEOSTANDARDSTRING-1);
            return;
        }
    }

    if ( i == MAX_VIDEOSTANDARDINFO )
    {
        _RomStringCopy(pcBuffer, "ALLOM  ", MAX_VIDEOSTANDARDSTRING-1);
    }
}

#define MAX_AUDIOSTANDARDSTRING         9

typedef struct
{
    AUDIOSTANDARD_TYPE eAudioStandard;
    BYTE sStandardSting[MAX_AUDIOSTANDARDSTRING];
} AUDIOSTANDARDINFO;

#define MAX_AUDIOSTANDARDINFO           14

static ROM AUDIOSTANDARDINFO m_AudioStandardInfo[MAX_AUDIOSTANDARDINFO] =
{
    {E_AUDIOSTANDARD_BG,            "BG MONO "},
    {E_AUDIOSTANDARD_BG_A2,         "BG A2   "},
    {E_AUDIOSTANDARD_BG_NICAM,      "BG NICAM"},
    {E_AUDIOSTANDARD_I,             "I       "},
    {E_AUDIOSTANDARD_DK,            "DK MONO "},
    {E_AUDIOSTANDARD_DK1_A2,        "DK1 A2  "},
    {E_AUDIOSTANDARD_DK2_A2,        "DK2 A2  "},
    {E_AUDIOSTANDARD_DK3_A2,        "DK3 A2  "},
    {E_AUDIOSTANDARD_DK_NICAM,      "DK NICAM"},
    {E_AUDIOSTANDARD_L,             "L       "},
    {E_AUDIOSTANDARD_M,             "M MONO  "},
    {E_AUDIOSTANDARD_M_BTSC,        "M BTSC  "},
    {E_AUDIOSTANDARD_M_A2,          "M A2    "},
    {E_AUDIOSTANDARD_M_EIA_J,       "M EIA-J "}
};

static void msAPI_ConvertAudioStandardToString(AUDIOSTANDARD_TYPE eAudioStandard, char *pcBuffer)
{
    U8 i;

    for ( i = 0; i < MAX_AUDIOSTANDARDINFO; i++ )
    {
        if ( eAudioStandard == m_AudioStandardInfo[i].eAudioStandard )
        {
            _RomStringCopy(pcBuffer, ( char ROM *)m_AudioStandardInfo[i].sStandardSting, MAX_AUDIOSTANDARDSTRING-1);
            return;
        }
    }

    if ( i == MAX_AUDIOSTANDARDINFO )
    {
        _RomStringCopy(pcBuffer, "ALLOM   ", MAX_AUDIOSTANDARDSTRING-1);
    }
}

void msAPI_Tuner_PrintTVAVSourceInformation(void)
{
    char sChannelInfo[] = "ABCDE:000.00MHz NTSC 44 BG NICAM";
    WORD wIntegerOfFreq, wFractionOfFreq;
    U8 i;

    #define STATION_NAME_INFO_START_INDEX    0
#if ENABLE_TTX
    if ( TRUE != msAPI_TTX_GetStationNameFromTeletext((U8*)&sChannelInfo[STATION_NAME_INFO_START_INDEX], sizeof(sChannelInfo), NULL) )
#endif
    {
        msAPI_Tuner_ConvertMediumAndChannelNumberToString(_eMedium, _u8ChannelNumber, (U8*)&sChannelInfo[STATION_NAME_INFO_START_INDEX]);
        sChannelInfo[5]=' ';// can not print other message using msTV_tools
    }


    #define FREQUENCY_INFO_START_INDEX    6
    wIntegerOfFreq = msAPI_CFT_ConvertPLLtoIntegerOfFrequency(_u16TunerPLL);
    wFractionOfFreq = msAPI_CFT_ConvertPLLtoFractionOfFrequency(_u16TunerPLL);
    msAPI_ConvertFrequencyToString(wIntegerOfFreq, wFractionOfFreq, &sChannelInfo[FREQUENCY_INFO_START_INDEX]);

    #define VIDEO_STANDARD_INFO_START_INDEX    16
    msAPI_ConvertVideoStandardToString(msAPI_AVD_GetVideoStandard(), &sChannelInfo[VIDEO_STANDARD_INFO_START_INDEX]);

    #define AUDIO_STANDARD_INFO_START_INDEX    24
    msAPI_ConvertAudioStandardToString(msAPI_AUD_GetAudioStandard(), &sChannelInfo[AUDIO_STANDARD_INFO_START_INDEX]);

    putchar('\r');
    putchar('\n');
    printf("CH %3d: ", msAPI_ATV_GetCurrentProgramNumber()+1);
    for ( i = 0; i < (sizeof(sChannelInfo)/sizeof(sChannelInfo[0])-1); i++ )
    {
        putchar(sChannelInfo[i]);
    }
}
#endif

void msAPI_Tuning_IsScanL(BOOLEAN bEnable)
{
    _bIsLSearch = bEnable;
}
//------------------------------------------------------------------------------
// Local Functions.
//------------------------------------------------------------------------------

U16 msAPI_Tuner_GetIF(void)
{
    if ( FALSE == _IsLPrime() )
    {
    #if TN_FREQ_STEP == FREQ_STEP_62_5KHz
        return (WORD)((TUNER_IF_FREQ_KHz * 10) / 625);
    #elif TN_FREQ_STEP == FREQ_STEP_50KHz
        return (WORD)(TUNER_IF_FREQ_KHz / 50);
    #else
        return (WORD)((TUNER_IF_FREQ_KHz * 100) / 3125);
    #endif // TN_FREQ_STEP
    }
    else
    {
    #if TN_FREQ_STEP == FREQ_STEP_62_5KHz
        return (WORD)((TUNER_L_PRIME_IF_FREQ_KHz * 10) / 625);
    #elif TN_FREQ_STEP == FREQ_STEP_50KHz
        return (WORD)(TUNER_L_PRIME_IF_FREQ_KHz / 50);
    #else
        return (WORD)((TUNER_L_PRIME_IF_FREQ_KHz * 100) / 3125);
    #endif // TN_FREQ_STEP
    }
}

BOOLEAN msAPI_Tuner_IsCurrentAudioLPrime(void)
{
    WORD wTunerPLL;
    U32 u32TunerPLLI, u32TunerPLLF, u32LPrimeFreq;
    AUDIOSTANDARD_TYPE eAudioStandard;

    eAudioStandard = msAPI_AUD_GetAudioStandard();
    if (eAudioStandard != E_AUDIOSTANDARD_L)
        return FALSE;

    wTunerPLL = msAPI_Tuner_GetCurrentChannelPLL();
    u32TunerPLLI = (U32)msAPI_CFT_ConvertPLLtoIntegerOfFrequency(wTunerPLL);
    u32TunerPLLF = (U32)msAPI_CFT_ConvertPLLtoFractionOfFrequency(wTunerPLL);
    u32LPrimeFreq = (u32TunerPLLI*1000) + u32TunerPLLF;
    if (u32LPrimeFreq < (U32)L_PRIME_BOUNDARY_FREQ)
       return TRUE;

    return FALSE;
}

#if ENABLE_CUS_MANUAL_SCAN
static U32 _u32ManualScanFreq_Start;
static U32 _u32ManualScanFreq_End;

#define DBG_MANUAG_SCAN(x) //x
BOOLEAN msAPI_Tuner_SetManualScanStartFreq(U32 u32Freq)
{
    DBG_MANUAG_SCAN(printf("\r\n Set star freq:[%lu]",u32Freq));
    _u32ManualScanFreq_Start = u32Freq;
    return TRUE;

}
U32 msAPI_Tuner_GetManualScanStartFreq(void)
{
    DBG_MANUAG_SCAN(printf("\r\n Get star freq:[%lu]",_u32ManualScanFreq_Start));
    return _u32ManualScanFreq_Start;
}
BOOLEAN msAPI_Tuner_SetManualScanEndFreq(U32 u32Freq)
{
    DBG_MANUAG_SCAN(printf("\r\n Set End freq:[%lu]",u32Freq));/*Creass.liu at 2012-06-13*/
    _u32ManualScanFreq_End = u32Freq;
    return TRUE;
}

U32 msAPI_Tuner_GetManualScanEndFreq(void)
{
    DBG_MANUAG_SCAN(printf("\r\n Get End freq:[%lu]",_u32ManualScanFreq_End));/*Creass.liu at 2012-06-13*/
    return _u32ManualScanFreq_End;
}

BOOLEAN msAPI_Tuner_CheckManualScanStartAndEndFreq(void)
{
    DBG_MANUAG_SCAN(printf(" \n Check Start and End freq"));
    if( _u32ManualScanFreq_Start < (MIN_MANUAL_START_FREQ))
    {
        DBG_MANUAG_SCAN(printf(",and [1] Start << MIN_freq!\n"));
        _u32ManualScanFreq_Start = MIN_MANUAL_START_FREQ;
    }
    else if( _u32ManualScanFreq_Start >(MAX_MANUAL_END_FREQ))
    {
        DBG_MANUAG_SCAN(printf(",and [2] Start > MAX_freq!\n"));
        _u32ManualScanFreq_Start = MAX_MANUAL_END_FREQ;
    }
    else if( _u32ManualScanFreq_End <(MIN_MANUAL_START_FREQ))
    {
        DBG_MANUAG_SCAN(printf(",and [3] End << MIN_freq!\n"));
        _u32ManualScanFreq_End = MIN_MANUAL_START_FREQ;
    }
    else if(_u32ManualScanFreq_End > (MAX_MANUAL_END_FREQ))
    {
        DBG_MANUAG_SCAN(printf(",and [4] End > MAX_freq!\n"));
        _u32ManualScanFreq_End = MAX_MANUAL_END_FREQ;
    }
    else
    {
        DBG_MANUAG_SCAN(printf(" \n"));
    }

    if(_u32ManualScanFreq_Start > _u32ManualScanFreq_End)
    {
        U32 u32Freq_TEMP;
        DBG_MANUAG_SCAN(printf("-->Set End Freq:Start=[%lu],End =[%lu] \n",_u32ManualScanFreq_Start,_u32ManualScanFreq_End));

        u32Freq_TEMP = _u32ManualScanFreq_End;
        _u32ManualScanFreq_End = _u32ManualScanFreq_Start;
        _u32ManualScanFreq_Start = u32Freq_TEMP;
    }

    return TRUE;
}

U16 msAPI_Tuner_GetManualScanFreqConvertToPLL(U32 u32Freq)
{
    U16 u16PLL;
#if TN_FREQ_STEP == FREQ_STEP_62_5KHz
    u16PLL = (U16)( ( (DWORD)u32Freq*10/625 ));
#elif TN_FREQ_STEP == FREQ_STEP_50KHz
    u16PLL = (U16)( ( (DWORD)u32Freq/50 ));
#else
    u16PLL = (U16)( ( (DWORD)u32Freq*100/3125 ));
#endif // TN_FREQ_STEP
    return u16PLL;
}

void msAPI_Tuner_SetTunerPLLValue(U16 u16Pll)
{
    _u16TunerPLL = u16Pll;
}
#endif


#undef MSAPI_TUNING_C
