////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#define MAPP_ZUI_ACTINPUTSOURCE_C
#define _ZUI_INTERNAL_INSIDE_ //NOTE: for ZUI internal


//-------------------------------------------------------------------------------------------------
// Include Files
//-------------------------------------------------------------------------------------------------
#include "Board.h"
#include "datatype.h"
#include "MsCommon.h"
#include "apiXC.h"
#include "apiXC_Adc.h"
#include "MApp_GlobalSettingSt.h"
#include "MApp_ZUI_Main.h"
#include "MApp_ZUI_APIcommon.h"
#include "MApp_ZUI_APIstrings.h"
#include "MApp_ZUI_APIwindow.h"
#include "ZUI_tables_h.inl"
#include "MApp_ZUI_APIgdi.h"
#include "MApp_ZUI_APIcontrols.h"
#include "MApp_ZUI_ACTeffect.h"
#include "MApp_ZUI_ACTglobal.h"
#include "OSDcp_String_EnumIndex.h"
#include "ZUI_exefunc.h"
#include "MApp_ZUI_ACTmainpage.h"
#include "MApp_InputSource_Main.h"
#include "MApp_OSDPage_Main.h"
#include "MApp_ZUI_ACTinputsource.h"
#include "MApp_UiMenuDef.h"
#include "MApp_ChannelChange.h"
#include "MApp_Key.h"
#include "msAPI_Scaler_Adaptive.h"

#if (ENABLE_DTV)
#include "mapp_demux.h"
#endif

#include "msAPI_Tuning.h"
#include "MApp_InputSource.h"
#include "MApp_SaveData.h"
#include "MApp_PVR.h"
#include "MApp_UiPvr.h"
#include "MApp_UiPvr.h"
#if ENABLE_DMP
#include "MApp_DMP_Main.h"
#endif

#ifdef ENABLE_KTV
#include "MApp_KTV_Main.h"
#endif

#if 1 //def AP_COWORK
#include "MApp_APEngine.h"
#include "msAPI_APEngine.h"
#endif

#include "MApp_USBDownload.h"
#include "MApp_ZUI_APIstyletables.h"
#include "msAPI_OCP.h"
#include "msAPI_Bootloader.h"
#include "imginfo.h"
#include "drvGPIO.h"
#include "drvPWM.h"
#include "MApp_XC_PQ.h"

#include "drvGlobal.h"

/////////////////////////////////////////////////////////////////////
extern BOOLEAN _MApp_ZUI_API_WindowProcOnIdle(void);

extern EN_INPUTSOURCE_STATE enInputSourceState;

static EN_INPUTSOURCE_STATE _enTargetInputSourceState;

static U16 _u16LaunchKeys;

#if 0//def CUS_USB_UPDATE_FW
#include "cusUSBDownloadFileName.h"
extern BOOLEAN MW_UsbDownloadFullName (void);
#endif


extern BOOLEAN _MApp_ZUI_API_AllocateVarData(void);
#if 0//def ENABLE_CUS_FIRMWARE_UPGRADE_FUNCTION
extern BOOLEAN MDrv_UsbDeviceConnect(void);
extern BOOLEAN MDrv_UsbDeviceConnect_Port2(void);
extern U8 MDrv_USBGetPortEnableStatus(void);
//static U8 Source_USB_Upgrade_Percent = 0xFF;
#endif

typedef struct _SOURCE_SRC2HWND_STRUCT
{
    E_UI_INPUT_SOURCE source;
    HWND hwnd;
} SOURCE_SRC2HWND_STRUCT;

static SOURCE_SRC2HWND_STRUCT _ZUI_TBLSEG _source_items[] =
{
#if 0//vincent 20120604
#if (ENABLE_DTV)
    {
        UI_INPUT_SOURCE_DTV,            // VIDEO - DTV Tuner
        HWND_SOURCE_INPUT_ITEM_DTV
    },
#endif
    {
        UI_INPUT_SOURCE_ATV,             // VIDEO - TV Tuner
        HWND_SOURCE_INPUT_ITEM_TV
    },

#if DVB_T_C_DIFF_DB
    {
        UI_INPUT_SOURCE_CADTV,            // VIDEO - CATV Tuner
        HWND_SOURCE_INPUT_ITEM_CADTV
    },
#endif

#if (INPUT_SCART_VIDEO_COUNT >= 1)
{
        UI_INPUT_SOURCE_SCART,
        HWND_SOURCE_INPUT_ITEM_SCART1
    },
#endif
#if (INPUT_SCART_VIDEO_COUNT >= 2)
    {
        UI_INPUT_SOURCE_SCART2,
        HWND_SOURCE_INPUT_ITEM_SCART2
    },
#endif

#if (INPUT_YPBPR_VIDEO_COUNT>=1)
    {
        UI_INPUT_SOURCE_COMPONENT,
        HWND_SOURCE_INPUT_ITEM_COMPONENT1
    },
#endif
#if (INPUT_YPBPR_VIDEO_COUNT >= 2)
    {
        UI_INPUT_SOURCE_COMPONENT2,
        HWND_SOURCE_INPUT_ITEM_COMPONENT2
    },
#endif

    {
        UI_INPUT_SOURCE_RGB,            // PC - VGA
        HWND_SOURCE_INPUT_ITEM_PC
    },

#if (INPUT_HDMI_VIDEO_COUNT >= 1)
    {
        UI_INPUT_SOURCE_HDMI,           // HDMI
        HWND_SOURCE_INPUT_ITEM_HDMI1
    },
#endif
#if (INPUT_HDMI_VIDEO_COUNT >= 2)
    {
        UI_INPUT_SOURCE_HDMI2,
        HWND_SOURCE_INPUT_ITEM_HDMI2
    },
#endif
#if (INPUT_HDMI_VIDEO_COUNT >= 3)
    {
        UI_INPUT_SOURCE_HDMI3,
        HWND_SOURCE_INPUT_ITEM_HDMI3
    },
#endif
#if (INPUT_HDMI_VIDEO_COUNT >= 4)
    {
        UI_INPUT_SOURCE_HDMI4,
        HWND_SOURCE_INPUT_ITEM_HDMI4
    },
#endif

#if (INPUT_AV_VIDEO_COUNT >= 1)
    {
        UI_INPUT_SOURCE_AV,             // VIDEO - CVBS
        HWND_SOURCE_INPUT_ITEM_AV1
    },
#endif
#if (INPUT_AV_VIDEO_COUNT >= 2)
    {
        UI_INPUT_SOURCE_AV2,             // VIDEO - CVBS
        HWND_SOURCE_INPUT_ITEM_AV2
    },
#endif
#if (INPUT_AV_VIDEO_COUNT >= 3)
    {
        UI_INPUT_SOURCE_AV3,             // VIDEO - CVBS
        HWND_SOURCE_INPUT_ITEM_AV3
    },
#endif

#if (INPUT_SV_VIDEO_COUNT >= 1)
    {
        UI_INPUT_SOURCE_SVIDEO,
        HWND_SOURCE_INPUT_ITEM_SVIDEO1
    },
#endif
#if ((INPUT_SCART_USE_SV2 == 0) && (INPUT_SV_VIDEO_COUNT >= 2))
    {
        UI_INPUT_SOURCE_SVIDEO2,
        HWND_SOURCE_INPUT_ITEM_SVIDEO2
    },
#endif
#if (ENABLE_DMP)
  #if( ENABLE_DMP_SWITCH )
    {
         UI_INPUT_SOURCE_DMP1,
         HWND_SOURCE_INPUT_ITEM_USB1
    },
    {
         UI_INPUT_SOURCE_DMP2,
         HWND_SOURCE_INPUT_ITEM_USB2
    },
 #endif
#endif
#ifdef ENABLE_KTV
    {
         UI_INPUT_SOURCE_KTV,
         HWND_SOURCE_INPUT_ITEM_KTV
    },
#endif
#else
#if 0//NO_NEED_ATV_EN
    {
        UI_INPUT_SOURCE_ATV,             // VIDEO - TV Tuner
        HWND_SOURCE_INPUT_ITEM_TV
    },
#endif
#if 1//NO_NEED_AV_EN
#if (INPUT_AV_VIDEO_COUNT >= 1)
	{
		UI_INPUT_SOURCE_AV, 			// VIDEO - CVBS
		HWND_SOURCE_INPUT_ITEM_AV1
	},
#endif
#endif
#if (INPUT_AV_VIDEO_COUNT >= 2)
	{
		UI_INPUT_SOURCE_AV2,			 // VIDEO - CVBS
		HWND_SOURCE_INPUT_ITEM_AV2
	},
#endif
#if (INPUT_AV_VIDEO_COUNT >= 3)
	{
		UI_INPUT_SOURCE_AV3,			 // VIDEO - CVBS
		HWND_SOURCE_INPUT_ITEM_AV3
	},
#endif

#if 0//NO_NEED_YPBPR_EN
#if (INPUT_YPBPR_VIDEO_COUNT>=1)
    {
        UI_INPUT_SOURCE_COMPONENT,
        HWND_SOURCE_INPUT_ITEM_COMPONENT1
    },
#endif
#endif
#if (INPUT_YPBPR_VIDEO_COUNT >= 2)
    {
        UI_INPUT_SOURCE_COMPONENT2,
        HWND_SOURCE_INPUT_ITEM_COMPONENT2
    },
#endif

    {
        UI_INPUT_SOURCE_RGB,            // PC - VGA
        HWND_SOURCE_INPUT_ITEM_PC
    },

#if (INPUT_HDMI_VIDEO_COUNT >= 1)
    {
        UI_INPUT_SOURCE_HDMI,           // HDMI
        HWND_SOURCE_INPUT_ITEM_HDMI1
    },
#endif
#if (INPUT_HDMI_VIDEO_COUNT >= 2)
    {
        UI_INPUT_SOURCE_HDMI2,
        HWND_SOURCE_INPUT_ITEM_HDMI2
    },
#endif
#if (INPUT_HDMI_VIDEO_COUNT >= 3)
    {
        UI_INPUT_SOURCE_HDMI3,
        HWND_SOURCE_INPUT_ITEM_HDMI3
    },
#endif
#if (INPUT_HDMI_VIDEO_COUNT >= 4)
    {
        UI_INPUT_SOURCE_HDMI4,
        HWND_SOURCE_INPUT_ITEM_HDMI4
    },
#endif


#if (INPUT_SV_VIDEO_COUNT >= 1)
    {
        UI_INPUT_SOURCE_SVIDEO,
        HWND_SOURCE_INPUT_ITEM_SVIDEO1
    },
#endif
#if ((INPUT_SCART_USE_SV2 == 0) && (INPUT_SV_VIDEO_COUNT >= 2))
    {
        UI_INPUT_SOURCE_SVIDEO2,
        HWND_SOURCE_INPUT_ITEM_SVIDEO2
    },
#endif
#if (ENABLE_DMP)
  #if( ENABLE_DMP_SWITCH )

 #ifndef ENABLE_DMP_ONE_PORT		// CUS_XM Sea 20120629:
    {
         UI_INPUT_SOURCE_DMP1,
         HWND_SOURCE_INPUT_ITEM_USB1
    },
 #endif
 #if 0//(!MGMT_BOARD_DEF)//minglin1231
    {
         UI_INPUT_SOURCE_DMP2,
         HWND_SOURCE_INPUT_ITEM_USB2
    },
#endif    
#else
	{
		 UI_INPUT_SOURCE_DMP,
		 HWND_SOURCE_INPUT_ITEM_USB1
	},

#endif
#endif
#ifdef ENABLE_KTV
    {
         UI_INPUT_SOURCE_KTV,
         HWND_SOURCE_INPUT_ITEM_KTV
    },
#endif

#endif

};

static E_UI_INPUT_SOURCE _MApp_ZUI_ACT_InputSourceWindowMapToId(HWND hwnd)
{
    U8 i;
    for (i = 0; i < COUNTOF(_source_items); i++)
    {
        if (hwnd == _source_items[i].hwnd ||
            MApp_ZUI_API_IsSuccessor(_source_items[i].hwnd, hwnd))
        {
            return _source_items[i].source;
        }
    }
    return _source_items[0].source;
}

static HWND _MApp_ZUI_ACT_InputSourceIdMapToWindow(E_UI_INPUT_SOURCE id)
{
    U8 i;
    for (i = 0; i < COUNTOF(_source_items); i++)
    {
        if (id == _source_items[i].source)
        {
            return _source_items[i].hwnd;
        }
    }
    return _source_items[0].hwnd;
}

/*
static void _MApp_ZUI_ACT_InputSource_SwUpdate_Progress(U8 percent)
{
    U8 u8tmp = 0;
    static const HWND aUpdateWindows[] =
    {
        HWND_SOURCE_FWUPGRADE_TEXT1,
        HWND_SOURCE_FWUPGRADE_TEXT2,
        HWND_SOURCE_FWUPGRADE_PROGRESS_BAR,
        HWND_SOURCE_FWUPGRADE_PROGRESS_VALUE,
    };
    u8tmp = sizeof(aUpdateWindows)/sizeof(HWND);
    Source_USB_Upgrade_Percent = percent;
    //MApp_ZUI_CTL_PercentProgressBar_SetPercentage(percent);
    _MApp_ZUI_API_ForceUpdateWindows((HWND*)aUpdateWindows,u8tmp);

    //Updating Need LED Blink ???
    if((percent/2) % 2 == 0)
    {
        LED_RED_ON();
        LED_GREEN_OFF();
    }
    else
    {
        LED_RED_OFF();
        LED_GREEN_ON();
    }

    return;
}

*/

void MApp_ZUI_ACT_AppShowInputSource(void)
{
    HWND wnd;
    RECT rect;
    E_OSD_ID osd_id = E_OSD_INPUT_SOURCE;

    g_GUI_WindowList = GetWindowListOfOsdTable(osd_id);
    g_GUI_WinDrawStyleList = GetWindowStyleOfOsdTable(osd_id);
    g_GUI_WindowPositionList = GetWindowPositionOfOsdTable(osd_id);
#if ZUI_ENABLE_ALPHATABLE
    g_GUI_WinAlphaDataList = GetWindowAlphaDataOfOsdTable(osd_id);
#endif
    HWND_MAX = GetWndMaxOfOsdTable(osd_id);
    OSDPAGE_BLENDING_ENABLE = IsBlendingEnabledOfOsdTable(osd_id);
    OSDPAGE_BLENDING_VALUE = GetBlendingValueOfOsdTable(osd_id);

    if (!_MApp_ZUI_API_AllocateVarData())
    {
        ZUI_DBG_FAIL(printf("[ZUI]ALLOC\n"));
        ABORT();
        return;
    }

    //RECT_SET(rect, ((g_IPanel.HStart()+3)&0xFFFC), 1, g_IPanel.Width(), g_IPanel.Height());
    RECT_SET(rect,
        ZUI_INPUT_SOURCE_XSTART, ZUI_INPUT_SOURCE_YSTART,
        ZUI_INPUT_SOURCE_WIDTH, ZUI_INPUT_SOURCE_HEIGHT);

    if (!MApp_ZUI_API_InitGDI(&rect))
    {
        ZUI_DBG_FAIL(printf("[ZUI]GDIINIT\n"));
        ABORT();
        return;
    }

    for (wnd = 0; wnd < HWND_MAX; wnd++)
    {
        //printf("create msg: %lu\n", (U32)wnd);
        MApp_ZUI_API_SendMessage(wnd, MSG_CREATE, 0);
    }

    MApp_ZUI_API_ShowWindow(HWND_MAINFRAME, SW_SHOW);
    MApp_ZUI_API_ShowWindow(HWND_PVR_SOURCE_CHANGE_CHECK_PANE, SW_HIDE);
    MApp_ZUI_API_ShowWindow(HWND_SOURCE_FWUPGRADE_BG, SW_HIDE);
    MApp_ZUI_API_SetFocus(_MApp_ZUI_ACT_InputSourceIdMapToWindow(UI_INPUT_SOURCE_TYPE));
    MApp_ZUI_API_SendMessage(HWND_SOURCE_INPUT_LIST, MSG_NOTIFY_CONTENT_CHANGED, 0);

#if ENABLE_SBTVD_BRAZIL_APP
#if ENABLE_DMP
    if((UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_DMP))
    {
        if(UI_PREV_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_ATV && msAPI_ATV_GetCurrentAntenna() == ANT_AIR)
        {
            MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_SOURCE_INPUT_LIST,
                _MApp_ZUI_ACT_InputSourceIdMapToWindow(UI_INPUT_SOURCE_ANTENNA));
        }
        else
        {
            MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_SOURCE_INPUT_LIST,
                _MApp_ZUI_ACT_InputSourceIdMapToWindow(UI_PREV_INPUT_SOURCE_TYPE));
        }
    }
    else
#endif
    {
       if(msAPI_ATV_GetCurrentAntenna() == ANT_AIR && UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_ATV)
       {
          MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_SOURCE_INPUT_LIST,
              _MApp_ZUI_ACT_InputSourceIdMapToWindow(UI_INPUT_SOURCE_ANTENNA));
       }
       else
       {
          MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_SOURCE_INPUT_LIST,
              _MApp_ZUI_ACT_InputSourceIdMapToWindow(UI_INPUT_SOURCE_TYPE));
       }
    }
#else
#if ENABLE_DMP
    if((UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_DMP))
    {
        MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_SOURCE_INPUT_LIST,
            _MApp_ZUI_ACT_InputSourceIdMapToWindow(UI_PREV_INPUT_SOURCE_TYPE));
    }
    else
    #endif
    MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_SOURCE_INPUT_LIST,
        _MApp_ZUI_ACT_InputSourceIdMapToWindow(UI_INPUT_SOURCE_TYPE));
#endif


    MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_OPEN, E_ZUI_STATE_RUNNING);
    _u16LaunchKeys = 0xFFFF;

}

LPTSTR MApp_ZUI_ACT_GetInputSourceDynamicText(HWND hwnd)
{
    U16 u16TempID = Empty;
    switch(hwnd)
    {
        case HWND_SOURCE_INPUT_ITEM_DTV_TEXT:
#if ENABLE_SBTVD_BRAZIL_APP
            u16TempID = en_str_Tune_Type_Air;
#else
            u16TempID = en_strInputSourceDtvText;
#endif
            break;

        case HWND_SOURCE_INPUT_ITEM_TV_TEXT:
#if ENABLE_SBTVD_BRAZIL_APP
            u16TempID = en_str_Tune_Type_Cable;
#else
        #if ENABLE_CUS_UI_SPEC
            u16TempID = en_strIcon_TV;
        #else
            u16TempID = en_strInputSourceAtvText;
        #endif
#endif
            break;
        case HWND_SOURCE_INPUT_ITEM_CADTV:
            u16TempID = en_strInputSourceCADTVText;
            break;

        #if (INPUT_AV_VIDEO_COUNT >= 1)
        case HWND_SOURCE_INPUT_ITEM_AV1_TEXT:
            u16TempID = en_strInputSourceAvText;
            #if (INPUT_AV_VIDEO_COUNT >= 2)
            u16TempID = en_strInputSourceAv1Text;
            #endif
            break;
        #endif

       #if (INPUT_AV_VIDEO_COUNT >= 2)
        case HWND_SOURCE_INPUT_ITEM_AV2:
            u16TempID = en_strInputSourceAv2Text;
            break;
       #endif
       #if (INPUT_YPBPR_VIDEO_COUNT >= 1)
        case HWND_SOURCE_INPUT_ITEM_COMPONENT1_TEXT:
            u16TempID = en_str_InputSource_Component;
           #if (INPUT_YPBPR_VIDEO_COUNT >= 2)
            u16TempID = en_strYPbPrText;
           #endif
            break;
       #endif
       case HWND_SOURCE_INPUT_ITEM_USB1_TEXT:
           #if (!ENABLE_DMP_SWITCH)  //SMC jayden.chen  //ENABLE_CUS_UI_SPEC
            u16TempID = en_str_USB;
           #else
            u16TempID = en_str_USB1;
           #endif
            break;
       case HWND_SOURCE_INPUT_ITEM_PC_TEXT:
           #if ENABLE_CUS_UI_SPEC
            u16TempID = en_strInputLockVGAText;
           #else
            u16TempID = en_strInputSource_RGB_PC;
           #endif
            break;
       #if (INPUT_HDMI_VIDEO_COUNT >= 1)
       case HWND_SOURCE_INPUT_ITEM_HDMI1_TEXT:
            u16TempID = en_strInputSourceHdmiText;
           #if (INPUT_HDMI_VIDEO_COUNT >= 2)
            u16TempID = en_strInputSourceHdmi1Text;
           #endif
            break;
       #endif

    /*
       #ifdef ENABLE_CUS_FIRMWARE_UPGRADE_FUNCTION
       case HWND_SOURCE_FWUPGRADE_TEXT1:
            if(Source_USB_Upgrade_Percent <=100)
            {
                u16TempID = en_strFwUpgradeInProgressText1;
            }
            else
            {
                u16TempID = en_str_SW_USB_Upgrade;
            }
            break;
       case HWND_SOURCE_FWUPGRADE_PROGRESS_VALUE:
           if(Source_USB_Upgrade_Percent<=100)
           {
               MApp_ZUI_API_GetU16String((U16)Source_USB_Upgrade_Percent);
               if(Source_USB_Upgrade_Percent < 10 )
               {
                   CHAR_BUFFER[1] = CHAR_SPACE;
                   CHAR_BUFFER[2] = CHAR_SPACE;
               }
               else if(Source_USB_Upgrade_Percent < 100)
               {
                   CHAR_BUFFER[2] = CHAR_SPACE;
               }
               CHAR_BUFFER[3] = CHAR_PERCENT;
               CHAR_BUFFER[4] = '\0';
           }
           else
           {
               MApp_ZUI_API_GetU16String((U16)0);
               CHAR_BUFFER[1] = CHAR_SPACE;
               CHAR_BUFFER[2] = CHAR_SPACE;
               CHAR_BUFFER[3] = CHAR_PERCENT;
               CHAR_BUFFER[4] = '\0';

           }
           return CHAR_BUFFER;


            break;
       case HWND_SOURCE_FWUPGRADE_TEXT2:
           if(Source_USB_Upgrade_Percent != 0xFF)
           {
               if(Source_USB_Upgrade_Percent == 0xFE)
               {
                   U8 str[] = {"CRC Error"};
                   MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER,str, strlen((const char *)str));
               }
               else if(Source_USB_Upgrade_Percent == 0xFD)
               {
                   U8 str[] = {"Fail to Burn AP Code"};
                   MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, str, strlen((const char *)str));
               }
               else if(Source_USB_Upgrade_Percent == 0xFC)
               {
                   U8 str[] = {"Unknown image type"};
                   MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, str, strlen((const char *)str));
               }
               else if(Source_USB_Upgrade_Percent == 0xFB)
               {
                   U8 str[] = {"Reboot fail"};
                   MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, str, strlen((const char *)str));
               }
               else if(Source_USB_Upgrade_Percent == 0xFA)
               {
                   U8 str[] = {"Failed to update software"};
                   MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, str, strlen((const char *)str));
               }
               else if(Source_USB_Upgrade_Percent <=100)
               {
                   u16TempID = en_strFwUpgradeInProgressText2;
                   break;
               }
               else
               {
                   return 0;
               }
               return CHAR_BUFFER;
           }
           else
           {
               #ifdef ENABLE_CUS_SW_VERSION
                U8 u8strlen;
                MS_IMG_INFO ImgInfo;
                U8 u8SW_VersionHight,u8SW_VersionLow;
                MApp_ImgInfo_GetAppInfo(&ImgInfo);//read from flash.
                u8SW_VersionHight = (ImgInfo.u16SW_Version&0xFF00)>>8;
                u8SW_VersionLow = ImgInfo.u16SW_Version&0x00FF;

                MApp_ZUI_API_LoadString(en_strDoYouWantUpgrade, CHAR_BUFFER);
                u8strlen = MApp_ZUI_API_Strlen(CHAR_BUFFER);
                CHAR_BUFFER[u8strlen++] = ((u8SW_VersionHight/100) == 0) ? ' ' : '0'+(u8SW_VersionHight/100);
                CHAR_BUFFER[u8strlen++] = (((u8SW_VersionHight%100)/10) == 0) ? ' ' : '0'+((u8SW_VersionHight%100)/10);
                CHAR_BUFFER[u8strlen++] = '0'+(u8SW_VersionHight%10);
                CHAR_BUFFER[u8strlen++] = CHAR_DOT;
                CHAR_BUFFER[u8strlen++] = ((u8SW_VersionLow/100) == 0) ? ' ' : '0'+(u8SW_VersionLow/100);
                CHAR_BUFFER[u8strlen++] = '0'+((u8SW_VersionLow%100)/10);
                CHAR_BUFFER[u8strlen++] = '0'+(u8SW_VersionLow%10);
                CHAR_BUFFER[u8strlen++] = CHAR_SPACE;
                CHAR_BUFFER[u8strlen++]= CHAR_t;
                CHAR_BUFFER[u8strlen++] = CHAR_o;
                CHAR_BUFFER[u8strlen++] = CHAR_SPACE;
                CHAR_BUFFER[u8strlen++] = 'x'; // TODO:
                CHAR_BUFFER[u8strlen++] = '.';
                CHAR_BUFFER[u8strlen++] = 'x'; // TODO:
                CHAR_BUFFER[u8strlen++] = '?';

#if  0
#ifdef  CUS_USB_UPDATE_FW
                CHAR_BUFFER[u8strlen++] = '\n';

		  {

	            U8 i;
	            U8 l ;
	            U8* pu8cusUpdateAllFileName;

			if (MW_UsbDownloadFullName() == TRUE)
			{
	           		pu8cusUpdateAllFileName = CUS_USB_DOWNLOAD_FILE_FULL_NAME;
	            		l = strlen(CUS_USB_DOWNLOAD_FILE_FULL_NAME);
			}
			else
			{
	           		pu8cusUpdateAllFileName = CUS_USB_UPDATE_ALL_FW;
	            		l = strlen(CUS_USB_UPDATE_ALL_FW);

			}

	            for (i=0; i<l; i++)
	            {
                		CHAR_BUFFER[u8strlen++] = *(pu8cusUpdateAllFileName+i);
	            }

		  }

#endif
#endif

                CHAR_BUFFER[u8strlen++] = 0;

                return CHAR_BUFFER;
              #else
                u16TempID = en_str_AreYouSure;
                break;
              #endif
           }
           break;

       #endif
     */

    }

    if (u16TempID != Empty)
        return MApp_ZUI_API_GetString(u16TempID);
    return 0; //for empty string....
}
S16 MApp_ZUI_ACT_GetInputSourceDynamicValue(HWND hwnd)
{
   switch(hwnd)
    {
        /*case HWND_SOURCE_FWUPGRADE_PROGRESS_BAR: //case EN_DNUM_GetenA1_ScanPercentageValue:

	{
            if(Source_USB_Upgrade_Percent>100)
            {
                if(Source_USB_Upgrade_Percent == 0xff)
                {
                    return 0;
                }
                return 100;
            }
            return Source_USB_Upgrade_Percent;
        }
        */
        default:
        break;

    }

    return 0; //for empty  data
}


#if ENABLE_OFFLINE_SIGNAL_DETECTION
void MApp_ZUI_ACT_DrawAisIcon(void)
{
    if(MApp_ZUI_API_IsWindowVisible(HWND_SOURCE_INPUT_LIST))
    {
        if(stAISSrcList[UI_INPUT_SOURCE_COMPONENT].bChangeFlag)
        {
            MApp_ZUI_API_InvalidateWindow(HWND_SOURCE_INPUT_ITEM_COMPONENT1);
        }
        else if(stAISSrcList[UI_INPUT_SOURCE_AV].bChangeFlag)
        {
            MApp_ZUI_API_InvalidateWindow(HWND_SOURCE_INPUT_ITEM_AV1);
        }
        else if(stAISSrcList[UI_INPUT_SOURCE_RGB].bChangeFlag)
        {
            MApp_ZUI_API_InvalidateWindow(HWND_SOURCE_INPUT_ITEM_PC);
        }
    }
}
#endif

U16 MApp_ZUI_ACT_GetInputSourceDynamicBitmap(HWND hwnd, DRAWSTYLE_TYPE ds_type)
{
    UNUSED(ds_type);
#if ENABLE_OFFLINE_SIGNAL_DETECTION
    switch(hwnd)
    {
        case HWND_SOURCE_INPUT_ITEM_COMPONENT1_ICON:
            if(stAISSrcList[UI_INPUT_SOURCE_COMPONENT].bHaveSignal)
            {
                return E_BMP_ARROW_BACKSPACE;
            }
            else
            {
                return 0xFFFF;
            }
            break;
        case HWND_SOURCE_INPUT_ITEM_PC_ICON:
            if(stAISSrcList[UI_INPUT_SOURCE_RGB].bHaveSignal)
            {
                return E_BMP_ARROW_BACKSPACE;
            }
            else
            {
                return 0xFFFF;
            }
            break;
        case HWND_SOURCE_INPUT_ITEM_AV1_ICON:
            if(stAISSrcList[UI_INPUT_SOURCE_AV].bHaveSignal)
            {
                return E_BMP_ARROW_BACKSPACE;
            }
            else
            {
                return 0xFFFF;
            }
            break;
        default:
            return 0xFFFF;
            break;
    }
#else
    switch(hwnd)
    {
        case HWND_SOURCE_INPUT_ITEM_TV_SELECT:
            if(IsATVInUse())
            {
            	  #if(UI_SKIN_SEL==UI_SKIN_1366X768X565_HAIER_CN) // cus_xm helen add 20120811
						return E_BMP_SOURCE_TV;
				  #else
                return E_BMP_PIONEER_SOUCELIST_ICON;
				  #endif
            }
            else
            {
                return 0xFFFF;
            }
            break;
        case HWND_SOURCE_INPUT_ITEM_AV1_SELECT:
            if(UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_AV)
            {
                return E_BMP_PIONEER_SOUCELIST_ICON;
            }
            else
            {
                return 0xFFFF;
            }
            break;
       #if (INPUT_AV_VIDEO_COUNT >= 2)
        case HWND_SOURCE_INPUT_ITEM_AV2_SELECT:
            if(UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_AV2)
            {
                return E_BMP_PIONEER_SOUCELIST_ICON;
            }
            else
            {
                return 0xFFFF;
            }
            break;
       #endif
       #if (INPUT_YPBPR_VIDEO_COUNT >= 1)
        case HWND_SOURCE_INPUT_ITEM_COMPONENT1_SELECT:
            if(UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_COMPONENT)
            {
                return E_BMP_PIONEER_SOUCELIST_ICON;
            }
            else
            {
                return 0xFFFF;
            }
            break;
       #endif
       #if (INPUT_YPBPR_VIDEO_COUNT >= 2)
        case HWND_SOURCE_INPUT_ITEM_COMPONENT2_SELECT:
            if(UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_COMPONENT2)
            {
                return E_BMP_PIONEER_SOUCELIST_ICON;
            }
            else
            {
                return 0xFFFF;
            }
            break;
       #endif
       #if (INPUT_HDMI_VIDEO_COUNT >= 1)
        case HWND_SOURCE_INPUT_ITEM_HDMI1_SELECT:
            if(UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_HDMI)
            {
                return E_BMP_PIONEER_SOUCELIST_ICON;
            }
            else
            {
                return 0xFFFF;
            }
            break;
       #endif
       #if (INPUT_HDMI_VIDEO_COUNT >= 2)
        case HWND_SOURCE_INPUT_ITEM_HDMI2_SELECT:
            if(UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_HDMI2)
            {
                return E_BMP_PIONEER_SOUCELIST_ICON;
            }
            else
            {
                return 0xFFFF;
            }
            break;
       #endif
       #if (INPUT_HDMI_VIDEO_COUNT >= 3)
        case HWND_SOURCE_INPUT_ITEM_HDMI3_SELECT:
            if(UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_HDMI3)
            {
                return E_BMP_PIONEER_SOUCELIST_ICON;
            }
            else
            {
                return 0xFFFF;
            }
            break;
       #endif
       #if (INPUT_HDMI_VIDEO_COUNT >= 4)
        case HWND_SOURCE_INPUT_ITEM_HDMI4_SELECT:
            if(UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_HDMI4)
            {
                return E_BMP_PIONEER_SOUCELIST_ICON;
            }
            else
            {
                return 0xFFFF;
            }
            break;
       #endif
        case HWND_SOURCE_INPUT_ITEM_PC_SELECT:
            if(UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_RGB)
            {
                return E_BMP_PIONEER_SOUCELIST_ICON;
            }
            else
            {
                return 0xFFFF;
            }
            break;
     #if (ENABLE_DMP)
        case HWND_SOURCE_INPUT_ITEM_USB1_SELECT:
           #if( ENABLE_DMP_SWITCH )
            if(UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_DMP1)
           #else
            if(UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_DMP)
           #endif
            {
                return E_BMP_PIONEER_SOUCELIST_ICON;
            }
            else
            {
                return 0xFFFF;
            }
            break;

       #if( ENABLE_DMP_SWITCH )
        case HWND_SOURCE_INPUT_ITEM_USB2_SELECT:
            if(UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_DMP2)
            {
                return E_BMP_PIONEER_SOUCELIST_ICON;
            }
            else
            {
                return 0xFFFF;
            }
            break;
       #endif
     #endif
        default:
            return 0xFFFF;
            break;
    }
#endif
    return 0xFFFF; //for empty bitmap....
}

//////////////////////////////////////////////////////////
// Key Handler
#if ENABLE_MULTI_PANELS
extern void test_panel_set(U16 RES);
#endif
BOOLEAN MApp_ZUI_ACT_HandleInputSourceKey(VIRTUAL_KEY_CODE key)
{
    //note: this function will be called in running state
    //reset timer if any key
    MApp_ZUI_API_ResetTimer(HWND_SOURCE_BG_PANE, 0);
    switch(key)
    {
        case VK_MENU:
            #ifdef ENABLE_CUS_FIRMWARE_UPGRADE_FUNCTION
            if(MApp_ZUI_API_IsSuccessor(HWND_SOURCE_FWUPGRADE_BG, MApp_ZUI_API_GetFocus()))
            {

            }
            else
            #endif
            {
                MApp_ZUI_ACT_ExecuteInputSourceAction(EN_EXE_GOTO_MAINMENU);
            }
            return TRUE;
        case VK_EXIT:
            #ifdef ENABLE_CUS_FIRMWARE_UPGRADE_FUNCTION
            if(MApp_ZUI_API_IsSuccessor(HWND_SOURCE_FWUPGRADE_BG, MApp_ZUI_API_GetFocus()))
            {

            }
            else
            #endif
            {
                MApp_ZUI_ACT_ExecuteInputSourceAction(EN_EXE_CLOSE_CURRENT_OSD);
            }
            return TRUE;
        case VK_POWER:
            MApp_ZUI_ACT_ExecuteInputSourceAction(EN_EXE_POWEROFF);
            return TRUE;
        case VK_SELECT:
            #ifdef ENABLE_CUS_FIRMWARE_UPGRADE_FUNCTION
            if(MApp_ZUI_API_IsSuccessor(HWND_SOURCE_FWUPGRADE_BG, MApp_ZUI_API_GetFocus()))
            {
                ;
            }
            else
            #endif
            {
                MApp_ZUI_API_SetTimer(HWND_SOURCE_BOTTOM_OK_BTN, 0, BUTTONANICLICK_PERIOD);
                MApp_ZUI_API_InvalidateWindow(HWND_SOURCE_BOTTOM_OK_BTN);
            }
            break;
        #ifdef ENABLE_BUTTON_LOCK
        case VK_KEY_BUTTON_LOCK:
            if(IsStorageInUse())
            {
                u8KeyCode = KEY_NULL;
                return TRUE;
            }
            else
            {
                MApp_ZUI_ACT_ExecuteInputSourceAction(EN_EXE_CLOSE_CURRENT_OSD);
            }
            return TRUE;
        #endif

		#if CUS_SMC_ENABLE_HOTEL_MODE
        case VK_KEY_SOURCE_KEY_LOCK:
            if(IsStorageInUse())
            {
                u8KeyCode = KEY_NULL;
                return TRUE;
            }
            else
            {
                MApp_ZUI_ACT_ExecuteInputSourceAction(EN_EXE_CLOSE_CURRENT_OSD);
            }
            return TRUE;
        #endif

        case VK_INPUT_SOURCE:
        {
            break;
        }
        default:
            break;
    }


    //launch code for factory menu, instart menu, media player(testing)
    if (VK_NUM_0 <= key && key <= VK_NUM_9)
    {
      ZUI_MSG(printf("key:=%x\n",key););
        _u16LaunchKeys = (_u16LaunchKeys<<4)|(key-VK_NUM_0);
       ZUI_MSG(printf("_u16LaunchKeys:=%xl\n",_u16LaunchKeys););
       //_u16LaunchKeys = (_u16LaunchKeys<<4)|(key-VK_UP);
        switch (_u16LaunchKeys)

        {
        	//#if(ENABLE_CUS_UI_SPEC==DISABLE)// cus_xm gary20120716  modify  enter factory menu
        	 case 0x2580:
		   g_bGotoCUSMenu = 0;
                MApp_ZUI_ACT_ExecuteInputSourceAction(EN_EXE_GOTO_FACTORY_MENU);
                break;
             case 0x2588:
                MApp_ZUI_ACT_ExecuteInputSourceAction(EN_EXE_GOTO_EXPERT_MENU);
                break;
		  #if CUS_SMC_ENABLE_HOTEL_MODE
			 case 0x1234:
				g_bGotoCUSMenu = 3;
                MApp_ZUI_ACT_ExecuteInputSourceAction(EN_EXE_GOTO_FACTORY_MENU);
				break;
		  #endif
		//#endif

		/*	case 0x4567:
            {
	#ifdef ENABLE_CUS_FIRMWARE_UPGRADE_FUNCTION
            #if ( ENABLE_SW_UPGRADE && ENABLE_FILESYSTEM )

                U8 u8PortEnStatus = 0;

                #if ENABLE_DMP
                // for dmp
                if((UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_DMP)
            #if( ENABLE_DMP_SWITCH )
                      ||(UI_INPUT_SOURCE_DMP1 == UI_INPUT_SOURCE_TYPE)
                      ||(UI_INPUT_SOURCE_DMP2 == UI_INPUT_SOURCE_TYPE)
                    #endif
                  )
                {
                    if((MApp_MPlayer_IsMediaFileInPlaying()||MApp_MPlayer_QueryCurrentMediaType()==E_MPLAYER_TYPE_TEXT)
                        &&(MApp_DMP_GetDmpFlag()& DMP_FLAG_MEDIA_FILE_PLAYING))
                    {
                        MApp_MPlayer_Stop();
                        switch(MApp_MPlayer_QueryCurrentMediaType())
                        {
                            case E_MPLAYER_TYPE_MOVIE:
                                MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_STOP);
                                break;
                            default:
                                break;
                        }
                    }
                }
                #endif // #if ENABLE_DMP

                #if ENABLE_DMP_SWITCH
                MDrv_USBSetPortSwitch(0x00); // TODO:
                #endif

                u8PortEnStatus = MDrv_USBGetPortEnableStatus();
                //MApp_ZUI_API_StoreFocusCheckpoint();

                if((u8PortEnStatus & BIT0) == BIT0)
                {
                    MDrv_UsbDeviceConnect();
                    if (!MDrv_UsbDeviceConnect())
                    {
                        MsOS_DelayTask(1000);
                    }

                    if (!MDrv_UsbDeviceConnect())
                    {
                        if((u8PortEnStatus & BIT1) != BIT1)
                        {
                            printf("\r\n [USB1]Device is not detected and Goto CSM menu!!! \n");
                            g_bGotoCUSMenu = 1;
                            MApp_ZUI_ACT_ExecuteInputSourceAction(EN_EXE_GOTO_FACTORY_MENU);
                            return TRUE;
                        }
                    }
                    else
                    {
                        MApp_UsbDownload_Init(BIT0, _MApp_ZUI_ACT_InputSource_SwUpdate_Progress);

                        if (MW_UsbDownload_Search())
                        {
                            MApp_ZUI_API_StoreFocusCheckpoint();
                            MApp_ZUI_ACT_ExecuteInputSourceAction(EN_EXE_INPUTSRC_GOTO_SW_UPGRADE_CONFIRM);
                            return TRUE;
                        }
                        else //no sw file detected
                        {
                            MS_VE_Output_Ctrl OutputCtrl;

                            // enable VE
                            OutputCtrl.bEnable = ENABLE;

                            msAPI_VE_SetOutputCtrl(&OutputCtrl);

                            // enable DNR buffer
                            MApi_XC_DisableInputSource(FALSE, MAIN_WINDOW);

                            if(!msAPI_AUD_IsAudioMutedByUser())
                            {
                            MW_AUD_SetSoundMute(SOUND_MUTE_ALL, E_MUTE_OFF);
                            }

                            MApp_DMP_SetDMPStat(DMP_STATE_RESET);

                            if((u8PortEnStatus & BIT1) != BIT1)
                            {
                                printf("\r\n [USB1]File is not detected and Goto CSM menu!!! \n");
                                g_bGotoCUSMenu = 1;
                                //              printf("\r\n!!!!!!!g_bGotoCUSMenu");
                                MApp_ZUI_ACT_ExecuteInputSourceAction(EN_EXE_GOTO_FACTORY_MENU);
                                return TRUE;
                            }
                        }
                    }
                }

                if((u8PortEnStatus & BIT1) == BIT1)
                {
                    if (!MDrv_UsbDeviceConnect_Port2())
                    {
                        MsOS_DelayTask(1000);
                    }

                    if (!MDrv_UsbDeviceConnect_Port2())
                    {
                        g_bGotoCUSMenu = 1;
                        printf("\r\n [USB2]device is not detected and Goto CSM menu!!! \n");
                        //printf("\r\n!!!!!!!g_bGotoCUSMenu");
                        MApp_ZUI_ACT_ExecuteInputSourceAction(EN_EXE_GOTO_FACTORY_MENU);
                        return TRUE;
                    }
                    else
                    {
                        MApp_UsbDownload_Init(BIT1, _MApp_ZUI_ACT_InputSource_SwUpdate_Progress);

                        if (MW_UsbDownload_Search())
                        {
                            MApp_ZUI_API_StoreFocusCheckpoint();
                            MApp_ZUI_ACT_ExecuteInputSourceAction(EN_EXE_INPUTSRC_GOTO_SW_UPGRADE_CONFIRM);
                        }
                        else //no sw file detected
                        {
                            {
                                MS_VE_Output_Ctrl OutputCtrl;
                                // enable VE
                                OutputCtrl.bEnable = ENABLE;
                                msAPI_VE_SetOutputCtrl(&OutputCtrl);
                                // enable DNR buffer
                                MApi_XC_DisableInputSource(FALSE, MAIN_WINDOW);
                                if(!msAPI_AUD_IsAudioMutedByUser())
                                {
                                    MW_AUD_SetSoundMute(SOUND_MUTE_ALL, E_MUTE_OFF);
                                }
                            }
                            printf("\r\n [USB2]File is not detected and Goto CSM menu!!! \n");
                            g_bGotoCUSMenu = 1;
                            MApp_ZUI_ACT_ExecuteInputSourceAction(EN_EXE_GOTO_FACTORY_MENU);
                            return TRUE;
                        }
                    }
                }
                return TRUE;
            #endif
#else
            g_bGotoCUSMenu = 1;
            MApp_ZUI_ACT_ExecuteInputSourceAction(EN_EXE_GOTO_FACTORY_MENU);
            break
#endif
            }
            */
				break;
        }
#if(ENABLE_MULTI_PANELS==1)//fanjian0822
		bMulti_panel_count=bMulti_panel_count*10+(key-VK_NUM_0);
		if((bMulti_panel_count>=901)&&(bMulti_panel_count<=906))
			{
			  bMulti_panel=TRUE;
			  bMulti_panel_count=bMulti_panel_count%900;
			  test_panel_set((bMulti_panel_count-1));
			  bMulti_panel_count=0;
		}
		else if(bMulti_panel_count==907)
		{
			if(MDrv_ReadRegBit(0x103294, BIT0))
				{
				MDrv_WriteRegBit(0x103294, DISABLE, BIT0);
				stGenSetting.g_SysSetting.uLvdsPortSwap=0;
				}
			else
				{
				MDrv_WriteRegBit(0x103294, ENABLE, BIT0);
				stGenSetting.g_SysSetting.uLvdsPortSwap=1;
				}
			
			bMulti_panel_count=0;
		}
		else if(bMulti_panel_count==908)
		{
		if(MDrv_ReadRegBit(0x103280, BIT5))
			{
			MDrv_WriteRegBit(0x103280, DISABLE, BIT5);
			stGenSetting.g_SysSetting.uLvdsPolSwap=0;
			}
			else
			{
			MDrv_WriteRegBit(0x103280, ENABLE, BIT5); 
			stGenSetting.g_SysSetting.uLvdsPolSwap=1;
			}
			bMulti_panel_count=0;
		}
		else if((bMulti_panel_count<9)||(bMulti_panel_count>908))
		bMulti_panel_count=0;
#endif
    }
    else
    {
        _u16LaunchKeys = 0xFFFF;
      #if(ENABLE_MULTI_PANELS==1)//fanjian0822
      	bMulti_panel_count=0;//ASANO_0829-->
      #endif
    }

    return FALSE;
}

void MApp_ZUI_ACT_TerminateInputSource(void)
{
    ZUI_MSG(printf("[]term:input\n");)
    enInputSourceState = _enTargetInputSourceState;

    MApp_SaveSysSetting();
}

static E_UI_INPUT_SOURCE _MApp_ZUI_ACT_GetSourceType(void)
{
    E_UI_INPUT_SOURCE source_type;

#if (ENABLE_CUS_UI_SPEC == DISABLE)
    if(MApp_ZUI_GetActiveOSD() == E_OSD_MAIN_MENU && MApp_ZUI_API_IsSuccessor(HWND_MENU_APP_PAGE, MApp_ZUI_API_GetFocus()))
    {
          HWND hwnd;
          S16 s16Index = 0;
          hwnd = MApp_ZUI_API_GetFocus();
          s16Index = MApp_ZUI_API_GetChildIndex(hwnd);
          source_type = MApp_ZUI_ACT_GetAppItemSource(s16Index);
    }
    else
 #endif
    {
          source_type = _MApp_ZUI_ACT_InputSourceWindowMapToId(MApp_ZUI_API_GetFocus());
    }

    return source_type;
}
#if ENABLE_SZ_BLUESCREEN_FUNCTION
extern BOOLEAN bIsSrcChangeScreen;
#endif

void MApp_ZUI_ACT_InputSourceSwitch( E_UI_INPUT_SOURCE source_type )
{
#if (ENABLE_PIP)
    //If sub window is opened, close SUB_WINDOW.
    if(IsPIPSupported() && UI_INPUT_SOURCE_TYPE != source_type )
    {
        //INPUT_SOURCE_TYPE_t enSrc = MApp_InputSource_GetInputSourceType(source_type);
        //E_UI_INPUT_SOURCE enUISrc = MApp_InputSource_GetUIInputSourceType(MApp_InputSource_PIP_Get1stCompatibleSrc(enSrc));
        stGenSetting.g_stPipSetting.enPipMode = EN_PIP_MODE_OFF;
        if(stGenSetting.g_stPipSetting.enPipSoundSrc!=EN_PIP_SOUND_SRC_MAIN)
        {
            stGenSetting.g_stPipSetting.enPipSoundSrc=EN_PIP_SOUND_SRC_MAIN;
        }
        //stGenSetting.g_stPipSetting.enSubInputSourceType = enUISrc;
        if(SYS_INPUT_SOURCE_TYPE(SUB_WINDOW) != INPUT_SOURCE_NONE)
        {
            UI_SUB_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_NONE;
            MApp_InputSource_ChangeInputSource(SUB_WINDOW);
        }
        UI_SUB_INPUT_SOURCE_TYPE = MApp_InputSource_GetUIInputSourceType(MApp_InputSource_PIP_Get1stCompatibleSrc(MApp_InputSource_GetInputSourceType(source_type)));
    }
#endif

#if ENABLE_PVR
    if ( (UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_DTV) && (UI_INPUT_SOURCE_TYPE != source_type) )
    {
        if(MApp_PVR_IsRecording())
        {
            MApp_InputSource_RecordSource(source_type);
            MApp_ZUI_API_ShowWindow(HWND_PVR_SOURCE_CHANGE_CHECK_PANE, SW_SHOW);
            MApp_ZUI_API_SetFocus(HWND_PVR_SOURCE_CHANGE_CHECK_TXT_2);
            return;
        }
    }
#endif

#if DVB_C_ENABLE
	if((UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_CADTV)&&
	   (source_type == UI_INPUT_SOURCE_DTV))
	{
		return;
	}
#endif

#if ENABLE_SBTVD_BRAZIL_APP
     if ( UI_INPUT_SOURCE_TYPE != source_type
        || (UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_ATV
        && msAPI_ATV_GetCurrentAntenna() == ANT_AIR))
#else
#if ENABLE_DMP
  #if( ENABLE_DMP_SWITCH )
    if ( UI_INPUT_SOURCE_TYPE != source_type || UI_INPUT_SOURCE_TYPE > UI_INPUT_SOURCE_DMP2)
  #else
    if ( UI_INPUT_SOURCE_TYPE != source_type || UI_INPUT_SOURCE_TYPE > UI_INPUT_SOURCE_DMP)
  #endif
 #else
    if ( UI_INPUT_SOURCE_TYPE != source_type )
#endif
#endif
    {
#if ENABLE_SZ_BLUESCREEN_FUNCTION
        if(UI_INPUT_SOURCE_TYPE < UI_INPUT_SOURCE_DMP && source_type >= UI_INPUT_SOURCE_DMP)
    	{
		 bIsSrcChangeScreen=1;
    	}
#endif
        #ifdef AP_COWORK
        if(MApp_APEngine_CheckAPStatus() && !(MApp_APEngine_CheckAPStatus()>>1))
        {
            msAPI_APEngine_TransmitKey(KEY_EXIT);
            MApp_APEngine_Exit();
        }
        #endif

        #if ENABLE_DMP
        if(source_type != UI_INPUT_SOURCE_DMP
            && IsStorageInUse())
        {
            MApp_DMP_Exit();
        }
      #if( ENABLE_DMP_SWITCH )
        if(source_type != UI_INPUT_SOURCE_DMP1
            && IsStorageInUse())
        {
            MApp_DMP_Exit();
        }
        if(source_type != UI_INPUT_SOURCE_DMP2
            && IsStorageInUse())
        {
            MApp_DMP_Exit();
        }
      #endif
    #endif
        #ifdef ENABLE_KTV
        if(source_type != UI_INPUT_SOURCE_KTV
            && IsStorageInUse())
        {
            MApp_KTV_Exit();
        }
        #endif
	#if 0
	 if(IsDTVInUse()||IsATVInUse())
	{
		MApi_VDEC_Exit();
	}
	#endif

        //switch input source from TV/DTV to non-TV/DTV
        MApp_InputSource_RecordSource(UI_INPUT_SOURCE_TYPE);
        #if (ENABLE_CUS_UI_SPEC && ENABLE_SZ_BLUESCREEN_FUNCTION)
		if(source_type < UI_INPUT_SOURCE_DMP)
        MApp_InputSource_ResetAspectRatio();
        #endif

        UI_INPUT_SOURCE_TYPE = source_type;
		UI_PREV_INPUT_SOURCE_TYPE = source_type;//<<SMC jayden.chen add for USB source 20130813

        MApp_InputSource_ChangeInputSource(MAIN_WINDOW);

        if (IsSrcTypeDTV(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)) || IsSrcTypeATV(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)))
        {
            MApp_ChannelChange_EnableChannel(MAIN_WINDOW);
        }

        //exp: In PIP/POP mode, main is TV and switch sub to another source.
        // It should not Enable channel "AGAIN"
        else if (IsAnyTVSourceInUse())
        {
            ;
        }
        else
        {
            MApp_ChannelChange_EnableAV();
        }

        if(IsStorageInUse())
        {
            extern void MApp_DMP_SetMediaKey (U8 u8Key);
            MApp_DMP_SetMediaKey(KEY_NULL);
        }

        Panel_Backlight_PWM_ADJ(msAPI_Mode_PictureBackLightN100toReallyValue(ST_PICTURE.u8Backlight));
    }
   #if ENABLE_SZ_BLUESCREEN_FUNCTION
    bIsSrcChangeScreen=0;
   #endif

}



BOOLEAN MApp_ZUI_ACT_ExecuteInputSourceAction(U16 act)
{
    switch(act)
    {
        case EN_EXE_GOTO_MAINMENU:
            MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
            _enTargetInputSourceState = STATE_INPUTSOURCE_GOTO_MAIN_MENU;
            return TRUE;

        case EN_EXE_CLOSE_CURRENT_OSD:
            MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
         #if ( ENABLE_DMP_SWITCH )		// CUS_XM Sea 20120629:
            if(UI_INPUT_SOURCE_TYPE !=_MApp_ZUI_ACT_GetSourceType())
            {
                  if( UI_INPUT_SOURCE_DMP1 == UI_INPUT_SOURCE_TYPE )
                  {
                         printf("\n=SET USB 1=\n");
                         MDrv_USBSetPortSwitch(INPUT_USB1_PORT);
                  }
                  if( UI_INPUT_SOURCE_DMP2 == UI_INPUT_SOURCE_TYPE )
                  {
                        printf("\n=SET USB 2=\n");
                        MDrv_USBSetPortSwitch(INPUT_USB2_PORT);
                  }
          }
        #endif
            #if ENABLE_DMP
               if((UI_INPUT_SOURCE_DMP == UI_INPUT_SOURCE_TYPE)
            #if( ENABLE_DMP_SWITCH )
                  ||(UI_INPUT_SOURCE_DMP1 == UI_INPUT_SOURCE_TYPE)
                  ||(UI_INPUT_SOURCE_DMP2 == UI_INPUT_SOURCE_TYPE)
            #endif
               )
            {
                _enTargetInputSourceState = STATE_INPUTSOURCE_GOTO_DMP;
            }
            else
            #endif
            _enTargetInputSourceState = STATE_INPUTSOURCE_CLEAN_UP;

            #ifdef ENABLE_BT
            if(UI_INPUT_SOURCE_BT == UI_INPUT_SOURCE_TYPE)
            {
                _enTargetInputSourceState = STATE_INPUTSOURCE_GOTO_BT;
            }
            #endif

            #ifdef ENABLE_KTV
            if(UI_INPUT_SOURCE_KTV == UI_INPUT_SOURCE_TYPE)
            {
                _enTargetInputSourceState = STATE_INPUTSOURCE_GOTO_KTV;
            }
            #endif

            return TRUE;
#ifdef ENABLE_SRC_MENU_AUTOCLOSE_AND_SWITCH_SOURCE
        case EN_EXE_SWITCH_SRC_AND_CLOSE_OSD:
            {
                E_UI_INPUT_SOURCE selectInputSource = _MApp_ZUI_ACT_InputSourceWindowMapToId(MApp_ZUI_API_GetFocus());

                if(UI_INPUT_SOURCE_TYPE !=selectInputSource)
                {
                    #if ( ENABLE_DMP_SWITCH )
                    if( UI_INPUT_SOURCE_DMP1 == selectInputSource )
                    {
                        //printf("\n=SET USB 1_2=\n");
                        MDrv_USBSetPortSwitch(INPUT_USB1_PORT);
                    }
                    if( UI_INPUT_SOURCE_DMP2 == selectInputSource)
                    {
                        //printf("\n=SET USB 2_2=\n");
                        MDrv_USBSetPortSwitch(INPUT_USB2_PORT);
                    }
                    #endif

                    MApp_ZUI_ACT_InputSourceSwitch(selectInputSource);
                #if ENABLE_PVR
                    //PVR is recording, so already popup souce change dialog,not do anything here
                    if( MApp_PVR_IsRecording() && MApp_ZUI_API_IsWindowVisible(HWND_PVR_SOURCE_CHANGE_CHECK_PANE) )
                        return TRUE;
                #endif
                    MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
            #if ENABLE_DMP
                    if((selectInputSource == UI_INPUT_SOURCE_DMP)
                        #if( ENABLE_DMP_SWITCH )
                        ||(selectInputSource == UI_INPUT_SOURCE_DMP1)
                        ||(selectInputSource == UI_INPUT_SOURCE_DMP2)
                        #endif
                        )
                    {
                        _enTargetInputSourceState = STATE_INPUTSOURCE_GOTO_DMP;
                    }
                    else
            #endif
                    {
                        _enTargetInputSourceState = STATE_INPUTSOURCE_GOTO_CH_INFO;
                    }
                }
                else
                {
                    MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
            #if ENABLE_DMP
                    if((UI_INPUT_SOURCE_DMP == UI_INPUT_SOURCE_TYPE)
                        #if( ENABLE_DMP_SWITCH )
                        ||(UI_INPUT_SOURCE_DMP1 == UI_INPUT_SOURCE_TYPE)
                        ||(UI_INPUT_SOURCE_DMP2 == UI_INPUT_SOURCE_TYPE)
                        #endif
                        )
                    {
                        _enTargetInputSourceState = STATE_INPUTSOURCE_GOTO_DMP;
                    }
                    else
            #endif
                    {
                        _enTargetInputSourceState = STATE_INPUTSOURCE_CLEAN_UP;
                    }
                }

            }
            return TRUE;
#endif

        case EN_EXE_POWEROFF:
            MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
            _enTargetInputSourceState = STATE_INPUTSOURCE_GOTO_STANDBY;
            return TRUE;

        case EN_EXE_GOTO_FACTORY_MENU:
            MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
            _enTargetInputSourceState = STATE_INPUTSOURCE_GOTO_OSDPAGE;
            MApp_OSDPage_SetOSDPage(E_OSD_FACTORY_MENU);
            return TRUE;

        case EN_EXE_GOTO_EXPERT_MENU:
            // TODO: entry point
            MS_DEBUG_MSG(printf("MApi_XC_SotreCurrentValue\n"));
            MApi_XC_SotreCurrentValue();
            MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_PAGE_FADE_OUT, E_ZUI_STATE_TERMINATE);
            _enTargetInputSourceState = STATE_INPUTSOURCE_GOTO_OSDPAGE;
            MApp_OSDPage_SetOSDPage(E_OSD_EXPERT_MENU);
            return TRUE;

//EN_EXE_GOTO_MEDIA_PLAYER do not use currently; MM entry already moved to app list of main menu.
#if ENABLE_DMP
    #if( ENABLE_DMP_SWITCH )		// CUS_XM Sea 20120629:
        case EN_EXE_GOTO_MEDIA_PLAYER:
            #if (ENABLE_SOURCECHANGETIME)
                printf("act Begin = %ld\n", msAPI_Timer_DiffTimeFromNow(gU32SourceChangeTime));
            #endif
            #if ENABLE_PVR
                if ( (UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_DTV) )
                {
                    if(MApp_PVR_IsRecording())
                    {
                        MS_DEBUG_MSG(printf("\r\n PVR is recording...."));
                        break;
                    }
                }
            #endif

            if( UI_INPUT_SOURCE_DMP1 == _MApp_ZUI_ACT_GetSourceType())
           {
               printf("\n=SET USB 1=\n");
                MDrv_USBSetPortSwitch(INPUT_USB1_PORT);
            }
            if( UI_INPUT_SOURCE_DMP2 == _MApp_ZUI_ACT_GetSourceType())
            {
                printf("\n=SET USB 2=\n");
                MDrv_USBSetPortSwitch(INPUT_USB2_PORT);
            }
            MApp_ZUI_ACT_InputSourceSwitch( _MApp_ZUI_ACT_GetSourceType() );
            MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
            _enTargetInputSourceState = STATE_INPUTSOURCE_GOTO_DMP;
            #if (ENABLE_SOURCECHANGETIME)
                printf("act End = %ld\n", msAPI_Timer_DiffTimeFromNow(gU32SourceChangeTime));
            #endif
            return TRUE;
	#else  //SMC jayden.chen add for only USB
		case EN_EXE_GOTO_MEDIA_PLAYER:			
			#if ENABLE_ATV_VCHIP
			MApp_VChip_Init();
			#endif
            MApp_ZUI_ACT_InputSourceSwitch( _MApp_ZUI_ACT_GetSourceType() );

            MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
            if(UI_INPUT_SOURCE_DMP == UI_INPUT_SOURCE_TYPE)
            {
                _enTargetInputSourceState = STATE_INPUTSOURCE_GOTO_DMP;
            }
            else
            {
            	_enTargetInputSourceState = STATE_INPUTSOURCE_GOTO_CH_INFO;
			
            }
            return TRUE;
    #endif
#endif
#ifdef ENABLE_BT
        case EN_EXE_GOTO_BT:
            MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
            _enTargetInputSourceState = STATE_INPUTSOURCE_GOTO_BT;
            return TRUE;
#endif
#ifdef ENABLE_KTV
        case EN_EXE_GOTO_KTV:
            MApp_ZUI_ACT_InputSourceSwitch( _MApp_ZUI_ACT_GetSourceType() );
            MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
            _enTargetInputSourceState = STATE_INPUTSOURCE_GOTO_KTV;
            return TRUE;
#endif

#ifdef ENABLE_YOUTUBE
        case EN_EXE_GOTO_YOUTUBE:
            MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
            _enTargetInputSourceState = STATE_INPUTSOURCE_GOTO_YOUTUBE;
            return TRUE;
#endif
#ifdef ENABLE_EXTENSION
        case EN_EXE_GOTO_EXTENSION:
            MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
            _enTargetInputSourceState = STATE_INPUTSOURCE_GOTO_EXTENSION;
            return TRUE;
#endif
#ifdef ENABLE_RSS
        case EN_EXE_GOTO_RSS:
            MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
            _enTargetInputSourceState = STATE_INPUTSOURCE_GOTO_RSS;
            return TRUE;
#endif
//#ifdef ENABLE_NETFLIX
//        case EN_EXE_GOTO_NETFLIX:
//            MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
//            _enTargetInputSourceState = STATE_INPUTSOURCE_GOTO_NETFLIX;
//            return TRUE;
//#endif
#if (ENABLE_GAME)
        case EN_EXE_GOTO_GAME:
            //printf("execute goto game\n");
            MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_PAGE_FADE_OUT, E_ZUI_STATE_TERMINATE);
            _enTargetInputSourceState = STATE_INPUTSOURCE_GOTO_GAME;
            return TRUE;
#endif

        case EN_EXE_GOTO_SWITCH_INPUTSOURCE: //for click animation
            MApp_ZUI_API_SetTimer(HWND_SOURCE_BG_PANE, 0, 100);
            break;

        case EN_EXE_SWITCH_INPUTSOURCE:
            #if ENABLE_PVR
                #if( ENABLE_DMP_SWITCH )		// CUS_XM Sea 20120629:
                if ( (UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_DTV)
			&&(( UI_INPUT_SOURCE_DMP1 == _MApp_ZUI_ACT_GetSourceType())
			||( UI_INPUT_SOURCE_DMP2 == _MApp_ZUI_ACT_GetSourceType())))
                {
                    if(MApp_PVR_IsRecording())
                    {
                        MS_DEBUG_MSG(printf("\r\n PVR is recording...."));
                        break;
                    }
                }
		  #endif
            #endif
            MApp_ZUI_ACT_InputSourceSwitch( _MApp_ZUI_ACT_GetSourceType() );

            MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
        #if ENABLE_DMP
            if((UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_DMP)
                #if( ENABLE_DMP_SWITCH )
                ||(UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_DMP1)
                ||(UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_DMP2)
                #endif
                )
            {
                _enTargetInputSourceState = STATE_INPUTSOURCE_GOTO_DMP;
            }
            else
        #endif
            {
                _enTargetInputSourceState = STATE_INPUTSOURCE_GOTO_CH_INFO;
            }
            return TRUE;

        case EN_EXE_SHOW_BRIEF_CH_INFO:
#if ENABLE_PVR
            //PVR is recording, so already popup souce change dialog,not do anything here
            if( MApp_PVR_IsRecording() && MApp_ZUI_API_IsWindowVisible(HWND_PVR_SOURCE_CHANGE_CHECK_PANE) )
                return TRUE;
#endif
            MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
            _enTargetInputSourceState = STATE_INPUTSOURCE_GOTO_CH_INFO;
            return TRUE;

#if ENABLE_PVR
        case EN_EXE_SWITCH_INPUTSOURCE_CONFIRM_OK:
            if( MApp_PVR_IsPlaybacking())
                MApp_UiPvr_PlaybackStop();

            if( MApp_PVR_IsRecording() )
                MApp_UiPvr_RecordStop();

            MApp_ZUI_API_SetFocus( _MApp_ZUI_ACT_InputSourceIdMapToWindow(MApp_InputSource_GetRecordSource()));
            MApp_ZUI_ACT_InputSourceSwitch( _MApp_ZUI_ACT_GetSourceType() );
            MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
            _enTargetInputSourceState = STATE_INPUTSOURCE_GOTO_CH_INFO;
            break;
		case EN_EXE_ENTER_LOCK_SOURCE_PSSWD:
			printf("\r\n&&&&&&&&&&&&&&&");
            MApp_ZUI_API_SetFocus( _MApp_ZUI_ACT_InputSourceIdMapToWindow(MApp_InputSource_GetRecordSource()));
            MApp_ZUI_ACT_InputSourceSwitch( _MApp_ZUI_ACT_GetSourceType() );
            MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
            _enTargetInputSourceState = STATE_INPUTSOURCE_GOTO_CH_INFO;
            break;
        case EN_EXE_SWITCH_INPUTSOURCE_CONFIRM_CANCEL:
            MApp_ZUI_API_ShowWindow(HWND_PVR_SOURCE_CHANGE_CHECK_PANE, SW_HIDE);
            MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
            _enTargetInputSourceState = STATE_INPUTSOURCE_CLEAN_UP;
            break;
#endif

        case EN_EXE_EFFECT_POPUP:
            switch(MApp_ZUI_API_GetFocus())
            {
                default:
                    break;
            }
            MApp_ZUI_API_PostMessage(MApp_ZUI_API_GetFocus(), MSG_EFFECT_POPUP, (WPARAM)NULL);
            return TRUE;

        case EN_EXE_EFFECT_SLIDEITEM:
            MApp_ZUI_API_PostMessage(MApp_ZUI_API_GetFocus(), MSG_EFFECT_SLIDEITEM, MApp_ZUI_API_GetFocus());
            return TRUE;

	  /*
        case EN_EXE_INPUTSRC_GOTO_SW_UPGRADE_CONFIRM:
            MApp_ZUI_API_KillTimer(HWND_SOURCE_BG_PANE, 0);
            MApp_ZUI_API_ShowWindow(HWND_PVR_SOURCE_CHANGE_CHECK_PANE, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_SOURCE_BG_PANE, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_SOURCE_INPUT_LIST, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_SOURCE_FWUPGRADE_BG, SW_SHOW);
            MApp_ZUI_API_SetFocus(HWND_SOURCE_FWUPGRADE_NO);
            return TRUE;

        case EN_EXE_INPUTSRC_DO_SW_UPGRADE:
            {
                MApp_ZUI_API_KillTimer(HWND_SOURCE_BG_PANE, 0);

                Source_USB_Upgrade_Percent = 0;

                if(IsSrcTypeATV(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW))||IsSrcTypeDTV(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)))
                {
                    MApp_ChannelChange_DisableChannel(TRUE,MAIN_WINDOW);
                }

            #if ENABLE_DMP
                // for dmp
                if(( UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_DMP)
               #if( ENABLE_DMP_SWITCH )
                     ||(UI_INPUT_SOURCE_DMP1 == UI_INPUT_SOURCE_TYPE)
                     ||(UI_INPUT_SOURCE_DMP2 == UI_INPUT_SOURCE_TYPE)
                  #endif
                 )
                {
                    //MApp_DMP_SetDMPStat(DMP_STATE_GOTO_PREV_SRC);
                    MApp_DMP_Exit();
                }
            #endif // #if ENABLE_DMP

            #if ( ENABLE_SW_UPGRADE && ENABLE_FILESYSTEM )
                    if(!_bOCPFromMem)
                    {
                        msAPI_OCP_LoadAllStringToMem();
                    }

            #if (OBA2!=1)

                _MApp_ZUI_API_WindowProcOnIdle();
                if (MW_UsbDownload_Start())
                {
                    msAPI_BLoader_Reboot();
                }
                else
                {
                    //Screen will Blue & Red flash
                }
            #endif
            #endif
            }
            return TRUE;


         case EN_EXE_INPUTSRC_CANCEL_SW_UPGRADE:
            {
                MS_VE_Output_Ctrl OutputCtrl;
                // enable VE
                OutputCtrl.bEnable = TRUE;
                msAPI_VE_SetOutputCtrl(&OutputCtrl);
                // enable DNR buffer
                MApi_XC_DisableInputSource(FALSE, MAIN_WINDOW);
                MW_AUD_SetSoundMute(SOUND_MUTE_ALL, E_MUTE_OFF);
            }
            MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
            _enTargetInputSourceState = STATE_INPUTSOURCE_CLEAN_UP;
             return TRUE;
   	*/


    }
    return FALSE;
}


GUI_ENUM_DYNAMIC_LIST_STATE MApp_ZUI_ACT_QueryInputSourceItemStatus(HWND hwnd)
{
    U8 i;
    //printf("[]query=%u\n", hwnd);

    for (i = 0; i < COUNTOF(_source_items); i++)
    {
        if (hwnd == _source_items[i].hwnd)
        {
            return EN_DL_STATE_NORMAL;
        }
    }
    return EN_DL_STATE_HIDDEN;
}


///////////////////////////////////////////////////////////////////////////////
///  global  MApp_ZUI_ACT_InputSourceWinProc
///  [MENU application customization] top circle icon rotate animation
///
///  @param [in]       hwnd HWND     window handle we are processing
///  @param [in]       msg PMSG     message type
///
///  @return S32 message execute result
///
///  @author MStarSemi @date 2007/1/25
///////////////////////////////////////////////////////////////////////////////
S32 MApp_ZUI_ACT_InputSourceWinProc(HWND hwnd, PMSG msg)
{
    switch(msg->message)
    {
        case MSG_NOTIFY_SETFOCUS:
            switch(MApp_ZUI_API_GetFocus())
            {
                #if ENABLE_DTV
                case HWND_SOURCE_INPUT_ITEM_DTV:
                #else
                case HWND_SOURCE_INPUT_ITEM_TV:
                #endif
                default:
                    break;
            }
            break;

        case MSG_TIMER:
            if(hwnd == HWND_SOURCE_BG_PANE)
            {
                MApp_ZUI_API_KillTimer(hwnd, 0);
                MApp_ZUI_ACT_ExecuteInputSourceAction(EN_EXE_CLOSE_CURRENT_OSD);
                MApp_ZUI_ACT_InputSourceSwitch( _MApp_ZUI_ACT_GetSourceType() );
            }

        default:
            break;
    }
    return DEFAULTWINPROC(hwnd, msg);
    //return EFFECT_WINPROC(hwnd, msg);
}

/////////////////////////////////////////////////////////
// Customize Window Procedures
/*
S32 MApp_ZUI_ACT_InputSourceListWinProc(HWND hwnd, PMSG msg)
{
    switch(msg->message)
    {
        case MSG_CREATE:
            {


                //setting AP timeout, auto close
                MApp_ZUI_API_SetTimer(hwnd, 0, HOT_MENU_TIME_OUT_3SEC);
            }
            break;

        case MSG_TIMER:
            {
                //if the time is up, kill the timer and then close AP!
                MApp_ZUI_API_KillTimer(hwnd, 0);
                MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_CLOSE_CURRENT_OSD);
            }
            break;

        case MSG_DESTROY:
            {

            }
            break;

    }

    return DEFAULTWINPROC(hwnd, msg);
}
*/
    #if (ENABLE_GAME)
    EN_GAME_STATE enGameState=STATE_GAME_INIT;
    extern BOOLEAN SearchAppBinInUSB(void);
    extern EN_RET MApp_APEngine_Process(void);
    extern U8 MApp_GetSuitableFileNum(void);
    extern U8 MApp_GetLongFileName(U8 idx,U8 *u8LongFileName);
    extern BOOLEAN LoadAppBinFromUSB(U8 idx);
    extern BOOLEAN _MApp_ZUI_API_AllocateVarData(void);

    EN_RET MApp_Game_Browse_Main(void)
    {
        EN_RET enRetVal =EXIT_NULL;

        //printf("game state %d\n",(U8)enGameState);
        switch(enGameState)
        {
            case STATE_GAME_INIT:
                SearchAppBinInUSB();
                MApp_ZUI_ACT_StartupOSD(E_OSD_GAME_BROWSER);
                enGameState = STATE_GAME_WAIT;
                break;

            case STATE_GAME_WAIT:
                //printf("game wait");
                MApp_ZUI_ProcessKey(u8KeyCode);
                u8KeyCode = KEY_NULL;
                break;

            case STATE_GAME_APP_RUNING:
                if(MApp_APEngine_Process()==EXIT_APENGINE_EXIT)
                {
                    enRetVal =EXIT_CLOSE;
                }
                break;

            case STATE_GAME_CLEAN_UP:
                //printf("clean up osd\n");
                MApp_ZUI_ACT_ShutdownOSD();
                enGameState = STATE_GAME_INIT;
                enRetVal =EXIT_CLOSE;
                break;

            case STATE_GAME_GOTO_STANDBY:
                MApp_ZUI_ACT_ShutdownOSD();
                u8KeyCode = KEY_POWER;
                enRetVal =EXIT_GOTO_STANDBY;
                break;

            case STATE_GAME_GOTO_MAIN_MENU:
                MApp_ZUI_ACT_ShutdownOSD();
                enGameState = STATE_GAME_INIT;
                enRetVal =EXIT_GOTO_MENU;
                break;
            default:
                enGameState = STATE_GAME_WAIT;
            break;
        }
        return enRetVal;
    }

    void MApp_ZUI_ACT_AppShowGameBrowser(void)
    {
        HWND wnd;
        RECT rect;

        g_GUI_WindowList = _GUI_WindowList_Zui_Game_Browser;
        g_GUI_WinDrawStyleList =    _GUI_WindowsDrawStyleList_Zui_Game_Browser;
        g_GUI_WindowPositionList =    _GUI_WindowPositionList_Zui_Game_Browser;
    #if ZUI_ENABLE_ALPHATABLE
        g_GUI_WinAlphaDataList = _GUI_WindowsAlphaList_Zui_Game_Browser;
    #endif
        HWND_MAX = HWND_GAME_BROWSER_MAX;

        if (!_MApp_ZUI_API_AllocateVarData())
        {
            ZUI_DBG_FAIL(printf("[ZUI]ALLOC\n"));
            ABORT();
            return;
        }

        RECT_SET(rect,
            ZUI_GAME_BROWSER_XSTART, ZUI_GAME_BROWSER_YSTART,
            ZUI_GAME_BROWSER_WIDTH, ZUI_GAME_BROWSER_HEIGHT);

        if (!MApp_ZUI_API_InitGDI(&rect))
        {
            ZUI_DBG_FAIL(printf("[ZUI]GDIINIT\n"));
            ABORT();
            return;
        }

        for (wnd = 0; wnd < HWND_MAX; wnd++)
        {
            //printf("create msg: %lu\n", (U32)wnd);
            MApp_ZUI_API_SendMessage(wnd, MSG_CREATE, 0);
        }

        MApp_ZUI_API_ShowWindow(HWND_MAINFRAME, SW_SHOW);

        MApp_ZUI_API_ShowWindow(HWND_SOURCE_BG_GAME, SW_SHOW);
        MApp_ZUI_API_ShowWindow(HWND_SOURCE_GAME_LIST, SW_SHOW);
        MApp_ZUI_API_SetFocus(HWND_SOURCE_GAME_1);

        ZUI_MSG(printf("MApp_ZUI_ACT_AppShowGameBrowser\n");)

        MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_LIST_SHOWUP, E_ZUI_STATE_RUNNING);

    }

#if 0
    BOOLEAN MApp_ZUI_ACT_ExecuteGameAction(U16 act)
    {
        BOOLEAN bExeResult = FALSE;
        HWND cur;

        switch(act)
        {
            case EN_EXE_GAME_SELECT:
                cur=MApp_ZUI_API_GetFocus();
                if(cur>=HWND_SOURCE_GAME_1&&cur<=HWND_SOURCE_GAME_16)
                    bExeResult = LoadAppBinFromUSB((U8)(cur-HWND_SOURCE_GAME_1));
            break;
            default:
                break;
        }
        return bExeResult;
    }

    void MApp_ZUI_ACT_TerminateGameBrowser(void)
    {
        //enGameState = _enTargetGameState;
    }

#endif

    LPTSTR MApp_ZUI_ACT_GetGameBrowserDynamicText(HWND hwnd)
    {
        U8 u8Item;

        CHAR_BUFFER[0] = 0;
        CHAR_BUFFER[1] = 0;
        u8Item=MApp_GetSuitableFileNum();
        if(u8Item==0)
            return CHAR_BUFFER;
        printf("Dynamic Text : hwnd(%d)\n", (U16)hwnd);
        switch(hwnd)
        {
            case HWND_SOURCE_GAME_1:
            case HWND_SOURCE_GAME_2:
            case HWND_SOURCE_GAME_3:
            case HWND_SOURCE_GAME_4:
            case HWND_SOURCE_GAME_5:
            case HWND_SOURCE_GAME_6:
            case HWND_SOURCE_GAME_7:
            case HWND_SOURCE_GAME_8:
            case HWND_SOURCE_GAME_9:
            case HWND_SOURCE_GAME_10:
            case HWND_SOURCE_GAME_11:
            case HWND_SOURCE_GAME_12:
            case HWND_SOURCE_GAME_13:
            case HWND_SOURCE_GAME_14:
            case HWND_SOURCE_GAME_15:
            case HWND_SOURCE_GAME_16:
                if(u8Item>(hwnd-HWND_SOURCE_GAME_1))
                {
                    MApp_GetLongFileName((U8)(hwnd-HWND_SOURCE_GAME_1),(U8 *)CHAR_BUFFER);
                }
            break;

        default:
            break;
        }
        return CHAR_BUFFER;
    }


    BOOLEAN MApp_ZUI_ACT_ExecuteGameBrowseAction(U16 act)
    {
        switch(act)
        {
            case EN_EXE_GOTO_MAINMENU:
                MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_PAGE_FADE_OUT, E_ZUI_STATE_TERMINATE);
                //_enTargetGameState = STATE_GAME_GOTO_MAIN_MENU;
                enGameState = STATE_GAME_GOTO_MAIN_MENU;
                return TRUE;
            case EN_EXE_CLOSE_CURRENT_OSD:
                printf("close current osd\n");
                MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_PAGE_FADE_OUT, E_ZUI_STATE_TERMINATE);
                //_enTargetGameState = STATE_GAME_CLEAN_UP;
                enGameState = STATE_GAME_CLEAN_UP;
                return TRUE;

            case EN_EXE_POWEROFF:
                MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_PAGE_FADE_OUT, E_ZUI_STATE_TERMINATE);
                //_enTargetGameState = STATE_GAME_GOTO_STANDBY;
                enGameState = STATE_GAME_GOTO_STANDBY;
                return TRUE;
        }
        return FALSE;
    }

    BOOLEAN MApp_ZUI_ACT_HandleGameBrowseKey(VIRTUAL_KEY_CODE key)
    {
        //note: this function will be called in running state
        //reset timer if any key
        MApp_ZUI_API_ResetTimer(HWND_SOURCE_BG_GAME, 0);
        switch(key)
        {
            case VK_MENU:
                MApp_ZUI_ACT_ExecuteGameBrowseAction(EN_EXE_GOTO_MAINMENU);
                return TRUE;
            case VK_EXIT:
                //printf("exit key\n");
                MApp_ZUI_ACT_ExecuteGameBrowseAction(EN_EXE_CLOSE_CURRENT_OSD);
                return TRUE;
            case VK_POWER:
                MApp_ZUI_ACT_ExecuteGameBrowseAction(EN_EXE_POWEROFF);
                return TRUE;
            case VK_SELECT:
                {
                    HWND cur;
                    cur=MApp_ZUI_API_GetFocus();
                    enGameState=STATE_GAME_APP_RUNING;
                    MApp_ZUI_ACT_ShutdownOSD();
                    if(cur>=HWND_SOURCE_GAME_1&&cur<=HWND_SOURCE_GAME_16)
                        LoadAppBinFromUSB((U8)(cur-HWND_SOURCE_GAME_1));
                    return TRUE;
                }
            default:
                break;
        }

        return FALSE;
    }

    S32 MApp_ZUI_ACT_GameBrowseWinProc(HWND hwnd, PMSG msg)
    {
        switch(msg->message)
        {
            case MSG_NOTIFY_SETFOCUS:
                switch(MApp_ZUI_API_GetFocus())
                {
                    case HWND_SOURCE_GAME_1:
                    case HWND_SOURCE_GAME_2:
                    case HWND_SOURCE_GAME_3:
                    case HWND_SOURCE_GAME_4:
                    case HWND_SOURCE_GAME_5:
                    case HWND_SOURCE_GAME_6:
                    case HWND_SOURCE_GAME_7:
                    case HWND_SOURCE_GAME_8:
                    case HWND_SOURCE_GAME_9:
                    case HWND_SOURCE_GAME_10:
                    case HWND_SOURCE_GAME_11:
                    case HWND_SOURCE_GAME_12:
                    case HWND_SOURCE_GAME_13:
                    case HWND_SOURCE_GAME_14:
                    case HWND_SOURCE_GAME_15:
                    case HWND_SOURCE_GAME_16:
                        if(MApp_ZUI_API_IsWindowVisible(HWND_SOURCE_BG_GAME) == FALSE)
                        {
                            MApp_ZUI_API_ShowWindow(HWND_SOURCE_BG_GAME, SW_SHOW);
                            MApp_ZUI_API_ShowWindow(HWND_SOURCE_GAME_LIST, SW_SHOW);
                        }
                        break;
                    default:
                        MApp_ZUI_API_ShowWindow(HWND_SOURCE_BG_GAME, SW_HIDE);
                        MApp_ZUI_API_ShowWindow(HWND_SOURCE_GAME_LIST, SW_HIDE);
                        MApp_ZUI_API_ShowWindow(HWND_SOURCE_TOP_HALF_LIST_BG_CLEAN,SW_SHOW);
                        break;
                }
                break;

            case MSG_TIMER:
                if(hwnd == HWND_SOURCE_BG_GAME)
                {
                    MApp_ZUI_API_KillTimer(hwnd, 0);
                    MApp_ZUI_ACT_ExecuteGameBrowseAction(EN_EXE_CLOSE_CURRENT_OSD);
                }

            default:
                break;
        }
        return DEFAULTWINPROC(hwnd, msg);
        //return EFFECTPOPUP_WINPROC(hwnd, msg);
    }

#endif

#undef MAPP_ZUI_ACTINPUTSOURCE_C
