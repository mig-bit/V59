////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// ("MStar Confidential Information") by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#define MAPP_AVSYNC_C

#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include "debug.h"

#include "datatype.h"
#include "sysinfo.h"

// Common Definition
#include "MsCommon.h"
#include "apiXC.h"
#include "msAPI_Video.h"
#include "MApp_AVSync.h"
#include "msAPI_Timer.h"
#include "apiDMX.h"

#if (ENABLE_DTV)
#include "mapp_demux.h"
#endif

//extern U8 u8PcrFid;
//extern U32 msAPI_DMX_GetStc(U8 );

void MApp_AVSync_ForceSync(void)
{
    static U32 u32PreSyncTimer;
    static U32 u32PrevVideoPTS = 0;
    U32 u32VideoPTS;
    U32 u32SystemSTC,u32SystemSTC_H;
    U32 u32Diff;
    U8 u8Status = 0;
    static U8 u8ErrorCount = 0;

    if (msAPI_Timer_DiffTimeFromNow(u32PreSyncTimer) >= 2000)
    {
        //get video pts
        //u32SystemSTC = msAPI_DMX_GetStc();
        MApi_DMX_Stc_Get(&u32SystemSTC_H, &u32SystemSTC);
//        u32VideoPTS = msAPI_VID_GetPTS();
        u32VideoPTS = MApi_VDEC_GetPTS();

        if (u32SystemSTC >= u32VideoPTS)
        {
            u32Diff = u32SystemSTC-u32VideoPTS;
        }
        else
        {
            u32Diff = u32VideoPTS-u32SystemSTC;
        }

        if ((u32VideoPTS != 0) && (u32VideoPTS != u32PrevVideoPTS))
        {
            if(u32Diff>0x40000)
            {
                u8ErrorCount++;

                if(u8ErrorCount == 2)
                {
                    //msAPI_DMX_SetStc(*MApp_Dmx_GetFid(EN_PCR_FID), u32VideoPTS);
                    MApi_DMX_Stc_Set(u32SystemSTC_H, u32VideoPTS);
                    u8Status = 1;
                    u8ErrorCount = 0;
                }
                else
                {
                    u8Status = 4;
                }
            }

            else if(u32Diff>0x1000)
            {
                if (u32SystemSTC >= u32VideoPTS)
                {
                    //msAPI_DMX_SetStc(*MApp_Dmx_GetFid(EN_PCR_FID), u32SystemSTC-u32Diff/2);
                    MApi_DMX_Stc_Set(u32SystemSTC_H, u32SystemSTC-u32Diff/2);
                    u8Status = 2;
                    u8ErrorCount = 0;
                }
                else
                {
                    //msAPI_DMX_SetStc(*MApp_Dmx_GetFid(EN_PCR_FID),  u32VideoPTS-u32Diff/2);
                    MApi_DMX_Stc_Set(u32SystemSTC_H, u32VideoPTS-u32Diff/2);
                    u8Status = 3;
                    u8ErrorCount = 0;
                }
            }
            else
            {
                u8Status = 0;
                u8ErrorCount = 0;
            }
        }
        u32PreSyncTimer = msAPI_Timer_GetTime0();
        u32PrevVideoPTS = u32VideoPTS;

        MS_DEBUG_MSG(printf("STC = %08lx, ", u32SystemSTC));
        MS_DEBUG_MSG(printf("PTS = %08lx, ", u32VideoPTS));

        if (u32SystemSTC >= u32VideoPTS)
        {
            MS_DEBUG_MSG(printf("diff = +%08lx ", u32Diff));
        }
        else
        {
            MS_DEBUG_MSG(printf("diff = -%08lx ", u32Diff));
        }

        if(u8Status == 0)
        {
            MS_DEBUG_MSG(printf("skip \n"));
        }
        else if(u8Status == 1)
        {
            MS_DEBUG_MSG(printf("force \n"));
        }
        else if(u8Status == 2)
        {
            MS_DEBUG_MSG(printf("STC > PTS \n"));
        }
        else if(u8Status == 3)
        {
            MS_DEBUG_MSG(printf("STC < PTS \n"));
        }
        else if(u8Status == 4)
        {
            MS_DEBUG_MSG(printf("too diff, skip \n"));
        }
    }
}

#undef MAPP_AVSYNC_C
