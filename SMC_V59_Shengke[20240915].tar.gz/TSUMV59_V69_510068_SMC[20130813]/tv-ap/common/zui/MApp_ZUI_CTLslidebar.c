////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#define MAPP_ZUI_CTL_SLIDEBAR_C
#define _ZUI_INTERNAL_INSIDE_ //NOTE: for ZUI internal


//-------------------------------------------------------------------------------------------------
// Include Files
//-------------------------------------------------------------------------------------------------
#include "stdlib.h"
#include "stdio.h"
#include "string.h"
#include "datatype.h"
#include "debug.h"
#include "msAPI_OSD.h"
#include "msAPI_Memory.h"
#include "MApp_ZUI_Main.h"
#include "MApp_ZUI_APIcommon.h"
#include "MApp_ZUI_APIstrings.h"
#include "MApp_ZUI_APIwindow.h"
#include "MApp_ZUI_APItables.h"
#include "MApp_ZUI_APIgdi.h"
#include "MApp_ZUI_APIdraw.h"
#include "MApp_ZUI_APIcontrols.h"
#include "MApp_ZUI_APIcomponent.h"
#include "MApp_ZUI_APIalphatables.h"
#include "MApp_ZUI_ACTglobal.h"
#include "OSDcp_Bitmap_EnumIndex.h"
#include "MApp_ZUI_CTLslidebar.h"


///////////////////////////////////////////////////////////////////////////////

DRAW_BITMAP _ZUI_TBLSEG stDrawBitmap =
{
    //BMPHANDLE handle;
    E_ZUI_BMP_MAX, //U16 u16BitmapIndex;
    FALSE, //BOOLEAN bSrcColorKey;
    0x0, //OSD_COLOR srcColorKeyFrom;
    0x0, //OSD_COLOR srcColorKeyEnd;
    255, //U8 u8Constant_Alpha;
};

ST_SLIDEBAR_PARAM _ZUI_TBLSEG stSlideBarParam =
{
    FALSE,
    E_SLIDEBAR_STYLE_NONE,
    NULL,
    //left index
    {
        0, 0,
        //value style
        {
            E_ZUI_BMP_MAX,
            E_ZUI_BMP_MAX,
            E_ZUI_BMP_MAX,
        },
        //non-value style
        {
            E_ZUI_BMP_MAX,
            E_ZUI_BMP_MAX,
            E_ZUI_BMP_MAX,
        },
    },
    //mid index
    {
        0, 0,
        //value style
        {
            E_ZUI_BMP_MAX,
            E_ZUI_BMP_MAX,
            E_ZUI_BMP_MAX,
        },
        //non-value style
        {
            E_ZUI_BMP_MAX,
            E_ZUI_BMP_MAX,
            E_ZUI_BMP_MAX,
        },
    },
    //right index
    {
        0, 0,
        //value style
        {
            E_ZUI_BMP_MAX,
            E_ZUI_BMP_MAX,
            E_ZUI_BMP_MAX,
        },
        //non-value style
        {
            E_ZUI_BMP_MAX,
            E_ZUI_BMP_MAX,
            E_ZUI_BMP_MAX,
        },
    },
    //center ball index
    {
        0, 0,
        //value style
        {
            E_ZUI_BMP_MAX,
            E_ZUI_BMP_MAX,
            E_ZUI_BMP_MAX,
        },
        //non-value style
        {
            E_ZUI_BMP_MAX,
            E_ZUI_BMP_MAX,
            E_ZUI_BMP_MAX,
        },
    },
};

void MApp_ZUI_CTL_SlideBarSetParam(ST_SLIDEBAR_PARAM stParam)
{
    stSlideBarParam = stParam;
    stDrawBitmap.u16BitmapIndex = ((DRAW_BITMAP *)(stSlideBarParam.pBitmapStyle))->u16BitmapIndex;
    stDrawBitmap.bSrcColorKey = ((DRAW_BITMAP *)(stSlideBarParam.pBitmapStyle))->bSrcColorKey;
    stDrawBitmap.srcColorKeyFrom = ((DRAW_BITMAP *)(stSlideBarParam.pBitmapStyle))->srcColorKeyFrom;
    stDrawBitmap.srcColorKeyEnd = ((DRAW_BITMAP *)(stSlideBarParam.pBitmapStyle))->srcColorKeyEnd;
    stDrawBitmap.u8Constant_Alpha = ((DRAW_BITMAP *)(stSlideBarParam.pBitmapStyle))->u8Constant_Alpha;
}

///////////////////////////////////////////////////////////////////////////////
///  public  MApp_ZUI_CTL_SlideBarWinProc
///  Window Proc for "slide bar" control,
///     which a round rectangle in background, and use black, red, and center bar.
///
///  @param [in]       hWnd HWND     window handle
///  @param [in]       pMsg PMSG     message
///
///  @return S32 event handler result
///
///  @author MStarSemi @date 2007/1/25
///////////////////////////////////////////////////////////////////////////////

S32 MApp_ZUI_CTL_SlideBarWinProc(HWND hWnd, PMSG pMsg)
{
    switch(pMsg->message)
    {
        case MSG_PAINT:
            {
                //get buffer GC for offline drawing...
                PAINT_PARAM * param = (PAINT_PARAM*)pMsg->wParam;
                RECT rect_border = *(param->rect);
                RECT rect_draw = {0, 0, 0, 0};
                S16 value;
                U16 x, y, width, u16CenterBall_x;
                U8 i;

                if(stSlideBarParam.enSlideBarStyle == E_SLIDEBAR_STYLE_NONE)
                {
                    printf("[ZUI_ERROR],%s, %d\n", __FILE__, __LINE__);
                    return FALSE;
                }

                value = MApp_ZUI_ACT_GetDynamicValue(hWnd);
                if (value < 0) value = 0;
                if (value > 100) value = 100;

                u16CenterBall_x = rect_border.left;

                if(stSlideBarParam.enSlideBarStyle == E_SLIDEBAR_STYLE_MID
                    || stSlideBarParam.enSlideBarStyle == E_SLIDEBAR_STYLE_MID_CENTERBALL)
                {
                    if(value)
                    {
                        x = rect_border.left;
                        y = rect_border.top+(rect_border.height-stSlideBarParam.stMid.height)/2;
                        width = rect_border.width/100;
                        RECT_SET(rect_draw, x, y, width, stSlideBarParam.stMid.height);

                        if(param->bIsFocus)
                        {
                            stDrawBitmap.u16BitmapIndex = stSlideBarParam.stMid.stValue.enFocusIdx;
                        }
                        else if(param->bIsDisable)
                        {
                            stDrawBitmap.u16BitmapIndex = stSlideBarParam.stMid.stValue.enDisableIdx;
                        }
                        else
                        {
                            stDrawBitmap.u16BitmapIndex = stSlideBarParam.stMid.stValue.enNormalIdx;
                        }
                        for(i=1; i<=value; i++)
                        {
                            _MApp_ZUI_API_DrawDynamicComponent(CP_BITMAP, &stDrawBitmap, &param->dc, &rect_draw);
                            rect_draw.left += width;
                        }
                        u16CenterBall_x = rect_draw.left;

                        if(param->bIsFocus)
                        {
                            stDrawBitmap.u16BitmapIndex = stSlideBarParam.stMid.stNonValue.enFocusIdx;
                        }
                        else if(param->bIsDisable)
                        {
                            stDrawBitmap.u16BitmapIndex = stSlideBarParam.stMid.stNonValue.enDisableIdx;
                        }
                        else
                        {
                            stDrawBitmap.u16BitmapIndex = stSlideBarParam.stMid.stNonValue.enNormalIdx;
                        }
                        for(; i<=100; i++)
                        {
                            _MApp_ZUI_API_DrawDynamicComponent(CP_BITMAP, &stDrawBitmap, &param->dc, &rect_draw);
                            rect_draw.left += width;
                        }
                    }
                    else
                    {
                        x = rect_border.left;
                        y = rect_border.top+(rect_border.height-stSlideBarParam.stMid.height)/2;
                        width = rect_border.width/100;
                        RECT_SET(rect_draw, x, y, width, stSlideBarParam.stMid.height);

                        if(param->bIsFocus)
                        {
                            stDrawBitmap.u16BitmapIndex = stSlideBarParam.stMid.stNonValue.enFocusIdx;
                        }
                        else if(param->bIsDisable)
                        {
                            stDrawBitmap.u16BitmapIndex = stSlideBarParam.stMid.stNonValue.enDisableIdx;
                        }
                        else
                        {
                            stDrawBitmap.u16BitmapIndex = stSlideBarParam.stMid.stNonValue.enNormalIdx;
                        }
                        for(i=1; i<=100; i++)
                        {
                            _MApp_ZUI_API_DrawDynamicComponent(CP_BITMAP, &stDrawBitmap, &param->dc, &rect_draw);
                            rect_draw.left += width;
                        }
                    }
                }
                else if(stSlideBarParam.enSlideBarStyle == E_SLIDEBAR_STYLE_L_M_R
                    || stSlideBarParam.enSlideBarStyle == E_SLIDEBAR_STYLE_L_M_R_CENTERBALL)
                {
                    if(value)
                    {
                        x = rect_border.left;
                        y = rect_border.top+(rect_border.height-stSlideBarParam.stLeft.height)/2;
                        width = rect_border.width/100;
                        RECT_SET(rect_draw, x, y, stSlideBarParam.stLeft.width, stSlideBarParam.stLeft.height);

                        if(param->bIsFocus)
                        {
                            stDrawBitmap.u16BitmapIndex = stSlideBarParam.stLeft.stValue.enFocusIdx;
                        }
                        else if(param->bIsDisable)
                        {
                            stDrawBitmap.u16BitmapIndex = stSlideBarParam.stLeft.stValue.enDisableIdx;
                        }
                        else
                        {
                            stDrawBitmap.u16BitmapIndex = stSlideBarParam.stLeft.stValue.enNormalIdx;
                        }
                        _MApp_ZUI_API_DrawDynamicComponent(CP_BITMAP, &stDrawBitmap, &param->dc, &rect_draw);

                        rect_draw.left += stSlideBarParam.stLeft.width;
                        rect_draw.width = width;
                        if(param->bIsFocus)
                        {
                            stDrawBitmap.u16BitmapIndex = stSlideBarParam.stMid.stValue.enFocusIdx;
                        }
                        else if(param->bIsDisable)
                        {
                            stDrawBitmap.u16BitmapIndex = stSlideBarParam.stMid.stValue.enDisableIdx;
                        }
                        else
                        {
                            stDrawBitmap.u16BitmapIndex = stSlideBarParam.stMid.stValue.enNormalIdx;
                        }
                        for(i=2; i<=value; i++)
                        {
                            _MApp_ZUI_API_DrawDynamicComponent(CP_BITMAP, &stDrawBitmap, &param->dc, &rect_draw);
                            rect_draw.left += width;
                        }
                        u16CenterBall_x = rect_draw.left;

                        if(param->bIsFocus)
                        {
                            stDrawBitmap.u16BitmapIndex = stSlideBarParam.stMid.stNonValue.enFocusIdx;
                        }
                        else if(param->bIsDisable)
                        {
                            stDrawBitmap.u16BitmapIndex = stSlideBarParam.stMid.stNonValue.enDisableIdx;
                        }
                        else
                        {
                            stDrawBitmap.u16BitmapIndex = stSlideBarParam.stMid.stNonValue.enNormalIdx;
                        }
                        for(; i<=99; i++)
                        {
                            _MApp_ZUI_API_DrawDynamicComponent(CP_BITMAP, &stDrawBitmap, &param->dc, &rect_draw);
                            rect_draw.left += width;
                        }

                        rect_draw.width = stSlideBarParam.stRight.width;
                        if(value == 100)
                        {
                            rect_draw.left -= width;
                            if(param->bIsFocus)
                            {
                                stDrawBitmap.u16BitmapIndex = stSlideBarParam.stRight.stValue.enFocusIdx;
                            }
                            else if(param->bIsDisable)
                            {
                                stDrawBitmap.u16BitmapIndex = stSlideBarParam.stRight.stValue.enDisableIdx;
                            }
                            else
                            {
                                stDrawBitmap.u16BitmapIndex = stSlideBarParam.stRight.stValue.enNormalIdx;
                            }
                        }
                        else
                        {
                            if(param->bIsFocus)
                            {
                                stDrawBitmap.u16BitmapIndex = stSlideBarParam.stRight.stNonValue.enFocusIdx;
                            }
                            else if(param->bIsDisable)
                            {
                                stDrawBitmap.u16BitmapIndex = stSlideBarParam.stRight.stNonValue.enDisableIdx;
                            }
                            else
                            {
                                stDrawBitmap.u16BitmapIndex = stSlideBarParam.stRight.stNonValue.enNormalIdx;
                            }
                        }
                        _MApp_ZUI_API_DrawDynamicComponent(CP_BITMAP, &stDrawBitmap, &param->dc, &rect_draw);
                    }
                    else
                    {
                        x = rect_border.left;
                        y = rect_border.top+(rect_border.height-stSlideBarParam.stLeft.height)/2;
                        width = rect_border.width/100;
                        RECT_SET(rect_draw, x, y, stSlideBarParam.stLeft.width, stSlideBarParam.stLeft.height);

                        if(param->bIsFocus)
                        {
                            stDrawBitmap.u16BitmapIndex = stSlideBarParam.stLeft.stNonValue.enFocusIdx;
                        }
                        else if(param->bIsDisable)
                        {
                            stDrawBitmap.u16BitmapIndex = stSlideBarParam.stLeft.stNonValue.enDisableIdx;
                        }
                        else
                        {
                            stDrawBitmap.u16BitmapIndex = stSlideBarParam.stLeft.stNonValue.enNormalIdx;
                        }
                        _MApp_ZUI_API_DrawDynamicComponent(CP_BITMAP, &stDrawBitmap, &param->dc, &rect_draw);

                        rect_draw.left += stSlideBarParam.stLeft.width;
                        rect_draw.width = width;
                        if(param->bIsFocus)
                        {
                            stDrawBitmap.u16BitmapIndex = stSlideBarParam.stMid.stNonValue.enFocusIdx;
                        }
                        else if(param->bIsDisable)
                        {
                            stDrawBitmap.u16BitmapIndex = stSlideBarParam.stMid.stNonValue.enDisableIdx;
                        }
                        else
                        {
                            stDrawBitmap.u16BitmapIndex = stSlideBarParam.stMid.stNonValue.enNormalIdx;
                        }
                        for(i=2; i<=99; i++)
                        {
                            _MApp_ZUI_API_DrawDynamicComponent(CP_BITMAP, &stDrawBitmap, &param->dc, &rect_draw);
                            rect_draw.left += width;
                        }

                        rect_draw.width = stSlideBarParam.stRight.width;
                        if(param->bIsFocus)
                        {
                            stDrawBitmap.u16BitmapIndex = stSlideBarParam.stRight.stNonValue.enFocusIdx;
                        }
                        else if(param->bIsDisable)
                        {
                            stDrawBitmap.u16BitmapIndex = stSlideBarParam.stRight.stNonValue.enDisableIdx;
                        }
                        else
                        {
                            stDrawBitmap.u16BitmapIndex = stSlideBarParam.stRight.stNonValue.enNormalIdx;
                        }
                        _MApp_ZUI_API_DrawDynamicComponent(CP_BITMAP, &stDrawBitmap, &param->dc, &rect_draw);
                    }
                }

                if(stSlideBarParam.enSlideBarStyle == E_SLIDEBAR_STYLE_MID_CENTERBALL
                    || stSlideBarParam.enSlideBarStyle == E_SLIDEBAR_STYLE_L_M_R_CENTERBALL)
                {
                    if(param->bIsFocus)
                    {
                        stDrawBitmap.u16BitmapIndex = stSlideBarParam.stCenterBall.stValue.enFocusIdx;
                    }
                    else if(param->bIsDisable)
                    {
                        stDrawBitmap.u16BitmapIndex = stSlideBarParam.stCenterBall.stValue.enDisableIdx;
                    }
                    else
                    {
                        stDrawBitmap.u16BitmapIndex = stSlideBarParam.stCenterBall.stValue.enNormalIdx;
                    }
                    x = u16CenterBall_x-stSlideBarParam.stCenterBall.width/2;
                    y = rect_border.top+(rect_border.height-stSlideBarParam.stCenterBall.height)/2;
                    RECT_SET(rect_draw, x, y, stSlideBarParam.stCenterBall.width, stSlideBarParam.stCenterBall.height);
                    _MApp_ZUI_API_DrawDynamicComponent(CP_BITMAP, &stDrawBitmap, &param->dc, &rect_draw);
                }
            }
            return 0;

        default:
            break;

    }
    return DEFAULTWINPROC(hWnd, pMsg);
}

#undef MAPP_ZUI_CTL_SLIDEBAR_C

