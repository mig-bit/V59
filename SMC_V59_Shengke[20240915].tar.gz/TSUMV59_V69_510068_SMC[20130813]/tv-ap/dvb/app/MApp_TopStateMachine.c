////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#define MAPP_TOPSTATEMACHINE_C
/******************************************************************************/
/*                            Header Files                                    */
/******************************************************************************/
#include "Board.h"
#include "datatype.h"
#include "MsCommon.h"
#include "debug.h"
#include "apiXC.h"
#include "apiXC_Adc.h"
#include "msAPI_ATVSystem.h"
#include "msAPI_MailBox.h"
#include "MApp_Main.h"
#include "MApp_TopStateMachine.h"
#include "MApp_GlobalFunction.h"
#include "MApp_GlobalSettingSt.h"
#include "MApp_ChannelChange.h"
#include "MApp_ATV_Scan.h"
#include "MApp_TV.h"
#include "MApp_AnalogInputs.h"
#include "MApp_SignalMonitor.h"
#include "MApp_Standby.h"
#include "MApp_Scan.h"

#if (ENABLE_DTV_EPG)
#include "mapp_epgdb_public.h"
#endif

#include "MApp_UiMenuDef.h"
#include "MApp_ZUI_Main.h"
#include "ZUI_tables_h.inl"
#include "MApp_Menu_Main.h"
#include "MApp_Install_Main.h"
#if DVB_C_ENABLE
#include "MApp_CADTV_ManualTuning_Main.h"
#include "GPIO.h"
#endif
#include "MApp_DTV_ManualTuning_Main.h"
#include "MApp_ATV_ManualTuning_Main.h"
#include "MApp_InputSource_Main.h"
#if ENABLE_OAD
#include "MApp_OAD.h"
#endif
#if ENABLE_DMP
#include "MApp_DMP_Main.h"
#include "MApp_APEngine.h"
#include "mapp_mplayer.h"
#endif
#include "MApp_OSDPage_Main.h"

#if ENABLE_SUBTITLE
#include "MApp_Subtitle.h"
#endif

#ifdef ENABLE_BT
#include "MApp_BT.h"
#include "MApp_BT_Main.h"
#endif

#ifdef ENABLE_KTV
#include "MApp_KTV_Main.h"
#endif

#if(ENABLE_PVR ==1)
    #include "MApp_PVR_Main.h"
    #include "MApp_PVR.h"
#endif

#if MHEG5_ENABLE
#include "MApp_MHEG5_Main.h"
#endif
#include "MApp_APEngine.h"
#include "MApp_UiEpg.h"

#if (CHANNEL_SCAN_AUTO_TEST)
#include "drvUartDebug.h"
#include "drvAUDIO.h"
#include "mapp_demux.h"
#include "msAPI_DTVSystem.h"
#include "msAPI_FreqTableDTV.h"
#include "MApp_Subtitle.h"
//ZUI_TODO: #include "MApp_UiMenuStr.h"
//ZUI_TODO: #include "MApp_UiMenuFunc.h"
#endif

#if (ENABLE_USB)
#include "MApp_USBDownload.h"
#endif

#if ENABLE_CI
#include "MApp_CIMMI.h"
#include "msAPI_CI.h"
#endif

#if (ENABLE_TTX)
#include "msAPI_TTX.h"
#include "mapp_ttx.h"
#endif
#include "MApp_MultiTasks.h"


#include "MApp_APEngine.h"
#include "msAPI_APEngine.h"
#include "MApp_InputSource.h"
#if ((BRAZIL_CC )|| (ATSC_CC == ATV_CC))
#include "mapp_closedcaption.h"
#endif

#if (ENABLE_DTV_EPG)
#include "MApp_EpgTimer.h"
#endif
#include "msAPI_FreqTableDTV.h"
#include "MApp_SaveData.h"
#if (OBA2 && PARTIALLY_UPDATE && !defined(UI2_OBAMA))
#include "MApp_ZUI_ACTupgrade.h"
#endif

#ifdef CHIP_S7LD
#include "drvMIU.h"
#endif
#if NTV_FUNCTION_ENABLE
#include "MApp_ChList_Main.h"
#endif
#include "msAPI_Timer.h"
#if (ENABLE_DTV_EPG && DTG_FREEVIEW_STANDBY)
    extern BOOLEAN MApp_FreeView_Standby_Switch(void);
#endif

#if BOE_USB_UPGRADE_FACTROY//minglin1206
extern void MApp_Usb_UpDate_Init(void); 
#endif

/*****************************************************************************/
/*                                 Macro                                     */
/*****************************************************************************/
#if USER_DEBUG && BUILD_SYSDEBUG
extern void userdebug(void);
#define USERDBG(x)   x
#else
#define USERDBG(x)
#endif

#if SYSTEM_DEBUG && BUILD_SYSDEBUG
extern void sysdebug(void);
#define SYSDBG(x)   x
#else
#define SYSDBG(x)
#endif

#if ENABLE_MSTV_UART_DEBUG
#define UART_DEBUG()    if (msAPI_UART_DecodeCommand()) { msAPI_Timer_ResetWDT(); continue;}// stop main loop for debug
#else
#define UART_DEBUG()
#endif

#if (CHANNEL_SCAN_AUTO_TEST)
#define CHSCANTEST_MSG(x)    x

extern ScanAutoTestData g_ScanAutoTestData;
extern ScanAutoTestAU   g_ScanAutoTestAU;
extern U8               g_u8ScanAutoTestCmd;
extern U8               g_u8ScanAutoTestKey;
extern U8               g_u8TopStateChkCase;
extern U8               g_u8AUDbgCmd;
extern U8               PrnStrBuf[128] = {0};
extern U8                u8RFCh;

extern void MApp_TV_ProcessUserInput(void);

#else
#define CHSCANTEST_MSG(x)
#endif
extern EN_OSD_TUNE_TYPE_SETTING eTuneType;
#if NTV_FUNCTION_ENABLE
extern EN_CHLIST_MODE _eChannelListMode;
#endif

/********************************************************************************/
/*                                Static                                        */
/********************************************************************************/
static EN_TOP_STATE enTopState;
static EN_TOP_STATE enTopStateBeforeScan;

#if (CHANNEL_SCAN_AUTO_TEST)
static void _MApp_ScanAutoTest(void);
#endif

#if SYSTEM_DEBUG
static EN_TOP_STATE previousTopState = (EN_TOP_STATE)0xFF;
#endif

/********************************************************************************/
/*                                Function                                       */
/********************************************************************************/
void MApp_TopStateMachine(void)
{
    #if STATE_PRINT
    if (u8KeyCode != KEY_NULL)
    {
        printf("\nMS:0x%x \n", enTopState);
    }
    #endif

    SYSDBG(sysdebug());

    MApp_PreProcessUserInput();

    #if SYSTEM_DEBUG
    if ( enTopState != previousTopState )
    {
        printf("enTopState=%u\n", (U16)enTopState);
        previousTopState=enTopState;
    }
    #endif

    #if (CHANNEL_SCAN_AUTO_TEST)
    _MApp_ScanAutoTest();
    #endif
    switch ( enTopState )
    {
        #if (OBA2 && PARTIALLY_UPDATE && !defined(UI2_OBAMA))
        case STATE_TOP_UPGRADE:
            switch((U8)MApp_Upgrade_Main())
            {
                case EXIT_CLOSE:
                    enTopState = STATE_TOP_DIGITALINPUTS;
                    break;
                case EXIT_GOTO_STANDBY:
                    enTopState = STATE_TOP_STANDBY;
                    break;
            }
            break;
        #endif

        case STATE_TOP_TTX:
            // mheg_process is moved to multitask now.
            break;

        case STATE_TOP_ANALOG_SHOW_BANNER:
            switch(MApp_ChannelChange_ShowAnalogBanner())
            {
                case EXIT_CLOSE:
                    enTopState = STATE_TOP_DIGITALINPUTS;
                    break;

                default:
                    break;
            }
            break;

    #if ((BRAZIL_CC )|| (ATSC_CC == ATV_CC))
        case STATE_TOP_CLOSEDCAPTION:
            if(enCCFontStatus == CC_FONT_LOAD)
            {
                switch(MApp_ClosedCaption_Main())
                {
                    // If user press any key
                    case EXIT_CLOSE:
                    case EXIT_CLOSEDCAPTION_NULL:
                    case EXIT_CLOSEDCAPTION_DONE:
                        enTopState = STATE_TOP_DIGITALINPUTS;//STATE_TOP_TV;
                    break;

                    default:
                        break;
                }
            }
            else
            {
                enCCFontStatus = CC_FONT_UNLOAD_SPEEDUP;
            }
            break;
    #endif // #ifdef NTSC_CC_ON_DVB


        case STATE_TOP_CHANNELCHANGE:
            switch(MApp_ChannelChange())
            {
                case EXIT_CLOSE:
                   #if (ENABLE_DTV_EPG)
                    MApp_Epg_SrvPriorityHandler(msAPI_CM_GetCurrentPosition(msAPI_CM_GetCurrentServiceType()));
                   #endif

                   enTopState = STATE_TOP_DIGITALINPUTS;
                    //MApp_ChannelChange_CheckBlockChannelPW();
                    break;

                default:
                    break;
            }
            break;

    #if ENABLE_DTV
        case STATE_TOP_DTV_SCAN:
          #if ENABLE_SBTVD_BRAZIL_APP
            msAPI_ATV_SetCurrentAntenna(ANT_AIR);
          #endif
#if ENABLE_OAD
            if(bShowOadScanPage == TRUE)
            {
                switch ( MApp_OAD_Scan(&u8OADpercentage) )
                {
                    case EXIT_GOTO_CHANNELCHANGE:
                        enTopState = STATE_TOP_CHANNELCHANGE;
                        break;
                    default:
                        break;
                }
                break;
            }
            else
#endif
            {
            switch ( MApp_DTV_Scan() )
            {

                case EXIT_GOTO_PREVIOUS:
                    enTopState = enTopStateBeforeScan;  //for not closing tuing page immediately when tuining completely
              break;

                case EXIT_GOTO_CHANNELCHANGE:
                    enTopState = STATE_TOP_CHANNELCHANGE;
                    break;

                case EXIT_GOTO_TV:
                    enTopState = enTopStateBeforeScan;
                    break;

                case EXIT_GOTO_STANDBY:
                    enTopState = STATE_TOP_STANDBY;
                    break;
              #if ENABLE_SBTVD_BRAZIL_APP
                case EXIT_GOTO_ATVSCAN:
                    enTopState = STATE_TOP_ATV_SCAN;
                    break;
              #endif
#if 0 //NTV_FUNCTION_ENABLE  //wait to do
                    case EXIT_GOTO_NTV_LIST:
                    {
                    //set FavoriteNetwork is 0 for defalut;
                        //msAPI_CM_Set_FavoriteNetwork(0);
                        //MApp_ZUI_ACT_ExecuteChannelListAction(EN_EXE_CLOSE_CURRENT_OSD);
                        //msAPI_CM_ArrangeDataManager(TRUE);
                        MApp_OSDPage_SetOSDPage(E_OSD_CHANNEL_LIST);
                        MApp_ChannelList_SetMode(MODE_NETWORK_CHLIST_TV);
                        enTopState = STATE_TOP_OSDPAGE;
                    }
                    break;
#endif
                default:
                    break;
            }
            break;
            }
    #endif // #if ENABLE_DTV


#if (ENABLE_UPDATE_MULTIPLEX_VIA_NIT)
        case STATE_TOP_SCAN_NEW_MUX:
            switch ( MApp_DTV_Scan_Update_Mux() )
            {
                case EXIT_GOTO_PREVIOUS:
                    enTopState = enTopStateBeforeScan;
                    break;
                case EXIT_GOTO_CHANNELCHANGE:
                    enTopState = STATE_TOP_CHANNELCHANGE;
                    break;
                case EXIT_GOTO_WAIT:
                    enTopState = STATE_TOP_DIGITALINPUTS;
                    break;
                case EXIT_GOTO_STANDBY:
                    enTopState = STATE_TOP_STANDBY;
                    break;
                default:
                    break;
            }
            break;
#endif

        case STATE_TOP_ATV_SCAN:
#if ENABLE_SBTVD_BRAZIL_APP
            msAPI_ATV_SetCurrentAntenna(ANT_AIR);
#endif

            switch(MApp_ATV_Scan())
            {
                case EXIT_GOTO_STANDBY:
                    enTopState = STATE_TOP_STANDBY;
                    break;

                case EXIT_GOTO_CHANNELCHANGE:
                    enTopState = STATE_TOP_CHANNELCHANGE;
                    break;

                case EXIT_GOTO_TV:
                    enTopState = STATE_TOP_DIGITALINPUTS;
                    break;

                case EXIT_GOTO_PREVIOUS:
                    enTopState = enTopStateBeforeScan;  //for not closing tuing page immediately when tuining completely
                    break;

            #if ENABLE_DTV
                case EXIT_GOTO_DTVSCAN:
                    enTopState =STATE_TOP_DTV_SCAN;
                    MApp_ATV_Scan_State_Init();
                    MApp_Scan_State_Init();
                    break;
            #endif

            #if ENABLE_SBTVD_BRAZIL_APP
                case EXIT_GOTO_CATVSCAN:
                    enTopState = STATE_TOP_CATV_SCAN;
                    break;
            #endif
                default:
                    break;
            }
            break;

    #if ENABLE_SBTVD_BRAZIL_APP
        case STATE_TOP_CATV_SCAN:
            msAPI_ATV_SetCurrentAntenna(ANT_CATV);
            switch(MApp_ATV_Scan())
            {
                case EXIT_GOTO_STANDBY:
                    enTopState = STATE_TOP_STANDBY;
                    break;

                case EXIT_GOTO_CHANNELCHANGE:
                    enTopState = STATE_TOP_CHANNELCHANGE;
                    break;

                case EXIT_GOTO_TV:
                    enTopState = STATE_TOP_DIGITALINPUTS;
                    break;

                case EXIT_GOTO_PREVIOUS:
                    enTopState = enTopStateBeforeScan;  //for not closing tuing page immediately when tuining completely
                    break;
            #if ENABLE_DTV
                case EXIT_GOTO_DTVSCAN:
                    enTopState =STATE_TOP_DTV_SCAN;
                    MApp_ATV_Scan_State_Init();
                    MApp_Scan_State_Init();
                    break;
            #endif
                default:
                    break;
            }
            break;
        #endif // #if ENABLE_SBTVD_BRAZIL_APP

        case STATE_TOP_DIGITALINPUTS:
            switch(MApp_TV())
            {
                case EXIT_GOTO_USB:
                    enTopState = STATE_TOP_USB_DOWNLOAD;
                    break;

            #if ENABLE_OAD
                case EXIT_GOTO_OAD:
                    enTopState = STATE_TOP_OAD;
                    break;
            #endif

               case EXIT_GOTO_MENU:
                    enTopState = STATE_TOP_MENU;
                    break;

                case EXIT_GOTO_INSTALLGUIDE:
                    enTopState = STATE_TOP_INSTALLGUIDE;
                    break;

                case EXIT_GOTO_STANDBY:
                    enTopState = STATE_TOP_STANDBY;
                    break;

                case EXIT_GOTO_CHANNELCHANGE:
                    enTopState = STATE_TOP_CHANNELCHANGE;
                    break;

            #if ((BRAZIL_CC )|| (ATSC_CC == ATV_CC))
                case EXIT_GOTO_CLOSEDCAPTION:
                    enTopState = STATE_TOP_CLOSEDCAPTION;
                    break;
            #endif

            #if ( ENABLE_SUBTITLE&&(SUBTITLE_WITH_OSD == FALSE) )
                case EXIT_GOTO_SUBTITLE:
                    enTopState = STATE_TOP_SUBTITLE;
                    break;
            #endif

            #if (ENABLE_DTV_EPG)
                case EXIT_GOTO_EPG:
                    enTopState = STATE_TOP_EPG;
                    break;
            #endif  //#if (ENABLE_DTV_EPG)

                case EXIT_GOTO_INPUTSOURCE:
                    enTopState = STATE_TOP_INPUTSOURCE;
                    break;

                case EXIT_GOTO_OSDPAGE:
                    enTopState = STATE_TOP_OSDPAGE;
                    break;

            #if ( ENABLE_DVB_TAIWAN_APP || ENABLE_SBTVD_BRAZIL_APP || (TV_SYSTEM == TV_NTSC) )
                case EXIT_GOTO_SCAN:
                    enTopStateBeforeScan = STATE_TOP_DIGITALINPUTS;
                    enTopState = STATE_TOP_ATV_SCAN;
                    MApp_ATV_Scan_State_Init();
                    break;
            #endif

            #if ENABLE_CI
                case EXIT_GOTO_MMI:
                    //if(IsAnyTVSourceInUse()||IsAVInUse())
                    enTopState = STATE_TOP_MMI;
                    break;
            #endif

            #if ENABLE_DMP
                case EXIT_GOTO_DMP:
                    enTopState = STATE_TOP_DMP;
                    break;
            #endif

            #if (ENABLE_UPDATE_MULTIPLEX_VIA_NIT)
                case EXIT_GOTO_SCAN_NEW_MUX:
                    enTopStateBeforeScan = STATE_TOP_DIGITALINPUTS;
                    enTopState = STATE_TOP_SCAN_NEW_MUX;
                    MApp_DTV_Scan_Update_Mux_State_Init();
                    break;
            #endif
                default:
                    break;
            }
            break;

        case STATE_TOP_MENU:
            switch(MApp_Menu_Main())
            {
                case EXIT_CLOSE:
                {
                    if(IsAnyTVSourceInUse())
                    {
                        enTopState = STATE_TOP_DIGITALINPUTS;
                    }
                    else
                    {
                        enTopState = STATE_TOP_DIGITALINPUTS;
                    }
                }
                break;

                case EXIT_GOTO_STANDBY:
                    enTopState = STATE_TOP_STANDBY;
                    break;

                case EXIT_GOTO_SCAN:
                    enTopStateBeforeScan = STATE_TOP_MENU;

                #if (!ENABLE_DVBC_PLUS_DTMB_CHINA_APP)
                  #if ENABLE_T_C_COMBO
                    if(IsCATVInUse())//TODO need add DVB-C case
                    {
                        stGenSetting.stScanMenuSetting.u8DVBCTvConnectionType=EN_DVB_C_TYPE;
                        msAPI_CM_ResetAllProgram();
                        MApp_SaveScanMenuSetting();
                        msAPI_Tuner_SwitchSource((EN_DVB_TYPE)stGenSetting.stScanMenuSetting.u8DVBCTvConnectionType, TRUE);
                    }
                    else
                    {
                        stGenSetting.stScanMenuSetting.u8DVBCTvConnectionType=EN_DVB_T_TYPE;
                        MApp_SaveScanMenuSetting();
                        msAPI_Tuner_SwitchSource((EN_DVB_TYPE)stGenSetting.stScanMenuSetting.u8DVBCTvConnectionType, TRUE);
                    }
				    MApp_DVBType_SetPrevType((EN_DVB_TYPE)stGenSetting.stScanMenuSetting.u8DVBCTvConnectionType);
                  #elif  DVB_T_C_DIFF_DB
                    if(IsCATVInUse())
                     {
                        msAPI_CM_ResetAllProgram();
                        stGenSetting.stScanMenuSetting.u8DVBCTvConnectionType=EN_DVB_T_TYPE;
                        MApp_SaveScanMenuSetting();
                        msAPI_Tuner_SwitchSource((EN_DVB_TYPE)stGenSetting.stScanMenuSetting.u8DVBCTvConnectionType, TRUE);
                    }
                  #endif
                #endif // #if (!ENABLE_DVBC_PLUS_DTMB_CHINA_APP)

                    if(stGenSetting.stScanMenuSetting.u8ScanType == SCAN_TYPE_AUTO)
                    {
                        // reset ATV CM and DTV CM
                    #if ( ENABLE_DVB_TAIWAN_APP || ENABLE_SBTVD_BRAZIL_APP )
                        if(msAPI_ATV_GetCurrentAntenna() == ANT_AIR)
                        {
                            msAPI_ATV_ResetChannelData(E_CHRESET_AIR);
                            msAPI_CM_ResetAllProgram();
                          #if (ENABLE_UPDATE_MULTIPLEX_VIA_NIT)
                            MApp_SI_ResetNetwork();
                          #endif
                        }
                        else
                        {
                            msAPI_ATV_ResetChannelData(E_CHRESET_CATV);
                        }
                    #elif ( TV_SYSTEM == TV_NTSC )
                        if(msAPI_ATV_GetCurrentAntenna() == ANT_AIR)
                        {
                            msAPI_ATV_ResetChannelData(E_CHRESET_AIR);
                          #if (ENABLE_UPDATE_MULTIPLEX_VIA_NIT)
                            MApp_SI_ResetNetwork();
                          #endif
                        }
                        else
                        {
                            msAPI_ATV_ResetChannelData(E_CHRESET_CATV);
                        }

                    #else
                        #if ENABLE_CUS_UPDATE_SCAN
                        if(g_bGotoUpdateScan)
                        {
                            //DON'T reset channel
                        }
                        else
                        #endif
                        {
                            if(eTuneType==OSD_TUNE_TYPE_DTV_PLUS_ATV || eTuneType==OSD_TUNE_TYPE_ATV_ONLY)
                                msAPI_ATV_ResetChannelData();

                          #if ENABLE_DTV
                            if(eTuneType==OSD_TUNE_TYPE_DTV_PLUS_ATV || eTuneType==OSD_TUNE_TYPE_DTV_ONLY)
                            {
                              #if ENABLE_T_C_CHANNEL_MIX
                                msAPI_CM_RemoveDTVProgramOfAntenna();
                              #else
                                msAPI_CM_ResetAllProgram();
                              #endif
                            }
                          #endif // #if ENABLE_DTV
                        }

                      #if (ENABLE_UPDATE_MULTIPLEX_VIA_NIT)
                        MApp_SI_ResetNetwork();
                      #endif
                    #endif

                    #if ENABLE_SBTVD_BRAZIL_APP
                        enTopState = STATE_TOP_DTV_SCAN;
                    #else
                        if(eTuneType == OSD_TUNE_TYPE_DTV_ONLY )
                            enTopState = STATE_TOP_DTV_SCAN;
                        else
                            enTopState = STATE_TOP_ATV_SCAN;
                    #endif

                    #if ENABLE_TTX_ACI
                        MApp_TTX_InitACI();
                    #endif
                    }
                #if DVB_C_ENABLE
                    else if(stGenSetting.stScanMenuSetting.u8ScanType == SCAN_TYPE_NETWORK)
                    {
                        //eTuneType must == OSD_TUNE_TYPE_CADTV_ONLY
                        msAPI_CM_ResetAllProgram();
                        enTopState = STATE_TOP_DTV_SCAN;
                    }
                #endif
                    else
                    {
                        if(IsSrcTypeATV(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)))
                            enTopState = STATE_TOP_ATV_SCAN;
                        else
                            enTopState = STATE_TOP_DTV_SCAN;
                    }
                    MApp_ATV_Scan_State_Init();
                    MApp_Scan_State_Init();
                    break;

            #if (ENABLE_DTV_EPG)
                case EXIT_GOTO_EPG:
                    enTopState = STATE_TOP_EPG;
                    break;
            #endif  //#if (ENABLE_DTV_EPG)

            #if ENABLE_DTV
                case EXIT_GOTO_DTV_MANUALTUNING:
                    g_CurSignalStrength = 0;
                    enTopState = STATE_TOP_DTV_MANUAL_TUNING;
                    break;
            #endif

                case EXIT_GOTO_ATV_MANUALTUNING:
                  #if ENABLE_CUS_UI_SPEC
                    enTopStateBeforeScan = STATE_TOP_MENU;
                    enTopState = STATE_TOP_ATV_SCAN;
                    MApp_ATV_Scan_State_Init();
                    MApp_Scan_State_Init();
                   #if ( ENABLE_DVB_TAIWAN_APP || ENABLE_SBTVD_BRAZIL_APP )
                    msAPI_ATV_SetDirectTuneFlag(FALSE);
                   #endif
                    stGenSetting.stScanMenuSetting.u8ScanType = SCAN_TYPE_MANUAL;
                    stGenSetting.stScanMenuSetting.u8ATVManScanType = ATV_MAN_SCAN_TYPE_ONECH;
                    stGenSetting.stScanMenuSetting.u8ATVManScanDir = ATV_MAN_SCAN_UP;
                    u8IdleDigitCount = 0;
                    u16IdleInputValue = 0;
                  #else
                    enTopState = STATE_TOP_ATV_MANUAL_TUNING;
                  #endif
                    break;

                case EXIT_GOTO_CHANNELCHANGE:
                    enTopState = STATE_TOP_CHANNELCHANGE;
                    break;

            #if ENABLE_CI
                case EXIT_GOTO_MMI:
                    enTopState = STATE_TOP_MMI;
                    break;
            #endif

            #if ENABLE_DMP
                case EXIT_GOTO_DMP:
                    enTopState = STATE_TOP_DMP;
                    break;
            #endif

            #ifdef ENABLE_BT
                case EXIT_GOTO_BT: //for BT
                    enTopState = STATE_TOP_BT;
                    MApp_BT_Main_Exit();
                    break;
            #endif

            #ifdef ENABLE_KTV
                case EXIT_GOTO_KTV:
                    enTopState = STATE_TOP_KTV;
                    break;
            #endif

            #if(ENABLE_PVR ==1)
                case EXIT_GOTO_PVR_CHECK_FS:
                    enPvrState = STATE_PVR_CHECK_FS_INIT;
                    enTopState = STATE_TOP_PVR;
                    break;
            #endif

            #if DVB_C_ENABLE
                 case EXIT_GOTO_CADTV_MANUALTUNING:
                    enTopState = STATE_TOP_CADTV_MANUAL_TUNING;
                    break;
            #endif

                case EXIT_GOTO_OSDPAGE:
                    enTopState = STATE_TOP_OSDPAGE;
                    break;

                case EXIT_GOTO_INPUTSOURCE:
                    enTopState = STATE_TOP_INPUTSOURCE;
                    break;

                case EXIT_GOTO_INFO:
                    enTopState = STATE_TOP_ANALOG_SHOW_BANNER;
                    break;

            #if OBA2
                case EXIT_GOTO_APENGINE:
                    enTopState = STATE_TOP_APENGINE;
                    MApp_APEngine_ClearRetVal();
                    break;
            #endif

                default:
                    break;
            }
            break;

#if(ENABLE_PVR ==1)
        case STATE_TOP_PVR:
            switch(MApp_PVR_Main())
            {
                case EXIT_CLOSE:
                    enTopState = STATE_TOP_DIGITALINPUTS;
                    break;

                case EXIT_GOTO_STANDBY:
                    enTopState = STATE_TOP_STANDBY;
                    break;

                case EXIT_GOTO_MENU:
                    enTopState = STATE_TOP_MENU;
                    break;
                default:
                    break;
            }
            break;
#endif

        case STATE_TOP_INSTALLGUIDE:
            switch(MApp_InstallGuide_Main())
            {
                case EXIT_CLOSE:
                    enTopState = STATE_TOP_DIGITALINPUTS;
                break;

                case EXIT_GOTO_STANDBY:
                    enTopState = STATE_TOP_STANDBY;
                    break;

                case EXIT_GOTO_SCAN:
                    printf("\r\ngoto scan");
                    enTopStateBeforeScan = STATE_TOP_INSTALLGUIDE;//STATE_TOP_DIGITALINPUTS;
#if ENABLE_SBTVD_BRAZIL_APP
        #if ENABLE_DTV
                    enTopState = STATE_TOP_DTV_SCAN;
        #else
                    enTopState = STATE_TOP_ATV_SCAN;
        #endif
#else
                    enTopState = STATE_TOP_ATV_SCAN;
#if ENABLE_TTX_ACI
                    MApp_TTX_InitACI();
#endif
                    MApp_ATV_Scan_State_Init();
#endif
                    MApp_Scan_State_Init();
                    break;
#if (ENABLE_DTV_EPG)
                case EXIT_GOTO_EPG:
                    enTopState = STATE_TOP_EPG;
                    break;
#endif //#if (ENABLE_DTV_EPG)

                case EXIT_GOTO_CHANNELCHANGE:
                    enTopState = STATE_TOP_CHANNELCHANGE;
                    break;
                default:
                    break;

            }
            break;

#if ENABLE_DTV
        case STATE_TOP_DTV_MANUAL_TUNING:

            switch(MApp_DTV_ManualTuning_Main())
            {
                case EXIT_CLOSE:
                    enTopState = STATE_TOP_DIGITALINPUTS;
                    break;

                case EXIT_GOTO_STANDBY:
                    enTopState = STATE_TOP_STANDBY;
                    break;

                case EXIT_GOTO_MENU:
                    enTopState = STATE_TOP_MENU;
                    break;

                case EXIT_GOTO_DTVSCAN:
#if 0//ENABLE_T_C_COMBO
                    msAPI_CM_ResetAllProgram();
#endif
                    enTopState = STATE_TOP_DTV_SCAN;
                    enTopStateBeforeScan = STATE_TOP_DTV_MANUAL_TUNING;

                    MApp_Scan_State_Init();
                    break;
#if 0 //NTV_FUNCTION_ENABLE // wait to do
                case EXIT_GOTO_NTV_LIST:
                {
                    //set FavoriteNetwork is 0 for defalut;
                    //msAPI_CM_Set_FavoriteNetwork(0);
                    //MApp_ZUI_ACT_ExecuteChannelListAction(EN_EXE_CLOSE_CURRENT_OSD);
                    //msAPI_CM_ArrangeDataManager(TRUE);
                    //MApp_ZUI_ACT_StartupOSD(E_OSD_CHANNEL_LIST);
                    MApp_OSDPage_SetOSDPage(E_OSD_CHANNEL_LIST);
                    MApp_ChannelList_SetMode(MODE_NETWORK_CHLIST_TV);
                    enTopState = STATE_TOP_OSDPAGE;
                }
                break;
#endif
                default:
                    break;


            }
            break;
#endif
        case STATE_TOP_ATV_MANUAL_TUNING:
            switch(MApp_ATV_ManualTuning_Main())
            {
                case EXIT_CLOSE:
                    enTopState = STATE_TOP_DIGITALINPUTS;
                    break;

                case EXIT_GOTO_STANDBY:
                    enTopState = STATE_TOP_STANDBY;
                    break;

                case EXIT_GOTO_MENU:
                    enTopState = STATE_TOP_MENU;
                    break;

                case EXIT_GOTO_ATVSCAN:
                    enTopState = STATE_TOP_ATV_SCAN;
                    enTopStateBeforeScan = STATE_TOP_ATV_MANUAL_TUNING;

                    MApp_Scan_State_Init();
                    break;
                default:
                    break;

            }
            break;

#if ENABLE_DTV
#if DVB_C_ENABLE
        case STATE_TOP_CADTV_MANUAL_TUNING:
            switch(MApp_CADTV_ManualTuning_Main())
            {
                case EXIT_CLOSE:
                    enTopState = STATE_TOP_DIGITALINPUTS;
                    break;

                case EXIT_GOTO_STANDBY:
                    enTopState = STATE_TOP_STANDBY;
                    break;

                case EXIT_GOTO_MENU:
                    enTopState = STATE_TOP_MENU;
                    break;
                //case EXIT_GOTO_CADTV_MANUALTUNING:
                    //printf("\n Isaac  EXIT_GOTO_CADTV_MANUALTUNING \n");
                    //g_CurSignalStrength = 0;
                    //enTopState = STATE_TOP_CADTV_MANUAL_TUNING;
                    //break;
                case EXIT_GOTO_SCAN:
#if ENABLE_T_C_COMBO
                    msAPI_CM_ResetAllProgram();
#endif
                case EXIT_GOTO_CADTV_MANUALTUNING://CADTV manu tuning no need reset CM database
                    enTopState = STATE_TOP_DTV_SCAN;
                    enTopStateBeforeScan = STATE_TOP_CADTV_MANUAL_TUNING;
                    MApp_Scan_State_Init();
                    break;

                default:
                    break;
            }
            break;
#endif
#endif

        case STATE_TOP_INPUTSOURCE:
            switch(MApp_InputSource_Main())
            {
                case EXIT_CLOSE:
                    if(IsAnyTVSourceInUse())
                    {
                        enTopState = STATE_TOP_DIGITALINPUTS;
                    }
                    else
                    {
                        enTopState = STATE_TOP_DIGITALINPUTS;
                    }
                break;

                case EXIT_GOTO_STANDBY:
                    enTopState = STATE_TOP_STANDBY;
                    break;

#if ENABLE_DMP
                case EXIT_GOTO_DMP:
                    enTopState = STATE_TOP_DMP;
                    break;
#endif

#ifdef ENABLE_BT
                case EXIT_GOTO_BT:
                enTopState = STATE_TOP_BT;
                MApp_BT_Main_Exit();
                break;
#endif

#ifdef ENABLE_KTV
                case EXIT_GOTO_KTV:
                enTopState = STATE_TOP_KTV;
                break;
#endif

                case EXIT_GOTO_OSDPAGE:
                    enTopState = STATE_TOP_OSDPAGE;
                    break;

                case EXIT_GOTO_MENU:
                    enTopState = STATE_TOP_MENU;
                    break;

                case EXIT_GOTO_INFO:
                    enTopState = STATE_TOP_ANALOG_SHOW_BANNER;
                    break;

#ifdef ENABLE_YOUTUBE
                case EXIT_GOTO_YOUTUBE:
                    enTopState = STATE_TOP_APENGINE;
                    MApp_APEngine_ClearRetVal();
                    if(MApp_APEngine_CheckAPStatus() && (MApp_APEngine_GetnowBIN() == BIN_ID_CODE_AEON_YOUTUBE))
                    {
                        MApp_APEngine_Resume();
#if (OBA2!=1)
                        MApp_APEngine_RestoreGWIN();
#endif
                    }
                    else
                    {
                        MApp_APEngine_Start();
                        MApp_APEngine_RegisterByID(BIN_ID_CODE_AEON_YOUTUBE, FULL_HANDLE, ((BEON_MEM_MEMORY_TYPE & MIU1) ? (BEON_MEM_ADR | MIU_INTERVAL) : ( BEON_MEM_ADR)), BEON_MEM_LEN);
                        //msAPI_APEngine_AppRunByBinID(BIN_ID_CODE_AEON_YOUTUBE, ((BEON_MEM_MEMORY_TYPE & MIU1) ? (BEON_MEM_ADR | MIU_INTERVAL) : ( BEON_MEM_ADR)), BEON_MEM_LEN);
                    }
                    break;
#endif

#ifdef ENABLE_RSS
                case EXIT_GOTO_RSS:
                    enTopState = STATE_TOP_APENGINE;
                    MApp_APEngine_ClearRetVal();
                    if(MApp_APEngine_CheckAPStatus() && (MApp_APEngine_GetnowBIN() == BIN_ID_CODE_AEON_RSS))
                    {
                        MApp_APEngine_Resume();
#if (OBA2!=1)
                        MApp_APEngine_RestoreGWIN();
#endif
                    }
                    else
                    {
                        MApp_APEngine_Start();
#if (OBA2!=1)
                        MApp_APEngine_RegisterByID(BIN_ID_CODE_AEON_RSS, FULL_HANDLE, ((BEON_MEM_MEMORY_TYPE & MIU1) ? (BEON_MEM_ADR | MIU_INTERVAL) : ( BEON_MEM_ADR)), BEON_MEM_LEN);
#else
                        MApp_APEngine_RegisterByName("RSS");
#endif
                        //msAPI_APEngine_AppRunByBinID(BIN_ID_CODE_AEON_RSS, ((BEON_MEM_MEMORY_TYPE & MIU1) ? (BEON_MEM_ADR | MIU_INTERVAL) : ( BEON_MEM_ADR)), BEON_MEM_LEN);
                    }
                break;
#endif

                #if (ENABLE_GAME)
                case EXIT_GOTO_GAME:
                    {
                        enTopState = STATE_TOP_APGAME;
                    }
                    break;
                #endif

#ifdef ENABLE_EXTENSION
                case EXIT_GOTO_EXTENSION:
                    {
                    }
                break;
#endif

                default:
                    break;
            }
            break;

#if (ENABLE_DTV_EPG)
        case STATE_TOP_EPG:
            switch(MApp_Epg_Main())
            {
                case EXIT_CLOSE:
                    enTopState = STATE_TOP_DIGITALINPUTS;
                    break;

                case EXIT_GOTO_MENU:
                    enTopState = STATE_TOP_MENU;
                    break;

                case EXIT_GOTO_STANDBY:
                    enTopState = STATE_TOP_STANDBY;
                    break;
                default:
                    break;

            }
            break;
#endif  //#if (ENABLE_DTV_EPG)

        case STATE_TOP_OSDPAGE:
          #if 0//NTV_FUNCTION_ENABLE //wait to do
            if(_eChannelListMode == MODE_NETWORK_CHLIST_TV)
            {
                MApp_SI_Disable_Auto_Update(TRUE);
            }
          #endif
            switch (MApp_OSDPage_Main())
            {
                case EXIT_CLOSE:
                    enTopState = STATE_TOP_DIGITALINPUTS;
                    break;

                case EXIT_GOTO_CHANNELCHANGE:
                    enTopState = STATE_TOP_CHANNELCHANGE;
                    break;

                case EXIT_GOTO_MENU:
                    enTopState = STATE_TOP_MENU;
                    break;

            #if (ENABLE_DTV_EPG)
                case EXIT_GOTO_EPG:
                    enTopState = STATE_TOP_EPG;
                    break;
            #endif  //#if (ENABLE_DTV_EPG)

                case EXIT_GOTO_INPUTSOURCE:
                    enTopState = STATE_TOP_INPUTSOURCE;
                    break;

                case EXIT_GOTO_STANDBY:
                    enTopState = STATE_TOP_STANDBY;
                    break;
            #if ENABLE_DMP
                case EXIT_GOTO_DMP:
                    enTopState = STATE_TOP_DMP;
                    break;
            #endif

            #ifdef ENABLE_BT
                case EXIT_GOTO_BT:
                    enTopState = STATE_TOP_BT;
                    MApp_BT_Main_Exit();
                    break;
            #endif

            #ifdef ENABLE_KTV
                case EXIT_GOTO_KTV:
                    enTopState = STATE_TOP_KTV;
                    break;
            #endif
            #if BOE_USB_UPGRADE_FACTROY//minglin1206
			  case EXIT_GOTO_UPDATE:
                    enTopState = STATE_TOP_MENU;
                    MApp_Usb_UpDate_Init();
                    break;
            #endif  
                default:
                    break;
            }
            break;

    #if (ENABLE_USB)
        case STATE_TOP_USB_DOWNLOAD:
            /*
            switch(MApp_USB_Download_Main())
            {
                    case EXIT_USB_DOWNLOAD_TRAN_REBOOT:

                    break;
                    case EXIT_USB_DOWNLOAD_WAIT:
                    break;
                    case EXIT_USB_DOWNLOAD_CANCEL:
                        enTopState = STATE_TOP_DIGITALINPUTS;
                    break;

            }*/
            break;
    #endif

    #if ENABLE_OAD
       case STATE_TOP_OAD:
            switch (MApp_OAD_AppMain())
            {
                case EXIT_CLOSE:
                    enTopState = STATE_TOP_DIGITALINPUTS;
                    break;

                default:
                    break;
            }
        break;
    #endif

        case STATE_TOP_STANDBY:
			//gary add for ac on time
			    stGenSetting.g_FactorySetting.gFactoryTotaltimeback=msAPI_Timer_GetSystemTime();
			printf("gFactoryTotaltimeback==%d\n", stGenSetting.g_FactorySetting.gFactoryTotaltimeback);
        #if DVB_C_ENABLE
            if ((IsDTVInUse()) &&
          #if ENABLE_T_C_COMBO
              IsCATVInUse() &&
          #endif
              (MApp_Scan_DVBC_QuickInstall_GetProcessedFlag()))
            {
                //MUTE_On();
                MApi_PNL_SetBackLight(DISABLE);
                if (IsAnyTVSourceInUse())
                    MApp_ChannelChange_DisableChannel(TRUE, MAIN_WINDOW);
                else
                    msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_PERMANENT_MUTEON, E_AUDIOMUTESOURCE_ACTIVESOURCE);

                MApp_ZUI_ACT_ShutdownOSD();
                MApi_PNL_En(FALSE);

                #if (MS_BOARD_TYPE_SEL == BD_CUS_715G_5740)
                PANEL_3D_ENABLE_OFF();
                #endif

                MW_AUD_SetSoundMute(SOUND_MUTE_SPDIF, E_MUTE_ON);
                if (TRUE == MApp_Scan_DVBC_QuickInstall_ChList())
                {
                    MW_AUD_SetSoundMute(SOUND_MUTE_SPDIF, E_MUTE_OFF);
                    MApi_PNL_En(TRUE);
                    if (IsAnyTVSourceInUse())
                        MApp_ChannelChange_EnableChannel(MAIN_WINDOW);
                    else
                        msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_PERMANENT_MUTEOFF, E_AUDIOMUTESOURCE_ACTIVESOURCE);

                    MApi_PNL_SetBackLight(ENABLE);
                    MUTE_Off();
                    enTopState = STATE_TOP_DIGITALINPUTS;
                    u8KeyCode = KEY_NULL;
                    break;
                }
            }
        #endif // #if DVB_C_ENABLE

        #if (ENABLE_DTV_EPG && DTG_FREEVIEW_STANDBY)
            if(IsDTVInUse())
            {
                if(MApp_FreeView_Standby_Switch())
                {
                    enTopState = STATE_TOP_DIGITALINPUTS;
                    u8KeyCode = KEY_NULL;
                    break;
                }
            }
        #endif

            MApp_Standby_Init();
            break;

    #if ( ENABLE_SUBTITLE&&(SUBTITLE_WITH_OSD == FALSE) )
        case STATE_TOP_SUBTITLE:
            enTopState = STATE_TOP_DIGITALINPUTS;
            switch(MApp_Subtitle_Main())
            {

                case EXIT_SUBTITLE_DECODING:
                    enTopState = STATE_TOP_SUBTITLE;
                    break;

                case EXIT_CLOSE:
                    enTopState = STATE_TOP_DIGITALINPUTS;
                    break;

                default:
                    enTopState = STATE_TOP_DIGITALINPUTS;
                    break;
            }
        #if (MHEG5_ENABLE && MHEG5_WITH_SUBTITLE)
            if (//( bIsBlocked == FALSE || bStopMonitorBlock == TRUE)
                    //&& IsSrcTypeDTV(SYS_INPUT_SOURCE_TYPE(eWindow))
                    //&&
                    (msAPI_MHEG5_checkGoBackMHEG5()== FALSE))
            {
                // TODO...remove this! subtitle should co exist with dsmcc downloading
                MApp_TV_MHEG_Loading_Monitor();
            }
        #endif
            break;
    #endif //#ifdef SUBTITLE

#if ENABLE_CI
        case STATE_TOP_MMI:
            switch(MApp_CIMMI_Main())
            {
                case EXIT_CLOSE:
                    enTopState = STATE_TOP_DIGITALINPUTS;
                    break;
                case EXIT_GOTO_STANDBY:
                    enTopState = STATE_TOP_STANDBY;
                    break;
                default:
                    break;
            }
            break;
#endif

#if ENABLE_DMP
        case STATE_TOP_DMP:
#ifdef ENABLE_SANYO_WB_JPG//from us3b
			if(bSanyoWbJpgDisplayed)
			{
				if(UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_ATV
					|| UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_DTV)
				{
						enTopState = STATE_TOP_DIGITALINPUTS;
				}
				else if(UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_DMP
         #if ENABLE_DMP_SWITCH
					 ||(UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_DMP1)
					 ||(UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_DMP2)
         #endif
					 )
				{
				   // enTopState = STATE_TOP_DMP;
					enTopState = STATE_TOP_DIGITALINPUTS;
				}
				else
				{
					enTopState = STATE_TOP_DIGITALINPUTS;
				}

					 break;
			}
#endif
            switch(MApp_DMP_Main())
            {
                case EXIT_MPLAYER_TRAN_MENU:
                    enTopState = STATE_TOP_MENU;
                    break;

                case EXIT_MPLAYER_TRAN_INPUTSOURCE:
                    enTopState = STATE_TOP_INPUTSOURCE;
                    break;
              #if CUS_SMC_ENABLE_HOTEL_MODE
                case EXIT_MPLAYER_TRAN_HOTEL:
                    enTopState = STATE_TOP_OSDPAGE;
					break;
			  #endif
                case EXIT_MPLAYER_EXIT:
                    if(IsAnyTVSourceInUse())
                    {
                        #if 0
                        #if ENABLE_PVR
						if(IsDTVInUse())
						{
	                        MApp_PVR_SetDiskDriveIndex(msAPI_PVRFS_GetDriveIndex()); //co-buffer issue, need to re-init buffer setting
						}
						#endif
                        #endif
                        enTopState = STATE_TOP_CHANNELCHANGE;
                    }
                    else
                    {
                        enTopState = STATE_TOP_DIGITALINPUTS;
                    }
                    break;

                case EXIT_MPLAYER_TRAN_STANDBY:
                    enTopState = STATE_TOP_STANDBY;
                    break;
                    default:
                        break;

            }
            break;
#endif


#if ENABLE_DMP
#ifdef AP_COWORK
        case STATE_TOP_APENGINE:
            #if 1
            switch( MApp_APEngine_CheckRetVal() )
            {
                case EXIT_GOTO_INPUTSOURCE:
                    enTopState = STATE_TOP_INPUTSOURCE;
                break;

                case EXIT_APENGINE_EXIT:
#if OBA2
                    enTopState = STATE_TOP_DIGITALINPUTS;
#else
                    enTopState = STATE_TOP_INPUTSOURCE;
#endif
                break;

                case EXIT_GOTO_DMP:
                    enTopState = STATE_TOP_DMP;
                    break;

                case EXIT_GOTO_STANDBY:
                    enTopState = STATE_TOP_STANDBY;
                    break;
#if OBA2
                case EXIT_GOTO_MENU:
                    enTopState = STATE_TOP_MENU;
                break;
#endif
                default:
                    break;
            }
            #else
            switch ( MApp_APEngine_Process() )
            {
                case EXIT_APENGINE_EXIT:
                    enTopState = STATE_TOP_INPUTSOURCE;
                    break;
                default:
                    break;
            }
            #endif
            break;
#endif
#endif

#ifdef ENABLE_BT
        case STATE_TOP_BT:
            switch(MApp_BT_Main())
            {
                case EXIT_BT_TRAN_MENU:
                    enTopState = STATE_TOP_MENU;
                    break;
                case EXIT_GOTO_INPUTSOURCE:
                    enTopState = STATE_TOP_INPUTSOURCE;
                    break;
                case EXIT_CLOSE:
                    enTopState = STATE_TOP_DIGITALINPUTS;
                    break;

                case EXIT_GOTO_STANDBY:
                    enTopState = STATE_TOP_STANDBY;
                    break;

                default:
                    break;
            }
            break;
#endif

#ifdef ENABLE_KTV
        case STATE_TOP_KTV:
            switch(MApp_KTV_Main())
            {
                case EXIT_KTV_TRAN_MENU:
                    enTopState = STATE_TOP_MENU;
                    break;
                case EXIT_GOTO_INPUTSOURCE:
                    enTopState = STATE_TOP_INPUTSOURCE;
                    break;
                case EXIT_CLOSE:
                    if(IsAnyTVSourceInUse())
                    {
                        enTopState = STATE_TOP_CHANNELCHANGE;
                    }
                    else
                    {
                        enTopState = STATE_TOP_DIGITALINPUTS;
                    }
                    break;

                case EXIT_GOTO_STANDBY:
                    enTopState = STATE_TOP_STANDBY;
                    break;

                default:
                    break;
            }
            break;
#endif

#if (ENABLE_GAME)
            case STATE_TOP_APGAME:
            {
                extern EN_RET MApp_Game_Browse_Main(void);
                switch((U8)MApp_Game_Browse_Main())
                 {
                     case EXIT_CLOSE:
                        MApp_InputSource_RestoreSource();
                    #if ENABLE_DMP
                   if((UI_INPUT_SOURCE_TYPE==UI_INPUT_SOURCE_DMP)
                 #if( ENABLE_DMP_SWITCH )
                    ||(UI_INPUT_SOURCE_TYPE==UI_INPUT_SOURCE_DMP1)
                    ||(UI_INPUT_SOURCE_TYPE==UI_INPUT_SOURCE_DMP2)
                #endif
                   )
                        {
                            enTopState = STATE_TOP_DMP;
                        }
                        else
                    #endif
                        {
                            enTopState = STATE_TOP_DIGITALINPUTS;
                        }
                        break;

                     case EXIT_GOTO_STANDBY:
                         enTopState = STATE_TOP_STANDBY;
                         break;
                }
            }
            break;
#endif


        default:
            DEBUG_STATE(printf("\nMSerr:%bx ", enTopState));
            enTopState = STATE_TOP_DIGITALINPUTS;
            break;
    }


    #if (CHANNEL_SCAN_AUTO_TEST)
    if ( g_ScanAutoTestData.u2State == 2 )
    {
        DEBUG_STATE(printf("SCAN: Leave!\n"));
        CHSCANTEST_MSG(printf("SCAN: Stop Scan!\n"));
        g_ScanAutoTestData.u2State = 0;
        g_ScanAutoTestData.u12ChNum = 0;
        g_ScanAutoTestData.u16DTVProgNum = msAPI_CM_CountProgram(E_SERVICETYPE_DTV, E_PROGACESS_INCLUDE_VISIBLE_ONLY);
        g_ScanAutoTestData.u16ATVProgNum = msAPI_CM_CountProgram(E_SERVICETYPE_ATV, E_PROGACESS_INCLUDE_VISIBLE_ONLY);
        g_ScanAutoTestData.u16AudioProgNum = msAPI_CM_CountProgram(E_SERVICETYPE_RADIO, E_PROGACESS_INCLUDE_VISIBLE_ONLY);
    }
    #endif


    //2007/11/29: ZUI is a inter-state GUI service,
    //            so we don't have a specified state for it!
    MApp_ZUI_MainTask();

}

EN_TOP_STATE MApp_TopStateMachine_GetTopState(void)
{
    return enTopState;
}

char* MApp_TopStateMachine_GetTopStateName(void)
{
    char* cTopStateName[] =
    {
        "CHANNELCHANGE",
        "DTV_SCAN",
        "ATV_SCAN",

    #if ENABLE_SBTVD_BRAZIL_APP
        "CATV_SCAN",
    #endif

        "DIGITALINPUTS",
        "MENU",
        "INSTALLGUIDE",
        "DTV_MANUAL_TUNING",
        "ATV_MANUAL_TUNING",
        "INPUTSOURCE",
        "STANDBY",
        "TTX",
        "ANALOG_SHOW_BANNER",

    #if (ENABLE_DTV_EPG)
        "EPG",
    #endif

        "OSDPAGE",
        "USB_DOWNLOAD",

    #if ENABLE_OAD
        "OAD",
    #endif

    #if (ENABLE_SUBTITLE)
        "SUBTITLE",
    #endif

    #if ENABLE_CI
        "MMI",
    #endif

        "DMP",

    #if ENABLE_DMP
        "APENGINE",
    #endif

    #ifdef ENABLE_BT
        "BT",
    #endif

    #ifdef ENABLE_KTV
        "KTV",
    #endif

    #if (ENABLE_GAME)
        "APGAME",
    #endif

    #if(ENABLE_PVR ==1)
        "PVR",
    #endif

    #if DVB_C_ENABLE
        "CADTV_MANUAL_TUNING",
    #endif

    #if ((BRAZIL_CC )|| (ATSC_CC == ATV_CC))
        "CLOSEDCAPTION",
    #endif

    #if (ENABLE_UPDATE_MULTIPLEX_VIA_NIT)
        "SCAN_NEW_MUX",
    #endif
    };
    return cTopStateName[enTopState];
}

void MApp_TopStateMachine_SetTopState(EN_TOP_STATE enSetTopState)
{
    enTopState = enSetTopState;
}

#if (CHANNEL_SCAN_AUTO_TEST)
//transfer 2bytes character to be 1byte character
U8* _Mapp_TransToPrintfStr(U8* pdest, U8* psrc)
{
    U8* pu8Str = pdest;
    U8* ptemp = psrc;

    *pu8Str = '\0';
    while(*(++ptemp) != 0)
    {
        *pu8Str++ = *ptemp++;
    }
    *pu8Str = '\0';

    return pdest;
}

U8 _Mapp_MAP2NUMKey(U8 no)
{
    U8 u8rtnKey;

    switch(no)
    {
    case 0:
        u8rtnKey = KEY_0;
        break;
    case 1:
        u8rtnKey = KEY_1;
        break;
    case 2:
        u8rtnKey = KEY_2;
        break;
    case 3:
        u8rtnKey = KEY_3;
        break;
    case 4:
        u8rtnKey = KEY_4;
        break;
    case 5:
        u8rtnKey = KEY_5;
        break;
    case 6:
        u8rtnKey = KEY_6;
        break;
    case 7:
        u8rtnKey = KEY_7;
        break;
    case 8:
        u8rtnKey = KEY_8;
        break;
    case 9:
        u8rtnKey = KEY_9;
        break;
    default:
        u8rtnKey = no;
        break;
    }

    return u8rtnKey;
}

void _MApp_ScanAutoTest(void)
{
    U16 i, k;
    U8  j;
    MS_TP_SETTING stTpSetting;
    U8 u8Data[2] = {0};

    MEMBER_SERVICETYPE bServiceType;
    AUD_INFO stAudioStreamInfo;

    if ((g_ScanAutoTestData.u2State == 0) && (g_ScanAutoTestData.fCommand == 1))
    {
        //printf("====enTopState %d enUiMainMenuState %d\n", enTopState, enUiMainMenuState);
        u16ScanDtvChNum=0;
        u16ScanRadioChNum=0;
        #if NORDIG_FUNC //for Nordig Spec v2.0
        u16ScanDataChNum = 0;
        #endif
        u8ScanPercentageNum=0;
        u8RFCh=0;
        stGenSetting.stScanMenuSetting.u8ScanType = SCAN_TYPE_AUTO;
        enTopState = STATE_TOP_MENU;
        // temply remove
        //enUiMainMenuState = STATE_UIMENU_GOTO_SCAN;
        g_ScanAutoTestData.u2State = 1;
    }

    if(g_u8ScanAutoTestCmd & SCAN_AUTOTEST_CMD_POLL)
    {
        // temply remove
        //CHSCANTEST_MSG(printf("SCAN: %u %bu\n", MApp_UiMenuFunc_GetU16DynamicNumber(EN_DNUM_GetenA1_ScanPerCentNumber), 100));
        g_u8ScanAutoTestCmd &= ~SCAN_AUTOTEST_CMD_POLL;
    }
    else if(g_u8ScanAutoTestCmd & SCAN_AUTOTEST_CMD_DUMP_ONE_CH_INFO)
    {
        i = g_ScanAutoTestData.u12ChNum;
        if(i >= g_ScanAutoTestData.u16DTVProgNum)
        {
            i -= g_ScanAutoTestData.u16DTVProgNum;
            bServiceType = E_SERVICETYPE_RADIO;
        }
        else
            bServiceType = E_SERVICETYPE_DTV;

        j = msAPI_CM_GetPhysicalChannelNumber(bServiceType, i);
        msAPI_DFT_GetTSSetting(j, &stTpSetting);
        for(u8Data[0] = 0; u8Data[0] < MAX_AUD_LANG_NUM ; u8Data[0]++)
        {
            msAPI_CM_GetAudioStreamInfo(bServiceType, i, &stAudioStreamInfo, u8Data[0]);
            if(stAudioStreamInfo.aISOLangInfo[0].bISOLangIndex == SI_LANGUAGE_UNKNOWN)
                break;
        }
        CHSCANTEST_MSG(printf("SCAN: CH %u %bu 0x%04x %bu %lu %bu %bu %bu %bu\n",
                g_ScanAutoTestData.u12ChNum,
                j,
                msAPI_CM_GetLogicalChannelNumber(bServiceType,i),
                0,
                stTpSetting.u32Frequency,
                0,
                stTpSetting.enBandWidth,
                u8Data[0],
                1
                ));
        if(u8Data[0] > 0)
        {
            for(u8Data[1] = 0; u8Data[1] < u8Data[0]; u8Data[1]++)
        {
                msAPI_CM_GetAudioStreamInfo(bServiceType, i, &stAudioStreamInfo, u8Data[1]);
                //if(u8Data[1] == 0) CHSCANTEST_MSG(printf("SCAN: LANG"));
               //     CHSCANTEST_MSG(printf(" %bu", stAudioStreamInfo.ToBeRemoved_u8AudLangCodeIdx));
        }
            if(u8Data[1] > 0) CHSCANTEST_MSG(printf("\n"));
        }

        g_u8ScanAutoTestCmd &= ~SCAN_AUTOTEST_CMD_DUMP_ONE_CH_INFO;

    }
    else if(g_u8ScanAutoTestCmd & SCAN_AUTOTEST_CMD_DUMP_ONE_CH_INFO2)
    {
        #if 0  // temply remove
        BYTE sName[120];
        bServiceType = msAPI_CM_GetCurrentServiceType();
        i = msAPI_CM_GetCurrentPosition(bServiceType);
        MApp_UiMenu_GetServiceNameToUCS2(bServiceType, i, (WORD*)sName, KEEP_CONTROL_CODE_NONE);
        Mapp_Main_TransToPrintfStr(PrnStrBuf, sName);
        u8Data[0] = MApp_Dmx_Check_Descriptor(TAG_SED);
        u8Data[0] = MApp_Dmx_Check_Descriptor(TAG_EED);
#if (ENABLE_TTX && ENABLE_SUBTITLE)
        CHSCANTEST_MSG(printf("SCAN: INFO %u,%bu,%bu,%bu,%bu\n",
                (i + 1),
                (U8)msAPI_TTX_TurnOnTTSource(),
                u8Data[0],
                u8Data[1],
                (u8SubtitleMenuNum > 0)));
#endif
        CHSCANTEST_MSG(printf("SCAN: AU %u,%bu\n", g_SrcInfo.u16H_CapSize, 0/*msAPI_AUD_GetCurrentSoundMode()*/));
        u8Data[0] = msAPI_CM_GetProgramAttribute(bServiceType, i, E_ATTRIBUTE_IS_SCRAMBLED);
        CHSCANTEST_MSG(printf("SCAN: NA %s,%bu\n", PrnStrBuf, u8Data[0]));
        Mapp_Main_TransToPrintfStr(PrnStrBuf, MApp_UiMenu_String(INFO_EVENTTITLETEXT));
        CHSCANTEST_MSG(printf("SCAN: EN %s\n", PrnStrBuf));
        #endif
        g_u8ScanAutoTestCmd &= ~SCAN_AUTOTEST_CMD_DUMP_ONE_CH_INFO2;
    }
    else if(g_u8ScanAutoTestCmd & SCAN_AUTOTEST_CMD_PLUSCHANGE_ONE_CH)
    {
        if(u8KeyCode == KEY_NULL)
        {
            //CHSCANTEST_MSG(printf("SCAN: CH change\n"));
            u8KeyCode = KEY_CHANNEL_PLUS;
            MApp_TV_ProcessUserInput();
            g_u8ScanAutoTestCmd &= ~SCAN_AUTOTEST_CMD_PLUSCHANGE_ONE_CH;
        }
    }
    else if(g_u8ScanAutoTestCmd & SCAN_AUTOTEST_CMD_SETKEY)
    {
        if(u8KeyCode == KEY_NULL)
        {
            u8KeyCode = _Mapp_MAP2NUMKey(g_u8ScanAutoTestKey);
            MApp_TV_ProcessUserInput();
            g_u8ScanAutoTestCmd &= ~SCAN_AUTOTEST_CMD_SETKEY;
        }
    }

    if(g_u8ScanAutoTestCmd & SCAN_AUTOTEST_CMD_CHK_MAINSTATE)
    {
        switch(g_u8TopStateChkCase)
        {
            case 0: //STATE_TOP_CHANNELCHANGE
                u8Data[0] = (enTopState == STATE_TOP_CHANNELCHANGE);
                break;
            case 1: //STATE_TOP_SCAN
                u8Data[0] = ((enTopState == STATE_TOP_DTV_SCAN) || (enTopState == STATE_TOP_DTV_SCAN)
                               /* || (enUiMainMenuState == STATE_UIMENU_GOTO_SCAN)*/);  // temply remove
                break;
            default:
                break;

        }
        if(u8Data[0])
            //CHSCANTEST_MSG(printf("SCAN: Check Ready %bu %bu %bu\n", u8Data[0], enTopState, enUiMainMenuState));
            CHSCANTEST_MSG(printf("SCAN: Check Ready %bu %bu\n", u8Data[0], enTopState));
        else
            //CHSCANTEST_MSG(printf("SCAN: Check Error %bu %bu %bu\n", u8Data[0], enTopState, enUiMainMenuState));
            CHSCANTEST_MSG(printf("SCAN: Check Error %bu %bu\n", u8Data[0], enTopState));

        g_u8ScanAutoTestCmd &= ~SCAN_AUTOTEST_CMD_CHK_MAINSTATE;
    }
    else if(g_u8ScanAutoTestCmd & SCAN_AUTOTEST_CMD_DUMP_MAINSTATE)
    {
        //CHSCANTEST_MSG(printf("SCAN: enTopState %bu,%bu\n", enTopState, enUiMainMenuState));
        CHSCANTEST_MSG(printf("SCAN: enTopState %bu\n", enTopState));
        g_u8ScanAutoTestCmd &= ~SCAN_AUTOTEST_CMD_DUMP_MAINSTATE;
    }

    if(g_u8AUDbgCmd & AUDIO_DEBUG_CMD_RWREG)
    {
        i = 0x2d00 + g_ScanAutoTestAU.u8RegStartAddr;
        j = g_ScanAutoTestAU.u8WriteData;
        k = g_ScanAutoTestAU.u8ReadBytes;
        if(g_ScanAutoTestAU.u8ReadBytes == 0)
            MDrv_AUDIO_DecWriteByte(i, j);                      // if have any problem, please contact with AudioTeam Cathy
        j = MDrv_AUDIO_DecReadByte(i);    //read for checking   //if have any problem, please contact with AudioTeam Cathy
        CHSCANTEST_MSG(printf("Audio: Set BK9 0x%04x 0x%02bx\n",i, j));
        if(k > 0)
            CHSCANTEST_MSG(printf("Audio: Data 0x"));
        while(k > 0)
        {
            j = MDrv_AUDIO_DecReadByte(i);                      //if have any problem, please contact with AudioTeam Cathy
            CHSCANTEST_MSG(printf("%02bx", j));
            i += 2;
            k--;
        }
        CHSCANTEST_MSG(printf("\n\n"));
        g_u8AUDbgCmd &= ~AUDIO_DEBUG_CMD_RWREG;
    }
}
#endif


#undef MAPP_TOPSTATEMACHINE_C

