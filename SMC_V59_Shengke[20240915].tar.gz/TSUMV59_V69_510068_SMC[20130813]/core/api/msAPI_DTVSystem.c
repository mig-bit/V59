////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (MStar Confidential Information!�L) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//
/// @file msAPI_DTVSystem.h
/// This file includes MStar DTV system application interface
/// @brief API for DTV control
/// @author MStar Semiconductor, Inc.
//
////////////////////////////////////////////////////////////////////////////////

#define API_DTVSYSTEM_C


#include <stddef.h>
#include <string.h>
#include "sysinfo.h"
#include "debug.h"
#include "msAPI_Memory.h"
#include "msAPI_DTVSystem.h"
#include "msAPI_Ram.h"
#include "msAPI_MIU.h" // for EEPROM_SAVE_NONE
#include "msAPI_Flash.h"
#include "MApp_SaveData.h"
#include "apiXC_Sys.h"
#include "apiXC_Cus.h"
#if ( WATCH_DOG == ENABLE )
#include "msAPI_Timer.h"
#endif

#if (DVB_C_ENABLE)
#include "MApp_CADTV_Proc.h"
#endif

#if (!ENABLE_DTV)
#if (EEPROM_DB_STORAGE!=EEPROM_SAVE_ALL)
static BOOLEAN _bSaveDataToFlash=TRUE;
#endif
#define START_ADDRESS_OF_DTVDATA_STRUCTURE      RM_DTV_CHSET_START_ADDR
#define BASEADDRESS_PR_DATA                         ( START_ADDRESS_OF_DTVDATA_STRUCTURE )
#define BASEADDRESS_PR_SERIALNO                     ( BASEADDRESS_PR_DATA + (offsetof(DTV_CHANNEL_DATA_STRUCTURE, bSerialNum)) )
#define BASEADDRESS_PR_IDENT                        ( BASEADDRESS_PR_DATA + (offsetof(DTV_CHANNEL_DATA_STRUCTURE, wID)) )
#define BASEADDRESS_COUNTRY                         ( BASEADDRESS_PR_DATA + (offsetof(DTV_CHANNEL_DATA_STRUCTURE, eCountry)) )
#define END_ADDRESS_OF_DTVDATA_STRUCTURE            ( START_ADDRESS_OF_DTVDATA_STRUCTURE + (sizeof(DTV_CHANNEL_DATA_STRUCTURE)))
#ifdef AUSTRALIA
#define DEFAULT_COUNTRY                         E_AUSTRALIA
#elif  ENABLE_SBTVD_BRAZIL_APP
#define DEFAULT_COUNTRY                         E_BRAZIL
#elif (ENABLE_DTMB_CHINA_APP || ENABLE_ATV_CHINA_APP || ENABLE_DVBC_PLUS_DTMB_CHINA_APP)
#define DEFAULT_COUNTRY                         E_CHINA
#elif ( ENABLE_DVB_TAIWAN_APP )
#define DEFAULT_COUNTRY                         E_TAIWAN
#else
#define DEFAULT_COUNTRY                         E_UK
#endif


#else

#include "MsOS.h"

#if ENABLE_AUTOTEST
extern BOOLEAN g_bAutobuildDebug;
#endif

#if ENABLE_DVB_T2
MS_U8 u8PlpIDList[32];
#endif

#if 0
#define DEBUG_PRINT printf("~~ F: %s, L:%d \n", __FUNCTION__, __LINE__);
#else
#define DEBUG_PRINT
#endif

//------------------------------------------------------------------------------
// Local defines
//------------------------------------------------------------------------------

typedef enum
{
    EXCLUDE_NOT_VISIBLE_AND_DELETED,
    INCLUDE_NOT_VISIBLE_EXCLUDE_DELETED,
    INCLUDE_ALL,
    MAX_COUNT_PROGRAM_OPTION
} COUNT_PROGRAM_OPTION;


typedef BYTE E_LCN_ASSIGNMENT_TYPE;
//--------------------------------
#define E_LCN_INVALID                   0x00
#define E_LCN_ABSENT                    0x01
#define E_LCN_PRESENT                   0x02
#define E_LCN_DUPLICATE                 0x04
#define E_LCN_SAME_SERVICE              0x08
#define E_LCN_LAST          0x10//RiksTV spec , ONID 0x2242 LCN 900~999 shall be end of list for hearing and visually impaired people
#define E_LCN_ZERO          0x20
//#define E_LCN_NOT_NATIVE_ON_ID          0x10
#if ENABLE_DTV_STORE_TTX_PAGE_INFO// ENABLE_TTX
#define DEFAULT_LISTPAGE                            m_wDefaultListPageNumber
static ROM WORD m_wDefaultListPageNumber[MAX_LISTPAGE] =
{
    100,
    200,
    300,
    400
};
#endif

typedef struct
{
    WORD bServiceType                   : 3;
    WORD bServiceTypePrio               : 2;
    WORD bIsReplaceDel                  : 1;
    WORD bInvalidCell                   : 1;
    WORD bUnconfirmedService            : 1;
    #if ENABLE_T_C_CHANNEL_MIX
    WORD bIsTerrestrial                 : 1;
    #else
    WORD reserved1                      : 1;
    #endif
    WORD bInvalidService            : 1;
    #if (CM_MULTI_FAVORITE)
    WORD bIsFavorite                    : 4;
    #else
    WORD bIsFavorite                    : 1;
    WORD reserved2                      : 3;
    #endif
    WORD bIsSpecialService              : 1;
    //WORD bIsMHEGIncluded                : 1;
    WORD bReplaceService                : 1;


    WORD bVisibleServiceFlag            : 1;
    WORD bNumericSelectionFlag          : 1;
    WORD bIsDelete                      : 1;
    WORD bIsSkipped                     : 1;
    WORD bIsLock                        : 1;
    WORD eLCNAssignmentType             : 6;
    WORD bIsMove                        : 1;
    WORD bIsScramble                    : 1;
    WORD bIsServiceIdOnly               : 1;
    WORD eVideoType                     : 2;

    DWORD wPRIndex                      : 13;
    DWORD cIDIndex                      : 7;
    DWORD bIsStillPicture               : 1;
    DWORD wSimu_LCN                     : 11;

    union
    {
        #if ENABLE_SBTVD_BRAZIL_APP
        ST_LCN stLCN;
        #endif
        WORD wLCN;
    };


    WORD wService_ID;

} DTVPROGRAMINDEX;

#define DTVPROGRAMINDEX_LEN     sizeof(DTVPROGRAMINDEX)

//---PROGRAM MAP---
#define BASEADDRESS_PR_DATA                         ( START_ADDRESS_OF_DTVDATA_STRUCTURE )
#define BASEADDRESS_PR_SERIALNO                     ( BASEADDRESS_PR_DATA + (offsetof(DTV_CHANNEL_DATA_STRUCTURE, bSerialNum)) )
#define BASEADDRESS_PR_IDENT                        ( BASEADDRESS_PR_DATA + (offsetof(DTV_CHANNEL_DATA_STRUCTURE, wID)) )
#define BASEADDRESS_COUNTRY                         ( BASEADDRESS_PR_DATA + (offsetof(DTV_CHANNEL_DATA_STRUCTURE, eCountry)) )
#define BASEADDRESS_PR_IS_LCN_ARRANGED              ( BASEADDRESS_PR_DATA + (offsetof(DTV_CHANNEL_DATA_STRUCTURE, bIsLogicalChannelNumberArranged)) )
#if (EEPROM_DB_STORAGE == EEPROM_SAVE_NONE)
#define BASEADDRESS_PR_CURRENTORDER_TV              ( BASEADDRESS_PR_DATA + (offsetof(DTV_CHANNEL_DATA_STRUCTURE, wCurOrderOfTV)) )
#define BASEADDRESS_PR_CURRENTORDER_RADIO           ( BASEADDRESS_PR_DATA + (offsetof(DTV_CHANNEL_DATA_STRUCTURE, wCurOrderOfRadio)) )
#define BASEADDRESS_PR_CURRENTORDER_DATA            ( BASEADDRESS_PR_DATA + (offsetof(DTV_CHANNEL_DATA_STRUCTURE, wCurOrderOfData)) )
#define BASEADDRESS_PR_CURRENT_SERVICETYPE          ( BASEADDRESS_PR_DATA + (offsetof(DTV_CHANNEL_DATA_STRUCTURE, eDTVCurrentServiceType)) )
#endif
#if (NTV_FUNCTION_ENABLE)
#define BASEADDRESS_PR_FAVORITE_REGION              ( BASEADDRESS_PR_DATA + (offsetof(DTV_CHANNEL_DATA_STRUCTURE, bFavorite_Region)) )
#endif
#define BASEADDRESS_PR_DTVPRTABLEMAP                ( BASEADDRESS_PR_DATA + (offsetof(DTV_CHANNEL_DATA_STRUCTURE, bDTVChannelTableMap)) )
#define BASEADDRESS_PR_DTVPRTABLE                   ( BASEADDRESS_PR_DATA + (offsetof(DTV_CHANNEL_DATA_STRUCTURE, astDTVChannelTable)) )
#define BASEADDRESS_PR_DTVIDTABLEMAP                ( BASEADDRESS_PR_DATA + (offsetof(DTV_CHANNEL_DATA_STRUCTURE, bDTVIDtableMap)) )
#define BASEADDRESS_PR_DTVIDTABLE                   ( BASEADDRESS_PR_DATA + (offsetof(DTV_CHANNEL_DATA_STRUCTURE, astDtvIDTable)) )
#define BASEADDRESS_PR_DTVNETWORK                   ( BASEADDRESS_PR_DATA + (offsetof(DTV_CHANNEL_DATA_STRUCTURE, astDtvNetwork)) )
#define BASEADDRESS_PR_UNSUPPORT_LANGCODE_COUNT     ( BASEADDRESS_PR_DATA + (offsetof(DTV_CHANNEL_DATA_STRUCTURE, bUnsupportedLangCode_Count)) )
#define BASEADDRESS_PR_NSUPPORT_LANGCODE            ( BASEADDRESS_PR_DATA + (offsetof(DTV_CHANNEL_DATA_STRUCTURE, abUnsupportedLangCode)) )

#if DVB_T_C_DIFF_DB
#define BASEADDRESS_PR_DTV_C_PRTABLEMAP             ( BASEADDRESS_PR_DATA + (offsetof(DTV_CHANNEL_DATA_STRUCTURE, bDTV_C_ChannelTableMap)) )
#define BASEADDRESS_PR_DTV_C_PRTABLE                ( BASEADDRESS_PR_DATA + (offsetof(DTV_CHANNEL_DATA_STRUCTURE, astDTV_C_ChannelTable)) )
#define BASEADDRESS_PR_DTV_C_IDTABLEMAP             ( BASEADDRESS_PR_DATA + (offsetof(DTV_CHANNEL_DATA_STRUCTURE, bDTV_C_IDtableMap)) )
#define BASEADDRESS_PR_DTV_C_IDTABLE                ( BASEADDRESS_PR_DATA + (offsetof(DTV_CHANNEL_DATA_STRUCTURE, astDtv_C_IDTable)) )
#define BASEADDRESS_PR_DTV_C_DTVNETWORK             ( BASEADDRESS_PR_DATA + (offsetof(DTV_CHANNEL_DATA_STRUCTURE, astDtv_C_Network)) )
#endif

#define END_ADDRESS_OF_DTVDATA_STRUCTURE            ( START_ADDRESS_OF_DTVDATA_STRUCTURE + (sizeof(DTV_CHANNEL_DATA_STRUCTURE)))


#define MAX_LCN 9999


#define RIKSTV_HEARING_AND_VISUALLY_IMPAIRED_LCN_START  900
#define RIKSTV_HEARING_AND_VISUALLY_IMPAIRED_LCN_END  999
#define ITALY_PREFER_LCN_OVERFLOW_START 75
#define ITALY_PREFER_LCN_OVERFLOW_END 99
#define ITALY_MAIN_LCN_OVERFLOW_START 850
#define ITALY_MAIN_LCN_OVERFLOW_END MAX_LCN//9999

#define ITALY_PREFER_LCN_START 1
#define ITALY_PREFER_LCN_END 99
#define ITALY_ASSIGN_LCN_START 100
#define ITALY_ASSIGN_LCN_END 999

#define ITALY_NETWORK_START 0x3001
#define ITALY_NETWORK_END 0x3100




static DTVPROGRAMINDEX _m_astDTVProgramIndexTable[MAX_DTVPROGRAM];
#define m_astDTVProgramIndexTable _m_astDTVProgramIndexTable

static BYTE m_acDTVProgramTableMap[MAX_DTVCHANNELTABLE_MAP];
static BYTE m_acDTVIDtableMap[MAX_DTVIDTABLE_MAP];

#if DVB_T_C_DIFF_DB
static BYTE m_acDTV_C_ProgramTableMap[MAX_DTVCHANNELTABLE_MAP];
static BYTE m_acDTV_C_IDtableMap[MAX_DTVIDTABLE_MAP];
#endif

static WORD m_wCurrentOrderOfTV;
static WORD m_wPastOrderOfTV;
static WORD m_wCurrentOrderOfRadio;
static WORD m_wPastOrderOfRadio;
static WORD m_wCurrentOrderOfData;
static WORD m_wPastOrderOfData;
static MEMBER_SERVICETYPE        m_eCurrentServiceType;

#if DVB_T_C_DIFF_DB
static WORD m_awDVBCProgramCount[3][MAX_COUNT_PROGRAM_OPTION];
static DTVPROGRAMID_M _astDTVCProgramIDTable[MAX_MUX_NUMBER];
#endif
static WORD m_awProgramCount[3][MAX_COUNT_PROGRAM_OPTION];
static MEMBER_COUNTRY m_eCountry;
static WORD _wCurTS_ID;
static BOOLEAN _bOnlyUpdateCurTS=FALSE;
static DTVPROGRAMID_M _astDTVProgramIDTable[MAX_MUX_NUMBER];
static DTVNETWORK _astDTVNetwork[MAX_NETWOEK_NUMBER];
static U8 _au8CurNetworkName[MAX_NETWORK_NAME];
static U8 _au8CurNetworkLen;
static U16 _u16ValidAudioIndex=0xFFFF;
static BOOLEAN _bSaveDataToFlash=TRUE;
static U8 u8CM_LibVer[32] = {CM_VER()};
#if (NTV_FUNCTION_ENABLE)
static BYTE _cFavoriteNetwork = INVALID_NETWORKINDEX;
#endif
static DTV_SIMPLE_SERVICE_INFO* _pDuplicateServiceList=NULL;

//------------------------------------------------------------------------------
// Private functions.
//------------------------------------------------------------------------------
static BOOLEAN IsServiceTypeValid(MEMBER_SERVICETYPE bServiceType);
static BOOLEAN IsPositionValid(MEMBER_SERVICETYPE bServiceType, WORD wPosition);
static BOOLEAN IsLogicalChannelNumberValid(WORD wLCN);
static BOOLEAN IsPhysicalChannelNumberValid(WORD cRFChannelNumber);
static BOOLEAN IsVersionValid(BYTE cVersion);
static BOOLEAN IsTS_IDValid(WORD wTransportStream_ID);
static BOOLEAN IsON_IDValid(WORD wOriginalNetwork_ID);
static BOOLEAN IsService_IDValid(WORD Service_ID);
static BOOLEAN IsPMT_PIDValid(WORD wPMT_PID);
static BOOLEAN IsPCR_PIDValid(WORD wPCR_PID);
static BOOLEAN IsVideoPIDValid(WORD wVideo_PID);
static BOOLEAN IsAudioStreamInfoValid(AUD_INFO * pastAudioStreamInfo);
static BOOLEAN IsAudioPIDValid(WORD wAudPID);
//static BOOLEAN IsAudioStreamModeValid(AUDIOSTREAM_TYPE wAudType);
//static BOOLEAN _IsAudioLangCodeValid(AUDIO_LANG_CODE eAudioLangCode);

static BOOLEAN IsLogicalChannelNumberArranged(void);
static void LogicalChannelNumberIsArranged(BOOLEAN bIsArranged);

static WORD ConvertPositionToOrder(MEMBER_SERVICETYPE bServiceType, WORD wPosition);
static WORD ConvertOrderToPosition(WORD wOrder);

static BOOLEAN CreatDTVProgramIndexTableAndProgramIDTable(void);
static BOOLEAN IsLinkOfOrderValid(void);
static BOOLEAN FillDTVProgramIndexTableWithOrder(void);
static BOOLEAN FillDTVProgramIndexTableWithoutOrder(void);
//static BOOLEAN FillDTVProgramIDTable(MEMBER_SERVICETYPE bServiceType);
//static BYTE AddProgramIDTable(WORD wTransportStream_ID, WORD wOriginalNetwork_ID, BYTE cRFChannelNumber);
static BOOLEAN UpdateOrderOfProgramTable(MEMBER_SERVICETYPE bServiceType);
#if ENABLE_SBTVD_BRAZIL_CM_APP
static BOOLEAN SortProgram_Brazil(MEMBER_SERVICETYPE bServiceType);
#endif
static BOOLEAN SortProgram(MEMBER_SERVICETYPE bServiceType);
#if (NTV_FUNCTION_ENABLE)
static BOOLEAN SortProgramByRegionPriority(MEMBER_SERVICETYPE bServiceType);
static void msAPI_CM_FillMove_AttributeWithDefault(MEMBER_SERVICETYPE bServiceType);
static WORD msAPI_CM_GetFirstSpecialProgramPosition(MEMBER_SERVICETYPE bServiceType, BOOLEAN bIncludeSkipped);
static WORD msAPI_CM_GetLastSpecialProgramPosition(MEMBER_SERVICETYPE bServiceType, BOOLEAN bIncludeSkipped);
#endif

#if (PRG_EDIT_INPUT_LCN_MOVE == 1)
#if 0
static FUNCTION_RESULT ChangeLCN(MEMBER_SERVICETYPE bServiceType, WORD wPosition, WORD wLCN);
#else
static FUNCTION_RESULT SwapLCN(MEMBER_SERVICETYPE bServiceType, WORD wPosition, WORD wLCN);
#endif
#endif
static BOOLEAN MoveProgram(WORD wFromOrder, WORD wToOrder);
static BOOLEAN SwapProgram(WORD wFromOrder, WORD wToOrder);
static BOOLEAN GetProgramTable(DWORD wPRIndex, BYTE * pcBuffer, PROGRAMDATA_MEMBER eMember);
static BOOLEAN SetProgramTable(DWORD wPRIndex, BYTE * pcBuffer, PROGRAMDATA_MEMBER eMember);
static BOOLEAN GetIDTable(BYTE bIDIndex, BYTE * pcBuffer,PROGRAMDATA_MEMBER eMember);
static BOOLEAN SetIDTable(BYTE bIDIndex, BYTE * pcBuffer,PROGRAMDATA_MEMBER eMember);
static WORD GetEmptyIndexOfProgramTable(void);
static BOOLEAN IsProgramEntityActive(WORD wPRIndex);
static BOOLEAN ActiveProgramEntity(WORD wPRIndex, BOOLEAN bActive);
static BOOLEAN FillAudioStreamInfoWithDefault(AUD_INFO *pstAudioStreamInfo);
static BOOLEAN FillProgramIDWithDefault(DTVPROGRAMID_M * pstDTVProgramID);
static BOOLEAN FillNetworkWithDefault(DTVNETWORK * pstDTVNetwork);
static BOOLEAN FillProgramIndexWithDefault(DTVPROGRAMINDEX * pstDTVProgramIndex);
static BOOLEAN FillProgramDataWithDefault(BYTE * pcBuffer, PROGRAMDATA_MEMBER eMember);
static BOOLEAN AreOrdersSameService(WORD wOrderOfChamp, WORD wOrderOfChallenger, BOOLEAN bCheckTSID);
static void DistinguishLCNSameService(MEMBER_SERVICETYPE bServiceType);
static BYTE GetCountOfSameServiceWithIDs(MEMBER_SERVICETYPE bServiceType, WORD wTransportStream_ID, WORD wOriginalNetwork_ID, WORD wService_ID, BOOLEAN bCheckTsID);
static WORD GetOrderOfSameServiceWithIDs(MEMBER_SERVICETYPE bServiceType, WORD wTransportStream_ID, WORD wOriginalNetwork_ID, WORD wService_ID, BYTE cOrdinal, BOOLEAN bCheckTsID);
static WORD GetOrderOfSameServiceWithPCN(BYTE cRFChannelNumber, WORD wService_ID);
static WORD GetProgramCount(MEMBER_SERVICETYPE bServiceType, COUNT_PROGRAM_OPTION eCountOption);
static void UpdateProgramCount(MEMBER_SERVICETYPE bServiceType);
static WORD CountProgram(MEMBER_SERVICETYPE bServiceType, COUNT_PROGRAM_OPTION eCountOption);

static BOOLEAN SaveCurrentServiceType(MEMBER_SERVICETYPE bServiceType);
static MEMBER_SERVICETYPE LoadCurrentServiceType(void);
static BOOLEAN SaveCurrentOrderOfTV(WORD wOrder);
static WORD LoadCurrentOrderOfTV(void);
static BOOLEAN SaveCurrentOrderOfRadio(WORD wOrder);
static WORD LoadCurrentOrderOfRadio(void);
static BOOLEAN SaveCurrentOrderOfData(WORD wOrder);
static WORD LoadCurrentOrderOfData(void);
#if ENABLE_DTV_STORE_TTX_PAGE_INFO
static WORD GetListPageNumber(BYTE *pu8Buffer, BYTE u8ListIndex);
static void SetListPageNumber(BYTE *pu8Buffer, BYTE u8ListIndex, WORD u16ListPageNumber);
#endif
static BOOLEAN GetNVRAM(DWORD wAddress, BYTE * pcBuffer, BYTE cSize);
static BOOLEAN SetNVRAM(DWORD wAddress, BYTE * pcBuffer, BYTE cSize);

static S8 SelectBestMux(CHANNEL_ATTRIBUTE *Misc1, WORD wNID_1, CHANNEL_ATTRIBUTE *Misc2, WORD wNID_2);
static void RemoveSameService(MEMBER_SERVICETYPE bServiceType);//for Nordig Spec
static BOOLEAN IsIDEntityActive(BYTE bIDIndex);
static BOOLEAN ActiveIDEntity(BYTE bIDIndex, BOOLEAN bActive);
static void ResetIDtable(void);
//static void RemoveInactiveID(void);
static void UpdateIDInfo(void);
static E_CM_SERVICE_POS ConvertServiceTypeToPosition(MEMBER_SERVICETYPE eSERVICETYPE);
static void DistinguishSDLCNAndHDSimuLCNDuplicate(MEMBER_SERVICETYPE bServiceType, WORD wNativeON_ID);
static void _RestInvalidMUXAndNetwork(void);
#if DVB_C_ENABLE
static BOOLEAN IsFreqInsideOffsetRange(U32 u32SrcFreq, U32 u32CompFreq);
#endif
static void _FillNextValidOrderToProgramData(DTV_CHANNEL_INFO *pDTVProgramData, WORD wPRIndex);


static void (*_pfNotify_CM_SwapProgram)(WORD wFromOrder, WORD wToOrder)=NULL;
static void (*_pfNotify_CM_MoveProgram)(U16 u16FromIndex, U16 u16ToIndex)=NULL;
static void (*_pfNotify_SrvPriorityHandler) (U16 u16MainlistIdx)=NULL;
static void (*_pfNotify_CM_RemoveProgram) (WORD wSrvOrder)=NULL;
static void (*_pfNotify_CM_ResetAllProgram) (void)=NULL;

static void DistinguishSameService(MEMBER_SERVICETYPE bServiceType);
BOOLEAN _msAPI_CM_GetCurrentNetworkName(U8 *bNetworkName, U8 *u8NetworkLen);
static BOOLEAN RemoveProgram(MEMBER_SERVICETYPE bServiceType, WORD wPosition);
static BOOLEAN _RemoveService(U8  cIDIndex, WORD wService_ID);

#define DBGMSG(x) // x
static WORD _wCurTSID=INVALID_TS_ID;


//------------------------------------------------------------------------------
///  Initialize Parameter
/// @return  :
//------------------------------------------------------------------------------
void msAPI_CM_Init(DTV_CM_INIT_PARAMETER* psNotify)
{
    _pfNotify_CM_SwapProgram = psNotify->pfNotify_CM_SwapProgram;
    _pfNotify_CM_MoveProgram = psNotify->pfNotify_CM_MoveProgram;
    _pfNotify_SrvPriorityHandler = psNotify->pfNotify_SrvPriorityHandler;
    _pfNotify_CM_RemoveProgram = psNotify->pfNotify_CM_RemoveProgram;
    _pfNotify_CM_ResetAllProgram = psNotify->pfNotify_CM_ResetAllProgram;
    //printf("CM init\n");
}





//****************************************************************************
///  Reset all program
/// @return BOOLEAN : Function execution result
//****************************************************************************
BOOLEAN msAPI_CM_ResetAllProgram(void)
{
    WORD i;

    for (i=0; i < (MAX_DTVCHANNELTABLE_MAP); i++)
    {
        m_acDTVProgramTableMap[i] = 0x00;
    }

    #if DVB_T_C_DIFF_DB
        if (IsCATVInUse())
            SetNVRAM(BASEADDRESS_PR_DTV_C_PRTABLEMAP, m_acDTV_C_ProgramTableMap, sizeof(m_acDTV_C_ProgramTableMap));
        else
    #endif
    SetNVRAM(BASEADDRESS_PR_DTVPRTABLEMAP, m_acDTVProgramTableMap, sizeof(m_acDTVProgramTableMap));

    LogicalChannelNumberIsArranged(FALSE);

    for (i=0; i < MAX_DTVPROGRAM; i++)
    {
        m_astDTVProgramIndexTable[i].bServiceType = E_SERVICETYPE_INVALID;
        m_astDTVProgramIndexTable[i].bServiceTypePrio = E_SERVICETYPE_PRIORITY_NONE;
        m_astDTVProgramIndexTable[i].wPRIndex = INVALID_PRINDEX;
    }

    ResetIDtable();
#if (NTV_FUNCTION_ENABLE)
    msAPI_CM_Set_FavoriteNetwork(INVALID_NETWORKINDEX);
#endif
    m_eCurrentServiceType = DEFAULT_CURRENT_SERVICETYPE;
    m_wCurrentOrderOfTV = DEFAULT_CURRENT_ORDER_TV;
    SaveCurrentOrderOfTV(m_wCurrentOrderOfTV);
    m_wPastOrderOfTV = m_wCurrentOrderOfTV;

    m_wCurrentOrderOfRadio = DEFAULT_CURRENT_ORDER_RADIO;
    SaveCurrentOrderOfRadio(m_wCurrentOrderOfRadio);
    m_wPastOrderOfRadio = m_wCurrentOrderOfRadio;
    m_wCurrentOrderOfData = DEFAULT_CURRENT_ORDER_DATA;
    SaveCurrentOrderOfData(m_wCurrentOrderOfData);
    m_wPastOrderOfData = m_wCurrentOrderOfData;

    #if DVB_T_C_DIFF_DB
    if (IsCATVInUse())
    {   //printf("\n~~~ ResetAllProgram CATV...\n");
        m_awDVBCProgramCount[E_CM_SERVICE_POS_DTV][EXCLUDE_NOT_VISIBLE_AND_DELETED] = 0;
        m_awDVBCProgramCount[E_CM_SERVICE_POS_DTV][INCLUDE_NOT_VISIBLE_EXCLUDE_DELETED] = 0;
        m_awDVBCProgramCount[E_CM_SERVICE_POS_DTV][INCLUDE_ALL] = 0;

        m_awDVBCProgramCount[E_CM_SERVICE_POS_RADIO][EXCLUDE_NOT_VISIBLE_AND_DELETED] = 0;
        m_awDVBCProgramCount[E_CM_SERVICE_POS_RADIO][INCLUDE_NOT_VISIBLE_EXCLUDE_DELETED] = 0;
        m_awDVBCProgramCount[E_CM_SERVICE_POS_RADIO][INCLUDE_ALL] = 0;

        m_awDVBCProgramCount[E_CM_SERVICE_POS_DATA][EXCLUDE_NOT_VISIBLE_AND_DELETED] = 0;
        m_awDVBCProgramCount[E_CM_SERVICE_POS_DATA][INCLUDE_NOT_VISIBLE_EXCLUDE_DELETED] = 0;
        m_awDVBCProgramCount[E_CM_SERVICE_POS_DATA][INCLUDE_ALL] = 0;
    }
    else
    {   //printf("\n~~~ ResetAllProgram DTV...\n");
        m_awProgramCount[E_CM_SERVICE_POS_DTV][EXCLUDE_NOT_VISIBLE_AND_DELETED] = 0;
        m_awProgramCount[E_CM_SERVICE_POS_DTV][INCLUDE_NOT_VISIBLE_EXCLUDE_DELETED] = 0;
        m_awProgramCount[E_CM_SERVICE_POS_DTV][INCLUDE_ALL] = 0;

        m_awProgramCount[E_CM_SERVICE_POS_RADIO][EXCLUDE_NOT_VISIBLE_AND_DELETED] = 0;
        m_awProgramCount[E_CM_SERVICE_POS_RADIO][INCLUDE_NOT_VISIBLE_EXCLUDE_DELETED] = 0;
        m_awProgramCount[E_CM_SERVICE_POS_RADIO][INCLUDE_ALL] = 0;

        m_awProgramCount[E_CM_SERVICE_POS_DATA][EXCLUDE_NOT_VISIBLE_AND_DELETED] = 0;
        m_awProgramCount[E_CM_SERVICE_POS_DATA][INCLUDE_NOT_VISIBLE_EXCLUDE_DELETED] = 0;
        m_awProgramCount[E_CM_SERVICE_POS_DATA][INCLUDE_ALL] = 0;
    }
    #else
    m_awProgramCount[E_CM_SERVICE_POS_DTV][EXCLUDE_NOT_VISIBLE_AND_DELETED] = 0;
    m_awProgramCount[E_CM_SERVICE_POS_DTV][INCLUDE_NOT_VISIBLE_EXCLUDE_DELETED] = 0;
    m_awProgramCount[E_CM_SERVICE_POS_DTV][INCLUDE_ALL] = 0;

    m_awProgramCount[E_CM_SERVICE_POS_RADIO][EXCLUDE_NOT_VISIBLE_AND_DELETED] = 0;
    m_awProgramCount[E_CM_SERVICE_POS_RADIO][INCLUDE_NOT_VISIBLE_EXCLUDE_DELETED] = 0;
    m_awProgramCount[E_CM_SERVICE_POS_RADIO][INCLUDE_ALL] = 0;

    m_awProgramCount[E_CM_SERVICE_POS_DATA][EXCLUDE_NOT_VISIBLE_AND_DELETED] = 0;
    m_awProgramCount[E_CM_SERVICE_POS_DATA][INCLUDE_NOT_VISIBLE_EXCLUDE_DELETED] = 0;
    m_awProgramCount[E_CM_SERVICE_POS_DATA][INCLUDE_ALL] = 0;
    #endif
    //clear unsupported ISO639 language code
    //msAPI_CM_ResetUnsupportedIso639Code();
    if(_pfNotify_CM_ResetAllProgram != NULL)
    {
        _pfNotify_CM_ResetAllProgram();
    }
    return TRUE;
}



//****************************************************************************
/// Get Current service type
/// @return MEMBER_SERVICETYPE : Service type
//****************************************************************************
MEMBER_SERVICETYPE msAPI_CM_GetCurrentServiceType(void)
{
    return  m_eCurrentServiceType;
}

//****************************************************************************
/// Set Current service type
/// @param bServiceType \b IN: Service type
/// -@see MEMBER_SERVICETYPE
/// @return BOOLEAN : Function execution result
//****************************************************************************
BOOLEAN msAPI_CM_SetCurrentServiceType(MEMBER_SERVICETYPE bServiceType)
{
    if( FALSE == IsServiceTypeValid(bServiceType) || m_eCurrentServiceType == bServiceType)
    {
        return FALSE;
    }

    m_eCurrentServiceType = bServiceType;
    SaveCurrentServiceType(m_eCurrentServiceType);

    return  TRUE;
}

//****************************************************************************
/// Get Current position
/// @param bServiceType \b IN: Service type
/// @return WORD : current position
//****************************************************************************
WORD msAPI_CM_GetCurrentPosition(MEMBER_SERVICETYPE bServiceType)
{
    if( FALSE == IsServiceTypeValid(bServiceType) )
    {
        return INVALID_PROGRAM_POSITION;
    }

    if( bServiceType == E_SERVICETYPE_DTV )
    {
        return ConvertOrderToPosition(m_wCurrentOrderOfTV);
    }
    else if( bServiceType == E_SERVICETYPE_DATA )
    {
        return ConvertOrderToPosition(m_wCurrentOrderOfData);
    }
    else
    {
        return ConvertOrderToPosition(m_wCurrentOrderOfRadio);
    }
}

//****************************************************************************
/// Set Current position
/// @param bServiceType \b IN: Service type
/// -@see MEMBER_SERVICETYPE
/// @param wPosition : current position
/// @return BOOLEAN : Function execution result
//****************************************************************************
BOOLEAN msAPI_CM_SetCurrentPosition(MEMBER_SERVICETYPE bServiceType, WORD wPosition)
{
    if( FALSE == IsServiceTypeValid(bServiceType) )
    {
        return FALSE;
    }

    if( FALSE == IsPositionValid(bServiceType, wPosition) )
    {
        return FALSE;
    }

    if( bServiceType == E_SERVICETYPE_DTV )
    {
        m_wPastOrderOfTV = m_wCurrentOrderOfTV;
        m_wCurrentOrderOfTV = ConvertPositionToOrder(bServiceType, wPosition);
        SaveCurrentOrderOfTV(m_wCurrentOrderOfTV);
    }
    else if( bServiceType == E_SERVICETYPE_DATA )
    {
        m_wPastOrderOfData = m_wCurrentOrderOfData;
        m_wCurrentOrderOfData = ConvertPositionToOrder(bServiceType, wPosition);
        SaveCurrentOrderOfData(m_wCurrentOrderOfData);
    }
    else
    {
        m_wPastOrderOfRadio = m_wCurrentOrderOfRadio;
        m_wCurrentOrderOfRadio = ConvertPositionToOrder(bServiceType, wPosition);
        SaveCurrentOrderOfRadio(m_wCurrentOrderOfRadio);
    }

    #if (ENABLE_DTV_EPG)
    // Calculate Pr Priority for EPGDB
    if(_pfNotify_SrvPriorityHandler)
    {
		#if (TS_FROM_PLAYCARD == DISABLE)
        _pfNotify_SrvPriorityHandler(wPosition);
		#endif
    }
    //MApp_Epg_SrvPriorityHandler(wPosition);
    #endif

    return TRUE;
}

//****************************************************************************
/// Count program
/// @param bServiceType \b IN: Service type
/// -@see MEMBER_SERVICETYPE
/// @param eBoundary \b IN: Boundry
/// -@see E_MEMBER_PROGRAM_ACCESSIBLE_BOUNDARY
/// @return WORD : Program count
//****************************************************************************
WORD msAPI_CM_CountProgram(MEMBER_SERVICETYPE bServiceType, E_MEMBER_PROGRAM_ACCESSIBLE_BOUNDARY eBoundary)
{
    if( FALSE == IsServiceTypeValid(bServiceType) )
    {
        return 0;
    }

    if(E_PROGACESS_INCLUDE_VISIBLE_ONLY == eBoundary)
    {
        return GetProgramCount(bServiceType, EXCLUDE_NOT_VISIBLE_AND_DELETED);
    }
    else if( E_PROGACESS_INCLUDE_NOT_VISIBLE_ALSO == eBoundary)
    {
        return GetProgramCount(bServiceType, INCLUDE_NOT_VISIBLE_EXCLUDE_DELETED);
    }
    else if( E_PROGACESS_INCLUDE_ALL== eBoundary)
    {
        return GetProgramCount(bServiceType, INCLUDE_ALL);
    }

    return 0;
}

//****************************************************************************
/// Get first program position
/// @param bServiceType \b IN: Service type
/// -@see MEMBER_SERVICETYPE
/// @param bIncludeSkipped \b IN: Include skipped program or not
/// -TRUE: Include skipped program
/// -FALSE: Not include
/// @return WORD : First Program position
//****************************************************************************
WORD msAPI_CM_GetFirstProgramPosition(MEMBER_SERVICETYPE bServiceType, BOOLEAN bIncludeSkipped)
{
    WORD wProgramCount;
    WORD wPosition;

    if( FALSE == IsServiceTypeValid(bServiceType) )
    {
        return INVALID_PROGRAM_POSITION;
    }

    wProgramCount = GetProgramCount(bServiceType, EXCLUDE_NOT_VISIBLE_AND_DELETED);

    for(wPosition=0; wPosition < wProgramCount; wPosition++)
    {
        if( TRUE == bIncludeSkipped )
        {
            return wPosition;
        }
        else
        {
            if( FALSE == msAPI_CM_GetProgramAttribute(bServiceType, wPosition, E_ATTRIBUTE_IS_SKIPPED) )
            {
                return wPosition;
            }
        }
    }

    return INVALID_PROGRAM_POSITION;
}
//****************************************************************************
/// Get last program position
/// @param bServiceType \b IN: Service type
/// -@see MEMBER_SERVICETYPE
/// @param bIncludeSkipped \b IN: Include skipped program or not
/// -TRUE: Include skipped program
/// -FALSE: Not include
/// @return WORD : Last Program position
//****************************************************************************
WORD msAPI_CM_GetLastProgramPosition(MEMBER_SERVICETYPE bServiceType, BOOLEAN bIncludeSkipped)
{
    WORD wProgramCount;
    WORD wPosition;

    if( FALSE == IsServiceTypeValid(bServiceType) )
    {
        return INVALID_PROGRAM_POSITION;
    }

    wProgramCount = GetProgramCount(bServiceType, EXCLUDE_NOT_VISIBLE_AND_DELETED);

    for(wPosition=wProgramCount; wPosition >0; wPosition--)
    {
        if( TRUE == bIncludeSkipped )
        {
            return (wPosition-1);
        }
        else
        {
            if( FALSE == msAPI_CM_GetProgramAttribute(bServiceType, (wPosition-1), E_ATTRIBUTE_IS_SKIPPED) )
            {
                return (wPosition-1);
            }
        }
    }

    return INVALID_PROGRAM_POSITION;
}
#if NTV_FUNCTION_ENABLE
//****************************************************************************
/// Get first special program position
/// @param bServiceType \b IN: Service type
/// -@see MEMBER_SERVICETYPE
/// @param bIncludeSkipped \b IN: Include skipped program or not
/// -TRUE: Include skipped program
/// -FALSE: Not include
/// @return WORD : First Program position
//****************************************************************************
static WORD msAPI_CM_GetFirstSpecialProgramPosition(MEMBER_SERVICETYPE bServiceType, BOOLEAN bIncludeSkipped)
{
    WORD wProgramCount;
    WORD wPosition;
    WORD wLCN;
    WORD wON_ID;
    WORD wOrder;
    BOOLEAN bIsSpecialService;

    wProgramCount = GetProgramCount(bServiceType, EXCLUDE_NOT_VISIBLE_AND_DELETED);
    for(wPosition=0; wPosition < wProgramCount; wPosition++)
    {
        wOrder = ConvertPositionToOrder(bServiceType, wPosition);
        bIsSpecialService = m_astDTVProgramIndexTable[wOrder].bIsSpecialService;
        if( TRUE == bIncludeSkipped )
        {
            wLCN = msAPI_CM_GetLogicalChannelNumber(bServiceType, wPosition);
            wON_ID = msAPI_CM_GetON_ID(bServiceType, wPosition);

            if(bIsSpecialService == TRUE && wON_ID == SI_ONID_NORWAY)
            {
                return wPosition;
            }
        }
        else
        {
            if( FALSE == msAPI_CM_GetProgramAttribute(bServiceType, wPosition, E_ATTRIBUTE_IS_SKIPPED) )
            {
                wLCN = msAPI_CM_GetLogicalChannelNumber(bServiceType, wPosition);
                wON_ID = msAPI_CM_GetON_ID(bServiceType, wPosition);

                if(bIsSpecialService == TRUE && wON_ID == SI_ONID_NORWAY)
                {
                    return wPosition;
                }
            }
        }
    }
    return INVALID_PROGRAM_POSITION;
}
//****************************************************************************
/// Get last program position
/// @param bServiceType \b IN: Service type
/// -@see MEMBER_SERVICETYPE
/// @param bIncludeSkipped \b IN: Include skipped program or not
/// -TRUE: Include skipped program
/// -FALSE: Not include
/// @return WORD : Last Program position
//****************************************************************************
static WORD msAPI_CM_GetLastSpecialProgramPosition(MEMBER_SERVICETYPE bServiceType, BOOLEAN bIncludeSkipped)
{
    WORD wProgramCount;
    WORD wPosition;
    WORD wLCN;
    WORD wON_ID;
    WORD wOrder;
    BOOLEAN bIsSpecialService;

    wProgramCount = GetProgramCount(bServiceType, EXCLUDE_NOT_VISIBLE_AND_DELETED);

    for(wPosition=wProgramCount; wPosition >0; wPosition--)
    {
        wOrder = ConvertPositionToOrder(bServiceType, wPosition-1);
        bIsSpecialService = m_astDTVProgramIndexTable[wOrder].bIsSpecialService;
        if( TRUE == bIncludeSkipped )
        {
            wLCN = msAPI_CM_GetLogicalChannelNumber(bServiceType, wPosition-1);
            wON_ID = msAPI_CM_GetON_ID(bServiceType, wPosition-1);

            if(bIsSpecialService == TRUE && wON_ID == SI_ONID_NORWAY)
            {
                return (wPosition-1);
            }
            else
            {
                return INVALID_PROGRAM_POSITION;
            }
        }
        else
        {
            if( FALSE == msAPI_CM_GetProgramAttribute(bServiceType, wPosition-1, E_ATTRIBUTE_IS_SKIPPED) )
            {
                wLCN = msAPI_CM_GetLogicalChannelNumber(bServiceType, wPosition-1);
                wON_ID = msAPI_CM_GetON_ID(bServiceType, wPosition-1);

                if(bIsSpecialService == TRUE && wON_ID == SI_ONID_NORWAY)
                {
                    return (wPosition-1);
                }
                else
                {
                    return INVALID_PROGRAM_POSITION;
                }
            }
        }
    }
    return INVALID_PROGRAM_POSITION;
}
#endif

//****************************************************************************
/// Get next program position
/// @param bServiceType \b IN: Service type
/// -@see MEMBER_SERVICETYPE
/// @param wBasePosition \b IN: base position
/// @param bIncludeSkipped \b IN: Include skipped program or not
/// -TRUE: Include skipped program
/// -FALSE: Not include
/// @return WORD : First Program position
//****************************************************************************
WORD msAPI_CM_GetNextProgramPosition(MEMBER_SERVICETYPE bServiceType, WORD wBasePosition, BOOLEAN bIncludeSkipped, CHANNEL_LIST_TYPE bList_type, MEMBER_SERVICETYPE *bNewServiceType)
{
    WORD wProgramCount,wDTVProgramCount=0,wRadioProgramCount=0;
    WORD wDataProgramCount = 0;
    WORD wPosition;
    WORD i;
#if NTV_FUNCTION_ENABLE
    WORD wFirstDTVSpecailProgram = INVALID_PROGRAM_POSITION;
#endif
    //MEMBER_SERVICETYPE bPreServiceType = bServiceType;
    if( FALSE == IsServiceTypeValid(bServiceType) )
    {
        return INVALID_PROGRAM_POSITION;
    }

    if( FALSE == IsPositionValid(bServiceType, wBasePosition) )
    {
        return INVALID_PROGRAM_POSITION;
    }
    if(bList_type == E_ALL_LIST && (bServiceType == E_SERVICETYPE_DTV || bServiceType == E_SERVICETYPE_RADIO ||bServiceType == E_SERVICETYPE_DATA))
    {
        wDTVProgramCount = GetProgramCount(E_SERVICETYPE_DTV, EXCLUDE_NOT_VISIBLE_AND_DELETED);
        wRadioProgramCount = GetProgramCount(E_SERVICETYPE_RADIO, EXCLUDE_NOT_VISIBLE_AND_DELETED);
        wDataProgramCount = GetProgramCount(E_SERVICETYPE_DATA, EXCLUDE_NOT_VISIBLE_AND_DELETED);
        wProgramCount = wDTVProgramCount + wRadioProgramCount + wDataProgramCount;
    }
    else
    {
        wProgramCount = GetProgramCount(bServiceType, EXCLUDE_NOT_VISIBLE_AND_DELETED);
    }
    if(bList_type == E_ALL_LIST && (bServiceType == E_SERVICETYPE_DTV || bServiceType == E_SERVICETYPE_RADIO || bServiceType == E_SERVICETYPE_DATA))
    {
        if(bServiceType == E_SERVICETYPE_DTV && wBasePosition >= wDTVProgramCount)
        {
            wPosition = wDTVProgramCount;
        }
        else if(bServiceType == E_SERVICETYPE_RADIO && wBasePosition >= wRadioProgramCount)
        {
            wPosition = wRadioProgramCount;
        }
        else if(bServiceType == E_SERVICETYPE_DATA && wBasePosition >= wDataProgramCount)
        {
            wPosition = wDataProgramCount;
        }
        else
        {
            wPosition = wBasePosition;
        }
    }
    else if( wBasePosition >= wProgramCount )
    {
        wPosition = wProgramCount;
    }
    else
    {
        wPosition = wBasePosition;
    }
    for(i=0; i< wProgramCount; i++)
    {
        wPosition++;
        if(bList_type == E_ALL_LIST && (bServiceType == E_SERVICETYPE_DTV || bServiceType == E_SERVICETYPE_RADIO || bServiceType == E_SERVICETYPE_DATA))
        {
            if(bServiceType == E_SERVICETYPE_DTV)
            {
                if(wPosition >= wDTVProgramCount)
                {
#if NTV_FUNCTION_ENABLE
                    if(msAPI_CM_GetCountry() == E_NORWAY && msAPI_CM_GetLastSpecialProgramPosition(E_SERVICETYPE_DTV, bIncludeSkipped) != INVALID_PROGRAM_POSITION)
                    {
                        bServiceType = E_SERVICETYPE_DTV;
                    }
                    else
#endif
                    {
                        if(wRadioProgramCount > 0)
                        {
                                bServiceType = E_SERVICETYPE_RADIO;
                        }
                        else if(wDataProgramCount > 0)
                        {
                                bServiceType = E_SERVICETYPE_DATA;
                        }
                    }

                    wPosition = 0;
                }
#if (NTV_FUNCTION_ENABLE)
                else if(msAPI_CM_GetCountry() == E_NORWAY && wPosition == msAPI_CM_GetFirstSpecialProgramPosition(E_SERVICETYPE_DTV, bIncludeSkipped))
                {
                    if(wRadioProgramCount > 0)
                    {
                        bServiceType = E_SERVICETYPE_RADIO;
                        wPosition = 0;
                    }
                    else if(wDataProgramCount > 0)
                    {
                        bServiceType = E_SERVICETYPE_DATA;
                        wPosition = 0;
                    }
                }
#endif
            }
            else if(bServiceType == E_SERVICETYPE_RADIO)
            {
                if(wPosition >= wRadioProgramCount)
                {
                    if(wDataProgramCount > 0)
                    {
                            bServiceType = E_SERVICETYPE_DATA;
                    }
                    else if(wDTVProgramCount > 0)
                    {
#if NTV_FUNCTION_ENABLE
                        if(msAPI_CM_GetCountry() == E_NORWAY)
                        {
                            wFirstDTVSpecailProgram = msAPI_CM_GetFirstSpecialProgramPosition(E_SERVICETYPE_DTV, bIncludeSkipped);
                        }
#endif
                            bServiceType = E_SERVICETYPE_DTV;
                    }
#if (NTV_FUNCTION_ENABLE)
                    if(msAPI_CM_GetCountry() == E_NORWAY)
                    {
                        if(wFirstDTVSpecailProgram != INVALID_PROGRAM_POSITION)
                            wPosition = wFirstDTVSpecailProgram;
                        else
                            wPosition = 0;
                    }
                    else
                    {
                        wPosition = 0;
                    }
#else
                    wPosition = 0;
#endif
                }
            }
            else if(bServiceType == E_SERVICETYPE_DATA)
            {
                if(wPosition >= wDataProgramCount)
                {
                    if(wDTVProgramCount > 0)
                    {
#if NTV_FUNCTION_ENABLE
                        if(msAPI_CM_GetCountry() == E_NORWAY)
                        {
                            wFirstDTVSpecailProgram = msAPI_CM_GetFirstSpecialProgramPosition(E_SERVICETYPE_DTV, bIncludeSkipped);
                        }
#endif
                        bServiceType = E_SERVICETYPE_DTV;
                    }
                    else if(wRadioProgramCount > 0)
                    {
                        bServiceType = E_SERVICETYPE_RADIO;
                    }
#if NTV_FUNCTION_ENABLE
                    if(msAPI_CM_GetCountry() == E_NORWAY)
                    {
                        if(wFirstDTVSpecailProgram != INVALID_PROGRAM_POSITION)
                            wPosition = wFirstDTVSpecailProgram;
                        else
                            wPosition = 0;
                    }
                    else
                    {
                        wPosition = 0;
                    }
#else
                    wPosition = 0;
#endif
                }
            }
            #if 0
            if(bServiceType == E_SERVICETYPE_DTV && wPosition >= wDTVProgramCount)
            {
                bServiceType = E_SERVICETYPE_RADIO;
                wPosition=0;
            }
            else if(bServiceType == E_SERVICETYPE_RADIO && wPosition >= wRadioProgramCount)
            {
                bServiceType=E_SERVICETYPE_DTV;
                wPosition=0;
            }
            #endif
        }
        else if( wPosition >= wProgramCount )
        {
            wPosition = 0;
        }
        if(bList_type == E_ALL_LIST && bNewServiceType != NULL )
        {
            *bNewServiceType = bServiceType;
        }
        if( TRUE == bIncludeSkipped )
        {
            return wPosition;
        }
        else
        {
            if( FALSE == msAPI_CM_GetProgramAttribute(bServiceType, wPosition, E_ATTRIBUTE_IS_SKIPPED) )
            {
                return wPosition;
            }
        }
    }

    return INVALID_PROGRAM_POSITION;
}

//****************************************************************************
/// Get previous program position
/// @param bServiceType \b IN: Service type
/// -@see MEMBER_SERVICETYPE
/// @param wBasePosition \b IN: base position
/// @param bIncludeSkipped \b IN: Include skipped program or not
/// -TRUE: Include skipped program
/// -FALSE: Not include
/// @param *bNewServiceType \b IN: pointer to service type for return
/// -@see MEMBER_SERVICETYPE
/// @return WORD : First Program position
//****************************************************************************
WORD msAPI_CM_GetPrevProgramPosition(MEMBER_SERVICETYPE bServiceType, WORD wBasePosition, BOOLEAN bIncludeSkipped, CHANNEL_LIST_TYPE bList_type, MEMBER_SERVICETYPE *bNewServiceType)
{
    WORD wProgramCount = 0,wDTVProgramCount = 0,wRadioProgramCount = 0;
    WORD wDataProgramCount = 0;
    WORD wPosition;
    WORD i;
#if NTV_FUNCTION_ENABLE
    WORD wFirstDTVSpecailProgram = INVALID_PROGRAM_POSITION, wLastDTVSpecailProgram = INVALID_PROGRAM_POSITION;
#endif
    //MEMBER_SERVICETYPE bPreServiceType = bServiceType;

    if( FALSE == IsServiceTypeValid(bServiceType) )
    {
        return INVALID_PROGRAM_POSITION;
    }

    if( FALSE == IsPositionValid(bServiceType, wBasePosition) )
    {
        return INVALID_PROGRAM_POSITION;
    }
    if(bList_type == E_ALL_LIST && (bServiceType == E_SERVICETYPE_DTV || bServiceType == E_SERVICETYPE_RADIO || bServiceType == E_SERVICETYPE_DATA))
    {
        wDTVProgramCount = GetProgramCount(E_SERVICETYPE_DTV, EXCLUDE_NOT_VISIBLE_AND_DELETED);
        wRadioProgramCount = GetProgramCount(E_SERVICETYPE_RADIO, EXCLUDE_NOT_VISIBLE_AND_DELETED);
        wDataProgramCount = GetProgramCount(E_SERVICETYPE_DATA, EXCLUDE_NOT_VISIBLE_AND_DELETED);
        wProgramCount = wDTVProgramCount + wRadioProgramCount + wDataProgramCount;
    }
    else
    {
        wProgramCount = GetProgramCount(bServiceType, EXCLUDE_NOT_VISIBLE_AND_DELETED);
    }
    if(bList_type == E_ALL_LIST && (bServiceType == E_SERVICETYPE_DTV || bServiceType == E_SERVICETYPE_RADIO || bServiceType == E_SERVICETYPE_DATA))
    {
        if(bServiceType == E_SERVICETYPE_DTV && wBasePosition >= wDTVProgramCount)
        {
            wPosition = wDTVProgramCount;
        }
        else if(bServiceType == E_SERVICETYPE_RADIO && wBasePosition >= wRadioProgramCount)
        {
            wPosition = wRadioProgramCount;
        }
        else if(bServiceType == E_SERVICETYPE_DATA && wBasePosition >= wDataProgramCount)
        {
            wPosition = wDataProgramCount;
        }
        else
        {
            wPosition = wBasePosition;
        }
    }
    else if( wBasePosition >= wProgramCount )
    {
        wPosition = wProgramCount;
    }
    else
    {
        wPosition = wBasePosition;
    }

    for(i=0; i< wProgramCount; i++)
    {
        if( wPosition > 0 )
        {
#if (NTV_FUNCTION_ENABLE)
            if((msAPI_CM_GetCountry() == E_NORWAY) && (bServiceType == E_SERVICETYPE_DTV))
            {
                wFirstDTVSpecailProgram = msAPI_CM_GetFirstSpecialProgramPosition(E_SERVICETYPE_DTV, bIncludeSkipped);
                if(wFirstDTVSpecailProgram != INVALID_PROGRAM_POSITION && wPosition == wFirstDTVSpecailProgram)
                {
                    if(wDataProgramCount > 0)
                    {
                        bServiceType = E_SERVICETYPE_DATA;
                        wPosition = wDataProgramCount - 1;
                    }
                    else if(wRadioProgramCount > 0)
                    {
                        bServiceType = E_SERVICETYPE_RADIO;
                        wPosition = wRadioProgramCount - 1;
                    }
                    else
                    {
                        wPosition--;
                    }
                }
                else
                    wPosition--;
            }
            else
#endif
            wPosition--;
        }
        else
        {
            if(bList_type == E_ALL_LIST && (bServiceType == E_SERVICETYPE_DTV || bServiceType == E_SERVICETYPE_RADIO || bServiceType == E_SERVICETYPE_DATA))
            {
                if(bServiceType == E_SERVICETYPE_DTV)
                {
#if NTV_FUNCTION_ENABLE
                    if((msAPI_CM_GetCountry() == E_NORWAY) && (wDTVProgramCount > 0))
                        wLastDTVSpecailProgram = msAPI_CM_GetLastSpecialProgramPosition(E_SERVICETYPE_DTV, bIncludeSkipped);
                    if((msAPI_CM_GetCountry() == E_NORWAY) && (wLastDTVSpecailProgram != INVALID_PROGRAM_POSITION))
                    {
                        wPosition = wLastDTVSpecailProgram;
                    }
                    else
#endif
                    if(wDataProgramCount > 0)
                    {
                        bServiceType = E_SERVICETYPE_DATA;
                        wPosition = wDataProgramCount - 1;
                    }
                    else if(wRadioProgramCount > 0)
                    {
                        bServiceType = E_SERVICETYPE_RADIO;
                        wPosition = wRadioProgramCount - 1;
                    }
                    else if(wDTVProgramCount > 0)
                    {
                        bServiceType = E_SERVICETYPE_DTV;
                        wPosition = wDTVProgramCount - 1;
                    }
                }
                else if(bServiceType == E_SERVICETYPE_RADIO)
                {
                    if(wDTVProgramCount > 0)
                    {
                        bServiceType = E_SERVICETYPE_DTV;
#if NTV_FUNCTION_ENABLE
                        if((msAPI_CM_GetCountry() == E_NORWAY) && (wDTVProgramCount > 0))
                            wFirstDTVSpecailProgram = msAPI_CM_GetFirstSpecialProgramPosition(E_SERVICETYPE_DTV, bIncludeSkipped);
                        if((msAPI_CM_GetCountry() == E_NORWAY) && (wFirstDTVSpecailProgram != INVALID_PROGRAM_POSITION))
                        {
                            wPosition = wFirstDTVSpecailProgram-1;
                        }
                        else
#endif
                        wPosition = wDTVProgramCount - 1;
                    }
                    else if(wDataProgramCount > 0)
                    {
                        bServiceType = E_SERVICETYPE_DATA;
                        wPosition = wDataProgramCount - 1;
                    }
                    else if(wRadioProgramCount > 0)
                    {
                        bServiceType = E_SERVICETYPE_RADIO;
                        wPosition = wRadioProgramCount - 1;
                    }
                }
                else if(bServiceType == E_SERVICETYPE_DATA)
                {
                    if(wRadioProgramCount > 0)
                    {
                        bServiceType = E_SERVICETYPE_RADIO;
                        wPosition = wRadioProgramCount - 1;
                    }
                    else if(wDTVProgramCount > 0)
                    {
                        bServiceType = E_SERVICETYPE_DTV;
#if NTV_FUNCTION_ENABLE
                        if(msAPI_CM_GetCountry() == E_NORWAY)
                        {
                            wFirstDTVSpecailProgram = msAPI_CM_GetFirstSpecialProgramPosition(E_SERVICETYPE_DTV, bIncludeSkipped);
                            if(wFirstDTVSpecailProgram != INVALID_PROGRAM_POSITION)
                            {
                                wPosition = wFirstDTVSpecailProgram-1;
                            }
                            else
                            {
                                wPosition = wDTVProgramCount - 1;
                            }
                        }
                        else
                        {
                            wPosition = wDTVProgramCount - 1;
                        }
#else
                        wPosition = wDTVProgramCount - 1;
#endif
                    }
                    else if(wDataProgramCount > 0)
                    {
                        bServiceType = E_SERVICETYPE_DATA;
                        wPosition = wDataProgramCount - 1;
                    }
                }
            }
            else
            {
                wPosition = wProgramCount - 1;
            }
        }
        if(bList_type == E_ALL_LIST && bNewServiceType != NULL )
        {
            *bNewServiceType = bServiceType;
        }
        if( TRUE == bIncludeSkipped )
        {
            return wPosition;
        }
        else
        {
            if( FALSE == msAPI_CM_GetProgramAttribute(bServiceType, wPosition, E_ATTRIBUTE_IS_SKIPPED) )
            {
               return wPosition;
            }
        }
    }

    return INVALID_PROGRAM_POSITION;
}

#if (CM_MULTI_FAVORITE)
//****************************************************************************
/// Count favorite program
/// @param bServiceType \b IN: Service type
/// -@see MEMBER_SERVICETYPE
/// @return WORD : Favorite program number
//****************************************************************************
WORD msAPI_CM_CountFavoriteProgram(MEMBER_SERVICETYPE bServiceType, E_FAVORITE_TYPE eFavorType)
{
    WORD wProgramCount;
    WORD wFavoriteCount;
    WORD wPosition;

    if( FALSE == IsServiceTypeValid(bServiceType) )
    {
        return 0;
    }

    wProgramCount = GetProgramCount(bServiceType, EXCLUDE_NOT_VISIBLE_AND_DELETED);
    wFavoriteCount = 0;

    for(wPosition=0; wPosition < wProgramCount; wPosition++)
    {
        if( TRUE == msAPI_CM_GetProgramAttribute(bServiceType, wPosition, (E_MEMBER_CHANNEL_ATTRIBUTE)(E_ATTRIBUTE_IS_FAVORITE1+eFavorType)) )
        {
            wFavoriteCount++;
        }
    }

    return wFavoriteCount;
}

//****************************************************************************
/// Get first favorite program position
/// @param bServiceType \b IN: Service type
/// -@see MEMBER_SERVICETYPE
/// @param bIncludeSkipped \b IN: Include skipped program or not
/// -TRUE: Include skipped program
/// -FALSE: Not include
/// @return WORD : First favorite Program position
//****************************************************************************
WORD msAPI_CM_GetFirstFavoriteProgramPosition(MEMBER_SERVICETYPE bServiceType, BOOLEAN bIncludeSkipped, E_FAVORITE_TYPE eFavorType)
{
    WORD wProgramCount;
    WORD wPosition;

    if( FALSE == IsServiceTypeValid(bServiceType) )
    {
        return INVALID_PROGRAM_POSITION;
    }

    wProgramCount = GetProgramCount(bServiceType, EXCLUDE_NOT_VISIBLE_AND_DELETED);

    for(wPosition=0; wPosition < wProgramCount; wPosition++)
    {
        if( TRUE == msAPI_CM_GetProgramAttribute(bServiceType, wPosition, (E_MEMBER_CHANNEL_ATTRIBUTE)(E_ATTRIBUTE_IS_FAVORITE1+eFavorType)) )
        {
            if( TRUE == bIncludeSkipped )
            {
                return wPosition;
            }
            else
            {
                if( FALSE == msAPI_CM_GetProgramAttribute(bServiceType, wPosition, E_ATTRIBUTE_IS_SKIPPED) )
                {
                    return wPosition;
                }
            }
        }
    }

    return INVALID_PROGRAM_POSITION;
}

//****************************************************************************
/// Get last favorite program position
/// @param bServiceType \b IN: Service type
/// -@see MEMBER_SERVICETYPE
/// @param bIncludeSkipped \b IN: Include skipped program or not
/// -TRUE: Include skipped program
/// -FALSE: Not include
/// @return WORD : last favorite Program position
//****************************************************************************
WORD msAPI_CM_GetLastFavoriteProgramPosition(MEMBER_SERVICETYPE bServiceType, BOOLEAN bIncludeSkipped, E_FAVORITE_TYPE eFavorType)
{
    WORD wPosition;

    if( FALSE == IsServiceTypeValid(bServiceType) )
    {
        return INVALID_PROGRAM_POSITION;
    }

    wPosition = msAPI_CM_GetFirstFavoriteProgramPosition(bServiceType, bIncludeSkipped, eFavorType);
    return msAPI_CM_GetPrevFavoriteProgramPosition(bServiceType, wPosition, bIncludeSkipped, eFavorType);
}

//****************************************************************************
/// Get previous favorite program position
/// @param bServiceType \b IN: Service type
/// -@see MEMBER_SERVICETYPE
/// @param wBasePosition \b IN: base position
/// @param bIncludeSkipped \b IN: Include skipped program or not
/// -TRUE: Include skipped program
/// -FALSE: Not include
/// @param eFavorType \b IN: Favorite list type
/// -@see E_FAVORITE_TYPE
/// @return WORD : previous favorite Program position
//****************************************************************************
WORD msAPI_CM_GetPrevFavoriteProgramPosition(MEMBER_SERVICETYPE bServiceType, WORD wBasePosition, BOOLEAN bIncludeSkipped, E_FAVORITE_TYPE eFavorType)
{
    WORD wProgramCount;
    WORD wPosition;
    WORD i;

    if( FALSE == IsServiceTypeValid(bServiceType) )
    {
        return INVALID_PROGRAM_POSITION;
    }

    if( FALSE == IsPositionValid(bServiceType, wBasePosition) )
    {
        return INVALID_PROGRAM_POSITION;
    }

    wProgramCount = GetProgramCount(bServiceType, EXCLUDE_NOT_VISIBLE_AND_DELETED);

    if( wBasePosition >= wProgramCount )
    {
        wPosition = wProgramCount;
    }
    else
    {
        wPosition = wBasePosition;
    }

    for(i=0; i < wProgramCount; i++)
    {
        if( wPosition > 0 )
        {
            wPosition--;
        }
        else
        {
            wPosition = wProgramCount - 1;
        }

        if( TRUE == msAPI_CM_GetProgramAttribute(bServiceType, wPosition, (E_MEMBER_CHANNEL_ATTRIBUTE)(E_ATTRIBUTE_IS_FAVORITE1+eFavorType)) )
        {
            if( TRUE == bIncludeSkipped )
            {
                return wPosition;
            }
            else
            {
                if( FALSE == msAPI_CM_GetProgramAttribute(bServiceType, wPosition, E_ATTRIBUTE_IS_SKIPPED) )
                {
                    return wPosition;
                }
            }
        }
    }

    return INVALID_PROGRAM_POSITION;
}

//****************************************************************************
/// Get Next favorite program position
/// @param bServiceType \b IN: Service type
/// -@see MEMBER_SERVICETYPE
/// @param wBasePosition \b IN: base position
/// @param bIncludeSkipped \b IN: Include skipped program or not
/// -TRUE: Include skipped program
/// -FALSE: Not include
/// @param eFavorType \b IN: Favorite list type
/// -@see E_FAVORITE_TYPE
/// @return WORD : Next favorite Program position
//****************************************************************************
WORD msAPI_CM_GetNextFavoriteProgramPosition(MEMBER_SERVICETYPE bServiceType, WORD wBasePosition, BOOLEAN bIncludeSkipped, E_FAVORITE_TYPE eFavorType)
{
    WORD wProgramCount;
    WORD wPosition;
    WORD i;

    if( FALSE == IsServiceTypeValid(bServiceType) )
    {
        return INVALID_PROGRAM_POSITION;
    }

    if( FALSE == IsPositionValid(bServiceType, wBasePosition) )
    {
        return INVALID_PROGRAM_POSITION;
    }

    wProgramCount = GetProgramCount(bServiceType, EXCLUDE_NOT_VISIBLE_AND_DELETED);

    if( wBasePosition >= wProgramCount )
    {
        wPosition = wProgramCount;
    }
    else
    {
        wPosition = wBasePosition;
    }

    for(i=0; i< wProgramCount; i++)
    {
        wPosition++;

        if( wPosition >= wProgramCount )
        {
            wPosition = 0;
        }

        if( TRUE == msAPI_CM_GetProgramAttribute(bServiceType, wPosition, (E_MEMBER_CHANNEL_ATTRIBUTE)(E_ATTRIBUTE_IS_FAVORITE1+eFavorType)) )
        {
            if( TRUE == bIncludeSkipped )
            {
                return wPosition;
            }
            else
            {
                if( FALSE == msAPI_CM_GetProgramAttribute(bServiceType, wPosition, E_ATTRIBUTE_IS_SKIPPED) )
                {
                    return wPosition;
                }
            }
        }
    }

    return INVALID_PROGRAM_POSITION;
}
#else
//****************************************************************************
/// Count favorite program
/// @param bServiceType \b IN: Service type
/// -@see MEMBER_SERVICETYPE
/// @return WORD : Favorite program number
//****************************************************************************
WORD msAPI_CM_CountFavoriteProgram(MEMBER_SERVICETYPE bServiceType)
{
    WORD wProgramCount;
    WORD wFavoriteCount;
    WORD wPosition;

    if( FALSE == IsServiceTypeValid(bServiceType) )
    {
        return 0;
    }

    wProgramCount = GetProgramCount(bServiceType, EXCLUDE_NOT_VISIBLE_AND_DELETED);
    wFavoriteCount = 0;

    for(wPosition=0; wPosition < wProgramCount; wPosition++)
    {
        if( TRUE == msAPI_CM_GetProgramAttribute(bServiceType, wPosition, E_ATTRIBUTE_IS_FAVORITE) )
        {
            wFavoriteCount++;
        }
    }

    return wFavoriteCount;
}

//****************************************************************************
/// Get first favorite program position
/// @param bServiceType \b IN: Service type
/// -@see MEMBER_SERVICETYPE
/// @param bIncludeSkipped \b IN: Include skipped program or not
/// -TRUE: Include skipped program
/// -FALSE: Not include
/// @return WORD : First favorite Program position
//****************************************************************************
WORD msAPI_CM_GetFirstFavoriteProgramPosition(MEMBER_SERVICETYPE bServiceType, BOOLEAN bIncludeSkipped)
{
    WORD wProgramCount;
    WORD wPosition;

    if( FALSE == IsServiceTypeValid(bServiceType) )
    {
        return INVALID_PROGRAM_POSITION;
    }

    wProgramCount = GetProgramCount(bServiceType, EXCLUDE_NOT_VISIBLE_AND_DELETED);

    for(wPosition=0; wPosition < wProgramCount; wPosition++)
    {
        if( TRUE == msAPI_CM_GetProgramAttribute(bServiceType, wPosition, E_ATTRIBUTE_IS_FAVORITE) )
        {
            if( TRUE == bIncludeSkipped )
            {
                return wPosition;
            }
            else
            {
                if( FALSE == msAPI_CM_GetProgramAttribute(bServiceType, wPosition, E_ATTRIBUTE_IS_SKIPPED) )
                {
                    return wPosition;
                }
            }
        }
    }

    return INVALID_PROGRAM_POSITION;
}

//****************************************************************************
/// Get last favorite program position
/// @param bServiceType \b IN: Service type
/// -@see MEMBER_SERVICETYPE
/// @param bIncludeSkipped \b IN: Include skipped program or not
/// -TRUE: Include skipped program
/// -FALSE: Not include
/// @return WORD : last favorite Program position
//****************************************************************************
WORD msAPI_CM_GetLastFavoriteProgramPosition(MEMBER_SERVICETYPE bServiceType, BOOLEAN bIncludeSkipped)
{
    WORD wPosition;

    if( FALSE == IsServiceTypeValid(bServiceType) )
    {
        return INVALID_PROGRAM_POSITION;
    }

    wPosition = msAPI_CM_GetFirstFavoriteProgramPosition(bServiceType, bIncludeSkipped);
    return msAPI_CM_GetPrevFavoriteProgramPosition(bServiceType, wPosition, bIncludeSkipped);
}

//****************************************************************************
/// Get previous favorite program position
/// @param bServiceType \b IN: Service type
/// -@see MEMBER_SERVICETYPE
/// @param wBasePosition \b IN: base position
/// @param bIncludeSkipped \b IN: Include skipped program or not
/// -TRUE: Include skipped program
/// -FALSE: Not include
/// @return WORD : previous favorite Program position
//****************************************************************************
WORD msAPI_CM_GetPrevFavoriteProgramPosition(MEMBER_SERVICETYPE bServiceType, WORD wBasePosition, BOOLEAN bIncludeSkipped)
{
    WORD wProgramCount;
    WORD wPosition;
    WORD i;

    if( FALSE == IsServiceTypeValid(bServiceType) )
    {
        return INVALID_PROGRAM_POSITION;
    }

    if( FALSE == IsPositionValid(bServiceType, wBasePosition) )
    {
        return INVALID_PROGRAM_POSITION;
    }

    wProgramCount = GetProgramCount(bServiceType, EXCLUDE_NOT_VISIBLE_AND_DELETED);

    if( wBasePosition >= wProgramCount )
    {
        wPosition = wProgramCount;
    }
    else
    {
        wPosition = wBasePosition;
    }

    for(i=0; i < wProgramCount; i++)
    {
        if( wPosition > 0 )
        {
            wPosition--;
        }
        else
        {
            wPosition = wProgramCount - 1;
        }

        if( TRUE == msAPI_CM_GetProgramAttribute(bServiceType, wPosition, E_ATTRIBUTE_IS_FAVORITE) )
        {
            if( TRUE == bIncludeSkipped )
            {
                return wPosition;
            }
            else
            {
                if( FALSE == msAPI_CM_GetProgramAttribute(bServiceType, wPosition, E_ATTRIBUTE_IS_SKIPPED) )
                {
                    return wPosition;
                }
            }
        }
    }

    return INVALID_PROGRAM_POSITION;
}

//****************************************************************************
/// Get Next favorite program position
/// @param bServiceType \b IN: Service type
/// -@see MEMBER_SERVICETYPE
/// @param wBasePosition \b IN: base position
/// @param bIncludeSkipped \b IN: Include skipped program or not
/// -TRUE: Include skipped program
/// -FALSE: Not include
/// @return WORD : Next favorite Program position
//****************************************************************************
WORD msAPI_CM_GetNextFavoriteProgramPosition(MEMBER_SERVICETYPE bServiceType, WORD wBasePosition, BOOLEAN bIncludeSkipped)
{
    WORD wProgramCount;
    WORD wPosition;
    WORD i;

    if( FALSE == IsServiceTypeValid(bServiceType) )
    {
        return INVALID_PROGRAM_POSITION;
    }

    if( FALSE == IsPositionValid(bServiceType, wBasePosition) )
    {
        return INVALID_PROGRAM_POSITION;
    }

    wProgramCount = GetProgramCount(bServiceType, EXCLUDE_NOT_VISIBLE_AND_DELETED);

    if( wBasePosition >= wProgramCount )
    {
        wPosition = wProgramCount;
    }
    else
    {
        wPosition = wBasePosition;
    }

    for(i=0; i< wProgramCount; i++)
    {
        wPosition++;

        if( wPosition >= wProgramCount )
        {
            wPosition = 0;
        }

        if( TRUE == msAPI_CM_GetProgramAttribute(bServiceType, wPosition, E_ATTRIBUTE_IS_FAVORITE) )
        {
            if( TRUE == bIncludeSkipped )
            {
                return wPosition;
            }
            else
            {
                if( FALSE == msAPI_CM_GetProgramAttribute(bServiceType, wPosition, E_ATTRIBUTE_IS_SKIPPED) )
                {
                    return wPosition;
                }
            }
        }
    }

    return INVALID_PROGRAM_POSITION;
}
#endif

//****************************************************************************
/// Get logical channel number (LCN)
/// @param bServiceType \b IN: Service type
/// -@see MEMBER_SERVICETYPE
/// @param wPosition \b IN: position
/// @param bSimuLCN \b IN: is SimuLCN or not
/// -TRUE: SimuLCN
/// -FALSE: LCN
/// @return WORD : LCN
//****************************************************************************
static WORD __msAPI_CM_GetLogicalChannelNumber(MEMBER_SERVICETYPE bServiceType, WORD wPosition, BOOLEAN bSimuLCN)
{
    WORD wOrder,wLCN;

    if( FALSE == IsServiceTypeValid(bServiceType) )
    {
        return bSimuLCN ? INVALID_SIMULCAST_LOGICAL_CHANNEL_NUMBER : INVALID_LOGICAL_CHANNEL_NUMBER;
    }

    if( FALSE == IsPositionValid(bServiceType, wPosition) )
    {
        return bSimuLCN ? INVALID_SIMULCAST_LOGICAL_CHANNEL_NUMBER : INVALID_LOGICAL_CHANNEL_NUMBER;
    }

    wOrder = ConvertPositionToOrder(bServiceType, wPosition);

    if(bSimuLCN)
    {
        wLCN = m_astDTVProgramIndexTable[wOrder].wSimu_LCN;
    }
    else
    {
        wLCN = m_astDTVProgramIndexTable[wOrder].wLCN;
    }

    return wLCN;
}

static WORD __msAPI_CM_GetOriginalLogicalChannelNumber(MEMBER_SERVICETYPE bServiceType, WORD wPosition)
{
    WORD wOrder,wLCN,wPRIndex;

    if( FALSE == IsServiceTypeValid(bServiceType) )
    {
        return INVALID_LOGICAL_CHANNEL_NUMBER;
    }

    if( FALSE == IsPositionValid(bServiceType, wPosition) )
    {
        return INVALID_LOGICAL_CHANNEL_NUMBER;
    }

    wOrder = ConvertPositionToOrder(bServiceType, wPosition);
    wPRIndex = m_astDTVProgramIndexTable[wOrder].wPRIndex;
    GetProgramTable(wPRIndex, (BYTE *)&wLCN, E_DATA_TS_LCN);

    return wLCN;
}

//****************************************************************************
// Use  __msAPI_CM_GetLogicalChannelNumber() if need
//****************************************************************************
WORD msAPI_CM_GetSimuLogicalChannelNumber(MEMBER_SERVICETYPE bServiceType, WORD wPosition)
{
    return __msAPI_CM_GetLogicalChannelNumber(bServiceType,wPosition,TRUE);
}

//****************************************************************************
// Use  __msAPI_CM_GetLogicalChannelNumber() if need
//****************************************************************************
WORD msAPI_CM_GetLogicalChannelNumber(MEMBER_SERVICETYPE bServiceType, WORD wPosition)
{
    return __msAPI_CM_GetLogicalChannelNumber(bServiceType,wPosition,FALSE);
}
WORD msAPI_CM_GetOriginalLogicalChannelNumber(MEMBER_SERVICETYPE bServiceType, WORD wPosition)
{
    return __msAPI_CM_GetOriginalLogicalChannelNumber(bServiceType,wPosition);
}

//****************************************************************************
/// Get Physical Channel Number
/// @param bServiceType \b IN: Service type
/// -@see MEMBER_SERVICETYPE
/// @param wPosition \b IN: position
/// @return BYTE: Physical Channel Number
//****************************************************************************
BYTE msAPI_CM_GetPhysicalChannelNumber(MEMBER_SERVICETYPE bServiceType, WORD wPosition)
{
    WORD wOrder;
    BYTE cIDIndex;
	DTVPROGRAMID_M *pMuxTable=_astDTVProgramIDTable;
#if DVB_T_C_DIFF_DB
	if (IsCATVInUse())pMuxTable=_astDTVCProgramIDTable;
#endif

    if( FALSE == IsServiceTypeValid(bServiceType) )
    {
        return INVALID_PHYSICAL_CHANNEL_NUMBER;
    }

    if( FALSE == IsPositionValid(bServiceType, wPosition) )
    {
        return INVALID_PHYSICAL_CHANNEL_NUMBER;
    }

    wOrder = ConvertPositionToOrder(bServiceType, wPosition);

    cIDIndex = m_astDTVProgramIndexTable[wOrder].cIDIndex;
#if ENABLE_T_C_COMBO
    if(IsCATVInUse())
    {
        return cIDIndex;
    }
    if( FALSE == IsPhysicalChannelNumberValid(pMuxTable[cIDIndex].cRFChannelNumber) )
    {
        return INVALID_PHYSICAL_CHANNEL_NUMBER;
    }
    return pMuxTable[cIDIndex].cRFChannelNumber;
#elif DVB_C_ENABLE
	return cIDIndex;

#else
    if( FALSE == IsPhysicalChannelNumberValid(pMuxTable[cIDIndex].cRFChannelNumber) )
    {
        return INVALID_PHYSICAL_CHANNEL_NUMBER;
    }

    return pMuxTable[cIDIndex].cRFChannelNumber;
#endif
}

#if  ENABLE_SBTVD_BRAZIL_APP
BYTE msAPI_CM_Get_FirstPhysicalChannelNumber(void)
{

    BYTE i,bMin_Num=0;
	DTVPROGRAMID_M *pMuxTable=_astDTVProgramIDTable;
#if DVB_T_C_DIFF_DB
	if (IsCATVInUse())pMuxTable=_astDTVCProgramIDTable;
#endif

    for(i=0; i<MAX_MUX_NUMBER && pMuxTable[i].cRFChannelNumber != INVALID_PHYSICAL_CHANNEL_NUMBER;i++)
    {
        bMin_Num = pMuxTable[i].cRFChannelNumber;
        if(pMuxTable[i].cRFChannelNumber < bMin_Num)
            bMin_Num = pMuxTable[i].cRFChannelNumber;
    }

    return bMin_Num;


}
#endif


#if ENABLE_SZ_DTV_ADDCH_SCAN_FUNCTION
//****************************************************************************
/// Is empty Physical Channel Number
/// @param bnumber \b IN: Physical Channel Number
/// @return BOOLEAN:
/// - 1: Default Not empty
/// - 0: Others
//****************************************************************************
BOOLEAN msAPI_IsEmptyPhysicalChannelNumber(BYTE bnumber)
{
    BYTE i;
	DTVPROGRAMID_M *pMuxTable=_astDTVProgramIDTable;
#if DVB_T_C_DIFF_DB
	if (IsCATVInUse())pMuxTable=_astDTVCProgramIDTable;
#endif

    for(i=0;i<MAX_MUX_NUMBER;i++)
    {
        if(pMuxTable[i].cRFChannelNumber==number)
            return FALSE;
    }

    return TRUE;
}

//****************************************************************************
/// Get next Physical Channel Number
/// @param cRFChannelNumber \b IN: Physical Channel Number
/// @return BYTE: Physical Channel Number
//****************************************************************************
BYTE msAPI_CM_GetNextEmptyPhysicalChannelNumber(BYTE cRFChannelNumber)
{
    MEMBER_COUNTRY eCountry;
    PHYSICAL_CHANNEL_INFO * pastPhysicalChannelInfoTable;
    BYTE cTableSize;
    BYTE i,j,number;
	DTVPROGRAMID_M *pMuxTable=_astDTVProgramIDTable;
#if DVB_T_C_DIFF_DB
	if (IsCATVInUse())pMuxTable=_astDTVCProgramIDTable;
#endif

    eCountry = msAPI_CM_GetCountry();

    if( FALSE == IsPhysicalChannelNumberValid(eCountry, cRFChannelNumber) )
        return INVALID_PHYSICAL_CHANNEL_NUMBER;

        if( MIN_UHF_PHYSICAL_CHANNEL_NUMBER(eCountry) <= cRFChannelNumber &&
            cRFChannelNumber <= MAX_UHF_PHYSICAL_CHANNEL_NUMBER )
        {
            if( cRFChannelNumber == MAX_UHF_PHYSICAL_CHANNEL_NUMBER )
                return INVALID_PHYSICAL_CHANNEL_NUMBER;

            for(number=cRFChannelNumber+1;number<=MAX_UHF_PHYSICAL_CHANNEL_NUMBER;number++)
            {
                for(j=0;j<MAX_MUX_NUMBER;j++)
                {
                    if(pMuxTable[j].cRFChannelNumber==number)
                        break;
                }
                if(j==MAX_MUX_NUMBER)
             return (number);
            }

            return INVALID_PHYSICAL_CHANNEL_NUMBER;
     }
     else
     {
            cTableSize = GetPhysicalChannelInfoTableForVHF(eCountry, &pastPhysicalChannelInfoTable);

            for(i=0; i < cTableSize; i++)
            {
                if( cRFChannelNumber == pastPhysicalChannelInfoTable[i].cRFChannelNumber )
                {
                    if( (i+1) == cTableSize )
                    {
                        return MIN_UHF_PHYSICAL_CHANNEL_NUMBER(eCountry);
                    }
                }
            }

            for(i=i+1; i < cTableSize; i++)
            {
                number=pastPhysicalChannelInfoTable[i].cRFChannelNumber;
                for(j=0;j<MAX_MUX_NUMBER;j++)
                {
                    if(pMuxTable[j].cRFChannelNumber==number)
                        break;
                }
                if(j==MAX_MUX_NUMBER)
                {
                    return number;
                }
            }
            return MIN_UHF_PHYSICAL_CHANNEL_NUMBER(eCountry);
    }

    return INVALID_PHYSICAL_CHANNEL_NUMBER;
}
#endif
//****************************************************************************
/// Get PSI/SI Version
/// @param bServiceType \b IN: Service type
/// -@see MEMBER_SERVICETYPE
/// @param wPosition \b IN: position
/// @param eVersionMember \b IN: PSI/SI Version member
/// -@see E_MEMBER_PSI_SI_VERSION
/// @return BYTE: PSI/SI Version
//****************************************************************************
BYTE msAPI_CM_GetPSISIVersion(MEMBER_SERVICETYPE bServiceType, WORD wPosition, E_MEMBER_PSI_SI_VERSION eVersionMember)
{
    WORD wOrder,wPRIndex;
    BYTE cVersion;
    PROGRAMDATA_MEMBER eProgramDataMember;

    if( FALSE == IsServiceTypeValid(bServiceType) )
    {
        return INVALID_PSI_SI_VERSION;
    }

    if( FALSE == IsPositionValid(bServiceType, wPosition) )
    {
        return INVALID_PSI_SI_VERSION;
    }

    switch( eVersionMember )
    {
    case E_VERSION_PAT:        eProgramDataMember = E_DATA_VERSION_PAT;        break;
    case E_VERSION_PMT:        eProgramDataMember = E_DATA_VERSION_PMT;        break;
    case E_VERSION_NIT:        eProgramDataMember = E_DATA_VERSION_NIT;        break;
    case E_VERSION_SDT:        eProgramDataMember = E_DATA_VERSION_SDT;        break;
    default:
        return INVALID_PSI_SI_VERSION;
    }

    wOrder = ConvertPositionToOrder(bServiceType, wPosition);

    wPRIndex = m_astDTVProgramIndexTable[wOrder].wPRIndex;

    if( TRUE != GetProgramTable(wPRIndex, &cVersion, eProgramDataMember) )
    {
        return INVALID_PSI_SI_VERSION;
    }

    if( FALSE == IsVersionValid(cVersion) )
    {
        return INVALID_PSI_SI_VERSION;
    }
    return cVersion;
}

//****************************************************************************
/// Get Program Attribute
/// @param bServiceType \b IN: Service type
/// -@see MEMBER_SERVICETYPE
/// @param wPosition \b IN: position
/// @param eAttributeMember \b IN: Channel Attribute member
/// -@seeE_MEMBER_CHANNEL_ATTRIBUTE
/// @return BOOLEAN:
/// - 1: Default attribute is
/// - 0: Others
//****************************************************************************
BOOLEAN msAPI_CM_GetProgramAttribute(MEMBER_SERVICETYPE bServiceType, WORD wPosition, E_MEMBER_CHANNEL_ATTRIBUTE eAttributeMember)
{
    BOOLEAN bIsValidParameter, bRet;
    WORD wOrder;

    bIsValidParameter = TRUE;
    bIsValidParameter &= IsServiceTypeValid(bServiceType);
    bIsValidParameter &= IsPositionValid(bServiceType, wPosition);

    wOrder = ConvertPositionToOrder(bServiceType, wPosition);

    switch(eAttributeMember)
    {
    case E_ATTRIBUTE_IS_VISIBLE:
        if( FALSE == bIsValidParameter )
        {
            bRet = DEFAULT_VISIBLE_SERVICE_FLAG;
        }
        else
        {
            bRet = m_astDTVProgramIndexTable[wOrder].bVisibleServiceFlag;
        }
        break;

    case E_ATTRIBUTE_IS_NUMERIC_SELECTION:
        if( FALSE == bIsValidParameter )
        {
            bRet = DEFAULT_NUMERIC_SELECTION_FLAG;
        }
        else
        {
            bRet = m_astDTVProgramIndexTable[wOrder].bNumericSelectionFlag;
        }
        break;

    case E_ATTRIBUTE_IS_DELETED:
        if( FALSE == bIsValidParameter )
        {
            bRet = DEFAULT_IS_DELETED;
        }
        else
        {

            bRet = m_astDTVProgramIndexTable[wOrder].bIsDelete;
        }
        break;
    case E_ATTRIBUTE_IS_REPLACE_DEL:
        if( FALSE == bIsValidParameter )
        {
            bRet = DEFAULT_IS_REPLACE_DEL;
        }
        else
        {
            bRet = m_astDTVProgramIndexTable[wOrder].bIsReplaceDel;
        }
        break;
#if (CM_MULTI_FAVORITE)
    case E_ATTRIBUTE_IS_FAVORITE1:
    case E_ATTRIBUTE_IS_FAVORITE2:
    case E_ATTRIBUTE_IS_FAVORITE3:
    case E_ATTRIBUTE_IS_FAVORITE4:
        if( FALSE == bIsValidParameter )
        {
            bRet = DEFAULT_IS_FAVORITE;
        }
        else
        {
            bRet = (GETBIT(m_astDTVProgramIndexTable[wOrder].bIsFavorite, eAttributeMember-E_ATTRIBUTE_IS_FAVORITE1) > 0);
        }
        break;
#else
    case E_ATTRIBUTE_IS_FAVORITE:
        if( FALSE == bIsValidParameter )
        {
            bRet = DEFAULT_IS_FAVORITE;
        }
        else
        {

            bRet = m_astDTVProgramIndexTable[wOrder].bIsFavorite;
        }
        break;
#endif

    case E_ATTRIBUTE_IS_SKIPPED:
        if( FALSE == bIsValidParameter )
        {
            bRet = DEFAULT_IS_SKIPPED;
        }
        else
        {
            bRet = m_astDTVProgramIndexTable[wOrder].bIsSkipped;
        }
        break;

    case E_ATTRIBUTE_IS_LOCKED:
        if( FALSE == bIsValidParameter )
        {
            bRet = DEFAULT_IS_LOCKED;
        }
        else
        {
            bRet = m_astDTVProgramIndexTable[wOrder].bIsLock;
        }
        break;

    case E_ATTRIBUTE_IS_SCRAMBLED:
        if( FALSE == bIsValidParameter )
        {
            bRet = DEFAULT_IS_SCRAMBLED;
        }
        else
        {
            bRet = m_astDTVProgramIndexTable[wOrder].bIsScramble;
        }
        break;

    case E_ATTRIBUTE_IS_STILL_PICTURE:
        if( FALSE == bIsValidParameter )
        {
            bRet = DEFAULT_IS_STILL_PICTURE;
        }
        else
        {
            bRet = m_astDTVProgramIndexTable[wOrder].bIsStillPicture;
        }
        break;

    case E_ATTRIBUTE_IS_REPLACE_SERVICE:
        if( FALSE == bIsValidParameter )
        {
            bRet = DEFAULT_IS_REPLACE_SERVICE;
        }
        else
        {
            bRet = m_astDTVProgramIndexTable[wOrder].bReplaceService;
        }
        break;

    case E_ATTRIBUTE_IS_SERVICE_ID_ONLY:
        if( FALSE == bIsValidParameter )
        {
            bRet = DEFAULT_IS_SERVICE_ID_ONLY;
        }
        else
        {
            bRet = m_astDTVProgramIndexTable[wOrder].bIsServiceIdOnly;
        }
        break;
    case E_ATTRIBUTE_IS_UNCONFIRMED_SERVICE:
        if( FALSE == bIsValidParameter )
        {
            bRet = DEFAULT_IS_UNCONFIRMED_SERVICE;
        }
        else
        {
            bRet = m_astDTVProgramIndexTable[wOrder].bUnconfirmedService;
        }
        break;
    case E_ATTRIBUTE_IS_INVALID_SERVICE:
        if( FALSE == bIsValidParameter )
        {
            bRet = DEFAULT_IS_INVALID_SERVICE;
        }
        else
        {
            bRet = m_astDTVProgramIndexTable[wOrder].bInvalidService;
        }
        break;
    case E_ATTRIBUTE_IS_MOVED:
        if( FALSE == bIsValidParameter )
        {
            bRet = DEFAULT_IS_MOVED;
        }
        else
        {
            bRet = m_astDTVProgramIndexTable[wOrder].bIsMove;
        }
        break;
    case E_ATTRIBUTE_IS_SPECIAL_CH:
        if( FALSE == bIsValidParameter )
        {
            bRet = DEFAULT_SPECIAL_SERVICE;
        }
        else
        {
            bRet = m_astDTVProgramIndexTable[wOrder].bIsSpecialService;
        }
        break;

#if ENABLE_T_C_CHANNEL_MIX
    case E_ATTRIBUTE_IS_TERRESTRIAL:
        if( FALSE == bIsValidParameter )
        {
            bRet = DEFAULT_IS_CABLE;
        }
        else
        {
            bRet = m_astDTVProgramIndexTable[wOrder].bIsTerrestrial;
        }
        break;
#endif
    case E_ATTRIBUTE_IS_LCN_VALID:
        {
            CHANNEL_ATTRIBUTE Misc;
            GetProgramTable(wOrder, (BYTE *)&Misc, E_DATA_MISC);
            bRet = Misc.bValidLCN;
        }
        break;
    default:
        bRet = FALSE;
        break;
    }

    return bRet;
}


//****************************************************************************
/// Get Program Video type
/// @param bServiceType \b IN: Service type
/// -@see MEMBER_SERVICETYPE
/// @param wPosition \b IN: position
/// @return VIDEO_TYPE:
/// -@see VIDEO_TYPE
//****************************************************************************
VIDEO_TYPE msAPI_CM_GetProgramVideoType(MEMBER_SERVICETYPE bServiceType, WORD wPosition)
{
    BOOLEAN bIsValidParameter;
    WORD wOrder;
    VIDEO_TYPE bRet;
    bIsValidParameter = TRUE;
    bIsValidParameter &= IsServiceTypeValid(bServiceType);
    bIsValidParameter &= IsPositionValid(bServiceType, wPosition);

    wOrder = ConvertPositionToOrder(bServiceType, wPosition);

    if( FALSE == bIsValidParameter )
    {
        bRet = DEFAULT_VIDEO_TYPE;
    }
    else
    {
        bRet = (VIDEO_TYPE)m_astDTVProgramIndexTable[wOrder].eVideoType;
    }

    return bRet;
}
//****************************************************************************
/// Get Pmt PID
/// @param bServiceType \b IN: Service type
/// -@see MEMBER_SERVICETYPE
/// @param wPosition \b IN: position
/// @return WORD: Pmt PID
//****************************************************************************
WORD msAPI_CM_GetPmtPID(MEMBER_SERVICETYPE bServiceType, WORD wPosition)
{
    WORD wOrder;
    WORD wPmt_PID,wPRIndex;

    if( FALSE == IsServiceTypeValid(bServiceType) )
    {
        return INVALID_PID;
    }

    if( FALSE == IsPositionValid(bServiceType, wPosition) )
    {
        return INVALID_PID;
    }

    wOrder = ConvertPositionToOrder(bServiceType, wPosition);


    wPRIndex = m_astDTVProgramIndexTable[wOrder].wPRIndex;


    if( TRUE != GetProgramTable(wPRIndex, (BYTE *)&wPmt_PID, E_DATA_PMT_PID) )
    {
        return INVALID_PID;
    }

    if( FALSE == IsPMT_PIDValid(wPmt_PID) )
    {
        return INVALID_PID;
    }

    return wPmt_PID;
}


//****************************************************************************
/// Get PCR PID
/// @param bServiceType \b IN: Service type
/// -@see MEMBER_SERVICETYPE
/// @param wPosition \b IN: position
/// @return WORD: PCR PID
//****************************************************************************
WORD msAPI_CM_GetPCR_PID(MEMBER_SERVICETYPE bServiceType, WORD wPosition)
{
    WORD wOrder;
    WORD wPCR_PID,wPRIndex;

    if( FALSE == IsServiceTypeValid(bServiceType) )
    {
        return INVALID_PID;
    }

    if( FALSE == IsPositionValid(bServiceType, wPosition) )
    {
        return INVALID_PID;
    }

    wOrder = ConvertPositionToOrder(bServiceType, wPosition);

    wPRIndex = m_astDTVProgramIndexTable[wOrder].wPRIndex;

    if( TRUE != GetProgramTable(wPRIndex, (BYTE *)&wPCR_PID, E_DATA_PCR_PID) )
    {
        return INVALID_PID;
    }

    if( FALSE == IsPCR_PIDValid(wPCR_PID) )
    {
        return INVALID_PID;
    }

    return wPCR_PID;
}

//****************************************************************************
/// Get Video PID
/// @param bServiceType \b IN: Service type
/// -@see MEMBER_SERVICETYPE
/// @param wPosition \b IN: position
/// @return WORD: Video PID
//****************************************************************************
WORD msAPI_CM_GetVideoPID(MEMBER_SERVICETYPE bServiceType, WORD wPosition)
{
    WORD wOrder;
    WORD wVideo_PID,wPRIndex;

    if( FALSE == IsServiceTypeValid(bServiceType) )
    {
        return INVALID_PID;
    }

    if( FALSE == IsPositionValid(bServiceType, wPosition) )
    {
        return INVALID_PID;
    }

    wOrder = ConvertPositionToOrder(bServiceType, wPosition);

    wPRIndex = m_astDTVProgramIndexTable[wOrder].wPRIndex;

    if( TRUE != GetProgramTable(wPRIndex, (BYTE *)&wVideo_PID, E_DATA_VIDEO_PID) )
    {
        return INVALID_PID;
    }

    if( FALSE == IsVideoPIDValid(wVideo_PID) )
    {
        return INVALID_PID;
    }
    return wVideo_PID;
}

//****************************************************************************
/// Get Service ID
/// @param bServiceType \b IN: Service type
/// -@see MEMBER_SERVICETYPE
/// @param wPosition \b IN: position
/// @return WORD: Service ID
//****************************************************************************
WORD msAPI_CM_GetService_ID(MEMBER_SERVICETYPE bServiceType, WORD wPosition)
{
    WORD wOrder, wService_ID;

    if( FALSE == IsServiceTypeValid(bServiceType) )
    {
        return INVALID_SERVICE_ID;
    }

    if( FALSE == IsPositionValid(bServiceType, wPosition) )
    {
        return INVALID_SERVICE_ID;
    }

    wOrder = ConvertPositionToOrder(bServiceType, wPosition);

    wService_ID = m_astDTVProgramIndexTable[wOrder].wService_ID;

    if( FALSE == IsService_IDValid(wService_ID) )
    {
        return INVALID_SERVICE_ID;
    }

    return wService_ID;
}

//****************************************************************************
/// Get TS ID
/// @param bServiceType \b IN: Service type
/// -@see MEMBER_SERVICETYPE
/// @param wPosition \b IN: position
/// @return WORD: TS ID
//****************************************************************************
WORD msAPI_CM_GetTS_ID(MEMBER_SERVICETYPE bServiceType, WORD wPosition)
{
    WORD wOrder;
    BYTE cIDIndex;
	DTVPROGRAMID_M *pMuxTable=_astDTVProgramIDTable;
#if DVB_T_C_DIFF_DB
	if (IsCATVInUse())pMuxTable=_astDTVCProgramIDTable;
#endif

    if( FALSE == IsServiceTypeValid(bServiceType) )
    {
        return INVALID_TS_ID;
    }

    if( FALSE == IsPositionValid(bServiceType, wPosition) )
    {
        return INVALID_TS_ID;
    }

    wOrder = ConvertPositionToOrder(bServiceType, wPosition);
    cIDIndex = m_astDTVProgramIndexTable[wOrder].cIDIndex;

    if( FALSE == IsTS_IDValid(pMuxTable[cIDIndex].wTransportStream_ID) )
    {
        return INVALID_TS_ID;
    }

    return pMuxTable[cIDIndex].wTransportStream_ID;
}

//****************************************************************************
/// Get ON ID
/// @param bServiceType \b IN: Service type
/// -@see MEMBER_SERVICETYPE
/// @param wPosition \b IN: position
/// @return WORD: ON ID
//****************************************************************************
WORD msAPI_CM_GetON_ID(MEMBER_SERVICETYPE bServiceType, WORD wPosition)
{
    WORD wOrder;
    BYTE cIDIndex;
	DTVPROGRAMID_M *pMuxTable=_astDTVProgramIDTable;
#if DVB_T_C_DIFF_DB
	if (IsCATVInUse())pMuxTable=_astDTVCProgramIDTable;
#endif

    if( FALSE == IsServiceTypeValid(bServiceType) )
    {
        return INVALID_ON_ID;
    }

    if( FALSE == IsPositionValid(bServiceType, wPosition) )
    {
        return INVALID_ON_ID;
    }

    wOrder = ConvertPositionToOrder(bServiceType, wPosition);
    cIDIndex = m_astDTVProgramIndexTable[wOrder].cIDIndex;

    if( FALSE == IsON_IDValid(pMuxTable[cIDIndex].wOriginalNetwork_ID) )
    {
        return INVALID_ON_ID;
    }

    return pMuxTable[cIDIndex].wOriginalNetwork_ID;
}

//****************************************************************************
/// Get Network ID
/// @param bServiceType \b IN: Service type
/// -@see MEMBER_SERVICETYPE
/// @param wPosition \b IN: position
/// @return WORD: Network ID
//****************************************************************************
WORD msAPI_CM_GetNetwork_ID(MEMBER_SERVICETYPE bServiceType, WORD wPosition)
{
    WORD wOrder;
    BYTE cIDIndex;
	DTVPROGRAMID_M *pMuxTable=_astDTVProgramIDTable;
#if DVB_T_C_DIFF_DB
	if (IsCATVInUse())pMuxTable=_astDTVCProgramIDTable;
#endif

    if( FALSE == IsServiceTypeValid(bServiceType) )
    {
        return INVALID_NID;
    }

    if( FALSE == IsPositionValid(bServiceType, wPosition) )
    {
        return INVALID_NID;
    }

    wOrder = ConvertPositionToOrder(bServiceType, wPosition);
    cIDIndex = m_astDTVProgramIndexTable[wOrder].cIDIndex;

    if( FALSE == IsON_IDValid(_astDTVNetwork[pMuxTable[cIDIndex].cNetWorkIndex].wNetwork_ID) )
    {
        return INVALID_NID;
    }

    return _astDTVNetwork[pMuxTable[cIDIndex].cNetWorkIndex].wNetwork_ID;
}

//****************************************************************************
/// Get Cell ID Infomation
/// @param bServiceType \b IN: Service type
/// -@see MEMBER_SERVICETYPE
/// @param wPosition \b IN: position
/// @param *pwCellID \b IN: pointer to cell ID information for return
/// @return BOOLEAN: Function execution result
//****************************************************************************
BOOLEAN msAPI_CM_GetCellIDByPosition(MEMBER_SERVICETYPE bServiceType, WORD wPosition, WORD *pwCellID)
{
    WORD wOrder;
    BYTE cIDIndex;
	DTVPROGRAMID_M *pMuxTable=_astDTVProgramIDTable;
#if DVB_T_C_DIFF_DB
	if (IsCATVInUse())pMuxTable=_astDTVCProgramIDTable;
#endif
    if( FALSE == IsServiceTypeValid(bServiceType) )
    {
        return FALSE;
    }

    if( FALSE == IsPositionValid(bServiceType, wPosition) )
    {
        return FALSE;
    }
    wOrder = ConvertPositionToOrder(bServiceType, wPosition);
    cIDIndex = m_astDTVProgramIndexTable[wOrder].cIDIndex;
    *pwCellID=pMuxTable[cIDIndex].wCellID;
    return TRUE;
}

//****************************************************************************
/// Get plp ID Infomation via TSID and ONID
/// @param wTS_ID \b IN: transport stream ID
/// @param wON_ID \b IN: original network ID
/// @param *pu8PLP_ID \b IN: pointer to plp ID information for return
/// @return BOOLEAN: Function execution result
//****************************************************************************
BOOLEAN msAPI_CM_GetPLPID_WithID(WORD wTS_ID, WORD wON_ID, U8* pu8PLP_ID)
{
    int i;
	DTVPROGRAMID_M *pMuxTable=_astDTVProgramIDTable;
#if DVB_T_C_DIFF_DB
	if (IsCATVInUse())pMuxTable=_astDTVCProgramIDTable;
#endif
    for(i=0;i<MAX_MUX_NUMBER;i++)
    {
        if((pMuxTable[i].wTransportStream_ID  == wTS_ID)
            && (pMuxTable[i].wOriginalNetwork_ID== wON_ID))
        {
            *pu8PLP_ID=pMuxTable[i].cPLPID;
            return TRUE;
        }
    }
    return FALSE;
}
//****************************************************************************
/// Get HpLP Infomation via TSID and ONID
/// @param wTS_ID \b IN: transport stream ID
/// @param wON_ID \b IN: original network ID
/// @param *pu8HpLP \b IN: pointer to HpLp information for return
/// @return BOOLEAN: Function execution result
//****************************************************************************
BOOLEAN msAPI_CM_GetHpLP_WithID(WORD wTS_ID, WORD wON_ID, U8* pu8HpLp)
{
    int i;
	DTVPROGRAMID_M *pMuxTable=_astDTVProgramIDTable;
#if DVB_T_C_DIFF_DB
	if (IsCATVInUse())pMuxTable=_astDTVCProgramIDTable;
#endif
    for(i=0;i<MAX_MUX_NUMBER;i++)
    {
        if((pMuxTable[i].wTransportStream_ID  == wTS_ID)
            && (pMuxTable[i].wOriginalNetwork_ID== wON_ID))
        {
            *pu8HpLp=pMuxTable[i].cHpLp;
            return TRUE;
        }
    }
    return FALSE;
}

//****************************************************************************
/// Get PLP ID
/// @param bServiceType \b IN: Service type
/// -@see MEMBER_SERVICETYPE
/// @param wPosition \b IN: position
/// @return WORD: PLP ID
//****************************************************************************
WORD msAPI_CM_GetPLP_ID(MEMBER_SERVICETYPE bServiceType, WORD wPosition)
{
    WORD wOrder;
    BYTE cIDIndex;
	DTVPROGRAMID_M *pMuxTable=_astDTVProgramIDTable;
#if DVB_T_C_DIFF_DB
	if (IsCATVInUse())pMuxTable=_astDTVCProgramIDTable;
#endif

    if( FALSE == IsServiceTypeValid(bServiceType) )
    {
        return 0;
    }

    if( FALSE == IsPositionValid(bServiceType, wPosition) )
    {
        return 0;
    }

    wOrder = ConvertPositionToOrder(bServiceType, wPosition);
    cIDIndex = m_astDTVProgramIndexTable[wOrder].cIDIndex;

    return pMuxTable[cIDIndex].cPLPID;
}



//****************************************************************************
/// Get HP/LP
/// @param bServiceType \b IN: Service type
/// -@see MEMBER_SERVICETYPE
/// @param wPosition \b IN: position
/// @return BYTE: HP/LP 0=>HP, 1=>LP
//****************************************************************************
BYTE msAPI_CM_GetHpLp(MEMBER_SERVICETYPE bServiceType, WORD wPosition)
{
    WORD wOrder;
    BYTE cIDIndex;
	DTVPROGRAMID_M *pMuxTable=_astDTVProgramIDTable;
#if DVB_T_C_DIFF_DB
	if (IsCATVInUse())pMuxTable=_astDTVCProgramIDTable;
#endif

    if( FALSE == IsServiceTypeValid(bServiceType) )
    {
        return 0;
    }

    if( FALSE == IsPositionValid(bServiceType, wPosition) )
    {
        return 0;
    }

    wOrder = ConvertPositionToOrder(bServiceType, wPosition);
    cIDIndex = m_astDTVProgramIndexTable[wOrder].cIDIndex;

    return pMuxTable[cIDIndex].cHpLp;
}


//****************************************************************************
/// Get Audio stream count
/// @param bServiceType \b IN: Service type
/// -@see MEMBER_SERVICETYPE
/// @param wPosition \b IN: position
/// @return BYTE: Audio stream count
//****************************************************************************
BYTE msAPI_CM_GetAudioStreamCount(MEMBER_SERVICETYPE bServiceType, WORD wPosition)
{
    AUD_INFO stAudInfo[MAX_AUD_LANG_NUM];
    WORD wOrder, wPRIndex;
    BYTE i;
    BYTE cAudioStreamCount;

    if( FALSE == IsServiceTypeValid(bServiceType) )
    {
        return 0;
    }

    if( FALSE == IsPositionValid(bServiceType, wPosition) )
    {
        return 0;
    }

    wOrder = ConvertPositionToOrder(bServiceType, wPosition);
    wPRIndex = m_astDTVProgramIndexTable[wOrder].wPRIndex;
    GetProgramTable(wPRIndex, (BYTE *)stAudInfo, E_DATA_AUDIO_STREAM_INFO);
    cAudioStreamCount = 0;
    for(i=0; i < MAX_AUD_LANG_NUM; i++)
    {
        if( (TRUE == IsAudioPIDValid(stAudInfo[i].wAudPID)) &&
            (GETBIT(_u16ValidAudioIndex,i)) &&
            ((E_AUDIOSTREAM_MPEG == stAudInfo[i].wAudType) ||
             (E_AUDIOSTREAM_AC3 == stAudInfo[i].wAudType)  ||
             (E_AUDIOSTREAM_AC3P == stAudInfo[i].wAudType) ||
             (E_AUDIOSTREAM_MPEG4 == stAudInfo[i].wAudType) ||
             (E_AUDIOSTREAM_AAC == stAudInfo[i].wAudType)) )
        {
            cAudioStreamCount++;
//            printf("stAudInfo[%u].wAudPID=%u wAudType=%u \n",i,stAudInfo[i].wAudPID,stAudInfo[i].wAudType);
        }
        else
        {
            break;
        }
    }

    return cAudioStreamCount;
}



//****************************************************************************
/// Get Audio Stream Infomation
/// @param bServiceType \b IN: Service type
/// -@see MEMBER_SERVICETYPE
/// @param wPosition \b IN: position
/// @param *pstAudioStreamInfo \b IN: pointer to Audio stream information for return
/// -@see AUD_INFO
/// @param cOrdinal \b IN: Ordinal
/// @return BOOLEAN: Function execution result
//****************************************************************************
BOOLEAN msAPI_CM_GetAudioStreamInfo(MEMBER_SERVICETYPE bServiceType, WORD wPosition, AUD_INFO * pstAudioStreamInfo, BYTE cOrdinal)
{
    AUD_INFO stAudInfo[MAX_AUD_LANG_NUM];
    WORD wOrder,wPRIndex;

    FillAudioStreamInfoWithDefault(pstAudioStreamInfo);

    if( FALSE == IsServiceTypeValid(bServiceType) )
    {
        return FALSE;
    }

    if( FALSE == IsPositionValid(bServiceType, wPosition) )
    {
        return FALSE;
    }

    if( MAX_AUD_LANG_NUM <= cOrdinal)
    {
        return FALSE;
    }

    wOrder = ConvertPositionToOrder(bServiceType, wPosition);

    wPRIndex = m_astDTVProgramIndexTable[wOrder].wPRIndex;

    GetProgramTable(wPRIndex, (BYTE *)stAudInfo, E_DATA_AUDIO_STREAM_INFO);

    if( (TRUE == IsAudioPIDValid(stAudInfo[cOrdinal].wAudPID)) &&
        (GETBIT(_u16ValidAudioIndex,cOrdinal)) &&
        ((E_AUDIOSTREAM_MPEG == stAudInfo[cOrdinal].wAudType) ||
         (E_AUDIOSTREAM_AC3 == stAudInfo[cOrdinal].wAudType)  ||
         (E_AUDIOSTREAM_AC3P == stAudInfo[cOrdinal].wAudType) ||
         (E_AUDIOSTREAM_MPEG4 == stAudInfo[cOrdinal].wAudType) ||
         (E_AUDIOSTREAM_AAC == stAudInfo[cOrdinal].wAudType)) )
    {
        *pstAudioStreamInfo = stAudInfo[cOrdinal];

        return TRUE;
    }

    return FALSE;
}


//****************************************************************************
/// Get Program Infomation
/// @param bServiceType \b IN: Service type
/// -@see MEMBER_SERVICETYPE
/// @param wPosition \b IN: position
/// @param *pChannelInfo \b IN: pointer to Audio program information for return
/// -@see DTV_CHANNEL_INFO
/// @return BOOLEAN: Function execution result
//****************************************************************************
BOOLEAN msAPI_CM_GetProgramInfo(MEMBER_SERVICETYPE bServiceType, WORD wPosition,DTV_CHANNEL_INFO *pChannelInfo)
{
    WORD wOrder;
    WORD wPRIndex;

    if( FALSE == IsServiceTypeValid(bServiceType) )
    {
        return FALSE;
    }

    if( FALSE == IsPositionValid(bServiceType, wPosition) )
    {
        return FALSE;
    }

    wOrder = ConvertPositionToOrder(bServiceType, wPosition);

    wPRIndex = m_astDTVProgramIndexTable[wOrder].wPRIndex;

    if( TRUE != GetProgramTable(wPRIndex, (BYTE *)pChannelInfo, E_DATA_ALL) )
    {
        return FALSE;
    }
    return TRUE;
}

//****************************************************************************
/// Arrange Audio Stream Infomation
/// @param bServiceType \b IN: Service type
/// -@see MEMBER_SERVICETYPE
/// @param wPosition \b IN: position
/// @param stValidAudioInfo \b IN: pointer to Valid Audio Information
/// -@see AUD_VALID_INFO
/// @return BOOLEAN: Function execution result
//****************************************************************************
BOOLEAN msAPI_CM_ArrangeAudioStreamInfo(MEMBER_SERVICETYPE bServiceType, WORD wPosition, U16 cValidAudIndex)
{
    AUD_INFO stAudInfoNew[MAX_AUD_LANG_NUM],stAudInfo[MAX_AUD_LANG_NUM];
    WORD wOrder,wPRIndex;
    BYTE bAudioNum,i,bValidIndex,bInvalidIndex;
    BOOLEAN result;

    if( FALSE == IsServiceTypeValid(bServiceType) )
    {
        return FALSE;
    }

    if( FALSE == IsPositionValid(bServiceType, wPosition) )
    {
        return FALSE;
    }

    wOrder = ConvertPositionToOrder(bServiceType, wPosition);


    wPRIndex = m_astDTVProgramIndexTable[wOrder].wPRIndex;


    GetProgramTable(wPRIndex, (BYTE *)stAudInfo, E_DATA_AUDIO_STREAM_INFO);

    bAudioNum = 0;
    for(i=0; i < MAX_AUD_LANG_NUM; i++)
    {
        if( (TRUE == IsAudioPIDValid(stAudInfo[i].wAudPID)) &&
            ((E_AUDIOSTREAM_MPEG == stAudInfo[i].wAudType) ||
             (E_AUDIOSTREAM_AC3 == stAudInfo[i].wAudType)  ||
             (E_AUDIOSTREAM_AC3P == stAudInfo[i].wAudType) ||
             (E_AUDIOSTREAM_MPEG4 == stAudInfo[i].wAudType) ||
             (E_AUDIOSTREAM_AAC == stAudInfo[i].wAudType)) )
        {
            bAudioNum++;
        }
        else
        {
            break;
        }
    }
    if(bAudioNum ==0)
    {
        return FALSE;
    }
    _u16ValidAudioIndex=0;
    bValidIndex=0;
    bInvalidIndex=bAudioNum-1;
    memset(stAudInfoNew,0,sizeof(AUD_INFO)*MAX_AUD_LANG_NUM);
    for(i=0; i < bAudioNum; i++)
    {
        if( (TRUE == IsAudioPIDValid(stAudInfo[i].wAudPID)) &&
            (GETBIT(cValidAudIndex,i))  &&
            ((E_AUDIOSTREAM_MPEG == stAudInfo[i].wAudType ) ||
             (E_AUDIOSTREAM_AC3 == stAudInfo[i].wAudType )  ||
             (E_AUDIOSTREAM_AC3P == stAudInfo[i].wAudType ) ||
             (E_AUDIOSTREAM_MPEG4 == stAudInfo[i].wAudType ) ||
             (E_AUDIOSTREAM_AAC == stAudInfo[i].wAudType )) )
        {
            stAudInfoNew[bValidIndex]=stAudInfo[i];
            SETBIT(_u16ValidAudioIndex,bValidIndex);
            bValidIndex++;

        }
        else
        {
            stAudInfoNew[bInvalidIndex]=stAudInfo[i];
            CLRBIT(_u16ValidAudioIndex,bInvalidIndex);
            bInvalidIndex--;
        }
    }
    _bSaveDataToFlash=FALSE;
    result = SetProgramTable(wPRIndex, (BYTE*)stAudInfoNew, E_DATA_AUDIO_STREAM_INFO);;
    _bSaveDataToFlash=TRUE;
    return result;
    //return SetProgramTable(wPRIndex, (BYTE*)stAudInfoNew, E_DATA_AUDIO_STREAM_INFO);
}

//****************************************************************************
/// Get Next Audio Stream ordinal
/// @param bServiceType \b IN: Service type
/// -@see MEMBER_SERVICETYPE
/// @param wPosition \b IN: position
/// @param cBaseOrdinal \b IN: Base Ordinal
/// @return BYTE: Next Audio stream ordinal
//****************************************************************************
BYTE msAPI_CM_GetNextAudioStreamOrdinal(MEMBER_SERVICETYPE bServiceType, WORD wPosition, BYTE cBaseOrdinal)
{
    AUD_INFO stAudInfo[MAX_AUD_LANG_NUM];
    WORD wOrder,wPRIndex;
    BYTE i;
    BYTE cOrdinal;
    BYTE cAudioStreamCount;

    if( MAX_AUD_LANG_NUM <= cBaseOrdinal)
    {
        return DEFAULT_SELECTED_AUDIO_STREAM;
    }

    if( FALSE == IsServiceTypeValid(bServiceType) )
    {
        return cBaseOrdinal;
    }

    if( FALSE == IsPositionValid(bServiceType, wPosition) )
    {
        return cBaseOrdinal;
    }

    wOrder = ConvertPositionToOrder(bServiceType, wPosition);
    wPRIndex = m_astDTVProgramIndexTable[wOrder].wPRIndex;
    GetProgramTable(wPRIndex, (BYTE *)stAudInfo, E_DATA_AUDIO_STREAM_INFO);
    cOrdinal = cBaseOrdinal;
    cAudioStreamCount = msAPI_CM_GetAudioStreamCount(bServiceType, wPosition);

    for(i=0; i < cAudioStreamCount; i++)
    {
        cOrdinal++;
        if( cOrdinal >= cAudioStreamCount || cOrdinal >= MAX_AUD_LANG_NUM)
        {
            cOrdinal = 0;
        }

        if( (TRUE == IsAudioPIDValid(stAudInfo[cOrdinal].wAudPID)) &&
            (GETBIT(_u16ValidAudioIndex,cOrdinal)) &&
            ((E_AUDIOSTREAM_MPEG == stAudInfo[cOrdinal].wAudType) ||
             (E_AUDIOSTREAM_AC3P == stAudInfo[cOrdinal].wAudType) ||
             (E_AUDIOSTREAM_MPEG4 == stAudInfo[cOrdinal].wAudType) ||
             (E_AUDIOSTREAM_AAC == stAudInfo[cOrdinal].wAudType) ||
             (E_AUDIOSTREAM_AC3 == stAudInfo[cOrdinal].wAudType)) )
        {
            return cOrdinal;
        }
    }

    return cBaseOrdinal;
}

//****************************************************************************
/// Get Previous Audio Stream ordinal
/// @param bServiceType \b IN: Service type
/// -@see MEMBER_SERVICETYPE
/// @param wPosition \b IN: position
/// @param cBaseOrdinal \b IN: Base Ordinal
/// @return BYTE: Previous Audio stream ordinal
//****************************************************************************
BYTE msAPI_CM_GetPrevAudioStreamOrdinal(MEMBER_SERVICETYPE bServiceType, WORD wPosition, BYTE cBaseOrdinal)
{
    AUD_INFO stAudInfo[MAX_AUD_LANG_NUM];
    WORD wOrder,wPRIndex;
    BYTE i;
    BYTE cOrdinal;
    BYTE cAudioStreamCount;

    if( MAX_AUD_LANG_NUM <= cBaseOrdinal)
    {
        return DEFAULT_SELECTED_AUDIO_STREAM;
    }

    if( FALSE == IsServiceTypeValid(bServiceType) )
    {
        return cBaseOrdinal;
    }

    if( FALSE == IsPositionValid(bServiceType, wPosition) )
    {
        return cBaseOrdinal;
    }

    wOrder = ConvertPositionToOrder(bServiceType, wPosition);

    wPRIndex = m_astDTVProgramIndexTable[wOrder].wPRIndex;

    GetProgramTable(wPRIndex, (BYTE *)stAudInfo, E_DATA_AUDIO_STREAM_INFO);
    cOrdinal = cBaseOrdinal;
    cAudioStreamCount = msAPI_CM_GetAudioStreamCount(bServiceType, wPosition);

    for(i=0; i < cAudioStreamCount; i++)
    {
        if( cOrdinal > 0 )
        {
            cOrdinal--;
        }
        else
        {
            cOrdinal = cAudioStreamCount-1;
        }

        if( (TRUE == IsAudioPIDValid(stAudInfo[cOrdinal].wAudPID)) &&
            ((E_AUDIOSTREAM_MPEG == stAudInfo[cOrdinal].wAudType) ||
             (E_AUDIOSTREAM_AC3P == stAudInfo[cOrdinal].wAudType) ||
             (E_AUDIOSTREAM_MPEG4 == stAudInfo[cOrdinal].wAudType) ||
             (E_AUDIOSTREAM_AAC == stAudInfo[cOrdinal].wAudType) ||
             (E_AUDIOSTREAM_AC3 == stAudInfo[cOrdinal].wAudType)) )
        {
            return cOrdinal;
        }
    }

    return cBaseOrdinal;
}

//****************************************************************************
/// Get Service name
/// @param bServiceType \b IN: Service type
/// -@see MEMBER_SERVICETYPE
/// @param wPosition \b IN: position
/// @param *bChannelName \b IN: pointer to Channel name for return
/// @return BOOLEAN: Function execution result
//****************************************************************************
BOOLEAN msAPI_CM_GetServiceName(MEMBER_SERVICETYPE bServiceType, WORD wPosition, BYTE * bChannelName)
{
    WORD wOrder,wPRIndex;
    BYTE i;
#if ENABLE_SAVE_MULTILINGUAL_SERVICE_NAME
	BYTE aLang[MAX_MULTI_LINGUAL_SERVICE_NAME];
	BYTE aName[MAX_MULTI_LINGUAL_SERVICE_NAME][MAX_SERVICE_NAME];
#endif
    if( FALSE == IsServiceTypeValid(bServiceType) )
    {
        return FALSE;
    }

    if( FALSE == IsPositionValid(bServiceType, wPosition) )
    {
        return FALSE;
    }

    for(i=0; i < MAX_SERVICE_NAME; i++)
    {
        bChannelName[i] = NULL;
    }

    wOrder = ConvertPositionToOrder(bServiceType, wPosition);
    wPRIndex = m_astDTVProgramIndexTable[wOrder].wPRIndex;
#if ENABLE_SAVE_MULTILINGUAL_SERVICE_NAME
	GetProgramTable(wPRIndex, (BYTE *)aLang, E_DATA_NAME_MULTILINGUAL_LANGUAGE);
	GetProgramTable(wPRIndex, (BYTE *)aName, E_DATA_SERVICE_MULTILINGUAL_NAME);
	for(i=0;i<MAX_MULTI_LINGUAL_SERVICE_NAME;i++)
	{
		if(aLang[i]==(U8)GET_OSD_MENU_LANGUAGE())
		{
			memcpy(bChannelName,aName[i],MAX_SERVICE_NAME);
			//printf("lang %x name %s %x %x %x %x %x\n",aLang[i],
			//	aName[i],aName[0],aName[1],aName[2],aName[3],aName[4]);
			return TRUE;
		}
	}
#endif
    return GetProgramTable(wPRIndex, (BYTE *)bChannelName, E_DATA_SERVICE_NAME);

}

//****************************************************************************
/// Delete program
/// @param bServiceType \b IN: Service type
/// -@see MEMBER_SERVICETYPE
/// @param wPosition \b IN: position
/// @param fIsDelete \b IN: delete or not
/// @return BOOLEAN: Function execution result
//****************************************************************************
BOOLEAN msAPI_CM_DeleteProgram(MEMBER_SERVICETYPE bServiceType, WORD wPosition,MS_U8 fIsDelete)
{
    CHANNEL_ATTRIBUTE stCHAttribute;
    WORD wFromOrder,wPRIndex;
    WORD wToOrder;
    WORD wDeletedPosition;

    /* For complier happy */
    fIsDelete = fIsDelete;

    if( FALSE == IsServiceTypeValid(bServiceType) )
    {
        return FALSE;
    }

    if( FALSE == IsPositionValid(bServiceType, wPosition) )
    {
        return FALSE;
    }

    wDeletedPosition = GetProgramCount(bServiceType, INCLUDE_ALL) - 1;

    wFromOrder = ConvertPositionToOrder(bServiceType, wPosition);
    wToOrder = ConvertPositionToOrder(bServiceType, wDeletedPosition);
    MoveProgram(wFromOrder, wToOrder);
//#if (ENABLE_DTV_EPG)
    //MApp_Epg_MoveSrvBuffer(wFromOrder, wToOrder);
//#endif  //#if (ENABLE_DTV_EPG)
    UpdateOrderOfProgramTable(bServiceType);

    wPRIndex = m_astDTVProgramIndexTable[wToOrder].wPRIndex;
    GetProgramTable(wPRIndex, (BYTE *)&stCHAttribute, E_DATA_MISC);
    stCHAttribute.bIsDelete = TRUE;
    m_astDTVProgramIndexTable[wToOrder].bIsDelete = stCHAttribute.bIsDelete;

    if( TRUE != SetProgramTable(wPRIndex, (BYTE *)&stCHAttribute, E_DATA_MISC) )
    {
        return FALSE;
    }

    UpdateProgramCount(bServiceType);

    return TRUE;
}

//****************************************************************************
/// This function will set Replace Del
/// @param bServiceType \b IN: Service type
/// -@see MEMBER_SERVICETYPE
/// @param wPosition \b IN: position
/// @param bDel \b IN: it's a Replace Del program or not
/// @return BOOLEAN: Function execution result
//****************************************************************************
BOOLEAN msAPI_CM_ReplaceDelProgram(MEMBER_SERVICETYPE bServiceType, WORD wPosition, BOOLEAN bDel)
{
    CHANNEL_ATTRIBUTE stCHAttribute;
    WORD wOrder,wPRIndex;

    if( FALSE == IsServiceTypeValid(bServiceType) )
    {
        return FALSE;
    }

    if( FALSE == IsPositionValid(bServiceType, wPosition) )
    {
        return FALSE;
    }

    wOrder = ConvertPositionToOrder(bServiceType, wPosition);

    wPRIndex = m_astDTVProgramIndexTable[wOrder].wPRIndex;
    GetProgramTable(wPRIndex, (BYTE *)&stCHAttribute, E_DATA_MISC);

    if( bDel == TRUE )
    {
        stCHAttribute.bIsReplaceDel = TRUE;
    }
    else
    {
        stCHAttribute.bIsReplaceDel = FALSE;
    }

    m_astDTVProgramIndexTable[wOrder].bIsReplaceDel = stCHAttribute.bIsReplaceDel;

    UpdateProgramCount(bServiceType);

    return SetProgramTable(wPRIndex, (BYTE *)&stCHAttribute, E_DATA_MISC);
}

//****************************************************************************
/// This function will Recovery Del program
/// @param bServiceType \b IN: Service type
/// -@see MEMBER_SERVICETYPE
/// @param wPosition \b IN: position
/// @return BOOLEAN: Function execution result
//****************************************************************************
BOOLEAN msAPI_CM_RecoveryDelProgram(MEMBER_SERVICETYPE bServiceType, WORD wPosition)
{
    CHANNEL_ATTRIBUTE stCHAttribute;
    WORD wPRIndex;
    WORD wRecoveryPosition;
    U16 u16Service_ID,u16TS_ID,u16ON_ID,u16CurPosition;
    MEMBER_SERVICETYPE bCurServiceType;

    bCurServiceType = msAPI_CM_GetCurrentServiceType();
    u16CurPosition = msAPI_CM_GetCurrentPosition(bCurServiceType);
    u16Service_ID = msAPI_CM_GetService_ID(bCurServiceType,u16CurPosition);
    u16ON_ID = msAPI_CM_GetON_ID(bCurServiceType,u16CurPosition);
    u16TS_ID = msAPI_CM_GetTS_ID(bCurServiceType,u16CurPosition);

    if( FALSE == IsServiceTypeValid(bServiceType) )
    {
        return FALSE;
    }

    if( FALSE == IsPositionValid(bServiceType, wPosition) )
    {
        return FALSE;
    }
    wRecoveryPosition = ConvertPositionToOrder(bServiceType, wPosition);

    wPRIndex = m_astDTVProgramIndexTable[wRecoveryPosition].wPRIndex;
    GetProgramTable(wPRIndex, (BYTE *)&stCHAttribute, E_DATA_MISC);
    stCHAttribute.bIsDelete = FALSE;
    m_astDTVProgramIndexTable[wRecoveryPosition].bIsDelete = stCHAttribute.bIsDelete;

    if( TRUE != SetProgramTable(wPRIndex, (BYTE *)&stCHAttribute, E_DATA_MISC) )
    {
        return FALSE;
    }

    UpdateProgramCount(bServiceType);
    msAPI_CM_ArrangeDataManager(TRUE,FALSE);

    return TRUE;
}

//****************************************************************************
/// This function will set service ID only program
/// @param bServiceType \b IN: Service type
/// -@see MEMBER_SERVICETYPE
/// @param wPosition \b IN: position
/// @param IsServiceIdOnly \b IN: it's a service ID only program or not
/// @return BOOLEAN: Function execution result
//****************************************************************************
BOOLEAN msAPI_CM_ServiceIDOnlyProgram(MEMBER_SERVICETYPE bServiceType, WORD wPosition,MS_U8 IsServiceIdOnly)
{
    CHANNEL_ATTRIBUTE stCHAttribute;
    WORD wOrder,wPRIndex;

    if( FALSE == IsServiceTypeValid(bServiceType) )
    {
        return FALSE;
    }

    if( FALSE == IsPositionValid(bServiceType, wPosition) )
    {
        return FALSE;
    }

    wOrder = ConvertPositionToOrder(bServiceType, wPosition);

    wPRIndex = m_astDTVProgramIndexTable[wOrder].wPRIndex;
    m_astDTVProgramIndexTable[wOrder].bIsServiceIdOnly=IsServiceIdOnly;

    GetProgramTable(wPRIndex, (BYTE *)&stCHAttribute, E_DATA_MISC);
    stCHAttribute.bIsServiceIdOnly = IsServiceIdOnly;

    if( TRUE != SetProgramTable(wPRIndex, (BYTE *)&stCHAttribute, E_DATA_MISC) )
    {
        return FALSE;
    }

    return TRUE;
}

//****************************************************************************
/// This function will set scramble program
/// @param bServiceType \b IN: Service type
/// -@see MEMBER_SERVICETYPE
/// @param wPosition \b IN: position
/// @param IsScramble \b IN: it's a scramble program or not
/// @return BOOLEAN: Function execution result
//****************************************************************************
BOOLEAN msAPI_CM_ScrambleProgram(MEMBER_SERVICETYPE bServiceType, WORD wPosition,MS_U8 IsScramble)
{
    CHANNEL_ATTRIBUTE stCHAttribute;
    WORD wOrder,wPRIndex;

    if( FALSE == IsServiceTypeValid(bServiceType) )
    {
        return FALSE;
    }

    if( FALSE == IsPositionValid(bServiceType, wPosition) )
    {
        return FALSE;
    }

    wOrder = ConvertPositionToOrder(bServiceType, wPosition);

    wPRIndex = m_astDTVProgramIndexTable[wOrder].wPRIndex;

    GetProgramTable(wPRIndex, (BYTE *)&stCHAttribute, E_DATA_MISC);
    stCHAttribute.bIsScramble = IsScramble;
    m_astDTVProgramIndexTable[wOrder].bIsScramble = stCHAttribute.bIsScramble;

    if( TRUE != SetProgramTable(wPRIndex, (BYTE *)&stCHAttribute, E_DATA_MISC) )
    {
        return FALSE;
    }

    return TRUE;
}




//****************************************************************************
/// This function will set Video Type
/// @param bServiceType \b IN: Service type
/// -@see MEMBER_SERVICETYPE
/// @param wPosition \b IN: position
/// @param u8VideoType \b IN: video type
/// -@see VIDEO_TYPE
/// @return BOOLEAN: Function execution result
//****************************************************************************
BOOLEAN msAPI_CM_SetProgramVideoType(MEMBER_SERVICETYPE bServiceType, WORD wPosition,U8 u8VideoType)
{
    CHANNEL_ATTRIBUTE stCHAttribute;
    WORD wOrder,wPRIndex;

    if( FALSE == IsServiceTypeValid(bServiceType) )
    {
        return FALSE;
    }

    if( FALSE == IsPositionValid(bServiceType, wPosition) )
    {
        return FALSE;
    }

    wOrder = ConvertPositionToOrder(bServiceType, wPosition);

    wPRIndex = m_astDTVProgramIndexTable[wOrder].wPRIndex;

    GetProgramTable(wPRIndex, (BYTE *)&stCHAttribute, E_DATA_MISC);
    m_astDTVProgramIndexTable[wOrder].eVideoType=stCHAttribute.eVideoType = u8VideoType;
    if( TRUE != SetProgramTable(wPRIndex, (BYTE *)&stCHAttribute, E_DATA_MISC) )
    {
        return FALSE;
    }
    return TRUE;
}


#if (CM_MULTI_FAVORITE)
//****************************************************************************
/// This function will set Favorite program
/// @param bServiceType \b IN: Service type
/// -@see MEMBER_SERVICETYPE
/// @param wPosition \b IN: position
/// @param bFavorite \b IN: it's a favorite program or not
/// @param eFavorType \b IN: set eFavorite Type
/// -@see E_FAVORITE_TYPE
/// @return BOOLEAN: Function execution result
//****************************************************************************
BOOLEAN msAPI_CM_FavorProgram(MEMBER_SERVICETYPE bServiceType, WORD wPosition, BOOLEAN bFavorite, E_FAVORITE_TYPE eFavorType)
{
    CHANNEL_ATTRIBUTE stCHAttribute;
    WORD wOrder,wPRIndex;

    if( FALSE == IsServiceTypeValid(bServiceType) )
    {
        return FALSE;
    }

    if( FALSE == IsPositionValid(bServiceType, wPosition) )
    {
        return FALSE;
    }

    wOrder = ConvertPositionToOrder(bServiceType, wPosition);

    wPRIndex = m_astDTVProgramIndexTable[wOrder].wPRIndex;
    GetProgramTable(wPRIndex, (BYTE *)&stCHAttribute, E_DATA_MISC);

    if( bFavorite == TRUE )
    {
        if (eFavorType == E_FAVORITE_TYPE_ALL)
        {
            stCHAttribute.bIsFavorite |= BITMASK(E_FAVORITE_TYPE_4:E_FAVORITE_TYPE_1);
        }
        else
        {
            SETBIT(stCHAttribute.bIsFavorite, eFavorType);
        }
    }
    else
    {
        if (eFavorType == E_FAVORITE_TYPE_ALL)
        {
            stCHAttribute.bIsFavorite &= ~BITMASK(E_FAVORITE_TYPE_4:E_FAVORITE_TYPE_1);
        }
        else
        {
            CLRBIT(stCHAttribute.bIsFavorite, eFavorType);
        }
    }

    m_astDTVProgramIndexTable[wOrder].bIsFavorite = stCHAttribute.bIsFavorite;

    return SetProgramTable(wPRIndex, (BYTE *)&stCHAttribute, E_DATA_MISC);
}
#else
//****************************************************************************
/// This function will set Favorite program
/// @param bServiceType \b IN: Service type
/// -@see MEMBER_SERVICETYPE
/// @param wPosition \b IN: position
/// @param bFavorite \b IN: it's a favorite program or not
/// @return BOOLEAN: Function execution result
//****************************************************************************
BOOLEAN msAPI_CM_FavorProgram(MEMBER_SERVICETYPE bServiceType, WORD wPosition, BOOLEAN bFavorite)
{
    CHANNEL_ATTRIBUTE stCHAttribute;
    WORD wOrder,wPRIndex;

    if( FALSE == IsServiceTypeValid(bServiceType) )
    {
        return FALSE;
    }

    if( FALSE == IsPositionValid(bServiceType, wPosition) )
    {
        return FALSE;
    }

    wOrder = ConvertPositionToOrder(bServiceType, wPosition);

    wPRIndex = m_astDTVProgramIndexTable[wOrder].wPRIndex;
    GetProgramTable(wPRIndex, (BYTE *)&stCHAttribute, E_DATA_MISC);

    if( bFavorite == TRUE )
    {
        stCHAttribute.bIsFavorite = TRUE;
    }
    else
    {
        stCHAttribute.bIsFavorite = FALSE;
    }
    m_astDTVProgramIndexTable[wOrder].bIsFavorite = stCHAttribute.bIsFavorite;

    return SetProgramTable(wPRIndex, (BYTE *)&stCHAttribute, E_DATA_MISC);
}
#endif

//****************************************************************************
/// This function will set skip program
/// @param bServiceType \b IN: Service type
/// -@see MEMBER_SERVICETYPE
/// @param wPosition \b IN: position
/// @param bSkip \b IN: it's a skip program or not
/// @return BOOLEAN: Function execution result
//****************************************************************************
BOOLEAN msAPI_CM_SkipProgram(MEMBER_SERVICETYPE bServiceType, WORD wPosition, BOOLEAN bSkip)
{
    CHANNEL_ATTRIBUTE stCHAttribute;
    WORD wOrder,wPRIndex;

    if( FALSE == IsServiceTypeValid(bServiceType) )
    {
        return FALSE;
    }

    if( FALSE == IsPositionValid(bServiceType, wPosition) )
    {
        return FALSE;
    }

    wOrder = ConvertPositionToOrder(bServiceType, wPosition);

    wPRIndex = m_astDTVProgramIndexTable[wOrder].wPRIndex;
    GetProgramTable(wPRIndex, (BYTE *)&stCHAttribute, E_DATA_MISC);

    if( bSkip == TRUE )
    {
        stCHAttribute.bIsSkipped = TRUE;
    }
    else
    {
        stCHAttribute.bIsSkipped = FALSE;
    }

    m_astDTVProgramIndexTable[wOrder].bIsSkipped = stCHAttribute.bIsSkipped;

    return SetProgramTable(wPRIndex, (BYTE *)&stCHAttribute, E_DATA_MISC);
}

//****************************************************************************
/// This function will update program Visible or Selectable
/// @param bServiceType \b IN: Service type
/// -@see MEMBER_SERVICETYPE
/// @param wPosition \b IN: position
/// @param bVisible \b IN: it's a bVisible program or not
/// @param bSelectable \b IN: it's a bSelectable program or not
/// @return BOOLEAN: Function execution result
//****************************************************************************
BOOLEAN msAPI_CM_UpdateProgramVisibleAndSelectable(MEMBER_SERVICETYPE bServiceType, WORD wPosition, BOOLEAN bVisible, BOOLEAN bSelectable)
{
    CHANNEL_ATTRIBUTE stCHAttribute;
    WORD wOrder,wPRIndex;
    BOOLEAN bUpdate=FALSE;


    if( FALSE == IsServiceTypeValid(bServiceType) )
    {
        return FALSE;
    }

    if( FALSE == IsPositionValid(bServiceType, wPosition) )
    {
        return FALSE;
    }
    wOrder = ConvertPositionToOrder(bServiceType, wPosition);

    wPRIndex = m_astDTVProgramIndexTable[wOrder].wPRIndex;

    GetProgramTable(wPRIndex, (BYTE *)&stCHAttribute, E_DATA_MISC);
    if(stCHAttribute.bInvalidService && (bVisible || bSelectable))
    {
        return FALSE;
    }
    //printf("v..%bu %bu\n",stCHAttribute.bVisibleServiceFlag,stCHAttribute.bNumericSelectionFlag);
    if(stCHAttribute.bVisibleServiceFlag != bVisible)
    {
        m_astDTVProgramIndexTable[wOrder].bVisibleServiceFlag=stCHAttribute.bVisibleServiceFlag = bVisible;
        bUpdate=TRUE;
    }
    if(stCHAttribute.bNumericSelectionFlag != bSelectable)
    {
        m_astDTVProgramIndexTable[wOrder].bNumericSelectionFlag=stCHAttribute.bNumericSelectionFlag = bSelectable;
        bUpdate=TRUE;
    }

    if(bUpdate)
    {
       UpdateProgramCount(bServiceType);
       return SetProgramTable(wPRIndex, (BYTE *)&stCHAttribute, E_DATA_MISC);
    }

    return TRUE;
}

BOOLEAN msAPI_CM_UpdateProgramSpecialService(MEMBER_SERVICETYPE bServiceType, WORD wPosition, BOOLEAN bSpecialService)
{
    CHANNEL_ATTRIBUTE stCHAttribute;
    WORD wOrder,wPRIndex;
    BOOLEAN bUpdate=FALSE;
    if( FALSE == IsServiceTypeValid(bServiceType) )
    {
        return FALSE;
    }

    if( FALSE == IsPositionValid(bServiceType, wPosition) )
    {
        return FALSE;
    }
    wOrder = ConvertPositionToOrder(bServiceType, wPosition);
    {
        wPRIndex = m_astDTVProgramIndexTable[wOrder].wPRIndex;
        GetProgramTable(wPRIndex, (BYTE *)&stCHAttribute, E_DATA_MISC);
        //printf("v..%bu \n",stCHAttribute.bIsSpecialService);
        if(stCHAttribute.bIsSpecialService != bSpecialService)
        {
            m_astDTVProgramIndexTable[wOrder].bIsSpecialService=stCHAttribute.bIsSpecialService = bSpecialService;
            bUpdate=TRUE;
        }
    }
    if(bUpdate)
    {
        UpdateProgramCount(bServiceType);
        return SetProgramTable(wPRIndex, (BYTE *)&stCHAttribute, E_DATA_MISC);
    }

    return TRUE;
}

//****************************************************************************
/// This function will set lock program
/// @param bServiceType \b IN: Service type
/// -@see MEMBER_SERVICETYPE
/// @param wPosition \b IN: position
/// @param bLock \b IN: it's a bLock program or not
/// @return BOOLEAN: Function execution result
//****************************************************************************
BOOLEAN msAPI_CM_LockProgram(MEMBER_SERVICETYPE bServiceType, WORD wPosition, BOOLEAN bLock)
{
    CHANNEL_ATTRIBUTE stCHAttribute;
    WORD wOrder,wPRIndex;

    if( FALSE == IsServiceTypeValid(bServiceType) )
    {
        return FALSE;
    }

    if( FALSE == IsPositionValid(bServiceType, wPosition) )
    {
        return FALSE;
    }

    wOrder = ConvertPositionToOrder(bServiceType, wPosition);

    wPRIndex = m_astDTVProgramIndexTable[wOrder].wPRIndex;

    GetProgramTable(wPRIndex, (BYTE *)&stCHAttribute, E_DATA_MISC);

    if( bLock == TRUE )
    {
        stCHAttribute.bIsLock = TRUE;
    }
    else
    {
        stCHAttribute.bIsLock = FALSE;
    }

    m_astDTVProgramIndexTable[wOrder].bIsLock = stCHAttribute.bIsLock;

    return SetProgramTable(wPRIndex, (BYTE *)&stCHAttribute, E_DATA_MISC);
}

static void _FillNextValidOrderToProgramData(DTV_CHANNEL_INFO *pDTVProgramData, WORD wPRIndex)
{
    S32 s32Order;
    MEMBER_SERVICETYPE eServiceType;
    WORD wServiceID;

    if (NULL == pDTVProgramData)
        return;
    eServiceType = (MEMBER_SERVICETYPE)pDTVProgramData->stCHAttribute.bServiceType;
    wServiceID = pDTVProgramData->wService_ID;

    if (eServiceType == E_SERVICETYPE_DTV)
    {
        WORD wOrderOfTV=FIRST_ORDER_OF_TV;
        for(s32Order=wOrderOfTV; s32Order < MAX_DTVPROGRAM; s32Order++)
        {
            if((DEFAULT_SERVICE_TYPE == m_astDTVProgramIndexTable[s32Order].bServiceType) &&
                (FALSE == IsProgramEntityActive(m_astDTVProgramIndexTable[s32Order].wPRIndex)) )
            {
                m_astDTVProgramIndexTable[s32Order].bServiceType = eServiceType;
                m_astDTVProgramIndexTable[s32Order].wService_ID = wServiceID;
                m_astDTVProgramIndexTable[s32Order].wPRIndex = wPRIndex;
                m_astDTVProgramIndexTable[s32Order].cIDIndex = pDTVProgramData->bIDIdex;
                pDTVProgramData->wOrder = (WORD)s32Order;
                return;
            }
            else if(((E_SERVICETYPE_RADIO == m_astDTVProgramIndexTable[s32Order].bServiceType) ||
                (E_SERVICETYPE_DATA == m_astDTVProgramIndexTable[s32Order].bServiceType))&&
                (TRUE == IsProgramEntityActive(m_astDTVProgramIndexTable[s32Order].wPRIndex)))
            {
                MS_DEBUG_MSG(printf("No empty dtv order be found\n"));
                return;
            }
        }
    }
    else if (eServiceType == E_SERVICETYPE_RADIO)
    {
        WORD wOrderOfRadio = FIRST_ORDER_OF_RADIO;
        for(s32Order=0; s32Order < MAX_DTVPROGRAM; s32Order++)
        {
            if((E_SERVICETYPE_DATA == m_astDTVProgramIndexTable[s32Order].bServiceType) &&
                (TRUE == IsProgramEntityActive(m_astDTVProgramIndexTable[s32Order].wPRIndex)) )
            {
                wOrderOfRadio--;
            }
        }

        for(s32Order=wOrderOfRadio; s32Order >=FIRST_ORDER_OF_TV; s32Order--)
        {
            if((DEFAULT_SERVICE_TYPE == m_astDTVProgramIndexTable[s32Order].bServiceType) &&
                (FALSE == IsProgramEntityActive(m_astDTVProgramIndexTable[s32Order].wPRIndex)) )
            {
                m_astDTVProgramIndexTable[s32Order].bServiceType = eServiceType;
                m_astDTVProgramIndexTable[s32Order].wService_ID = wServiceID;
                m_astDTVProgramIndexTable[s32Order].wPRIndex = wPRIndex;
                m_astDTVProgramIndexTable[s32Order].cIDIndex = pDTVProgramData->bIDIdex;
                pDTVProgramData->wOrder = (WORD)s32Order;
                return;
            }
            else if((E_SERVICETYPE_DTV == m_astDTVProgramIndexTable[s32Order].bServiceType) &&
                (TRUE == IsProgramEntityActive(m_astDTVProgramIndexTable[s32Order].wPRIndex)))
            {
                MS_DEBUG_MSG(printf("No empty radio order be found\n"));
                return;
            }
        }
    }
    else if (eServiceType == E_SERVICETYPE_DATA)
    {
        WORD wOrderOfData = FIRST_ORDER_OF_DATA;
        for(s32Order=wOrderOfData; s32Order >=FIRST_ORDER_OF_TV; s32Order--)
        {
            if((DEFAULT_SERVICE_TYPE == m_astDTVProgramIndexTable[s32Order].bServiceType) &&
                (FALSE == IsProgramEntityActive(m_astDTVProgramIndexTable[s32Order].wPRIndex)) )
            {
                m_astDTVProgramIndexTable[s32Order].bServiceType = eServiceType;
                m_astDTVProgramIndexTable[s32Order].wService_ID = wServiceID;
                m_astDTVProgramIndexTable[s32Order].wPRIndex = wPRIndex;
                m_astDTVProgramIndexTable[s32Order].cIDIndex = pDTVProgramData->bIDIdex;
                pDTVProgramData->wOrder = (WORD)s32Order;
                return;
            }
            else if(((E_SERVICETYPE_DTV == m_astDTVProgramIndexTable[s32Order].bServiceType) ||
                (E_SERVICETYPE_RADIO == m_astDTVProgramIndexTable[s32Order].bServiceType)) &&
                (TRUE == IsProgramEntityActive(m_astDTVProgramIndexTable[s32Order].wPRIndex)))
            {
                MS_DEBUG_MSG(printf("No empty data order be found\n"));
                return;
            }
        }
    }
    else
    {
        pDTVProgramData->wOrder = DEFAULT_ORDER;
        return;
    }
}

//****************************************************************************
/// This function will add program
/// @param *pDTVProgramData \b IN: pointer to DTV program data
/// -@see DTV_CHANNEL_INFO
/// @return BOOLEAN: Function execution result
//****************************************************************************
BOOLEAN msAPI_CM_AddProgram(DTV_CHANNEL_INFO *pDTVProgramData, BOOLEAN *bDBFull, BOOLEAN bSkipCheck)
{
    MEMBER_COUNTRY eCountry;
    BOOLEAN bIsValid,bIsValidService=TRUE;;
    WORD wPRIndex,l_wPosition;
    BOOLEAN bUpdateCurrentService;

    DTVPROGRAMID_M *pMuxTable=_astDTVProgramIDTable;
#if DVB_T_C_DIFF_DB
    if (IsCATVInUse())pMuxTable=_astDTVCProgramIDTable;
#endif

    //remove old same service
    //printf("pDTVProgramData->bIDIdex...%d\n",pDTVProgramData->bIDIdex);
    bUpdateCurrentService=_RemoveService(pDTVProgramData->bIDIdex,pDTVProgramData->wService_ID);

    if(bUpdateCurrentService)
    {
        if(msAPI_CM_GetFirstPositionInPCN(E_SERVICETYPE_DTV, pMuxTable[pDTVProgramData->bIDIdex].cRFChannelNumber, &l_wPosition))
        {
            msAPI_CM_SetCurrentServiceType(E_SERVICETYPE_DTV);
            msAPI_CM_SetCurrentPosition(E_SERVICETYPE_DTV,l_wPosition);
        }
        else if(msAPI_CM_GetFirstPositionInPCN(E_SERVICETYPE_RADIO, pMuxTable[pDTVProgramData->bIDIdex].cRFChannelNumber, &l_wPosition))
        {
            msAPI_CM_SetCurrentServiceType(E_SERVICETYPE_RADIO);
            msAPI_CM_SetCurrentPosition(E_SERVICETYPE_RADIO,l_wPosition);
        }
        else if(msAPI_CM_GetFirstPositionInPCN(E_SERVICETYPE_DATA, pMuxTable[pDTVProgramData->bIDIdex].cRFChannelNumber, &l_wPosition))
        {
            msAPI_CM_SetCurrentServiceType(E_SERVICETYPE_DATA);
            msAPI_CM_SetCurrentPosition(E_SERVICETYPE_DATA,l_wPosition);
        }
        else
        {
            //should not have this case
        }
    }


    eCountry = msAPI_CM_GetCountry();

    if(msAPI_CM_GetCountry() == E_FRANCE)
    {
        float ber;
        if(msAPI_Tuner_GetBER(&ber))
        {
            if(ber > 0.0002)
            {
                pDTVProgramData->stCHAttribute.wSignalStrength=pDTVProgramData->stCHAttribute.wSignalStrength&0x7F00;
            }
        }
    }

    wPRIndex = GetEmptyIndexOfProgramTable();
    if( MAX_DTVPROGRAM <= wPRIndex || INVALID_PRINDEX == wPRIndex )
    {
        *bDBFull=TRUE;
        return FALSE;
    }
    *bDBFull=FALSE;
    bIsValid = TRUE;

    bIsValid &= IsServiceTypeValid((MEMBER_SERVICETYPE)pDTVProgramData->stCHAttribute.bServiceType);

    bIsValid &= IsService_IDValid(pDTVProgramData->wService_ID);

    if(bSkipCheck == FALSE)
    {
        bIsValidService &= IsLogicalChannelNumberValid(pDTVProgramData->wLCN);

        bIsValidService &= IsVersionValid(pDTVProgramData->stPSI_SI_Version.bPATVer);

        bIsValidService &= IsVersionValid(pDTVProgramData->stPSI_SI_Version.bPMTVer);

        bIsValidService &= IsVersionValid(pDTVProgramData->stPSI_SI_Version.bNITVer);

        bIsValidService &= IsVersionValid(pDTVProgramData->stPSI_SI_Version.bSDTVer);

        bIsValidService &= IsService_IDValid(pDTVProgramData->wService_ID);

        bIsValidService &= IsPMT_PIDValid(pDTVProgramData->wPmt_PID);

        bIsValidService &= IsPCR_PIDValid(pDTVProgramData->wPCR_PID);

        if( pDTVProgramData->stCHAttribute.bServiceType == E_SERVICETYPE_DTV )
        {
            bIsValidService &= IsVideoPIDValid(pDTVProgramData->wVideo_PID);

        }
        bIsValidService &= IsAudioStreamInfoValid(pDTVProgramData->stAudInfo);

    }
/*
printf("add service valid %d idindex %x sid %x lcn %d simulcn %d name %s\n",bIsValidService,
    pDTVProgramData->bIDIdex,pDTVProgramData->wService_ID,
    pDTVProgramData->wLCN,pDTVProgramData->wSimu_LCN,pDTVProgramData->bChannelName
    );
*/
    if( FALSE == bIsValid)
    {
        return FALSE;
    }
    if( FALSE == bIsValidService)
    {
        pDTVProgramData->stCHAttribute.bInvalidService=TRUE;
        pDTVProgramData->stCHAttribute.bVisibleServiceFlag=FALSE;
        pDTVProgramData->stCHAttribute.bNumericSelectionFlag=FALSE;
    }
    bIsValidService=pDTVProgramData->stCHAttribute.bInvalidService ? FALSE: TRUE;
    eCountry = msAPI_CM_GetCountry();



    switch(eCountry)
    {
    case E_FINLAND:
    case E_SWEDEN:
    case E_DENMARK:
    case E_NORWAY:
        if( INVALID_LOGICAL_CHANNEL_NUMBER != pDTVProgramData->wLCN &&
            9999 < pDTVProgramData->wLCN )
        {
            pDTVProgramData->wLCN &= 0x3FF;
        }
        break;

    default:
        #if (ENABLE_SBTVD_BRAZIL_APP == 0)
        // Outside Nordig countries, LCN > 999 is Illegal. Set Invalid.
        if( INVALID_LOGICAL_CHANNEL_NUMBER != pDTVProgramData->wLCN &&
            999 < pDTVProgramData->wLCN )
        {
            pDTVProgramData->wLCN = INVALID_LOGICAL_CHANNEL_NUMBER;
        }
        #endif
        break;
    }
    _FillNextValidOrderToProgramData(pDTVProgramData, wPRIndex);
    if( TRUE != SetProgramTable(wPRIndex, (BYTE *)pDTVProgramData, E_DATA_ALL) )
    {
        return FALSE;
    }

    ActiveProgramEntity(wPRIndex, TRUE);
    UpdateProgramCount((MEMBER_SERVICETYPE)pDTVProgramData->stCHAttribute.bServiceType);
    return bIsValidService;
}

static BOOLEAN _IsCountryNetworkService(WORD wNID)
{
	MEMBER_COUNTRY eCountry;
	eCountry = msAPI_CM_GetCountry();
	switch(eCountry)
	{
		case E_ITALY:
			if((wNID>=ITALY_NETWORK_START)&&(wNID<=ITALY_NETWORK_END))
			{
				return TRUE;
			}
			return FALSE;
		default:
			return TRUE;
	}

}


//****************************************************************************
/// This function will check it have duplicate LCN program(different service)
/// @param bServiceType \b IN: Service type
/// -@see MEMBER_SERVICETYPE
/// @param wStartLCN \b IN: start number to check
/// @return DTV_SIMPLE_SERVICE_INFO*: list point of duplicate service
//****************************************************************************
DTV_SIMPLE_SERVICE_INFO* msAPI_CM_GetDuplicateService(MEMBER_SERVICETYPE bServiceType, WORD wStartLCN)
{
	DWORD index1,index2;
	DTV_CHANNEL_INFO stCHInfo;
	WORD NextLCN;
	DTV_SIMPLE_SERVICE_INFO *pItem,*pNext;
	WORD wCountryVisibleService,wCountryInvisibleService,wOtherCountryVisibleService;
	DTVPROGRAMID_M *pMuxTable=_astDTVProgramIDTable;
#if DVB_T_C_DIFF_DB
	if (IsCATVInUse())pMuxTable=_astDTVCProgramIDTable;
#endif
	if(wStartLCN==1)//first
	{
		memset(m_astDTVProgramIndexTable,0,sizeof(DTVPROGRAMINDEX)*MAX_DTVPROGRAM);
		for(index1=0; index1 < MAX_DTVPROGRAM; index1++)//collect channel
		{
			m_astDTVProgramIndexTable[index1].bServiceType=E_SERVICETYPE_INVALID;
			if(IsProgramEntityActive(index1))
			{
				if(GetProgramTable(index1, (BYTE*)&stCHInfo, E_DATA_ALL))
				{
					if(stCHInfo.stCHAttribute.bServiceType == bServiceType)
					{
						m_astDTVProgramIndexTable[index1].wService_ID=stCHInfo.wService_ID;
						m_astDTVProgramIndexTable[index1].wLCN=stCHInfo.wLCN;
						m_astDTVProgramIndexTable[index1].cIDIndex=stCHInfo.bIDIdex;
						m_astDTVProgramIndexTable[index1].bServiceType=stCHInfo.stCHAttribute.bServiceType;
						m_astDTVProgramIndexTable[index1].bVisibleServiceFlag=stCHInfo.stCHAttribute.bVisibleServiceFlag;
					}
				}
			}
		}
		for(index1=0; index1 < (MAX_DTVPROGRAM-1); index1++)//set same service
		{
			if(m_astDTVProgramIndexTable[index1].bServiceType==bServiceType)
			{
				for(index2=index1+1; index2 < MAX_DTVPROGRAM; index2++)//set same service
				{
					if(m_astDTVProgramIndexTable[index2].bServiceType==bServiceType)
					{
						if(m_astDTVProgramIndexTable[index1].wService_ID==m_astDTVProgramIndexTable[index2].wService_ID)
						{
							if(pMuxTable[m_astDTVProgramIndexTable[index1].cIDIndex].wTransportStream_ID == \
								pMuxTable[m_astDTVProgramIndexTable[index2].cIDIndex].wTransportStream_ID && \
								pMuxTable[m_astDTVProgramIndexTable[index1].cIDIndex].wOriginalNetwork_ID == \
								pMuxTable[m_astDTVProgramIndexTable[index2].cIDIndex].wOriginalNetwork_ID)
							{
								CHANNEL_ATTRIBUTE Misc1,Misc2;
								WORD wNID_1=INVALID_NID,wNID_2=INVALID_NID;
								GetProgramTable(index1, (BYTE *)&Misc1, E_DATA_MISC);
								GetProgramTable(index2, (BYTE *)&Misc2, E_DATA_MISC);
								if(pMuxTable[m_astDTVProgramIndexTable[index1].cIDIndex].cNetWorkIndex < INVALID_NETWORKINDEX)
								{
									wNID_1=_astDTVNetwork[pMuxTable[m_astDTVProgramIndexTable[index1].cIDIndex].cNetWorkIndex].wNetwork_ID;
								}
								if(pMuxTable[m_astDTVProgramIndexTable[index2].cIDIndex].cNetWorkIndex < INVALID_NETWORKINDEX)
								{
									wNID_2=_astDTVNetwork[pMuxTable[m_astDTVProgramIndexTable[index2].cIDIndex].cNetWorkIndex].wNetwork_ID;
								}
								if(SelectBestMux(&Misc1,wNID_1,&Misc2,wNID_2)>0)
								{
									m_astDTVProgramIndexTable[index1].eLCNAssignmentType|=E_LCN_SAME_SERVICE;
								}
								else
								{
									m_astDTVProgramIndexTable[index2].eLCNAssignmentType|=E_LCN_SAME_SERVICE;
								}
							}
						}
					}
				}
			}
		}
	}

Restart:
	wCountryVisibleService=0;
	wCountryInvisibleService=0;
	wOtherCountryVisibleService=0;
	while(_pDuplicateServiceList)//free old service
	{
		pItem=_pDuplicateServiceList;
		_pDuplicateServiceList=_pDuplicateServiceList->next;
		msAPI_Memory_Free(pItem,(EN_BUFFER_ID)0);
	}
	NextLCN=INVALID_LOGICAL_CHANNEL_NUMBER;
    for(index1=0; index1 < MAX_DTVPROGRAM; index1++)//find next LCN
    {
    	if(m_astDTVProgramIndexTable[index1].bServiceType == bServiceType)
		{
			if(m_astDTVProgramIndexTable[index1].wLCN>=wStartLCN && \
				m_astDTVProgramIndexTable[index1].wLCN<NextLCN)
			{
				NextLCN=m_astDTVProgramIndexTable[index1].wLCN;
			}
		}
    }
    if(NextLCN==INVALID_LOGICAL_CHANNEL_NUMBER)
    {
        return NULL;//no more duplicate LCN
    }

	for(index1=0; index1 < MAX_DTVPROGRAM; index1++)
	{
		if((m_astDTVProgramIndexTable[index1].wLCN==NextLCN)&&(m_astDTVProgramIndexTable[index1].bServiceType == bServiceType))
		{
			if(!(m_astDTVProgramIndexTable[index1].eLCNAssignmentType&E_LCN_SAME_SERVICE))
			{
				BOOLEAN bCountryService;
				if(pMuxTable[m_astDTVProgramIndexTable[index1].cIDIndex].cNetWorkIndex<MAX_NETWOEK_NUMBER)
				{
					//printf("network id %x name %s\n",_astDTVNetwork[pMuxTable[m_astDTVProgramIndexTable[index1].cIDIndex].cNetWorkIndex].wNetwork_ID,
					//	_astDTVNetwork[pMuxTable[m_astDTVProgramIndexTable[index1].cIDIndex].cNetWorkIndex].bNetworkName);
					bCountryService=_IsCountryNetworkService(_astDTVNetwork[pMuxTable[m_astDTVProgramIndexTable[index1].cIDIndex].cNetWorkIndex].wNetwork_ID);
				}
				else
				{
					ASSERT(0);
					bCountryService=FALSE;
				}
				if(bCountryService || m_astDTVProgramIndexTable[index1].bVisibleServiceFlag)
				{
					pItem=(DTV_SIMPLE_SERVICE_INFO*)msAPI_Memory_Allocate(sizeof(DTV_SIMPLE_SERVICE_INFO),(EN_BUFFER_ID)0);
					ASSERT(pItem);
					if(pItem==NULL)goto exit;
					memset(pItem,0,sizeof(DTV_SIMPLE_SERVICE_INFO));
					GetProgramTable(index1, pItem->bChannelName, E_DATA_SERVICE_NAME);
					pItem->wNumber=m_astDTVProgramIndexTable[index1].wLCN;
					pItem->dwPosition=index1;
					pItem->bVisible=m_astDTVProgramIndexTable[index1].bVisibleServiceFlag;
					pItem->bCountryService=bCountryService;
					pItem->bServiceToSelect=TRUE;
					pItem->next=_pDuplicateServiceList;
					_pDuplicateServiceList=pItem;

					//printf("add service index %d lcn %d country %d visible %d name %s\n",
					//	index1,pItem->wNumber,pItem->bCountryService,pItem->bVisible,pItem->bChannelName);
					if(bCountryService)
					{
						if(pItem->bVisible)
						{
							wCountryVisibleService++;
						}
						else
						{
							wCountryInvisibleService++;
						}
					}
					else
					{
						wOtherCountryVisibleService++;
					}
				}
			}
		}
	}
exit:
	//printf("wCountryVisibleService %d wCountryInvisibleService %d wOtherCountryVisibleService %d\n",
	//	wCountryVisibleService,wCountryInvisibleService,wOtherCountryVisibleService);
	if((wCountryVisibleService+wCountryInvisibleService+wOtherCountryVisibleService)>1)
	{
		if(wCountryVisibleService||wCountryInvisibleService)//have service match country
		{
			if(wCountryVisibleService<=1)
			{
				wStartLCN=NextLCN+1;
				goto Restart;
			}
			pNext=_pDuplicateServiceList;
			while(pNext)
			{
				if((pNext->bCountryService==FALSE)||(pNext->bVisible==FALSE))
				{
					pNext->bServiceToSelect=FALSE;
				}
				pNext=pNext->next;
			}
		}
		else if(wOtherCountryVisibleService>1)
		{
			pNext=_pDuplicateServiceList;
			while(pNext)
			{
				if(pNext->bVisible==FALSE)
				{
					pNext->bServiceToSelect=FALSE;
				}
				pNext=pNext->next;
			}
		}
		else
		{
			wStartLCN=NextLCN+1;
			goto Restart;
		}
	}
	else if(_pDuplicateServiceList!=NULL)
	{
		wStartLCN=NextLCN+1;
		goto Restart;
	}
	return _pDuplicateServiceList;
}


//****************************************************************************
/// This function will put the service that user select to the first in list
/// @param dwIndex \b IN: index of service
/// @return BOOLEAN: Function execution result
//****************************************************************************
BOOLEAN msAPI_CM_SetSelectService(DWORD dwIndex)
{
	CHANNEL_ATTRIBUTE Misc1;

	if((dwIndex>=MAX_DTVPROGRAM)||(IsProgramEntityActive(dwIndex)==FALSE))
	{
		ASSERT(0);
		return FALSE;
	}
	if(GetProgramTable(dwIndex, (BYTE *)&Misc1, E_DATA_MISC)==FALSE)return FALSE;
    Misc1.wSignalStrength=0x7FFF;
	return SetProgramTable(dwIndex, (BYTE *)&Misc1, E_DATA_MISC);
}


//****************************************************************************
/// This function will update program
/// @param bServiceType \b IN: Service type
/// -@see MEMBER_SERVICETYPE
/// @param wPosition \b IN: position
/// @param *pcBuffer \b IN: pointer buffer
/// @param eMember \b IN: program data member
/// -@see PROGRAMDATA_MEMBER
/// @return BOOLEAN: Function execution result
//****************************************************************************
BOOLEAN msAPI_CM_UpdateProgram(MEMBER_SERVICETYPE bServiceType, WORD wPosition, BYTE *pcBuffer, PROGRAMDATA_MEMBER eMember)
{
    AUD_INFO AudioInfo;
    DTV_CHANNEL_INFO DTVProgramData;
    MEMBER_COUNTRY eCountry;
    WORD wOrder,wPRIndex,cIDIndex,wLCN,wMemID;
    BYTE bPhyNum,bVerNum;
    BOOLEAN Ret=FALSE;
    //CHANNEL_ATTRIBUTE Misc1;
	DTVPROGRAMID_M *pMuxTable=_astDTVProgramIDTable;
#if DVB_T_C_DIFF_DB
	if (IsCATVInUse())pMuxTable=_astDTVCProgramIDTable;
#endif

    if( FALSE == IsServiceTypeValid(bServiceType) )
    {
        return FALSE;
    }

    if( FALSE == IsPositionValid(bServiceType, wPosition) )
    {
        return FALSE;
    }

    wOrder = ConvertPositionToOrder(bServiceType, wPosition);
    wPRIndex = m_astDTVProgramIndexTable[wOrder].wPRIndex;
    cIDIndex = m_astDTVProgramIndexTable[wOrder].cIDIndex;
#if 0
    GetProgramTable(wPRIndex, (BYTE *)&Misc1, E_DATA_MISC);

    if( TRUE == Misc1.bInvalidService)
    {
        return FALSE;
    }
#endif
    switch(eMember)
    {
    case E_DATA_ALL:

        memcpy(&DTVProgramData,pcBuffer,sizeof(DTV_CHANNEL_INFO));
        // need touch. check param.
//        return SetProgramTable(m_astDTVProgramIndexTable[wOrder].wPRIndex, pcBuffer, E_DATA_ALL);
        eCountry = msAPI_CM_GetCountry();
        switch(eCountry)
        {
        case E_FINLAND:
        case E_SWEDEN:
        case E_DENMARK:
        case E_NORWAY:
            if( INVALID_LOGICAL_CHANNEL_NUMBER != DTVProgramData.wLCN &&
                9999 < DTVProgramData.wLCN )
            {
                DTVProgramData.wLCN &= 0x3FF;
            }
            break;

        default:
            break;
        }
        Ret=SetProgramTable(wPRIndex, (BYTE *)&DTVProgramData, eMember);
        msAPI_CM_UpdateProgramVisibleAndSelectable(bServiceType,wPosition,
            DTVProgramData.stCHAttribute.bVisibleServiceFlag,
            DTVProgramData.stCHAttribute.bNumericSelectionFlag);
        return Ret;

    case E_DATA_LCN:
        memcpy(&wLCN,pcBuffer,sizeof(WORD));
        if( TRUE == IsLogicalChannelNumberValid(wLCN) )
        {
            CHANNEL_ATTRIBUTE Misc;
            GetProgramTable(wPRIndex, (BYTE *)&Misc, E_DATA_MISC);
            Misc.wSignalStrength=0x7FFD;
            Misc.bValidLCN=TRUE;

            SetProgramTable(wPRIndex, (BYTE *)&Misc, E_DATA_MISC);
            return SetProgramTable(wPRIndex, pcBuffer, E_DATA_LCN);
        }
        break;
    case E_DATA_TS_LCN:
        memcpy(&wLCN,pcBuffer,sizeof(WORD));
        if( TRUE == IsLogicalChannelNumberValid(wLCN) )
        {
            return SetProgramTable(wPRIndex, pcBuffer, E_DATA_TS_LCN);
        }
        break;
    case E_DATA_SIMU_LCN:
        memcpy(&wLCN,pcBuffer,sizeof(WORD));
        if( TRUE == IsLogicalChannelNumberValid(wLCN) )
        {
            return SetProgramTable(wPRIndex, pcBuffer, E_DATA_SIMU_LCN);
        }
        break;
    case E_DATA_PCN:
        memcpy(&bPhyNum,pcBuffer,sizeof(BYTE));
        if( TRUE == IsPhysicalChannelNumberValid(bPhyNum) )
        {
            return SetIDTable(cIDIndex, pcBuffer, E_DATA_PCN);
        }
        break;

    case E_DATA_VERSION_PAT:
        memcpy(&bVerNum,pcBuffer,sizeof(BYTE));
        if( TRUE == IsVersionValid(bVerNum) )
        {
            return SetProgramTable(wPRIndex, pcBuffer, E_DATA_VERSION_PAT);
        }
        break;

    case E_DATA_VERSION_PMT:
        memcpy(&bVerNum,pcBuffer,sizeof(BYTE));
        if( TRUE == IsVersionValid(bVerNum) )
        {
            return SetProgramTable(wPRIndex, pcBuffer, E_DATA_VERSION_PMT);
        }
        break;

    case E_DATA_VERSION_NIT:
        memcpy(&bVerNum,pcBuffer,sizeof(BYTE));
        if( TRUE == IsVersionValid(bVerNum) )
        {
            return SetProgramTable(wPRIndex, pcBuffer, E_DATA_VERSION_NIT);
        }
        break;

    case E_DATA_VERSION_SDT:
        memcpy(&bVerNum,pcBuffer,sizeof(BYTE));
        if( TRUE == IsVersionValid(bVerNum) )
        {
            return SetProgramTable(wPRIndex, pcBuffer, E_DATA_VERSION_SDT);
        }
        break;

    case E_DATA_TS_ID:
        memcpy(&wMemID,pcBuffer,sizeof(WORD));
        if( TRUE == IsTS_IDValid(wMemID) )
        {
            pMuxTable[cIDIndex].wTransportStream_ID= wMemID;
            return SetIDTable(cIDIndex, pcBuffer, E_DATA_TS_ID);
        }
        break;

    case E_DATA_ON_ID:
        memcpy(&wMemID,pcBuffer,sizeof(WORD));
        if( TRUE == IsON_IDValid(wMemID) )
        {
            pMuxTable[cIDIndex].wOriginalNetwork_ID= wMemID;
            return SetIDTable(cIDIndex, pcBuffer, E_DATA_ON_ID);
        }
        break;
    case E_DATA_NETWORK_ID:
        memcpy(&wMemID,pcBuffer,sizeof(WORD));
        if( TRUE == IsON_IDValid(wMemID) )
        {
            _astDTVNetwork[pMuxTable[cIDIndex].cNetWorkIndex].wNetwork_ID= wMemID;
            return SetIDTable(pMuxTable[cIDIndex].cNetWorkIndex, pcBuffer, E_DATA_NETWORK_ID);
        }
        break;
    case E_DATA_CELL_ID:
        memcpy(&wMemID,pcBuffer,sizeof(WORD));
        pMuxTable[cIDIndex].wCellID= wMemID;
        return SetIDTable(cIDIndex, pcBuffer, E_DATA_CELL_ID);
    case E_DATA_SERVICE_ID:
        memcpy(&wMemID,pcBuffer,sizeof(WORD));
        if( TRUE == IsService_IDValid(wMemID) )
        {
            return SetProgramTable(wPRIndex, pcBuffer, E_DATA_SERVICE_ID);
        }
        break;

    case E_DATA_PCR_PID:
        memcpy(&wMemID,pcBuffer,sizeof(WORD));
        if( TRUE == IsPCR_PIDValid(wMemID) )
        {
            return SetProgramTable(wPRIndex, pcBuffer, E_DATA_PCR_PID);
        }
        break;
    case E_DATA_PMT_PID:
        memcpy(&wMemID,pcBuffer,sizeof(WORD));
        if( TRUE == IsPMT_PIDValid(wMemID) )
        {
            return SetProgramTable(wPRIndex, pcBuffer, E_DATA_PMT_PID);
        }
        break;
    case E_DATA_VIDEO_PID:
        memcpy(&wMemID,pcBuffer,sizeof(WORD));
        if( bServiceType == E_SERVICETYPE_DTV || bServiceType == E_SERVICETYPE_DATA)
        {
            if( TRUE == IsVideoPIDValid(wMemID) )
            {
                return SetProgramTable(wPRIndex, pcBuffer, E_DATA_VIDEO_PID);
            }
        }
        break;

    case E_DATA_AUDIO_STREAM_INFO:
        memcpy(&AudioInfo,pcBuffer,sizeof(AUD_INFO));
        if( TRUE == IsAudioStreamInfoValid(&AudioInfo) )
        {
            return SetProgramTable(wPRIndex, pcBuffer, E_DATA_AUDIO_STREAM_INFO);
        }
        break;

    case E_DATA_SERVICE_NAME:
        return SetProgramTable(wPRIndex, pcBuffer, E_DATA_SERVICE_NAME);

    #if ENABLE_DTV_STORE_TTX_PAGE_INFO
    case E_DATA_TTX_LIST:
         return SetProgramTable(wPRIndex, pcBuffer, E_DATA_TTX_LIST);
    #endif
    case E_DATA_REPLACE_SERVICE:
        {
            CHANNEL_ATTRIBUTE stCHAttribute;
            GetProgramTable(wPRIndex, (BYTE *)&stCHAttribute, E_DATA_MISC);
            stCHAttribute.bReplaceService=*pcBuffer;
            m_astDTVProgramIndexTable[wOrder].bReplaceService=*pcBuffer;
            return SetProgramTable(wPRIndex, (BYTE *)&stCHAttribute, E_DATA_MISC);
        }
    default:
        break;
    }

    return FALSE;
}


//------------------------------------------------------------------------------
/// -This function will get List Page Number
/// @param u8ListIndex \b IN: List Index
/// @param pwListPageNumber \b IN: pointer to List Page Number
/// @return BOOLEAN: Function execution result
//------------------------------------------------------------------------------
#if ENABLE_DTV_STORE_TTX_PAGE_INFO
BOOLEAN msAPI_CM_GetListPageNumber(BYTE u8ListIndex, WORD * pwListPageNumber,MEMBER_SERVICETYPE bServiceType,WORD wPosition)
{
    BYTE u8SavedListPage[MAX_LISTPAGE_SIZE];
    WORD wSavedListPageNumber,wOrder;

    wOrder = ConvertPositionToOrder(bServiceType, wPosition);

    if ( MAX_LISTPAGE <= u8ListIndex )
    {
        return FALSE;
    }

    if ( TRUE != GetProgramTable(m_astDTVProgramIndexTable[wOrder].wPRIndex, u8SavedListPage, E_DATA_TTX_LIST) )
    {
        return FALSE;
    }

    wSavedListPageNumber = GetListPageNumber(u8SavedListPage, u8ListIndex);

    if ( wSavedListPageNumber < 100 || 899 < wSavedListPageNumber )
    {
        wSavedListPageNumber = DEFAULT_LISTPAGE[u8ListIndex];
    }

    *pwListPageNumber = wSavedListPageNumber;

    return TRUE;
}

//------------------------------------------------------------------------------
/// -This function will set List Page Number
/// @param u8ListIndex \b IN: List Index
/// @param pwListPageNumber \b IN: pointer to List Page Number
/// @return BOOLEAN: Function execution result
//------------------------------------------------------------------------------
BOOLEAN msAPI_CM_SetListPageNumber(BYTE u8ListIndex, WORD wListPageNumber,MEMBER_SERVICETYPE bServiceType,WORD wPosition)
{
    BYTE u8SavedListPage[MAX_LISTPAGE_SIZE];
    WORD wOrder;

    wOrder = ConvertPositionToOrder(bServiceType, wPosition);

    if ( MAX_LISTPAGE <= u8ListIndex )
    {
        return FALSE;
    }

    if ( wListPageNumber < 100 || 899 < wListPageNumber )
    {
        return FALSE;
    }

    if ( TRUE != GetProgramTable(m_astDTVProgramIndexTable[wOrder].wPRIndex, u8SavedListPage, E_DATA_TTX_LIST) )
    {
        return FALSE;
    }

    SetListPageNumber(u8SavedListPage, u8ListIndex, wListPageNumber);

    SetProgramTable(m_astDTVProgramIndexTable[wOrder].wPRIndex, u8SavedListPage, E_DATA_TTX_LIST);

    return TRUE;
}
#endif

static void ReassignInvalidLCN(MEMBER_SERVICETYPE bServiceType)//for Freeview NZ spec
{
    WORD wPosition;
    WORD wOrder;
    WORD wProgramCount;

    wProgramCount = GetProgramCount(bServiceType, INCLUDE_ALL);
    for( wPosition = 0; wPosition < wProgramCount; wPosition++)
    {
        wOrder = ConvertPositionToOrder(bServiceType, wPosition);
        if( m_astDTVProgramIndexTable[wOrder].wLCN > NZ_MAX_LCN)
        {
            m_astDTVProgramIndexTable[wOrder].wLCN = INVALID_LOGICAL_CHANNEL_NUMBER;
        }
    }
}

//****************************************************************************
/// Distinguish LCN Present or Absent
/// @param bServiceType \b IN: Service type
/// -@see MEMBER_SERVICETYPE
/// @return BOOLEAN: Function execution result
//****************************************************************************
static void DistinguishLCNPresentOrAbsent(MEMBER_SERVICETYPE bServiceType)
{
    WORD wPosition;
    WORD wOrder;
    WORD wProgramCount;
    WORD wOriinalLCN;
    wProgramCount = GetProgramCount(bServiceType, INCLUDE_ALL);

    for( wPosition = 0; wPosition < wProgramCount; wPosition++)
    {
        wOrder = ConvertPositionToOrder(bServiceType, wPosition);

        GetProgramTable(m_astDTVProgramIndexTable[wOrder].wPRIndex, (BYTE *)&wOriinalLCN, E_DATA_TS_LCN);
//printf("sid %d LCN %d %d\n",m_astDTVProgramIndexTable[wOrder].wService_ID,
//wOriinalLCN,m_astDTVProgramIndexTable[wOrder].wLCN);
        if(wOriinalLCN == 0)
        {
            m_astDTVProgramIndexTable[wOrder].wLCN = INVALID_LOGICAL_CHANNEL_NUMBER;
            m_astDTVProgramIndexTable[wOrder].eLCNAssignmentType &= ~(E_LCN_PRESENT|E_LCN_DUPLICATE);
            m_astDTVProgramIndexTable[wOrder].eLCNAssignmentType |= E_LCN_ZERO;
            continue;
        }
        if((m_astDTVProgramIndexTable[wOrder].bIsMove == 0) && (wOriinalLCN==INVALID_LOGICAL_CHANNEL_NUMBER)
            && (m_astDTVProgramIndexTable[wOrder].wSimu_LCN == INVALID_SIMULCAST_LOGICAL_CHANNEL_NUMBER))
        {
            m_astDTVProgramIndexTable[wOrder].wLCN = INVALID_LOGICAL_CHANNEL_NUMBER;//assign new number for no LCN service
        }
        if( 0 == m_astDTVProgramIndexTable[wOrder].wLCN )
        {
            m_astDTVProgramIndexTable[wOrder].wLCN = INVALID_LOGICAL_CHANNEL_NUMBER;
        }

        if( INVALID_LOGICAL_CHANNEL_NUMBER == m_astDTVProgramIndexTable[wOrder].wLCN )
        {
            m_astDTVProgramIndexTable[wOrder].eLCNAssignmentType &= ~(E_LCN_PRESENT|E_LCN_DUPLICATE);
            m_astDTVProgramIndexTable[wOrder].eLCNAssignmentType |= E_LCN_ABSENT;
        }
        else
        {
            m_astDTVProgramIndexTable[wOrder].eLCNAssignmentType &= ~(E_LCN_ABSENT);
            m_astDTVProgramIndexTable[wOrder].eLCNAssignmentType |= E_LCN_PRESENT;
        }
    }

}


//****************************************************************************
/// Distinguish LCN Last
/// @param bServiceType \b IN: Service type
/// -@see MEMBER_SERVICETYPE
/// @return BOOLEAN: Function execution result
//****************************************************************************
static void DistinguishLCNLast(MEMBER_SERVICETYPE bServiceType)
{
#if (NTV_FUNCTION_ENABLE)
    WORD wPosition;
    WORD wOrder;
    WORD wProgramCount;

    wProgramCount = GetProgramCount(bServiceType, INCLUDE_ALL);

    for( wPosition = 0; wPosition < wProgramCount; wPosition++)
    {
        wOrder = ConvertPositionToOrder(bServiceType, wPosition);
        if( m_astDTVProgramIndexTable[wOrder].bIsSpecialService)
        {
            if(msAPI_CM_GetCountry() == E_NORWAY)
            {
                m_astDTVProgramIndexTable[wOrder].eLCNAssignmentType |= E_LCN_LAST;
            }
        }
    }
#else
    UNUSED(bServiceType);
#endif

}





//****************************************************************************
/// Distinguish LCN Duplicate
/// @param bServiceType \b IN: Service type
/// -@see MEMBER_SERVICETYPE
/// @return BOOLEAN: Function execution result
//****************************************************************************
static void DistinguishLCNDuplicate(MEMBER_SERVICETYPE bServiceType)
{
    WORD wPosition1, wPosition2;
    WORD wOrder1, wOrder2;
    WORD wProgramCount;
    CHANNEL_ATTRIBUTE Misc1, Misc2;
	DTVPROGRAMID_M *pMuxTable=_astDTVProgramIDTable;
#if DVB_T_C_DIFF_DB
	if (IsCATVInUse())pMuxTable=_astDTVCProgramIDTable;
#endif


    wProgramCount = GetProgramCount(bServiceType, INCLUDE_ALL);

    for( wPosition1 = 0; wPosition1 < wProgramCount; wPosition1++ )
    {
        wOrder1 = ConvertPositionToOrder(bServiceType, wPosition1);

        for( wPosition2 = wPosition1+1; wPosition2 < wProgramCount; wPosition2++ )
        {
            wOrder2 = ConvertPositionToOrder(bServiceType, wPosition2);

            if( (m_astDTVProgramIndexTable[wOrder1].wLCN != 0 ) &&
            (m_astDTVProgramIndexTable[wOrder1].wLCN != INVALID_LOGICAL_CHANNEL_NUMBER ) &&
            (m_astDTVProgramIndexTable[wOrder1].wLCN == m_astDTVProgramIndexTable[wOrder2].wLCN) )
            {
                #if ( WATCH_DOG == ENABLE )
                msAPI_Timer_ResetWDT();
                #endif
                if ( IS_NORDIC_COUNTRY( m_eCountry ) &&(m_astDTVProgramIndexTable[wOrder2].bVisibleServiceFlag != m_astDTVProgramIndexTable[wOrder1].bVisibleServiceFlag ))
                {
                    if ( m_astDTVProgramIndexTable[wOrder2].bVisibleServiceFlag)
                    {
                        m_astDTVProgramIndexTable[wOrder1].eLCNAssignmentType &= ~(E_LCN_ABSENT);
                        m_astDTVProgramIndexTable[wOrder1].eLCNAssignmentType |= (E_LCN_DUPLICATE|E_LCN_PRESENT);

                    }
                    else
                    {
                        m_astDTVProgramIndexTable[wOrder2].eLCNAssignmentType &= ~(E_LCN_ABSENT);
                        m_astDTVProgramIndexTable[wOrder2].eLCNAssignmentType |= (E_LCN_DUPLICATE|E_LCN_PRESENT);

                    }
                }
                else if ( IS_NORDIC_COUNTRY( m_eCountry ) &&(m_astDTVProgramIndexTable[wOrder2].bServiceTypePrio != m_astDTVProgramIndexTable[wOrder1].bServiceTypePrio ))
                {
                    if ( m_astDTVProgramIndexTable[wOrder2].bServiceTypePrio < m_astDTVProgramIndexTable[wOrder1].bServiceTypePrio )
                    {
                        m_astDTVProgramIndexTable[wOrder1].eLCNAssignmentType &= ~(E_LCN_ABSENT);
                        m_astDTVProgramIndexTable[wOrder1].eLCNAssignmentType |= (E_LCN_DUPLICATE|E_LCN_PRESENT);

                    }
                    else
                    {
                        m_astDTVProgramIndexTable[wOrder2].eLCNAssignmentType &= ~(E_LCN_ABSENT);
                        m_astDTVProgramIndexTable[wOrder2].eLCNAssignmentType |= (E_LCN_DUPLICATE|E_LCN_PRESENT);

                    }
                }
                else
                {
                    GetProgramTable(m_astDTVProgramIndexTable[wOrder1].wPRIndex, (BYTE *)&Misc1, E_DATA_MISC);
                    GetProgramTable(m_astDTVProgramIndexTable[wOrder2].wPRIndex, (BYTE *)&Misc2, E_DATA_MISC);
#if (NTV_FUNCTION_ENABLE)
                    if((OSD_COUNTRY_SETTING == OSD_COUNTRY_NORWAY)&&(pMuxTable[m_astDTVProgramIndexTable[wOrder1].cIDIndex].cNetWorkIndex == _cFavoriteNetwork
                         && pMuxTable[m_astDTVProgramIndexTable[wOrder2].cIDIndex].cNetWorkIndex != _cFavoriteNetwork))
                    {
                        m_astDTVProgramIndexTable[wOrder2].eLCNAssignmentType &= ~(E_LCN_ABSENT);
                        m_astDTVProgramIndexTable[wOrder2].eLCNAssignmentType |= (E_LCN_DUPLICATE|E_LCN_PRESENT);
                    }
                    else if((OSD_COUNTRY_SETTING == OSD_COUNTRY_NORWAY)&&(pMuxTable[m_astDTVProgramIndexTable[wOrder1].cIDIndex].cNetWorkIndex != _cFavoriteNetwork
                         && pMuxTable[m_astDTVProgramIndexTable[wOrder2].cIDIndex].cNetWorkIndex == _cFavoriteNetwork))
                    {
                        m_astDTVProgramIndexTable[wOrder1].eLCNAssignmentType &= ~(E_LCN_ABSENT);
                        m_astDTVProgramIndexTable[wOrder1].eLCNAssignmentType |= (E_LCN_DUPLICATE|E_LCN_PRESENT);
                    }
                    else
#endif
                    {


						WORD wNID_1=INVALID_NID,wNID_2=INVALID_NID;
						if(pMuxTable[m_astDTVProgramIndexTable[wOrder1].cIDIndex].cNetWorkIndex < INVALID_NETWORKINDEX)
						{
							wNID_1=_astDTVNetwork[pMuxTable[m_astDTVProgramIndexTable[wOrder1].cIDIndex].cNetWorkIndex].wNetwork_ID;
						}
						if(pMuxTable[m_astDTVProgramIndexTable[wOrder2].cIDIndex].cNetWorkIndex < INVALID_NETWORKINDEX)
						{
							wNID_2=_astDTVNetwork[pMuxTable[m_astDTVProgramIndexTable[wOrder2].cIDIndex].cNetWorkIndex].wNetwork_ID;
						}


                        if( SelectBestMux(&Misc1,wNID_1, &Misc2,wNID_2) <= 0 )
                        {
                            m_astDTVProgramIndexTable[wOrder2].eLCNAssignmentType &= ~(E_LCN_ABSENT);
                            m_astDTVProgramIndexTable[wOrder2].eLCNAssignmentType |= (E_LCN_DUPLICATE|E_LCN_PRESENT);
                        }
                        else
                        {
                            m_astDTVProgramIndexTable[wOrder1].eLCNAssignmentType &= ~(E_LCN_ABSENT);
                            m_astDTVProgramIndexTable[wOrder1].eLCNAssignmentType |= (E_LCN_DUPLICATE|E_LCN_PRESENT);
                        }
                    }
                }
            }
        }
    }

}

//****************************************************************************
/// Distinguish SD and HD LCN Duplicate
/// @param bServiceType \b IN: Service type
/// -@see MEMBER_SERVICETYPE
/// @return BOOLEAN: Function execution result
//****************************************************************************
static void DistinguishSDAndHDLCNDuplicate(MEMBER_SERVICETYPE bServiceType)
{
#if (defined SUPPORT_MPEG2_SD_ONLY || (defined AUSTRALIA && (MEMORY_MAP <= MMAP_64MB)))
    UNUSED(bServiceType);
#else
    WORD wPosition1, wPosition2;
    WORD wOrder1, wOrder2;
    WORD wProgramCount;
    CHANNEL_ATTRIBUTE Misc1, Misc2;
    BOOLEAN bGotSameService=FALSE;
    MEMBER_COUNTRY eCountry;

    eCountry = msAPI_CM_GetCountry();
    memset((BYTE *)&Misc1,0x00,sizeof(CHANNEL_ATTRIBUTE));
    memset((BYTE *)&Misc2,0x00,sizeof(CHANNEL_ATTRIBUTE));
    wProgramCount = GetProgramCount(bServiceType, INCLUDE_ALL);

    for( wPosition1 = 0; wPosition1 < wProgramCount; wPosition1++ )
    {
        wOrder1 = ConvertPositionToOrder(bServiceType, wPosition1);
        bGotSameService=FALSE;
        GetProgramTable(m_astDTVProgramIndexTable[wOrder1].wPRIndex, (BYTE *)&Misc1, E_DATA_MISC);
        for( wPosition2 = wPosition1+1; wPosition2 < wProgramCount; wPosition2++ )
        {
            wOrder2 = ConvertPositionToOrder(bServiceType, wPosition2);
            if( (m_astDTVProgramIndexTable[wOrder1].wLCN != 0 ) &&
                (m_astDTVProgramIndexTable[wOrder1].wLCN != INVALID_LOGICAL_CHANNEL_NUMBER ) &&
                //(m_astDTVProgramIndexTable[wOrder1].wSimu_LCN != INVALID_SIMULCAST_LOGICAL_CHANNEL_NUMBER ) &&
                (m_astDTVProgramIndexTable[wOrder2].wLCN != INVALID_LOGICAL_CHANNEL_NUMBER ) &&
                //(m_astDTVProgramIndexTable[wOrder2].wSimu_LCN != INVALID_SIMULCAST_LOGICAL_CHANNEL_NUMBER ) &&
            ((m_astDTVProgramIndexTable[wOrder1].wLCN == m_astDTVProgramIndexTable[wOrder2].wSimu_LCN) ||
            (m_astDTVProgramIndexTable[wOrder1].wSimu_LCN == m_astDTVProgramIndexTable[wOrder2].wLCN)) )
            {
#if ( WATCH_DOG == ENABLE )
                msAPI_Timer_ResetWDT();
#endif
                bGotSameService=TRUE;
                GetProgramTable(m_astDTVProgramIndexTable[wOrder2].wPRIndex, (BYTE *)&Misc2, E_DATA_MISC);
                //if(Misc1.eVideoType != Misc2.eVideoType)
                {
                    WORD wNewLCN;
                    WORD wQuality;
                    WORD wLCN1,wLCN2;
                    wQuality=(Misc1.eVideoType == E_VIDEOTYPE_H264) ?
                                    (Misc1.wSignalStrength &0xff) : (Misc2.wSignalStrength &0xff);
                    if(wQuality)//check if HD service in good quality
                    {
                        wLCN1=m_astDTVProgramIndexTable[wOrder1].wLCN;
                        wLCN2=m_astDTVProgramIndexTable[wOrder2].wLCN;
                        if(!(m_astDTVProgramIndexTable[wOrder2].eLCNAssignmentType &E_LCN_DUPLICATE))
                        {
                            wNewLCN=m_astDTVProgramIndexTable[wOrder2].wLCN=wLCN1;
                            SetProgramTable(m_astDTVProgramIndexTable[wOrder2].wPRIndex, (BYTE *)&(wNewLCN), E_DATA_LCN);
                        }
                        if(!(m_astDTVProgramIndexTable[wOrder1].eLCNAssignmentType &E_LCN_DUPLICATE))
                        {
                            wNewLCN=m_astDTVProgramIndexTable[wOrder1].wLCN =wLCN2;
                            SetProgramTable(m_astDTVProgramIndexTable[wOrder1].wPRIndex, (BYTE *)&(wNewLCN), E_DATA_LCN);
                        }
                    }
                }
            }
        }
        if(bGotSameService == FALSE)//for no the same SD service
        {
        /*
            if ((((E_FRANCE == eCountry) || (E_PORTUGAL== eCountry))  && (Misc1.eVideoType != E_VIDEOTYPE_MPEG)) ||
                ((E_UK == eCountry) && (INVALID_LOGICAL_CHANNEL_NUMBER == m_astDTVProgramIndexTable[wOrder1].wLCN)))
*/
            if (Misc1.eVideoType == E_VIDEOTYPE_H264)
            {
                WORD wNewLCN;
                wNewLCN=m_astDTVProgramIndexTable[wOrder1].wSimu_LCN;
                if((wNewLCN != INVALID_SIMULCAST_LOGICAL_CHANNEL_NUMBER)&&(!(m_astDTVProgramIndexTable[wOrder1].eLCNAssignmentType &E_LCN_DUPLICATE)))
                {
                    m_astDTVProgramIndexTable[wOrder1].wLCN = wNewLCN;
                    SetProgramTable(m_astDTVProgramIndexTable[wOrder1].wPRIndex, (BYTE *)&(wNewLCN), E_DATA_LCN);
                }
            }

        }
    }
#endif
}

static void DistinguishSDLCNAndHDSimuLCNDuplicate(MEMBER_SERVICETYPE bServiceType, WORD wNativeON_ID)
{
#if (defined SUPPORT_MPEG2_SD_ONLY || (defined AUSTRALIA && (MEMORY_MAP <= MMAP_64MB)))
    UNUSED(bServiceType);
    UNUSED(wNativeON_ID);
#else
    WORD wPosition1, wPosition2;
    WORD wOrder1, wOrder2;
    WORD wProgramCount;
    CHANNEL_ATTRIBUTE Misc1, Misc2;
    //BOOLEAN bGotSameService=FALSE;
    MEMBER_COUNTRY eCountry;
    WORD wHDSimuLCN;
    WORD wOriginalNetwork_ID;

    eCountry = msAPI_CM_GetCountry();
    if(eCountry == E_UK)
    {
        wProgramCount = GetProgramCount(bServiceType, INCLUDE_ALL);

        for( wPosition1 = 0; wPosition1 < wProgramCount; wPosition1++ )
        {
            wOrder1 = ConvertPositionToOrder(bServiceType, wPosition1);
            //bGotSameService=FALSE;
            GetProgramTable(m_astDTVProgramIndexTable[wOrder1].wPRIndex, (BYTE *)&Misc1, E_DATA_MISC);
            GetIDTable(m_astDTVProgramIndexTable[wOrder1].cIDIndex, (BYTE *)&wOriginalNetwork_ID, E_DATA_ON_ID);
            if((m_astDTVProgramIndexTable[wOrder1].bServiceTypePrio >= E_SERVICETYPE_PRIORITY_LOW) || wOriginalNetwork_ID != wNativeON_ID)
            {
                continue;
            }

            wHDSimuLCN = m_astDTVProgramIndexTable[wOrder1].wSimu_LCN;
            if(wHDSimuLCN != INVALID_SIMULCAST_LOGICAL_CHANNEL_NUMBER && wHDSimuLCN > 0)
            {
                for( wPosition2 = 0; wPosition2 < wProgramCount; wPosition2++ )
                {
                    if (wPosition2 == wPosition1) continue;

                    wOrder2 = ConvertPositionToOrder(bServiceType, wPosition2);
                    GetProgramTable(m_astDTVProgramIndexTable[wOrder2].wPRIndex, (BYTE *)&Misc2, E_DATA_MISC);
                    if((m_astDTVProgramIndexTable[wOrder2].bServiceTypePrio >= E_SI_SERVICETYPE_PRIORITY_LOW) && (wHDSimuLCN == m_astDTVProgramIndexTable[wOrder2].wLCN))
                    {
                        if(!(m_astDTVProgramIndexTable[wOrder2].eLCNAssignmentType &E_LCN_DUPLICATE))
                        {
                            m_astDTVProgramIndexTable[wOrder2].wLCN = m_astDTVProgramIndexTable[wOrder1].wLCN;
                            SetProgramTable(m_astDTVProgramIndexTable[wOrder2].wPRIndex, (BYTE *)&(m_astDTVProgramIndexTable[wOrder2].wLCN), E_DATA_LCN);
                        }
                    }
                }
                if(!(m_astDTVProgramIndexTable[wOrder1].eLCNAssignmentType &E_LCN_DUPLICATE))
                {
                    m_astDTVProgramIndexTable[wOrder1].wLCN = wHDSimuLCN;
                    if(FALSE == SetProgramTable(m_astDTVProgramIndexTable[wOrder1].wPRIndex, (BYTE *)&(m_astDTVProgramIndexTable[wOrder1].wLCN), E_DATA_LCN))
                    {
                        //printf("DATA LCN store fail\n");
                    }
                }
            }
        }
    }
#endif
}
//****************************************************************************
/// Distinguish Same Service
/// @param bServiceType \b IN: Service type
/// -@see MEMBER_SERVICETYPE
/// @return BOOLEAN: Function execution result
//****************************************************************************
static void DistinguishSameService(MEMBER_SERVICETYPE bServiceType)
{
    WORD wPosition1, wPosition2;
    WORD wOrder1, wOrder2;
    WORD wProgramCount,wIDs_1=INVALID_TS_ID;
    CHANNEL_ATTRIBUTE Misc1, Misc2;
    BOOLEAN bIsSameService = FALSE;
	DTVPROGRAMID_M *pMuxTable=_astDTVProgramIDTable;
#if DVB_T_C_DIFF_DB
	if (IsCATVInUse())pMuxTable=_astDTVCProgramIDTable;
#endif

    wProgramCount = GetProgramCount(bServiceType, INCLUDE_ALL);

    for(wPosition1=0; wPosition1 < wProgramCount; wPosition1++)
    {
        #if ( WATCH_DOG == ENABLE )
        msAPI_Timer_ResetWDT();
        #endif

        wOrder1 = ConvertPositionToOrder(bServiceType, wPosition1);

        if(_bOnlyUpdateCurTS)
        {
            GetIDTable(m_astDTVProgramIndexTable[wOrder1].cIDIndex, (BYTE *)&wIDs_1, E_DATA_TS_ID);

            if(_wCurTS_ID != wIDs_1)
            {
                continue;
            }
        }

        for(wPosition2=wPosition1+1; wPosition2 < wProgramCount; wPosition2++)
        {
            wOrder2 = ConvertPositionToOrder(bServiceType, wPosition2);

			bIsSameService = AreOrdersSameService(wOrder1, wOrder2, IS_SID_UNIQUE_COUNTRY(m_eCountry) ? FALSE : TRUE);


            if( TRUE == bIsSameService)
            {
                GetProgramTable(m_astDTVProgramIndexTable[wOrder1].wPRIndex, (BYTE *)&Misc1, E_DATA_MISC);
                GetProgramTable(m_astDTVProgramIndexTable[wOrder2].wPRIndex, (BYTE *)&Misc2, E_DATA_MISC);
#if 0//(NTV_FUNCTION_ENABLE)
                if((OSD_COUNTRY_SETTING == OSD_COUNTRY_NORWAY)&&(pMuxTable[m_astDTVProgramIndexTable[wOrder1].cIDIndex].cNetWorkIndex == _cFavoriteNetwork
                    && pMuxTable[m_astDTVProgramIndexTable[wOrder2].cIDIndex].cNetWorkIndex != _cFavoriteNetwork))
                {
                    m_astDTVProgramIndexTable[wOrder2].eLCNAssignmentType |= E_LCN_SAME_SERVICE;
                }
                else if((OSD_COUNTRY_SETTING == OSD_COUNTRY_NORWAY)&&(pMuxTable[m_astDTVProgramIndexTable[wOrder1].cIDIndex].cNetWorkIndex != _cFavoriteNetwork
                    && pMuxTable[m_astDTVProgramIndexTable[wOrder2].cIDIndex].cNetWorkIndex == _cFavoriteNetwork))
                {
                    m_astDTVProgramIndexTable[wOrder1].eLCNAssignmentType |= E_LCN_SAME_SERVICE;
                }
                else
#endif
                {


					WORD wNID_1=INVALID_NID,wNID_2=INVALID_NID;

					if(pMuxTable[m_astDTVProgramIndexTable[wOrder1].cIDIndex].cNetWorkIndex < INVALID_NETWORKINDEX)
					{
						wNID_1=_astDTVNetwork[pMuxTable[m_astDTVProgramIndexTable[wOrder1].cIDIndex].cNetWorkIndex].wNetwork_ID;
					}
					if(pMuxTable[m_astDTVProgramIndexTable[wOrder2].cIDIndex].cNetWorkIndex < INVALID_NETWORKINDEX)
					{
						wNID_2=_astDTVNetwork[pMuxTable[m_astDTVProgramIndexTable[wOrder2].cIDIndex].cNetWorkIndex].wNetwork_ID;
					}




	                if( SelectBestMux(&Misc1,wNID_1, &Misc2,wNID_2) <= 0 )
	                {
	                    m_astDTVProgramIndexTable[wOrder2].eLCNAssignmentType |= E_LCN_SAME_SERVICE;
	                }
	                else
	                {
	                    m_astDTVProgramIndexTable[wOrder1].eLCNAssignmentType |= E_LCN_SAME_SERVICE;
	                }
            }
        }
    }
    }

}

static void DistinguishLCNSameService(MEMBER_SERVICETYPE bServiceType)
{
    WORD wPosition1, wPosition2;
    WORD wOrder1, wOrder2;
    WORD wProgramCount;
    CHANNEL_ATTRIBUTE Misc1, Misc2;
    WORD wLCN1, wLCN2;
	DTVPROGRAMID_M *pMuxTable=_astDTVProgramIDTable;
#if DVB_T_C_DIFF_DB
	if (IsCATVInUse())pMuxTable=_astDTVCProgramIDTable;
#endif

    wLCN1 = INVALID_LOGICAL_CHANNEL_NUMBER;
    wLCN2 = INVALID_LOGICAL_CHANNEL_NUMBER;
    wProgramCount = GetProgramCount(bServiceType, INCLUDE_ALL);

    for( wPosition1 = 0; wPosition1 < wProgramCount; wPosition1++ )
    {
        #if ( WATCH_DOG == ENABLE )
        msAPI_Timer_ResetWDT();
        #endif
        wOrder1 = ConvertPositionToOrder(bServiceType, wPosition1);
        for( wPosition2 = wPosition1+1; wPosition2 < wProgramCount; wPosition2++ )
        {
            wOrder2 = ConvertPositionToOrder(bServiceType, wPosition2);
            wLCN1 = m_astDTVProgramIndexTable[wOrder1].wLCN;
            wLCN2 = m_astDTVProgramIndexTable[wOrder2].wLCN;
            if( (wLCN1 != 0 ) && (wLCN1 != INVALID_LOGICAL_CHANNEL_NUMBER ) && (wLCN1 == wLCN2) )
            {
                #if ( WATCH_DOG == ENABLE )
                msAPI_Timer_ResetWDT();
                #endif
                if( TRUE == AreOrdersSameService(wOrder1, wOrder2, FALSE) )
                {
                    GetProgramTable(m_astDTVProgramIndexTable[wOrder1].wPRIndex, (BYTE *)&Misc1, E_DATA_MISC);
                    GetProgramTable(m_astDTVProgramIndexTable[wOrder2].wPRIndex, (BYTE *)&Misc2, E_DATA_MISC);


					WORD wNID_1=INVALID_NID,wNID_2=INVALID_NID;

					if(pMuxTable[m_astDTVProgramIndexTable[wOrder1].cIDIndex].cNetWorkIndex < INVALID_NETWORKINDEX)
					{
						wNID_1=_astDTVNetwork[pMuxTable[m_astDTVProgramIndexTable[wOrder1].cIDIndex].cNetWorkIndex].wNetwork_ID;
					}
					if(pMuxTable[m_astDTVProgramIndexTable[wOrder2].cIDIndex].cNetWorkIndex < INVALID_NETWORKINDEX)
					{
						wNID_2=_astDTVNetwork[pMuxTable[m_astDTVProgramIndexTable[wOrder2].cIDIndex].cNetWorkIndex].wNetwork_ID;
					}

                    if( SelectBestMux(&Misc1,wNID_1, &Misc2,wNID_2) <= 0 )
                    {
                        m_astDTVProgramIndexTable[wOrder2].eLCNAssignmentType |= E_LCN_SAME_SERVICE;
                    }
                    else
                    {
                        m_astDTVProgramIndexTable[wOrder1].eLCNAssignmentType |= E_LCN_SAME_SERVICE;
                    }
                }
            }
        }
    }
}

//****************************************************************************
/// Distinguish NotNative ON_ID
/// @param bServiceType \b IN: Service type
/// -@see MEMBER_SERVICETYPE
/// @param wNativeON_ID \b IN: Native ON_ID
/// @return BOOLEAN: Function execution result
//****************************************************************************
static void DistinguishNotNativeON_ID(MEMBER_SERVICETYPE bServiceType, WORD wNativeON_ID)
{
    WORD wPosition;
    WORD wOrder;
    WORD wProgramCount;
    WORD wOriginalNetwork_ID=INVALID_ON_ID;

    wProgramCount = GetProgramCount(bServiceType, INCLUDE_ALL);
    for( wPosition = 0; wPosition < wProgramCount; wPosition++)
    {
        #if ( WATCH_DOG == ENABLE )
        msAPI_Timer_ResetWDT();
        #endif

        wOrder = ConvertPositionToOrder(bServiceType, wPosition);

        GetIDTable(m_astDTVProgramIndexTable[wOrder].cIDIndex, (BYTE *)&wOriginalNetwork_ID, E_DATA_ON_ID);
        if( wNativeON_ID != wOriginalNetwork_ID )
        {
            //m_astDTVProgramIndexTable[wOrder].eLCNAssignmentType |= E_LCN_NOT_NATIVE_ON_ID;

            m_astDTVProgramIndexTable[wOrder].wLCN = INVALID_LOGICAL_CHANNEL_NUMBER;
            m_astDTVProgramIndexTable[wOrder].eLCNAssignmentType &= ~(E_LCN_PRESENT|E_LCN_DUPLICATE);
            m_astDTVProgramIndexTable[wOrder].eLCNAssignmentType |= E_LCN_ABSENT;
        }
    }
}


static void RestoreOriginalLCN(MEMBER_SERVICETYPE bServiceType)
{
    WORD wPosition,wPosition2,wPRIndex;
    WORD wOrder,wOrder2;
    WORD wProgramCount;
    WORD wOriinalLCN;
    BOOLEAN bLCNExit=FALSE;
    wProgramCount = GetProgramCount(bServiceType, INCLUDE_ALL);
    for( wPosition = 0; wPosition < wProgramCount; wPosition++)
    {
        #if ( WATCH_DOG == ENABLE )
        msAPI_Timer_ResetWDT();
        #endif
        bLCNExit=FALSE;
        wOrder = ConvertPositionToOrder(bServiceType, wPosition);
        if(m_astDTVProgramIndexTable[wOrder].bIsMove)
        {
            continue;
        }
        if( m_astDTVProgramIndexTable[wOrder].wLCN == INVALID_LOGICAL_CHANNEL_NUMBER)
        {
            continue;
        }
        wPRIndex = m_astDTVProgramIndexTable[wOrder].wPRIndex;
        GetProgramTable(wPRIndex, (BYTE *)&wOriinalLCN, E_DATA_TS_LCN);

        if( (m_astDTVProgramIndexTable[wOrder].wLCN == wOriinalLCN)
            || (wOriinalLCN == INVALID_LOGICAL_CHANNEL_NUMBER))
        {
            continue;
        }

        for( wPosition2 = 0; wPosition2 < wProgramCount; wPosition2++)
        {
            #if ( WATCH_DOG == ENABLE )
            msAPI_Timer_ResetWDT();
            #endif
            if(wPosition == wPosition2)
            {
                continue;
            }
            wOrder2 = ConvertPositionToOrder(bServiceType, wPosition2);
            if(m_astDTVProgramIndexTable[wOrder2].wLCN == wOriinalLCN)
            {
                bLCNExit=TRUE;
                break;
            }
        }
        if(!bLCNExit)
        {
            wPRIndex = m_astDTVProgramIndexTable[wOrder].wPRIndex;
            //printf("restore LCN org %d new %d\n",m_astDTVProgramIndexTable[wOrder].wLCN,wOriinalLCN);
            m_astDTVProgramIndexTable[wOrder].wLCN = wOriinalLCN;
            SetProgramTable(wPRIndex, (BYTE *)&wOriinalLCN, E_DATA_LCN);
        }
    }
}


//****************************************************************************
/// Assign New LCN
/// @param bServiceType \b IN: Service type
/// -@see MEMBER_SERVICETYPE
/// @param eAssignmentType \b IN: Assignment Type
/// -@see E_LCN_ASSIGNMENT_TYPE
/// @param wBeginFromLCN \b IN: begin LCN
/// @param wEndToLCN \b IN: End LCN
/// @param wBeginOfNewLCN \b IN: Begin Of New LCN
/// @param wEndOfNewLCN \b IN: End Of New LCN
/// @param wNewAssignableLCN \b IN: New Assignable LCN
/// @return BOOLEAN: Function execution result
//****************************************************************************
static void AssignNewLCN(MEMBER_SERVICETYPE bServiceType, E_LCN_ASSIGNMENT_TYPE eAssignmentType, WORD wBeginFromLCN, WORD wEndToLCN, WORD wBeginOfNewLCN, WORD wEndOfNewLCN, WORD wNewAssignableLCN)
{
    WORD wPosition;
    WORD wOrder;
    WORD wProgramCount;
    WORD wIndex;
    BOOLEAN bIsDeletionRequired;
    CHANNEL_ATTRIBUTE stCHAttribute;

    wProgramCount = GetProgramCount(bServiceType, INCLUDE_ALL);

    bIsDeletionRequired = FALSE;

    if( 0 == wBeginFromLCN &&
        0 == wEndToLCN &&
        0 == wBeginOfNewLCN &&
        0 == wEndOfNewLCN &&
        0 == wNewAssignableLCN )
    {
        bIsDeletionRequired = TRUE;
    }

    if( wNewAssignableLCN < wBeginOfNewLCN )
    {
        wNewAssignableLCN = wBeginOfNewLCN;
    }

    //assign new unused LCN within manual assignned range when wNewAssignableLCN > wEndOfNewLCN
    if( wNewAssignableLCN > wEndOfNewLCN)
    {
        for( wIndex = wBeginOfNewLCN; wIndex <= wEndOfNewLCN; wIndex++ )
        {
            for( wPosition = 0; wPosition < wProgramCount; wPosition++ )
            {
                wOrder = ConvertPositionToOrder(bServiceType, wPosition);

                if(m_astDTVProgramIndexTable[wOrder].wLCN == wIndex)
                {
                    break;
                }
            }
            if (wPosition == wProgramCount)
            {
                wNewAssignableLCN = wIndex;
                //printf("new assigned LCN is %d\n", wNewAssignableLCN);
                break;
            }
        }
    }
    switch(eAssignmentType)
    {
    case E_LCN_DUPLICATE:
        for(wPosition=0; wPosition < wProgramCount ; wPosition++)
        {
            #if ( WATCH_DOG == ENABLE )
            msAPI_Timer_ResetWDT();
            #endif

            wOrder = ConvertPositionToOrder(bServiceType, wPosition);

            if( ((E_LCN_DUPLICATE|E_LCN_PRESENT) == m_astDTVProgramIndexTable[wOrder].eLCNAssignmentType) &&
                ((wBeginFromLCN <= m_astDTVProgramIndexTable[wOrder].wLCN) ||
                 (m_astDTVProgramIndexTable[wOrder].wLCN <= wEndToLCN)) )
            {
                if( TRUE == bIsDeletionRequired )
                {
                    m_astDTVProgramIndexTable[wOrder].bIsDelete = TRUE;

                    GetProgramTable(m_astDTVProgramIndexTable[wOrder].wPRIndex, (BYTE *)&stCHAttribute, E_DATA_MISC);
                    stCHAttribute.bIsDelete = TRUE;
                    SetProgramTable(m_astDTVProgramIndexTable[wOrder].wPRIndex, (BYTE *)&stCHAttribute, E_DATA_MISC);
                }
                else
                {
                    m_astDTVProgramIndexTable[wOrder].wLCN = wNewAssignableLCN;
                    SetProgramTable(m_astDTVProgramIndexTable[wOrder].wPRIndex, (BYTE *)&(wNewAssignableLCN), E_DATA_LCN);
                    m_astDTVProgramIndexTable[wOrder].eLCNAssignmentType &= ~(E_LCN_DUPLICATE|E_LCN_PRESENT);
					wNewAssignableLCN++;
                    if( wNewAssignableLCN > wEndOfNewLCN )
                    {
                        break;
                    }
                }
            }
        }
        break;

    case E_LCN_ABSENT:
        for(wPosition=0; wPosition < wProgramCount ; wPosition++)
        {
            #if ( WATCH_DOG == ENABLE )
            msAPI_Timer_ResetWDT();
            #endif

            wOrder = ConvertPositionToOrder(bServiceType, wPosition);

            if( E_LCN_ABSENT == m_astDTVProgramIndexTable[wOrder].eLCNAssignmentType )
            {
                if( TRUE == bIsDeletionRequired )
                {
                    m_astDTVProgramIndexTable[wOrder].bIsDelete = TRUE;

                    GetProgramTable(m_astDTVProgramIndexTable[wOrder].wPRIndex, (BYTE *)&stCHAttribute, E_DATA_MISC);
                    stCHAttribute.bIsDelete = TRUE;
                    SetProgramTable(m_astDTVProgramIndexTable[wOrder].wPRIndex, (BYTE *)&stCHAttribute, E_DATA_MISC);
                }
                else
                {
                    m_astDTVProgramIndexTable[wOrder].wLCN = wNewAssignableLCN;
                    SetProgramTable(m_astDTVProgramIndexTable[wOrder].wPRIndex, (BYTE *)&(wNewAssignableLCN), E_DATA_LCN);
                    m_astDTVProgramIndexTable[wOrder].eLCNAssignmentType &= ~E_LCN_ABSENT;
                    wNewAssignableLCN++;
                    if( wNewAssignableLCN > wEndOfNewLCN )
                        break;
                }
            }
        }
        break;


    case E_LCN_ZERO:
        for(wPosition=0; wPosition < wProgramCount ; wPosition++)
        {
        #if ( WATCH_DOG == ENABLE )
            msAPI_Timer_ResetWDT();
        #endif

            wOrder = ConvertPositionToOrder(bServiceType, wPosition);

            if( E_LCN_ZERO == m_astDTVProgramIndexTable[wOrder].eLCNAssignmentType )
            {
                if( TRUE == bIsDeletionRequired )
                {
                    m_astDTVProgramIndexTable[wOrder].bIsDelete = TRUE;

                    GetProgramTable(m_astDTVProgramIndexTable[wOrder].wPRIndex, (BYTE *)&stCHAttribute, E_DATA_MISC);
                    stCHAttribute.bIsDelete = TRUE;
                    SetProgramTable(m_astDTVProgramIndexTable[wOrder].wPRIndex, (BYTE *)&stCHAttribute, E_DATA_MISC);
                }
                else
                {
                    m_astDTVProgramIndexTable[wOrder].wLCN = wNewAssignableLCN;
                    SetProgramTable(m_astDTVProgramIndexTable[wOrder].wPRIndex, (BYTE *)&(wNewAssignableLCN), E_DATA_LCN);
                    m_astDTVProgramIndexTable[wOrder].eLCNAssignmentType &= ~E_LCN_ZERO;
                    wNewAssignableLCN++;
                    if( wNewAssignableLCN > wEndOfNewLCN )
                        break;
                }
            }
        }
        break;



    case E_LCN_SAME_SERVICE:
        for(wPosition=0; wPosition < wProgramCount ; wPosition++)
        {
            #if ( WATCH_DOG == ENABLE )
            msAPI_Timer_ResetWDT();
            #endif

            wOrder = ConvertPositionToOrder(bServiceType, wPosition);

            if( E_LCN_SAME_SERVICE & m_astDTVProgramIndexTable[wOrder].eLCNAssignmentType )
            {
                if( TRUE == bIsDeletionRequired )
                {
                    m_astDTVProgramIndexTable[wOrder].bIsDelete = TRUE;
                    GetProgramTable(m_astDTVProgramIndexTable[wOrder].wPRIndex, (BYTE *)&stCHAttribute, E_DATA_MISC);
                    stCHAttribute.bIsDelete = TRUE;
                    SetProgramTable(m_astDTVProgramIndexTable[wOrder].wPRIndex, (BYTE *)&stCHAttribute, E_DATA_MISC);
                }
                else
                {
                    m_astDTVProgramIndexTable[wOrder].wLCN = wNewAssignableLCN;
                    SetProgramTable(m_astDTVProgramIndexTable[wOrder].wPRIndex, (BYTE *)&(wNewAssignableLCN), E_DATA_LCN);
                    m_astDTVProgramIndexTable[wOrder].eLCNAssignmentType &= ~E_LCN_SAME_SERVICE;
                    wNewAssignableLCN++;
                    if( wNewAssignableLCN > wEndOfNewLCN )
                        break;
                }
            }
        }
        break;

    case E_LCN_LAST:
        {
                WORD wMaxLCN = 0;
                WORD NewAssignLastLCN;
                //get special service max lcn
                for(wPosition=0; wPosition < wProgramCount ; wPosition++)
                {
#if ( WATCH_DOG == ENABLE )
                    msAPI_Timer_ResetWDT();
#endif
                    wOrder = ConvertPositionToOrder(bServiceType, wPosition);
                    if( E_LCN_LAST & m_astDTVProgramIndexTable[wOrder].eLCNAssignmentType )
                    {
                        if(m_astDTVProgramIndexTable[wOrder].wLCN > wMaxLCN)
                        {
                            wMaxLCN = m_astDTVProgramIndexTable[wOrder].wLCN;
                        }
                    }
                }
                NewAssignLastLCN = wMaxLCN + 1;
                if(NewAssignLastLCN < wBeginOfNewLCN || NewAssignLastLCN > wEndOfNewLCN)
                    break;
                //Special service duplicated lcn reassign lcn order
                for(wPosition=0; wPosition < wProgramCount ; wPosition++)
                {
                #if ( WATCH_DOG == ENABLE )
                    msAPI_Timer_ResetWDT();
                #endif

                    wOrder = ConvertPositionToOrder(bServiceType, wPosition);

                    if( ((E_LCN_DUPLICATE|E_LCN_PRESENT|E_LCN_LAST) == m_astDTVProgramIndexTable[wOrder].eLCNAssignmentType) &&
                        ((wBeginFromLCN <= m_astDTVProgramIndexTable[wOrder].wLCN) ||
                         (m_astDTVProgramIndexTable[wOrder].wLCN <= wEndToLCN)) )
                    {
                        if( TRUE == bIsDeletionRequired )
                        {
                            m_astDTVProgramIndexTable[wOrder].bIsDelete = TRUE;

                            GetProgramTable(m_astDTVProgramIndexTable[wOrder].wPRIndex, (BYTE *)&stCHAttribute, E_DATA_MISC);
                            stCHAttribute.bIsDelete = TRUE;
                            SetProgramTable(m_astDTVProgramIndexTable[wOrder].wPRIndex, (BYTE *)&stCHAttribute, E_DATA_MISC);
                        }
                        else
                        {
                            m_astDTVProgramIndexTable[wOrder].eLCNAssignmentType &= ~(E_LCN_DUPLICATE|E_LCN_PRESENT);
                            m_astDTVProgramIndexTable[wOrder].wLCN = NewAssignLastLCN;
                            SetProgramTable(m_astDTVProgramIndexTable[wOrder].wPRIndex, (BYTE *)&(NewAssignLastLCN), E_DATA_LCN);
                            NewAssignLastLCN++;

                            if( NewAssignLastLCN > wEndOfNewLCN )
                            {
                                break;
                            }
                        }
                    }
                }
            if(wNewAssignableLCN <= wBeginOfNewLCN)
            {
                break;
            }
            while(1)
            {
                WORD wMinimalLCN,wOrderMinimalLCN=0;
                wMinimalLCN=INVALID_LOGICAL_CHANNEL_NUMBER;
                for(wPosition=0; wPosition < wProgramCount ; wPosition++)
                {
#if ( WATCH_DOG == ENABLE )
                    msAPI_Timer_ResetWDT();
#endif
                    wOrder = ConvertPositionToOrder(bServiceType, wPosition);
                    if( E_LCN_LAST & m_astDTVProgramIndexTable[wOrder].eLCNAssignmentType )
                    {
                        if(m_astDTVProgramIndexTable[wOrder].wLCN < wMinimalLCN)
                        {
                            wMinimalLCN=m_astDTVProgramIndexTable[wOrder].wLCN;
                            wOrderMinimalLCN=wOrder;
                        }
                    }
                }

                if(wMinimalLCN != INVALID_LOGICAL_CHANNEL_NUMBER && wMinimalLCN < wNewAssignableLCN)
                {
                    m_astDTVProgramIndexTable[wOrderMinimalLCN].eLCNAssignmentType &= ~E_LCN_LAST;
                    m_astDTVProgramIndexTable[wOrderMinimalLCN].wLCN = wNewAssignableLCN;
                    SetProgramTable(m_astDTVProgramIndexTable[wOrderMinimalLCN].wPRIndex, (BYTE *)&(wNewAssignableLCN), E_DATA_LCN);
                    wNewAssignableLCN++;
                    if(wNewAssignableLCN > wEndOfNewLCN )
                    {
                        break;
                    }
                    else
                    {
                        continue;
                    }
                }
                else
                {
                        break;
                }
            }
        }
        break;

    default:
        break;
    }

}

//****************************************************************************
/// Get last LCN
/// @param bServiceType \b IN: Service type
/// -@see MEMBER_SERVICETYPE
/// @param eExcludingTypes \b IN: LCN assignment Type
/// -@see E_LCN_ASSIGNMENT_TYPE
/// @return WORD: LCN
//****************************************************************************
static WORD GetLastLCN(MEMBER_SERVICETYPE bServiceType, E_LCN_ASSIGNMENT_TYPE eExcludingTypes)
{
    WORD wLastLCN;
    WORD wProgramCount;
    WORD wPosition;
    WORD wOrder;

    wProgramCount = GetProgramCount(bServiceType, INCLUDE_ALL);
    wLastLCN = 0;

    for(wPosition=0; wPosition < wProgramCount; wPosition++)
    {
        wOrder = ConvertPositionToOrder(bServiceType, wPosition);

        if( eExcludingTypes & m_astDTVProgramIndexTable[wOrder].eLCNAssignmentType )
        {
            continue;
        }

        if( (INVALID_LOGICAL_CHANNEL_NUMBER != m_astDTVProgramIndexTable[wOrder].wLCN) &&
            (wLastLCN < m_astDTVProgramIndexTable[wOrder].wLCN) )
        {
            if(m_eCountry == E_AUSTRALIA)
            {
                if( (m_astDTVProgramIndexTable[wOrder].wLCN >= 350) && (m_astDTVProgramIndexTable[wOrder].wLCN <= 399) )
                    wLastLCN = m_astDTVProgramIndexTable[wOrder].wLCN;
            }
            else
            {
                wLastLCN = m_astDTVProgramIndexTable[wOrder].wLCN;
            }
        }
    }
    return wLastLCN;
}


static WORD GetLastLCNByRange(MEMBER_SERVICETYPE bServiceType, WORD wStart, WORD wEND)
{
    WORD wLastLCN=wStart;
    WORD wProgramCount;
    WORD wPosition;
    WORD wOrder;

    wProgramCount = GetProgramCount(bServiceType, INCLUDE_ALL);
    for(wPosition=0; wPosition < wProgramCount; wPosition++)
    {
        wOrder = ConvertPositionToOrder(bServiceType, wPosition);
        if((m_astDTVProgramIndexTable[wOrder].wLCN<wStart)||(m_astDTVProgramIndexTable[wOrder].wLCN>wEND))
        {
            continue;
        }
        if(wLastLCN < m_astDTVProgramIndexTable[wOrder].wLCN )
        {

            wLastLCN = m_astDTVProgramIndexTable[wOrder].wLCN;
        }
    }
    return wLastLCN;
}

// return value : misc1 (-1), misc2 (1), equal (0)
#define BEST_MUX_DIFF 5
//****************************************************************************
/// Select Best Mux
/// @param Misc1 \b IN: channel attribute
/// -@see CHANNEL_ATTRIBUTE
/// @param Misc2 \b IN: channel attribute
/// -@see CHANNEL_ATTRIBUTE
/// @return S8: MUX
//****************************************************************************
static S8 SelectBestMux(CHANNEL_ATTRIBUTE *Misc1, WORD wNID_1, CHANNEL_ATTRIBUTE *Misc2, WORD wNID_2)
{
#if 1 ////////////////////////////////////

    WORD snr_1, snr_2, strength_differ;
	MEMBER_COUNTRY eCountry;

#if ENABLE_TARGET_REGION
	if(Misc1->cRegion != Misc2->cRegion)
	{
		if(Misc1->cRegion > Misc2->cRegion)
		{
			return -1;
		}
		else
		{
			return 1;
		}
	}
#endif



    snr_1 = Misc1->wSignalStrength;
    snr_2 = Misc2->wSignalStrength;
    strength_differ = abs((snr_1>>8)-(snr_2>>8));

    if (strength_differ <= BEST_MUX_DIFF)
    {
        snr_1&=0xFF;
        snr_2&=0xFF;
    }
    if(Misc1->bUnconfirmedService || Misc1->bInvalidService)
    {
        return 1;   // select _tpr2
    }
    if(Misc2->bUnconfirmedService || Misc2->bInvalidService)
    {
        return -1;   // select _tp1
    }






	eCountry = msAPI_CM_GetCountry();

	if(eCountry == E_ITALY)
	{
		if(wNID_1<ITALY_NETWORK_START || wNID_1>ITALY_NETWORK_END)
		{
			if(wNID_2>=ITALY_NETWORK_START && wNID_2<=ITALY_NETWORK_END)
			{
				return 1;   // select _tpr2
			}
		}
		else if(wNID_2<ITALY_NETWORK_START || wNID_2>ITALY_NETWORK_END)
		{
			if(wNID_1>=ITALY_NETWORK_START && wNID_1<=ITALY_NETWORK_END)
			{
				return -1;   // select _tp1
			}
		}
	}


	if(Misc1->bVisibleServiceFlag == FALSE)
	{
		return 1;   // select _tpr2
	}
	if(Misc2->bVisibleServiceFlag == FALSE)
	{
		return -1;   // select _tp1
	}
    // ========== Compare SNR ==========
    if(snr_1 == snr_2)
    {
        return 1;

    }
    else if (snr_1 > snr_2)
    {
        return -1;  // select _tpr1
    }
    else
    {
        return 1;   // select _tpr2
    }

    return 0;       // default return value

#else ////////////////////////////////////
    WORD    snr_1, snr_2;

    snr_1 = Misc1->wSignalStrength;
    snr_2 = Misc2->wSignalStrength;

    // ========== Compare SNR ==========
    if(snr_1 == snr_2)
        return 0;

    else if( snr_1 > snr_2 )
        return -1;    // select _tpr1

    else
        return 1;    // select _tpr2

    return 0;    // default return value
#endif
}

//****************************************************************************
/// Reset Best Mux Data
/// @param eServiceType \b IN: service type
/// -@see MEMBER_SERVICETYPE
//****************************************************************************
static void ResetBestMuxData(MEMBER_SERVICETYPE eServiceType)
{
    WORD wPosition;
    WORD wOrder;
    WORD wProgramCount;
    CHANNEL_ATTRIBUTE stCHAttribute;

    wProgramCount = GetProgramCount(eServiceType, INCLUDE_ALL);
    for( wPosition = 0; wPosition < wProgramCount; wPosition++ )
    {
        wOrder = ConvertPositionToOrder(eServiceType, wPosition);

        GetProgramTable(m_astDTVProgramIndexTable[wOrder].wPRIndex, (BYTE *)&stCHAttribute, E_DATA_MISC);
        stCHAttribute.wSignalStrength = 0x7FFE;//for Nordig Spec
        SetProgramTable(m_astDTVProgramIndexTable[wOrder].wPRIndex, (BYTE *)&stCHAttribute, E_DATA_MISC);
    }
}

//****************************************************************************
/// Keep Move Position
/// @param eServiceType \b IN: service type
/// -@see MEMBER_SERVICETYPE
//****************************************************************************
static void KeepMovePosition(MEMBER_SERVICETYPE eServiceType)
{
    WORD wPosition;
    WORD wSearchPos,i;
    WORD wOrder;
    WORD wSavedOrder;
    WORD wProgramCount;

    wProgramCount    = GetProgramCount(eServiceType, INCLUDE_ALL);

    for( wPosition = 0; wPosition < wProgramCount; wPosition++ )
    {
        #if ( WATCH_DOG == ENABLE )
        msAPI_Timer_ResetWDT();
        #endif
        wSearchPos = ConvertPositionToOrder( eServiceType, wPosition );
        //printf(" wPosition:%d of Max:%d => Search Pos:%d\n", wPosition, wProgramCount, wSearchPos );
        for ( i = wPosition ; i <  wProgramCount ; i++ )
        {
            wOrder = ConvertPositionToOrder( eServiceType, i );
            //printf( "             i:%d of Max:%d => wOrder:%d \n", i, wProgramCount, wOrder );
            if( m_astDTVProgramIndexTable[wOrder].bIsMove == TRUE )
            {
                GetProgramTable(m_astDTVProgramIndexTable[wOrder].wPRIndex, (BYTE *)&wSavedOrder, E_DATA_ORDER);
                //printf("              m_astDTVProgramIndexTable[wOrder].wPRIndex :%d, wSaveOrder:%d SearchPos:%d\n",
                //                         m_astDTVProgramIndexTable[wOrder].wPRIndex, wSavedOrder, wSearchPos );
                if ( wSavedOrder == wSearchPos )
                {
                    if(i!=wPosition)
                    {
                        if( m_astDTVProgramIndexTable[wSavedOrder].bIsMove == TRUE )
                            SwapProgram(wOrder, wSavedOrder);
                        else
                            MoveProgram(wOrder, wSavedOrder);
                            }
                    break;
                }
            }
        }
    }

}

//****************************************************************************
/// Make All LCN Absent
/// @param eServiceType \b IN: service type
/// -@see MEMBER_SERVICETYPE
//****************************************************************************
static void MakeAllLCNAbsent(MEMBER_SERVICETYPE bServiceType)
{
    WORD wPosition;
    WORD wProgramCount;
    WORD wOrder;

    wProgramCount = GetProgramCount(bServiceType, INCLUDE_ALL);

    for(wPosition=0; wPosition < wProgramCount; wPosition++)
    {
        wOrder = ConvertPositionToOrder(bServiceType, wPosition);
        m_astDTVProgramIndexTable[wOrder].wLCN = INVALID_LOGICAL_CHANNEL_NUMBER;
        m_astDTVProgramIndexTable[wOrder].eLCNAssignmentType = E_LCN_ABSENT;
    }
}

//****************************************************************************
/// Arrange Logical Channel Number
/// @param eServiceType \b IN: service type
/// -@see MEMBER_SERVICETYPE
/// @param eLcnType \b IN: LCN type
/// -@see E_MEMBER_LCN_TYPE
//****************************************************************************
static void ArrangeLogicalChannelNumber(MEMBER_SERVICETYPE bServiceType, E_MEMBER_LCN_TYPE eLcnType, BOOLEAN bSkipDupSrvRemove)
{
    WORD wNewAssignableLCN;
    MEMBER_COUNTRY eCountry;

    LogicalChannelNumberIsArranged(FALSE);

    eCountry = msAPI_CM_GetCountry();

    switch(eCountry)
    {
#if ENABLE_SBTVD_BRAZIL_APP
    case E_BRAZIL:
        DistinguishSameService(bServiceType);
        RemoveSameService(bServiceType);

        #if ENABLE_SBTVD_BRAZIL_CM_APP
        SortProgram_Brazil(bServiceType);
        #else
        SortProgram(bServiceType);
        #endif
        break;
#endif
    case E_AUSTRALIA:
        DistinguishLCNPresentOrAbsent(bServiceType);
        DistinguishLCNDuplicate(bServiceType);
        DistinguishSameService(bServiceType);

        if( eLcnType != E_LCN_TYPE_MOVE)
        {
            KeepMovePosition(bServiceType);
        }

        wNewAssignableLCN = GetLastLCN( bServiceType, E_LCN_ABSENT|E_LCN_DUPLICATE|E_LCN_SAME_SERVICE ) + 1;
        AssignNewLCN(bServiceType, E_LCN_DUPLICATE, 1, 999, 350, MAX_LCN, wNewAssignableLCN);

        wNewAssignableLCN = GetLastLCN(bServiceType, (E_LCN_ABSENT|E_LCN_SAME_SERVICE)) + 1;
        AssignNewLCN(bServiceType, E_LCN_ABSENT, 1, 999, 350, MAX_LCN, wNewAssignableLCN);

        wNewAssignableLCN = GetLastLCN(bServiceType, (E_LCN_SAME_SERVICE)) + 1;
        AssignNewLCN(bServiceType, E_LCN_SAME_SERVICE, 1, 999, 350, MAX_LCN, wNewAssignableLCN);


        wNewAssignableLCN = GetLastLCN( bServiceType, E_LCN_ZERO ) + 1;
        AssignNewLCN( bServiceType, E_LCN_ZERO, 1, 999, 350, MAX_LCN, wNewAssignableLCN );


        SortProgram(bServiceType);
        break;

    case E_ITALY:
        DistinguishLCNPresentOrAbsent(bServiceType);
        DistinguishLCNDuplicate(bServiceType);
        DistinguishSameService(bServiceType);
        RemoveSameService(bServiceType);

        if( eLcnType != E_LCN_TYPE_MOVE)
        {
            KeepMovePosition(bServiceType);
        }

        wNewAssignableLCN = GetLastLCNByRange(bServiceType, ITALY_PREFER_LCN_OVERFLOW_START, ITALY_PREFER_LCN_OVERFLOW_END)+1;
		if(wNewAssignableLCN<=ITALY_PREFER_LCN_OVERFLOW_END)
        {
            AssignNewLCN(bServiceType, E_LCN_DUPLICATE, ITALY_PREFER_LCN_START, ITALY_PREFER_LCN_OVERFLOW_START-1, ITALY_PREFER_LCN_OVERFLOW_START, ITALY_PREFER_LCN_OVERFLOW_END, wNewAssignableLCN);
        }

        wNewAssignableLCN = GetLastLCN(bServiceType, (E_LCN_ABSENT|E_LCN_SAME_SERVICE|E_LCN_DUPLICATE)) + 1;
        AssignNewLCN(bServiceType, E_LCN_DUPLICATE, ITALY_ASSIGN_LCN_START, ITALY_MAIN_LCN_OVERFLOW_START-1, ITALY_MAIN_LCN_OVERFLOW_START, ITALY_MAIN_LCN_OVERFLOW_END, wNewAssignableLCN);

        wNewAssignableLCN = GetLastLCN(bServiceType, (E_LCN_ABSENT|E_LCN_SAME_SERVICE)) + 1;
        AssignNewLCN(bServiceType, E_LCN_ABSENT, ITALY_PREFER_LCN_START, ITALY_ASSIGN_LCN_END, ITALY_MAIN_LCN_OVERFLOW_START, ITALY_MAIN_LCN_OVERFLOW_END, wNewAssignableLCN);

        wNewAssignableLCN = GetLastLCN(bServiceType, (E_LCN_SAME_SERVICE)) + 1;
        AssignNewLCN(bServiceType, E_LCN_SAME_SERVICE, ITALY_PREFER_LCN_START, ITALY_ASSIGN_LCN_END, ITALY_MAIN_LCN_OVERFLOW_START, ITALY_MAIN_LCN_OVERFLOW_END, wNewAssignableLCN);

        wNewAssignableLCN = GetLastLCN( bServiceType, E_LCN_ZERO ) + 1;
        AssignNewLCN( bServiceType, E_LCN_ZERO, ITALY_PREFER_LCN_START, ITALY_ASSIGN_LCN_END, ITALY_MAIN_LCN_OVERFLOW_START, ITALY_MAIN_LCN_OVERFLOW_END, wNewAssignableLCN );

        SortProgram(bServiceType);
        break;

    case E_UK:
    case E_NEWZEALAND:
        // DTG says we need use best mux rule to store duplicate service.
        if(E_NEWZEALAND== eCountry)
        {
            DistinguishNotNativeON_ID(bServiceType, 0x222A);
            ReassignInvalidLCN(bServiceType);//for Freeview NZ spec
        }
        else if(E_UK== eCountry)
        {
            DistinguishNotNativeON_ID(bServiceType, 0x233A);
            DistinguishLCNDuplicate(bServiceType);
            DistinguishSDLCNAndHDSimuLCNDuplicate(bServiceType, 0x233A);
        }
        DistinguishSameService(bServiceType);
        if(E_NEWZEALAND== eCountry)
        {
            DistinguishLCNSameService(bServiceType);
        }
        RemoveSameService(bServiceType);//for Nordig Spec
        DistinguishLCNPresentOrAbsent(bServiceType);
        DistinguishLCNDuplicate(bServiceType);

        ResetBestMuxData(bServiceType);

        if( eLcnType != E_LCN_TYPE_MOVE)
        {
            KeepMovePosition(bServiceType);
        }

        wNewAssignableLCN = GetLastLCN( bServiceType, E_LCN_ABSENT|E_LCN_DUPLICATE|E_LCN_SAME_SERVICE ) + 1;
        AssignNewLCN( bServiceType, E_LCN_DUPLICATE, 1, 799, 800, MAX_LCN, wNewAssignableLCN );

        wNewAssignableLCN = GetLastLCN( bServiceType, E_LCN_ABSENT|E_LCN_SAME_SERVICE ) + 1;
        AssignNewLCN( bServiceType, E_LCN_ABSENT, 1, 799, 800, MAX_LCN, wNewAssignableLCN );

        //wNewAssignableLCN = GetLastLCN( bServiceType, E_LCN_SAME_SERVICE ) + 1;
        //AssignNewLCN( bServiceType, E_LCN_SAME_SERVICE, 1, 799, 800, 999, wNewAssignableLCN );

        wNewAssignableLCN = GetLastLCN( bServiceType, E_LCN_ZERO ) + 1;
        AssignNewLCN( bServiceType, E_LCN_ZERO, 1, 799, 800, MAX_LCN, wNewAssignableLCN );

        SortProgram(bServiceType);
        break;

  #if 0
        case E_FRANCE:
            DistinguishSDAndHDLCNDuplicate(bServiceType);
        case E_NETHERLANDS:
  #else // Modified by coverity_0601
        case E_PORTUGAL:
        case E_FRANCE:
        case E_NETHERLANDS:
        if (eCountry == E_FRANCE)
        {
            DistinguishNotNativeON_ID(bServiceType, 0x20FA);
           // DistinguishLCNDuplicate(bServiceType);
           // DistinguishSDAndHDLCNDuplicate(bServiceType);
        }
        else if (eCountry == E_PORTUGAL)
        {
            DistinguishLCNDuplicate(bServiceType);
            DistinguishSDAndHDLCNDuplicate(bServiceType);
        }
        else if(eCountry == E_NETHERLANDS)
        {
            DistinguishNotNativeON_ID(bServiceType, 0x03E8);
            DistinguishLCNDuplicate(bServiceType);
            DistinguishSDLCNAndHDSimuLCNDuplicate(bServiceType, 0x03E8);
        }
  #endif
        DistinguishLCNPresentOrAbsent(bServiceType);
        DistinguishLCNDuplicate(bServiceType);
        DistinguishSameService(bServiceType);
        RemoveSameService(bServiceType);

        if( eLcnType != E_LCN_TYPE_MOVE)
        {
            KeepMovePosition(bServiceType);
        }

        wNewAssignableLCN = GetLastLCN( bServiceType, E_LCN_ABSENT|E_LCN_DUPLICATE|E_LCN_SAME_SERVICE ) + 1;
        AssignNewLCN( bServiceType, E_LCN_DUPLICATE, 1, 799, 800, MAX_LCN, wNewAssignableLCN );

        wNewAssignableLCN = GetLastLCN( bServiceType, E_LCN_ABSENT|E_LCN_SAME_SERVICE ) + 1;
        AssignNewLCN( bServiceType, E_LCN_ABSENT, 1, 799, 800, MAX_LCN, wNewAssignableLCN );

        wNewAssignableLCN = GetLastLCN( bServiceType, E_LCN_SAME_SERVICE ) + 1;
        AssignNewLCN( bServiceType, E_LCN_SAME_SERVICE, 1, 799, 800, MAX_LCN, wNewAssignableLCN );

        wNewAssignableLCN = GetLastLCN( bServiceType, E_LCN_ZERO ) + 1;
        AssignNewLCN( bServiceType, E_LCN_ZERO, 1, 799, 800, MAX_LCN, wNewAssignableLCN );
        if (eCountry == E_FRANCE)
        {
           DistinguishLCNDuplicate(bServiceType);
           DistinguishSDAndHDLCNDuplicate(bServiceType);
        }
        SortProgram(bServiceType);
        break;
    case E_NORWAY:
    case E_SWEDEN:
    case E_FINLAND:
    case E_DENMARK:
    case E_IRELAND:
        #if 0 // I am not sure if there is any side effect.
        if( eCountry == E_SWEDEN )
        {
            DistinguishNotNativeON_ID(bServiceType, 0x22F1);
        }
        #endif
        DistinguishSameService(bServiceType);
        if(bSkipDupSrvRemove == FALSE)
        {
            if(IS_BESTMUX_COUNTRY(m_eCountry))
            RemoveSameService(bServiceType);//for Nordig Spec
        }
        DistinguishLCNPresentOrAbsent(bServiceType);
        DistinguishLCNDuplicate(bServiceType);
        if( eCountry == E_NORWAY )
        {
            //DistinguishNotNativeON_ID(bServiceType, 0x2242);
            DistinguishLCNLast(bServiceType);//for RiksTV spec,900~999 shall be end of list
        }
        if(bSkipDupSrvRemove == FALSE)
        {
            if(IS_BESTMUX_COUNTRY(m_eCountry))
            ResetBestMuxData(bServiceType);
        }
        if( eLcnType != E_LCN_TYPE_MOVE)
        {
            KeepMovePosition(bServiceType);
        }

        wNewAssignableLCN = GetLastLCN( bServiceType, E_LCN_ABSENT|E_LCN_DUPLICATE|E_LCN_SAME_SERVICE|E_LCN_LAST ) + 1;
        AssignNewLCN( bServiceType, E_LCN_DUPLICATE, 1, MAX_LCN, 1, MAX_LCN, wNewAssignableLCN );

        wNewAssignableLCN = GetLastLCN( bServiceType, E_LCN_ABSENT|E_LCN_SAME_SERVICE|E_LCN_LAST ) + 1;
        AssignNewLCN( bServiceType, E_LCN_ABSENT, 1, MAX_LCN, 1, MAX_LCN, wNewAssignableLCN );
        if( eCountry == E_NORWAY )
        {
            wNewAssignableLCN = GetLastLCN( bServiceType, E_LCN_SAME_SERVICE|E_LCN_LAST ) + 1;
            AssignNewLCN( bServiceType, E_LCN_LAST, 1, MAX_LCN, RIKSTV_HEARING_AND_VISUALLY_IMPAIRED_LCN_START, MAX_LCN, wNewAssignableLCN );
        }
//        wNewAssignableLCN = GetLastLCN( bServiceType, E_LCN_SAME_SERVICE ) + 1;
//        AssignNewLCN( bServiceType, E_LCN_SAME_SERVICE, 1, 9999, 1, 9999, wNewAssignableLCN );
//        AssignNewLCN( bServiceType, E_LCN_SAME_SERVICE, 0, 0, 0, 0, 0 );

        wNewAssignableLCN = GetLastLCN( bServiceType, E_LCN_ZERO ) + 1;
        AssignNewLCN( bServiceType, E_LCN_ZERO, 1, MAX_LCN, 1, MAX_LCN, wNewAssignableLCN );

        SortProgram(bServiceType);
#if NTV_FUNCTION_ENABLE
        if( eCountry == E_NORWAY )
        {
            SortProgramByRegionPriority(bServiceType);
        }
#endif

        break;
    case E_GERMANY:
#if ENABLE_T_C_COMBO
        if (IsCATVInUse())
        {
            DistinguishLCNDuplicate(bServiceType);
            DistinguishLCNPresentOrAbsent(bServiceType);
            DistinguishLCNDuplicate(bServiceType);
            DistinguishSameService(bServiceType);
            RemoveSameService(bServiceType);

            if( eLcnType != E_LCN_TYPE_MOVE)
            {
                KeepMovePosition(bServiceType);
            }

            wNewAssignableLCN = GetLastLCN( bServiceType, E_LCN_ABSENT|E_LCN_DUPLICATE|E_LCN_SAME_SERVICE ) + 1;
            AssignNewLCN( bServiceType, E_LCN_DUPLICATE, 1, 799, 800, MAX_LCN, wNewAssignableLCN );

            wNewAssignableLCN = GetLastLCN( bServiceType, E_LCN_ABSENT|E_LCN_SAME_SERVICE ) + 1;
            AssignNewLCN( bServiceType, E_LCN_ABSENT, 1, 799, 800, MAX_LCN, wNewAssignableLCN );

            wNewAssignableLCN = GetLastLCN( bServiceType, E_LCN_SAME_SERVICE ) + 1;
            AssignNewLCN( bServiceType, E_LCN_SAME_SERVICE, 1, 799, 800, MAX_LCN, wNewAssignableLCN );

            wNewAssignableLCN = GetLastLCN( bServiceType, E_LCN_ZERO ) + 1;
            AssignNewLCN( bServiceType, E_LCN_ZERO, 1, 799, 800, MAX_LCN, wNewAssignableLCN );

            SortProgram(bServiceType);
            break;
        }
#endif


    //case E_SPAIN:
    //case E_CHINA:
    //case E_TAIWAN:
    default:

        MakeAllLCNAbsent(bServiceType);
        DistinguishSameService(bServiceType);
        RemoveSameService(bServiceType);

        if( eLcnType != E_LCN_TYPE_MOVE)
        {
            DistinguishSameService(bServiceType);
            KeepMovePosition(bServiceType);
        }

        AssignNewLCN( bServiceType, E_LCN_ABSENT, 1, MAX_LCN, 1, MAX_LCN, 1 );

        wNewAssignableLCN = GetLastLCN( bServiceType, E_LCN_SAME_SERVICE ) + 1;
        AssignNewLCN( bServiceType, E_LCN_SAME_SERVICE, 1, MAX_LCN, 1, MAX_LCN, wNewAssignableLCN );

        if( eLcnType != E_LCN_TYPE_MOVE)
        {
            SortProgram(bServiceType);
        }
        break;
    }

    UpdateOrderOfProgramTable(bServiceType);

    UpdateProgramCount(bServiceType);

    LogicalChannelNumberIsArranged(TRUE);
}

//****************************************************************************
/// Arrange Data Manager
/// @param bReArrangeLcn \b IN: reArrange LCN or not
/// - TRUE: Re-arrange
/// - FALSE: NO
/// @param bUpdatePosition \b IN: Update Position or not
/// - TRUE: Update
/// - FALSE: NO
/// @return BOOLEAN: Function execution result
//****************************************************************************
static BOOLEAN __msAPI_CM_ArrangeDataManager(BOOLEAN bReArrangeLcn, BOOLEAN bUpdatePosition, BOOLEAN bSkipDupSrvRemove)
{
    MEMBER_SERVICETYPE bServiceType = E_SERVICETYPE_DTV, l_eServiceType = E_SERVICETYPE_DTV;
    WORD wPosition = 0, l_wPosition = 0;
    WORD wService_ID = 0;
    WORD wPhysicalChannelNumber = 0;

    if(bReArrangeLcn)
    {
        if(bUpdatePosition)
        {
            bServiceType = msAPI_CM_GetCurrentServiceType();
            wPosition = msAPI_CM_GetCurrentPosition(bServiceType);
            wService_ID = msAPI_CM_GetService_ID(bServiceType, wPosition);
            wPhysicalChannelNumber = msAPI_CM_GetPhysicalChannelNumber(bServiceType, wPosition);
        }
        //FillDTVProgramIndexTableWithoutOrder();
        if (TRUE == IsLinkOfOrderValid())
        {
            FillDTVProgramIndexTableWithOrder();
        }
        else
        {
            FillDTVProgramIndexTableWithoutOrder();
        }
    }

    UpdateProgramCount(E_SERVICETYPE_DTV);
    UpdateProgramCount(E_SERVICETYPE_DATA);
    UpdateProgramCount(E_SERVICETYPE_RADIO);

    UpdateIDInfo();
    
    if(bReArrangeLcn)
    {
        if( OSD_COUNTRY_SETTING== OSD_COUNTRY_NORWAY)
        {
            DistinguishNotNativeON_ID(E_SERVICETYPE_DTV, 0x2242);
            DistinguishNotNativeON_ID(E_SERVICETYPE_RADIO, 0x2242);
            DistinguishNotNativeON_ID(E_SERVICETYPE_DATA, 0x2242);
        }
        if( OSD_COUNTRY_SETTING== OSD_COUNTRY_DENMARK)
        {
            DistinguishNotNativeON_ID(E_SERVICETYPE_DTV, 0x20D0);
            DistinguishNotNativeON_ID(E_SERVICETYPE_RADIO, 0x20D0);
            DistinguishNotNativeON_ID(E_SERVICETYPE_DATA, 0x20D0);
        }
        if( OSD_COUNTRY_SETTING== OSD_COUNTRY_SWEDEN)
        {
            DistinguishNotNativeON_ID(E_SERVICETYPE_DTV, 0x22F1);
            DistinguishNotNativeON_ID(E_SERVICETYPE_RADIO, 0x22F1);
            DistinguishNotNativeON_ID(E_SERVICETYPE_DATA, 0x22F1);
        }
        if( OSD_COUNTRY_SETTING== OSD_COUNTRY_FINLAND)
        {
            DistinguishNotNativeON_ID(E_SERVICETYPE_DTV, 0x20F6);
            DistinguishNotNativeON_ID(E_SERVICETYPE_RADIO, 0x20F6);
            DistinguishNotNativeON_ID(E_SERVICETYPE_DATA, 0x20F6);
        }
        if( OSD_COUNTRY_SETTING== OSD_COUNTRY_IRELAND)
        {
            DistinguishNotNativeON_ID(E_SERVICETYPE_DTV, 0x2174);
            DistinguishNotNativeON_ID(E_SERVICETYPE_RADIO, 0x2174);
            DistinguishNotNativeON_ID(E_SERVICETYPE_DATA, 0x2174);
        }

        RestoreOriginalLCN(E_SERVICETYPE_DTV);
        RestoreOriginalLCN(E_SERVICETYPE_DATA);
        RestoreOriginalLCN(E_SERVICETYPE_RADIO);

        ArrangeLogicalChannelNumber(E_SERVICETYPE_DTV, E_LCN_TYPE_AUTO, bSkipDupSrvRemove);
        ArrangeLogicalChannelNumber(E_SERVICETYPE_DATA, E_LCN_TYPE_AUTO, bSkipDupSrvRemove);
        ArrangeLogicalChannelNumber(E_SERVICETYPE_RADIO, E_LCN_TYPE_AUTO, bSkipDupSrvRemove);
        if(bUpdatePosition)
        {
            if(TRUE==msAPI_CM_GetServiceTypeAndPositionWithPCN(wPhysicalChannelNumber, wService_ID, &l_eServiceType, &l_wPosition))
            {
            if (wPosition != l_wPosition)
                msAPI_CM_SetCurrentPosition(bServiceType, l_wPosition);
            }
        }
    }
    _RestInvalidMUXAndNetwork();
    //msAPI_CM_PrintAllProgram();
    return TRUE;
}

//****************************************************************************
/// This function will arrange Data manager
/// @param bReArrangeLcn \b IN: Re-arrange LCN or NOT
/// - TRUE: Re-arrange
/// - FALSE: NO
/// @return BOOLEAN: Function execution result
//****************************************************************************
BOOLEAN msAPI_CM_ArrangeDataManager(BOOLEAN bReArrangeLcn, BOOLEAN bSkipDupSrvRemove)
{
    return __msAPI_CM_ArrangeDataManager(bReArrangeLcn, TRUE, bSkipDupSrvRemove);
}
//****************************************************************************
/// This function will sort data manager
/// @return BOOLEAN: Function execution result
//****************************************************************************
BOOLEAN ddmArrangeLogicalChannelNumber(MEMBER_SERVICETYPE eServiceType, E_MEMBER_LCN_TYPE eLcnType)
{
    if( FALSE == IsServiceTypeValid(eServiceType) )
    {
        return FALSE;
    }

    ArrangeLogicalChannelNumber(eServiceType, eLcnType, FALSE);

    return TRUE;
}

//****************************************************************************
/// This function will sort data manager
/// @return BOOLEAN: Function execution result
//****************************************************************************
#if 0
BOOLEAN msAPI_CM_SortDataManager(void)
{
    SortProgram(E_SERVICETYPE_DTV);
    SortProgram(E_SERVICETYPE_RADIO);
    UpdateOrderOfProgramTable(E_SERVICETYPE_DTV);
    UpdateOrderOfProgramTable(E_SERVICETYPE_RADIO);

    return TRUE;
}
#endif
//****************************************************************************
/// Get first position in PCN
/// @param bServiceType \b IN: Service type
/// -@see MEMBER_SERVICETYPE
/// @param cPCN \b IN: PCN
/// @param *pwPosition \b IN: pointer to position for return
/// @return BOOLEAN: Function execution result
//****************************************************************************
BOOLEAN msAPI_CM_GetFirstPositionInPCN(MEMBER_SERVICETYPE bServiceType, BYTE cPCN, WORD * pwPosition)
{
    WORD wPosition;
    WORD wOrder;
    BYTE cIDIndex;
    WORD wProgramCount;
    BOOLEAN eResult = FALSE;
	DTVPROGRAMID_M *pMuxTable=_astDTVProgramIDTable;
#if DVB_T_C_DIFF_DB
	if (IsCATVInUse())pMuxTable=_astDTVCProgramIDTable;
#endif
    if( FALSE == IsPhysicalChannelNumberValid(cPCN) ||
        FALSE == IsServiceTypeValid(bServiceType) )
    {
        return FALSE;
    }

    wProgramCount = GetProgramCount(bServiceType, EXCLUDE_NOT_VISIBLE_AND_DELETED);
    for(wPosition=0; wPosition < wProgramCount; wPosition++)
    {
        wOrder = ConvertPositionToOrder(bServiceType, wPosition);

        cIDIndex = m_astDTVProgramIndexTable[wOrder].cIDIndex;
#if ENABLE_T_C_COMBO
        if (IsCATVInUse() && (cPCN == cIDIndex))
        {
            *pwPosition = ConvertOrderToPosition(wOrder);
            eResult = TRUE;
            break;
        }
        if( !IsCATVInUse() && (cPCN == pMuxTable[cIDIndex].cRFChannelNumber) )
        {
            *pwPosition = ConvertOrderToPosition(wOrder);
            eResult = TRUE;
            break;
        }
#elif DVB_C_ENABLE
        if (cPCN == cIDIndex)
        {
            *pwPosition = ConvertOrderToPosition(wOrder);
            eResult = TRUE;
            break;
        }
#else
        if( cPCN == pMuxTable[cIDIndex].cRFChannelNumber )
        {
            *pwPosition = ConvertOrderToPosition(wOrder);
            eResult = TRUE;
            break;
        }
#endif
    }

    return eResult;
}

#if ENABLE_SBTVD_BRAZIL_APP
//****************************************************************************
/// Get first position in msjor number
/// @param bServiceType \b IN: Service type
/// -@see MEMBER_SERVICETYPE
/// @param cPCN \b IN: PCN
/// @param *pwPosition \b IN: pointer to position for return
/// @return BOOLEAN: Function execution result
//****************************************************************************
BOOLEAN msAPI_CM_GetFirstPositionInMajorNum(MEMBER_SERVICETYPE bServiceType, BYTE cMajorNum, WORD * pwPosition)
{
    WORD wPosition;
    WORD wOrder;
    WORD wProgramCount;
    BOOLEAN eResult = FALSE;
    if( FALSE == IsPhysicalChannelNumberValid(cMajorNum) ||
        FALSE == IsServiceTypeValid(bServiceType) )
    {
        return FALSE;
    }

    wProgramCount = GetProgramCount(bServiceType, EXCLUDE_NOT_VISIBLE_AND_DELETED);
    for(wPosition=0; wPosition < wProgramCount; wPosition++)
    {
        wOrder = ConvertPositionToOrder(bServiceType, wPosition);

        if( cMajorNum == m_astDTVProgramIndexTable[wOrder].stLCN.bPhysicalChannel)
        {
            *pwPosition = ConvertOrderToPosition(wOrder);
            eResult = TRUE;
            break;
        }
    }

    return eResult;
}
#endif

//****************************************************************************
/// Get Service Type And Position With Physical Channel Number(PCN)
/// @param cPCN \b IN: Physical Channel Number
/// @param wService_ID \b IN: Service ID
/// @param peServiceType \b IN: pointer to service type to return
/// -@see MEMBER_SERVICETYPE
/// @param *pwPosition \b IN: pointer to position for return
/// @return BOOLEAN: Function execution result
//****************************************************************************
BOOLEAN msAPI_CM_GetServiceTypeAndPositionWithPCN(BYTE cPCN, WORD wService_ID, MEMBER_SERVICETYPE *peServiceType, WORD * pwPosition)
{
    WORD wOrder;

    if( FALSE == IsPhysicalChannelNumberValid(cPCN) ||
        FALSE == IsService_IDValid(wService_ID) )
    {
        return FALSE;
    }

    wOrder = GetOrderOfSameServiceWithPCN(cPCN, wService_ID);
    if( wOrder == INVALID_ORDER )
    {
        return FALSE;
    }

    *peServiceType = (MEMBER_SERVICETYPE)(m_astDTVProgramIndexTable[wOrder].bServiceType);

    *pwPosition = ConvertOrderToPosition(wOrder);

    return TRUE;
}

//****************************************************************************
/// Get Count Of Same Service With IDs
/// @param wTransportStream_ID \b IN: Transport Stream ID
/// @param wOriginalNetwork_ID \b IN: Original Network ID
/// @param wService_ID \b IN: Service ID
/// @return BYTE: Count
//****************************************************************************
BYTE msAPI_CM_GetCountOfSameServiceWithIDs(WORD wTransportStream_ID, WORD wOriginalNetwork_ID, WORD wService_ID)
{
    BYTE cCountOfSameService;

    if( FALSE == IsTS_IDValid(wTransportStream_ID) ||
        FALSE == IsON_IDValid(wOriginalNetwork_ID) ||
        FALSE == IsService_IDValid(wService_ID) )
    {
        return 0;
    }

    cCountOfSameService = GetCountOfSameServiceWithIDs(E_SERVICETYPE_DTV, wTransportStream_ID, wOriginalNetwork_ID, wService_ID, TRUE) + GetCountOfSameServiceWithIDs(E_SERVICETYPE_RADIO, wTransportStream_ID, wOriginalNetwork_ID, wService_ID, TRUE)+GetCountOfSameServiceWithIDs(E_SERVICETYPE_DATA, wTransportStream_ID, wOriginalNetwork_ID, wService_ID, TRUE);
    return cCountOfSameService;
}

//****************************************************************************
/// Get Service Type And Position With IDs
/// @param wTransportStream_ID \b IN: Transport Stream ID
/// @param wOriginalNetwork_ID \b IN: Original Network ID
/// @param cOrdinal \b IN: Ordinal
/// @param peServiceType \b IN: pointer to Service type for return
/// -@see MEMBER_SERVICETYPE
/// @param pwPosition \b IN: pointer to Position for return
/// @param bCheckTsID \b IN: check TS ID or not
/// @return BOOLEAN: Function execution result
//****************************************************************************
BOOLEAN msAPI_CM_GetServiceTypeAndPositionWithIDs(WORD wTransportStream_ID, WORD wOriginalNetwork_ID, WORD wService_ID, BYTE cOrdinal, MEMBER_SERVICETYPE * peServiceType, WORD * pwPosition, BOOLEAN bCheckTsID)
{
    WORD wOrder;
    MEMBER_SERVICETYPE bServiceType;


    if(bCheckTsID)bCheckTsID = IS_SID_UNIQUE_COUNTRY(m_eCountry) ? FALSE : TRUE;



    // if check ts id flag is 1, then check ts id -- we may not check ts id if it is dvb://xxx..xxx in MHEG 1.0.6 spec
    if( (bCheckTsID && (FALSE == IsTS_IDValid(wTransportStream_ID))) ||
        FALSE == IsON_IDValid(wOriginalNetwork_ID) ||
        FALSE == IsService_IDValid(wService_ID) ||
        0 == cOrdinal )
    {
        return FALSE;
    }

    if( cOrdinal <= GetCountOfSameServiceWithIDs(E_SERVICETYPE_DTV, wTransportStream_ID, wOriginalNetwork_ID, wService_ID, bCheckTsID) )
    {
        bServiceType = E_SERVICETYPE_DTV;
    }
    else if( cOrdinal <= GetCountOfSameServiceWithIDs(E_SERVICETYPE_RADIO, wTransportStream_ID, wOriginalNetwork_ID, wService_ID, bCheckTsID) )
    {
        bServiceType = E_SERVICETYPE_RADIO;
    }
    else if( cOrdinal <= GetCountOfSameServiceWithIDs(E_SERVICETYPE_DATA, wTransportStream_ID, wOriginalNetwork_ID, wService_ID, bCheckTsID) )
    {
        bServiceType = E_SERVICETYPE_DATA;
    }
    else
    {
        return FALSE;
    }

    wOrder = GetOrderOfSameServiceWithIDs(bServiceType, wTransportStream_ID, wOriginalNetwork_ID, wService_ID, cOrdinal, bCheckTsID);

    if( wOrder == INVALID_ORDER )
    {
        return FALSE;
    }
    *peServiceType = (MEMBER_SERVICETYPE)m_astDTVProgramIndexTable[wOrder].bServiceType;
    *pwPosition = ConvertOrderToPosition(wOrder);

    return TRUE;
}

//****************************************************************************
/// Move Program
/// @param peServiceType \b IN: pointer to Service type for return
/// -@see MEMBER_SERVICETYPE
/// @param wFromPosition \b IN: from Position
/// @param wToPosition \b IN: To Position
/// @return BOOLEAN: Function execution result
//****************************************************************************
BOOLEAN msAPI_CM_MoveProgram(MEMBER_SERVICETYPE bServiceType, WORD wFromPosition, WORD wToPosition)
{
    WORD wFromOrder, wToOrder;
    WORD wFromPRIndex, wToPRIndex;
    CHANNEL_ATTRIBUTE stFromCHAttribute, stToCHAttribute;
    MEMBER_SERVICETYPE l_eServiceType,bCurServiceType;
    WORD l_wPosition,wCurPosition;
    WORD wCurService_ID;
    WORD wPhysicalChannelNumber;

    if( FALSE == IsServiceTypeValid(bServiceType) )
    {
        return FALSE;
    }

    if( FALSE == IsPositionValid(bServiceType, wFromPosition) )
    {
        return FALSE;
    }

    if( FALSE == IsPositionValid(bServiceType, wToPosition) )
    {
        return FALSE;
    }

    bCurServiceType = msAPI_CM_GetCurrentServiceType();
    wCurPosition = msAPI_CM_GetCurrentPosition(bCurServiceType);
    wCurService_ID = msAPI_CM_GetService_ID(bCurServiceType, wCurPosition);
    wPhysicalChannelNumber = msAPI_CM_GetPhysicalChannelNumber(bCurServiceType, wCurPosition);

    wFromOrder = ConvertPositionToOrder(bServiceType, wFromPosition);
    wToOrder = ConvertPositionToOrder(bServiceType, wToPosition);

    wFromPRIndex = m_astDTVProgramIndexTable[wFromOrder].wPRIndex;
    GetProgramTable(wFromPRIndex, (BYTE *)&stFromCHAttribute, E_DATA_MISC);
    stFromCHAttribute.bIsMove = TRUE;
    m_astDTVProgramIndexTable[wFromOrder].bIsMove = stFromCHAttribute.bIsMove;

    wToPRIndex = m_astDTVProgramIndexTable[wToOrder].wPRIndex;
    GetProgramTable(wToPRIndex, (BYTE *)&stToCHAttribute, E_DATA_MISC);
    stToCHAttribute.bIsMove = TRUE;
    m_astDTVProgramIndexTable[wToOrder].bIsMove = stToCHAttribute.bIsMove;

    SwapProgram(wFromOrder, wToOrder);
//#if (ENABLE_DTV_EPG)
    //MApp_Epg_MoveSrvBuffer(wFromOrder, wToOrder);
//#endif  //#if (ENABLE_DTV_EPG)
    UpdateOrderOfProgramTable(bServiceType);


    msAPI_CM_GetServiceTypeAndPositionWithPCN(wPhysicalChannelNumber, wCurService_ID, &l_eServiceType, &l_wPosition);
    if (wCurPosition != l_wPosition)
    {
        msAPI_CM_SetCurrentPosition(bCurServiceType, l_wPosition);
    }

    if (SetProgramTable(wFromPRIndex, (BYTE *)&stFromCHAttribute, E_DATA_MISC)==TRUE &&\
        SetProgramTable(wToPRIndex, (BYTE *)&stToCHAttribute, E_DATA_MISC)==TRUE)
        return TRUE;
    else
        return FALSE;
}

#if (PRG_EDIT_INPUT_LCN_MOVE == 1)
FUNCTION_RESULT msAPI_CM_MoveLCN(MEMBER_SERVICETYPE bServiceType, WORD wPosition, WORD wLCN)
{
    WORD wOrder;

    MEMBER_SERVICETYPE bCurServiceType ,l_eServiceType;
    WORD wCurPosition = 0,l_wPosition;
    WORD wService_ID = 0;
    WORD wPhysicalChannelNumber = 0;

    //DBG_CM: printf("msAPI_CM_MoveProgram[Svr:%bu][From:%u][To:%u]\n",bServiceType,wFromPosition,wToPosition);
    if( FALSE == IsServiceTypeValid(bServiceType) )
    {
        return E_RESULT_INVALID_PARAMETER;
    }

    if( FALSE == IsPositionValid(bServiceType, wPosition) )
    {
        return E_RESULT_INVALID_PARAMETER;
    }

    bCurServiceType = msAPI_CM_GetCurrentServiceType();
    wCurPosition = msAPI_CM_GetCurrentPosition(bCurServiceType);
    wService_ID = msAPI_CM_GetService_ID(bCurServiceType, wCurPosition);
    wPhysicalChannelNumber = msAPI_CM_GetPhysicalChannelNumber(bCurServiceType, wCurPosition);

    wOrder = ConvertPositionToOrder(bServiceType, wPosition);

    #if 0
    ChangeLCN(bServiceType, wPosition, wLCN);
    #else
    SwapLCN(bServiceType, wPosition, wLCN);
    #endif
    SortProgram(bServiceType);
    UpdateOrderOfProgramTable(bServiceType);

    if(TRUE==msAPI_CM_GetServiceTypeAndPositionWithPCN(wPhysicalChannelNumber, wService_ID, &l_eServiceType, &l_wPosition))
    {
        if (wCurPosition != l_wPosition)
        {
            msAPI_CM_SetCurrentPosition(bCurServiceType, l_wPosition);
        }
    }

    return E_RESULT_SUCCESS;
}
#endif

//****************************************************************************
/// Set TS to Update
/// @param bCheck \b IN: only update TS or not
/// @param wTS_ID \b IN: TS ID
//****************************************************************************
void msAPI_CM_Set_TS_Update(BOOLEAN bCheck, WORD wTS_ID)
{
    _bOnlyUpdateCurTS=bCheck;
    _wCurTS_ID=wTS_ID;
}

//****************************************************************************
/// Remove Program
/// @param peServiceType \b IN: Service Type
/// -@see MEMBER_SERVICETYPE
/// @param wPosition \b IN: Position
/// @return BOOLEAN: Function execution result
//****************************************************************************
static BOOLEAN RemoveProgram(MEMBER_SERVICETYPE bServiceType, WORD wPosition)
{
    WORD wFromOrder;
    WORD wToOrder;
    WORD wRemovedPosition;
    WORD wPRIndex;
    WORD i;

    if( FALSE == IsServiceTypeValid(bServiceType) )
    {
        return FALSE;
    }

    if( FALSE == IsPositionValid(bServiceType, wPosition) )
    {
        return FALSE;
    }

    wRemovedPosition = GetProgramCount(bServiceType, INCLUDE_ALL) - 1;
    wFromOrder = ConvertPositionToOrder(bServiceType, wPosition);
    wToOrder = ConvertPositionToOrder(bServiceType, wRemovedPosition);
#if 0
    {
        BYTE name[MAX_SERVICE_NAME];
        msAPI_CM_GetServiceName(bServiceType,bServiceType,name);
        printf("%s.....sid %x name %s\n",__FUNCTION__,msAPI_CM_GetService_ID(bServiceType,wPosition),
            name);
    }
#endif

    MoveProgram(wFromOrder, wToOrder);
    UpdateOrderOfProgramTable(bServiceType);

    wPRIndex = m_astDTVProgramIndexTable[wToOrder].wPRIndex;
    FillProgramIndexWithDefault(&m_astDTVProgramIndexTable[wToOrder]);

    ActiveProgramEntity(wPRIndex, FALSE);

    UpdateProgramCount(bServiceType);
    if(bServiceType == E_SERVICETYPE_DATA && GetProgramCount(E_SERVICETYPE_RADIO, INCLUDE_ALL))
    {
        for(i=0;i<GetProgramCount(E_SERVICETYPE_RADIO, INCLUDE_ALL);i++)
        {
            memcpy(&m_astDTVProgramIndexTable[wToOrder-i],
                &m_astDTVProgramIndexTable[wToOrder-i-1 ],
                sizeof(DTVPROGRAMINDEX));
        }
        FillProgramIndexWithDefault(&m_astDTVProgramIndexTable[wToOrder-GetProgramCount(E_SERVICETYPE_RADIO, INCLUDE_ALL)]);
        UpdateOrderOfProgramTable(E_SERVICETYPE_RADIO);
    }
#if (ENABLE_DTV_EPG)
    if(_pfNotify_CM_RemoveProgram)
    {
        _pfNotify_CM_RemoveProgram(wFromOrder);
    }
#endif
    return TRUE;
}

//****************************************************************************
/// Remove Mismatched Program
/// @param peServiceType \b IN: Service Type
/// -@see MEMBER_SERVICETYPE
/// @param cRFChannelNumber \b IN: RF Channel Number
/// @param pwService_ID \b IN: Service ID
/// @param peService_Type \b IN: peService Type
/// @param cCountOfServiceID \b IN: Count Of Service ID
/// @return BOOLEAN: Function execution result
//****************************************************************************
static BYTE RemoveMismatchedProgram(MEMBER_SERVICETYPE bServiceType, BYTE cRFChannelNumber, BYTE cPlp_ID, BYTE cHpLp, WORD *pwService_ID, MEMBER_SERVICETYPE *peService_Type, BYTE cCountOfServiceID)
{
    BYTE cIDIndex;
    WORD wProgramCount;
    WORD wPosition;
    WORD wOrder;
    WORD wServiceId;
    WORD i;
    BYTE j;
    BYTE cRemovedProgramCount;
	DTVPROGRAMID_M *pMuxTable=_astDTVProgramIDTable;
    peService_Type=peService_Type;
#if DVB_T_C_DIFF_DB
	if (IsCATVInUse())pMuxTable=_astDTVCProgramIDTable;
#endif
    if( FALSE == IsServiceTypeValid(bServiceType) ||
        FALSE == IsPhysicalChannelNumberValid(cRFChannelNumber) )
    {
        return 0;
    }
#if ENABLE_T_C_COMBO
    if(IsCATVInUse())
    {
        UNUSED(cPlp_ID);
        UNUSED(cHpLp);
        cIDIndex = cRFChannelNumber;
    }
    else
    {
        for(cIDIndex=0; cIDIndex < MAX_MUX_NUMBER; cIDIndex++)
        {

            if( (cHpLp == pMuxTable[cIDIndex].cHpLp)
                 && (cPlp_ID == pMuxTable[cIDIndex].cPLPID) && (cRFChannelNumber == pMuxTable[cIDIndex].cRFChannelNumber) )
            {
                break;
            }

        }
    }
#elif DVB_C_ENABLE
    UNUSED(cPlp_ID);
    UNUSED(cHpLp);
    cIDIndex = cRFChannelNumber;
#else
    for(cIDIndex=0; cIDIndex < MAX_MUX_NUMBER; cIDIndex++)
    {

        if( (cHpLp == pMuxTable[cIDIndex].cHpLp)
                &&(cPlp_ID == pMuxTable[cIDIndex].cPLPID)
                && (cRFChannelNumber == pMuxTable[cIDIndex].cRFChannelNumber) )
        {
            break;
        }

    }
#endif

    if( MAX_MUX_NUMBER <= cIDIndex )
    {
        return 0;
    }

    cRemovedProgramCount = 0;
    wProgramCount = GetProgramCount(bServiceType, INCLUDE_ALL);
    wPosition = wProgramCount-1;

    for(i=wProgramCount; i > 0; i--)
    {
        wOrder = ConvertPositionToOrder(bServiceType, wPosition);
        cIDIndex = m_astDTVProgramIndexTable[wOrder].cIDIndex;
#if ENABLE_T_C_COMBO
        if (IsCATVInUse() && (cIDIndex != cRFChannelNumber))
        {
            wPosition--;
            continue;
        }
#elif DVB_C_ENABLE
        if ((cIDIndex != cRFChannelNumber))
        {
            wPosition--;
            continue;
        }
#endif
#if ENABLE_T_C_COMBO
        if ((IsCATVInUse() &&(cIDIndex == cRFChannelNumber)) ||
           ( !IsCATVInUse()&& (cRFChannelNumber == pMuxTable[cIDIndex].cRFChannelNumber)
            && (cPlp_ID == pMuxTable[cIDIndex].cPLPID)
            &&(cHpLp == pMuxTable[cIDIndex].cHpLp)))
#elif DVB_C_ENABLE
        if (cIDIndex == cRFChannelNumber)
#else
        if( (cRFChannelNumber == pMuxTable[cIDIndex].cRFChannelNumber)
            && ((cPlp_ID == pMuxTable[cIDIndex].cPLPID)
            &&(cHpLp == pMuxTable[cIDIndex].cHpLp)))
#endif
        {
            wServiceId = m_astDTVProgramIndexTable[wOrder].wService_ID;

            for(j=0; j < cCountOfServiceID; j++)
            {
                if(pwService_ID[j] == wServiceId )//the service type maybe changed, don't check type//&& peService_Type[j] == bServiceType)
                {
                    break;
                }
            }
            if(( cCountOfServiceID <= j )
                || ((_wCurTSID != INVALID_TS_ID) && (pMuxTable[cIDIndex].wTransportStream_ID != _wCurTSID)))
            {
                RemoveProgram(bServiceType, wPosition);
                cRemovedProgramCount++;
            }
        }

        wPosition--;
    }

    return cRemovedProgramCount;
}

//****************************************************************************
/// Remove Same Program
/// @param peServiceType \b IN: Service Type
/// -@see MEMBER_SERVICETYPE
//****************************************************************************
static void RemoveSameService(MEMBER_SERVICETYPE bServiceType)//for Nordig Spec
{
    WORD wProgramCount;
    WORD wPosition;
    WORD wOrder;
    WORD i;

    if( FALSE == IsServiceTypeValid(bServiceType))
    {
        return ;
    }
    wProgramCount = GetProgramCount(bServiceType, INCLUDE_ALL);
    wPosition = wProgramCount-1;
    for(i=wProgramCount; i > 0; i--)
    {
        wOrder = ConvertPositionToOrder(bServiceType, wPosition);
        if(m_astDTVProgramIndexTable[wOrder].eLCNAssignmentType & E_LCN_SAME_SERVICE)
        {
            #if ( WATCH_DOG == ENABLE )
            msAPI_Timer_ResetWDT();
            #endif

            RemoveProgram(bServiceType, wPosition);
        }
        wPosition--;
    }

}

//****************************************************************************
/// Remove Mismatched Program
/// @param cRFChannelNumber \b IN: RF Channel Number
/// @param peServiceType \b IN: Service Type
/// -@see MEMBER_SERVICETYPE
/// @param pwService_ID \b IN: Service ID
/// @param cCountOfServiceID \b IN: Count Of Service ID
/// @return BYTE: Removed Program Count
//****************************************************************************
BYTE msAPI_CM_RemoveMismatchedProgram(BYTE cRFChannelNumber, WORD wTSID, BYTE cPLP_ID, BYTE cHpLp, WORD *pwService_ID, MEMBER_SERVICETYPE *peService_Type, BYTE cCountOfServiceID)
{
    BYTE cRemovedProgramCount=0;
    MEMBER_SERVICETYPE bServiceType, l_eServiceType;
    WORD wPosition, l_wPosition;
    WORD wService_ID;
    WORD wPhysicalChannelNumber;
    WORD wProgCount;
    BOOLEAN eResult;

    bServiceType = msAPI_CM_GetCurrentServiceType();
    wPosition = msAPI_CM_GetCurrentPosition(bServiceType);
    wService_ID = msAPI_CM_GetService_ID(bServiceType, wPosition);
    wPhysicalChannelNumber = msAPI_CM_GetPhysicalChannelNumber(bServiceType,wPosition);

    if( FALSE == IsPhysicalChannelNumberValid(cRFChannelNumber) )
    {
        return 0;
    }
    if(cCountOfServiceID>0)
    {
        _wCurTSID=wTSID;
    }
    cRemovedProgramCount += RemoveMismatchedProgram(E_SERVICETYPE_DTV, cRFChannelNumber, cPLP_ID, cHpLp, pwService_ID, peService_Type, cCountOfServiceID);
    cRemovedProgramCount += RemoveMismatchedProgram(E_SERVICETYPE_DATA, cRFChannelNumber, cPLP_ID, cHpLp, pwService_ID, peService_Type, cCountOfServiceID);
    cRemovedProgramCount += RemoveMismatchedProgram(E_SERVICETYPE_RADIO, cRFChannelNumber, cPLP_ID, cHpLp, pwService_ID, peService_Type, cCountOfServiceID);
    _wCurTSID=INVALID_TS_ID;
    if(cRemovedProgramCount)
    {
        __msAPI_CM_ArrangeDataManager(TRUE,FALSE,FALSE);
        wProgCount = msAPI_CM_CountProgram(bServiceType, E_PROGACESS_INCLUDE_NOT_VISIBLE_ALSO);
        if(wProgCount)
        {
            //find service with same RF and S_ID
            l_eServiceType = bServiceType;
            eResult = msAPI_CM_GetServiceTypeAndPositionWithPCN(wPhysicalChannelNumber, wService_ID, &l_eServiceType, &l_wPosition);
            if(TRUE != eResult || l_eServiceType != bServiceType)
            {
                //find first service of current physical channel if service is not exist
                if(TRUE != msAPI_CM_GetFirstPositionInPCN(bServiceType, wPhysicalChannelNumber, &l_wPosition))
            {
                l_wPosition = msAPI_CM_GetFirstProgramPosition(bServiceType, FALSE);
                if(INVALID_PROGRAM_POSITION == l_wPosition)
                {
                    //printf("Get program fail from bServiceType %bu\n", bServiceType);
                    }
                }
            }
            if(l_wPosition != wPosition)
            {
                msAPI_CM_SetCurrentPosition(bServiceType, l_wPosition);
            }

        }
        else
        {
            //service type change
            bServiceType = (bServiceType == E_SERVICETYPE_DTV ? E_SERVICETYPE_RADIO : E_SERVICETYPE_DTV);
            msAPI_CM_SetCurrentServiceType(bServiceType);
            wPosition = msAPI_CM_GetFirstProgramPosition(bServiceType, FALSE);
            msAPI_CM_SetCurrentPosition(bServiceType, wPosition);
        }

    }
    return cRemovedProgramCount;
}

//****************************************************************************
/// Fill Program Data With Default
/// @param pDTVProgramData \b IN: DTV Program Data
/// -@see DTV_CHANNEL_INFO
/// @return BOOLEAN: Function execution result
//****************************************************************************
BOOLEAN msAPI_CM_FillProgramDataWithDefault(DTV_CHANNEL_INFO *pDTVProgramData)
{
    if( pDTVProgramData )
    {
        return FillProgramDataWithDefault((BYTE *)pDTVProgramData, E_DATA_ALL);
    }

    return FALSE;
}

#if 0//ENABLE_SCAN_CM_DEBUG
//****************************************************************************
/// Print All Program
//****************************************************************************
void msAPI_CM_PrintAllProgram(void)
{
    WORD wPosition;
    WORD wProgramCount;

    wProgramCount = GetProgramCount(E_SERVICETYPE_DTV, INCLUDE_ALL);
    printf("=== DTV Programs #[%u] ===\n", wProgramCount);
    for(wPosition=0; wPosition < wProgramCount; wPosition++)
    {
        msAPI_CM_PrintProgram(E_SERVICETYPE_DTV, wPosition);
    }

    wProgramCount = GetProgramCount(E_SERVICETYPE_RADIO, INCLUDE_ALL);
    printf("\n=== RADIO Programs #[%u] ===\n", wProgramCount);
    for(wPosition=0; wPosition < wProgramCount; wPosition++)
    {
        msAPI_CM_PrintProgram(E_SERVICETYPE_RADIO, wPosition);
    }

    printf("\n\n");
}

//****************************************************************************
/// Print Program
//****************************************************************************
void msAPI_CM_PrintProgram(MEMBER_SERVICETYPE bServiceType, WORD wPosition)
{
    WORD wOrder;
    WORD wProgramCount;
    BYTE cIDIndex;
    BYTE bChannelName[MAX_SERVICE_NAME];
    //BYTE i;

    if( FALSE == IsServiceTypeValid(bServiceType) )
    {
        return;
    }

    wProgramCount = GetProgramCount(bServiceType, INCLUDE_ALL);

    if( wProgramCount <= wPosition )
    {
        return;
    }

    wOrder = ConvertPositionToOrder(bServiceType, wPosition);

    cIDIndex = m_astDTVProgramIndexTable[wOrder].cIDIndex;
    memset(bChannelName, 0x00, MAX_SERVICE_NAME);
    GetProgramTable(m_astDTVProgramIndexTable[wOrder].wPRIndex, (BYTE *)bChannelName, E_DATA_SERVICE_NAME);
    printf("[%4u]LCN %05u SID %05u Phy %02u SType %u Vis %u Sel %u Move %u Scr %u Mheg %u SidOnly %u HD %u Name: %s \n",
            wOrder,
            m_astDTVProgramIndexTable[wOrder].wLCN,
            m_astDTVProgramIndexTable[wOrder].wService_ID,
            _astDTVProgramIDTable[cIDIndex].cRFChannelNumber,
            (U8)m_astDTVProgramIndexTable[wOrder].bServiceType,
            (U8)m_astDTVProgramIndexTable[wOrder].bVisibleServiceFlag,
            (U8)m_astDTVProgramIndexTable[wOrder].bNumericSelectionFlag,
            (U8)m_astDTVProgramIndexTable[wOrder].bIsMove,
            (U8)m_astDTVProgramIndexTable[wOrder].bIsScramble,
            (U8)m_astDTVProgramIndexTable[wOrder].bIsMHEGIncluded,
            (U8)m_astDTVProgramIndexTable[wOrder].bIsServiceIdOnly,
            (U8)m_astDTVProgramIndexTable[wOrder].eVideoType,
            bChannelName
            );
#if 0 // refine log msg
    for(i = 0; i < MAX_SERVICE_NAME; i++)
    {
        GetProgramTable(m_astDTVProgramIndexTable[wOrder].wPRIndex, (BYTE *)bChannelName, E_DATA_SERVICE_NAME);

        if(bChannelName[i] == NULL)
        {
            break;
        }

        printf("%c",(BYTE)bChannelName[i]);
    }
    printf("\n");
#endif

}
#endif

//****************************************************************************
// Start of private implementation
//****************************************************************************

//****************************************************************************
/// Is Service Type Valid
/// @param bServiceType \b IN: Service Type
/// -@see MEMBER_SERVICETYPE
/// @return BOOLEAN:
/// - 1: Default is valid
/// - 0: NO
//****************************************************************************
static BOOLEAN IsServiceTypeValid(MEMBER_SERVICETYPE bServiceType)
{
    if( bServiceType == E_SERVICETYPE_DTV || bServiceType == E_SERVICETYPE_RADIO || bServiceType == E_SERVICETYPE_DATA)
    {
        return TRUE;
    }

    return FALSE;
}

//****************************************************************************
/// Is Position Valid
/// @param bServiceType \b IN: Service Type
/// -@see MEMBER_SERVICETYPE
/// @param wPosition \b IN: Position
/// @return BOOLEAN:
/// - 1: Default is valid
/// - 0: NO
//****************************************************************************
static BOOLEAN IsPositionValid(MEMBER_SERVICETYPE bServiceType, WORD wPosition)
{
    if( bServiceType == E_SERVICETYPE_DTV || bServiceType == E_SERVICETYPE_RADIO || bServiceType == E_SERVICETYPE_DATA)
    {
        if( wPosition < GetProgramCount(bServiceType, INCLUDE_ALL) )
        {
            return TRUE;
        }
    }

    return FALSE;
}

//****************************************************************************
/// Is Logical Channel Number Valid
/// @param wLCN \b IN: LCN (Logical Channel Number)
/// @return BOOLEAN:
/// - 1: Default is valid
/// - 0: NO
//****************************************************************************
static BOOLEAN IsLogicalChannelNumberValid(WORD wLCN)
{
    // Dummy code for avoid compile warning
  #if 0
    wLCN = 0;
  #else  // Modified by coverity_0468
    UNUSED(wLCN);
  #endif

    return TRUE;
}

//****************************************************************************
/// Is Physical Channel Number Valid
/// @param cRFChannelNumber \b IN: RF Channel Number
/// @return BOOLEAN:
/// - 1: Default is valid
/// - 0: NO
//****************************************************************************
static BOOLEAN IsPhysicalChannelNumberValid(WORD cRFChannelNumber)
{
    // Dummy code for avoid compile warning
  #if 0
    cRFChannelNumber = 0;
  #else // Modified by coverity_0469
    UNUSED(cRFChannelNumber);
  #endif

    return TRUE;
}

//****************************************************************************
/// Is Version Valid
/// @param cVersion \b IN: Version
/// @return BOOLEAN:
/// - 1: Default is valid
/// - 0: NO
//****************************************************************************
static BOOLEAN IsVersionValid(BYTE cVersion)
{
    // Dummy code for avoid compile warning
    if((cVersion != DEFAULT_VERSION) && (cVersion > 31))
    {
        return FALSE;
    }

    return TRUE;
}

//****************************************************************************
/// Is TS_ID Valid
/// @param wTransportStream_ID \b IN: Transport Stream ID
/// @return BOOLEAN:
/// - 1: Default is valid
/// - 0: NO
//****************************************************************************
static BOOLEAN IsTS_IDValid(WORD wTransportStream_ID)
{
    // Dummy code for avoid compile warning
  #if 0
    wTransportStream_ID = 0;
  #else // Modified by coverity_0470
    UNUSED(wTransportStream_ID);
  #endif

    return TRUE;
}

//****************************************************************************
/// Is ON_ID Valid
/// @param wOriginalNetwork_ID \b IN: Original Network ID
/// @return BOOLEAN:
/// - 1: Default is valid
/// - 0: NO
//****************************************************************************
static BOOLEAN IsON_IDValid(WORD wOriginalNetwork_ID)
{
    // Dummy code for avoid compile warning
  #if 0
    wOriginalNetwork_ID = 0;
  #else // Modified by coverity_0471
    UNUSED(wOriginalNetwork_ID);
  #endif

    return TRUE;
}

//****************************************************************************
/// Is Service ID Valid
/// @param Service_ID \b IN: Service ID
/// @return BOOLEAN:
/// - 1: Default is valid
/// - 0: NO
//****************************************************************************
static BOOLEAN IsService_IDValid(WORD Service_ID)
{
    // Dummy code for avoid compile warning
  #if 0
    Service_ID = 0;
  #else // Modified by coverity_0472
    UNUSED(Service_ID);
  #endif

    return TRUE;
}

//****************************************************************************
/// Is PMT PID Valid
/// @param wPMT_PID \b IN: PMT PID
/// @return BOOLEAN:
/// - 1: Default is valid
/// - 0: NO
//****************************************************************************
static BOOLEAN IsPMT_PIDValid(WORD wPMT_PID)
{
    if( ((0x0010 <= wPMT_PID) && (wPMT_PID <= 0x1FFF)) )
    {
        return TRUE;
    }

    return FALSE;
}

//****************************************************************************
/// Is PCR_PID Valid
/// @param wPCR_PID \b IN: PCR PID
/// @return BOOLEAN:
/// - 1: Default is valid
/// - 0: NO
//****************************************************************************
static BOOLEAN IsPCR_PIDValid(WORD wPCR_PID)
{
    if( (wPCR_PID <= 0x0001) || ((0x0010 <= wPCR_PID) && (wPCR_PID <= 0x1FFF)) )
    {
        return TRUE;
    }

    return FALSE;
}

//****************************************************************************
/// Is Video PID Valid
/// @param wVideo_PID \b IN: Video PID
/// @return BOOLEAN:
/// - 1: Default is valid
/// - 0: NO
//****************************************************************************
static BOOLEAN IsVideoPIDValid(WORD wVideo_PID)
{
    if( (wVideo_PID <= 0x000F) || (0x1FFF < wVideo_PID) )
    {
        return FALSE;
    }

    return TRUE;
}

//****************************************************************************
/// Is Audio Stream Info Valid
/// @param pastAudioStreamInfo \b IN: Audio Stream Info
/// - @see AUD_INFO
/// @return BOOLEAN:
/// - 1: Default is valid
/// - 0: NO
//****************************************************************************
static BOOLEAN IsAudioStreamInfoValid(AUD_INFO * pastAudioStreamInfo)
{
    // Dummy code for avoid compile warning
    pastAudioStreamInfo = pastAudioStreamInfo;
    return TRUE;
}


//****************************************************************************
/// Is Audio PID Valid
/// @param wAudPID \b IN: Audio PID
/// @return BOOLEAN:
/// - 1: Default is valid
/// - 0: NO
//****************************************************************************
static BOOLEAN IsAudioPIDValid(WORD wAudPID)
{
    if( (wAudPID <= 0x000F) || (0x1FFF <= wAudPID) )
    {
        return FALSE;
    }

    return TRUE;
}
#if 0
static BOOLEAN IsAudioStreamModeValid(AUDIOSTREAM_TYPE wAudType)
{
    // Dummy code for avoid compile warning
    wAudType = (AUDIOSTREAM_TYPE)0;
    return TRUE;
}

static BOOLEAN _IsAudioLanguageCodeValid(AUDIO_LANG_CODE eAudioLangCode)
{
//TODO
    // Dummy code for avoid compile warning
    eAudioLangCode = (AUDIO_LANG_CODE)0;
    return TRUE;
}
#endif

//****************************************************************************
/// Is Logical Channel Number Arranged
/// @return BOOLEAN:
/// - 1: Default is arranged
/// - 0: NO
//****************************************************************************
static BOOLEAN IsLogicalChannelNumberArranged(void)
{
    BOOLEAN bIsArranged=TRUE;

    GetNVRAM(BASEADDRESS_PR_IS_LCN_ARRANGED, (BYTE *)&bIsArranged, sizeof(bIsArranged));

    if( bIsArranged == TRUE || bIsArranged == FALSE )
    {
        return bIsArranged;
    }

    return FALSE;
}

//****************************************************************************
/// This function will set Logical Channel Number is Arranged
/// @param bIsArranged \b IN: Is Arranged or not
//****************************************************************************
static void LogicalChannelNumberIsArranged(BOOLEAN bIsArranged)
{
    if( bIsArranged == TRUE || bIsArranged == FALSE )
    {
        SetNVRAM(BASEADDRESS_PR_IS_LCN_ARRANGED, (BYTE *)&bIsArranged, sizeof(bIsArranged));
    }
}

//****************************************************************************
/// Convert Position To Order
/// @param bServiceType \b IN: Service Type
/// - @see MEMBER_SERVICETYPE
/// @param wPosition \b IN: Position
/// @return WORD: order
//****************************************************************************
static WORD ConvertPositionToOrder(MEMBER_SERVICETYPE bServiceType, WORD wPosition)
{
    WORD wStartOrderOfRadio;

    #if DVB_T_C_DIFF_DB
    if (IsCATVInUse())
    {
        wStartOrderOfRadio = MAX_DTV_C_PROGRAM-m_awDVBCProgramCount[E_CM_SERVICE_POS_DATA][INCLUDE_ALL]-1;
    }
    else
    #endif
    wStartOrderOfRadio = MAX_DTVPROGRAM-m_awProgramCount[E_CM_SERVICE_POS_DATA][INCLUDE_ALL]-1;
    if( bServiceType == E_SERVICETYPE_DTV )
    {
        if( wPosition < MAX_DTVPROGRAM )
        {
            return wPosition;
        }
        else
        {
            return LAST_ORDER_OF_TV;
        }
    }
    else if( bServiceType == E_SERVICETYPE_RADIO )
    {
        if( wPosition < (wStartOrderOfRadio+1) )
        {
            return (wStartOrderOfRadio-wPosition);
        }
        else
        {
            return LAST_ORDER_OF_RADIO;
        }
    }
    else
    {
        if( wPosition < MAX_DTVPROGRAM )
        {
            return (MAX_DTVPROGRAM - wPosition - 1);
        }
        else
        {
            return LAST_ORDER_OF_DATA;
        }
    }
}

//****************************************************************************
/// Convert Order To Position
/// @param wOrder \b IN: Order
/// @return WORD: Position
//****************************************************************************
static WORD ConvertOrderToPosition(WORD wOrder)
{
    U8 bServiceType;
    WORD wStartOrderOfRadio = LAST_ORDER_OF_RADIO;

    #if DVB_T_C_DIFF_DB
    if (IsCATVInUse())
    {
        bServiceType = m_astDTVProgramIndexTable[wOrder].bServiceType;
        wStartOrderOfRadio = MAX_DTV_C_PROGRAM - m_awDVBCProgramCount[E_CM_SERVICE_POS_DATA][INCLUDE_ALL]-1;
    }
    else
    {
        bServiceType = m_astDTVProgramIndexTable[wOrder].bServiceType;
        wStartOrderOfRadio = MAX_DTVPROGRAM - m_awProgramCount[E_CM_SERVICE_POS_DATA][INCLUDE_ALL]-1;
    }
    #else
    bServiceType = m_astDTVProgramIndexTable[wOrder].bServiceType;
    wStartOrderOfRadio = MAX_DTVPROGRAM - m_awProgramCount[E_CM_SERVICE_POS_DATA][INCLUDE_ALL]-1;
    #endif

    if( E_SERVICETYPE_DTV == bServiceType )
    {
        if( wOrder < MAX_DTVPROGRAM )
        {
            return wOrder;
        }
        else
        {
            return MAX_DTVPROGRAM - 1;
        }
    }
    else if( E_SERVICETYPE_RADIO == bServiceType )
    {
        if( wOrder < (wStartOrderOfRadio+1) )
        {
            return (wStartOrderOfRadio - wOrder);
        }
        else
        {
            return wStartOrderOfRadio;
        }
    }
    else
    {
        if( wOrder < MAX_DTVPROGRAM )
        {
            return (MAX_DTVPROGRAM - wOrder - 1);
        }
        else
        {
            return MAX_DTVPROGRAM - 1;
        }
    }
}

//****************************************************************************
/// Creat DTV Program Index Table And Program ID Table
/// @return BOOLEAN: Function execution result
//****************************************************************************
static BOOLEAN CreatDTVProgramIndexTableAndProgramIDTable(void)
{
    WORD wOrder;

    for(wOrder = 0; wOrder < MAX_DTVPROGRAM; wOrder++)
    {
        FillProgramIndexWithDefault(&m_astDTVProgramIndexTable[wOrder]);
    }

    if( TRUE == IsLogicalChannelNumberArranged() &&
        TRUE == IsLinkOfOrderValid() )
    {
        FillDTVProgramIndexTableWithOrder();
        UpdateProgramCount(E_SERVICETYPE_DTV);
        UpdateProgramCount(E_SERVICETYPE_DATA);
        UpdateProgramCount(E_SERVICETYPE_RADIO);
        UpdateIDInfo();

    }
    else if( TRUE == IsLogicalChannelNumberArranged() )
    {
        FillDTVProgramIndexTableWithoutOrder();
        UpdateProgramCount(E_SERVICETYPE_DTV);
        UpdateProgramCount(E_SERVICETYPE_DATA);
        UpdateProgramCount(E_SERVICETYPE_RADIO);
        UpdateIDInfo();
        SortProgram(E_SERVICETYPE_DTV);
        SortProgram(E_SERVICETYPE_RADIO);
        SortProgram(E_SERVICETYPE_DATA);
        UpdateOrderOfProgramTable(E_SERVICETYPE_DTV);
        UpdateOrderOfProgramTable(E_SERVICETYPE_DATA);
        UpdateOrderOfProgramTable(E_SERVICETYPE_RADIO);
    }
    else
    {
        msAPI_CM_ArrangeDataManager(TRUE,FALSE);
    }

    return TRUE;
}

//****************************************************************************
/// Is Link Of Order Valid
/// @return BOOLEAN:
/// - 1: Default is Valid
/// - 0: NO
//****************************************************************************
static BOOLEAN IsLinkOfOrderValid(void)
{
    BYTE cMapForCheckingDuplicationOfOrder[MAX_DTVCHANNELTABLE_MAP];
    WORD wPRIndex;
    WORD wOrder;

    for(wPRIndex=0; wPRIndex < (MAX_DTVCHANNELTABLE_MAP); wPRIndex++)
    {
        cMapForCheckingDuplicationOfOrder[wPRIndex] = 0x00;
    }

    for(wPRIndex=0; wPRIndex < MAX_DTVPROGRAM; wPRIndex++)
    {
        if( TRUE == IsProgramEntityActive(wPRIndex) )
        {
            GetProgramTable(wPRIndex, (BYTE *)&wOrder, E_DATA_ORDER);

            if( MAX_DTVPROGRAM <= wOrder )
            {
//                printf("Not linked case: %u\n", wPRIndex);
                return FALSE; // not linked case.
            }

            if( TRUE == (cMapForCheckingDuplicationOfOrder[wOrder/8] & (0x01 << (wOrder%8))) )
            {
//                printf("Duplicated case: %u\n", wPRIndex);
                return FALSE; // duplicated case.
            }
            else
            {
                cMapForCheckingDuplicationOfOrder[wOrder/8] |= (0x01 << (wOrder%8));
            }
        }
    }

    return TRUE;
}

//****************************************************************************
/// Fill DTV Program Index Table With Order
/// @return BOOLEAN: Function execution result
//****************************************************************************
static BOOLEAN FillDTVProgramIndexTableWithOrder(void)
{
    WORD wPRIndex;
    WORD wOrder;
    WORD wValue;
    CHANNEL_ATTRIBUTE stCHAttribute;

    for( wPRIndex=0; wPRIndex < MAX_DTVPROGRAM; wPRIndex++)
    {
        if( TRUE == IsProgramEntityActive(wPRIndex) )
        {
            GetProgramTable(wPRIndex, (BYTE *)&wOrder, E_DATA_ORDER);

            GetProgramTable(wPRIndex, (BYTE *)&stCHAttribute, E_DATA_MISC);
            m_astDTVProgramIndexTable[wOrder].bServiceType = stCHAttribute.bServiceType;
            m_astDTVProgramIndexTable[wOrder].bVisibleServiceFlag = stCHAttribute.bVisibleServiceFlag;
            m_astDTVProgramIndexTable[wOrder].bIsDelete = stCHAttribute.bIsDelete;
            m_astDTVProgramIndexTable[wOrder].bIsReplaceDel = stCHAttribute.bIsReplaceDel;
            m_astDTVProgramIndexTable[wOrder].bIsFavorite = stCHAttribute.bIsFavorite;
            m_astDTVProgramIndexTable[wOrder].bIsSkipped = stCHAttribute.bIsSkipped;
            m_astDTVProgramIndexTable[wOrder].bIsLock = stCHAttribute.bIsLock;
            m_astDTVProgramIndexTable[wOrder].bIsStillPicture = stCHAttribute.bIsStillPicture;
            m_astDTVProgramIndexTable[wOrder].bIsMove = stCHAttribute.bIsMove;
            m_astDTVProgramIndexTable[wOrder].bInvalidCell = stCHAttribute.bInvalidCell;
            m_astDTVProgramIndexTable[wOrder].bUnconfirmedService = stCHAttribute.bUnconfirmedService;
            m_astDTVProgramIndexTable[wOrder].bInvalidService = stCHAttribute.bInvalidService;
            m_astDTVProgramIndexTable[wOrder].bNumericSelectionFlag = stCHAttribute.bNumericSelectionFlag;
            m_astDTVProgramIndexTable[wOrder].bIsSpecialService = stCHAttribute.bIsSpecialService;
            m_astDTVProgramIndexTable[wOrder].bServiceTypePrio = stCHAttribute.bServiceTypePrio;
            m_astDTVProgramIndexTable[wOrder].bIsScramble = stCHAttribute.bIsScramble;
            m_astDTVProgramIndexTable[wOrder].bReplaceService = stCHAttribute.bReplaceService;
            m_astDTVProgramIndexTable[wOrder].bIsServiceIdOnly = stCHAttribute.bIsServiceIdOnly;
            m_astDTVProgramIndexTable[wOrder].eVideoType = stCHAttribute.eVideoType;
            #if ENABLE_T_C_CHANNEL_MIX
            m_astDTVProgramIndexTable[wOrder].bIsTerrestrial = stCHAttribute.bIsTerrestrial;
            #endif

            GetProgramTable(wPRIndex, (BYTE *)&wValue, E_DATA_LCN);
            m_astDTVProgramIndexTable[wOrder].wLCN = wValue;
            GetProgramTable(wPRIndex, (BYTE *)&wValue, E_DATA_SIMU_LCN);
            m_astDTVProgramIndexTable[wOrder].wSimu_LCN = wValue;
            GetProgramTable(wPRIndex, (BYTE *)&wValue, E_DATA_SERVICE_ID);
            m_astDTVProgramIndexTable[wOrder].wService_ID = wValue;
            GetProgramTable(wPRIndex, (BYTE *)&wValue, E_DATA_ID_INDEX);
            m_astDTVProgramIndexTable[wOrder].cIDIndex = wValue;

            m_astDTVProgramIndexTable[wOrder].wPRIndex = wPRIndex;
        }
    }

    return TRUE;
}

//****************************************************************************
/// Fill DTV Program Index Table Without Order
/// @return BOOLEAN: Function execution result
//****************************************************************************
static BOOLEAN FillDTVProgramIndexTableWithoutOrder(void)
{
    WORD wPRIndex;
    WORD wOrderOfTV;
    WORD wOrderOfRadio;
    WORD wOrderOfData;
    WORD wOrder,wIDs_1=INVALID_TS_ID;
    WORD wValue;
    CHANNEL_ATTRIBUTE stCHAttribute;

    wOrderOfTV = FIRST_ORDER_OF_TV;
    wOrderOfRadio = FIRST_ORDER_OF_RADIO;
    wOrderOfData = FIRST_ORDER_OF_DATA;
    wOrder = 0;

    for(wPRIndex=0; wPRIndex < MAX_DTVPROGRAM; wPRIndex++)
    {
        if( TRUE == IsProgramEntityActive(wPRIndex) )
        {
            GetProgramTable(wPRIndex, (BYTE *)&stCHAttribute, E_DATA_MISC);

            if( stCHAttribute.bServiceType == E_SERVICETYPE_DATA )
            {
                wOrderOfRadio--;
            }
        }
    }

    for(wPRIndex=0; wPRIndex < MAX_DTVPROGRAM; wPRIndex++)
    {
        if( TRUE == IsProgramEntityActive(wPRIndex) )
        {
            GetProgramTable(wPRIndex, (BYTE *)&stCHAttribute, E_DATA_MISC);

            if( stCHAttribute.bServiceType == E_SERVICETYPE_DTV )
            {
                wOrder = wOrderOfTV;
            }
            else if( stCHAttribute.bServiceType == E_SERVICETYPE_RADIO )
            {
                wOrder = wOrderOfRadio;
            }
            else if( stCHAttribute.bServiceType == E_SERVICETYPE_DATA )
            {
                wOrder = wOrderOfData;
            }
            else
            {
                ActiveProgramEntity(wPRIndex, FALSE);
                continue;
            }

            m_astDTVProgramIndexTable[wOrder].bServiceType = stCHAttribute.bServiceType;
            m_astDTVProgramIndexTable[wOrder].bVisibleServiceFlag = stCHAttribute.bVisibleServiceFlag;
            m_astDTVProgramIndexTable[wOrder].bIsDelete = stCHAttribute.bIsDelete;
            m_astDTVProgramIndexTable[wOrder].bIsReplaceDel = stCHAttribute.bIsReplaceDel;
            m_astDTVProgramIndexTable[wOrder].bIsFavorite = stCHAttribute.bIsFavorite;
            m_astDTVProgramIndexTable[wOrder].bIsSkipped = stCHAttribute.bIsSkipped;
            m_astDTVProgramIndexTable[wOrder].bIsLock = stCHAttribute.bIsLock;
            m_astDTVProgramIndexTable[wOrder].bIsStillPicture = stCHAttribute.bIsStillPicture;
            m_astDTVProgramIndexTable[wOrder].bIsMove = stCHAttribute.bIsMove;
            m_astDTVProgramIndexTable[wOrder].bInvalidCell = stCHAttribute.bInvalidCell;
            m_astDTVProgramIndexTable[wOrder].bUnconfirmedService = stCHAttribute.bUnconfirmedService;
            m_astDTVProgramIndexTable[wOrder].bInvalidService = stCHAttribute.bInvalidService;
            m_astDTVProgramIndexTable[wOrder].bNumericSelectionFlag = stCHAttribute.bNumericSelectionFlag;
            m_astDTVProgramIndexTable[wOrder].bIsSpecialService = stCHAttribute.bIsSpecialService;
            m_astDTVProgramIndexTable[wOrder].bServiceTypePrio = stCHAttribute.bServiceTypePrio;
            m_astDTVProgramIndexTable[wOrder].bIsScramble = stCHAttribute.bIsScramble;
            m_astDTVProgramIndexTable[wOrder].bReplaceService = stCHAttribute.bReplaceService;
            m_astDTVProgramIndexTable[wOrder].bIsServiceIdOnly = stCHAttribute.bIsServiceIdOnly;
            m_astDTVProgramIndexTable[wOrder].eVideoType = stCHAttribute.eVideoType;
            #if ENABLE_T_C_CHANNEL_MIX
            m_astDTVProgramIndexTable[wOrder].bIsTerrestrial = stCHAttribute.bIsTerrestrial;
            #endif

            GetProgramTable(wPRIndex, (BYTE *)&wValue, E_DATA_LCN);
            m_astDTVProgramIndexTable[wOrder].wLCN = wValue;
            GetProgramTable(wPRIndex, (BYTE *)&wValue, E_DATA_SIMU_LCN);
            m_astDTVProgramIndexTable[wOrder].wSimu_LCN = wValue;
            GetProgramTable(wPRIndex, (BYTE *)&wValue, E_DATA_SERVICE_ID);
            m_astDTVProgramIndexTable[wOrder].wService_ID = wValue;
            GetProgramTable(wPRIndex, (BYTE *)&wValue, E_DATA_ID_INDEX);
            m_astDTVProgramIndexTable[wOrder].cIDIndex = wValue;

            m_astDTVProgramIndexTable[wOrder].wPRIndex = wPRIndex;

            if(_bOnlyUpdateCurTS)
            {
                GetIDTable(m_astDTVProgramIndexTable[wOrder].cIDIndex, (BYTE *)&wIDs_1, E_DATA_TS_ID);
                if(_wCurTS_ID == wIDs_1)
                {
                    m_astDTVProgramIndexTable[wOrder].eLCNAssignmentType = DEFAULT_LCN_ASSIGNMENT_TYPE;
                }
                else
                {
                    if( E_LCN_SAME_SERVICE & m_astDTVProgramIndexTable[wOrder].eLCNAssignmentType )
                    {
                       m_astDTVProgramIndexTable[wOrder].eLCNAssignmentType = DEFAULT_LCN_ASSIGNMENT_TYPE;
                       m_astDTVProgramIndexTable[wOrder].eLCNAssignmentType |= E_LCN_SAME_SERVICE;
                    }
                    else
                        m_astDTVProgramIndexTable[wOrder].eLCNAssignmentType = DEFAULT_LCN_ASSIGNMENT_TYPE;
                }
            }
            else
            {
                m_astDTVProgramIndexTable[wOrder].eLCNAssignmentType = DEFAULT_LCN_ASSIGNMENT_TYPE;
            }

            if( stCHAttribute.bServiceType == E_SERVICETYPE_DTV )
            {
                wOrderOfTV++;
            }
            else if( stCHAttribute.bServiceType == E_SERVICETYPE_DATA )
            {
                wOrderOfData--;
            }
            else
            {
                wOrderOfRadio--;
            }
        }
    }

    return TRUE;
}

//****************************************************************************
/// Fill DTV Program ID Table
/// @param bServiceType \b IN: Service type
/// -@see MEMBER_SERVICETYPE
/// @return BOOLEAN: Function execution result
//****************************************************************************
#if 0
static BOOLEAN FillDTVProgramIDTable(MEMBER_SERVICETYPE bServiceType)
{
    WORD wPosition;
    WORD wOrder;
    WORD wProgramCount;
    BYTE cIDIndex,cIDIndex_pre=0xFF;
    BOOLEAN result;

    wProgramCount = GetProgramCount(bServiceType, INCLUDE_ALL);
    result = TRUE;

    for(wPosition=0; wPosition < wProgramCount; wPosition++)
    {
        wOrder = ConvertPositionToOrder(bServiceType, wPosition);

        GetProgramTable(m_astDTVProgramIndexTable[wOrder].wPRIndex, (BYTE *)&cIDIndex, E_DATA_ID_INDEX);
        m_astDTVProgramIndexTable[wOrder].cIDIndex = cIDIndex;

        if(cIDIndex_pre!=cIDIndex)
        {
            GetIDTable(cIDIndex,(BYTE *)&_astDTVProgramIDTable[cIDIndex],E_DATA_ID_TABLE);
            if(FALSE == ActiveIDEntity(cIDIndex,TRUE))
                __ASSERT(0);
            cIDIndex_pre = cIDIndex;
        }

        if( INVALID_IDINDEX == cIDIndex )
        {
            result = FALSE;
            break;
        }
    }

    return result;
}
#endif
//****************************************************************************
/// Add Program ID Table
/// @param pstDtvIDTable \b IN: point of DTVPROGRAMID
/// -@see DTVPROGRAMID
/// @param bSave \b IN: save or not save mux info
/// @return BYTE: MUX Index
//****************************************************************************
BYTE msAPI_CM_AddProgramIDTable(DTVPROGRAMID *pstDtvIDTable,BOOLEAN bSave)
{
    BYTE cIDIndex,cNameLen;
    BYTE cNetworkIndex = INVALID_NETWORKINDEX;
    DTVPROGRAMID_M stDtvIDTable_M;
    DTVPROGRAMID_M *pProgramIDTable=_astDTVProgramIDTable;
#if DVB_T_C_DIFF_DB
    if (IsCATVInUse())
    {
        pProgramIDTable=_astDTVCProgramIDTable;
    }
#endif




    for(cNetworkIndex=0; cNetworkIndex < MAX_NETWOEK_NUMBER; cNetworkIndex++)
    {

        if(pstDtvIDTable->wNetwork_ID == _astDTVNetwork[cNetworkIndex].wNetwork_ID)
        {
            break;
        }
    }

    if(cNetworkIndex>=MAX_NETWOEK_NUMBER)//search free network
    {
        for(cNetworkIndex=0; cNetworkIndex < MAX_NETWOEK_NUMBER; cNetworkIndex++)
        {
            if((_astDTVNetwork[cNetworkIndex].wNetwork_ID == INVALID_NID))
            {
                break;
            }
        }
    }


    if(cNetworkIndex == MAX_NETWOEK_NUMBER)
    {
        MS_DEBUG_MSG(printf("error over max support network (%d)\n", cNetworkIndex));
        //return INVALID_IDINDEX;//over max network, don't save network info
    }

    for(cIDIndex=0; cIDIndex < MAX_MUX_NUMBER; cIDIndex++)
    {
#if (ENABLE_T_C_COMBO)
        if( (!IsCATVInUse()||(pstDtvIDTable->u32Frequency == pProgramIDTable[cIDIndex].u32Frequency||
            IsFreqInsideOffsetRange(pstDtvIDTable->u32Frequency, pProgramIDTable[cIDIndex].u32Frequency))) &&
            //(pstDtvIDTable->wTransportStream_ID == pProgramIDTable[cIDIndex].wTransportStream_ID) &&
            //(pstDtvIDTable->wOriginalNetwork_ID == pProgramIDTable[cIDIndex].wOriginalNetwork_ID) &&
            (IsCATVInUse() ||((pstDtvIDTable->cPLPID == pProgramIDTable[cIDIndex].cPLPID) &&
            (pstDtvIDTable->cHpLp== pProgramIDTable[cIDIndex].cHpLp) &&
            (pstDtvIDTable->cRFChannelNumber == pProgramIDTable[cIDIndex].cRFChannelNumber))))
#elif DVB_C_ENABLE
        if( (pstDtvIDTable->u32Frequency == pProgramIDTable[cIDIndex].u32Frequency ||
            IsFreqInsideOffsetRange(pstDtvIDTable->u32Frequency, pProgramIDTable[cIDIndex].u32Frequency))
            //&& pstDtvIDTable->wTransportStream_ID == pProgramIDTable[cIDIndex].wTransportStream_ID &&
            //pstDtvIDTable->wOriginalNetwork_ID == pProgramIDTable[cIDIndex].wOriginalNetwork_ID
            )
#else
        if( /*pstDtvIDTable->wTransportStream_ID == pProgramIDTable[cIDIndex].wTransportStream_ID &&
            pstDtvIDTable->wOriginalNetwork_ID == pProgramIDTable[cIDIndex].wOriginalNetwork_ID &&*/
            pstDtvIDTable->cRFChannelNumber == pProgramIDTable[cIDIndex].cRFChannelNumber &&
            pstDtvIDTable->cPLPID == pProgramIDTable[cIDIndex].cPLPID &&
            pstDtvIDTable->cHpLp== pProgramIDTable[cIDIndex].cHpLp)
#endif
        {
            if(cNetworkIndex != pProgramIDTable[cIDIndex].cNetWorkIndex)//TS change case
            {

                if((pProgramIDTable[cIDIndex].cNetWorkIndex < MAX_NETWOEK_NUMBER))//&&(FALSE == SetIDTable(cIDIndex,(BYTE *)&cNetworkIndex,E_DATA_NETWORK_INDEX)))
                {
                	cNetworkIndex = pProgramIDTable[cIDIndex].cNetWorkIndex;// = cNetworkIndex;
	                _astDTVNetwork[cNetworkIndex].wNetwork_ID=pstDtvIDTable->wNetwork_ID;
		            if(FALSE == SetIDTable(cNetworkIndex,(BYTE *)&_astDTVNetwork[cNetworkIndex],E_DATA_NETWORK))
		            {
		                __ASSERT(0);
		            }
                }
            }
#if (ENABLE_T_C_COMBO || DVB_C_ENABLE)
            if (pstDtvIDTable->u32Frequency != pProgramIDTable[cIDIndex].u32Frequency
#if (ENABLE_T_C_COMBO)
                && IsCATVInUse()
#endif
                )
            {
                pProgramIDTable[cIDIndex].u32Frequency = pstDtvIDTable->u32Frequency;
                if (FALSE == SetIDTable(cIDIndex, (BYTE *)&pstDtvIDTable->u32Frequency, E_DATA_FREQ))
                {
                    __ASSERT(0);
                }
            }
#endif
            //for manual scan in change TS case
            if(pstDtvIDTable->wTransportStream_ID != pProgramIDTable[cIDIndex].wTransportStream_ID)
            {
                pProgramIDTable[cIDIndex].wTransportStream_ID= pstDtvIDTable->wTransportStream_ID;
                if (FALSE == SetIDTable(cIDIndex, (BYTE *)&pstDtvIDTable->wTransportStream_ID, E_DATA_TS_ID))
                {
                    __ASSERT(0);
                }
            }
            if(pstDtvIDTable->wOriginalNetwork_ID != pProgramIDTable[cIDIndex].wOriginalNetwork_ID)
            {
                pProgramIDTable[cIDIndex].wOriginalNetwork_ID= pstDtvIDTable->wOriginalNetwork_ID;
                if (FALSE == SetIDTable(cIDIndex, (BYTE *)&pstDtvIDTable->wOriginalNetwork_ID, E_DATA_ON_ID))
                {
                    __ASSERT(0);
                }
            }
            break;
        }
    }


    if(cIDIndex>=MAX_MUX_NUMBER)//search free mux
    {
        for(cIDIndex=0; cIDIndex < MAX_MUX_NUMBER; cIDIndex++)
        {
#if (ENABLE_T_C_COMBO)
            if((IsCATVInUse() && (INVALID_FREQUENCY == pProgramIDTable[cIDIndex].u32Frequency)) ||
                (!IsCATVInUse() && (INVALID_PHYSICAL_CHANNEL_NUMBER == pProgramIDTable[cIDIndex].cRFChannelNumber )))
#elif DVB_C_ENABLE
            if(INVALID_FREQUENCY == pProgramIDTable[cIDIndex].u32Frequency)
#else
            if(INVALID_PHYSICAL_CHANNEL_NUMBER == pProgramIDTable[cIDIndex].cRFChannelNumber )
#endif
            {
                stDtvIDTable_M.wTransportStream_ID= pstDtvIDTable->wTransportStream_ID;
                stDtvIDTable_M.wOriginalNetwork_ID = pstDtvIDTable->wOriginalNetwork_ID;
                stDtvIDTable_M.cRFChannelNumber = pstDtvIDTable->cRFChannelNumber;
#if (ENABLE_UPDATE_MULTIPLEX_VIA_NIT)
                stDtvIDTable_M.cOriginal_RF = pstDtvIDTable->cOriginal_RF;
                stDtvIDTable_M.dwAlternativeTime = pstDtvIDTable->dwAlternativeTime;
#endif
                stDtvIDTable_M.wCellID = pstDtvIDTable->wCellID;
                stDtvIDTable_M.cPLPID = pstDtvIDTable->cPLPID;
                stDtvIDTable_M.cHpLp= pstDtvIDTable->cHpLp;
                stDtvIDTable_M.cNetWorkIndex = cNetworkIndex;
#if DVB_C_ENABLE
                stDtvIDTable_M.u32Frequency = pstDtvIDTable->u32Frequency;
                stDtvIDTable_M.u32SymbRate = pstDtvIDTable->u32SymbRate;
                stDtvIDTable_M.QamMode = pstDtvIDTable->QamMode;
#endif
                memcpy(&pProgramIDTable[cIDIndex],&stDtvIDTable_M,sizeof(DTVPROGRAMID_M));

                if(bSave)
                {
/*
printf("add mux freq %d sym %d ONID %x TSID %x\n",
stDtvIDTable_M.u32Frequency,
stDtvIDTable_M.u32SymbRate,
stDtvIDTable_M.QamMode,
stDtvIDTable_M.wOriginalNetwork_ID,
stDtvIDTable_M.wTransportStream_ID
);
*/

                    if(FALSE == IsIDEntityActive(cIDIndex))
                    {
                        SetIDTable(cIDIndex,(BYTE *)&stDtvIDTable_M,E_DATA_ID_TABLE);
                        if(TRUE != ActiveIDEntity(cIDIndex,TRUE))
                        {
                            __ASSERT(0);
                        }
                    }
                }
                break;
            }
        }

    }

    if(cIDIndex < MAX_MUX_NUMBER)
    {
        if(cNetworkIndex < MAX_NETWOEK_NUMBER)
        {
            _astDTVNetwork[cNetworkIndex].wNetwork_ID =  pstDtvIDTable->wNetwork_ID;
            _msAPI_CM_GetCurrentNetworkName(_astDTVNetwork[cNetworkIndex].bNetworkName, &cNameLen);
            if(FALSE == SetIDTable(cNetworkIndex,(BYTE *)&_astDTVNetwork[cNetworkIndex],E_DATA_NETWORK))
            {
                __ASSERT(0);
            }
        }
        return cIDIndex;
    }
    return INVALID_IDINDEX;
}

//****************************************************************************
/// Update Order Of Program Table
/// @param bServiceType \b IN: Service type
/// -@see MEMBER_SERVICETYPE
/// @return BOOLEAN: Function execution result
//****************************************************************************
static BOOLEAN UpdateOrderOfProgramTable(MEMBER_SERVICETYPE bServiceType)
{
    WORD wPosition;
    WORD wOrder;
    WORD wSavedOrder;
    WORD wProgramCount;
    WORD wDeletedOrder;
    WORD i;

    wProgramCount = GetProgramCount(bServiceType, INCLUDE_ALL);
    wPosition = 0;

    for(i=0; i < wProgramCount; i++)
    {
        wOrder = ConvertPositionToOrder(bServiceType, wPosition);

        if( (bServiceType == m_astDTVProgramIndexTable[wOrder].bServiceType) &&
            (TRUE == IsProgramEntityActive(m_astDTVProgramIndexTable[wOrder].wPRIndex)) )
        {
            GetProgramTable(m_astDTVProgramIndexTable[wOrder].wPRIndex, (BYTE *)&wSavedOrder, E_DATA_ORDER);
            if( wOrder != wSavedOrder )
            {
                wSavedOrder = wOrder;
                SetProgramTable(m_astDTVProgramIndexTable[wOrder].wPRIndex, (BYTE *)&wSavedOrder, E_DATA_ORDER);
            }

            wPosition++;
        }
        else
        {
            wDeletedOrder = ConvertPositionToOrder(bServiceType, (wProgramCount-1));
            MoveProgram(wOrder, wDeletedOrder);

            m_astDTVProgramIndexTable[wDeletedOrder].bServiceType = E_SERVICETYPE_INVALID;
            m_astDTVProgramIndexTable[wDeletedOrder].wPRIndex = INVALID_PRINDEX;

            ActiveProgramEntity(m_astDTVProgramIndexTable[wDeletedOrder].wPRIndex, FALSE);

            UpdateProgramCount(bServiceType);
            wProgramCount = GetProgramCount(bServiceType, INCLUDE_ALL);
        }
    }

    return TRUE;
}

#if ENABLE_SBTVD_BRAZIL_CM_APP
static BOOLEAN SortProgram_Brazil(MEMBER_SERVICETYPE bServiceType)
{
    WORD wOrder1,wOrder2;
    WORD wMinLCN, wCurrentLCN;
    WORD wMinOrder;
    WORD wProgramCount;
    WORD wPosition1, wPosition2;
    WORD i;
	DTVPROGRAMID_M *pMuxTable=_astDTVProgramIDTable;
#if DVB_T_C_DIFF_DB
	if (IsCATVInUse())pMuxTable=_astDTVCProgramIDTable;
#endif


    wProgramCount = GetProgramCount(bServiceType, INCLUDE_ALL);

    // sort LCN from Min to Max
    for(wPosition1=0; wPosition1 < wProgramCount; wPosition1++)
    {
        wOrder1 = ConvertPositionToOrder(bServiceType, wPosition1);

        if( TRUE == m_astDTVProgramIndexTable[wOrder1].bIsMove )
        {
            continue;
        }

        wMinOrder = wOrder1;
        //bMinRF = _astDTVProgramIDTable[m_astDTVProgramIndexTable[wOrder1].cIDIndex].cRFChannelNumber;
        wMinLCN = ((m_astDTVProgramIndexTable[wOrder1].stLCN.bPhysicalChannel << 8) | m_astDTVProgramIndexTable[wOrder1].stLCN.bVirtualChannel);

        for(wPosition2=wPosition1+1; wPosition2 < wProgramCount; wPosition2++)
        {
            wOrder2 = ConvertPositionToOrder(bServiceType, wPosition2);
            //bCurrentRF = _astDTVProgramIDTable[m_astDTVProgramIndexTable[wOrder2].cIDIndex].cRFChannelNumber;
            wCurrentLCN = ((m_astDTVProgramIndexTable[wOrder2].stLCN.bPhysicalChannel << 8) | m_astDTVProgramIndexTable[wOrder2].stLCN.bVirtualChannel);

            if( (INVALID_LOGICAL_CHANNEL_NUMBER == wCurrentLCN) ||
                (TRUE == m_astDTVProgramIndexTable[wOrder2].bIsMove)||
                (FALSE == m_astDTVProgramIndexTable[wOrder2].bVisibleServiceFlag)||
                (TRUE == m_astDTVProgramIndexTable[wOrder2].bIsDelete))
            {
                continue;
            }

            if(wMinLCN > wCurrentLCN)
            {
                wMinLCN =  wCurrentLCN;
                wMinOrder =  wOrder2;
            }
        }

        if( wMinOrder != wOrder1 )
        {
            #if ( WATCH_DOG == ENABLE )
            msAPI_Timer_ResetWDT();
            #endif

            SwapProgram(wMinOrder, wOrder1);
        }
    }

    // Move Invisible to last
    wPosition1 = 0;
    for(i=0; i < wProgramCount; i++)
    {
        wOrder1 = ConvertPositionToOrder(bServiceType, wPosition1);
        if( FALSE == m_astDTVProgramIndexTable[wOrder1].bVisibleServiceFlag )
        {
            #if ( WATCH_DOG == ENABLE )
            msAPI_Timer_ResetWDT();
            #endif

            wOrder2 = ConvertPositionToOrder(bServiceType, (wProgramCount-1));
            MoveProgram(wOrder1, wOrder2);
        }
        else
        {
            wPosition1++;
        }
    }

    // Move Deleted to last
    wPosition1 = 0;
    for(i=0; i < wProgramCount; i++)
    {
        wOrder1 = ConvertPositionToOrder(bServiceType, wPosition1);
        if( TRUE == m_astDTVProgramIndexTable[wOrder1].bIsDelete )
        {
            #if ( WATCH_DOG == ENABLE )
            msAPI_Timer_ResetWDT();
            #endif

            wOrder2 = ConvertPositionToOrder(bServiceType, (wProgramCount-1));
            MoveProgram(wOrder1, wOrder2);
        }
        else
        {
            wPosition1++;
        }
    }

    wProgramCount = GetProgramCount(bServiceType, INCLUDE_NOT_VISIBLE_EXCLUDE_DELETED);
    for(wPosition1=0; wPosition1 < wProgramCount; wPosition1++)
    {
        wOrder1 = ConvertPositionToOrder(bServiceType, wPosition1);

        if( INVALID_LOGICAL_CHANNEL_NUMBER != m_astDTVProgramIndexTable[wOrder1].wLCN )
        {
            continue;
        }

        if( TRUE == m_astDTVProgramIndexTable[wOrder1].bIsMove )
        {
            continue;
        }

        wMinOrder = wOrder1;

        for(wPosition2=wPosition1+1; wPosition2 < wProgramCount; wPosition2++)
        {
            wOrder2 = ConvertPositionToOrder(bServiceType, wPosition2);

            if( TRUE == m_astDTVProgramIndexTable[wOrder2].bIsMove )
                continue;

            if( m_astDTVProgramIndexTable[wOrder1].cIDIndex != m_astDTVProgramIndexTable[wOrder2].cIDIndex )
            {
                if( pMuxTable[m_astDTVProgramIndexTable[wOrder2].cIDIndex].cRFChannelNumber <
                    pMuxTable[m_astDTVProgramIndexTable[wOrder1].cIDIndex].cRFChannelNumber )
                {
                    wMinOrder = wOrder2;
                }
            }
        }

        if( wMinOrder != wOrder1 )
        {
            #if ( WATCH_DOG == ENABLE )
            msAPI_Timer_ResetWDT();
            #endif

            SwapProgram(wMinOrder, wOrder1);
        }
    }

    return TRUE;
}
#endif
#if ENABLE_DTV_STORE_TTX_PAGE_INFO
//------------------------------------------------------------------------------
/// -This function will Get List Page Number
/// @param pu8Buffer \b IN: pointer to Buffer
/// @param u8ListIndex \b IN: List Index
/// @return WORD: List page number
//------------------------------------------------------------------------------
static WORD GetListPageNumber(BYTE *pu8Buffer, BYTE u8ListIndex)
{
    WORD u16ListPageNumber;
    WORD u16Temp;

    switch ( u8ListIndex )
    {
    case 0:
        u16Temp = (WORD)pu8Buffer[0];
        u16Temp = u16Temp & 0x00FF;
        u16ListPageNumber = u16Temp;

        u16Temp = (WORD)pu8Buffer[1];
        u16Temp = u16Temp & 0x0003;
        u16ListPageNumber |= (u16Temp << 8);
        break;

    case 1:
        u16Temp = (WORD)pu8Buffer[1];
        u16Temp = u16Temp & 0x00FC;
        u16ListPageNumber = u16Temp >> 2;

        u16Temp = (WORD)pu8Buffer[2];
        u16Temp = u16Temp & 0x000F;
        u16ListPageNumber |= (u16Temp << 6);
        break;

    case 2:
        u16Temp = (WORD)pu8Buffer[2];
        u16Temp = u16Temp & 0x00F0;
        u16ListPageNumber = u16Temp >> 4;

        u16Temp = (WORD)pu8Buffer[3];
        u16Temp = u16Temp & 0x003F;
        u16ListPageNumber |= (u16Temp << 4);
        break;

    case 3:
        u16Temp = (WORD)pu8Buffer[3];
        u16Temp = u16Temp & 0x00C0;
        u16ListPageNumber = u16Temp >> 6;

        u16Temp = (WORD)pu8Buffer[4];
        u16Temp = u16Temp & 0x00FF;
        u16ListPageNumber |= (u16Temp << 2);
        break;

    default:
        u16ListPageNumber = DEFAULT_LISTPAGE[0];
        break;
    }

    u16ListPageNumber &= 0x03FF;

    return u16ListPageNumber;
}

//------------------------------------------------------------------------------
/// -This function will Set List Page Number
/// @param pu8Buffer \b IN: pointer to Buffer
/// @param u8ListIndex \b IN: List Index
/// @param u16ListPageNumber \b IN: List Page Number
//------------------------------------------------------------------------------
static void SetListPageNumber(BYTE *pu8Buffer, BYTE u8ListIndex, WORD u16ListPageNumber)
{
    u16ListPageNumber &= 0x03FF;

    switch ( u8ListIndex )
    {
    case 0:
        pu8Buffer[0] &= 0x0000;
        pu8Buffer[0] |= (u16ListPageNumber & 0x00FF);

        pu8Buffer[1] &= 0x00FC;
        pu8Buffer[1] |= ((u16ListPageNumber & 0x0300) >> 8);
        break;

    case 1:
        pu8Buffer[1] &= 0x0003;
        pu8Buffer[1] |= ((u16ListPageNumber & 0x003F) << 2);

        pu8Buffer[2] &= 0x00F0;
        pu8Buffer[2] |= ((u16ListPageNumber & 0x03C0) >> 6);
        break;

    case 2:
        pu8Buffer[2] &= 0x000F;
        pu8Buffer[2] |= ((u16ListPageNumber & 0x000F) << 4);

        pu8Buffer[3] &= 0x00C0;
        pu8Buffer[3] |= ((u16ListPageNumber & 0x03F0) >> 4);
        break;

    case 3:
        pu8Buffer[3] &= 0x003F;
        pu8Buffer[3] |= ((u16ListPageNumber & 0x0003) << 6);

        pu8Buffer[4] &= 0x0000;
        pu8Buffer[4] |= ((u16ListPageNumber & 0x03FC) >> 2);
        break;
    }
}
#endif

#if (PRG_EDIT_INPUT_LCN_MOVE == 1)
#if 0
static FUNCTION_RESULT ChangeLCN(MEMBER_SERVICETYPE bServiceType, WORD wPosition, WORD wLCN)
{
    WORD wProgramCount;
    WORD wPosition1, wPosition2;
    WORD wOrder, wOrder1, wOrder2;
    WORD wTempLCN;

    wProgramCount = GetProgramCount(bServiceType, INCLUDE_ALL);
    wOrder = ConvertPositionToOrder(bServiceType, wPosition);

    for(wPosition1=0; wPosition1 < wProgramCount; wPosition1++)
    {
        wOrder1 = ConvertPositionToOrder(bServiceType, wPosition1);

        if( wLCN == m_astDTVProgramIndexTable[wOrder1].wLCN )
        {
            wTempLCN = wLCN;

            if (wPosition > wPosition1)
            {
                for (wPosition2=wPosition1; wPosition2 < wPosition; wPosition2++)
                {
                    wOrder2 = ConvertPositionToOrder(bServiceType, wPosition2);

                    if ( wTempLCN == m_astDTVProgramIndexTable[wOrder2].wLCN )
                    {
                        m_astDTVProgramIndexTable[wOrder2].wLCN = (++wTempLCN);
                        SetProgramTable(m_astDTVProgramIndexTable[wOrder2].wPRIndex, (BYTE *)&(wTempLCN), E_DATA_LCN);
                    }
                    else
                    {
                        break;
                    }
                }

            }
            else
            {
                for (wPosition2=wPosition1; wPosition2 < wProgramCount ; wPosition2++)
                {
                    wOrder2 = ConvertPositionToOrder(bServiceType, wPosition2);

                    if ( wTempLCN == m_astDTVProgramIndexTable[wOrder2].wLCN )
                    {
                        if (wTempLCN < 999)
                        {
                            m_astDTVProgramIndexTable[wOrder2].wLCN = (++wTempLCN);
                            SetProgramTable(m_astDTVProgramIndexTable[wOrder2].wPRIndex, (BYTE *)&(wTempLCN), E_DATA_LCN);
                        }
                        else
                        {
                            wTempLCN = 1;

                            if (999 == m_astDTVProgramIndexTable[wOrder2].wLCN )
                            {
                                m_astDTVProgramIndexTable[wOrder2].wLCN = wTempLCN;
                                SetProgramTable(m_astDTVProgramIndexTable[wOrder2].wPRIndex, (BYTE *)&(wTempLCN), E_DATA_LCN);
                            }

                            for (wPosition2=0; wPosition2 < wPosition ; wPosition2++)
                            {
                                wOrder2 = ConvertPositionToOrder(bServiceType, wPosition2);
                                if ( wTempLCN == m_astDTVProgramIndexTable[wOrder2].wLCN )
                                {
                                    m_astDTVProgramIndexTable[wOrder2].wLCN = (++wTempLCN) ;
                                    SetProgramTable(m_astDTVProgramIndexTable[wOrder2].wPRIndex, (BYTE *)&(wTempLCN), E_DATA_LCN);
                                }
                                else
                                {
                                    break;
                                }
                            }

                            break;
                        }
                    }
                    else
                    {
                        break;
                    }
                }

            }
            break;
        }
    }

    m_astDTVProgramIndexTable[wOrder].wLCN = wLCN;
    m_astDTVProgramIndexTable[wOrder].eLCNAssignmentType = E_LCN_PRESENT;
    SetProgramTable(m_astDTVProgramIndexTable[wOrder].wPRIndex, (BYTE *)&(wLCN), E_DATA_LCN);

    return E_RESULT_SUCCESS;
}

#else
static FUNCTION_RESULT SwapLCN(MEMBER_SERVICETYPE bServiceType, WORD wPosition, WORD wLCN)
{
    WORD wProgramCount;
    WORD wPosition1;
    WORD wOrder, wOrder1;
    WORD wTempLCN;

    wProgramCount = GetProgramCount(bServiceType, INCLUDE_ALL);
    wOrder = ConvertPositionToOrder(bServiceType, wPosition);

    for(wPosition1=0; wPosition1 < wProgramCount; wPosition1++)
    {
        wOrder1 = ConvertPositionToOrder(bServiceType, wPosition1);

        if( wLCN == m_astDTVProgramIndexTable[wOrder1].wLCN )
        {
            wTempLCN = m_astDTVProgramIndexTable[wOrder].wLCN;
            m_astDTVProgramIndexTable[wOrder1].wLCN = wTempLCN;
            SetProgramTable(m_astDTVProgramIndexTable[wOrder1].wPRIndex, (BYTE *)&(wTempLCN), E_DATA_LCN);
            break;
        }
    }

    m_astDTVProgramIndexTable[wOrder].wLCN = wLCN;
    m_astDTVProgramIndexTable[wOrder].eLCNAssignmentType = E_LCN_PRESENT;
    SetProgramTable(m_astDTVProgramIndexTable[wOrder].wPRIndex, (BYTE *)&(wLCN), E_DATA_LCN);

    return E_RESULT_SUCCESS;
}
#endif
#endif

#if (NTV_FUNCTION_ENABLE)
static BOOLEAN SortProgramByRegionPriority(MEMBER_SERVICETYPE bServiceType)
{
    WORD wOrder1,wOrder2;
    WORD wProgramCount;
    WORD wPosition1,wPositionEnd;
    WORD i;
	DTVPROGRAMID_M *pMuxTable=_astDTVProgramIDTable;
#if DVB_T_C_DIFF_DB
	if (IsCATVInUse())pMuxTable=_astDTVCProgramIDTable;
#endif

    wProgramCount = GetProgramCount(bServiceType, INCLUDE_ALL);
#if 0
    printf("###########################################\n");
    for(wPosition1=0; wPosition1 < wProgramCount; wPosition1++)
    {
        wOrder1 = ConvertPositionToOrder(bServiceType, wPosition1);
        printf("SID %u, LCN %u, Special %bu, cNetWorkIndex %bu\n",m_astDTVProgramIndexTable[wOrder1].wService_ID, m_astDTVProgramIndexTable[wOrder1].wLCN,
            m_astDTVProgramIndexTable[wOrder1].bIsSpecialService,_astDTVProgramIDTable[m_astDTVProgramIndexTable[wOrder1].cIDIndex].cNetWorkIndex);
    }
    printf("\n\n\n");
#endif
    //[3]Sort Service LCN 900-999 with ONID_NORWAY Order placed at the end of list
    wPositionEnd = wProgramCount;
    wOrder2 = ConvertPositionToOrder(bServiceType, (wProgramCount-1));

    for(wPosition1 = 0; wPosition1 < wPositionEnd; )
    {
        wOrder1 = ConvertPositionToOrder(bServiceType, wPosition1);
        if(pMuxTable[m_astDTVProgramIndexTable[wOrder1].cIDIndex].wOriginalNetwork_ID != SI_ONID_NORWAY)
        {
            break;
        }
        if(m_astDTVProgramIndexTable[wOrder1].bIsSpecialService == FALSE)
        {
            wPosition1++;
            continue;
        }
        if( TRUE == m_astDTVProgramIndexTable[wOrder1].bIsMove )
        {
            wPosition1++;
            continue;
        }
        MoveProgram(wOrder1, wOrder2);
        wPositionEnd--;

    }
#if 0
    printf("###########################################\n");
    for(wPosition1=0; wPosition1 < wProgramCount; wPosition1++)
    {
        wOrder1 = ConvertPositionToOrder(bServiceType, wPosition1);
        printf("SID %u, LCN %u, Special %bu, cNetWorkIndex %bu\n",m_astDTVProgramIndexTable[wOrder1].wService_ID, m_astDTVProgramIndexTable[wOrder1].wLCN,
            m_astDTVProgramIndexTable[wOrder1].bIsSpecialService,_astDTVProgramIDTable[m_astDTVProgramIndexTable[wOrder1].cIDIndex].cNetWorkIndex);
    }
    printf("\n\n\n");
#endif
    wPosition1 = 0;
    for(i=0; i < wProgramCount; i++)
    {
        wOrder1 = ConvertPositionToOrder(bServiceType, wPosition1);
        if( FALSE == m_astDTVProgramIndexTable[wOrder1].bVisibleServiceFlag )
        {
            #if ( WATCH_DOG == ENABLE )
            msAPI_Timer_ResetWDT();
            #endif

            wOrder2 = ConvertPositionToOrder(bServiceType, (wProgramCount-1));
            MoveProgram(wOrder1, wOrder2);
        }
        else
        {
            wPosition1++;
        }
    }

    wPosition1 = 0;
    for(i=0; i < wProgramCount; i++)
    {
        wOrder1 = ConvertPositionToOrder(bServiceType, wPosition1);
        if( TRUE == m_astDTVProgramIndexTable[wOrder1].bIsDelete )
        {
            #if ( WATCH_DOG == ENABLE )
            msAPI_Timer_ResetWDT();
            #endif

            wOrder2 = ConvertPositionToOrder(bServiceType, (wProgramCount-1));
            MoveProgram(wOrder1, wOrder2);
        }
        else
        {
            wPosition1++;
        }
    }
    UpdateOrderOfProgramTable(bServiceType);
    return TRUE;
}
#endif

static BOOLEAN SortProgram(MEMBER_SERVICETYPE bServiceType)
{
    WORD wOrder1,wOrder2;
    WORD wMinLCN, wCurrentLCN;
    WORD wMinOrder;
    WORD wProgramCount;
    WORD wPosition1, wPosition2;
    WORD i;
	DTVPROGRAMID_M *pMuxTable=_astDTVProgramIDTable;
#if DVB_T_C_DIFF_DB
	if (IsCATVInUse())pMuxTable=_astDTVCProgramIDTable;
#endif

    wProgramCount = GetProgramCount(bServiceType, INCLUDE_ALL);
    for(wPosition1=0; wPosition1 < wProgramCount; wPosition1++)
    {
        wOrder1 = ConvertPositionToOrder(bServiceType, wPosition1);

#if (PRG_EDIT_INPUT_LCN_MOVE == 0)
        if( TRUE == m_astDTVProgramIndexTable[wOrder1].bIsMove )
        {
            continue;
        }
#endif

        wMinOrder = wOrder1;
        wMinLCN = m_astDTVProgramIndexTable[wOrder1].wLCN;

        for(wPosition2=wPosition1+1; wPosition2 < wProgramCount; wPosition2++)
        {
            wOrder2 = ConvertPositionToOrder(bServiceType, wPosition2);
            wCurrentLCN = m_astDTVProgramIndexTable[wOrder2].wLCN;

            if( INVALID_LOGICAL_CHANNEL_NUMBER == m_astDTVProgramIndexTable[wOrder2].wLCN )
            {
                continue;
            }

#if (PRG_EDIT_INPUT_LCN_MOVE == 0)
            if( TRUE == m_astDTVProgramIndexTable[wOrder2].bIsMove )
            {
                continue;
            }
#endif

            if( FALSE == m_astDTVProgramIndexTable[wOrder2].bVisibleServiceFlag )
            {
                continue;
            }

            if( TRUE == m_astDTVProgramIndexTable[wOrder2].bIsDelete )
            {
                continue;
            }

            if( wMinLCN > wCurrentLCN )
            {
                wMinLCN = wCurrentLCN;
                wMinOrder = wOrder2;
            }
        }

        if( wMinOrder != wOrder1 )
        {
            #if ( WATCH_DOG == ENABLE )
            msAPI_Timer_ResetWDT();
            #endif

            SwapProgram(wMinOrder, wOrder1);
        }
    }

    wPosition1 = 0;
    for(i=0; i < wProgramCount; i++)
    {
        wOrder1 = ConvertPositionToOrder(bServiceType, wPosition1);
        if( FALSE == m_astDTVProgramIndexTable[wOrder1].bVisibleServiceFlag )
        {
            #if ( WATCH_DOG == ENABLE )
            msAPI_Timer_ResetWDT();
            #endif

            wOrder2 = ConvertPositionToOrder(bServiceType, (wProgramCount-1));
            MoveProgram(wOrder1, wOrder2);
        }
        else
        {
            wPosition1++;
        }
    }

    wPosition1 = 0;
    for(i=0; i < wProgramCount; i++)
    {
        wOrder1 = ConvertPositionToOrder(bServiceType, wPosition1);
        if( TRUE == m_astDTVProgramIndexTable[wOrder1].bIsDelete )
        {
            #if ( WATCH_DOG == ENABLE )
            msAPI_Timer_ResetWDT();
            #endif

            wOrder2 = ConvertPositionToOrder(bServiceType, (wProgramCount-1));
            MoveProgram(wOrder1, wOrder2);
        }
        else
        {
            wPosition1++;
        }
    }

    wProgramCount = GetProgramCount(bServiceType, INCLUDE_NOT_VISIBLE_EXCLUDE_DELETED);
    for(wPosition1=0; wPosition1 < wProgramCount; wPosition1++)
    {
        wOrder1 = ConvertPositionToOrder(bServiceType, wPosition1);

        if( INVALID_LOGICAL_CHANNEL_NUMBER != m_astDTVProgramIndexTable[wOrder1].wLCN )
        {
            continue;
        }

#if (PRG_EDIT_INPUT_LCN_MOVE == 0)
        if( TRUE == m_astDTVProgramIndexTable[wOrder1].bIsMove )
        {
            continue;
        }
#endif

        wMinOrder = wOrder1;

        for(wPosition2=wPosition1+1; wPosition2 < wProgramCount; wPosition2++)
        {
            wOrder2 = ConvertPositionToOrder(bServiceType, wPosition2);

#if (PRG_EDIT_INPUT_LCN_MOVE == 0)
            if( TRUE == m_astDTVProgramIndexTable[wOrder2].bIsMove )
                continue;
#endif

            if( m_astDTVProgramIndexTable[wOrder1].cIDIndex != m_astDTVProgramIndexTable[wOrder2].cIDIndex )
            {
#if (ENABLE_T_C_COMBO)
                if((IsCATVInUse() && ( pMuxTable[m_astDTVProgramIndexTable[wOrder2].cIDIndex].u32Frequency<
                    pMuxTable[m_astDTVProgramIndexTable[wOrder1].cIDIndex].u32Frequency)) ||
                    (!IsCATVInUse()&&( pMuxTable[m_astDTVProgramIndexTable[wOrder2].cIDIndex].cRFChannelNumber <
                    pMuxTable[m_astDTVProgramIndexTable[wOrder1].cIDIndex].cRFChannelNumber )))
#elif DVB_C_ENABLE
                if( pMuxTable[m_astDTVProgramIndexTable[wOrder2].cIDIndex].u32Frequency<
                    pMuxTable[m_astDTVProgramIndexTable[wOrder1].cIDIndex].u32Frequency)
#else
                if( pMuxTable[m_astDTVProgramIndexTable[wOrder2].cIDIndex].cRFChannelNumber <
                    pMuxTable[m_astDTVProgramIndexTable[wOrder1].cIDIndex].cRFChannelNumber )
#endif
                {
                    wMinOrder = wOrder2;
                }
            }
        }

        if( wMinOrder != wOrder1 )
        {
            #if ( WATCH_DOG == ENABLE )
            msAPI_Timer_ResetWDT();
            #endif

            SwapProgram(wMinOrder, wOrder1);
        }
    }
    UpdateOrderOfProgramTable(bServiceType);
    return TRUE;
}

//****************************************************************************
/// Move Program
/// @param wFromOrder \b IN: From Order
/// @param wToOrder \b IN: To Order
/// @return BOOLEAN: Function execution result
//****************************************************************************
static BOOLEAN MoveProgram(WORD wFromOrder, WORD wToOrder)
{
    DTVPROGRAMINDEX stDTVProgramIndex;
    WORD wOrder;

    if(wFromOrder == wToOrder)
    {
        return TRUE;
    }

    if(wFromOrder > wToOrder)
    {
        stDTVProgramIndex = m_astDTVProgramIndexTable[wFromOrder];
        for(wOrder=wFromOrder; wOrder > wToOrder; wOrder--)
        {
            m_astDTVProgramIndexTable[wOrder] = m_astDTVProgramIndexTable[wOrder-1];
        }
        m_astDTVProgramIndexTable[wToOrder] = stDTVProgramIndex;
    }
    else
    {
        stDTVProgramIndex = m_astDTVProgramIndexTable[wFromOrder];

        for(wOrder=wFromOrder; wOrder < wToOrder; wOrder++)
        {
            m_astDTVProgramIndexTable[wOrder] = m_astDTVProgramIndexTable[wOrder+1];
        }
        m_astDTVProgramIndexTable[wToOrder] = stDTVProgramIndex;
    }
#if (ENABLE_DTV_EPG)
    if(_pfNotify_CM_MoveProgram)
    {
        _pfNotify_CM_MoveProgram(wFromOrder, wToOrder);
    }
#endif  //#if (ENABLE_EPG)
    return TRUE;
}

//****************************************************************************
/// Swap Program
/// @param wFromOrder \b IN: From Order
/// @param wToOrder \b IN: To Order
/// @return BOOLEAN: Function execution result
//****************************************************************************
static BOOLEAN SwapProgram(WORD wFromOrder, WORD wToOrder)
{
    DTVPROGRAMINDEX stDTVProgramIndex;

    if(wFromOrder == wToOrder)
    {
        return TRUE;
    }

    stDTVProgramIndex = m_astDTVProgramIndexTable[wFromOrder];
    m_astDTVProgramIndexTable[wFromOrder] = m_astDTVProgramIndexTable[wToOrder];
    m_astDTVProgramIndexTable[wToOrder] = stDTVProgramIndex;
#if (ENABLE_DTV_EPG)
    if(_pfNotify_CM_SwapProgram)
    {
        _pfNotify_CM_SwapProgram(wFromOrder, wToOrder);
    }
#endif
    return TRUE;
}

//****************************************************************************
/// Get Program Table
/// @param wPRIndex \b IN: Program Index
/// @param pcBuffer \b IN: pointer To Buffer
/// @param eMember \b IN: program data Member
/// -@see PROGRAMDATA_MEMBER
/// @return BOOLEAN: Function execution result
//****************************************************************************

static BOOLEAN GetProgramTable(DWORD wPRIndex, BYTE * pcBuffer, PROGRAMDATA_MEMBER eMember)
{
	DWORD StartAddress=BASEADDRESS_PR_DTVPRTABLE;
    if( MAX_DTVPROGRAM <= wPRIndex )
    {
        return FALSE;
    }

    if(IsProgramEntityActive(wPRIndex) == FALSE)
    {
        FillProgramDataWithDefault(pcBuffer, eMember);
        return FALSE;
    }
#if DVB_T_C_DIFF_DB
	if (IsCATVInUse())
	{
		StartAddress=BASEADDRESS_PR_DTV_C_PRTABLE;
	}
#endif
    //printf("Get eMember: %bu ", eMember);

    switch(eMember)
    {
    case E_DATA_ALL:
        return GetNVRAM(StartAddress+
                        (wPRIndex*sizeof(DTV_CHANNEL_INFO)),
                        pcBuffer, sizeof(DTV_CHANNEL_INFO));

    case E_DATA_ORDER:
        return GetNVRAM(StartAddress+
                        (wPRIndex*sizeof(DTV_CHANNEL_INFO)+offsetof(DTV_CHANNEL_INFO, wOrder)),
                        pcBuffer, sizeof(WORD));

    case E_DATA_LCN:
        return GetNVRAM(StartAddress+
                        (wPRIndex*sizeof(DTV_CHANNEL_INFO)+offsetof(DTV_CHANNEL_INFO, wLCN)),
                        pcBuffer, sizeof(WORD));
#if 1//NTV_FUNCTION_ENABLE
    case E_DATA_TS_LCN:
        return GetNVRAM(StartAddress+
                        (wPRIndex*sizeof(DTV_CHANNEL_INFO)+offsetof(DTV_CHANNEL_INFO, wTS_LCN)),
                        pcBuffer, sizeof(WORD));
#endif
    case E_DATA_SIMU_LCN:
        return GetNVRAM(StartAddress+
                        (wPRIndex*sizeof(DTV_CHANNEL_INFO)+offsetof(DTV_CHANNEL_INFO, wSimu_LCN)),
                        pcBuffer, sizeof(WORD));

    case E_DATA_ID_INDEX:
        return GetNVRAM(StartAddress+
                        (wPRIndex*sizeof(DTV_CHANNEL_INFO)+offsetof(DTV_CHANNEL_INFO, bIDIdex)),
                        pcBuffer, sizeof(BYTE));

    case E_DATA_VERSION_PAT:
        return GetNVRAM(StartAddress+
                        (wPRIndex*sizeof(DTV_CHANNEL_INFO)+offsetof(DTV_CHANNEL_INFO, stPSI_SI_Version)+offsetof(DVB_TABLE_VERSION, bPATVer)),
                        pcBuffer, sizeof(BYTE));

    case E_DATA_VERSION_PMT:
        return GetNVRAM(StartAddress+
                        (wPRIndex*sizeof(DTV_CHANNEL_INFO)+offsetof(DTV_CHANNEL_INFO, stPSI_SI_Version)+offsetof(DVB_TABLE_VERSION, bPMTVer)),
                        pcBuffer, sizeof(BYTE));

    case E_DATA_VERSION_NIT:
        return GetNVRAM(StartAddress+
                        (wPRIndex*sizeof(DTV_CHANNEL_INFO)+offsetof(DTV_CHANNEL_INFO, stPSI_SI_Version)+offsetof(DVB_TABLE_VERSION, bNITVer)),
                        pcBuffer, sizeof(BYTE));

    case E_DATA_VERSION_SDT:
        return GetNVRAM(StartAddress+
                        (wPRIndex*sizeof(DTV_CHANNEL_INFO)+offsetof(DTV_CHANNEL_INFO, stPSI_SI_Version)+offsetof(DVB_TABLE_VERSION, bSDTVer)),
                        pcBuffer, sizeof(BYTE));

    case E_DATA_MISC:
        return GetNVRAM(StartAddress+
                        (wPRIndex*sizeof(DTV_CHANNEL_INFO)+offsetof(DTV_CHANNEL_INFO, stCHAttribute)),
                        pcBuffer, sizeof(CHANNEL_ATTRIBUTE));

    case E_DATA_SERVICE_ID:
        return GetNVRAM(StartAddress+
                        (wPRIndex*sizeof(DTV_CHANNEL_INFO)+offsetof(DTV_CHANNEL_INFO, wService_ID)),
                        pcBuffer, sizeof(WORD));
    case E_DATA_PMT_PID:
        return GetNVRAM(StartAddress+
                        (wPRIndex*sizeof(DTV_CHANNEL_INFO)+offsetof(DTV_CHANNEL_INFO, wPmt_PID)),
                        pcBuffer, sizeof(WORD));
    case E_DATA_PCR_PID:
        return GetNVRAM(StartAddress+
                        (wPRIndex*sizeof(DTV_CHANNEL_INFO)+offsetof(DTV_CHANNEL_INFO, wPCR_PID)),
                        pcBuffer, sizeof(WORD));

    case E_DATA_VIDEO_PID:
        return GetNVRAM(StartAddress+
                        (wPRIndex*sizeof(DTV_CHANNEL_INFO)+offsetof(DTV_CHANNEL_INFO, wVideo_PID)),
                        pcBuffer, sizeof(WORD));

    case E_DATA_AUDIO_STREAM_INFO:
        return GetNVRAM(StartAddress+
                        (wPRIndex*sizeof(DTV_CHANNEL_INFO)+offsetof(DTV_CHANNEL_INFO, stAudInfo)),
                        pcBuffer, sizeof(AUD_INFO)*MAX_AUD_LANG_NUM);
#if ENABLE_SAVE_MULTILINGUAL_SERVICE_NAME
	case E_DATA_NAME_MULTILINGUAL_LANGUAGE:
		return GetNVRAM(StartAddress+
						(wPRIndex*sizeof(DTV_CHANNEL_INFO)+offsetof(DTV_CHANNEL_INFO, bMultiLanguage)),
						pcBuffer, sizeof(BYTE)*MAX_MULTI_LINGUAL_SERVICE_NAME);
	case E_DATA_SERVICE_MULTILINGUAL_NAME:
		return GetNVRAM(StartAddress+
						(wPRIndex*sizeof(DTV_CHANNEL_INFO)+offsetof(DTV_CHANNEL_INFO, bMultiChannelName)),
						pcBuffer, sizeof(BYTE)*MAX_MULTI_LINGUAL_SERVICE_NAME*MAX_SERVICE_NAME);
#endif

    case E_DATA_SERVICE_NAME:
        return GetNVRAM(StartAddress+
                        (wPRIndex*sizeof(DTV_CHANNEL_INFO)+offsetof(DTV_CHANNEL_INFO, bChannelName)),
                        pcBuffer, sizeof(BYTE)*MAX_SERVICE_NAME);

    #if ENABLE_DTV_STORE_TTX_PAGE_INFO
    case E_DATA_TTX_LIST:
         return GetNVRAM(StartAddress+
                    (wPRIndex*sizeof(DTV_CHANNEL_INFO)+offsetof(DTV_CHANNEL_INFO, u8ListPage)),
                    pcBuffer, sizeof(BYTE)*MAX_LISTPAGE_SIZE);
    #endif

    default:
        break;
    }

    return FALSE;
}

//****************************************************************************
/// Set Program Table
/// @param wPRIndex \b IN: Program Index
/// @param pcBuffer \b IN: pointer To Buffer
/// @param eMember \b IN: program data Member
/// -@see PROGRAMDATA_MEMBER
/// @return BOOLEAN: Function execution result
//****************************************************************************
static BOOLEAN SetProgramTable(DWORD wPRIndex, BYTE * pcBuffer, PROGRAMDATA_MEMBER eMember)
{
	DWORD StartAddress=BASEADDRESS_PR_DTVPRTABLE;

    if( MAX_DTVPROGRAM <= wPRIndex )
    {
        return FALSE;
    }

    if( eMember != E_DATA_ALL && FALSE == IsProgramEntityActive(wPRIndex) )
    {
        return FALSE;
    }

    //printf("Set eMember: %bu ", eMember);
#if DVB_T_C_DIFF_DB
	if (IsCATVInUse())
	{
		StartAddress=BASEADDRESS_PR_DTV_C_PRTABLE;
	}
#endif


    switch(eMember)
    {
    case E_DATA_ALL:
        return SetNVRAM(StartAddress+
                        (wPRIndex*sizeof(DTV_CHANNEL_INFO)),
                        pcBuffer, sizeof(DTV_CHANNEL_INFO));

    case E_DATA_ORDER:
        return SetNVRAM(StartAddress+
                        (wPRIndex*sizeof(DTV_CHANNEL_INFO)+offsetof(DTV_CHANNEL_INFO, wOrder)),
                        pcBuffer, sizeof(WORD));

    case E_DATA_LCN:
        return SetNVRAM(StartAddress+
                        (wPRIndex*sizeof(DTV_CHANNEL_INFO)+offsetof(DTV_CHANNEL_INFO, wLCN)),
                        pcBuffer, sizeof(WORD));
#if 1//NTV_FUNCTION_ENABLE
    case E_DATA_TS_LCN:
        return SetNVRAM(StartAddress+
                        (wPRIndex*sizeof(DTV_CHANNEL_INFO)+offsetof(DTV_CHANNEL_INFO, wTS_LCN)),
                        pcBuffer, sizeof(WORD));
#endif
    case E_DATA_SIMU_LCN:
        return SetNVRAM(StartAddress+
                        (wPRIndex*sizeof(DTV_CHANNEL_INFO)+offsetof(DTV_CHANNEL_INFO, wSimu_LCN)),
                        pcBuffer, sizeof(WORD));

    case E_DATA_ID_INDEX:
        return SetNVRAM(StartAddress+
                        (wPRIndex*sizeof(DTV_CHANNEL_INFO)+offsetof(DTV_CHANNEL_INFO, bIDIdex)),
                        pcBuffer, sizeof(BYTE));

    case E_DATA_VERSION_PAT:
        return SetNVRAM(StartAddress+
                        (wPRIndex*sizeof(DTV_CHANNEL_INFO)+offsetof(DTV_CHANNEL_INFO, stPSI_SI_Version)+offsetof(DVB_TABLE_VERSION, bPATVer)),
                        pcBuffer, sizeof(BYTE));

    case E_DATA_VERSION_PMT:
        return SetNVRAM(StartAddress+
                        (wPRIndex*sizeof(DTV_CHANNEL_INFO)+offsetof(DTV_CHANNEL_INFO, stPSI_SI_Version)+offsetof(DVB_TABLE_VERSION, bPMTVer)),
                        pcBuffer, sizeof(BYTE));

    case E_DATA_VERSION_NIT:
        return SetNVRAM(StartAddress+
                        (wPRIndex*sizeof(DTV_CHANNEL_INFO)+offsetof(DTV_CHANNEL_INFO, stPSI_SI_Version)+offsetof(DVB_TABLE_VERSION, bNITVer)),
                        pcBuffer, sizeof(BYTE));

    case E_DATA_VERSION_SDT:
        return SetNVRAM(StartAddress+
                        (wPRIndex*sizeof(DTV_CHANNEL_INFO)+offsetof(DTV_CHANNEL_INFO, stPSI_SI_Version)+offsetof(DVB_TABLE_VERSION, bSDTVer)),
                        pcBuffer, sizeof(BYTE));

    case E_DATA_MISC:
        return SetNVRAM(StartAddress+
                        (wPRIndex*sizeof(DTV_CHANNEL_INFO)+offsetof(DTV_CHANNEL_INFO, stCHAttribute)),
                        pcBuffer, sizeof(CHANNEL_ATTRIBUTE));


    case E_DATA_SERVICE_ID:
        return SetNVRAM(StartAddress+
                        (wPRIndex*sizeof(DTV_CHANNEL_INFO)+offsetof(DTV_CHANNEL_INFO, wService_ID)),
                        pcBuffer, sizeof(WORD));

    case E_DATA_PCR_PID:
        return SetNVRAM(StartAddress+
                        (wPRIndex*sizeof(DTV_CHANNEL_INFO)+offsetof(DTV_CHANNEL_INFO, wPCR_PID)),
                        pcBuffer, sizeof(WORD));

    case E_DATA_VIDEO_PID:
        return SetNVRAM(StartAddress+
                        (wPRIndex*sizeof(DTV_CHANNEL_INFO)+offsetof(DTV_CHANNEL_INFO, wVideo_PID)),
                        pcBuffer, sizeof(WORD));

    case E_DATA_AUDIO_STREAM_INFO:
        return SetNVRAM(StartAddress+
                        (wPRIndex*sizeof(DTV_CHANNEL_INFO)+offsetof(DTV_CHANNEL_INFO, stAudInfo)),
                        pcBuffer, sizeof(AUD_INFO)*MAX_AUD_LANG_NUM);

    case E_DATA_SERVICE_NAME:
        return SetNVRAM(StartAddress+
                        (wPRIndex*sizeof(DTV_CHANNEL_INFO)+offsetof(DTV_CHANNEL_INFO, bChannelName)),
                        pcBuffer, sizeof(BYTE)*MAX_SERVICE_NAME);

    #if ENABLE_DTV_STORE_TTX_PAGE_INFO
    case E_DATA_TTX_LIST:
         return SetNVRAM(StartAddress+
                        (wPRIndex*sizeof(DTV_CHANNEL_INFO)+offsetof(DTV_CHANNEL_INFO, u8ListPage)),
                        pcBuffer, sizeof(BYTE)*MAX_LISTPAGE_SIZE);
    #endif

    default:
        break;
    }

    return FALSE;
}


static BOOLEAN SetIDTable(BYTE bIDIndex, BYTE * pcBuffer,PROGRAMDATA_MEMBER eMember)
{
	DWORD StartAddress=BASEADDRESS_PR_DTVIDTABLE;
	DWORD NetworkStartAddress=BASEADDRESS_PR_DTVNETWORK;

    if( MAX_MUX_NUMBER <= bIDIndex )
    {
        return FALSE;
    }
#if DVB_T_C_DIFF_DB
	if (IsCATVInUse())
	{
		StartAddress=BASEADDRESS_PR_DTV_C_IDTABLE;
		NetworkStartAddress=BASEADDRESS_PR_DTV_C_DTVNETWORK;
	}
#endif


    switch(eMember)
    {
        case E_DATA_PLP:
            return SetNVRAM(StartAddress+(bIDIndex*sizeof(DTVPROGRAMID_M)+offsetof(DTVPROGRAMID_M, cPLPID)),pcBuffer, sizeof(BYTE));

        case E_DATA_PCN:
            return SetNVRAM(StartAddress+(bIDIndex*sizeof(DTVPROGRAMID_M)+offsetof(DTVPROGRAMID_M, cRFChannelNumber)),
                        pcBuffer, sizeof(BYTE));

        case E_DATA_TS_ID:
            return SetNVRAM(StartAddress+(bIDIndex*sizeof(DTVPROGRAMID_M)+offsetof(DTVPROGRAMID_M, wTransportStream_ID)),
                        pcBuffer, sizeof(WORD));

        case E_DATA_ON_ID:
            return SetNVRAM(StartAddress+(bIDIndex*sizeof(DTVPROGRAMID_M)+offsetof(DTVPROGRAMID_M, wOriginalNetwork_ID)),
                        pcBuffer, sizeof(WORD));
        case E_DATA_NETWORK_ID:
            return SetNVRAM(NetworkStartAddress+(bIDIndex*sizeof(DTVNETWORK)+offsetof(DTVNETWORK, wNetwork_ID)),
                        pcBuffer, sizeof(WORD));
        case E_DATA_CELL_ID:
            return SetNVRAM(StartAddress+(bIDIndex*sizeof(DTVPROGRAMID_M)+offsetof(DTVPROGRAMID_M, wCellID)),
                        pcBuffer, sizeof(WORD));
        case E_DATA_NETWORK_NAME:
            return SetNVRAM(NetworkStartAddress+(bIDIndex*sizeof(DTVNETWORK)+offsetof(DTVNETWORK, bNetworkName)),
                        pcBuffer, sizeof(BYTE)*MAX_SERVICE_NAME);

        case E_DATA_NETWORK:
            return SetNVRAM(NetworkStartAddress+(bIDIndex*sizeof(DTVNETWORK)),pcBuffer, sizeof(DTVNETWORK));

        case E_DATA_NETWORK_INDEX:
            return SetNVRAM(StartAddress+(bIDIndex*sizeof(DTVPROGRAMID_M)+offsetof(DTVPROGRAMID_M, cNetWorkIndex)),pcBuffer, sizeof(BYTE));
#if (ENABLE_UPDATE_MULTIPLEX_VIA_NIT)
        case E_DATA_ORIGINAL_PCN:
            return SetNVRAM(StartAddress+(bIDIndex*sizeof(DTVPROGRAMID_M)+offsetof(DTVPROGRAMID_M, cOriginal_RF)),
                        pcBuffer, sizeof(BYTE));

        case E_DATA_ALTERNATIVE_TIME:
            return SetNVRAM(StartAddress+(bIDIndex*sizeof(DTVPROGRAMID_M)+offsetof(DTVPROGRAMID_M, dwAlternativeTime)),
                            pcBuffer, sizeof(DWORD));
#endif
        case E_DATA_ID_TABLE:
            return SetNVRAM(StartAddress+(bIDIndex*sizeof(DTVPROGRAMID_M)),pcBuffer, sizeof(DTVPROGRAMID_M));
#if DVB_C_ENABLE
        case E_DATA_FREQ:
            return SetNVRAM(StartAddress+(bIDIndex*sizeof(DTVPROGRAMID_M)+offsetof(DTVPROGRAMID_M, u32Frequency)),
                            pcBuffer, sizeof(U32));

        case E_DATA_SYMB_RATE:
            return SetNVRAM(StartAddress+(bIDIndex*sizeof(DTVPROGRAMID_M)+offsetof(DTVPROGRAMID_M, u32SymbRate)),
                            pcBuffer, sizeof(U32));

        case E_DATA_QAM_MODE:
            return SetNVRAM(StartAddress+(bIDIndex*sizeof(DTVPROGRAMID_M)+offsetof(DTVPROGRAMID_M, QamMode)),
                            pcBuffer, sizeof(BYTE));
#endif
    }

    return FALSE;
}


static BOOLEAN GetIDTable(BYTE bIDIndex, BYTE * pcBuffer,PROGRAMDATA_MEMBER eMember)
{
	DWORD StartAddress=BASEADDRESS_PR_DTVIDTABLE;
	DWORD NetworkStartAddress=BASEADDRESS_PR_DTVNETWORK;

    if( MAX_MUX_NUMBER <= bIDIndex )
    {
        return FALSE;
    }
#if DVB_T_C_DIFF_DB
	if (IsCATVInUse())
	{
		StartAddress=BASEADDRESS_PR_DTV_C_IDTABLE;
		NetworkStartAddress=BASEADDRESS_PR_DTV_C_DTVNETWORK;
	}
#endif


    switch(eMember)
    {
        case E_DATA_PLP:
            return GetNVRAM(StartAddress+(bIDIndex*sizeof(DTVPROGRAMID_M)+offsetof(DTVPROGRAMID_M, cPLPID)),pcBuffer, sizeof(BYTE));


        case E_DATA_PCN:
            return GetNVRAM(StartAddress+(bIDIndex*sizeof(DTVPROGRAMID_M)+offsetof(DTVPROGRAMID_M, cRFChannelNumber)),
                        pcBuffer, sizeof(BYTE));


        case E_DATA_TS_ID:
            return GetNVRAM(StartAddress+(bIDIndex*sizeof(DTVPROGRAMID_M)+offsetof(DTVPROGRAMID_M, wTransportStream_ID)),
                        pcBuffer, sizeof(WORD));


        case E_DATA_ON_ID:
            return GetNVRAM(StartAddress+(bIDIndex*sizeof(DTVPROGRAMID_M)+offsetof(DTVPROGRAMID_M, wOriginalNetwork_ID)),
                        pcBuffer, sizeof(WORD));

        case E_DATA_CELL_ID:
            return GetNVRAM(StartAddress+(bIDIndex*sizeof(DTVPROGRAMID_M)+offsetof(DTVPROGRAMID_M, wCellID)),
                        pcBuffer, sizeof(WORD));

        case E_DATA_NETWORK_ID:
            return GetNVRAM(NetworkStartAddress+(bIDIndex*sizeof(DTVNETWORK)+offsetof(DTVNETWORK, wNetwork_ID)),
                        pcBuffer, sizeof(WORD));

        case E_DATA_NETWORK_NAME:
            return GetNVRAM(NetworkStartAddress+(bIDIndex*sizeof(DTVNETWORK)+offsetof(DTVNETWORK, bNetworkName)),
                        pcBuffer, sizeof(BYTE)*MAX_SERVICE_NAME);

        case E_DATA_NETWORK:
            return GetNVRAM(NetworkStartAddress+(bIDIndex*sizeof(DTVNETWORK)),pcBuffer, sizeof(DTVNETWORK));

        case E_DATA_NETWORK_INDEX:
            return GetNVRAM(StartAddress+(bIDIndex*sizeof(DTVPROGRAMID_M)+offsetof(DTVPROGRAMID_M, cNetWorkIndex)),pcBuffer, sizeof(BYTE));
#if (ENABLE_UPDATE_MULTIPLEX_VIA_NIT)
        case E_DATA_ORIGINAL_PCN:
            return GetNVRAM(StartAddress+(bIDIndex*sizeof(DTVPROGRAMID_M)+offsetof(DTVPROGRAMID_M, cOriginal_RF)),
                        pcBuffer, sizeof(BYTE));

        case E_DATA_ALTERNATIVE_TIME:
            return GetNVRAM(StartAddress+(bIDIndex*sizeof(DTVPROGRAMID_M)+offsetof(DTVPROGRAMID_M, dwAlternativeTime)),
                        pcBuffer, sizeof(DWORD));
#endif
        case E_DATA_ID_TABLE:
            return GetNVRAM(StartAddress+(bIDIndex*sizeof(DTVPROGRAMID_M)),
                        pcBuffer, sizeof(DTVPROGRAMID_M));
#if DVB_C_ENABLE
        case E_DATA_FREQ:
            return GetNVRAM(StartAddress+(bIDIndex*sizeof(DTVPROGRAMID_M)+offsetof(DTVPROGRAMID_M, u32Frequency)),
                        pcBuffer, sizeof(U32));

        case E_DATA_SYMB_RATE:
            return GetNVRAM(StartAddress+(bIDIndex*sizeof(DTVPROGRAMID_M)+offsetof(DTVPROGRAMID_M, u32SymbRate)),
                        pcBuffer, sizeof(U32));

        case E_DATA_QAM_MODE:
            return GetNVRAM(StartAddress+(bIDIndex*sizeof(DTVPROGRAMID_M)+offsetof(DTVPROGRAMID_M, QamMode)),
                        pcBuffer, sizeof(BYTE));
#endif
    }

    return FALSE;
}

//****************************************************************************
/// Get Empty Index Of Program Table
/// @return WORD: Program Index
//****************************************************************************
static WORD GetEmptyIndexOfProgramTable(void)
{
    WORD wPRIndex;

    for(wPRIndex=0; wPRIndex < MAX_DTVPROGRAM; wPRIndex++)
    {
        if( FALSE == IsProgramEntityActive(wPRIndex) )
        {
            return wPRIndex;
        }
    }

    return INVALID_PRINDEX;
}

//****************************************************************************
/// Is Program Entity Active
/// @param wPRIndex \b IN: Program Index
/// @return BOOLEAN:
/// - 1: Default is Active
/// - 0: NO
//****************************************************************************
static BOOLEAN IsProgramEntityActive(WORD wPRIndex)
{
    if( MAX_DTVPROGRAM <= wPRIndex )
    {
        return FALSE;
    }

    #if DVB_T_C_DIFF_DB
    if (IsCATVInUse())
        return ( (m_acDTV_C_ProgramTableMap[wPRIndex/8] & (0x01 << (wPRIndex%8))) ? TRUE : FALSE );
    else
    #endif
    return ( (m_acDTVProgramTableMap[wPRIndex/8] & (0x01 << (wPRIndex%8))) ? TRUE : FALSE );
}

static BOOLEAN IsIDEntityActive(BYTE bIDIndex)
{
    if( MAX_MUX_NUMBER <= bIDIndex )
    {
        return FALSE;
    }

    #if DVB_T_C_DIFF_DB
    if (IsCATVInUse())
        return ( (m_acDTV_C_IDtableMap[bIDIndex/8] & (0x01 << (bIDIndex%8))) ? TRUE : FALSE );
    else
    #endif
    return ( (m_acDTVIDtableMap[bIDIndex/8] & (0x01 << (bIDIndex%8))) ? TRUE : FALSE );
}

//****************************************************************************
/// This function will Active Program Entity
/// @param wPRIndex \b IN: Program Index
/// @param bActive \b IN: Active or noy
/// @return BOOLEAN: Function execution result
//****************************************************************************
static BOOLEAN ActiveProgramEntity(WORD wPRIndex, BOOLEAN bActive)
{
    BYTE cTemp;

    if( MAX_DTVPROGRAM <= wPRIndex )
    {
        return FALSE;
    }

    cTemp = wPRIndex/8;

    #if DVB_T_C_DIFF_DB
    if (IsCATVInUse())
    {
        if(TRUE == bActive)
        {
            m_acDTV_C_ProgramTableMap[cTemp] =  m_acDTV_C_ProgramTableMap[cTemp] | (0x01 << (wPRIndex%8));
        }
        else
        {
            m_acDTV_C_ProgramTableMap[cTemp] =  m_acDTV_C_ProgramTableMap[cTemp] & ~(0x01 << (wPRIndex%8));
        }

        SetNVRAM(BASEADDRESS_PR_DTV_C_PRTABLEMAP+cTemp, &(m_acDTV_C_ProgramTableMap[cTemp]), sizeof(BYTE));
    }
    else
    {
        if(TRUE == bActive)
        {
            m_acDTVProgramTableMap[cTemp] =  m_acDTVProgramTableMap[cTemp] | (0x01 << (wPRIndex%8));
        }
        else
        {
            m_acDTVProgramTableMap[cTemp] =  m_acDTVProgramTableMap[cTemp] & ~(0x01 << (wPRIndex%8));
        }

        SetNVRAM(BASEADDRESS_PR_DTVPRTABLEMAP+cTemp, &(m_acDTVProgramTableMap[cTemp]), sizeof(BYTE));
    }
    #else
    if(TRUE == bActive)
    {
        m_acDTVProgramTableMap[cTemp] =  m_acDTVProgramTableMap[cTemp] | (0x01 << (wPRIndex%8));
    }
    else
    {
        m_acDTVProgramTableMap[cTemp] =  m_acDTVProgramTableMap[cTemp] & ~(0x01 << (wPRIndex%8));
    }

    SetNVRAM(BASEADDRESS_PR_DTVPRTABLEMAP+cTemp, &(m_acDTVProgramTableMap[cTemp]), sizeof(BYTE));
    #endif

    return TRUE;
}


static BOOLEAN ActiveIDEntity(BYTE bIDIndex, BOOLEAN bActive)
{
    BYTE cTemp;

    if( MAX_MUX_NUMBER <= bIDIndex )
    {
        return FALSE;
    }

    cTemp = bIDIndex/8;

    #if DVB_T_C_DIFF_DB
    if (IsCATVInUse())
    {
		if(TRUE == bActive)
        {
            m_acDTVIDtableMap[cTemp] =  m_acDTVIDtableMap[cTemp] | (0x01 << (bIDIndex%8));
        }
        else
        {
            m_acDTVIDtableMap[cTemp] =  m_acDTVIDtableMap[cTemp] & ~(0x01 << (bIDIndex%8));
        }

        SetNVRAM(BASEADDRESS_PR_DTV_C_IDTABLEMAP+cTemp, &(m_acDTV_C_IDtableMap[cTemp]), sizeof(BYTE));
    }
    else
    {
        if(TRUE == bActive)
        {
            m_acDTVIDtableMap[cTemp] =  m_acDTVIDtableMap[cTemp] | (0x01 << (bIDIndex%8));
        }
        else
        {
            m_acDTVIDtableMap[cTemp] =  m_acDTVIDtableMap[cTemp] & ~(0x01 << (bIDIndex%8));
        }

        SetNVRAM(BASEADDRESS_PR_DTVIDTABLEMAP+cTemp, &(m_acDTVIDtableMap[cTemp]), sizeof(BYTE));
    }
    #else

    if(TRUE == bActive)
    {
        m_acDTVIDtableMap[cTemp] =  m_acDTVIDtableMap[cTemp] | (0x01 << (bIDIndex%8));
    }
    else
    {
        m_acDTVIDtableMap[cTemp] =  m_acDTVIDtableMap[cTemp] & ~(0x01 << (bIDIndex%8));
    }

    SetNVRAM(BASEADDRESS_PR_DTVIDTABLEMAP+cTemp, &(m_acDTVIDtableMap[cTemp]), sizeof(BYTE));
    #endif

    return TRUE;
}

//****************************************************************************
/// Fill Audio Stream Info With Default
/// @param pstAudioStreamInfo \b IN: Audio Stream Info
/// - @see AUD_INFO
/// @return BOOLEAN: Function execution result
//****************************************************************************
static BOOLEAN FillAudioStreamInfoWithDefault(AUD_INFO *pstAudioStreamInfo)
{
    BYTE i;

    pstAudioStreamInfo->wAudPID = INVALID_PID;
    pstAudioStreamInfo->wAudType = E_AUDIOSTREAM_INVALID;
#if 1//NTV_FUNCTION_ENABLE
    pstAudioStreamInfo->u8ProfileAndLevel = 0;
    pstAudioStreamInfo->u8Component_AAC_Type = 0;
#endif

    for(i = 0; i < MAX_AUD_ISOLANG_NUM; i++)
    {
        pstAudioStreamInfo->aISOLangInfo[i].bAudType = 0x00;
        pstAudioStreamInfo->aISOLangInfo[i].bISOLanguageInfo = 0x00;
        pstAudioStreamInfo->aISOLangInfo[i].bIsValid = FALSE;
        pstAudioStreamInfo->aISOLangInfo[i].bBroadcastMixedAD = FALSE;
        pstAudioStreamInfo->aISOLangInfo[i].bISOLangIndex = LANGUAGE_NONE;
    }
    return TRUE;
}

//****************************************************************************
/// Fill Program ID With Default
/// @param pstDTVPROGRAMID_M \b IN: DTV Program ID
/// - @see DTVPROGRAMID_M
/// @return BOOLEAN: Function execution result
//****************************************************************************
static BOOLEAN FillProgramIDWithDefault(DTVPROGRAMID_M * pstDTVProgramID)
{
    pstDTVProgramID->wTransportStream_ID = INVALID_TS_ID;
    pstDTVProgramID->wOriginalNetwork_ID = INVALID_ON_ID;
    pstDTVProgramID->cNetWorkIndex = INVALID_NETWORKINDEX;
    pstDTVProgramID->cRFChannelNumber = INVALID_PHYSICAL_CHANNEL_NUMBER;
    pstDTVProgramID->cPLPID = INVALID_PLPID;
#if (ENABLE_UPDATE_MULTIPLEX_VIA_NIT)
    pstDTVProgramID->cOriginal_RF = INVALID_PHYSICAL_CHANNEL_NUMBER;
    pstDTVProgramID->dwAlternativeTime = INVALID_ALTERNATIVETIME;
#endif
    #if DVB_C_ENABLE
    pstDTVProgramID->u32Frequency = INVALID_FREQUENCY;
    pstDTVProgramID->u32SymbRate  = INVALID_SYMBRATE;
    pstDTVProgramID->QamMode      = INVALID_QAMMODE;
    #endif

    return TRUE;
}

//****************************************************************************
/// Fill NETWORK With Default
/// @param DTVNETWORK \b IN: Network ID
/// - @see DTVNETWORK
/// @return BOOLEAN: Function execution result
//****************************************************************************
static BOOLEAN FillNetworkWithDefault(DTVNETWORK * pstDTVNetwork)
{
    pstDTVNetwork->wNetwork_ID = INVALID_NID;
    memset(pstDTVNetwork->bNetworkName,0x00,sizeof(BYTE)*MAX_NETWORK_NAME);

    return TRUE;
}


//****************************************************************************
/// Fill Program Index With Default
/// @param pstDTVProgramIndex \b IN: DTV Program Index
/// - @see DTVPROGRAMINDEX
/// @return BOOLEAN: Function execution result
//****************************************************************************
static BOOLEAN FillProgramIndexWithDefault(DTVPROGRAMINDEX * pstDTVProgramIndex)
{
    pstDTVProgramIndex->bServiceType = DEFAULT_SERVICE_TYPE;
    pstDTVProgramIndex->bVisibleServiceFlag = DEFAULT_VISIBLE_SERVICE_FLAG;
    pstDTVProgramIndex->bIsDelete = DEFAULT_IS_DELETED;
    pstDTVProgramIndex->bIsReplaceDel = DEFAULT_IS_REPLACE_DEL;
    pstDTVProgramIndex->bIsFavorite = DEFAULT_IS_FAVORITE;
    pstDTVProgramIndex->bIsSkipped = DEFAULT_IS_SKIPPED;
    pstDTVProgramIndex->bIsLock = DEFAULT_IS_LOCKED;
    pstDTVProgramIndex->bIsStillPicture = DEFAULT_IS_STILL_PICTURE;
    pstDTVProgramIndex->bIsMove = DEFAULT_IS_MOVED;
    pstDTVProgramIndex->bInvalidCell = DEFAULT_IS_INVALID_CELL;
    pstDTVProgramIndex->bUnconfirmedService = DEFAULT_IS_UNCONFIRMED_SERVICE;
    pstDTVProgramIndex->bInvalidService = DEFAULT_IS_INVALID_SERVICE;
    pstDTVProgramIndex->bNumericSelectionFlag = DEFAULT_NUMERIC_SELECTION_FLAG;
    pstDTVProgramIndex->wPRIndex = DEFAULT_PRINDEX;
    pstDTVProgramIndex->eLCNAssignmentType = DEFAULT_LCN_ASSIGNMENT_TYPE;
    pstDTVProgramIndex->wLCN = DEFAULT_LCN;
    pstDTVProgramIndex->wSimu_LCN = DEFAULT_SIMU_LCN;
    pstDTVProgramIndex->wService_ID = DEFAULT_SERVICE_ID;
    pstDTVProgramIndex->bServiceTypePrio = DEFAULT_SERVICE_TYPE_PRIO;
    pstDTVProgramIndex->bIsSpecialService = DEFAULT_SPECIAL_SERVICE;
    #if ENABLE_T_C_CHANNEL_MIX
    pstDTVProgramIndex->bIsTerrestrial = DEFAULT_IS_CABLE;
    #endif

    return TRUE;
}

//****************************************************************************
/// Fill Program Default Data Without Service Name
/// @param pstShortDtvPgmData \b IN: Short DTV Program Data
/// - @see SHORT_DTV_CHANNEL_INFO
//****************************************************************************
void msAPI_CM_FillProgramDefaultDataWithoutSrvName(SHORT_DTV_CHANNEL_INFO *pstShortDtvPgmData)
{
    BYTE i;

    pstShortDtvPgmData->wOrder = DEFAULT_ORDER;
    pstShortDtvPgmData->wLCN = DEFAULT_LCN;
#if 1//NTV_FUNCTION_ENABLE
    pstShortDtvPgmData->wTS_LCN = DEFAULT_LCN;
#endif
    pstShortDtvPgmData->wSimu_LCN = DEFAULT_SIMU_LCN;
    pstShortDtvPgmData->wCellID = DEFAULT_CELLID;
    pstShortDtvPgmData->cRFChannelNumber = DEFAULT_PCN;
    pstShortDtvPgmData->stPSI_SI_Version.bPATVer = DEFAULT_VERSION;
    pstShortDtvPgmData->stPSI_SI_Version.bPMTVer = DEFAULT_VERSION;
    pstShortDtvPgmData->stPSI_SI_Version.bNITVer = DEFAULT_VERSION;
    pstShortDtvPgmData->stPSI_SI_Version.bSDTVer = DEFAULT_VERSION;
    pstShortDtvPgmData->stCHAttribute.wSignalStrength = DEFAULT_SIGNAL_STRENGTH;
    pstShortDtvPgmData->stCHAttribute.bValidLCN = DEFAULT_LCN_VALID;
#if ENABLE_TARGET_REGION
    pstShortDtvPgmData->stCHAttribute.cRegion = DEFAULT_REGION;
#endif
    pstShortDtvPgmData->stCHAttribute.bVisibleServiceFlag = DEFAULT_VISIBLE_SERVICE_FLAG;
    pstShortDtvPgmData->stCHAttribute.bNumericSelectionFlag = DEFAULT_NUMERIC_SELECTION_FLAG;
    pstShortDtvPgmData->stCHAttribute.bIsDelete = DEFAULT_IS_DELETED;
    pstShortDtvPgmData->stCHAttribute.bIsReplaceDel = DEFAULT_IS_REPLACE_DEL;
    pstShortDtvPgmData->stCHAttribute.bIsFavorite = DEFAULT_IS_FAVORITE;
    pstShortDtvPgmData->stCHAttribute.bIsMove = DEFAULT_IS_MOVED;
    pstShortDtvPgmData->stCHAttribute.bInvalidCell = DEFAULT_IS_INVALID_CELL;
    pstShortDtvPgmData->stCHAttribute.bUnconfirmedService = DEFAULT_IS_UNCONFIRMED_SERVICE;
    pstShortDtvPgmData->stCHAttribute.bInvalidService = DEFAULT_IS_INVALID_SERVICE;
    pstShortDtvPgmData->stCHAttribute.bIsSkipped = DEFAULT_IS_SKIPPED;
    pstShortDtvPgmData->stCHAttribute.bIsLock = DEFAULT_IS_LOCKED;
    pstShortDtvPgmData->stCHAttribute.bIsScramble = DEFAULT_IS_SCRAMBLED;
    pstShortDtvPgmData->stCHAttribute.bIsStillPicture = DEFAULT_IS_STILL_PICTURE;
    pstShortDtvPgmData->stCHAttribute.bReplaceService = DEFAULT_IS_REPLACE_SERVICE;
    pstShortDtvPgmData->stCHAttribute.eVideoType = DEFAULT_VIDEO_TYPE;
    pstShortDtvPgmData->stCHAttribute.bIsServiceIdOnly = DEFAULT_IS_SERVICE_ID_ONLY;
    pstShortDtvPgmData->stCHAttribute.bServiceType = DEFAULT_SERVICE_TYPE;
    pstShortDtvPgmData->stCHAttribute.bIsSpecialService = DEFAULT_SPECIAL_SERVICE;
    pstShortDtvPgmData->stCHAttribute.bServiceTypePrio = DEFAULT_SERVICE_TYPE_PRIO;
    #if ENABLE_T_C_CHANNEL_MIX
    pstShortDtvPgmData->stCHAttribute.bIsTerrestrial = DEFAULT_IS_CABLE;
    #endif
    pstShortDtvPgmData->wTransportStream_ID = DEFAULT_TS_ID;
    pstShortDtvPgmData->wOriginalNetwork_ID = DEFAULT_ON_ID;
    pstShortDtvPgmData->wService_ID = DEFAULT_SERVICE_ID;
    pstShortDtvPgmData->wPmt_PID = DEFAULT_PMT_PID;
    pstShortDtvPgmData->wPCR_PID = DEFAULT_PCR_PID;
    pstShortDtvPgmData->wVideo_PID = DEFAULT_VIDEO_PID;

    for(i=0; i < MAX_AUD_LANG_NUM; i++)
    {
        FillAudioStreamInfoWithDefault(&(pstShortDtvPgmData->stAudInfo[i]));
    }
}

//****************************************************************************
/// Fill Program Data With Default
/// @param pcBuffer \b IN: pointer to Buffer
/// @param eMember \b IN: Member
/// - @see PROGRAMDATA_MEMBER
/// @return BOOLEAN: Function execution result
//****************************************************************************
static BOOLEAN FillProgramDataWithDefault(BYTE * pcBuffer, PROGRAMDATA_MEMBER eMember)
{
    BYTE i;
    CHANNEL_ATTRIBUTE Misc;
    AUD_INFO astAudioStreamInfo[MAX_AUD_LANG_NUM];
    DTV_CHANNEL_INFO DTVProgramData;
    BYTE sServiceName[MAX_SERVICE_NAME],bPhN,bVerNum;
    WORD wOrder,wLCN,wMemID;

    // Added by coverity_0216
    memset(&DTVProgramData, 0, sizeof(DTV_CHANNEL_INFO));

    switch(eMember)
    {
    case E_DATA_ALL:
        DTVProgramData.wOrder = DEFAULT_ORDER;
        DTVProgramData.wLCN = DEFAULT_LCN;
#if 1//NTV_FUNCTION_ENABLE
        DTVProgramData.wTS_LCN = DEFAULT_LCN;
#endif
        DTVProgramData.wSimu_LCN = DEFAULT_SIMU_LCN;
        DTVProgramData.stPSI_SI_Version.bPATVer = DEFAULT_VERSION;
        DTVProgramData.stPSI_SI_Version.bPMTVer = DEFAULT_VERSION;
        DTVProgramData.stPSI_SI_Version.bNITVer = DEFAULT_VERSION;
        DTVProgramData.stPSI_SI_Version.bSDTVer = DEFAULT_VERSION;
        DTVProgramData.stCHAttribute.bVisibleServiceFlag = DEFAULT_VISIBLE_SERVICE_FLAG;
        DTVProgramData.stCHAttribute.bNumericSelectionFlag = DEFAULT_NUMERIC_SELECTION_FLAG;
        DTVProgramData.stCHAttribute.bIsDelete = DEFAULT_IS_DELETED;
        DTVProgramData.stCHAttribute.bIsReplaceDel = DEFAULT_IS_REPLACE_DEL;
        DTVProgramData.stCHAttribute.bIsFavorite = DEFAULT_IS_FAVORITE;
        DTVProgramData.stCHAttribute.bIsSkipped = DEFAULT_IS_SKIPPED;
        DTVProgramData.stCHAttribute.bIsLock = DEFAULT_IS_LOCKED;
        DTVProgramData.stCHAttribute.bIsScramble = DEFAULT_IS_SCRAMBLED;
        DTVProgramData.stCHAttribute.bIsStillPicture = DEFAULT_IS_STILL_PICTURE;
        DTVProgramData.stCHAttribute.bIsMove = DEFAULT_IS_MOVED;
        DTVProgramData.stCHAttribute.bInvalidCell = DEFAULT_IS_INVALID_CELL;
        DTVProgramData.stCHAttribute.bUnconfirmedService = DEFAULT_IS_UNCONFIRMED_SERVICE;
        DTVProgramData.stCHAttribute.bInvalidService = DEFAULT_IS_INVALID_SERVICE;
        DTVProgramData.stCHAttribute.bReplaceService = DEFAULT_IS_REPLACE_SERVICE;
        DTVProgramData.stCHAttribute.bIsServiceIdOnly = DEFAULT_IS_SERVICE_ID_ONLY;
        DTVProgramData.stCHAttribute.eVideoType = DEFAULT_VIDEO_TYPE;
        DTVProgramData.stCHAttribute.bServiceType = DEFAULT_SERVICE_TYPE;
        DTVProgramData.stCHAttribute.bIsSpecialService = DEFAULT_SPECIAL_SERVICE;
        DTVProgramData.stCHAttribute.bServiceTypePrio = DEFAULT_SERVICE_TYPE_PRIO;
        DTVProgramData.stCHAttribute.wSignalStrength = DEFAULT_SIGNAL_STRENGTH;
        DTVProgramData.stCHAttribute.bValidLCN = DEFAULT_LCN_VALID;

#if ENABLE_TARGET_REGION
		DTVProgramData.stCHAttribute.cRegion = DEFAULT_REGION;
#endif
        #if ENABLE_T_C_CHANNEL_MIX
        DTVProgramData.stCHAttribute.bIsTerrestrial = DEFAULT_IS_CABLE;
        #endif
        DTVProgramData.wService_ID = DEFAULT_SERVICE_ID;
        DTVProgramData.wPmt_PID = DEFAULT_PMT_PID;
        DTVProgramData.wPCR_PID = DEFAULT_PCR_PID;
        DTVProgramData.wVideo_PID = DEFAULT_VIDEO_PID;

        for(i=0; i < MAX_AUD_LANG_NUM; i++)
        {
            FillAudioStreamInfoWithDefault(&(DTVProgramData.stAudInfo[i]));
        }
#if ENABLE_SAVE_MULTILINGUAL_SERVICE_NAME
		{
			int j;
			for(j=0;j<MAX_MULTI_LINGUAL_SERVICE_NAME;j++)
			{
				DTVProgramData.bMultiLanguage[j]=INVALID_LANG_INDEX;
				for(i=0; i < MAX_SERVICE_NAME; i++)
				{
					DTVProgramData.bMultiChannelName[j][i] = NULL;
				}
			}
		}
#endif

        for(i=0; i < MAX_SERVICE_NAME; i++)
        {
            DTVProgramData.bChannelName[i] = NULL;
        }

        #if ENABLE_DTV_STORE_TTX_PAGE_INFO
        SetListPageNumber(DTVProgramData.u8ListPage, 0, DEFAULT_LISTPAGE[0]);
        SetListPageNumber(DTVProgramData.u8ListPage, 1, DEFAULT_LISTPAGE[1]);
        SetListPageNumber(DTVProgramData.u8ListPage, 2, DEFAULT_LISTPAGE[2]);
        SetListPageNumber(DTVProgramData.u8ListPage, 3, DEFAULT_LISTPAGE[3]);
        #endif
        memcpy(pcBuffer,&DTVProgramData,sizeof(DTV_CHANNEL_INFO));
        break;

    case E_DATA_ORDER:
        wOrder = DEFAULT_ORDER;
        memcpy(pcBuffer,&wOrder,sizeof(WORD));
        break;
    case E_DATA_SIMU_LCN:
    case E_DATA_LCN:
        if(eMember == E_DATA_LCN)
        {
            wLCN = DEFAULT_LCN;
        }
        else
        {
            wLCN = DEFAULT_SIMU_LCN;
        }
        memcpy(pcBuffer,&wLCN,sizeof(WORD));
        break;

    case E_DATA_PCN:
        bPhN = DEFAULT_PCN;
        memcpy(pcBuffer,&bPhN,sizeof(BYTE));
        break;

    case E_DATA_VERSION_PAT:
    case E_DATA_VERSION_PMT:
    case E_DATA_VERSION_NIT:
    case E_DATA_VERSION_SDT:
        bVerNum = DEFAULT_VERSION;
        memcpy(pcBuffer,&bVerNum,sizeof(BYTE));
        break;

    case E_DATA_MISC:
        Misc.bVisibleServiceFlag = DEFAULT_VISIBLE_SERVICE_FLAG;
        Misc.bNumericSelectionFlag = DEFAULT_NUMERIC_SELECTION_FLAG;
        Misc.bIsDelete = DEFAULT_IS_DELETED;
        Misc.bIsReplaceDel = DEFAULT_IS_REPLACE_DEL;
        Misc.bIsFavorite = DEFAULT_IS_FAVORITE;
        Misc.bIsSkipped = DEFAULT_IS_SKIPPED;
        Misc.bIsLock = DEFAULT_IS_LOCKED;
        Misc.bIsScramble = DEFAULT_IS_SCRAMBLED;
        Misc.bIsStillPicture = DEFAULT_IS_STILL_PICTURE;
        Misc.bIsMove = DEFAULT_IS_MOVED;
        Misc.bInvalidCell = DEFAULT_IS_INVALID_CELL;
        Misc.bInvalidService = DEFAULT_IS_INVALID_SERVICE;
        Misc.bUnconfirmedService = DEFAULT_IS_UNCONFIRMED_SERVICE;
        Misc.bReplaceService = DEFAULT_IS_REPLACE_SERVICE;
        Misc.bIsServiceIdOnly = DEFAULT_IS_SERVICE_ID_ONLY;
        Misc.eVideoType = DEFAULT_VIDEO_TYPE;
        Misc.bServiceType = DEFAULT_SERVICE_TYPE;
        Misc.bIsSpecialService = DEFAULT_SPECIAL_SERVICE;
        Misc.bServiceTypePrio = DEFAULT_SERVICE_TYPE_PRIO;
        Misc.wSignalStrength = DEFAULT_SIGNAL_STRENGTH;
        Misc.bValidLCN = DEFAULT_LCN_VALID;

#if ENABLE_TARGET_REGION
		Misc.cRegion=DEFAULT_REGION;
#endif
        #if ENABLE_T_C_CHANNEL_MIX
        Misc.bIsTerrestrial = DEFAULT_IS_CABLE;
        #endif
        memcpy(pcBuffer,&Misc,sizeof(CHANNEL_ATTRIBUTE));
        break;

    case E_DATA_TS_ID:
        wMemID = DEFAULT_TS_ID;
        memcpy(pcBuffer,&wMemID,sizeof(WORD));
        break;

    case E_DATA_ON_ID:
        wMemID = DEFAULT_ON_ID;
        memcpy(pcBuffer,&wMemID,sizeof(WORD));
        break;

    case E_DATA_SERVICE_ID:
        wMemID = DEFAULT_SERVICE_ID;
        memcpy(pcBuffer,&wMemID,sizeof(WORD));
        break;

    case E_DATA_PCR_PID:
        wMemID = DEFAULT_PCR_PID;
        memcpy(pcBuffer,&wMemID,sizeof(WORD));
        break;

    case E_DATA_VIDEO_PID:
        wMemID = DEFAULT_VIDEO_PID;
        memcpy(pcBuffer,&wMemID,sizeof(WORD));
        break;

    case E_DATA_AUDIO_STREAM_INFO:
        for(i=0; i < MAX_AUD_LANG_NUM; i++)
        {
            FillAudioStreamInfoWithDefault(&astAudioStreamInfo[i]);
        }
        memcpy(pcBuffer,astAudioStreamInfo,sizeof(AUD_INFO));
        break;

    case E_DATA_SERVICE_NAME:

        for(i=0; i < MAX_SERVICE_NAME; i++)
        {
            sServiceName[i] = NULL;
        }
        memcpy(pcBuffer,sServiceName,sizeof(BYTE)*MAX_SERVICE_NAME);
        break;

    default:
        return FALSE;
    }

    return TRUE;
}

//****************************************************************************
/// Are Orders Same Service
/// @param wOrderOfChamp \b IN: Order Of Champ
/// @param wOrderOfChallenger \b IN: Order Of Challenger
/// @return BOOLEAN:
/// - TRUE:  Is same
/// - FALSE: NO
//****************************************************************************
static BOOLEAN AreOrdersSameService(WORD wOrderOfChamp, WORD wOrderOfChallenger, BOOLEAN bCheckTSID)
{
    WORD wIDs_1, wIDs_2;
    BOOLEAN bRet = FALSE;

    if( MAX_DTVPROGRAM <= wOrderOfChamp || MAX_DTVPROGRAM <= wOrderOfChallenger )
    {
        bRet = FALSE;
        goto exit1;
    }

    if( (m_astDTVProgramIndexTable[wOrderOfChamp].bServiceType == m_astDTVProgramIndexTable[wOrderOfChallenger].bServiceType) &&
        ((E_SERVICETYPE_DTV == m_astDTVProgramIndexTable[wOrderOfChamp].bServiceType) ||
        (E_SERVICETYPE_DATA == m_astDTVProgramIndexTable[wOrderOfChamp].bServiceType)||
        (E_SERVICETYPE_RADIO == m_astDTVProgramIndexTable[wOrderOfChamp].bServiceType)) )
    {
        if( (FALSE == IsProgramEntityActive(m_astDTVProgramIndexTable[wOrderOfChamp].wPRIndex)) ||
            (FALSE == IsProgramEntityActive(m_astDTVProgramIndexTable[wOrderOfChallenger].wPRIndex)) )
        {
            bRet = FALSE;
            goto exit1;
        }

        GetProgramTable(m_astDTVProgramIndexTable[wOrderOfChamp].wPRIndex, (BYTE *)&wIDs_1, E_DATA_SERVICE_ID);
        GetProgramTable(m_astDTVProgramIndexTable[wOrderOfChallenger].wPRIndex, (BYTE *)&wIDs_2, E_DATA_SERVICE_ID);
        if( wIDs_1 == wIDs_2 )
        {
            if(bCheckTSID)
            {
            GetIDTable(m_astDTVProgramIndexTable[wOrderOfChamp].cIDIndex, (BYTE *)&wIDs_1, E_DATA_TS_ID);
            GetIDTable(m_astDTVProgramIndexTable[wOrderOfChallenger].cIDIndex, (BYTE *)&wIDs_2, E_DATA_TS_ID);
                    if( wIDs_1 != wIDs_2 )
            {
                    bRet = FALSE;
                    goto exit1;
                }
            }
                GetIDTable(m_astDTVProgramIndexTable[wOrderOfChamp].cIDIndex, (BYTE *)&wIDs_1, E_DATA_ON_ID);
                GetIDTable(m_astDTVProgramIndexTable[wOrderOfChallenger].cIDIndex, (BYTE *)&wIDs_2, E_DATA_ON_ID);
                if( wIDs_1 == wIDs_2 )
                {
                    bRet = TRUE;
                    goto exit1;

                }
            }
        }

exit1:

    return bRet;

}

//****************************************************************************
/// Get Count Of Same Service With IDs
/// @param bServiceType \b IN: Service Type
/// - @see MEMBER_SERVICETYPE
/// @param wTransportStream_ID \b IN: Transport Stream ID
/// @param wOriginalNetwork_ID \b IN: Original Network ID
/// @param wService_ID \b IN: Service ID
/// @param bCheckTsID \b IN: bCheck TsID or not
/// - TRUE: To check
/// - FALSE: NO
/// @return BYTE: count
//****************************************************************************
static BYTE GetCountOfSameServiceWithIDs(MEMBER_SERVICETYPE bServiceType, WORD wTransportStream_ID, WORD wOriginalNetwork_ID, WORD wService_ID, BOOLEAN bCheckTsID)
{
    WORD wPosition;
    WORD wOrder;
    BYTE cIDIndex;
    WORD wProgramCount;
    BYTE cCountOfSameService;
	DTVPROGRAMID_M *pMuxTable=_astDTVProgramIDTable;
#if DVB_T_C_DIFF_DB
	if (IsCATVInUse())pMuxTable=_astDTVCProgramIDTable;
#endif

    wProgramCount = GetProgramCount(bServiceType, INCLUDE_ALL);
    cCountOfSameService = 0;

    for(wPosition = 0; wPosition < wProgramCount; wPosition++)
    {
        wOrder = ConvertPositionToOrder(bServiceType, wPosition);

        if( wService_ID != m_astDTVProgramIndexTable[wOrder].wService_ID )
        {
            continue;
        }

        cIDIndex = m_astDTVProgramIndexTable[wOrder].cIDIndex;

        // if check ts id flag is 1, then check ts id -- we may not check ts id if it is dvb://xxx..xxx in MHEG 1.0.6 spec
        if( (!bCheckTsID || (wTransportStream_ID == pMuxTable[cIDIndex].wTransportStream_ID)) &&
            wOriginalNetwork_ID == pMuxTable[cIDIndex].wOriginalNetwork_ID )
        {
            cCountOfSameService++;
        }
    }

    return cCountOfSameService;
}

//****************************************************************************
/// Get Order Of Same Service With IDs
/// @param bServiceType \b IN: Service Type
/// - @see MEMBER_SERVICETYPE
/// @param wTransportStream_ID \b IN: Transport Stream ID
/// @param wOriginalNetwork_ID \b IN: Original Network ID
/// @param cOrdinal \b IN: Ordinal
/// @param wService_ID \b IN: Service ID
/// @param bCheckTsID \b IN: bCheck TsID or not
/// - TRUE: To check
/// - FALSE: NO
/// @return BYTE: count
//****************************************************************************
static WORD GetOrderOfSameServiceWithIDs(MEMBER_SERVICETYPE bServiceType, WORD wTransportStream_ID, WORD wOriginalNetwork_ID, WORD wService_ID, BYTE cOrdinal, BOOLEAN bCheckTsID)
{
    WORD wPosition;
    WORD wOrder;
    BYTE cIDIndex;
    WORD wProgramCount;
    BYTE cCountOfSameService;
    WORD wRet;
	DTVPROGRAMID_M *pMuxTable=_astDTVProgramIDTable;
#if DVB_T_C_DIFF_DB
	if (IsCATVInUse())pMuxTable=_astDTVCProgramIDTable;
#endif


    wProgramCount = GetProgramCount(bServiceType, INCLUDE_ALL);
    cCountOfSameService = 0;

    wRet = INVALID_ORDER;

    for(wPosition=0; wPosition < wProgramCount; wPosition++)
    {
        wOrder = ConvertPositionToOrder(bServiceType, wPosition);

        if( wService_ID != m_astDTVProgramIndexTable[wOrder].wService_ID )
        {
            continue;
        }

        cIDIndex = m_astDTVProgramIndexTable[wOrder].cIDIndex;

        // if check ts id flag is 1, then check ts id -- we may not check ts id if it is dvb://xxx..xxx in MHEG 1.0.6 spec
        if( (!bCheckTsID || (wTransportStream_ID == pMuxTable[cIDIndex].wTransportStream_ID)) &&
            wOriginalNetwork_ID == pMuxTable[cIDIndex].wOriginalNetwork_ID )
        {
            cCountOfSameService++;

            if( cOrdinal == cCountOfSameService )
            {
                wRet = wOrder;
                break;

            }
        }
    }
    return wRet;
}

//****************************************************************************
/// Get Order Of Same Service With PCN
/// @param cRFChannelNumber \b IN: RF Channel Number
/// @param wService_ID \b IN: Service ID
/// @return WORD: order
//****************************************************************************
static WORD GetOrderOfSameServiceWithPCN(BYTE cRFChannelNumber, WORD wService_ID)
{
    WORD wPosition;
    WORD wOrder;
    BYTE cIDIndex;
    WORD wProgramCount;
    MEMBER_SERVICETYPE bServiceType;
    WORD wRet;
	DTVPROGRAMID_M *pMuxTable=_astDTVProgramIDTable;
#if DVB_T_C_DIFF_DB
	if (IsCATVInUse())pMuxTable=_astDTVCProgramIDTable;
#endif
    bServiceType = E_SERVICETYPE_DTV;
    wProgramCount = GetProgramCount(bServiceType, INCLUDE_ALL);

    wRet = INVALID_ORDER;
    for(wPosition=0; wPosition < wProgramCount; wPosition++)
    {
        wOrder = ConvertPositionToOrder(bServiceType, wPosition);

        if( wService_ID != m_astDTVProgramIndexTable[wOrder].wService_ID )
        {
            continue;
        }

        cIDIndex = m_astDTVProgramIndexTable[wOrder].cIDIndex;
#if (ENABLE_T_C_COMBO)
        if ((IsCATVInUse() &&(cRFChannelNumber == cIDIndex)) ||
            (!IsCATVInUse() &&( cRFChannelNumber == pMuxTable[cIDIndex].cRFChannelNumber )))
#elif DVB_C_ENABLE
        if (cRFChannelNumber == cIDIndex)
#else
        if( cRFChannelNumber == pMuxTable[cIDIndex].cRFChannelNumber )
#endif
        {
            wRet = wOrder;
            goto exit1;
        }
    }

    bServiceType = E_SERVICETYPE_RADIO;

    wProgramCount = GetProgramCount(bServiceType, INCLUDE_ALL);

    for(wPosition=0; wPosition < wProgramCount; wPosition++)
    {
        wOrder = ConvertPositionToOrder(bServiceType, wPosition);

        if( wService_ID != m_astDTVProgramIndexTable[wOrder].wService_ID )
        {
            continue;
        }

        cIDIndex = m_astDTVProgramIndexTable[wOrder].cIDIndex;
#if (ENABLE_T_C_COMBO)
        if ((IsCATVInUse() &&(cRFChannelNumber == cIDIndex)) ||
            (!IsCATVInUse() &&( cRFChannelNumber == pMuxTable[cIDIndex].cRFChannelNumber )))
#elif DVB_C_ENABLE
        if (cRFChannelNumber == cIDIndex)
#else
        if( cRFChannelNumber == pMuxTable[cIDIndex].cRFChannelNumber )
#endif
        {
            wRet = wOrder;
            goto exit1;
        }
    }
    bServiceType = E_SERVICETYPE_DATA;

    wProgramCount = GetProgramCount(bServiceType, INCLUDE_ALL);

    for(wPosition=0; wPosition < wProgramCount; wPosition++)
    {
        wOrder = ConvertPositionToOrder(bServiceType, wPosition);

        if( wService_ID != m_astDTVProgramIndexTable[wOrder].wService_ID )
        {
            continue;
        }

        cIDIndex = m_astDTVProgramIndexTable[wOrder].cIDIndex;
#if (ENABLE_T_C_COMBO)
        if ((IsCATVInUse() &&(cRFChannelNumber == cIDIndex)) ||
            (!IsCATVInUse() &&( cRFChannelNumber == pMuxTable[cIDIndex].cRFChannelNumber )))
#elif DVB_C_ENABLE
        if (cRFChannelNumber == cIDIndex)
#else
        if( cRFChannelNumber == pMuxTable[cIDIndex].cRFChannelNumber )
#endif
        {
            wRet = wOrder;
            goto exit1;
        }
    }
exit1:

    return wRet;
}

//****************************************************************************
/// Get Program Count
/// @param bServiceType \b IN: Service Type
/// - @see MEMBER_SERVICETYPE
/// @param eCountOption \b IN: Count Option
/// - @see COUNT_PROGRAM_OPTION
/// @return WORD: count
//****************************************************************************
static WORD GetProgramCount(MEMBER_SERVICETYPE bServiceType, COUNT_PROGRAM_OPTION eCountOption)
{
    if( FALSE == IsServiceTypeValid(bServiceType) )
    {
        return 0;
    }

    #if DVB_T_C_DIFF_DB
    if (IsCATVInUse())
        return m_awDVBCProgramCount[ConvertServiceTypeToPosition(bServiceType)][eCountOption];
    else
    #endif
    return m_awProgramCount[ConvertServiceTypeToPosition(bServiceType)][eCountOption];
}

//****************************************************************************
/// Update Program Count
/// @param bServiceType \b IN: Service Type
/// - @see MEMBER_SERVICETYPE
//****************************************************************************
static void UpdateProgramCount(MEMBER_SERVICETYPE bServiceType)
{
    #if DVB_T_C_DIFF_DB
    if (IsCATVInUse())
    {
        //if (bServiceType == E_SERVICETYPE_DTV) printf("\n~~~ CATV [%d, %d, %d]\n", CountProgram(bServiceType, EXCLUDE_NOT_VISIBLE_AND_DELETED), CountProgram(bServiceType, INCLUDE_NOT_VISIBLE_EXCLUDE_DELETED), CountProgram(bServiceType, INCLUDE_ALL));
        m_awDVBCProgramCount[ConvertServiceTypeToPosition(bServiceType)][EXCLUDE_NOT_VISIBLE_AND_DELETED] = CountProgram(bServiceType, EXCLUDE_NOT_VISIBLE_AND_DELETED);
        m_awDVBCProgramCount[ConvertServiceTypeToPosition(bServiceType)][INCLUDE_NOT_VISIBLE_EXCLUDE_DELETED] = CountProgram(bServiceType, INCLUDE_NOT_VISIBLE_EXCLUDE_DELETED);
        m_awDVBCProgramCount[ConvertServiceTypeToPosition(bServiceType)][INCLUDE_ALL] = CountProgram(bServiceType, INCLUDE_ALL);
    }
    else
    {
        m_awProgramCount[ConvertServiceTypeToPosition(bServiceType)][EXCLUDE_NOT_VISIBLE_AND_DELETED] = CountProgram(bServiceType, EXCLUDE_NOT_VISIBLE_AND_DELETED);
        m_awProgramCount[ConvertServiceTypeToPosition(bServiceType)][INCLUDE_NOT_VISIBLE_EXCLUDE_DELETED] = CountProgram(bServiceType, INCLUDE_NOT_VISIBLE_EXCLUDE_DELETED);
        m_awProgramCount[ConvertServiceTypeToPosition(bServiceType)][INCLUDE_ALL] = CountProgram(bServiceType, INCLUDE_ALL);
    }
    #else
    m_awProgramCount[ConvertServiceTypeToPosition(bServiceType)][EXCLUDE_NOT_VISIBLE_AND_DELETED] = CountProgram(bServiceType, EXCLUDE_NOT_VISIBLE_AND_DELETED);
    m_awProgramCount[ConvertServiceTypeToPosition(bServiceType)][INCLUDE_NOT_VISIBLE_EXCLUDE_DELETED] = CountProgram(bServiceType, INCLUDE_NOT_VISIBLE_EXCLUDE_DELETED);
    m_awProgramCount[ConvertServiceTypeToPosition(bServiceType)][INCLUDE_ALL] = CountProgram(bServiceType, INCLUDE_ALL);
    #endif
}

//****************************************************************************
/// Count Program
/// @param bServiceType \b IN: Service Type
/// - @see MEMBER_SERVICETYPE
/// @param eCountOption \b IN: Count Option
/// - @see COUNT_PROGRAM_OPTION
//****************************************************************************
static WORD CountProgram(MEMBER_SERVICETYPE bServiceType, COUNT_PROGRAM_OPTION eCountOption)
{
    WORD wPosition;
    WORD wOrder;
    WORD wProgramCount;

    wProgramCount=0;

    for(wPosition=0; wPosition < MAX_DTVPROGRAM; wPosition++)
    {
        wOrder = ConvertPositionToOrder(bServiceType, wPosition);

        if( bServiceType == m_astDTVProgramIndexTable[wOrder].bServiceType )
        {
            if( eCountOption == EXCLUDE_NOT_VISIBLE_AND_DELETED )
            {
                if( (FALSE == m_astDTVProgramIndexTable[wOrder].bVisibleServiceFlag) ||
                    (TRUE == m_astDTVProgramIndexTable[wOrder].bIsDelete))
                {
                    continue;
                }
            }
            else if( eCountOption == INCLUDE_NOT_VISIBLE_EXCLUDE_DELETED )
            {
                if( TRUE == m_astDTVProgramIndexTable[wOrder].bIsDelete )
                {
                    continue;
                }
            }

            wProgramCount++;
        }
        else
        {
            break;
        }
    }

    if( MAX_DTVPROGRAM <= wProgramCount )
    {
        return MAX_DTVPROGRAM;
    }

    return wProgramCount;
}

//****************************************************************************
/// Save Current Service Type
/// @param bServiceType \b IN: Service Type
/// - @see MEMBER_SERVICETYPE
/// @return BOOLEAN: Function execution result
//****************************************************************************
static BOOLEAN SaveCurrentServiceType(MEMBER_SERVICETYPE bServiceType)
{
    if( FALSE == IsServiceTypeValid(bServiceType) )
    {
        return FALSE;
    }

    #if (EEPROM_DB_STORAGE == EEPROM_SAVE_NONE)
    return SetNVRAM( BASEADDRESS_PR_CURRENT_SERVICETYPE,
                     (BYTE *)&bServiceType,
                     sizeof(bServiceType) );
    #else
    return SetNVRAM( RM_SERVICETYPE_LAST_START_ADR,
                     (BYTE *)&bServiceType,
                     sizeof(bServiceType) );
    #endif
}

//****************************************************************************
/// Load Current Service Type
/// @return MEMBER_SERVICETYPE:
/// - @see MEMBER_SERVICETYPE
//****************************************************************************
static MEMBER_SERVICETYPE LoadCurrentServiceType(void)
{
    MEMBER_SERVICETYPE bServiceType;

    bServiceType=E_SERVICETYPE_DTV;
    #if (EEPROM_DB_STORAGE == EEPROM_SAVE_NONE)
    GetNVRAM( BASEADDRESS_PR_CURRENT_SERVICETYPE,
              (BYTE *)&bServiceType,
              sizeof(bServiceType));
    #else
    GetNVRAM( RM_SERVICETYPE_LAST_START_ADR,
              (BYTE *)&bServiceType,
              sizeof(bServiceType));
    #endif
    if( FALSE == IsServiceTypeValid(bServiceType) )
    {
        bServiceType = DEFAULT_CURRENT_SERVICETYPE;
        SaveCurrentServiceType(bServiceType);
    }

    return bServiceType;
}

//****************************************************************************
/// Save Current Order Of TV
/// @param wOrder \b IN: Order
/// @return BOOLEAN: Function execution result
//****************************************************************************
static BOOLEAN SaveCurrentOrderOfTV(WORD wOrder)
{
    if( MAX_DTVPROGRAM <= wOrder )
    {
        return FALSE;
    }
    #if (EEPROM_DB_STORAGE == EEPROM_SAVE_NONE)
    return SetNVRAM(BASEADDRESS_PR_CURRENTORDER_TV, (BYTE *)&wOrder, sizeof(wOrder));
    #else
    return SetNVRAM(RM_DTV_LAST_START_ADR, (BYTE *)&wOrder, sizeof(wOrder));
    #endif
}

//****************************************************************************
/// Load Current Order Of TV
/// @return WORD: order
//****************************************************************************
static WORD LoadCurrentOrderOfTV(void)
{
    WORD wOrder=0;
    WORD wMaxTVOrder;
    #if (EEPROM_DB_STORAGE == EEPROM_SAVE_NONE)
    GetNVRAM(BASEADDRESS_PR_CURRENTORDER_TV, (BYTE *)&wOrder, sizeof(wOrder));
    #else
    GetNVRAM(RM_DTV_LAST_START_ADR, (BYTE *)&wOrder, sizeof(wOrder));
    #endif

    wMaxTVOrder = m_awProgramCount[E_CM_SERVICE_POS_DTV][INCLUDE_ALL]-1;
    if( wMaxTVOrder < wOrder )
    {
        wOrder = DEFAULT_CURRENT_ORDER_TV;
        SaveCurrentOrderOfTV(wOrder);
    }

    return wOrder;
}

//****************************************************************************
/// Save Current Order Of Radio
/// @param wOrder \b IN: Order
/// @return BOOLEAN: Function execution result
//****************************************************************************
static BOOLEAN SaveCurrentOrderOfRadio(WORD wOrder)
{
    if( MAX_DTVPROGRAM <= wOrder )
    {
        return FALSE;
    }
    #if (EEPROM_DB_STORAGE == EEPROM_SAVE_NONE)
    return SetNVRAM(BASEADDRESS_PR_CURRENTORDER_RADIO, (BYTE *)&wOrder, sizeof(wOrder));
    #else
    return SetNVRAM(RM_RADIO_LAST_START_ADR, (BYTE *)&wOrder, sizeof(wOrder));
    #endif
}

//****************************************************************************
/// Load Current Order Of Radio
/// @return WORD: order
//****************************************************************************
static WORD LoadCurrentOrderOfRadio(void)
{
    WORD wOrder=0;
    WORD wMaxRadioOrder, wMinRadioOrder;

    #if (EEPROM_DB_STORAGE == EEPROM_SAVE_NONE)
    GetNVRAM(BASEADDRESS_PR_CURRENTORDER_RADIO, (BYTE *)&wOrder, sizeof(wOrder));
    #else
    GetNVRAM(RM_RADIO_LAST_START_ADR, (BYTE *)&wOrder, sizeof(wOrder));
    #endif

    wMaxRadioOrder = MAX_DTVPROGRAM - m_awProgramCount[E_CM_SERVICE_POS_DATA][INCLUDE_ALL]-1;
    wMinRadioOrder = ((m_awProgramCount[E_CM_SERVICE_POS_RADIO][INCLUDE_ALL]) ? \
            (MAX_DTVPROGRAM - m_awProgramCount[E_CM_SERVICE_POS_DATA][INCLUDE_ALL]-
            m_awProgramCount[E_CM_SERVICE_POS_RADIO][INCLUDE_ALL]) : wMaxRadioOrder);

    if( (wMinRadioOrder > wOrder) || (wMaxRadioOrder < wOrder))
    {
        wOrder = wMaxRadioOrder;//DEFAULT_CURRENT_ORDER_RADIO;
        SaveCurrentOrderOfRadio(wOrder);
    }

    return wOrder;
}
//****************************************************************************
/// Save Current Order Of Data
/// @param wOrder \b IN: Order
/// @return BOOLEAN: Function execution result
//****************************************************************************
static BOOLEAN SaveCurrentOrderOfData(WORD wOrder)
{
    if( MAX_DTVPROGRAM <= wOrder )
    {
        return FALSE;
    }
    #if (EEPROM_DB_STORAGE == EEPROM_SAVE_NONE)
    return SetNVRAM(BASEADDRESS_PR_CURRENTORDER_DATA, (BYTE *)&wOrder, sizeof(wOrder));
    #else
    return SetNVRAM(RM_DATA_LAST_START_ADR, (BYTE *)&wOrder, sizeof(wOrder));
    #endif
}

//****************************************************************************
/// Load Current Order Of Data
/// @return WORD: order
//****************************************************************************
static WORD LoadCurrentOrderOfData(void)
{
    WORD wOrder=0;
    WORD wMaxDataOrder, wMinDataOrder;

    #if (EEPROM_DB_STORAGE == EEPROM_SAVE_NONE)
    GetNVRAM(BASEADDRESS_PR_CURRENTORDER_DATA, (BYTE *)&wOrder, sizeof(wOrder));
    #else
    GetNVRAM(RM_DATA_LAST_START_ADR, (BYTE *)&wOrder, sizeof(wOrder));
    #endif

    wMaxDataOrder = MAX_DTVPROGRAM - 1;
    wMinDataOrder = ((m_awProgramCount[E_CM_SERVICE_POS_DATA][INCLUDE_ALL]) ?
                    (MAX_DTVPROGRAM - m_awProgramCount[E_CM_SERVICE_POS_DATA][INCLUDE_ALL]) :
                    wMaxDataOrder);
    if( (wMinDataOrder > wOrder) || (wMaxDataOrder < wOrder))
    {
        wOrder = wMaxDataOrder;//DEFAULT_CURRENT_ORDER_DATA;
        SaveCurrentOrderOfData(wOrder);
    }

    return wOrder;
}

#if 0
static void RemoveInactiveID(void)
{
    BYTE    cIDIndex;

    for(cIDIndex=0; cIDIndex < MAX_MUX_NUMBER; cIDIndex++)
    {
        if(FALSE == IsIDEntityActive(cIDIndex))
        {
            FillProgramIDWithDefault(&_astDTVProgramIDTable[cIDIndex]);
            SetIDTable(cIDIndex,(BYTE *)&_astDTVProgramIDTable[cIDIndex],E_DATA_ID_TABLE);
            ActiveIDEntity(cIDIndex,FALSE);
        }
    }
}
#endif

static void ResetIDtable(void)
{
    BYTE cIDIndex;
    BYTE* pIDtableMap=m_acDTVIDtableMap;
    DTVPROGRAMID_M *pProgramIDTable=_astDTVProgramIDTable;
#if DVB_T_C_DIFF_DB
    if (IsCATVInUse())
    {
        pIDtableMap=m_acDTV_C_IDtableMap;
        pProgramIDTable=_astDTVCProgramIDTable;
    }
#endif


    for(cIDIndex=0; cIDIndex < MAX_MUX_NUMBER; cIDIndex++)
    {
        FillProgramIDWithDefault(&pProgramIDTable[cIDIndex]);
        SetIDTable(cIDIndex, (BYTE *)&pProgramIDTable[cIDIndex], E_DATA_ID_TABLE);
    }


    for(cIDIndex=0; cIDIndex < MAX_NETWOEK_NUMBER; cIDIndex++)
    {
        FillNetworkWithDefault(&_astDTVNetwork[cIDIndex]);
        SetIDTable(cIDIndex, (BYTE *)&_astDTVNetwork[cIDIndex], E_DATA_NETWORK);
    }

/*
    for(cIDIndex=0; cIDIndex < MAX_DTVIDTABLE_MAP; cIDIndex++)
    {
        m_acDTVIDtableMap[cIDIndex] = 0x00;
    }*/
    memset(pIDtableMap,0,sizeof(m_acDTVIDtableMap));
    SetNVRAM(BASEADDRESS_PR_DTVIDTABLEMAP, pIDtableMap, sizeof(m_acDTVIDtableMap));
}

static void UpdateIDInfo(void)
{
    U8 u8Loop;
    BYTE* pIDtableMap=m_acDTVIDtableMap;
    DTVPROGRAMID_M *pProgramIDTable=_astDTVProgramIDTable;
#if DVB_T_C_DIFF_DB
    if (IsCATVInUse())
    {
        pIDtableMap=m_acDTV_C_IDtableMap;
        pProgramIDTable=_astDTVCProgramIDTable;
    }
#endif


    GetNVRAM(BASEADDRESS_PR_DTVIDTABLEMAP, pIDtableMap, sizeof(m_acDTVIDtableMap));

    for (u8Loop=0; u8Loop < MAX_MUX_NUMBER; u8Loop++)
    {
/*
        if(u8Loop < (MAX_DTVIDTABLE_MAP))
        {
            m_acDTVIDtableMap[u8Loop] = 0x00;
        }
        GetNVRAM(BASEADDRESS_PR_DTVIDTABLEMAP, m_acDTVIDtableMap, sizeof(m_acDTVIDtableMap));
*/
        //FillProgramIDWithDefault(&_astDTVProgramIDTable[u8Loop]);
        GetIDTable(u8Loop,(BYTE *)&pProgramIDTable[u8Loop],E_DATA_ID_TABLE);

    }

    for (u8Loop=0; u8Loop < MAX_NETWOEK_NUMBER; u8Loop++)
    {
        //FillNetworkWithDefault(&_astDTVNetwork[u8Loop]);
        GetIDTable(u8Loop,(BYTE *)&_astDTVNetwork[u8Loop],E_DATA_NETWORK);

    }


}

static void _RestInvalidMUXAndNetwork(void)
{
    U16 i,j;
    DTVPROGRAMID_M* pMuxInfo=_astDTVProgramIDTable;
#if DVB_T_C_DIFF_DB
    if (IsCATVInUse())
    {
        pMuxInfo=_astDTVCProgramIDTable;
    }
#endif

    for (i=0; i < MAX_MUX_NUMBER; i++)
    {
         if((pMuxInfo[i].cRFChannelNumber==INVALID_PHYSICAL_CHANNEL_NUMBER)
#if DVB_C_ENABLE
            && (pMuxInfo[i].u32Frequency==INVALID_FREQUENCY)
#endif
            )
        {
            continue;
        }

        for(j=0;j<MAX_DTVPROGRAM;j++)
        {
            if(m_astDTVProgramIndexTable[j].cIDIndex == i)
            {
                break;
            }
        }
        if(j>=MAX_DTVPROGRAM)
        {
            FillProgramIDWithDefault(&pMuxInfo[i]);
            SetIDTable(i, (BYTE *)&pMuxInfo[i], E_DATA_ID_TABLE);
            ActiveIDEntity(i,FALSE);
        }
    }

    for (i=0; i < MAX_NETWOEK_NUMBER; i++)
    {
        if(_astDTVNetwork[i].wNetwork_ID == INVALID_NID)
        {
            continue;
        }
        for(j=0;j<MAX_MUX_NUMBER;j++)
        {
            if(pMuxInfo[j].cNetWorkIndex == i)
            {
                break;
            }
        }
        if(j>=MAX_MUX_NUMBER)
        {
            FillNetworkWithDefault(&_astDTVNetwork[i]);
            SetIDTable(i,(BYTE *)&_astDTVNetwork[i],E_DATA_NETWORK);
        }


    }
}


static E_CM_SERVICE_POS ConvertServiceTypeToPosition(MEMBER_SERVICETYPE eServiceType)
{
    switch(eServiceType)
    {
        case E_SERVICETYPE_DTV: return E_CM_SERVICE_POS_DTV;
        case E_SERVICETYPE_RADIO: return E_CM_SERVICE_POS_RADIO;
        case E_SERVICETYPE_DATA: return E_CM_SERVICE_POS_DATA;
        default: return E_CM_SERVICE_POS_DTV;
    }
}

//****************************************************************************
/// Update PCN
/// @param cOldRFCH \b IN: Old RF CH
/// @param cNewRFCH \b IN: New RF CH
/// @return BOOLEAN: Function execution result
//****************************************************************************
#if 0
BOOLEAN msAPI_CM_UpdatePCN(BYTE cOldRFCH, BYTE cNewRFCH)
{
    BYTE bIDIdex;
    BYTE cRFChannelNumber;

    for(bIDIdex=0; bIDIdex < MAX_MUX_NUMBER; bIDIdex++)
    {
        GetIDTable(bIDIdex, (BYTE *)&cRFChannelNumber, E_DATA_PCN);
        if(cRFChannelNumber == cOldRFCH)
        {
            #if ( WATCH_DOG == ENABLE )
            msAPI_Timer_ResetWDT();
            #endif

            SetIDTable(bIDIdex, (BYTE *)&cNewRFCH, E_DATA_PCN);
        }
    }
    return TRUE;
}
#endif

#if 0
//****************************************************************************
/// Reset Unsupported Iso639Code
//****************************************************************************
void msAPI_CM_ResetUnsupportedIso639Code(void)
{
    U8 temp=0;

    SetNVRAM(BASEADDRESS_PR_UNSUPPORT_LANGCODE_COUNT, &temp, sizeof(temp));
}

//****************************************************************************
/// Load Unsupported Iso639Code By Index
/// @param pBuf \b IN: pointer to Buf for return
/// @param u8BufSize \b IN: Buffer Size
/// @param u8Index \b IN: Index
//****************************************************************************
void msAPI_CM_LoadUnsupportedIso639CodeByIndex(U8 *pBuf, U8 u8BufSize, U8 u8Index)
{
    if(u8Index >= (MAX_UNSUPPORTED_ISO639CODE_NUM + UNSUPPORT_ISO639CODE_BASE_INDEX))
    {
        return;
    }
    GetNVRAM(BASEADDRESS_PR_NSUPPORT_LANGCODE + (MAX_ISO639CODE_LENGTH * (u8Index - UNSUPPORT_ISO639CODE_BASE_INDEX) ), pBuf, u8BufSize);
}

//****************************************************************************
/// Load Unsupported Iso639Code By Index
/// @param pCode \b IN: Code
/// @return U8: Unsupport ISO639CODE index
//****************************************************************************
U8 msAPI_CM_SaveUnsupportedIso639Code(U8 *pCode)
{
    U8 u8CurSaveNum=0;
    U8 i,au8Code[MAX_ISO639CODE_LENGTH];

    memset(au8Code,0x00,MAX_ISO639CODE_LENGTH);
    GetNVRAM(BASEADDRESS_PR_UNSUPPORT_LANGCODE_COUNT, &u8CurSaveNum, sizeof(u8CurSaveNum));

    if(u8CurSaveNum <= MAX_UNSUPPORTED_ISO639CODE_NUM)
    {
        for(i = 0; i < u8CurSaveNum; i++)
        {
            msAPI_CM_LoadUnsupportedIso639CodeByIndex(au8Code, MAX_ISO639CODE_LENGTH, (i + UNSUPPORT_ISO639CODE_BASE_INDEX));
            if(!memcmp(pCode, au8Code, MAX_ISO639CODE_LENGTH))
            {
                return (i + UNSUPPORT_ISO639CODE_BASE_INDEX);
            }
        }
    }

    if(u8CurSaveNum < MAX_UNSUPPORTED_ISO639CODE_NUM)
    {
        SetNVRAM(BASEADDRESS_PR_NSUPPORT_LANGCODE + (MAX_ISO639CODE_LENGTH * u8CurSaveNum ), pCode, MAX_ISO639CODE_LENGTH);

        u8CurSaveNum++;
        SetNVRAM(BASEADDRESS_PR_UNSUPPORT_LANGCODE_COUNT, &u8CurSaveNum, sizeof(u8CurSaveNum));
        return (u8CurSaveNum + UNSUPPORT_ISO639CODE_BASE_INDEX - 1);
    }
    else
    {
        return (MAX_UNSUPPORTED_ISO639CODE_NUM + UNSUPPORT_ISO639CODE_BASE_INDEX);
    }
}
#endif
//****************************************************************************
/// Reset Audio Valid Information
//****************************************************************************
void msAPI_CM_Reset_AudioValidIndex(void)
{
    _u16ValidAudioIndex=0xFFFF;
}

//****************************************************************************
/// Get current audio valid index
/// @return BYTE: valid index
//****************************************************************************
U16 msAPI_CM_Get_AudioValidIndex(void)
{
    return _u16ValidAudioIndex;
}

//****************************************************************************
/// Update Audio Valid Information
/// @param stValidAudioInfo \b IN: pointer to Valid Audio Information
/// -@see AUD_VALID_INFO
/// @return BOOLEAN:
/// - TRUE:  function done
/// - FALSE: NO
//****************************************************************************
BOOLEAN msAPI_CM_Update_AudioValidInfo(U16 u16AudioValidIndex)
{
    _u16ValidAudioIndex=u16AudioValidIndex;
    return TRUE;
}
//****************************************************************************
/// Get index of RF channel
/// @param bRFChannel \b IN: rf channel
/// @return BYTE: index
//****************************************************************************
BYTE msAPI_CM_Get_RFChannelIndex(BYTE bRFChannel)
{
#if ENABLE_T_C_COMBO
    BYTE i;
	DTVPROGRAMID_M *pMuxTable=_astDTVProgramIDTable;
#if DVB_T_C_DIFF_DB
	if (IsCATVInUse())pMuxTable=_astDTVCProgramIDTable;
#endif

    if(IsCATVInUse())
    {
        if (bRFChannel>=MAX_MUX_NUMBER)
            return MAX_MUX_NUMBER;
        else
            return bRFChannel;
    }

    for(i=0;i<MAX_MUX_NUMBER;i++)
    {
        if(pMuxTable[i].cRFChannelNumber == bRFChannel)
        {
            return i;
        }
    }
    return MAX_MUX_NUMBER;
#elif DVB_C_ENABLE
    if (bRFChannel>=MAX_MUX_NUMBER)
        return MAX_MUX_NUMBER;
    else
        return bRFChannel;
#else
    BYTE i;
    for(i=0;i<MAX_MUX_NUMBER;i++)
    {
        if(_astDTVProgramIDTable[i].cRFChannelNumber == bRFChannel)
        {
            return i;
        }
    }
    return MAX_MUX_NUMBER;
#endif
}


void msAPI_CM_SetAudioStreamValidIndex(MEMBER_SERVICETYPE bServiceType, WORD wPosition,  WORD wType, BYTE bISOLangIndex,U16 *pu16Index)
{
    AUD_INFO stAudInfo[MAX_AUD_LANG_NUM];
    WORD wOrder, wPRIndex;
    BYTE i;
    BYTE cAudioStreamCount;

    if( FALSE == IsServiceTypeValid(bServiceType) )
    {
        return;
    }

    if( FALSE == IsPositionValid(bServiceType, wPosition) )
    {
        return;
    }

    wOrder = ConvertPositionToOrder(bServiceType, wPosition);


    wPRIndex = m_astDTVProgramIndexTable[wOrder].wPRIndex;

    GetProgramTable(wPRIndex, (BYTE *)stAudInfo, E_DATA_AUDIO_STREAM_INFO);
    cAudioStreamCount = 0;

    for(i=0; i < MAX_AUD_LANG_NUM; i++)
    {
        if( (TRUE == IsAudioPIDValid(stAudInfo[i].wAudPID)) &&
            ((wType == stAudInfo[i].wAudType) &&
             (bISOLangIndex == stAudInfo[i].aISOLangInfo[0].bISOLangIndex) ) )
        {
            SETBIT(*pu16Index,i);
        }
    }

}

BYTE msAPI_CM_GetPhysicalChannelNumberByID(WORD wONID, WORD wTSID)
{
    U8 i;
	DTVPROGRAMID_M *pMuxTable=_astDTVProgramIDTable;
#if DVB_T_C_DIFF_DB
	if (IsCATVInUse())pMuxTable=_astDTVCProgramIDTable;
#endif
    for(i=0;i<MAX_MUX_NUMBER;i++)
    {
        if((pMuxTable[i].wOriginalNetwork_ID == wONID) && (pMuxTable[i].wTransportStream_ID== wTSID))
        {
#if ENABLE_T_C_COMBO
            return IsCATVInUse() ? i : pMuxTable[i].cRFChannelNumber;
#elif DVB_C_ENABLE
            return  i;
#else
            return pMuxTable[i].cRFChannelNumber;
#endif
        }
    }
    return INVALID_PHYSICAL_CHANNEL_NUMBER;
}
#if ENABLE_SDT_OTHER_MONITOR

static BOOLEAN _msAPI_CM_GetCEllID(WORD wTS_ID, WORD wON_ID, WORD *wCell_ID, BOOLEAN *bOverOneCell)
{
    BYTE bIDIdex;
    WORD wCellID=DEFAULT_CELLID;
    WORD wPreCell=DEFAULT_CELLID;
	DTVPROGRAMID_M *pMuxTable=_astDTVProgramIDTable;
#if DVB_T_C_DIFF_DB
	if (IsCATVInUse())pMuxTable=_astDTVCProgramIDTable;
#endif
    *bOverOneCell=FALSE;

    *wCell_ID = wCellID;
    for(bIDIdex=0; bIDIdex < MAX_MUX_NUMBER; bIDIdex++)
    {
        if(wTS_ID == pMuxTable[bIDIdex].wTransportStream_ID && wON_ID == pMuxTable[bIDIdex].wOriginalNetwork_ID)
        {
            *wCell_ID = wCellID = pMuxTable[bIDIdex].wCellID;
            if(wPreCell && (wCellID!=wPreCell))
            {
                *bOverOneCell=TRUE;
                break;
            }
            else if(wPreCell==DEFAULT_CELLID)
            {
                wPreCell=wCellID;
            }
        }
    }

    if(wCellID!=DEFAULT_CELLID)
    {
        return TRUE;
    }

    return FALSE;

}
BOOLEAN msAPI_CM_GetCEllID_WithID(WORD wTS_ID, WORD wON_ID, WORD *wCell_ID, BOOLEAN *bOverOneCell)
{
    *wCell_ID = DEFAULT_CELLID;
    if((_msAPI_CM_GetCEllID(wTS_ID, wON_ID, wCell_ID,bOverOneCell))==TRUE)
    {
        //printf("Get Cell ID %u\n",*wCell_ID);
    }
    if(*wCell_ID == DEFAULT_CELLID)
    {
        return FALSE;
    }
    return TRUE;
}
BOOLEAN msAPI_CM_Is_TSExist(WORD wONID, WORD wTSID, BYTE *pcRFChannelNumber)
{
    U8 i;
	DTVPROGRAMID_M *pMuxTable=_astDTVProgramIDTable;
#if DVB_T_C_DIFF_DB
	if (IsCATVInUse())pMuxTable=_astDTVCProgramIDTable;
#endif
    //printf("msAPI_CM_Is_TSExist ONID %u TSID %u\n",wONID,wTSID);
    for(i=0;i<MAX_MUX_NUMBER;i++)
    {
#if ENABLE_T_C_COMBO
        if(IsCATVInUse())
        {
            if(pMuxTable[i].u32Frequency == INVALID_FREQUENCY)continue;
        }
        else if(pMuxTable[i].cRFChannelNumber == INVALID_PHYSICAL_CHANNEL_NUMBER)
        {
            continue;
        }
#elif DVB_C_ENABLE
        if(pMuxTable[i].u32Frequency == INVALID_FREQUENCY)continue;
#else
        if(pMuxTable[i].cRFChannelNumber == INVALID_PHYSICAL_CHANNEL_NUMBER)continue;
#endif

        if((pMuxTable[i].wOriginalNetwork_ID == wONID) && (pMuxTable[i].wTransportStream_ID== wTSID))
        {
#if ENABLE_T_C_COMBO
            *pcRFChannelNumber = IsCATVInUse() ? i : pMuxTable[i].cRFChannelNumber;
#elif DVB_C_ENABLE
            *pcRFChannelNumber =  i;
#else
            *pcRFChannelNumber=pMuxTable[i].cRFChannelNumber;
#endif
            break;
        }
    }
    if(i>=MAX_MUX_NUMBER)return FALSE;
    return TRUE;
}
BOOLEAN msAPI_CM_GetSameServiceInOtherMux(MEMBER_SERVICETYPE bServiceType, WORD wLCN, WORD wSID, WORD *pPosition)
{
    WORD wPosition;
    WORD wOrder1;
    WORD wProgramCount;

    wProgramCount = GetProgramCount(bServiceType, INCLUDE_ALL);


    for( wPosition = 0; wPosition < wProgramCount; wPosition++ )
    {
        wOrder1 = ConvertPositionToOrder(bServiceType, wPosition);
        //printf("find %u(%u) %u(%u)\n",m_astDTVProgramIndexTable[wOrder1].wLCN,wLCN,m_astDTVProgramIndexTable[wOrder1].wService_ID,wSID);
        if((m_astDTVProgramIndexTable[wOrder1].wLCN == wLCN)&&(wSID==m_astDTVProgramIndexTable[wOrder1].wService_ID))
        {
            *pPosition=wPosition;
            break;
        }

    }
    if(wPosition<wProgramCount)
    {
        return TRUE;
    }
    return FALSE;
}
#endif
BOOLEAN msAPI_CM_IsServiceExistWithIDsAndLCN(WORD wOriginalNetwork_ID, WORD wService_ID,  WORD wLCN)
{
    WORD i;
    BOOLEAN eResult=FALSE;
    BYTE cIDIndex;
    MEMBER_SERVICETYPE bServiceType;
    WORD wPosition,wProgramCount,wOrder;
	DTVPROGRAMID_M *pMuxTable=_astDTVProgramIDTable;
#if DVB_T_C_DIFF_DB
	if (IsCATVInUse())pMuxTable=_astDTVCProgramIDTable;
#endif

    bServiceType=E_SERVICETYPE_DTV;
    wProgramCount = GetProgramCount(bServiceType, INCLUDE_ALL);
    wPosition = wProgramCount-1;
    for(i=wProgramCount; i > 0; i--)
    {
        wOrder = ConvertPositionToOrder(bServiceType, wPosition);
        cIDIndex = m_astDTVProgramIndexTable[wOrder].cIDIndex;
        if(pMuxTable[cIDIndex].wOriginalNetwork_ID==wOriginalNetwork_ID)
        {
            if(wService_ID == m_astDTVProgramIndexTable[wOrder].wService_ID)
            {
                if(wLCN == m_astDTVProgramIndexTable[wOrder].wLCN)
                {
                    //printf("got same lcn service\n");
                    eResult = TRUE;
                    break;
                }
            }
        }
        wPosition--;
    }

    bServiceType=E_SERVICETYPE_RADIO;
    wProgramCount = GetProgramCount(bServiceType, INCLUDE_ALL);
    wPosition = wProgramCount-1;
    for(i=wProgramCount; i > 0; i--)
    {
        wOrder = ConvertPositionToOrder(bServiceType, wPosition);
        cIDIndex = m_astDTVProgramIndexTable[wOrder].cIDIndex;
        if(pMuxTable[cIDIndex].wOriginalNetwork_ID==wOriginalNetwork_ID)
        {
            if(wService_ID == m_astDTVProgramIndexTable[wOrder].wService_ID)
            {
                if(wLCN == m_astDTVProgramIndexTable[wOrder].wLCN)
                {
                    //printf("got same lcn service\n");
                    eResult = TRUE;
                    break;
                }
            }
        }
        wPosition--;
    }

    bServiceType=E_SERVICETYPE_DATA;
    wProgramCount = GetProgramCount(bServiceType, INCLUDE_ALL);
    wPosition = wProgramCount-1;
    for(i=wProgramCount; i > 0; i--)
    {
        wOrder = ConvertPositionToOrder(bServiceType, wPosition);
        cIDIndex = m_astDTVProgramIndexTable[wOrder].cIDIndex;
        if(pMuxTable[cIDIndex].wOriginalNetwork_ID==wOriginalNetwork_ID)
        {
            if(wService_ID == m_astDTVProgramIndexTable[wOrder].wService_ID)
            {
                if(wLCN == m_astDTVProgramIndexTable[wOrder].wLCN)
                {
                    //printf("got same lcn service\n");
                    eResult = TRUE;
                    break;
                }
            }
        }
        wPosition--;
    }
    return eResult;
}
#if (ENABLE_UPDATE_MULTIPLEX_VIA_NIT)
BOOLEAN msAPI_CM_RemoveMismatchedMux(WORD wNID, WORD *pwTS_ID,  BYTE cCountOfTS, U32 *u32NewTS, BOOLEAN bRemove)
{
    BYTE cIDIndex;
    WORD wProgramCount;
    WORD wPosition;
    WORD wOrder;
    WORD i;
    BYTE k;
    WORD wRemovedProgramCount=0;
    MEMBER_SERVICETYPE bServiceType;
    U32 u32GetTS=0;
	DTVPROGRAMID_M *pMuxTable=_astDTVProgramIDTable;
#if DVB_T_C_DIFF_DB
	if (IsCATVInUse())pMuxTable=_astDTVCProgramIDTable;
#endif
    for(i=0;(i<cCountOfTS)&&(i<32);i++)
    {
        SETBIT(u32GetTS, i);
    }

    bServiceType=E_SERVICETYPE_DTV;
    wProgramCount = GetProgramCount(bServiceType, INCLUDE_ALL);
    wPosition = wProgramCount-1;
    for(i=wProgramCount; i > 0; i--)
    {
        wOrder = ConvertPositionToOrder(bServiceType, wPosition);
        cIDIndex = m_astDTVProgramIndexTable[wOrder].cIDIndex;
        if( wNID == _astDTVNetwork[pMuxTable[cIDIndex].cNetWorkIndex].wNetwork_ID)
        {
            for(k=0;k<cCountOfTS;k++)
            {
                if(pMuxTable[cIDIndex].wTransportStream_ID == pwTS_ID[k])
                {
                    CLRBIT(u32GetTS,k);
                    break;
                }
            }
            if( cCountOfTS <= k )
            {
                if(bRemove)
                {
                    RemoveProgram(bServiceType, wPosition);
                }
                wRemovedProgramCount++;
            }
        }
        wPosition--;
    }

    bServiceType=E_SERVICETYPE_RADIO;
    wProgramCount = GetProgramCount(bServiceType, INCLUDE_ALL);
    wPosition = wProgramCount-1;
    for(i=wProgramCount; i > 0; i--)
    {
        wOrder = ConvertPositionToOrder(bServiceType, wPosition);
        cIDIndex = m_astDTVProgramIndexTable[wOrder].cIDIndex;
        if( wNID == _astDTVNetwork[pMuxTable[cIDIndex].cNetWorkIndex].wNetwork_ID)
        {
            for(k=0;k<cCountOfTS;k++)
            {
                if(pMuxTable[cIDIndex].wTransportStream_ID == pwTS_ID[k])
                {
                    CLRBIT(u32GetTS,k);
                    break;
                }
            }
            if( cCountOfTS <= k)
            {
                if(bRemove)
                {
                    RemoveProgram(bServiceType, wPosition);
                }
                wRemovedProgramCount++;
            }
        }
        wPosition--;
    }

#if (NORDIG_FUNC) //for Nordig spec v2.0
    bServiceType=E_SERVICETYPE_DATA;
    wProgramCount = GetProgramCount(bServiceType, INCLUDE_ALL);
    wPosition = wProgramCount-1;
    for(i=wProgramCount; i > 0; i--)
    {
        wOrder = ConvertPositionToOrder(bServiceType, wPosition);
        cIDIndex = m_astDTVProgramIndexTable[wOrder].cIDIndex;
        if( wNID == _astDTVNetwork[pMuxTable[cIDIndex].cNetWorkIndex].wNetwork_ID)
        {
            for(k=0;k<cCountOfTS;k++)
            {
                if(pMuxTable[cIDIndex].wTransportStream_ID == pwTS_ID[k])
                {
                    CLRBIT(u32GetTS,k);
                    break;
                }
            }
            if( cCountOfTS <= k)
            {
                if(bRemove)
                {
                    RemoveProgram(bServiceType, wPosition);
                }
                wRemovedProgramCount++;
            }
        }
        wPosition--;
    }
#endif

    if(wRemovedProgramCount && bRemove)
    {
        //printf("remove..........%\n");
        __msAPI_CM_ArrangeDataManager(TRUE, TRUE, FALSE);
    }
    *u32NewTS=u32GetTS;
    if(wRemovedProgramCount)return TRUE;
    return FALSE;
}



static BOOLEAN _msAPI_CM_Set_InvalidCell(WORD wONID, WORD wTSID, WORD wCellID)
{
    WORD i;
    BYTE  cIDIndex;

    MEMBER_SERVICETYPE bServiceType;
    WORD wPosition,wProgramCount,wOrder;
    WORD wPRIndex;
    CHANNEL_ATTRIBUTE stCHAttribute;
	DTVPROGRAMID_M *pMuxTable=_astDTVProgramIDTable;
#if DVB_T_C_DIFF_DB
	if (IsCATVInUse())pMuxTable=_astDTVCProgramIDTable;
#endif

    //printf("x_msAPI_CM_Set_InvalidCell ONID %u TS %u Cell %u\n",wONID,wTSID,wCellID);

    bServiceType=E_SERVICETYPE_DTV;
    wProgramCount = GetProgramCount(bServiceType, INCLUDE_ALL);
    wPosition = wProgramCount-1;
    for(i=wProgramCount; i > 0; i--)
    {
        wOrder = ConvertPositionToOrder(bServiceType, wPosition);
        cIDIndex = m_astDTVProgramIndexTable[wOrder].cIDIndex;
        if((pMuxTable[cIDIndex].wOriginalNetwork_ID==wONID)
            && (pMuxTable[cIDIndex].wTransportStream_ID==wTSID))
        {
            if(pMuxTable[cIDIndex].wCellID==wCellID)
            {
                if (FALSE == m_astDTVProgramIndexTable[wOrder].bInvalidCell)
                {
                    wPRIndex = m_astDTVProgramIndexTable[wOrder].wPRIndex;
                    GetProgramTable(wPRIndex, (BYTE *)&stCHAttribute, E_DATA_MISC);
                    stCHAttribute.bInvalidCell = TRUE;
                    m_astDTVProgramIndexTable[wOrder].bInvalidCell = stCHAttribute.bInvalidCell;
                    if( TRUE != SetProgramTable(wPRIndex, (BYTE *)&stCHAttribute, E_DATA_MISC) )
                    {
                        return FALSE;
                    }
                }
            }
            //printf("invalid cell %u cell %u lcn %u\n",m_astDTVProgramIndexTable[wOrder].bInvalidCell,_astDTVProgramIDTable[cIDIndex].wCellID,m_astDTVProgramIndexTable[wOrder].wLCN);
        }
        wPosition--;
    }

    bServiceType=E_SERVICETYPE_RADIO;
    wProgramCount = GetProgramCount(bServiceType, INCLUDE_ALL);
    wPosition = wProgramCount-1;
    for(i=wProgramCount; i > 0; i--)
    {
        wOrder = ConvertPositionToOrder(bServiceType, wPosition);
        cIDIndex = m_astDTVProgramIndexTable[wOrder].cIDIndex;
        if((pMuxTable[cIDIndex].wOriginalNetwork_ID==wONID)
            && (pMuxTable[cIDIndex].wTransportStream_ID==wTSID))
        {
            if(pMuxTable[cIDIndex].wCellID==wCellID)
            {
                if (FALSE == m_astDTVProgramIndexTable[wOrder].bInvalidCell)
                {
                    wPRIndex = m_astDTVProgramIndexTable[wOrder].wPRIndex;
                    GetProgramTable(wPRIndex, (BYTE *)&stCHAttribute, E_DATA_MISC);
                    stCHAttribute.bInvalidCell = TRUE;
                    m_astDTVProgramIndexTable[wOrder].bInvalidCell = stCHAttribute.bInvalidCell;
                    if( TRUE != SetProgramTable(wPRIndex, (BYTE *)&stCHAttribute, E_DATA_MISC) )
                    {
                        return FALSE;
                    }
                }
            }
            //printf("invalid cell %u cell %u lcn %u\n",m_astDTVProgramIndexTable[wOrder].bInvalidCell,_astDTVProgramIDTable[cIDIndex].wCellID,m_astDTVProgramIndexTable[wOrder].wLCN);
        }
        wPosition--;
    }

#if (NORDIG_FUNC) //for Nordig spec v2.0
    bServiceType=E_SERVICETYPE_DATA;
    wProgramCount = GetProgramCount(bServiceType, INCLUDE_ALL);
    wPosition = wProgramCount-1;
    for(i=wProgramCount; i > 0; i--)
    {
        wOrder = ConvertPositionToOrder(bServiceType, wPosition);
        cIDIndex = m_astDTVProgramIndexTable[wOrder].cIDIndex;
        if((pMuxTable[cIDIndex].wOriginalNetwork_ID==wONID)
            && (pMuxTable[cIDIndex].wTransportStream_ID==wTSID))
        {
            if(pMuxTable[cIDIndex].wCellID==wCellID)
            {
                if (FALSE == m_astDTVProgramIndexTable[wOrder].bInvalidCell)
                {
                    wPRIndex = m_astDTVProgramIndexTable[wOrder].wPRIndex;
                    GetProgramTable(wPRIndex, (BYTE *)&stCHAttribute, E_DATA_MISC);
                    stCHAttribute.bInvalidCell = TRUE;
                    m_astDTVProgramIndexTable[wOrder].bInvalidCell = stCHAttribute.bInvalidCell;
                    if( TRUE != SetProgramTable(wPRIndex, (BYTE *)&stCHAttribute, E_DATA_MISC) )
                    {
                        return FALSE;
                    }
                }
            }
            //printf("invalid cell %u cell %u lcn %u\n",m_astDTVProgramIndexTable[wOrder].bInvalidCell,_astDTVProgramIDTable[cIDIndex].wCellID,m_astDTVProgramIndexTable[wOrder].wLCN);
        }
        wPosition--;
    }
#endif
    return TRUE;
}
BOOLEAN msAPI_CM_SetMismatchedCell(WORD wONID, WORD wTSID, WORD *pCellLsit, U8 u8CellNumber, BOOLEAN *bRemoved)
{
    U8 i,j;
    BOOLEAN eResult=FALSE;
	DTVPROGRAMID_M *pMuxTable=_astDTVProgramIDTable;
#if DVB_T_C_DIFF_DB
	if (IsCATVInUse())pMuxTable=_astDTVCProgramIDTable;
#endif
    *bRemoved=FALSE;
    for(i=0;i<MAX_MUX_NUMBER;i++)
    {
        if((pMuxTable[i].wCellID)&&(pMuxTable[i].wOriginalNetwork_ID == wONID) && (pMuxTable[i].wTransportStream_ID== wTSID))
        {
            //printf("msAPI_CM_SetMismatchedCell ts %u cell %u\n",_astDTVProgramIDTable[i].wTransportStream_ID,_astDTVProgramIDTable[i].wCellID);
            for(j=0;j<u8CellNumber;j++)
            {
                if(pMuxTable[i].wCellID == pCellLsit[j])
                {
                    break;
                }
            }
            if(j>=u8CellNumber)
            {
                *bRemoved=TRUE;
                _msAPI_CM_Set_InvalidCell(wONID, wTSID, pMuxTable[i].wCellID);
                eResult=TRUE;
            }
        }
    }
    return eResult;
}

BOOLEAN msAPI_CM_SetUnconfirmedServiceInvalid(WORD wONID, WORD wTSID, BOOLEAN *bGotService)
{
    WORD i;
    BYTE  cIDIndex;
    MEMBER_SERVICETYPE bServiceType;
    WORD wPosition,wProgramCount,wOrder;
    *bGotService=FALSE;
    WORD wPRIndex;
    CHANNEL_ATTRIBUTE stCHAttribute;
	DTVPROGRAMID_M *pMuxTable=_astDTVProgramIDTable;
#if DVB_T_C_DIFF_DB
	if (IsCATVInUse())pMuxTable=_astDTVCProgramIDTable;
#endif
    //printf("x_msAPI_CM_Set_InvalidCell ONID %u TS %u Cell %u\n",wONID,wTSID,wCellID);

    bServiceType=E_SERVICETYPE_DTV;
    wProgramCount = GetProgramCount(bServiceType, INCLUDE_ALL);
    wPosition = wProgramCount-1;
    for(i=wProgramCount; i > 0; i--)
    {
        wOrder = ConvertPositionToOrder(bServiceType, wPosition);
        cIDIndex = m_astDTVProgramIndexTable[wOrder].cIDIndex;
        if((pMuxTable[cIDIndex].wOriginalNetwork_ID==wONID)
            && (pMuxTable[cIDIndex].wTransportStream_ID==wTSID)
            && (pMuxTable[cIDIndex].cRFChannelNumber==UNCONFIRMED_PHYSICAL_CHANNEL_NUMBER))
        {
            *bGotService=TRUE;
            if (FALSE == m_astDTVProgramIndexTable[wOrder].bInvalidCell)
            {
                wPRIndex = m_astDTVProgramIndexTable[wOrder].wPRIndex;
                GetProgramTable(wPRIndex, (BYTE *)&stCHAttribute, E_DATA_MISC);
                stCHAttribute.bInvalidCell = TRUE;
                m_astDTVProgramIndexTable[wOrder].bInvalidCell = stCHAttribute.bInvalidCell;
                if( TRUE != SetProgramTable(wPRIndex, (BYTE *)&stCHAttribute, E_DATA_MISC) )
                {
                    return FALSE;
                }
            }
        }
        wPosition--;
    }

    bServiceType=E_SERVICETYPE_RADIO;
    wProgramCount = GetProgramCount(bServiceType, INCLUDE_ALL);
    wPosition = wProgramCount-1;
    for(i=wProgramCount; i > 0; i--)
    {
        wOrder = ConvertPositionToOrder(bServiceType, wPosition);
        cIDIndex = m_astDTVProgramIndexTable[wOrder].cIDIndex;
        if((pMuxTable[cIDIndex].wOriginalNetwork_ID==wONID)
            && (pMuxTable[cIDIndex].wTransportStream_ID==wTSID)
            && (pMuxTable[cIDIndex].cRFChannelNumber==UNCONFIRMED_PHYSICAL_CHANNEL_NUMBER))
        {
            *bGotService=TRUE;
            if (FALSE == m_astDTVProgramIndexTable[wOrder].bInvalidCell)
            {
                wPRIndex = m_astDTVProgramIndexTable[wOrder].wPRIndex;
                GetProgramTable(wPRIndex, (BYTE *)&stCHAttribute, E_DATA_MISC);
                stCHAttribute.bInvalidCell = TRUE;
                m_astDTVProgramIndexTable[wOrder].bInvalidCell = stCHAttribute.bInvalidCell;
                if( TRUE != SetProgramTable(wPRIndex, (BYTE *)&stCHAttribute, E_DATA_MISC) )
                {
                    return FALSE;
                }
            }
        }
        wPosition--;
    }

#if (NORDIG_FUNC) //for Nordig spec v2.0
    bServiceType=E_SERVICETYPE_DATA;
    wProgramCount = GetProgramCount(bServiceType, INCLUDE_ALL);
    wPosition = wProgramCount-1;
    for(i=wProgramCount; i > 0; i--)
    {
        wOrder = ConvertPositionToOrder(bServiceType, wPosition);
        cIDIndex = m_astDTVProgramIndexTable[wOrder].cIDIndex;
        if((pMuxTable[cIDIndex].wOriginalNetwork_ID==wONID)
            && (pMuxTable[cIDIndex].wTransportStream_ID==wTSID)
            && (pMuxTable[cIDIndex].cRFChannelNumber==UNCONFIRMED_PHYSICAL_CHANNEL_NUMBER))
        {
            *bGotService=TRUE;
            if (FALSE == m_astDTVProgramIndexTable[wOrder].bInvalidCell)
            {
                wPRIndex = m_astDTVProgramIndexTable[wOrder].wPRIndex;
                GetProgramTable(wPRIndex, (BYTE *)&stCHAttribute, E_DATA_MISC);
                stCHAttribute.bInvalidCell = TRUE;
                m_astDTVProgramIndexTable[wOrder].bInvalidCell = stCHAttribute.bInvalidCell;
                if( TRUE != SetProgramTable(wPRIndex, (BYTE *)&stCHAttribute, E_DATA_MISC) )
                {
                    return FALSE;
                }
            }
        }
        wPosition--;
    }
#endif
    return TRUE;
}

BOOLEAN msAPI_CM_RemoveInvalidService(BOOLEAN *bCurCHIsRemoved)
{
    MEMBER_SERVICETYPE bServiceType, l_eServiceType;
    WORD wPosition, l_wPosition,wProgramCount,wOrder;
    WORD wService_ID;
    WORD i,position;
    BYTE cPhysicalChannelNumber;
    WORD wRemoveCnt=0;
    *bCurCHIsRemoved=FALSE;
    bServiceType = msAPI_CM_GetCurrentServiceType();
    wPosition = msAPI_CM_GetCurrentPosition(bServiceType);
    wService_ID = msAPI_CM_GetService_ID(bServiceType, wPosition);
    cPhysicalChannelNumber = msAPI_CM_GetPhysicalChannelNumber(bServiceType, wPosition);

    bServiceType=E_SERVICETYPE_DTV;
    wProgramCount = GetProgramCount(bServiceType, INCLUDE_ALL);
    wPosition = wProgramCount-1;
    for(i=wProgramCount; i > 0; i--)
    {
        wOrder = ConvertPositionToOrder(bServiceType, wPosition);
        if(m_astDTVProgramIndexTable[wOrder].bInvalidCell)
        {
            RemoveProgram(bServiceType, wPosition);
            wRemoveCnt++;
        }
        wPosition--;
    }

    bServiceType=E_SERVICETYPE_RADIO;
    wProgramCount = GetProgramCount(bServiceType, INCLUDE_ALL);
    wPosition = wProgramCount-1;
    for(i=wProgramCount; i > 0; i--)
    {
        wOrder = ConvertPositionToOrder(bServiceType, wPosition);
        if(m_astDTVProgramIndexTable[wOrder].bInvalidCell)
        {
            RemoveProgram(bServiceType, wPosition);
            wRemoveCnt++;
        }
        wPosition--;
    }

#if (NORDIG_FUNC) //for Nordig spec v2.0
    bServiceType=E_SERVICETYPE_DATA;
    wProgramCount = GetProgramCount(bServiceType, INCLUDE_ALL);
    wPosition = wProgramCount-1;
    for(i=wProgramCount; i > 0; i--)
    {
        wOrder = ConvertPositionToOrder(bServiceType, wPosition);
        if( m_astDTVProgramIndexTable[wOrder].bInvalidCell)
        {
            RemoveProgram(bServiceType, wPosition);
            wRemoveCnt++;
        }
        wPosition--;
    }
#endif

    if(wRemoveCnt)
    {
        __msAPI_CM_ArrangeDataManager(TRUE,FALSE,FALSE);
        if(TRUE== msAPI_CM_GetServiceTypeAndPositionWithPCN(cPhysicalChannelNumber, wService_ID, &l_eServiceType, &l_wPosition))
        {
            if (wPosition != l_wPosition)
            {
                msAPI_CM_SetCurrentPosition(l_eServiceType, l_wPosition);
                //printf("msAPI_CM_RemoveInvalidCell update position\n");
            }
        }
         else
        {
            *bCurCHIsRemoved=TRUE;
            //printf("msAPI_CM_RemoveInvalidCell current service is removed\n");
            if((position= msAPI_CM_GetFirstProgramPosition(E_SERVICETYPE_DTV,FALSE)) != INVALID_PROGRAM_POSITION )
            {
                msAPI_CM_SetCurrentServiceType(E_SERVICETYPE_DTV);
                msAPI_CM_SetCurrentPosition(E_SERVICETYPE_DTV,position);
            }
            else if((position= msAPI_CM_GetFirstProgramPosition(E_SERVICETYPE_RADIO,FALSE)) != INVALID_PROGRAM_POSITION)
            {
                msAPI_CM_SetCurrentServiceType(E_SERVICETYPE_RADIO);
                msAPI_CM_SetCurrentPosition(E_SERVICETYPE_RADIO,position);
            }
#if (NORDIG_FUNC) //for Nordig spec v2.0
            else if((position= msAPI_CM_GetFirstProgramPosition(E_SERVICETYPE_DATA,FALSE)) != INVALID_PROGRAM_POSITION)
            {
                msAPI_CM_SetCurrentServiceType(E_SERVICETYPE_DATA);
                msAPI_CM_SetCurrentPosition(E_SERVICETYPE_DATA,position);
            }
#endif
        }
    }
    return TRUE;
}
BOOLEAN msAPI_CM_CheckNetwork(WORD wNID, WORD *pwTS_ID,  BYTE cCountOfTS, U32 *u32NewTS, BOOLEAN *bRemove)
{
    U32 u32GetTS=0;
    BYTE i,j;
    BOOLEAN bMatchNetwork=FALSE;
	DTVPROGRAMID_M *pMuxTable=_astDTVProgramIDTable;
#if DVB_T_C_DIFF_DB
	if (IsCATVInUse())pMuxTable=_astDTVCProgramIDTable;
#endif
    *bRemove=FALSE;
    for(i=0;(i<cCountOfTS)&&(i<32);i++)
    {
        SETBIT(u32GetTS, i);
    }
    for(i=0;i<MAX_MUX_NUMBER;i++)
    {
        if(_astDTVNetwork[pMuxTable[i].cNetWorkIndex].wNetwork_ID== wNID)
        {
            for(j=0;j<cCountOfTS;j++)
            {
                if(pwTS_ID[j] == pMuxTable[i].wTransportStream_ID)
                {
                    CLRBIT(u32GetTS,j);
                    break;
                }
            }
            if(j>=cCountOfTS)
            {
                *bRemove=TRUE;
            }
            bMatchNetwork=TRUE;
        }
    }
    *u32NewTS=u32GetTS;
    if(bMatchNetwork == FALSE)
    {
        *u32NewTS=0;
    }
    return TRUE;
}
#endif
BOOLEAN msAPI_CM_GetIDTable(BYTE bIDIndex, BYTE * pcBuffer,PROGRAMDATA_MEMBER eMember)
{
    return GetIDTable(bIDIndex, pcBuffer, eMember);
}
BOOLEAN msAPI_CM_SetIDTable(BYTE bIDIndex, BYTE * pcBuffer,PROGRAMDATA_MEMBER eMember)
{
    return SetIDTable(bIDIndex, pcBuffer, eMember);
}

void msAPI_CM_EnableStoreDataToFlash(BOOLEAN bEnable)//20090806
{
    _bSaveDataToFlash=bEnable;
}
void msAPI_CM_GetCMVerString(U8 *pVer)
{
    if(pVer != NULL)
        memcpy(pVer, &u8CM_LibVer[0], sizeof(u8CM_LibVer));
}



//------------------------------------------------------------------------------
///  Reset DTV Data manager
/// @return BOOLEAN : Function execution result
//****************************************************************************
BOOLEAN msAPI_CM_ResetDTVDataManager(void)
{
    U16 wID;

    msAPI_CM_SetCountry(DEFAULT_COUNTRY);
#if ENABLE_DTV
    msAPI_CM_ResetAllProgram();
#endif
    wID = DTVDATA_ID;

    SetNVRAM(BASEADDRESS_PR_IDENT, (BYTE *)&wID, sizeof(wID));

    return TRUE;
}

//------------------------------------------------------------------------------
///  Initialize DTV Data manager
/// @return BOOLEAN : Function execution result
//------------------------------------------------------------------------------
BOOLEAN msAPI_CM_InitDTVDataManager(void)
{
    BYTE i;
    WORD wID=0;

    for (i=0; i < 5; i++)
    {
        if( TRUE == GetNVRAM(BASEADDRESS_PR_IDENT, (BYTE *)&wID, sizeof(wID)) )
        {
            if ( wID == DTVDATA_ID )
            {
                break;
            }
        }
    }

    if( wID != DTVDATA_ID )
    {
        msAPI_CM_ResetDTVDataManager();
    }

    GetNVRAM(BASEADDRESS_COUNTRY, (BYTE *)&m_eCountry, sizeof(m_eCountry));
#if ENABLE_DTV
#if (NTV_FUNCTION_ENABLE)
    GetNVRAM(BASEADDRESS_PR_FAVORITE_REGION, (BYTE *)&_cFavoriteNetwork, sizeof(_cFavoriteNetwork));
#endif
    #if DVB_T_C_DIFF_DB
    if (IsCATVInUse())
        GetNVRAM(BASEADDRESS_PR_DTV_C_PRTABLEMAP, (BYTE *)m_acDTV_C_ProgramTableMap, sizeof(m_acDTV_C_ProgramTableMap));
    else
    #endif
    GetNVRAM(BASEADDRESS_PR_DTVPRTABLEMAP, (BYTE *)m_acDTVProgramTableMap, sizeof(m_acDTVProgramTableMap));
    //GetNVRAM(BASEADDRESS_PR_DTVIDTABLEMAP,(BYTE * )m_acDTVIDtableMap,sizeof(m_acDTVIDtableMap));
    CreatDTVProgramIndexTableAndProgramIDTable();
    m_eCurrentServiceType = LoadCurrentServiceType();
    m_wCurrentOrderOfTV = LoadCurrentOrderOfTV();
    m_wPastOrderOfTV = m_wCurrentOrderOfTV;
    m_wCurrentOrderOfRadio = LoadCurrentOrderOfRadio();
    m_wPastOrderOfRadio = m_wCurrentOrderOfRadio;
    m_wCurrentOrderOfData = LoadCurrentOrderOfData();
    m_wPastOrderOfData = m_wCurrentOrderOfData;
#endif
    return TRUE;
}



//****************************************************************************
/// Get NVRAM
/// @param wAddress \b IN: Address
/// @param pcBuffer \b IN: pointer to Buffer for return
/// @param cSize \b IN: pointer to cSize for return
/// @return BOOLEAN: Function execution result
//****************************************************************************
static BOOLEAN GetNVRAM(DWORD wAddress, BYTE * pcBuffer, BYTE cSize)
{
#if (EEPROM_DB_STORAGE==EEPROM_SAVE_ALL)
    msAPI_rmBurstReadBytes(wAddress,pcBuffer,cSize);

#else
    #if (EEPROM_DB_STORAGE!=EEPROM_SAVE_NONE) //#if (EEPROM_DB_STORAGE==EEPROM_SAVE_WITHOUT_CH_DB)
    if(wAddress>=RM_DTV_LAST_START_ADR && wAddress<=RM_SERVICETYPE_LAST_START_ADR)
    {
        msAPI_rmBurstReadBytes(wAddress,pcBuffer,cSize);
    }
    else
    #endif
    if(wAddress>=BASEADDRESS_PR_DATA && wAddress<END_ADDRESS_OF_DTVDATA_STRUCTURE)
    {
        memcpy(pcBuffer,(void *)_PA2VA(wAddress-RM_GEN_USAGE+DRAM_64K_DB_START(((DATABASE_START_MEMORY_TYPE & MIU1) ? (DATABASE_START_ADR | MIU_INTERVAL) : (DATABASE_START_ADR)))),cSize);
    }
    else
    {
        MS_DEBUG_MSG(printf("\n DTV GetNVRAM  >> something wrong...."));
    }
#endif

    return TRUE;
}
//****************************************************************************
/// Set NVRAM
/// @param wAddress \b IN: Address
/// @param pcBuffer \b IN: pointer to Buffer
/// @param cSize \b IN: pointer to cSize
/// @return BOOLEAN: Function execution result
//****************************************************************************
static BOOLEAN SetNVRAM(DWORD wAddress, BYTE * pcBuffer, BYTE cSize)
{
#if (EEPROM_DB_STORAGE==EEPROM_SAVE_ALL)
    msAPI_rmBurstWriteBytes(wAddress,pcBuffer, cSize);

#else
    #if (EEPROM_DB_STORAGE!=EEPROM_SAVE_NONE)//#if (EEPROM_DB_STORAGE==EEPROM_SAVE_WITHOUT_CH_DB)
    if(wAddress>=RM_DTV_LAST_START_ADR && wAddress<=RM_SERVICETYPE_LAST_START_ADR)
    {
        msAPI_rmBurstWriteBytes(wAddress,pcBuffer,cSize);
    }
    else
    #endif
    if(wAddress>=BASEADDRESS_PR_DATA && wAddress<END_ADDRESS_OF_DTVDATA_STRUCTURE)
    {
        memcpy( (void *)_PA2VA(wAddress-RM_GEN_USAGE+DRAM_64K_DB_START(((DATABASE_START_MEMORY_TYPE & MIU1) ? (DATABASE_START_ADR | MIU_INTERVAL) : (DATABASE_START_ADR)))),pcBuffer,cSize);
        if(_bSaveDataToFlash)
        {
            g_u8QuickDataBase |= QUICK_DB_UPDATE;
        }
    }
    else
    {
        //printf("\n DTV SetNVRAM  >> something wrong....wAddress(0x%x)", wAddress);
        __ASSERT(0);
    }
#endif

    return TRUE;
}

//****************************************************************************
///  Get Country
/// @return MEMBER_COUNTRY : Country
//****************************************************************************
MEMBER_COUNTRY msAPI_CM_GetCountry(void)
{
    return m_eCountry;
}

//****************************************************************************
///  Set Country
/// @param eCountry \b IN: Country
/// - @see MEMBER_COUNTRY
/// @return BOOLEAN : Function execution result
//****************************************************************************
BOOLEAN msAPI_CM_SetCountry(MEMBER_COUNTRY eCountry)
{
    if(eCountry < E_COUNTRY_NUM)
    {
        m_eCountry = eCountry;
        SetNVRAM(BASEADDRESS_COUNTRY, (BYTE *)&eCountry, sizeof(eCountry));

        return TRUE;
    }

    return FALSE;
}

//****************************************************************************
/// Get Network name
/// @param bIndex \b IN: bIndex
/// @param *bNetworkName \b IN: pointer to network name for return
/// @return BOOLEAN: Function execution result
//****************************************************************************
BOOLEAN msAPI_CM_GetNetworkName(BYTE bIndex, BYTE * bNetworkName)
{
    if( bIndex >=  MAX_NETWOEK_NUMBER)
    {
        return FALSE;
    }
    memset(bNetworkName,0,MAX_NETWORK_NAME);

    return GetIDTable(bIndex, (BYTE *)bNetworkName, E_DATA_NETWORK_NAME);
}

//****************************************************************************
/// Store Network Name
/// @param bIndex \b IN: Network Name Table Index
/// @param *bNetworkName \b IN: pointer to Network Name for store
/// @return BYTE: Network Name Table Index of stored Network Name
//****************************************************************************
BOOLEAN msAPI_CM_SetNetworkName(BYTE bIndex, BYTE * bNetworkName)
{
    if( bIndex >=  MAX_NETWOEK_NUMBER || bNetworkName == NULL)
    {
        return FALSE;
    }

    return SetIDTable(bIndex, (BYTE *)bNetworkName, E_DATA_NETWORK_NAME);
}

BOOLEAN msAPI_CM_UpdateNetworkNameWithNID(WORD wNID, BYTE *bNetworkName)
{
    int i;
    BYTE cNetworkIndex = MAX_NETWOEK_NUMBER;

    for(i=0;i < MAX_NETWOEK_NUMBER; i++)
    {
        if((wNID!= INVALID_NID) && (wNID == _astDTVNetwork[i].wNetwork_ID))
        {
            cNetworkIndex = i;
            break;
        }
    }
    if(cNetworkIndex < MAX_NETWOEK_NUMBER)
    {
        if(memcmp(_astDTVNetwork[cNetworkIndex].bNetworkName, bNetworkName, MAX_NETWORK_NAME))
        {
            memcpy(_astDTVNetwork[cNetworkIndex].bNetworkName, bNetworkName, MAX_NETWORK_NAME);
            if(TRUE == msAPI_CM_SetNetworkName(cNetworkIndex, bNetworkName))
                return TRUE;
        }
        else
        {
            return TRUE;
        }
    }
    return FALSE;
}
BOOLEAN msAPI_CM_SetCurrentNetworkName(U8 *bNetworkName, U8 u8NetworkLen)
{
    memset(_au8CurNetworkName,0,MAX_NETWORK_NAME);

    if(bNetworkName != NULL && u8NetworkLen)
    {
        _au8CurNetworkLen = u8NetworkLen > MAX_NETWORK_NAME ? MAX_NETWORK_NAME:u8NetworkLen;
        if(u8NetworkLen > MAX_NETWORK_NAME)
        {
            MS_DEBUG_MSG(printf("overrun-buffer-arg"));//coverity
        }
        else
        {
            memcpy(_au8CurNetworkName, bNetworkName, u8NetworkLen);
        }
        return TRUE;
    }
    return FALSE;
}

BOOLEAN _msAPI_CM_GetCurrentNetworkName(U8 *bNetworkName, U8 *u8NetworkLen)
{
    if(_au8CurNetworkLen)
    {
        memcpy(bNetworkName, _au8CurNetworkName, _au8CurNetworkLen);
        *u8NetworkLen = _au8CurNetworkLen;
        return TRUE;
    }
    else
    {
        *u8NetworkLen = 0;
        return FALSE;
    }
}
BOOLEAN msAPI_CM_GetCurrentNetworkName(U8 *bNetworkName, U8 *u8NetworkLen, U8 u8MaxLen)
{
    int i;
    MEMBER_SERVICETYPE bServiceType;
    WORD wCurrentPosition,wNetwork_ID;
    bServiceType = msAPI_CM_GetCurrentServiceType();
    wCurrentPosition = msAPI_CM_GetCurrentPosition(bServiceType);
    if(INVALID_PROGRAM_POSITION == wCurrentPosition)return FALSE;
    wNetwork_ID = msAPI_CM_GetNetwork_ID(bServiceType,wCurrentPosition);
    if(INVALID_NID == wNetwork_ID)return FALSE;
    for(i=0;i < MAX_NETWOEK_NUMBER; i++)
    {
        if(wNetwork_ID == _astDTVNetwork[i].wNetwork_ID)
        {
            if(u8MaxLen>MAX_NETWORK_NAME)u8MaxLen=MAX_NETWORK_NAME;
            memcpy(bNetworkName, _astDTVNetwork[i].bNetworkName, u8MaxLen);
            if(bNetworkName[u8MaxLen-1])*u8NetworkLen=u8MaxLen;
            else *u8NetworkLen = strlen((char*)bNetworkName);
            return TRUE;
        }
    }
    return FALSE;
}


//****************************************************************************
/// Count same Network program
/// @param bServiceType \b IN: Service type
/// -@see MEMBER_SERVICETYPE
/// @return WORD : Same network program number
//****************************************************************************
WORD msAPI_CM_CountNetworkProgram(MEMBER_SERVICETYPE bServiceType, U16 u16NetworkID)
{
    WORD wProgramCount;
    WORD wNetworkCount;
    WORD wPosition;

    if( FALSE == IsServiceTypeValid(bServiceType) )
    {
        return 0;
    }

    wProgramCount = GetProgramCount(bServiceType, EXCLUDE_NOT_VISIBLE_AND_DELETED);
    wNetworkCount = 0;

    for(wPosition=0; wPosition < wProgramCount; wPosition++)
    {
        if(u16NetworkID == msAPI_CM_GetNetwork_ID(bServiceType,wPosition))
        {
            wNetworkCount++;
        }
    }

    return wNetworkCount;
}

//****************************************************************************
/// Get first same network program position
/// @param bServiceType \b IN: Service type
/// -@see MEMBER_SERVICETYPE
/// @return WORD : First same Network Program position
//****************************************************************************
WORD msAPI_CM_GetFirstNetworkProgramPosition(MEMBER_SERVICETYPE bServiceType, U16 u16NetworkID)
{
    WORD wProgramCount;
    WORD wPosition;

    if( FALSE == IsServiceTypeValid(bServiceType) )
    {
        return INVALID_PROGRAM_POSITION;
    }

    wProgramCount = GetProgramCount(bServiceType, EXCLUDE_NOT_VISIBLE_AND_DELETED);

    for(wPosition=0; wPosition < wProgramCount; wPosition++)
    {
         if(u16NetworkID == msAPI_CM_GetNetwork_ID(bServiceType,wPosition))
            return wPosition;
    }

    return INVALID_PROGRAM_POSITION;
}

//****************************************************************************
/// Get previous Same network program position
/// @param bServiceType \b IN: Service type
/// -@see MEMBER_SERVICETYPE
/// @param wBasePosition \b IN: base position
/// @return WORD : previous same network Program position
//****************************************************************************
WORD msAPI_CM_GetPrevNetworkProgramPosition(MEMBER_SERVICETYPE bServiceType,U16 wBasePosition, U16 u16NetworkID)
{
    WORD wProgramCount;
    WORD wPosition;
    WORD i;

    if( FALSE == IsServiceTypeValid(bServiceType) )
    {
        return INVALID_PROGRAM_POSITION;
    }

    if( FALSE == IsPositionValid(bServiceType, wBasePosition) )
    {
        return INVALID_PROGRAM_POSITION;
    }

    wProgramCount = GetProgramCount(bServiceType, EXCLUDE_NOT_VISIBLE_AND_DELETED);

    if( wBasePosition >= wProgramCount )
    {
        wPosition = wProgramCount;
    }
    else
    {
        wPosition = wBasePosition;
    }

    for(i=0; i < wProgramCount; i++)
    {
        if( wPosition > 0 )
        {
            wPosition--;
        }
        else
        {
            wPosition = wProgramCount - 1;
        }

        if(u16NetworkID == msAPI_CM_GetNetwork_ID(bServiceType,wPosition))
            return wPosition;
    }

    return INVALID_PROGRAM_POSITION;
}

//****************************************************************************
/// Get Next same network program position
/// @param bServiceType \b IN: Service type
/// -@see MEMBER_SERVICETYPE
/// @param wBasePosition \b IN: base position
/// @return WORD : Next network Program position
//****************************************************************************
WORD msAPI_CM_GetNextNetworkProgramPosition(MEMBER_SERVICETYPE bServiceType, WORD wBasePosition, U16 u16NetworkID)
{
    WORD wProgramCount;
    WORD wPosition;
    WORD i;

    if( FALSE == IsServiceTypeValid(bServiceType) )
    {
        return INVALID_PROGRAM_POSITION;
    }

    if( FALSE == IsPositionValid(bServiceType, wBasePosition) )
    {
        return INVALID_PROGRAM_POSITION;
    }

    wProgramCount = GetProgramCount(bServiceType, EXCLUDE_NOT_VISIBLE_AND_DELETED);

    if( wBasePosition >= wProgramCount )
    {
        wPosition = wProgramCount;
    }
    else
    {
        wPosition = wBasePosition;
    }

    for(i=0; i< wProgramCount; i++)
    {
        wPosition++;

        if( wPosition >= wProgramCount )
        {
            wPosition = 0;
        }

        if(u16NetworkID == msAPI_CM_GetNetwork_ID(bServiceType,wPosition))
            return wPosition;
    }

    return INVALID_PROGRAM_POSITION;
}


//****************************************************************************
/// Get last same network program position
/// @param bServiceType \b IN: Service type
/// -@see MEMBER_SERVICETYPE
/// @return WORD : last same network Program position
//****************************************************************************
WORD msAPI_CM_GetLastNetworkProgramPosition(MEMBER_SERVICETYPE bServiceType)
{
    U16 wPosition;
    U16 wNetworkID;

    if( FALSE == IsServiceTypeValid(bServiceType) )
    {
        return INVALID_PROGRAM_POSITION;
    }

    wPosition = msAPI_CM_GetCurrentPosition(bServiceType);

    wNetworkID = msAPI_CM_GetNetwork_ID(bServiceType,wPosition);

    wPosition = msAPI_CM_GetFirstNetworkProgramPosition(bServiceType,wNetworkID);
    return msAPI_CM_GetPrevNetworkProgramPosition(bServiceType, wPosition,wNetworkID);
}

#if DVB_C_ENABLE
//****************************************************************************
/// check the source frequency is inside the range of comparing frequency
/// @param u32SrcFreq \b IN: souce frequency
/// @param U32CompFreq \b IN: compare frequency
/// @return BOOLEAN: TRUE: inside FALSE: outside
//****************************************************************************
static BOOLEAN IsFreqInsideOffsetRange(U32 u32SrcFreq, U32 u32CompFreq)
{
    U32 u32Min, u32Max;
    if ((u32CompFreq>=FREQ_OFFSET_RANGE) && (u32CompFreq-FREQ_OFFSET_RANGE>MIN_DVBC_FREQUENCY))
        u32Min = u32CompFreq-FREQ_OFFSET_RANGE;
    else
        u32Min = MIN_DVBC_FREQUENCY;

    if ((u32CompFreq+FREQ_OFFSET_RANGE)<MAX_DVBC_FREQUENCY)
        u32Max = u32CompFreq+FREQ_OFFSET_RANGE;
    else
        u32Max = MAX_DVBC_FREQUENCY;

    if ((u32SrcFreq>=u32Min) && (u32SrcFreq<=u32Max))
        return TRUE;
    else
        return FALSE;
}

BOOLEAN msAPI_CM_GetIDIndexWithFreq(U32 u32Freq, BYTE *cIDIndex)
{
    U8 u8i;
	DTVPROGRAMID_M *pMuxTable=_astDTVProgramIDTable;
#if DVB_T_C_DIFF_DB
	if (IsCATVInUse())pMuxTable=_astDTVCProgramIDTable;
#endif
    if (NULL == cIDIndex)
        return FALSE;

    for(u8i=0;u8i<MAX_MUX_NUMBER;u8i++)
    {
        if (pMuxTable[u8i].u32Frequency == u32Freq)
        {
            *cIDIndex = u8i;
            return TRUE;
        }
    }
    *cIDIndex = INVALID_IDINDEX;
    return FALSE;
}
BYTE msAPI_CM_RemoveQuickInstallMismatchedProgram(WORD *pwServiceID, U8 cCountOfServiceID, BYTE cRFChannelNumber, MEMBER_SERVICETYPE eServiceType)
{
    BYTE cIDIndex;
    WORD wProgramCount;
    WORD wPosition;
    WORD wOrder;
    WORD wServiceId;
    WORD i;
    BYTE j;
    BYTE cRemovedProgramCount;

    if( FALSE == IsServiceTypeValid(eServiceType) ||
        FALSE == IsPhysicalChannelNumberValid(cRFChannelNumber) )
    {
        return 0;
    }

    cIDIndex = cRFChannelNumber;

    if( MAX_MUX_NUMBER <= cIDIndex )
    {
        return 0;
    }

    cRemovedProgramCount = 0;
    wProgramCount = GetProgramCount(eServiceType, INCLUDE_ALL);
    wPosition = wProgramCount-1;

    for(i=wProgramCount; i > 0; i--)
    {
        wOrder = ConvertPositionToOrder(eServiceType, wPosition);
        cIDIndex = m_astDTVProgramIndexTable[wOrder].cIDIndex;
        if (cIDIndex == cRFChannelNumber)
        {
            wServiceId = m_astDTVProgramIndexTable[wOrder].wService_ID;

            for(j=0; j < cCountOfServiceID; j++)
            {
                if(pwServiceID[j] == wServiceId)
                {
                    break;
                }
            }
            if( cCountOfServiceID <= j )
            {
                RemoveProgram(eServiceType, wPosition);
                cRemovedProgramCount++;
            }
        }
        wPosition--;
    }
    return cRemovedProgramCount;
}
void msAPI_CM_RemoveQuickInstallMismatchedTS(U16 *pu16TsIds, U8 u8TsIdNum)
{
    U8 index1,index2,index3;
    WORD wTsId,wTotalServiceNumber,wOrder;
	DTVPROGRAMID_M *pMuxTable=_astDTVProgramIDTable;
#if DVB_T_C_DIFF_DB
	if (IsCATVInUse())pMuxTable=_astDTVCProgramIDTable;
#endif

    for(index1 = 0; index1 < MAX_MUX_NUMBER; index1++)
    {
        wTsId = pMuxTable[index1].wTransportStream_ID;

        if(wTsId == INVALID_TS_ID)
            continue;//TODO: Check if continue is needed or break is needed

        for(index2 = 0; index2 < u8TsIdNum; index2++)
        {
            if(pu16TsIds[index2] == wTsId)
                break;
        }

        if(index2 >= u8TsIdNum)
        {
            wTotalServiceNumber = CountProgram(E_SERVICETYPE_DTV, INCLUDE_ALL);
            for(index3 = 0; index3 < wTotalServiceNumber; index3++)
            {
                wOrder = ConvertPositionToOrder(E_SERVICETYPE_DTV, index3);

                if(index1 == m_astDTVProgramIndexTable[wOrder].cIDIndex)
                {
                    RemoveProgram(E_SERVICETYPE_DTV, index3);
                    --index3;
                    --wTotalServiceNumber;
                }
            }

            wTotalServiceNumber = CountProgram(E_SERVICETYPE_RADIO, INCLUDE_ALL);
            for(index3 = 0; index3 < wTotalServiceNumber; index3++)
            {
                wOrder = ConvertPositionToOrder(E_SERVICETYPE_RADIO, index3);
                if(index1 == m_astDTVProgramIndexTable[wOrder].cIDIndex)
                {
                    RemoveProgram(E_SERVICETYPE_RADIO, index3);
                    --index3;
                    --wTotalServiceNumber;
                }
            }
#if (NORDIG_FUNC)
            wTotalServiceNumber = CountProgram(E_SERVICETYPE_DATA, INCLUDE_ALL);
            for(index3 = 0; index3 < wTotalServiceNumber; index3++)
            {
                wOrder = ConvertPositionToOrder(E_SERVICETYPE_DATA, index3);
                if(index1 == m_astDTVProgramIndexTable[wOrder].cIDIndex)
                {
                    RemoveProgram(E_SERVICETYPE_DATA, index3);
                    --index3;
                    --wTotalServiceNumber;
                }
            }
#endif
        }
    }
}
#if ENABLE_T_C_CHANNEL_MIX
BOOLEAN msAPI_CM_RemoveDTVProgramOfAntenna(void)
{
    WORD i;

    for (i=0; i < (MAX_DTVIDTABLE_MAP); i++)
    {
        m_acDTVIDtableMap[i] = 0x00;
    }

    #if ENABLE_T_C_CHANNEL_MIX
    for (i=0; i < MAX_DTVPROGRAM; i++)
    {
        if( ((m_astDTVProgramIndexTable[i].bIsTerrestrial==FALSE) && IsCATVInUse())
            || (m_astDTVProgramIndexTable[i].bIsTerrestrial && (IsCATVInUse()==FALSE)) )
            m_acDTVProgramTableMap[i/8] &= (~(0x01 << (i%8)));
    }
    #endif

    #if DVB_T_C_DIFF_DB
        if (IsCATVInUse())
            SetNVRAM(BASEADDRESS_PR_DTV_C_PRTABLEMAP, m_acDTV_C_ProgramTableMap, sizeof(m_acDTV_C_ProgramTableMap));
        else
    #endif
    SetNVRAM(BASEADDRESS_PR_DTVPRTABLEMAP, m_acDTVProgramTableMap, sizeof(m_acDTVProgramTableMap));

    LogicalChannelNumberIsArranged(FALSE);

    for (i=0; i < MAX_DTVPROGRAM; i++)
    {
        if( (m_acDTVProgramTableMap[i/8] & (0x01 << (i%8))) != 0x00 )
        {
            m_acDTVIDtableMap[m_astDTVProgramIndexTable[i].cIDIndex/8] |= (0x01 << (m_astDTVProgramIndexTable[i].cIDIndex%8));
        }
        else
        {
            m_astDTVProgramIndexTable[i].bServiceType = E_SERVICETYPE_INVALID;
            m_astDTVProgramIndexTable[i].bServiceTypePrio = E_SERVICETYPE_PRIORITY_NONE;
            m_astDTVProgramIndexTable[i].wPRIndex = INVALID_PRINDEX;
        }
    }

    for(i=0; i < MAX_MUX_NUMBER; i++)
    {
        if( (m_acDTVIDtableMap[i/8] & (0x01 << (i%8))) == 0x00 )
        {
            FillProgramIDWithDefault(&_astDTVProgramIDTable[i]);
            SetIDTable(i, (BYTE *)&_astDTVProgramIDTable[i], E_DATA_ID_TABLE);
            if(_astDTVProgramIDTable[i].cNetWorkIndex < MAX_NETWOEK_NUMBER)
            {
                FillNetworkWithDefault(&_astDTVNetwork[_astDTVProgramIDTable[i].cNetWorkIndex]);
                SetIDTable(_astDTVProgramIDTable[i].cNetWorkIndex, (BYTE *)&_astDTVNetwork[_astDTVProgramIDTable[i].cNetWorkIndex], E_DATA_NETWORK);
            }
        }
    }

    SetNVRAM(BASEADDRESS_PR_DTVIDTABLEMAP, m_acDTVIDtableMap, sizeof(m_acDTVIDtableMap));

    m_eCurrentServiceType = DEFAULT_CURRENT_SERVICETYPE;
    m_wCurrentOrderOfTV = DEFAULT_CURRENT_ORDER_TV;
    SaveCurrentOrderOfTV(m_wCurrentOrderOfTV);
    m_wPastOrderOfTV = m_wCurrentOrderOfTV;

    m_wCurrentOrderOfRadio = DEFAULT_CURRENT_ORDER_RADIO;
    SaveCurrentOrderOfRadio(m_wCurrentOrderOfRadio);
    m_wPastOrderOfRadio = m_wCurrentOrderOfRadio;
    m_wCurrentOrderOfData = DEFAULT_CURRENT_ORDER_DATA;
    SaveCurrentOrderOfData(m_wCurrentOrderOfData);
    m_wPastOrderOfData = m_wCurrentOrderOfData;

    #if DVB_T_C_DIFF_DB
    if (IsCATVInUse())
    {   //printf("\n~~~ ResetAllProgram CATV...\n");
        m_awDVBCProgramCount[E_CM_SERVICE_POS_DTV][EXCLUDE_NOT_VISIBLE_AND_DELETED] = 0;
        m_awDVBCProgramCount[E_CM_SERVICE_POS_DTV][INCLUDE_NOT_VISIBLE_EXCLUDE_DELETED] = 0;
        m_awDVBCProgramCount[E_CM_SERVICE_POS_DTV][INCLUDE_ALL] = 0;

        m_awDVBCProgramCount[E_CM_SERVICE_POS_RADIO][EXCLUDE_NOT_VISIBLE_AND_DELETED] = 0;
        m_awDVBCProgramCount[E_CM_SERVICE_POS_RADIO][INCLUDE_NOT_VISIBLE_EXCLUDE_DELETED] = 0;
        m_awDVBCProgramCount[E_CM_SERVICE_POS_RADIO][INCLUDE_ALL] = 0;

        m_awDVBCProgramCount[E_CM_SERVICE_POS_DATA][EXCLUDE_NOT_VISIBLE_AND_DELETED] = 0;
        m_awDVBCProgramCount[E_CM_SERVICE_POS_DATA][INCLUDE_NOT_VISIBLE_EXCLUDE_DELETED] = 0;
        m_awDVBCProgramCount[E_CM_SERVICE_POS_DATA][INCLUDE_ALL] = 0;
    }
    else
    {   //printf("\n~~~ ResetAllProgram DTV...\n");
        m_awProgramCount[E_CM_SERVICE_POS_DTV][EXCLUDE_NOT_VISIBLE_AND_DELETED] = 0;
        m_awProgramCount[E_CM_SERVICE_POS_DTV][INCLUDE_NOT_VISIBLE_EXCLUDE_DELETED] = 0;
        m_awProgramCount[E_CM_SERVICE_POS_DTV][INCLUDE_ALL] = 0;

        m_awProgramCount[E_CM_SERVICE_POS_RADIO][EXCLUDE_NOT_VISIBLE_AND_DELETED] = 0;
        m_awProgramCount[E_CM_SERVICE_POS_RADIO][INCLUDE_NOT_VISIBLE_EXCLUDE_DELETED] = 0;
        m_awProgramCount[E_CM_SERVICE_POS_RADIO][INCLUDE_ALL] = 0;

        m_awProgramCount[E_CM_SERVICE_POS_DATA][EXCLUDE_NOT_VISIBLE_AND_DELETED] = 0;
        m_awProgramCount[E_CM_SERVICE_POS_DATA][INCLUDE_NOT_VISIBLE_EXCLUDE_DELETED] = 0;
        m_awProgramCount[E_CM_SERVICE_POS_DATA][INCLUDE_ALL] = 0;
    }
    #else
    m_awProgramCount[E_CM_SERVICE_POS_DTV][EXCLUDE_NOT_VISIBLE_AND_DELETED] = 0;
    m_awProgramCount[E_CM_SERVICE_POS_DTV][INCLUDE_NOT_VISIBLE_EXCLUDE_DELETED] = 0;
    m_awProgramCount[E_CM_SERVICE_POS_DTV][INCLUDE_ALL] = 0;

    m_awProgramCount[E_CM_SERVICE_POS_RADIO][EXCLUDE_NOT_VISIBLE_AND_DELETED] = 0;
    m_awProgramCount[E_CM_SERVICE_POS_RADIO][INCLUDE_NOT_VISIBLE_EXCLUDE_DELETED] = 0;
    m_awProgramCount[E_CM_SERVICE_POS_RADIO][INCLUDE_ALL] = 0;

    m_awProgramCount[E_CM_SERVICE_POS_DATA][EXCLUDE_NOT_VISIBLE_AND_DELETED] = 0;
    m_awProgramCount[E_CM_SERVICE_POS_DATA][INCLUDE_NOT_VISIBLE_EXCLUDE_DELETED] = 0;
    m_awProgramCount[E_CM_SERVICE_POS_DATA][INCLUDE_ALL] = 0;
    #endif
    //clear unsupported ISO639 language code
    //msAPI_CM_ResetUnsupportedIso639Code();

    return TRUE;
}
#endif
#endif

BOOLEAN msAPI_CM_ResetAttribute(MEMBER_SERVICETYPE bServiceType, WORD wPosition)
{
    WORD wOrder,wPRIndex;
    CHANNEL_ATTRIBUTE stAttribute;

    if( FALSE == IsServiceTypeValid(bServiceType) )
    {
        return FALSE;
    }

    if( FALSE == IsPositionValid(bServiceType, wPosition) )
    {
        return FALSE;
    }

    wOrder = ConvertPositionToOrder(bServiceType, wPosition);
    wPRIndex = m_astDTVProgramIndexTable[wOrder].wPRIndex;

    if(GetProgramTable(wPRIndex, (BYTE *)&stAttribute, E_DATA_MISC))
    {
        stAttribute.bIsDelete  =  DEFAULT_IS_DELETED;
        stAttribute.bIsSkipped =  DEFAULT_IS_SKIPPED;
        stAttribute.bIsLock    =  DEFAULT_IS_LOCKED;
        stAttribute.bIsMove    =  DEFAULT_IS_MOVED;

        if(SetProgramTable(wPRIndex, (BYTE *)&stAttribute, E_DATA_MISC))
        {
            m_astDTVProgramIndexTable[wOrder].bIsDelete  = DEFAULT_IS_DELETED;
            m_astDTVProgramIndexTable[wOrder].bIsSkipped = DEFAULT_IS_SKIPPED;
            m_astDTVProgramIndexTable[wOrder].bIsLock    = DEFAULT_IS_LOCKED;
            m_astDTVProgramIndexTable[wOrder].bIsMove    = DEFAULT_IS_MOVED;

            return TRUE;
        }
    }
    return FALSE;
}

//****************************************************************************
///  Check if LCN exist in CM
/// @param bServiceType \b IN: service type
/// - @see MEMBER_SERVICETYPE
/// @param wLCN \b IN: logical channel number
/// @return BOOLEAN : Function execution result
//****************************************************************************
BOOLEAN msAPI_CM_IsLCNExit(MEMBER_SERVICETYPE bServiceType, WORD wLCN, WORD *pPosition)
{
    WORD wPosition;
    WORD wOrder;
    WORD wProgramCount;

    wProgramCount = GetProgramCount(bServiceType, INCLUDE_ALL);
    for(wPosition=0; wPosition < wProgramCount; wPosition++)
    {
        wOrder = ConvertPositionToOrder(bServiceType, wPosition);
        if( wLCN == m_astDTVProgramIndexTable[wOrder].wLCN )
        {
            *pPosition=wPosition;
            return TRUE;
        }
    }
    return FALSE;
}


#endif//#if ENABLE_DTV
#if (ENABLE_UPDATE_MULTIPLEX_VIA_NIT)
BYTE msAPI_CM_GetOriginalRFnumber(MEMBER_SERVICETYPE bServiceType, WORD wPosition)
{
    WORD wOrder;
    BYTE cIDIndex;
	DTVPROGRAMID_M *pMuxTable=_astDTVProgramIDTable;
#if DVB_T_C_DIFF_DB
	if (IsCATVInUse())pMuxTable=_astDTVCProgramIDTable;
#endif
    if( FALSE == IsServiceTypeValid(bServiceType) )
    {
        return INVALID_PHYSICAL_CHANNEL_NUMBER;
    }
    if( FALSE == IsPositionValid(bServiceType, wPosition) )
    {
        return INVALID_PHYSICAL_CHANNEL_NUMBER;
    }
    wOrder = ConvertPositionToOrder(bServiceType, wPosition);
    cIDIndex = m_astDTVProgramIndexTable[wOrder].cIDIndex;

    return pMuxTable[cIDIndex].cOriginal_RF;
}

BOOLEAN msAPI_CM_ResetOriginalRFnumber(MEMBER_SERVICETYPE bServiceType, WORD wPosition)
{
    WORD wOrder;
    BYTE cIDIndex;
	DTVPROGRAMID_M *pMuxTable=_astDTVProgramIDTable;
#if DVB_T_C_DIFF_DB
	if (IsCATVInUse())pMuxTable=_astDTVCProgramIDTable;
#endif

    if( FALSE == IsServiceTypeValid(bServiceType) )
    {
        return FALSE;
    }

    if( FALSE == IsPositionValid(bServiceType, wPosition) )
    {
        return FALSE;
    }

    wOrder = ConvertPositionToOrder(bServiceType, wPosition);
    cIDIndex = m_astDTVProgramIndexTable[wOrder].cIDIndex;

    pMuxTable[cIDIndex].cOriginal_RF = INVALID_PHYSICAL_CHANNEL_NUMBER;
    if(TRUE == msAPI_CM_SetIDTable(cIDIndex,(BYTE *)&pMuxTable[cIDIndex].cOriginal_RF, E_DATA_ORIGINAL_PCN))
    {
        return TRUE;
    }

    return FALSE;
}

BOOLEAN msAPI_CM_ResetAlternativeTime(MEMBER_SERVICETYPE bServiceType, WORD wPosition)
{
    WORD wOrder;
    BYTE cIDIndex;
	DTVPROGRAMID_M *pMuxTable=_astDTVProgramIDTable;
#if DVB_T_C_DIFF_DB
	if (IsCATVInUse())pMuxTable=_astDTVCProgramIDTable;
#endif

    if( FALSE == IsServiceTypeValid(bServiceType) )
    {
        return FALSE;
    }

    if( FALSE == IsPositionValid(bServiceType, wPosition) )
    {
        return FALSE;
    }

    wOrder = ConvertPositionToOrder(bServiceType, wPosition);
    cIDIndex = m_astDTVProgramIndexTable[wOrder].cIDIndex;
    pMuxTable[cIDIndex].dwAlternativeTime = INVALID_ALTERNATIVETIME;

    if(TRUE == msAPI_CM_SetIDTable(cIDIndex,(BYTE *)&pMuxTable[cIDIndex].dwAlternativeTime, E_DATA_ALTERNATIVE_TIME))
    {
        return TRUE;
    }

    return FALSE;
}
U32 msAPI_CM_GetAlternativeTime(MEMBER_SERVICETYPE bServiceType, WORD wPosition)
{
    WORD wOrder;
    BYTE cIDIndex;
	DTVPROGRAMID_M *pMuxTable=_astDTVProgramIDTable;
#if DVB_T_C_DIFF_DB
	if (IsCATVInUse())pMuxTable=_astDTVCProgramIDTable;
#endif

    if( FALSE == IsServiceTypeValid(bServiceType) )
    {
        return INVALID_ALTERNATIVETIME;
    }

    if( FALSE == IsPositionValid(bServiceType, wPosition) )
    {
        return INVALID_ALTERNATIVETIME;
    }

    wOrder = ConvertPositionToOrder(bServiceType, wPosition);
    cIDIndex = m_astDTVProgramIndexTable[wOrder].cIDIndex;

    return pMuxTable[cIDIndex].dwAlternativeTime;
}

#endif
#if NTV_FUNCTION_ENABLE
BOOLEAN msAPI_CM_IS_NorwegianNetwork(BYTE cNetworkIndex)
{
    BYTE cIDIndex;
	DTVPROGRAMID_M *pMuxTable=_astDTVProgramIDTable;
#if DVB_T_C_DIFF_DB
	if (IsCATVInUse())pMuxTable=_astDTVCProgramIDTable;
#endif

    if(cNetworkIndex >= MAX_NETWOEK_NUMBER)
    {
        //printf("overflow max NetworkIndex\n");
        return FALSE;
    }
    for(cIDIndex=0; cIDIndex < MAX_MUX_NUMBER; cIDIndex++)
    {
        if(pMuxTable[cIDIndex].cRFChannelNumber == INVALID_PHYSICAL_CHANNEL_NUMBER)
        {
            //return FALSE;
            continue;
        }
        if((cNetworkIndex == pMuxTable[cIDIndex].cNetWorkIndex)
            &&(pMuxTable[cIDIndex].wOriginalNetwork_ID == 0x2242))
        {
            return TRUE;
        }
    }
    return FALSE;
}


//****************************************************************************
///  Get Favorite Region
/// @return Favorite Region
//****************************************************************************
BYTE msAPI_CM_Get_FavoriteNetwork(void)
{
    return _cFavoriteNetwork;
}

//****************************************************************************
///  Set Favorite Region
/// @param cNetworkIndex \b IN: Favorite Region
//****************************************************************************
void msAPI_CM_Set_FavoriteNetwork(BYTE cNetworkIndex)
{
    _cFavoriteNetwork = cNetworkIndex;
    SetNVRAM(BASEADDRESS_PR_FAVORITE_REGION, (BYTE *)&cNetworkIndex, sizeof(cNetworkIndex));
}

static void msAPI_CM_FillMove_AttributeWithDefault(MEMBER_SERVICETYPE bServiceType)
{
    WORD wProgramCount;
    WORD wPosition;
    WORD wOrder;
    WORD wPRIndex;
    CHANNEL_ATTRIBUTE stCHAttribute;

    wProgramCount = GetProgramCount(bServiceType, INCLUDE_ALL);
    for(wPosition=0; wPosition < wProgramCount; wPosition++)
    {
        wOrder = ConvertPositionToOrder(E_SERVICETYPE_DTV, wPosition);

        if( TRUE == m_astDTVProgramIndexTable[wOrder].bIsMove )
        {
            m_astDTVProgramIndexTable[wOrder].bIsMove = DEFAULT_IS_MOVED;
            wPRIndex = m_astDTVProgramIndexTable[wOrder].wPRIndex;
            GetProgramTable(wPRIndex, (BYTE *)&stCHAttribute, E_DATA_MISC);
            stCHAttribute.bIsMove = m_astDTVProgramIndexTable[wOrder].bIsMove;
            if(FALSE == SetProgramTable(wPRIndex, (BYTE *)&stCHAttribute, E_DATA_MISC))
        	{
            	__ASSERT(0);
        	}
        }
    }

}

void msAPI_CM_RestoreProgramOrder(void)
{
    msAPI_CM_FillMove_AttributeWithDefault(E_SERVICETYPE_DTV);
    msAPI_CM_FillMove_AttributeWithDefault(E_SERVICETYPE_RADIO);
#if 1//NORDIG_FUNC
    msAPI_CM_FillMove_AttributeWithDefault(E_SERVICETYPE_DATA);
#endif
    msAPI_CM_ArrangeDataManager(TRUE,FALSE);

}

static void _msAPI_CM_RestoreLCN(MEMBER_SERVICETYPE bServiceType)
{
    WORD wProgramCount;
    WORD wPosition;
    WORD wOrder;
    WORD wPRIndex;
    WORD wLCN;

    wProgramCount = GetProgramCount(bServiceType, INCLUDE_ALL);
    for(wPosition=0; wPosition < wProgramCount; wPosition++)
    {
        wOrder = ConvertPositionToOrder(bServiceType, wPosition);
        wPRIndex = m_astDTVProgramIndexTable[wOrder].wPRIndex;
        if(FALSE == GetProgramTable(wPRIndex, (BYTE *)&wLCN, E_DATA_TS_LCN))
        {
            __ASSERT(0);
        }
        m_astDTVProgramIndexTable[wOrder].wLCN = wLCN;
        if(FALSE == SetProgramTable(wPRIndex, (BYTE *)&wLCN, E_DATA_LCN))
        {
            __ASSERT(0);
        }
    }

}
void msAPI_CM_RestoreLCN(void)
{
    _msAPI_CM_RestoreLCN(E_SERVICETYPE_DTV);
    _msAPI_CM_RestoreLCN(E_SERVICETYPE_RADIO);
#if 1//NORDIG_FUNC
    _msAPI_CM_RestoreLCN(E_SERVICETYPE_DATA);
#endif
}
#endif

#if ENABLE_TARGET_REGION
void msAPI_CM_SetRegion(WORD wONID, WORD wTSID, WORD wSID, BYTE cValue)
{
    U32 i;
	DTV_CHANNEL_INFO DTVProgramData;
	DTVPROGRAMID_M *pMuxTable=_astDTVProgramIDTable;
#if DVB_T_C_DIFF_DB
	if (IsCATVInUse())pMuxTable=_astDTVCProgramIDTable;
#endif
	//printf("%s onid %x tsid %x sid %x cValue %x\n",__FUNCTION__,
	//	wONID,  wTSID,  wSID,  cValue);
	for(i=0; i< MAX_DTVPROGRAM; i++)
	{

		if(IsProgramEntityActive(m_astDTVProgramIndexTable[i].wPRIndex))
		{
			if( GetProgramTable(m_astDTVProgramIndexTable[i].wPRIndex, (BYTE *)&DTVProgramData, E_DATA_ALL) )
			{
				//printf("check onid %x tsid %x sid %x(%d) %x\n",
				//	_astDTVProgramIDTable[DTVProgramData.bIDIdex].wOriginalNetwork_ID, _astDTVProgramIDTable[DTVProgramData.bIDIdex].wTransportStream_ID
				//	, DTVProgramData.wService_ID, DTVProgramData.bIDIdex,DTVProgramData.stCHAttribute.cRegion);
				if((pMuxTable[DTVProgramData.bIDIdex].wTransportStream_ID == wTSID) &&
					(pMuxTable[DTVProgramData.bIDIdex].wOriginalNetwork_ID == wONID) &&
					((wSID==0)||(wSID==DTVProgramData.wService_ID))&&
					(((DTVProgramData.stCHAttribute.cRegion&cValue)!=cValue)||(cValue==0)))
				{
					if(cValue)
					{
						DTVProgramData.stCHAttribute.cRegion|=cValue;
					}
					else
					{
						DTVProgramData.stCHAttribute.cRegion=cValue;
					}
					SetProgramTable(m_astDTVProgramIndexTable[i].wPRIndex, (BYTE *)&DTVProgramData, E_DATA_ALL);
					//printf("onid %x tsid %x sid %x cValue %x(%x)\n",wONID,wTSID,wSID,cValue,DTVProgramData.stCHAttribute.cRegion);
				}
			}
		}
	}

/*
printf("dddddddddddddddddddddd\n");
	for(i=0; i< MAX_DTVPROGRAM; i++)
	{
		if(IsProgramEntityActive(m_astDTVProgramIndexTable[i].wPRIndex))
		{
			if( GetProgramTable(m_astDTVProgramIndexTable[i].wPRIndex, (BYTE *)&DTVProgramData, E_DATA_ALL) )
			{
				printf("tsid %x sid %x name %s index %d cRegion %x\n",_astDTVProgramIDTable[DTVProgramData.bIDIdex].wTransportStream_ID,DTVProgramData.wService_ID,
					DTVProgramData.bChannelName,DTVProgramData.bIDIdex,
					DTVProgramData.stCHAttribute.cRegion);
			}
		}
	}
	printf("xxxxxxxxxxxdddddddddddddddddddddd\n");
*/

}

#endif

BOOLEAN msAPI_CM_IS_SID_Unique_Country(void)
{
	return IS_SID_UNIQUE_COUNTRY(m_eCountry);
}

#if (ENABLE_LCN_CONFLICT)
void msAPI_CM_ResetLCNConflictParams(void)
{
    DTV_SIMPLE_SERVICE_INFO* pItem;
    memset(m_astDTVProgramIndexTable,0,sizeof(DTVPROGRAMINDEX)*MAX_DTVPROGRAM);
    while(_pDuplicateServiceList)//free old service
    {
        pItem=_pDuplicateServiceList;
        _pDuplicateServiceList=_pDuplicateServiceList->next;
        msAPI_Memory_Free(pItem,(EN_BUFFER_ID)0);
    }
}
#endif
void msAPI_CM_RemoveSameService(void)
{

    int i;
    DistinguishSameService(E_SERVICETYPE_DTV);
    RemoveSameService(E_SERVICETYPE_DTV);

    DistinguishSameService(E_SERVICETYPE_DATA);
    RemoveSameService(E_SERVICETYPE_DATA);

    DistinguishSameService(E_SERVICETYPE_RADIO);
    RemoveSameService(E_SERVICETYPE_RADIO);
    for(i=0;i<MAX_DTVPROGRAM;i++)
    {
        m_astDTVProgramIndexTable[i].eLCNAssignmentType=DEFAULT_LCN_ASSIGNMENT_TYPE;
    }

}

BOOLEAN msAPI_CM_IsAVCService(WORD wOriginalNetwork_ID, WORD wService_ID)
{
    WORD i;
    BYTE cIDIndex;
    MEMBER_SERVICETYPE bServiceType;
    WORD wPosition,wProgramCount,wOrder;
    DTVPROGRAMID_M *pMuxTable=_astDTVProgramIDTable;
#if DVB_T_C_DIFF_DB
    if (IsCATVInUse())pMuxTable=_astDTVCProgramIDTable;
#endif

    bServiceType=E_SERVICETYPE_DTV;
    wProgramCount = GetProgramCount(bServiceType, INCLUDE_ALL);
    wPosition = wProgramCount-1;
    for(i=wProgramCount; i > 0; i--)
    {
        wOrder = ConvertPositionToOrder(bServiceType, wPosition);
        cIDIndex = m_astDTVProgramIndexTable[wOrder].cIDIndex;
        if(pMuxTable[cIDIndex].wOriginalNetwork_ID==wOriginalNetwork_ID)
        {
            if(wService_ID == m_astDTVProgramIndexTable[wOrder].wService_ID)
            {

                if(m_astDTVProgramIndexTable[wOrder].bServiceTypePrio == E_SERVICETYPE_PRIORITY_HIGH
                    || m_astDTVProgramIndexTable[wOrder].bServiceTypePrio == E_SERVICETYPE_PRIORITY_MIDDLE)
                {
                    return TRUE;
                }
                return FALSE;
            }
        }
        wPosition--;
    }

    bServiceType=E_SERVICETYPE_RADIO;
    wProgramCount = GetProgramCount(bServiceType, INCLUDE_ALL);
    wPosition = wProgramCount-1;
    for(i=wProgramCount; i > 0; i--)
    {
        wOrder = ConvertPositionToOrder(bServiceType, wPosition);
        cIDIndex = m_astDTVProgramIndexTable[wOrder].cIDIndex;
        if(pMuxTable[cIDIndex].wOriginalNetwork_ID==wOriginalNetwork_ID)
        {
            if(wService_ID == m_astDTVProgramIndexTable[wOrder].wService_ID)
            {
                if(m_astDTVProgramIndexTable[wOrder].bServiceTypePrio == E_SERVICETYPE_PRIORITY_HIGH
                    || m_astDTVProgramIndexTable[wOrder].bServiceTypePrio == E_SERVICETYPE_PRIORITY_MIDDLE)
                {
                    return TRUE;
                }
                return FALSE;

            }
        }
        wPosition--;
    }

    bServiceType=E_SERVICETYPE_DATA;
    wProgramCount = GetProgramCount(bServiceType, INCLUDE_ALL);
    wPosition = wProgramCount-1;
    for(i=wProgramCount; i > 0; i--)
    {
        wOrder = ConvertPositionToOrder(bServiceType, wPosition);
        cIDIndex = m_astDTVProgramIndexTable[wOrder].cIDIndex;
        if(pMuxTable[cIDIndex].wOriginalNetwork_ID==wOriginalNetwork_ID)
        {
            if(wService_ID == m_astDTVProgramIndexTable[wOrder].wService_ID)
            {
                if(m_astDTVProgramIndexTable[wOrder].bServiceTypePrio == E_SERVICETYPE_PRIORITY_HIGH
                    || m_astDTVProgramIndexTable[wOrder].bServiceTypePrio == E_SERVICETYPE_PRIORITY_MIDDLE)
                {
                    return TRUE;
                }
                return FALSE;

            }
        }
        wPosition--;
    }
    return FALSE;
}

BOOLEAN msAPI_CM_RestLCNByRF(WORD* pServiceList, WORD wNumber, BYTE cRFNumber)
{
    WORD wPosition;
    WORD wOrder;
    WORD wProgramCount;
    MEMBER_SERVICETYPE eServiceType;
    BYTE cRFIndex;
    WORD i,j;
    BOOLEAN bRet=FALSE;
    BOOLEAN bReset;
    WORD wLCN=INVALID_LOGICAL_CHANNEL_NUMBER;

    for(i=0;i<3;i++)
    {
        if(i==0)eServiceType=E_SERVICETYPE_DTV;
        else if(i==1)eServiceType=E_SERVICETYPE_RADIO;
        else eServiceType=E_SERVICETYPE_DATA;
        wProgramCount = GetProgramCount(eServiceType, INCLUDE_ALL);
        for(wPosition=0; wPosition < wProgramCount; wPosition++)
        {
            #if ( WATCH_DOG == ENABLE )
            msAPI_Timer_ResetWDT();
            #endif
            wOrder = ConvertPositionToOrder(eServiceType, wPosition);
            if(m_astDTVProgramIndexTable[wOrder].bIsMove)
            {
                continue;
            }
            cRFIndex=msAPI_CM_GetPhysicalChannelNumber(eServiceType,wPosition);
            if(cRFIndex == cRFNumber)
            {
                GetProgramTable(m_astDTVProgramIndexTable[wOrder].wPRIndex, (BYTE *)&wLCN, E_DATA_TS_LCN);
                if(wLCN == INVALID_LOGICAL_CHANNEL_NUMBER)
                {
                    continue;
                }
                bReset=TRUE;
                for(j=0;j<wNumber;j++)
                {
                    if(pServiceList[j] == m_astDTVProgramIndexTable[wOrder].wService_ID)
                    {
                        bReset=FALSE;
                        break;
                    }
                }
                if(bReset)
                {
                    wLCN=INVALID_LOGICAL_CHANNEL_NUMBER;
                    //printf("reset sid %d lcn %d\n",m_astDTVProgramIndexTable[wOrder].wService_ID,
                    //m_astDTVProgramIndexTable[wOrder].wLCN);
                    m_astDTVProgramIndexTable[wOrder].wLCN=INVALID_LOGICAL_CHANNEL_NUMBER;
                    m_astDTVProgramIndexTable[wOrder].wSimu_LCN=INVALID_SIMULCAST_LOGICAL_CHANNEL_NUMBER;
                    SetProgramTable(m_astDTVProgramIndexTable[wOrder].wPRIndex, (BYTE *)&wLCN, E_DATA_TS_LCN);
                    bRet=TRUE;
                }
            }

        }
    }
    return bRet;
}
#if NTV_FUNCTION_ENABLE
#if ENABLE_FAVORITE_NETWORK
void msAPI_DTV_Program_Network_Info_Print(U8 u8Index)
{
       U8 i;

       printf("\r\n _cFavoriteNetwork     = %d",  _cFavoriteNetwork);
       printf("\r\n _au8CurNetworkLen     = %d",  _au8CurNetworkLen);
       printf("\r\n _au8CurNetworkName : ");

       for (i=0;i<MAX_NETWORK_NAME;i++)
         {
              if (_au8CurNetworkName[i] == 0)
                  break;

            printf("%c", _au8CurNetworkName[i]);
         }

       printf("\r\n");
       printf("\r\n _astDTVNetwork.wNetwork_ID    = %d" , _astDTVNetwork[u8Index].wNetwork_ID);
       printf("\r\n _astDTVNetwork.bNetworkName[] : ");

       for (i=0;i<MAX_NETWORK_NAME;i++)
          {
            if (_astDTVNetwork[u8Index].bNetworkName[i] == 0)
                  break;

            printf("%c", _astDTVNetwork[u8Index].bNetworkName[i]);
          }
}
#endif
#endif

BOOLEAN msAPI_CM_RemoveMux(WORD wNID, WORD *pwTS_ID,  BYTE cCountOfTS, BOOLEAN *bRemove)
{
    BYTE i,j;
    WORD dummy1;
    MEMBER_SERVICETYPE dummy2;
    DTVPROGRAMID_M *pMuxTable=_astDTVProgramIDTable;
#if DVB_T_C_DIFF_DB
    if (IsCATVInUse())pMuxTable=_astDTVCProgramIDTable;
#endif
    *bRemove=FALSE;

    for(i=0;i<MAX_MUX_NUMBER;i++)
    {
        if(pMuxTable[i].cRFChannelNumber == INVALID_PHYSICAL_CHANNEL_NUMBER
#if DVB_C_ENABLE
            && pMuxTable[i].u32Frequency == INVALID_FREQUENCY
#endif
            )
        {
            continue;
        }
        if(_astDTVNetwork[pMuxTable[i].cNetWorkIndex].wNetwork_ID== wNID)
        {
            for(j=0;j<cCountOfTS;j++)
            {
                if(pwTS_ID[j] == pMuxTable[i].wTransportStream_ID)
                {
                    break;
                }
            }
            if(j>=cCountOfTS)
            {
                *bRemove=TRUE;
                RemoveMismatchedProgram(E_SERVICETYPE_DTV,i, 0, 0, &dummy1, &dummy2, 0);
                FillProgramIDWithDefault(&pMuxTable[i]);
                SetIDTable(i, (BYTE *)&pMuxTable[i], E_DATA_ID_TABLE);
                ActiveIDEntity(i,FALSE);


        }
        }
        }
    return TRUE;
}

BOOLEAN msAPI_CM_GetServiceIndex(WORD wOriginalNetwork_ID, WORD wTS_ID, WORD wService_ID, U32* pU32Index)
{
    WORD i;
    BYTE cIDIndex;
    MEMBER_SERVICETYPE bServiceType=E_SERVICETYPE_INVALID;
    WORD wPosition,wProgramCount,wOrder;
    DTVPROGRAMID_M *pMuxTable=_astDTVProgramIDTable;
    U32 u32Index=0;
#if DVB_T_C_DIFF_DB
    if (IsCATVInUse())pMuxTable=_astDTVCProgramIDTable;
#endif

    for(i=0;i<3;i++)
    {
        if(i == 0)
        {
            bServiceType=E_SERVICETYPE_DTV;
        }
        else if(i == 1)
        {
            bServiceType=E_SERVICETYPE_RADIO;
        }
        else if(i == 2)
        {
            bServiceType=E_SERVICETYPE_DATA;
        }
        wProgramCount = GetProgramCount(bServiceType, INCLUDE_ALL);
        for(wPosition=0; wPosition < wProgramCount; wPosition++)
        {
            wOrder = ConvertPositionToOrder(bServiceType, wPosition);
            cIDIndex = m_astDTVProgramIndexTable[wOrder].cIDIndex;
            if(!((m_astDTVProgramIndexTable[wOrder].bUnconfirmedService == TRUE)
                || (m_astDTVProgramIndexTable[wOrder].bIsDelete == TRUE)
                || (m_astDTVProgramIndexTable[wOrder].bInvalidService == TRUE)))
            {
                if(pMuxTable[cIDIndex].wOriginalNetwork_ID == wOriginalNetwork_ID)
                {
                    if((wTS_ID == INVALID_TS_ID) || (pMuxTable[cIDIndex].wTransportStream_ID == wTS_ID))
                    {
                        if(wService_ID == m_astDTVProgramIndexTable[wOrder].wService_ID)
                        {
                            *pU32Index=u32Index;
                            return TRUE;
                        }
                    }
                }
                u32Index++;
            }

        }
    }
    return FALSE;
}



static BOOLEAN _RemoveService(U8 cIDIndex, WORD wService_ID)
{
    WORD i;
    WORD wPosition,wProgramCount,wOrder;


    wProgramCount = GetProgramCount(E_SERVICETYPE_DTV, INCLUDE_ALL);
    wPosition = wProgramCount-1;
    for(i=wProgramCount; i > 0; i--)
    {
        wOrder = ConvertPositionToOrder(E_SERVICETYPE_DTV, wPosition);
        if(m_astDTVProgramIndexTable[wOrder].cIDIndex == cIDIndex)
        {
            if(m_astDTVProgramIndexTable[wOrder].wService_ID == wService_ID)
            {
                RemoveProgram(E_SERVICETYPE_DTV,wPosition);
                if((m_eCurrentServiceType == E_SERVICETYPE_DTV)
                    && (wPosition == msAPI_CM_GetCurrentPosition(m_eCurrentServiceType)))
                {
                    return TRUE;
                }
                return FALSE;
            }
        }
        wPosition--;
    }
    wProgramCount = GetProgramCount(E_SERVICETYPE_RADIO, INCLUDE_ALL);
    wPosition = wProgramCount-1;
    for(i=wProgramCount; i > 0; i--)
    {
        wOrder = ConvertPositionToOrder(E_SERVICETYPE_RADIO, wPosition);
        if(m_astDTVProgramIndexTable[wOrder].cIDIndex == cIDIndex)
        {
            if(m_astDTVProgramIndexTable[wOrder].wService_ID == wService_ID)
            {
                RemoveProgram(E_SERVICETYPE_RADIO,wPosition);
                if((m_eCurrentServiceType == E_SERVICETYPE_RADIO)
                    && (wPosition == msAPI_CM_GetCurrentPosition(m_eCurrentServiceType)))
                {
                    return TRUE;
                }
                return FALSE;

            }
        }
        wPosition--;
    }
    wProgramCount = GetProgramCount(E_SERVICETYPE_DATA, INCLUDE_ALL);
    wPosition = wProgramCount-1;
    for(i=wProgramCount; i > 0; i--)
    {
        wOrder = ConvertPositionToOrder(E_SERVICETYPE_DATA, wPosition);
        if(m_astDTVProgramIndexTable[wOrder].cIDIndex == cIDIndex)
        {
            if(m_astDTVProgramIndexTable[wOrder].wService_ID == wService_ID)
            {
                RemoveProgram(E_SERVICETYPE_DATA,wPosition);
                if((m_eCurrentServiceType == E_SERVICETYPE_DATA)
                    && (wPosition == msAPI_CM_GetCurrentPosition(m_eCurrentServiceType)))
                {
                    return TRUE;
                }
                return FALSE;

            }
        }
        wPosition--;
    }
    return FALSE;

}

#if ENABLE_DVB_T2
BOOLEAN msAPI_CM_DVBT2_RemoveMux(BYTE cRFChannelNumber, BYTE *pu8PlpIDList,  BYTE cCountOfPlpID)
{
    BYTE i,j;
    WORD dummy1;
    MEMBER_SERVICETYPE dummy2;
	DTVPROGRAMID_M *pMuxTable=_astDTVProgramIDTable;
	U8 u8ServiceCount=MApp_SI_GetScanNumOfPatItem();

    for(i=0;i<MAX_MUX_NUMBER;i++)
    {
        if(pMuxTable[i].cRFChannelNumber == cRFChannelNumber)
        {
            for(j=0;j<cCountOfPlpID;j++)
            {
                if(pu8PlpIDList[j] == pMuxTable[i].cPLPID)
                {
                    break;
                }
            }
            if(j>=cCountOfPlpID && j!=0)
            {
			RemoveMismatchedProgram(E_SERVICETYPE_DTV,cRFChannelNumber, pMuxTable[i].cPLPID, pMuxTable[i].cHpLp, &dummy1, &dummy2, u8ServiceCount);
			RemoveMismatchedProgram(E_SERVICETYPE_RADIO,cRFChannelNumber, pMuxTable[i].cPLPID, pMuxTable[i].cHpLp, &dummy1, &dummy2, u8ServiceCount);
			RemoveMismatchedProgram(E_SERVICETYPE_DATA,cRFChannelNumber, pMuxTable[i].cPLPID, pMuxTable[i].cHpLp, &dummy1, &dummy2, u8ServiceCount);
            }
        }
    }
	memset(u8PlpIDList,INVALID_PLPID,32);
    return TRUE;
}
#endif

#undef API_DTVSYSTEM_C

