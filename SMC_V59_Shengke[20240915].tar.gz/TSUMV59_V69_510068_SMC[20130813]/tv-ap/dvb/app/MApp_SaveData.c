////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#define MAPP_SAVEDATA_C

/******************************************************************************/
/*                            Header Files                                    */
/******************************************************************************/

#include <string.h>
#include "msAPI_MIU.h"
#include "msAPI_Flash.h"
#include "msAPI_Ram.h"
#include "msAPI_Timer.h"

#include "MApp_ChannelList.h"
#include "MApp_Scaler.h"
#include "apiXC.h"
#include "apiXC_Adc.h"
#include "apiXC_Sys.h"
#include "apiXC_ModeParse.h"
#include "apiXC_Cus.h"
#include "msAPI_DTVSystem.h"

#include "MApp_GlobalSettingSt.h"
#include "MApp_GlobalVar.h"
#include "MApp_GlobalFunction.h"
#include "MApp_RestoreToDefault.h"
#include "MApp_SaveData.h"
#include "MApp_DataBase.h"
#include "MApp_IR.h"
#include "MApp_PCMode.h"
#include "MApp_EpgTimer.h"
#include "GPIO.h"
#include "MApp_ATVProc.h"
#if ENABLE_CI
#include "msAPI_CI.h"
#endif
#include "debug.h"

#include "MsOS.h"

#if (OBA2)
#include "p_misc.h"
#include "MApp_ZUI_APIcommon.h"
#include "ZUI_tables_h.inl"
#include "MApp_ZUI_ACTmenufunc.h"
#endif

#if (ENABLE_SZ_FACTORY_OVER_SCAN_FUNCTION)
#include"MApp_MVDMode.h"
#include"msAPI_Video.h"
#include"msAPI_VD.h"
#include"drvXC_HDMI_if.h"
#endif

//#define EEPROM_DEBUG 1
#ifdef EEPROM_DEBUG
    #define EE_PUTSTR(str)          printf(str)
    #define EE_PRINTF(str,val)      printf(str,val)
    #define EE_VALIDATE(x)          x
    #define EE_LOAD(x)              x
#else
    #define EE_PUTSTR(str)
    #define EE_PRINTF(str,val)
    #define EE_VALIDATE(x)
    #define EE_LOAD(x)
#endif

//********************************************************************************
//                     Macro
//********************************************************************************
#define DATA_SAVE_PERIOD    ( (U16)1000)
typedef enum
{
    STATE_DATA_SAVE_INIT,
    STATE_DATA_SAVE_VIDEO,
    STATE_DATA_SAVE_WHITEBALANCE,
    STATE_DATA_SAVE_AUDIO,
    STATE_DATA_SAVE_TIME,

    STATE_DATA_SAVE_LOCK,
    STATE_DATA_SAVE_SYSTEM,
    STATE_DATA_SAVE_MODETABLE,
    STATE_DATA_SAVE_SCANMENU,
#if ENABLE_DRM
    STATE_DATA_SAVE_DRM,
#endif
#ifdef ENABLE_BT
    STATE_DATA_SAVE_BT,
#endif
#if (ENABLE_PIP)
    STATE_DATA_SAVE_PIP,
#endif
#if (ENABLE_UPDATE_MULTIPLEX_VIA_NIT)
    STATE_DATA_SAVE_NETWORK,
#endif
#if (ENABLE_CI && ENABLE_CI_PLUS)
    STATE_DATA_SAVE_CI,
#endif
#if (ENABLE_LAST_MEMORY==1)&&(ENABLE_LAST_MEMORY_STORAGE_SAVE==1)
    STATE_DATA_SAVE_MM_LASTMEMORY,
#endif
    STATE_DATA_SAVE_NUM,
}E_DATA_SAVE_STATE;

/******************************************************************************/
/*                            Local variable                                 */
/******************************************************************************/

//U8 randTimeText[] = {__TIME__};

/******************************************************************************/
/*                                 Local                                        */
/******************************************************************************/

WORD checkSum;
static U32 su32DataSavePeriod = 0;
static E_DATA_SAVE_STATE eDataSaveState = STATE_DATA_SAVE_INIT;
static BOOLEAN sbPcModeSaveFlag = FALSE;
static U8 u8SaveDataFlag=0;


void MApp_ReadDatabase(U32 srcIndex, U8* dstAddr, U16 size)
{
    if(srcIndex<RM_GEN_USAGE)
    {
        #if (EEPROM_DB_STORAGE==EEPROM_SAVE_NONE)
        memcpy(dstAddr,(void *)_PA2VA(srcIndex+DRAM_GEN_DB_START(((DATABASE_START_MEMORY_TYPE & MIU1) ? (DATABASE_START_ADR | MIU_INTERVAL) : (DATABASE_START_ADR)))),size);
        #else
        msAPI_rmBurstReadBytes(srcIndex, dstAddr, size);
        #endif
    }
    else if(srcIndex>=RM_GEN_USAGE && srcIndex<(RM_64K_SIZE+RM_GEN_USAGE))
    {
        #if (EEPROM_DB_STORAGE==EEPROM_SAVE_ALL)
        msAPI_rmBurstReadBytes(srcIndex, dstAddr, size);
        #else
        memcpy(dstAddr,(void *)_PA2VA(srcIndex-RM_GEN_USAGE+DRAM_64K_DB_START(((DATABASE_START_MEMORY_TYPE & MIU1) ? (DATABASE_START_ADR | MIU_INTERVAL) : (DATABASE_START_ADR)))),size);
        #endif
    }
    else
    {
        __ASSERT(0);//printf("\n MApp_ReadDatabase index overflow...!!!");
    }

}


void MApp_WriteDatabase(U32 dstIndex, U8* srcAddr, U16 size)
{
    if( dstIndex<RM_GEN_USAGE)
    {
        #if (EEPROM_DB_STORAGE==EEPROM_SAVE_NONE)
        memcpy((void *)_PA2VA(dstIndex+DRAM_GEN_DB_START(((DATABASE_START_MEMORY_TYPE & MIU1) ? (DATABASE_START_ADR | MIU_INTERVAL) : (DATABASE_START_ADR)))),srcAddr,size);
        g_u8QuickDataBase |= QUICK_DB_GENST_MODIFIED;
        #else
        msAPI_rmBurstWriteBytes(dstIndex, srcAddr, size);
        #endif
    }
    else if(dstIndex>=RM_GEN_USAGE && dstIndex<(RM_64K_SIZE+RM_GEN_USAGE))
    {
        #if (EEPROM_DB_STORAGE==EEPROM_SAVE_ALL)
        msAPI_rmBurstWriteBytes(dstIndex, srcAddr, size);
        #else
        memcpy((void *)_PA2VA(dstIndex-RM_GEN_USAGE+DRAM_64K_DB_START(((DATABASE_START_MEMORY_TYPE & MIU1) ? (DATABASE_START_ADR | MIU_INTERVAL) : (DATABASE_START_ADR)))),srcAddr, size);
        g_u8QuickDataBase |= QUICK_DB_UPDATE;
        #endif
    }
    else
    {
        __ASSERT(0);//printf("\n MApp_WriteDatabase index overflow...!!!");
    }

}


//*************************************************************************
//Function name:
//Passing parameter:
//Return parameter:
//Description:
//*************************************************************************
U16 MApp_CalCheckSum( BYTE *pBuf, U16 ucBufLen )
{
    U16 CheckSum;

    CheckSum = 0;

    while( ucBufLen > sizeof(CheckSum) )//calculate pBuf[2]~pBuf[End] do not count pBuf[0] pBuf[1],it is checksum
    {
        -- ucBufLen;
        CheckSum += pBuf[ucBufLen];
    }

    //ask to mstar
    return (CheckSum+0x55);
}

#if (EEPROM_DB_STORAGE != EEPROM_SAVE_NONE)
void MApp_CheckEEPROM(void)
{
    BYTE ucTmp;
    BYTE bInitEEPROM = FALSE;  // if eeprom test error init variable by default

    // if you want erase database, change database version which is defined in MApp_RestoreToDefault.h
    ucTmp = msAPI_rmReadByte(RM_EEPROM_ID_ADDRESS);

    // Check EEPROM ...
    if (ucTmp != USR_EEPROM_ID/*+randTimeText[7]*/) // check EEPROM ID
    {
        EE_PUTSTR("\r\nEEPROM ID Invalid!");
        bInitEEPROM = TRUE;
    }
    else // general
    {
        EE_PUTSTR("\r\nEEPROM ID OK! ");
    }

    //bInitEEPROM = TRUE;
    if( bInitEEPROM ) // EEPROM need init
    {
        msAPI_rmWriteByte(RM_EEPROM_ID_ADDRESS, USR_EEPROM_ID); // reset EEPROM ID

        MApp_InitGenSetting(); // initialize general setting   

        #if (EEPROM_DB_STORAGE == EEPROM_SAVE_ALL)
        #if (ENABLE_DTV)
        msAPI_CM_ResetDTVDataManager();
        #endif
        msAPI_ATV_ResetATVDataManager();
        MApp_DB_ResetGenSettingExt();
        #endif

        EE_PUTSTR("\r\nEEPROM reloaded!");
    }
    else
    {	
		MApp_LoadGenSetting(); // load general setting   

        #if (EEPROM_DB_STORAGE == EEPROM_SAVE_ALL)
#if (ENABLE_DTV == 1)
        msAPI_CM_InitDTVDataManager();
#endif     
        //msAPI_ATV_InitATVDataManager();
        #endif
		MApp_DB_LoadGenSettingExt();
    }
}
#endif

#if (EEPROM_DB_STORAGE!=EEPROM_SAVE_ALL)
void MApp_CheckFlash(void)
{
  #if (EEPROM_DB_STORAGE == EEPROM_SAVE_NONE)
    msAPI_Flash_CheckFlash();
    if(g_u16QuickGenSettingIdx == 1)
    {
        g_u8EraseGenSettingBank = ERASE_BANK0;
    }
  #endif

    MApp_DB_LoadChDataBase();

    g_u8QuickDataBase = QUICK_DB_READY | QUICK_DB_GENST_READY;
}
#endif


void MApp_InitGenSetting(void)
{
    MApp_DataBase_RestoreDefaultValue(RESTORE_KEEP_NONE);

    MApp_SaveGenSetting();
}

void MApp_LoadGenSetting(void)
{
    EE_VALIDATE(U32 StartTime = msAPI_Timer_GetTime0());

    MApp_ReadDatabase(RM_GENSET_START_ADR, (BYTE *)&stGenSetting, RM_SIZE_GENSET);

    MApp_CheckSysSetting();

    MApp_CheckSoundSetting();

    MApp_CheckScanMenuSetting();

    MApp_CheckTimeData();

    MApp_CheckBlockData();

  #if ENABLE_SSC
    MApp_CheckSSCData();
  #endif

  #if (ENABLE_NONLINEAR_CURVE)
    MApp_CheckNonLinearCurveSetting();
  #endif

    MApp_CheckFactorySetting();

  #if ENABLE_DRM
    MApp_CheckDrmSetting();
  #endif

  #ifdef ENABLE_BT
    MApp_CheckBtSetting();
  #endif

  #if (ENABLE_PIP)
    if(IsPIPDBCheck())
    {
        MApp_CheckPipSetting();
    }
  #endif

  #if (ENABLE_UPDATE_MULTIPLEX_VIA_NIT)
    MApp_CheckNetworkInfoSetting();
  #endif

  #if (ENABLE_LAST_MEMORY==1)&&(ENABLE_LAST_MEMORY_STORAGE_SAVE==1)
    MApp_CheckMmLastMemorySetting();
  #endif

    EE_VALIDATE(printf("Reload Period: %Lu ms\n", msAPI_Timer_DiffTimeFromNow(StartTime)));
}

void MApp_SaveGenSetting(void)
{
	stGenSetting.g_SysSetting.SystemSettingCS =
    MApp_CalCheckSum((BYTE *)&(stGenSetting.g_SysSetting), SIZE_SYS_SETTING );

    stGenSetting.g_SoundSetting.soundSettingCS =
    MApp_CalCheckSum((BYTE *)&(stGenSetting.g_SoundSetting), SIZE_SOUND_SETTING );

    stGenSetting.g_Time.wTimeDataCS =
    MApp_CalCheckSum((BYTE *)&(stGenSetting.g_Time), SIZE_TIME_DATA  );

    stGenSetting.stScanMenuSetting.ScanSettingCS=
    MApp_CalCheckSum((BYTE *)&(stGenSetting.stScanMenuSetting), SIZE_SCANMENU_SETTING );

    stGenSetting.g_BlockSysSetting.vchipSettingCS =
    MApp_CalCheckSum((BYTE *)&(stGenSetting.g_BlockSysSetting), SIZE_BLOCK_DATA);

#if (ENABLE_SSC)
    stGenSetting.g_SSCSetting.SscSettingCS =
    MApp_CalCheckSum((BYTE *)&(stGenSetting.g_SSCSetting), SIZE_SSC_DATA );
#endif

#if (ENABLE_NONLINEAR_CURVE)
    stGenSetting.g_NonLinearCurveSetting.NonLinearCurveSettingCS =
    MApp_CalCheckSum((BYTE *)&(stGenSetting.g_NonLinearCurveSetting), SIZE_NONLINER_CURVE_SETTING);
#endif

    stGenSetting.g_FactorySetting.FactorySettignCS =
    MApp_CalCheckSum((BYTE *)&(stGenSetting.g_FactorySetting), SIZE_FACTORY_SETTING_DATA);
#if ENABLE_CUS_UI_SPEC
    stGenSetting.g_VChipSetting.vchipSettingCS=
    MApp_CalCheckSum((BYTE *)&(stGenSetting.g_VChipSetting), SIZE_VCHIP_SETTING_DATA);
#endif

#ifdef ENABLE_BT
    stGenSetting.TorrentSetupInfo.TorrentSetupInfoCS =
    MApp_CalCheckSum((BYTE *)&(stGenSetting.TorrentSetupInfo), SIZE_BT_DATA);
#endif

#if (ENABLE_PIP)
    stGenSetting.g_stPipSetting.PIPSetupInfoCS =
    MApp_CalCheckSum((BYTE *)&(stGenSetting.g_stPipSetting), SIZE_PIP_DATA );
#endif

#if (ENABLE_UPDATE_MULTIPLEX_VIA_NIT)
    stGenSetting.g_Network_TS.NetWorkInfoCS =
    MApp_CalCheckSum((BYTE *)&(stGenSetting.g_Network_TS), SIZE_NETWORK_INFO_DATA );
#endif

#if ENABLE_DRM
    stGenSetting.g_VDplayerDRMInfo.VDplayerDRMInfoCS =
    MApp_CalCheckSum((BYTE *)&(stGenSetting.g_VDplayerDRMInfo), SIZE_DRM_DATA );
#endif

    MApp_WriteDatabase(RM_GENSET_START_ADR, (BYTE *)&stGenSetting, RM_SIZE_GENSET);

    EE_PUTSTR("\r\nEEPROM saved!");
}

static void MApp_SaveGenUserSetting(void)
{
	stGenSetting.g_SysSetting.SystemSettingCS =
        MApp_CalCheckSum((BYTE *)&(stGenSetting.g_SysSetting), SIZE_SYS_SETTING );
	stGenSetting.g_SoundSetting.soundSettingCS =
        MApp_CalCheckSum((BYTE *)&(stGenSetting.g_SoundSetting), SIZE_SOUND_SETTING );

    MApp_WriteDatabase(RM_GENSET_START_ADR, (BYTE *)&stGenSetting, RM_SIZE_GENSET);

    EE_PUTSTR("\r\nEEPROM saved!");
}

void MApp_ResetGenUserSetting(void)
{
    MApp_DataBase_RestoreUserSettingDefaultValue(RESTORE_KEEP_SYSTEM_PASSWORD);
    MApp_SaveGenUserSetting();
}

#if ENABLE_DRM
void MApp_InitDrmSetting(void)
{

    MApp_Drm_RestoreDefaultSetupInfo();

    MApp_SaveDrmSetting();
}

void MApp_CheckDrmSetting(void)
{
    checkSum = MApp_CalCheckSum((BYTE *)&(stGenSetting.g_VDplayerDRMInfo), SIZE_DRM_DATA);

    if( stGenSetting.g_VDplayerDRMInfo.VDplayerDRMInfoCS != checkSum )
    {
        MApp_InitDrmSetting();
        EE_LOAD(printf("MApp_InitDrmSetting!\n"));
    }
}

void MApp_LoadDrmSetting(void)
{
    MApp_ReadDatabase(RM_DRM_DATA_ADDRESS, (BYTE *)&(stGenSetting.g_VDplayerDRMInfo), SIZE_DRM_DATA);
    checkSum = MApp_CalCheckSum((BYTE *)&(stGenSetting.g_VDplayerDRMInfo), SIZE_DRM_DATA );
    if( stGenSetting.g_VDplayerDRMInfo.VDplayerDRMInfoCS != checkSum )
    {
        MApp_InitDrmSetting();
        EE_LOAD(printf("MApp_InitDrmSetting!\n"));
    }
}

void MApp_SaveDrmSetting(void)
{
    stGenSetting.g_VDplayerDRMInfo.VDplayerDRMInfoCS = MApp_CalCheckSum((BYTE *)&(stGenSetting.g_VDplayerDRMInfo), SIZE_DRM_DATA );
    MApp_WriteDatabase(RM_DRM_DATA_ADDRESS, (BYTE *)&(stGenSetting.g_VDplayerDRMInfo), SIZE_DRM_DATA);
    EE_PUTSTR("\n MApp_SaveDrmSetting!\n");
}
#endif

#ifdef ENABLE_BT
void MApp_InitBtSetting(void)
{

    MApp_BT_RestoreDefaultTorrentSetupInfo();

    MApp_SaveBtSetting();
}

void MApp_CheckBtSetting(void)
{
    checkSum = MApp_CalCheckSum((BYTE *)&(stGenSetting.TorrentSetupInfo), SIZE_BT_DATA);

    if( stGenSetting.TorrentSetupInfo.TorrentSetupInfoCS != checkSum )
    {
        MApp_InitBtSetting();
        EE_LOAD(printf("MApp_InitBtSetting!\n"));
    }
}

void MApp_LoadBtSetting(void)
{
    MApp_ReadDatabase(RM_BT_DATA_ADDRESS, (BYTE *)&(stGenSetting.TorrentSetupInfo), SIZE_BT_DATA);
    checkSum = MApp_CalCheckSum((BYTE *)&(stGenSetting.TorrentSetupInfo), SIZE_BT_DATA );
    if( stGenSetting.TorrentSetupInfo.TorrentSetupInfoCS != checkSum )
    {
        MApp_InitBtSetting();
        EE_LOAD(printf("MApp_InitBtSetting!\n"));
    }
}

void MApp_SaveBtSetting(void)
{
    stGenSetting.TorrentSetupInfo.TorrentSetupInfoCS = MApp_CalCheckSum((BYTE *)&(stGenSetting.TorrentSetupInfo), SIZE_BT_DATA );
    MApp_WriteDatabase(RM_BT_DATA_ADDRESS, (BYTE *)&(stGenSetting.TorrentSetupInfo), SIZE_BT_DATA);
    EE_PUTSTR("\n MApp_SaveBtSetting!\n");
}
#endif
#if (ENABLE_PIP)
void MApp_InitPipSetting(void)
{
    if(IsPIPDBCheck())
    {
        MApp_DataBase_RestoreDefaultPIP();
        MApp_SavePipSetting();
    }
}

void MApp_CheckPipSetting(void)
{
    if(IsPIPDBCheck())
    {
        checkSum = MApp_CalCheckSum((BYTE *)&(stGenSetting.g_stPipSetting), SIZE_PIP_DATA);

        if( stGenSetting.g_stPipSetting.PIPSetupInfoCS != checkSum )
        {
            MApp_InitPipSetting();
            EE_LOAD(printf("MApp_InitPipSetting!\n"));
        }
    }
}

void MApp_LoadPipSetting(void)
{
    if(IsPIPDBCheck())
    {
        MApp_ReadDatabase(RM_PIP_DATA_ADDRESS, (BYTE *)&(stGenSetting.g_stPipSetting), SIZE_PIP_DATA);
        checkSum = MApp_CalCheckSum((BYTE *)&(stGenSetting.g_stPipSetting), SIZE_PIP_DATA );
        if( stGenSetting.g_stPipSetting.PIPSetupInfoCS != checkSum )
        {
            MApp_InitPipSetting();
            EE_LOAD(printf("MApp_InitPipSetting!\n"));
        }
    }
}

void MApp_SavePipSetting(void)
{
    if(IsPIPDBCheck())
    {
        stGenSetting.g_stPipSetting.PIPSetupInfoCS = MApp_CalCheckSum((BYTE *)&(stGenSetting.g_stPipSetting), SIZE_PIP_DATA );
        MApp_WriteDatabase(RM_PIP_DATA_ADDRESS, (BYTE *)&(stGenSetting.g_stPipSetting), SIZE_PIP_DATA);
        EE_PUTSTR("\n MApp_SavePipSetting!\n");
    }
}
#endif
void MApp_InitSysSetting(void)
{
    SET_OSD_MENU_LANGUAGE(LANGUAGE_ENGLISH); // menu language
    #if (OBA2)
    MApp_ZUI_ACT_SetEnvLanguage(LANGUAGE_ENGLISH);
    #endif
    //SET_VCOM_VAULE(220);
    MApp_DataBase_RestoreDefaultSystem(RESTORE_KEEP_NONE);

    MApp_SaveSysSetting();
}

void MApp_CheckSysSetting(void)
{
    //msAPI_rmBurstReadBytes(RM_SYS_SETTING_ADDRESS, (BYTE *)&(stGenSetting.g_SysSetting), SIZE_SYS_SETTING);
    checkSum = MApp_CalCheckSum((BYTE *)&(stGenSetting.g_SysSetting), SIZE_SYS_SETTING );
    if( stGenSetting.g_SysSetting.SystemSettingCS != checkSum )
    {
        MApp_InitSysSetting();
        EE_LOAD(printf("MApp_InitSysSetting!\n"));
    }
}

void MApp_LoadSysSetting(void)
{
    MApp_ReadDatabase(RM_SYS_SETTING_ADDRESS, (BYTE *)&(stGenSetting.g_SysSetting), SIZE_SYS_SETTING);
    checkSum = MApp_CalCheckSum((BYTE *)&(stGenSetting.g_SysSetting), SIZE_SYS_SETTING );
    if( stGenSetting.g_SysSetting.SystemSettingCS != checkSum )
    {
        MApp_InitSysSetting();
        EE_LOAD(printf("MApp_InitSysSetting!\n"));
    }
}


void MApp_SaveSysSetting(void)
{
    stGenSetting.g_SysSetting.SystemSettingCS = MApp_CalCheckSum((BYTE *)&(stGenSetting.g_SysSetting), SIZE_SYS_SETTING );
    MApp_WriteDatabase(RM_SYS_SETTING_ADDRESS, (BYTE *)&(stGenSetting.g_SysSetting), SIZE_SYS_SETTING);
    EE_PUTSTR("\n MApp_SaveSysSetting!\n");
}

#if (ENABLE_UPDATE_MULTIPLEX_VIA_NIT)
void MApp_InitNetworkInfoSetting(void)
{
    MApp_DataBase_RestoreDefaultNetworkInfo();

    MApp_SaveNetworkInfoSetting();
}
void MApp_CheckNetworkInfoSetting(void)
{
    checkSum = MApp_CalCheckSum((BYTE *)&(stGenSetting.g_Network_TS), SIZE_NETWORK_INFO_DATA);

    if( stGenSetting.g_Network_TS.NetWorkInfoCS != checkSum )
    {
        MApp_InitNetworkInfoSetting();
        EE_LOAD(printf("MApp_CheckNetworkInfoSetting!\n"));
    }
}
void MApp_LoadNetworkInfoSetting(void)
{
    MApp_ReadDatabase(RM_NETWORK_INFO_DATA_ADDRESS, (BYTE *)&(stGenSetting.g_Network_TS), SIZE_NETWORK_INFO_DATA);
    checkSum = MApp_CalCheckSum((BYTE *)&(stGenSetting.g_Network_TS), SIZE_NETWORK_INFO_DATA );
    if( stGenSetting.g_Network_TS.NetWorkInfoCS != checkSum )
    {
        MApp_InitNetworkInfoSetting();
        EE_LOAD(printf("MApp_InitNetworkInfo!\n"));
    }

}
void MApp_SaveNetworkInfoSetting(void)
{
    stGenSetting.g_Network_TS.NetWorkInfoCS = MApp_CalCheckSum((BYTE *)&(stGenSetting.g_Network_TS), SIZE_NETWORK_INFO_DATA );
    MApp_WriteDatabase(RM_NETWORK_INFO_DATA_ADDRESS, (BYTE *)&stGenSetting.g_Network_TS,SIZE_NETWORK_INFO_DATA);
    EE_PUTSTR("\n MApp_SaveNetworkInfoSetting!\n");
}

MS_NETWORKID_TS* MApp_GetNetworkInfo(U8 u8NetworkIndex)
{
    return &stGenSetting.g_Network_TS.astNetworkInfo[u8NetworkIndex];
}
#endif

#if (ENABLE_CI && ENABLE_CI_PLUS)
void MApp_InitCISetting(void)
{
    MApp_DataBase_RestoreDefaultCI();

    MApp_SaveCISetting();
}

void MApp_CheckCISetting(void)
{
    checkSum = MApp_CalCheckSum((BYTE *)&(stGenSetting.g_CIKeySetting), (BYTE)(SIZE_CI_DATA-sizeof(checkSum)));

    if( stGenSetting.g_CIKeySetting.CIKeyCS != checkSum )
    {
        MApp_InitCISetting();
        EE_LOAD(printf("MApp_CheckCISetting!\n"));
    }
}

void MApp_LoadCISetting(void)
{
    MApp_ReadDatabase(RM_CI_DATA_ADDRESS, (BYTE *)&(stGenSetting.g_CIKeySetting), SIZE_CI_DATA);
    checkSum = MApp_CalCheckSum((BYTE *)&(stGenSetting.g_CIKeySetting), (BYTE)(SIZE_CI_DATA - sizeof(checkSum)));
    if( stGenSetting.g_CIKeySetting.CIKeyCS != checkSum )
    {
        MApp_InitCISetting();
        EE_LOAD(printf("MApp_InitCI!\n"));
    }
}

void MApp_SaveCISetting(void)
{
    stGenSetting.g_CIKeySetting.CIKeyCS = MApp_CalCheckSum((BYTE *)&(stGenSetting.g_CIKeySetting), (BYTE)(SIZE_CI_DATA-sizeof(checkSum)) );
    MApp_WriteDatabase(RM_CI_DATA_ADDRESS, (BYTE *)&stGenSetting.g_CIKeySetting,SIZE_CI_DATA);
    EE_PUTSTR("\n MApp_SaveCISetting!\n");
}
#endif

//=============================================================================================
void MApp_InitADCSetting(E_ADC_SET_INDEX eAdcIndex )
{
    MApp_DataBase_RestoreDefaultADC(eAdcIndex);
	
    MApp_SaveADCSetting(eAdcIndex);
}

void MApp_LoadADCSetting(E_ADC_SET_INDEX eAdcIndex )
{
    MApp_ReadDatabase(RM_ADC_SETTING_ADDRESS(eAdcIndex), (BYTE *)&(stGenSettingExt.g_AdcSetting[eAdcIndex] ), SIZE_ADC_SETTING);
    checkSum = MApp_CalCheckSum((BYTE *)&(stGenSettingExt.g_AdcSetting[eAdcIndex]), SIZE_ADC_SETTING );
    if( stGenSettingExt.g_AdcSetting[eAdcIndex].u16ADCDataCS != checkSum )
    {
        MApp_InitADCSetting((E_ADC_SET_INDEX) eAdcIndex);
        EE_LOAD(printf("MApp_InitADCSetting(%bu)!\n", eAdcIndex));
    }
}

void MApp_CheckADCSetting(void)
{
    BYTE i;

    for( i = 0; i < ADC_SET_NUMS; i++ )
    {
        //msAPI_rmBurstReadBytes(RM_ADC_SETTING_ADDRESS + (SIZE_ADC_SETTING * i ), (BYTE *)&(stGenSettingExt.g_AdcSetting[i]), SIZE_ADC_SETTING);
        checkSum = MApp_CalCheckSum((BYTE *)&(stGenSettingExt.g_AdcSetting[i]), SIZE_ADC_SETTING );
        if( stGenSettingExt.g_AdcSetting[i].u16ADCDataCS != checkSum )
        {
            MApp_InitADCSetting( (E_ADC_SET_INDEX) i);
            EE_LOAD(printf("MApp_InitADCSetting(%bu)!\n", i));
            printf("MApp_InitADCSetting(%bu)!\n", i);
        }
    }
}

void MApp_SaveADCSetting(E_ADC_SET_INDEX eAdcIndex )
{
#if (EEPROM_DB_STORAGE!=EEPROM_SAVE_ALL)
    U8 u8QuickDBFlag = g_u8QuickDataBase;
#endif
    stGenSettingExt.g_AdcSetting[eAdcIndex].u16ADCDataCS = MApp_CalCheckSum((BYTE *)&(stGenSettingExt.g_AdcSetting[eAdcIndex]), SIZE_ADC_SETTING );
    MApp_WriteDatabase(RM_ADC_SETTING_ADDRESS(eAdcIndex), (BYTE *)&(stGenSettingExt.g_AdcSetting[eAdcIndex]), SIZE_ADC_SETTING);
#if (EEPROM_DB_STORAGE!=EEPROM_SAVE_ALL)
    if (u8QuickDBFlag & QUICK_DB_UPDATE)
        g_u8QuickDataBase = g_u8QuickDataBase | QUICK_DB_GENSTEXT_MODIFIED;
    else
        g_u8QuickDataBase = (g_u8QuickDataBase & ~QUICK_DB_UPDATE) | QUICK_DB_GENSTEXT_MODIFIED;
#endif
    EE_PUTSTR("\n MApp_SaveADCSetting!\n");
}

//=============================================================================================

void MApp_InitVideoSetting(E_DATA_INPUT_SOURCE enDataInputSource)
{
		
	MApp_DataBase_RestoreDefaultVideo(enDataInputSource);

    MApp_SaveVideoSetting(enDataInputSource);
}

void MApp_LoadVideoSetting(E_DATA_INPUT_SOURCE enDataInputSource)
{
	MApp_ReadDatabase(RM_VIDEO_DATA_ADDRESS(enDataInputSource), (BYTE *)&(stGenSettingExt.g_astVideo[enDataInputSource] ), SIZE_VIDEO_DATA);
    checkSum = MApp_CalCheckSum((BYTE *)&(stGenSettingExt.g_astVideo[enDataInputSource]), SIZE_VIDEO_DATA );
    if( stGenSettingExt.g_astVideo[enDataInputSource].wVideoDataCS != checkSum )
    {
		MApp_InitVideoSetting((E_DATA_INPUT_SOURCE) enDataInputSource);
		
        EE_LOAD(printf("MApp_InitVideoSetting(%bu)!\n", enDataInputSource));
    }
}

void MApp_CheckVideoSetting(void)
{
    BYTE i;

    for( i = 0; i < DATA_INPUT_SOURCE_NUM; i++ )
    {
        //msAPI_rmBurstReadBytes(RM_VIDEO_DATA_ADDRESS + (SIZE_VIDEO_DATA * i ), (BYTE *)&(stGenSettingExt.g_astVideo[i] ), SIZE_VIDEO_DATA);
        checkSum = MApp_CalCheckSum((BYTE *)&(stGenSettingExt.g_astVideo[i]), SIZE_VIDEO_DATA );
        if( stGenSettingExt.g_astVideo[i].wVideoDataCS != checkSum )
        {
            MApp_InitVideoSetting((E_DATA_INPUT_SOURCE) i);
            EE_LOAD(printf("MApp_InitVideoSetting(%bu)!\n", i));
        }
    }
}

void MApp_SaveVideoSetting(E_DATA_INPUT_SOURCE enDataInputSource)
{
#if (EEPROM_DB_STORAGE!=EEPROM_SAVE_ALL)
    U8 u8QuickDBFlag = g_u8QuickDataBase;
#endif
    BYTE i;

    if( enDataInputSource >= DATA_INPUT_SOURCE_NUM )
    {
        for( i = 0; i < DATA_INPUT_SOURCE_NUM; i++ )
        {
            stGenSettingExt.g_astVideo[i].wVideoDataCS =
            MApp_CalCheckSum((BYTE *)&(stGenSettingExt.g_astVideo[i]), SIZE_VIDEO_DATA );
            MApp_WriteDatabase(RM_VIDEO_DATA_ADDRESS(i),
                                    (BYTE *)&(stGenSettingExt.g_astVideo[i]), SIZE_VIDEO_DATA);
        }
    }
    else
    {
        stGenSettingExt.g_astVideo[enDataInputSource].wVideoDataCS =
        MApp_CalCheckSum((BYTE *)&(stGenSettingExt.g_astVideo[enDataInputSource]), SIZE_VIDEO_DATA );
        MApp_WriteDatabase(RM_VIDEO_DATA_ADDRESS(enDataInputSource),
                                (BYTE *)&(stGenSettingExt.g_astVideo[enDataInputSource]), SIZE_VIDEO_DATA);
    }
#if (EEPROM_DB_STORAGE!=EEPROM_SAVE_ALL)
    if (u8QuickDBFlag & QUICK_DB_UPDATE)
        g_u8QuickDataBase = g_u8QuickDataBase | QUICK_DB_GENSTEXT_MODIFIED;
    else
        g_u8QuickDataBase = (g_u8QuickDataBase & ~QUICK_DB_UPDATE) | QUICK_DB_GENSTEXT_MODIFIED;
#endif
    EE_PUTSTR("\n MApp_SaveVideoSetting!\n");
}

//================================================================================

void MApp_InitWhiteBalanceSetting(E_DATA_INPUT_SOURCE enDataInputSource)
{
    MApp_DataBase_RestoreDefaultWhiteBalance(enDataInputSource);

	MApp_SaveWhiteBalanceSetting(enDataInputSource);
}

void MApp_LoadWhiteBalanceSetting(E_DATA_INPUT_SOURCE enDataInputSource)
{
    MApp_ReadDatabase(RM_WHITEBALANCE_DATA_ADDRESS(enDataInputSource), (BYTE *)&(stGenSettingExt.g_astWhiteBalance[enDataInputSource] ), SIZE_WHITEBALANCE_DATA);
    checkSum = MApp_CalCheckSum((BYTE *)&(stGenSettingExt.g_astWhiteBalance[enDataInputSource]), SIZE_WHITEBALANCE_DATA );
    if( stGenSettingExt.g_astWhiteBalance[enDataInputSource].wWhiteBalanceDataCS != checkSum )
    {
        MApp_InitWhiteBalanceSetting( (E_DATA_INPUT_SOURCE) enDataInputSource);
        EE_LOAD(printf("MApp_InitWhiteBalanceSetting(%bu)!\n", enDataInputSource));
    }
}

void MApp_CheckWhiteBalanceSetting(void)
{
    BYTE i;

    for( i = 0; i < DATA_INPUT_SOURCE_NUM; i++ )
    {
        //msAPI_rmBurstReadBytes(RM_WHITEBALANCE_DATA_ADDRESS, (BYTE *)&(stGenSettingExt.g_astWhiteBalance[i] ), SIZE_WHITEBALANCE_DATA);
        checkSum = MApp_CalCheckSum((BYTE *)&(stGenSettingExt.g_astWhiteBalance[i]), SIZE_WHITEBALANCE_DATA );
        if( stGenSettingExt.g_astWhiteBalance[i].wWhiteBalanceDataCS != checkSum )
        {
            MApp_InitWhiteBalanceSetting( (E_DATA_INPUT_SOURCE) i);
            EE_LOAD(printf("MApp_InitWhiteBalanceSetting(%bu)!\n", i));
            printf("MApp_InitWhiteBalanceSetting(%bu)!\n", i);
        }
    }

    #ifdef ENABLE_CUS_POWERON_CHECK_WB_ADC
    for( i = 0; i < DATA_INPUT_SOURCE_NUM; i++ )
    {
        U8 j;
        for(j = 0;j < MS_COLOR_TEMP_COUNT;j++)
        {
            U16 u16Sum;
            u16Sum = 0;
            u16Sum += stGenSettingExt.g_astWhiteBalance[i].astColorTemp[j].cRedOffset;
            u16Sum += stGenSettingExt.g_astWhiteBalance[i].astColorTemp[j].cGreenOffset;
            u16Sum += stGenSettingExt.g_astWhiteBalance[i].astColorTemp[j].cBlueOffset;

            if((u16Sum <= 30) || (u16Sum > 750))
            {
                MApp_InitWhiteBalanceSetting( (E_DATA_INPUT_SOURCE) i);
                break;
            }

            u16Sum = 0;
            u16Sum += stGenSettingExt.g_astWhiteBalance[i].astColorTemp[j].cRedColor;
            u16Sum += stGenSettingExt.g_astWhiteBalance[i].astColorTemp[j].cGreenColor;
            u16Sum += stGenSettingExt.g_astWhiteBalance[i].astColorTemp[j].cBlueColor;

            if((u16Sum <= 30) || (u16Sum > 750))
            {
                MApp_InitWhiteBalanceSetting( (E_DATA_INPUT_SOURCE) i);
                break;
            }
        }
    }
    #endif
}

void MApp_SaveWhiteBalanceSetting(E_DATA_INPUT_SOURCE enDataInputSource)
{
#if (EEPROM_DB_STORAGE!=EEPROM_SAVE_ALL)
    U8 u8QuickDBFlag = g_u8QuickDataBase;
#endif
    BYTE i;

    if( enDataInputSource >= DATA_INPUT_SOURCE_NUM )
    {
        for( i = 0; i < DATA_INPUT_SOURCE_NUM; i++ )
        {
            stGenSettingExt.g_astWhiteBalance[i].wWhiteBalanceDataCS =
            MApp_CalCheckSum((BYTE *)&(stGenSettingExt.g_astWhiteBalance[i]), SIZE_WHITEBALANCE_DATA );
            MApp_WriteDatabase(RM_WHITEBALANCE_DATA_ADDRESS(i),
                                    (BYTE *)&(stGenSettingExt.g_astWhiteBalance[i]), SIZE_WHITEBALANCE_DATA);
        }
    }
    else
    {
        stGenSettingExt.g_astWhiteBalance[enDataInputSource].wWhiteBalanceDataCS =
        MApp_CalCheckSum((BYTE *)&(stGenSettingExt.g_astWhiteBalance[enDataInputSource]), SIZE_WHITEBALANCE_DATA );
        MApp_WriteDatabase(RM_WHITEBALANCE_DATA_ADDRESS(enDataInputSource),
                                (BYTE *)&(stGenSettingExt.g_astWhiteBalance[enDataInputSource]), SIZE_WHITEBALANCE_DATA);
    }
#if (EEPROM_DB_STORAGE!=EEPROM_SAVE_ALL)
    if (u8QuickDBFlag & QUICK_DB_UPDATE)
        g_u8QuickDataBase = g_u8QuickDataBase | QUICK_DB_GENSTEXT_MODIFIED;
    else
        g_u8QuickDataBase = (g_u8QuickDataBase & ~QUICK_DB_UPDATE) | QUICK_DB_GENSTEXT_MODIFIED;
#endif

    EE_PUTSTR("\n MApp_SaveWhiteBalanceSetting!\n");
}

void MApp_CopyWhiteBalanceSettingToAllInput(void)
{
    U8 i;
    for(i = 0; i < DATA_INPUT_SOURCE_NUM; i++)
    {
        stGenSettingExt.g_astWhiteBalance[i] = stGenSettingExt.g_astWhiteBalance[DATA_INPUT_SOURCE_TYPE(MAIN_WINDOW)];
        MApp_SaveWhiteBalanceSetting((E_DATA_INPUT_SOURCE) i);
    }
//    printf("MApp_CopyWhiteBalanceSettingToAllInput\n");
}

#ifdef ENABLE_CUS_SERIAL_NUMBER
static U8 cusCSM_SN[CUS_CSM_SN_SIZE] = "123456789987654321";		// CUS_XM Sea 20120615: 18 SN chars add 1 �ַ��������ַ�
//static U8 cusCSM_SN[CUS_CSM_SN_SIZE] = "666666666666666666";		// CUS_XM Sea 20120615: 18 SN chars add 1 �ַ��������ַ�
void MApp_InitSerialNumberSetting(void)
{
    U8 i;
    for(i = 0; i < CUS_CSM_SN_SIZE; i++)
    {
        stGenSettingExt.g_astSerialNumber.u8SerialNumber[i] = cusCSM_SN[i];
    }
    MApp_SaveSerialNumberSetting();
}

void MApp_LoadSerialNumberSetting(void)
{
    MApp_ReadDatabase(RM_SN_DATA_START_ADR, (BYTE *)&(stGenSettingExt.g_astSerialNumber), RM_SIZE_SN_DATA);
    checkSum = MApp_CalCheckSum((BYTE *)&(stGenSettingExt.g_astSerialNumber), ( (U16)sizeof(T_MS_SERIAL_NUM) ) );
    if( stGenSettingExt.g_astSerialNumber.u16SerialNumCS != checkSum )
    {
        MApp_InitSerialNumberSetting();
        EE_LOAD(printf("MApp_InitSerialNumberSetting!\n"));
    }
}

void MApp_CheckSerialNumberSetting(void)
{
    checkSum = MApp_CalCheckSum((BYTE *)&(stGenSettingExt.g_astSerialNumber), ( (U16)sizeof(T_MS_SERIAL_NUM) ) );
    if( stGenSettingExt.g_astSerialNumber.u16SerialNumCS != checkSum )
    {
        MApp_InitSerialNumberSetting();
        EE_LOAD(printf("MApp_InitSerialNumberSetting!\n"));
    }
}

void MApp_SaveSerialNumberSetting(void)
{
#if 0//(EEPROM_DB_STORAGE!=EEPROM_SAVE_ALL)
    U8 u8QuickDBFlag = g_u8QuickDataBase;
#endif
    stGenSettingExt.g_astSerialNumber.u16SerialNumCS =
    MApp_CalCheckSum((BYTE *)&(stGenSettingExt.g_astSerialNumber), ( (U16)sizeof(T_MS_SERIAL_NUM) ) );
    MApp_WriteDatabase(RM_SN_DATA_START_ADR,
                            (BYTE *)&(stGenSettingExt.g_astSerialNumber), ( (U16)sizeof(T_MS_SERIAL_NUM) ));

#if 0//(EEPROM_DB_STORAGE!=EEPROM_SAVE_ALL)
    if (u8QuickDBFlag & QUICK_DB_UPDATE)
        g_u8QuickDataBase = g_u8QuickDataBase | QUICK_DB_GENSTEXT_MODIFIED;
    else
        g_u8QuickDataBase = (g_u8QuickDataBase & ~QUICK_DB_UPDATE) | QUICK_DB_GENSTEXT_MODIFIED;
#endif

    EE_PUTSTR("\n MApp_SaveSerialNumberSetting!\n");
}
#endif
//================================================================================

void MApp_InitSubColorSetting(E_DATA_INPUT_SOURCE enDataInputSource)
{
    MApp_DataBase_RestoreDefaultSubColor(enDataInputSource);

    MApp_SaveSubColorSetting(enDataInputSource);
}

void MApp_LoadSubColorSetting(E_DATA_INPUT_SOURCE enDataInputSource)
{
    MApp_ReadDatabase(RM_SUBCOLOR_DATA_ADDRESS(enDataInputSource), (BYTE *)&(stGenSettingExt.g_astSubColor[enDataInputSource] ), SIZE_SUBCOLOR_DATA);
    checkSum = MApp_CalCheckSum((BYTE *)&(stGenSettingExt.g_astSubColor[enDataInputSource]), SIZE_SUBCOLOR_DATA );
    if( stGenSettingExt.g_astSubColor[enDataInputSource].u16SubColorDataCS != checkSum )
    {
        MApp_InitSubColorSetting((E_DATA_INPUT_SOURCE) enDataInputSource);
        EE_LOAD(printf("MApp_InitSubColorSetting(%bu)!\n", enDataInputSource));
    }
}

void  MApp_CheckSubColorSetting(void)
{
    BYTE i;

    for( i = 0; i < DATA_INPUT_SOURCE_NUM; i++ )
    {
        //msAPI_rmBurstReadBytes(RM_SUBCOLOR_DATA_ADDRESS, (BYTE *)&(stGenSettingExt.g_astSubColor[i] ), SIZE_SUBCOLOR_DATA);
        checkSum = MApp_CalCheckSum((BYTE *)&(stGenSettingExt.g_astSubColor[i]), SIZE_SUBCOLOR_DATA );
        if( stGenSettingExt.g_astSubColor[i].u16SubColorDataCS != checkSum )
        {
            MApp_InitSubColorSetting( (E_DATA_INPUT_SOURCE) i);
            EE_LOAD(printf("MApp_InitSubColorSetting(%bu)!\n", i));
        }
    }
}

void MApp_SaveSubColorSetting(E_DATA_INPUT_SOURCE enDataInputSource)
{
#if (EEPROM_DB_STORAGE!=EEPROM_SAVE_ALL)
    U8 u8QuickDBFlag = g_u8QuickDataBase;
#endif
    BYTE i;

    if( enDataInputSource >= DATA_INPUT_SOURCE_NUM )
    {
        for( i = 0; i < DATA_INPUT_SOURCE_NUM; i++ )
        {
            stGenSettingExt.g_astSubColor[i].u16SubColorDataCS =
            MApp_CalCheckSum((BYTE *)&(stGenSettingExt.g_astSubColor[i]), SIZE_SUBCOLOR_DATA );
            MApp_WriteDatabase(RM_SUBCOLOR_DATA_ADDRESS(i),
                                    (BYTE *)&(stGenSettingExt.g_astSubColor[i]), SIZE_SUBCOLOR_DATA);
        }
    }
    else
    {
        stGenSettingExt.g_astSubColor[enDataInputSource].u16SubColorDataCS =
        MApp_CalCheckSum((BYTE *)&(stGenSettingExt.g_astSubColor[enDataInputSource]), SIZE_SUBCOLOR_DATA );
        MApp_WriteDatabase(RM_SUBCOLOR_DATA_ADDRESS(enDataInputSource),
                                (BYTE *)&(stGenSettingExt.g_astSubColor[enDataInputSource]), SIZE_SUBCOLOR_DATA);
    }
#if (EEPROM_DB_STORAGE!=EEPROM_SAVE_ALL)
    if (u8QuickDBFlag & QUICK_DB_UPDATE)
        g_u8QuickDataBase = g_u8QuickDataBase | QUICK_DB_GENSTEXT_MODIFIED;
    else
        g_u8QuickDataBase = (g_u8QuickDataBase & ~QUICK_DB_UPDATE) | QUICK_DB_GENSTEXT_MODIFIED;
#endif

    EE_PUTSTR("\n MApp_SaveSubColorSetting!\n");
}


void MApp_CopySubColorDataToAllInput(void)
{
    U8 i;
    for(i = 0; i < DATA_INPUT_SOURCE_NUM; i++)
    {
        stGenSettingExt.g_astSubColor[i] = stGenSettingExt.g_astSubColor[DATA_INPUT_SOURCE_TYPE(MAIN_WINDOW)];
        MApp_SaveSubColorSetting( (E_DATA_INPUT_SOURCE) i);
    }
//    printf("MApp_CopySubColorDataToAllInput\n");
}

//================================================================================

void MApp_InitSoundSetting(void)
{
    MApp_DataBase_RestoreDefaultAudio();

    MApp_SaveSoundSetting();
}

void MApp_CheckSoundSetting(void)
{
    //msAPI_rmBurstReadBytes(RM_SOUND_SETTING_ADDRESS, (BYTE *)&(stGenSetting.g_SoundSetting), SIZE_SOUND_SETTING);
    checkSum = MApp_CalCheckSum((BYTE *)&(stGenSetting.g_SoundSetting), SIZE_SOUND_SETTING );
    if( stGenSetting.g_SoundSetting.soundSettingCS != checkSum )
    {
        MApp_InitSoundSetting();
        EE_LOAD(printf("MApp_InitSoundSetting!\n"));
    }
}
void MApp_LoadSoundSetting(void)
{
    MApp_ReadDatabase(RM_SOUND_SETTING_ADDRESS, (BYTE *)&(stGenSetting.g_SoundSetting), SIZE_SOUND_SETTING);
    checkSum = MApp_CalCheckSum((BYTE *)&(stGenSetting.g_SoundSetting), SIZE_SOUND_SETTING );
    if( stGenSetting.g_SoundSetting.soundSettingCS != checkSum )
    {
        MApp_InitSoundSetting();
        EE_LOAD(printf("MApp_InitSoundSetting!\n"));
    }
}

void MApp_SaveSoundSetting(void)
{
    stGenSetting.g_SoundSetting.soundSettingCS =
    MApp_CalCheckSum((BYTE *)&(stGenSetting.g_SoundSetting), SIZE_SOUND_SETTING );
    MApp_WriteDatabase(RM_SOUND_SETTING_ADDRESS, (BYTE *)&(stGenSetting.g_SoundSetting), SIZE_SOUND_SETTING);
    EE_PUTSTR("\n MApp_SaveSoundSetting!\n");
}

void MApp_InitScanMenuSetting(void)
{
    MApp_DataBase_RestoreDefaultScanMenu();

    MApp_SaveScanMenuSetting();
}

void MApp_CheckScanMenuSetting(void)
{
    //msAPI_rmBurstReadBytes(RM_SOUND_SETTING_ADDRESS, (BYTE *)&(stGenSetting.g_SoundSetting), SIZE_SOUND_SETTING);
    checkSum = MApp_CalCheckSum((BYTE *)&(stGenSetting.stScanMenuSetting), SIZE_SCANMENU_SETTING );
    if( stGenSetting.stScanMenuSetting.ScanSettingCS != checkSum )
    {
        MApp_InitScanMenuSetting();
        EE_LOAD(printf("MApp_InitScanMenuSetting!\n"));
    }
}

void MApp_LoadScanMenuSetting(void)
{
    MApp_ReadDatabase(RM_SOUND_SETTING_ADDRESS, (BYTE *)&(stGenSetting.g_SoundSetting), SIZE_SOUND_SETTING);
    checkSum = MApp_CalCheckSum((BYTE *)&(stGenSetting.stScanMenuSetting), SIZE_SCANMENU_SETTING );
    if( stGenSetting.stScanMenuSetting.ScanSettingCS != checkSum )
    {
        MApp_InitScanMenuSetting();
        EE_LOAD(printf("MApp_InitScanMenuSetting!\n"));
    }
}


void MApp_SaveScanMenuSetting(void)
{
    stGenSetting.stScanMenuSetting.ScanSettingCS=
    MApp_CalCheckSum((BYTE *)&(stGenSetting.stScanMenuSetting), SIZE_SCANMENU_SETTING );
    MApp_WriteDatabase(RM_SCANMENU_SETTING_ADDRESS, (BYTE *)&(stGenSetting.stScanMenuSetting), SIZE_SCANMENU_SETTING);
    EE_PUTSTR("\n MApp_SaveScanMenuSetting!\n");
}

//========================================
void MApp_InitTimeData(void)
{
    MApp_DataBase_RestoreDefaultTime();

    MApp_SaveTimeData();
}

void MApp_CheckTimeData(void)
{
    //msAPI_rmBurstReadBytes(RM_TIME_DATA_ADDRESS, (BYTE *)&(stGenSetting.g_Time), SIZE_TIME_DATA);
    checkSum = MApp_CalCheckSum((BYTE *)&(stGenSetting.g_Time), SIZE_TIME_DATA );
    if( stGenSetting.g_Time.wTimeDataCS != checkSum )
    {
        MApp_InitTimeData();
        EE_LOAD(printf("MApp_InitTimeData!\n"));
    }
}

void MApp_LoadTimeData(void)
{
    MApp_ReadDatabase(RM_TIME_DATA_ADDRESS, (BYTE *)&(stGenSetting.g_Time), SIZE_TIME_DATA);
    checkSum = MApp_CalCheckSum((BYTE *)&(stGenSetting.g_Time), SIZE_TIME_DATA );
    if( stGenSetting.g_Time.wTimeDataCS != checkSum )
    {
        MApp_InitTimeData();
        EE_LOAD(printf("MApp_InitTimeData!\n"));
    }
}

void MApp_SaveTimeData(void)
{
    stGenSetting.g_Time.wTimeDataCS =
    MApp_CalCheckSum((BYTE *)&(stGenSetting.g_Time), SIZE_TIME_DATA  );
    MApp_WriteDatabase(RM_TIME_DATA_ADDRESS, (BYTE *)&(stGenSetting.g_Time), SIZE_TIME_DATA);
    EE_PUTSTR("\n MApp_SaveTimeData!\n");
}

void MApp_InitBlockData(void)
{
    App_DataBase_RestoreDefaultBlock();
    MApp_SaveBlockData();
}

void MApp_CheckBlockData(void)
{
    checkSum = MApp_CalCheckSum((BYTE *)&(stGenSetting.g_BlockSysSetting), SIZE_BLOCK_DATA );

    if( stGenSetting.g_BlockSysSetting.vchipSettingCS != checkSum )
    {
        MApp_InitBlockData();
        EE_LOAD(printf("MApp_InitBlockData!\n"));
    }
}

void MApp_LoadBlockData(void)
{
    MApp_ReadDatabase(RM_BLOCK_DATA_ADDRESS, (BYTE *)&(stGenSetting.g_BlockSysSetting), SIZE_BLOCK_DATA);

    checkSum = MApp_CalCheckSum((BYTE *)&(stGenSetting.g_BlockSysSetting), SIZE_BLOCK_DATA );

    if( stGenSetting.g_BlockSysSetting.vchipSettingCS != checkSum )
    {
        MApp_InitBlockData();
        EE_LOAD(printf("MApp_InitBlockData!\n"));
    }
}

void MApp_SaveBlockData(void)
{
    stGenSetting.g_BlockSysSetting.vchipSettingCS =
        MApp_CalCheckSum((BYTE *)&(stGenSetting.g_BlockSysSetting), SIZE_BLOCK_DATA );
    MApp_WriteDatabase(RM_BLOCK_DATA_ADDRESS, (BYTE *)&(stGenSetting.g_BlockSysSetting), SIZE_BLOCK_DATA);
    EE_PUTSTR("\n MApp_SaveBlockData!\n");
}
//=========SSC SETTING============================
#if ENABLE_SSC
void App_InitSSCData(void)
{
    MApp_DataBase_RestoreDefaultSSC();
    MApp_SaveSSCData();
}

void MApp_CheckSSCData(void)
{
    checkSum = MApp_CalCheckSum((BYTE *)&(stGenSetting.g_SSCSetting), SIZE_SSC_DATA );

    if( stGenSetting.g_SSCSetting.SscSettingCS != checkSum )
    {
        App_InitSSCData();
        EE_LOAD(printf("App_InitSSCData!\n"));
    }
}

void MApp_LoadSSCData(void)
{
    MApp_ReadDatabase(RM_SSC_DATA_ADDRESS, (BYTE *)&(stGenSetting.g_SSCSetting), SIZE_SSC_DATA);

    checkSum = MApp_CalCheckSum((BYTE *)&(stGenSetting.g_SSCSetting), SIZE_SSC_DATA );

    if( stGenSetting.g_SSCSetting.SscSettingCS != checkSum )
    {
        App_InitSSCData();
        EE_LOAD(printf("App_InitSSCData!\n"));
    }
}


void MApp_SaveSSCData(void)
{
    stGenSetting.g_SSCSetting.SscSettingCS =
        MApp_CalCheckSum((BYTE *)&(stGenSetting.g_SSCSetting), SIZE_SSC_DATA );
    MApp_WriteDatabase(RM_SSC_DATA_ADDRESS, (BYTE *)&(stGenSetting.g_SSCSetting), SIZE_SSC_DATA);
    EE_PUTSTR("\n MApp_SaveBlockData!\n");
}
#endif

#if (ENABLE_NONLINEAR_CURVE)
void MApp_InitNonLinearCurveSetting(void)
{
    MApp_DataBase_RestoreDefaultNonLinearCurve();

    MApp_SaveNonLinearCurveSetting();
}

void MApp_CheckNonLinearCurveSetting(void)
{
    checkSum = MApp_CalCheckSum((BYTE *)&(stGenSetting.g_NonLinearCurveSetting), SIZE_NONLINER_CURVE_SETTING);
    if( stGenSetting.g_NonLinearCurveSetting.NonLinearCurveSettingCS != checkSum )
    {
        MApp_InitNonLinearCurveSetting();
        EE_LOAD(printf("MApp_InitNonLinearCurveSetting()!\n"));
    }
}

void MApp_SaveNonLinearCurveSetting(void)
{
    stGenSetting.g_NonLinearCurveSetting.NonLinearCurveSettingCS = MApp_CalCheckSum((BYTE *)&(stGenSetting.g_NonLinearCurveSetting), SIZE_NONLINER_CURVE_SETTING);
    MApp_WriteDatabase(RM_NONLINER_SETTING_ADDRESS, (BYTE *)&(stGenSetting.g_NonLinearCurveSetting), SIZE_NONLINER_CURVE_SETTING);
    EE_PUTSTR("\n MApp_SaveNonLinearCurveSetting!\n");
}
#endif

//=============================================================================================
void MApp_InitFactorySetting(void)
{
    MApp_DataBase_RestoreDefaultFactorySetting();

    MApp_SaveFactorySetting();
}

void MApp_CheckFactorySetting(void)
{
    checkSum = MApp_CalCheckSum((BYTE *)&(stGenSetting.g_FactorySetting), SIZE_FACTORY_SETTING_DATA);
    if( stGenSetting.g_FactorySetting.FactorySettignCS != checkSum )
    {
        MApp_InitFactorySetting();
        EE_LOAD(printf("MApp_InitFactorySetting!\n"));
    }
}

void MApp_SaveFactorySetting(void)
{
    stGenSetting.g_FactorySetting.FactorySettignCS = MApp_CalCheckSum((BYTE *)&(stGenSetting.g_FactorySetting), SIZE_FACTORY_SETTING_DATA);
    MApp_WriteDatabase(RM_FACTORY_SETTING_DATA_ADDRESS, (BYTE *)&(stGenSetting.g_FactorySetting), SIZE_FACTORY_SETTING_DATA);
    EE_PUTSTR("\n MApp_SaveFactorySetting!\n");
}
#if ENABLE_CUS_UI_SPEC
void MApp_InitVshipSetting(void)
{
    MApp_DataBase_RestoreDefaultVChip();

    MApp_SaveVshipSetting();
}

void MApp_CheckVshipSetting(void)
{
    checkSum = MApp_CalCheckSum((BYTE *)&(stGenSetting.g_VChipSetting), SIZE_VCHIP_SETTING_DATA);
    if( stGenSetting.g_VChipSetting.vchipSettingCS != checkSum )
    {
        MApp_InitVshipSetting();
        EE_LOAD(printf("MApp_InitFactorySetting!\n"));
    }
}

void MApp_SaveVshipSetting(void)
{
    stGenSetting.g_VChipSetting.vchipSettingCS= MApp_CalCheckSum((BYTE *)&(stGenSetting.g_VChipSetting), SIZE_VCHIP_SETTING_DATA);
    MApp_WriteDatabase(RM_VCHIP_SETTING_DATA_ADDRESS, (BYTE *)&(stGenSetting.g_FactorySetting), SIZE_VCHIP_SETTING_DATA);
}
#endif

void MApp_DoFactoryInit(void)
{
#if (EEPROM_DB_STORAGE != EEPROM_SAVE_NONE)
    msAPI_rmWriteByte(RM_EEPROM_ID_ADDRESS, 0xFF); // reset EEPROM ID
    MApp_CheckEEPROM();
#endif
}

#if (ENABLE_LAST_MEMORY==1)&&(ENABLE_LAST_MEMORY_STORAGE_SAVE==1)
void MApp_InitMmLastMemorySetting(void)
{
    MApp_DataBase_RestoreDefaultMmLastMemorySetting();

    MApp_SaveMmLastMemorySetting();
}

void MApp_CheckMmLastMemorySetting(void)
{
    checkSum = MApp_CalCheckSum((BYTE *)&(stGenSetting.g_MmLastMemorySetting), SIZE_MM_LASTMEMORY_SETTING-sizeof(checkSum));

    if( stGenSetting.g_MmLastMemorySetting.MmLastMemorySettignCS != checkSum )
    {
        MApp_InitMmLastMemorySetting();
        EE_LOAD(printf("MApp_InitMmLastMemorySetting!\n"));
    }
}

void MApp_LoadMmLastMemorySetting(void)
{
    MApp_ReadDatabase(RM_MM_LASTMEMORY_SETTING_ADDRESS, (BYTE *)&(stGenSetting.g_MmLastMemorySetting), SIZE_MM_LASTMEMORY_SETTING);
    checkSum = MApp_CalCheckSum((BYTE *)&(stGenSetting.g_MmLastMemorySetting), SIZE_MM_LASTMEMORY_SETTING - sizeof(checkSum));
    if( stGenSetting.g_MmLastMemorySetting.MmLastMemorySettignCS != checkSum )
    {
        MApp_InitMmLastMemorySetting();
        EE_LOAD(printf("MApp_InitMmLastMemorySetting!\n"));
    }
}

void MApp_SaveMmLastMemorySetting(void)
{
    stGenSetting.g_MmLastMemorySetting.MmLastMemorySettignCS = MApp_CalCheckSum((BYTE *)&(stGenSetting.g_MmLastMemorySetting), SIZE_MM_LASTMEMORY_SETTING-sizeof(checkSum));
    MApp_WriteDatabase(RM_MM_LASTMEMORY_SETTING_ADDRESS, (BYTE *)&stGenSetting.g_MmLastMemorySetting,SIZE_MM_LASTMEMORY_SETTING);
    EE_PUTSTR("\n MApp_SaveMmLastMemorySetting!\n");
}
#endif

//*************************************************************************
// General Setting Checking Fucntion === Start
//*************************************************************************
void MApp_DataCheckHandler(void)
{
    if(msAPI_Timer_DiffTimeFromNow(su32DataSavePeriod) > DATA_SAVE_PERIOD)
    {
        if( MApp_KeyIsReapeatStatus() == FALSE )
        {
            U8 u8DBCheckStatus[STATE_DATA_SAVE_NUM];
            U16 u16CheckSum;

            memset(u8DBCheckStatus,0,STATE_DATA_SAVE_NUM);

            //printf("Start Check time=%lx\n",msAPI_Timer_GetTime0());

            u16CheckSum = MApp_CalCheckSum((BYTE *)&(stGenSetting.g_SysSetting), SIZE_SYS_SETTING );
            if( stGenSetting.g_SysSetting.SystemSettingCS != u16CheckSum )
            {
                stGenSetting.g_SysSetting.SystemSettingCS = u16CheckSum;
                u8DBCheckStatus[STATE_DATA_SAVE_SYSTEM]=1;
                u8SaveDataFlag=1;
                eDataSaveState=STATE_DATA_SAVE_SYSTEM;
                EE_PUTSTR("System data changed!\n");
                su32DataSavePeriod = msAPI_Timer_GetTime0();
                return;
            }

            u16CheckSum = MApp_CalCheckSum((BYTE *)&(stGenSettingExt.g_astVideo[DATA_INPUT_SOURCE_TYPE(MAIN_WINDOW)]), SIZE_VIDEO_DATA );
            if( stGenSettingExt.g_astVideo[DATA_INPUT_SOURCE_TYPE(MAIN_WINDOW)].wVideoDataCS != u16CheckSum )
            {
                stGenSettingExt.g_astVideo[DATA_INPUT_SOURCE_TYPE(MAIN_WINDOW)].wVideoDataCS = u16CheckSum;
                u8DBCheckStatus[STATE_DATA_SAVE_VIDEO]=1;
                u8SaveDataFlag=1;
                eDataSaveState=STATE_DATA_SAVE_VIDEO;
                EE_PUTSTR("Video data changed! \n");
                su32DataSavePeriod = msAPI_Timer_GetTime0();
                return;

            }

            u16CheckSum = MApp_CalCheckSum((BYTE *)&(stGenSettingExt.g_astWhiteBalance[DATA_INPUT_SOURCE_TYPE(MAIN_WINDOW)]), SIZE_WHITEBALANCE_DATA );
            if( stGenSettingExt.g_astWhiteBalance[DATA_INPUT_SOURCE_TYPE(MAIN_WINDOW)].wWhiteBalanceDataCS != u16CheckSum )
            {
                stGenSettingExt.g_astWhiteBalance[DATA_INPUT_SOURCE_TYPE(MAIN_WINDOW)].wWhiteBalanceDataCS = u16CheckSum;
                u8DBCheckStatus[STATE_DATA_SAVE_WHITEBALANCE]=1;
                u8SaveDataFlag=1;
                eDataSaveState=STATE_DATA_SAVE_WHITEBALANCE;
                EE_PUTSTR("White balance data change! \n");
                su32DataSavePeriod = msAPI_Timer_GetTime0();
                return;
            }

            u16CheckSum = MApp_CalCheckSum((BYTE *)&(stGenSetting.g_SoundSetting), SIZE_SOUND_SETTING );
            if( stGenSetting.g_SoundSetting.soundSettingCS != u16CheckSum )
            {
                stGenSetting.g_SoundSetting.soundSettingCS = u16CheckSum;
                u8DBCheckStatus[STATE_DATA_SAVE_AUDIO]=1;
                u8SaveDataFlag=1;
                eDataSaveState=STATE_DATA_SAVE_AUDIO;
                EE_PUTSTR("Audio data changed! \n");
                su32DataSavePeriod = msAPI_Timer_GetTime0();
                return;
            }

            u16CheckSum = MApp_CalCheckSum((BYTE *)&(stGenSetting.g_Time), SIZE_TIME_DATA );
            if( stGenSetting.g_Time.wTimeDataCS != u16CheckSum )
            {
                stGenSetting.g_Time.wTimeDataCS = u16CheckSum;
                u8DBCheckStatus[STATE_DATA_SAVE_TIME]=1;
                u8SaveDataFlag=1;
                eDataSaveState=STATE_DATA_SAVE_TIME;
                EE_PUTSTR("Time data changed!\n");
                su32DataSavePeriod = msAPI_Timer_GetTime0();
                return;
            }

            u16CheckSum = MApp_CalCheckSum((BYTE *)&(stGenSetting.g_BlockSysSetting), SIZE_BLOCK_DATA );
            if( stGenSetting.g_BlockSysSetting.vchipSettingCS != u16CheckSum )
            {
                stGenSetting.g_BlockSysSetting.vchipSettingCS= u16CheckSum;
                u8DBCheckStatus[STATE_DATA_SAVE_LOCK]=1;
                u8SaveDataFlag=1;
                eDataSaveState=STATE_DATA_SAVE_LOCK;
                EE_PUTSTR("Block data changed!\n");
                su32DataSavePeriod = msAPI_Timer_GetTime0();
                return;
            }



            if( sbPcModeSaveFlag == TRUE )
            {
                u8DBCheckStatus[STATE_DATA_SAVE_MODETABLE]=1;
                u8SaveDataFlag=1;
                eDataSaveState=STATE_DATA_SAVE_MODETABLE;
                EE_PUTSTR("Mode table data changed!\n");
                su32DataSavePeriod = msAPI_Timer_GetTime0();
                return;
            }

            u16CheckSum = MApp_CalCheckSum((BYTE *)&(stGenSetting.stScanMenuSetting), SIZE_SCANMENU_SETTING );
            if( stGenSetting.stScanMenuSetting.ScanSettingCS != u16CheckSum )
            {
                stGenSetting.stScanMenuSetting.ScanSettingCS = u16CheckSum;
                u8DBCheckStatus[STATE_DATA_SAVE_SCANMENU]=1;
                u8SaveDataFlag=1;
                eDataSaveState=STATE_DATA_SAVE_SCANMENU;
                EE_PUTSTR("Scan menu data changed!\n");
                su32DataSavePeriod = msAPI_Timer_GetTime0();
                return;
            }

#ifdef ENABLE_BT
            u16CheckSum = MApp_CalCheckSum((BYTE *)&(stGenSetting.TorrentSetupInfo), SIZE_BT_DATA);
            if( stGenSetting.TorrentSetupInfo.TorrentSetupInfoCS != u16CheckSum )
            {
                stGenSetting.TorrentSetupInfo.TorrentSetupInfoCS = u16CheckSum;
                u8DBCheckStatus[STATE_DATA_SAVE_BT]=1;
                u8SaveDataFlag=1;
                eDataSaveState=STATE_DATA_SAVE_BT;
                EE_PUTSTR("Bt data changed!\n");
                su32DataSavePeriod = msAPI_Timer_GetTime0();
                return;
            }
#endif
#if (ENABLE_PIP)
            //In some cases, system data & PIP data will be changed at the same time;
            //  and caused data reloading and some abnormal situations occured.
            //  ex. PIP is enabled, do auto-scan in DTV src.
            if(IsPIPDBCheck())
            {
                if(u8SaveDataFlag==0)
                {
                    u16CheckSum = MApp_CalCheckSum((BYTE *)&(stGenSetting.g_stPipSetting), SIZE_PIP_DATA);
                    if( stGenSetting.g_stPipSetting.PIPSetupInfoCS != u16CheckSum )
                    {
                        stGenSetting.g_stPipSetting.PIPSetupInfoCS = u16CheckSum;
                        u8DBCheckStatus[STATE_DATA_SAVE_PIP]=1;
                        u8SaveDataFlag=1;
                        eDataSaveState=STATE_DATA_SAVE_PIP;
                        EE_PUTSTR("PIP data changed!\n");
                        su32DataSavePeriod = msAPI_Timer_GetTime0();
                        return;
                    }
                }
            }
#endif
#if (ENABLE_UPDATE_MULTIPLEX_VIA_NIT)
            u16CheckSum = MApp_CalCheckSum((BYTE *)&(stGenSetting.g_Network_TS), SIZE_NETWORK_INFO_DATA);
            if( stGenSetting.g_Network_TS.NetWorkInfoCS!= u16CheckSum )
            {
                stGenSetting.g_Network_TS.NetWorkInfoCS= u16CheckSum;
                u8DBCheckStatus[STATE_DATA_SAVE_NETWORK]=1;
                u8SaveDataFlag=1;
                eDataSaveState=STATE_DATA_SAVE_NETWORK;
                EE_PUTSTR("network info data changed!\n");
                su32DataSavePeriod = msAPI_Timer_GetTime0();
                return;
            }
#endif
#if (ENABLE_CI && ENABLE_CI_PLUS)
            u16CheckSum = MApp_CalCheckSum((BYTE *)&(stGenSetting.g_CIKeySetting), SIZE_CI_DATA- sizeof(u16CheckSum));
            if( stGenSetting.g_CIKeySetting.CIKeyCS!= u16CheckSum )
            {
                //printf("\n\n~~~u16CheckSum: %u, %u", u16CheckSum, stGenSetting.g_CIKeySetting.CIKeyCS);
                stGenSetting.g_CIKeySetting.CIKeyCS= u16CheckSum;
                u8DBCheckStatus[STATE_DATA_SAVE_CI]=1;
                u8SaveDataFlag=1;
                eDataSaveState=STATE_DATA_SAVE_CI;
                EE_PUTSTR("network info data changed!\n");
                su32DataSavePeriod = msAPI_Timer_GetTime0();
                return;
            }
#endif
#if (ENABLE_LAST_MEMORY==1)&&(ENABLE_LAST_MEMORY_STORAGE_SAVE==1)
            u16CheckSum = MApp_CalCheckSum((BYTE *)&(stGenSetting.g_MmLastMemorySetting), SIZE_MM_LASTMEMORY_SETTING- sizeof(u16CheckSum));
            if( stGenSetting.g_MmLastMemorySetting.MmLastMemorySettignCS!= u16CheckSum )
            {
                //printf("\n\n~~~u16CheckSum: %u, %u", u16CheckSum, stGenSetting.g_MmLastMemorySetting.MmLastMemorySettignCS);
                stGenSetting.g_MmLastMemorySetting.MmLastMemorySettignCS= u16CheckSum;
                u8DBCheckStatus[STATE_DATA_SAVE_MM_LASTMEMORY]=1;
                u8SaveDataFlag=1;
                eDataSaveState=STATE_DATA_SAVE_MM_LASTMEMORY;
                EE_PUTSTR("MM Last Memory Setting changed!\n");
                su32DataSavePeriod = msAPI_Timer_GetTime0();
                return;
            }
#endif
        }
    }

}

//========================================
//need to sepperate user & system data!!!.
void MApp_DataSaveHandler(void)
{
    if(u8SaveDataFlag) //unit = ms
    {
        switch(eDataSaveState)
        {
            case STATE_DATA_SAVE_VIDEO:
                MApp_SaveVideoSetting(DATA_INPUT_SOURCE_TYPE(MAIN_WINDOW));
                EE_PUTSTR("save video data! \n");
                break;
            case STATE_DATA_SAVE_WHITEBALANCE:
                MApp_SaveWhiteBalanceSetting(DATA_INPUT_SOURCE_TYPE(MAIN_WINDOW));
                EE_PUTSTR("save WHITEBALANCE data! \n");
                break;
            case STATE_DATA_SAVE_AUDIO:
                MApp_SaveSoundSetting();
                EE_PUTSTR("save audio data! \n");
                break;
            case STATE_DATA_SAVE_TIME:
                MApp_SaveTimeData();
                EE_PUTSTR("save time data!\n");
                break;
            case STATE_DATA_SAVE_LOCK:
                MApp_SaveBlockData();
                EE_PUTSTR("save block data!\n");
                break;
            case STATE_DATA_SAVE_SYSTEM:
                MApp_SaveSysSetting();
                EE_PUTSTR("STATE_DATA_SAVE_SYSTEM!\n");
                break;
            case STATE_DATA_SAVE_MODETABLE:
                if( sbPcModeSaveFlag == TRUE )
                {
                    sbPcModeSaveFlag = FALSE;
                    #if (ENABLE_PIP)
                    if(IsPIPEnable()&& (IsSrcTypeVga(SYS_INPUT_SOURCE_TYPE(SUB_WINDOW))||IsSrcTypeYPbPr(SYS_INPUT_SOURCE_TYPE(SUB_WINDOW))))
                    {
                        MApp_PCMode_SaveModeRamSetting(SUB_WINDOW);
                    }
                    else
                    #endif
                    {
                        MApp_PCMode_SaveModeRamSetting(MAIN_WINDOW);
                    }
                    EE_PUTSTR("STATE_DATA_SAVE_MODETABLE!\n");
                }
                break;
            case STATE_DATA_SAVE_SCANMENU:
                MApp_SaveScanMenuSetting();
                EE_PUTSTR("STATE_DATA_SAVE_SCANMENU!\n");
                break;
#if ENABLE_DRM
            case STATE_DATA_SAVE_DRM:
                MApp_SaveDrmSetting();
                EE_PUTSTR("STATE_DATA_SAVE_DRM!\n");
            break;
#endif
#ifdef ENABLE_BT
            case STATE_DATA_SAVE_BT:
                MApp_SaveBtSetting();
                EE_PUTSTR("STATE_DATA_SAVE_BT!\n");
                break;
#endif
#if (ENABLE_PIP)
            case STATE_DATA_SAVE_PIP:
                if(IsPIPDBCheck())
                {
                    MApp_SavePipSetting();
                    EE_PUTSTR("STATE_DATA_SAVE_PIP!\n");
                }
                break;
#endif
#if (ENABLE_UPDATE_MULTIPLEX_VIA_NIT)
            case STATE_DATA_SAVE_NETWORK:
                MApp_SaveNetworkInfoSetting();
                EE_PUTSTR("STATE_DATA_SAVE_NETWORK!\n");
                break;
#endif
#if (ENABLE_CI && ENABLE_CI_PLUS)
            case STATE_DATA_SAVE_CI:
                MApp_SaveCISetting();
                EE_PUTSTR("STATE_DATA_SAVE_CI!\n");
                break;
#endif
#if (ENABLE_LAST_MEMORY==1)&&(ENABLE_LAST_MEMORY_STORAGE_SAVE==1)
            case STATE_DATA_SAVE_MM_LASTMEMORY:
                MApp_SaveMmLastMemorySetting();
                EE_PUTSTR("STATE_DATA_SAVE_MM_LASTMEMORY!\n");
                break;
#endif

            default:
                break;
        }
        eDataSaveState = STATE_DATA_SAVE_INIT;
        u8SaveDataFlag=0;
    }
}

void MApp_SetSaveModeDataFlag(void)
{
    sbPcModeSaveFlag = TRUE;
}

void MApp_DataInitVariable(void)
{
    eDataSaveState = STATE_DATA_SAVE_INIT;
    sbPcModeSaveFlag = FALSE;
    su32DataSavePeriod = msAPI_Timer_GetTime0();
}
//*************************************************************************
// General Setting Checking Fucntion === End
//*************************************************************************

//*************************************************************************
//Function name:    MApp_DB_LoadModeSetting
//Passing parameter:    U8 u8ModeIndex: mode index
//Return parameter:     none
//Description:      Load mode setting from SDRAM to XDATASDRAM
//*************************************************************************
void MApp_DB_LoadModeSetting ( SCALER_WIN eWindow, U8 u8ModeIndex )
{
    MApp_ReadDatabase((U32)(RM_MODE_SETTING_START_ADR + u8ModeIndex*sizeof(MS_PCADC_MODESETTING_TYPE)), (BYTE *)&g_PcadcModeSetting[eWindow], sizeof(MS_PCADC_MODESETTING_TYPE));
}
//*************************************************************************
//Function name:    MApp_DB_SaveModeSetting
//Passing parameter:    U8 u8ModeIndex: mode index
//Return parameter:     none
//Description:      Save mode setting from XDATSDRAM to SDRAM
//*************************************************************************
void MApp_DB_SaveModeSetting ( SCALER_WIN eWindow, U8 u8ModeIndex )
{
    MApp_WriteDatabase((U32)(RM_MODE_SETTING_START_ADR + sizeof(MS_PCADC_MODESETTING_TYPE)*u8ModeIndex), (BYTE *)&g_PcadcModeSetting[eWindow], sizeof(MS_PCADC_MODESETTING_TYPE));
}

void MApp_DB_LoadDefaultTable( SCALER_WIN eWindow, U8 u8ModeIndex)
{
    MS_PCADC_MODETABLE_TYPE_EX sModeTbl;

    MApi_XC_ModeParse_GetModeTbl(u8ModeIndex, &sModeTbl);

    g_PcadcModeSetting[eWindow].u8ModeIndex = u8ModeIndex;
    g_PcadcModeSetting[eWindow].u16HorizontalStart = sModeTbl.u16HorizontalStart;
    g_PcadcModeSetting[eWindow].u16VerticalStart = sModeTbl.u16VerticalStart;
    g_PcadcModeSetting[eWindow].u16HorizontalTotal = sModeTbl.u16HorizontalTotal;
    g_PcadcModeSetting[eWindow].u16Phase = sModeTbl.u16AdcPhase;
    g_PcadcModeSetting[eWindow].u16DefaultHStart = g_PcadcModeSetting[eWindow].u16HorizontalStart;
    g_PcadcModeSetting[eWindow].u16DefaultVStart = g_PcadcModeSetting[eWindow].u16VerticalStart;
    g_PcadcModeSetting[eWindow].u16DefaultHTotal = g_PcadcModeSetting[eWindow].u16HorizontalTotal;
    g_PcadcModeSetting[eWindow].u8SyncStatus = sModeTbl.u8StatusFlag;
    g_PcadcModeSetting[eWindow].u8AutoSign = 0;
}

//*************************************************************************
//Function name:    MApp_DB_RestoreAllModeTable
//Passing parameter:    none
//Return parameter:     none
//Description:      Load default standard mode settings to SDRAM
//*************************************************************************
void MApp_RestoreAllModeTable(SCALER_WIN eWindow)
{
    U8 u8Loop;
    U8 NumberOfItems= MApi_XC_GetTotalModeCount();
    for(u8Loop = 0 ; u8Loop < NumberOfItems ; u8Loop++)
    {
        MApp_DB_LoadDefaultTable(eWindow, u8Loop);

        MApp_DB_SaveModeSetting(eWindow, u8Loop);
    }

    for(u8Loop = 0 ; u8Loop < MAX_USER_MODE_NUM ; u8Loop++)
    {
        g_PcadcModeSetting[eWindow].u8ModeIndex = 0xFF;

        g_PcadcModeSetting[eWindow].u16HorizontalStart = 0xFF;
        g_PcadcModeSetting[eWindow].u16VerticalStart = 0xFF;
        g_PcadcModeSetting[eWindow].u16HorizontalTotal = 0xFF;
        g_PcadcModeSetting[eWindow].u16Phase = 0x3FF;
        g_PcadcModeSetting[eWindow].u16DefaultHStart = 0xFF;
        g_PcadcModeSetting[eWindow].u16DefaultVStart = 0xFF;
        g_PcadcModeSetting[eWindow].u16DefaultHTotal = 0xFF;
        g_PcadcModeSetting[eWindow].u8SyncStatus = 0xFF;
        g_PcadcModeSetting[eWindow].u8AutoSign = 0;
        MApp_DB_SaveModeSetting(eWindow, u8Loop+NumberOfItems);
    }
    stGenSetting.g_SysSetting.NextNewRamIndex = 0; // user mode index
    MApp_SaveSysSetting();
}

void MApp_RestorePCModeTable(SCALER_WIN eWindow)
{
    U8 u8Loop;
    U8 NumberOfItems = MApi_XC_GetTotalModeCount();
    for(u8Loop = 0 ; u8Loop < MIN_STD_COMPO_NUM ; u8Loop++)
    {
        MApp_DB_LoadDefaultTable(eWindow, u8Loop);

        MApp_DB_SaveModeSetting(eWindow, u8Loop);
    }
    for(u8Loop = MAX_STD_COMPO_NUM+1 ; u8Loop < NumberOfItems ; u8Loop++)
    {
        MApp_DB_LoadDefaultTable(eWindow, u8Loop);

        MApp_DB_SaveModeSetting(eWindow, u8Loop);
    }
    for(u8Loop = 0 ; u8Loop < MAX_USER_MODE_NUM ; u8Loop++)
    {
        g_PcadcModeSetting[eWindow].u8ModeIndex = 0xFF;

        g_PcadcModeSetting[eWindow].u16HorizontalStart = 0xFF;
        g_PcadcModeSetting[eWindow].u16VerticalStart = 0xFF;
        g_PcadcModeSetting[eWindow].u16HorizontalTotal = 0xFF;
        g_PcadcModeSetting[eWindow].u16Phase = 0x3FF;
        g_PcadcModeSetting[eWindow].u16DefaultHStart = 0xFF;
        g_PcadcModeSetting[eWindow].u16DefaultVStart = 0xFF;
        g_PcadcModeSetting[eWindow].u16DefaultHTotal = 0xFF;
        g_PcadcModeSetting[eWindow].u8SyncStatus = 0xFF;
        g_PcadcModeSetting[eWindow].u8AutoSign = 0;
        MApp_DB_SaveModeSetting(eWindow, u8Loop+NumberOfItems);
    }
    stGenSetting.g_SysSetting.NextNewRamIndex = 0; // user mode index
    MApp_SaveSysSetting();
}

void MApp_RestoreComponentModeTable(void)
{
    U8 u8Loop;

    for(u8Loop = MIN_STD_COMPO_NUM ; u8Loop < MAX_STD_COMPO_NUM+1 ; u8Loop++)
    {
        #if (ENABLE_PIP)
        if(IsPIPEnable()&&(IsSrcTypeVga(SYS_INPUT_SOURCE_TYPE(SUB_WINDOW))&&IsSrcTypeVga(SYS_INPUT_SOURCE_TYPE(SUB_WINDOW))))
        {
            MApp_DB_LoadDefaultTable(SUB_WINDOW, u8Loop);

            MApp_DB_SaveModeSetting(SUB_WINDOW, u8Loop);
        }
        else
        #endif
        {
            MApp_DB_LoadDefaultTable(MAIN_WINDOW, u8Loop);

            MApp_DB_SaveModeSetting(MAIN_WINDOW, u8Loop);
        }
    }
    MApp_SaveSysSetting();
}


#if (ENABLE_DIP_PWS)
void MApp_Load_Input_Source_Setting(void)
{
    U32 u32AddrOffset;
    u32AddrOffset=((U32)(&(stGenSetting.g_SysSetting.enUiInputSourceType)) - (U32)(&(stGenSetting.g_SysSetting)));
    printf("u32AddrOffset = %x \n",u32AddrOffset);
    MApp_ReadDatabase(RM_SYS_SETTING_ADDRESS+u32AddrOffset,
                                    (BYTE *)&(stGenSetting.g_SysSetting.enUiInputSourceType),
                                    sizeof(E_UI_INPUT_SOURCE));
    printf("enUiInputSourceType=0x%x \n",stGenSetting.g_SysSetting.enUiInputSourceType);
}
#endif

#if (ENABLE_SZ_FACTORY_OVER_SCAN_FUNCTION)

 U32 wRmOverscanAddress;
#if 1//20130416 modify 96%
code MS_OVERSCAN_SETTING tOVerScanInitValue[EN_FACTORY_OverScan_NUM]=
{
	// CUS_XM Xue 20120719: modify all source  overscan 95%
    //Checksum, osOffsetX, osOffsetY; osOffsetWidth, osOffsetHeight
//ATV
    //{0x00,      -24,     	 -7,     	63,           18}, // NTSC
    {0x00,      -26,   	    10,         70,        	  -16}, // NTSC
    {0x00,      -22,   	    -10,         62,        	  18}, // PAL
    {0x00,      -34,    	-12 ,        63,           19 }, // SECAM
    //{0x00,      0x00,      0x00,      0x00,          0x00}, // NTSC443
    {0x00,      -26,   	    10,         70,        	  -16}, // NTSC443
    {0x00,      -26,      -7,      70,          18}, // PALM
    {0x00,      -27,      -9,      61,          17}, // PALN
//AV
    {0x00,      -25,        -8,           63,            20}, // NTSC
    {0x00,      -21,        -10,           63,            19}, // PAL
    {0x00,      -34,        -11,           63,            17}, // SECAM
    {0x00,      -39,      -7,      67,          19}, // NTSC443
    {0x00,      -26,      -7,      70,          18}, // PALM
    {0x00,      -28,      -9,      61,          17}, // PALN
//SV
    {0x00,      0x00,      0x00,      0x00,          0x00}, // NTSC
    {0x00,      0x00,      0x00,      0x00,          0x00}, // PAL
    {0x00,      0x00,      0x00,      0x00,          0x00}, // SECAM
    {0x00,      0x00,      0x00,      0x00,          0x00}, // NTSC443
    {0x00,      0x00,      0x00,      0x00,          0x00}, // PALM
    {0x00,      0x00,      0x00,      0x00,          0x00}, // PALN
//SCART-RGB
    {0x00,      0x00,      0x00,      0x00,          0x00}, // NTSC
    {0x00,      0x00,      0x00,      0x00,          0x00}, // PAL
    {0x00,      0x00,      0x00,      0x00,          0x00}, // SECAM
    {0x00,      0x00,      0x00,      0x00,          0x00}, // NTSC443
    {0x00,      0x00,      0x00,      0x00,          0x00}, // PALM
    {0x00,      0x00,      0x00,      0x00,          0x00}, // PALN
//HDMI
    {0x00,      -17,       -10,         34,            20}, // 480I
    { 0x00,	    -17,       -8,          34,            19, }, // 480P
    {0x00,      0x00,      0x00,        0x00,          0x00}, // 1440*480I 		// CUS_XM Xue 20120718: no adjust
    {0x00,      0x00,      0x00,        0x00,          0x00}, // 1440*480P	// CUS_XM Xue 20120718: no adjust
    {0x00,      -16,       -11,         33,             23}, // 576I
    {0x00,      -19,       0x00,        39,            0x00}, // 576P
    {0x00,      0x00,      0x00,        0x00,          0x00}, // 1440*576I	// CUS_XM Xue 20120718: no adjust
    {0x00,      0x00,      0x00,        0x00,          0x00}, // 1440*576P	// CUS_XM Xue 20120718: no adjust
    {0x00,      10,    	   -4,        -16,            6}, // 720P
    {0x00,      13,        0x00,        -21,            0x00}, // 1080I
    {0x00,      41/*30*/,        0x00/*22*/,          0x00/*-59*/,            0x00}, // 1080P
    {0x00,      0x00,      0x00,        0x00,          0x00}, // Default// for some VESA timing
    // CUS_XM Xue 20120723:Add HDMI1080i 24\25\30HZ
    {0x00,      -2,           0,        -10,            0}, // 1080P 24
    {0x00,      14,           2 ,       -27,            -1}, // 1080P 25
    {0x00,      13,           2,        -26,            -2}, // 1080P 30

//YPBPR
    {0x00,      -29,     	 -7,     	  62,             5}, // 480I
    {0x00,      -37,      	-1,    	  76,            2}, // 480P
    {0x00,      -33/*-31*/,       	-8,     	  67/*66*/,            16}, // 576I
    {0x00,      -35,     	 -5,         70,          7}, // 576P
    {0x00,      -14,          -1,          -5,          5}, // 720P50
    {0x00,      5,      	0x00,       -8,          0x00}, // 720P60
    {0x00,      15,           0x00,      -26,         0x00}, // 1080I50
    {0x00,      14,           0x00,         -27,      0x00}, // 1080I60
#if (SUPPORT_EURO_HDTV)
    {0x00,      0x00,       0x00,      0x00,          0x00}, // 1080I50EURO
#endif
#if 1//(ENABLE_YPBPR_30P_24P)
    {0x00,      21,         -1,         -30,          3}, // 1080P24
    {0x00,      17,         0x00,       -26,          0x00}, // 1080P25
    {0x00,      16,         0x00,       -27,          0x00}, // 1080P30
#endif
    {0x00,      31,      17,      -56,          -33}, // 1080P50
    {0x00,      26,          13,          -55,          -27}, // 1080P60
//DTV
    {0x00,      0x00,      0x00,      0x00,          0x00}, // 480i
    {0x00,      0x00,      0x00,      0x00,          0x00}, // 480P
    {0x00,      0x00,      0x00,      0x00,          0x00}, // 576i **
    {0x00,      0x00,      0x00,      0x00,          0x00}, // 576P
    {0x00,      0x00,      0x00,      0x00,          0x00}, // 720P
    {0x00,      0x00,      0x00,      0x00,          0x00}, // 1080i**
    {0x00,      0x00,      0x00,      0x00,          0x00}, // 1080P
};
#else
code MS_OVERSCAN_SETTING tOVerScanInitValue[EN_FACTORY_OverScan_NUM]=
{
	// CUS_XM Xue 20120719: modify all source  overscan 95%
    //Checksum, osOffsetX, osOffsetY; osOffsetWidth, osOffsetHeight
//ATV
    {0x00,      -24,     	 -7,     	63,           18}, // NTSC
    {0x00,      -22,   	    -10,         62,        	  18}, // PAL
    {0x00,      -34,    	-12 ,        63,           19 }, // SECAM
    {0x00,      0x00,      0x00,      0x00,          0x00}, // NTSC443
    {0x00,      -26,      -7,      70,          18}, // PALM
    {0x00,      -27,      -9,      61,          17}, // PALN
//AV
    {0x00,      -25,        -8,           63,            20}, // NTSC
    {0x00,      -21,        -10,           63,            19}, // PAL
    {0x00,      -34,        -11,           63,            17}, // SECAM
    {0x00,      -39,      -7,      67,          19}, // NTSC443
    {0x00,      -26,      -7,      70,          18}, // PALM
    {0x00,      -28,      -9,      61,          17}, // PALN
//SV
    {0x00,      0x00,      0x00,      0x00,          0x00}, // NTSC
    {0x00,      0x00,      0x00,      0x00,          0x00}, // PAL
    {0x00,      0x00,      0x00,      0x00,          0x00}, // SECAM
    {0x00,      0x00,      0x00,      0x00,          0x00}, // NTSC443
    {0x00,      0x00,      0x00,      0x00,          0x00}, // PALM
    {0x00,      0x00,      0x00,      0x00,          0x00}, // PALN
//SCART-RGB
    {0x00,      0x00,      0x00,      0x00,          0x00}, // NTSC
    {0x00,      0x00,      0x00,      0x00,          0x00}, // PAL
    {0x00,      0x00,      0x00,      0x00,          0x00}, // SECAM
    {0x00,      0x00,      0x00,      0x00,          0x00}, // NTSC443
    {0x00,      0x00,      0x00,      0x00,          0x00}, // PALM
    {0x00,      0x00,      0x00,      0x00,          0x00}, // PALN
//HDMI
    {0x00,      -17,       -10,         34,            20}, // 480I
    { 0x00,	    -17,       -8,          34,            19, }, // 480P
    {0x00,      0x00,      0x00,        0x00,          0x00}, // 1440*480I 		// CUS_XM Xue 20120718: no adjust
    {0x00,      0x00,      0x00,        0x00,          0x00}, // 1440*480P	// CUS_XM Xue 20120718: no adjust
    {0x00,      -16,       -11,         33,             23}, // 576I
    {0x00,      -19,       0x00,        39,            0x00}, // 576P
    {0x00,      0x00,      0x00,        0x00,          0x00}, // 1440*576I	// CUS_XM Xue 20120718: no adjust
    {0x00,      0x00,      0x00,        0x00,          0x00}, // 1440*576P	// CUS_XM Xue 20120718: no adjust
    {0x00,      10,    	   -4,        -16,            6}, // 720P
    {0x00,      13,        0x00,        -21,            0x00}, // 1080I
    {0x00,      30,        22,          -59,            -46}, // 1080P
    {0x00,      0x00,      0x00,        0x00,          0x00}, // Default// for some VESA timing
    // CUS_XM Xue 20120723:Add HDMI1080i 24\25\30HZ
    {0x00,      -2,           0,        -10,            0}, // 1080P 24
    {0x00,      14,           2 ,       -27,            -1}, // 1080P 25
    {0x00,      13,           2,        -26,            -2}, // 1080P 30

//YPBPR
    {0x00,      -29,     	 -7,     	  62,             5}, // 480I
    {0x00,      -37,      	-1,    	  76,            2}, // 480P
    {0x00,      -27,       	-3,     	  45,            6}, // 576I
    {0x00,      -35,     	 -5,         70,          7}, // 576P
    {0x00,      -14,          -1,          -5,          5}, // 720P50
    {0x00,      5,      	0x00,       -8,          0x00}, // 720P60
    {0x00,      15,           0x00,      -26,         0x00}, // 1080I50
    {0x00,      14,           0x00,         -27,      0x00}, // 1080I60
#if (SUPPORT_EURO_HDTV)
    {0x00,      0x00,       0x00,      0x00,          0x00}, // 1080I50EURO
#endif
#if 1//(ENABLE_YPBPR_30P_24P)
    {0x00,      21,         -1,         -30,          3}, // 1080P24
    {0x00,      17,         0x00,       -26,          0x00}, // 1080P25
    {0x00,      16,         0x00,       -27,          0x00}, // 1080P30
#endif
    {0x00,      31,      17,      -56,          -33}, // 1080P50
    {0x00,      26,          13,          -55,          -27}, // 1080P60
//DTV
    {0x00,      0x00,      0x00,      0x00,          0x00}, // 480i
    {0x00,      0x00,      0x00,      0x00,          0x00}, // 480P
    {0x00,      0x00,      0x00,      0x00,          0x00}, // 576i **
    {0x00,      0x00,      0x00,      0x00,          0x00}, // 576P
    {0x00,      0x00,      0x00,      0x00,          0x00}, // 720P
    {0x00,      0x00,      0x00,      0x00,          0x00}, // 1080i**
    {0x00,      0x00,      0x00,      0x00,          0x00}, // 1080P
};
#endif
U32 CalculatorOverScanAddress(void)
{

    U32 wRmAddress=0;

        if(IsATVInUse())
        {
            wRmAddress=(U32)(RM_OVERSCAN_DATA_START_ADR+mvideo_vd_get_videosystem()*SIZE_OVERSCAN_DATA);
        }
        else if(IsAVInUse())
        {
            wRmAddress=(U32)(RM_OVERSCAN_DATA_START_ADR+(mvideo_vd_get_videosystem()+EN_FACTORY_OverScan_AVNTSC)*SIZE_OVERSCAN_DATA);
        }
        else if(IsSVInUse())
        {
            wRmAddress=(U32)(RM_OVERSCAN_DATA_START_ADR+(mvideo_vd_get_videosystem()+EN_FACTORY_OverScan_SVNTSC)*SIZE_OVERSCAN_DATA);
        }

        #if (INPUT_SCART_VIDEO_COUNT > 0)
        else if(IsScartInUse())//scart1
        {
            SCART_SOURCE_TYPE _ScarSrcTypeTemp = E_SCART_SRC_TYPE_UNKNOWN;

            if(IsSrcTypeScart(INPUT_SOURCE_SCART))
            {
                if(msAPI_AVD_GetScart1SrcType())
                {
                    _ScarSrcTypeTemp = E_SCART_SRC_TYPE_RGB;
                }
                else
                {
                    if(IsSrcTypeScart(INPUT_SOURCE_SCART))
                    {
                        _ScarSrcTypeTemp = E_SCART_SRC_TYPE_CVBS;
                    }
                    else
                    {
                        switch (stGenSetting.g_SysSetting.fSCARTInputSel)
                        {
                            case EN_SCART_SEL_AV:
                                    _ScarSrcTypeTemp = E_SCART_SRC_TYPE_CVBS;
                                    break;
                            case EN_SCART_SEL_SV:
                                    _ScarSrcTypeTemp = E_SCART_SRC_TYPE_SVIDEO;
                                    break;
                            default:
                                    _ScarSrcTypeTemp = E_SCART_SRC_TYPE_UNKNOWN;
                                    break;
                        }
                    }
                }
            }
            #if (INPUT_SCART_VIDEO_COUNT == 2)
            else if(IsSrcTypeScart(INPUT_SOURCE_SCART2))//scart2
            {
                _ScarSrcTypeTemp = E_SCART_SRC_TYPE_CVBS;
            }
            #endif //end of (INPUT_SCART_VIDEO_COUNT == 2)
            switch(_ScarSrcTypeTemp)
            {
                case E_SCART_SRC_TYPE_CVBS:
                    wRmAddress = (U32)(RM_OVERSCAN_DATA_START_ADR + (mvideo_vd_get_videosystem()+EN_FACTORY_OverScan_AVNTSC) * SIZE_OVERSCAN_DATA); //morgan.smc as av setting.
                    break;
                case E_SCART_SRC_TYPE_RGB:
                    //To get a table for Scart RGB, if need
                    printf("g_VdInfo.ucVideoSystem is %bx",mvideo_vd_get_videosystem());
                    wRmAddress = (U32)(RM_OVERSCAN_DATA_START_ADR + (mvideo_vd_get_videosystem() + EN_FACTORY_OverScan_SCARTRGB_NTSC)*SIZE_OVERSCAN_DATA);

                    /*
                    if(u16VSize>=450 && u16VSize <=500) // NTSC
                        wRmAddress = (U32)(RM_OVERSCAN_DATA_START_ADR +EN_FACTORY_OverScan_SCARTNTSC*SIZE_OVERSCAN_DATA);
                    else
                        wRmAddress = (U32)(RM_OVERSCAN_DATA_START_ADR +EN_FACTORY_OverScan_SCARTPAL*SIZE_OVERSCAN_DATA);*/
                    break;
                case E_SCART_SRC_TYPE_SVIDEO:
                    wRmAddress = (U32)(RM_OVERSCAN_DATA_START_ADR + (mvideo_vd_get_videosystem()+ EN_FACTORY_OverScan_SVNTSC)*SIZE_OVERSCAN_DATA);
                    break;
                case E_SCART_SRC_TYPE_UNKNOWN:
                default:
                    break;
            }
        }
  #endif // #if (INPUT_SCART_VIDEO_COUNT > 0)
        else if( IsHDMIInUse()&& (g_HdmiPollingStatus.bIsHDMIMode == TRUE))
        {
            U16  u16HSize = MApp_PCMode_Get_HResolution(MAIN_WINDOW,FALSE);
            U16 u16VSize = MApp_PCMode_Get_VResolution(MAIN_WINDOW,FALSE);
            U16 u16Freq = MApi_XC_PCMonitor_Get_VFreqx10(MAIN_WINDOW);

            BOOL bInterlace = FALSE;

            printf(" HDMI freq =[%u]",u16Freq);		// CUS_XM Xue 20120724:
            bInterlace = (MApi_XC_PCMonitor_GetSyncStatus(MAIN_WINDOW) & XC_MD_INTERLACE_BIT) ? (TRUE) : (FALSE);

            if((u16HSize>=710 && u16HSize<=730) && (u16VSize>=470 && u16VSize<=490))
            {// 720
                if(bInterlace)
                {// 480i
                    wRmAddress=(U32)(RM_OVERSCAN_DATA_START_ADR+EN_FACTORY_OverScan_HDMI480I*SIZE_OVERSCAN_DATA);
                }
                else
                {// 480p
                    wRmAddress=(U32)(RM_OVERSCAN_DATA_START_ADR+EN_FACTORY_OverScan_HDMI480P*SIZE_OVERSCAN_DATA);
                }
            }
            else if((u16HSize>=710 && u16HSize<=730) && (u16VSize>=566 && u16VSize<=586))
            {// 720
                if(bInterlace)
                {// 576i
                    wRmAddress=(U32)(RM_OVERSCAN_DATA_START_ADR+EN_FACTORY_OverScan_HDMI576I*SIZE_OVERSCAN_DATA);
                }
                else
                {// 576p
                    wRmAddress=(U32)(RM_OVERSCAN_DATA_START_ADR+EN_FACTORY_OverScan_HDMI576P*SIZE_OVERSCAN_DATA);
                }
            }
            else if((u16HSize>=1430 && u16HSize<=1450) && (u16VSize>=470 && u16VSize<=490))
            {// 1440
                if(bInterlace)
                {// 480i
                    wRmAddress=(U32)(RM_OVERSCAN_DATA_START_ADR+EN_FACTORY_OverScan_HDMI1440_480I*SIZE_OVERSCAN_DATA);
                }
                else
                {// 480p
                    wRmAddress=(U32)(RM_OVERSCAN_DATA_START_ADR+EN_FACTORY_OverScan_HDMI1440_480P*SIZE_OVERSCAN_DATA);
                }
            }
            else if((u16HSize>=1430 && u16HSize<=1450) && (u16VSize>=566 && u16VSize<=586))
            {// 1440
                if(bInterlace)
                {// 576I
                    wRmAddress=(U32)(RM_OVERSCAN_DATA_START_ADR+EN_FACTORY_OverScan_HDMI1440_576I*SIZE_OVERSCAN_DATA);
                }
                else
                {//576P
                    wRmAddress=(U32)(RM_OVERSCAN_DATA_START_ADR+EN_FACTORY_OverScan_HDMI1440_576P*SIZE_OVERSCAN_DATA);
                }
            }
            else if((u16HSize>=1270 && u16HSize<=1290) && (u16VSize>=710 && u16VSize<=730))
            {// 1280
                // 720P
                wRmAddress=(U32)(RM_OVERSCAN_DATA_START_ADR+EN_FACTORY_OverScan_HDMI720P*SIZE_OVERSCAN_DATA);
            }
            else if((u16HSize>=1910 && u16HSize<=1930) && (u16VSize>=1070 && u16VSize<=1090))
            {// 1920
                if (bInterlace)
                {//1080i
                    wRmAddress=(U32)(RM_OVERSCAN_DATA_START_ADR+EN_FACTORY_OverScan_HDMI1080I*SIZE_OVERSCAN_DATA);
                }
                else
                {// 1080P 		// CUS_XM Xue 20120724: add HDMI 1080P23\24\25\30 HZ overscan
                    if(u16Freq==239)
                    {
                        wRmAddress=(U32)(RM_OVERSCAN_DATA_START_ADR+EN_FACTORY_OverScan_HDMI1080P24*SIZE_OVERSCAN_DATA);
                    }
                    else if(u16Freq==249)
                    {
                        wRmAddress=(U32)(RM_OVERSCAN_DATA_START_ADR+EN_FACTORY_OverScan_HDMI1080P25*SIZE_OVERSCAN_DATA);
                    }
                    else if(u16Freq==299)
                    {
                        wRmAddress=(U32)(RM_OVERSCAN_DATA_START_ADR+EN_FACTORY_OverScan_HDMI1080P30*SIZE_OVERSCAN_DATA);
                    }
                    else
                    {
                        wRmAddress=(U32)(RM_OVERSCAN_DATA_START_ADR+EN_FACTORY_OverScan_HDMI1080P*SIZE_OVERSCAN_DATA);
                    }
                }
            }
            else//default
            {
                wRmAddress=(U32)(RM_OVERSCAN_DATA_START_ADR+EN_FACTORY_OverScan_HDMIDefault*SIZE_OVERSCAN_DATA);
            }
        }
        else if(IsYPbPrInUse())
        {
            wRmAddress=(U32)(RM_OVERSCAN_DATA_START_ADR+(g_PcadcModeSetting[MAIN_WINDOW].u8ModeIndex -MD_720x480_60I+EN_FACTORY_OverScan_YPBPR480I)*SIZE_OVERSCAN_DATA);
        }
        else if(IsSrcTypeDTV(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)) ||
            (IsSrcTypeStorage(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)) && !IsSrcTypeJpeg(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)))) // storage type except JPEG
        {
            U16 u16HSize ,u16VSize;
            U8 bInterlace;
            msAPI_VID_GetVidInfo(&gstVidStatus);
            // if( TRUE == msAPI_VID_GetVidInfo(&gstVidStatus))
            {
                u16HSize = gstVidStatus.u16VerSize;
                u16VSize =  gstVidStatus.u16HorSize;
                bInterlace  =gstVidStatus.u8Interlace;
            }
            if(u16HSize <= 750 && u16VSize <= 500)
            {
                if(bInterlace)//(g_DisplayWindowSetting.u8DisplayStatus & DISPLAYWINDOW_INTERLACE)
                {// 480i
                     wRmAddress=(U32)(RM_OVERSCAN_DATA_START_ADR+EN_FACTORY_OverScan_DTV480I*SIZE_OVERSCAN_DATA);
                }
                else
                {// 480p
                     wRmAddress=(U32)(RM_OVERSCAN_DATA_START_ADR+EN_FACTORY_OverScan_DTVR480P*SIZE_OVERSCAN_DATA);
                }
            }
            else if(u16HSize <= 750 && u16VSize <= 600)
            {
                if(bInterlace)// (g_DisplayWindowSetting.u8DisplayStatus & DISPLAYWINDOW_INTERLACE)
                {// 576i
                    wRmAddress=(U32)(RM_OVERSCAN_DATA_START_ADR+EN_FACTORY_OverScan_DTV576I*SIZE_OVERSCAN_DATA);
                }
                else
                {// 576p
                    wRmAddress=(U32)(RM_OVERSCAN_DATA_START_ADR+EN_FACTORY_OverScan_DTV576P*SIZE_OVERSCAN_DATA);
                }
            }
            else if(u16HSize <= 1300 && u16VSize <= 750)
            {   //720P
                wRmAddress=(U32)(RM_OVERSCAN_DATA_START_ADR+EN_FACTORY_OverScan_DTV720P*SIZE_OVERSCAN_DATA);
            }
            else if(u16HSize <= 1950 && u16VSize <= 1200)
            {
                if (bInterlace)//(g_DisplayWindowSetting.u8DisplayStatus & DISPLAYWINDOW_INTERLACE)
                {//1080i
                    wRmAddress=(U32)(RM_OVERSCAN_DATA_START_ADR+EN_FACTORY_OverScan_DTV1080I*SIZE_OVERSCAN_DATA);
                }
                else
                {// 1080P
                    wRmAddress=(U32)(RM_OVERSCAN_DATA_START_ADR+EN_FACTORY_OverScan_DTV1080P*SIZE_OVERSCAN_DATA);
                }
            }
     }

    return wRmAddress;
}

void MApp_InitOverScanData(void)
{
   U8 OverScanIndex;
   wRmOverscanAddress = RM_OVERSCAN_DATA_START_ADR;

    for(OverScanIndex=0;OverScanIndex<EN_FACTORY_OverScan_NUM;OverScanIndex++)
     {
        g_OverScan = tOVerScanInitValue[OverScanIndex];
        MApp_SaveOverScanData();
	 wRmOverscanAddress += SIZE_OVERSCAN_DATA;
    }
}
void MApp_LoadOverScanData (void)
{
    wRmOverscanAddress = CalculatorOverScanAddress();
    if(wRmOverscanAddress!=0)
    {
        MApp_ReadDatabase((U32)wRmOverscanAddress, (BYTE *)&g_OverScan, SIZE_OVERSCAN_DATA);
        checkSum = MApp_CalCheckSum((BYTE *)&g_OverScan, SIZE_OVERSCAN_DATA - sizeof(checkSum));
        if( g_OverScan.Checksum != checkSum )
        {
            // Load default and save.
          g_OverScan = tOVerScanInitValue[(wRmOverscanAddress - RM_OVERSCAN_DATA_START_ADR)/SIZE_OVERSCAN_DATA];
            MApp_SaveOverScanData();
        }
     }
    else
     {
        g_OverScan.osOffsetX      = 0;
        g_OverScan.osOffsetY      = 0;
        g_OverScan.osOffsetWidth  = 0;
        g_OverScan.osOffsetHeight = 0;
     }
}
void MApp_SaveOverScanData (void )
{
    g_OverScan.Checksum = MApp_CalCheckSum((BYTE *)&g_OverScan, SIZE_OVERSCAN_DATA - sizeof(checkSum));
      if (wRmOverscanAddress != 0)// write safe.
    {
    MApp_WriteDatabase((U32)wRmOverscanAddress, (BYTE *)&g_OverScan, SIZE_OVERSCAN_DATA);
}
}
#endif
#if (ENABLE_SZ_FACTORY_USB_SAVE_DATABASE_FUNCTION == ENABLE)
#include "msAPI_FCtrl.h"
#include "IOUtil.h"
#include "mw_usbdownload.h"

#define SW_DATABASE "DATABASE.bin"

static FileEntry g_fileEntry;

extern BOOLEAN MDrv_UsbDeviceConnect(void);
extern void msAPI_BLoader_Reboot(void);
extern BOOLEAN MApp_UsbSaveData_SearchFileInRoot(U8* pu8FileName, FileEntry* pFileEntry);
extern U8 MDrv_USBGetPortEnableStatus(void);

static void _MApp_CopyDB2GenSetting(void)
{
    MApp_ReadDatabase(RM_GENSET_START_ADR, (BYTE *)&stGenSetting, RM_SIZE_GENSET);
}

void MApp_BackupDatabase(void)//usb clone :tv to usb
{
    U8  USBDeviceDetect=0;                          //cus_xm zhihe modify for  usb clone 20120820
    USBDeviceDetectFlag = TRUE;
    while (!MDrv_UsbDeviceConnect())
    {
        EE_LOAD(printf("\n init USB__fail \n"));
		printf("\n init USB__fail \n");
		USBDeviceDetect++;
		if(USBDeviceDetect>20)
			{
				USBDeviceDetectFlag = FALSE;   //show error message box's flag
				return;
			}
		
    }

    U8 u8PortEnStatus = MDrv_USBGetPortEnableStatus();

    if((u8PortEnStatus & BIT0) == BIT0)
    {
        MApp_UsbSaveData_SetPort(BIT0);
    }
    else if((u8PortEnStatus & BIT1) == BIT1)
    {
        MApp_UsbSaveData_SetPort(BIT1);
    }
    else
    {
        EE_LOAD(printf("Error> Unknown USB port\n"));
		printf("Error> Unknown USB port\n");
        return;
    }
	printf("USBDeviceDetectFlag333 = %d\n",USBDeviceDetectFlag);

    if (!MApp_UsbSaveData_InitFileSystem())
    {
        MApp_UsbSaveData_Exit();
		EE_LOAD(printf("Exit"));
		printf("Exit");
        return ;
    }

#if (WATCH_DOG == ENABLE)
    msAPI_Timer_ResetWDT();
#endif

	U8 u8HandleNo;
    U8 u8FileName[40] = SW_DATABASE;
    U16 u16FileName[20];

    // step 1  setup environment
    if(MApp_UsbSaveData_SearchFileInRoot((U8 *)u8FileName, &g_fileEntry))
    {
        msAPI_FCtrl_FileDelete(&g_fileEntry);
        EE_LOAD(printf("Found and Deleted\n"));
		printf("Found and Deleted\n");
    }
    else
    {
        EE_LOAD(printf("Not Found\n"));
		printf("Not Found\n");
    }

    // step 2
	ASCIItoUnicode2((S8*)u8FileName, strlen((char *)u8FileName));

    memset(u16FileName, 0, sizeof(u16FileName));

    memcpy(u16FileName, u8FileName, sizeof(u16FileName));

	u8HandleNo = MApp_UsbSaveData_OpenNewFileForWrite((U16 *)u16FileName, UnicodeLen((S8*)u16FileName));

	EE_LOAD(printf("OpenForWrite Passed\n"));
	printf("OpenForWrite Passed\n");

    EE_LOAD(printf("HandleNo is 0x%x\n",u8HandleNo));
	printf("HandleNo is 0x%x\n",u8HandleNo);
    if(u8HandleNo != FCTRL_INVALID_FILE_HANDLE)
    {
        MApp_SaveGenSetting();      //General setting

        MApp_DB_LoadChDataBase();   //Channel list

        EE_LOAD(printf("start  write\n"));
		printf("start  write\n");
        msAPI_FCtrl_FileWrite(u8HandleNo, DRAM_GEN_DB_START((DATABASE_START_MEMORY_TYPE & MIU1) ? (DATABASE_START_ADR | MIU_INTERVAL) : (DATABASE_START_ADR)), DATABASE_START_LEN);

        EE_LOAD(printf("Save to file: msAPI_FCtrl_FileClose\n"));
		printf("Save to file: msAPI_FCtrl_FileClose\n");
        msAPI_FCtrl_FileClose(u8HandleNo);
    }
}

void MApp_RestoreDatabase(void)//usb clone :usb to tv
{
    U8  USBDeviceDetect=0;                        //cus_xm zhihe modify for  usb clone 20120820
    USBDeviceDetectFlag = TRUE;
    while (!MDrv_UsbDeviceConnect())
    {
        EE_LOAD(printf("\n init USB__fail \n"));
		printf("\n init USB__fail \n");
		USBDeviceDetect++;
		if(USBDeviceDetect>20)
			{
				USBDeviceDetectFlag = FALSE;   //show error message box's flag
				return;
			}
    }

    U8 u8PortEnStatus = MDrv_USBGetPortEnableStatus();

    if ((u8PortEnStatus & BIT0) == BIT0)
    {
        MApp_UsbSaveData_SetPort(BIT0);
    }
    else if((u8PortEnStatus & BIT1) == BIT1)
    {
        MApp_UsbSaveData_SetPort(BIT1);
    }
    else
    {
        EE_LOAD(printf("Error> Unknown USB port\n"));
        return;
    }
	printf("USBDeviceDetectFlag444 = %d\n",USBDeviceDetectFlag);
    if (!MApp_UsbSaveData_InitFileSystem())
    {
        MApp_UsbSaveData_Exit();
		EE_LOAD(printf("Exit"));
		printf("Exit");
        return ;
    }

   	U8 u8HandleNo;
    U8 u8FileName[20] = SW_DATABASE;

  	if (MApp_UsbSaveData_SearchFileInRoot((U8 *)u8FileName, &g_fileEntry))
	{
		u8HandleNo = msAPI_FCtrl_FileOpen(&g_fileEntry, OPEN_MODE_FOR_READ);

        if(u8HandleNo != FCTRL_INVALID_FILE_HANDLE)
        {
    		EE_LOAD(printf("current file is exist\r\n"));
            printf("current file is exist\r\n");
            msAPI_FCtrl_FileRead(u8HandleNo, DRAM_GEN_DB_START((DATABASE_START_MEMORY_TYPE & MIU1) ? (DATABASE_START_ADR | MIU_INTERVAL) : (DATABASE_START_ADR)), DATABASE_START_LEN);

            EE_LOAD( printf("Close file: msAPI_FCtrl_FileClose\n") );
			printf("current file is exist\r\n");
            msAPI_FCtrl_FileClose(u8HandleNo);
        }
        else
        {
            EE_LOAD(printf("Open file fail\n"));
			printf("Open file fail\n");
    		return;
        }
	}
	else
	{
		EE_LOAD(printf("database file is not exist\r\n"));
		printf("database file is not exist\r\n");
		return;
	}

    //store to flash immediately
#if (EEPROM_DB_STORAGE == EEPROM_SAVE_NONE)
   _MApp_CopyDB2GenSetting();//read gensetting database

#if GENSETTING_STORE_USE_NEW_METHOD
    msAPI_Flash_EraseGensettingBank();
#else
    if (g_u16QuickGenSettingIdx == (QUICK_DB_GENST_NUM - 1))
    {
        msAPI_MIU_QuickGenSettingErase(QUICK_DB_GENSETTING_BANK, TRUE);
        msAPI_MIU_QuickGenSettingErase(QUICK_DB_GENSETTING_BANK+1, FALSE);
        g_u16QuickGenSettingIdx = 0;
    }
#endif

    MApp_DB_SaveGenSetting();

    MApp_DB_SaveDataBase();//save system database and SerialNumber
	
#endif

    while(msAPI_MIU_QuickDataBaseCheck() != TRUE);

    MApp_CheckFlash();//load country setting in database 

    msAPI_BLoader_Reboot();//restart TV
}

#endif

#undef MAPP_SAVEDATA_C

