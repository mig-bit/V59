////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////////////////
///
/// file   apiXC_Sys.h
/// @brief  Scaler API layer Interface
/// @author MStar Semiconductor Inc.
///////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef _API_XC_SYS_H_
#define _API_XC_SYS_H_

#ifdef _API_XC_SYS_C_
#define INTERFACE
#else
#define INTERFACE extern
#endif

#include "drvTVEncoder.h"
//-------------------------------------------------------------------------------------------------
//  Include Files
//-------------------------------------------------------------------------------------------------

//-------------------------------------------------------------------------------------------------
//  Macro and Define
//-------------------------------------------------------------------------------------------------
INTERFACE BOOLEAN g_bEnableDLC;
INTERFACE MS_U16 U16PQSrcType;

#define HDMI_HPD_DELAY                  (700)
#define INVALID_PQ_SRC_TYPE             (0xFFFF)
//-------------------------------------------------------------------------------------------------
//  Type and Structure
//-------------------------------------------------------------------------------------------------

/// PC ADC Mode setting type
typedef struct
{
    U8 u8ModeIndex;             ///< mode index

    // program
    U16 u16HorizontalStart;     ///< horizontal start
    U16 u16VerticalStart;       ///< vertical start
    U16 u16HorizontalTotal;     ///< ADC horizontal total
    U16 u16Phase;                 ///< ADC phase
    U8 u8AutoSign;              ///< Already after auto tuned or not

    // from mode table
    U8 u8Resolution;
    U16 u16DefaultHStart;       ///< default horizontal start
    U16 u16DefaultVStart;       ///< default Vertical start
    U16 u16DefaultHTotal;       ///< default horizontal total
    U8 u8SyncStatus;            ///< sync status
}MS_PCADC_MODESETTING_TYPE;

INTERFACE MS_PCADC_MODESETTING_TYPE g_PcadcModeSetting[MAX_WINDOW];
INTERFACE U8 g_u8PcUserModeRamIndex[MAX_WINDOW];

// For ScreenMute
typedef enum
{
    E_SCREEN_MUTE_INIT,

    E_SCREEN_MUTE_TEMPORARY = BIT0,

    E_SCREEN_MUTE_RATING =  BIT1,
    E_SCREEN_MUTE_FREERUN = BIT2,
    E_SCREEN_MUTE_CHANNEL = BIT3,
    E_SCREEN_MUTE_BLOCK =   BIT4,
    E_SCREEN_MUTE_MHEG5 =   BIT5,

    E_SCREEN_MUTE_INPUT =   BIT6,       ///< lock some input such as change to AV always mute

    E_SCREEN_MUTE_PERMANENT = (E_SCREEN_MUTE_RATING | E_SCREEN_MUTE_FREERUN | E_SCREEN_MUTE_CHANNEL | E_SCREEN_MUTE_BLOCK | E_SCREEN_MUTE_MHEG5 | E_SCREEN_MUTE_INPUT),
}E_SCREEN_MUTE_STATUS;

/// White Pattern Color
typedef enum
{
    TEST_COLOR_OFF,         ///< OFF
    TEST_COLOR_WHITE,       ///< White
    TEST_COLOR_RED,         ///< Red
    TEST_COLOR_GREEN,       ///< Green
    TEST_COLOR_BLUE,        ///< Blue
    TEST_COLOR_BLACK,       ///< Black
    //TEST_COLOR_PATT,
    TEST_COLOR_NUM,         ///< Color pattern Number
} EN_TEST_COLOR;

typedef enum
{
    E_VE_MUTE_INIT  = 0x00,
    E_VE_MUTE_GEN   = 0x01,        // mute VE for general purpose
    E_VE_MUTE_BLOCK = 0x02,        // mute VE for block
    E_VE_MUTE_RATING = 0x04,       // mute VE for rating
    E_VE_MUTE_CI_PLUS = 0x08,      // mute VE for CI+
    E_VE_MUTE_INVALID = 0xFF,      // Invalid VE mute state for init
}E_VE_MUTE_STATUS;

typedef enum
{
    E_XC_PQ_3D_NR_OFF,
    E_XC_PQ_3D_NR_LOW,
    E_XC_PQ_3D_NR_MID,
    E_XC_PQ_3D_NR_HIGH,
    E_XC_PQ_3D_NR_AUTO,
    E_XC_PQ_3D_NR_DEFAULT,
    E_XC_PQ_3D_NR_NUM = E_XC_PQ_3D_NR_AUTO,
}E_XC_PQ_3D_NR;

#ifdef MSOS_TYPE_LINUX
typedef struct
{
    U16 PanelHStart;
    U16 PanelWidth;
    U16 PanelHeight;
}DBUS_XC_INFO;

typedef enum
{
    E_OBAMA_XC_REDUCE_BW_FOR_OSD, //signal
            // Input Parameters:
            //   --pu8Msg[0]: E_OBAMA_XC_REDUCE_BW_FOR_OSD
            //   --pu8Msg[1]: subwin or mainwin
            //   --pu8Msg[2]: OSD on or off
    E_OBAMA_XC_PANEL_INFO, //signal
}E_OBAMA_XC_MSG_TYPE;
#endif

typedef enum
{
    E_DAC_RES_720x480I_60Hz = 0,
    E_DAC_RES_720x480P_60Hz,
    E_DAC_RES_720x576I_50Hz,
    E_DAC_RES_720x576P_50Hz,
    E_DAC_RES_1280x720P_50Hz,
    E_DAC_RES_1280x720P_60Hz,
    E_DAC_RES_1920x1080I_50Hz,
    E_DAC_RES_1920x1080I_60Hz,
    E_DAC_RES_1920x1080P_50Hz,
    E_DAC_RES_1920x1080P_60Hz,
}E_DAC_OUTPUT_TIMING_TYPE;



#if ENABLE_DBC

typedef enum
{
    DCR_FINETUNE_BRIGHTNESS,
    DCR_FINETUNE_CONTRAST
} EN_DCR_FINETUNE_ITEM;

  #ifndef DCR_CONTRAST_HDMI1
    #define DCR_CONTRAST_HDMI1      0x80
  #endif
  #ifndef DCR_BRIGHTNESS_HDMI1
    #define DCR_BRIGHTNESS_HDMI1    0x80
  #endif
  #ifndef DCR_CONTRAST_DTV
    #define DCR_CONTRAST_DTV        0x80
  #endif
  #ifndef DCR_BRIGHTNESS_DTV
    #define DCR_BRIGHTNESS_DTV      0x80
  #endif
  #ifndef DCR_CONTRAST_VGA
    #define DCR_CONTRAST_VGA        0x80
  #endif
  #ifndef DCR_BRIGHTNESS_VGA
    #define DCR_BRIGHTNESS_VGA      0x80
  #endif
  #ifndef DCR_CONTRAST_YPBPR
    #define DCR_CONTRAST_YPBPR      0x80
  #endif
  #ifndef DCR_BRIGHTNESS_YPBPR
    #define DCR_BRIGHTNESS_YPBPR    0x80
  #endif
  #ifndef DCR_CONTRAST_TV
    #define DCR_CONTRAST_TV         0x80
  #endif
  #ifndef DCR_BRIGHTNESS_TV
    #define DCR_BRIGHTNESS_TV       0x80
  #endif
  #ifndef DCR_CONTRAST_CVBS
    #define DCR_CONTRAST_CVBS       0x80
  #endif
  #ifndef DCR_BRIGHTNESS_CVBS
    #define DCR_BRIGHTNESS_CVBS     0x80
  #endif
  #ifndef DCR_CONTRAST_SVIDEO
    #define DCR_CONTRAST_SVIDEO     0x80
  #endif
  #ifndef DCR_BRIGHTNESS_SVIDEO
    #define DCR_BRIGHTNESS_SVIDEO   0x80
  #endif



#define DBC_MAX_VIDEO_DBC          55     // 0 ~ 255
#define DBC_MID_VIDEO_DBC          30     // 0 ~ 255
#define DBC_MIN_VIDEO_DBC          10     // 0 ~ 255
#define DBC_MAX_PWM                254    // 0 ~ 255
#define DBC_BACKLIGHT_THRES        66     // % percentage, 0 ~ 100
#define DBC_MIN_PWM                0      // 0 ~ 255
//#define DBC_Y_GAIN_H               0x40   // Hex: 0x00 ~ 0x7F, default: 0x40
#define DBC_Y_GAIN_M               0x48   // Hex: 0x00 ~ 0x7F, default: 0x40
#define DBC_Y_GAIN_L               0x50   // Hex: 0x00 ~ 0x7F, default: 0x40
//#define DBC_C_GAIN_H               0x40   // Hex: 0x00 ~ 0x7F, default: 0x40
#define DBC_C_GAIN_M               0x48   // Hex: 0x00 ~ 0x7F, default: 0x40
#define DBC_C_GAIN_L               0x50   // Hex: 0x00 ~ 0x7F, default: 0x40
#define DBC_ALPHA_BLENDING_CURRENT 60     // 0 ~ 100
#define DBC_AVG_DELTA              8      // 0 ~ 30
#define DBC_FAST_ALPHABLENDING     32     // 1 ~ 32
#define DBC_LOOP_DLY_H             4      // 0 ~ 30
#define DBC_LOOP_DLY_MH            6      // 0 ~ 30
#define DBC_LOOP_DLY_ML            2      // 0 ~ 30
#define DBC_LOOP_DLY_L             2      // 0 ~ 30

#endif

//-------------------------------------------------------------------------------------------------
//  Function and Variable
//-------------------------------------------------------------------------------------------------
INTERFACE BOOL g_bIsUsingTconTable;
INTERFACE BOOL g_bIsGammaSettingBySW;
INTERFACE BOOL g_bPcSelfAutoDone;

// Init
INTERFACE void MApi_XC_Sys_Init(void);
INTERFACE void MApi_XC_Sys_HDMI_Init(void);

#ifdef MSOS_TYPE_LINUX
INTERFACE BOOLEAN MApi_XC_DBUS_ReceiveMsg(unsigned char * pu8Msg, unsigned short u16DataSize, unsigned char * pu8OutData, unsigned short u16OutDataSize);
#endif

// Blue screen & screen mute
#ifdef ATSC_SYSTEM
#define DEFAULT_SCREEN_UNMUTE_TIME  (300)
#else
#define DEFAULT_SCREEN_UNMUTE_TIME  (200)
#endif

#if (ENABLE_SW_CH_FREEZE_SCREEN)
#define DEFAULT_SCREEN_FREEZE_TIME  (1200)
INTERFACE void msAPI_Scaler_SetFreezeScreen( BOOLEAN bEnable, U16 u16ScreenUnMuteTime, SCALER_WIN eWindow);
#endif

/******************************************************************************/
///-This function will enable/diable free run screen
///@param bEnable \b IN: enable/disable blue screen
///-False: Disable
///-TRUE: Enable
///@param u8Color \b IN: the color setting
///-  0: Black
///-  1: White
///-  2: Blue
/******************************************************************************/
#define DEBUG_BLUE_SCREEN_CALLED   0

#if( DEBUG_BLUE_SCREEN_CALLED )
INTERFACE void msAPI_Scaler_SetBlueScreen2( BOOLEAN bEnable, U8 u8Color, U16 u16ScreenUnmuteTime, SCALER_WIN eWindow);
#define msAPI_Scaler_SetBlueScreen(  bEnable, u8Color, u16ScreenUnmuteTime, eWindow)   do { \
    printf("%s %u Call SetBlueScreen()\n", __FUNCTION__, __LINE__); \
    msAPI_Scaler_SetBlueScreen2(  bEnable, u8Color, u16ScreenUnmuteTime, eWindow);  \
} while(0)
#else
INTERFACE void msAPI_Scaler_SetBlueScreen( BOOLEAN bEnable, U8 u8Color, U16 u16ScreenUnmuteTime, SCALER_WIN eWindow);
#endif
INTERFACE void msAPI_Scaler_SetBlueScreen_Origin( BOOLEAN bEnable, U8 u8Color, U16 u16ScreenUnMuteTime, SCALER_WIN eWindow);


INTERFACE E_SCREEN_MUTE_STATUS msAPI_Scaler_GetScreenMute( SCALER_WIN eWindow);
INTERFACE BOOLEAN msAPI_Scaler_SetScreenMuteStatus( SCALER_WIN eWindow,E_SCREEN_MUTE_STATUS eScreenMuteStatus);



#define DEBUG_SCREEN_MUTE_CALLED    0

#if( DEBUG_SCREEN_MUTE_CALLED )
INTERFACE void msAPI_Scaler_SetScreenMute2(E_SCREEN_MUTE_STATUS eScreenMute, BOOLEAN bMuteEnable, U16 u161ms, SCALER_WIN eWindow);
#define msAPI_Scaler_SetScreenMute( eScreenMute,  bMuteEnable,  u161ms,  eWindow)   do { \
    printf("%s %u Call SetScreenMute()\n", __FUNCTION__, __LINE__); \
    msAPI_Scaler_SetScreenMute2( eScreenMute,  bMuteEnable,  u161ms,  eWindow);  \
} while(0)
#else
INTERFACE void msAPI_Scaler_SetScreenMute(E_SCREEN_MUTE_STATUS eScreenMute, BOOLEAN bMuteEnable, U16 u161ms, SCALER_WIN eWindow);
#endif

// White Pattern
/******************************************************************************/
/// -This function will set output test pattern
/// @param enColorOfPattern \b IN: Color pattern
/// - @see EN_TEST_COLOR
/// @param enInputSourceType \b IN: Indicate what's the current input source
/// - @see INPUT_SOURCE_TYPE_t
/// @param enVideoScreen \b IN: Carry the aspect ratio info
/// - @see EN_ASPECT_RATIO_TYPE
/******************************************************************************/
INTERFACE void msAPI_Scaler_SetTestPattern(INPUT_SOURCE_TYPE_t enInputSourceType, EN_TEST_COLOR enColorOfPattern);
INTERFACE void msAPI_Scaler_SetTestPattern_For_CUS_AgainMode(INPUT_SOURCE_TYPE_t enInputSourceType, EN_TEST_COLOR enColorOfPattern);
INTERFACE void msAPI_Scaler_SetTestPatternBysRGB(INPUT_SOURCE_TYPE_t enInputSourceType, BOOLEAN bOnoff,U8 u8R,U8 u8G,U8 u8B);

// Position Control
/******************************************************************************/
///-Set H position for PC mode
///@param u16Position \b IN
///- H position
/******************************************************************************/
INTERFACE void MApi_XC_Set_PC_HPosition( U16 u16HPosition , SCALER_WIN eWindow);

/******************************************************************************/
///-Set H position for PC mode
///@param u16Position \b IN
///- V position
/******************************************************************************/
INTERFACE void MApi_XC_Set_PC_VPosition( U16 u16VPosition , SCALER_WIN eWindow);

/******************************************************************************/
///-Set V position for Ypbpr mode
///@param u16PrePosition \b IN
///@param u16NewPosition \b IN
///- V position
/******************************************************************************/
INTERFACE void MApi_XC_Set_Ypbpr_VPosition(U16 u16PrePosition, U16 u16NewPosition , SCALER_WIN eWindow);

/******************************************************************************/
///-Set H position for Ypbpr mode
///@param u16PrePosition \b IN
///@param u16NewPosition \b IN
///- H position
/******************************************************************************/
INTERFACE void MApi_XC_Set_Ypbpr_HPosition(U16 u16PrePosition, U16 u16NewPosition , SCALER_WIN eWindow);

// others
INTERFACE void msAPI_Scaler_SetSourceType(INPUT_SOURCE_TYPE_t enInputSourceType , SCALER_WIN eWindow);
INTERFACE void msAPI_ScalerFront_Init(void);

INTERFACE void msAPI_Scaler_ProgAnalogInputPort(void);

#define msAPI_Scaler_GetVerticalTotal    MDrv_SC_ip_get_verticaltotal
INTERFACE U16 msAPI_Scaler_GetVerticalTotal(SCALER_WIN eWindow);

// Recommend to use below API interface for VE HW related control NOT the MDrvxxx functions in AP layer.
// The purpose is to limit the VE HW functions under the control of MACRO 'ENABLE_VE'
INTERFACE void msAPI_Scaler_SetVE(INPUT_SOURCE_TYPE_t src,E_DEST_TYPE enOutputType);
INTERFACE void msAPI_Scaler_SetCVBSMute(BOOLEAN bEn , E_VE_MUTE_STATUS eMuteStatus, INPUT_SOURCE_TYPE_t enInputPortType,E_DEST_TYPE OutputPortType);
INTERFACE MS_BOOL msAPI_Scaler_ForceVE_BlackOutPut(MS_BOOL bEnable, INPUT_SOURCE_TYPE_t src, E_DEST_TYPE enOutputType, MS_VE_VIDEOSYS VideoSystem);
INTERFACE void msAPI_Scaler_SetAFDToVEWSS(BOOLEAN bEn, U8 u8AFD, U8 u8SrcARC);

INTERFACE void msAPI_VE_SetTtxBuffer(MS_U32 u32StartAddr, MS_U32 u32Size);
INTERFACE void msAPI_VE_SetOutputCtrl(PMS_VE_Output_Ctrl pOutputCtrl);
INTERFACE void msAPI_VE_SetBlackScreen(MS_BOOL bEn);
INTERFACE MS_BOOL msAPI_VE_GetTtxReadDoneStatus(void);
INTERFACE void msAPI_VE_Exit(void);

INTERFACE void msAPI_Scaler_IPAutoCoastHandler(void);

// Source is HD/SD
INTERFACE void MApi_XC_Sys_SetSrcIsHD(MS_BOOL bIsHd, SCALER_WIN eWindow);
INTERFACE MS_BOOL MApi_XC_Sys_IsSrcHD(SCALER_WIN eWindow);

INTERFACE void  MApi_XC_Sys_HDMI_Init(void);
INTERFACE void  MApi_XC_Sys_HDMI_PowerOff(void);
INTERFACE void  MApi_XC_Sys_SetHPD( MS_BOOL bEnable, E_MUX_INPUTPORT enInputPortType );
INTERFACE void  MApi_XC_Sys_Do_HPD(INPUT_SOURCE_TYPE_t enInputSourceType);
INTERFACE void MApi_XC_Sys_SetHPD_ALL( MS_BOOL bEnable);

INTERFACE void  MApi_XC_Sys_Periodic_Handler(SCALER_WIN eWindow, MS_BOOL bRealTimeMonitorOnly);
INTERFACE void  MApi_XC_Sys_PQ_SetNR(E_XC_PQ_3D_NR en3DNRType, SCALER_WIN eWindow);


// ACE related
INTERFACE void  MApi_XC_Sys_ACE_PatchDTGColorChecker(MS_U8 u8Mode);
#if ENABLE_PRECISE_RGBBRIGHTNESS
INTERFACE MS_U16 MApi_XC_Sys_ACE_transferRGB_Bri(MS_U16 u16Brightness, MS_U8 u8Brightnesstype);
#else
INTERFACE MS_U8 MApi_XC_Sys_ACE_transferRGB_Bri(MS_U8 u8Brightness, MS_U8 u8Brightnesstype);
#endif
INTERFACE MS_U8 MApi_XC_Sys_ACE_transfer_Bri(MS_U8 u8Brightness, MS_U8 u8Brightnesstype);

// DLC related
#if ENABLE_DBC
INTERFACE void MApi_XC_Sys_DLC_DBC_OnOff(MS_BOOL bEnable);
INTERFACE void MApi_XC_Sys_DLC_DBC_Handler(void);
INTERFACE void MApi_XC_Sys_DLC_DBC_YCGainInit(void);
#elif (ENABLE_CUS_DBC)
INTERFACE void MApi_XC_Sys_DLC_DBC_OnOff(void);
INTERFACE void MApi_XC_Sys_DLC_DBC_Handler(void);
INTERFACE void MApi_XC_Sys_DLC_DBC_YCGainInit(void);
#endif

// DAC related
INTERFACE void msAPI_Scaler_ChangePanelType(E_DAC_OUTPUT_TIMING_TYPE eTiming);
INTERFACE void msAPI_Scaler_SetDacOutputMode(E_DAC_OUTPUT_TIMING_TYPE eTiming);

//wrapper for PQ reduce BW
INTERFACE void MApi_XC_Sys_PQ_ReduceBW_ForOSD(MS_U8 PqWin, MS_BOOL bOSD_On);

#if 0//( ENABLE_FRC_R2 )
void msAPI_XC_SendMailToFRC( U8 u8Cmd, U8 count, U8 p1, U8 p2, U8 p3, U8 p4, U8 p5, U8 p6, U8 p7, U8 p8);
#define SEND_CMD_TO_FRC__0P(cmd)    msAPI_XC_SendMailToFRC(cmd, 0,    0, 0, 0, 0, 0, 0, 0, 0)
#define SEND_CMD_TO_FRC__1P(cmd,p1) msAPI_XC_SendMailToFRC(cmd, 1, (p1), 0, 0, 0, 0, 0, 0, 0)
#endif


///////////////////////////////////////////////////////////////////////////////////////////////////
#if 1
typedef enum
{
    E_PANEL_DIR_LEFT_RIGHT__UP_DOWN,
    E_PANEL_DIR_RIGHT_LEFT__UP_DOWN,
    E_PANEL_DIR_LEFT_RIGHT__DOWN_UP,
    E_PANEL_DIR_RIGHT_LEFT__DOWN_UP,
}EnuPanelDirection;
INTERFACE void MApi_XC_TCON_Panel_SetPanelDirection( EnuPanelDirection panelDirection );
#endif
void MApi_TCON_PNL_POWER_ENABLE(void);
#ifdef ENABLE_CUS_DBC
INTERFACE U8  	g_ucDBCTimer;
INTERFACE U32 	g_u32DBCTimer;
INTERFACE U8 	g_ucAverageLumaValue;

INTERFACE void MApi_XC_Sys_DBCInit(void);
INTERFACE void MApi_XC_Sys_DBCHandler(void);
#endif
#if ENABLE_CUS_RS232_FUNC
INTERFACE U8 MApi_XC_Sys_GetEDIDdata(INPUT_SOURCE_TYPE_t enInputSourceType, U8 offset);
#endif
#ifdef ENABLE_GAMMA_FOR_COLORTEMP
INTERFACE BOOLEAN MApi_XC_Sys_AdjustGammaTbl(BOOLEAN bIsForceSetGamma);
#endif
#if (ENABLE_CUS_9WINDOWS_DETECT && ENABLE_CUS_DBC)
INTERFACE void MApi_XC_Sys_Detect_9Windows_Handler(void);
INTERFACE BOOLEAN  MApi_XC_Sys_bIsVideoPattern9Windows(void);
INTERFACE void MApi_XC_Sys_SetVideoPattern9WindowsFlag(BOOLEAN bIsTrue);
#endif

///////////////////////////////////////////////////////////////////////////////////////////////////

#undef INTERFACE
#endif  // _API_XC_SYS_H_
