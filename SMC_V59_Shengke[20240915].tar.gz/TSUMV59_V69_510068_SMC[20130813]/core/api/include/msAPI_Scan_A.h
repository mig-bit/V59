#ifndef MSAPI_SCAN_A_H
#define MSAPI_SCAN_A_H

//==============================================================================
/*                     Macro                                                    */
//==============================================================================

#ifdef MSAPI_TUNER_A_C
#define INTERFACE
#else
#define INTERFACE extern
#endif

typedef enum
{
    STATE_NTSC_SCAN_INIT,
    STATE_NTSC_JUMP,
    STATE_NTSC_CHECK_LOCK,
} EN_NTSC_SCAN_STATE;

typedef enum
{
    STATE_VSB_SCAN_INIT,
    STATE_VSB_INIT_DEMODE,
    STATE_VSB_CHECK_LOCK,
} EN_VSB_SCAN_STATE;

typedef enum
{
    STATE_QAM_SCAN_INIT,
    STATE_QAM_INIT_DEMODE,
    STATE_QAM_CHECK_LOCK,
} EN_QAM_SCAN_STATE;

typedef enum
{
    SCAN_ANT_CATV,
    SCAN_ANT_AIR,
    SCAN_ANT_TYPE_NUM
} EN_SCAN_ANT_TYPE;

INTERFACE void msAPI_SCAN_Init(void);
INTERFACE EN_SCAN_RESULT msAPI_NTSC_Scan(MS_TP_SETTING *pstTPSetting, U8 CurRFCh, EN_SCAN_ANT_TYPE CurChType);
INTERFACE EN_SCAN_RESULT msAPI_VSB_Scan( MS_TP_SETTING *pstTPSetting );
INTERFACE EN_SCAN_RESULT msAPI_QAM_Scan(MS_TP_SETTING *pstTPSetting);
INTERFACE S16 msAPI_ScanGetFreqByZigZagPoint(EN_DEMOD_MODE Modulation, U8 ZigZagPt, U8 CurRF);
INTERFACE BOOL msAPI_InNTSC_FreqOffset_Range(S16 freq_offset, U8 CurRF);

#undef INTERFACE

#endif /* MSAPI_SCAN_H */
