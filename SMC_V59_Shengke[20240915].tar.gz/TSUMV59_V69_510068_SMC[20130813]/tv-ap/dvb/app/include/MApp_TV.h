////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef MAPP_TV_H
#define MAPP_TV_H

#include "datatype.h"
#include "MApp_Exit.h"
#include "MApp_GlobalVar.h"

#ifdef MAPP_TV_C
#define INTERFACE
#else
#define INTERFACE extern
#endif

// TV states
typedef enum
{
    STATE_TV_INIT,
    STATE_TV_WAIT,
    // STATE_TV_CHANNEL_LIST,
    // STATE_TV_NINE_LATTICE,
    STATE_TV_SOURCE,
    STATE_TV_CARDREADER,
} EN_TV_STATE;

#if ENABLE_SBTVD_BRAZIL_APP
typedef enum
{
    MAJOR_CH_NUM,
    MINOR_CH_NUM
} EN_LCN_TYPE;
#endif

#ifdef ENABLE_SELECT_NONESEARCH_CH
  #define IVALID_TV_RETURN_NUM    0xFFFF
  INTERFACE U16 u16ChannelReturn_Num1;
  INTERFACE U16 u16ChannelReturn_Num2;
#endif

INTERFACE EN_RET MApp_TV(void);
INTERFACE void MApp_TV_NumWinProcDigitKey(U8 bKeyValue);
INTERFACE void MApp_TV_Force2MonitorIdleModeWindows(void);
INTERFACE void MApp_TV_Initial_IdleCount(void);
INTERFACE BOOLEAN MApp_TV_MHEG_Loading_Monitor(void);
INTERFACE void MApp_TV_DSMCC_Trigger_Monitor(void);
INTERFACE void MApp_TV_ExitAndGotoMenuState(void);
INTERFACE void MApp_TV_ClearCIFlag(void);
INTERFACE U16 MApp_TV_NumWinVerifyInputValue(U16 u16Value);
INTERFACE BOOLEAN MApp_TV_SelectSubtileLang(void);

INTERFACE U16 u16IdleInputValue;
#if ENABLE_SBTVD_BRAZIL_APP
INTERFACE U8 u8IdleMajorValue;
INTERFACE U8 u8IdleMinorValue;
INTERFACE EN_LCN_TYPE enLCNTypeVerified;
#endif
INTERFACE U8 u8IdleDigitCount;
INTERFACE U8 u8MaxDigiKeyNum;
INTERFACE U32 u32NumChannChangeTimer;

INTERFACE void MApp_TV_ProcessInstallWizard(void);

//////////////////////////////////////////////////////////
//ZUI: idle mode key process functions
INTERFACE BOOLEAN MApp_TV_ProcessAudioVolumeKey(U8 key);
INTERFACE BOOLEAN MApp_TV_ProcessChannelInfoKey(U8 key);
INTERFACE BOOLEAN MApp_TV_ProcessMessageBoxKey(U8 key);
INTERFACE BOOLEAN MApp_TV_ProcessHotkeyOptionKey(U8 key);

//////////////////////////////////////////////////////////
//ZUI: moved from MApp_UiMenu2.c
INTERFACE BOOLEAN MApp_TV_ScreenSaverClear(SCALER_WIN eWindow);
INTERFACE BOOLEAN MApp_TV_IsProgramRunning(void);
#if (ENABLE_UPDATE_MULTIPLEX_VIA_NIT)
INTERFACE void MApp_TV_SetCheckAlternativeFlag(BOOLEAN bFlag);
INTERFACE BOOLEAN MApp_TV_GetCheckAlternativeFlag(void);
INTERFACE BOOLEAN MApp_TV_CheckLossSignal30Days(void);
#endif
INTERFACE BOOLEAN MApp_Get_CheckParentalPWStatus(void);
INTERFACE void MApp_Set_CheckParentalPWStatus(BOOLEAN bStatus);
#undef INTERFACE

#endif
