////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MAPP_ZUI_ACTTHUNDER_H
#define _MAPP_ZUI_ACTTHUNDER_H

#if 1//(ENABLE_THUNDER_DOWNLOAD)
#include "MApp_ZUI_APIgdi.h"

#ifdef MAPP_ZUI_ACTTHUNDER_C
#define INTERFACE
#else
#define INTERFACE extern
#endif

#define NUM_OF_IME_CHARS_PER_PAGE     8
#define NUM_OF_SEARCH_STRING     64


typedef enum
{
    TYPE_THUNDER_TORRENT_SEARCH,
    TYPE_THUNDER_TOP_10,
    TYPE_THUNDER_NEW_10,
    TYPE_THUNDER_DOWNLOAD_LIST,
    TYPE_THUNDER_SETUP,
    TYPE_THUNDER_INVALID=0xFF,
} EN_THUNDER_PAGE_TYPE;


typedef enum
{
    IME_TYPE_ENGLISH,
    IME_TYPE_CHINESE,
    IME_TYPE_PINYIN,
    IME_TYPE_MAX,
} EN_IME_TYPE;

typedef enum
{
    KEYWORD_SEARCH_STATE_STEP1,
    KEYWORD_SEARCH_STATE_STEP2,
} EN_KEYWORD_SEARCH_STATE;


/// Specify the torrent Search IME.
typedef enum
{
    STATE_IME_NULL,
    STATE_IME_SPELL,
    STATE_IME_CHS,
    STATE_IME_SETP3,
} EN_IME_STATE;


typedef struct
{
    BOOLEAN bInputOK;
    EN_IME_TYPE uIME_Type;
    BOOLEAN bIsCAPs;
    EN_IME_STATE     uIME_State;
    U8     u8Char;
    U16     u16SpellCounter;
    U16     u16SpellStar;
    U16     u16CHS_Offset;
    U8 u8Sting[NUM_OF_IME_CHARS_PER_PAGE][7];
    U16 u16StringName[NUM_OF_SEARCH_STRING];    // file name
} _Thunder_IME;


/////////////////////////////////////////
#define MApp_ZUI_ACT_BTTopWinProc MApp_ZUI_ACT_ThunderTopWinProc
#define MApp_ZUI_ACT_BTLinkPhotoWinProc MApp_ZUI_ACT_ThunderTopWinProc
#define MApp_ZUI_ACT_BTDescriptionWinProc MApp_ZUI_ACT_ThunderDescriptionWinProc
#define MApp_ZUI_ACT_TerminateBT MApp_ZUI_ACT_TerminateThunder
#define MApp_ZUI_ACT_GetBTDynamicText MApp_ZUI_ACT_GetThunderDynamicText
#define MApp_ZUI_ACT_GetBTDynamicBitmap MApp_ZUI_ACT_GetThunderDynamicBitmap
#define MApp_ZUI_ACT_HandleBTKey MApp_ZUI_ACT_HandleThunderKey
#define MApp_ZUI_ACT_ExecuteBTAction MApp_ZUI_ACT_ExecuteThunderAction
#define MApp_ZUI_ACT_AppShowBT MApp_ZUI_ACT_AppShowThunder
//#define MApp_ZUI_ACT_GetBTDynamicText MApp_ZUI_ACT_GetThunderDynamicText
//#define MApp_ZUI_ACT_GetBTDynamicText MApp_ZUI_ACT_GetThunderDynamicText

/////////////////////////////////////////
// Event Handlers....
INTERFACE S32 MApp_ZUI_ACT_ThunderTopWinProc(HWND hwnd, PMSG msg);
INTERFACE S32 MApp_ZUI_ACT_ThunderLinkPhotoWinProc(HWND hwnd, PMSG msg);
INTERFACE S32 MApp_ZUI_ACT_ThunderDescriptionWinProc(HWND hWnd, PMSG pMsg);
INTERFACE void MApp_ZUI_ACT_TerminateThunder(void);
INTERFACE LPTSTR MApp_ZUI_ACT_GetThunderDynamicText(HWND hwnd);
INTERFACE U16 MApp_ZUI_ACT_GetThunderDynamicBitmap(HWND hwnd, DRAWSTYLE_TYPE ds_type);
INTERFACE BOOLEAN MApp_ZUI_ACT_HandleThunderKey(VIRTUAL_KEY_CODE key);
INTERFACE BOOLEAN MApp_ZUI_ACT_ExecuteThunderAction(U16 act);
INTERFACE void MApp_ZUI_ACT_AppShowThunder(void);
INTERFACE void MApp_Thunder_ClearTopOrNewListPhotoBG(U8 u8Item);
INTERFACE void MApp_ZUI_ACT_ThunderSystemErrorShow(void);
INTERFACE void MApp_ZUI_ACT_ThunderSystemErrorShowExit(void);



#undef INTERFACE

#endif // #if (ENABLE_THUNDER_DOWNLOAD)

#endif /* _MAPP_ZUI_ACTTHUNDER_H */


