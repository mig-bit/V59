////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MAPP_ZUI_ACTMAINPAGE_H
#define _MAPP_ZUI_ACTMAINPAGE_H

#ifdef __cplusplus
extern "C" {
#endif  /* __cplusplus */

#ifdef MAPP_ZUI_ACTMAINPAGE_C
#define INTERFACE
#else
#define INTERFACE extern
#endif
#if 1//(ENABLE_ATV_VCHIP)
typedef enum _VCHIP_PAGE_TYPE
{
    EN_VCHIP_MPAA,
    EN_VCHIP_CANADAENG,
    EN_VCHIP_CANADAFRE
}VCHIP_PAGE_TYPE;

INTERFACE U16 g_u16Password;
INTERFACE U16 g_u16PasswordTemp;
INTERFACE U8 g_u8PasswordCount;
INTERFACE U8 g_u8PasswordPosition;

INTERFACE VCHIP_PAGE_TYPE g_vchipPageType;
#endif

INTERFACE U8 g_u8IdleMainpageDigitKeyCount; // num. key count

#if (ENABLE_CUS_UI_SPEC == DISABLE)
INTERFACE E_UI_INPUT_SOURCE MApp_ZUI_ACT_GetAppItemSource(int APP);
INTERFACE U16 MApp_ZUI_ACT_GetAppItemString(int APP);
#endif

typedef enum _COMMON_DLG_MODE
{
    EN_COMMON_DLG_MODE_INVALID,
    EN_COMMON_DLG_MODE_FACTORY_RESET,
    EN_COMMON_DLG_MODE_FACTORY_RESET_CONFIRM,
    EN_COMMON_DLG_MODE_DIVX,
    EN_COMMON_DLG_MODE_DEACTIVATION,
    EN_COMMON_DLG_MODE_DEACTIVATION_CONFIRM,
    EN_COMMON_DLG_MODE_SCAN_INPUT_PASSWORD,
    EN_COMMON_DLG_MODE_DTV_TUNING_INPUT_PASSWORD,
    EN_COMMON_DLG_MODE_ATV_TUNING_INPUT_PASSWORD,
    EN_COMMON_DLG_MODE_FACTORY_RESET_INPUT_PASSWORD,
    EN_COMMON_DLG_MODE_WRONG_PASSWORD,
    EN_COMMON_DLG_MODE_MISMATCH_PASSWORD,
    EN_COMMON_DLG_MODE_INPUT_PASSWORD,
    EN_COMMON_DLG_MODE_SET_PASSWORD,
    EN_COMMON_DLG_MODE_USB_NOT_DETECTED,
    EN_COMMON_DLG_MODE_SW_FILE_NOT_DETECTED,
    EN_COMMON_DLG_MODE_USB_UPDATE_CONFIRM,
    EN_COMMON_DLG_MODE_USB_UPGRADING,
    EN_COMMON_DLG_MODE_CH_LIST_CLEAN_ALL_CONFIRM,
    EN_COMMON_DLG_MODE_ENTER_MENU_LOCK_PAGE_INPUT_PASSWORD,
    EN_COMMON_DLG_MODE_CHANNEL_INFO_SAVE_CHANGED,
    EN_COMMON_DLG_MODE_CLEAN_LOCK,
} COMMON_DLG_MODE;

#if (ENABLE_CUS_UI_SPEC == FALSE) /*Creass.liu at 2012-08-03*/
typedef enum _COMMON_SINGLELIST_MODE
{
    EN_COMMON_SINGLELIST_INVALID,
    EN_COMMON_SINGLELIST_ASPECT_RATIO,
    EN_COMMON_SINGLELIST_NOISE_REDUCTION,
    EN_COMMON_SINGLELIST_SURROUND_SOUND,
    EN_COMMON_SINGLELIST_SLEEP_TIMER,
    EN_COMMON_SINGLELIST_PARENTAL_GUIDANCE,
#if  (ATSC_CC == ATV_CC)
	EN_COMMON_SINGLELIST_CC_OPTION,
#endif
#if ENABLE_3D_PROCESS
    EN_COMMON_SINGLELIST_3D_OPTION,
#endif

#if 0//ENABLE_T_C_COMBO
    EN_COMMON_SINGLELIST_DVB_SELECT,
#endif
} COMMON_SINGLELIST_MODE;

typedef enum _COMMON_OPTIONLIST_MODE
{
    EN_COMMON_OPTIONLIST_INVALID,
    EN_COMMON_OPTIONLIST_NETWORK_DNS,
    EN_COMMON_OPTIONLIST_NETWORK_GW,
    EN_COMMON_OPTIONLIST_NETWORK_IP,
    EN_COMMON_OPTIONLIST_NETWORK_NETMASK,
    EN_COMMON_OPTIONLIST_NETWORK_CONFIG,
    EN_COMMON_OPTIONLIST_SOUND_SWITCH,
    EN_COMMON_OPTIONLIST_SOUND_BALANCE,
} COMMON_OPTIONLIST_MODE;
#endif

#ifdef NETWORK_CONFIG
typedef enum eNetwork
{
    HW_STATUS,
    INTRANET_STATUS,
    INTERNET_STATUS,
    DNS_STATUS,
}eNetwork_Mode;

BOOLEAN MApp_Check_Network(eNetwork_Mode eMode);
BOOLEAN MApp_UDHCPC_Reset(void);
BOOLEAN MApp_Check_IP_Status(void);
BOOLEAN MApp_Network_Config(void);

#endif
/////////////////////////////////////////
// Cutomize Window Procedures...

INTERFACE S32 MApp_ZUI_ACT_ButtonAniClickWinProc(HWND, PMSG);
INTERFACE S32 MApp_ZUI_ACT_TEXTHIDEWinProc(HWND hwnd, PMSG msg);
#define BUTTONANICLICK_WINPROC MApp_ZUI_ACT_ButtonAniClickWinProc
#define HIDEDYMECTEXT_WINDPROC MApp_ZUI_ACT_TEXTHIDEWinProc
INTERFACE S32 MApp_ZUI_ACT_ButtonAniClickChildWinProc(HWND, PMSG);
//INTERFACE S32 MApp_ZUI_ACT_Mainpage_DynamicListWinProc(HWND hWnd, PMSG pMsg);

#define BUTTONANICLICKCHILD_WINPROC MApp_ZUI_ACT_ButtonAniClickChildWinProc

/////////////////////////////////////////
// Event Handlers....
INTERFACE void MApp_ZUI_ACT_InitializeMainMenu(void);
INTERFACE void MApp_ZUI_ACT_AppShowMainMenu(void);
INTERFACE BOOLEAN MApp_ZUI_ACT_HandleMainPageKey(VIRTUAL_KEY_CODE key);
INTERFACE BOOLEAN MApp_ZUI_ACT_HotelModeHandleMainPageKey(VIRTUAL_KEY_CODE key);

INTERFACE void MApp_ZUI_ACT_TerminateMainMenu(void);
INTERFACE BOOLEAN MApp_ZUI_ACT_ExecuteMainMenuAction(U16 act);
INTERFACE LPTSTR MApp_ZUI_ACT_GetMainMenuDynamicText(HWND hwnd);
#if (ENABLE_CUS_UI_SPEC == FALSE) /*Creass.liu at 2012-08-03*/
INTERFACE LPTSTR MApp_ZUI_ACT_GetSingleListDynamicText(HWND hwnd);
INTERFACE LPTSTR MApp_ZUI_ACT_GetOptionListDynamicText(HWND hwnd);
INTERFACE COMMON_SINGLELIST_MODE MApp_ZUI_ACT_GetSingleListMode(void);
INTERFACE COMMON_OPTIONLIST_MODE MApp_ZUI_ACT_GetOptionListMode(void);
INTERFACE void MApp_ZUI_ACT_SetOptionListMode(COMMON_OPTIONLIST_MODE mode);
#endif
INTERFACE void MApp_ZUI_ACT_ShowMainMenuBackground(HWND hwnd);
#ifdef NETWORK_CONFIG
INTERFACE LPTSTR MApp_ZUI_ACT_GetNetworkDynamicText(HWND hwnd);
#endif
#if DVB_C_ENABLE
void MApp_ZUI_ACT_ShowDVBCScanPage(void);
#endif

#if 1//(ENABLE_ATV_VCHIP)
INTERFACE U16 MApp_ZUI_ACT_GetMainMenuDynamicBitmap(HWND hwnd, DRAWSTYLE_TYPE ds_type);
#endif
INTERFACE OSD_COLOR MApp_ZUI_ACT_GetMenuMainDynamicColor(HWND hwnd, DRAWSTYLE_TYPE type, OSD_COLOR colorOriginal);
INTERFACE HWND MApp_ZUI_ACT_Mainpage_ProgramEditIndexMapToWindow(U8 u8Index);
INTERFACE S16 MApp_ZUI_ACT_GetMenuDynamicValue(HWND hwnd); //cus_xm:zb add at 2012-7-17
#undef INTERFACE

#ifdef __cplusplus
}
#endif  /* __cplusplus */

#endif /* _MAPP_ZUI_ACTMAINPAGE_H */

