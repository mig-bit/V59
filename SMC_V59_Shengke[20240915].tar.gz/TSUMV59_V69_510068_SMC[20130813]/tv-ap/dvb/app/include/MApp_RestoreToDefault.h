////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef MAPP_RESTORETODEFAULT_H
#define MAPP_RESTORETODEFAULT_H

#include "MApp_GlobalSettingSt.h"
#include "cusModelSet.h"

//------------------------------------------------------------------------------
// Defines
//------------------------------------------------------------------------------
#define DEFAULT_DATABASE_VERSION                0x23//0x07
#define DEFAULT_DATABASE_VERSION_COM            0xF9//0xF3

#define DEFAULT_VCH_DATABASE_VERSION            0xAA58

#define DEFAULT_SCAN_SRV_TYPE                   FTA
#define DEFAULT_RF_CHANNEL                      CHAN_AIR_MIN
#define DEFAULT_CABLE_SYSTEM                    CABLE_SYSTEM_STD

#define DEFAULT_VOLUME_SETTING                  70//30//50// 20 //minglin1205
#define DEFAULT_BALANCE_SETTING                 50
#define DEFAULT_TIME_ZONE                       EN_D1_Clock_TimeZone_Eastern

#define DEFAULT_TIME_DST                        TIME_DST_OFF

#define DEFAULT_GENERAL_PASSWORD                0x00

#if (CUS_AUDIO_VOLUME_CURVE == AVC_8W_PIONEER_42) || (CUS_AUDIO_VOLUME_CURVE == AVC_10W_SMC_42)
#define DEFAULT_AUTO_VOLUME                     0x00 //0x01		// CUS_XM Sea 20120613: register 0X112D82
#else
#define DEFAULT_AUTO_VOLUME                     0x00
#endif


#define DEFAULT_ENABLE_CINEMA                   0x00    //Film Mode

////////////////////////////////////////////////////////////////////////////////
// default base date = 1980 Jan/1 00:00:00
#define DEFAULT_MJD                             44239 //51544
#define DEFAULT_YEAR                            2000 //smc.chy 2010/06/30 1980  //2000
#define DEFAULT_MONTH                           1
#define DEFAULT_DAY                             1
#define DEFAULT_HOUR                            0
#define DEFAULT_MIN                             0
#define DEFAULT_SEC                             0

////////////////////////////////////////////////////////////////////////////////

#define DEFAULT_OSD_DURATION                    OSD_DURATION_40_SEC
#define DEFAULT_INFO_DURATION                   INFO_DURATION_4_SEC

#define DEFAULT_TRANSPARENCY                    0

#if (ENABLE_DTMB_CHINA_APP || ENABLE_ATV_CHINA_APP || ENABLE_DVBC_PLUS_DTMB_CHINA_APP||CHINESE_SIMP_FONT_ENABLE ||CHINESE_BIG5_FONT_ENABLE)
#define DEFAULT_MENU_LANG                        LANGUAGE_ENGLISH//LANGUAGE_CHINESE
#else
#define DEFAULT_MENU_LANG                        LANGUAGE_ENGLISH
#endif
#define DEFAULT_SUB_LANG                        LANGUAGE_ENGLISH
#if (ENABLE_DVBC_PLUS_DTMB_CHINA_APP)
#define DEFAULT_TUNING_COUNTRY                  OSD_COUNTRY_CHINA
#elif (ENABLE_SBTVD_BRAZIL_APP)
#define DEFAULT_TUNING_COUNTRY                  OSD_COUNTRY_BRAZIL
#else
#define DEFAULT_TUNING_COUNTRY                  OSD_COUNTRY_UK
#endif

//#ifdef TV_SETTING//kitty0928
#define INIT_VEDIO_SDTV_BRI_STD                 50//00//50
#define INIT_VEDIO_SDTV_CON_STD                 50//33//50
#define INIT_VEDIO_SDTV_HUE_STD                 50
#define INIT_VEDIO_SDTV_SAT_STD                 50
#define INIT_VEDIO_SDTV_SHARP_STD               47

#define INIT_VEDIO_HDTV_BRI_STD                 50
#define INIT_VEDIO_HTDV_CON_STD                 50
#define INIT_VEDIO_HDTV_HUE_STD                 50
#define INIT_VEDIO_HDTV_SAT_STD                 50
#define INIT_VEDIO_HDTV_SHARP_STD               47

#define INIT_VEDIO_SDTV_BRI_MOVIE               50
#define INIT_VEDIO_SDTV_CON_MOVIE               40
#define INIT_VEDIO_SDTV_HUE_MOVIE               50
#define INIT_VEDIO_SDTV_SAT_MOVIE               30
#define INIT_VEDIO_SDTV_SHARP_MOVIE             20

#define INIT_VEDIO_HDTV_BRI_MOVIE               00//50
#define INIT_VEDIO_HTDV_CON_MOVIE               33//40
#define INIT_VEDIO_HDTV_HUE_MOVIE               50
#define INIT_VEDIO_HDTV_SAT_MOVIE               30
#define INIT_VEDIO_HDTV_SHARP_MOVIE             10//20

#define INIT_VEDIO_SDTV_BRI_VIVID               80
#define INIT_VEDIO_SDTV_CON_VIVID               70
#define INIT_VEDIO_SDTV_HUE_VIVID               50
#define INIT_VEDIO_SDTV_SAT_VIVID               70
#define INIT_VEDIO_SDTV_SHARP_VIVID             60

#define INIT_VEDIO_HDTV_BRI_VIVID               80
#define INIT_VEDIO_HTDV_CON_VIVID               70
#define INIT_VEDIO_HDTV_HUE_VIVID               50
#define INIT_VEDIO_HDTV_SAT_VIVID               70
#define INIT_VEDIO_HDTV_SHARP_VIVID             60

#define INIT_VEDIO_SDTV_BRI_USER                50
#define INIT_VEDIO_SDTV_CON_USER                50
#define INIT_VEDIO_SDTV_HUE_USER                50
#define INIT_VEDIO_SDTV_SAT_USER                70
#define INIT_VEDIO_SDTV_SHARP_USER              70

#define INIT_VEDIO_HDTV_BRI_USER                50
#define INIT_VEDIO_HTDV_CON_USER                50
#define INIT_VEDIO_HDTV_HUE_USER                50
#define INIT_VEDIO_HDTV_SAT_USER                50
#define INIT_VEDIO_HDTV_SHARP_USER              50
//#endif //~TV_SETTING

////////////////////////////////////////////////////////////////////////////////
// restore all mask
#define RESTORE_KEEP_NONE                       (0x0)

#define RESTORE_KEEP_SYSTEM_LANGUAGE            (0x0001)
#define RESTORE_KEEP_SYSTEM_PASSWORD            (0x0002)
#define RESTORE_KEEP_SYSTEM_TIME                (0x0004)
#define RESTORE_KEEP_SYSTEM_SOURCE            (0x0008)
#define RESTORE_KEEP_SYSTEM_FACTORY_SETTING  (0x0010)

#define DEFAULT_D_ONTIME_CH  1 // this value must be 1,
                               // bcz when we restore both general and channel setting
                               // the database only have 1 dummy ch "2-1"

#define RESTORE_GENSETTING      0x01
#define RESTORE_GENSETTING_CUSTOMER_MODE     0x02
#define RESTORE_USERSETTING     0x04
#define RESTORE_DATABASE_INCLUDE_ADC     0x10
#define RESTORE_DATABASE_INCLUDE_WB     0x20
#define RESTORE_DATABASE        0x30 //ALL(WB+ADC)
#define RESTORE_DATABASE_EXCEPT_WB_ADC     0x40
#define RESTORE_DATABASE_CUSTOMER_MODE        0x80

typedef enum
{
    OSD_DURATION_5_SEC,
    OSD_DURATION_10_SEC,
    OSD_DURATION_15_SEC,
    OSD_DURATION_20_SEC,
    OSD_DURATION_25_SEC,
    OSD_DURATION_30_SEC,
    OSD_DURATION_35_SEC,
    OSD_DURATION_40_SEC,
    OSD_DURATION_45_SEC,
    OSD_DURATION_50_SEC,
    OSD_DURATION_55_SEC,
    OSD_DURATION_60_SEC,
    OSD_DURATION_NUM
} EN_OSD_DURATION;

typedef enum
{
    //INFO_DURATION_0_SEC,
    INFO_DURATION_2_SEC,
    INFO_DURATION_4_SEC,
    INFO_DURATION_6_SEC,
    INFO_DURATION_8_SEC,
    INFO_DURATION_10_SEC,
    INFO_DURATION_NUM
} EN_INFO_DURATION;

typedef enum
{
    MODE_ON,
    MODE_OFF,
    MODE_NUM
} EN_ONOFF_MODE;

//------------------------------------------------------------------------------
// Function Prototypes
//------------------------------------------------------------------------------
#ifdef MAPP_RESTORETODEFAULT_C
#define INTERFACE
#else
#define INTERFACE extern
#endif

INTERFACE BOOLEAN MApp_DataBase_VersionCheck(void);
INTERFACE void MApp_DataBase_RestoreDefaultSystem(U16 u16KeepSetting);
INTERFACE void MApp_DataBase_RestoreDefaultVideo(E_DATA_INPUT_SOURCE enDataInputSource);
INTERFACE void MApp_DataBase_RestoreDefaultWhiteBalance(E_DATA_INPUT_SOURCE enDataInputSource);
INTERFACE void MApp_DataBase_PictureResetWhiteBalance(E_DATA_INPUT_SOURCE enDataInputSource);

INTERFACE void MApp_DataBase_RestoreDefaultSubColor(E_DATA_INPUT_SOURCE enDataInputSource);

INTERFACE void MApp_DataBase_RestoreDefaultAudio(void);
INTERFACE void MApp_DataBase_RestoreDefaultScanMenu(void);
INTERFACE void MApp_DataBase_RestoreDefaultTime(void);

INTERFACE void App_DataBase_RestoreDefaultBlock(void);

INTERFACE void MApp_DataBase_RestoreDefaultSSC(void);

#if (ENABLE_NONLINEAR_CURVE)
INTERFACE void MApp_DataBase_RestoreDefaultNonLinearCurve(void);
#endif
INTERFACE void MApp_DataBase_RestoreDefaultFactorySetting(void);

INTERFACE void MApp_DataBase_RestoreDefaultValue(U16 u16KeepSetting);
INTERFACE void MApp_DataBase_RestoreDefaultInstallGuide(BOOLEAN bRunInstallationGuide);

INTERFACE void MApp_DataBase_RestoreUserSettingDefaultValue(U16 u16KeepSetting);

INTERFACE void MApp_DataBase_RestoreDefaultADC(E_ADC_SET_INDEX eAdcIndex );
#if ENABLE_DRM
INTERFACE void MApp_Drm_RestoreDefaultSetupInfo(void);
#endif
INTERFACE void MApp_DataBase_RestoreDefaultVChip(void);
#ifdef ENABLE_BT
INTERFACE void MApp_BT_RestoreDefaultTorrentSetupInfo(void);
#endif
//#if (ENABLE_PIP)
INTERFACE void MApp_DataBase_RestoreDefaultPIP(void);
//#endif
#if (ENABLE_UPDATE_MULTIPLEX_VIA_NIT)
INTERFACE void MApp_DataBase_RestoreDefaultNetworkInfo(void);
#endif
INTERFACE void MApp_DataBase_RestoreFactoryDefault(U8 u8RestoreMask);
INTERFACE void MApp_DataBase_RestoreUserSettingDefault(U8 u8RestoreMask);
#if ENABLE_CI
INTERFACE void MApp_DataBase_RestoreDefaultCI(void);
#endif
#if (ENABLE_LAST_MEMORY==1)&&(ENABLE_LAST_MEMORY_STORAGE_SAVE==1)
INTERFACE void MApp_DataBase_RestoreDefaultMmLastMemorySetting(void);
#endif
#if ENABLE_CUS_RS232_FUNC
INTERFACE void MApp_RestoreDefaultPictureSettingForRS232(E_DATA_INPUT_SOURCE enDataInputSource,U8 u8extraAct,EN_MS_PICTURE enFollowPicmodeValue);
#endif

#undef INTERFACE

#endif

