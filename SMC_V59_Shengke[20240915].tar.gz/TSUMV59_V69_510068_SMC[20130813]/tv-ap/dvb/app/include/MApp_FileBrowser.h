////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
//
// @file
// @brief
// @author MStarSemi Inc.
//
//-
//-
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MAPP_FILEBROWSER_H
#define    _MAPP_FILEBROWSER_H
/*************************************************************************************************************/


#include "datatype.h"
#include "debug.h"
#include "mapp_mplayer.h"

/*definition ====================================================================================*/
#define FCTRL_MAX_CONCURRENCY_FILTER_NAMES      5
#define FCTRL_MAX_FILTER_VALUE                  32

// File type: This is mapped to 'fileTypeStr[]' and 'fileTypeStrLower[]'...
#define FS_FILETYPE_DIR                 (1UL << 0)      // Directory
#define FS_FILETYPE_FILE                (1UL << 1)      // All files
#define FS_FILETYPE_JPG                 (1UL << 2)
#define FS_FILETYPE_MP3                 (1UL << 3)
#define FS_FILETYPE_MP4                 (1UL << 4)
#define FS_FILETYPE_AVI                 (1UL << 5)

#define FS_FILETYPE_NONE                (1UL << (FCTRL_MAX_FILTER_VALUE-1))

#define SECTOR_SIZE_512_BYTE            512
#define INVALID_BROWSER_HANDLE          0xFF

typedef struct
{
    U8 ps8DirEntryName[8];
    U8 ps8DirEntryExtName[3];
    U8 u8DirEntryAttrib;
    U8 pu8DirEntryReserved[8];
    U16 u16DirEntryStartClusterHI;
    U16 u16DirEntryTime;
    U16 u16DirEntryDate;
    U16 u16DirEntryStartClusterLO;
    U32 u32DirEntryFileLength;
}DirEntryStruct;

/*enumeration ===================================================================================*/
// Error code for file system
enum FS_ERROR_CODE
{
    FS_ERROR_CODE_FAIL                  = 0,
    FS_ERROR_CODE_TRUE                  = 1,
    FS_ERROR_CODE_NO_SYS                = 2,
    FS_ERROR_CODE_NO_ROOT               = 3
};

/*function ======================================================================================*/
#ifdef MAPP_FILEBROWSER_C
#define FILEBROWSER_INTERFACE
#else
#define    FILEBROWSER_INTERFACE extern
#endif

FILEBROWSER_INTERFACE U8 MApp_FileBrowser_Init(U16 driveIndex);

FILEBROWSER_INTERFACE U8 MApp_FileBrowser_Create(U16 driveIndex);
FILEBROWSER_INTERFACE void MApp_FileBrowser_Destroy(U8 u8Handle);
FILEBROWSER_INTERFACE void MApp_FileBrowser_SetEnvironment(U8 u8Handle);
FILEBROWSER_INTERFACE U8 MApp_FileBrowser_GetEnvironment(void);

FILEBROWSER_INTERFACE U8 MApp_FileBrowser_GetCurrentLongName(U32 MIUAddr,U8 charLen);
FILEBROWSER_INTERFACE U8 MApp_FileBrowser_GetLongFileNameByFileEntry(FileEntry *pEntry, U32 MIUAddr,U8 charLen);
FILEBROWSER_INTERFACE BOOLEAN MApp_FileBrowser_GetCurrentShortName(U32 shortNameAddr, U32 extNameAddr);
FILEBROWSER_INTERFACE U8 MApp_FileBrowser_GetCurrentDirectoryName(U32 MIUAddr,U8 charLen);
FILEBROWSER_INTERFACE BOOLEAN MApp_FileBrowser_ToFirstEntryInCurrentDirectory(void);
FILEBROWSER_INTERFACE BOOLEAN MApp_FileBrowser_ChangeDrive(U8 driveIndex);
FILEBROWSER_INTERFACE BOOLEAN MApp_FileBrowser_ChangeToRootDirectory(void);
FILEBROWSER_INTERFACE BOOLEAN MApp_FileBrowser_EnterDirectory(S16 EntryIndex);
FILEBROWSER_INTERFACE BOOLEAN MApp_FileBrowser_EnterDirectoryToContained(FileEntry *pFileEntry);
FILEBROWSER_INTERFACE void MApp_FileBrowser_PrintCurrentName(void);
FILEBROWSER_INTERFACE void MApp_FileBrowser_PrintCurrentEntry(void);
FILEBROWSER_INTERFACE void MApp_FileBrowser_GetFileEntryFullpath(FileEntry *fileEntry, char *fullpath);
FILEBROWSER_INTERFACE BOOLEAN MApp_FilrBrowser_CheckNameExistedInCurrent(U16* pString,U8 charLen);
FILEBROWSER_INTERFACE EN_FILE_SYSTEM_TYPE MApp_FileBrowser_GetCurrentFileSystemType(void);
FILEBROWSER_INTERFACE U8 MApp_FileBrowser_OpenNewFileForWrite(U16* pString,U8 charLen);
FILEBROWSER_INTERFACE U32 u32InfoFileSize;
FILEBROWSER_INTERFACE BOOLEAN MApp_FileBrowser_GetCurrentFileEntry(FileEntry* pEntryToSet);
FILEBROWSER_INTERFACE U8 MApp_FileBrowser_GetCurrentDriveName(void);

FILEBROWSER_INTERFACE DirEntryStruct * MApp_FileBrowser_GetCurrentDirEntry(void);
FILEBROWSER_INTERFACE DirEntryStruct * MApp_FileBrowser_GetNextDirEntry(U16 NextEntryNo);
FILEBROWSER_INTERFACE DirEntryStruct * MApp_FileBrowser_GetPrevDirEntry(U16 PrevEntryNo);

FILEBROWSER_INTERFACE void MApp_FileBrowser_DeInit(void);
FILEBROWSER_INTERFACE U32 MApp_FileBrowser_GetCurrentLength(void);
FILEBROWSER_INTERFACE LongLong MApp_FileBrowser_GetCurrentLength_LongLong(void);
FILEBROWSER_INTERFACE U8 MApp_FileBrowser_EnterFile(S16 EntryIndex);
FILEBROWSER_INTERFACE BOOLEAN MApp_FileBrowser_DeleteFile(S16 EntryIndex);
FILEBROWSER_INTERFACE BOOLEAN MApp_FileBrowser_DeleteFileByFileEntry(FileEntry *pEntry);
FILEBROWSER_INTERFACE void MApp_FileBrowser_GetCurrentTime( FS_TIME *pstTime );

#if DYNAMIC_VECTOR_FONT_ENABLE  || ENABLE_DVD
FILEBROWSER_INTERFACE BOOLEAN MApp_FilrBrowser_GetNameExistedInCurrent(U16* pString,U8 charLen, FileEntry *pEntryToSet);
#endif

/*debug function =================================================================================*/
FILEBROWSER_INTERFACE void MApp_FileBrowser_Write_Debug(S8 * s8WriteFileName, U32 u32WriteTotalLength, U32 u32BufferLength);
FILEBROWSER_INTERFACE void MApp_FileBrowser_Copy_Debug(S8 * s8WriteFileName, S8 * s8ReadFileName, U32 u32BufferLength);




/*************************************************************************************************************/
#endif    /*_MAPP_FILEBROWSER_H END */

