////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#define MAPP_SIGNAL_MONITOR_C

/******************************************************************************/
/*                            Header Files                                    */
/******************************************************************************/
#include "Board.h"
#include "datatype.h"
#include "MsCommon.h"

// Common Definition
#include "apiXC.h"
#include "apiXC_Adc.h"
#include "msAPI_Video.h"
#include "msAPI_Timer.h"
#include "msAPI_DTVSystem.h"
#if (ENABLE_CI)
#include "msAPI_CI.h"
#endif
#include "msAPI_audio.h"
//#include "drvMAD.h"
#include "MApp_GlobalSettingSt.h"
#include "MApp_SignalMonitor.h"
#include "MApp_TV.h"
#include "MApp_AnalogInputs.h"

#include "MApp_Scan.h"
//ZUI: #include "MApp_DispMenu.h"
#include "MApp_ChannelChange.h"
#include "MApp_GlobalVar.h"
#include "MApp_Audio.h"
#include "MApp_MVDMode.h"
#include "MApp_UiEpg.h"

#if (ENABLE_DTV_EPG)
#include "mapp_eit.h"
#endif

#if (ENABLE_TTX)
#include "mapp_ttx.h"
#endif
#include "MApp_ATVProc.h"
#include "MApp_PlayCard.h"

#if (ENABLE_DTV)
#include "mapp_demux.h"
#include "mapp_si.h"
#endif

#if (((ENABLE_SBTVD_BRAZIL_APP)&&(BRAZIL_CC))||(ATSC_CC == ATV_CC))
#include "mapp_closedcaption.h"
#endif

//ZUI_TODO: #include "MApp_UiMenu.h"
#include "MApp_UiMenuDef.h" //ZUI:
#include "MApp_GlobalFunction.h"
#if MHEG5_ENABLE
#include "MApp_MHEG5_Main.h"
#endif
#if ENABLE_PVR
#include "MApp_PVR.h"
#endif
#include <string.h>
#if (ENABLE_UPDATE_MULTIPLEX_VIA_NIT)
#include "ZUI_exefunc.h"
#include "MApp_ZUI_Main.h"
#endif

/********************************************************************************/
/*                              Macro                                           */
/********************************************************************************/
#define SIGNAL_MONITOR_DBG(y) //y


/********************************************************************************/
/*                     Local                                                      */
/********************************************************************************/
static U32 u32SignalMonitorTimer; //ms
static U32 u32SignalMonitorPeriod; //ms
static EN_SIGNAL_LOCK_STATUS enPrevSignalLockStatus;
#if ENABLE_DTV
static BOOLEAN fTmpCurScrambleFlag;
#endif
#if ENABLE_CI
static BOOLEAN _bCITSState = 0;
static U32 _u32CITimer=0;
#define SIGNAL_CHK_TIME_CI_STATE          3000 //ms    //CUS03 Spec.
#endif
//////////////////////////////////////////////////////////////////////////////////////////
#define SIGNAL_CHK_TIME_LOCK_STATE          100 //ms    //CUS03 Spec.
#define SIGNAL_CHK_TIME_UNLOCK_STATE        300 //ms    //CUS03 Spec.
#define SIGNAL_CHK_TIME_ANALOG_LOCK_STATE   500 //ms    //CUS03 Spec.
#define SIGNAL_CHK_TIME_ANALOG_UNLOCK_STATE 500 //ms    //CUS03 Spec.


#if SWWDT
U8 VDCounter=0;
U8 DSPCounter=0;
U32 logtime=0;
#endif
static U32 u32AudioReadyTimer;

void MApp_SignalMonitor_Init(void)
{
    enFrotEndLockStatus = FRONTEND_UNKNOWN;
    u32SignalMonitorPeriod = SIGNAL_CHK_TIME_LOCK_STATE;
    enPrevSignalLockStatus=SIGNAL_UNKNOWN;
    u32SignalMonitorTimer = msAPI_Timer_GetTime0();
#if ENABLE_CI
    _u32CITimer=0;
#endif
    #if (ENABLE_DTV_EPG)
    MApp_EIT_All_Sche_ResetFilter();
    #endif  //#if (ENABLE_DTV_EPG)
}


#if SWWDT
void MApp_Monitor_CoOperators(void)
{

    logtime++;


    // VD MCU
    VDCounter = msAPI_VD_MCU_StatusCheck();

    // Audio DSP
    DSPCounter = msAPI_AUDIO_DSP_StatusCheck();

    if (logtime ==500 )
    {
        logtime = 0;
        printf("Co-Operators status  REG :  VD/MCU      --> 0x%bx\n",MDrv_ReadByte( 0x3500+0xD6 ));
       //incorrect, please contact with audioteam,Cathy   printf("Co-Operators status  REG :  AUDIO/DSP --> 0x%bx\n\n",MDrv_AUDIO_ReadByte( 0x2D54));

        printf("Co-Operators status  VAL :   VD/MCU     --> 0x%bx \n",VDCounter);
        printf("Co-Operators status  VAL :   AUDIO/DSP -->0x%bx\n\n",DSPCounter);
   }
}
#endif

void MApp_Set_Audio_Mute_Timer(BOOLEAN bStartTimer)
{
    if(bStartTimer)
        u32AudioReadyTimer=msAPI_Timer_GetTime0();
    else
        u32AudioReadyTimer=0;
}
#if ENABLE_DTV
void MApp_AudioMuteMonitor(void)
{
    if(u32AudioReadyTimer && msAPI_Timer_DiffTimeFromNow(u32AudioReadyTimer) > 10000)
    {
        //if(enMVDVideoStatus != MVD_GOOD_VIDEO && IS_MADGOOD())
        if(enMVDVideoStatus != MVD_GOOD_VIDEO && MApi_AUDIO_IsMadLock())
        {
            if(!MApp_SI_Is_Running(NULL)&& (MApp_SI_CheckMHEG5Status() == SI_MHEG5_DISABLE))
            {
                return;
            }
            msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_PERMANENT_MUTEOFF, E_AUDIOMUTESOURCE_ACTIVESOURCE);
            u32AudioReadyTimer=0;
        }
    }
}

#endif
void MApp_SignalMonitor(void)
{
    BOOLEAN Check_FE_Result;
#if ENABLE_DTV
    MEMBER_SERVICETYPE bServiceType = msAPI_CM_GetCurrentServiceType();
#endif
#if ENABLE_CI
    if( (_bCITSState != msAPI_CI_CardDetect()) )
    {
        _bCITSState=msAPI_CI_CardDetect();
        if(_bCITSState)
        {
            _u32CITimer=msAPI_Timer_GetTime0();
        }
        else
        {
            _u32CITimer=0;
        }
    }
    if(_u32CITimer)
    {
        if( msAPI_Timer_DiffTimeFromNow(_u32CITimer) < SIGNAL_CHK_TIME_CI_STATE)
        {
            return;
        }
        else
        {
            _u32CITimer=0;
        }
    }
#endif


//    U16 u16CurPosition = msAPI_CM_GetCurrentPosition(bServiceType);
    Check_FE_Result = FALSE;

    if(msAPI_Timer_DiffTimeFromNow(u32SignalMonitorTimer) > u32SignalMonitorPeriod) //unit = ms
    {
#if ENABLE_DTV
        if(IsDTVInUse())
        {
            if( msAPI_Tuner_CheckLock( &Check_FE_Result,FALSE) == FALSE )
            {
                SIGNAL_MONITOR_DBG(printf("FE Fail!\n"));
                if(enFrotEndLockStatus == FRONTEND_LOCK || enFrotEndLockStatus == FRONTEND_UNKNOWN)
                {
                    #if PLAYCARD_DISABLE // if you want use play card turn off this
                        enFrotEndLockStatus = FRONTEND_UNLOCK;
                    #else
                    enFrotEndLockStatus = FRONTEND_LOCK;
                    #endif
                    u32SignalMonitorPeriod = SIGNAL_CHK_TIME_UNLOCK_STATE; //ms
                }
            }
            else
            {
                if(Check_FE_Result==FE_LOCK)
                {
                    if(enFrotEndLockStatus == FRONTEND_UNLOCK || enFrotEndLockStatus == FRONTEND_UNKNOWN)
                    {
                        enFrotEndLockStatus = FRONTEND_LOCK;
                        u32SignalMonitorPeriod = SIGNAL_CHK_TIME_LOCK_STATE;
                    }
                }
                else
                {
                    if(enFrotEndLockStatus == FRONTEND_LOCK || enFrotEndLockStatus == FRONTEND_UNKNOWN)
                    {
                        #if PLAYCARD_DISABLE // if you want use play card turn off this
                        enFrotEndLockStatus = FRONTEND_UNLOCK;
                        #else
                        enFrotEndLockStatus = FRONTEND_LOCK;
                        #endif
                        u32SignalMonitorPeriod = SIGNAL_CHK_TIME_UNLOCK_STATE; //ms
                    }
                }
            }
        }
        else
#endif
        {
          #if 0 //Modified by coverity
            Check_FE_Result = FE_LOCK;//Temp

            if(Check_FE_Result == FE_LOCK)
            {
                enFrotEndLockStatus = FRONTEND_LOCK;
                u32SignalMonitorPeriod=SIGNAL_CHK_TIME_ANALOG_LOCK_STATE;   //ms
            }
            else
            {
                u32SignalMonitorPeriod = SIGNAL_CHK_TIME_ANALOG_UNLOCK_STATE;
                #if PLAYCARD_DISABLE // if you want use play card turn off this
                enFrotEndLockStatus = FRONTEND_UNLOCK;
                #else
                enFrotEndLockStatus = FRONTEND_LOCK;
                #endif
            }
          #else
            enFrotEndLockStatus = FRONTEND_LOCK;
            u32SignalMonitorPeriod=SIGNAL_CHK_TIME_ANALOG_LOCK_STATE;   //ms
          #endif
        }

        if(MApp_GetSignalStatus()==SIGNAL_LOCK)
        {
            if(enPrevSignalLockStatus == SIGNAL_UNLOCK || enPrevSignalLockStatus == SIGNAL_UNKNOWN)
            {
#if ENABLE_DTV
                if(IsDTVInUse())
                {
                    //bServiceType = msAPI_CM_GetCurrentServiceType();
                    //u16CurPosition = msAPI_CM_GetCurrentPosition(bServiceType);

                    #if 1//modify by leo.wang 2007/11/26
                    //if radio channel, unmute audio directly.
                    //if still picture, unmute audio after mvd get sync in MApp_ScreenMuteMonitor()
                    if(bServiceType == E_SERVICETYPE_RADIO &&
                        MApp_TV_IsProgramRunning()) //audio only condition.
                    #else
                    if((bServiceType == E_SERVICETYPE_RADIO) || //audio only condition.
                        (msAPI_CM_GetProgramAttribute(bServiceType,u16CurPosition, E_ATTRIBUTE_IS_STILL_PICTURE) == TRUE))//still picture channel.
                    #endif
                    {
                        msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_PERMANENT_MUTEOFF, E_AUDIOMUTESOURCE_ACTIVESOURCE);
                    }

                    #if (ENABLE_DTV_EPG)
                    MApp_EIT_All_Sche_ResetFilter();
                    #endif  //#if (ENABLE_DTV_EPG)
#if (ENABLE_UPDATE_MULTIPLEX_VIA_NIT)
                    if (OSD_COUNTRY_SETTING == OSD_COUNTRY_NORWAY)
                    {
                        if (LOSS_SIGNAL_CONFIRM_MSG == MApp_DTV_Scan_GetLossSignalState())
                        {
                            MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_CLOSE_CURRENT_OSD);
                        }
                        MApp_DTV_Scan_SetLossSignalState(LOSS_SIGNAL_INIT);
                    }
#endif

                    if (stSystemInfo[MAIN_WINDOW].u8PanelPowerStatus & PANEL_POWER_BLUESCREEN
                    #if (ENABLE_PIP)
                        || (IsPIPSupported() && (stSystemInfo[SUB_WINDOW].u8PanelPowerStatus & PANEL_POWER_BLUESCREEN))
                    #endif
                        )
                    {
                        MApp_ChannelChange_EnableAV();
                    }

                    MApp_TV_Force2MonitorIdleModeWindows();
                    fTmpCurScrambleFlag = FALSE;
                    #if(ENABLE_TTX_SHOW_OFF_SIGNAL)//Refresh TTX when signal is on
                    MApp_TTX_Reflesh();
                    #endif
                }
#endif
                enPrevSignalLockStatus=SIGNAL_LOCK;
                #if (ENABLE_PIP)
                //This is a patch for TV Monitor. MApp_SI_Is_Running() always return TRUE, and
                //  it is used for special case(Jupiter said). So, SYS_SCREEN_SAVER_TYPE cannot
                //  be set to EN_SCREENSAVER_NULL when cable is inserted to the tuner when PIP
                //  is enabled. (May 5, 2009)
                if(IsPIPEnable())
                {
                    if(IsSrcTypeDTV(SYS_INPUT_SOURCE_TYPE(SUB_WINDOW))
                        && SYS_SCREEN_SAVER_TYPE(SUB_WINDOW) != EN_SCREENSAVER_NULL)
                    {
                        SYS_SCREEN_SAVER_TYPE(SUB_WINDOW) = EN_SCREENSAVER_NULL;
                    }
                }
                #endif
                SIGNAL_MONITOR_DBG(printf("Signal Recovery!\n"));
            }
        }
        else if(MApp_GetSignalStatus()==SIGNAL_UNLOCK)
        {
            if(enPrevSignalLockStatus == SIGNAL_LOCK || enPrevSignalLockStatus == SIGNAL_UNKNOWN)
            {
#if ENABLE_DTV
                if(IsDTVInUse())
                {
#if MHEG5_ENABLE
#if MHEG5_WITH_OSD
                    if(msAPI_MHEG5_checkGoBackMHEG5()==true)
                        MApp_MHEG5_Force_Exit();
#endif
#endif
#if 0//ENABLE_PVR
                    if (!MApp_PVR_IsPlaybacking() && !MApp_PVR_IsRecording())
#endif

#if ((ENABLE_SBTVD_BRAZIL_APP) && (BRAZIL_CC))
    if ((IsDTVInUse() && stGenSetting.g_SysSetting.enDTVCaptionType != DTV_CAPTION_OFF)
      ||(IsATVInUse() && stGenSetting.g_SysSetting.enATVCaptionType != ATV_CAPTION_TYPE_OFF))
    {
        if(MApp_CC_GetInfo(CC_SELECTOR_STATUS_CODE) == STATE_CAPTION_PARSER)
        {
            MApp_CC_StopParser();
            MApp_Dmx_PES_Stop();
        }
    }
#endif

                    {
                        if( IsSrcTypeDTV(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)) )
                        {
                            #if ENABLE_PVR
                            if (!MApp_PVR_IsPlaybacking() && !MApp_PVR_IsRecording()) //to prevent blue screen when recording & playbacking
                            #endif
                            MApp_ChannelChange_DisableAV(MAIN_WINDOW);
                        }
                        #if (ENABLE_PIP)
                        if( IsPIPEnable() && IsSrcTypeDTV(SYS_INPUT_SOURCE_TYPE(SUB_WINDOW)) )
                        {
                            MApp_ChannelChange_DisableAV(SUB_WINDOW);
                        }
                        #endif
                    }
                    MApp_TV_Force2MonitorIdleModeWindows();
#if ENABLE_TTX
                    MApp_TTX_TeletextCommand(TTX_TV);
			   #endif
                }
#endif
                enPrevSignalLockStatus=SIGNAL_UNLOCK;
                SIGNAL_MONITOR_DBG(printf("Signal Lost!\n"));
            }
        }

        u32SignalMonitorTimer = msAPI_Timer_GetTime0();
    }
}
BOOLEAN MApp_Scramble_GetCurStatus(void)
{
#if ENABLE_DTV
    if(IsDTVInUse())
    {
        //printf("Scram %bu\n",fTmpCurScrambleFlag);
        return fTmpCurScrambleFlag;
    }
    else
#endif
        return FALSE;
}
EN_SIGNAL_LOCK_STATUS    MApp_GetSignalStatus_UnCheckMHEG5(void)
{
#if ENABLE_DTV
    if(IsDTVInUse())
    {
        if(enFrotEndLockStatus == FRONTEND_LOCK)
        {
            //if(enMVDVideoStatus == MVD_GOOD_VIDEO || IS_MADGOOD())
            if(enMVDVideoStatus == MVD_GOOD_VIDEO || MApi_AUDIO_IsMadLock())
            {
                return SIGNAL_LOCK;
            }
        }
    }
#endif
    return SIGNAL_UNLOCK;
}

#if ENABLE_CI
static BOOLEAN MApp_SignalMonitor_CheckIfNeed2TryMPEG2( void )
{
    #define CIINFO_LENGTH 10
    U8 manufacturer[CIINFO_LENGTH];
    U8 product[CIINFO_LENGTH];
    U8 Info1[CIINFO_LENGTH];

    if(g_eCodecType == E_VDEC_CODEC_TYPE_MPEG2)
    {
        return FALSE;
    }
    else if(g_eCodecType == E_VDEC_CODEC_TYPE_H264)
    {
        if(msAPI_CI_CardDetect() == FALSE || msAPI_CI_GetCardState() != EN_MODULE_READY)
        {
            //printf("Not ready\n");
            return FALSE;
        }
        else
        {
            if(msAPI_Timer_DiffTimeFromNow( u32ChkTry2ChgMpeg2Time ) > 4000 &&
               msAPI_Timer_DiffTimeFromNow( u32ChkTry2ChgMpeg2Time ) < 5000)
            {
                msAPI_CI_GetCIS( manufacturer, CIINFO_LENGTH, product, CIINFO_LENGTH, Info1, CIINFO_LENGTH );
                //printf("%s:%s:%d:%d\n",manufacturer,product,bAVCH264,msAPI_CI_GetCardType());
                if(/*msAPI_CI_GetCardType()               == EN_SMARTCARD_TYPE_NEOTNT   &&*/
                   strcmp((char*)manufacturer,"NEOTION")== 0            &&
                   strcmp((char*)product,"NP4")         == 0)
                {
                    //printf("try mepg2\n");
                    return TRUE;
                }
                else
                {
                    //printf("Don't try\n");
                    return FALSE;
                }
            }
            else return FALSE;
        }

    }
    return FALSE;
}

static void MApp_SignalMonitor_ChangeMVD2MPEG2( void )
{
    SHOW_VIDEO_INFO(("MApp_SignalMonitor_ChangeMVD2MPEG2"));



    //printf("Switch MVD to MPEG2 to check again\n");
    msAPI_VID_Command( MSAPI_VID_STOP );
//    msAPI_VID_Command( MSAPI_VID_RESET );

    msAPI_VID_SetMappingAVCParameter(E_VDEC_CODEC_TYPE_MPEG2);

//    MAPI_VID_Init(msAPI_VID_GetCodecType(),FALSE);
    msAPI_VID_Init(FALSE, E_VDEC_SRC_MODE_DTV);

    MApp_VID_VariableInit();
    msAPI_VID_Command( MSAPI_VID_PLAY );
}
#endif

EN_SIGNAL_LOCK_STATUS    MApp_GetSignalStatus(void)
{
#if ENABLE_DTV
    MEMBER_SERVICETYPE bServiceType = msAPI_CM_GetCurrentServiceType();
    U16 u16CurPosition = msAPI_CM_GetCurrentPosition(bServiceType);
    if(IsDTVInUse())
    {
        if(enFrotEndLockStatus == FRONTEND_UNKNOWN)
          {
              fTmpCurScrambleFlag = FALSE;
              return SIGNAL_UNKNOWN;
            }
        else if(enFrotEndLockStatus == FRONTEND_LOCK && enMVDVideoStatus == MVD_UNKNOWN_VIDEO)
        {
            if ( msAPI_CM_GetProgramAttribute(bServiceType, u16CurPosition, E_ATTRIBUTE_IS_SERVICE_ID_ONLY) == TRUE )
            {
                return SIGNAL_UNLOCK;
            }
            if(bServiceType == E_SERVICETYPE_RADIO)
            {
                /*if(g_stSIInfo.stSdtMonInfo.u8RunningStatus == SI_SDT_RUN_UNDEFINED
                   //|| g_stSIInfo.stSdtMonInfo.u8RunningStatus == SI_SDT_RUN_RUNNING)
                {
                    //Do nothing. Just return SIGNAL_LOCK.
                }
                else */
                //if((!IS_MADGOOD() || (!MApp_SI_Is_Running()))&& (MApp_SI_CheckMHEG5Status() == SI_MHEG5_DISABLE))
                if((!MApi_AUDIO_IsMadLock() || (!MApp_TV_IsProgramRunning()))&& (MApp_SI_CheckMHEG5Status() == SI_MHEG5_DISABLE))
                {
                    if(MApp_SI_CheckCurProgScramble())
                        fTmpCurScrambleFlag = TRUE;
                    else
                        fTmpCurScrambleFlag = FALSE;
                    //printf("audio unlock\n");
                    return SIGNAL_UNLOCK;
                }
                //printf("audio lock\n");
                //fTmpCurScrambleFlag = FALSE;
                return SIGNAL_LOCK;
            }
            else
            {
                if((MApp_SI_CheckCurProgScramble() || (!MApp_TV_IsProgramRunning())) && (MApp_SI_CheckMHEG5Status() == SI_MHEG5_DISABLE))
                {
                    if(MApp_SI_CheckCurProgScramble())
                    {

                        #if ENABLE_CI
                        if(MApp_SignalMonitor_CheckIfNeed2TryMPEG2() == TRUE)
                        {
                            MApp_SignalMonitor_ChangeMVD2MPEG2();
                            //printf("MVDVideoStatus %d\n",enMVDVideoStatus);
                            return SIGNAL_LOCK;
                        }
                        else
                        #endif
                        {
                            fTmpCurScrambleFlag = TRUE;
                            //printf("Vid unlock1\n");
                            return SIGNAL_UNLOCK;
                        }
                    }
                    else
                    {
                        fTmpCurScrambleFlag = FALSE;
                        //printf("Vid unlock\n");
                        return SIGNAL_UNLOCK;
                    }
                }
                #if ENABLE_CI
                if(MApp_SignalMonitor_CheckIfNeed2TryMPEG2() == TRUE)
                {
                    MApp_SignalMonitor_ChangeMVD2MPEG2();
                }
                #endif
                //printf("Vid lock\n");
                return SIGNAL_LOCK;
            }
        }
        else if(enFrotEndLockStatus == FRONTEND_LOCK && enMVDVideoStatus == MVD_GOOD_VIDEO)
        {
            fTmpCurScrambleFlag = FALSE;
            if((!MApp_TV_IsProgramRunning())&& (MApp_SI_CheckMHEG5Status() == SI_MHEG5_DISABLE))
            {
                return SIGNAL_UNLOCK;
            }
            return SIGNAL_LOCK;
        }
#if (MHEG5_ENABLE)
        else if(enFrotEndLockStatus == FRONTEND_LOCK && (enMVDVideoStatus == MVD_BAD_VIDEO && !g_MHEG5Video.bIFrame))
        {
            if((msAPI_MHEG5_IsRunning()||msAPI_MHEG5_checkGoBackMHEG5())&& msAPI_VID_GetPlayMode() != MSAPI_VID_PLAY)
            {
                return SIGNAL_LOCK;
            }
            else
#else
        else if(enFrotEndLockStatus == FRONTEND_LOCK && (enMVDVideoStatus == MVD_BAD_VIDEO ))
        {
#endif
            {
                if(MApp_SI_CheckCurProgScramble())
                {
                    #if ENABLE_CI
                    if(MApp_SignalMonitor_CheckIfNeed2TryMPEG2() == TRUE)
                    {
                        MApp_SignalMonitor_ChangeMVD2MPEG2();
                    }
                    else
                    #endif
                    {
                        fTmpCurScrambleFlag = TRUE;
                        return SIGNAL_UNLOCK;
                    }
                }
                if((!MApp_TV_IsProgramRunning())&& (MApp_SI_CheckMHEG5Status() == SI_MHEG5_DISABLE))
                {
                    return SIGNAL_UNLOCK;
                }
                //if(IS_MADGOOD())return SIGNAL_LOCK;
                if(MApi_AUDIO_IsMadLock())return SIGNAL_LOCK;
                return SIGNAL_UNLOCK;
            }
        }
        else if(enFrotEndLockStatus == FRONTEND_UNLOCK)
        {
            fTmpCurScrambleFlag = FALSE;
            return SIGNAL_UNLOCK;
        }
    }
    else
    {
        if(enFrotEndLockStatus == FRONTEND_UNKNOWN)
            return SIGNAL_UNKNOWN;
        else if(enFrotEndLockStatus == FRONTEND_LOCK)
            return SIGNAL_LOCK;
        else if(enFrotEndLockStatus == FRONTEND_UNLOCK)
         {
            fTmpCurScrambleFlag = FALSE;
            return SIGNAL_UNLOCK;
        }
    }
#endif
    return SIGNAL_UNKNOWN;
}


#undef MAPP_SIGNAL_MONITOR_C
