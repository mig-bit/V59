////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef MAPP_PCMODE_H
#define MAPP_PCMODE_H

/********************************************************************************/
/*                               Macro                                          */
/********************************************************************************/
#include "apiXC_Auto.h"

#ifdef MAPP_PCMODE_C
#define INTERFACE
#else
#define INTERFACE extern
#endif

////////////////////////////////////////////////////////////////////////////////

typedef enum
{
    E_PCMODE_NOSYNC = 0,                ///< Input timing stable, no input sync detected
    E_PCMODE_STABLE_SUPPORT_MODE,       ///< Input timing stable, has stable input sync and support this timing
    E_PCMODE_STABLE_UN_SUPPORT_MODE,    ///< Input timing stable, has stable input sync but this timing is not supported
    E_PCMODE_UNSTABLE,                  ///< Timing change, has to wait InfoFrame if HDMI input
} PCMODE_SyncStatus;

#if ENABLE_3D_PROCESS
 INTERFACE E_XC_3D_INPUT_MODE    g_HdmiInput3DFormat;
 INTERFACE E_XC_3D_INPUT_MODE    g_HdmiInput3DFormatStatus;
#endif
//*************************************************************************
//              Function prototypes
//*************************************************************************
INTERFACE BOOLEAN MApp_YPbPr_Setting_Auto(XC_Auto_CalibrationType type,SCALER_WIN eWindow);
INTERFACE BOOLEAN MApp_RGB_Setting_Auto(XC_Auto_CalibrationType type,SCALER_WIN eWindow);
INTERFACE BOOLEAN MApp_SCART_RGB_Setting_Auto(XC_Auto_CalibrationType type,SCALER_WIN eWindow);
INTERFACE BOOLEAN MApp_PCMode_Enable_SelfAuto(BOOLEAN EnableAuto, SCALER_WIN eWindow);
INTERFACE void MApp_PCMode_RunSelfAuto(SCALER_WIN eWindow);

INTERFACE void MApp_PCMode_LoadModeData(SCALER_WIN eWindow, U8 u8ModeIndex, BOOLEAN bIsNewMode);
INTERFACE void MApp_PCMode_SaveModeRamSetting(SCALER_WIN eWindow);

INTERFACE void MApp_PC_MainWin_Handler(INPUT_SOURCE_TYPE_t src, BOOLEAN bRealTimeMonitorOnly);
#if (ENABLE_PIP)
INTERFACE void MApp_PC_SubWin_Handler(INPUT_SOURCE_TYPE_t src, BOOLEAN bRealTimeMonitorOnly);
#endif

INTERFACE PCMODE_SyncStatus MApp_PCMode_GetCurrentState(SCALER_WIN eWindow);
INTERFACE BOOLEAN MApp_PCMode_IsAspectRatioWide(INPUT_SOURCE_TYPE_t enInputSourceType);
INTERFACE MS_U8 MApp_PCMode_Get_Mode_Idx(SCALER_WIN eWindow);
INTERFACE MS_U16 MApp_PCMode_Get_HResolution(SCALER_WIN eWindow,MS_BOOL IsYpbprOrVga);
INTERFACE MS_U16 MApp_PCMode_Get_VResolution(SCALER_WIN eWindow,MS_BOOL IsYpbprOrVga);
INTERFACE void MApp_PCMode_Reset( SCALER_WIN eWindow);
INTERFACE void MAPP_PCMode_PIP_ChangeAudioSource2HDMI(SCALER_WIN eWindow);
INTERFACE BOOLEAN MApp_ADC_HW_SaveGainOffset(void);
INTERFACE void MApp_ADC_Get_RGBData(void );

INTERFACE BOOLEAN _MApp_CheckBWOK(U16 u16HSize, U16 u16VSize, U16 u16InputVFreq);


//*************************************************************************
//              Global Variables
//*************************************************************************

#undef INTERFACE
#endif  /*MAPP_PCMODE_H*/
