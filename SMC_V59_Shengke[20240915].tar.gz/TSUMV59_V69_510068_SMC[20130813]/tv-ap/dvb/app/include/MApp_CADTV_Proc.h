////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MApp_CADTVPROC_H
#define _MApp_CADTVPROC_H

#include "drvAVD.h"
/********************************************************************************/
/*                               Macro                                          */
/********************************************************************************/

#ifdef MAPP_CADTVPROC_C
#define INTERFACE
#else
#define INTERFACE extern
#endif

//****************************************************************************
// Public attributes.
//****************************************************************************
// CADTV PROGRAM DATA STRUCTURE
#define DEFAULT_DVBC_CONSTEL_TYPE CAB_QAM16
#define MAX_DVBC_FREQUENCY        862000//888000
#define MIN_DVBC_FREQUENCY        48000//99000
#define DEFAULT_DVBC_FREQUENCY    770000 //642000
#define MAX_DVBC_SYMBOL_RATE      9999
#define MIN_DVBC_SYMBOL_RATE      9
#define DEFAULT_DVBC_NORDIG_SYMBOL_RATE  6875
#define DEFAULT_DVBC_CHINA_SYMBOL_RATE   6875
#define DEFAULT_DVBC_SYMBOL_RATE         6900

#define DEFAULT_DVBC_NID        0xFFFF
/// Define DVB-C modulation scheme
typedef enum
{
    CAB_QAM16,                                                          ///< QAM 16
    CAB_QAM32,                                                          ///< QAM 32
    CAB_QAM64,                                                          ///< QAM 64
    CAB_QAM128,                                                         ///< QAM 128
    CAB_QAM256,
} EN_CAB_CONSTEL_TYPE;
//****************************************************************************
// Public functions.
//****************************************************************************

INTERFACE BOOL MApp_CadtvManualTuning_IncreaseFrequency(void);
INTERFACE BOOL MApp_CadtvManualTuning_DecreaseFrequency(void);
INTERFACE U32 MApp_CadtvManualTuning_GetFrequency(void);
INTERFACE BOOL MApp_CadtvManualTuning_SetFrequency(U32 u32Freq);
INTERFACE BOOL MApp_CadtvManualTuning_IncreaseSymbol(void);
INTERFACE BOOL MApp_CadtvManualTuning_DecreaseSymbol(void);
INTERFACE U16 MApp_CadtvManualTuning_GetSymbol(void);
INTERFACE BOOL MApp_CadtvManualTuning_SetSymbol(U16 u16Sym);
INTERFACE BOOL MApp_CadtvManualTuning_IncreaseQamType(void);
INTERFACE BOOL MApp_CadtvManualTuning_DecreaseQamType(void);
INTERFACE EN_CAB_CONSTEL_TYPE MApp_CadtvManualTuning_GetQamType(void);
INTERFACE BOOL MApp_CadtvManualTuning_SetQamType(EN_CAB_CONSTEL_TYPE eQAM);
INTERFACE U16 MApp_CadtvManualTuning_GetNID(void);
INTERFACE BOOL MApp_CadtvManualTuning_SetNID(U16 u16NID);
INTERFACE void MApp_CATV_RestoreManutuning_settingDefault(void);
#undef INTERFACE
#endif // __CADTVPROC_H__
