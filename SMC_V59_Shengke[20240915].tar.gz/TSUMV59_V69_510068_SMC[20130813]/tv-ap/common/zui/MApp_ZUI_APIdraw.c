////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#define MAPP_ZUI_APIGUIDRAW_C
#define _ZUI_INTERNAL_INSIDE_ //NOTE: for ZUI internal


///////////////////////////////////////////////////////////////////////////////////////////////////
// Description: default drawing style
///////////////////////////////////////////////////////////////////////////////////////////////////

//-------------------------------------------------------------------------------------------------
// Include Files
//-------------------------------------------------------------------------------------------------
#include <stdio.h>
#include <string.h>
#include "MsCommon.h"

#include "MApp_ZUI_Main.h"
#include "apiXC.h"
#include "apiXC_Adc.h"
#include "MApp_GlobalSettingSt.h"
#include "MApp_ZUI_APIcommon.h"
#include "MApp_ZUI_APIstrings.h"
#include "MApp_ZUI_APIwindow.h"
#include "MApp_ZUI_APItables.h"
#include "MApp_ZUI_APIgdi.h"
#include "OSDcp_Bitmap_EnumIndex.h"
#include "OSDcp_String_EnumIndex.h"
#include "MApp_ZUI_APIdraw.h"
#include "MApp_ZUI_APIcomponent.h"

#include "msAPI_Font.h"
#include "apiGOP.h"
#include "MApp_GlobalVar.h"
#include "MApp_Font.h"
#include "MsTypes.h"
#include "drvBDMA.h"
#include "msAPI_Memory.h"
#if ENABLE_JPEGPNG_OSD
#include "msAPI_OSD_A.h"
#endif

///////////////////////////////////////////////////////////////////////////////
///  private  _MApp_ZUI_API_DrawComponent
///  draw a single style into GRAPHIC_DC (for drawing built-in components)
///
///  @param [in]  component DRAWCOMPONENT    style(component) type
///  @param [in]  u16Index  U16              style(component) index
///  @param [in]  pdc GRAPHIC_DC *    target GRAPHIC_DC wants to paint for
///  @param [in]  rect RECT *    target region wants to draw
///
///  This function doesn't return a value
///
///  @author MStar @date 2007/1/25
///////////////////////////////////////////////////////////////////////////////
void _MApp_ZUI_API_DrawComponent(DRAWCOMPONENT component, U16 u16Index, const GRAPHIC_DC * pdc, const RECT * rect)
{


    switch(component)
    {
        case CP_RECT_BORDER:
            {
                DRAW_RECT_BORDER * paramRectBorder = (DRAW_RECT_BORDER*)&_Zui_RectBorder_List[u16Index];
                _MApp_ZUI_API_DrawDynamicComponent(CP_RECT_BORDER, paramRectBorder, pdc, rect);
            }
            break;

        case CP_FILL_RECT:
            {
                DRAW_FILL_RECT * paramFillRect = (DRAW_FILL_RECT*)&_Zui_FillRect_List[u16Index];
                _MApp_ZUI_API_DrawDynamicComponent(CP_FILL_RECT, paramFillRect, pdc, rect);

            }
            break;

        case CP_TEXT_OUT:
            {
                DRAW_TEXT_OUT * paramTextOut = (DRAW_TEXT_OUT*)&_Zui_TextOut_List[u16Index];
                _MApp_ZUI_API_DrawDynamicComponent(CP_TEXT_OUT, paramTextOut, pdc, rect);

            }
            break;

        case CP_BITMAP:
            {
                DRAW_BITMAP * paramBitmap = (DRAW_BITMAP*)&_Zui_Bitmap_List[u16Index];
                _MApp_ZUI_API_DrawDynamicComponent(CP_BITMAP, paramBitmap, pdc, rect);

            }
            break;

        case CP_RECT:
            {

                DRAW_RECT * paramRect = (DRAW_RECT*)&_Zui_Rect_List[u16Index];
                _MApp_ZUI_API_DrawDynamicComponent(CP_RECT, paramRect, pdc, rect);

            }
            break;
    #if ENABLE_JPEGPNG_OSD
        case CP_JPEG:
            {
                DRAW_JPEG * paramJpeg = (DRAW_JPEG*)&_Zui_JPEG_List[u16Index];
                _MApp_ZUI_API_DrawDynamicComponent(CP_JPEG, paramJpeg, pdc, rect);

            }
            break;
    #endif

        default:
            break;
    }
}


///////////////////////////////////////////////////////////////////////////////
///  private  _MApp_ZUI_API_DrawDynamicComponent
///  draw a single style into GRAPHIC_DC (for drawing user-defined components)
///
///  @param [in]  component DRAWCOMPONENT         style(component) type
///  @param [in]  param void *                    style(component) parameters
///  @param [in]  pdc GRAPHIC_DC *    target GRAPHIC_DC wants to paint for
///  @param [in]  rect RECT *    target region wants to draw
///
///  This function doesn't return a value
///
///  @author MStar @date 2007/1/25
///////////////////////////////////////////////////////////////////////////////
void _MApp_ZUI_API_DrawDynamicComponent(DRAWCOMPONENT component, const void * param, const GRAPHIC_DC * pdc, const RECT * rect)
{
    RECT rectGWin, rectClip;
    RECT_SET(rectGWin, 0, 0, 0, 0);
    RECT_SET(rectClip, 0, 0, 0, 0);

    MApp_ZUI_API_QueryGWinRect(&rectGWin);
    rectClip = *rect;
    if ( (rectGWin.left + rectClip.left + rectClip.width) > g_IPanel.Width() )
    {
        rectClip.width = g_IPanel.Width() - rectClip.left - rectGWin.left;
    }

    msAPI_OSD_SetClipWindow(rectClip.left, rectClip.top, rectClip.left+rectClip.width-1, rectClip.top+rectClip.height-1);
    MApi_GOP_GWIN_Switch2FB(pdc->u8FbID);//SetDstBuffer(pGC, BUFFER_DISPLAY);
#if (ENABLE_UI_3D_PROCESS)
    MApi_GFX_SetNearestMode(FALSE); //default setting
    MApi_GFX_SetDither (FALSE);
#else
    MApi_GFX_SetNearestMode(TRUE); //default setting
    #if ENABLE_CUS_UI_SPEC
    MApi_GFX_SetDither (FALSE);
    #else
    MApi_GFX_SetDither (TRUE);
    #endif
#endif
#if (MPLAYER_BITMAP_FORMAT == MPLAYER_ARGB4444 || MPLAYER_BITMAP_FORMAT == MPLAYER_ARGB8888)
    //for ARGB4444 and ARGB8888, use bitmap original alpha value
    if (pdc->bSrcAlphaReplaceDstAlpha)
        MApi_GFX_SetAlpha(TRUE, COEF_ASRC, ABL_FROM_ASRC, 0);
    else
        MApi_GFX_SetAlpha(TRUE, COEF_ASRC, ABL_FROM_ADST, 0);
#elif (MPLAYER_BITMAP_FORMAT == MPLAYER_ARGB1555)
    if (pdc->bSrcAlphaReplaceDstAlpha)
    {
        MApi_GFX_SetAlpha(TRUE, COEF_CONST, ABL_FROM_ASRC, pdc->u8ConstantAlpha);
    }
    else
    {
        MApi_GFX_SetAlpha(TRUE, COEF_CONST, ABL_FROM_ADST, pdc->u8ConstantAlpha);
    }
#elif (MPLAYER_BITMAP_FORMAT == MPLAYER_I8)
    //for I8 palette mode, alpha disabled
#else
    if (pdc->u8ConstantAlpha == 0xFF)
    {
        MApi_GFX_SetAlpha(FALSE, COEF_CONST, ABL_FROM_CONST, 0xFF);
    }
    else
    {
        MApi_GFX_SetAlpha(TRUE, COEF_CONST, ABL_FROM_CONST, pdc->u8ConstantAlpha);
    }
#endif

    switch(component)
    {
        case CP_RECT_BORDER:
            {
                DRAW_RECT_BORDER * paramRectBorder = (DRAW_RECT_BORDER*)param;
                U8 i;

                g_ClrLine.u8LineWidth    = 1;

                for(i=0; i<paramRectBorder->thickness; i++)
                {
                    RECT R;
                    RECT_SET(R, rect->left+i, rect->top+i, rect->width-(i<<1), rect->height-(i<<1));

                    g_ClrLine.u32LineColor    = paramRectBorder->colorLeftTop;
                    g_ClrLine.x1 = R.left;
                    g_ClrLine.y1 = R.top;
                    g_ClrLine.x2 = (R.left+R.width);
                    g_ClrLine.y2 = R.top;
                    msAPI_OSD_DrawLine(&g_ClrLine);

                    g_ClrLine.u32LineColor    = paramRectBorder->colorRightDown;
                    g_ClrLine.x1 = (R.left+R.width-1);
                    g_ClrLine.y1 = R.top;
                    g_ClrLine.x2 = (R.left+R.width-1);
                    g_ClrLine.y2 = (R.top+R.height+1);
                    msAPI_OSD_DrawLine(&g_ClrLine);

                    g_ClrLine.u32LineColor    = paramRectBorder->colorLeftTop;
                    g_ClrLine.x1 = R.left;
                    g_ClrLine.y1 = R.top;
                    g_ClrLine.x2 = R.left;
                    g_ClrLine.y2 = (R.top+R.height);
                    msAPI_OSD_DrawLine(&g_ClrLine);

                    g_ClrLine.u32LineColor    = paramRectBorder->colorRightDown;
                    g_ClrLine.x1 = R.left;
                    g_ClrLine.y1 = (R.top+R.height-1);
                    g_ClrLine.x2 = (R.left+R.width+1);
                    g_ClrLine.y2 = (R.top+R.height-1);
                    msAPI_OSD_DrawLine(&g_ClrLine);

                }
            }
            break;

        case CP_FILL_RECT:
            {
                DRAW_FILL_RECT * paramFillRect = (DRAW_FILL_RECT*)param;

                clrBtn1.x = rect->left;
                clrBtn1.y = rect->top;
                clrBtn1.width = rect->width;
                clrBtn1.height = rect->height;
                clrBtn1.u8Gradient = paramFillRect->eGradient;
                clrBtn1.fHighLight = FALSE;
                clrBtn1.g_clr = paramFillRect->toColor;
                clrBtn1.b_clr = paramFillRect->fromColor;

                msAPI_OSD_DrawBlock(&clrBtn1);

            }
            break;

        /*case CP_RECT_BORDER_EX:
            {
                DRAW_RECT_BORDER_EX * param = (DRAW_RECT_BORDER_EX*)style_list->param;
                MApi_Osd_DrawRectangleBorderEx(hdc->pGC,
                                rect,
                                UI_MENU_DRAW_COLOR_FMT,
                                param->colorTopLeft,
                                param->colorTopRight,
                                param->colorRightTop,
                                param->colorRightDown,
                                param->colorDownRight,
                                param->colorDownLeft,
                                param->colorLeftDown,
                                param->colorLeftTop,
                                param->thickness,
                                param->lt,
                                hdc->pAlpha);
            }
            break;

        case CP_RECT_3D:
            {
                DRAW_RECT_3D * param = (DRAW_RECT_3D*)style_list->param;
                MApi_Osd_Draw3DRectangle(hdc->pGC,
                                rect,
                                UI_MENU_DRAW_COLOR_FMT,
                                param->COLOR_3DBORDER_DARK,
                                param->COLOR_3DBORDER_LIGHT,
                                param->borderWidth,
                                param->flag,
                                hdc->pAlpha);
            }
            break;*/

        case CP_TEXT_OUT:
            {
                DRAW_TEXT_OUT * paramTextOut = (DRAW_TEXT_OUT*)param;
                U16 * pString = MApp_ZUI_API_GetString(paramTextOut->StringID);

                clrBtn1.x = rect->left;
                clrBtn1.y = rect->top;
                clrBtn1.width = rect->width;
                clrBtn1.height = rect->height;
                #if (MPLAYER_BITMAP_FORMAT == MPLAYER_I8)
                clrBtn1.t_clr = paramTextOut->TextColor&0xFF;
                #else //ZUI_ENABLE_PALETTE
                clrBtn1.t_clr = paramTextOut->TextColor;
                #endif //ZUI_ENABLE_PALETTE

                clrBtn1.Fontfmt.flag = paramTextOut->flag;
                clrBtn1.Fontfmt.ifont_gap = paramTextOut->u8dis;
                clrBtn1.bStringIndexWidth = CHAR_IDX_2BYTE;

                switch (paramTextOut->eTextAttrib)  // XM CUS ZHIQIN ADD
                {
                    case eTextAlignLeft:
                       if(stGenSetting.g_SysSetting.Language == LANGUAGE_ARABIC
                    #if(UI_SKIN_SEL==UI_SKIN_1366X768X565_HAIER_CN)  // CUS_xm zHIHE 20120814 modify
					   	  ||stGenSetting.g_SysSetting.Language == LANGUAGE_FARSI
					   	  ||stGenSetting.g_SysSetting.Language == LANGUAGE_HEBREW
					#endif   	  
					   	 )
		//cus_xm zhihe  20120815 modify			   	 
                            {
                                clrBtn1.enTextAlign = EN_ALIGNMENT_RIGHT;
                            }
                        else
                            {
                                clrBtn1.enTextAlign = EN_ALIGNMENT_LEFT;
                            }
                        break;
                    case eTextAlignMiddle:
                    case eTextAlignMiddleWH:
                    case eTextAlignLeft_MiddleH:
                    case eTextAlignRight_MiddleH:
                        clrBtn1.enTextAlign = EN_ALIGNMENT_CENTER;
                        break;
                    case eTextAlignRight:
                        clrBtn1.enTextAlign = EN_ALIGNMENT_RIGHT;
                        break;
                    default:
                        clrBtn1.enTextAlign = EN_ALIGNMENT_DEFAULT;
                        break;
                }
                #if ENABLE_CUS_SUPPORT_SIMP_CH_ARABIC_FONT
                if((paramTextOut->eSystemFont == FONT_CHINESE) || (paramTextOut->eSystemFont == FONT_ASIA))
                {
                    if(stGenSetting.g_SysSetting.Language==LANGUAGE_ARABIC||stGenSetting.g_SysSetting.Language==LANGUAGE_THAI||stGenSetting.g_SysSetting.Language==LANGUAGE_HEBREW)
                    {
                        paramTextOut->eSystemFont=FONT_ASIA;//FONT_SMALL;
                    }
                    else
                    {
                        paramTextOut->eSystemFont=FONT_CHINESE;//FONT_SMALL;
                    }
                }
                #endif

                msAPI_OSD_DrawClippedString(Font[paramTextOut->eSystemFont].fHandle,
                    pString, &clrBtn1, EN_STRING_ENDING_2_DOT);

            }
            break;


        case CP_TEXT_OUT_DYNAMIC:
            {
                DRAW_TEXT_OUT_DYNAMIC * paramTextOut = (DRAW_TEXT_OUT_DYNAMIC*)param;

                clrBtn1.x = rect->left;
                clrBtn1.y = rect->top;
                clrBtn1.width = rect->width;
                clrBtn1.height = rect->height;
                #if (MPLAYER_BITMAP_FORMAT == MPLAYER_I8)
                clrBtn1.t_clr = paramTextOut->TextColor&0xFF;
                #else //ZUI_ENABLE_PALETTE
                clrBtn1.t_clr = paramTextOut->TextColor;
                #endif //ZUI_ENABLE_PALETTE

                clrBtn1.Fontfmt.flag = paramTextOut->flag;
                clrBtn1.Fontfmt.ifont_gap = paramTextOut->u8dis;
                clrBtn1.bStringIndexWidth = CHAR_IDX_2BYTE;

                switch (paramTextOut->eTextAttrib)
                {
                    case eTextAlignLeft:
                        clrBtn1.enTextAlign = EN_ALIGNMENT_LEFT;
                        break;
                    case eTextAlignMiddle:
                    case eTextAlignMiddleWH:
                    case eTextAlignLeft_MiddleH:
                    case eTextAlignRight_MiddleH:
                        clrBtn1.enTextAlign = EN_ALIGNMENT_CENTER;
                        break;
                    case eTextAlignRight:
                        clrBtn1.enTextAlign = EN_ALIGNMENT_RIGHT;
                        break;
                    default:
                        clrBtn1.enTextAlign = EN_ALIGNMENT_DEFAULT;
                        break;
                }
                #if ENABLE_CUS_SUPPORT_SIMP_CH_ARABIC_FONT
                if((paramTextOut->eSystemFont == FONT_CHINESE) || (paramTextOut->eSystemFont == FONT_ASIA))
                {
                    if(stGenSetting.g_SysSetting.Language==LANGUAGE_ARABIC||stGenSetting.g_SysSetting.Language==LANGUAGE_THAI||stGenSetting.g_SysSetting.Language==LANGUAGE_HEBREW)
                    {
                        paramTextOut->eSystemFont=FONT_ASIA;//FONT_SMALL;
                    }
                    else
                    {
                        paramTextOut->eSystemFont=FONT_CHINESE;//FONT_SMALL;
                    }
                }
                #endif

                msAPI_OSD_DrawClippedString(Font[paramTextOut->eSystemFont].fHandle,
                    paramTextOut->pString, &clrBtn1, (EN_STRING_ENDING_TYPE)paramTextOut->u8dots/*EN_STRING_ENDING_3_DOT*/);


            }
            break;


        case CP_PUNCTUATED_DYNAMIC:
            {
                //NOTE: we define CP_PUNCTUATED_DYNAMIC use original height with max row
                //      this component also automatically H-center,
                //      not the same as msAPI_OSD_DrawPunctuatedString() only define the first single height

                DRAW_PUNCTUATED_DYNAMIC * paramTextOut = (DRAW_PUNCTUATED_DYNAMIC*)param;
                U8 u8Row;
                U16 u16Height;
                //U16 * pString = MApp_ZUI_API_GetString(paramTextOut->StringID);

                if (paramTextOut->max_row == 0) break;

                clrBtn1.x = rect->left + 2; //note: reserve 2 pixel for avoiding crop...
                clrBtn1.y = rect->top;
                clrBtn1.width = rect->width - 8; //note: reserve 8 pixel for avoiding crop...
                clrBtn1.height = rect->height / paramTextOut->max_row;
                #if (MPLAYER_BITMAP_FORMAT == MPLAYER_I8)
                clrBtn1.t_clr = paramTextOut->TextColor&0xFF;
                #else //ZUI_ENABLE_PALETTE
                clrBtn1.t_clr = paramTextOut->TextColor;
                #endif //ZUI_ENABLE_PALETTE

                clrBtn1.Fontfmt.flag = paramTextOut->flag;
                clrBtn1.Fontfmt.ifont_gap = paramTextOut->u8dis;
                clrBtn1.bStringIndexWidth = CHAR_IDX_2BYTE;

                switch (paramTextOut->eTextAttrib)
                {
                    case eTextAlignLeft:
                        clrBtn1.enTextAlign = EN_ALIGNMENT_LEFT;
                        break;
                    case eTextAlignMiddle:
                    case eTextAlignMiddleWH:
                    case eTextAlignLeft_MiddleH:
                    case eTextAlignRight_MiddleH:
                        clrBtn1.enTextAlign = EN_ALIGNMENT_CENTER;
                        break;
                    case eTextAlignRight:
                        clrBtn1.enTextAlign = EN_ALIGNMENT_RIGHT;
                        break;
                    default:
                        clrBtn1.enTextAlign = EN_ALIGNMENT_DEFAULT;
                        break;
                }

                #if ENABLE_CUS_SUPPORT_SIMP_CH_ARABIC_FONT
                if((paramTextOut->eSystemFont == FONT_CHINESE) || (paramTextOut->eSystemFont == FONT_ASIA))
                {
                    if(stGenSetting.g_SysSetting.Language==LANGUAGE_ARABIC||stGenSetting.g_SysSetting.Language==LANGUAGE_THAI||stGenSetting.g_SysSetting.Language==LANGUAGE_HEBREW)
                    {
                        paramTextOut->eSystemFont=FONT_ASIA;//FONT_SMALL;
                    }
                    else
                    {
                        paramTextOut->eSystemFont=FONT_CHINESE;//FONT_SMALL;
                    }
                }
                #endif

                msAPI_OSD_GetPunctuatedStringHeight(Font[paramTextOut->eSystemFont].fHandle,
                    paramTextOut->pString, &clrBtn1, paramTextOut->max_row, &u8Row, &u16Height);

                //printf("[]row=%bu,height=%u\n", u8Row, u16Height);

                if (u8Row > 0 && u16Height > 0)
                {
                    if (u16Height < rect->height)
                    {
                        clrBtn1.y += (rect->height-u16Height)/2;
                    }
                    if ( u8Row > paramTextOut->max_row )
                    {
                        u8Row = paramTextOut->max_row;
                    }

                    msAPI_OSD_DrawPunctuatedString(Font[paramTextOut->eSystemFont].fHandle,
                        paramTextOut->pString, &clrBtn1, u8Row);
                }

            }
            break;

        case CP_EPG_PUNCTUATED_DYNAMIC:
            {
                //NOTE: we define CP_PUNCTUATED_DYNAMIC use original height with max row
                //      this component also automatically H-center,
                //      not the same as msAPI_OSD_DrawPunctuatedString() only define the first single height

                DRAW_PUNCTUATED_DYNAMIC * paramTextOut = (DRAW_PUNCTUATED_DYNAMIC*)param;

                if (paramTextOut->max_row == 0) break;

                clrBtn1.x = rect->left + 2; //note: reserve 2 pixel for avoiding crop...
                clrBtn1.y = rect->top;
                clrBtn1.width = rect->width - 8; //note: reserve 8 pixel for avoiding crop...
                clrBtn1.height = rect->height / paramTextOut->max_row;
                #if (MPLAYER_BITMAP_FORMAT == MPLAYER_I8)
                clrBtn1.t_clr = paramTextOut->TextColor&0xFF;
                #else //ZUI_ENABLE_PALETTE
                clrBtn1.t_clr = paramTextOut->TextColor;
                #endif //ZUI_ENABLE_PALETTE

                clrBtn1.Fontfmt.flag = paramTextOut->flag;
                clrBtn1.Fontfmt.ifont_gap = paramTextOut->u8dis;
                clrBtn1.bStringIndexWidth = CHAR_IDX_2BYTE;

                switch (paramTextOut->eTextAttrib)
                {
                    case eTextAlignLeft:
                        clrBtn1.enTextAlign = EN_ALIGNMENT_LEFT;
                        break;
                    case eTextAlignMiddle:
                    case eTextAlignMiddleWH:
                    case eTextAlignLeft_MiddleH:
                    case eTextAlignRight_MiddleH:
                        clrBtn1.enTextAlign = EN_ALIGNMENT_CENTER;
                        break;
                    case eTextAlignRight:
                        clrBtn1.enTextAlign = EN_ALIGNMENT_RIGHT;
                        break;
                    default:
                        clrBtn1.enTextAlign = EN_ALIGNMENT_DEFAULT;
                        break;
                }


                #if ENABLE_CUS_SUPPORT_SIMP_CH_ARABIC_FONT
                if((paramTextOut->eSystemFont == FONT_CHINESE) || (paramTextOut->eSystemFont == FONT_ASIA))
                {
                    if(stGenSetting.g_SysSetting.Language==LANGUAGE_ARABIC||stGenSetting.g_SysSetting.Language==LANGUAGE_THAI||stGenSetting.g_SysSetting.Language==LANGUAGE_HEBREW)
                    {
                        paramTextOut->eSystemFont=FONT_ASIA;//FONT_SMALL;
                    }
                    else
                    {
                        paramTextOut->eSystemFont=FONT_CHINESE;//FONT_SMALL;
                    }
                }
                #endif

                msAPI_OSD_DrawPunctuatedString_S1(Font[paramTextOut->eSystemFont].fHandle,
                    (U8*)paramTextOut->pString, &clrBtn1, paramTextOut->max_row);

            }
            break;

        case CP_BT_TEXT_DYNAMIC:
            {
                //NOTE: we define CP_PUNCTUATED_DYNAMIC use original height with max row
                //      this component also automatically H-center,
                //      not the same as msAPI_OSD_DrawPunctuatedString() only define the first single height

                DRAW_PUNCTUATED_DYNAMIC * paramTextOut = (DRAW_PUNCTUATED_DYNAMIC*)param;

                if (paramTextOut->max_row == 0) break;

                clrBtn1.x = rect->left + 2; //note: reserve 2 pixel for avoiding crop...
                clrBtn1.y = rect->top;
                clrBtn1.width = rect->width - 8; //note: reserve 8 pixel for avoiding crop...
                clrBtn1.height = rect->height / paramTextOut->max_row;
                #if (MPLAYER_BITMAP_FORMAT == MPLAYER_I8)
                clrBtn1.t_clr = paramTextOut->TextColor&0xFF;
                #else //ZUI_ENABLE_PALETTE
                clrBtn1.t_clr = paramTextOut->TextColor;
                #endif //ZUI_ENABLE_PALETTE

                clrBtn1.Fontfmt.flag = paramTextOut->flag;
                clrBtn1.Fontfmt.ifont_gap = paramTextOut->u8dis;
                clrBtn1.bStringIndexWidth = CHAR_IDX_2BYTE;

                switch (paramTextOut->eTextAttrib)
                {
                    case eTextAlignLeft:
                        clrBtn1.enTextAlign = EN_ALIGNMENT_LEFT;
                        break;
                    case eTextAlignMiddle:
                    case eTextAlignMiddleWH:
                    case eTextAlignLeft_MiddleH:
                    case eTextAlignRight_MiddleH:
                        clrBtn1.enTextAlign = EN_ALIGNMENT_CENTER;
                        break;
                    case eTextAlignRight:
                        clrBtn1.enTextAlign = EN_ALIGNMENT_RIGHT;
                        break;
                    default:
                        clrBtn1.enTextAlign = EN_ALIGNMENT_DEFAULT;
                        break;
                }

                #if ENABLE_CUS_SUPPORT_SIMP_CH_ARABIC_FONT
                if((paramTextOut->eSystemFont == FONT_CHINESE) || (paramTextOut->eSystemFont == FONT_ASIA))
                {
                    if(stGenSetting.g_SysSetting.Language==LANGUAGE_ARABIC||stGenSetting.g_SysSetting.Language==LANGUAGE_THAI||stGenSetting.g_SysSetting.Language==LANGUAGE_HEBREW)
                    {
                        paramTextOut->eSystemFont=FONT_ASIA;//FONT_SMALL;
                    }
                    else
                    {
                        paramTextOut->eSystemFont=FONT_CHINESE;//FONT_SMALL;
                    }
                }
                #endif

                msAPI_OSD_DrawPunctuatedString_S2(Font[paramTextOut->eSystemFont].fHandle,
                    (U8*)paramTextOut->pString, &clrBtn1, paramTextOut->max_row);

            }
            break;


        case CP_BITMAP:
            {
                DRAW_BITMAP * paramBitmap = (DRAW_BITMAP*)param;
                U8 r_clr, g_clr, b_clr;

                #if (MPLAYER_BITMAP_FORMAT == MPLAYER_ARGB4444 || MPLAYER_BITMAP_FORMAT == MPLAYER_ARGB8888)
                //for ARGB4444 and ARGB8888, use bitmap original alpha value
                if (pdc->bSrcAlphaReplaceDstAlpha)
                    MApi_GFX_SetAlpha(TRUE, COEF_ASRC, ABL_FROM_ASRC, 0);
                else
                    MApi_GFX_SetAlpha(TRUE, COEF_ASRC, ABL_FROM_ADST, 0);
                #elif (MPLAYER_BITMAP_FORMAT == MPLAYER_ARGB1555)
                U16 a = paramBitmap->u8Constant_Alpha;
                a *= pdc->u8ConstantAlpha;
                if (pdc->bSrcAlphaReplaceDstAlpha)
                    MApi_GFX_SetAlpha(TRUE, COEF_CONST, ABL_FROM_ASRC, a/255);
                else
                    MApi_GFX_SetAlpha(TRUE, COEF_CONST, ABL_FROM_ADST, a/255);
                MApi_GFX_SetAlpha_ARGB1555(0xFF); //for alpha channel of ARGB1555 bitblt
                #elif (MPLAYER_BITMAP_FORMAT == MPLAYER_I8)
                //for I8 palette mode, alpha disabled
                #else
                //for RGB565 and RGB555, constant alpha used
                if (pdc->u8ConstantAlpha != 0xFF || paramBitmap->u8Constant_Alpha != 0xFF)
                {
                    U16 a = paramBitmap->u8Constant_Alpha;
                    a *= pdc->u8ConstantAlpha;
                    MApi_GFX_SetAlpha(TRUE, COEF_CONST, ABL_FROM_CONST, a/255);
                }
                #endif

                clrBtn1.x = rect->left;
                clrBtn1.y = rect->top;

                gbmpfmt.width = rect->width;
                gbmpfmt.height = rect->height;

                gbmpfmt.bScale = TRUE;

                if ( paramBitmap->bSrcColorKey )
                {
                    gbmpfmt.bBmpColorKeyEnable = TRUE;

                    r_clr=((paramBitmap->srcColorKeyFrom&0x00ff0000)>>16)&0xff;
                    g_clr=((paramBitmap->srcColorKeyFrom&0x0000ff00)>>8)&0xff;
                    b_clr=((paramBitmap->srcColorKeyFrom&0x000000ff))&0xff;

                    gbmpfmt.clrrange.color_s.a = 0;
                    gbmpfmt.clrrange.color_s.r = r_clr;
                    gbmpfmt.clrrange.color_s.g = g_clr;
                    gbmpfmt.clrrange.color_s.b = b_clr;

                    r_clr=((paramBitmap->srcColorKeyEnd&0x00ff0000)>>16)&0xff;
                    g_clr=((paramBitmap->srcColorKeyEnd&0x0000ff00)>>8)&0xff;
                    b_clr=((paramBitmap->srcColorKeyEnd&0x000000ff))&0xff;

                    gbmpfmt.clrrange.color_e.a = 0;
                    gbmpfmt.clrrange.color_e.r = r_clr;
                    gbmpfmt.clrrange.color_e.g = g_clr;
                    gbmpfmt.clrrange.color_e.b = b_clr;

                    #if (MPLAYER_BITMAP_FORMAT == MPLAYER_I8)
                    msAPI_OSD_DrawBitmap_I8(paramBitmap->u16BitmapIndex,
                        clrBtn1.x, clrBtn1.y, gbmpfmt);
                    #else
                    msAPI_OSD_DrawColorKeyBitmap(paramBitmap->u16BitmapIndex,
                        clrBtn1.x, clrBtn1.y, gbmpfmt);
                    #endif

                }
                else
                {
                    gbmpfmt.bBmpColorKeyEnable = FALSE;


#if (MPLAYER_BITMAP_FORMAT == MPLAYER_I8)
                    msAPI_OSD_DrawBitmap_I8(paramBitmap->u16BitmapIndex,
                        clrBtn1.x, clrBtn1.y, gbmpfmt);
#else
                    msAPI_OSD_DrawColorKeyBitmap(paramBitmap->u16BitmapIndex,
                        clrBtn1.x, clrBtn1.y, gbmpfmt);
#endif

                }

                #if (MPLAYER_BITMAP_FORMAT == MPLAYER_ARGB4444 || MPLAYER_BITMAP_FORMAT == MPLAYER_ARGB8888)
                MApi_GFX_SetAlpha(TRUE, COEF_CONST, ABL_FROM_CONST, 0xFF);
                #endif
            }
            break;

        /*case CP_ROUND_BAR:
            {
                DRAW_ROUND_BAR * param = (DRAW_ROUND_BAR*)style_list->param;
                MApi_Osd_DrawRoundBar(hdc->pGC,
                                rect,
                                UI_MENU_DRAW_COLOR_FMT,
                                param->colorFrom,
                                param->colorTo,
                                param->egradient,
                                param->bshadow,
                                param->eOSD_RoundBar,
                                hdc->pAlpha);
            }
            break;

        case CP_WINDOW:
            {
                DRAW_WINDOW * param = (DRAW_WINDOW*)style_list->param;
                MApi_Osd_DrawWindow(hdc->pGC,
                                UI_MENU_DRAW_COLOR_FMT,
                                rect,
                                param->titleHeight,
                                param->colorTitle,
                                param->colorBkgnd,
                                param->attrib,
                                param->BroderColor,
                                param->sizeBorder,
                                param->bShadow,
                                hdc->pAlpha);
            }
            break;*/

        case CP_RECT:
            {

                DRAW_RECT * paramRect = (DRAW_RECT*)param;

                clrBtn1.x = rect->left;
                clrBtn1.y = rect->top;

                clrBtn1.width = rect->width;
                clrBtn1.height = rect->height;
                clrBtn1.u8Gradient = paramRect->eRectGradient;
                clrBtn1.fHighLight = FALSE;

                clrBtn1.b_clr = paramRect->RcolorFrom;
                clrBtn1.g_clr = paramRect->RcolorTo;

                if (paramRect->attrib == eRectBorderRound &&
                    paramRect->radius > 0)
                {
                    clrBtn1.radius = paramRect->radius;
                    if (clrBtn1.u8Gradient == CONSTANT_COLOR)
                    {
                      #if (MPLAYER_BITMAP_FORMAT == MPLAYER_ARGB1555)
                             MApi_GFX_SetAlphaSrcFrom(ABL_FROM_CONST);
                             MApi_GFX_EnableAlphaBlending(TRUE);
                      #endif
                        msAPI_OSD_DrawRoundBlock(&clrBtn1);
                      #if (MPLAYER_BITMAP_FORMAT == MPLAYER_ARGB1555)
                             MApi_GFX_EnableAlphaBlending(FALSE);
                      #endif
                    }
                    else
                    {
                        //note: msAPI_OSD_DrawGradientRoundBlock() only support gradient_y
                        //      so we ignore radious....
                        #if (MPLAYER_BITMAP_FORMAT != MPLAYER_I8)
                        if ( clrBtn1.u8Gradient == OSD_COLOR_GRADIENT_Y )
                        {
                           #if (MPLAYER_BITMAP_FORMAT == MPLAYER_ARGB1555)
                             MApi_GFX_SetAlphaSrcFrom(ABL_FROM_CONST);
                             MApi_GFX_EnableAlphaBlending(TRUE);
                           #endif
                            msAPI_OSD_DrawGradientRoundBlock(&clrBtn1);
                           #if (MPLAYER_BITMAP_FORMAT == MPLAYER_ARGB1555)
                             MApi_GFX_EnableAlphaBlending(FALSE);
                           #endif
                        }
                        else
                        #endif
                        {
                            msAPI_OSD_DrawBlock(&clrBtn1);
                        }
                    }
                }
                else
                {
                    //clrBtn1.radius = 0;
                    msAPI_OSD_DrawBlock(&clrBtn1);
                }
            }
            break;

        /*case CP_DASH_BAR:
            {
                DRAW_DASH_BAR * param = (DRAW_DASH_BAR*)style_list->param;
                MApi_Osd_DrawDashBar(hdc->pGC,
                                UI_MENU_DRAW_COLOR_FMT,
                                rect,
                                param->colorFrom,
                                param->colorTo,
                                param->bXdirection,
                                param->dash_len,
                                hdc->pAlpha);
            }
            break;*/

        /*/case CP_TRIANGLE:
            {
                paramTriangle = (DRAW_TRIANGLE*)&_NewSkin_Triangle_List[u16Index];
                //PRINT("[CP_TRIANGLE] param=%X, color=%X\n", param, param->color);
                MApi_Osd_DrawTriangle(hdc->pGC,
                                UI_MENU_DRAW_COLOR_FMT,
                                paramTriangle->style,
                                rect,
                                paramTriangle->color,
                                hdc->pAlpha);
            }
            break;*/

        /*case CP_CIRCLE:
            {
                DRAW_CIRCLE * param = (DRAW_CIRCLE*)style_list->param;
                Pos center = { rect->left + rect->width/2, rect->top + rect->height/2 };
                MApi_Osd_DrawCircle(hdc->pGC,
                                &center,
                                MIN(rect->width, rect->height)/2 - 2, //avoiding shadow overlapping
                                UI_MENU_DRAW_COLOR_FMT,
                                param->colorFrom,
                                param->colorTo,
                                hdc->pAlpha,
                                param->bShadow);
            }
            break;

        case CP_ROUND_BORDER:
            {
                DRAW_ROUND_BORDER * param = (DRAW_ROUND_BORDER*)style_list->param;
                MApi_Osd_DrawRoundBorder(hdc->pGC,
                                param->radius,
                                rect,
                                param->u16BorderWidth,
                                UI_MENU_DRAW_COLOR_FMT,
                                param->BorderColor,
                                hdc->pAlpha);
            }
            break;*/
     #if TXTFONT_ZOOM2X
        case CP_ZOOM2X_PUNCTUATED_DYNAMIC:
            {
                //NOTE: we define CP_ZOOM2X_PUNCTUATED_DYNAMIC use original height with max row
                //      this component also automatically H-center,
                //      not the same as msAPI_OSD_DrawPunctuatedString() only define the first single height

                DRAW_PUNCTUATED_DYNAMIC * paramTextOut = (DRAW_PUNCTUATED_DYNAMIC*)param;

                if (paramTextOut->max_row == 0) break;

                clrBtn1.x = rect->left + 2; //note: reserve 2 pixel for avoiding crop...
                clrBtn1.y = rect->top;
                clrBtn1.width = rect->width - 8; //note: reserve 8 pixel for avoiding crop...
                clrBtn1.height = rect->height / paramTextOut->max_row;
                #if (MPLAYER_BITMAP_FORMAT == MPLAYER_I8)
                clrBtn1.t_clr = paramTextOut->TextColor&0xFF;
                #else //ZUI_ENABLE_PALETTE
                clrBtn1.t_clr = paramTextOut->TextColor;
                #endif //ZUI_ENABLE_PALETTE
                clrBtn1.Fontfmt.flag = paramTextOut->flag;
                clrBtn1.Fontfmt.ifont_gap = paramTextOut->u8dis;
                clrBtn1.bStringIndexWidth = CHAR_IDX_2BYTE;

                switch (paramTextOut->eTextAttrib)
                {
                    case eTextAlignLeft:
                        clrBtn1.enTextAlign = EN_ALIGNMENT_LEFT;
                        break;
                    case eTextAlignMiddle:
                    case eTextAlignMiddleWH:
                    case eTextAlignLeft_MiddleH:
                    case eTextAlignRight_MiddleH:
                        clrBtn1.enTextAlign = EN_ALIGNMENT_CENTER;
                        break;
                    case eTextAlignRight:
                        clrBtn1.enTextAlign = EN_ALIGNMENT_RIGHT;
                        break;
                    default:
                        clrBtn1.enTextAlign = EN_ALIGNMENT_DEFAULT;
                        break;
                }

                #if ENABLE_CUS_SUPPORT_SIMP_CH_ARABIC_FONT
                if((paramTextOut->eSystemFont == FONT_CHINESE) || (paramTextOut->eSystemFont == FONT_ASIA))
                {
                    if(stGenSetting.g_SysSetting.Language==LANGUAGE_ARABIC||stGenSetting.g_SysSetting.Language==LANGUAGE_THAI||stGenSetting.g_SysSetting.Language==LANGUAGE_HEBREW)
                    {
                        paramTextOut->eSystemFont=FONT_ASIA;//FONT_SMALL;
                    }
                    else
                    {
                        paramTextOut->eSystemFont=FONT_CHINESE;//FONT_SMALL;
                    }
                }
                #endif
                msAPI_OSD_DrawPunctuatedString_Zoom2X(Font[paramTextOut->eSystemFont].fHandle,
                    (U8*)paramTextOut->pString, &clrBtn1, paramTextOut->max_row);
            }
            break;
    #endif
	#if ENABLE_JPEGPNG_OSD
        case CP_JPEG:
            {
                DRAW_JPEG * paramJpeg = (DRAW_JPEG*)param;
                msAPI_OSD_DrawJpegPng(paramJpeg->index, rect->left, rect->top, rect->width, rect->height, pdc->u8FbID, pdc->bSrcAlphaReplaceDstAlpha, 0xE0);
            }
            break;
        case CP_ALPHA_JPEG:
            {
                DRAW_JPEG * paramJpeg = (DRAW_JPEG*)param;
                DRAW_BITMAP * paramBitmap = (DRAW_BITMAP*)param;
                msAPI_OSD_DrawJpegPng(paramJpeg->index, rect->left, rect->top, rect->width, rect->height, pdc->u8FbID, pdc->bSrcAlphaReplaceDstAlpha, paramBitmap->u8Constant_Alpha);
            }
            break;
	#endif

        default:
            break;
    }
    MApi_GFX_SetDither (FALSE);
}

///////////////////////////////////////////////////////////////////////////////
///  private  _MApp_ZUI_API_ConvertTextComponentToDynamic
///  convert static "DRAW_TEXT_OUT" component to "DRAW_TEXT_OUT_DYNAMIC" component
///
///  @param [in]  u16TextOutIndex U16         built-in DRAW_TEXT_OUT component index
///  @param [out]  pComp DRAW_TEXT_OUT_DYNAMIC   user-defined DRAW_TEXT_OUT_DYNAMIC parameters
///
///  This function doesn't return a value
///
///  @author MStar @date 2007/1/25
///////////////////////////////////////////////////////////////////////////////
void _MApp_ZUI_API_ConvertTextComponentToDynamic(U16 u16TextOutIndex, DRAW_TEXT_OUT_DYNAMIC * pComp)
{
    DRAW_TEXT_OUT * paramTextOut = (DRAW_TEXT_OUT*)&_Zui_TextOut_List[u16TextOutIndex];
    //pComp->bShadow = paramTextOut->bShadow;
    pComp->eSystemFont = paramTextOut->eSystemFont;
    pComp->eTextAttrib = paramTextOut->eTextAttrib;
    pComp->flag = paramTextOut->flag;
    pComp->TextColor = paramTextOut->TextColor;
    pComp->u8dis = paramTextOut->u8dis;
    pComp->u8dots = EN_STRING_ENDING_2_DOT;
}

///////////////////////////////////////////////////////////////////////////////
///  private  _MApp_ZUI_API_ConvertTextComponentToPunctuated
///  convert static "DRAW_TEXT_OUT" component to "DRAW_PUNCTUATED_DYNAMIC" component
///
///  @param [in]  u16TextOutIndex U16         built-in DRAW_TEXT_OUT component index
///  @param [out]  pComp DRAW_TEXT_OUT_DYNAMIC   user-defined DRAW_PUNCTUATED_DYNAMIC parameters
///
///  This function doesn't return a value
///
///  @author MStar @date 2007/1/25
///////////////////////////////////////////////////////////////////////////////
void _MApp_ZUI_API_ConvertTextComponentToPunctuated(U16 u16TextOutIndex, DRAW_PUNCTUATED_DYNAMIC * pComp)
{
    DRAW_TEXT_OUT * paramTextOut = (DRAW_TEXT_OUT*)&_Zui_TextOut_List[u16TextOutIndex];
    //pComp->bShadow = paramTextOut->bShadow;
    pComp->eSystemFont = paramTextOut->eSystemFont;
    pComp->eTextAttrib = paramTextOut->eTextAttrib;
    pComp->flag = paramTextOut->flag;
    pComp->TextColor = paramTextOut->TextColor;
    pComp->u8dis = paramTextOut->u8dis;
}

/*
///////////////////////////////////////////////////////////////////////////////
///  private  _MApp_ZUI_API_ConvertBitmapComponentToDynamic
///  convert static "DRAW_BITMAP" component to dynamic component
///
///  @param [in]  u16CompIndex U16         built-in DRAW_BITMAP component index
///  @param [out]  pComp DRAW_BITMAP   user-defined DRAW_BITMAP parameters
///
///  This function doesn't return a value
///
///  @author MStar @date 2007/1/25
///////////////////////////////////////////////////////////////////////////////
void _MApp_ZUI_API_ConvertBitmapComponentToDynamic(U16 u16CompIndex , DRAW_BITMAP * pComp)
{
    DRAW_BITMAP * paramBitmap = (DRAW_BITMAP*)&_Zui_Bitmap_List[u16CompIndex];
    memcpy(pComp, paramBitmap, sizeof(DRAW_BITMAP));
}
*/

///////////////////////////////////////////////////////////////////////////////
///  private  _MApp_ZUI_API_ConvertComponentToDynamic
///  convert static component to dynamic component
///
///  @param [in]  comp DRAWCOMPONENT       built-in component type
///  @param [in]  u16CompIndex U16         built-in component index
///  @param [out]  pDraw void *            user-defined drawing structure
///
///  This function doesn't return a value
///
///  @author MStar @date 2007/1/25
///////////////////////////////////////////////////////////////////////////////
void _MApp_ZUI_API_ConvertComponentToDynamic(DRAWCOMPONENT comp, U16 u16CompIndex, void * pDraw)
{
    switch(comp)
    {
        case CP_BITMAP:
            memcpy(pDraw, &_Zui_Bitmap_List[u16CompIndex], sizeof(DRAW_BITMAP));
            break;
        case CP_RECT:
            memcpy(pDraw, &_Zui_Rect_List[u16CompIndex], sizeof(DRAW_RECT));
            break;
        case CP_FILL_RECT:
            memcpy(pDraw, &_Zui_FillRect_List[u16CompIndex], sizeof(DRAW_FILL_RECT));
            break;
        case CP_RECT_BORDER:
            memcpy(pDraw, &_Zui_RectBorder_List[u16CompIndex], sizeof(DRAW_RECT_BORDER));
            break;
        case CP_TEXT_OUT:
            memcpy(pDraw, &_Zui_TextOut_List[u16CompIndex], sizeof(DRAW_TEXT_OUT));
            break;
   	#if ENABLE_JPEGPNG_OSD
        case CP_JPEG:
            memcpy(pDraw, &_Zui_JPEG_List[u16CompIndex], sizeof(DRAW_JPEG));
            break;
	#endif
        default:
            break;
    }

}

/*************************************************************************************************************/

#if 0//CUS35_TEST_PATTERN

#define PTP_DBG(x)      //x


extern BOOLEAN _MApp_ZUI_API_AllocateVarData(void);

typedef enum
{
    PANASONIC_TEST_MIN = 0,

    PANASONIC_TEST_00_WHITE = PANASONIC_TEST_MIN,
    PANASONIC_TEST_01_BLACK,
    PANASONIC_TEST_02_RED,
    PANASONIC_TEST_03_GREEN,
    PANASONIC_TEST_04_BLUE,
    PANASONIC_TEST_05_GRAY,
    PANASONIC_TEST_06_CYAN,
    PANASONIC_TEST_07_MAGENTA,
    PANASONIC_TEST_08_YELLOW,

    PANASONIC_TEST_09_BLACK_WHITE,
    PANASONIC_TEST_10_WHITE_BLACK,

    PANASONIC_TEST_11_GRADIENT_GS1,         // 0x0B
    PANASONIC_TEST_11_GRADIENT_GS2,
    PANASONIC_TEST_11_GRADIENT_GS3,
    PANASONIC_TEST_11_GRADIENT_GS4,

    PANASONIC_TEST_12_GRADIENT_GS1,         // 0x0F
    PANASONIC_TEST_12_GRADIENT_GS2,         // 0x10
    PANASONIC_TEST_12_GRADIENT_GS3,
    PANASONIC_TEST_12_GRADIENT_GS4,

    PANASONIC_TEST_13_GRADIENT_GS1,         // 0x13
    PANASONIC_TEST_13_GRADIENT_GS2,
    PANASONIC_TEST_13_GRADIENT_GS3,
    PANASONIC_TEST_13_GRADIENT_GS4,

    PANASONIC_TEST_14_GRADIENT_GS1,         // 0x17
    PANASONIC_TEST_14_GRADIENT_GS2,
    PANASONIC_TEST_14_GRADIENT_GS3,
    PANASONIC_TEST_14_GRADIENT_GS4,

    PANASONIC_TEST_15_FLICKER_A,            // 0x1B
    PANASONIC_TEST_15_FLICKER_B,
    PANASONIC_TEST_15_FLICKER_C,
    PANASONIC_TEST_15_FLICKER_D0,

    PANASONIC_TEST_16_GRAY_RAMP_SCROLL,     // 0x1F
    PANASONIC_TEST_17_1PIXEL_PIN_STRIPE,    // 0x20
    PANASONIC_TEST_18_2PIXEL_PIN_STRIPE,
    PANASONIC_TEST_19_1LINE_SIDE_STRIPE,

    PANASONIC_TEST_20_COLOR_BAR_1,          // 0x23
    PANASONIC_TEST_21_COLOR_BAR_2,

    PANASONIC_TEST_22_CIRCUMFERENCE,        // 0x25
    PANASONIC_TEST_23_DOT_DEFECT_DETECT,

    PANASONIC_TEST_24_H_SCROLL_NOTE,

    PANASONIC_PATTERN_MAX,
} PANASONIC_TEST_PATTERN_INDEX;

#define PANASONIC_WIDTH     1366
#define PANASONIC_HEIGHT    768

#define TP_WIDTH            1368
#define TP_HEIGHT           768

OSD_COLOR ColorBarTbl[] =
{
    COLOR_WHITE,
    COLOR_YELLOW,
    COLOR_CYAN,
    COLOR_GREEN,
    COLOR_MAGENTA,
    COLOR_RED,
    COLOR_BLUE,
    COLOR_BLACK,
};

void MApp_UiMenu_CUS35TestPaterm_DisplayBmp(U8 u8Pattern)
{
    RECT rect;
    RECT Wrect;//for bitmap use
    U16 i =0, j=0;
    U8 u8offset = 0;
    U16 u8width = 8;
    U16 u8height = 8;

    GRAPHIC_DC *Wdc = MApp_ZUI_API_GetScreenDC();
    DRAW_BITMAP * aparamBmp = (DRAW_BITMAP*)_ZUI_MALLOC(sizeof(DRAW_BITMAP));
    DRAW_FILL_RECT * aparamRect = (DRAW_FILL_RECT*)_ZUI_MALLOC(sizeof(DRAW_FILL_RECT));

    aparamBmp->u16BitmapIndex = 0;

    MApp_ZUI_ACT_ShutdownOSD();

//    RECT_SET(rect,0, 0, PANASONIC_WIDTH, PANASONIC_HEIGHT);
    RECT_SET(rect,0, 0, 960, 540);

    MApp_ZUI_API_TerminateGDI();

//    MApi_GOP_GWIN_Set_STRETCHWIN(E_GOP_OSD, E_GOP_DST_OP0,0, 0, 1366, 768);
//    MApi_GOP_GWIN_Set_HSCALE(FALSE, 960, 1366);
//    MApi_GOP_GWIN_Set_VSCALE(FALSE, 540, 768);

    PTP_DBG(printf(">> MApp_UiMenu_TestPaterm_DisplayBmp"));

    if (!_MApp_ZUI_API_AllocateVarData())
    {
//        ZUI_DBG_FAIL(printf("[ZUI]ALLOC \n"));
        printf(" [ZUI] ALLOC fail \r\n");
        ABORT();
        return;
    }

    PTP_DBG(printf("(%d) \r\n", u8Pattern));

    if (!MApp_ZUI_API_InitGDI(&rect))
    {
//        ZUI_DBG_FAIL(printf("[ZUI]GDIINIT\n"));
        printf("[ZUI] GDIINIT fail \r\n");
        ABORT();
        return;
    }

    switch (u8Pattern)
    {
        case PANASONIC_TEST_00_WHITE:
            aparamBmp->u16BitmapIndex = E_BMP_PANASONIC_00WHITE;
            PTP_DBG(printf("- E_BMP_PANASONIC_00WHITE \r\n"));
            break;

        case PANASONIC_TEST_01_BLACK:
            aparamBmp->u16BitmapIndex = E_BMP_PANASONIC_01BLACK;
            PTP_DBG(printf("- E_BMP_PANASONIC_01BLACK \r\n"));
            break;

        case PANASONIC_TEST_02_RED:
            aparamBmp->u16BitmapIndex = E_BMP_PANASONIC_02RED;
            PTP_DBG(printf("- E_BMP_PANASONIC_02RED \r\n)"));
            break;

        case PANASONIC_TEST_03_GREEN:
            aparamBmp->u16BitmapIndex = E_BMP_PANASONIC_03GREEN;
            PTP_DBG(printf("- E_BMP_PANASONIC_03GREEN \r\n"));
            break;

        case PANASONIC_TEST_04_BLUE:
            aparamBmp->u16BitmapIndex = E_BMP_PANASONIC_04BLUE;
            PTP_DBG(printf("- E_BMP_PANASONIC_04BLUE \r\n"));
            break;

        case PANASONIC_TEST_05_GRAY:
            aparamBmp->u16BitmapIndex = E_BMP_PANASONIC_05GRAY;
            PTP_DBG(printf("- E_BMP_PANASONIC_05GRAY \r\n"));
            break;

        case PANASONIC_TEST_06_CYAN:
            aparamBmp->u16BitmapIndex = E_BMP_PANASONIC_06CYAN;
            PTP_DBG(printf("- E_BMP_PANASONIC_06CYAN \r\n"));
            break;

        case PANASONIC_TEST_07_MAGENTA:
            aparamBmp->u16BitmapIndex = E_BMP_PANASONIC_07MAGENTA;
            PTP_DBG(printf("- E_BMP_PANASONIC_07MAGENTA \r\n"));
            break;

        case PANASONIC_TEST_08_YELLOW:
            aparamBmp->u16BitmapIndex = E_BMP_PANASONIC_08YELLOW;
            PTP_DBG(printf("- E_BMP_PANASONIC_08YELLOW \r\n"));
            break;

        case PANASONIC_TEST_09_BLACK_WHITE:
            aparamBmp->u16BitmapIndex = E_BMP_PANASONIC_09BLACK;
            u8width = 683;
            u8height = 1;
            PTP_DBG(printf("- PANASONIC_TEST_09_BLACK \r\n"));
            break;

        case PANASONIC_TEST_10_WHITE_BLACK:
            aparamBmp->u16BitmapIndex = E_BMP_PANASONIC_10WHITE;
            PTP_DBG(printf("- PANASONIC_TEST_10_WHITE \r\n"));
            break;

        case PANASONIC_TEST_11_GRADIENT_GS1:
        case PANASONIC_TEST_11_GRADIENT_GS4:
            aparamRect->fromColor = COLOR_BLACK;
            aparamRect->toColor = COLOR_WHITE;
            PTP_DBG(printf("- PANASONIC_TEST_11_GRADIENT_GS%d \r\n", (u8Pattern-PANASONIC_TEST_11_GRADIENT_GS1+1)));
            break;

        case PANASONIC_TEST_11_GRADIENT_GS2:
        case PANASONIC_TEST_11_GRADIENT_GS3:
            aparamRect->fromColor = COLOR_WHITE;
            aparamRect->toColor = COLOR_BLACK;
            PTP_DBG(printf("- PANASONIC_TEST_11_GRADIENT_GS%d \r\n", (u8Pattern-PANASONIC_TEST_11_GRADIENT_GS1+1)));
            break;

        case PANASONIC_TEST_12_GRADIENT_GS1:
        case PANASONIC_TEST_12_GRADIENT_GS4:
            aparamRect->fromColor = COLOR_BLACK;
            aparamRect->toColor = COLOR_RED;
            PTP_DBG(printf("- PANASONIC_TEST_12_GRADIENT_GS%d \r\n", (u8Pattern-PANASONIC_TEST_12_GRADIENT_GS1+1)));
            break;

        case PANASONIC_TEST_12_GRADIENT_GS2:
        case PANASONIC_TEST_12_GRADIENT_GS3:
            aparamRect->fromColor = COLOR_RED;
            aparamRect->toColor = COLOR_BLACK;
            PTP_DBG(printf("- PANASONIC_TEST_12_GRADIENT_GS%d \r\n", (u8Pattern-PANASONIC_TEST_12_GRADIENT_GS1+1)));
            break;

        case PANASONIC_TEST_13_GRADIENT_GS1:
        case PANASONIC_TEST_13_GRADIENT_GS4:
            aparamRect->fromColor = COLOR_BLACK;
            aparamRect->toColor = COLOR_GREEN;
            PTP_DBG(printf("- PANASONIC_TEST_13_GRADIENT_GS%d \r\n", (u8Pattern-PANASONIC_TEST_13_GRADIENT_GS1+1)));
            break;

        case PANASONIC_TEST_13_GRADIENT_GS2:
        case PANASONIC_TEST_13_GRADIENT_GS3:
            aparamRect->fromColor = COLOR_GREEN;
            aparamRect->toColor = COLOR_BLACK;
            PTP_DBG(printf("- PANASONIC_TEST_13_GRADIENT_GS%d \r\n", (u8Pattern-PANASONIC_TEST_13_GRADIENT_GS1+1)));
            break;

        case PANASONIC_TEST_14_GRADIENT_GS1:
        case PANASONIC_TEST_14_GRADIENT_GS4:
            aparamRect->fromColor = COLOR_BLACK;
            aparamRect->toColor = COLOR_BLUE;
            PTP_DBG(printf("- PANASONIC_TEST_14_GRADIENT_GS%d \r\n", (u8Pattern-PANASONIC_TEST_14_GRADIENT_GS1+1)));
            break;

        case PANASONIC_TEST_14_GRADIENT_GS2:
        case PANASONIC_TEST_14_GRADIENT_GS3:
            aparamRect->fromColor = COLOR_BLUE;
            aparamRect->toColor = COLOR_BLACK;
            PTP_DBG(printf("- PANASONIC_TEST_14_GRADIENT_GS%d \r\n", (u8Pattern-PANASONIC_TEST_14_GRADIENT_GS1+1)));
            break;

        case PANASONIC_TEST_15_FLICKER_A:
            aparamBmp->u16BitmapIndex = E_BMP_PANASONIC_FLICKER_A;
            PTP_DBG(printf("- E_BMP_PANASONIC_FLICKER_A \r\n"));
            break;

        case PANASONIC_TEST_15_FLICKER_B:
            aparamBmp->u16BitmapIndex = E_BMP_PANASONIC_FLICKER_B;
            PTP_DBG(printf("- E_BMP_PANASONIC_FLICKER_B \r\n"));
            break;

        case PANASONIC_TEST_15_FLICKER_C:
            aparamBmp->u16BitmapIndex = E_BMP_PANASONIC_FLICKER_C;
            PTP_DBG(printf("- E_BMP_PANASONIC_FLICKER_C \r\n"));
            break;

        case PANASONIC_TEST_15_FLICKER_D0:
            aparamBmp->u16BitmapIndex = E_BMP_PANASONIC_FLICKER_D0;
            u8offset = 1;
            PTP_DBG(printf("- E_BMP_PANASONIC_FLICKER_D0 \r\n"));
            break;

        case PANASONIC_TEST_16_GRAY_RAMP_SCROLL:
        case PANASONIC_TEST_23_DOT_DEFECT_DETECT:
        case PANASONIC_TEST_24_H_SCROLL_NOTE:
            aparamBmp->u16BitmapIndex = E_ZUI_BMP_MAX;
            PTP_DBG(printf("- Not Supported yet \r\n"));
            break;

        case PANASONIC_TEST_17_1PIXEL_PIN_STRIPE:
            aparamBmp->u16BitmapIndex = E_BMP_PANASONIC_17PINSTRIPE_1PIXEL;
//            u8width = 8;
//            u8height = 8;
            PTP_DBG(printf("- E_BMP_PANASONIC_17PINSTRIPE_1PIXEL \r\n"));
            break;

        case PANASONIC_TEST_18_2PIXEL_PIN_STRIPE:
            aparamBmp->u16BitmapIndex = E_BMP_PANASONIC_18PINSTRIPE_2PIXEL;
//            u8width = 4;
//            u8height = 4;
            PTP_DBG(printf("- E_BMP_PANASONIC_18PINSTRIPE_2PIXEL \r\n"));
            break;

        case PANASONIC_TEST_19_1LINE_SIDE_STRIPE:
            aparamBmp->u16BitmapIndex = E_BMP_PANASONIC_19SIDESTRIPE;
//            u8width = 2;
//            u8height = 1;
            PTP_DBG(printf("- E_BMP_PANASONIC_19SIDESTRIPE \r\n"));
            break;

        case PANASONIC_TEST_20_COLOR_BAR_1:
            aparamRect->toColor = COLOR_BLACK;
            PTP_DBG(printf("- PANASONIC_TEST_20_COLOR_BAR_1 \r\n"));
            break;

        case PANASONIC_TEST_21_COLOR_BAR_2:
            aparamBmp->u16BitmapIndex = E_BMP_PANASONIC_21COLORBAR01WHILE;
            PTP_DBG(printf("- E_BMP_PANASONIC_21COLORBAR \r\n"));
            break;

        case PANASONIC_TEST_22_CIRCUMFERENCE:
            aparamBmp->u16BitmapIndex = E_BMP_PANASONIC_00WHITE;
            PTP_DBG(printf("- PANASONIC_TEST_22_CIRCUMFERENCE \r\n"));
            break;


        default:
            aparamBmp->u16BitmapIndex = E_ZUI_BMP_MAX;
            PTP_DBG(printf("- PANASONIC_TEST_MIN \r\n"));
            break;

    }

    if (aparamBmp->u16BitmapIndex == E_ZUI_BMP_MAX)
    {
        printf(" Wrong Test Pattern \r\n");
        return;
    }

    msAPI_Scaler_SetBlueScreen( ENABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
//MDrv_WriteByteMask(0x101F02, 0x00, BIT3);
    MApi_GOP_GWIN_EnableTransClr(GOPTRANSCLR_FMT0, FALSE);
    MApi_GOP_GWIN_EnableTransClr(GOPTRANSCLR_FMT1, FALSE);

    aparamBmp->bSrcColorKey = TRUE;
    aparamBmp->srcColorKeyFrom = 0x0;
    aparamBmp->srcColorKeyEnd = 0x0;
    aparamBmp->u8Constant_Alpha = 0xFF;

    MApi_GOP_GWIN_Enable(MApp_ZUI_API_QueryGWinID(), FALSE); //hide it first!

    if (aparamBmp->u16BitmapIndex == E_BMP_PANASONIC_FLICKER_D0)  //patch for D pattern 1st line
    {
    #if 1
        RECT_SET(Wrect, 0, 0, TP_WIDTH, 1);
        _MApp_ZUI_API_DrawDynamicComponent(CP_BITMAP, aparamBmp, Wdc, &Wrect);
    #else
        for (i=0; i<(TP_WIDTH/u8width); i++)
        {
            RECT_SET(Wrect, 0+u8width*i, 0, u8width, 1);
            _MApp_ZUI_API_DrawDynamicComponent(CP_BITMAP, aparamBmp, Wdc, &Wrect);
        }
    #endif
        aparamBmp->u16BitmapIndex = E_BMP_PANASONIC_FLICKER_D;
    }


    if ( (u8Pattern == PANASONIC_TEST_09_BLACK_WHITE) ||
         (u8Pattern == PANASONIC_TEST_10_WHITE_BLACK) )
    {
        RECT_SET(Wrect, 0, 0, (PANASONIC_WIDTH/2), (TP_HEIGHT/2));
        _MApp_ZUI_API_DrawDynamicComponent(CP_BITMAP, aparamBmp, Wdc, &Wrect);

        RECT_SET(Wrect, (PANASONIC_WIDTH/2)+1, (TP_HEIGHT/2)+1, (PANASONIC_WIDTH/2), (TP_HEIGHT/2));
        _MApp_ZUI_API_DrawDynamicComponent(CP_BITMAP, aparamBmp, Wdc, &Wrect);

        if (u8Pattern == PANASONIC_TEST_09_BLACK_WHITE)
            aparamBmp->u16BitmapIndex = E_BMP_PANASONIC_10WHITE;
        else
            aparamBmp->u16BitmapIndex = E_BMP_PANASONIC_09BLACK;

        RECT_SET(Wrect, (PANASONIC_WIDTH/2)+1, 0, (PANASONIC_WIDTH/2), (TP_HEIGHT/2));
        _MApp_ZUI_API_DrawDynamicComponent(CP_BITMAP, aparamBmp, Wdc, &Wrect);

        RECT_SET(Wrect, 0, (TP_HEIGHT/2)+1, (PANASONIC_WIDTH/2), (TP_HEIGHT/2));
        _MApp_ZUI_API_DrawDynamicComponent(CP_BITMAP, aparamBmp, Wdc, &Wrect);
    }
#if 1
    else if ( (u8Pattern == PANASONIC_TEST_11_GRADIENT_GS1)
           || (u8Pattern == PANASONIC_TEST_11_GRADIENT_GS2)
           || (u8Pattern == PANASONIC_TEST_12_GRADIENT_GS1)
           || (u8Pattern == PANASONIC_TEST_12_GRADIENT_GS2)
           || (u8Pattern == PANASONIC_TEST_13_GRADIENT_GS1)
           || (u8Pattern == PANASONIC_TEST_13_GRADIENT_GS2)
           || (u8Pattern == PANASONIC_TEST_14_GRADIENT_GS1)
           || (u8Pattern == PANASONIC_TEST_14_GRADIENT_GS2)
            )
    {
        aparamRect->eGradient = OSD_COLOR_GRADIENT_X;

        RECT_SET(Wrect, 0, 0, 1366, 768);
        _MApp_ZUI_API_DrawDynamicComponent(CP_FILL_RECT, aparamRect, Wdc, &Wrect);
    }
    else if ( (u8Pattern == PANASONIC_TEST_11_GRADIENT_GS3)
           || (u8Pattern == PANASONIC_TEST_11_GRADIENT_GS4)
           || (u8Pattern == PANASONIC_TEST_12_GRADIENT_GS3)
           || (u8Pattern == PANASONIC_TEST_12_GRADIENT_GS4)
           || (u8Pattern == PANASONIC_TEST_13_GRADIENT_GS3)
           || (u8Pattern == PANASONIC_TEST_13_GRADIENT_GS4)
           || (u8Pattern == PANASONIC_TEST_14_GRADIENT_GS3)
           || (u8Pattern == PANASONIC_TEST_14_GRADIENT_GS4)
            )
    {
        aparamRect->eGradient = OSD_COLOR_GRADIENT_Y;

        RECT_SET(Wrect, 0, 0, 1366, 768);
        _MApp_ZUI_API_DrawDynamicComponent(CP_FILL_RECT, aparamRect, Wdc, &Wrect);
    }

#endif
    else if ( (u8Pattern >= PANASONIC_TEST_15_FLICKER_A) && (u8Pattern <= PANASONIC_TEST_15_FLICKER_D0) )
    {
        for (i=0; i<(TP_WIDTH/u8width); i++)
        {
           for (j=0;j<(TP_HEIGHT/u8height); j++)
           {
                RECT_SET(Wrect, 0+u8width*i, u8offset+u8height*j, u8width, u8height);
                _MApp_ZUI_API_DrawDynamicComponent(CP_BITMAP, aparamBmp, Wdc, &Wrect);
           }
        }
    }
    else if ( (u8Pattern >= PANASONIC_TEST_17_1PIXEL_PIN_STRIPE) && (u8Pattern <= PANASONIC_TEST_19_1LINE_SIDE_STRIPE) )
    {
        for (i=0; i<(PANASONIC_WIDTH/u8width); i++)
        {
           for (j=0;j<(PANASONIC_HEIGHT/u8height); j++)
           {
                RECT_SET(Wrect, 0+u8width*i, u8offset+u8height*j, u8width, u8height);
                _MApp_ZUI_API_DrawDynamicComponent(CP_BITMAP, aparamBmp, Wdc, &Wrect);
           }
        }
    }

    else if (u8Pattern == PANASONIC_TEST_20_COLOR_BAR_1)
    {
        U16 u8ColorBarTblNum = (U16) (sizeof(ColorBarTbl)/sizeof(OSD_COLOR));
        U16 u8ColorBarHeight = (U16) (768 / u8ColorBarTblNum);

        aparamRect->eGradient = OSD_COLOR_GRADIENT_X;

        for (i=0; i<u8ColorBarTblNum; i++)
        {
            aparamRect->fromColor = ColorBarTbl[i];
            RECT_SET(Wrect, 0, 0+u8ColorBarHeight*i, 1366, u8ColorBarHeight);
            _MApp_ZUI_API_DrawDynamicComponent(CP_FILL_RECT, aparamRect, Wdc, &Wrect);
        }

    }

    else if (u8Pattern == PANASONIC_TEST_21_COLOR_BAR_2)
    {
        for (i=0; i<(E_BMP_PANASONIC_21COLORBAR07BLUE - E_BMP_PANASONIC_21COLORBAR01WHILE); i++)
        {
            RECT_SET(Wrect, 0+195*i, 0, (PANASONIC_WIDTH/7), TP_HEIGHT);
            _MApp_ZUI_API_DrawDynamicComponent(CP_BITMAP, aparamBmp, Wdc, &Wrect);
            aparamBmp->u16BitmapIndex++;
        }

        RECT_SET(Wrect, 0+195*i, 0, (PANASONIC_WIDTH/7)+1, TP_HEIGHT);
        _MApp_ZUI_API_DrawDynamicComponent(CP_BITMAP, aparamBmp, Wdc, &Wrect);
    }

    else if (u8Pattern == PANASONIC_TEST_22_CIRCUMFERENCE)
    {
      #if 1
        RECT_SET(Wrect, 0, 0, TP_WIDTH, TP_HEIGHT);
        _MApp_ZUI_API_DrawDynamicComponent(CP_BITMAP, aparamBmp, Wdc, &Wrect);
      #else
        aparamRect->fromColor = COLOR_WHITE;
        aparamRect->toColor = COLOR_WHITE;
        RECT_SET(Wrect, 0, 0, 1366, 768);
        _MApp_ZUI_API_DrawDynamicComponent(CP_FILL_RECT, aparamRect, Wdc, &Wrect);
      #endif

        aparamRect->eGradient = OSD_GRADIENT_DISABLE;
        aparamRect->fromColor = COLOR_BLACK;
        aparamRect->toColor = COLOR_BLACK;

        //value is weird, double check latter!!!
        RECT_SET(Wrect, 2, 1, 1363, 766);
        _MApp_ZUI_API_DrawDynamicComponent(CP_FILL_RECT, aparamRect, Wdc, &Wrect);
    }

    else
    {
      #if 1
        RECT_SET(Wrect, 0, u8offset, TP_WIDTH, TP_HEIGHT-u8offset);
        _MApp_ZUI_API_DrawDynamicComponent(CP_BITMAP, aparamBmp, Wdc, &Wrect);
      #else
        for (i=0; i<(TP_WIDTH/u8width); i++)
        {
           for (j=0;j<(TP_HEIGHT/u8height); j++)
           {
                RECT_SET(Wrect, 0+u8width*i, u8offset+u8height*j, u8width, u8height);
                _MApp_ZUI_API_DrawDynamicComponent(CP_BITMAP, aparamBmp, Wdc, &Wrect);
           }
        }
      #endif
    }

    MApi_GOP_GWIN_Enable(MApp_ZUI_API_QueryGWinID(), TRUE); //hide it first!

    _ZUI_FREE(aparamBmp);
}

#endif //#if PANASONIC_TEST_PATTERN




/*************************************************************************************************************/


#undef MAPP_ZUI_APIGUIDRAW_C

