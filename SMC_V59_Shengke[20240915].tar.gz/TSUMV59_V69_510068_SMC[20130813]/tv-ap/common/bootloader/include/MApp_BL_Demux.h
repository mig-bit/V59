#ifndef _MAPP_BL_DEMUX_H_
#define _MAPP_BL_DEMUX_H_

/******************************************************************************/
/*                     macro                                 */
/******************************************************************************/
#define TSGetBitFromU8(ptr, bitn)           (((*(U8 *)ptr) >> bitn) & 0x01)
#define TSGetBitsFromU8(ptr, lsb, mask)     (((*(U8 *)ptr) >> lsb) & mask)
#define TSGetU16(ptr)                       ((((U8 *)ptr)[0] << 8) + ((U8 *)ptr)[1])
#define TSGetBitsFromU16(ptr, lsb, mask)    ((TSGetU16(ptr) >> lsb) & mask)
#define TSGetU32(ptr)                       ((((U8 *)ptr)[0] << 24) + (((U8 *)ptr)[1] << 16) + (((U8 *)ptr)[2] << 8) + (((U8 *)ptr)[3] << 0))
#define TSGetBitsFromU32(ptr, lsb, mask)    ((TSGetU32(ptr) >> lsb) & mask)


/******************************************************************************/
/*                                 Enum                                       */
/******************************************************************************/
/* PID definition */
typedef enum
{
    BL_PID_PAT         = 0x0000,
} EN_BL_PSIP_PID;

/* A/V/PCR/TTX/SUBT */
typedef enum
{
    EN_BL_OAD_MONITOR_FID,
    EN_BL_OAD_DOWNLOAD_FID
} EN_BL_FID;
/******************************************************************************/
/*                     struct                                 */
/******************************************************************************/
typedef struct
{
    U32 u32SecMask;
    U8  u8LastSecNum;
    U8  u8SecCount;
    U16 u16SecLengthCount:15;
    U16 fIsTblReceived:1;
} ST_BL_DMXSEC_MONITOR;

/******************************************************************************/
/*                       Global Variable Declarations                         */
/******************************************************************************/
#ifdef MAPP_BL_DEMUX_C
#define INTERFACE
#else
#define INTERFACE extern
#endif

/******************************************************************************/
/*                       Global Function Prototypes                           */
/******************************************************************************/
INTERFACE void MApp_BL_Dmx_Init(U32 u32BufferStart, U32 u32BufferSize);
INTERFACE void MApp_BL_Dmx_CloseAllFilters(void);
INTERFACE void MApp_BL_Dmx_ResetPatSecTable(void);
INTERFACE void MApp_BL_Dmx_SetOadScan(BOOLEAN bEnable);
INTERFACE U8 MApp_BL_Dmx_GetTableFilterID(EN_BL_PSIP_TABLE enTable);
INTERFACE U8 MApp_BL_Dmx_GetOpenFilterChNums(void);
INTERFACE U8 *MApp_BL_Dmx_GetSI4KSectionBuffer(void);
INTERFACE U8 *MApp_BL_Dmx_GetFid(EN_BL_FID eFid);
INTERFACE void MApp_BL_Dmx_SetFid(U8 u8Fid, EN_BL_FID eFid);
INTERFACE void MApp_BL_Dmx_PAT_Monitor(void);
INTERFACE void MApp_BL_Dmx_PMTs_Monitor(void);
#undef INTERFACE
#endif

