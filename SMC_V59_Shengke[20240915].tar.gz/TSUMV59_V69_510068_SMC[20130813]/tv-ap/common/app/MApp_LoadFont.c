////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////


#define MAPP_LOADFONT_C

#include <stdlib.h>
#include <stdio.h>
#include "Board.h"
#include "datatype.h"
#include "MsCommon.h"
#include "apiXC.h"
#include "apiXC_Adc.h"
#include "msAPI_MIU.h"
#include "msAPI_Font.h"
#include "msAPI_Timer.h"
#include "MApp_Font.h"
#include "MApp_GlobalSettingSt.h"
#include "MApp_GlobalVar.h"
#include "BinInfo.h"
#include "Utl.h"
#if ((BRAZIL_CC )|| (ATSC_CC == ATV_CC))
#include "msAPI_cc_parser.h"
#endif
/*****************************************************************************/
/*                                 Global Variable                           */
/*****************************************************************************/

#if ((BRAZIL_CC )|| (ATSC_CC == ATV_CC))
static U8 CCFontNumber;
static U32 CCFontLoadTimer;
#endif
/******************************************************************************/


//==============================================================================
/*                               Functions                                      */
//==============================================================================

void MApp_LoadFont_SetBMPFontInfo(LOADFONT_PAIR *fontpair, U8 u8num)
{
    U8 i =0;
    for(;i<u8num;i++)
    {
        if(fontpair[i].FontID > MAX_FONTTABLE_NUM_OSD)
            break;//error
        Font[fontpair[i].FontID].fHandle = msAPI_Font_LoadFlashFontToSDRAM(fontpair[i].MMapID);
    }

}


#if VECTOR_FONT_ENABLE
void MApp_LoadFont_SetVecFontInfo(LOADFONT_STRUCT* strfont, U8 u8Begin, U8 u8End)
{
    msAPI_Font_MVF_LoadFont(strfont, u8Begin, u8End);
}
#endif

/*************************************************************************************************************/
#if (ATSC_CC)
void MApp_LoadFont_CC_Init(void)
{
    CCFontNumber    = 0;
    CCFontLoadTimer = msAPI_Timer_GetTime0();
    enCCFontStatus  = CC_FONT_UNLOAD;

    msAPI_CC_SetCCFont(&Font_CC[0]);
}

BOOLEAN MApp_LoadFont_CC(void)
{
    if(CCFontNumber >= MAX_FONTTABLE_NUM_CC)
    {
        return TRUE;
    }

    if(msAPI_Timer_DiffTimeFromNow(CCFontLoadTimer) < ((enCCFontStatus==CC_FONT_UNLOAD_SPEEDUP)? 10:100))
    {
        return FALSE;
    }

#if LOAD_CCFONT_ONCE
    for(CCFontNumber=0; CCFontNumber<MAX_FONTTABLE_NUM_CC; CCFontNumber++)
    {
        Font_CC[CCFontNumber].fHandle = msAPI_Font_LoadFlashFontToSDRAM(CCFontNumber+BIN_ID_FONT_CS0);
        //printf("\n...load cc font, id=%d, fh=0x%x", CCFontNumber, Font_CC[CCFontNumber].fHandle);
    }
#else
    Font_CC[CCFontNumber].fHandle = msAPI_Font_LoadFlashFontToSDRAM(CCFontNumber+BIN_ID_FONT_CS0);
    //printf("\n...load cc font, id=%d, fh=0x%x", CCFontNumber, Font_CC[CCFontNumber].fHandle);

    CCFontNumber++;
#endif

    CCFontLoadTimer=msAPI_Timer_GetTime0();

    return FALSE;
}
#endif




#undef MAPP_LOADFONT_C


