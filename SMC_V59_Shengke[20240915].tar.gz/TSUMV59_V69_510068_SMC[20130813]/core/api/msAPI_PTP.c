////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//
/// @file msAPI_IR.h
/// This file includes MStar application interface for IR process
/// @brief API for Irda Control
/// @author MStar Semiconductor, Inc.
//
////////////////////////////////////////////////////////////////////////////////
#ifdef ENABLE_PTP

#define MSAPI_PTP_C

#include "msAPI_PTP.h"

static U8 u8PTPCurrentUsbPort;
static U32 u32PTPCurrentObjectHandle;
static U32 u32PTPCurrentObjectSize;
static U32 u32PTPCurrentObjectReadOffset;

U8 msAPI_PTP_FileOpen(FileEntry *pFileEntry, U8 u8OpenMode)
{
    PTPFileEntry *pPTPFileEntry = (PTPFileEntry *)pFileEntry;

    u8OpenMode = u8OpenMode;
    u8PTPCurrentUsbPort = pPTPFileEntry->u8UsbPort;
    u32PTPCurrentObjectHandle = pPTPFileEntry->u32ObjectHandle;
    u32PTPCurrentObjectSize = pPTPFileEntry->u32ObjectSize;
    u32PTPCurrentObjectReadOffset = 0;

    return 0;
}

EN_FILE_CLOSE_RESULT msAPI_PTP_FileClose(U8 u8Handle)
{
    u8Handle = u8Handle;

    return FILE_CLOSE_RESULT_SUCCESS;
}

U32 msAPI_PTP_FileRead(U8 u8Handle, U32 u32Buffer, U32 u32Length)
{
    u8Handle = u8Handle;
    u32Buffer = u32Buffer;
    u32Length = u32Length;

    // To Do: Thumb ??
    drvUsbPTP_GetObject(u8PTPCurrentUsbPort, u32PTPCurrentObjectHandle, u32PTPCurrentObjectReadOffset, u32Length, u32Buffer);
    u32PTPCurrentObjectReadOffset += u32Length;

    return u32Length;
}

U32 msAPI_PTP_FileLength(U8 u8Handle)
{
    u8Handle = u8Handle;

    return u32PTPCurrentObjectSize;
}

U32 msAPI_PTP_FileTell(U8 u8Handle)
{
    u8Handle = u8Handle;

    return u32PTPCurrentObjectReadOffset;
}


#undef MSAPI_PTP_C

#endif // ENABLE_PTP
