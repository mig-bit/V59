////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (MStar Confidential Information) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  [Doxygen]
/// @file msapi_audio.h
/// @brief API for Audio Control
/// @author MStar Semiconductor, Inc.
//
////////////////////////////////////////////////////////////////////////////////

#define _MSAPI_AUDIO_C_
#include <math.h>
#include "Board.h"
#include "debug.h"
#include "msAPI_audio.h"
#include "msAPI_Global.h"
#include "apiAUDIO.h"
#include "drvAUDIO.h"
#include "drvAUDIO_if.h"
#include "drvSOUND.h"
#include "drvADVSOUND.h"
#include "drvMAD.h"
#include "drvMAD2.h"
#include "msAPI_MIU.h"
#include "BinInfo.h"
#include "msAPI_DrvInit.h"
#include "msAPI_Timer.h"
#include "drvISR.h"
#include "drvMIU.h"
#include "msAPI_Tuning.h"
#include "msAPI_VD.h"
#include "MApp_Audio.h"
#include "MsCommon.h"
#include "MsIRQ.h"
#include "MsOS.h"
#include"MApp_GlobalSettingSt.h"
#include "MApp_UiMenuDef.h"
#include "MApp_ATVProc.h"

#if (DIGITAL_I2S_SELECT != AUDIO_I2S_NONE)
#include "Audio_amplifier.h"
#endif
#define DEBUG_AUDIO    //0xFF
#if ENABLE_NO_AUDIO_INPUT_AUTO_MUTE
#include "mapp_mplayer.h"
#endif

#include "GPIO.h"

#ifdef DEBUG_ASP
    #define debugASPPrint(a,b)  //printf(a,b)
    #include "debug.h"
#else
    #define debugASPPrint(a,b)
#endif

#ifdef DEBUG_AUDIO
    #define debugAudioPrint(a,b)    debugPrint(a,b)
#else
    #define debugAudioPrint(a,b)
#endif

#define IsVideoStandard60Hz(s)        ( ( ((s)==E_VIDEOSTANDARD_NTSC_M) || \
                                        ((s)==E_VIDEOSTANDARD_NTSC_44) || \
                                        ((s)==E_VIDEOSTANDARD_PAL_M) || \
                                        ((s)==E_VIDEOSTANDARD_PAL_60) )? TRUE : FALSE )

#define IsVideoStandard50Hz(s)        ( ( ((s)==E_VIDEOSTANDARD_PAL_BGHI) || \
                                        ((s)==E_VIDEOSTANDARD_SECAM) || \
                                        ((s)==E_VIDEOSTANDARD_PAL_N) )? TRUE : FALSE )


#define AUD_DEBUG(msg) //msg

//-------------------------------------------------------------------------
// Extern
//-------------------------------------------------------------------------
extern U32 AseBinAddress[8];
extern MS_U8          gu8MADEncodeDone;
AUDIOSTATUS           m_eAudioStatus;

AUDIOMODE_TYPE        m_eAudioMode;
MS_U16                m_wAudioDownCountTimer;
AUDIOSTANDARD_TYPE    m_eAudioStandard;

AUDIO_DSP_SYSTEM      m_eAudioDSPSystem;
extern THR_TBL_TYPE code     AuSifInitThreshold[];

MS_U8                 g_A2ModeInvalidCnt=0;
#if (MTS_NICAM_UNSTABLE)
MS_U16              g_NICAMEnable = 1;
MS_U8               g_CarrierStableCnt = 0;
#endif

//-------------------------------------------------------------------------
// Local
//-------------------------------------------------------------------------
static BOOLEANS m_BOOLEANS_1;
#define m_bIsAudioModeChanged    m_BOOLEANS_1.bBOOL_0
#define m_bPermanentAudioMute    m_BOOLEANS_1.bBOOL_1
#define m_bMomentAudioMute        m_BOOLEANS_1.bBOOL_2
#define m_bByUserAudioMute        m_BOOLEANS_1.bBOOL_3
#define m_bBySyncAudioMute        m_BOOLEANS_1.bBOOL_4
#define m_bByVChipAudioMute        m_BOOLEANS_1.bBOOL_5
#define m_bByBlockAudioMute        m_BOOLEANS_1.bBOOL_6
#define m_bInternal1AudioMute    m_BOOLEANS_1.bBOOL_7

static BOOLEANS m_BOOLEANS_2;
#define m_bInternal2AudioMute                    m_BOOLEANS_2.bBOOL_0
#define m_bInternal3AudioMute                    m_BOOLEANS_2.bBOOL_1
#define m_bInternal4AudioMute                    m_BOOLEANS_2.bBOOL_2
#define m_bByDuringLimitedTimeAudioMute            m_BOOLEANS_2.bBOOL_3
#define m_bIsRealtimeAudioDetectionEnabled        m_BOOLEANS_2.bBOOL_4
#define m_bIsSRSWOWEnabled                        m_BOOLEANS_2.bBOOL_5
#define m_bMHEGApMute                               m_BOOLEANS_2.bBOOL_6    // MHEG AP Mute - for MHEG use only
#define m_bCIAudioMute                              m_BOOLEANS_2.bBOOL_7

#if (ENABLE_CHANNEL_CHANGE_MUTE_ON_OFF_DELAY)
static MS_BOOL               m_bByPassDelay;
#endif

static MS_U8                 m_cAudioVolumePercentage;
static MS_U32                m_dwStartedTimeOfMute;
static MS_U16                m_wLimitedTimeOfMute;

AUDIOSOURCE_TYPE   m_eAudioSource;
#if OBA2
BOOL audio_FW_Status = FALSE;
#endif

static void SetAudioMuteDuringLimitedTime(WORD w1ms, AUDIOMUTESOURCE_TYPE eAudioMuteSource);
static void SetAudioMute(AUDIOMUTETYPE eAudioMuteType, AUDIOMUTESOURCE_TYPE eAudioMuteSource);
#ifndef ATSC_SYSTEM
#if(TV_SYSTEM != TV_NTSC)
static void CheckAudioStandard(void);
#endif
#if (TV_SYSTEM == TV_PAL)
static void CheckATVAudioMode(void);
#endif
#endif
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
///
///         AUDIO_SYSTEM RELATIONAL API FUNCTION
///
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

/******************************************************************************/
/// API for Audio::
/// Initial Audio system. Involve this function during the initial time.
/******************************************************************************/
void msAPI_AUD_InitAudioSystem(THR_TBL_TYPE code *ThrTbl)
{
    AUDIO_INIT_INFO SystemInfo;
    AUDIO_OUT_INFO OutputInfo;
    AUDIO_PATH_INFO PathInfo;
  //  U32 DCOffet=0x00000800;

    CAL_TIME_FUNC_START();

    SystemInfo.miu=0;
    UNUSED(ThrTbl);
//======================================
// Set system info
//======================================
    #if (TV_SYSTEM == TV_PAL)
        SystemInfo.tv_system=TV_PAL;
    #elif(TV_SYSTEM == TV_NTSC)
        SystemInfo.tv_system=TV_NTSC;
    #else
        SystemInfo.tv_system=TV_CHINA;
    #endif

    #ifdef ATSC_SYSTEM
        SystemInfo.dtv_system=1;  // For ATSC
    #else
        SystemInfo.dtv_system=0;  // For DVB
    #endif

    #if (AUDIO_SYSTEM_SEL == AUDIO_SYSTEM_BTSC)
        SystemInfo.au_system_sel=AUDIO_SYSTEM_BTSC;
    #elif(AUDIO_SYSTEM_SEL == AUDIO_SYSTEM_A2)
        SystemInfo.au_system_sel=AUDIO_SYSTEM_A2;
    #endif
    MApi_AUDIO_SetSystemInfo(&SystemInfo);

//======================================
// Set output info
//======================================

    OutputInfo.SpeakerOut=AUDIO_OUTPUT_MAIN_SPEAKER;
    OutputInfo.HpOut=AUDIO_OUTPUT_HP;
    OutputInfo.ScartOut=AUDIO_OUTPUT_SIFOUT;
    OutputInfo.MonitorOut=AUDIO_OUTPUT_LINEOUT;
    MApi_AUDIO_SetOutputInfo(&OutputInfo);

//======================================
// Set path info
//======================================
    PathInfo.SpeakerOut=AUDIO_PATH_MAIN_SPEAKER;
    PathInfo.HpOut=AUDIO_PATH_HP;
    PathInfo.ScartOut=AUDIO_PATH_SIFOUT;
    PathInfo.MonitorOut=AUDIO_PATH_LINEOUT;
    PathInfo.SpdifOut=AUDIO_PATH_SPDIF;
    MApi_AUDIO_SetPathInfo(&PathInfo);


//======================================
#if((FRONTEND_IF_DEMODE_TYPE==MSTAR_VIF)||(FRONTEND_IF_DEMODE_TYPE==MSTAR_VIF_MSB1210)||(FRONTEND_IF_DEMODE_TYPE==MSTAR_INTERN_VIF))
    MApi_AUDIO_SIF_SendCmd(MSAPI_AUD_SIF_CMD_SET_ADC_FROM_VIF_PATH, TRUE, 0);
#else
    MApi_AUDIO_SIF_SendCmd(MSAPI_AUD_SIF_CMD_SET_ADC_FROM_VIF_PATH, FALSE, 0);
#endif

    MW_AUD_GetBinAddress();

    MApi_AUDIO_Initialize();

#if (TV_SYSTEM == TV_PAL)
    MApi_AUDIO_SIF_SendCmd(MSAPI_AUD_SIF_CMD_DETECT_MAIN_STD_ONLY, TRUE, 0);
#endif

#if (MTS_NICAM_UNSTABLE)
    g_CarrierStableCnt = 0;
    g_NICAMEnable = 1;
#endif
//    m_eAudioStreamType = astNOT_VALID;

    m_eAudioSource = E_AUDIOSOURCE_INVALID;
    m_eAudioStandard = E_AUDIOSTANDARD_NOTSTANDARD;
    m_eAudioStatus = E_STATE_AUDIO_NO_CARRIER;
    m_eAudioMode = E_AUDIOMODE_INVALID;
    m_eAudioDSPSystem = E_AUDIO_DSP_INVALID;
    m_bIsAudioModeChanged = FALSE;

    m_bMHEGApMute = FALSE;
    m_bPermanentAudioMute = FALSE;
    m_bMomentAudioMute = FALSE;
    m_bByUserAudioMute = FALSE;
    m_bBySyncAudioMute = FALSE;
    m_bByVChipAudioMute = FALSE;
    m_bByBlockAudioMute = FALSE;
    m_bInternal1AudioMute = FALSE;
    m_bInternal2AudioMute = FALSE;
    m_bInternal3AudioMute = FALSE;
    m_bInternal4AudioMute = FALSE;
    m_bByDuringLimitedTimeAudioMute = FALSE;
    m_bCIAudioMute = FALSE;

    m_dwStartedTimeOfMute = 0;
    m_wLimitedTimeOfMute = 0;

    m_bIsSRSWOWEnabled = FALSE;

    m_bIsRealtimeAudioDetectionEnabled = FALSE;

    MDrv_AUDIO_SetNormalPath(AUDIO_PATH_SIFOUT, AUDIO_SOURCE_ATV, AUDIO_OUTPUT_SIFOUT);

    m_wAudioDownCountTimer = WAIT_0ms;
    m_cAudioVolumePercentage = 0;

    MApi_AUDIO_EnableEQ(FALSE);
    MApi_AUDIO_EnableTone(TRUE);

#if (ENABLE_CHANNEL_CHANGE_MUTE_ON_OFF_DELAY)
    m_bByPassDelay = FALSE;
#endif

#if ENABLE_ATV_CHINA_APP
    #if ENABLE_VD_PACH_IN_CHINA
      if(stGenSetting.g_FactorySetting.AUDIO_HIDEV==E_AUDIO_HIDEV_BW_L1)
      {
                MApi_AUDIO_SIF_SendCmd(MSAPI_AUD_SIF_CMD_ENABLE_HIDEV, TRUE, NULL);
                MApi_AUDIO_SIF_SendCmd(MSAPI_AUD_SIF_CMD_SET_HIDEV_FILTER_BW_LEVEL, MSAPI_AUD_SIF_HIDEV_FILTER_BW_L1, NULL);
          }
      else if(stGenSetting.g_FactorySetting.AUDIO_HIDEV==E_AUDIO_HIDEV_BW_L2)
      {
                MApi_AUDIO_SIF_SendCmd(MSAPI_AUD_SIF_CMD_ENABLE_HIDEV, TRUE, NULL);
                MApi_AUDIO_SIF_SendCmd(MSAPI_AUD_SIF_CMD_SET_HIDEV_FILTER_BW_LEVEL, MSAPI_AUD_SIF_HIDEV_FILTER_BW_L2, NULL);
          }
      else if(stGenSetting.g_FactorySetting.AUDIO_HIDEV==E_AUDIO_HIDEV_BW_L3)
      {
               MApi_AUDIO_SIF_SendCmd(MSAPI_AUD_SIF_CMD_ENABLE_HIDEV, TRUE, NULL);
               MApi_AUDIO_SIF_SendCmd(MSAPI_AUD_SIF_CMD_SET_HIDEV_FILTER_BW_LEVEL, MSAPI_AUD_SIF_HIDEV_FILTER_BW_L3, NULL);
           }
      else
          {
              MApi_AUDIO_SIF_SendCmd(MSAPI_AUD_SIF_CMD_ENABLE_HIDEV, FALSE, NULL);
          }
      #else
    MApi_AUDIO_SIF_SendCmd(MSAPI_AUD_SIF_CMD_ENABLE_HIDEV, TRUE,0);
    MApi_AUDIO_SIF_SendCmd(MSAPI_AUD_SIF_CMD_SET_HIDEV_FILTER_BW_LEVEL, MSAPI_AUD_SIF_HIDEV_FILTER_BW_L1,0);
#endif
#endif

#if  ((CHIP_FAMILY_TYPE == CHIP_FAMILY_S7LD )||(CHIP_FAMILY_TYPE == CHIP_FAMILY_U3 )\
      ||(CHIP_FAMILY_TYPE == CHIP_FAMILY_S7J)||(CHIP_FAMILY_TYPE == CHIP_FAMILY_M10)\
      || (CHIP_FAMILY_TYPE == CHIP_FAMILY_M12))
    if(OutputInfo.SpeakerOut!=AUDIO_I2S_OUTPUT)
      MApi_AUDIO_SetMute(AUDIO_PATH_MAIN,FALSE);  // Clear Mute in SRC path
#endif

//========== For customer setting============
    MApi_AUDIO_SetAvcMode(2);         // AVC= MStar mode

#if (CUS_AUDIO_VOLUME_CURVE == AVC_8W_PIONEER_42) || (CUS_AUDIO_VOLUME_CURVE == AVC_10W_SMC_42)

    MApi_AUDIO_SetAvcAT(0);           // Set AVC attack time to 20ms		// CUS_XM Sea 20120613: register 0X112D29 = 0x18= 0001 1000
    MApi_AUDIO_SetAvcRT(1);           // Set AVC release time to 2sec
    MApi_AUDIO_SetAvcThreshold(0x1d); // 	// CUS_XM Sea 20120613:register 0X112D28 = 1d

 #else

    MApi_AUDIO_SetAvcAT(3);           // Set AVC attack time to 1sec
    MApi_AUDIO_SetAvcRT(1);           // Set AVC release time to 2sec
    MApi_AUDIO_SetAvcThreshold(0x20); // -16 dBFS

 #endif

#ifdef CUS_AUDIO_DRC_ADJUST
#if (CUS_AUDIO_VOLUME_CURVE == AVC_8W_PIONEER_42) || (CUS_AUDIO_VOLUME_CURVE == AVC_10W_SMC_42)
    MApi_SND_ProcessEnable(Sound_ENABL_Type_DRC, ENABLE); // DRC		// CUS_XM Sea 20120709:
    MApi_SND_SetParam1(Sound_SET_PARAM_Drc_Threshold, 0x10, 0); // -8 dBFS		// CUS_XM Sea 20120725: 0X112D34


    #ifdef CUS_AUDIO_DRC_ADJUST

    if (stGenSetting.g_SysSetting.fAutoVolume)
    {
	    MApi_SND_SetParam1(Sound_SET_PARAM_Drc_Threshold, 0x1a, 0); // -8 dBFS		// CUS_XM Sea 20120725: 0X112D34
    }
    else
    {
	    MApi_SND_SetParam1(Sound_SET_PARAM_Drc_Threshold, 0x10, 0); // -8 dBFS		// CUS_XM Sea 20120725: 0X112D34
    }

    #endif



#else
    MApi_SND_ProcessEnable(Sound_ENABL_Type_DRC, DISABLE); // DRC
    MApi_SND_SetParam1(Sound_SET_PARAM_Drc_Threshold, 0x10, 0); // -8 dBFS
#endif
#else
#if 0
	MApi_SND_ProcessEnable(Sound_ENABL_Type_DRC, ENABLE); // DRC
	MApi_SND_SetParam1(Sound_SET_PARAM_Drc_Threshold, 0x08/*0x10*/, 0); // -8 dBFS
#else
	MApi_SND_ProcessEnable(Sound_ENABL_Type_DRC, DISABLE); // DRC
	MApi_SND_SetParam1(Sound_SET_PARAM_Drc_Threshold, 0x0d/*0x10*/, 0); // -8 dBFS
#endif
#endif

    MApi_AUDIO_SetSurroundXA(0);
    MApi_AUDIO_SetSurroundXB(3);
    MApi_AUDIO_SetSurroundXK(0);
    MApi_AUDIO_SetSurroundLPFGain(2);

    MDrv_AUDIO_SetPowerDownWait(TRUE);

#if (SUPPORT_PEQ_TOOL)
    msAPI_AUD_SetPEQ(0, 0, 10, 0, 16);
    msAPI_AUD_SetPEQ(1, 0, 10, 0, 16);
    msAPI_AUD_SetPEQ(2, 0, 10, 0, 16);
  #if (PEQ_BANDS == 5)
    msAPI_AUD_SetPEQ(3, 0, 10, 0, 16);
    msAPI_AUD_SetPEQ(4, 0, 10, 0, 16);
  #endif
#endif

#if ENABLE_VD_PACH_IN_CHINA
    //Enable Audio NR
    MApi_AUDIO_SetCommAudioInfo(Audio_Comm_infoType_setNR_Threshold, stGenSetting.g_FactorySetting.AUDIO_NR,0X00);//should finetune
#endif

  //  MApi_AUDIO_SOUND_SetParam(Sound_SET_Type_SetDCOffet, &DCOffet);//should finetune

CAL_TIME_FUNC_END();

}


/******************************************************************************/
/// API for Audio::
/// Adjust audio by specific factor
/// @param eFactor  \b IN adjust factor
/// @param wParam1  \b param1
/// @param wParam2  \b param2
/******************************************************************************/
#if ENABLE_NO_AUDIO_INPUT_AUTO_MUTE //minglin0111
extern BOOLEAN MApp_IsSrcHasSignal(SCALER_WIN eWindow);
#endif
void msAPI_AUD_AdjustAudioFactor(ADJUST_TVAVFACTOR eFactor, WORD wParam1, WORD wParam2)
{
    /* Used to check the mute flag, and deside if we should start mute process
        or not.
    */
    U8 bMuteProcess = FALSE;

    switch(eFactor)
    {

    case E_ADJUST_CHANGE_AUDIOSOURCE: // APP Used
        msAPI_AUD_SetAudioSource((AUDIOSOURCE_TYPE)wParam1);
        m_eAudioSource = (AUDIOSOURCE_TYPE)wParam1;
            if(m_eAudioSource==E_AUDIOSOURCE_ATV)
            {
               msAPI_ATV_GetAudioMode((AUDIOSOURCE_TYPE)wParam1, &m_eAudioMode);
               MApi_AUDIO_SIF_SetSoundMode(m_eAudioMode);
            }
            break;

    case E_ADJUST_AUDIOMUTE:
        /* This switch statment can avoid the unnecessary delay time */
        switch(( (AUDIOMUTETYPE) wParam1 ))
        {
            case E_AUDIO_PERMANENT_MUTEOFF:
                if ( m_bPermanentAudioMute != FALSE )
                {
                    bMuteProcess = TRUE;
                }
                break;

            case E_AUDIO_PERMANENT_MUTEON:
                if ( m_bPermanentAudioMute != TRUE)
                {
                    bMuteProcess = TRUE;
                }
                break;

            case E_AUDIO_MOMENT_MUTEOFF:
                if ( m_bMomentAudioMute != FALSE )
                {
                    bMuteProcess = TRUE;
                }
                break;

            case E_AUDIO_MOMENT_MUTEON:
                if ( m_bMomentAudioMute != TRUE )
                {
                    bMuteProcess = TRUE;
                }
                break;

            case E_AUDIO_BYUSER_MUTEOFF:
                if ( m_bByUserAudioMute != FALSE )
                {
                    bMuteProcess = TRUE;
                }
                break;

            case E_AUDIO_BYUSER_MUTEON:
                if ( m_bByUserAudioMute != TRUE)
                {
                    bMuteProcess = TRUE;
                }
                break;

            case E_AUDIO_BYSYNC_MUTEOFF:
                if (m_bBySyncAudioMute != FALSE)
                {
                    bMuteProcess = TRUE;
                }
                break;

            case E_AUDIO_BYSYNC_MUTEON:
                if (m_bBySyncAudioMute != TRUE)
                {
                    bMuteProcess = TRUE;
                }
                break;

            case E_AUDIO_BYVCHIP_MUTEOFF:
                if (m_bByVChipAudioMute != FALSE)
                {
                    bMuteProcess = TRUE;
                }
                break;

            case E_AUDIO_BYVCHIP_MUTEON:
                if (m_bByVChipAudioMute != TRUE)
                {
                    bMuteProcess = TRUE;
                }
                break;

            case E_AUDIO_BYBLOCK_MUTEOFF:
                if (m_bByBlockAudioMute != FALSE)
                {
                    bMuteProcess = TRUE;
                }
                break;

            case E_AUDIO_BYBLOCK_MUTEON:
                if (m_bByBlockAudioMute != TRUE)
                {
                    bMuteProcess = TRUE;
                }
                break;

            case E_AUDIO_INTERNAL_1_MUTEOFF:
                if (m_bInternal1AudioMute != FALSE)
                {
                    bMuteProcess = TRUE;
                }
                break;

            case E_AUDIO_INTERNAL_1_MUTEON:
                if (m_bInternal1AudioMute != TRUE)
                {
                    bMuteProcess = TRUE;
                }
                break;

            case E_AUDIO_INTERNAL_2_MUTEOFF:
                if (m_bInternal2AudioMute != FALSE)
                {
                    bMuteProcess = TRUE;
                }
                break;

            case E_AUDIO_INTERNAL_2_MUTEON:
                if (m_bInternal2AudioMute != TRUE)
                {
                    bMuteProcess = TRUE;
                }
                break;

            case E_AUDIO_INTERNAL_3_MUTEOFF:
                if (m_bInternal3AudioMute != FALSE)
                {
                    bMuteProcess = TRUE;
                }
                break;

            case E_AUDIO_INTERNAL_3_MUTEON:
                if (m_bInternal3AudioMute != TRUE)
                {
                    bMuteProcess = TRUE;
                }
                break;

            case E_AUDIO_INTERNAL_4_MUTEOFF:
                if (m_bInternal4AudioMute != FALSE)
                {
                    bMuteProcess = TRUE;
                }
                break;

            case E_AUDIO_INTERNAL_4_MUTEON:
                if (m_bInternal4AudioMute != TRUE)
                {
                    bMuteProcess = TRUE;
                }
                break;

            case E_AUDIO_DURING_LIMITED_TIME_MUTEOFF:
                if (m_bByDuringLimitedTimeAudioMute != FALSE)
                {
                    bMuteProcess = TRUE;
                }
                break;

            case E_AUDIO_DURING_LIMITED_TIME_MUTEON:
                if ( m_bByDuringLimitedTimeAudioMute != TRUE )
                {
                    bMuteProcess = TRUE;
                }
                break;

            // MHEG AP Mute Off
            case E_AUDIO_MHEGAP_MUTEOFF:
                if (m_bMHEGApMute != FALSE)
                {
                    bMuteProcess = TRUE;
                }
                break;

            // MHEG AP Mute On
            case E_AUDIO_MHEGAP_MUTEON:
                if (m_bMHEGApMute != TRUE)
                {
                    bMuteProcess = TRUE;
                }
                break;

            case E_AUDIO_CI_MUTEOFF:
                if (m_bCIAudioMute != FALSE)
                {
                    bMuteProcess = TRUE;
                }
                break;

            case E_AUDIO_CI_MUTEON:
                if (m_bCIAudioMute != TRUE)
                {
                    bMuteProcess = TRUE;
                }
                break;


            default:
                  break;
        }

        if ( bMuteProcess )
        {
        #if (ENABLE_CHANNEL_CHANGE_MUTE_ON_OFF_DELAY)
            if ((wParam1%2)==0)   // Mute off
            {
                if(!m_bByPassDelay) //fix laggardly issue of playing movie; MHEG Audio File Playback also needs no time delay when mute on/off
                {
                    msAPI_Timer_Delayms(DELAY_FOR_LEAVING_MUTE);
                }
            }

            SetAudioMute((AUDIOMUTETYPE) wParam1, (AUDIOMUTESOURCE_TYPE) wParam2);

            if ((wParam1%2)==1)  // Mute on
            {
                if(!m_bByPassDelay) //fix laggardly issue of playing movie; MHEG Audio File Playback also needs no time delay when mute on/off
                {
                    msAPI_Timer_Delayms(DELAY_FOR_ENTERING_MUTE);
                }
            }
        #else
            SetAudioMute((AUDIOMUTETYPE) wParam1, (AUDIOMUTESOURCE_TYPE) wParam2);
        #endif
        }
        break;

    case E_ADJUST_AUDIOMUTE_DURING_LIMITED_TIME:
        SetAudioMuteDuringLimitedTime(wParam1, (AUDIOMUTESOURCE_TYPE) wParam2);
        break;

    case E_ADJUST_VOLUME:
        if( wParam1 <= 100 )
            m_cAudioVolumePercentage = (BYTE)wParam1;
#if ENABLE_NO_AUDIO_INPUT_AUTO_MUTE //minglin0111
		if(m_bByUserAudioMute == TRUE)
			return;

		if(IsAVInUse()||IsSVInUse()||IsYPbPrInUse()||IsVgaInUse()||IsATVInUse()||IsHDMIInUse())
		{
			BYTE NR_status;
			
			//printf("\r\n-5-");
		 if(MApp_IsSrcHasSignal(MAIN_WINDOW))
		   {
			NR_status = MApi_AUDIO_GetCommAudioInfo(Audio_Comm_infoType_getNR_Status) ;
			{
				if(!NR_status)
				{
				   if((IsVgaInUse())||(UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_AV2))
				   	{
                   MUTE_On();
				   printf("==>>>>>>>>>>>>>>msAPI_audio_mute_on()<<<<<<<<<<<<\n");
				   }
				   else
				   	{
					if(!msAPI_AUD_IsAudioMutedByUser()&&stGenSetting.g_SoundSetting.Volume)
					MUTE_Off();
					else
					MUTE_On();
				   	}
				}
				else
				{
					MUTE_On();
				}
			}
		   }
		 else
			 MUTE_On();
		}
		else
		{
			if(stGenSetting.g_SoundSetting.Volume>0)
			{
			#if ENABLE_NO_AUDIO_INPUT_AUTO_MUTE //minglin0111
				if(IsStorageInUse()&&MAPP_USBAudioMute())
				{
					MUTE_On();
					return;
				}
			#endif
				if(!IsStorageInUse()&&( m_bPermanentAudioMute == TRUE ||
				  m_bMomentAudioMute == TRUE ||
				  m_bByUserAudioMute == TRUE ||
				  m_bBySyncAudioMute == TRUE ||
				  m_bByVChipAudioMute == TRUE ||
				  m_bByBlockAudioMute == TRUE ||
				  m_bInternal1AudioMute == TRUE ||
				  m_bInternal2AudioMute == TRUE ||
				  m_bInternal3AudioMute == TRUE ||
				  m_bInternal4AudioMute == TRUE ||
				  m_bByDuringLimitedTimeAudioMute == TRUE ))
				{
					return;
				}
				MUTE_Off();
			}
			else
			 MUTE_On();
		}
        if(!IsStorageInUse()&&( m_bPermanentAudioMute == TRUE ||
            m_bMomentAudioMute == TRUE ||
            m_bByUserAudioMute == TRUE ||
            m_bBySyncAudioMute == TRUE ||
            m_bByVChipAudioMute == TRUE ||
            m_bByBlockAudioMute == TRUE ||
            m_bInternal1AudioMute == TRUE ||
            m_bInternal2AudioMute == TRUE ||
            m_bInternal3AudioMute == TRUE ||
            m_bInternal4AudioMute == TRUE ||
            m_bByDuringLimitedTimeAudioMute == TRUE ))
        {
            return;
        }
#else
        if( m_bPermanentAudioMute == TRUE ||
            m_bMomentAudioMute == TRUE ||
            m_bByUserAudioMute == TRUE ||
            m_bBySyncAudioMute == TRUE ||
            m_bByVChipAudioMute == TRUE ||
            m_bByBlockAudioMute == TRUE ||
            m_bInternal1AudioMute == TRUE ||
            m_bInternal2AudioMute == TRUE ||
            m_bInternal3AudioMute == TRUE ||
            m_bInternal4AudioMute == TRUE ||
            m_bByDuringLimitedTimeAudioMute == TRUE )
        {
            return;
        }

#endif
        MApp_Audio_AdjustMainVolume(m_cAudioVolumePercentage);
        #if ENABLE_CUS_HEADPHONE_SPEC
        MApp_Audio_AdjustHeadPhoneVolume(m_cAudioVolumePercentage);
        #endif
        break;

    case E_ADJUST_CHANGE_AUDIOMODE: //APP used
        msAPI_AUD_ChangeAudioMode();
    #ifndef ATSC_SYSTEM//ATSC_FIX_C
        if( (m_eAudioSource == E_AUDIOSOURCE_ATV) && (msAPI_AVD_IsAutoAVActive(E_AUTOAV_SOURCE_2) == TRUE) )
            msAPI_ATV_SetAudioMode(E_AUDIOSOURCE_SCART2, m_eAudioMode);
        else if( (m_eAudioSource == E_AUDIOSOURCE_ATV) && (msAPI_AVD_IsAutoAVActive(E_AUTOAV_SOURCE_1) == TRUE) )
            msAPI_ATV_SetAudioMode(E_AUDIOSOURCE_SCART1, m_eAudioMode);
        else
            msAPI_ATV_SetAudioMode(m_eAudioSource, m_eAudioMode);
    #endif
        break;

     default:
        break;
    }
}

/******************************************************************************/
/// API for Audio::
/// Check audio is muted now
/// @return true or false
/******************************************************************************/
BOOLEAN msAPI_AUD_IsAudioMuted(void)
{
    if( m_bPermanentAudioMute == FALSE &&
        m_bMomentAudioMute == FALSE &&
        m_bByUserAudioMute == FALSE &&
        m_bBySyncAudioMute == FALSE &&
        m_bByVChipAudioMute == FALSE &&
        m_bByBlockAudioMute == FALSE &&
        m_bInternal1AudioMute == FALSE &&
        m_bInternal2AudioMute == FALSE &&
        m_bInternal3AudioMute == FALSE &&
        m_bInternal4AudioMute == FALSE &&
        m_bByDuringLimitedTimeAudioMute == FALSE )
    {
        return FALSE;
    }

    return TRUE;
}

/******************************************************************************/
/// API for Audio::
/// Check audio is muted by user or not
/// @return true or false
/******************************************************************************/
BOOLEAN msAPI_AUD_IsAudioMutedByUser(void)
{
    if(m_bByUserAudioMute == FALSE)
        return FALSE;

    return TRUE;
}

/******************************************************************************/
/// API for Audio::
/// Set audio mute during time limit
/// @param w1ms \b IN Limit time of mute
/// @param eAudioMuteSource \b IN the audio source type
/******************************************************************************/
static void SetAudioMuteDuringLimitedTime(WORD w1ms, AUDIOMUTESOURCE_TYPE eAudioMuteSource)
{
      SetAudioMute(E_AUDIO_DURING_LIMITED_TIME_MUTEON, eAudioMuteSource);

      m_wLimitedTimeOfMute = w1ms;
      m_dwStartedTimeOfMute = msAPI_Timer_GetTime0();
}

/******************************************************************************/
/// API for Audio::
/// Check the audio mute time is expiration or not.
/******************************************************************************/
void msAPI_AUD_CheckExpirationOfAudioMute(void)
{
    if( m_wLimitedTimeOfMute == 0 )
        return;

    if(msAPI_Timer_DiffTimeFromNow(m_dwStartedTimeOfMute) > m_wLimitedTimeOfMute)
    {
        SetAudioMute(E_AUDIO_DURING_LIMITED_TIME_MUTEOFF, E_AUDIOMUTESOURCE_ACTIVESOURCE);
        m_wLimitedTimeOfMute = 0;
        m_dwStartedTimeOfMute = 0;
    }
}

/******************************************************************************/
/// API for Audio::
/// The main function of setting audio mute
/// @param eAudioMuteType \b IN The mute type
/// @param eAudioMuteSource \b IN The input source that needs to be mute
/******************************************************************************/
static void SetAudioMute(AUDIOMUTETYPE eAudioMuteType, AUDIOMUTESOURCE_TYPE eAudioMuteSource)
{
    if( (eAudioMuteSource != E_AUDIOMUTESOURCE_ACTIVESOURCE) && (eAudioMuteSource !=(AUDIOMUTESOURCE_TYPE) m_eAudioSource) )
        return;

    MS_BOOL spkrMute, scartMute, spdifMute;

    switch(eAudioMuteType)
    {
    case E_AUDIO_MHEGAP_MUTEOFF:
        m_bMHEGApMute = FALSE;
        break;
    case E_AUDIO_MHEGAP_MUTEON:
        m_bMHEGApMute = TRUE;
        break;

    case E_AUDIO_PERMANENT_MUTEOFF:
        m_bPermanentAudioMute = FALSE;
        break;

    case E_AUDIO_PERMANENT_MUTEON:
        m_bPermanentAudioMute = TRUE;
        break;

    case E_AUDIO_MOMENT_MUTEOFF:
        m_bMomentAudioMute = FALSE;
        break;
    case E_AUDIO_MOMENT_MUTEON:
        m_bMomentAudioMute = TRUE;
        break;
    case E_AUDIO_BYUSER_MUTEOFF:
        m_bByUserAudioMute = FALSE;
        break;
    case E_AUDIO_BYUSER_MUTEON:
        m_bByUserAudioMute = TRUE;
        break;
    case E_AUDIO_BYSYNC_MUTEOFF:
        m_bBySyncAudioMute = FALSE;
        break;
    case E_AUDIO_BYSYNC_MUTEON:
        m_bBySyncAudioMute = TRUE;
        break;
    case E_AUDIO_BYVCHIP_MUTEOFF:
        m_bByVChipAudioMute = FALSE;
        break;
    case E_AUDIO_BYVCHIP_MUTEON:
        m_bByVChipAudioMute = TRUE;
        break;
    case E_AUDIO_BYBLOCK_MUTEOFF:
        m_bByBlockAudioMute = FALSE;
        break;
    case E_AUDIO_BYBLOCK_MUTEON:
        m_bByBlockAudioMute = TRUE;
        break;
    case E_AUDIO_INTERNAL_1_MUTEOFF:
        m_bInternal1AudioMute = FALSE;
        break;
    case E_AUDIO_INTERNAL_1_MUTEON:
        m_bInternal1AudioMute = TRUE;
        break;
    case E_AUDIO_INTERNAL_2_MUTEOFF:
        m_bInternal2AudioMute = FALSE;
        break;
    case E_AUDIO_INTERNAL_2_MUTEON:
        m_bInternal2AudioMute = TRUE;
        break;
    case E_AUDIO_INTERNAL_3_MUTEOFF:
        m_bInternal3AudioMute = FALSE;
        break;
    case E_AUDIO_INTERNAL_3_MUTEON:
        m_bInternal3AudioMute = TRUE;
        break;
    case E_AUDIO_INTERNAL_4_MUTEOFF:
        m_bInternal4AudioMute = FALSE;
        break;
    case E_AUDIO_INTERNAL_4_MUTEON:
        m_bInternal4AudioMute = TRUE;
        break;
    case E_AUDIO_DURING_LIMITED_TIME_MUTEOFF:
        m_bByDuringLimitedTimeAudioMute = FALSE;
        break;
    case E_AUDIO_DURING_LIMITED_TIME_MUTEON:
        m_bByDuringLimitedTimeAudioMute = TRUE;
        break;
    case E_AUDIO_CI_MUTEOFF:
        m_bCIAudioMute = FALSE;
        break;
    case E_AUDIO_CI_MUTEON:
        m_bCIAudioMute = TRUE;
        break;

    default:
        return;
    }

#if 0
    printf("audio mute status: p:%d,", m_bPermanentAudioMute);
    printf("m:%d,",m_bMomentAudioMute);
    printf("u:%d,",m_bByUserAudioMute);
    printf("s:%d,",m_bBySyncAudioMute);
    printf("b:%d,",m_bByBlockAudioMute);
    printf("v:%d,",m_bByVChipAudioMute);
    printf("i1:%d,",m_bInternal1AudioMute);
    printf("i2:%d,",m_bInternal2AudioMute);
    printf("i3:%d,",m_bInternal3AudioMute);
    printf("i4:%d,",m_bInternal4AudioMute);
    printf("t:%d,",m_bByDuringLimitedTimeAudioMute);
    printf("mhg:%d,", m_bMHEGApMute);
    printf("CI:%d\n",m_bCIAudioMute);
#endif

        spkrMute =  m_bPermanentAudioMute|
                    m_bMomentAudioMute|
                    m_bByUserAudioMute|
                    m_bBySyncAudioMute|
                    m_bByBlockAudioMute|
                    m_bByVChipAudioMute|
                    m_bInternal1AudioMute|
                    m_bInternal2AudioMute|
                    m_bInternal3AudioMute|
                    m_bInternal4AudioMute|
                    //m_bCIAudioMute|
                    m_bByDuringLimitedTimeAudioMute|
                    m_bMHEGApMute;

        scartMute = m_bPermanentAudioMute|
                    m_bMomentAudioMute|
                    //m_bByUserAudioMute|           //remote mute cannot mute SCART
                    m_bBySyncAudioMute|
                    m_bByBlockAudioMute|
                    m_bByVChipAudioMute|
                    m_bInternal1AudioMute|
                    m_bInternal2AudioMute|
                    m_bInternal3AudioMute|
                    m_bInternal4AudioMute|
                    m_bCIAudioMute|
                    m_bByDuringLimitedTimeAudioMute|
                    m_bMHEGApMute;

        spdifMute = m_bPermanentAudioMute|
                    m_bMomentAudioMute|
                    //m_bByUserAudioMute|         //reomte mute cannot mute SPDIF
                    m_bBySyncAudioMute|
                    m_bByBlockAudioMute|
                    m_bByVChipAudioMute|
                    m_bInternal1AudioMute|
                    m_bInternal2AudioMute|
                    m_bInternal3AudioMute|
                    m_bInternal4AudioMute|
                    //m_bCIAudioMute|
                    m_bByDuringLimitedTimeAudioMute|
                    m_bMHEGApMute;

        if(scartMute == TRUE)
        {
            MW_AUD_SetSoundMute(SOUND_MUTE_SCART, E_MUTE_ON);
            MW_AUD_SetSoundMute(SOUND_MUTE_SCART2, E_MUTE_ON);
        }
        else
        {
            MW_AUD_SetSoundMute(SOUND_MUTE_SCART, E_MUTE_OFF);
            MW_AUD_SetSoundMute(SOUND_MUTE_SCART2, E_MUTE_OFF);
        }

        if(spdifMute == TRUE)
        {
            MW_AUD_SetSoundMute(SOUND_MUTE_SPDIF, E_MUTE_ON);
        }
        else
        {
            MW_AUD_SetSoundMute(SOUND_MUTE_SPDIF, E_MUTE_OFF);
        }

        if (spkrMute == TRUE)
        {
            MW_AUD_SetSoundMute(SOUND_MUTE_TV, E_MUTE_ON);

#if !(AUDIO_EN_CONTROL_DISABLE) // CUS_XM Sea 20120615
            MUTE_On();
#endif

        }
        else
        {
            MApp_Audio_AdjustMainVolume(m_cAudioVolumePercentage);
            #if ENABLE_CUS_HEADPHONE_SPEC
            MApp_Audio_AdjustHeadPhoneVolume(m_cAudioVolumePercentage);
            #endif
        #if (EAR_PHONE_POLLING && ENABLE_CUS_HEADPHONE_SPEC)
            if (GetEarphoneState() == EAR_PHONE_NULL)
        #endif
            {
                MW_AUD_SetSoundMute(SOUND_MUTE_TV, E_MUTE_OFF);
            }
			#if 0//BOE_POP_MODIFY//minglin0220
 			msAPI_Timer_Delayms(1000);
			#endif
#if !ENABLE_NO_AUDIO_INPUT_AUTO_MUTE
            MUTE_Off();
#endif
        }
#if ENABLE_NO_AUDIO_INPUT_AUTO_MUTE
		if(IsAVInUse()||IsSVInUse()||IsYPbPrInUse()||IsVgaInUse()||IsATVInUse()||IsHDMIInUse())
		{
			BYTE NR_status;		
			
			//printf("\r\n-6-");
		  if(MApp_IsSrcHasSignal(MAIN_WINDOW))
		   {
			NR_status = MApi_AUDIO_GetCommAudioInfo(Audio_Comm_infoType_getNR_Status) ;
			{
				if(!NR_status)
				{
					if(!msAPI_AUD_IsAudioMutedByUser()&&stGenSetting.g_SoundSetting.Volume)
					{
						if(spkrMute == FALSE)
						{
						msAPI_Timer_Delayms(300);
						MUTE_Off();
						}
					}
					else
						MUTE_On();
				}
				else
				{
					MUTE_On();
				}
			}
		  }
		  else
		  	MUTE_On();
		}
		else
		{
			if(spkrMute == TRUE)
			{
				MUTE_On();
			}
			else
			{
			 if(IsStorageInUse()&&MAPP_USBAudioMute())
			   MUTE_On();
			 else
			  {
  			   msAPI_Timer_Delayms(300);
  			   MUTE_Off();
			  }
			}
		}
  #endif

}

#if (ENABLE_CHANNEL_CHANGE_MUTE_ON_OFF_DELAY)
void msAPI_AUD_SetByPassDelayFlag(BOOLEAN flag)
{
    m_bByPassDelay = flag;
}
#endif

//****************************************************************************
// Start of private implementation
//****************************************************************************

void msAPI_AUD_SwitchAduioDSPSystem(AUDIO_DSP_SYSTEM eAudioDSPSystem)
{
    WORD timeout = 0;

    if( m_eAudioDSPSystem == eAudioDSPSystem)
    {
        if (eAudioDSPSystem == E_AUDIO_DSP_SIF)
        {
            MDrv_AUDIO_TriggerSifPLL();
        }
        return;
    }

    /*****************************************************************
    *  S4 Bug Fix: Audio dsp download code error
    *  Audio DSP will download code from flash, if flash is busy for other process.
    *  Then dsp will download wrong code, add safe check code to avoid dsp download fail
    ******************************************************************/
    while((MDrv_FLASH_CheckWriteDone() == FALSE)&&(timeout++ < 1000))
        MsOS_DelayTask(1);

    if(timeout >= 1000)
    {
        MS_DEBUG_MSG(printf("flash chk fail \r\n"));
    }

    switch(eAudioDSPSystem)
    {
    case E_AUDIO_DSP_AC3:
    MApi_AUDIO_SetCommand((En_DVB_decCmdType)MSAPI_AUD_STOP);
        m_eAudioDSPSystem = E_AUDIO_DSP_AC3;
        MApi_AUDIO_SetSystem(MSAPI_AUD_DVB_AC3);//MDrv_MAD_SetSystem(AU_DVB_SYS_AC3);
        break;

    case E_AUDIO_DSP_AC3_AD:
        m_eAudioDSPSystem = E_AUDIO_DSP_AC3_AD;
        MApi_AUDIO_SetSystem(MSAPI_AUD_DVB2_AC3);//MDrv_MAD2_SetSystem(AU_DVB2_SYS_AC3_AD);  // Separate DVB2(AD) decoder from DVB
        break;

    case E_AUDIO_DSP_AC3P:
    MApi_AUDIO_SetCommand((En_DVB_decCmdType)MSAPI_AUD_STOP);
        m_eAudioDSPSystem = E_AUDIO_DSP_AC3P;
        MApi_AUDIO_SetSystem(MSAPI_AUD_DVB_AC3P);//MDrv_MAD_SetSystem(AU_DVB_SYS_AC3P);
        break;

    case E_AUDIO_DSP_AC3P_AD:
        m_eAudioDSPSystem = E_AUDIO_DSP_AC3P_AD;
        MApi_AUDIO_SetSystem(MSAPI_AUD_DVB2_AC3P);//MDrv_MAD2_SetSystem(AU_DVB2_SYS_AC3P_AD);
        break;

    case E_AUDIO_DSP_SIF:
        m_eAudioDSPSystem = E_AUDIO_DSP_SIF;
        MApi_AUDIO_SIF_SendCmd(MSAPI_AUD_SIF_CMD_SET_STOP, 0,0);// stop play
        #if (ENABLE_SBTVD_BRAZIL_APP)
            MApi_AUDIO_SetSystem(MSAPI_AUD_ATV_BTSC);
        #elif (TV_SYSTEM == TV_PAL)
            MApi_AUDIO_SetSystem(MSAPI_AUD_ATV_PAL);
        #elif (TV_SYSTEM == TV_NTSC)
            #if (AUDIO_SYSTEM_SEL == AUDIO_SYSTEM_BTSC)
                MApi_AUDIO_SetSystem(MSAPI_AUD_ATV_BTSC);
            #elif (AUDIO_SYSTEM_SEL == AUDIO_SYSTEM_A2)
                MApi_AUDIO_SetSystem(MSAPI_AUD_ATV_PAL);
            #endif
        #endif
        MApi_AUDIO_SIF_SetThreshold(AuSifInitThreshold);

        #if (ENABLE_SBTVD_BRAZIL_APP)
            MApi_AUDIO_SIF_SetPrescale(SET_PRESCALE_BTSC,0);
        #elif (TV_SYSTEM == TV_PAL)
            #if((FRONTEND_IF_DEMODE_TYPE==MSTAR_VIF)||(FRONTEND_IF_DEMODE_TYPE==MSTAR_VIF_MSB1210)||(FRONTEND_IF_DEMODE_TYPE==MSTAR_INTERN_VIF))
            MApi_AUDIO_SIF_SetPrescale(SET_PRESCALE_A2_FM,3); //kochien for VIF
            MApi_AUDIO_SIF_SetPrescale(SET_PRESCALE_NICAM,3);
            MApi_AUDIO_SIF_SetPrescale(SET_PRESCALE_AM,7);
            MApi_AUDIO_SIF_SetPrescale(SET_PRESCALE_HIDEV,3);
            #else  // MSTAR_INTERN_VIF & NONE_VIF
            MApi_AUDIO_SIF_SetPrescale(SET_PRESCALE_A2_FM,6);
            MApi_AUDIO_SIF_SetPrescale(SET_PRESCALE_AM,9);
            MApi_AUDIO_SIF_SetPrescale(SET_PRESCALE_NICAM,6);
            MApi_AUDIO_SIF_SetPrescale(SET_PRESCALE_HIDEV,6);
            #endif
        #elif (TV_SYSTEM == TV_NTSC)
            #if (AUDIO_SYSTEM_SEL == AUDIO_SYSTEM_BTSC)
                MApi_AUDIO_SIF_SetPrescale(SET_PRESCALE_BTSC,0);
            #elif (AUDIO_SYSTEM_SEL == AUDIO_SYSTEM_A2)
                MApi_AUDIO_SIF_SetPrescale(SET_PRESCALE_FM_M,0); //Korea A2
            #endif
        #endif
        MDrv_AUDIO_TriggerSifPLL();
        MApi_AUDIO_SIF_SendCmd(MSAPI_AUD_SIF_CMD_SET_PLAY, 0,0);
        break;

    case E_AUDIO_DSP_AACP:
    MApi_AUDIO_SetCommand((En_DVB_decCmdType)MSAPI_AUD_STOP);
        m_eAudioDSPSystem = E_AUDIO_DSP_AACP;
        MApi_AUDIO_SetSystem(MSAPI_AUD_DVB_AAC);//MDrv_MAD_SetSystem(AU_DVB_SYS_AAC);
        break;

    case E_AUDIO_DSP_MPEG_AD:
        m_eAudioDSPSystem = E_AUDIO_DSP_MPEG_AD;
        MApi_AUDIO_SetSystem(MSAPI_AUD_DVB2_MPEG);//MDrv_MAD2_SetSystem(AU_DVB2_SYS_MPEG_AD);  // Separate DVB2(AD) decoder from DVB
        break;

    case E_AUDIO_DSP_AACP_AD:
        m_eAudioDSPSystem = E_AUDIO_DSP_AACP_AD;
        MApi_AUDIO_SetSystem(MSAPI_AUD_DVB2_AAC);//MDrv_MAD2_SetSystem(AU_DVB2_SYS_AAC_AD);  // Separate DVB2(AD) decoder from DVB
        break;

    case E_AUDIO_DSP_MPEG:
    default:
        MApi_AUDIO_SetCommand((En_DVB_decCmdType)MSAPI_AUD_STOP);
        m_eAudioDSPSystem = E_AUDIO_DSP_MPEG;
        MApi_AUDIO_SetSystem(MSAPI_AUD_DVB_MPEG);//MDrv_MAD_SetSystem(AU_DVB_SYS_MPEG);
        break;
    }

}

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
///
///           AUDIO_ATV RELATIONAL API FUNCTION
///
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

/******************************************************************************/
/// API for Audio::
/// Get the present audio standard.
/// @return the audio standard
/******************************************************************************/
AUDIOSTANDARD_TYPE msAPI_AUD_GetAudioStandard(void)
{
    if(E_AUDIOSTANDARD_NOTSTANDARD == MApi_AUDIO_SIF_ConvertToBasicAudioStandard(m_eAudioStandard))
    {
    #ifdef ATSC_SYSTEM //ATSC_FIX_C
        return E_AUDIOSTANDARD_NOTSTANDARD;
    #else
        #if (TV_SYSTEM == TV_NTSC)
            #if (AUDIO_SYSTEM_SEL == AUDIO_SYSTEM_BTSC)
                return E_AUDIOSTANDARD_M_BTSC;
            #elif (AUDIO_SYSTEM_SEL == AUDIO_SYSTEM_A2)
                return E_AUDIOSTANDARD_M_A2;
            #endif
        #else
        //return msAPI_ATV_GetAudioStandard(msAPI_ATV_GetCurrentProgramNumber());

        //Use "msAPI_ATV_GetCurrentProgramNumber()" to refer the audio standard of previous channel is wrong at manual tuning.
        //Suggest to assign default audio standard. 20100321EL
            #if ( ENABLE_DTMB_CHINA_APP || ENABLE_ATV_CHINA_APP )
                return E_AUDIOSTANDARD_DK;
            #else
                return E_AUDIOSTANDARD_BG;
            #endif
        #endif
    #endif
    }

    return m_eAudioStandard;
}


/******************************************************************************/
/// API for Audio::
/// chec if audio stand is detected
/// @return true/ false
/******************************************************************************/

BOOLEAN msAPI_AUD_IsAudioDetected(void)
{
    if(E_AUDIOSTANDARD_NOTSTANDARD == MApi_AUDIO_SIF_ConvertToBasicAudioStandard(m_eAudioStandard))
        return FALSE;
    else
        return TRUE;

}


/******************************************************************************/
/// API for Audio::
/// Set the audio standard.
/// @param eStandard \b IN The audio standard
/******************************************************************************/
void msAPI_AUD_SetAudioStandard(AUDIOSTANDARD_TYPE eStandard)
{
#if (TV_SYSTEM == TV_NTSC)
    m_eAudioStandard = eStandard;
#else
    m_eAudioStandard = MApi_AUDIO_SIF_ConvertToBasicAudioStandard(eStandard);
#endif

    if( E_AUDIOSTANDARD_NOTSTANDARD == m_eAudioStandard )
    {
    #ifndef ATSC_SYSTEM //ATSC_FIX_C
        eStandard = msAPI_ATV_GetAudioStandard(msAPI_ATV_GetCurrentProgramNumber());
    #endif

        if(eStandard == E_AUDIOSTANDARD_NOTSTANDARD)
        {
        #if ( ENABLE_DTMB_CHINA_APP || ENABLE_ATV_CHINA_APP )
            #if (TV_SYSTEM == TV_NTSC)
                #if (AUDIO_SYSTEM_SEL == AUDIO_SYSTEM_BTSC)
                    eStandard = E_AUDIOSTANDARD_M_BTSC;
                #elif (AUDIO_SYSTEM_SEL == AUDIO_SYSTEM_A2)
                    eStandard = E_AUDIOSTANDARD_M_A2;
                #endif
            #else
                eStandard = E_AUDIOSTANDARD_DK;
            #endif
        #else
                eStandard = E_AUDIOSTANDARD_BG;
        #endif
        }
    }

    SetAudioMute(E_AUDIO_INTERNAL_1_MUTEON, E_AUDIOMUTESOURCE_ATV);
    MApi_AUDIO_SIF_SendCmd(MSAPI_AUD_SIF_STANDARD_RESET, NULL, NULL);
    g_A2ModeInvalidCnt = 0;

    if(m_eAudioStandard == E_AUDIOSTANDARD_L)
        MApi_AUDIO_SIF_SetPALType(AU_SIF_PAL_NICAM);
    else
        MApi_AUDIO_SIF_SetPALType(AU_SIF_PAL_MONO);

    MApi_AUDIO_SIF_SetStandard(m_eAudioStandard);
    MApi_AUDIO_SIF_SetSoundMode(m_eAudioMode);
    m_eAudioStatus = E_STATE_AUDIO_NO_CARRIER;

    //if( (m_eAudioSource == E_AUDIOSOURCE_ATV) && (msAPI_AVD_IsAutoAVActive(E_AUTOAV_SOURCE_ALL) == FALSE) )

    msAPI_Timer_Delayms(DELAY_FOR_ENTERING_MUTE);
    SetAudioMute(E_AUDIO_INTERNAL_1_MUTEOFF, E_AUDIOMUTESOURCE_ATV);
}

/******************************************************************************/
/// API for Audio::
/// Force to set the audio standard.
/// @param eStandard \b IN The audio standard
/******************************************************************************/
void msAPI_AUD_ForceAudioStandard(AUDIOSTANDARD_TYPE eStandard)
{
    #ifndef ATSC_SYSTEM//ATSC_FIX_C
    AUDIOMODE_TYPE eAudioMode;
    #endif

    SetAudioMute(E_AUDIO_INTERNAL_1_MUTEON, E_AUDIOMUTESOURCE_ATV);
    msAPI_AUD_SetAudioStandard(eStandard);

#ifndef ATSC_SYSTEM//ATSC_FIX_C
    msAPI_ATV_GetAudioMode(E_AUDIOSOURCE_ATV, &eAudioMode);
#endif

    msAPI_Timer_Delayms(DELAY_FOR_ENTERING_MUTE);
    SetAudioMute(E_AUDIO_INTERNAL_1_MUTEOFF, E_AUDIOMUTESOURCE_ATV);
}

/******************************************************************************/
/// API for Audio::
/// Get the result of audio standard after auto standard detection called.
/// @return the audio standard type
/******************************************************************************/
#if (TV_SYSTEM == TV_NTSC)
AUDIOSTANDARD_TYPE msAPI_AUD_GetResultOfAutoStandardDetection(void)
{
#if (AUDIO_SYSTEM_SEL == AUDIO_SYSTEM_BTSC)
    m_eAudioStandard = E_AUDIOSTANDARD_M_BTSC;
#elif (AUDIO_SYSTEM_SEL == AUDIO_SYSTEM_A2)
    m_eAudioStandard = E_AUDIOSTANDARD_M_A2;
#endif

    return m_eAudioStandard;
}
#else
AUDIOSTANDARD_TYPE msAPI_AUD_GetResultOfAutoStandardDetection(void)
{
    if(m_eAudioStandard != E_AUDIOSTANDARD_L)
    {
        m_eAudioStandard = MApi_AUDIO_SIF_GetResultOfAutoStandardDetection();

        // Get Audio Status
        MApi_AUDIO_SIF_GetAudioStatus(&m_eAudioStatus);

/*
        if( E_AUDIOSTANDARD_NOTSTANDARD == MApi_AUDIO_SIF_ConvertToBasicAudioStandard(m_eAudioStandard) )
        {
            if(m_eAudioStandard == E_AUDIOSTANDARD_NOTSTANDARD)
                m_eAudioStandard = E_AUDIOSTANDARD_BG;
        }
*/
        if ( IS_SYSTEM_L_ENABLED == TRUE )
        {
            if( E_AUDIOSTANDARD_M == MApi_AUDIO_SIF_ConvertToBasicAudioStandard(m_eAudioStandard) )
            {
                if( m_eAudioStandard == E_AUDIOSTANDARD_NOTSTANDARD ||
                    m_eAudioStandard == E_AUDIOSTANDARD_M )
                {
                #if ( ENABLE_DTMB_CHINA_APP || ENABLE_ATV_CHINA_APP )
                    m_eAudioStandard = E_AUDIOSTANDARD_DK;
                #else
                    m_eAudioStandard = E_AUDIOSTANDARD_BG;
                #endif
                }
            }
        }

        MApi_AUDIO_SIF_SendCmd(MSAPI_AUD_SIF_STANDARD_RESET, 0, 0);
        if( E_AUDIOSTANDARD_NOTSTANDARD == MApi_AUDIO_SIF_ConvertToBasicAudioStandard(m_eAudioStandard) )
        {
          #if ( ENABLE_DTMB_CHINA_APP || ENABLE_ATV_CHINA_APP )
            MApi_AUDIO_SIF_SetStandard(E_AUDIOSTANDARD_DK);
          #else
            MApi_AUDIO_SIF_SetStandard(E_AUDIOSTANDARD_BG);
          #endif
        }
        else
            MApi_AUDIO_SIF_SetStandard(m_eAudioStandard);

    }

    return m_eAudioStandard;
}
#endif

/******************************************************************************/
/// API for Audio::
/// Get the detected TV audio mode
/// @return the audio standard type
/******************************************************************************/
void msAPI_AUD_ForceAudioMode(AUDIOMODE_TYPE eAudioMode)
{
    if( (m_eAudioSource != E_AUDIOSOURCE_ATV) || ((m_eAudioSource == E_AUDIOSOURCE_ATV) && (TRUE == msAPI_AVD_IsAutoAVActive(E_AUTOAV_SOURCE_ALL))) )
    {
        switch(eAudioMode)
        {
        case E_AUDIOMODE_LEFT_RIGHT:
            m_eAudioMode = E_AUDIOMODE_LEFT_RIGHT;
            break;

        case E_AUDIOMODE_LEFT_LEFT:
            m_eAudioMode = E_AUDIOMODE_LEFT_LEFT;
            break;

        case E_AUDIOMODE_RIGHT_RIGHT:
            m_eAudioMode = E_AUDIOMODE_RIGHT_RIGHT;
            break;

        default:
            m_eAudioMode = E_AUDIOMODE_LEFT_RIGHT;
            break;
        }
        MApi_AUDIO_SIF_SetSoundMode(m_eAudioMode);
        return;
    }

    m_eAudioMode = eAudioMode;

    m_bIsAudioModeChanged = TRUE;

    MApi_AUDIO_SIF_SetSoundMode(m_eAudioMode);
}

/******************************************************************************/
/// API for Audio::
/// Change the audio mode
/// @return the value after changing
/******************************************************************************/
AUDIOMODE_TYPE msAPI_AUD_ChangeAudioMode(void)
{
    if( (m_eAudioSource != E_AUDIOSOURCE_ATV) || ((m_eAudioSource == E_AUDIOSOURCE_ATV) && (TRUE == msAPI_AVD_IsAutoAVActive(E_AUTOAV_SOURCE_ALL))) )
    {
        switch(m_eAudioMode)
        {
        case E_AUDIOMODE_LEFT_RIGHT:
            m_eAudioMode = E_AUDIOMODE_LEFT_LEFT;
            break;

        case E_AUDIOMODE_LEFT_LEFT:
            m_eAudioMode = E_AUDIOMODE_RIGHT_RIGHT;
            break;

        case E_AUDIOMODE_RIGHT_RIGHT:
            m_eAudioMode = E_AUDIOMODE_LEFT_RIGHT;
            break;

        default:
            m_eAudioMode = E_AUDIOMODE_LEFT_RIGHT;
            break;
        }

        MApi_AUDIO_SIF_SetSoundMode(m_eAudioMode);
        return m_eAudioMode;
    }

    #if (MTS_NICAM_UNSTABLE)
        g_NICAMEnable = 1;
        g_CarrierStableCnt = 0;
    #endif

    switch(m_eAudioMode)
    {
    case E_AUDIOMODE_MONO:
        m_eAudioMode = E_AUDIOMODE_FORCED_MONO;
        break;

    case E_AUDIOMODE_G_STEREO:
        m_eAudioMode = E_AUDIOMODE_FORCED_MONO;
        break;

    case E_AUDIOMODE_K_STEREO:
        m_eAudioMode = E_AUDIOMODE_FORCED_MONO;
        break;

    case E_AUDIOMODE_MONO_SAP:
        m_eAudioMode = E_AUDIOMODE_FORCED_MONO;
        break;

    case E_AUDIOMODE_STEREO_SAP:
        m_eAudioMode = E_AUDIOMODE_K_STEREO;
        break;

    case E_AUDIOMODE_DUAL_A:
        m_eAudioMode = E_AUDIOMODE_DUAL_B;
        break;

    case E_AUDIOMODE_DUAL_B:
        m_eAudioMode = E_AUDIOMODE_DUAL_AB;
        break;

    case E_AUDIOMODE_DUAL_AB:
        m_eAudioMode = E_AUDIOMODE_DUAL_A;
        break;

    case E_AUDIOMODE_NICAM_MONO:
        m_eAudioMode = E_AUDIOMODE_FORCED_MONO;
        break;

    case E_AUDIOMODE_NICAM_STEREO:
        m_eAudioMode = E_AUDIOMODE_FORCED_MONO;
        break;

    case E_AUDIOMODE_NICAM_DUAL_A:
        m_eAudioMode = E_AUDIOMODE_NICAM_DUAL_B;
        break;

    case E_AUDIOMODE_NICAM_DUAL_B:
        m_eAudioMode = E_AUDIOMODE_NICAM_DUAL_AB;
        break;

    case E_AUDIOMODE_NICAM_DUAL_AB:
        m_eAudioMode = E_AUDIOMODE_FORCED_MONO;
        break;

    case E_AUDIOMODE_FORCED_MONO:
        m_eAudioMode = (AUDIOMODE_TYPE)MApi_AUDIO_SIF_GetSoundMode();
        if( m_eAudioMode == E_AUDIOMODE_INVALID )
        {
            m_eAudioMode = E_AUDIOMODE_FORCED_MONO;
            return m_eAudioMode;
        }
        break;

    default:
        m_eAudioMode = E_AUDIOMODE_MONO;
        break;
    }
    SetAudioMute(E_AUDIO_INTERNAL_1_MUTEON, E_AUDIOMUTESOURCE_ATV);
    MApi_AUDIO_SIF_SetSoundMode(m_eAudioMode);
    msAPI_Timer_Delayms(DELAY_FOR_ENTERING_MUTE);
    SetAudioMute(E_AUDIO_INTERNAL_1_MUTEOFF, E_AUDIOMUTESOURCE_ATV);

    return m_eAudioMode;
}

/******************************************************************************/
/// API for Audio::
/// Check audio mode changed or not
/// @return true and false
/******************************************************************************/
BOOLEAN msAPI_AUD_IsAudioModeChanged(void)
{
    if ( m_bIsAudioModeChanged == FALSE )
        return FALSE;

    m_bIsAudioModeChanged = FALSE;

    return TRUE;
}

/******************************************************************************/
/// API for Audio::
/// Set/Reset the realtime audio detection
/******************************************************************************/
void msAPI_AUD_EnableRealtimeAudioDetection(BOOLEAN bEnable)
{
    if( bEnable == TRUE )
        m_bIsRealtimeAudioDetectionEnabled = TRUE;
    else
        m_bIsRealtimeAudioDetectionEnabled = FALSE;
}

/******************************************************************************/
/// API for Audio::
/// Check realtime audio detction enabled or not
/// @return true or false
/******************************************************************************/
BOOLEAN msAPI_AUD_IsEnableRealtimeAudioDetection(void)
{
    return m_bIsRealtimeAudioDetectionEnabled;
}

/******************************************************************************/
/// API for Audio::
/// Check audio standard
/******************************************************************************/
#ifndef ATSC_SYSTEM
#if(TV_SYSTEM != TV_NTSC)
static void CheckAudioStandard(void)
{
    AUDIOSTATUS eCurrentAudioStatus;
    MS_BOOL AudioStatusIsA2 = FALSE;
    MS_U8 max_a2_mode_invalid_cnt = 0x20;

    if( (m_eAudioSource != E_AUDIOSOURCE_ATV) || ((m_eAudioSource == E_AUDIOSOURCE_ATV) && (msAPI_AVD_IsAutoAVActive(E_AUTOAV_SOURCE_ALL) == TRUE)) )
        return;

    if( TRUE != MApi_AUDIO_SIF_GetAudioStatus(&eCurrentAudioStatus) )
        return;

    if( m_eAudioStatus != eCurrentAudioStatus )
    {
        m_eAudioStatus = eCurrentAudioStatus;
        msAPI_Timer_Delayms(5);

        if( TRUE != MApi_AUDIO_SIF_GetAudioStatus(&eCurrentAudioStatus) )
            return;

        if( m_eAudioStatus != eCurrentAudioStatus )     //Check twice for speed up detection, C.P.Chen 2007/12/06
        {
            m_eAudioStatus = eCurrentAudioStatus;
            return;
        }
    }

    if (g_A2ModeInvalidCnt >= max_a2_mode_invalid_cnt)
    {
        if( ((m_eAudioStatus & (E_STATE_AUDIO_PRIMARY_CARRIER|E_STATE_AUDIO_PILOT)) == (E_STATE_AUDIO_PRIMARY_CARRIER|E_STATE_AUDIO_PILOT))
           && ((m_eAudioStatus & E_STATE_AUDIO_STEREO) || (m_eAudioStatus & E_STATE_AUDIO_BILINGUAL)))
            AudioStatusIsA2 = TRUE;
    }
    else
    {
        if( (m_eAudioStatus & (E_STATE_AUDIO_PRIMARY_CARRIER|E_STATE_AUDIO_PILOT)) == (E_STATE_AUDIO_PRIMARY_CARRIER|E_STATE_AUDIO_PILOT) )
            AudioStatusIsA2 = TRUE;
    }

    #if (TV_SYSTEM == TV_PAL)

    if( m_eAudioStandard == E_AUDIOSTANDARD_L)    // need touch.
    {
        if( ((m_eAudioStatus & (E_STATE_AUDIO_PRIMARY_CARRIER|E_STATE_AUDIO_NICAM)) == (E_STATE_AUDIO_PRIMARY_CARRIER|E_STATE_AUDIO_NICAM)) ||
            ((m_eAudioStatus & E_STATE_AUDIO_PRIMARY_CARRIER) == E_STATE_AUDIO_PRIMARY_CARRIER) )
        {
            CheckATVAudioMode();
        }
        return;
    }

    if( (m_eAudioStatus & (E_STATE_AUDIO_PRIMARY_CARRIER|E_STATE_AUDIO_NICAM)) == (E_STATE_AUDIO_PRIMARY_CARRIER|E_STATE_AUDIO_NICAM) )
    {
        g_A2ModeInvalidCnt = 0;
        #if (MTS_NICAM_UNSTABLE)
        if(g_NICAMEnable == 0)
            {
            return;
            }
        #endif

        if( FALSE == MApi_AUDIO_SIF_IsPALType(AU_SIF_PAL_NICAM) )
        {
            switch(m_eAudioStandard)
            {
            case E_AUDIOSTANDARD_BG:
            case E_AUDIOSTANDARD_BG_A2:
                m_eAudioStandard = E_AUDIOSTANDARD_BG_NICAM;
                break;
            case E_AUDIOSTANDARD_DK:
            case E_AUDIOSTANDARD_DK1_A2:
                m_eAudioStandard = E_AUDIOSTANDARD_DK_NICAM;
                break;
            default:
                break;
            }
            //SetAudioMuteDuringLimitedTime(150, E_AUDIOMUTESOURCE_ACTIVESOURCE); //C.P.Chen 2007/12/06
            MApi_AUDIO_SIF_SetPALType(AU_SIF_PAL_NICAM);
            MApi_AUDIO_SIF_SetStandard(m_eAudioStandard);
            // We do not want to change audio standard of eeprom when one channel search is running or manual change.
            if( TRUE == msAPI_Tuner_IsCurrentChannelAndSavedChannelSame() )
            {
                msAPI_ATV_SetAudioStandard(msAPI_ATV_GetCurrentProgramNumber(), m_eAudioStandard);
            }
            m_wAudioDownCountTimer = (WAIT_50ms);
            return;
        }

        CheckATVAudioMode();
    }
    else if(AudioStatusIsA2 == TRUE)
    {   //Reload A2 while Pilot detected. C.P.Chen
        if( FALSE == MApi_AUDIO_SIF_IsPALType(AU_SIF_PAL_A2) )
        {
            if((m_eAudioStatus&E_STATE_AUDIO_DK2) == E_STATE_AUDIO_DK2)
                m_eAudioStandard = E_AUDIOSTANDARD_DK2_A2;
            else if((m_eAudioStatus&E_STATE_AUDIO_DK3) == E_STATE_AUDIO_DK3)
                m_eAudioStandard = E_AUDIOSTANDARD_DK3_A2;

            MApi_AUDIO_SIF_SetStandard(m_eAudioStandard);
            //SetAudioMuteDuringLimitedTime(150, E_AUDIOMUTESOURCE_ACTIVESOURCE);  //C.P.Chen 2007/12/06
            g_A2ModeInvalidCnt = 0;
            MApi_AUDIO_SIF_SetPALType(AU_SIF_PAL_A2);

            // We do not want to change audio standard of eeprom when one channel search is running or manual change.
            if( TRUE == msAPI_Tuner_IsCurrentChannelAndSavedChannelSame() )
            {
                msAPI_ATV_SetAudioStandard(msAPI_ATV_GetCurrentProgramNumber(), m_eAudioStandard);
            }
            m_wAudioDownCountTimer = (WAIT_50ms);
            return;
        }
        else if((m_eAudioStatus & (E_STATE_AUDIO_STEREO|E_STATE_AUDIO_BILINGUAL)) == 0 )
        {
            g_A2ModeInvalidCnt++;
        }
        else // STEREO or DUAL exist
        {
            g_A2ModeInvalidCnt = 0;
        }

        CheckATVAudioMode();
    }
    else if( (m_eAudioStatus & E_STATE_AUDIO_PRIMARY_CARRIER) == E_STATE_AUDIO_PRIMARY_CARRIER )
    {

        CheckATVAudioMode();

        msAPI_Tuner_UpdateMediumAndChannelNumber();

        #if (MTS_NICAM_UNSTABLE)
        if( TRUE == MApi_AUDIO_SIF_IsPALType(AU_SIF_PAL_NICAM) )
            {
            if (g_CarrierStableCnt <= 30)
                {
                g_CarrierStableCnt++;
                return;
                }
            g_CarrierStableCnt = 0;
            g_NICAMEnable = 0;
            }
        #endif

        switch(m_eAudioStandard)
        {
        case E_AUDIOSTANDARD_BG_NICAM:
            MApi_AUDIO_SIF_SetStandard(E_AUDIOSTANDARD_BG_A2);
            m_eAudioStandard = E_AUDIOSTANDARD_BG_A2;
            break;
        case E_AUDIOSTANDARD_DK_NICAM:
         case E_AUDIOSTANDARD_DK2_A2:
         case E_AUDIOSTANDARD_DK3_A2:
            MApi_AUDIO_SIF_SetStandard(E_AUDIOSTANDARD_DK1_A2);
            m_eAudioStandard = E_AUDIOSTANDARD_DK1_A2;
            break;
        default:
            break;
        }

        if( FALSE == MApi_AUDIO_SIF_IsPALType(AU_SIF_PAL_MONO) )
        {
            //SetAudioMuteDuringLimitedTime(50, E_AUDIOMUTESOURCE_ACTIVESOURCE); //C.P.Chen 2007/12/06
            MApi_AUDIO_SIF_SetPALType(AU_SIF_PAL_MONO);

            // We do not want to change audio standard of eeprom when one channel search is running or manual change.
            if( TRUE == msAPI_Tuner_IsCurrentChannelAndSavedChannelSame() )
            {
                msAPI_ATV_SetAudioStandard(msAPI_ATV_GetCurrentProgramNumber(), MApi_AUDIO_SIF_ConvertToBasicAudioStandard(m_eAudioStandard));
            }
        }
    }
#endif
}
#endif
#endif

/******************************************************************************/
/// API for Audio::
/// Check ATV audio mode
/******************************************************************************/
#ifndef ATSC_SYSTEM
#if (TV_SYSTEM == TV_PAL)
static void CheckATVAudioMode(void)
{
    AUDIOMODE_TYPE eDetectedAudioMode;
    EN_DUAL_AUDIO_SELECTION eSaveAudioMode;

#if (ENABLE_SBTVD_BRAZIL_APP)
    eDetectedAudioMode = E_AUDIOMODE_INVALID;
    return; //just for remove make warning
#endif

    if( TRUE == MApi_AUDIO_SIF_IsPALType(AU_SIF_PAL_MONO) )
        {
        eDetectedAudioMode = E_AUDIOMODE_MONO;
        }
    else
        {
        eDetectedAudioMode = (AUDIOMODE_TYPE)MApi_AUDIO_SIF_GetSoundMode();
        }

    if( eDetectedAudioMode == E_AUDIOMODE_INVALID )
        return;

    if( m_eAudioMode == eDetectedAudioMode )
        {
        MApi_AUDIO_SIF_SetSoundMode(m_eAudioMode);
        return;
        }

    if( ((m_eAudioMode == E_AUDIOMODE_DUAL_A) || (m_eAudioMode == E_AUDIOMODE_DUAL_B) || (m_eAudioMode == E_AUDIOMODE_DUAL_AB)) &&
        ((eDetectedAudioMode == E_AUDIOMODE_DUAL_A) || (eDetectedAudioMode == E_AUDIOMODE_DUAL_B) || (eDetectedAudioMode == E_AUDIOMODE_DUAL_AB)) )
    {
        MApi_AUDIO_SIF_SetSoundMode(m_eAudioMode);
        return;
    }

    if( ((m_eAudioMode == E_AUDIOMODE_NICAM_DUAL_A) || (m_eAudioMode == E_AUDIOMODE_NICAM_DUAL_B) || (m_eAudioMode == E_AUDIOMODE_NICAM_DUAL_AB)) &&
        ((eDetectedAudioMode == E_AUDIOMODE_NICAM_DUAL_A) || (eDetectedAudioMode == E_AUDIOMODE_NICAM_DUAL_B) || (eDetectedAudioMode == E_AUDIOMODE_NICAM_DUAL_AB)) )
    {
        MApi_AUDIO_SIF_SetSoundMode(m_eAudioMode);
        return;
    }

    if( m_eAudioMode == E_AUDIOMODE_FORCED_MONO && eDetectedAudioMode != E_AUDIOMODE_DUAL_A )
    {
        MApi_AUDIO_SIF_SetSoundMode(m_eAudioMode);
        return;
    }

    if( (eDetectedAudioMode == E_AUDIOMODE_DUAL_A) || (eDetectedAudioMode == E_AUDIOMODE_NICAM_DUAL_A) )
    {
        eSaveAudioMode = (EN_DUAL_AUDIO_SELECTION)msAPI_ATV_GetDualAudioSelected();
        if(eSaveAudioMode == E_DUAL_AUDIO_A)
        {
            eDetectedAudioMode = (eDetectedAudioMode == E_AUDIOMODE_DUAL_A) ? E_AUDIOMODE_DUAL_A : E_AUDIOMODE_NICAM_DUAL_A;
        }
        else if(eSaveAudioMode == E_DUAL_AUDIO_B)
        {
            eDetectedAudioMode = (eDetectedAudioMode == E_AUDIOMODE_DUAL_A) ? E_AUDIOMODE_DUAL_B : E_AUDIOMODE_NICAM_DUAL_B;
        }
        else //E_DUAL_AUDIO_AB
        {
            eDetectedAudioMode = (eDetectedAudioMode == E_AUDIOMODE_DUAL_A) ? E_AUDIOMODE_DUAL_AB : E_AUDIOMODE_NICAM_DUAL_AB;
        }
    }
    if( TRUE == msAPI_Tuner_IsCurrentChannelAndSavedChannelSame() )
    {
        msAPI_ATV_SetAudioMode(E_AUDIOSOURCE_ATV, eDetectedAudioMode);
    }
    m_eAudioMode = eDetectedAudioMode;

    m_bIsAudioModeChanged = TRUE;

    MApi_AUDIO_SIF_SetSoundMode(m_eAudioMode);
}
#endif
#endif

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
///
///         AUDIO_HDMI RELATIONAL API FUNCTION
///
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

//*************************************************************************
//Function name:    msAPI_AUD_HDMI_SetNonpcm
//  [doxygen]
/// This function setting HDMI non-PCM or PCM relational register
//*************************************************************************
void msAPI_AUD_HDMI_SetNonpcm(BYTE nonPCM_en)
{
    WORD time_cnt;
    if (nonPCM_en)
    {
        MApi_AUDIO_SetCommand( (En_DVB_decCmdType)MSAPI_AUD_STOP );
        MApi_AUDIO_SetSystem( MSAPI_AUD_DVB2_AC3 );
        //msAPI_AUD_SwitchAduioDSPSystem(E_AUDIO_DSP_AC3_AD);
        //printf("API-nonPCM\r\n");
        MDrv_AUDIO_SetNormalPath(AUDIO_PATH_MAIN_SPEAKER, AUDIO_DSP2_DVB_INPUT, AUDIO_OUTPUT_MAIN_SPEAKER);
        MDrv_AUDIO_SetNormalPath(AUDIO_PATH_LINEOUT, AUDIO_DSP2_DVB_INPUT, AUDIO_OUTPUT_LINEOUT);
        #if ENABLE_CUS_HEADPHONE_SPEC
        MDrv_AUDIO_SetNormalPath(AUDIO_PATH_HP, AUDIO_DSP2_DVB_INPUT, AUDIO_OUTPUT_HP);
        #endif
        MDrv_AUDIO_HDMI_SetNonpcm(TRUE);

        for (time_cnt=0; time_cnt< 800; time_cnt++)
        {
            msAPI_Timer_Delayms(1);
        }
        if (MDrv_AUDIO_HDMI_DolbyMonitor() == 1)
        {   // Dolby mod
            //printf("API non-PCM Dolby mod\r\n");
            MApi_AUDIO_SPDIF_SetMode(MSAPI_AUD_SPDIF_NONPCM);
            MApi_AUDIO_SetCommand((En_DVB_decCmdType) MSAPI_AUD_PLAY );
        }
        else
        {   // Other mod (ie DTS ...)
            //printf("API non-PCM DTS mod\r\n");
            MApi_AUDIO_SPDIF_SetMode(MSAPI_AUD_SPDIF_NONPCM);
            MApi_AUDIO_SetCommand( (En_DVB_decCmdType)MSAPI_AUD_STOP );
        }
    }
    else
    {
        //printf("API-PCM\r\n");
        MDrv_AUDIO_HDMI_SetNonpcm(FALSE);
        MDrv_AUDIO_SetNormalPath(AUDIO_PATH_MAIN_SPEAKER, AUDIO_HDMI_INPUT, AUDIO_OUTPUT_MAIN_SPEAKER);
        MDrv_AUDIO_SetNormalPath(AUDIO_PATH_LINEOUT, AUDIO_HDMI_INPUT, AUDIO_OUTPUT_LINEOUT);
        #if ENABLE_CUS_HEADPHONE_SPEC
        MDrv_AUDIO_SetNormalPath(AUDIO_PATH_HP, AUDIO_HDMI_INPUT, AUDIO_OUTPUT_HP);
        #endif
        MApi_AUDIO_SetCommand( (En_DVB_decCmdType)MSAPI_AUD_STOP );
        MApi_AUDIO_SPDIF_SetMode(MSAPI_AUD_SPDIF_PCM);
    }
}

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
///
///         AUDIO_SPDIF RELATIONAL API FUNCTION
///
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//*************************************************************************
//Function name:    msAPI_AUD_SPDIF_SetSCMS
//  [doxygen]
/// This routine Set SPDIF SCMS.
/// @param input_src \b IN
///      SPDIF SCMS, C_bit_en : copy right control bit
///                             register in 0x2C80[5]
///                            0 : Copy Right
///                            1 : non-Copy Right
///                  L_bit_en : generation bit
///                            register in 0x2C82[0]
///                            0 : L-bit disable
///                            1 : L-bit enable
//*************************************************************************
void msAPI_AUD_SPDIF_SetSCMS(MS_U8 C_bit_en, MS_U8 L_bit_en)
{
#if 0 // CI+ Cert set 0
    MS_U8 C_bit_en_tmp, L_bit_en_tmp;

    C_bit_en_tmp = C_bit_en;
    L_bit_en_tmp = L_bit_en;
#endif

#if 1  // CI+ Cert set 1
    MApi_AUDIO_SPDIF_SetSCMS(C_bit_en, L_bit_en);
#endif

}

//*************************************************************************
//Function name:    msAPI_AUD_SPDIF_GetSCMS
//  [doxygen]
/// This routine Get SPDIF SCMS.
/// @return BYTE:apiaud
///     SCMS[0] = C bit status
///     SCMS[1] = L bit status
//*************************************************************************
MS_U8 msAPI_AUD_SPDIF_GetSCMS(void)
{
#if 0 // CI+ Cert set 0
    return(0);
#endif
#if 1 // CI+ Cert set 1
    return(MApi_AUDIO_SPDIF_GetSCMS());
#endif
}



////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
///
///         AUDIO_SOUND RELATIONAL API FUNCTION
///
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

//=========================================================
//******************************************************************************
//  [Function Name]:
//      msAPI_AUD_SetAudioSource
//  [Description]:
//      re-load the audio decoder here
//  [Arguments]:
//*******************************************************************************
void msAPI_AUD_SetAudioSource(AUDIOSOURCE_TYPE eSource)
{
 //=====================================================================
 // Just re-load the audio decoder here.
 //=====================================================================
    switch(eSource)
    {
    case E_AUDIOSOURCE_MPEG:
        msAPI_AUD_SwitchAduioDSPSystem(E_AUDIO_DSP_MPEG);
            break;

    case E_AUDIOSOURCE_AC3:
        msAPI_AUD_SwitchAduioDSPSystem(E_AUDIO_DSP_AC3);
            break;

    case E_AUDIOSOURCE_ATV:
        msAPI_AUD_SwitchAduioDSPSystem(E_AUDIO_DSP_SIF);
            break;

    case E_AUDIOSOURCE_HDMI:
    case E_AUDIOSOURCE_HDMI2:
    case E_AUDIOSOURCE_HDMI3:
        msAPI_AUD_SwitchAduioDSPSystem(E_AUDIO_DSP_AC3);
        break;

        default:
        msAPI_AUD_SwitchAduioDSPSystem(E_AUDIO_DSP_SIF);
            break;
    }
}


//=============================================================
// AUDIO_Miscellany FUNCTION
//=============================================================
void msAPI_AUD_I2S_Amp_Reset(void)
{
    //Dont remove it, prepare for furture
#if (DIGITAL_I2S_SELECT != AUDIO_I2S_NONE)
    drvAudio_AMP_Init();
#endif
}

void msAPI_AUD_I2S_Amp_UnReset(void)
{
    //Dont remove it, prepare for furture
}

void msAPI_AUD_SW_Reset(void)
{
    //Dont remove it, prepare for furture
}

//=============================================================
// AUDIO MW functions
//=============================================================

////////////////////////////////////////////////////////////////////////////////
/// @brief \b Function \b Name: MW_AUD_AudioProcessor()
/// @brief \b Function \b Description: Audio handler
/// @param <IN>        \b NONE    :
/// @param <OUT>       \b NONE    :
/// @param <RET>       \b  NONE    :
/// @param <GLOBAL>    \b NONE    :
////////////////////////////////////////////////////////////////////////////////
void MW_AUD_AudioProcessor(void)
{
    if( m_eAudioSource != E_AUDIOSOURCE_ATV &&
        m_eAudioSource != E_AUDIOSOURCE_CVBS1 &&
        m_eAudioSource != E_AUDIOSOURCE_CVBS2 &&
        m_eAudioSource != E_AUDIOSOURCE_SVIDEO1 &&
        m_eAudioSource != E_AUDIOSOURCE_SVIDEO2 &&
        m_eAudioSource != E_AUDIOSOURCE_SCART1 &&
        m_eAudioSource != E_AUDIOSOURCE_SCART2 )
    {
        return;
    }

    msAPI_AUD_CheckExpirationOfAudioMute();

       // Check the tuning module

#if(TV_SYSTEM != TV_NTSC)
    if ( msAPI_Tuner_IsTuningProcessorBusy() == TRUE )
    {
        return;
    }
#endif

    if(m_wAudioDownCountTimer > WAIT_0ms)
    {
        m_wAudioDownCountTimer--;
        return;
    }

    m_wAudioDownCountTimer = WAIT_50ms;

    if(m_bBySyncAudioMute== FALSE && IsVDHasSignal()==TRUE )
    {
    #if(ENABLE_AUDIO_AUTO_DETECT)
      #if(TV_SYSTEM != TV_NTSC)
        CheckAudioStandard();
   // #else
   //      CheckATVAudioMode();
      #endif
    #endif//(ENABLE_AUDIO_AUTO_DETECT)
    }
    else if( (m_bBySyncAudioMute == TRUE) &&
            (IsVDHasSignal() == TRUE) )
    {
        msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_BYSYNC_MUTEOFF, E_AUDIOMUTESOURCE_ACTIVESOURCE);
    }
    else if( (m_bBySyncAudioMute == FALSE) &&
             (IsVDHasSignal()  == FALSE) )
    {
        msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_BYSYNC_MUTEON, E_AUDIOMUTESOURCE_ACTIVESOURCE);
    }
}

////////////////////////////////////////////////////////////////////////////////
/// @brief \b Function \b Name: MW_AUD_GetBinAddress()
/// @brief \b Function \b Description: Get audio bin file
/// @param <IN>        \b NONE    :
/// @param <OUT>       \b NONE    :
/// @param <RET>       \b  NONE    :
/// @param <GLOBAL>    \b NONE    :
////////////////////////////////////////////////////////////////////////////////
void MW_AUD_GetBinAddress(void)
{

#if defined (MSOS_TYPE_ECOS) || defined (MSOS_TYPE_LINUX)
//==============For OS======================
// In OS mode ,Audio dsp code is in  .c  file
    MDrv_AUDIO_SetDspBaseAddr(DSP_DEC, 0 , ((MAD_DEC_BUFFER_MEMORY_TYPE & MIU1) ? (MAD_DEC_BUFFER_ADR | MIU_INTERVAL) : (MAD_DEC_BUFFER_ADR)));
    MDrv_AUDIO_SetDspBaseAddr(DSP_SE, 0 , ((MAD_BASE_BUFFER_MEMORY_TYPE & MIU1) ? (MAD_SE_BUFFER_ADR | MIU_INTERVAL) : (MAD_SE_BUFFER_ADR)));

#else
//==============For NOS=====================
    BININFO BinInfo;
    BOOLEAN bResult;

    // main system
    /* check audio dspcode binary in flash */
#if 0//def NON_COMPRESS_AUDIO_DSP
    BinInfo.B_ID = BIN_ID_CODE_DEC_AUDIO_UZIP;
#else
  #if ( COMPRESS_BIN_AUDIO_DEC )
    BinInfo.B_ID = BIN_ID_CODE_DEC_AUDIO_COMP;
  #else
    BinInfo.B_ID = BIN_ID_CODE_DEC_AUDIO;
  #endif
#endif

    msAPI_MIU_Get_BinInfo(&BinInfo, &bResult);
    if (bResult  != PASS )
    {
        printf("Audio: could not find Audio dec binary on flash.\n", 0);
        return;
    }

    MDrv_AUDIO_SetDspBaseAddr(DSP_DEC, BinInfo.B_FAddr, ((MAD_DEC_BUFFER_MEMORY_TYPE & MIU1) ? (MAD_DEC_BUFFER_ADR | MIU_INTERVAL) : (MAD_DEC_BUFFER_ADR)));


    //20091229EL
    if (SUCCESS == MDrv_DMA_LoadBin(&BinInfo, _PA2VA((MAD_DSP_DEC_BUFFER_ADR & MIU1) ? (MAD_DSP_DEC_BUFFER_ADR | MIU_INTERVAL) : (MAD_DSP_DEC_BUFFER_ADR)),
        _PA2VA(((POOL_BUFFER_ADR+ BUF_FOR_DECOMPRESS_OFFSET1) & MIU1) ? ((POOL_BUFFER_ADR+ BUF_FOR_DECOMPRESS_OFFSET1) | MIU_INTERVAL) : (POOL_BUFFER_ADR+ BUF_FOR_DECOMPRESS_OFFSET1)),
        _PA2VA(((POOL_BUFFER_ADR+ BUF_FOR_DECOMPRESS_OFFSET2) & MIU1) ? ((POOL_BUFFER_ADR+ BUF_FOR_DECOMPRESS_OFFSET2) | MIU_INTERVAL) : (POOL_BUFFER_ADR+ BUF_FOR_DECOMPRESS_OFFSET2))))
    {
        switch(BinInfo.B_IsComp)
        {
        case LZSS_COMPRESS:
        case MS_COMPRESS:
        case MS_COMPRESS7:
            //printf("~~~  BIN_ID_CODE_DEC_AUDIO \n");
            //printf("~~~1 BinInfo.B_Len = %ld\n", BinInfo.B_Len);
            //printf("~~~2 MAD_DSP_DEC_BUFFER_LEN = %ld\n",MAD_DSP_DEC_BUFFER_LEN);

            if(BinInfo.B_Len > MAD_DSP_DEC_BUFFER_LEN)
            {
                MS_DEBUG_MSG(printf("ASSERT!!! BinInfo.B_Len > MAD_DSP_DEC_BUFFER_LEN\n"));
                ASSERT(0);
            }

            MApi_AUDIO_SetCommAudioInfo(Audio_Comm_infoType_CompressBin_LoadCode, BinInfo.B_IsComp, 0);
            MApi_AUDIO_SetCommAudioInfo(Audio_Comm_infoType_CompressBin_DDRAddress, DSP_DEC, (MAD_DSP_DEC_BUFFER_ADR & MIU1) ? (MAD_DSP_DEC_BUFFER_ADR | MIU_INTERVAL) : (MAD_DSP_DEC_BUFFER_ADR));
            break;
        default:
            MApi_AUDIO_SetCommAudioInfo(Audio_Comm_infoType_CompressBin_LoadCode, FALSE, 0);
            break;
        }

    }
    else
    {
        MS_DEBUG_MSG(printf("ERROR!![%s]%d\n",__FILE__,__LINE__));
        return;
    }


#if 0//(CHIP_FAMILY_TYPE != CHIP_FAMILY_S7J) && (CHIP_FAMILY_TYPE != CHIP_FAMILY_M10) && (CHIP_FAMILY_TYPE != CHIP_FAMILY_M12)
    /* check audio dspcode binary in flash */
 #ifdef NON_COMPRESS_AUDIO_DSP
    BinInfo.B_ID = BIN_ID_CODE_SE_AUDIO_UZIP;
 #else
    BinInfo.B_ID = BIN_ID_CODE_SE_AUDIO;
 #endif
     msAPI_MIU_Get_BinInfo(&BinInfo, &bResult);
    if ( bResult != PASS )
    {
        debugASPPrint("Audio: could not find Audio se binary on flash.\n", 0);
        return;
    }
    /* Set audio binary address in flash */
    //MDrv_AudioSetBaseAddress(BinInfo.B_FAddr, MAD_BASE_BUFFER_ADR);

    MDrv_AUDIO_SetDspBaseAddr(DSP_SE, BinInfo.B_FAddr, ((MAD_BASE_BUFFER_MEMORY_TYPE & MIU1) ? (MAD_SE_BUFFER_ADR | MIU_INTERVAL) : (MAD_SE_BUFFER_ADR)));



    //20091229EL
  #if (CHIP_FAMILY_TYPE == CHIP_FAMILY_S8) // T8 dont decompress bin
  #else
    if (SUCCESS == MDrv_DMA_LoadBin(&BinInfo, _PA2VA((MAD_DSP_SE_BUFFER_ADR & MIU1) ? (MAD_DSP_SE_BUFFER_ADR | MIU_INTERVAL) : (MAD_DSP_SE_BUFFER_ADR)),
        _PA2VA(((POOL_BUFFER_ADR+ BUF_FOR_DECOMPRESS_OFFSET1) & MIU1) ? ((POOL_BUFFER_ADR+ BUF_FOR_DECOMPRESS_OFFSET1) | MIU_INTERVAL) : (POOL_BUFFER_ADR+ BUF_FOR_DECOMPRESS_OFFSET1)),
        _PA2VA(((POOL_BUFFER_ADR+ BUF_FOR_DECOMPRESS_OFFSET2) & MIU1) ? ((POOL_BUFFER_ADR+ BUF_FOR_DECOMPRESS_OFFSET2) | MIU_INTERVAL) : (POOL_BUFFER_ADR+ BUF_FOR_DECOMPRESS_OFFSET2))  ))
    {
        switch(BinInfo.B_IsComp)
        {
        case LZSS_COMPRESS:
        case MS_COMPRESS:
        case MS_COMPRESS7:
            //printf("~~~  BIN_ID_CODE_SE_AUDIO \n");
            //printf("~~~1 BinInfo.B_Len = %ld\n", BinInfo.B_Len);
            //printf("~~~2 MAD_DSP_SE_BUFFER_LEN = %ld\n",MAD_DSP_SE_BUFFER_LEN);

            if(BinInfo.B_Len > MAD_DSP_SE_BUFFER_LEN)
            {
                MS_DEBUG_MSG(printf("ASSERT!!! BinInfo.B_Len > MAD_DSP_SE_BUFFER_LEN\n"));
                ASSERT(0);
            }

            MApi_AUDIO_SetCommAudioInfo(Audio_Comm_infoType_CompressBin_LoadCode, BinInfo.B_IsComp, 0);
            MApi_AUDIO_SetCommAudioInfo(Audio_Comm_infoType_CompressBin_DDRAddress, DSP_SE, MAD_DSP_SE_BUFFER_ADR);
            break;
        default:
            MApi_AUDIO_SetCommAudioInfo(Audio_Comm_infoType_CompressBin_LoadCode, FALSE, 0);
            break;
        }
    }
    else
    {
        MS_DEBUG_MSG(printf("ERROR!![%s]%d\n",__FILE__,__LINE__));
        return;
    }
  #endif
#endif


#if ( CHIP_FAMILY_TYPE == CHIP_FAMILY_S7J   \
   || CHIP_FAMILY_TYPE == CHIP_FAMILY_S7LD  \
    || CHIP_FAMILY_TYPE == CHIP_FAMILY_M10  \
   || CHIP_FAMILY_TYPE == CHIP_FAMILY_M12)
    /* check audio dspcode binary in flash */
 #if 0//def NON_COMPRESS_AUDIO_DSP
    BinInfo.B_ID = BIN_ID_CODE_ADVSND_AUDIO_UZIP;
 #else
   #if ( COMPRESS_BIN_AUDIO_DEC )
    BinInfo.B_ID = BIN_ID_CODE_ADVSND_AUDIO_COMP;
   #else
    BinInfo.B_ID = BIN_ID_CODE_ADVSND_AUDIO;
   #endif
 #endif

    msAPI_MIU_Get_BinInfo(&BinInfo, &bResult);
    if ( bResult != PASS )
    {
        debugASPPrint("Audio: could not find Audio adv snd binary on flash.\n", 0);
        return;
    }

    /* Set audio binary address in flash */
    MApi_AUDIO_AseSetBinAddress(0, BinInfo.B_FAddr);  /* always set to 0 */

    if (SUCCESS == MDrv_DMA_LoadBin(&BinInfo, _PA2VA((MAD_DSP_ADV_BUFFER_ADR & MIU1) ? (MAD_DSP_ADV_BUFFER_ADR | MIU_INTERVAL) : (MAD_DSP_ADV_BUFFER_ADR)),
                                              _PA2VA(((POOL_BUFFER_ADR + BUF_FOR_DECOMPRESS_OFFSET1) & MIU1) ? ((POOL_BUFFER_ADR+ BUF_FOR_DECOMPRESS_OFFSET1) | MIU_INTERVAL) : (POOL_BUFFER_ADR+ BUF_FOR_DECOMPRESS_OFFSET1)),
                                              _PA2VA(((POOL_BUFFER_ADR + BUF_FOR_DECOMPRESS_OFFSET2) & MIU1) ? ((POOL_BUFFER_ADR+ BUF_FOR_DECOMPRESS_OFFSET2) | MIU_INTERVAL) : (POOL_BUFFER_ADR+ BUF_FOR_DECOMPRESS_OFFSET2)) ))
    {
        switch(BinInfo.B_IsComp)
        {
        case LZSS_COMPRESS:
        case MS_COMPRESS:
        case MS_COMPRESS7:
            //printf("~~~  BIN_ID_CODE_SE_AUDIO \n");
            //printf("~~~1 BinInfo.B_Len = %ld\n", BinInfo.B_Len);
            //printf("~~~2 MAD_DSP_ADV_BUFFER_LEN = %ld\n",MAD_DSP_ADV_BUFFER_LEN);

            if(BinInfo.B_Len > MAD_DSP_ADV_BUFFER_LEN)
            {
                MS_DEBUG_MSG(printf("ASSERT!!! BinInfo.B_Len > MAD_DSP_ADV_BUFFER_LEN\n"));
                ASSERT(0);
            }

            MApi_AUDIO_SetCommAudioInfo(Audio_Comm_infoType_CompressBin_LoadCode, BinInfo.B_IsComp, 0);
            MApi_AUDIO_SetCommAudioInfo(Audio_Comm_infoType_CompressBin_DDRAddress, DSP_ADV, MAD_DSP_ADV_BUFFER_ADR);
            break;
        default:
            MApi_AUDIO_SetCommAudioInfo(Audio_Comm_infoType_CompressBin_LoadCode, FALSE, 0);
            break;
        }
    }
    else
    {
        MS_DEBUG_MSG(printf("ERROR!![%s]%d\n",__FILE__,__LINE__));
        return;
    }

#else

  #if (CHIP_FAMILY_TYPE == CHIP_FAMILY_S8)  // T8 dont decompress adv snd eff
    #elif (CHIP_FAMILY_TYPE == CHIP_FAMILY_A7)
    // SRS
    BinInfo.B_ID = BIN_ID_CODE_AUDIO_SRS;
    msAPI_MIU_Get_BinInfo(&BinInfo, &bResult);
    if ( bResult != PASS )
    {
        debugASPPrint("Audio: could not find Audio SRS binary on flash.\r\n", 0);
        return;
    }
    MApi_AUDIO_AseSetBinAddress(MSAPI_AUD_ADVSND_SRS, BinInfo.B_FAddr);

    // TSHD
    BinInfo.B_ID = BIN_ID_CODE_AUDIO_TSHD;
    msAPI_MIU_Get_BinInfo(&BinInfo, &bResult);
    if ( bResult != PASS )
    {
        debugASPPrint("Audio: could not find Audio TSHD binary on flash.\r\n", 0);
        return;
    }
    MApi_AUDIO_AseSetBinAddress(MSAPI_AUD_ADVSND_TSHD, BinInfo.B_FAddr);
  #else
    // BBE
    BinInfo.B_ID = BIN_ID_CODE_AUDIO_BBE;

    msAPI_MIU_Get_BinInfo(&BinInfo, &bResult);
    if ( bResult != PASS )
    {
        debugASPPrint("Audio: could not find Audio BBE binary on flash.\r\n, 0", 0);
        return;
    }
    MApi_AUDIO_AseSetBinAddress(MSAPI_AUD_ADVSND_BBE, BinInfo.B_FAddr);

    // SRS
    BinInfo.B_ID = BIN_ID_CODE_AUDIO_SRS;

    msAPI_MIU_Get_BinInfo(&BinInfo, &bResult);
    if ( bResult != PASS )
    {
        debugASPPrint("Audio: could not find Audio SRS binary on flash.\r\n", 0);
        return;
    }
    MApi_AUDIO_AseSetBinAddress(MSAPI_AUD_ADVSND_SRS, BinInfo.B_FAddr);

    // VDS
    BinInfo.B_ID = BIN_ID_CODE_AUDIO_VDS;
      msAPI_MIU_Get_BinInfo(&BinInfo, &bResult);
    if ( bResult != PASS )
    {
        debugASPPrint("Audio: could not find Audio VDS binary on flash.\r\n", 0);
        return;
    }
    MApi_AUDIO_AseSetBinAddress(MSAPI_AUD_ADVSND_VDS, BinInfo.B_FAddr);

    // VSPK
    BinInfo.B_ID = BIN_ID_CODE_AUDIO_VSPK;
     msAPI_MIU_Get_BinInfo(&BinInfo, &bResult);
    if ( bResult != PASS )
    {
        debugASPPrint("Audio: could not find Audio VSPK binary on flash.\r\n", 0);
        return;
    }
    MApi_AUDIO_AseSetBinAddress(MSAPI_AUD_ADVSND_VSPK, BinInfo.B_FAddr);


    // SUPV
    BinInfo.B_ID = BIN_ID_CODE_AUDIO_SUPV;
     msAPI_MIU_Get_BinInfo(&BinInfo, &bResult);
    if ( bResult != PASS )
    {
        debugASPPrint("Audio: could not find Audio SuperVoice binary on flash.\r\n", 0);
        return;
    }
    MApi_AUDIO_AseSetBinAddress(MSAPI_AUD_ADVSND_SUPV, BinInfo.B_FAddr);

    // TSHD
    BinInfo.B_ID = BIN_ID_CODE_AUDIO_TSHD;
      msAPI_MIU_Get_BinInfo(&BinInfo, &bResult);
    if ( bResult != PASS )
    {
        debugASPPrint("Audio: could not find Audio TSHD binary on flash.\r\n", 0);
        return;
    }
    MApi_AUDIO_AseSetBinAddress(MSAPI_AUD_ADVSND_TSHD, BinInfo.B_FAddr);


    // XEN
    BinInfo.B_ID = BIN_ID_CODE_AUDIO_XEN;
     msAPI_MIU_Get_BinInfo(&BinInfo, &bResult);
    if ( bResult != PASS )
    {
        debugASPPrint("Audio: could not find Audio XEN binary on flash.\r\n", 0);
        return;
    }
    MApi_AUDIO_AseSetBinAddress(MSAPI_AUD_ADVSND_XEN, BinInfo.B_FAddr);
  #endif
#endif

#endif // #if defined (MSOS_TYPE_ECOS) || defined (MSOS_TYPE_LINUX)
}

////////////////////////////////////////////////////////////////////////////////
/// @brief \b Function \b Name: MApi_AUDIO_SetNormalPath()
/// @brief \b Function \b Description: This routine is used to set the topalogy for Audio Input .
/// @param <IN>        \b path    : Audio DSP channel
/// @param <IN>        \b input    : Audio input type
/// @param <IN>        \b output: Audio output type
/// @param <OUT>       \b NONE    :
/// @param <RET>       \b NONE    :
/// @param <GLOBAL>    \b NONE    :
////////////////////////////////////////////////////////////////////////////////
void MApi_AUDIO_SetNormalPath(AUDIO_PATH_TYPE path, AUDIO_INPUT_TYPE input, AUDIO_OUTPUT_TYPE output)
{
    MDrv_AUDIO_SetNormalPath(path, input, output);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief \b Function \b Name: MW_AUD_SetSoundMute()
/// @brief \b Function \b Description: This routine is used to set all kind of audio  .
/// @param <IN>        \b eSoundMuteSource    : mute source type
/// @param <IN>        \b eOnOff    : mute or unmute
/// @param <OUT>       \b NONE    :
/// @param <RET>       \b NONE    :
/// @param <GLOBAL>    \b NONE    :
////////////////////////////////////////////////////////////////////////////////
void MW_AUD_SetSoundMute(SOUND_MUTE_SOURCE eSoundMuteSource, SOUND_MUTE_TYPE eOnOff)
{
    switch(eSoundMuteSource)
    {
        case SOUND_MUTE_TV:
         #if((CHIP_FAMILY_TYPE != CHIP_FAMILY_S7 ) && (CHIP_FAMILY_TYPE != CHIP_FAMILY_S8 ))
            if (AUDIO_OUTPUT_MAIN_SPEAKER != AUDIO_I2S_OUTPUT )
                MApi_AUDIO_SetMute(AUDIO_PATH_0, eOnOff); // Mute CH1 for CH5->SRC->CH1 case
         #endif
            MApi_AUDIO_SetMute(AUDIO_PATH_MAIN_SPEAKER, eOnOff);
         #if ENABLE_CUS_HEADPHONE_SPEC
            MApi_AUDIO_SetMute(AUDIO_PATH_HP, eOnOff); // disable mute AV out
         #endif
            break;

        case SOUND_MUTE_SPEAKER:
         #if((CHIP_FAMILY_TYPE != CHIP_FAMILY_S7 ) && (CHIP_FAMILY_TYPE != CHIP_FAMILY_S8 ))
            if (AUDIO_OUTPUT_MAIN_SPEAKER != AUDIO_I2S_OUTPUT )
                MApi_AUDIO_SetMute(AUDIO_PATH_0, eOnOff);   // Mute CH1 for CH5->SRC->CH1 case
         #endif
            MApi_AUDIO_SetMute(AUDIO_PATH_MAIN_SPEAKER, eOnOff);
            break;

        case SOUND_MUTE_HP:
            MApi_AUDIO_SetMute(AUDIO_PATH_HP, eOnOff);
            break;

        case SOUND_MUTE_SCART:
            MApi_AUDIO_SetMute(AUDIO_PATH_SIFOUT, eOnOff);
            break;

        case SOUND_MUTE_MONITOR_OUT:
        case SOUND_MUTE_SCART2:
            MApi_AUDIO_SetMute(AUDIO_PATH_LINEOUT, eOnOff);
            break;

        case SOUND_MUTE_SPDIF:
            MApi_AUDIO_SetMute(AUDIO_PATH_SPDIF, eOnOff);
            break;

        case SOUND_MUTE_ALL_EXCEPT_SCART:
         #if(0)// ((CHIP_FAMILY_TYPE != CHIP_FAMILY_S7 )&& (CHIP_FAMILY_TYPE != CHIP_FAMILY_S8 ))
            if (AUDIO_OUTPUT_MAIN_SPEAKER != AUDIO_I2S_OUTPUT )
                MApi_AUDIO_SetMute(AUDIO_PATH_0, eOnOff);   // Mute CH1 for CH5->SRC->CH1 case
         #endif
            MApi_AUDIO_SetMute(AUDIO_PATH_MAIN_SPEAKER, eOnOff);
            MApi_AUDIO_SetMute(AUDIO_PATH_HP, eOnOff);
            MApi_AUDIO_SetMute(AUDIO_PATH_LINEOUT, eOnOff);
            MApi_AUDIO_SetMute(AUDIO_PATH_SPDIF, eOnOff);
            break;

        case SOUND_MUTE_ALL:
         #if(0)// ((CHIP_FAMILY_TYPE != CHIP_FAMILY_S7 )&& (CHIP_FAMILY_TYPE != CHIP_FAMILY_S8 ))
            if (AUDIO_OUTPUT_MAIN_SPEAKER != AUDIO_I2S_OUTPUT )
                MApi_AUDIO_SetMute(AUDIO_PATH_0, eOnOff);   // Mute CH1 for CH5->SRC->CH1 case
         #endif
            MApi_AUDIO_SetMute(AUDIO_PATH_MAIN_SPEAKER, eOnOff);
            MApi_AUDIO_SetMute(AUDIO_PATH_HP, eOnOff);
            MApi_AUDIO_SetMute(AUDIO_PATH_LINEOUT, eOnOff);
            MApi_AUDIO_SetMute(AUDIO_PATH_SIFOUT, eOnOff);
            MApi_AUDIO_SetMute(AUDIO_PATH_SPDIF, eOnOff);
            break;

        case SOUND_MUTE_AMP:
            break;

        default:
            break;
    }
}

////////////////////////////////////////////////////////////////////////////////
/// @brief \b Function \b Description: This routine is used to set PEQ Coefficient.
/// @param <IN>        \b Band  : 0~4
///                                  \b Gain
///                                  \b Fo
///                                  \QValue
///                                  \sfs     : sampling frequency
/// @param <OUT>       \b NONE  :
/// @param <RET>       \b  NONE :
/// @param <GLOBAL>    \b NONE
////////////////////////////////////////////////////////////////////////////////
void msAPI_AUD_SetPEQ(MS_U8 Band, MS_U8 Gain, MS_U8 Foh, MS_U8 Fol, MS_U8 QValue)
{
    float coef;
    float v0,dem;
    float G,fc,Q;

    float k;
    float kpow2;
    AUDIO_PEQ_COEF PEQCoef;

    if(QValue == 0) QValue = 1;
    if(Foh == 0 && Fol == 0) Fol = 10;

    //MS_U32 pa0,pa1,pa2,pb1,pb2;
    //MS_U16 dsp_addr;
    //MS_U8 sfs;
    PEQCoef.band = Band;
    fc = (float)(((int)Foh)*100+(int)Fol);

    for(PEQCoef.sfs=0; PEQCoef.sfs<=1; PEQCoef.sfs++)
    {
        if(PEQCoef.sfs)
        {
            AUD_DEBUG(printf("48k: %x\r\n",1));
            k = tan((3.1415926*fc)/48000);
        }
        else
        {
            AUD_DEBUG(printf("32k: %x\r\n",0));
            k = tan((3.1415926*fc)/32000);
        }

        Q = ((float)QValue)/10;

        if(Gain >= 120)
        {
            G = ((float)(Gain-120))/10;
        }
        else
        {
            G = ((float)(120-Gain))/10;
        }

        fc = (float)(((int)Foh)*100+(int)Fol);

        kpow2 = k*k;
        if(Gain >= 120)
        {
            AUD_DEBUG(printf("+ G: %d\r\n",(int)G));
        }
        else
        {
            AUD_DEBUG(printf("- G: %d\r\n",(int)G));
        }

        AUD_DEBUG(printf("Fo: %d %d\r\n",(int)Foh, (int)Fol));
        AUD_DEBUG(printf("fc: %d\r\n",(int)fc));
        AUD_DEBUG(printf("Q: %d\r\n",(int)Q));

        v0 = powf (10.0, (G/20.0));

        if (Gain >= 120)
        {
            //Peak,boost
            dem = 1 + k/Q + kpow2;
            coef = (1 + v0*k/Q + kpow2)/dem;
            PEQCoef.a0 = (unsigned long)(coef * 4194304);
            coef = 2*(kpow2-1)/dem;
            PEQCoef.a1 = (unsigned long)(coef * 4194304);
            coef = (1 - v0*k/Q + kpow2)/dem;
            PEQCoef.a2 = (unsigned long)(coef * 4194304);
            coef = 2*(kpow2-1)/dem;
            PEQCoef.b1 = (unsigned long)(-coef * 4194304);
            coef = (1 - k/Q + kpow2)/dem;
            PEQCoef.b2 = (unsigned long)(-coef * 4194304);
        }
        else
        {
            //peak,cut
            dem = 1 + v0*k/Q + kpow2;
            coef = (1 + k/Q + kpow2)/dem;
            PEQCoef.a0 = (unsigned long)(coef * 4194304);
            coef = 2*(kpow2-1)/dem;
            PEQCoef.a1 = (unsigned long)(coef * 4194304);
            coef = (1 - k/Q + kpow2)/dem;
            PEQCoef.a2 = (unsigned long)(coef * 4194304);
            coef = 2*(kpow2-1)/dem;
            PEQCoef.b1 = (unsigned long)(-coef * 4194304);
            coef = (1 - v0*k/Q + kpow2)/dem;
            PEQCoef.b2 = (unsigned long)(-coef * 4194304);
        }

        MApi_AUDIO_EnablePEQ(FALSE);
        MApi_AUDIO_SetPEQCoef(&PEQCoef);
        MApi_AUDIO_EnablePEQ(TRUE);

        AUD_DEBUG(printf("msAPI a0 = %x", (MS_U8)(PEQCoef.a0>>16)));
        AUD_DEBUG(printf(" %x", (MS_U8)(PEQCoef.a0>>8)));
        AUD_DEBUG(printf(" %x\r\n", (MS_U8)PEQCoef.a0));

        AUD_DEBUG(printf("a1 = %x", (MS_U8)(PEQCoef.a1>>16)));
        AUD_DEBUG(printf(" %x", (MS_U8)(PEQCoef.a1>>8)));
        AUD_DEBUG(printf(" %x\r\n", (MS_U8)PEQCoef.a1));

        AUD_DEBUG(printf("a2 = %x", (MS_U8)(PEQCoef.a2>>16)));
        AUD_DEBUG(printf(" %x", (MS_U8)(PEQCoef.a2>>8)));
        AUD_DEBUG(printf(" %x\r\n", (MS_U8)PEQCoef.a2));

        AUD_DEBUG(printf("b1 = %x", (MS_U8)(PEQCoef.b1>>16)));
        AUD_DEBUG(printf(" %x", (MS_U8)(PEQCoef.b1>>8)));
        AUD_DEBUG(printf(" %x\r\n", (MS_U8)PEQCoef.b1));

        AUD_DEBUG(printf("b2 = %x", (MS_U8)(PEQCoef.b2>>16)));
        AUD_DEBUG(printf(" %x", (MS_U8)(PEQCoef.b2>>8)));
        AUD_DEBUG(printf(" %x\r\n", (MS_U8)PEQCoef.b2));
    }
}

void msApi_AUD_SIF_Shift(En_AUD_VIF_Type type)
{
    MApi_AUDIO_SIF_Shift(type);
    MApi_AUDIO_SIF_SetThreshold(AuSifInitThreshold);

    #if (ENABLE_SBTVD_BRAZIL_APP)
        MApi_AUDIO_SIF_SetPrescale(SET_PRESCALE_BTSC,0);
    #elif (TV_SYSTEM == TV_PAL)
        #if((FRONTEND_IF_DEMODE_TYPE==MSTAR_VIF)||(FRONTEND_IF_DEMODE_TYPE==MSTAR_VIF_MSB1210)||(FRONTEND_IF_DEMODE_TYPE==MSTAR_INTERN_VIF))
        MApi_AUDIO_SIF_SetPrescale(SET_PRESCALE_A2_FM,3); //kochien for VIF
        MApi_AUDIO_SIF_SetPrescale(SET_PRESCALE_NICAM,3);
        MApi_AUDIO_SIF_SetPrescale(SET_PRESCALE_AM,7);
        MApi_AUDIO_SIF_SetPrescale(SET_PRESCALE_HIDEV,3);
        #else  // MSTAR_INTERN_VIF & NONE_VIF
        MApi_AUDIO_SIF_SetPrescale(SET_PRESCALE_A2_FM,6);
        MApi_AUDIO_SIF_SetPrescale(SET_PRESCALE_AM,9);
        MApi_AUDIO_SIF_SetPrescale(SET_PRESCALE_NICAM,6);
        MApi_AUDIO_SIF_SetPrescale(SET_PRESCALE_HIDEV,6);
        #endif
    #elif (TV_SYSTEM == TV_NTSC)
        #if (AUDIO_SYSTEM_SEL == AUDIO_SYSTEM_BTSC)
            MApi_AUDIO_SIF_SetPrescale(SET_PRESCALE_BTSC,0);
        #elif (AUDIO_SYSTEM_SEL == AUDIO_SYSTEM_A2)
            MApi_AUDIO_SIF_SetPrescale(SET_PRESCALE_FM_M,0); //Korea A2
        #endif
    #endif
}

#ifdef CUS_AUDIO_TREBLE_BASS_LIMIT


/******************************************************************************
* Function	: MApi_AUDIO_SetBassLimit()
* Description	: ���Ƶ���������ΧΪ-8(21)~+8(79)
* Input		:
* Output		:
* Return		:
******************************************************************************/

#define CUS_SET_BASS_LIMIT_MIN			21		// CUS_XM Sea 20120712: -8
#define CUS_SET_BASS_LIMIT_MIDDLE		50		// CUS_XM Sea 20120712: 0
#define CUS_SET_BASS_LIMIT_MAX		79		// CUS_XM Sea 20120712: +8

void MApi_AUDIO_SetBassLimit (MS_U8 u8Bass)
{
	MS_U16 temp;

	if (u8Bass >= CUS_SET_BASS_LIMIT_MIDDLE)
	{
		temp = (u8Bass - CUS_SET_BASS_LIMIT_MIDDLE) * (CUS_SET_BASS_LIMIT_MAX-CUS_SET_BASS_LIMIT_MIDDLE) / 50;
		u8Bass = CUS_SET_BASS_LIMIT_MIDDLE + (MS_U8)temp;
	}
	else
	{
		temp = (CUS_SET_BASS_LIMIT_MIDDLE - u8Bass) * (CUS_SET_BASS_LIMIT_MIDDLE-CUS_SET_BASS_LIMIT_MIN) / 50;
		u8Bass = CUS_SET_BASS_LIMIT_MIDDLE - (MS_U8)temp;
	}

	//printf("u8Bass0 = %bu\n", u8Bass);

	if (u8Bass <= CUS_SET_BASS_LIMIT_MIN)
	{
		u8Bass = CUS_SET_BASS_LIMIT_MIN;
	}

	if (u8Bass >= CUS_SET_BASS_LIMIT_MAX)
	{
		u8Bass = CUS_SET_BASS_LIMIT_MAX;
	}

	//printf("u8Bass = %bu\n", u8Bass);

	MApi_AUDIO_SetBass(u8Bass);

}



/******************************************************************************
* Function	: MApi_AUDIO_SetTrebleLimit()
* Description	: ���Ƹ���������ΧΪ-8(21)~+8(79)
* Input		:
* Output		:
* Return		:
******************************************************************************/

#define CUS_SET_TREBLE_LIMIT_MIN			21		// CUS_XM Sea 20120712: -8
#define CUS_SET_TREBLE_LIMIT_MIDDLE		50		// CUS_XM Sea 20120712: 0
#define CUS_SET_TREBLE_LIMIT_MAX			79		// CUS_XM Sea 20120712: +8

void MApi_AUDIO_SetTrebleLimit (MS_U8 u8Treble)
{
	MS_U16 temp;

	if (u8Treble >= CUS_SET_TREBLE_LIMIT_MIDDLE)
	{
		temp = (u8Treble - CUS_SET_TREBLE_LIMIT_MIDDLE) * (CUS_SET_TREBLE_LIMIT_MAX-CUS_SET_TREBLE_LIMIT_MIDDLE) / 50;
		u8Treble = CUS_SET_TREBLE_LIMIT_MIDDLE + (MS_U8)temp;
	}
	else
	{
		temp = (CUS_SET_TREBLE_LIMIT_MIDDLE - u8Treble) * (CUS_SET_TREBLE_LIMIT_MIDDLE-CUS_SET_TREBLE_LIMIT_MIN) / 50;
		u8Treble = CUS_SET_TREBLE_LIMIT_MIDDLE - (MS_U8)temp;
	}

	//printf("u8Treble0 = %bu\n", u8Treble);

	if (u8Treble <= CUS_SET_TREBLE_LIMIT_MIN)
	{
		u8Treble = CUS_SET_TREBLE_LIMIT_MIN;
	}

	if (u8Treble >= CUS_SET_TREBLE_LIMIT_MAX)
	{
		u8Treble = CUS_SET_TREBLE_LIMIT_MAX;
	}

	//printf("u8Treble = %bu\n", u8Treble);

	MApi_AUDIO_SetTreble(u8Treble);

}




#endif

#ifdef ENABLE_CUS_AUTO_AUDIO_SYSTEM_DETECT
extern void MDrv_IFDM_BypassDBBAudioFilter(BOOL bEnable);
static BOOLEAN bIsBeginAudioSystemAutoDetect = FALSE;
static U32 u32AudioSystemAutoDetectTimer = 0;
void msAPI_AUD_ATV_BeginAudioSystemAutoDetect(BOOLEAN bIsBegin)
{
    printf("\r\n Begin Detect audio auto detect![%bu]",bIsBegin);/*Creass.liu at 2012-08-04*/
    u32AudioSystemAutoDetectTimer = msAPI_Timer_GetTime0();
    bIsBeginAudioSystemAutoDetect = bIsBegin;
    /*if(IsATVInUse() && bIsBeginAudioSystemAutoDetect)
    {
        // for detect PAL MN
        MDrv_IFDM_BypassDBBAudioFilter(TRUE);
        MApi_AUDIO_SIF_StartAutoStandardDetection();
    }*/

}

BOOLEAN msAPI_AUD_ATV_IsBeginAudioSystemAutoDetect(void)
{
    return bIsBeginAudioSystemAutoDetect;
}

extern U8 msAPI_Tuner_GetAudioAutoDetecStatus(void);
extern void msAPI_Tuner_SetAudioAutoDetecStatusExit(void);
void msAPI_AUD_ATV_AudioSystemAutoDetect(U32 u32CheckDelay)
{
    if(msAPI_Timer_DiffTimeFromNow(u32AudioSystemAutoDetectTimer) < u32CheckDelay)
    {
        return;
    }

    u32AudioSystemAutoDetectTimer = msAPI_Timer_GetTime0();

    if(IsATVInUse() && bIsBeginAudioSystemAutoDetect)
    {
        if(msAPI_Tuner_GetAudioAutoDetecStatus() == AUDIO_AUTO_STATUS_EXIT)
        {
            msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_INTERNAL_4_MUTEON, E_AUDIOMUTESOURCE_ATV);
            msAPI_Tuner_TuningProcessor(AFT_AUDIO_AUTODETECT);
        }
        else if(msAPI_Tuner_GetAudioAutoDetecStatus() == AUDIO_AUTO_STATUS_END)
        {
            #if (ENABLE_DTMB_CHINA_APP || ENABLE_ATV_CHINA_APP || ENABLE_DVBC_PLUS_DTMB_CHINA_APP)
            EN_ATV_SYSTEM_TYPE u8AudioSystem =EN_ATV_SystemType_DK;
            #else
            EN_ATV_SYSTEM_TYPE u8AudioSystem =EN_ATV_SystemType_BG;
            #endif
            #if 0
            AUDIOSTANDARD_TYPE eAudioStandard;
            eAudioStandard = msAPI_AUD_GetResultOfAutoStandardDetection();
            printf(" auStd=0x%X\n", eAudioStandard);

            //for detect PAL MN
            MDrv_IFDM_BypassDBBAudioFilter(FALSE);
            if( msAPI_AUD_IsAudioDetected() == FALSE)
            {
                printf(" Audio detect failed-2!\n");
            }
            #else
            if(eAudioStandard_AutoDetect_Result == FALSE)
            {
                printf(" Audio detect failed-2!\n");
            }
            #endif
            else
            {
                if( (E_VIDEOSTANDARD_NTSC_M == msAPI_AVD_GetStandardDetection())
                  &&((eAudioStandard_AutoDetect == E_AUDIOSTANDARD_I)||(eAudioStandard_AutoDetect == E_AUDIOSTANDARD_BG) )
                  )
                {
                    // Set audio std to M
                    //printf("Set audio std to M -2\n");
                    msAPI_AUD_SetAudioStandard((AUDIOSTANDARD_TYPE)E_AUDIOSTANDARD_M);
                }
            }

            //Update System
            eAudioStandard_AutoDetect = msAPI_AUD_GetAudioStandard();
            printf(" <eAudioStandard=%u> ", eAudioStandard_AutoDetect);
            u8AudioSystem = MApp_ATVProc_GetAudioSystem(eAudioStandard_AutoDetect);
            if (u8AudioSystem != stGenSetting.stScanMenuSetting.u8SoundSystem)
            {
                stGenSetting.stScanMenuSetting.u8SoundSystem = u8AudioSystem;
                //printf(" => stScanMenuSetting.u8SoundSystem=%u 2\n", stGenSetting.stScanMenuSetting.u8SoundSystem);
                msAPI_AUD_ForceAudioStandard(eAudioStandard_AutoDetect);
            #if ((FRONTEND_IF_DEMODE_TYPE == MSTAR_VIF_MSB1210)||(FRONTEND_IF_DEMODE_TYPE == MSTAR_VIF)||(FRONTEND_IF_DEMODE_TYPE == MSTAR_INTERN_VIF) )// GEM_SYNC_0815
                msAPI_Tuner_SetIF();
            #endif
                msAPI_SetTunerPLL_KeepFreq();
                msAPI_Timer_Delayms(100);
            }
            msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_INTERNAL_4_MUTEOFF, E_AUDIOMUTESOURCE_ATV);

            msAPI_Tuner_SetAudioAutoDetecStatusExit();
            bIsBeginAudioSystemAutoDetect = FALSE;
        }

    }
}
#endif

#undef _MSAPI_AUDIO_C_

