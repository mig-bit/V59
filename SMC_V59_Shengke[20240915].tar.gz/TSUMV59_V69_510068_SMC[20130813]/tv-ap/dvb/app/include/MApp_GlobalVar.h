////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef MAPP_GlOBALVAL_H
#define MAPP_GlOBALVAL_H

#include "Board.h"
#include "datatype.h"
#include "apiXC.h"
#include "apiXC_Adc.h"
#include "apiDMX.h"
#include "apiXC_Sys.h"
#include "msAPI_Global.h"
#include "msAPI_OSD.h"
#include "msAPI_DTVSystem.h"

#if ENABLE_DMP
#include "MApp_Scaler.h"
#endif
#include "MApp_GlobalSettingSt.h"

#if ENABLE_DTV
#include "mapp_demux.h"
#endif
#if ENABLE_JPEGPNG_OSD
#include "ZUI_jpeg_EnumIndex.h"
#endif

#ifdef MAPP_MAIN_C
#define INTERFACE
#else
#define INTERFACE extern
#endif

INTERFACE U8 u8KeyCode;
/* ~ ir_drv.c */


//ZUI_TODO: INTERFACE U8 u8ServiceTypeForMenuStr;
//ZUI_TODO: INTERFACE U16 g_wProgramPosition; // for text call back to get program name and number by index.
INTERFACE S16 g_u16ChannelOrinigalIndex;

//ZUI_TODO: INTERFACE U16 g_u16RecentMajor, g_u16RecentMinor;
//ZUI_TODO: INTERFACE U8 g_u8RecentSourceType;
//ZUI_TODO: INTERFACE U16 g_fRecentIsOnePartCh;


//ZUI_TODO: INTERFACE EN_MODE enMenuMode;

//INTERFACE S32 s32OffsetTime;
INTERFACE ST_TIME _stDate;


//ZUI_TODO: INTERFACE U8 iu8Loop_i,iu8Loop_j;
//ZUI_TODO: INTERFACE U8 iu8Buffer_i;

//ZUI_TODO: INTERFACE U16 iu16Loop_i;
//ZUI_TODO: INTERFACE U16 iu16Buffer_i;

//ZUI_TODO: INTERFACE U8 *iu8Ptr;

INTERFACE U8 iu8Loop_i,iu8Loop_j;
INTERFACE U8 iu8Buffer_i;

INTERFACE U16 iu16Loop_i;
//INTERFACE U16 iu16Buffer_i;

INTERFACE U8 *iu8Ptr;


#if ENABLE_DMP
INTERFACE U8 u8MainOSDWinId;
INTERFACE U8 g_u8MuteStatus;
#endif

#if  ((ATSC_CC == ATV_CC)||BRAZIL_CC)
INTERFACE BOOLEAN fEnableClosedCaptionFunc;// user decide from OSD Menu
INTERFACE U8 g_u8CCType_Option;
#endif

//ZUI_TODO: INTERFACE U8 u8OSDGWinTbl[MAXNUM_GWIN];

//ZUI_TODO: INTERFACE U8 OSDDuration;            // OSD idle time
//INTERFACE U8 InfoDuration;           // Info plate idle time
//ZUI_TODO: INTERFACE U8 Transparency;

#if ( ENABLE_ATV_VCHIP)
INTERFACE U32 au8Section[1024];//section data buffer
#endif
// 2048 -> 3076
//INTERFACE U16 au8StringBuffer[1024];// U32 (au8Section+((MSAPI_DMX_SECTION_1K<<2)/sizeof(U32)))
// 3076 -> 4096
//INTERFACE U16 au8StringBuffer2[1024];// (au8Section+((MSAPI_DMX_SECTION_1K<<2)/sizeof(U32))+(MSAPI_DMX_SECTION_1K/sizeof(U32)))

//INTERFACE U8 cIsBlocked;
INTERFACE BOOLEAN bIsBlocked;
INTERFACE OSDClrBtn clrBtn1;
INTERFACE OSDClrLine g_ClrLine;
INTERFACE MSAPI_GEBitmapFmt gbmpfmt;


//ZUI_TODO: INTERFACE U8 u8ChannelLabel[MAX_STATION_NAME];
//ZUI_TODO: INTERFACE U8 IsInEditChannelName;
//ZUI_TODO: INTERFACE U8 InEditChannelNameOrder;

// ZUI INTERFACE MS_TIME_LOG_T g_TimeLog; //Time Log to debug

INTERFACE BOOLEAN g_bPCSignalMonitor;
INTERFACE U8 g_u8PCSignalMonitorCounter;

//use for 1st time, clock setting from manual to auto (if default is manual)
//ZUI_TODO: INTERFACE BOOLEAN g_bFirstManual2Auto;
//use for redraw time val in clock setting
//ZUI_TODO: INTERFACE BOOLEAN g_bAutoTimeRedraw;
//ZUI_TODO: INTERFACE U8 u8PreviousPCModeIndex;


INTERFACE BOOLEAN bNextEvent;
//INTERFACE DTV_CHANNEL_INFO  chData;
//INTERFACE U16 u16RADIO_Num;
//INTERFACE U16 u16TV_Num;

INTERFACE U16 g_u16PasswordCheckSource;

//INTERFACE BOOLEAN bIsInsideDTVManualScanMenu;

#if ENABLE_OAD
INTERFACE BOOLEAN bFoundOAD;
INTERFACE BOOLEAN bNitFoundInvalidOAD;
#endif
#if (INPUT_SCART_VIDEO_COUNT >= 1)
INTERFACE U32 u32ScartSwitchDuration;
#endif
//#define MAX_BITMAP      600//500
//INTERFACE BMPHANDLE  Osdcp_bmpHandle[MAX_BITMAP];

#if EAR_PHONE_POLLING
INTERFACE BOOLEAN PreEarphoneState;
#endif

#define ZUI_ALIGNED_VALUE(value, align)  ( (value) & ~((align)-1) )

INTERFACE BOOLEAN g_bIsImageFrozen;

#if ((BRAZIL_CC)||(ATSC_CC == ATV_CC))
typedef enum
{
    CC_FONT_UNLOAD,
    CC_FONT_UNLOAD_SPEEDUP,
    CC_FONT_LOAD
} EN_CC_FONT_STATUS;
INTERFACE EN_CC_FONT_STATUS enCCFontStatus;
#endif

// Scan related
INTERFACE U8        u8ScanAtvChNum;                 // add for Auto Tune menu
INTERFACE U16        u16ScanDtvChNum;                 // add for Auto Tune menu
INTERFACE U16        u16ScanRadioChNum;               // add for Auto Tune menu


INTERFACE BOOLEAN   fEnableMvdTimingMonitor;        //<---should be moved to other place
#if ENABLE_SBTVD_BRAZIL_APP
INTERFACE U8        u8ScanCATVChNum;                 // add for Auto Tune menu
INTERFACE U8        u8ScanAirTVChNum;                 // add for Auto Tune menu
#endif
#if NORDIG_FUNC //for Nordig Spec v2.0
INTERFACE U16        u16ScanDataChNum;                 // add for Auto Tune menu
#endif
INTERFACE U8        u8ScanPercentageNum;            // add for Auto Tune menu

//#if (ENABLE_PIP)
//PIP sub window
INTERFACE MS_WINDOW_TYPE stSubWindowPosition;
//#endif

INTERFACE U32       gCurValidSubtitleIndex;
INTERFACE U8        gu8TTXSubtitleServiceNum;


INTERFACE BOOLEAN _bOCPFromMem;  //20091124EL
#if ENABLE_SHOW_PHASE_FACTORY
INTERFACE U16 g_u16Miu0_Dqs0;
INTERFACE U16 g_u16Miu0_Dqs1;
 #if 1// (ENABLE_MIU_1)
INTERFACE U16 g_u16Miu1_Dqs0;
INTERFACE U16 g_u16Miu1_Dqs1;
 #endif
#endif


#if DVB_C_ENABLE     //for test without UI
INTERFACE U8 DVBCSymbolRateScanType;      //1:auto mode; 0:manual mode
INTERFACE U8 DVBCFreqScanType;                //1:auto mode; 0:manual mode
INTERFACE U8 DVBCNetworkIdScanType;       //1:auto mode; 0:manual mode
INTERFACE U8 DVBCModulationScanType;      //1:auto mode; 0:manual mode
#endif
#if ENABLE_OAD
INTERFACE BOOLEAN bShowOadScanPage;
INTERFACE BOOLEAN bNITSignalSSU;
INTERFACE U8 u8OADpercentage;
#endif
#if ENABLE_JPEGPNG_OSD

typedef enum
{
    JPP_JPGFLG,
    JPP_LOADST_MAX,
} JPP_LOADST_INDEX;
#define MAX_STATICLOAD_JPEGPNG     E_ZUI_JPG_MAX
INTERFACE MSAPI_JPEGPNGHANDLE  Osdcp_JpegPngHandle[MAX_STATICLOAD_JPEGPNG];
#endif

INTERFACE U16 prePictureHWND; //FOR RECORD WHICH HWND ENTER HWND_MENU_PICTURE_ADJUST
INTERFACE U16 Second_level_hwnd_back; //FOR RECORD WHICH HWND ENTER HWND_MENU_PICTURE_ADJUST
INTERFACE U16 third_level_hwnd_back; //FOR RECORD WHICH HWND ENTER HWND_MENU_PICTURE_ADJUST
INTERFACE U8 g_bGotoCUSMenu; //0: mstar factory menu   1: csm menu  2: cus factory menu   add hdx 20120605
#if ENABLE_CUS_UPDATE_SCAN
INTERFACE U8 g_bGotoUpdateScan;
#endif

INTERFACE BOOLEAN g_bCancelAutoscanByUser;
INTERFACE BYTE g_u8PreditFocusATVProgramNumber; //for store channel num. of focus item in mainpage-predit page
INTERFACE BOOLEAN g_bSscEnable;
INTERFACE BOOLEAN g_bFactoryResetMode;
INTERFACE U8 g_bFactoryLanguageBack;
INTERFACE U32  gFactoryTotaltime;//AC ON total time
INTERFACE U32  gFactoryTotaltimeback;//AC ON total time
INTERFACE U32  gFactoryTotaltimeback1;//AC ON total time
INTERFACE BOOLEAN g_bRegionEnable;//For CSM Region enable
INTERFACE U32  gFactoryBLTBackLITtime;//BLIT  time
INTERFACE U32  gFactoryBLTBackLITtimeback;//BLIT  time
INTERFACE U32  gFactoryBLTBackLITtimeback1;//BLIT  time
#if ENABLE_CUS_KEY_DASH
INTERFACE BOOLEAN g_bPressDashKey;
#endif
#if ENABLE_CUS_RS232_FUNC
INTERFACE U8 g_u8USBPortAttachmentFlag;
#endif
#if ENABLE_CUS_BURNING_MODE
INTERFACE BOOLEAN g_bIsOpenTestPattern;
INTERFACE BOOLEAN g_bDisableBurninMode;
#endif
#ifdef ENABLE_CUS_AUTO_SCAN_HOTKEY
INTERFACE U8 g_u8FacIRGotoScanMonitorCounter;
#endif
INTERFACE BOOLEAN g_bInitFinished;
// CUS_XM Xue 20120822: DMP switch source
#if (CUS_BRAND_ID == BRAND_ID_EBONY)
INTERFACE  BOOLEAN		SwitchHDMI2Source;
#endif


#if 0//TV_FREQ_SHIFT_CLOCK
INTERFACE BOOLEAN g_bChangeChannelAtTVsource;//patch for freq shift clok /*Creass.liu at 2012-08-09*/
#endif
#if(ENABLE_MULTI_PANELS==1)//fanjian0822
INTERFACE BOOLEAN bMulti_panel;
INTERFACE U16 bMulti_panel_count;//fjremark
#endif
#ifdef ENABLE_SANYO_WB_JPG
INTERFACE BOOLEAN bSanyoWbJpgDisplayed;
INTERFACE BOOLEAN bSanyoWbJpgDisplayedFlag;
#endif
#if SH_RESUME_AUTOPLAY
INTERFACE U8 g_ucIsSearchFileCount;
INTERFACE U8 g_ucGotoPlay;
#endif
INTERFACE U8 g_ucShLongKey;
INTERFACE U8 g_ucShLongKey_menu;

#undef INTERFACE

#endif
