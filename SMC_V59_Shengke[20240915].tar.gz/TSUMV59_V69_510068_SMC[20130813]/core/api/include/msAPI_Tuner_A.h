#ifndef MSAPI_TUNER_A_H
#define MSAPI_TUNER_A_H


/********************************************************************************/
/*                     Macro                                                    */
/********************************************************************************/
typedef enum
{
    DEMOD_MODE_NTSC,
    DEMOD_MODE_256QAM,
    DEMOD_MODE_64QAM,
    DEMOD_MODE_8VSB,
    DEMOD_MODE_NUM
} EN_DEMOD_MODE;

typedef enum
{
    DEMOD_SPECTRUM_NORMAL,
    DEMOD_SPECTRUM_INVERTER,
    DEMOD_SPECTRUM_AUTO
} EN_DEMOD_SPECTRUM_MODE;

typedef enum
{
    SIGNAL_NO            = 0,    /* little or no input power detected    */
    SIGNAL_WEAK        ,    /* some power detected.                    */
    SIGNAL_MODERATE    ,    /* lock achieved, SNR < 15 dB (approx)    */
    SIGNAL_STRONG        ,    /* lock achieved, SNR < 24 dB (approx)    */
    SIGNAL_VERY_STRONG,    /* lock achieved, SNR > 24 dB (approx)    */
}EN_SIGNAL_CONDITION;


typedef struct
{
    U16 u16Frequency;  //(50,000 ~ 860,000 Khz)/Tuner_Step
    U8 fModulation :2; //0:NTSC 1:256QAM 2:64QAM 3:8VSB
    U8 fSpectrum :2;   //0:normal 1:inverter 2:auto-tune
    U8 reserved :4;
} MS_TP_SETTING;

typedef enum
{
    LOCK,
    CHECKING,
    CHECKEND,
    UNLOCK,
} EN_SCAN_RESULT;


#ifdef MSAPI_TUNER_A_C
#define INTERFACE
#else
#define INTERFACE extern
#endif

INTERFACE S8 FREQ_OFFSET_RANGE_LEFT;
INTERFACE U8 FREQ_OFFSET_RANGE_RIGHT;
INTERFACE U8 FREQ_OFFSET_RANGE_Ch5Ch6_RIGHT;
INTERFACE S8 NTSC_AUTO_FREQ_OFFSET_TABLE[3];
INTERFACE S8 NTSC_CH5CH6_OFFSET_TABLE[3];

INTERFACE void msAPI_DemodState_INIT(void);
INTERFACE void msAPI_Tuner_InintCurrentTPSetting(void);
INTERFACE void msAPI_Tuner_Initialization(BOOL bSrcChg);
INTERFACE void msAPI_Tuner_SetFreq(U16 u16Frequency, EN_DEMOD_MODE enModulation);
INTERFACE void msAPI_Tuner_ZigZagScan(void);
INTERFACE void msAPI_Tuner_Tune2RfCh(MS_TP_SETTING *pstTPSetting);
INTERFACE BOOLEAN msAPI_Tuner_IsSameRfChannel(MS_TP_SETTING *pstTPSetting);
INTERFACE U8 msAPI_Tuner_GetLockStatus(EN_DEMOD_MODE enModulation);
INTERFACE U32 msAPI_Tuner_GetTimer2CheckLock(U8 Antenna_Type, U8 u8ScanType, U8 CheckLockStage);
INTERFACE void msAPI_Tuner_PowerOnOff(BOOLEAN bPower);
INTERFACE EN_SIGNAL_CONDITION msAPI_Tuner_CheckSignalSNR(void);
INTERFACE void msAPI_Tuner_SetSpectrum(EN_DEMOD_SPECTRUM_MODE enSpectrum);
INTERFACE BOOLEAN msAPI_Demodulator_Reset(void);
INTERFACE void msAPI_Demodulator_Exit(void);
INTERFACE BOOLEAN msAPI_Demodulator_Init(EN_DEMOD_MODE enModulation,EN_DEMOD_SPECTRUM_MODE enSpectrumType);
INTERFACE BOOLEAN msAPI_Tuner_Wait(U32 WaitTiming);
INTERFACE EN_SCAN_RESULT msAPI_VSB_Check_Lock(void);
INTERFACE BOOLEAN msAPI_Demodulator_Reset(void);
INTERFACE EN_SCAN_RESULT msAPI_QAM_Check_Lock(MS_TP_SETTING *pstDemodeTPSetting);
INTERFACE BOOLEAN msAPI_NTSC_GetFreq_Offset(MS_TP_SETTING *pstModifyTPSetting);
INTERFACE BOOLEAN msAPI_CHECK_AFT_FUNCTION(U16 Frequency, U8 Modulation,U8 *AFT_Result, BOOLEAN *VD_Result);
INTERFACE BOOLEAN msAPI_Demodulator_Get_Lock(EN_DEMOD_MODE enModulation);
INTERFACE BOOLEAN msAPI_In_AFT_Win_Check(MS_TP_SETTING *pstModifyTPSetting);
INTERFACE BOOLEAN msAPI_AFT_Freq_Offset_Tune(MS_TP_SETTING *pstModifyTPSetting);
INTERFACE BOOLEAN msAPI_NTSC_Check_Lock(MS_TP_SETTING *pstModifyTPSetting);

BOOLEAN msAPI_Tuner_PaThruI2C_WriteBytes(U8 u8SlaveID, U8 u8AddrNum, U8* paddr, U16 u16size, U8* pu8data);
BOOLEAN msAPI_Tuner_PaThruI2C_ReadBytes(U8 u8SlaveID, U8 u8AddrNum, U8* paddr, U16 u16size, U8* pu8data);
INTERFACE void msAPI_Tuner_PaThruI2C(BOOLEAN bEnable);
INTERFACE void msAPI_Tuner_Serial_Control(BOOLEAN bParallelMode);
#undef INTERFACE

#endif /* MSAPI_OSD_H */
