////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// ("MStar Confidential Information") by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#define _MAPP_AUDIO_C

/********************************************************************************/
/*              Header Files                        */
/********************************************************************************/
#include "Board.h"
#include "datatype.h"
#include "MsTypes.h"

#include "debug.h"

#if (ENABLE_DTV)
#include "mapp_demux.h"
#endif

#include "MApp_Key.h"
#include "MApp_TV.h"
#include "MApp_GlobalSettingSt.h"
#include "MApp_GlobalFunction.h"
#include "MApp_Font.h"
#include "MApp_Bitmap.h"
#include "MApp_GlobalVar.h"
//ZUI: #include "MApp_DispMenu.h"
#include "msAPI_audio.h"
#include "MApp_Audio.h"
#include "msAPI_Timer.h"
//ZUI: #include "MApp_UiMenu.h"
//ZUI: #include "MApp_UiMenuFunc.h"
#include "MApp_ChannelChange.h"
#include "apiAUDIO.h"
#include "drvAUDIO.h"
#include "drvXC_HDMI_if.h"
#include "apiXC_Hdmi.h"
#if (ENABLE_MADMONITOR)
#include "msAPI_audio.h"
#endif
#include "MApp_RestoreToDefault.h"

#include "MApp_ATVProc.h"
#include "msAPI_DTVSystem.h"
#include "msAPI_Video.h"
#include "MApp_UiMenuDef.h" //ZUI:
#include "drvGPIO.h"

#if ENABLE_PVR
#include "MApp_PVR.h"
#endif

#if (ENABLE_ATV_VCHIP)
#include "MApp_VChip.h"
#include "apiXC.h"
#endif

//--------------------------------------------------------------
// Default prescale table.
// It's shoule be declared in each board header file.
//--------------------------------------------------------------
#ifndef S4_AUDIO_PATH_SETTING

 #define Prescale_0dB               0x6F

 #define Prescale_MainSpeaker_DTV   Prescale_0dB-9
 #define Prescale_LineOut_DTV       Prescale_0dB-9
 #define Prescale_SifOut_DTV        Prescale_0dB-9  // Output DTV
 #define Prescale_SpdifOut_DTV      0x00

 #define Prescale_MainSpeaker_ATV   Prescale_0dB-5
 #define Prescale_LineOut_ATV       Prescale_0dB-5
 #define Prescale_SifOut_ATV        Prescale_0dB-5  // Output ATV
 #define Prescale_SpdifOut_ATV      0x00

 #define Prescale_MainSpeaker_AV    Prescale_0dB
 #define Prescale_LineOut_AV        Prescale_0dB
 #define Prescale_SifOut_AV         Prescale_0dB-5  // Output ATV
 #define Prescale_SpdifOut_AV       0x00

 #define Prescale_MainSpeaker_PC    Prescale_0dB
 #define Prescale_LineOut_PC        Prescale_0dB
 #define Prescale_SifOut_PC         Prescale_0dB-5  // Output ATV
 #define Prescale_SpdifOut_PC       0x00

 #define Prescale_MainSpeaker_HDMI  Prescale_0dB-9
 #define Prescale_LineOut_HDMI      Prescale_0dB-9
 #define Prescale_SifOut_HDMI       Prescale_0dB-5  // Output ATV
 #define Prescale_SpdifOut_HDMI     0x00

#endif

#if (ENABLE_ATV_VCHIP)
extern BOOLEAN g_bInputBlocked;
#endif

// volume curve: y= -(3/625)^2*x^4 +(72/15625)x^3+(9/25)x^2 -(216/25)-60
#if ENABLE_SOUND_NEW_NONLINEAR
ROM BYTE TvVolumeFraTable[] =
{   
    0x07,0x06,0x05,0x04,0x03,0x02,0x01,0x00
};
#else
#if (MS_BOARD_TYPE_SEL == BD_CUS_715G_5740)

ROM BYTE TvVolumeIntTable[] = CUS_TV_VOLUME_INT_TABLE;		// CUS_XM Sea 20120613: register 112D8C
ROM BYTE TvVolumeFraTable[] = CUS_TV_VOLUME_FRA_TABLE;		// CUS_XM Sea 20120613: register 112DA8

#else

ROM BYTE TvVolumeIntTable[] =
{   0x7F,                                              //  00
    0x4F,0x4C,0x4A,0x48,0x46,0x44,0x42,0x40,0x3E,0x3C, // UI:  1~10
    0x3A,0x38,0x36,0x34,0x32,0x30,0x2E,0x2C,0x2A,0x28, // UI: 11~20
    0x27,0x26,0x25,0x24,0x23,0x23,0x22,0x21,0x20,0x20, // UI: 21~30
    0x1F,0x1E,0x1D,0x1C,0x1C,0x1B,0x1A,0x19,0x18,0x18, // UI: 31~40
    0x17,0x17,0x17,0x17,0x17,0x16,0x16,0x16,0x16,0x16, // UI: 41~50
    0x15,0x15,0x15,0x15,0x15,0x14,0x14,0x14,0x14,0x14, // UI: 51~60
    0x13,0x13,0x13,0x13,0x13,0x12,0x12,0x12,0x12,0x12, // UI: 61~70
    0x11,0x11,0x11,0x11,0x11,0x10,0x10,0x10,0x10,0x10, // UI: 71~80
    0x0F,0x0F,0x0F,0x0F,0x0F,0x0E,0x0E,0x0E,0x0E,0x0E, // UI: 81~90
    0x0D,0x0D,0x0D,0x0D,0x0D,0x0C,0x0C,0x0C,0x0C,0x0C  // UI: 91~100
};

ROM BYTE TvVolumeFraTable[] =
{   0x00,                                              // UI:  Mute
    0x70,0x00,0x70,0x70,0x60,0x60,0x50,0x50,0x40,0x40, // UI:  1~10
    0x30,0x30,0x20,0x20,0x20,0x10,0x10,0x00,0x00,0x00, // UI: 11~20
    0x10,0x30,0x40,0x60,0x00,0x10,0x30,0x40,0x60,0x00, // UI: 21~30
    0x10,0x30,0x40,0x60,0x00,0x10,0x30,0x40,0x60,0x00, // UI: 31~40
    0x60,0x40,0x30,0x10,0x00,0x60,0x40,0x30,0x10,0x00, // UI: 41~50
    0x60,0x40,0x30,0x10,0x00,0x60,0x40,0x30,0x10,0x00, // UI: 51~60
    0x60,0x40,0x30,0x10,0x00,0x60,0x40,0x30,0x10,0x00, // UI: 61~70
    0x60,0x40,0x30,0x10,0x00,0x60,0x40,0x30,0x10,0x00, // UI: 71~80
    0x60,0x40,0x30,0x10,0x00,0x60,0x40,0x30,0x10,0x00, // UI: 81~90
    0x60,0x40,0x30,0x10,0x00,0x60,0x40,0x30,0x10,0x00  // UI: 91~100
};

#endif
#endif

#if (TV_SYSTEM == TV_PAL)
    #if((FRONTEND_IF_DEMODE_TYPE == MSTAR_VIF)||(FRONTEND_IF_DEMODE_TYPE == MSTAR_INTERN_VIF)||(FRONTEND_IF_DEMODE_TYPE == MSTAR_VIF_MSB1210))    //threshold for VIF
    THR_TBL_TYPE code AuSifInitThreshold[] =
    {
         {0x03 ,0x00 ,} ,     //A2_M    CARRIER1_ON_AMP
         {0x02 ,0x00 ,} ,     //A2_M    CARRIER1_OFF_AMP
         {0x12 ,0x00 ,} ,     //A2_M    CARRIER1_ON_NSR
         {0x7F ,0xFF ,} ,     //A2_M    CARRIER1_OFF_NSR
         {0x02 ,0x00 ,} ,     //A2_M    CARRIER2_ON_AMP
         {0x01 ,0x80 ,} ,     //A2_M    CARRIER2_OFF_AMP
         {0x11 ,0x00 ,} ,     //A2_M    CARRIER2_ON_NSR
         {0x15 ,0x00 ,} ,     //A2_M    CARRIER2_OFF_NSR
         {0x02 ,0x80 ,} ,     //A2_M    A2_PILOT_ON_AMP
         {0x01 ,0x00 ,} ,     //A2_M    A2_PILOT_OFF_AMP

         {0x03 ,0x00 ,} ,     //A2_BG   CARRIER1_ON_AMP
         {0x02 ,0x00 ,} ,     //A2_BG   CARRIER1_OFF_AMP
         {0x13 ,0x00 ,} ,     //A2_BG   CARRIER1_ON_NSR
         {0x7F ,0xFF ,} ,     //A2_BG   CARRIER1_OFF_AMP
         {0x02 ,0x00 ,} ,     //A2_BG   CARRIER2_ON_AMP
         {0x01 ,0x80 ,} ,     //A2_BG   CARRIER2_OFF_AMP
         {0x11 ,0x00 ,} ,     //A2_BG   CARRIER2_ON_NSR
         {0x30 ,0x00 ,} ,     //A2_BG   CARRIER2_OFF_NSR
         {0x02 ,0x80 ,} ,     //A2_BG   A2_PILOT_ON_AMP
         {0x01 ,0x00 ,} ,     //A2_BG   A2_PILOT_OFF_AMP

         {0x03 ,0x00 ,} ,     //A2_DK   CARRIER1_ON_AMP
         {0x02 ,0x00 ,} ,     //A2_DK   CARRIER1_OFF_AMP
         {0x13 ,0x00 ,} ,     //A2_DK   CARRIER1_ON_NSR
         {0x7F ,0xFF ,} ,     //A2_DK   CARRIER1_OFF_NSR
         {0x02 ,0x00 ,} ,     //A2_DK   CARRIER2_ON_AMP
         {0x01 ,0x80 ,} ,     //A2_DK   CARRIER2_OFF_AMP
         {0x11 ,0x00 ,} ,     //A2_DK   CARRIER2_ON_NSR
         {0x15 ,0x00 ,} ,     //A2_DK   CARRIER2_OFF_NSR
         {0x02 ,0x80 ,} ,     //A2_DK   A2_PILOT_ON_AMP
         {0x01 ,0x00 ,} ,     //A2_DK   A2_PILOT_OFF_AMP

         {0x03 ,0x00 ,} ,     //FM_I   CARRIER1_ON_AMP
         {0x02 ,0x00 ,} ,     //FM_I   CARRIER1_OFF_AMP
         {0x12 ,0x00 ,} ,     //FM_I   CARRIER1_ON_NSR
         {0x7F ,0xFF ,} ,     //FM_I   CARRIER1_OFF_NSR

         {0x00 ,0xA0 ,} ,     //AM   CARRIER1_ON_AMP
         {0x00 ,0x80 ,} ,     //AM   CARRIER1_OFF_AMP

         {0x23 ,0x00 ,} ,     //NICAM_BG  NICAM_ON_SIGERR
         {0x29 ,0x00 ,} ,     //NICAM_BG  NICAM_OFF_SIGERR

         {0x23 ,0x00 ,} ,     //NICAM_I  NICAM_ON_SIGERR
         {0x29 ,0x00 ,} ,     //NICAM_I  NICAM_OFF_SIGERR

         {0x02 ,0x00 ,} ,     //HIDEV_M  CARRIER1_ON_AMP
         {0x01 ,0x00 ,} ,     //HIDEV_M  CARRIER1_OFF_AMP
         {0x12 ,0x00 ,} ,     //HIDEV_M  CARRIER1_ON_NSR
         {0x7F ,0xFF ,} ,     //HIDEV_M  CARRIER1_OFF_NSR

         {0x02 ,0x00 ,} ,     //HIDEV_BG  CARRIER1_ON_AMP
         {0x01 ,0x00 ,} ,     //HIDEV_BG  CARRIER1_OFF_AMP
         {0x12 ,0x00 ,} ,     //HIDEV_BG  CARRIER1_ON_NSR
         {0x7F ,0xFF ,} ,     //HIDEV_BG  CARRIER1_OFF_NSR

         {0x02 ,0x00 ,} ,     //HIDEV_DK  CARRIER1_ON_AMP
         {0x01 ,0x00 ,} ,     //HIDEV_DK  CARRIER1_OFF_AMP
         {0x12 ,0x00 ,} ,     //HIDEV_DK  CARRIER1_ON_NSR
         {0x7F ,0xFF ,} ,     //HIDEV_DK  CARRIER1_OFF_NSR

         {0x02 ,0x00 ,} ,     //HIDEV_I  CARRIER1_ON_AMP
         {0x01 ,0x00 ,} ,     //HIDEV_I  CARRIER1_OFF_AMP
         {0x12 ,0x00 ,} ,     //HIDEV_I  CARRIER1_ON_NSR
         {0x7F ,0xFF ,} ,     //HIDEV_I  CARRIER1_OFF_NSR
    };
    #else
    THR_TBL_TYPE code AuSifInitThreshold[] =
    {
         {0x02 ,0x00 ,} ,     //A2_M    CARRIER1_ON_AMP
         {0x01 ,0x00 ,} ,     //A2_M    CARRIER1_OFF_AMP
         {0x12 ,0x00 ,} ,     //A2_M    CARRIER1_ON_NSR
         {0x7F ,0xFF ,} ,     //A2_M    CARRIER1_OFF_NSR
         {0x01 ,0x00 ,} ,     //A2_M    CARRIER2_ON_AMP
         {0x00 ,0x80 ,} ,     //A2_M    CARRIER2_OFF_AMP
         {0x11 ,0x00 ,} ,     //A2_M    CARRIER2_ON_NSR
         {0x15 ,0x00 ,} ,     //A2_M    CARRIER2_OFF_NSR
         {0x02 ,0x80 ,} ,     //A2_M    A2_PILOT_ON_AMP
         {0x01 ,0x00 ,} ,     //A2_M    A2_PILOT_OFF_AMP

         {0x02 ,0x00 ,} ,     //A2_BG   CARRIER1_ON_AMP
         {0x01 ,0x00 ,} ,     //A2_BG   CARRIER1_OFF_AMP
         {0x13 ,0x00 ,} ,     //A2_BG   CARRIER1_ON_NSR
         {0x7F ,0xFF ,} ,     //A2_BG   CARRIER1_OFF_AMP
         {0x00 ,0x40 ,} ,     //A2_BG   CARRIER2_ON_AMP
         {0x00 ,0x30 ,} ,     //A2_BG   CARRIER2_OFF_AMP
         {0x11 ,0x00 ,} ,     //A2_BG   CARRIER2_ON_NSR
         {0x30 ,0x00 ,} ,     //A2_BG   CARRIER2_OFF_NSR
         {0x02 ,0x80 ,} ,     //A2_BG   A2_PILOT_ON_AMP
         {0x01 ,0x00 ,} ,     //A2_BG   A2_PILOT_OFF_AMP

         {0x02 ,0x00 ,} ,     //A2_DK   CARRIER1_ON_AMP
         {0x01 ,0x00 ,} ,     //A2_DK   CARRIER1_OFF_AMP
         {0x13 ,0x00 ,} ,     //A2_DK   CARRIER1_ON_NSR
         {0x7F ,0xFF ,} ,     //A2_DK   CARRIER1_OFF_NSR
         {0x00 ,0x40 ,} ,     //A2_DK   CARRIER2_ON_AMP
         {0x00 ,0x30 ,} ,     //A2_DK   CARRIER2_OFF_AMP
         {0x11 ,0x00 ,} ,     //A2_DK   CARRIER2_ON_NSR
         {0x15 ,0x00 ,} ,     //A2_DK   CARRIER2_OFF_NSR
         {0x02 ,0x80 ,} ,     //A2_DK   A2_PILOT_ON_AMP
         {0x01 ,0x00 ,} ,     //A2_DK   A2_PILOT_OFF_AMP

         {0x02 ,0x00 ,} ,     //FM_I   CARRIER1_ON_AMP
         {0x01 ,0x00 ,} ,     //FM_I   CARRIER1_OFF_AMP
         {0x12 ,0x00 ,} ,     //FM_I   CARRIER1_ON_NSR
         {0x7F ,0xFF ,} ,     //FM_I   CARRIER1_OFF_NSR

         {0x07 ,0x00 ,} ,     //AM   CARRIER1_ON_AMP
         {0x06 ,0x00 ,} ,     //AM   CARRIER1_OFF_AMP

         {0x23 ,0x00 ,} ,     //NICAM_BG  NICAM_ON_SIGERR
         {0x29 ,0x00 ,} ,     //NICAM_BG  NICAM_OFF_SIGERR

         {0x23 ,0x00 ,} ,     //NICAM_I  NICAM_ON_SIGERR
         {0x29 ,0x00 ,} ,     //NICAM_I  NICAM_OFF_SIGERR

         {0x00 ,0x80 ,} ,     //HIDEV_M  CARRIER1_ON_AMP
         {0x00 ,0x40 ,} ,     //HIDEV_M  CARRIER1_OFF_AMP
         {0x12 ,0x00 ,} ,     //HIDEV_M  CARRIER1_ON_NSR
         {0x7F ,0xFF ,} ,     //HIDEV_M  CARRIER1_OFF_NSR

         {0x00 ,0xB0 ,} ,     //HIDEV_BG  CARRIER1_ON_AMP
         {0x00 ,0x60 ,} ,     //HIDEV_BG  CARRIER1_OFF_AMP
         {0x12 ,0x00 ,} ,     //HIDEV_BG  CARRIER1_ON_NSR
         {0x7F ,0xFF ,} ,     //HIDEV_BG  CARRIER1_OFF_NSR

         {0x00 ,0xB0 ,} ,     //HIDEV_DK  CARRIER1_ON_AMP
         {0x00 ,0x60 ,} ,     //HIDEV_DK  CARRIER1_OFF_AMP
         {0x12 ,0x00 ,} ,     //HIDEV_DK  CARRIER1_ON_NSR
         {0x7F ,0xFF ,} ,     //HIDEV_DK  CARRIER1_OFF_NSR

         {0x00 ,0xB0 ,} ,     //HIDEV_I  CARRIER1_ON_AMP
         {0x00 ,0x60 ,} ,     //HIDEV_I  CARRIER1_OFF_AMP
         {0x12 ,0x00 ,} ,     //HIDEV_I  CARRIER1_ON_NSR
         {0x7F ,0xFF ,} ,     //HIDEV_I  CARRIER1_OFF_NSR
    };
    #endif
#elif (TV_SYSTEM == TV_NTSC)
THR_TBL_TYPE code AuSifInitThreshold[] =
{
    #if (AUDIO_SYSTEM_SEL == AUDIO_SYSTEM_BTSC)
    {0x30 ,0x00 ,} ,     //BTSC_MONO_ON_NSR_THRESHOLD
    {0x7f ,0xff ,} ,     //BTSC_MONO_OFF_NSR_THRESHOLD
    {0x20 ,0x00 ,} ,     //BTSC_PILOT_ON_AMPLITUDE_THRESHOLD
    {0x15 ,0x00 ,} ,     //BTSC_PILOT_OFF_AMPLITUDE_THRESHOLD
    {0x35 ,0x00 ,} ,     //BTSC_SAP_ON_NSR_THRESHOLD
    {0x7F ,0xFF ,} ,     //BTSC_SAP_OFF_NSR_THRESHOLD
    {0x30 ,0x00 ,} ,     //BTSC_STEREO_ON_THRESHOLD
    {0x7f ,0xff ,} ,     //BTSC_STEREO_OFF_THRESHOLD
    {0x00 ,0x90 ,} ,     //BTSC_SAP_ON_AMPLITUDE_THRESHOLD
    {0x00 ,0x50 ,} ,     //BTSC_SAP_OFF_AMPLITUDE_THRESHOLD
    #elif (AUDIO_SYSTEM_SEL == AUDIO_SYSTEM_A2)
    {0x00 ,0x11 ,} ,     //A2_M    CARRIER1_ON_AMP
    {0x00 ,0x0E ,} ,     //A2_M    CARRIER1_OFF_AMP
    {0x1A ,0x00 ,} ,     //A2_M    CARRIER1_ON_NSR
    {0x7F ,0xFF ,} ,     //A2_M    CARRIER1_OFF_NSR
    {0x01 ,0x00 ,} ,     //A2_M    CARRIER2_ON_AMP
    {0x00 ,0x80 ,} ,     //A2_M    CARRIER2_OFF_AMP
    {0x0D ,0x00 ,} ,     //A2_M    CARRIER2_ON_NSR
    {0x13 ,0x00 ,} ,     //A2_M    CARRIER2_OFF_NSR
    {0x02 ,0x80 ,} ,     //A2_M    A2_PILOT_ON_AMP
    {0x01 ,0x00 ,} ,     //A2_M    A2_PILOT_OFF_AMP
    #endif
};

#endif

//---------------------------------------------------------------

/********************************************************************************/
/*              Local                           */
/********************************************************************************/

#define THRESHOLD_MTS_CHANGED (3)
//static U8 u8MtsThresholdCount = 0;
//static U32 u32MonitorMtsTimer;

#define MTS_MONITOR_POLLING_TIMES (100)
#define MTS_MONITOR_MTSCHANGED_TIMES (500)
#define POLLING_STEREO_COUNTS (20)


#define AC3_MONITOR_TIMES (600)

#define MTS_DBINFO(x) //x


/********************************************************************************/
/*              Functions                           */
/********************************************************************************/
#if ENABLE_DTV
BOOLEAN MApp_Audio_SetAudioLanguage(U8 u8AudSelectedIndex)
{
    AUD_INFO stAudioStreamInfo;
    //move up, for invalid audio case, should stop audio
    /* mute during audio language change, to avoid transition noise, KH Tsai */
    msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_MOMENT_MUTEON, E_AUDIOMUTESOURCE_ACTIVESOURCE);

    /* stop audio decoder */
    MApi_AUDIO_SetCommand(MSAPI_AUD_DVB_DECCMD_STOP);

    /* delay before audio & demux stop to allow enough audio decoding samples to do fade out,
        make the sound smooth, KH Tsai */
    msAPI_Timer_Delayms(256);

#if ENABLE_PVR
    if (MApp_PVR_IsPlaybacking())
    {
        MApp_PVR_PlaybackAudioStopLanguage(g_u8AudLangSelected);
    }
    else
#endif
    {
        /* stop audio filter */
        msAPI_DMX_Stop(*MApp_Dmx_GetFid(EN_AUDIO_FID));
    }

#if ENABLE_PVR

    if (MApp_PVR_IsPlaybacking())
    {
        if (!MApp_PVR_PlaybackAudioGetStreamInfo(&stAudioStreamInfo, u8AudSelectedIndex))
        {
            msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_MOMENT_MUTEOFF, E_AUDIOMUTESOURCE_ACTIVESOURCE);
            return FALSE;
        }
    }
    else
#endif
    {
        if( TRUE != msAPI_CM_GetAudioStreamInfo(msAPI_CM_GetCurrentServiceType(), msAPI_CM_GetCurrentPosition(msAPI_CM_GetCurrentServiceType()), &stAudioStreamInfo, u8AudSelectedIndex) )
        {
            /* unmute the sound */
            msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_MOMENT_MUTEOFF, E_AUDIOMUTESOURCE_ACTIVESOURCE);
            return FALSE;
        }
    }

    g_u8AudLangSelected=u8AudSelectedIndex;
#if 0//move up, for invalid audio case, should stop audio
    /* mute during audio language change, to avoid transition noise, KH Tsai */
    msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_MOMENT_MUTEON, E_AUDIOMUTESOURCE_ACTIVESOURCE);

    /* delay before audio & demux stop to allow enough audio decoding samples to do fade out,
        make the sound smooth, KH Tsai */
    msAPI_Timer_Delayms(256);

    /* stop audio decoder */
    MApi_AUDIO_SetCommand(MSAPI_AUD_DVB_DECCMD_STOP);
    /* stop audio filter */
    MApp_DMX_Stop( *msAPI_DMX_GetAudioFid());
#endif

#if ENABLE_PVR
    if (MApp_PVR_IsPlaybacking())
    {
        MApp_PVR_PlaybackAudioSelectLanguage(g_u8AudLangSelected);
    }
    else
#endif
    {
        // start filter should be after than start audio decoder to prevent audio ES buffer overflow
        /* set audio PID & start filter */
        msAPI_DMX_StartFilter( stAudioStreamInfo.wAudPID, MSAPI_DMX_FILTER_TYPE_AUDIO, MApp_Dmx_GetFid(EN_AUDIO_FID));
    }

#if ENABLE_PVR
    if ((MApp_PVR_StateMachineGet() == E_PVR_STATE_TIMESHIFT) || (!MApp_PVR_IsPlaybacking()))
    {
        g_u16Current_PVR_AudioPID = stAudioStreamInfo.wAudPID;
        g_wCurrent_AudioType = stAudioStreamInfo.wAudType;
    }
#endif

    /* set decoder system and reload firmware code */
    switch(stAudioStreamInfo.wAudType)
    {
        case  E_AUDIOSTREAM_MPEG:
            MApi_AUDIO_SetSystem(MSAPI_AUD_DVB_MPEG);
            break;

        case E_AUDIOSTREAM_AC3:
            MApi_AUDIO_SetSystem(MSAPI_AUD_DVB_AC3);
            break;
        case E_AUDIOSTREAM_AC3P:
            MApi_AUDIO_SetSystem(MSAPI_AUD_DVB_AC3P);
            break;

        case E_AUDIOSTREAM_MPEG4:
        case E_AUDIOSTREAM_AAC:
            MApi_AUDIO_SetSystem(MSAPI_AUD_DVB_AAC);
            break;

        default:
            break;
    };
  //  MApi_AUDIO_SetSystem((En_DVB_decSystemType)stAudioStreamInfo.wAudType);

    if(stAudioStreamInfo.wAudType == E_AUDIOSTREAM_AC3)
    {
        if (g_eCodecType == E_VDEC_CODEC_TYPE_H264)
        {
            //printf("-- MTS H264 EN\n");
            MApi_AUDIO_SetH264StreamID_Mod(TRUE);
        }
        else
        {
             //printf("-- MTS H264 DIS\n");
            MApi_AUDIO_SetH264StreamID_Mod(FALSE);
        }
    }
    else
    {
        MApi_AUDIO_SetH264StreamID_Mod(FALSE);
    }

    /* start audio decoder */
    MApi_AUDIO_SetCommand(MSAPI_AUD_DVB_DECCMD_PLAY);
    /* unmute the sound */
    msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_MOMENT_MUTEOFF, E_AUDIOMUTESOURCE_ACTIVESOURCE);

#if MHEG5_ENABLE
    g_u16Current_AudioPID = stAudioStreamInfo.wAudPID;
    g_u16Current_AudioType = stAudioStreamInfo.wAudType;
#endif

    if(E_AUDIOSTREAM_AC3==stAudioStreamInfo.wAudType || E_AUDIOSTREAM_AC3P==stAudioStreamInfo.wAudType)
    {
        //printf("set SPDIF_non-PCM\r\n");
        MApi_AUDIO_SetAC3Info(Audio_AC3_infoType_DrcMode, RF_MODE, 0);    //RF Mod
        MApi_AUDIO_SetAC3Info(Audio_AC3_infoType_DownmixMode, DOLBY_DOWNMIX_MODE_LTRT, 0);
        if(stGenSetting.g_SysSetting.fSPDIFMODE == 0)
        {
        }
        #if ENABLE_CUS_SPDIF_MODE
        else if(stGenSetting.g_SysSetting.fSPDIFMODE >1)
        {
            MApi_AUDIO_SPDIF_SetMode(MSAPI_AUD_SPDIF_PCM);
        }
        #endif
        else
        {
            MApi_AUDIO_SPDIF_SetMode(MSAPI_AUD_SPDIF_NONPCM);
        }
    }
    else if(E_AUDIOSTREAM_AAC==stAudioStreamInfo.wAudType || E_AUDIOSTREAM_MPEG4==stAudioStreamInfo.wAudType)
    {
        if(stGenSetting.g_SysSetting.fSPDIFMODE == 0)
        {
            MApi_AUDIO_SPDIF_SetMode(MSAPI_AUD_SPDIF_PCM);
        }
        #if ENABLE_CUS_SPDIF_MODE
        else if(stGenSetting.g_SysSetting.fSPDIFMODE >1)
        {
            MApi_AUDIO_SPDIF_SetMode(MSAPI_AUD_SPDIF_PCM);
        }
        #endif
        else
        {
            MApi_AUDIO_SPDIF_SetMode(MSAPI_AUD_SPDIF_NONPCM);
        }
    }
    else
    {
        MApi_AUDIO_SPDIF_SetMode(MSAPI_AUD_SPDIF_PCM);
    }

    if(g_u8LRAudioMode == 0)
    {
        MApi_AUDIO_SetCommAudioInfo(Audio_Comm_infoType_SoundMode, MSAPI_AUD_MODE_STEREO, 0);
    }
    else if(g_u8LRAudioMode == 1)
    {
        MApi_AUDIO_SetCommAudioInfo(Audio_Comm_infoType_SoundMode, MSAPI_AUD_MODE_RR, 0);
        MApi_AUDIO_SetMpegInfo(Audio_MPEG_infoType_SoundMode, MSAPI_AUD_MPEG_SOUNDMODE_RR, 0);
    }
    else if(g_u8LRAudioMode == 2)
    {
        MApi_AUDIO_SetCommAudioInfo(Audio_Comm_infoType_SoundMode, MSAPI_AUD_MODE_LL, 0);
        MApi_AUDIO_SetMpegInfo(Audio_MPEG_infoType_SoundMode, MSAPI_AUD_MPEG_SOUNDMODE_LL, 0);
    }

    MApp_Audio_SearchAdAudio();
    //printf("SetAdAudio %u \n",g_u8AdAudSelected);
    MApp_Audio_SetAdAudio(g_u8AdAudSelected);

    return TRUE;
}

void MApp_Audio_SetAdAudio(U8 u8AudSelectedIndex)
{
    AUD_INFO stAudioStreamInfo;
    MApi_AUDIO_SetADOutputMode(AD_OUT_NONE);

#if ENABLE_PVR
    if (MApp_PVR_IsPlaybacking())
    {
        MApp_PVR_PlaybackAdAudioStopLanguage(u8AudSelectedIndex);
    }
    else
#endif
    {
        msAPI_DMX_Stop(*MApp_Dmx_GetFid(EN_AD_FID));
    }

    //msAPI_AUD_AdjustAudioFactor(E_ADJUST_DTV_AUDIO_COMMAND, E_AUDIO_DVB2_COM_STOP, 0);
    MApi_AUDIO_SetCommand(MSAPI_AUD_DVB2_DECCMD_STOP);


#if ENABLE_PVR
    if (MApp_PVR_IsPlaybacking())
    {
        if (!MApp_PVR_PlaybackAudioGetStreamInfo(&stAudioStreamInfo, u8AudSelectedIndex))
        {
            return;
        }
    }
    else
#endif
    {
        /* Get Audio Stream Info */
        if (TRUE != msAPI_CM_GetAudioStreamInfo(msAPI_CM_GetCurrentServiceType(), msAPI_CM_GetCurrentPosition(msAPI_CM_GetCurrentServiceType()), &stAudioStreamInfo, u8AudSelectedIndex))
            return;
    }

    #if 0
    if (stAudioStreamInfo.wAudType == E_AUDIOSTREAM_AC3)
    {
        /* Stop Ad Audio decoder */
        //msAPI_AUD_AdjustAudioFactor(E_ADJUST_DTV_AUDIO_COMMAND, E_AUDIO_DVB2_COM_STOP, 0);
        MApi_AUDIO_SetCommand(MSAPI_AUD_DVB2_DECCMD_STOP);
    }
    else
    #endif
    {
        if (stGenSetting.g_SoundSetting.bEnableAD)
        {
            /* set decoder system and reload firmware code */
            if (stAudioStreamInfo.wAudType == E_AUDIOSTREAM_AC3)
            {
                MApi_AUDIO_SetSystem(MSAPI_AUD_DVB2_AC3);
                #if ENABLE_PVR
                g_enCurrent_AudioDescriptorType = E_AUDIOSTREAM_AC3_AD;
                #endif
            }
            else if (stAudioStreamInfo.wAudType == E_AUDIOSTREAM_MPEG)
            {
                MApi_AUDIO_SetSystem(MSAPI_AUD_DVB2_MPEG);
                #if ENABLE_PVR
                g_enCurrent_AudioDescriptorType = E_AUDIOSTREAM_MPEG_AD;
                #endif
            }
            else if (stAudioStreamInfo.wAudType == E_AUDIOSTREAM_AC3P)
            {
                MApi_AUDIO_SetSystem(MSAPI_AUD_DVB2_AC3P);
                #if ENABLE_PVR
                g_enCurrent_AudioDescriptorType = E_AUDIOSTREAM_AC3P_AD;
                #endif
            }
            else if ((stAudioStreamInfo.wAudType == E_AUDIOSTREAM_AAC) ||
                    (stAudioStreamInfo.wAudType == E_AUDIOSTREAM_MPEG4))
            {
                MApi_AUDIO_SetSystem(MSAPI_AUD_DVB2_AAC);
                #if ENABLE_PVR
                g_enCurrent_AudioDescriptorType = E_AUDIOSTREAM_AACP_AD;
                #endif
            }
#if ENABLE_PVR
            if (MApp_PVR_IsPlaybacking())
            {
                MApp_PVR_PlaybackAdAudioSelectLanguage(u8AudSelectedIndex);
            }
            else
#endif
            {
#if ENABLE_PVR
                g_u16Current_AudioDescriptorPID = stAudioStreamInfo.wAudPID;
#endif
                // start filter should be after than start audio decoder to prevent audio ES buffer overflow
                /* set audio PID & start filter */
                //printf("## Channel change, ad audio pid 0x%x, u8AdAudFid %bu\n", stAudioStreamInfo.wAudPID, u8AdAFid);
                msAPI_DMX_StartFilter(stAudioStreamInfo.wAudPID, MSAPI_DMX_FILTER_TYPE_AUDIO2, MApp_Dmx_GetFid(EN_AD_FID));
            }


            /* start ad audio decoder */
            //msAPI_AUD_AdjustAudioFactor(E_ADJUST_DTV_AUDIO_COMMAND, E_AUDIO_DVB2_COM_PLAY, 0);
            MApi_AUDIO_SetADOutputMode(AD_OUT_BOTH);//stGenSetting.g_SoundSetting.ADOutput);
            MApi_AUDIO_SetCommand(MSAPI_AUD_DVB2_DECCMD_PLAY);
        }
    }
}

void MApp_Audio_SearchAdAudio(void)
{
    MEMBER_SERVICETYPE bServiceType;
    AUD_INFO aAudioStreamInfo;
    AUD_INFO aPriAudioStreamInfo;
    WORD wCurrentPosition;
    U8 AudioLangNum;
    U8 i, j, k;
    //U8 u8ADIndex=0xFF,u8ADNum=0;

    bServiceType = msAPI_CM_GetCurrentServiceType();
    wCurrentPosition = msAPI_CM_GetCurrentPosition(bServiceType);
    AudioLangNum = msAPI_CM_GetAudioStreamCount(bServiceType, wCurrentPosition);

#if ENABLE_PVR
       if (MApp_PVR_IsPlaybacking())
       {
           g_u8AdAudSelected = MApp_PVR_PlaybackAudioGetLanguageSelection();
       }
       else
#endif
       {
           g_u8AdAudSelected = 0xFF;
       }

    if (!stGenSetting.g_SoundSetting.bEnableAD)
    {
        //printf("MApp_UiMenu_SearchAdAudio : AD is disabled\n");
        return;
    }

#if ENABLE_PVR
    if (MApp_PVR_IsPlaybacking())
    {
        MApp_PVR_PlaybackAudioGetStreamInfo(&aPriAudioStreamInfo, g_u8AudLangSelected);
    }
    else
#endif
    {
        // Get current main audio language
        msAPI_CM_GetAudioStreamInfo(bServiceType, wCurrentPosition, &aPriAudioStreamInfo, g_u8AudLangSelected);
    }

    if (AudioLangNum != 0)
    {
        for (i = 0; i < AudioLangNum; i++)
        {

#if ENABLE_PVR
            if (MApp_PVR_IsPlaybacking())
            {
                MApp_PVR_PlaybackAudioGetStreamInfo(&aAudioStreamInfo, i);
            }
            else
#endif
            {
                /* Get all audio information */
                msAPI_CM_GetAudioStreamInfo(bServiceType, wCurrentPosition, &aAudioStreamInfo, i);
            }

            //printf("bAudType = 0x%02bx\n", aAudioStreamInfo.aISOLangInfo[0].bAudType);

            for (j = 0; j < MAX_AUD_ISOLANG_NUM; j++)
            {
                if (aAudioStreamInfo.aISOLangInfo[j].bISOLangIndex == SI_LANGUAGE_NONE)
                {
                    break;
                }

                    /* find visual impaired audio stream */
                    if (aAudioStreamInfo.aISOLangInfo[j].bAudType == 0x03)
                    {
                        // find ad's language
                        for (k = 0; k < MAX_AUD_ISOLANG_NUM; k++)
                        {
                            //if (aAudioStreamInfo.aISOLangInfo[j].bISOLangIndex == LANGUAGE_NONE)
                            //    continue;

                            // ad's language is the same as primary audio's
                            if ((aAudioStreamInfo.aISOLangInfo[j].bISOLangIndex == aPriAudioStreamInfo.aISOLangInfo[k].bISOLangIndex)
                                || ((SI_LANGUAGE_ENGLISH == aAudioStreamInfo.aISOLangInfo[j].bISOLangIndex) &&(SI_LANGUAGE_UND== aPriAudioStreamInfo.aISOLangInfo[k].bISOLangIndex))
                                || ((SI_LANGUAGE_UND == aAudioStreamInfo.aISOLangInfo[j].bISOLangIndex) &&(SI_LANGUAGE_ENGLISH== aPriAudioStreamInfo.aISOLangInfo[k].bISOLangIndex)))
                            {
                                if (g_u8AudLangSelected == i)
                                {
                                    //printf("primary audio playing current found ad, find another\n");
                                    continue;
                                }

                                if (aPriAudioStreamInfo.wAudType != aAudioStreamInfo.wAudType)
                                {
                                    //printf("primary audio stream type %x differs from ad audio stream type %x\n", aPriAudioStreamInfo.wAudType, aAudioStreamInfo.wAudType);
                                    continue;
                                }

                                //printf("####found ad audio 0x%02bx####\n", i);
                                g_u8AdAudSelected = i;
                                if ((aAudioStreamInfo.aISOLangInfo[j].bISOLangIndex == aPriAudioStreamInfo.aISOLangInfo[k].bISOLangIndex))
                                {
                                    return;
                                }
                            }
                            /*else
                            {
                                u8ADIndex=i;
                                u8ADNum++;
                            }*/
                        }
                    }
                }
        }
    }
    /*if((AudioLangNum==2) &&  (u8ADNum==1))
    {
        g_u8AdAudSelected = u8ADIndex;
    }*/
        //printf("MApp_UiMenu_SearchAdAudio : No AD found\n");
}
#endif
#if ENABLE_SOUND_NEW_NONLINEAR
static WORD MApp_NonLinearCalculateTen(P_MS_USER_NONLINEAR_CURVE_TEN pNonLinearCurve, U8 AdjustValue)
{
    //dual direction
    WORD rValue,ucY0,ucY1,ucX0,ucX1;//,ucIntercept;
    WORD wDistanceOfX,wMaxValue;
    if (AdjustValue < 10)
    {
          ucY0 = pNonLinearCurve->u8OSD_0;
          ucY1 = pNonLinearCurve->u8OSD_10;
          ucX0 = 0;
          ucX1 = 10;
		  
		  ucY0=(AdjustValue-ucX0)*(ucY1-ucY0)/10 +ucY0;
		  wDistanceOfX =0x4A-(ucY0/8);
		  wMaxValue = TvVolumeFraTable[ucY0%8];
		  rValue=(((WORD)wDistanceOfX)<<8) |((WORD)wMaxValue);
    }
    else if (AdjustValue < 20)
    {
          ucY0 = pNonLinearCurve->u8OSD_10;
          ucY1 = pNonLinearCurve->u8OSD_20;
          ucX0 = 10;
          ucX1 = 20;
		  
		  ucY0=(AdjustValue-ucX0)*(ucY1-ucY0)/10 +ucY0;
		  wDistanceOfX =0x4A-(ucY0/8);
		  wMaxValue = TvVolumeFraTable[ucY0%8];
		  rValue=(((WORD)wDistanceOfX)<<8) |((WORD)wMaxValue);
    }
    else if (AdjustValue < 30)
    {
          ucY0 = pNonLinearCurve->u8OSD_20;
          ucY1 = pNonLinearCurve->u8OSD_30;
          ucX0 = 20;
          ucX1 = 30;
		  
		  ucY0=(AdjustValue-ucX0)*(ucY1-ucY0)/10 +ucY0;
		  wDistanceOfX =0x4A-(ucY0/8);
		  wMaxValue = TvVolumeFraTable[ucY0%8];
		  rValue=(((WORD)wDistanceOfX)<<8) |((WORD)wMaxValue);
    }
    else if (AdjustValue < 40)
    {
          ucY0 = pNonLinearCurve->u8OSD_30;
          ucY1 = pNonLinearCurve->u8OSD_40;
          ucX0 = 30;
          ucX1 = 40;
		  
		  ucY0=(AdjustValue-ucX0)*(ucY1-ucY0)/10 +ucY0;
		  wDistanceOfX =0x4A-(ucY0/8);
		  wMaxValue = TvVolumeFraTable[ucY0%8];
		  rValue=(((WORD)wDistanceOfX)<<8) |((WORD)wMaxValue);
    }
    else if (AdjustValue < 50)
    {
          ucY0 = pNonLinearCurve->u8OSD_40;
          ucY1 = pNonLinearCurve->u8OSD_50;
          ucX0 = 40;
          ucX1 = 50;
		  
		  ucY0=(AdjustValue-ucX0)*(ucY1-ucY0)/10 +ucY0;
		  wDistanceOfX =0x4A-(ucY0/8);
		  wMaxValue = TvVolumeFraTable[ucY0%8];
		  rValue=(((WORD)wDistanceOfX)<<8) |((WORD)wMaxValue);
    }
    else if (AdjustValue < 60)
    {
          ucY0 = pNonLinearCurve->u8OSD_50;
          ucY1 = pNonLinearCurve->u8OSD_60;
          ucX0 = 50;
          ucX1 = 60;
		  
		  ucY0=(AdjustValue-ucX0)*(ucY1-ucY0)/10 +ucY0;
		  wDistanceOfX =0x4A-(ucY0/8);
		  wMaxValue = TvVolumeFraTable[ucY0%8];
		  rValue=(((WORD)wDistanceOfX)<<8) |((WORD)wMaxValue);
    }
    else if (AdjustValue < 70)
    {
          ucY0 = pNonLinearCurve->u8OSD_60;
          ucY1 = pNonLinearCurve->u8OSD_70;
          ucX0 = 60;
          ucX1 = 70;
		  
		  ucY0=(AdjustValue-ucX0)*(ucY1-ucY0)/10 +ucY0;
		  wDistanceOfX =0x4A-(ucY0/8);
		  wMaxValue = TvVolumeFraTable[ucY0%8];
		  rValue=(((WORD)wDistanceOfX)<<8) |((WORD)wMaxValue);
    }
    else if (AdjustValue < 85)
    {
          ucY0 = pNonLinearCurve->u8OSD_70;
          ucY1 = pNonLinearCurve->u8OSD_85;
          ucX0 = 70;
          ucX1 = 85;
		  
		  ucY0=(AdjustValue-ucX0)*(ucY1-ucY0)/15 +ucY0;
		  wDistanceOfX =0x4A-(ucY0/8);
		  wMaxValue = TvVolumeFraTable[ucY0%8];
		  rValue=(((WORD)wDistanceOfX)<<8) |((WORD)wMaxValue);
    }
    else
    {
          ucY0 = pNonLinearCurve->u8OSD_85;
          ucY1 = pNonLinearCurve->u8OSD_100;
          ucX0 = 85;
          ucX1 = 100;
		  
		  ucY0=(AdjustValue-ucX0)*(ucY1-ucY0)/15 +ucY0;
		  wDistanceOfX =0x4A-(ucY0/8);
		  wMaxValue = TvVolumeFraTable[ucY0%8];
		  rValue=(((WORD)wDistanceOfX)<<8) |((WORD)wMaxValue);
    }
	
    return rValue;
}
#endif

//Set the sound mode. Depend on global variable stGenSetting.g_SoundSetting.SoundMode.
void MApp_Audio_AdjustSoundMode(void)
{
    MApi_AUDIO_EnableEQ(FALSE);
     MApi_AUDIO_EnableTone(TRUE);

#ifdef CUS_AUDIO_TREBLE_BASS_LIMIT
     MApi_AUDIO_SetBassLimit(stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].Bass);
     MApi_AUDIO_SetTrebleLimit(stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].Treble);
#else
     MApi_AUDIO_SetBass(stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].Bass);
     MApi_AUDIO_SetTreble(stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].Treble);
#endif

    if(stGenSetting.g_SoundSetting.SoundMode != SOUND_MODE_USER)
    {
        MApp_Aud_EQ_Init();		// CUS_XM Sea 20120725:
    }

}

/*
     The input must be the surround mode option. The format of surround mode option
     is in Analog_DataType.h.
*/
void MApp_Aud_SetSurroundMode(U8 u8SurroundMode)
{
       /*
            Before enabling any surround mode,
            msAPI_AUD_AdjustAudioFactor(E_ADJUST_SURROUND, TRUE , 0 )
            should be called
       */
    MS_U8 u8DecStatus = 0;
    u8DecStatus = 0;
    if(MApi_AUDIO_GetDecStatus() == MSAPI_AUD_DVB_DECCMD_PLAY)
    {
       MApi_AUDIO_SetCommand((En_DVB_decCmdType)MSAPI_AUD_STOP);
       msAPI_Timer_Delayms(10);
       u8DecStatus = 1;
    }

    switch ( u8SurroundMode & SURROUND_SYSTEM_TYPE_MASK )
    {
        case SURROUND_SYSTEM_OFF:
            /* Close all mode */
            MApi_AUDIO_EnableSurround(FALSE);
            MApi_AUDIO_ADVSOUND_ProcessEnable(ADV_NONE);
            break;
        case SURROUND_SYSTEM_SURROUNDMAX:
            MApi_AUDIO_EnableSurround(TRUE);
            MApi_AUDIO_ADVSOUND_ProcessEnable(ADV_NONE);
            break;
        case SURROUND_SYSTEM_SRS:
            MApi_AUDIO_EnableSurround(FALSE);
            MApi_AUDIO_ADVSOUND_ProcessEnable(SRS_TSXT);
            MApi_AUDIO_ADVSOUND_ProcessEnable(SRS_TSHD);
            break;
        case SURROUND_SYSTEM_VDS:
            MApi_AUDIO_EnableSurround(TRUE);
            MApi_AUDIO_SetAdvSndSys(SURROUND_SYSTEM_VDS);
            MApi_AUDIO_SetVDS(ENABLE);

            break;
        case SURROUND_SYSTEM_VSPK:
            MApi_AUDIO_EnableSurround(TRUE);
            MApi_AUDIO_SetAdvSndSys(SURROUND_SYSTEM_VSPK);
            MApi_AUDIO_SetVSPK(ENABLE);

            /* Check and Set Wind mode */
            MApi_AUDIO_VSPK_WMod( ( u8SurroundMode& WIDE_MODE_BIT ) ? WIDE_MODE : REFERENCE_MODE );
            /* Check and Set Surround mode */
            MApi_AUDIO_VSPK_SMod( (u8SurroundMode& SURROUND_MODE_BIT)? SURROUND_MODE_MUSIC : SURROUND_MODE_MOVIE  );
            break;
        case SURROUND_SYSTEM_BBE:
            MApi_AUDIO_EnableSurround(TRUE);
            MApi_AUDIO_SetAdvSndSys ( SURROUND_SYSTEM_BBE );
            MApi_AUDIO_SetBBE(ENABLE, ( u8SurroundMode & BBE_MODE_BIT)? VIVA_MODE : BBE_MODE  );
            break;
    }
    if(u8DecStatus == 1)
    {
        MApi_AUDIO_SetCommand((En_DVB_decCmdType)MSAPI_AUD_DVB_DECCMD_PLAY);
    }

}

//=======================================================
BOOLEAN MApp_Audio_GetNextAvailableMtsMode ( void )
{
    return FALSE;
}

//=======================================================
BOOLEAN MApp_Audio_SetMtsMode(void)
{
    return TRUE;
}

//=======================================================
void MApp_Aud_Banlace_Init(void)
{
    MApi_AUDIO_SetBalance(stGenSetting.g_SoundSetting.Balance );
}

void MApp_Aud_AutoVolume_Init(void)
{
    #ifdef CUS_AUDIO_AVL_ALWAYS_ON
    MApi_AUDIO_EnableAutoVolume(DEFAULT_AUTO_VOLUME);
    #else
    MApi_AUDIO_EnableAutoVolume((BOOLEAN)stGenSetting.g_SysSetting.fAutoVolume);
    #endif

    #ifdef CUS_AUDIO_DRC_ADJUST

    MApi_SND_ProcessEnable(Sound_ENABL_Type_DRC, ENABLE); // DRC		// CUS_XM Sea 20120709:

    if (stGenSetting.g_SysSetting.fAutoVolume)
    {
	    MApi_SND_SetParam1(Sound_SET_PARAM_Drc_Threshold, 0x1a, 0); // -8 dBFS		// CUS_XM Sea 20120725: 0X112D34
    }
    else
    {
	    MApi_SND_SetParam1(Sound_SET_PARAM_Drc_Threshold, 0x10, 0); // -8 dBFS		// CUS_XM Sea 20120725: 0X112D34
    }

    #endif

}

void MApp_Aud_PEQ_Init(void)
{
    if(ST_AUDIO_PEQ.u8_PEQOnOff)
    {
        msAPI_AUD_SetPEQ(0, ST_AUDIO_PEQ.u8_Gain1Value, (U8)(ST_AUDIO_PEQ.u16_Fo1Value/100), (U8)(ST_AUDIO_PEQ.u16_Fo1Value%100), ST_AUDIO_PEQ.u8_Q1Value);
        msAPI_AUD_SetPEQ(1, ST_AUDIO_PEQ.u8_Gain2Value, (U8)(ST_AUDIO_PEQ.u16_Fo2Value/100), (U8)(ST_AUDIO_PEQ.u16_Fo2Value%100), ST_AUDIO_PEQ.u8_Q2Value);
        msAPI_AUD_SetPEQ(2, ST_AUDIO_PEQ.u8_Gain3Value, (U8)(ST_AUDIO_PEQ.u16_Fo3Value/100), (U8)(ST_AUDIO_PEQ.u16_Fo3Value%100), ST_AUDIO_PEQ.u8_Q3Value);
    }
}
void MApp_Aud_EQ_Init(void)
{
    MApi_AUDIO_EnableEQ(TRUE);

	//printf("SoundMode[%bu].u8120HZ = %bu\n",stGenSetting.g_SoundSetting.SoundMode, stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].u8120HZ);
    MApi_AUDIO_SetEq(E_EQUALIZER_BAND_1, stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].u8120HZ);

	//printf("SoundMode[%bu].u8500HZ = %bu\n",stGenSetting.g_SoundSetting.SoundMode, stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].u8500HZ);
    MApi_AUDIO_SetEq(E_EQUALIZER_BAND_2, stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].u8500HZ);

	//printf("SoundMode[%bu].u8_1_dot_5_KHZ = %bu\n",stGenSetting.g_SoundSetting.SoundMode, stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].u8_1_dot_5_KHZ);
    MApi_AUDIO_SetEq(E_EQUALIZER_BAND_3, stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].u8_1_dot_5_KHZ);

	//printf("SoundMode[%bu].u8_5KHZ = %bu\n",stGenSetting.g_SoundSetting.SoundMode, stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].u8_5KHZ);
    MApi_AUDIO_SetEq(E_EQUALIZER_BAND_4, stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].u8_5KHZ);

	//printf("SoundMode[%bu].u810KHZ = %bu\n",stGenSetting.g_SoundSetting.SoundMode, stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].u810KHZ);
    MApi_AUDIO_SetEq(E_EQUALIZER_BAND_5, stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].u810KHZ);

}

#if (ENABLE_MADMONITOR)
/********************************************************************************/
///
/// MAD Monitor
///
/********************************************************************************/
void MApp_Audio_Monitor(void)
{
    #if 1

    printf("\r\nNOT USED FOR NOW !!\r\n\n");

    #else
    U8   u8CurrentAudioMain, u8CurrentAudioISR1;
    U8   u8AudioDecStatus;
    static U8  u8LastAudioMain = 1;
    static U8  u8LastAudioISR1 = 1;
    static U8  u8MainFailCount = 0;
    static U8  u8ISR1FailCount = 0;
    static U32 Waittime = 0;

    if (msAPI_Timer_DiffTimeFromNow(Waittime) < 100)
    {
        return;
    }
    Waittime = msAPI_Timer_GetTime0();

    u8CurrentAudioMain = MDrv_DecWhile_CNT();
    u8CurrentAudioISR1 = MDrv_DecTimer_CNT();
    u8AudioDecStatus = MApi_AUDIO_GetDecStatus();

    if (u8CurrentAudioMain - u8LastAudioMain ==0)
    {
        u8MainFailCount++;
    }
    else
    {
        u8MainFailCount=0;
    }

    if (u8CurrentAudioISR1 - u8LastAudioISR1 ==0)
    {
        u8ISR1FailCount++;
    }
    else
    {
        u8ISR1FailCount=0;
    }
    // [Don't touch] When "channel change" and "channel scan", we do not judge all counter.
    if (IsAnyTVSourceInUse() && ((MApi_AUDIO_GetDecStatus()&0x01)==0))
    {
        u8MainFailCount = 0;
        u8ISR1FailCount = 0;
    }

    if ((u8MainFailCount>=10)||(u8ISR1FailCount>=10))
    {
        u8MainFailCount = 0;
        u8ISR1FailCount = 0;

        // mute OP AMP, Mark temp, it should be recovery
        //MApi_AUDIO_SetMute( 0, AUD_DSP_MUTE);
        //msAPI_Timer_Delayms( 2500 );  // for de-pop, it is adjustable, this mute time depend on AMP ...


        MApi_AUDIO_SetCommand((En_DVB_decCmdType) MSAPI_AUD_STOP );

        if ( IsDTVInUse() )
        {
            /* stop audio filter */
            msAPI_DMX_Stop( *MApp_Dmx_GetFid(EN_AUDIO_FID));
        }

        MApi_AUDIO_RebootDsp(DSP_DEC);

        if ( IsDTVInUse() )
        {
            /* set audio PID & start filter */
            msAPI_DMX_StartFilter( u16AudioPID, MSAPI_DMX_FILTER_TYPE_AUDIO, MApp_Dmx_GetFid(EN_AUDIO_FID) );
            MApi_AUDIO_SetSystem((En_DVB_decSystemType)u16AudioType);
        }

        MApi_AUDIO_SetCommand( (En_DVB_decCmdType)u8AudioDecStatus );

        // NOTE: Please use the original mute/unmute status!!
        //MApi_AUDIO_SetMute( 0, AUD_DSP_UNMUTE);
    }

    // save status
    u8LastAudioMain = u8CurrentAudioMain;
    u8LastAudioISR1 = u8CurrentAudioISR1;
    #endif
}
#endif

/********************************************************************************/
///
/// MAD MApp_Audio_SetScartOutAudioEnableMute
///
/********************************************************************************/
void MApp_Audio_HDMI_MODE_CONFIG(HDMI_POLLING_STATUS_t enHDMIPollingStatus, HDMI_PACKET_INFO_t *enHDMIPackInfo)
{
        MS_U32 c_bit, l_bit;
        static AUDIO_HDMI_RX_TYPE prvHdmiRawType = HDMI_RX_Other;
        AUDIO_HDMI_RX_TYPE curHdmiRawType = MApi_AUDIO_HDMI_RX_GetNonPCM();

        c_bit = MApi_AUDIO_GetCommAudioInfo(Audio_Comm_infoType_getHDMI_CopyRight_C_Bit);
        l_bit = MApi_AUDIO_GetCommAudioInfo(Audio_Comm_infoType_getHDMI_CopyRight_L_Bit);
        MApi_AUDIO_SetCommAudioInfo(Audio_Comm_infoType_SetSCMS, c_bit, l_bit);

        if (MApi_AUDIO_HDMI_GetNonpcmFlag())
           enHDMIPackInfo->enPKT_Status.AudioNotPCM =1;
        else
           enHDMIPackInfo->enPKT_Status.AudioNotPCM =0;

        if (MApi_AUDIO_HDMI_GetNonpcmFlag())
        {  // non-PCM
            if( enHDMIPollingStatus.bIsHDMIMode \
                && ( (enHDMIPackInfo->enPKT_Status.AudioNotPCM != enHDMIPackInfo->enPKT_Status.PreAudiostatus)\
                        || (curHdmiRawType != prvHdmiRawType) )\
               )
            {
                enHDMIPackInfo->enPKT_Status.PreAudiostatus = enHDMIPackInfo->enPKT_Status.AudioNotPCM;
                if( enHDMIPackInfo->enPKT_Status.AudioNotPCM)
                {
                    //printf("\r\n  non pcm");
                    #if ENABLE_NEW_SPDIF_MUTE_METHOD
                    MApp_Audio_SPDIF_SetMute(TRUE, FORCE_MUTE);
                    #else
                    MApi_AUDIO_SPDIF_SetMute(TRUE);
                    #endif
                    //msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_BYSYNC_MUTEON, E_AUDIOMUTESOURCE_ACTIVESOURCE);
                    MApi_AUDIO_HDMI_SetNonpcm(TRUE);                // HDMI non-PCM setting
                    //MApi_AUDIO_SetNormalPath(AUDIO_PATH_MAIN_SPEAKER, AUDIO_DSP1_DVB_INPUT, AUDIO_OUTPUT_MAIN_SPEAKER);
                    MApi_AUDIO_SetNormalPath(AUDIO_PATH_LINEOUT, AUDIO_DSP1_HDMI_INPUT, AUDIO_OUTPUT_LINEOUT);
                    #if ENABLE_CUS_HEADPHONE_SPEC
                    MApi_AUDIO_SetNormalPath(AUDIO_PATH_HP, AUDIO_DSP1_HDMI_INPUT, AUDIO_OUTPUT_HP);
                    #endif
                    //MApi_AUDIO_SetNormalPath(AUDIO_PATH_SPDIF, AUDIO_SRC_INPUT, AUDIO_SPDIF_OUTPUT);
                    //MApi_AUDIO_SPDIF_SetMode(MSAPI_AUD_SPDIF_NONPCM);
                    MApi_AUDIO_SetAC3Info(Audio_AC3_infoType_DrcMode, LINE_MODE, 0);    //Line Mod
                    MApi_AUDIO_SetAC3Info(Audio_AC3_infoType_DownmixMode, DOLBY_DOWNMIX_MODE_LTRT, 0);  //LtRt
                    if(stGenSetting.g_SysSetting.fSPDIFMODE == 0)
                    {
                        MApi_AUDIO_SPDIF_SetMode(MSAPI_AUD_SPDIF_PCM);
                    }
                    #if ENABLE_CUS_SPDIF_MODE
                    else if(stGenSetting.g_SysSetting.fSPDIFMODE >1)
                    {
                        MApi_AUDIO_SPDIF_SetMode(MSAPI_AUD_SPDIF_PCM);
                    }
                    #endif
                    else
                    {
                        MApi_AUDIO_SPDIF_SetMode(MSAPI_AUD_SPDIF_NONPCM);
                    }
                    //msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_BYSYNC_MUTEOFF, E_AUDIOMUTESOURCE_ACTIVESOURCE);
                    MApi_AUDIO_SetCommand((En_DVB_decCmdType) MSAPI_AUD_PLAY );
                    #if ENABLE_NEW_SPDIF_MUTE_METHOD
                    MApp_Audio_SPDIF_SetMute(FALSE, FORCE_MUTE);
                    #else
                    MApi_AUDIO_SPDIF_SetMute(FALSE);
                    #endif
                }
            }
        }
        else
        {
            if( enHDMIPollingStatus.bIsHDMIMode && (enHDMIPackInfo->enPKT_Status.AudioNotPCM != enHDMIPackInfo->enPKT_Status.PreAudiostatus))
            {
                enHDMIPackInfo->enPKT_Status.PreAudiostatus = enHDMIPackInfo->enPKT_Status.AudioNotPCM;
                if( !enHDMIPackInfo->enPKT_Status.AudioNotPCM)
                {
                    //printf("\r\n  pcm");
                    #if ENABLE_NEW_SPDIF_MUTE_METHOD
                    MApp_Audio_SPDIF_SetMute(TRUE, FORCE_MUTE);
                    #else
                    MApi_AUDIO_SPDIF_SetMute(TRUE);
                    #endif
                    //msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_BYSYNC_MUTEON, E_AUDIOMUTESOURCE_ACTIVESOURCE);
                    MApi_AUDIO_HDMI_SetNonpcm(FALSE);                // HDMI non-PCM setting
                    //MApi_AUDIO_SetNormalPath(AUDIO_PATH_MAIN_SPEAKER, AUDIO_SOURCE_HDMI, AUDIO_OUTPUT_MAIN_SPEAKER);
                    MApi_AUDIO_SetNormalPath(AUDIO_PATH_LINEOUT, AUDIO_SOURCE_HDMI, AUDIO_OUTPUT_LINEOUT);
                    #if ENABLE_CUS_HEADPHONE_SPEC
                    MApi_AUDIO_SetNormalPath(AUDIO_PATH_HP, AUDIO_SOURCE_HDMI, AUDIO_OUTPUT_HP);
                    #endif
                    //MApi_AUDIO_SetNormalPath(AUDIO_PATH_SPDIF,        AUDIO_SOURCE_HDMI, AUDIO_SPDIF_OUTPUT);
                    MApi_AUDIO_SPDIF_SetMode(MSAPI_AUD_SPDIF_PCM);
                    //msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_BYSYNC_MUTEOFF, E_AUDIOMUTESOURCE_ACTIVESOURCE);
                    #if ENABLE_NEW_SPDIF_MUTE_METHOD
                    MApp_Audio_SPDIF_SetMute(FALSE, FORCE_MUTE);
                    #else
                    MApi_AUDIO_SPDIF_SetMute(FALSE);
                    #endif
                }
            }
        }

        prvHdmiRawType = curHdmiRawType;

}


//======================================================
// User can set different PreScale Gain here level in Mapp_audio.C
// Min. 0x00 --> 0 dBFS ; Max. 0x50 --> -40 dBFS
 // each step -0.5dB
 // Threshold=0x20 ==> -0.5dB * 0x20= -0.5dB * 32= -16dB
 //======================================================

void MApp_Audio_AdjustPreScale(U8 InputSource)
{
  switch(InputSource)
  {
    case E_AUDIOSOURCE_MPEG:		// CUS_XM Sea 20120625: USB
    case E_AUDIOSOURCE_AC3:
        //MApi_AUDIO_SetPreScale(AUDIO_PATH_MAIN_SPEAKER,Prescale_MainSpeaker_DTV);
        MApi_AUDIO_SetPreScale(AUDIO_PATH_MAIN_SPEAKER,stGenSetting.g_NonLinearCurveSetting.StorageSoundCurve.Prescale);
        MApi_AUDIO_SetPreScale(AUDIO_PATH_LINEOUT     ,Prescale_LineOut_DTV);
        #if ENABLE_CUS_HEADPHONE_SPEC
        MApi_AUDIO_SetPreScale(AUDIO_PATH_HP     ,Prescale_LineOut_DTV);
        #endif
        MApi_AUDIO_SetPreScale(AUDIO_PATH_SIFOUT      ,Prescale_SifOut_DTV);
        MApi_AUDIO_SetPreScale(AUDIO_PATH_SPDIF       ,Prescale_SpdifOut_DTV);
        break;

  case E_AUDIOSOURCE_HDMI:
    case E_AUDIOSOURCE_HDMI2:
    case E_AUDIOSOURCE_HDMI3:
        //MApi_AUDIO_SetPreScale(AUDIO_PATH_MAIN_SPEAKER,Prescale_MainSpeaker_HDMI);
        MApi_AUDIO_SetPreScale(AUDIO_PATH_MAIN_SPEAKER,stGenSetting.g_NonLinearCurveSetting.HDMISoundCurve.Prescale);
        MApi_AUDIO_SetPreScale(AUDIO_PATH_LINEOUT     ,Prescale_LineOut_HDMI);
        #if ENABLE_CUS_HEADPHONE_SPEC
        MApi_AUDIO_SetPreScale(AUDIO_PATH_HP     ,Prescale_LineOut_HDMI);
        #endif
        MApi_AUDIO_SetPreScale(AUDIO_PATH_SIFOUT      ,Prescale_SifOut_HDMI);
        MApi_AUDIO_SetPreScale(AUDIO_PATH_SPDIF       ,Prescale_SpdifOut_HDMI);
        break;

    case E_AUDIOSOURCE_ATV: 
	//MApi_AUDIO_SetPreScale(AUDIO_PATH_MAIN_SPEAKER,0xf3);//minglin1231
	    //MApi_AUDIO_SetPreScale(AUDIO_PATH_MAIN_SPEAKER,Prescale_MainSpeaker_ATV);
	    MApi_AUDIO_SetPreScale(AUDIO_PATH_MAIN_SPEAKER,stGenSetting.g_NonLinearCurveSetting.ATVSoundCurve.Prescale);
        MApi_AUDIO_SetPreScale(AUDIO_PATH_LINEOUT     ,Prescale_LineOut_ATV);
        #if ENABLE_CUS_HEADPHONE_SPEC
        MApi_AUDIO_SetPreScale(AUDIO_PATH_HP     ,Prescale_LineOut_ATV);
        #endif
        MApi_AUDIO_SetPreScale(AUDIO_PATH_SIFOUT      ,Prescale_SifOut_ATV);
        MApi_AUDIO_SetPreScale(AUDIO_PATH_SPDIF       ,Prescale_SpdifOut_ATV);
        break;

    case E_AUDIOSOURCE_CVBS1:
    case E_AUDIOSOURCE_CVBS2:
    case E_AUDIOSOURCE_SVIDEO1:
    case E_AUDIOSOURCE_SVIDEO2:
    case E_AUDIOSOURCE_SCART1:
    case E_AUDIOSOURCE_SCART2:
        //MApi_AUDIO_SetPreScale(AUDIO_PATH_MAIN_SPEAKER,Prescale_MainSpeaker_AV);
        MApi_AUDIO_SetPreScale(AUDIO_PATH_MAIN_SPEAKER,stGenSetting.g_NonLinearCurveSetting.AVSoundCurve.Prescale);
        MApi_AUDIO_SetPreScale(AUDIO_PATH_LINEOUT     ,Prescale_LineOut_AV);
        #if ENABLE_CUS_HEADPHONE_SPEC
        MApi_AUDIO_SetPreScale(AUDIO_PATH_HP     ,Prescale_LineOut_AV);
        #endif
        MApi_AUDIO_SetPreScale(AUDIO_PATH_SIFOUT      ,Prescale_SifOut_AV);
        MApi_AUDIO_SetPreScale(AUDIO_PATH_SPDIF       ,Prescale_SpdifOut_AV);
        break;


    case E_AUDIOSOURCE_YPbPr:		// CUS_XM Sea 20120625:
    case E_AUDIOSOURCE_YPbPr2:
        //MApi_AUDIO_SetPreScale(AUDIO_PATH_MAIN_SPEAKER,Prescale_MainSpeaker_YPBPR);
        MApi_AUDIO_SetPreScale(AUDIO_PATH_MAIN_SPEAKER,stGenSetting.g_NonLinearCurveSetting.YPbPrSoundCurve.Prescale);
        MApi_AUDIO_SetPreScale(AUDIO_PATH_LINEOUT     ,Prescale_LineOut_YPBPR);
        #if ENABLE_CUS_HEADPHONE_SPEC
        MApi_AUDIO_SetPreScale(AUDIO_PATH_HP     ,Prescale_LineOut_YPBPR);
        #endif
        MApi_AUDIO_SetPreScale(AUDIO_PATH_SIFOUT      ,Prescale_SifOut_YPBPR);
        MApi_AUDIO_SetPreScale(AUDIO_PATH_SPDIF       ,Prescale_SpdifOut_YPBPR);
        break;


  case E_AUDIOSOURCE_PC:
    case E_AUDIOSOURCE_DVI:
    case E_AUDIOSOURCE_DVI2:
    case E_AUDIOSOURCE_DVI3:
        //MApi_AUDIO_SetPreScale(AUDIO_PATH_MAIN_SPEAKER,Prescale_MainSpeaker_PC);
        MApi_AUDIO_SetPreScale(AUDIO_PATH_MAIN_SPEAKER,stGenSetting.g_NonLinearCurveSetting.PCSoundCurve.Prescale);
        MApi_AUDIO_SetPreScale(AUDIO_PATH_LINEOUT     ,Prescale_LineOut_PC);
        #if ENABLE_CUS_HEADPHONE_SPEC
        MApi_AUDIO_SetPreScale(AUDIO_PATH_HP     ,Prescale_LineOut_PC);
        #endif
        MApi_AUDIO_SetPreScale(AUDIO_PATH_SIFOUT      ,Prescale_SifOut_PC);
        MApi_AUDIO_SetPreScale(AUDIO_PATH_SPDIF       ,Prescale_SpdifOut_PC);

    default:

        break;
    }
}

//======================================================
// User can set different AVC threshold level in Mapp_audio.C
// Min. 0x00 --> 0 dBFS ; Max. 0x50 --> -40 dBFS
 // each step -0.5dB
 // Threshold=0x20 ==> -0.5dB * 0x20= -0.5dB * 32= -16dB
 //======================================================
void MApp_Audio_AdjustAVCThreshold(U8 InputSource)
{
    switch(InputSource)
    {
        case E_AUDIOSOURCE_MPEG:
        case E_AUDIOSOURCE_AC3:
        case E_AUDIOSOURCE_ATV:
        case E_AUDIOSOURCE_CVBS1:
        case E_AUDIOSOURCE_CVBS2:
        case E_AUDIOSOURCE_SVIDEO1:
        case E_AUDIOSOURCE_SVIDEO2:
        case E_AUDIOSOURCE_YPbPr:
        case E_AUDIOSOURCE_PC:
        case E_AUDIOSOURCE_HDMI:
            MApi_AUDIO_SetAvcThreshold(0x20);   //Output Clipping Level = -16 dBFS
            break;
        case E_AUDIOSOURCE_SCART1:
        case E_AUDIOSOURCE_SCART2:
            MApi_AUDIO_SetAvcThreshold(0x20);   //Output Clipping Level = -16 dBFS
            break;

        default:
        MApi_AUDIO_SetAvcThreshold(0x20);     //Output Clipping Level = -16 dBFS
            break;
    }
}

//******************************************************************************
//Function name:    MApp_Audio_AdjustMainVolume
//Return parameter: none
//Description:      Set main speaker volume. 0 ~ 100
//  [Doxygen]
/// Set main speaker volume . 0 ~ 100
/// @param BYTE VolumePercent \b IN  volume percentage 0 ~ 100
//******************************************************************************
#if ENABLE_SOUND_NEW_NONLINEAR
void MApp_Audio_AdjustMainVolume(BYTE VolumePercent)
{
    BYTE value1,value2;
    WORD wTmpVolume;
    if( VolumePercent > 100 )
        VolumePercent= 100;

#if (EAR_PHONE_POLLING && ENABLE_CUS_HEADPHONE_SPEC)
    if (GetEarphoneState() == EAR_PHONE_INSERTED)
    {
        VolumePercent = 0;
    }
#endif
    if(VolumePercent== 0)
    	{
        MApi_AUDIO_SetMute(AUDIO_PATH_MAIN_SPEAKER,TRUE);
		MApi_AUDIO_SetAbsoluteVolume(AUDIO_PATH_MAIN_SPEAKER,0x7F,0);
		return;
    	}
    else
        MApi_AUDIO_SetMute(AUDIO_PATH_MAIN_SPEAKER,FALSE);

wTmpVolume = MApp_NonLinearCalculateTen(MApp_GetNonLinearCurveTen(NONLINEAR_CURVE_VOLUME),VolumePercent);
		 if(IsATVInUse())
			 {
			 MApi_AUDIO_SetAvcThreshold(stGenSetting.g_NonLinearCurveSetting.ATVSoundCurve.u8AVC_Value);
			 MApi_AUDIO_SetPreScale(AUDIO_PATH_MAIN_SPEAKER,stGenSetting.g_NonLinearCurveSetting.ATVSoundCurve.Prescale);
			 }
		 else if(IsSVInUse())
			{
			 MApi_AUDIO_SetAvcThreshold(stGenSetting.g_NonLinearCurveSetting.SVSoundCurve.u8AVC_Value);
			 MApi_AUDIO_SetPreScale(AUDIO_PATH_MAIN_SPEAKER,stGenSetting.g_NonLinearCurveSetting.SVSoundCurve.Prescale);
			}
		 else if(IsYPbPrInUse())
			{
			 MApi_AUDIO_SetAvcThreshold(stGenSetting.g_NonLinearCurveSetting.YPbPrSoundCurve.u8AVC_Value);
			 MApi_AUDIO_SetPreScale(AUDIO_PATH_MAIN_SPEAKER,stGenSetting.g_NonLinearCurveSetting.YPbPrSoundCurve.Prescale);
			}
		 else if(IsHDMIInUse())
			{
			 MApi_AUDIO_SetAvcThreshold(stGenSetting.g_NonLinearCurveSetting.HDMISoundCurve.u8AVC_Value);
			 MApi_AUDIO_SetPreScale(AUDIO_PATH_MAIN_SPEAKER,stGenSetting.g_NonLinearCurveSetting.HDMISoundCurve.Prescale);
			}
		 else if(IsVgaInUse())
			{
			 MApi_AUDIO_SetAvcThreshold(stGenSetting.g_NonLinearCurveSetting.PCSoundCurve.u8AVC_Value);
			 MApi_AUDIO_SetPreScale(AUDIO_PATH_MAIN_SPEAKER,stGenSetting.g_NonLinearCurveSetting.PCSoundCurve.Prescale);
			}
		 else if(IsStorageInUse())
			{
			 MApi_AUDIO_SetAvcThreshold(stGenSetting.g_NonLinearCurveSetting.StorageSoundCurve.u8AVC_Value);
			 MApi_AUDIO_SetPreScale(AUDIO_PATH_MAIN_SPEAKER,stGenSetting.g_NonLinearCurveSetting.StorageSoundCurve.Prescale);
			}
		 else
			{
			 MApi_AUDIO_SetAvcThreshold(stGenSetting.g_NonLinearCurveSetting.AVSoundCurve.u8AVC_Value);
			 MApi_AUDIO_SetPreScale(AUDIO_PATH_MAIN_SPEAKER,stGenSetting.g_NonLinearCurveSetting.AVSoundCurve.Prescale);
			}


value1 = (BYTE)((wTmpVolume>>8)&0xFF);
value2 = (BYTE)(wTmpVolume&0xFF);		
//printf("\r\n--value1=%x,--value2=%x--",value1,value2);
    MApi_AUDIO_SetAbsoluteVolume(AUDIO_PATH_MAIN_SPEAKER,value1,value2);
}

#else
void MApp_Audio_AdjustMainVolume(BYTE VolumePercent)
{
    BYTE value1,value2;

    if( VolumePercent > 100 )
        VolumePercent= 100;

#if (EAR_PHONE_POLLING && ENABLE_CUS_HEADPHONE_SPEC)
    if (GetEarphoneState() == EAR_PHONE_INSERTED)
    {
        VolumePercent = 0;
    }
#endif
    if(VolumePercent== 0)
        MApi_AUDIO_SetMute(AUDIO_PATH_MAIN_SPEAKER,TRUE);
    else
        MApi_AUDIO_SetMute(AUDIO_PATH_MAIN_SPEAKER,FALSE);

#if BOE_AVC_PRECALE_FUC//minglin1213
	VolumePercent = MApp_NonLinearVOLCalculate(MApp_GetNonLinearVOLCurve(NONLINEAR_VOLCURVE_VOLUME),VolumePercent);
	printf("\r\nVolumePercent=%x",VolumePercent);
	if(IsATVInUse())
	{
		MApi_AUDIO_SetAvcThreshold(stGenSetting.g_NonLinearVOLCurveSetting.ATVSoundCurve.u8AVC_Value);
		MApi_AUDIO_SetPreScale(AUDIO_PATH_MAIN_SPEAKER,stGenSetting.g_NonLinearVOLCurveSetting.ATVSoundCurve.Prescale);
	}
	else if(IsAVInUse())
	{
		MApi_AUDIO_SetAvcThreshold(stGenSetting.g_NonLinearVOLCurveSetting.AVSoundCurve.u8AVC_Value);
		MApi_AUDIO_SetPreScale(AUDIO_PATH_MAIN_SPEAKER,stGenSetting.g_NonLinearVOLCurveSetting.AVSoundCurve.Prescale);
	}
	else if(IsYPbPrInUse())
	{
		MApi_AUDIO_SetAvcThreshold(stGenSetting.g_NonLinearVOLCurveSetting.YPbPrSoundCurve.u8AVC_Value);
		MApi_AUDIO_SetPreScale(AUDIO_PATH_MAIN_SPEAKER,stGenSetting.g_NonLinearVOLCurveSetting.YPbPrSoundCurve.Prescale);
	}
	else if(IsHDMIInUse())
	{
		MApi_AUDIO_SetAvcThreshold(stGenSetting.g_NonLinearVOLCurveSetting.HDMISoundCurve.u8AVC_Value);
		MApi_AUDIO_SetPreScale(AUDIO_PATH_MAIN_SPEAKER,stGenSetting.g_NonLinearVOLCurveSetting.HDMISoundCurve.Prescale);
	}
	else if(IsVgaInUse())
	{
		MApi_AUDIO_SetAvcThreshold(stGenSetting.g_NonLinearVOLCurveSetting.VGASoundCurve.u8AVC_Value);
		MApi_AUDIO_SetPreScale(AUDIO_PATH_MAIN_SPEAKER,stGenSetting.g_NonLinearVOLCurveSetting.VGASoundCurve.Prescale);
	}
	else if(IsStorageInUse())
	{
		//printf("stGenSetting.g_NonLinearVOLCurveSetting.StorageSoundCurve.u8AVC_Value===%d\n",stGenSetting.g_NonLinearVOLCurveSetting.StorageSoundCurve.u8AVC_Value);
		//printf("stGenSetting.g_NonLinearVOLCurveSetting.StorageSoundCurve.Prescale===%d\n",stGenSetting.g_NonLinearVOLCurveSetting.StorageSoundCurve.Prescale);		
		MApi_AUDIO_SetAvcThreshold(stGenSetting.g_NonLinearVOLCurveSetting.StorageSoundCurve.u8AVC_Value);
		MApi_AUDIO_SetPreScale(AUDIO_PATH_MAIN_SPEAKER,stGenSetting.g_NonLinearVOLCurveSetting.StorageSoundCurve.Prescale);
	}
	else
	{
		MApi_AUDIO_SetAvcThreshold(stGenSetting.g_NonLinearVOLCurveSetting.AVSoundCurve.u8AVC_Value);
		MApi_AUDIO_SetPreScale(AUDIO_PATH_MAIN_SPEAKER,stGenSetting.g_NonLinearVOLCurveSetting.AVSoundCurve.Prescale);
	}
#else
#if(BOE_VOLUME_CURVE)
    VolumePercent = MApp_NonLinearVOLCalculate(MApp_GetNonLinearVOLCurve(NONLINEAR_VOLCURVE_VOLUME),VolumePercent);
#else
#if(ENABLE_SOUND_NONLINEAR_CURVE)
    VolumePercent = MApp_NonLinearCalculate(MApp_GetNonLinearCurve(NONLINEAR_CURVE_VOLUME),VolumePercent);
#endif
#endif
#endif


#if 0//(ENABLE_SOUND_NONLINEAR_CURVE)
    VolumePercent = MApp_NonLinearCalculate(MApp_GetNonLinearCurve(NONLINEAR_CURVE_VOLUME),VolumePercent);
#endif

    value1 = TvVolumeIntTable[VolumePercent];
    value2 = TvVolumeFraTable[VolumePercent] >> 4;		// CUS_XM Sea 20120709: �ײ�������4λ������������4λ��
    MApi_AUDIO_SetAbsoluteVolume(AUDIO_PATH_MAIN_SPEAKER,value1,value2);
}
#endif
#if ENABLE_CUS_HEADPHONE_SPEC
#if ENABLE_SOUND_NONLINEAR_CURVE_TEN
void MApp_Audio_AdjustHeadPhoneVolume(BYTE VolumePercent)
{
    BYTE value1,value2;
    WORD wTmpVolume;

    if( VolumePercent > 100 )
        VolumePercent= 100;

#if (EAR_PHONE_POLLING)
    if (GetEarphoneState() == EAR_PHONE_INSERTED)
#endif
    {
        //printf("Set HP volume :VolumePercent[%bu] \n ",VolumePercent);/*Creass.liu at 2012-07-25*/
        #if(ENABLE_SOUND_NONLINEAR_CURVE)	
		wTmpVolume = MApp_NonLinearCalculateTen(MApp_GetNonLinearCurveTen(NONLINEAR_CURVE_VOLUME),VolumePercent);
        #endif
        MApi_AUDIO_SetMute(AUDIO_PATH_HP,FALSE);
		
		value1 = (BYTE)((wTmpVolume>>8)&0xFF);
		value2 = (BYTE)(wTmpVolume&0xFF);		
        MApi_AUDIO_SetAbsoluteVolume(AUDIO_PATH_HP,value1,value2);
    }
}
#else
ROM BYTE TvHeadphoneVolumeIntTable[] =		// CUS_XM Sea 20120725: 0X112D2C
{
	0x7F,
	0x38, 0x37, 0x36, 0x35, 0x34, 0x33, 0x32, 0x31, 0x30, 0x2F,
	0x2E, 0x2D, 0x2C, 0x2B, 0x2A, 0x29, 0x28, 0x27, 0x26, 0x24,
	0x24, 0x24, 0x24, 0x23, 0x23, 0x23, 0x22, 0x22, 0x22, 0x21,
	0x21, 0x21, 0x21, 0x20, 0x20, 0x20, 0x1F, 0x1F, 0x1F, 0x1E,
	0x1E, 0x1E, 0x1E, 0x1D, 0x1D, 0x1D, 0x1C, 0x1C, 0x1C, 0x1B,
	0x1B, 0x1B, 0x1B, 0x1A, 0x1A, 0x1A, 0x19, 0x19, 0x19, 0x18,
	0x18, 0x18, 0x18, 0x17, 0x17, 0x17, 0x16, 0x16, 0x16, 0x15,
	0x15, 0x15, 0x15, 0x14, 0x14, 0x14, 0x13, 0x13, 0x13, 0x12,
	0x12, 0x12, 0x12, 0x11, 0x11, 0x11, 0x10, 0x10, 0x10, 0x0F,
	0x0F, 0x0F, 0x0F, 0x0E, 0x0E, 0x0E, 0x0D, 0x0D, 0x0C, 0x0C,

};
void MApp_Audio_AdjustHeadPhoneVolume(BYTE VolumePercent)
{
    BYTE value1,value2;

    if( VolumePercent > 100 )
        VolumePercent= 100;

#if (EAR_PHONE_POLLING)
    if (GetEarphoneState() == EAR_PHONE_INSERTED)
#endif
    {
        //printf("Set HP volume :VolumePercent[%bu] \n ",VolumePercent);/*Creass.liu at 2012-07-25*/
        #if(ENABLE_SOUND_NONLINEAR_CURVE)
        VolumePercent = MApp_NonLinearCalculate(MApp_GetNonLinearCurve(NONLINEAR_CURVE_VOLUME),VolumePercent);
        #endif
        MApi_AUDIO_SetMute(AUDIO_PATH_HP,FALSE);
        value1 = TvHeadphoneVolumeIntTable[VolumePercent];
        value2 = 0;
        MApi_AUDIO_SetAbsoluteVolume(AUDIO_PATH_HP,value1,value2);
    }
}
#endif
#endif

#if ENABLE_CUS_AUDIO_DELAY
void MApp_Aud_SetBufferProcess ( U8 DelayTime )
{
    if(DelayTime < 20)
        DelayTime = 20;
    if(DelayTime >200)
        DelayTime = 200;
    MApi_AUDIO_SetBufferProcess(DelayTime);
}
#endif

#if ENABLE_NEW_SPDIF_MUTE_METHOD
static BOOLEAN bSPDIFMuteStatus = FALSE;
void MApp_Audio_SPDIF_SetMute(MS_BOOL bMute_en,MS_BOOL bForceMute)
{
    if(bForceMute)
    {
        bSPDIFMuteStatus = bMute_en;
        //printf("\r\n-1->MApi_AUDIO_SPDIF_SetMute[%bu]",bMute_en);
        MApi_AUDIO_SPDIF_SetMute(bMute_en);
    }
    else
    {
        if(bSPDIFMuteStatus != bMute_en)
        {
            bSPDIFMuteStatus = bMute_en;
            //printf("\r\n-2->MApi_AUDIO_SPDIF_SetMute[%bu]",bMute_en);
            MApi_AUDIO_SPDIF_SetMute(bMute_en);
        }
    }
}
#endif

MS_BOOL MApp_AUDIO_IsSifSoundModeExist(EN_SOUND_MTS_TYPE enSifSoundMode)
{
    U8 bCurrentSIFMode;
    if(!IsATVInUse())
    {
        return FALSE;
    }
    bCurrentSIFMode = MApi_AUDIO_SIF_GetSoundMode();
    switch ( enSifSoundMode )
    {
        case SOUND_MTS_MONO:
            if((bCurrentSIFMode ==E_AUDIOMODE_MONO)||(bCurrentSIFMode ==E_AUDIOMODE_K_STEREO)||
                (bCurrentSIFMode==E_AUDIOMODE_MONO_SAP)||(bCurrentSIFMode==E_AUDIOMODE_STEREO_SAP)||(bCurrentSIFMode==E_AUDIOMODE_DUAL_A))
            {
                return TRUE;
            }
            break;

        case SOUND_MTS_STEREO:
            if((bCurrentSIFMode ==E_AUDIOMODE_K_STEREO)
                ||(bCurrentSIFMode==E_AUDIOMODE_G_STEREO)
                ||(bCurrentSIFMode==E_AUDIOMODE_DUAL_A)
                ||(bCurrentSIFMode==E_AUDIOMODE_DUAL_B)
                ||(bCurrentSIFMode==E_AUDIOMODE_DUAL_AB)
                ||(bCurrentSIFMode==E_AUDIOMODE_NICAM_STEREO)
                ||(bCurrentSIFMode==E_AUDIOMODE_NICAM_DUAL_A)
                ||(bCurrentSIFMode==E_AUDIOMODE_NICAM_DUAL_B)
                ||(bCurrentSIFMode==E_AUDIOMODE_NICAM_DUAL_AB)
                ||(bCurrentSIFMode==E_AUDIOMODE_NICAM_MONO)
            )
            {
                return TRUE;
            }
            break;
#if(CUS_OSD_STYLE==CUS_OSD_EBONY_ONEUX_LIKE)
        case SOUND_MTS_I:
            if((bCurrentSIFMode==E_AUDIOMODE_DUAL_A)
                ||(bCurrentSIFMode==E_AUDIOMODE_DUAL_B)
                ||(bCurrentSIFMode==E_AUDIOMODE_DUAL_AB)
                ||(bCurrentSIFMode==E_AUDIOMODE_NICAM_DUAL_A)
                ||(bCurrentSIFMode==E_AUDIOMODE_NICAM_DUAL_B)
                ||(bCurrentSIFMode==E_AUDIOMODE_NICAM_DUAL_AB)
            )
            {
                return TRUE;
            }
            break;
#endif


        #if (TV_SYSTEM == TV_NTSC)
        case SOUND_MTS_SAP:
            if((bCurrentSIFMode==E_AUDIOMODE_MONO_SAP)||(bCurrentSIFMode==E_AUDIOMODE_STEREO_SAP)||(bCurrentSIFMode==E_AUDIOMODE_DUAL_A))
            {
                return TRUE;
            }
            break;
        #endif

        default:
            return FALSE;
    }
    return FALSE;
}
#if  EAR_PHONE_POLLING

#define EAR_PHONE_STABLE_CNT      100

static U8 u8EarphoneStableCnt=0;
static U8 u8PreEarphoneState=0;
#define Audio_PhoneDect_ON()            FALSE //mdrv_gpio_get_level( HEADPHONE_DETECT_PIN)  //wchp++100601


/******************************************************************************
* Function	: ()
* Description	:
HI:   Earphone in, Mute Main Audio output
LOW: Earphone out, Enable Main Audio output
* Input		:
* Output		:
* Return		:
******************************************************************************/

BOOLEAN GetEarphoneState(void)
{
    U8 u8EarphoneState;

    u8EarphoneState = Audio_PhoneDect_ON();

    if(u8EarphoneState != u8PreEarphoneState)
    {
        u8EarphoneStableCnt = 0;
        u8PreEarphoneState = u8EarphoneState;
        //printf("\r\nu8EarphoneStableCnt clear!");
    }
    else if(u8EarphoneStableCnt<EAR_PHONE_STABLE_CNT)
    {
        u8EarphoneStableCnt++;
        //printf("\r\nu8EarphoneStableCnt = %bu",u8EarphoneStableCnt);
    }

    if(u8EarphoneStableCnt >= EAR_PHONE_STABLE_CNT )
    {
        return (BOOLEAN)((u8EarphoneState)? EAR_PHONE_INSERTED:EAR_PHONE_NULL);
    }
    else
    {
        return PreEarphoneState;
    }

}

void EarPhone_OFF(void)
{
	//printf("EarPhone_OFF \n");
	#if ENABLE_CUS_HEADPHONE_SPEC
    MW_AUD_SetSoundMute(SOUND_MUTE_SPEAKER, E_MUTE_OFF);
    msAPI_AUD_AdjustAudioFactor(E_ADJUST_VOLUME, stGenSetting.g_SoundSetting.Volume, 0);
    #else
	msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_BYUSER_MUTEOFF, E_AUDIOMUTESOURCE_ACTIVESOURCE);
    #endif

}


void EarPhone_ON(void)
{
	//printf("EarPhone_ON \n");
	#if ENABLE_CUS_HEADPHONE_SPEC
    MW_AUD_SetSoundMute(SOUND_MUTE_SPEAKER, E_MUTE_ON);
    msAPI_AUD_AdjustAudioFactor(E_ADJUST_VOLUME, stGenSetting.g_SoundSetting.Volume, 0);
    #else
	msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_BYUSER_MUTEON, E_AUDIOMUTESOURCE_ACTIVESOURCE);
    #endif

}


#endif


#undef _MAPP_AUDIO_C
