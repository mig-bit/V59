////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (MStar Confidential Information) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#define MAPP_ZUI_ACTINSTALL_C
#define _ZUI_INTERNAL_INSIDE_ //NOTE: for ZUI internal


//-------------------------------------------------------------------------------------------------
// Include Files
//-------------------------------------------------------------------------------------------------
#include "Board.h"
#include "datatype.h"
#include "MsCommon.h"
#include "apiXC.h"
#include "apiXC_Adc.h"
#include "apiXC_Sys.h"
#include "msAPI_Global.h"
#include "msAPI_VD.h"
#include "MApp_ZUI_Main.h"
#include "MApp_ZUI_APIcommon.h"
#include "MApp_ZUI_APIstrings.h"
#include "MApp_ZUI_APIwindow.h"
#include "ZUI_tables_h.inl"
#include "MApp_ZUI_APIgdi.h"
#include "MApp_ZUI_APIcontrols.h"
#include "MApp_GlobalSettingSt.h"
#include "MApp_ZUI_ACTmainpage.h"
#include "MApp_ZUI_ACTeffect.h"
#include "MApp_ZUI_ACTglobal.h"
#include "OSDcp_String_EnumIndex.h"
#include "ZUI_exefunc.h"

#include "MApp_Install_Main.h"
#include "MApp_GlobalSettingSt.h"
#include "MApp_ZUI_ACTmenufunc.h"
#include "MApp_ZUI_ACTinstall.h"

#include "MApp_GlobalFunction.h"
#include "msAPI_audio.h"
#include "MApp_Scaler.h"
#include "MApp_SaveData.h"
#if  ENABLE_SBTVD_BRAZIL_APP
#include "MApp_ChannelChange.h"
#include "MApp_InputSource.h"
#endif
#if (ENABLE_DTV)
#include "mapp_demux.h"
#endif

#include "MApp_UiMenuDef.h"
#if DVB_C_ENABLE
#include "MApp_TopStateMachine.h"
#endif
/////////////////////////////////////////////////////////////////////

extern EN_INSTALL_STATE enInstallGuideState;
extern EN_OSD_TUNE_TYPE_SETTING eTuneType;

static EN_INSTALL_STATE _enTargetInstallState;
static BOOLEAN _InstallScanState;

EN_INSTALL_GUIDE_PAGE enInstallGuidePage = PAGE_INSTALL_OSD_LANGUAGE;

#if ENABLE_SBTVD_BRAZIL_APP
extern E_ANTENNA_SOURCE_TYPE enLastWatchAntennaType;
#endif

extern BOOLEAN _MApp_ZUI_API_AllocateVarData(void);
void MApp_ZUI_ACT_Set_InstallGuidePage(EN_INSTALL_GUIDE_PAGE enPageIndex)
{
	enInstallGuidePage = enPageIndex;
}

EN_INSTALL_GUIDE_PAGE MApp_ZUI_ACT_Get_InstallGuidePage(void)
{
	return enInstallGuidePage;
}

//NOTE: when we are selecting country, don't modify the real one!!
EN_OSD_COUNTRY_SETTING _eTempCountry;

U8 MApp_ZUI_ACT_Install_GetOsdLanguageIndex(void)
{
    return GET_OSD_MENU_LANGUAGE_DTG();
}

U8 MApp_ZUI_ACT_Install_GetTuningMenuCountryIndex(void)
{
    return _eTempCountry;
}

void MApp_ZUI_ACT_Install_SetOsdLanguageIndex(U8 u8Index)
{
    SET_OSD_MENU_LANGUAGE((EN_LANGUAGE)u8Index);
    MApp_ZUI_API_InvalidateAllSuccessors(HWND_INSTALL_MAIN_PAGE);
}

void MApp_ZUI_ACT_Install_SetTuningMenuCountryIndex( U8 u8Index )
{
    _eTempCountry = (EN_OSD_COUNTRY_SETTING)u8Index;
    MApp_ZUI_API_InvalidateAllSuccessors(HWND_INSTALL_MAIN_PAGE);
}

LPTSTR MApp_ZUI_ACT_Install_GetLanguageStringByIndex(U8 u8Index)
{
    U16 u16TempID = Empty;
    if(u8Index <= LANGUAGE_MENU_MAX)
    {
        u16TempID = _MApp_ZUI_ACT_GetLanguageStringID((EN_LANGUAGE)u8Index, FALSE);
        if (u16TempID != Empty)
            return MApp_ZUI_API_GetString(u16TempID);
    }
    return 0; //for empty string....
}

LPTSTR MApp_ZUI_ACT_Install_GetCountryStringIDByIndex(U8 u8Index)
{
    U16 u16TempID = Empty;
    if(u8Index < OSD_COUNTRY_NUMS)
        u16TempID = _MApp_ZUI_ACT_GetCountryStringID((EN_OSD_COUNTRY_SETTING)u8Index );
    if (u16TempID != Empty)
        return MApp_ZUI_API_GetString(u16TempID);

    return 0; //for empty string....
}

void MApp_ZUI_ACT_AppShowInstallGuide(void)
{
    HWND wnd;
    RECT rect;
    E_OSD_ID osd_id = E_OSD_INSTALL_GUIDE;

    g_GUI_WindowList = GetWindowListOfOsdTable(osd_id);
    g_GUI_WinDrawStyleList = GetWindowStyleOfOsdTable(osd_id);
    g_GUI_WindowPositionList = GetWindowPositionOfOsdTable(osd_id);
#if ZUI_ENABLE_ALPHATABLE
    g_GUI_WinAlphaDataList = GetWindowAlphaDataOfOsdTable(osd_id);
#endif
    HWND_MAX = GetWndMaxOfOsdTable(osd_id);
    OSDPAGE_BLENDING_ENABLE = IsBlendingEnabledOfOsdTable(osd_id);
    OSDPAGE_BLENDING_VALUE = GetBlendingValueOfOsdTable(osd_id);

    if (!_MApp_ZUI_API_AllocateVarData())
    {
        ZUI_DBG_FAIL(printf("[ZUI]ALLOC\n"));
        ABORT();
        return;
    }

    RECT_SET(rect,
        ZUI_INSTALL_GUIDE_XSTART, ZUI_INSTALL_GUIDE_YSTART,
        ZUI_INSTALL_GUIDE_WIDTH, ZUI_INSTALL_GUIDE_HEIGHT);

    if (!MApp_ZUI_API_InitGDI(&rect))
    {
        ZUI_DBG_FAIL(printf("[ZUI]GDIINIT\n"));
        ABORT();
        return;
    }

    for (wnd = 0; wnd < HWND_MAX; wnd++)
    {
        //printf("create msg: %lu\n", (U32)wnd);
        MApp_ZUI_API_SendMessage(wnd, MSG_CREATE, 0);
    }

    _eTempCountry = OSD_COUNTRY_SETTING; //initial temp country

#if 1
MApp_ZUI_ACT_InstallPageSelect(1);
#else
MApp_ZUI_API_ShowWindow(HWND_MAINFRAME, SW_SHOW);

#if 0 //ENABLE_SBTVD_BRAZIL_APP
    MApp_ZUI_API_ShowWindow(HWND_INSTALL_MAIN_OSD_LANGUAGE, SW_HIDE);
    MApp_ZUI_API_ShowWindow(HWND_INSTALL_MAIN_COUNTRY, SW_HIDE);
    MApp_ZUI_API_SetFocus(HWND_INSTALL_MAIN_AUTO_TUNE);
#else
    MApp_ZUI_API_ShowWindow(HWND_INSTALL_MAIN_TEXT_1, SW_HIDE);
    MApp_ZUI_API_ShowWindow(HWND_INSTALL_MAIN_TEXT_2, SW_HIDE);
    //MApp_ZUI_API_SetFocus(HWND_INSTALL_MAIN_OSD_LANGUAGE);
#endif
    if( MApp_ZUI_ACT_Get_InstallGuidePage() == PAGE_INSTALL_OSD_LANGUAGE )
    {
        MApp_ZUI_CTL_Grid_SetIndex(HWND_INSTALL_MAIN_PAGE_GRID, MApp_ZUI_ACT_Install_GetOsdLanguageIndex, MApp_ZUI_ACT_Install_SetOsdLanguageIndex, LANGUAGE_MENU_MIN, LANGUAGE_MENU_MAX);
        MApp_ZUI_CTL_Grid_SetFnGetTextByIndex(HWND_INSTALL_MAIN_PAGE_GRID, MApp_ZUI_ACT_Install_GetLanguageStringByIndex);
    }
    else
    {
        MApp_ZUI_CTL_Grid_SetIndex(HWND_INSTALL_MAIN_PAGE_GRID, MApp_ZUI_ACT_Install_GetTuningMenuCountryIndex, MApp_ZUI_ACT_Install_SetTuningMenuCountryIndex, OSD_COUNTRY_AUSTRALIA, OSD_COUNTRY_NUMS-1);
        MApp_ZUI_CTL_Grid_SetFnGetTextByIndex(HWND_INSTALL_MAIN_PAGE_GRID, MApp_ZUI_ACT_Install_GetCountryStringIDByIndex);
    }
    MApp_ZUI_API_SetFocus(HWND_INSTALL_MAIN_PAGE_GRID);

    //MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_OPEN, E_ZUI_STATE_RUNNING);
#endif
}


//////////////////////////////////////////////////////////
// Key Handler

typedef struct _MENU_KEY2BTN_STRUCT
{
    VIRTUAL_KEY_CODE key;
    HWND hwnd;
} MENU_KEY2BTN_STRUCT;
extern void MApp_ATV_ExitATVScanPause2ScanEnd(void);

BOOLEAN MApp_ZUI_ACT_HandleInstallGuideKey(VIRTUAL_KEY_CODE key)
{
    //note: this function will be called in running state

    //reset timer if any key
    MApp_ZUI_API_ResetTimer(HWND_INSTALL_BACKGROUND, 0);

    /*//show click animation
    {
        static  MENU_KEY2BTN_STRUCT _ZUI_TBLSEG _key2btn[] =
        {
            {VK_SELECT, HWND_INSTALL_BOTTOM_HALF_OK_BG},
            {VK_EXIT, HWND_INSTALL_BOTTOM_HALF_EXIT_BG},
            {VK_UP, HWND_INSTALL_BOTTOM_HALF_UP_ARROW},
            {VK_DOWN, HWND_INSTALL_BOTTOM_HALF_DOWN_ARROW},
            {VK_LEFT, HWND_INSTALL_BOTTOM_HALF_LEFT_ARROW},
            {VK_RIGHT, HWND_INSTALL_BOTTOM_HALF_RIGHT_ARROW},
        };
        U8 i;

        for (i = 0; i < COUNTOF(_key2btn); i++)
        {
            if (_key2btn[i].key == key)
            {
                MApp_ZUI_API_SetTimer(_key2btn[i].hwnd, 0, BUTTONANICLICK_PERIOD);
                MApp_ZUI_API_InvalidateWindow(_key2btn[i].hwnd);
                break;
            }
        }
    }*/

    switch(key)
    {
        case VK_EXIT:
            if(MApp_ZUI_API_IsWindowVisible(HWND_INSTALL_GUIDE_PAGE5))
                {
                _InstallScanState=1;
                MApp_ATV_ExitATVScanPause2ScanEnd();
                return TRUE;
                }
            MApp_ZUI_ACT_ExecuteInstallGuideAction(EN_EXE_CLOSE_CURRENT_OSD);
            return TRUE;

	case VK_MENU:  //cus_xm:zb  add at 2012-7-12
		if((UI_SKIN_SEL == UI_SKIN_1366X768X565_SMC_India)||(UI_SKIN_SEL==UI_SKIN_1366X768X565_HAIER_CN))
		{
	                  if(MApp_ZUI_API_IsWindowVisible(HWND_INSTALL_GUIDE_PAGE5))
                         {
	                         _InstallScanState=1;
	                         MApp_ATV_ExitATVScanPause2ScanEnd();
	                         return TRUE;
                         }
			    if(!MApp_ZUI_API_IsWindowVisible(HWND_INSTALL_GUIDE_PAGE4))	  
                         {
                         	MApp_ZUI_ACT_ExecuteInstallGuideAction(EN_EXE_CLOSE_CURRENT_OSD);
                         	return TRUE;
			    }else
			   	return FALSE;
	      }else
	      return FALSE;

        case VK_POWER:
            MApp_ZUI_ACT_ExecuteInstallGuideAction(EN_EXE_POWEROFF);
            return TRUE;

        case VK_LEFT:
            if(MApp_ZUI_API_IsWindowVisible(HWND_INSTALL_GUIDE_PAGE4))
                MApp_ZUI_ACT_InstallPageSelect(3);
            else if(MApp_ZUI_API_IsWindowVisible(HWND_INSTALL_GUIDE_PAGE3))
                MApp_ZUI_ACT_InstallPageSelect(2);
            else if(MApp_ZUI_API_IsWindowVisible(HWND_INSTALL_GUIDE_PAGE2))
            {
                //SET_OSD_MENU_LANGUAGE((EN_LANGUAGE)(MApp_ZUI_API_GetFocus()-HWND_INSTALL_GUIDE_PAGE2_LAN1));
                MApp_ZUI_ACT_InstallPageSelect(1);
            }
            else
            return FALSE;

            return TRUE;
        case VK_RIGHT:
            if(MApp_ZUI_API_IsWindowVisible(HWND_INSTALL_GUIDE_PAGE1))
                MApp_ZUI_ACT_InstallPageSelect(2);
            else if(MApp_ZUI_API_IsWindowVisible(HWND_INSTALL_GUIDE_PAGE2))
                {
               #if (CUS_AREA_ID == AREA_ID_CHINA)
                if(MApp_ZUI_API_GetFocus() == HWND_INSTALL_GUIDE_PAGE2_LAN1)
                {
                    SET_OSD_MENU_LANGUAGE(LANGUAGE_CHINESE);
                }
                else
                {
                    SET_OSD_MENU_LANGUAGE(LANGUAGE_ENGLISH);
                }
               #else
                SET_OSD_MENU_LANGUAGE((EN_LANGUAGE)(MApp_ZUI_API_GetFocus()-HWND_INSTALL_GUIDE_PAGE2_LAN1));
               #endif
                MApp_ZUI_ACT_InstallPageSelect(3);
                }
            else if(MApp_ZUI_API_IsWindowVisible(HWND_INSTALL_GUIDE_PAGE3))
                {
                if(MApp_ZUI_API_GetFocus()==HWND_INSTALL_GUIDE_PAGE3_SCAN)
                {
                MApp_ZUI_ACT_InstallPageSelect(5);
                MApp_ZUI_ACT_ExecuteInstallGuideAction(EN_EXE_GOTO_AUTO_TUNING);
                }
                else
                MApp_ZUI_ACT_InstallPageSelect(4);
		   stGenSetting.fRunInstallationGuide = FALSE; //cus_xm:zb modify at 2012-8-17
                }
		  //cus_xm:zb modify at 2012-7-28
		  //else if(MApp_ZUI_API_IsWindowVisible(HWND_INSTALL_GUIDE_PAGE4))
                //MApp_ZUI_ACT_ExecuteInstallGuideAction(EN_EXE_CLOSE_CURRENT_OSD);
            else
            return FALSE;

            return TRUE;
          case VK_SELECT:
            if(MApp_ZUI_API_IsWindowVisible(HWND_INSTALL_GUIDE_PAGE2))
            {
                switch(MApp_ZUI_API_GetFocus())
                {
                    case HWND_INSTALL_GUIDE_PAGE2_LAN1:
                        break;
                    case HWND_INSTALL_GUIDE_PAGE2_LAN2:
                        break;
                    case HWND_INSTALL_GUIDE_PAGE2_LAN3:
                        break;
                    case HWND_INSTALL_GUIDE_PAGE2_LAN4:
                        break;
                    case HWND_INSTALL_GUIDE_PAGE2_LAN5:
                        break;
                    case HWND_INSTALL_GUIDE_PAGE2_LAN6:
                        break;
                    case HWND_INSTALL_GUIDE_PAGE2_LAN7:
                        break;
                    case HWND_INSTALL_GUIDE_PAGE2_LAN8:
                        break;
                    default:
                        break;
                    }
               #if (CUS_AREA_ID == AREA_ID_CHINA)
                if(MApp_ZUI_API_GetFocus() == HWND_INSTALL_GUIDE_PAGE2_LAN1)
                {
                    SET_OSD_MENU_LANGUAGE(LANGUAGE_CHINESE);
                }
                else
                {
                    SET_OSD_MENU_LANGUAGE(LANGUAGE_ENGLISH);
                }
               #else
                SET_OSD_MENU_LANGUAGE((EN_LANGUAGE)(MApp_ZUI_API_GetFocus()-HWND_INSTALL_GUIDE_PAGE2_LAN1));
               #endif
                MApp_ZUI_ACT_InstallPageSelect(3);
                return TRUE;
            }
            else if(MApp_ZUI_API_IsWindowVisible(HWND_INSTALL_GUIDE_PAGE3))
            {
                switch(MApp_ZUI_API_GetFocus())
                {
                    case HWND_INSTALL_GUIDE_PAGE3_SCAN:
                    {
                        MApp_ZUI_ACT_InstallPageSelect(5);
                        MApp_ZUI_ACT_ExecuteInstallGuideAction(EN_EXE_GOTO_AUTO_TUNING);
                    }
                    break;
                    case HWND_INSTALL_GUIDE_PAGE3_SKIPSCAN:
                        MApp_ZUI_ACT_InstallPageSelect(4);
			   stGenSetting.fRunInstallationGuide = FALSE; //cus_xm:zb modify at 2012-8-17			
                        break;
                    default:
                        break;
                }
                return TRUE;
            }
            else if(MApp_ZUI_API_IsWindowVisible(HWND_INSTALL_GUIDE_PAGE1))
            {
                MApp_ZUI_ACT_InstallPageSelect(2);
                return TRUE;
            }
            else if(MApp_ZUI_API_IsWindowVisible(HWND_INSTALL_GUIDE_PAGE4))
            {
                stGenSetting.fRunInstallationGuide = FALSE; //cus_xm:zb modify at 2012-8-17
                MApp_ZUI_ACT_ExecuteInstallGuideAction(EN_EXE_CLOSE_CURRENT_OSD);
                return TRUE;
            }
            break;
        default:
            break;
    }
    return FALSE;
}

void MApp_ZUI_ACT_TerminateInstallGuide(void)
{
    ZUI_MSG(printf("[]term:install\n");)
    enInstallGuideState = _enTargetInstallState;
}
extern EN_OSD_COUNTRY_SETTING MApp_ZUI_ACT_GetTuningCountry(void);
extern void MApp_ChannelChange_DisableChannel (BOOLEAN u8IfStopDsmcc, SCALER_WIN eWindow /*U8 u8ChanBufIdx*/ ); //for change channel
extern void MApp_InputSource_ChangeInputSource(SCALER_WIN eWindow);

BOOLEAN MApp_ZUI_ACT_ExecuteInstallGuideAction(U16 act)
{
    switch(act)
    {

        case EN_EXE_GOTO_INSTALL_PAGE2:
            MApp_ZUI_ACT_InstallPageSelect(2);
            return TRUE;

        case EN_EXE_ATV_MANUAL_SCAN_SHOW_INFO:
        case EN_EXE_REPAINT_AUTOTUNING_PROGRESS:
            MApp_ZUI_API_InvalidateAllSuccessors(HWND_INSTALL_GUIDE_PAGE5_BAR);
            MApp_ZUI_API_InvalidateAllSuccessors(HWND_INSTALL_GUIDE_PAGE5_TXT5);
            MApp_ZUI_API_InvalidateAllSuccessors(HWND_INSTALL_GUIDE_PAGE5_PERCENT);
            return TRUE;
        case EN_EXE_AUTO_SCAN_FINISH:
            if( _InstallScanState==1)
            MApp_ZUI_ACT_InstallPageSelect(3);
            else
            MApp_ZUI_ACT_InstallPageSelect(4);
            return TRUE;
        case EN_EXE_CLOSE_CURRENT_OSD:
            // stGenSetting.fRunInstallationGuide = FALSE; //cus_xm:zb modify at 2012-8-17
            MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
            _enTargetInstallState = STATE_INSTALL_CLEAN_UP;
            return TRUE;

        case EN_EXE_POWEROFF:
            MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
            _enTargetInstallState = STATE_INSTALL_GOTO_STANDBY;
            return TRUE;

        case EN_EXE_GOTO_AUTO_TUNING:
            #if 1
            {
                //from case MIA_START_SCAN
                MApp_SetOSDCountrySetting(MApp_ZUI_ACT_GetTuningCountry(), TRUE);
                u8ScanAtvChNum = 0;
            #if ENABLE_SBTVD_BRAZIL_APP
                u8ScanCATVChNum = 0;
                u8ScanAirTVChNum = 0;
            #endif
                u16ScanDtvChNum = 0;
                u16ScanRadioChNum = 0;
            #if NORDIG_FUNC //for Nordig Spec v2.0
                u16ScanDataChNum = 0;
            #endif
                u8ScanPercentageNum = 0;

            #if  ENABLE_SBTVD_BRAZIL_APP
                if( eTuneType == OSD_TUNE_TYPE_AIR_PLUS_CABLE)
            #else
                if( eTuneType == OSD_TUNE_TYPE_DTV_ONLY)
            #endif
                {
                    MApp_ChannelChange_DisableChannel(TRUE,MAIN_WINDOW);

                    #if (ENABLE_PIP)
                    if(IsPIPEnable())
                    {
                        if(stGenSetting.g_stPipSetting.enPipSoundSrc==EN_PIP_SOUND_SRC_SUB)
                        {
                            stGenSetting.g_stPipSetting.enPipSoundSrc=EN_PIP_SOUND_SRC_MAIN;
                            MApp_InputSource_PIP_ChangeAudioSource(MAIN_WINDOW);
                        }
                        UI_SUB_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_NONE;
                        MApp_InputSource_ChangeInputSource(SUB_WINDOW);
                        stGenSetting.g_stPipSetting.enPipMode = EN_PIP_MODE_OFF;
                        UI_SUB_INPUT_SOURCE_TYPE = MApp_InputSource_GetUIInputSourceType(MApp_InputSource_PIP_Get1stCompatibleSrc(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)));
                    }
                    #endif

            #if DVB_C_ENABLE
            #if ENABLE_T_C_COMBO
                    if(!IsCATVInUse())
                        UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_DTV;
                    else
                        UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_CADTV;
            #else
                    UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_CADTV;
            #endif
            #else
                    UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_DTV;
            #endif

            #if  ENABLE_SBTVD_BRAZIL_APP
                    MApp_InputSource_SwitchSource( UI_INPUT_SOURCE_DTV, MAIN_WINDOW );
            #else
                    MApp_InputSource_ChangeInputSource(MAIN_WINDOW );
            #endif
                    msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_INTERNAL_2_MUTEON, E_AUDIOMUTESOURCE_ACTIVESOURCE);
                }
                else
                {
                    mvideo_vd_set_videosystem(SIG_PAL); //dealut value for DVB
                    msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_INTERNAL_2_MUTEON, E_AUDIOMUTESOURCE_ACTIVESOURCE);
                    MApp_Scaler_Setting_SetVDScale(EN_AspectRatio_16X9, MAIN_WINDOW);
                }

            #if ENABLE_T_C_COMBO
            if(IsCATVInUse())
            {
                if(g_enScanType == SCAN_TYPE_AUTO)
                    stGenSetting.stScanMenuSetting.u8ScanType = SCAN_TYPE_AUTO;
                else if(g_enScanType == SCAN_TYPE_NETWORK)
                    stGenSetting.stScanMenuSetting.u8ScanType = SCAN_TYPE_NETWORK;
            }
            else
                stGenSetting.stScanMenuSetting.u8ScanType = SCAN_TYPE_AUTO;
            #else
                stGenSetting.stScanMenuSetting.u8ScanType = SCAN_TYPE_AUTO;
            #endif
            stGenSetting.fRunInstallationGuide = FALSE;
            enInstallGuideState = STATE_INSTALL_GOTO_SCAN;
            }
            #else
            if( MApp_ZUI_ACT_Get_InstallGuidePage() == PAGE_INSTALL_OSD_LANGUAGE )
            {
                MApp_ZUI_ACT_SetTuningCountryByOSDLanguage();
                MApp_ZUI_CTL_Grid_SetIndex(HWND_INSTALL_MAIN_PAGE_GRID, MApp_ZUI_ACT_Install_GetTuningMenuCountryIndex, MApp_ZUI_ACT_Install_SetTuningMenuCountryIndex, OSD_COUNTRY_AUSTRALIA, OSD_COUNTRY_NUMS-1);
                MApp_ZUI_CTL_Grid_SetFnGetTextByIndex(HWND_INSTALL_MAIN_PAGE_GRID, MApp_ZUI_ACT_Install_GetCountryStringIDByIndex);
			#if DVB_C_ENABLE
				MApp_ZUI_ACT_Set_InstallGuidePage(PAGE_INSTALL_SELECT_DVBC);
	            MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
				MApp_ZUI_ACT_ShutdownOSD();
                stGenSetting.fRunInstallationGuide = FALSE;
				_enReturnMenuItem = STATE_RETUNR_INSTALL_GUIDE;
				MApp_TopStateMachine_SetTopState(STATE_TOP_MENU);
				_enTargetInstallState = STATE_INSTALL_INIT;
			#else
				MApp_ZUI_ACT_Set_InstallGuidePage(PAGE_INSTALL_TUNING_COUNTRY);
				MApp_ZUI_API_InvalidateAllSuccessors(HWND_INSTALL_MAIN_PAGE);
                MApp_ZUI_API_SetFocus(HWND_INSTALL_MAIN_PAGE_GRID);
			#endif
            }
            else if( MApp_ZUI_ACT_Get_InstallGuidePage() == PAGE_INSTALL_TUNING_COUNTRY )
            {
                stGenSetting.fRunInstallationGuide = FALSE;
                //from case MIA_START_SCAN
                MApp_SetOSDCountrySetting(_eTempCountry, TRUE);
                u8ScanAtvChNum = 0;
#if ENABLE_SBTVD_BRAZIL_APP
                u8ScanCATVChNum = 0;
                u8ScanAirTVChNum = 0;
#endif
                u16ScanDtvChNum=0;
                u16ScanRadioChNum=0;
#if NORDIG_FUNC //for Nordig Spec v2.0
                u16ScanDataChNum=0;
#endif
                u8ScanPercentageNum=0;

#if  ENABLE_SBTVD_BRAZIL_APP
                    MApp_ChannelChange_DisableChannel(TRUE,MAIN_WINDOW);

                    UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_DTV;
                   #if ENABLE_SBTVD_BRAZIL_APP
                       enLastWatchAntennaType = ANTENNA_DTV_TYPE;
                      MApp_InputSource_SwitchSource( UI_INPUT_SOURCE_TYPE , MAIN_WINDOW );
                   #else
                       MApp_InputSource_ChangeInputSource(MAIN_WINDOW);
                   #endif
                    msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_INTERNAL_2_MUTEON, E_AUDIOMUTESOURCE_ACTIVESOURCE);
#else
                mvideo_vd_set_videosystem(SIG_PAL); //dealut value for DVB
                //MApp_UiMenuFunc_A_StartAutoScanFunction();
                msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_INTERNAL_2_MUTEON, E_AUDIOMUTESOURCE_ACTIVESOURCE);
                //ST_VIDEO.eAspectRatio = EN_AspectRatio_16X9; //[SQE-195]Set ARC 16:9 Auto Scanning state
                MApp_Scaler_Setting_SetVDScale(EN_AspectRatio_16X9, MAIN_WINDOW);
#endif
                stGenSetting.stScanMenuSetting.u8ScanType=SCAN_TYPE_AUTO;

                MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
                _enTargetInstallState = STATE_INSTALL_GOTO_SCAN;
            }
            #endif
            return TRUE;


        ///adjust functions//////////////////////

        case EN_EXE_DEC_TEMP_COUNTRY:
        case EN_EXE_INC_TEMP_COUNTRY:
            //from case MAPP_UIMENUFUNC_ADJUSTE2COUNTRY:
            _eTempCountry =(EN_OSD_COUNTRY_SETTING) MApp_ZUI_ACT_DecIncValue_Cycle(
                act==EN_EXE_INC_TEMP_COUNTRY,
                _eTempCountry, OSD_COUNTRY_AUSTRALIA, OSD_COUNTRY_NUMS-1, 1);
            //MApp_ZUI_API_InvalidateWindow(HWND_INSTALL_MAIN_COUNTRY_OPTION);
            return TRUE;

    }
    return FALSE;
}


extern U16 _MApp_ZUI_ACT_GetCountryStringID(EN_OSD_COUNTRY_SETTING country);
extern U16 _MApp_ZUI_ACT_GetLanguageStringID(EN_LANGUAGE lang, BOOLEAN bDefaultEnglish);
extern U16 MApp_ZUI_ACT_AutoTuningGetPercentValue(void);

S16 MApp_ZUI_ACT_GetInstallPageDynamicValue(HWND hwnd)
{
	// CUS_XM Xue 20120730:modify auto scan menu timeout issue XF112PIOCNMS0-768 
	MApp_ZUI_API_ResetTimer(HWND_INSTALL_BACKGROUND, 0);
switch(hwnd)
{
case HWND_INSTALL_GUIDE_PAGE5_BAR:
		
    return MApp_ZUI_ACT_AutoTuningGetPercentValue();
default:
    break;
}
 return 0;
}


//cus_xm:zb add at 2012-8-2
U16 MApp_ZUI_ACT_GetInstallDynamicBitmap(HWND hwnd, DRAWSTYLE_TYPE ds_type)
{
    U16 u16BtimapIdx=0xFFFF;
    ds_type = ds_type;
    switch(hwnd)
    {
     ////////////////////////////////////////////////////////////////////////////////
   case HWND_INSTALL_GUIDE_PAGE2_LAN3:
       #if(UI_SKIN_SEL==UI_SKIN_1366X768X565_SMC_India)
	  	 return E_BMP_INSTALL_LANGUE_NOMAL;
       #endif
       break;
    }
    return u16BtimapIdx;
}


LPTSTR MApp_ZUI_ACT_GetInstallGuideDynamicText(HWND hwnd)
{
    U16 u16TempID = Empty;

        if (MApp_ZUI_API_IsSuccessor(HWND_INSTALL_MAIN_PAGE_GRID, hwnd))
            return MApp_ZUI_CTL_GridGetDynamicText(HWND_INSTALL_MAIN_PAGE_GRID, hwnd);

        switch(hwnd)
        {
            case HWND_INSTALL_GUIDE_PAGE2_LAN1:
                #if (CUS_AREA_ID == AREA_ID_CHINA)
                return MApp_ZUI_ACT_Install_GetLanguageStringByIndex(LANGUAGE_CHINESE);
                #else
                return MApp_ZUI_ACT_Install_GetLanguageStringByIndex(LANGUAGE_ENGLISH);
                #endif
            case HWND_INSTALL_GUIDE_PAGE2_LAN2:
                #if (CUS_AREA_ID == AREA_ID_CHINA)
                return MApp_ZUI_ACT_Install_GetLanguageStringByIndex(LANGUAGE_ENGLISH);
                #else
                return MApp_ZUI_ACT_Install_GetLanguageStringByIndex(LANGUAGE_RUSSIAN);
                #endif
            case HWND_INSTALL_GUIDE_PAGE2_LAN3:
                return MApp_ZUI_ACT_Install_GetLanguageStringByIndex(LANGUAGE_ARABIC);
            case HWND_INSTALL_GUIDE_PAGE2_LAN4:
                return MApp_ZUI_ACT_Install_GetLanguageStringByIndex(LANGUAGE_CHINESE);
            case HWND_INSTALL_GUIDE_PAGE2_LAN5:
                return MApp_ZUI_ACT_Install_GetLanguageStringByIndex(LANGUAGE_CHINESE+1);
            case HWND_INSTALL_GUIDE_PAGE2_LAN6:
                return MApp_ZUI_ACT_Install_GetLanguageStringByIndex(LANGUAGE_CHINESE+2);
            case HWND_INSTALL_GUIDE_PAGE2_LAN7:
                return MApp_ZUI_ACT_Install_GetLanguageStringByIndex(LANGUAGE_CHINESE+3);
            case HWND_INSTALL_GUIDE_PAGE2_LAN8:
                return MApp_ZUI_ACT_Install_GetLanguageStringByIndex(LANGUAGE_CHINESE+4);

            case HWND_INSTALL_BACKGROUND_EXIT_TXT:
            switch(MApp_ZUI_API_GetParent(MApp_ZUI_API_GetFocus()))
            {
                default:
                    u16TempID=en_str_Button_Exit;
                    break;
                case HWND_INSTALL_GUIDE_PAGE5:
                    u16TempID=en_str_Cancel_Txt;
                    break;
            }
            break;
            case HWND_INSTALL_BACKGROUND_PAGE_TITLE:
            {
                switch(MApp_ZUI_API_GetParent(MApp_ZUI_API_GetFocus()))
                {
                    default:
                    case HWND_INSTALL_GUIDE_PAGE1:
                        u16TempID=en_strInstallWelcome;
                        break;
                    case HWND_INSTALL_GUIDE_PAGE2_LAN_LIST:
                        u16TempID=en_strInstalltxt4;
                        break;
                    case HWND_INSTALL_GUIDE_PAGE3_LAN_LIST:
                        u16TempID=en_strInstalltxt5;
                        break;
                    case HWND_INSTALL_GUIDE_PAGE4:
                        u16TempID=en_strInstalltxt9;
                        break;
                    case HWND_INSTALL_GUIDE_PAGE5:
                        u16TempID=en_strInstalltxt13;
                        break;
                }

                break;
            }
            case HWND_INSTALL_GUIDE_PAGE5_PERCENT:
                return MApp_ZUI_API_GetU16String(MApp_ZUI_ACT_AutoTuningGetPercentValue());
                break;
            case HWND_INSTALL_GUIDE_PAGE5_TXT5:
                #if ENABLE_SBTVD_BRAZIL_APP
                if(MApp_TopStateMachine_GetTopState() == STATE_TOP_ATV_SCAN )
                {
                    u8ScanAirTVChNum = msAPI_Tuner_GetNumberOfChBeFound_WhileAutoScan();
                }
                return MApp_ZUI_API_GetU16String(u8ScanAirTVChNum);
                #else

                #if ENABLE_CUS_UPDATE_SCAN
                if(g_bGotoUpdateScan)
                {
                    return MApp_ZUI_API_GetU16String(msAPI_ATV_GetFoundCHCount_ByUpdateScan());
                }
                else
                #endif
                {
                    return MApp_ZUI_API_GetU16String(u8ScanAtvChNum);
                }
                #endif
                break;
            case HWND_INSTALL_MAIN_TITLE:
                if( MApp_ZUI_ACT_Get_InstallGuidePage() == PAGE_INSTALL_OSD_LANGUAGE )
                {
                    //u16TempID=en_str_Language;
                    u16TempID=en_str_Select_OSD_Lang;
                }
                else
                {
                    u16TempID=en_str_Country;
                }
                    break;
            default:
                u16TempID = Empty;
                break;
        }

    if (u16TempID != Empty)
        return MApp_ZUI_API_GetString(u16TempID);
    return 0; //for empty string....
}
void MApp_ZUI_ACT_SetTuningCountryByOSDLanguage( void )
{

    switch( MApp_ZUI_ACT_Install_GetOsdLanguageIndex() )
    {
        case LANGUAGE_CZECH:
            _eTempCountry = OSD_COUNTRY_CZECH;
            break;
        case LANGUAGE_DANISH:
            _eTempCountry = OSD_COUNTRY_DENMARK;
            break;
        case LANGUAGE_GERMAN:
            _eTempCountry = OSD_COUNTRY_GERMANY;
            break;
        case LANGUAGE_ENGLISH:
            _eTempCountry = OSD_COUNTRY_UK;
            break;
        case LANGUAGE_SPANISH:
            _eTempCountry = OSD_COUNTRY_SPAIN;
            break;
        case LANGUAGE_GREEK:
            _eTempCountry = OSD_COUNTRY_GREECE;
            break;
        case LANGUAGE_FRENCH:
            _eTempCountry = OSD_COUNTRY_FRANCE;
            break;
        case LANGUAGE_CROATIAN:
            _eTempCountry = OSD_COUNTRY_CROATIA;
            break;
        case LANGUAGE_ITALIAN:
            _eTempCountry = OSD_COUNTRY_ITALY;
            break;
        case LANGUAGE_HUNGARIAN:
            _eTempCountry = OSD_COUNTRY_HUNGARY;
            break;
        case LANGUAGE_DUTCH:
            _eTempCountry = OSD_COUNTRY_NETHERLANDS;
            break;
        case LANGUAGE_NORWEGIAN:
            _eTempCountry = OSD_COUNTRY_NORWAY;
            break;
        case LANGUAGE_POLISH:
            _eTempCountry = OSD_COUNTRY_POLAND;
            break;
        case LANGUAGE_PORTUGUESE:
            _eTempCountry = OSD_COUNTRY_PORTUGAL;
            break;
        case LANGUAGE_RUSSIAN:
            _eTempCountry = OSD_COUNTRY_RUSSIA;
            break;
        case LANGUAGE_ROMANIAN:
            _eTempCountry = OSD_COUNTRY_RUMANIA;
            break;
        case LANGUAGE_SLOVENIAN:
            _eTempCountry = OSD_COUNTRY_SLOVENIA;
            break;
        case LANGUAGE_SERBIAN:
            _eTempCountry = OSD_COUNTRY_SERBIA;
        break;
        case LANGUAGE_FINNISH:
            _eTempCountry = OSD_COUNTRY_FINLAND;
        break;
        case LANGUAGE_SWEDISH:
            _eTempCountry = OSD_COUNTRY_SWEDEN;
        break;
        case LANGUAGE_BULGARIAN:
            _eTempCountry = OSD_COUNTRY_BULGARIA;
        break;
        case LANGUAGE_SLOVAK:
            _eTempCountry = OSD_COUNTRY_SLOVENIA;
        break;
#if (ENABLE_DTMB_CHINA_APP || ENABLE_ATV_CHINA_APP || ENABLE_DVBC_PLUS_DTMB_CHINA_APP||CHINESE_SIMP_FONT_ENABLE ||CHINESE_BIG5_FONT_ENABLE)
        case LANGUAGE_CHINESE:
            _eTempCountry = OSD_COUNTRY_CHINA;
        break;
#endif
        case LANGUAGE_NETHERLANDS:
            _eTempCountry = OSD_COUNTRY_NETHERLANDS;
        break;

        default:
            _eTempCountry = OSD_COUNTRY_UK;
        break;
    }

    return;
}
/////////////////////////////////////////////////////////
// Customize Window Procedures
S32 MApp_ZUI_ACT_InstallGuideWinProc(HWND hwnd, PMSG msg)
{
    switch(msg->message)
    {
        case MSG_CREATE:
            {
                U32 timeout_ms = MApp_ZUI_API_GetWindowData(hwnd);
                if (timeout_ms > 0)
                {
                    //setting AP timeout, auto close
                    MApp_ZUI_API_SetTimer(hwnd, 0, timeout_ms);
                }
            }
            break;

        case MSG_TIMER:
            {
                if (MApp_ZUI_API_IsWindowVisible(HWND_INSTALL_BACKGROUND))
                {
                    MApp_ZUI_ACT_ExecuteInstallGuideAction(EN_EXE_CLOSE_CURRENT_OSD);
                }
            }
            break;

        default:
            break;

    }

    return DEFAULTWINPROC(hwnd, msg);
}

#if 0 //use "auto close" control
///////////////////////////////////////////////////////////////////////////////
///  global  MApp_ZUI_ACT_InstallGuideRootWinProc
///  [install guide application customization] checking page key timeout
///
///  @param [in]       hwnd HWND     window handle we are processing
///  @param [in]       msg PMSG     message type
///
///  @return S32 message execute result
///
///  @author MStarSemi @date 2007/1/25
///////////////////////////////////////////////////////////////////////////////
S32 MApp_ZUI_ACT_InstallGuideRootWinProc(HWND hwnd, PMSG msg)
{
    switch(msg->message)
    {
        case MSG_CREATE:
            //setting AP timeout, auto close
            MApp_ZUI_API_SetTimer(hwnd, 0, APPLEVEL_MENU_TIME_OUT);
            break;

        case MSG_TIMER:
            {
                //if the time is up, kill the timer and then close AP!
                MApp_ZUI_API_KillTimer(hwnd, 0);
                MApp_ZUI_ACT_ExecuteInstallGuideAction(EN_EXE_CLOSE_CURRENT_OSD);
            }
            break;


    }

    return DEFAULTWINPROC(hwnd, msg);
}
#endif
void MApp_ZUI_ACT_InstallPageSelect(U8 InstallPageID)
{
    switch(InstallPageID)
    {
     default:
     case 1:
         MApp_ZUI_API_ShowWindow(HWND_MAINFRAME, SW_HIDE);
         MApp_ZUI_API_ShowWindow(HWND_INSTALL_BACKGROUND, SW_SHOW);
         MApp_ZUI_API_ShowWindow(HWND_INSTALL_BACKGROUND_BACK, SW_HIDE);
         MApp_ZUI_API_ShowWindow(HWND_INSTALL_BACKGROUND_SELECT, SW_HIDE);
         MApp_ZUI_API_ShowWindow(HWND_INSTALL_BACKGROUND_NEXT, SW_HIDE);
         MApp_ZUI_API_ShowWindow(HWND_INSTALL_BACKGROUND_EXIT, SW_HIDE);

         MApp_ZUI_API_ShowWindow(HWND_INSTALL_GUIDE_PAGE1, SW_SHOW);
         MApp_ZUI_API_SetFocus(HWND_INSTALL_GUIDE_PAGE1_TXT2);
        break;
     case 2:
         MApp_ZUI_API_ShowWindow(HWND_MAINFRAME, SW_HIDE);
         MApp_ZUI_API_ShowWindow(HWND_INSTALL_BACKGROUND, SW_SHOW);

         MApp_ZUI_API_ShowWindow(HWND_INSTALL_GUIDE_PAGE2, SW_SHOW);
         MApp_ZUI_API_SetFocus(HWND_INSTALL_GUIDE_PAGE2_LAN1);
        break;
     case 3:
         MApp_ZUI_API_ShowWindow(HWND_MAINFRAME, SW_HIDE);
         MApp_ZUI_API_ShowWindow(HWND_INSTALL_BACKGROUND, SW_SHOW);

         MApp_ZUI_API_ShowWindow(HWND_INSTALL_GUIDE_PAGE3, SW_SHOW);
         if(_InstallScanState)
         MApp_ZUI_API_ShowWindow(HWND_INSTALL_GUIDE_PAGE3_TXT1, SW_HIDE);
         else
         {
         MApp_ZUI_API_ShowWindow(HWND_INSTALL_GUIDE_PAGE3_TXT2, SW_HIDE);
         MApp_ZUI_API_ShowWindow(HWND_INSTALL_GUIDE_PAGE3_TXT3, SW_HIDE);
         MApp_ZUI_API_ShowWindow(HWND_INSTALL_GUIDE_PAGE3_TXT4, SW_HIDE);
         }
         _InstallScanState=0;
         MApp_ZUI_API_SetFocus(HWND_INSTALL_GUIDE_PAGE3_SCAN);
        break;
     case 4:
         MApp_ZUI_API_ShowWindow(HWND_MAINFRAME, SW_HIDE);
         MApp_ZUI_API_ShowWindow(HWND_INSTALL_BACKGROUND, SW_SHOW);
         MApp_ZUI_API_ShowWindow(HWND_INSTALL_BACKGROUND_SELECT, SW_HIDE);
         MApp_ZUI_API_ShowWindow(HWND_INSTALL_BACKGROUND_NEXT, SW_HIDE);
         MApp_ZUI_API_ShowWindow(HWND_INSTALL_BACKGROUND_EXIT, SW_HIDE);

         MApp_ZUI_API_ShowWindow(HWND_INSTALL_GUIDE_PAGE4, SW_SHOW);
         MApp_ZUI_API_SetFocus(HWND_INSTALL_GUIDE_PAGE4_TXT3);
        break;
     case 5:
         MApp_ZUI_API_ShowWindow(HWND_MAINFRAME, SW_HIDE);
         MApp_ZUI_API_ShowWindow(HWND_INSTALL_BACKGROUND, SW_SHOW);
         MApp_ZUI_API_ShowWindow(HWND_INSTALL_BACKGROUND_BACK, SW_HIDE);
         MApp_ZUI_API_ShowWindow(HWND_INSTALL_BACKGROUND_SELECT, SW_HIDE);
         MApp_ZUI_API_ShowWindow(HWND_INSTALL_BACKGROUND_NEXT, SW_HIDE);

         MApp_ZUI_API_ShowWindow(HWND_INSTALL_GUIDE_PAGE5, SW_SHOW);
         MApp_ZUI_API_SetFocus(HWND_INSTALL_GUIDE_PAGE5_TXT1);
        break;
    }
}
GUI_ENUM_DYNAMIC_LIST_STATE MApp_ZUI_ACT_QueryIstallItemStatus(HWND hwnd)
{
    switch(hwnd)
    {
#if (CUS_AREA_ID == AREA_ID_CHINA)
     case HWND_INSTALL_GUIDE_PAGE2_LAN1:
     case HWND_INSTALL_GUIDE_PAGE2_LAN2:
        return EN_DL_STATE_NORMAL;
#else
     case HWND_INSTALL_GUIDE_PAGE2_LAN1:
     case HWND_INSTALL_GUIDE_PAGE2_LAN2:
     case HWND_INSTALL_GUIDE_PAGE2_LAN3:
     case HWND_INSTALL_GUIDE_PAGE2_LAN4:
        return EN_DL_STATE_NORMAL;
#endif

     default:
         break;
    }
    return EN_DL_STATE_HIDDEN;
}

#undef MAPP_ZUI_ACTINSTALL_C
