////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (MStar Confidential Information!�L) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#ifdef  ENABLE_PTP

#ifndef MSAPI_PTP_H
#define MSAPI_PTP_H

#include "datatype.h"
#include "msAPI_FCtrl.h"
#include "msAPI_FSCommon.h"

#ifdef MSAPI_PTP_C
#define INTERFACE
#else
#define INTERFACE extern
#endif

typedef struct _PTPOBJECTINFO
{
    U16     ObjectFormat;
    U32     ObjectCompressedSize;
    U16     ThumbFormat;
    U32     ThumbCompressedSize;
    U32     ThumbPixWidth;
    U32     ThumbPixHeight;
    U32     ImagePixWidth;
    U32     ImagePixHeight;
    U16     Filename[13];           // 8 + . + 3 + null
    //struct _DATETIME sDateTime;
} PTPOBJECTINFO, *PPTPOBJECTINFO;

typedef struct
{
    U8 u8UsbPort;
    U32 u32ObjectHandle;
    U32 u32ObjectSize;
    U8 u8Dummy[27];
} PTPFileEntry;


//-------------------------------------------------------------------------------------------------
// Extern Functions
//-------------------------------------------------------------------------------------------------
U32 drvUsbPTP_GetObjectHandles(U8 u8UsbPort, U16 u16ObjFormat, U32 u32AssociObjHandle);
U32 drvUsbPTP_GetObjectHandleByIndex(U8 u8UsbPort, U32 u32Index);
PTPOBJECTINFO *drvUsbPTP_GetObjectInfo(U8 u8UsbPort, U32 u32ObjectHandle);
U32 drvUsbPTP_GetThumb(U8 u8UsbPort, U32 u32ObjectHandle, U32 u32Offset, U32 u32Length, U32 u32BufAddr);
U32 drvUsbPTP_GetObject(U8 u8UsbPort, U32 u32ObjectHandle, U32 u32Offset, U32 u32Length, U32 u32BufAddr);


//-------------------------------------------------------------------------------------------------
//  Functions
//-------------------------------------------------------------------------------------------------
INTERFACE U8 msAPI_PTP_FileOpen(FileEntry* pFileEntry, U8 u8OpenMode);
INTERFACE EN_FILE_CLOSE_RESULT msAPI_PTP_FileClose(U8 u8HandleNo);
INTERFACE U32 msAPI_PTP_FileRead(U8 u8HandleNo, U32 u32Buffer, U32 u32Length);
INTERFACE U32 msAPI_PTP_FileLength(U8 u8HandleNo);
INTERFACE U32 msAPI_PTP_FileTell(U8 u8HandleNo);

#undef INTERFACE

#endif

#endif // ENABLE_PTP

