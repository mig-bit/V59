////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef MAPP_ATV_SCAN_H
#define MAPP_ATV_SCAN_H

#include "MApp_Exit.h"


//*************************************************************************
//          Macro
//*************************************************************************


//*************************************************************************
//          Enums
//*************************************************************************
typedef enum
{
    STATE_ATV_SCAN_INIT,
    STATE_ATV_SCAN_WAIT,
    STATE_ATV_SCAN_SHOW_INFO,
    STATE_ATV_SCAN_PAUSE,
    STATE_ATV_SCAN_END,
    STATE_ATV_SCAN_EXIT_2_MAIN_MENU,
    STATE_ATV_SCAN_GOTO_STANDBY,
} EN_ATV_SCAN_STATE;



//*************************************************************************
//          Function prototypes
//*************************************************************************
#ifdef MAPP_ATV_SCAN_C
#define INTERFACE
#else
#define INTERFACE extern
#endif

INTERFACE EN_ATV_SCAN_STATE MApp_ATV_Scan_ScanState ( void );
INTERFACE void MApp_ATV_Scan_State_Init(void);
INTERFACE void MApp_ATV_Scan_End(void);
INTERFACE EN_RET MApp_ATV_Scan(void);

//ZUI: #if ENABLE_TTX_ACI
INTERFACE void MApp_ATV_SetATVScanState(EN_ATV_SCAN_STATE atvScanState);
//#endif

INTERFACE void MApp_ATV_ExitATVScanPauseState(void);
INTERFACE void MApp_ATV_ExitATVScanPause2Menu(void);
INTERFACE void MApp_ATV_ExitATVScanPause2ScanEnd(void);

#undef INTERFACE
#endif

