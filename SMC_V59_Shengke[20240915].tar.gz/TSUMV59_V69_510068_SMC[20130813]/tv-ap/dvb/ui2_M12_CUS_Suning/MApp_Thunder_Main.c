////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////
#ifdef ENABLE_BT


/******************************************************************************/
/*                 Header Files                                               */
/* ****************************************************************************/

#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#include "datatype.h"
#include "debug.h"
#include "Board.h"

#if (ENABLE_THUNDER_DOWNLOAD)

#define MAPP_THUNDER_MAIN_C

#include "MApp_Exit.h"
#include "MApp_Key.h"
#include "MApp_UiMenuDef.h"
#include "MApp_ZUI_Main.h"
#include "MApp_Thunder_Main.h"
#include "MApp_Thunder.h"


///////////////////////////////////////////////////////////
#define UI_DBG(x)   x

static enumThunderFlags m_eThunderFlags = E_THUNDER_FLAG_NONE;

//////////////////////////////////////////////////////////

static void _MApp_Thunder_Main_Init(void)
{
    if(!(m_eThunderFlags&E_THUNDER_FLAG_INITED))
    {
        //MApp_Thunder_Init();
        m_eThunderFlags |= E_THUNDER_FLAG_INITED;
    }
    MApp_Thunder_SetSystemInitState(STATE_SYSTEM_INIT_NONE);

    //enThunderSearchState = BT_SEARCH_STATE_INIT;
}

static void _MApp_Thunder_Switch2Thunder(void)
{
    //add switch Thunder AP code in here
    if(m_eThunderFlags & E_THUNDER_FLAG_INITED)
    {
        UI_DBG(printf("\n\n\n********Thunder has inited********\n"));
    }
    else
    {
        UI_DBG(printf("\n\n\n**********Thunder_Init**********\n"));
        _MApp_Thunder_Main_Init();
    }
}

EN_RET MApp_Thunder_Main(void)
{
    EN_RET enRetVal =EXIT_NULL;

    switch(enThunderState)
    {
        case STATE_THUNDER_INIT:
            _MApp_Thunder_Switch2Thunder();
            MApp_ZUI_ACT_StartupOSD(E_OSD_BT);
            enThunderState = STATE_THUNDER_WAIT;
            break;

        case STATE_THUNDER_WAIT:
            MApp_ZUI_ProcessKey(u8KeyCode);
            u8KeyCode = KEY_NULL;
            break;

        case STATE_THUNDER_CLEAN_UP:
            MApp_ZUI_ACT_ShutdownOSD();
            enThunderState = STATE_THUNDER_INIT;
            enRetVal =EXIT_CLOSE;
            break;

        case STATE_THUNDER_GOTO_STANDBY:
            MApp_ZUI_ACT_ShutdownOSD();
            u8KeyCode = KEY_POWER;
            enRetVal =EXIT_GOTO_STANDBY;
            break;

        case STATE_THUNDER_GOTO_MENU:
            MApp_ZUI_ACT_ShutdownOSD();
            enThunderState = STATE_THUNDER_RETURN_FROM_MENU;
            enRetVal = EXIT_BT_TRAN_MENU;
            break;

        case STATE_THUNDER_GOTO_INPUTSOURCE:
            MApp_ZUI_ACT_ShutdownOSD();
            enThunderState = STATE_THUNDER_RETURN_FROM_MENU;
            enRetVal = EXIT_GOTO_INPUTSOURCE;
            break;

        case STATE_THUNDER_RETURN_FROM_MENU:
            enThunderState = STATE_THUNDER_WAIT;
            MApp_ZUI_ACT_StartupOSD(E_OSD_BT);
            break;

        default:
            enThunderState = STATE_THUNDER_WAIT;
            break;
    }
    return enRetVal;
}

enumThunderFlags MApp_Thunder_GetThunderFlags(void)
{
    return m_eThunderFlags;
}

void MApp_Thunder_SetLink0Flags(BOOLEAN bEnable)
{
    if(bEnable)
        m_eThunderFlags |= E_THUNDER_FLAG_LINK0PHOTO_MODE;
    else
        m_eThunderFlags &= (enumThunderFlags)(~E_THUNDER_FLAG_LINK0PHOTO_MODE);

}

void MApp_Thunder_SetLink1Flags(BOOLEAN bEnable)
{
    if(bEnable)
        m_eThunderFlags |= E_THUNDER_FLAG_LINK1PHOTO_MODE;
    else
        m_eThunderFlags &= (enumThunderFlags)(~E_THUNDER_FLAG_LINK1PHOTO_MODE);
}

void MApp_Thunder_Main_Exit(void)
{
    m_eThunderFlags = E_THUNDER_FLAG_NONE;
    enThunderState = STATE_THUNDER_INIT;
}

#undef MAPP_THUNDER_MAIN_C
#endif

#endif

