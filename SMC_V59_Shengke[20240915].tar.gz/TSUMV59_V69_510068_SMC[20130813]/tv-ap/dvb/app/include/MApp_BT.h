////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
/// @file MApp_BT.h
/// @brief Bit-torrent download kernel
/// @author MStar Semiconductor Inc.
///
/// Bit-torrent download kernel provide a simple interface to let users implement
/// BT download on MStar chip.
///
////////////////////////////////////////////////////////////////////////////////
#include "MApp_BT_config.h"

#if (ENABLE_THUNDER_DOWNLOAD)

#include "MApp_Thunder.h"

#else

#ifndef MAPP_BT_H
#define MAPP_BT_H

#include "datatype.h"

//*****************************************************************************
//              Defines
//*****************************************************************************
#define NUM_OF_TORRENT_FILES_PER_PAGE       5
#define NUM_OF_MAINLINK0_PHOTO_PER_PAGE     6
#define NUM_OF_MAINLINK1_PHOTO_PER_PAGE     6
#define NUM_OF_IME_CHARS_PER_PAGE     8
#define NUM_OF_SEARCH_STRING     64
#define BT_SEARCH_WAIT_MONITOR_TIME     10000 //ms
#define NUM_OF_SEARCH_LIST_FILES_MAX       12
#define NUM_OF_DOWNLOAD_LIST_FILES_MAX       20
#define NUM_OF_TOP_FILES_MAX       NUM_OF_MAINLINK0_PHOTO_PER_PAGE  // 1~10
#define DESCRIPTION_MAX_SIZE       1000
#define IMAGE_MAX_SIZE       0x100000 // 1MByte


//*****************************************************************************
//              Enums
//*****************************************************************************



//*****************************************************************************
//              Data structure
//*****************************************************************************

#if 0
extern int atoi( const char * /* int_str */ );

extern long atol( const char * /* long_str */ );

extern long strtol( const char * /* long_str */, char ** /* endptr */,  int /* base */ );

extern unsigned long strtoul( const char * /* ulong_str */, char ** /* endptr */, int /* base */ );

#define SEED_ROOTDIR    "seed"
#endif

#define BTC_MAX_MATCH_LIST_ITEM 20
#define BTC_MAX_LIST_NAME_SIZE  128
/* data structure of a node at a returned torrent list */
typedef struct TorrentListNode_s
{
    S32            s32TID;                             /* torrent ID */
    U16 szTFilename[BTC_MAX_LIST_NAME_SIZE];    /* torrent file name(UCS2 format) with out ".torrent" suffix */
    struct CreateDate_s
    {
        U16 year;
        U8  month;
        U8  day;
        U8  hour;
        U8  min;
        U8  sec;
        U8  ampm;    /* 0:am, 1:pm */
    } sDate;           /* torrent create date */
    U8  u8Health;         /* torrent health: 0->Unknown, 1->Bad, 2->Medium, 3->Excellent */
    U8  u8VideoStatus;    /* video codec status: 0->unverified, 1->available */
    U8  u8Category;       /* category */
    U8  u8Subcategory;    /* subcategory */
    S32            s32Region;        /* region category */
    U32   u32Popularity;    /* popularity */
    S32            s32FileSize;      /* total file size in KBytes */
    U32   u32IMDBrating;    /* IMDB Rating */
} TorrentListNode_st,*pTorrentListNode_st;
/* data structure of the returned torrent list */
typedef struct TorrentList_s
{
    S32                s32Total;                       /* the number of matched torrent   */
    TorrentListNode_st asNode[BTC_MAX_MATCH_LIST_ITEM];    /* the list of the matched torrent */
} TorrentList_st,*pTorrentList_st;

#define BTC_TORRENTLIST_ITEM_NAME_LENGTH        256
/* data structure returned by BTC_ListTorrent()*/
typedef struct TorrentList_Item {
    int  num;
    int  st;                //state:  0: inactive, 1: start, 2: stop, 3: leech, 4: seed
    long long cgot;     //currently download file sizes
    long long csize;    //currently file total size
    long long totup;    //currently upload file total size  <- no use
    long long rate_down; // Download speed (Byte/S)
    char name[BTC_TORRENTLIST_ITEM_NAME_LENGTH];  // currently file name
    unsigned int TID;
} TorrentList_Item_st,*pTorrentList_Item_st;


typedef enum
{
    STATE_SYSTEM_INIT_NONE,
    STATE_SYSTEM_INIT_LOAD_BIN,
    STATE_SYSTEM_INIT_WAIT_LOAD_OK,
    STATE_SYSTEM_INIT_SET_PARAMETER,
    STATE_SYSTEM_INIT_CHECK_NETWORK,
    STATE_SYSTEM_INIT_OK,
} BT_Init_State;

// MailBox HK(AEON)  <=> BEON
typedef enum
{
    // HK(Aeon)  => Beon
    MB_BTC_UNLOCKMEM_A          = 0x10,
    MB_BTC_LISTTORRENT          = 0x11,
    MB_BTC_SETMEMADDR1          = 0x12,
    MB_BTC_SETMEMADDR2          = 0x13,
    MB_BTC_SETDAEMONPARAM       = 0x14,
    MB_BTC_STOPDAEMON           = 0x15,
    MB_BTC_ADDTORRENT           = 0x16,
    MB_BTC_DELTORRENT           = 0x17,
    MB_BTC_DELTORDATA           = 0x18,
    MB_BTC_STARTDAEMON          = 0x19,
    MB_BTC_STARTTORRENT         = 0x1A,
    MB_BTC_STOPTORRENT          = 0x1B,
    MB_BTC_SETTORRENTSVR        = 0x1C,
    MB_BTC_HTTPCMD_TTOTAL       = 0x20,
    MB_BTC_HTTPCMD_TLIST        = 0x21,
    MB_BTC_HTTPCMD_TGET         = 0x22,
    MB_BTC_HTTPCMD_PGET         = 0x23,
    MB_BTC_HTTPCMD_DGET         = 0x24,
    MB_BTC_HTTPCMD_CPUT         = 0x25,
    MB_BTC_HTTPCMD_PPUT         = 0x26,
    MB_BTC_CHECK_NETWORK        = 0x27,
    MB_BTC_CHECK_STORAGE        = 0x28,
    MB_BTC_HTTPCMD_ALL         = 0x29,

    // Beon  => HK(Aeon)
    MB_BTC_UNLOCKMEM_M          = 0x80,
    MB_BTC_OK                   = 0x81,
    MB_BTC_FAIL                 = 0x82,
    MB_BTC_RESPONSE_NUM         = 0x83,
    MB_BTC_RESPONSE_LIST        = 0x84,
    MB_BTC_LISTTORRENT_RESPONSE = 0x85,
    MB_BTC_SENDIMGRAWDATA       = 0x86,
    MB_BTC_SENDDESTXT           =0x87,
    MB_BTC_SENDALL           = 0x88
} MB_BTC;


// MailBox BEON => HK(AEON) Error State.
typedef enum
{
    MB_BTC_ERR_DN_TOR  = 0x01,          //Error while downloading the torrent file
    MB_BTC_ERR_DN_IMG = 0x02,           //Error while downloading the image file
    MB_BTC_ERR_DN_DES = 0x03,           //Error while downloading the description file
    MB_BTC_ERR_START_TOR = 0x04,        //Error while starting the torrent
    MB_BTC_ERR_STOP_TOR = 0x05,         //Error while stopping the torrent
    MB_BTC_ERR_ADD_TOR = 0x06,          //Error while adding the torrent
    MB_BTC_ERR_DEL_TOR = 0x07,          //Error while deleting the torrent
    MB_BTC_ERR_DEL_TORDATA  = 0x08, //Error while deleting the torrent and downloaded data
    MB_BTC_ERR_START_DAEM = 0x09,   //Error while starting the daemon
    MB_BTC_ERR_STOP_DAEM = 0x0A,        //Error while stopping the daemon
    MB_BTC_ERR_SET_PARAM = 0x0B,        //Error while setting the daemon parameters
    MB_BTC_ERR_NETWORK = 0x0C,          //Error for network
    MB_BTC_ERR_STORAGE = 0x0D,          //Error for storage
    MB_BTC_ERR_UNRESOLVED_HOST = 0x0E,  //Error while resolving the host name of the torrent server
    MB_BTC_ERR_DECODE_IMG = 0x0F,           //Error while decoding the image
    MB_BTC_ERR_NETWORK_PHY      = 0x10,
    MB_BTC_ERR_NETWORK_DHCP     = 0x11,
    MB_BTC_ERR_DN_ALL           = 0x12,

    MB_BTC_ERR_UNKNOWN  = 0xFF,              //Unknown error
} MB_BTC_ERROR;

/// Specify the torrent file information.

typedef enum
{
//state:  0: inactive, 1: start, 2: stop, 3: leech, 4: seed
    BT_TORRENT_STATE_INACTIVE = 0,
    BT_TORRENT_STATE_START = 1,
    BT_TORRENT_STATE_STOP = 2,
    BT_TORRENT_STATE_LEECH = 3,
    BT_TORRENT_STATE_SEED = 4,
} TORRENT_STATE;

typedef struct
{
    U8 u8LongFileName[BTC_TORRENTLIST_ITEM_NAME_LENGTH];    /// Long file name
    U8 u8ExtFileName[3+1];                              /// Short extension file name
    TORRENT_STATE u8State;                         /// Download state
    U32 u32TotalFileSize;                                    /// total File size  max 4.2G
    U32 u32LeftFileSize;                                    /// left File size  max 4.2G
    U32 u32DownloadSpeed;
} TorrentFileInfo;

/// Specify the MainLink0 information.
typedef struct
{
    U8 u8LinkPhoto_FileName[64];    /// Long file name
    U8 u8LinkFile_FileName[BTC_TORRENTLIST_ITEM_NAME_LENGTH];    /// Long file name
    U8 u8LinkFileDes_FileName[64];    /// Long file name
} MainLink0Info;

/// Specify the MainLink1 information.
typedef struct
{
    U8 u8LinkPhoto_FileName[64];    /// Long file name
    U8 u8LinkFile_FileName[BTC_TORRENTLIST_ITEM_NAME_LENGTH];    /// Long file name
    U8 u8LinkFileDes_FileName[64];    /// Long file name
} MainLink1Info;


/// the MainLink0 status.
typedef struct
{
    BOOLEAN bLinkPhoto_Ready;    // photo download finished or not
    BOOLEAN bLinkFile_Ready;    // link file name  download finished or not
    BOOLEAN bLinkFileDes_Ready;    // link file description download finished or not
    BOOLEAN bLinkPhoto_Show;    // photo can show or not
    BOOLEAN bLinkFile_Show;    // link file name  can show or not
    BOOLEAN bLinkFileDes_Show;    // link file description can show or not

} MainLink0Status;

/// the MainLink1 status.
typedef struct
{
    BOOLEAN bLinkPhoto_Ready;    // photo download finished or not
    BOOLEAN bLinkFile_Ready;    // link file name  download finished or not
    BOOLEAN bLinkFileDes_Ready;    // link file description download finished or not
    BOOLEAN bLinkPhoto_Show;    // photo can show or not
    BOOLEAN bLinkFile_Show;    // link file name  can show or not
    BOOLEAN bLinkFileDes_Show;    // link file description can show or not

} MainLink1Status;

/// Specify the torrent Search IME.
typedef enum
{
    STATE_IME_NULL,
    STATE_IME_SPELL,
    STATE_IME_CHS,
    STATE_IME_SETP3,
} EN_IME_STATE;


typedef enum
{
    STATE_SEARCH_NONE,
    STATE_SEARCH_GET_RESPONSE_NUM,
    STATE_SEARCH_GET_RESPONSE_LIST,
    STATE_SEARCH_GET_LIST_OK,
} BT_Search_State;

typedef enum
{
    STATE_GET_IMAGE_NONE,
    STATE_GET_IMAGE_INIT,
    STATE_GET_IMAGE,
    STATE_GET_IMAGE_OK,
} BT_Get_Image_State;

typedef enum
{
    STATE_GET_DESCRIPTION_NONE,
    STATE_GET_DESCRIPTION_INIT,
    STATE_GET_DESCRIPTION,
    STATE_GET_DESCRIPTION_OK,
} BT_Get_Description_State;

typedef enum
{
    STATE_DOWNLOADLIST_NONE,
    STATE_DOWNLOADLIST_SEMD_CMMD,
    STATE_DOWNLOADLIST_GET_RESPONSE_LIST,

} BT_DOWNLOADLIST_State;

typedef enum
{
    STATE_BT_JPEG_NONE,
    STATE_BT_JPEG_INIT,
    STATE_BT_JPEG_DECODE,
    STATE_BT_JPEG_SHOW,

} BT_JPEG_State;


typedef struct
{
    BOOLEAN bInputOK;
    BOOLEAN bIsEnglish;
    BOOLEAN bIsCAPs;
    EN_IME_STATE     uIME_State;
    U8     u8Char;
    U16     u16SpellCounter;
    U16     u16SpellStar;
    U16     u16CHS_Offset;
    U8 u8Sting[NUM_OF_IME_CHARS_PER_PAGE][7];
    U16 u16StringName[NUM_OF_SEARCH_STRING];    // file name
} _BT_IME;


/// Specify the Search List.
typedef struct
{
    U16 u16SearchList_FileName[128];    /// Long file name
    U8 u8ExtFileName[5+1];              /// Short extension file name
    U32 u32TotalFileSize;                    /// total File size  max 4.2G
} SearchListFileInfo;

typedef struct
{
    S32 u32Torrent_ID;    /// Torrern file ID
    SearchListFileInfo uFileInfo;              /// Short extension file name
} SearchTorrentListFileInfo;


#ifdef MAPP_BT_C
#define INTERFACE
#else
#define INTERFACE extern
#endif

//*****************************************************************************
//              Global variables
//*****************************************************************************

//*****************************************************************************
//              Function prototypes
//*****************************************************************************
INTERFACE BOOLEAN MApp_BT_QueryTorrentFileInfo(U8 u8FileIdx, TorrentFileInfo *pInfo);
INTERFACE BOOLEAN MApp_BT_QueryMainLink0Info(U8 u8Idx, MainLink0Info *pInfo);
INTERFACE BOOLEAN MApp_BT_QueryMainLink1Info(U8 u8Idx, MainLink1Info *pInfo);
INTERFACE BOOLEAN MApp_BT_QuerySearchListFileInfo(U16 u16FileIdx, SearchListFileInfo *pInfo);
INTERFACE BOOLEAN MApp_BT_QuerySearchListResult(void);
INTERFACE BOOLEAN MApp_BT_GetMatchTorrentTotal(U16 *pu16UnicodeString);
INTERFACE BOOLEAN MApp_BT_GetMatchTorrentList(U16 *pu16UnicodeString, U16 u16ListStar, U16 u16ListCont);
INTERFACE BOOLEAN MApp_BT_QuerySearchListResultPage( U16 u16ListStar, U16 u16ListCont);
INTERFACE BOOLEAN MApp_BT_GetTorrentFile(S32 s32TorrentID);
INTERFACE BOOLEAN MApp_BT_GetTopListOrNewList(BOOLEAN bIsToplist);
INTERFACE BOOLEAN MApp_BT_QueryImageFile(S32 s32TorrentID);
INTERFACE BOOLEAN MApp_BT_QueryDescriptionFile(S32 s32TorrentID);
INTERFACE BOOLEAN MApp_BT_QueryTopListOrNewListResult(void);
INTERFACE BOOLEAN MApp_BT_QueryTopListOrNewListDescription(void);
INTERFACE void MApp_BT_SetSearchFileState(BT_Search_State uState);
INTERFACE BT_Search_State MApp_BT_GetSearchFileState(void);
INTERFACE U32 MApp_BT_GetDescriptionFileSize(void);
INTERFACE BOOLEAN MApp_BT_AddTorrentFileToDownloadList(U16 * pFileName);
INTERFACE BOOLEAN MApp_BT_SearchList_StartTorrentFileToDownload(U16 * pFileName);
INTERFACE BOOLEAN MApp_BT_StartTorrentFileToDownload(U16 * pFileName);
INTERFACE BOOLEAN MApp_BT_StopTorrentFileToDownload(U16 * pFileName);
INTERFACE BOOLEAN MApp_BT_DeleteTorrentFileToDownload(U16 * pFileName);
INTERFACE BOOLEAN MApp_BT_DeleteTorrentFileAndData(U16 * pFileName);
INTERFACE BOOLEAN MApp_BT_GetDownloadFlieListInfo(void);
INTERFACE BOOLEAN MApp_BT_GetDownloadList(void);
INTERFACE U8 MApp_BT_GetDownloadListFileNum(void);
INTERFACE void MApp_BT_SetImageFileState(BT_Get_Image_State uState);
INTERFACE BT_Get_Image_State MApp_BT_GetImageFileState(void);
INTERFACE BOOLEAN MApp_BT_GetImageFile(U8 u8Index);
INTERFACE void  MApp_BT_SetImageFileSize(U32 u32Size);
INTERFACE U32 MApp_BT_GetImageFileSize(void);
INTERFACE void MApp_BT_SetImageFileID(U32 u32TorrentID);
INTERFACE U32 MApp_BT_GetImageFileID(void);
INTERFACE void MApp_BT_SetDescriptionFileState(BT_Get_Description_State uState);
INTERFACE BT_Get_Description_State MApp_BT_GetDescriptionFileState(void);
INTERFACE U32 MApp_BT_GetDescriptionBuffAddr(void);
INTERFACE void  MApp_BT_SetDescriptionFileSize(U32 u32Size);
INTERFACE U32 MApp_BT_GetDescriptionFileSize(void);
INTERFACE void MApp_BT_SetDescriptionFileID(U32 u32TorrentID);
INTERFACE U32 MApp_BT_GetDescriptionFileID(void);
INTERFACE U32 MApp_BT_GetSearchFileNum(void);
INTERFACE S32 MApp_BT_GetTorrentFileID(U8 u8Idx);
INTERFACE U16 *MApp_BT_GetTorrentFileName(U8 u8Idx);
INTERFACE BOOLEAN MApp_BT_MailBoxHandle(U32 u32WaitMs, U8 u8CommandIndex, MBX_Msg *pMsg);
INTERFACE U8 MApp_Get_System_ErrorState(void);
INTERFACE void MApp_System_ErrorHandle(void);
INTERFACE void MApp_BT_SetSystemInitState(BT_Init_State uState);
INTERFACE BT_Init_State MApp_BT_GetSystemInitState(void);

INTERFACE void MApp_BT_Task(void);
INTERFACE void MApp_BT_SetMainLink0PhotoShow(U8 u8Idx, BOOLEAN bShow);
INTERFACE void MApp_BT_SetMainLink1PhotoShow(U8 u8Idx, BOOLEAN bShow);
INTERFACE BOOLEAN MApp_BT_GetMainLink0PhotoReady(U8 u8Idx);
INTERFACE BOOLEAN MApp_BT_GetMainLink1PhotoReady(U8 u8Idx);
INTERFACE void MApp_BT_Init(void);
INTERFACE void MApp_BT_MainLink0_Init(void);
INTERFACE void MApp_BT_MainLink1_Init(void);


/////////////////////////////////////////////////////////////////////////////////////
INTERFACE BOOLEAN MApp_BT_GetAnyData(char *BURL);
INTERFACE BOOLEAN MApp_BT_GetAnySearch(char *skey,int num,int page);

typedef enum//ResultSet
{
    EN_BLOCKR=0,//FileInfo
    EN_CID,//Cid
    EN_TITLE,//Title
    EN_SIZE,//Size
    EN_FORMAT,//Format
    EN_PLAYTIME,//PlayTime
    EN_BITRATE,//BitRate
    EN_TORRENT,//Torrent
    EN_TONUM,//TorrentNum
    EN_MAX_FILEINFO,
} FILEINFO;

typedef enum//moviesets
{
    EN_BLOCKM=0,//movie
    EN_MID,//movie id="  "
    EN_NAME,//key
    EN_DESC,//desc
    EN_PIC,//pic
    EN_MAX_MOVEINFO,
} MOVEINFO;

typedef enum
{
    EN_START=0,
    EN_END,
    EN_MAX_POINTINFO,
} SPOINTER;

INTERFACE int strstrn(char **ppstringstart,char **ppstringend,char *psubstring);
INTERFACE int strnum(char *pstringstart,char *pstringend,char *pskeyword);
INTERFACE int strkeyn(char **ppstringstart,char **ppstringend,char *pskeyword,int counter);
INTERFACE int strdata(char **ppstringstart,char **ppstringend,char *pskeyword1,char *pskeyword2);

INTERFACE void CopyString(char *dst, char *s1, char *s2);
INTERFACE void PrintfInfo(char *s1,char *s2);

INTERFACE int DataParser(char *sInputBuffer, int iLength);

INTERFACE char * SearchResult[10][EN_MAX_FILEINFO][EN_MAX_POINTINFO];
INTERFACE int ResultCounter;
INTERFACE char * MovieList[10][EN_MAX_MOVEINFO][EN_MAX_POINTINFO];
INTERFACE char * MoviePIC[10][EN_MAX_POINTINFO];
INTERFACE char * MovieKeyword[10][EN_MAX_POINTINFO];
////////////////////////////////////////////////////////////////////////////////
#undef INTERFACE

#endif

#endif // #if (ENABLE_THUNDER_DOWNLOAD)

