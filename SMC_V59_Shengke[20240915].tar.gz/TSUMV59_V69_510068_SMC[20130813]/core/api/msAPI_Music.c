////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//
/// @file msAPI_MP3.c
/// @brief API for MP3 decoding and display
/// @author MStar Semiconductor, Inc.
//
////////////////////////////////////////////////////////////////////////////////

#if (ENABLE_DMP)

#define MSAPI_MUSIC_C

#include <stdio.h>
#include <string.h>

#include "MsCommon.h"
#include "MsIRQ.h"
#include "MsOS.h"

#include "sysinfo.h"
#include "hwreg.h"
#include "BinInfo.h"
#include "MsTypes.h"
#include "drvBDMA.h"
#include "drvAUDIO.h"
#include "drvMAD.h"
#include "SysInit.h"
#include "apiXC.h"
#include "apiXC_Adc.h"
#include "GPIO.h"
#include "drvGPIO.h"
#include "msAPI_MIU.h"
#include "msAPI_Music.h"
#include "msAPI_Memory.h"
#include "msAPI_Timer.h"
#include "IOUtil.h"
#include "msAPI_audio.h"
#include "MApp_GlobalSettingSt.h"
#include "MApp_GlobalVar.h"
#include "msAPI_DataStreamIO.h"


//**********************************************************
#define MP3_DBG(x)     //x

//**********************************************************
#define MP3_DECODE_DONE             0xFF
#define MP3_BUFFER_TIMEOUT_MS       (1000LU)
#define MP3_DECODE_TIMEOUT_MS       (3000LU)

#define MP3_TAG_BUF_SIZE            128

#define XING_FRAMES                 0x00000001
#define XING_BYTES                  0x00000002
#define XING_TOC                    0x00000004
#define XING_SCALE                  0x00000008

#define MP3_SAMPLE_PER_FRAME        1152UL
#define MP3_SAMPLE_PER_FRAME_LSF    576UL

static U8 u8IntTag;

En_DVB_decSystemType enDecSys = MSAPI_AUD_DVB_NONE; // here we only care if it's JPEG or not JPEG

extern XDATA BYTE g_DspCodeType;

//fix MP3 wrong bitrate&total time issue while playing V2/V2.5 stream, share same table for V2&V2.5
U16 Mp3BitRateTable[5][16] =
{
    {0xffff, 32, 64, 96, 128, 160, 192, 224, 256, 288, 320, 352, 384, 416, 448, MP3_INVALID_RATE}, // V1, L1
    {0xffff, 32, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320, 384, MP3_INVALID_RATE},    // V1, L2
    {0xffff, 32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320, MP3_INVALID_RATE},     // V1, L3
    {0xffff, 32, 48, 56, 64, 80, 96, 112, 128, 144, 160, 176, 192, 224, 256, MP3_INVALID_RATE},    // V2/V2.5, L1
    {0xffff, 8,  16, 24, 32, 40, 48, 56,  64,  80,  96, 112, 128, 144, 160, MP3_INVALID_RATE},     // V2/V2.5, L2/L3
};

U16 Mp3SampleRateTable[3][4] =
{
    {11025, 12000, 8000, MP3_INVALID_RATE}, // v2.5
    {22050, 24000, 16000, MP3_INVALID_RATE}, // v2
    {44100, 48000, 32000, MP3_INVALID_RATE}, // v1
};

/*
U32 SamplePerFrame[3][3]=
{
    {576, 1152, 384}, // v2.5
    {576, 1152, 384}, // v2
    {1152, 1152, 384}, // v1
};
*/
//**********************************************************

/******************************************************************************/
/// API for init Audio decoder initialization and decoding system
/// @param u32Mp3StartAddr \b IN Specify decode system
/******************************************************************************/
void msAPI_Music_Init(En_DVB_decSystemType enDecSystem, U16 u16InitVolume)
{
    BOOLEAN bUserMute = msAPI_AUD_IsAudioMutedByUser();

    msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_BYUSER_MUTEON, E_AUDIOMUTESOURCE_ACTIVESOURCE);

    MApi_AUDIO_SetCommand((En_DVB_decCmdType)MSAPI_AUD_STOP);

    u8IntTag = 1;
    MDrv_AUDIO_SetPlayFileFlag(DSP_DEC, 0);

    enDecSys = MSAPI_AUD_DVB_TONE ;
    if (enDecSys != MSAPI_AUD_DVB_TONE)
    {
        MDrv_AUDIO_Init();//, MAD_BASE_BUFFER_ADR);
        msAPI_Timer_Delayms(100);

        enDecSys = MSAPI_AUD_DVB_TONE;
        Audio_Amplifier_ON();  // this is critical because we turn off the amplifier when loading JPEG code to DSP
    }

    // Comment this code since need not to change to DTV input source
    // MApp_InputSource_ChangeAudioSource(INPUT_SOURCE_DTV);

    MApi_AUDIO_SetSystem(MSAPI_AUD_DVB_NONE);

    MApi_AUDIO_SetSystem(enDecSystem);

    if(!bUserMute)
        msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_BYUSER_MUTEOFF, E_AUDIOMUTESOURCE_ACTIVESOURCE);

    //force unmute ... the mute might be triggerrd from SIF which we can hardly
    // determine which type it is...
    msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_PERMANENT_MUTEOFF, E_AUDIOMUTESOURCE_ACTIVESOURCE);

    msAPI_AUD_AdjustAudioFactor(E_ADJUST_VOLUME, u16InitVolume, 0);

}

void msAPI_Music_StartDecode(void)
{
    MP3_DBG(printf("msAPI_Music_StartDecode\n"));
    MApi_AUDIO_SetCommand(MSAPI_AUD_DVB_DECCMD_PLAYFILE);//MDrv_MAD_SetDecCmd(0x04);
}

void msAPI_Music_StartBrowse(void)
{
    MP3_DBG(printf("msAPI_Music_StartBrowse\n"));
    // decode data but output no sound
    MApi_AUDIO_SetCommand(MSAPI_AUD_DVB_DECCMD_STARTBROWSE);//MDrv_MAD_SetDecCmd(0x05);
}

void msAPI_Music_StopDecode(void)
{
    MP3_DBG(printf("msAPI_Music_StopDecode\n"));
    MApi_AUDIO_SetCommand(MSAPI_AUD_DVB_DECCMD_STOP);// MDrv_MAD_SetDecCmd(0x00);
}

void msAPI_Music_PauseDecode(void)
{
    MP3_DBG(printf("msAPI_Music_PauseDecode\n"));
    MApi_AUDIO_SetCommand(MSAPI_AUD_DVB_DECCMD_PAUSE);//MDrv_MAD_SetDecCmd(0x06);
}

U8 msAPI_Music_CheckPlayDone(void)
{
    if ((MDrv_AUDIO_ReadDecMailBox(7) == 0) && (msAPI_Music_GetResidualBufferSize() <= ES_ALIGNMENT))
    {
        msAPI_Music_StopDecode();
        MP3_DBG(printf("\nPlay done"));
        return TRUE;
    }
    return FALSE;
}

EN_MP3_LAYER msAPI_Music_GetLayer(void)
{
    // MDrv_MAD_MPEG_GetLayer() return the layer of music. 1 & 2 for layer mpeg 1 & 2. 3 is for mp3
    EN_MP3_LAYER enLayer = EN_MP3_LAYER_NOT_DETERMINE_YET;

    //switch (MDrv_MAD_MPEG_GetLayer())
    switch(MApi_AUDIO_GetMpegInfo(Audio_MPEG_infoType_Layer))
    {
        case 1:
            enLayer = EN_MP3_LAYER_1;
            break;
        case 2:
            enLayer = EN_MP3_LAYER_2;
            break;
        case 3:
            enLayer = EN_MP3_LAYER_3;
            break;
    }

    return enLayer;
}

U16 msAPI_Music_GetResidualBufferSize(void)
{
    return MDrv_AUDIO_ReadDecMailBox(0) << 3; // line size is 8
}

U16 msAPI_Music_GetPCMBufferSize(U16 u16BitRate)
{
    U32 u32Tmp;

    u32Tmp = (U32)MDrv_AUDIO_ReadDecMailBox(1);
    // line size is 8, 1 sample 2 bytes and 2 channels (Left & Right)
    //u32Tmp = ((u32Tmp << 1) * ((U32)u16BitRate * 1000 / 8))/MDrv_MAD_MPEG_GetSampleRate();
    u32Tmp = ((u32Tmp << 1) * ((U32)u16BitRate * 1000 / 8))/MApi_AUDIO_GetMpegInfo(Audio_MPEG_infoType_SampleRate);
    return (U16)u32Tmp;
}

U16 msAPI_Music_GetPCMBufferSize2(U16 u16BitRate,U16 u16SampleRate)
{
    U32 u32Tmp;

    u32Tmp = (U32)MDrv_AUDIO_ReadDecMailBox(1);
    // line size is 8, 1 sample 2 bytes and 2 channels (Left & Right)
    u32Tmp = ((u32Tmp << 1) * ((U32)u16BitRate * 1000 / 8))/u16SampleRate;

    return (U16)u32Tmp;
}

U32 msAPI_Music_GetCurrentFrameNumber(void)
{
    return MApi_AUDIO_GetMpegInfo(Audio_MPEG_infoType_FrameNum);
}

U16 msAPI_Music_GetSampleRate(void)
{
    return MApi_AUDIO_GetMpegInfo(Audio_MPEG_infoType_SampleRate);
}

U16 msAPI_Music_GetBitRate(void)
{
    return MApi_AUDIO_GetMpegInfo(Audio_MPEG_infoType_BitRate);
}

U32 msAPI_Music_GetBitRateByIndex(U8 u8Version, U8 u8Layer, U8 u8BitRateIndex)
{
    U32 u32BitRate;

    if(u8BitRateIndex >= 16)
    {
        return 0;
    }
    
    if ((u8Version == 0x3) && (u8Layer == 0x3)) // V1 L1
    {
        u32BitRate = (U32) Mp3BitRateTable[0][u8BitRateIndex];
    }
    else if ((u8Version == 0x3) && (u8Layer == 0x2)) // V1 L2
    {
        u32BitRate = (U32) Mp3BitRateTable[1][u8BitRateIndex];
    }
    else if ((u8Version == 0x3) && (u8Layer == 0x1)) // V1 L3
    {
        u32BitRate = (U32) Mp3BitRateTable[2][u8BitRateIndex];
    }
    //fix MP3 wrong bitrate&total time issue while playing V2/V2.5 stream, share same table for V2&V2.5
    else if (((u8Version == 0x2)||(u8Version == 0x00)) && (u8Layer == 0x3)) // V2/V2.5 L1
    {
        u32BitRate = (U32) Mp3BitRateTable[3][u8BitRateIndex];
    }
    else if (((u8Version == 0x2)||(u8Version == 0x00)) && ((u8Layer == 0x2)||(u8Layer == 0x1))) // V2/V2.5 L2/L3
    {
        u32BitRate = (U32) Mp3BitRateTable[4][u8BitRateIndex];
    }
    else
    {
        return 0;
    }
    
    return u32BitRate;
}
/******************************************************************************/
/// API for start MP3 data transfer and decode
/// @param u32Mp3StartAddr \b IN Specify the buffer address
/// @param u32Mp3BlockSize \b IN Specify the block size
/******************************************************************************/
void msAPI_Music_SetInput(void)
{
    MDrv_AUDIO_WriteDecMailBox(6, (U16)u8IntTag);
    MDrv_AUDIO_FwTriggerDSP(0xe0);        // should change to MDrv_AUDIO_FwTriggerDSP
    u8IntTag++;
}

void msAPI_Music_SetSampleRateIndex(U16 u16Index)
{
    MDrv_AUDIO_WriteDecMailBox(4,u16Index);
}

void msAPI_Music_SetXPCMParam(XPCM_TYPE audioType, U8 channels, U16 sampleRate, U8 bitsPerSample, U16 blockSize, U16 samplePerBlock)
{
    MApi_AUDIO_XPCM_Param(audioType, channels, sampleRate, bitsPerSample, blockSize, samplePerBlock);
}

void msAPI_Music_FileEndDataHandle(U32 u32DataLeft)
{
    MP3_DBG(printf("msAPI_Music_FileEndDataHandle, u32DataLeft=0x%x\n", u32DataLeft));
    MDrv_AUDIO_WriteDecMailBox(5,(U16)(u32DataLeft>>3));
}

U8 msAPI_Music_CheckInputRequest(U32 *pU32WrtAddr, U32 *pU32WrtBytes)
{
    if (MDrv_AUDIO_GetPlayFileFlag(DSP_DEC))
    {

        MDrv_AUDIO_SetPlayFileFlag(DSP_DEC, 0);

        *pU32WrtAddr = MApi_AUDIO_GetCommAudioInfo(Audio_Comm_infoType_DEC1_BufferAddr);
        *pU32WrtAddr += (U32)((MAD_DEC_BUFFER_MEMORY_TYPE & MIU1) ? (MAD_DEC_BUFFER_ADR | MIU_INTERVAL) : (MAD_DEC_BUFFER_ADR));
        *pU32WrtBytes = MApi_AUDIO_GetCommAudioInfo(Audio_Comm_infoType_DEC1_BufferSize);

        return TRUE;
    }
    return FALSE;
}

BOOLEAN msAPI_Music_Parse_ID3v1(U32 u32FileBuffAddr, MP3_INFO *pMp3InfoPtr)
{
    U8 *pFileBufPtr;

    // u32FileBuffAddr must be 4K alignment
    pFileBufPtr = (U8 *)_PA2VA(u32FileBuffAddr);
    if ((pFileBufPtr[0] != 'T') || (pFileBufPtr[1] != 'A') || (pFileBufPtr[2] != 'G'))
    {
        return FALSE;
    }

    pMp3InfoPtr->title[0] = 0;  // indicate ASCII
    pMp3InfoPtr->title[31] = 0;
    pMp3InfoPtr->u8TitleLength = MP3_TAG_ID3v1_LENGTH;
    memcpy(pMp3InfoPtr->title+1, pFileBufPtr+3, 30);

    pMp3InfoPtr->artist[0] = 0;  // indicate ASCII
    pMp3InfoPtr->artist[31] = 0;
    pMp3InfoPtr->u8ArtistLength = MP3_TAG_ID3v1_LENGTH;
    memcpy(pMp3InfoPtr->artist+1, pFileBufPtr+33, 30);

    pMp3InfoPtr->album[0] = 0;  // indicate ASCII
    pMp3InfoPtr->album[31] = 0;
    pMp3InfoPtr->u8AlbumLength = MP3_TAG_ID3v1_LENGTH;
    memcpy(pMp3InfoPtr->album+1, pFileBufPtr+63, 30);

    pMp3InfoPtr->year[0] = 0;  // indicate ASCII
    pMp3InfoPtr->year[5] = 0;
    memcpy(pMp3InfoPtr->year+1, pFileBufPtr+93, 4);

    pMp3InfoPtr->comment[0] = 0;  // indicate ASCII
    pMp3InfoPtr->comment[31] = 0;
    memcpy(pMp3InfoPtr->comment+1, pFileBufPtr+97, 30);

    pMp3InfoPtr->genre = pFileBufPtr[127];

    MP3_DBG(printf("\nTitle: %s", pMp3InfoPtr->title+1));
    MP3_DBG(printf("\nArtist: %s", pMp3InfoPtr->artist+1));
    MP3_DBG(printf("\nAlbum: %s", pMp3InfoPtr->album+1));
    MP3_DBG(printf("\nyear: %s", pMp3InfoPtr->year+1));
    MP3_DBG(printf("\nComment: %s", pMp3InfoPtr->comment+1));

    return TRUE;
}

U32 msAPI_Music_Parse_ID3v2(U32 u32FileHandle, U32 u32FileBuffAddr, U32 u32FileBuffLen, MP3_INFO *pMp3InfoPtr, BOOLEAN bGetMp3OffsetOnly)
{
    U32 currentIdx, u32baseIdx;
    U32 u32FrameId, u32FrameSize, u32TagSize;
    U8 *pDstPtr=NULL, *pFileBufPtr, u8ID3Ver, u8CopyLen,u8OffsetTemp;

    // u32FileBuffAddr must be 4K alignment
    pFileBufPtr = (U8 *)_PA2VA(u32FileBuffAddr);
    if ((pFileBufPtr[0] != 'I') || (pFileBufPtr[1] != 'D') || (pFileBufPtr[2] != '3'))
    {
        MP3_DBG(printf("\nNo ID3 tag"));
        return 0;
    }

    u8ID3Ver = pFileBufPtr[3];

    u32TagSize = (U32) (pFileBufPtr[6] & 0x7F);
    u32TagSize <<= 7;
    u32TagSize |= (U32) (pFileBufPtr[7] & 0x7F);
    u32TagSize <<= 7;
    u32TagSize |= (U32) (pFileBufPtr[8] & 0x7F);
    u32TagSize <<= 7;
    u32TagSize |= (U32) (pFileBufPtr[9] & 0x7F);

    if (bGetMp3OffsetOnly == TRUE)
    {
        return (u32TagSize + 10);
    }

    if(u8ID3Ver == 0x02)
    {
        u8OffsetTemp=0x6;
    }
    else //u8ID3Ver == 0x03 , u8ID3Ver == 0x04
    {
        u8OffsetTemp=0xA;
    }

    u32baseIdx = 0;
    currentIdx = 0x0A;
//    while (currentIdx != (u32TagSize + 10))
    while (currentIdx <= (u32TagSize + 10)) //avoid endless loop
    {
        if(currentIdx > u32FileBuffLen - u8OffsetTemp)
        {
            u32baseIdx += currentIdx;
            msAPI_DataStreamIO_Seek(u32FileHandle, u32baseIdx, E_DATA_STREAM_SEEK_SET);
            msAPI_DataStreamIO_Read(u32FileHandle, (void*)u32FileBuffAddr, u32FileBuffLen);
            currentIdx = 0;
        }

        u8CopyLen = 0;
        if(u8ID3Ver == 0x02)
        {
            memcpy(&u32FrameId,pFileBufPtr + currentIdx,4);
            u32FrameId = (Swap32(u32FrameId) >>8) & 0x00FFFFFF;
            memcpy(&u32FrameSize,pFileBufPtr + currentIdx + 3,4);
            u32FrameSize = (Swap32(u32FrameSize)>>8) & 0x00FFFFFF;
            if (u32FrameId == 0x00000000)
                break;

            if(currentIdx + u32FrameSize + u8OffsetTemp > u32FileBuffLen)
            {
                if(currentIdx != 0)
                {
                    u32baseIdx += currentIdx;
                    msAPI_DataStreamIO_Seek(u32FileHandle, u32baseIdx, E_DATA_STREAM_SEEK_SET);
                    msAPI_DataStreamIO_Read(u32FileHandle, (void*)u32FileBuffAddr, u32FileBuffLen);
                    currentIdx = 0;
                }
            }

            switch (u32FrameId)
            {
                case MP3_TAG_ID3v2_2_TAL:
                    pDstPtr = (U8*)pMp3InfoPtr->album;
                    pMp3InfoPtr->u8AlbumLength = u32FrameSize;
                    if (u32FrameSize > (sizeof(pMp3InfoPtr->album)-1))
                        u8CopyLen = sizeof(pMp3InfoPtr->album)-1;
                    else
                        u8CopyLen = u32FrameSize;
                    memset(pDstPtr, 0, sizeof(pMp3InfoPtr->album));
                    break;
                case MP3_TAG_ID3v2_2_TCM:
                    pDstPtr = (U8*)pMp3InfoPtr->artist;
                    pMp3InfoPtr->u8ArtistLength = u32FrameSize;
                    if (u32FrameSize > (sizeof(pMp3InfoPtr->artist)-1))
                        u8CopyLen = sizeof(pMp3InfoPtr->artist)-1;
                    else
                        u8CopyLen = u32FrameSize;
                    memset(pDstPtr, 0, sizeof(pMp3InfoPtr->artist));
                    break;
                case MP3_TAG_ID3v2_2_TT2:
                    pDstPtr = (U8*)pMp3InfoPtr->title;
                    pMp3InfoPtr->u8TitleLength = u32FrameSize;
                    if (u32FrameSize > (sizeof(pMp3InfoPtr->title)-1))
                        u8CopyLen = sizeof(pMp3InfoPtr->title)-1;
                    else
                        u8CopyLen = u32FrameSize;
                    memset(pDstPtr, 0, sizeof(pMp3InfoPtr->title));
                    break;
                case MP3_TAG_ID3v2_2_TYE:
                    pDstPtr = (U8*)pMp3InfoPtr->year;
                    if (u32FrameSize > (sizeof(pMp3InfoPtr->year)-1))
                        u8CopyLen = sizeof(pMp3InfoPtr->year)-1;
                    else
                        u8CopyLen = u32FrameSize;
                    memset(pDstPtr, 0, sizeof(pMp3InfoPtr->year));
                    break;
                case MP3_TAG_ID3v2_2_PIC:
                    {
                        U8 strJpg[]="JPG";
                        u8CopyLen=0;
                        if((strcasecmp((const char *)(pFileBufPtr + currentIdx + u8OffsetTemp+1), (const char *)strJpg))==0)
                        {
                            U16 offset;
                            offset=currentIdx+u8OffsetTemp+1+3;
                            MP3_DBG(printf("found jpeg tag\n"));

                            //Picture type
                            offset++;

                            //Description
                            while(*((U8*)pFileBufPtr+offset)!=0)
                            {
                                offset++;
                            }
                            //Description '\0'
                            offset++;

                            //picture data
                            MP3_DBG(printf("offset=%d\n",offset));

                            pMp3InfoPtr->jpgOffset=u32baseIdx+offset;
                            pMp3InfoPtr->jpgSize=u32FrameSize-(offset-currentIdx-u8OffsetTemp);
                            MP3_DBG(printf("size=%d\n",pMp3InfoPtr->jpgSize));
                        }
                    }
                    break;
            }
        }
        else if(u8ID3Ver == 0x03 || u8ID3Ver == 0x04)
        {
            U8 bytes[4];
            U8 *tagSize;

            memcpy(&u32FrameId,pFileBufPtr + currentIdx,4);
            u32FrameId = Swap32(u32FrameId);
            tagSize = (U8*)&(pFileBufPtr[currentIdx + 4]);
            // The ID3v2 tag size is encoded with four bytes
            // where the most significant bit (bit 7)
            // is set to zero in every byte,
            // making a total of 28 bits.
            // The zeroed bits are ignored
            if(u8ID3Ver == 0x04)
            {
            bytes[3] =  tagSize[3]             | ((tagSize[2] & 1) << 7) ;
            bytes[2] = ((tagSize[2] >> 1) & 63) | ((tagSize[1] & 3) << 6) ;
            bytes[1] = ((tagSize[1] >> 2) & 31) | ((tagSize[0] & 7) << 5) ;
            bytes[0] = ((tagSize[0] >> 3) & 15) ;
            }
            else
            {
                bytes[3] = tagSize[3];
                bytes[2] = tagSize[2];
                bytes[1] = tagSize[1];
                bytes[0] = tagSize[0];
            }

            u32FrameSize  = ((U32)bytes[3] |
			((U32)bytes[2] << 8)  |
			((U32)bytes[1] << 16) |
			((U32)bytes[0] << 24)) ;

            if (u32FrameId == 0x00000000)
                break;

            if(currentIdx + u32FrameSize + u8OffsetTemp > u32FileBuffLen)
            {
                if(currentIdx != 0)
                {
                    u32baseIdx += currentIdx;
                    msAPI_DataStreamIO_Seek(u32FileHandle, u32baseIdx, E_DATA_STREAM_SEEK_SET);
                    msAPI_DataStreamIO_Read(u32FileHandle, (void*)u32FileBuffAddr, u32FileBuffLen);
                    currentIdx = 0;
                }
            }

            switch (u32FrameId)
            {
                case MP3_TAG_ID3v2_3_TALB:
                    pDstPtr = (U8*)pMp3InfoPtr->album;
                    pMp3InfoPtr->u8AlbumLength = u32FrameSize;
                    if (u32FrameSize > (sizeof(pMp3InfoPtr->album)-1))
                        u8CopyLen = sizeof(pMp3InfoPtr->album)-1;
                    else
                        u8CopyLen = u32FrameSize;
                    memset(pDstPtr, 0, sizeof(pMp3InfoPtr->album));
                    break;
                case MP3_TAG_ID3v2_3_TPE1:
                    pDstPtr = (U8*)pMp3InfoPtr->artist;
                    pMp3InfoPtr->u8ArtistLength = u32FrameSize;
                    if (u32FrameSize > (sizeof(pMp3InfoPtr->artist)-1))
                        u8CopyLen = sizeof(pMp3InfoPtr->artist)-1;
                    else
                        u8CopyLen = u32FrameSize;
                    memset(pDstPtr, 0, sizeof(pMp3InfoPtr->artist));
                    break;
                case MP3_TAG_ID3v2_3_TIT2:
                    pDstPtr = (U8*)pMp3InfoPtr->title;
                    pMp3InfoPtr->u8TitleLength = u32FrameSize;
                    if (u32FrameSize > (sizeof(pMp3InfoPtr->title)-1))
                        u8CopyLen = sizeof(pMp3InfoPtr->title)-1;
                    else
                        u8CopyLen = u32FrameSize;
                    memset(pDstPtr, 0, sizeof(pMp3InfoPtr->title));
                    break;
                case MP3_TAG_ID3v2_3_TYER:
                    pDstPtr = (U8*)pMp3InfoPtr->year;
                    if (u32FrameSize > (sizeof(pMp3InfoPtr->year)-1))
                        u8CopyLen = sizeof(pMp3InfoPtr->year)-1;
                    else
                        u8CopyLen = u32FrameSize;
                    memset(pDstPtr, 0, sizeof(pMp3InfoPtr->year));
                    break;
                case MP3_TAG_ID3v2_4_TDRC:
                    pDstPtr = (U8*)pMp3InfoPtr->year;
                    if (u32FrameSize > (sizeof(pMp3InfoPtr->year)-1))
                        u8CopyLen = sizeof(pMp3InfoPtr->year)-1;
                    else
                        u8CopyLen = u32FrameSize;
                    memset(pDstPtr, 0, sizeof(pMp3InfoPtr->year));
                    break;
                case MP3_TAG_ID3v2_3_APIC:
                {
                    U8 strJpg[]="image/jpeg";
                    u8CopyLen=0;
                    if((strcasecmp((const char *)(pFileBufPtr + currentIdx + u8OffsetTemp+1), (const char *)strJpg))==0)
                    {
                        U16 offset;
                        offset=currentIdx+u8OffsetTemp+1;
                        MP3_DBG(printf("found jpeg tag\n"));

                        //MINE type
                        while(*((U8*)pFileBufPtr+offset)!=0)
                        {
                            offset++;
                        }
                        //MINE type '\0'
                        offset++;

                        //Picture type
                        offset++;

                        //Description
                        while(*((U8*)pFileBufPtr+offset)!=0)
                        {
                            offset++;
                        }
                        //Description '\0'
                        offset++;

                        //picture data
                        MP3_DBG(printf("offset=%d\n",offset));

                        pMp3InfoPtr->jpgOffset=u32baseIdx+offset;
                        pMp3InfoPtr->jpgSize=u32FrameSize-(offset-currentIdx-u8OffsetTemp);
                        MP3_DBG(printf("size=%d\n",pMp3InfoPtr->jpgSize));
                    }
                }
                    break;
            }
        }
        else
        {
            //Not support!
            break;
        }

        if(u8CopyLen != 0)
        {
            memcpy(pDstPtr, pFileBufPtr + currentIdx + u8OffsetTemp, u8CopyLen);
        }

        currentIdx += (u32FrameSize + u8OffsetTemp);
    }

    MP3_DBG(printf("\nTitle: %s", pMp3InfoPtr->title+1));
    MP3_DBG(printf("\nArtist: %s", pMp3InfoPtr->artist+1));
    MP3_DBG(printf("\nAlbum: %s", pMp3InfoPtr->album+1));
    MP3_DBG(printf("\nyear: %s", pMp3InfoPtr->year+1));
    MP3_DBG(printf("\nComment: %s", pMp3InfoPtr->comment+1));

    return (u32TagSize + 10);
}

U32 msAPI_Music_GetPlayTick(void)
{
    return MApi_AUDIO_GetCommAudioInfo(Audio_Comm_infoType_1ms_PTS);
}

U16 msAPI_Music_GetEsMEMCnt(void)
{
    return MApi_AUDIO_GetCommAudioInfo(Audio_Comm_infoType_DEC1_PCMBufferSize);
}

void msAPI_Music_CleanFileEndData(U32 StrAddr, U32 length, U32 ClearValue)
{
    MP3_DBG(printf("msAPI_Music_CleanFileEndData, addr=0x%x, len=0x%x\n", StrAddr, length));
    //MApi_GFX_ClearFrameBufferByWord() didn't work in T4 m4a case??
    //anyway, use memset to clear
    //MApi_GFX_ClearFrameBufferByWord(StrAddr, length, ClearValue);
    memset((void*)_PA2VA(StrAddr), ClearValue, length);    
    MApi_GFX_FlushQueue();
}

U32 msAPI_Music_GetMP3CBRFrameSize(U8 u8Version,U8 u8Layer,U8 u8PaddingFlag,U8 u8SampleRateIndex,U8 u8BitRateIndex)
{
    U32 u32FrameSize = 0;
    U16 u16SampleRate = 0;
    U32 u32BitRate;

    if (u8Version == EN_MP3_VERSION_2_5) // v2.5
    {
        u16SampleRate = Mp3SampleRateTable[0][u8SampleRateIndex];
    }
    else if (u8Version == EN_MP3_VERSION_2) // v2
    {
        u16SampleRate = Mp3SampleRateTable[1][u8SampleRateIndex];
    }
    else if (u8Version == EN_MP3_VERSION_1) // v1
    {
        u16SampleRate = Mp3SampleRateTable[2][u8SampleRateIndex];
    }
    else
    {
        return 0;
    }

    if ((u8Version == 0x3) && (u8Layer == 0x3)) // V1 L1
    {
        u32BitRate = (U32) Mp3BitRateTable[0][u8BitRateIndex];
    }
    else if ((u8Version == 0x3) && (u8Layer == 0x2)) // V1 L2
    {
        u32BitRate = (U32) Mp3BitRateTable[1][u8BitRateIndex];
    }
    else if ((u8Version == 0x3) && (u8Layer == 0x1)) // V1 L3
    {
        u32BitRate = (U32) Mp3BitRateTable[2][u8BitRateIndex];
    }
    //fix MP3 wrong bitrate&total time issue while playing V2/V2.5 stream, share same table for V2&V2.5
    else if (((u8Version == 0x2)||(u8Version == 0x00)) && (u8Layer == 0x3)) // V2/V2.5 L1
    {
        u32BitRate = (U32) Mp3BitRateTable[3][u8BitRateIndex];
    }
    else if (((u8Version == 0x2)||(u8Version == 0x00)) && ((u8Layer == 0x2)||(u8Layer == 0x1))) // V2/V2.5 L2/L3
    {
        u32BitRate = (U32) Mp3BitRateTable[4][u8BitRateIndex];
    }
    else
    {
        return 0;
    }

    if ((u16SampleRate == 0xffff) || (u32BitRate == 0xffff))
    {
        return 0;
    }
    else
    {
        // Samples Per Frame: ref:http://www.codeproject.com/KB/audio-video/mpegaudioinfo.aspx
        // Frame Size = ( (Samples Per Frame / 8 * Bitrate) / Sampling Rate) + Padding Size
        //             |MPEG 1 |MPEG 2 (LSF) | MPEG 2.5 (LSF)
        // Layer I   |  384    |   384           |     384    
        // Layer II  | 1152   |   1152          |    1152
        // Layer III | 1152   |   576           |     576
        if (u8Layer == EN_MP3_LAYER_1)
        {
            u32FrameSize = (((48 * u32BitRate) * 1000) / u16SampleRate);
            u32FrameSize = ((u32FrameSize>>2)<<2);
            //In Layer I, a slot is always 4 byte long, in all other the layers a slot is 1 byte long.
            if(u8PaddingFlag)
            {
                u32FrameSize += 4;
            }
        }
        else if ((u8Layer == EN_MP3_LAYER_2) || ((u8Version == EN_MP3_VERSION_1) && (u8Layer == EN_MP3_LAYER_3)))
        {
            u32FrameSize = ((144 * u32BitRate * 1000) / u16SampleRate) + u8PaddingFlag;
        }
        else
        {
            u32FrameSize = ((72 * u32BitRate * 1000) / u16SampleRate) + u8PaddingFlag;
        }
    }

    return u32FrameSize;
}

U32 msAPI_Music_GetFileTime(
        U32 u32FileBuffAddr,
        U32 u32FileSize,
        EN_MP3_VERSION *penVersion,
        EN_MP3_LAYER *penLayer,
        U16 *pu16BitRate,
        U16 *pu16SampleRate,
        U8 *pbFlag,
        U16 *pu16TOCLength,
        U8 *pu8TOC)
{
    U8 *pFileBufPtr;
    U32 u32Tag, u32FrameCnt=0;
    U16 u16SampleRate;
    U8 u8Version, u8Layer, u8Offset;
    U16 u16Mp3HeaderOffset;
    U8  u8PaddingFlag;
    U32 u32Mp3FileTime;
    U32 u32MemPos = u32FileBuffAddr-((MP3_INFO_READ_MEMORY_TYPE & MIU1) ? (MP3_INFO_READ_ADR | MIU_INTERVAL) : (MP3_INFO_READ_ADR));
    U8 u8HeaderSecondByte;

    *pbFlag = 0;
    *pu16TOCLength = 0 ;

    pFileBufPtr = (U8*)_PA2VA(u32FileBuffAddr);
    // Seek the file to find the MP3 header, max seek 4096 bytes
    u16Mp3HeaderOffset = 0;
//Mp3_Get_FirstFrame: // update to fix "cannot play ILOVEU.mp3"
    while((!(pFileBufPtr[u16Mp3HeaderOffset] == 0xff &&
            (pFileBufPtr[u16Mp3HeaderOffset+1] & 0xe0) == 0xe0))
        &&((u16Mp3HeaderOffset+u32MemPos)<0xFFE))
    {
        u16Mp3HeaderOffset++;
    }
    if (!(pFileBufPtr[u16Mp3HeaderOffset] == 0xff && (pFileBufPtr[u16Mp3HeaderOffset+1] & 0xe0) == 0xe0))
    {
        return 0;   // not MP3 file
    }

    u8Version = (pFileBufPtr[u16Mp3HeaderOffset+1] >> 0x3) & 0x3;
    u8Layer = (pFileBufPtr[u16Mp3HeaderOffset+1] >> 0x1) & 0x3;
    *penVersion= (EN_MP3_VERSION)u8Version;
    *penLayer = (EN_MP3_LAYER)u8Layer;
    u8HeaderSecondByte = pFileBufPtr[u16Mp3HeaderOffset+1];

    u8PaddingFlag = (pFileBufPtr[u16Mp3HeaderOffset+2] & 0x02) >> 1;
    u16SampleRate = (pFileBufPtr[u16Mp3HeaderOffset+2] & 0x0c) >> 2;
    if (u8Version == EN_MP3_VERSION_2_5) // v2.5
    {
        u16SampleRate = Mp3SampleRateTable[0][u16SampleRate];
    }
    else if (u8Version == EN_MP3_VERSION_2) // v2
    {
        u16SampleRate = Mp3SampleRateTable[1][u16SampleRate];
    }
    else if (u8Version == EN_MP3_VERSION_1) // v1
    {
        u16SampleRate = Mp3SampleRateTable[2][u16SampleRate];
    }
    else
    {
        u16SampleRate = 0xffff;
    }
    *pu16SampleRate = u16SampleRate;

    u8Offset = 36;  // mpeg1, channel != mono
    //u32Tag = *(U32 *)(pFileBufPtr + u16Mp3HeaderOffset + u8Offset);
    memcpy(&u32Tag,(pFileBufPtr + u16Mp3HeaderOffset + u8Offset),4);
    u32Tag=Swap32(u32Tag);
    if (u32Tag == MP3_TAG_XING)
    {
        *pbFlag |= MP3_FLAG_VBR_XING;
    }
    else if(u32Tag == MP3_TAG_VBRI)
    {
        *pbFlag |= MP3_FLAG_VBR_VBRI;
    }
    else
    {
        u8Offset = 21;  // mpeg1, channel == mono or mpeg2, channel != mono
        //u32Tag = *(U32 *)(pFileBufPtr + u16Mp3HeaderOffset + u8Offset);
        memcpy(&u32Tag,(pFileBufPtr + u16Mp3HeaderOffset + u8Offset),4);
        u32Tag=Swap32(u32Tag);
        if (u32Tag == MP3_TAG_XING)
        {
            *pbFlag |= MP3_FLAG_VBR_XING;
        }
        else
        {
            u8Offset = 13;  // mpeg1, channel == monoo
            //u32Tag = *(U32 *)(pFileBufPtr + u16Mp3HeaderOffset + u8Offset);
            memcpy(&u32Tag,(pFileBufPtr + u16Mp3HeaderOffset + u8Offset),4);
            u32Tag=Swap32(u32Tag);
            if (u32Tag == MP3_TAG_XING)
            {
                *pbFlag |= MP3_FLAG_VBR_XING;
            }
        }
    }

    if(*pbFlag & MP3_FLAG_VBR_XING)               // VBR_Xing
    {
        if(pFileBufPtr[u16Mp3HeaderOffset + u8Offset + 7] & XING_FRAMES)
        {
            //u32FrameCnt = *(U32 *) (pFileBufPtr + u16Mp3HeaderOffset + u8Offset + 8);
            memcpy(&u32FrameCnt,(pFileBufPtr + u16Mp3HeaderOffset + u8Offset + 8),4);
            u32FrameCnt=Swap32(u32FrameCnt);  //SPEC: Big-endian
        }

        if(u32FrameCnt == 0)
        {
            //__ASSERT(0);
            return 0;
        }
        else
        {
            if ((pFileBufPtr[u16Mp3HeaderOffset + 1] & 0x08) == 0x08)
            {
                u32FrameCnt *= MP3_SAMPLE_PER_FRAME;
            }
            else
            {
                u32FrameCnt *= MP3_SAMPLE_PER_FRAME_LSF;
            }

            u32Mp3FileTime = u32FrameCnt / u16SampleRate;

            *pu16BitRate = (U16)(u32FileSize*8 / (u32FrameCnt/(u16SampleRate/1000)));

            if ((pFileBufPtr[u16Mp3HeaderOffset + u8Offset + 7] & XING_TOC) && (pu8TOC != NULL))
            {
                *pu16TOCLength=100;
                memcpy(pu8TOC, pFileBufPtr + u16Mp3HeaderOffset + u8Offset + 16, 100);
            }
        }
    }
    else if(*pbFlag & MP3_FLAG_VBR_VBRI)   //VBR_VBRI
    {
        //u32FrameCnt = *(U32 *) (pFileBufPtr + u16Mp3HeaderOffset + u8Offset + 14);
        memcpy(&u32FrameCnt,(pFileBufPtr + u16Mp3HeaderOffset + u8Offset + 14),4);
        u32FrameCnt=Swap32(u32FrameCnt);  //SPEC: Big-endian

        if ((pFileBufPtr[u16Mp3HeaderOffset + 1] & 0x08) == 0x08)
        {
            u32FrameCnt *= MP3_SAMPLE_PER_FRAME;
        }
        else
            u32FrameCnt *= MP3_SAMPLE_PER_FRAME_LSF;

        u32Mp3FileTime = u32FrameCnt / u16SampleRate;

        *pu16BitRate = (U16)(u32FileSize*8 / (u32FrameCnt/(u16SampleRate/1000)));

        //*pu16TOCLength = *(U16 *)(pFileBufPtr + u16Mp3HeaderOffset + u8Offset + 18);
        memcpy(pu16TOCLength,(pFileBufPtr + u16Mp3HeaderOffset + u8Offset + 18), 2);
        if(*pu16TOCLength>0 && *pu16TOCLength<100)
        {
           memcpy(pu8TOC, pFileBufPtr + u16Mp3HeaderOffset + u8Offset + 26, *pu16TOCLength);
        }
    }
    else  //CBR
    {
#if 0
        //Check 1~5 frame bitrate
        U8 u8FrameCount = 0;
        U8 u8Version_I,u8Layer_I,u8PaddingFlag_I,u8SampleRateIndex_I,u8BitRateIndex_I;
        U32 u32FrameSize_I;

        while((u8FrameCount<5) && ((u16Mp3HeaderOffset+u32MemPos)<0xFFE))
        {
            //printf("Data-> [0]:%02x [1]:%02x [2]:%02x\n",pFileBufPtr[u16Mp3HeaderOffset],pFileBufPtr[u16Mp3HeaderOffset+1],pFileBufPtr[u16Mp3HeaderOffset+2]);

            while( (!(pFileBufPtr[u16Mp3HeaderOffset] == 0xff &&
                        (pFileBufPtr[u16Mp3HeaderOffset+1]) == u8HeaderSecondByte))
                        && ((u16Mp3HeaderOffset+u32MemPos)<0xFFE))
            {
                u16Mp3HeaderOffset++;
            }

            u8Version_I = (pFileBufPtr[u16Mp3HeaderOffset+1] >> 0x3) & 0x3;
            u8Layer_I = (pFileBufPtr[u16Mp3HeaderOffset+1] >> 0x1) & 0x3;
            u8PaddingFlag_I = (pFileBufPtr[u16Mp3HeaderOffset+2] & 0x02) >> 1;
            u8SampleRateIndex_I = (pFileBufPtr[u16Mp3HeaderOffset+2] & 0x0c) >> 2;
            u8BitRateIndex_I = ((pFileBufPtr[u16Mp3HeaderOffset+2]>>4) & 0x0F);

            u32FrameSize_I = msAPI_Music_GetMP3CBRFrameSize(u8Version_I, u8Layer_I, u8PaddingFlag_I, u8SampleRateIndex_I, u8BitRateIndex_I);

            //find next header, u8BitRateIndex shoud be same
            if( (u16Mp3HeaderOffset+u32MemPos+2) >= 0xFFE )
            {
                u8FrameCount = 0;
                break;
            }
            else if( (u8BitRateIndex_I != (pFileBufPtr[u16Mp3HeaderOffset+u32FrameSize_I+2]>>4)) ||
                       (u32FrameSize_I == 0) )
            {
                u16Mp3HeaderOffset++;
                u8FrameCount = 0;
                continue;
            }
            u8FrameCount++;
        }

        if(u8FrameCount<5)
        {
            u32Mp3FileTime = 0;
        }
        else
        {
            if ((u8Version == 0x3) && (u8Layer == 0x3)) // V1 L1
            {
                u32BitRate = (U32) Mp3BitRateTable[0][pFileBufPtr[u16Mp3HeaderOffset+2] >> 4];
            }
            else if ((u8Version == 0x3) && (u8Layer == 0x2)) // V1 L2
            {
                u32BitRate = (U32) Mp3BitRateTable[1][pFileBufPtr[u16Mp3HeaderOffset+2] >> 4];
            }
            else if ((u8Version == 0x3) && (u8Layer == 0x1)) // V1 L3
            {
                u32BitRate = (U32) Mp3BitRateTable[2][pFileBufPtr[u16Mp3HeaderOffset+2] >> 4];
            }
            //fix MP3 wrong bitrate&total time issue while playing V2/V2.5 stream, share same table for V2&V2.5
            else if (((u8Version == 0x2)||(u8Version == 0x00)) && (u8Layer == 0x3)) // V2/V2.5 L1
            {
                u32BitRate = (U32) Mp3BitRateTable[3][pFileBufPtr[u16Mp3HeaderOffset+2] >> 4];
            }
            else if (((u8Version == 0x2)||(u8Version == 0x00)) && ((u8Layer == 0x2)||(u8Layer == 0x1))) // V2/V2.5 L2/L3
            {
                u32BitRate = (U32) Mp3BitRateTable[4][pFileBufPtr[u16Mp3HeaderOffset+2] >> 4];
            }
            else
            {
                u32BitRate = 0xffff;
            }

            if ((u16SampleRate == 0xffff) || (u32BitRate == 0xffff))
            {
                u32FrameSize = 2;
            }
            else
            {
                if (u8Version == EN_MP3_VERSION_1)
                    u32FrameSize = 144*u32BitRate*1000/u16SampleRate+u8PaddingFlag;
                else
                    u32FrameSize = 72*u32BitRate*1000/u16SampleRate+u8PaddingFlag;
            }
            u16Mp3HeaderOffset += u32FrameSize;
            if (!(pFileBufPtr[u16Mp3HeaderOffset] == 0xff && (pFileBufPtr[u16Mp3HeaderOffset+1] & 0xe0) == 0xe0))
            {
                //printf("Not a valid mp3 frame, Seek next!\n");
                u16Mp3HeaderOffset -= (u32FrameSize-1); //Bug fixed by Richard.0911
                goto Mp3_Get_FirstFrame;
            }

            *pu16BitRate = (U16)(u32BitRate);
            u32BitRate *= 1000;
            u32Mp3FileTime =  (U32)(u32FileSize / (u32BitRate >> 3));
        }
#else
    u32Mp3FileTime = 0;
#endif
    }

    return u32Mp3FileTime;
}




////////////////////////////////////////////////////////////////////////////////
#undef MSAPI_MUSIC_C

////////////////////////////////////////////////////////////////////////////////
#endif // #if (ENABLE_DMP)

