////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (¡§MStar Confidential Information¡¨) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#define MAPP_ZUI_ACTMAINPAGE_C
#define _ZUI_INTERNAL_INSIDE_ //NOTE: for ZUI internal

#ifdef MSOS_TYPE_LINUX
#include <unistd.h>
#endif

//-------------------------------------------------------------------------------------------------
// Include Files
//-------------------------------------------------------------------------------------------------
#include "Board.h"
#include "datatype.h"
#include "MsCommon.h"

#include "apiXC.h"
#include "apiXC_Adc.h"
#include "MApp_GlobalSettingSt.h"
#include "msAPI_Global.h"
#include "msAPI_VD.h"
#include "MApp_ZUI_Main.h"
#include "MApp_ZUI_APIcommon.h"
#include "MApp_ZUI_APIstrings.h"
#include "MApp_ZUI_APIwindow.h"
#include "ZUI_tables_h.inl"
#include "MApp_ZUI_APIgdi.h"
#include "MApp_ZUI_APIcontrols.h"
#include "MApp_ZUI_ACTmainpage.h"
#include "MApp_ZUI_ACTeffect.h"
#include "MApp_ZUI_ACTglobal.h"
#include "MApp_ZUI_ACTaudlang.h"
#include "MApp_ZUI_APIdraw.h"
#include "MApp_ZUI_ACTglobal.h"
#include "MApp_ZUI_APIcomponent.h"
#include "OSDcp_String_EnumIndex.h"
#include "OSDcp_Bitmap_EnumIndex.h"
#include "ZUI_exefunc.h"
#include "MApp_ZUI_ACTmenufunc.h"
#include"MApp_ZUI_ACTcoexistWin.h"
#include "apiXC_Sys.h"
#include "apiXC_Adc.h"
#include "apiAUDIO.h"
#include "MApp_Menu_Main.h"
#include "apiXC_Ace.h"
#if (ENABLE_ATV_VCHIP)
#include "MApp_UiMenuFunc.h"
#endif

#include "MApp_GlobalFunction.h"
#include "MApp_UiMenuDef.h"
#include "msAPI_Mode.h"
#include "apiXC_Ace.h"
#include "MApp_Scaler.h"
#include "MApp_XC_PQ.h"

#include "MApp_ZUI_ACTmenufunc.h"
#include "MApp_ZUI_ACTsetclockfunc.h"
#include "MApp_ZUI_ACTnetconfig.h"
#include "MApp_ZUI_ACTtuneconfirmfunc.h"
#include "MApp_ZUI_ACTmenudlgfunc.h"
#include "MApp_ZUI_ACTmainpage.h"
#include "MApp_ZUI_ACTsublang.h"

#include "MApp_SaveData.h"
#include "MApp_Sleep.h"

#if (ENABLE_DTV)
#include "mapp_demux.h"
#endif
#include "MApp_ChannelChange.h"
#include "msAPI_audio.h"
#include "msAPI_OSD.h"
#include "MApp_Scaler.h"
#include <stdio.h>
#include <string.h>
#include "msAPI_Memory.h"
#include "MApp_PrEdit_Main.h"
#include "MApp_OSDPage_Main.h"

#if ENABLE_CI
#include "msAPI_CI.h"
#endif

#include "MApp_Audio.h"
#include "MApp_InputSource.h"
#include "MApp_ZUI_ACTinputsource.h"
#include "MApp_ZUI_APIalphatables.h"
#include "MApp_ZUI_APIstyletables.h"
#include "MApp_USBDownload.h"
#include "MApp_UiPvr.h"
#include "MApp_TopStateMachine.h"

#ifdef MSOS_TYPE_LINUX
#include "madp.h"
#include "msAPI_APEngine.h"
#endif
#include "drvUSB.h"
#include "drvPWM.h"
#include "msAPI_OCP.h"
#include "MApp_Font.h"

#if ENABLE_DMP
#include "MApp_DMP_Main.h"
#endif

#if DVB_C_ENABLE
#include "MApp_ZUI_ACTcadtvmanualtuning.h"
#include "MApp_CADTV_Proc.h"
#include "MApp_Scan.h"
#endif
#if (ENABLE_DTV)
#include "MApp_MultiTasks.h"
#endif
#include "msAPI_Tuning.h"

#include "drvIPAUTH.h"
#include "MApp_ZUI_ACTmainpage_predit.h"
#include "msAPI_FreqTableATV.h"
#include "msAPI_Bootloader.h"
#include "imginfo.h"
#include "drvGPIO.h"
#if ENABLE_CUS_BLOCK_SYS
#include "MApp_BlockSys.h"
#endif

#include "MApp_ZUI_ACTfactorymenu.h"



#if ENABLE_6M30_3D_PROCESS
#include "drvUrsa6M30.h"
#endif

extern unsigned char code Customer_hash[];
extern unsigned char Customer_info[];

/////////////////////////////////////////////////////////////////////
#ifdef MSOS_TYPE_LINUX
extern U8 au8VisibleAPPList[];
#endif
#ifdef NETWORK_CONFIG
BOOLEAN bNetworkHWStatus;
BOOLEAN bNetworkIntranetStatus;
BOOLEAN bNetworkInternetStatus;
BOOLEAN bNetworkDNSStatus;
BOOLEAN bNetworkIPStatus;
#endif

extern EN_PREDIT_MODE _eProgramEditMode;
extern EN_MENU_STATE enMainMenuState;

static EN_MENU_STATE _enTargetMenuState;
static BOOLEAN bEnterPW2ChannelsList = FALSE;

COMMON_DLG_MODE _eCommonDlgMode, _ePrevCommonDlgMode;

#if (ENABLE_CUS_UI_SPEC == FALSE) /*Creass.liu at 2012-06-27*/
COMMON_SINGLELIST_MODE _eCommonSingleMode;
COMMON_OPTIONLIST_MODE _eCommonOptionMode;
#endif
//replaced by focus checkpoint: HWND            _hwndCommonDlgPrevFocus;
HWND            _hwndCommonDlgTargetFocus;

extern EN_OSD_TUNE_TYPE_SETTING eTuneType;
extern U16 _MApp_ZUI_ACT_PasswordConvertToSystemFormat(U16 password);
extern void _MApp_ZUI_API_ConvertComponentToDynamic(DRAWCOMPONENT comp, U16 u16CompIndex, void * pDraw);

extern BOOLEAN _MApp_ZUI_API_AllocateVarData(void);
extern BOOLEAN MDrv_UsbDeviceConnect(void);
extern BOOLEAN MDrv_UsbDeviceConnect_Port2(void);
//extern LPTSTR MApp_ZUI_ACT_GetAppDynamicText(HWND hwnd);
extern void MApp_ZUI_SwUpdate_ProgressBar(U8 percent);
extern U8 MDrv_USBGetPortEnableStatus(void);

#define MAIN_MENU_ICON_NUM 5// 6
static U32 _u32LaunchKeys;
static U8 Menu_USB_Upgrade_Percent = 0xFF;

static U16 _u16FacKeys;

#include "MApp_ZUI_ACTfactoryhotkey.h"

#if ENABLE_T_C_COMBO
extern EN_DVB_TYPE MApp_DVBType_GetCurrentType(void);
extern BOOL bIsDVBCScan;
#endif

#if ENABLE_CUS_BLOCK_SYS
extern void MApp_MuteAvByLock(U8 u8ScreenMute, BOOLEAN bMuteEnable);
#endif

#if (ENABLE_CUS_UI_SPEC == DISABLE) /*Creass.liu at 2012-06-27*/
typedef struct _SOURCE_SRC2STRING_STRUCT
{
         E_UI_INPUT_SOURCE source;
         U16 app_string;
} _SOURCE_SRC2STRING_STRUCT;

_SOURCE_SRC2STRING_STRUCT _ZUI_TBLSEG _app_items[] =
{
#if ENABLE_DMP
{
      UI_INPUT_SOURCE_DMP,
      en_str_DMP
},
#endif
#ifdef ENABLE_BT
{
          UI_INPUT_SOURCE_BT,
          en_str_BT
},
#endif
#ifdef ENABLE_YOUTUBE
{
          UI_INPUT_SOURCE_YOUTUBE,
          en_str_YOUTUBE
},
#endif
#ifdef ENABLE_RSS
{
          UI_INPUT_SOURCE_RSS,
          en_str_RSS
},
#endif
#ifdef ENABLE_GYM
{
          UI_INPUT_SOURCE_GYM,
          en_str_GYM
},
#endif
#ifdef ENABLE_KTV
{
          UI_INPUT_SOURCE_KTV,
          en_str_KTV
},
#endif
#ifdef INDEPENDENT_PLUG_IN
{
          UI_INPUT_SOURCE_PLUG_IN,
          en_str_PLUG_IN
},
#endif
#if (ENABLE_GAME)
{
          UI_INPUT_SOURCE_GAME,
          en_str_Game
},
#endif
#ifdef ENABLE_EXTENSION
{
          UI_INPUT_SOURCE_EXTENSION,
          en_str_EXTENSION
},
#endif
//#ifdef ENABLE_NETFLIX
//{
//          UI_INPUT_SOURCE_NETFLIX,
//          en_str_Netflix
//},
//#endif
{ //The last item, to prevent there is no app in the list.
          UI_INPUT_SOURCE_NONE,
          en_strLL
},
};
static HWND _ZUI_TBLSEG page_hide_ball[][1] =
{
        { HWND_MENU_BOTTOM_BALL_FOCUS_CHANNEL},
        { HWND_MENU_BOTTOM_BALL_FOCUS_PICTURE},
        { HWND_MENU_BOTTOM_BALL_FOCUS_SOUND},
        { HWND_MENU_BOTTOM_BALL_FOCUS_OPTION},
        { HWND_MENU_BOTTOM_BALL_FOCUS_TIME},
    #if ENABLE_DTV
        { HWND_MENU_BOTTOM_BALL_FOCUS_LOCK},
    #endif
        { HWND_MENU_BOTTOM_BALL_FOCUS_APP},
};

U16 TopIconAlpha[2][2];  //for save dynamic Alpha//save hwnd and Alpha
U16 MApp_ZUI_ACT_GetAppItemString(int APPindex)
{
    U8 app_num = COUNTOF(_app_items);

    //prevent no app in list
    if(APPindex == 0 && _app_items[0].source == UI_INPUT_SOURCE_NONE)
    {
        return _app_items[APPindex].app_string;
    }

    if(APPindex >= app_num - 1)
    {
        return Empty;
    }
    else
    {
        return _app_items[APPindex].app_string;
    }
}

E_UI_INPUT_SOURCE MApp_ZUI_ACT_GetAppItemSource(int APPindex)
{
       U8 app_num = COUNTOF(_app_items);

       if(APPindex >= app_num - 1)
       {
           return UI_INPUT_SOURCE_NUM;
       }
       else
       {
           return _app_items[APPindex].source;
       }
}
U8 MApp_ZUI_ACT_GetTimezoneIndex(void)
{
    return GET_TIMEZONE_MENU_LANGUAGE_DTG();
}

void MApp_ZUI_ACT_SetTimezoneIndex(U8 u8Index)
{
    SET_TIME_MENU_ZONE((EN_MENU_TIMEZONE)u8Index);

#if ENABLE_DTV
    MApp_SI_SetTimeZone(MApp_GetSITimeZone(stGenSetting.g_Time.enTimeZone));
    MApp_SI_SetClockTimeZone(MApp_GetSIClockTimeZone(stGenSetting.g_Time.en_Clock_TimeZone));
    MApp_SI_Update_Time(MApp_GetAutoSystemTimeFlag());
#endif

    MApp_Time_SetOnTime();

    MApp_ZUI_API_InvalidateWindow(HWND_MENU_TIME_TIMEZONE_PAGE);
    MApp_ZUI_API_InvalidateWindow(HWND_MENU_TIME_SET_CLOCK);
}

LPTSTR MApp_ZUI_ACT_GetTimezoneStringByIndex(U8 u8Index)
{
    U16 u16TempID = Empty;

    u16TempID = _MApp_ZUI_ACT_GetTimeZoneStringID((EN_MENU_TIMEZONE)u8Index);

    if (u16TempID != Empty)
        return MApp_ZUI_API_GetString(u16TempID);

    return 0; //for empty string....
}

U8 MApp_ZUI_ACT_GetOsdLanguageIndex(void)
{
    return GET_OSD_MENU_LANGUAGE_DTG();
}

U8 MApp_ZUI_ACT_GetAudioLanguageIndex(void)
{
    return GET_AUDIO_MENU_LANGUAGE_DTG();
}


U8 MApp_ZUI_ACT_GetSubLanguageIndex(void)
{
    return GET_SUB_MENU_LANGUAGE_DTG();
}

U8 MApp_ZUI_ACT_GetTuningCountryIndex(void)
{
    return GET_TUNING_MENU_COUNTRY_DTG();
}

void MApp_ZUI_ACT_SetOsdLanguageIndex(U8 u8Index)
{
    SET_OSD_MENU_LANGUAGE((EN_LANGUAGE)u8Index);
   #if (ENABLE_CUS_UI_SPEC == DISABLE)
    MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_OPTION_OSDLANG_PAGE);
   #endif
}
void MApp_ZUI_ACT_SetAudioLanguageIndex(U8 u8Index)
{
    SET_AUDIO_MENU_LANGUAGE((EN_LANGUAGE)u8Index);
    MApp_Audio_SetMtsMode();
    MApp_ZUI_API_InvalidateWindow(HWND_MENU_OPTION_AUDIOLANG_PAGE);
}

void MApp_ZUI_ACT_SetSubLanguageIndex(U8 u8Index)
{
    SET_SUB_MENU_LANGUAGE((EN_LANGUAGE)u8Index);
    MApp_Audio_SetMtsMode();
    MApp_ZUI_API_InvalidateWindow(HWND_MENU_OPTION_SUBLANG_PAGE);
}

void MApp_ZUI_ACT_SetTuningCountryIndex(U8 u8Index)
{
    SET_TUNING_MENU_COUNTRY((EN_OSD_COUNTRY_SETTING)u8Index);
    MApp_ZUI_API_InvalidateWindow(HWND_MENU_DLG_TUNE_CONFIRM);
}

LPTSTR MApp_ZUI_ACT_GetMenuLanguageStringByIndex(U8 u8Index)
{
    U16 u16TempID = Empty;

    if(u8Index <= LANGUAGE_MENU_MAX)
    {
        u16TempID = _MApp_ZUI_ACT_GetLanguageStringID((EN_LANGUAGE)u8Index, FALSE);

        if (u16TempID != Empty)
            return MApp_ZUI_API_GetString(u16TempID);
    }

    return 0; //for empty string....
}

LPTSTR MApp_ZUI_ACT_GetSubtitleLanguageStringByIndex(U8 u8Index)
{
    U16 u16TempID = Empty;

    if(OSD_COUNTRY_SETTING == E_NEWZEALAND)
    {
        if(u8Index <= LANGUAGE_SUBTITLE_MAX_NZ)
        {
            u16TempID = _MApp_ZUI_ACT_GetLanguageStringID((EN_LANGUAGE)u8Index, FALSE);

            if (u16TempID != Empty)
                 return MApp_ZUI_API_GetString(u16TempID);
        }
    }
    else
    {
        if(u8Index <= LANGUAGE_SUBTITLE_MAX_EU)
        {
            u16TempID = _MApp_ZUI_ACT_GetLanguageStringID((EN_LANGUAGE)u8Index, FALSE);

            if (u16TempID != Empty)
                 return MApp_ZUI_API_GetString(u16TempID);
        }
    }

    return 0; //for empty string....
}


LPTSTR MApp_ZUI_ACT_GetLanguageStringByIndex(U8 u8Index)
{
    U16 u16TempID = Empty;
    if(OSD_COUNTRY_SETTING == E_NEWZEALAND)
    {
        if(u8Index <= LANGUAGE_AUDIO_MAX_NZ)
        {
            u16TempID = _MApp_ZUI_ACT_GetLanguageStringID((EN_LANGUAGE)u8Index, FALSE);

            if (u16TempID != Empty)
                 return MApp_ZUI_API_GetString(u16TempID);
        }
    }
    else
    {
        if(u8Index <= LANGUAGE_AUDIO_MAX_EU)
        {
            u16TempID = _MApp_ZUI_ACT_GetLanguageStringID((EN_LANGUAGE)u8Index, FALSE);

            if (u16TempID != Empty)
                 return MApp_ZUI_API_GetString(u16TempID);
        }
    }

    return 0; //for empty string....
}

LPTSTR MApp_ZUI_ACT_GetCountryStringByIndex(U8 u8Index)
{
    U16 u16TempID = Empty;

    u16TempID = _MApp_ZUI_ACT_GetCountryStringID((EN_OSD_COUNTRY_SETTING)u8Index);

    if (u16TempID != Empty)
        return MApp_ZUI_API_GetString(u16TempID);

    return 0; //for empty string....
}
#endif

void MApp_ZUI_ACT_ShowMainMenuBackground(HWND hwnd)
{
    UNUSED(hwnd);
#if (ENABLE_CUS_UI_SPEC == DISABLE)
    U8 i;

    MApp_ZUI_API_ShowWindow(HWND_MENU_MASK_BACKGROUND, SW_SHOW);
 #if (ENABLE_DTV == 0)
     RECT rect;// Mantis 0118943

    MApp_ZUI_API_ShowWindow(HWND_MENU_BOTTOM_BALL_NORMAL_LOCK, SW_HIDE);
    MApp_ZUI_API_ShowWindow(HWND_MENU_BOTTOM_BALL_FOCUS_LOCK, SW_HIDE);
    MApp_ZUI_API_ShowWindow(HWND_MENU_BOTTOM_BALL_NORMAL_APP, SW_SHOW);
    MApp_ZUI_API_ShowWindow(HWND_MENU_BOTTOM_BALL_FOCUS_APP, SW_HIDE);

    MApp_ZUI_API_GetWindowInitialRect(HWND_MENU_BOTTOM_BALL_NORMAL_LOCK, &rect);
    MApp_ZUI_API_MoveAllSuccessors(HWND_MENU_BOTTOM_BALL_NORMAL_APP,rect.left, rect.top);
 #endif

    for (i=0; i<COUNTOF(page_hide_ball); i++)
    {
         if (hwnd == page_hide_ball[i][0])
         {
              MApp_ZUI_API_ShowWindow(page_hide_ball[i][0], SW_SHOW);
         }
         else
         {
              MApp_ZUI_API_ShowWindow(page_hide_ball[i][0], SW_HIDE);
         }
    }
#else
    MApp_ZUI_API_ShowWindow(HWND_MENU_MASK_BACKGROUND, SW_SHOW);
#endif
}

#if ENABLE_T_C_COMBO
void MApp_ZUI_ACT_ShowDVBCScanPage(void)
{
    if(MApp_DVBC_SCAN_GetCurrentType() == OSD_DVBC_TYPE_FULL)
    {
        MApp_ZUI_API_EnableWindow(HWND_DVBCSCAN_FREQUENCY_BG, DISABLE);
        MApp_ZUI_API_EnableWindow(HWND_DVBCSCAN_NETWORKID_BG, DISABLE);
        g_enScanType= SCAN_TYPE_AUTO;
    }
    else
    {
        MApp_ZUI_API_EnableWindow(HWND_DVBCSCAN_FREQUENCY_BG, ENABLE);
        MApp_ZUI_API_EnableWindow(HWND_DVBCSCAN_NETWORKID_BG, ENABLE);
        g_enScanType= SCAN_TYPE_NETWORK;
    }

    MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
    _enTargetMenuState = STATE_MENU_GOTO_CADTV_MANUALTUNING;
    bIsDVBCScan = TRUE;
    MApp_OSDPage_SetOSDPage(E_OSD_CADTV_MANUAL_TUNING);
}
#endif

void MApp_ZUI_ACT_InitializeMainMenu(void)
{
    if(IsATVInUse()||IsDTVInUse())
    {
        MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_CHANNEL, TRUE);
        MApp_ZUI_API_ShowWindow(HWND_MENU_TOP_ICON_CHANNEL_HIDE, SW_HIDE);
    }
    else
    {
        MApp_ZUI_API_ShowWindow(HWND_MENU_TOP_ICON_CHANNEL, SW_HIDE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_CHANNEL, FALSE);
        MApp_ZUI_API_ShowWindow(HWND_MENU_TOP_ICON_CHANNEL_HIDE, SW_SHOW);
        MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_CHANNEL_HIDE, FALSE);
        #if(UI_SKIN_SEL==UI_SKIN_1366X768X565_HAIER_CN)                         //CUS_XM zhihe  20120821 modify
		MApp_ZUI_API_ShowWindow(HWND_MENU_TOP_ICON_CHANNEL_BIG,SW_HIDE);
		MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_CHANNEL_BIG,FALSE);
		#endif
    }

    {
	   #if(UI_SKIN_SEL==UI_SKIN_1366X768X565_HAIER_CN)                         //CUS_XM zhihe  20120807 modify
		MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_PICTURE_BIG, TRUE);
	    MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_AUDIO_BIG, TRUE);
		MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_SETUP_BIG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_LOCK_BIG, TRUE);
	   #else
        MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_PICTURE, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_AUDIO, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_SETUP, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_LOCK, TRUE);
       #endif
        MApp_ZUI_API_ShowWindow(HWND_MENU_TOP_ICON_PICTURE_HIDE, SW_HIDE);
        MApp_ZUI_API_ShowWindow(HWND_MENU_TOP_ICON_AUDIO_HIDE, SW_HIDE);
        MApp_ZUI_API_ShowWindow(HWND_MENU_TOP_ICON_SETUP_HIDE, SW_HIDE);
        MApp_ZUI_API_ShowWindow(HWND_MENU_TOP_ICON_LOCK_HIDE, SW_HIDE);
    }
    if(stGenSetting.g_SysSetting.fSPDIFMODE)
    {
        MApp_ZUI_API_EnableWindow(HWND_MENU_SOUND_AUDIO_DELAY,DISABLE);
    }
    else
    {
        MApp_ZUI_API_EnableWindow(HWND_MENU_SOUND_AUDIO_DELAY,ENABLE);
    }
	///////////////////////////////////////////////////////////////////////////////
	//add for hotel menu's Installation @chuxu 2012-08-06
#if CUS_SMC_ENABLE_HOTEL_MODE
	if(stGenSetting.g_FactorySetting.HotelMenuHotelModeOperationEnable == ENABLE)
		{
			if(stGenSetting.g_FactorySetting.HotelMenuInstallation == 0)//can channel;can setting/child lock
				{
					//do not execute any actions
				}
			else if(stGenSetting.g_FactorySetting.HotelMenuInstallation == 1)//can not channel;can setting/child lock
				{
					//can not channel
				    #if(UI_SKIN_SEL==UI_SKIN_1366X768X565_HAIER_CN)                         //CUS_XM zhihe  20120821 modify
                    MApp_ZUI_API_ShowWindow(HWND_MENU_TOP_ICON_CHANNEL, SW_HIDE);
					MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_CHANNEL, FALSE);
					MApp_ZUI_API_ShowWindow(HWND_MENU_TOP_ICON_CHANNEL_HIDE, SW_SHOW);
					MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_CHANNEL_HIDE, FALSE);
					MApp_ZUI_API_ShowWindow(HWND_MENU_TOP_ICON_CHANNEL_BIG, SW_HIDE);
					MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_CHANNEL_BIG, FALSE);
					#else
					MApp_ZUI_API_ShowWindow(HWND_MENU_TOP_ICON_CHANNEL, SW_HIDE);
					MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_CHANNEL, FALSE);
					MApp_ZUI_API_ShowWindow(HWND_MENU_TOP_ICON_CHANNEL_HIDE, SW_SHOW);
					MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_CHANNEL_HIDE, TRUE);
					#endif
				}
			else if(stGenSetting.g_FactorySetting.HotelMenuInstallation == 2)//can channel;can not setting/child lock
				{
					//can not setting
					#if(UI_SKIN_SEL==UI_SKIN_1366X768X565_HAIER_CN)                         //CUS_XM zhihe  20120821 modify
					MApp_ZUI_API_ShowWindow(HWND_MENU_TOP_ICON_SETUP, SW_HIDE);
					MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_SETUP, FALSE);
					MApp_ZUI_API_ShowWindow(HWND_MENU_TOP_ICON_SETUP_HIDE, SW_SHOW);
					MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_SETUP_HIDE, FALSE);
					MApp_ZUI_API_ShowWindow(HWND_MENU_TOP_ICON_SETUP_BIG, SW_HIDE);
					MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_SETUP_BIG, FALSE);

					MApp_ZUI_API_ShowWindow(HWND_MENU_TOP_ICON_LOCK, SW_HIDE);
					MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_LOCK, FALSE);
					MApp_ZUI_API_ShowWindow(HWND_MENU_TOP_ICON_LOCK_HIDE, SW_SHOW);
					MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_LOCK_HIDE, FALSE);

					MApp_ZUI_API_ShowWindow(HWND_MENU_TOP_ICON_LOCK_BIG, SW_HIDE);
					MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_LOCK_BIG, FALSE);

					#else
					MApp_ZUI_API_ShowWindow(HWND_MENU_TOP_ICON_SETUP, SW_HIDE);
					MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_SETUP, FALSE);
					MApp_ZUI_API_ShowWindow(HWND_MENU_TOP_ICON_SETUP_HIDE, SW_SHOW);
					MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_SETUP_HIDE, TRUE);
					//can not child lock
					MApp_ZUI_API_ShowWindow(HWND_MENU_TOP_ICON_LOCK, SW_HIDE);
					MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_LOCK, FALSE);
					MApp_ZUI_API_ShowWindow(HWND_MENU_TOP_ICON_LOCK_HIDE, SW_SHOW);
					MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_LOCK_HIDE, TRUE);
					#endif

				}
			else if(stGenSetting.g_FactorySetting.HotelMenuInstallation == 3)//can not channel;can not setting/child lock
				{
                    #if(UI_SKIN_SEL==UI_SKIN_1366X768X565_HAIER_CN)                         //CUS_XM zhihe  20120821 modify
                    MApp_ZUI_API_ShowWindow(HWND_MENU_TOP_ICON_CHANNEL, SW_HIDE);
					MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_CHANNEL, FALSE);
					MApp_ZUI_API_ShowWindow(HWND_MENU_TOP_ICON_CHANNEL_HIDE, SW_SHOW);
					MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_CHANNEL_HIDE, FALSE);
					MApp_ZUI_API_ShowWindow(HWND_MENU_TOP_ICON_CHANNEL_BIG, SW_HIDE);
					MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_CHANNEL_BIG, FALSE);

					MApp_ZUI_API_ShowWindow(HWND_MENU_TOP_ICON_SETUP, SW_HIDE);
					MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_SETUP, FALSE);
					MApp_ZUI_API_ShowWindow(HWND_MENU_TOP_ICON_SETUP_HIDE, SW_SHOW);
					MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_SETUP_HIDE, FALSE);
					MApp_ZUI_API_ShowWindow(HWND_MENU_TOP_ICON_SETUP_BIG, SW_HIDE);
					MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_SETUP_BIG, FALSE);

					MApp_ZUI_API_ShowWindow(HWND_MENU_TOP_ICON_LOCK, SW_HIDE);
					MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_LOCK, FALSE);
					MApp_ZUI_API_ShowWindow(HWND_MENU_TOP_ICON_LOCK_HIDE, SW_SHOW);
					MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_LOCK_HIDE, FALSE);
					MApp_ZUI_API_ShowWindow(HWND_MENU_TOP_ICON_LOCK_BIG, SW_HIDE);
					MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_LOCK_BIG, FALSE);

					#else
					//can not channel
					MApp_ZUI_API_ShowWindow(HWND_MENU_TOP_ICON_CHANNEL, SW_HIDE);
					MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_CHANNEL, FALSE);
					MApp_ZUI_API_ShowWindow(HWND_MENU_TOP_ICON_CHANNEL_HIDE, SW_SHOW);
					MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_CHANNEL_HIDE, TRUE);
					//can not setting
					MApp_ZUI_API_ShowWindow(HWND_MENU_TOP_ICON_SETUP, SW_HIDE);
					MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_SETUP, FALSE);
					MApp_ZUI_API_ShowWindow(HWND_MENU_TOP_ICON_SETUP_HIDE, SW_SHOW);
					MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_SETUP_HIDE, TRUE);
					//can not child lock
					MApp_ZUI_API_ShowWindow(HWND_MENU_TOP_ICON_LOCK, SW_HIDE);
					MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_LOCK, FALSE);
					MApp_ZUI_API_ShowWindow(HWND_MENU_TOP_ICON_LOCK_HIDE, SW_SHOW);
					MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_LOCK_HIDE, TRUE);
					#endif
				}
		}
	else if(stGenSetting.g_FactorySetting.HotelMenuHotelModeOperationEnable == DISABLE)
		{
			//do not execute any actions
		}
#endif
	//the end:add for hotel menu's Installation @chuxu 2012-08-06
	/////////////////////////////////////////////////////////////////////////////////

    PasswordInput1=PasswordInput2=0;
    g_u8PasswordPosition = 0;
    g_u16Password = 0;
    g_u8PasswordCount = 0;

}

///////////////////////////////////////////////////////////////////////////////
///  private  MApp_ZUI_ACT_AppShowMainMenu
///  [OSD page handler] provide for showing MENU application
///
///  @return no return value
///
///  @author MStarSemi @date 2007/1/25
///////////////////////////////////////////////////////////////////////////////
void MApp_ZUI_ACT_AppShowMainMenu()
{
    HWND wnd;
    RECT rect;
    E_OSD_ID osd_id = E_OSD_MAIN_MENU;

    g_GUI_WindowList = GetWindowListOfOsdTable(osd_id);
    g_GUI_WinDrawStyleList = GetWindowStyleOfOsdTable(osd_id);
    g_GUI_WindowPositionList = GetWindowPositionOfOsdTable(osd_id);
#if ZUI_ENABLE_ALPHATABLE
    g_GUI_WinAlphaDataList = GetWindowAlphaDataOfOsdTable(osd_id);
#endif
    HWND_MAX = GetWndMaxOfOsdTable(osd_id);
    OSDPAGE_BLENDING_ENABLE = IsBlendingEnabledOfOsdTable(osd_id);
    OSDPAGE_BLENDING_VALUE = (63 - stGenSetting.g_SysSetting.OsdBlending*10);//GetBlendingValueOfOsdTable(osd_id);

    if (!_MApp_ZUI_API_AllocateVarData())
    {
        ZUI_DBG_FAIL(printf("[ZUI]ALLOC\n"));
        ABORT();
        return;
    }

    RECT_SET(rect,
        ZUI_MAIN_MENU_XSTART, ZUI_MAIN_MENU_YSTART,
        ZUI_MAIN_MENU_WIDTH, ZUI_MAIN_MENU_HEIGHT);

    if (!MApp_ZUI_API_InitGDI(&rect))
    {
        ZUI_DBG_FAIL(printf("[ZUI]GDIINIT\n"));
        ABORT();
        return;
    }

    #if ENABLE_PVR
        #if ((CHIP_FAMILY_TYPE == CHIP_FAMILY_S7LD) || (CHIP_FAMILY_TYPE == CHIP_FAMILY_S7J))
            MApp_ZUI_API_EnableFullScreenRelease(FALSE);  //Add to reduce the PVR write gap time related with main menu operation 20100721EL
        #endif
    #endif

    #if DTV_HD_USE_FBL
    {
        //disable de-blocking when enter Main Menu
        //for single MIU + FBL only
        if( IsDTVInUse() && MApi_XC_IsCurrentFrameBufferLessMode() )
        {
            MApi_VDEC_DisableDeblocking(TRUE); //means disable deblocking, so that VDEC would need less bandwidth
            //printf("\n disable de-blocking \n");
        }
    }
    #endif
    for (wnd = 0; wnd < HWND_MAX; wnd++)
    {
        //printf("create msg: %lu\n", (U32)wnd);
        MApp_ZUI_API_SendMessage(wnd, MSG_CREATE, 0);
    }

    printf("\r\n MApp_ZUI_ACT_AppShowMainMenu -[%s /%s]\n",__DATE__,__TIME__);/*Creass.liu at 2012-06-14*/

    MApp_ZUI_API_ShowWindow(HWND_MAINFRAME, SW_HIDE);
    MApp_ZUI_API_ShowWindow(HWND_MENU_BACKGROUND,SW_SHOW);

    MApp_ZUI_ACT_InitializeMainMenu();

#if (ENABLE_CUS_UI_SPEC == DISABLE)
#if (ENABLE_DTV==0)
    MApp_ZUI_API_ShowWindow(HWND_MENU_BOTTOM_BALL_NORMAL_LOCK, SW_HIDE);
    MApp_ZUI_API_ShowWindow(HWND_MENU_BOTTOM_BALL_FOCUS_LOCK, SW_HIDE);
#endif
#endif

    switch(_enReturnMenuItem)
    {
    #if ENABLE_DTV
    case STATE_RETURN_PROGRAM_BLOCK:
        MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_PAGE, SW_SHOW);
        //MApp_ZUI_ACT_ShowMainMenuBackground(HWND_MENU_BOTTOM_BALL_FOCUS_LOCK);
        #if 0//fix compiling error  //Roger.li###
        MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_LOCK_PAGE_LIST, HWND_MENU_LOCK_BLOCK_PROGRAM);
        #endif
        break;
    #endif

    case STATE_RETURN_DTV_MANUAL_TUNING:
        //MApp_ZUI_ACT_ShowMainMenuBackground(HWND_MENU_BOTTOM_BALL_FOCUS_CHANNEL);
        MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_PAGE, SW_SHOW);
        MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_CHANNEL_PAGE_LIST, HWND_MENU_CHANNEL_DTV_MAN_TUNE);
        break;

    case STATE_RETURN_ATV_MANUAL_TUNING:
        //MApp_ZUI_ACT_ShowMainMenuBackground(HWND_MENU_BOTTOM_BALL_FOCUS_CHANNEL);
        MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_PAGE, SW_SHOW);
        MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_CHANNEL_PAGE_LIST, HWND_MENU_CHANNEL_ATV_MAN_TUNE);
        break;
#if (ENABLE_CUS_UI_SPEC == DISABLE)
    case STATE_RETURN_CADTV_MANUAL_TUNING:
#if ENABLE_T_C_COMBO
        if(bIsDVBCScan == TRUE)
            MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_GOTO_TUNING_CONFIRM);
        else
        {
            //MApp_ZUI_ACT_ShowMainMenuBackground(HWND_MENU_BOTTOM_BALL_FOCUS_CHANNEL);
            MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_PAGE, SW_SHOW);
            MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_CHANNEL_PAGE_LIST, HWND_MENU_CHANNEL_CADTV_MAN_TUNE);
        }
#else
        //MApp_ZUI_ACT_ShowMainMenuBackground(HWND_MENU_BOTTOM_BALL_FOCUS_CHANNEL);
        MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_PAGE, SW_SHOW);
        MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_CHANNEL_PAGE_LIST, HWND_MENU_CHANNEL_CADTV_MAN_TUNE);
#endif
#endif
        break;

#if ENABLE_T_C_COMBO
    case STATE_RETURN_DVBC_SCAN_TUNING:
        MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_DVB_SELECT_MENU, SW_SHOW);
        if(MApp_DVBType_GetCurrentType() == EN_DVB_C_TYPE)
            MApp_ZUI_API_SetFocus(HWND_SELECTED_DVBC_BG);
        else
            MApp_ZUI_API_SetFocus(HWND_SELECTED_DVBT_BG);
        break;
#endif

    case STATE_RETURN_PROGRAM_EDIT:
        //MApp_ZUI_ACT_ShowMainMenuBackground(HWND_MENU_BOTTOM_BALL_FOCUS_CHANNEL);
        MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_PAGE, SW_SHOW);
        MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_CHANNEL_PAGE_LIST, HWND_MENU_CHANNEL_PROGRAM_EDIT);
        break;

#if ENABLE_PVR /*Creass.liu at 2012-06-02*/
    case STATE_RETURN_PVR_FILE_SYS:
        //MApp_ZUI_ACT_ShowMainMenuBackground(HWND_MENU_BOTTOM_BALL_FOCUS_OPTION);
        MApp_ZUI_API_ShowWindow(HWND_MENU_OPTION_PAGE, SW_SHOW);
        MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_OPTION_PAGE_LIST, HWND_MENU_OPTION_PVR_FILE_SYSTEM);
        break;
#endif

#ifdef ENABLE_CUS_AUTO_SCAN_HOTKEY
    case STATE_RETURN_AUTO_SCAN_PAGE_AND_DO_AUTO_SCAN:
        _enReturnMenuItem = STATE_RETURN_NULL;
        MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_PAGE, SW_HIDE);
        MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_SCAN_PAGE, SW_SHOW);
        MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_SCAN_PAGE_MANUAL_LIST, SW_HIDE);
        MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_SCAN_PAGE_TITLE, SW_HIDE);
        MApp_ZUI_API_SetFocus(HWND_MENU_CHANNEL_SCAN_PAGE_PROGRESS_BAR);
        break;
#endif

    case STATE_RETURN_LOCK_PAGE:
        _enReturnMenuItem = STATE_RETURN_NULL;
		MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_PAGE, SW_SHOW);
		MApp_ZUI_API_SetFocus(HWND_MENU_LOCK_ENTER_PASSWORD);
        break;
		
    case STATE_RETURN_NULL:
    default:
	#if 0//CUS_SMC_ENABLE_HOTEL_MODE
        if(stGenSetting.g_FactorySetting.HotelMenuOSDDisplayEnable == DISABLE)
        {
			MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_PAGE, SW_SHOW);
			MApp_ZUI_API_SetFocus(HWND_MENU_LOCK_ENTER_PASSWORD);
		}
		else
	#endif
        {
            //MApp_ZUI_ACT_ShowMainMenuBackground(HWND_MENU_BOTTOM_BALL_FOCUS_CHANNEL);
            if(IsVgaInUse())
            {
                MApp_ZUI_API_ShowWindow(HWND_MENU_PC_PICTURE_PAGE, SW_SHOW);
            }
            else
            {
                MApp_ZUI_API_ShowWindow(HWND_MENU_PICTURE_PAGE, SW_SHOW);
            }
			#if(UI_SKIN_SEL==UI_SKIN_1366X768X565_HAIER_CN)             //CUS_XM zhihe  20120807 modify
			MApp_ZUI_API_ShowWindow(HWND_MENU_TOP_ICON_PICTURE,SW_HIDE);
            MApp_ZUI_API_SetFocus(HWND_MENU_TOP_ICON_PICTURE_BIG);
			#else
			MApp_ZUI_API_SetFocus(HWND_MENU_TOP_ICON_PICTURE);
			#endif
            //MApp_ZUI_API_SendMessage(HWND_MENU_CHANNEL_PAGE_LIST, MSG_USER, HWND_MENU_CHANNEL_AUTOTUNE);
        }
    }
    MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_BG_MENUPAGE_INFO); //refresh mainmenu page info text

    _enReturnMenuItem = STATE_RETURN_NULL;
    #if ENABLE_CUS_UI_SPEC
    if(IsATVInUse())
    {
        msAPI_ATV_ChannelInfoEdit_SetVideoStandard(msAPI_ATV_GetVideoStandardOfProgram(msAPI_ATV_GetCurrentProgramNumber()));
    }
    #endif
    //MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_OPEN, E_ZUI_STATE_RUNNING);

}

void MApp_ZUI_ACT_MainPageMenuKey(void)
{
// CUS_XM Xue 20120801: modify XF112PIOCNMS0-145
      switch(MApp_ZUI_API_GetFocus())
      {
         case HWND_MENU_CHANNEL_SCAN_PAGE_MANUAL_FREQ_BEGIN:
	     case HWND_MENU_CHANNEL_SCAN_PAGE_MANUAL_FREQ_END:
	     case HWND_MENU_CHANNEL_SCAN_PAGE_MANUA_GOTO_SCAN:
            MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_SCAN_PAGE, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_PAGE, SW_SHOW);
            MApp_ZUI_API_SetFocus(HWND_MENU_CHANNEL_ATV_MAN_TUNE);
	     MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_BG_MENUPAGE_INFO); //refresh mainmenu page info text
	     return;
	     default:
	     break;
       }


	  #if(UI_SKIN_SEL==UI_SKIN_1366X768X565_HAIER_CN)                 //CUS_XM ZHIHE 20120807 modify
	     if(HWND_MENU_TOP_ICON_PICTURE_BIG == MApp_ZUI_API_GetFocus()
        ||HWND_MENU_TOP_ICON_AUDIO_BIG== MApp_ZUI_API_GetFocus()
        ||HWND_MENU_TOP_ICON_SETUP_BIG== MApp_ZUI_API_GetFocus()
        ||HWND_MENU_TOP_ICON_LOCK_BIG== MApp_ZUI_API_GetFocus()
        ||HWND_MENU_TOP_ICON_CHANNEL_BIG == MApp_ZUI_API_GetFocus())
    {
        MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_CLOSE_CURRENT_OSD);
    }
#else

    if(HWND_MENU_TOP_ICON_PICTURE == MApp_ZUI_API_GetFocus()
        ||HWND_MENU_TOP_ICON_AUDIO== MApp_ZUI_API_GetFocus()
        ||HWND_MENU_TOP_ICON_SETUP== MApp_ZUI_API_GetFocus()
        ||HWND_MENU_TOP_ICON_LOCK== MApp_ZUI_API_GetFocus()
        ||HWND_MENU_TOP_ICON_CHANNEL == MApp_ZUI_API_GetFocus())
    {
        MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_CLOSE_CURRENT_OSD);
    }
#endif
    else if(MApp_ZUI_API_IsSuccessor(HWND_MENU_CHANNEL_PAGE2_LIST, MApp_ZUI_API_GetFocus()))
    {
       #if(UI_SKIN_SEL==UI_SKIN_1366X768X565_HAIER_CN) 				//CUS_XM ZHIHE 20120807 modify
	    MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_CHANNEL,ENABLE);  //CUS_XM ZHIHE  20120809 ADD
	    MApp_ZUI_API_ShowWindow(HWND_MENU_TOP_ICON_CHANNEL, SW_HIDE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_CHANNEL_BIG,ENABLE);
        MApp_ZUI_API_SetFocus(HWND_MENU_TOP_ICON_CHANNEL_BIG);
       #else
        MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_CHANNEL,ENABLE);
        MApp_ZUI_API_SetFocus(HWND_MENU_TOP_ICON_CHANNEL);
	   #endif
    }
    else if(MApp_ZUI_API_IsSuccessor(HWND_MENU_CHANNEL_PAGE_LIST, MApp_ZUI_API_GetFocus()))
    {
    #if CHANNEL_PAGE_HIDE_MTS
		MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_CHANNEL,ENABLE);
		MApp_ZUI_API_SetFocus(HWND_MENU_TOP_ICON_CHANNEL);
	#else
        MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_PAGE, SW_HIDE);
        MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_PAGE2, SW_SHOW);
        MApp_ZUI_API_SetFocus(HWND_MENU_CHANNEL_PAGE2_CHANNEL);
	#endif
    }
    else if(MApp_ZUI_API_IsSuccessor(HWND_MENU_CHANNEL_SCAN_PAGE, MApp_ZUI_API_GetFocus()))
    {
        MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_SCAN_PAGE, SW_HIDE);
        MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_PAGE, SW_SHOW);
				// CUS_XM Xue 20120801: modify XF112PIOCNMS0-145
	if(g_bGotoUpdateScan)
       MApp_ZUI_API_SetFocus(HWND_MENU_CHANNEL_UPDATE_SCAN);
	else
	MApp_ZUI_API_SetFocus(HWND_MENU_CHANNEL_AUTOTUNE);
    }



    else if(MApp_ZUI_API_IsSuccessor(HWND_MENU_PICTURE_PAGE_LIST, MApp_ZUI_API_GetFocus()))
    {
        #if(UI_SKIN_SEL==UI_SKIN_1366X768X565_HAIER_CN) // CUS_xm zHIHE 20120807 modify
		  MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_PICTURE,ENABLE);  //CUS_XM ZHIHE  20120809 ADD
	    MApp_ZUI_API_ShowWindow(HWND_MENU_TOP_ICON_PICTURE, SW_HIDE);
		MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_PICTURE_BIG,ENABLE);
        MApp_ZUI_API_SetFocus(HWND_MENU_TOP_ICON_PICTURE_BIG);
        #else

		MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_PICTURE,ENABLE);
        MApp_ZUI_API_SetFocus(HWND_MENU_TOP_ICON_PICTURE);
		#endif

    }
    else if(MApp_ZUI_API_IsSuccessor(HWND_MENU_PC_PICTURE_PAGE_LIST, MApp_ZUI_API_GetFocus()))
    {
       #if(UI_SKIN_SEL==UI_SKIN_1366X768X565_HAIER_CN)  // CUS_xm zHIHE 20120807 modify
		MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_PICTURE,ENABLE);  //CUS_XM ZHIHE  20120809 ADD
	    MApp_ZUI_API_ShowWindow(HWND_MENU_TOP_ICON_PICTURE, SW_HIDE);
		MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_PICTURE_BIG,ENABLE);
        MApp_ZUI_API_SetFocus(HWND_MENU_TOP_ICON_PICTURE_BIG);
        #else

		MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_PICTURE,ENABLE);
        MApp_ZUI_API_SetFocus(HWND_MENU_TOP_ICON_PICTURE);
		#endif

    }
    else if(MApp_ZUI_API_IsSuccessor(HWND_MENU_PCMODE_ADJUST_PAGE, MApp_ZUI_API_GetFocus()))
    {
        MApp_ZUI_API_ShowWindow(HWND_MENU_PCMODE_ADJUST_PAGE_LIST, SW_HIDE);
        MApp_ZUI_API_ShowWindow(HWND_MENU_PC_PICTURE_PAGE_LIST, SW_SHOW);
        MApp_ZUI_API_SetFocus(HWND_MENU_PC_PICTURE_PC_ADJUST);
    }
    else if(MApp_ZUI_API_IsSuccessor(HWND_MENU_ADVANCE_PICTURE_PAGE_LIST, MApp_ZUI_API_GetFocus()))
    {
        if(IsVgaInUse())
        {
            MApp_ZUI_API_ShowWindow(HWND_MENU_ADVANCE_PICTURE_PAGE_LIST, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PC_PICTURE_PAGE, SW_SHOW);
            MApp_ZUI_API_SetFocus(HWND_MENU_PC_PICTURE_ADVANCE_PICTURE);
        }
        else
        {
            MApp_ZUI_API_ShowWindow(HWND_MENU_ADVANCE_PICTURE_PAGE_LIST, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PICTURE_PAGE, SW_SHOW);
            MApp_ZUI_API_SetFocus(HWND_MENU_PICTURE_ADVANCE_PICTURE);
        }
    }
    else if(MApp_ZUI_API_IsSuccessor(HWND_MENU_OPTION_3D_SETUP_PAGE_LIST, MApp_ZUI_API_GetFocus()))
    {
        MApp_ZUI_API_ShowWindow(HWND_MENU_OPTION_3D_SETUP_PAGE, SW_HIDE);
        MApp_ZUI_API_ShowWindow(HWND_MENU_OPTION_PAGE, SW_SHOW);
        MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_OPTION_PAGE_LIST,HWND_MENU_OPTION_3D_MODE_SETTING);
    }
    else if(MApp_ZUI_API_IsSuccessor(HWND_MENU_SOUND_PAGE_LIST, MApp_ZUI_API_GetFocus()))
    {
        #if(UI_SKIN_SEL==UI_SKIN_1366X768X565_HAIER_CN)   // CUS_xm zHIHE 20120807 modify
		MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_AUDIO,ENABLE);  //CUS_XM ZHIHE  20120809 ADD
	    MApp_ZUI_API_ShowWindow(HWND_MENU_TOP_ICON_AUDIO, SW_HIDE);
	    MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_AUDIO_BIG,ENABLE);
	    MApp_ZUI_API_SetFocus(HWND_MENU_TOP_ICON_AUDIO_BIG);
        #else
		MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_AUDIO,ENABLE);
        MApp_ZUI_API_SetFocus(HWND_MENU_TOP_ICON_AUDIO);
		#endif
    }
    else if(MApp_ZUI_API_IsSuccessor(HWND_MENU_OPTION_PAGE_LIST, MApp_ZUI_API_GetFocus()))
    {
        #if(UI_SKIN_SEL==UI_SKIN_1366X768X565_HAIER_CN)  // CUS_xm zHIHE 20120807 modify
		MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_SETUP,ENABLE);  //CUS_XM ZHIHE  20120809 ADD
	    MApp_ZUI_API_ShowWindow(HWND_MENU_TOP_ICON_SETUP, SW_HIDE);
		MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_SETUP_BIG,ENABLE);
        MApp_ZUI_API_SetFocus(HWND_MENU_TOP_ICON_SETUP_BIG);
		#else
		MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_SETUP,ENABLE);
        MApp_ZUI_API_SetFocus(HWND_MENU_TOP_ICON_SETUP);
		#endif
    }
    else if(MApp_ZUI_API_IsSuccessor(HWND_MENU_LOCK_PAGE_LIST, MApp_ZUI_API_GetFocus()))
    {
        if(bEnterPW2ChannelsList)
        {
            bEnterPW2ChannelsList = FALSE;
#if CHANNEL_PAGE_HIDE_MTS
            bEnterPW2ChannelsList = TRUE;
			MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_CHANNEL,ENABLE);
			MApp_ZUI_API_SetFocus(HWND_MENU_TOP_ICON_CHANNEL);
#else
            MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_PAGE, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_PAGE2, SW_SHOW);
            MApp_ZUI_API_SetFocus(HWND_MENU_CHANNEL_PAGE2_CHANNEL);
#endif
        }
        else
        {
            #if(UI_SKIN_SEL==UI_SKIN_1366X768X565_HAIER_CN)  // CUS_xm zHIHE 20120807 modify
		    MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_LOCK,ENABLE);  //CUS_XM ZHIHE  20120809 ADD
	        MApp_ZUI_API_ShowWindow(HWND_MENU_TOP_ICON_LOCK, SW_HIDE);
            MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_LOCK_BIG,ENABLE);
            MApp_ZUI_API_SetFocus(HWND_MENU_TOP_ICON_LOCK_BIG);
            #else
            MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_LOCK,ENABLE);
            MApp_ZUI_API_SetFocus(HWND_MENU_TOP_ICON_LOCK);
			#endif
        }
        PasswordInput1=PasswordInput2=0;
        g_u8PasswordPosition = 0;
        g_u16Password = 0;
        g_u8PasswordCount = 0;
    }
    else if(MApp_ZUI_API_IsSuccessor(HWND_MENU_LOCK_PAGE_LIST_CHANGEPW, MApp_ZUI_API_GetFocus()))
    {
        MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_PAGE_CHANGEPW, SW_HIDE);
        MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_SUBPAGE, SW_SHOW);
        MApp_ZUI_API_SetFocus(HWND_MENU_LOCK_MAINSUBPAGE_ITEM_CHANGEPW);
    }
    else if (MApp_ZUI_API_IsSuccessor(HWND_MENU_DLG_COMMON, MApp_ZUI_API_GetFocus())) //input password
    {
        switch(_eCommonDlgMode)
        {
        case EN_COMMON_DLG_MODE_INPUT_PASSWORD:
        case EN_COMMON_DLG_MODE_SCAN_INPUT_PASSWORD:
        case EN_COMMON_DLG_MODE_DTV_TUNING_INPUT_PASSWORD:
        case EN_COMMON_DLG_MODE_ATV_TUNING_INPUT_PASSWORD:
        case EN_COMMON_DLG_MODE_FACTORY_RESET_INPUT_PASSWORD:
        case EN_COMMON_DLG_MODE_ENTER_MENU_LOCK_PAGE_INPUT_PASSWORD:
            MApp_ZUI_ACT_ExecuteMenuCommonDialogAction(EN_EXE_CLOSE_INPUT_PASSWORD_DLG);
            break; // // Added it by coverity_0528

        case EN_COMMON_DLG_MODE_FACTORY_RESET_CONFIRM:
            MApp_ZUI_ACT_ExecuteMenuCommonDialogAction(EN_EXE_CLOSE_FACTORY_RESET_CONFIRM_DLG);
            break;
		case EN_COMMON_DLG_MODE_CLEAN_LOCK:
            MApp_ZUI_ACT_ExecuteMenuCommonDialogAction(EN_EXE_CLOSE_CLEAN_ALL_DLG);
            break;
        case EN_COMMON_DLG_MODE_CH_LIST_CLEAN_ALL_CONFIRM:
            MApp_ZUI_ACT_ExecuteMenuCommonDialogAction(EN_EXE_CLOSE_CH_LIST_CLEAN_ALL_DLG);
            break;
        case EN_COMMON_DLG_MODE_CHANNEL_INFO_SAVE_CHANGED:
            MApp_ZUI_ACT_ExecuteMenuCommonDialogAction(EN_EXE_CLOSE_CH_INFO_SAVE_CHANGED_DLG);
            break;
        case EN_COMMON_DLG_MODE_USB_UPDATE_CONFIRM:
            MApp_ZUI_ACT_ExecuteMenuCommonDialogAction(EN_EXE_CLOSE_CURRENT_OSD);
            break;

         default:
            break;
        }
    }

#if ENABLE_T_C_COMBO
    else if(MApp_ZUI_API_IsSuccessor(HWND_MENU_DLG_DVB_SELECT_MENU, MApp_ZUI_API_GetFocus()))
    {
        MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_DVB_SELECT_MENU, SW_HIDE);
        MApp_ZUI_ACT_ShowMainMenuBackground(HWND_MENU_BOTTOM_BALL_FOCUS_CHANNEL);
        MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_PAGE, SW_SHOW);
        MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_CHANNEL_PAGE_LIST, HWND_MENU_CHANNEL_AUTOTUNE);

        if(IsDTVInUse())
        {
			MApp_DVBType_SetCurrentType(MApp_DVBType_GetPrevType());

            switch (MApp_DVBType_GetPrevType())
            {
                case EN_DVB_T_TYPE:
                {
                    if(msAPI_Tuner_GetDspStatus() != 0x01)//1: DVBT, 2:DVBC, 3:ATSC, 0xff: Null
                    {
                        MApp_ChannelChange_DisableChannel(TRUE,MAIN_WINDOW);
                        msAPI_Tuner_SwitchSource((EN_DVB_TYPE)stGenSetting.stScanMenuSetting.u8DVBCTvConnectionType, TRUE);
                        MApp_ChannelChange_EnableChannel(MAIN_WINDOW);
                        //Cancel Freeze
                        if(g_bIsImageFrozen)
                        {
                            g_bIsImageFrozen = FALSE;
                            MApi_XC_FreezeImg(g_bIsImageFrozen, MAIN_WINDOW);
                        }
                    }
                    break;
               }

                case EN_DVB_C_TYPE:
                {
                    if(msAPI_Tuner_GetDspStatus() != 0x02)//1: DVBT, 2:DVBC, 3:ATSC, 0xff: Null
                    {
                        MApp_ChannelChange_DisableChannel(TRUE,MAIN_WINDOW);
                        msAPI_Tuner_SwitchSource((EN_DVB_TYPE)stGenSetting.stScanMenuSetting.u8DVBCTvConnectionType, TRUE);
                        MApp_ChannelChange_EnableChannel(MAIN_WINDOW);
                        //Cancel Freeze
                        if(g_bIsImageFrozen)
                        {
                            g_bIsImageFrozen = FALSE;
                            MApi_XC_FreezeImg(g_bIsImageFrozen, MAIN_WINDOW);
                        }
                    }
                    break;
               }

               default:
                break;
            }
        }
    }
#endif

    else if(MApp_ZUI_API_IsSuccessor(HWND_MENU_DLG_SIGNAL_INFORMAT, MApp_ZUI_API_GetFocus()))
    {
        MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_SIGNAL_INFORMAT, SW_HIDE);
        //MApp_ZUI_ACT_ShowMainMenuBackground(HWND_MENU_BOTTOM_BALL_FOCUS_CHANNEL);
        MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_PAGE, SW_SHOW);
        MApp_ZUI_API_SetFocus(HWND_MENU_CHANNEL_SIGNAL_INFORMAT);
    }
#if (ENABLE_CUS_UI_SPEC == FALSE)/*Creass.liu at 2012-06-27*/
    else if(MApp_ZUI_API_IsSuccessor(HWND_MENU_DLG_TUNE_CONFIRM, MApp_ZUI_API_GetFocus()))
    {
        if(MApp_ZUI_API_IsSuccessor(HWND_MENU_DLG_TUNE_CONFIRM_COUNTRY_GRID, MApp_ZUI_API_GetFocus()))
        {
            #if ENABLE_DTV
            MApp_ZUI_API_SetFocus(HWND_MENU_DLG_TUNE_CONFIRM_TUNE_TYPE);
            #else
            MApp_ZUI_ACT_ExecuteTuningConfirmDialogAction(EN_EXE_CLOSE_TUNING_CONFIRM);
            #endif
        }
        else
        {
        #if ENABLE_T_C_COMBO
        if(MApp_DVBType_GetCurrentType() == EN_DVB_C_TYPE)
        {
            MApp_ZUI_API_ShowWindow(HWND_MENU_TRANSPARENT_BG, SW_SHOW);
            MApp_ZUI_ACT_ShowDVBCScanPage();
        }
        else
        {       //DVBT
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_TUNE_CONFIRM, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_DVB_SELECT_MENU, SW_SHOW);
            MApp_ZUI_API_SetFocus(HWND_SELECTED_DVBT_BG);
        }
        #else
            MApp_ZUI_ACT_ExecuteTuningConfirmDialogAction(EN_EXE_CLOSE_TUNING_CONFIRM);
        #endif
        }
    }
    else if(MApp_ZUI_API_IsSuccessor(HWND_MENU_PCMODE_PAGE, MApp_ZUI_API_GetFocus()))
    {
        MApp_ZUI_API_ShowWindow(HWND_MENU_PCMODE_PAGE, SW_HIDE);
        MApp_ZUI_API_ShowWindow(HWND_MENU_PICTURE_PAGE, SW_SHOW);
        //MApp_ZUI_ACT_ShowMainMenuBackground(HWND_MENU_BOTTOM_BALL_FOCUS_PICTURE);
        MApp_ZUI_API_SetFocus(HWND_MENU_PICTURE_PC_ADJUST);
    }
#endif

#if (ENABLE_PIP)
     else if(IsPIPSupported() && MApp_ZUI_API_IsSuccessor(HWND_MENU_PIP_PAGE, MApp_ZUI_API_GetFocus()))
    {
#if (ENABLE_CUS_UI_SPEC == DISABLE)
        MApp_ZUI_API_ShowWindow(HWND_MENU_PIP_PAGE, SW_HIDE);
#endif
        MApp_ZUI_API_ShowWindow(HWND_MENU_PICTURE_PAGE, SW_SHOW);
        //MApp_ZUI_ACT_ShowMainMenuBackground(HWND_MENU_BOTTOM_BALL_FOCUS_PICTURE);
        MApp_ZUI_API_SetFocus(HWND_MENU_PICTURE_PIP);
    }
#endif
    else if(MApp_ZUI_API_IsSuccessor(HWND_MENU_PICTURE_MODE_PAGE, MApp_ZUI_API_GetFocus()))
    {
        MApp_ZUI_API_ShowWindow(HWND_MENU_PICTURE_MODE_PAGE, SW_HIDE);
        MApp_ZUI_API_ShowWindow(HWND_MENU_PICTURE_PAGE, SW_SHOW);
        //MApp_ZUI_ACT_ShowMainMenuBackground(HWND_MENU_BOTTOM_BALL_FOCUS_PICTURE);
        MApp_ZUI_API_SetFocus(HWND_MENU_PICTURE_PICMODE);
    }
    else if(MApp_ZUI_API_IsSuccessor(HWND_MENU_PICTURE_COLOR_PAGE, MApp_ZUI_API_GetFocus()))
    {
        MApp_ZUI_API_ShowWindow(HWND_MENU_PICTURE_COLOR_PAGE, SW_HIDE);
        MApp_ZUI_API_ShowWindow(HWND_MENU_PICTURE_PAGE, SW_SHOW);
        //MApp_ZUI_ACT_ShowMainMenuBackground(HWND_MENU_BOTTOM_BALL_FOCUS_PICTURE);
        MApp_ZUI_API_SetFocus(HWND_MENU_PICTURE_COLOR_TEMP);
    }
#if 0 // no used for CUS
    else if(MApp_ZUI_API_IsSuccessor(HWND_MENU_PICTURE_BACKLIGHT_PAGE, MApp_ZUI_API_GetFocus()))
    {
        MApp_ZUI_API_ShowWindow(HWND_MENU_PICTURE_BACKLIGHT_PAGE, SW_HIDE);
        MApp_ZUI_API_ShowWindow(HWND_MENU_PICTURE_PAGE, SW_SHOW);
        //MApp_ZUI_ACT_ShowMainMenuBackground(HWND_MENU_BOTTOM_BALL_FOCUS_PICTURE);
        MApp_ZUI_API_SetFocus(HWND_MENU_PICTURE_PC_BACKLIGHT);
    }
#endif
    else if(MApp_ZUI_API_IsSuccessor(HWND_MENU_SOUND_MODE_PAGE, MApp_ZUI_API_GetFocus()))
    {
        MApp_ZUI_API_ShowWindow(HWND_MENU_SOUND_MODE_PAGE, SW_HIDE);
        MApp_ZUI_API_ShowWindow(HWND_MENU_SOUND_PAGE, SW_SHOW);
        //MApp_ZUI_ACT_ShowMainMenuBackground(HWND_MENU_BOTTOM_BALL_FOCUS_SOUND);
        MApp_ZUI_API_SetFocus(HWND_MENU_SOUND_SNDMODE);
    }
    else if(MApp_ZUI_API_IsSuccessor(HWND_MENU_SOUND_EQ_PAGE, MApp_ZUI_API_GetFocus()))
    {
        MApp_ZUI_API_ShowWindow(HWND_MENU_SOUND_EQ_PAGE, SW_HIDE);
        MApp_ZUI_API_ShowWindow(HWND_MENU_SOUND_PAGE, SW_SHOW);
        //MApp_ZUI_ACT_ShowMainMenuBackground(HWND_MENU_BOTTOM_BALL_FOCUS_SOUND);
        MApp_ZUI_API_SetFocus(HWND_MENU_SOUND_EQMODE);
    }
 #if ENABLE_DTV
    else if(MApp_ZUI_API_IsSuccessor(HWND_MENU_SOUND_SWITCH_PAGE, MApp_ZUI_API_GetFocus()))
    {
        MApp_ZUI_API_ShowWindow(HWND_MENU_SOUND_SWITCH_PAGE, SW_HIDE);
        MApp_ZUI_API_ShowWindow(HWND_MENU_SOUND_PAGE, SW_SHOW);
        //MApp_ZUI_ACT_ShowMainMenuBackground(HWND_MENU_BOTTOM_BALL_FOCUS_SOUND);
        MApp_ZUI_API_SetFocus(HWND_MENU_SOUND_AD_SWITCH);
    }
 #endif
    else if(MApp_ZUI_API_IsSuccessor(HWND_MENU_TIME_PAGE_LIST, MApp_ZUI_API_GetFocus()))
    {
        MApp_ZUI_API_ShowWindow(HWND_MENU_TIME_PAGE, SW_HIDE);
        MApp_ZUI_API_ShowWindow(HWND_MENU_OPTION_TIME_SUBPAGE, SW_SHOW);
        MApp_ZUI_CTL_DynamicListRefreshContent(HWND_MENU_OPTION_TIME_SUBPAGE_LIST);
        MApp_ZUI_API_SetFocus(HWND_MENU_OP_TIME_SUBPAGE_TIME);
    }
    else if(MApp_ZUI_API_IsSuccessor(HWND_MENU_OPTION_TIME_SUBPAGE_LIST, MApp_ZUI_API_GetFocus()))
    {
        MApp_ZUI_API_ShowWindow(HWND_MENU_OPTION_TIME_SUBPAGE, SW_HIDE);
        MApp_ZUI_API_ShowWindow(HWND_MENU_OPTION_PAGE, SW_SHOW);
        MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_OPTION_PAGE_LIST,HWND_MENU_OPTION_TIME_SETTING);
        //MApp_ZUI_CTL_DynamicListRefreshContent(HWND_MENU_OPTION_PAGE_LIST);
        //MApp_ZUI_API_SetFocus(HWND_MENU_OPTION_TIME_SETTING);
    }
#if (ENABLE_CUS_UI_SPEC == FALSE)// no used for CUS
    else if(MApp_ZUI_API_IsSuccessor(HWND_MENU_TIME_OFFTIME_PAGE, MApp_ZUI_API_GetFocus()))
    {
        MApp_ZUI_API_ShowWindow(HWND_MENU_TIME_OFFTIME_PAGE, SW_HIDE);
        MApp_ZUI_API_ShowWindow(HWND_MENU_TIME_PAGE, SW_SHOW);
        //MApp_ZUI_ACT_ShowMainMenuBackground(HWND_MENU_BOTTOM_BALL_FOCUS_TIME);
        MApp_ZUI_API_SetFocus(HWND_MENU_TIME_SET_OFFTIME);
        MApp_ZUI_ACT_ExecuteSetOffTimeDialogAction(EN_EXE_CLOSE_SET_OFFTIME);
    }
    else if(MApp_ZUI_API_IsSuccessor(HWND_MENU_TIME_ONTIME_PAGE, MApp_ZUI_API_GetFocus()))
    {
        MApp_ZUI_API_ShowWindow(HWND_MENU_TIME_ONTIME_PAGE, SW_HIDE);
        MApp_ZUI_API_ShowWindow(HWND_MENU_TIME_PAGE, SW_SHOW);
        //MApp_ZUI_ACT_ShowMainMenuBackground(HWND_MENU_BOTTOM_BALL_FOCUS_TIME);
        MApp_ZUI_API_SetFocus(HWND_MENU_TIME_SET_ONTIME);
        MApp_ZUI_ACT_ExecuteSetOnTimeDialogAction(EN_EXE_CLOSE_SET_ONTIME);
    }
    else if(MApp_ZUI_API_IsSuccessor(HWND_MENU_TIME_CLOCK_PAGE, MApp_ZUI_API_GetFocus()))
    {
        MApp_ZUI_API_ShowWindow(HWND_MENU_TIME_CLOCK_PAGE, SW_HIDE);
        MApp_ZUI_API_ShowWindow(HWND_MENU_TIME_PAGE, SW_SHOW);
        //MApp_ZUI_ACT_ShowMainMenuBackground(HWND_MENU_BOTTOM_BALL_FOCUS_TIME);
        MApp_ZUI_API_SetFocus(HWND_MENU_TIME_SET_CLOCK);
    }
  #if ENABLE_DTV
    else if(MApp_ZUI_API_IsSuccessor(HWND_MENU_OPTION_AUDIOLANG_PAGE, MApp_ZUI_API_GetFocus()))
    {
        if(MApp_ZUI_API_GetFocus() == HWND_MENU_OPTION_AUDIOLANG_PRIMARY)
        {
            MApp_ZUI_API_ShowWindow(HWND_MENU_OPTION_AUDIOLANG_PAGE, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_OPTION_PAGE, SW_SHOW);
            //MApp_ZUI_ACT_ShowMainMenuBackground(HWND_MENU_BOTTOM_BALL_FOCUS_OPTION);
            MApp_ZUI_API_SetFocus(HWND_MENU_OPTION_AUDIO_LANG);
        }
        else
        {
            MApp_ZUI_API_SetFocus(HWND_MENU_OPTION_AUDIOLANG_PRIMARY);
        }
    }
  #endif
    else if(MApp_ZUI_API_IsSuccessor(HWND_MENU_OPTION_SUBLANG_PAGE, MApp_ZUI_API_GetFocus()))
    {
        if(MApp_ZUI_API_GetFocus() == HWND_MENU_OPTION_SUBLANG_PRIMARY)
        {
            MApp_ZUI_API_ShowWindow(HWND_MENU_OPTION_SUBLANG_PAGE, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_OPTION_PAGE, SW_SHOW);
            //MApp_ZUI_ACT_ShowMainMenuBackground(HWND_MENU_BOTTOM_BALL_FOCUS_OPTION);
            MApp_ZUI_API_SetFocus(HWND_MENU_OPTION_SUBTITLE_LANG);
        }
        else
        {
            MApp_ZUI_API_SetFocus(HWND_MENU_OPTION_SUBLANG_PRIMARY);
        }
    }
    else if(MApp_ZUI_API_IsSuccessor(HWND_MENU_OPTION_OSDLANG_PAGE, MApp_ZUI_API_GetFocus()))
    {
        MApp_ZUI_API_ShowWindow(HWND_MENU_OPTION_OSDLANG_PAGE, SW_HIDE);
        MApp_ZUI_API_ShowWindow(HWND_MENU_OPTION_PAGE, SW_SHOW);
        //MApp_ZUI_ACT_ShowMainMenuBackground(HWND_MENU_BOTTOM_BALL_FOCUS_OPTION);
        MApp_ZUI_API_SetFocus(HWND_MENU_OPTION_OSD_LANG);
    }
    else if(MApp_ZUI_API_IsSuccessor(HWND_MENU_SINGLELIST_COMMON_PAGE, MApp_ZUI_API_GetFocus()))
    {
        MApp_ZUI_API_ShowWindow(HWND_MENU_SINGLELIST_COMMON_PAGE, SW_HIDE);

        switch(_eCommonSingleMode)
        {
            case EN_COMMON_SINGLELIST_ASPECT_RATIO:
               MApp_ZUI_API_ShowWindow(HWND_MENU_PICTURE_PAGE, SW_SHOW);
               //MApp_ZUI_ACT_ShowMainMenuBackground(HWND_MENU_BOTTOM_BALL_FOCUS_PICTURE);
               if(MApp_ZUI_API_IsWindowVisible(HWND_MENU_ALERT_WINDOW))
               {
                   MApp_ZUI_API_ShowWindow(HWND_MENU_ALERT_WINDOW, SW_HIDE);
               }
               MApp_ZUI_API_SetFocus(HWND_MENU_PICTURE_ASPECT_RATIO);
               break;

            case EN_COMMON_SINGLELIST_NOISE_REDUCTION:
               MApp_ZUI_API_ShowWindow(HWND_MENU_PICTURE_PAGE, SW_SHOW);
               //MApp_ZUI_ACT_ShowMainMenuBackground(HWND_MENU_BOTTOM_BALL_FOCUS_PICTURE);
               MApp_ZUI_API_SetFocus(HWND_MENU_PICTURE_NOISE_REDUCTION);
               break;
            case EN_COMMON_SINGLELIST_SURROUND_SOUND:
               MApp_ZUI_API_ShowWindow(HWND_MENU_SOUND_PAGE, SW_SHOW);
               //MApp_ZUI_ACT_ShowMainMenuBackground(HWND_MENU_BOTTOM_BALL_FOCUS_SOUND);
               MApp_ZUI_API_SetFocus(HWND_MENU_SOUND_SURROUND);
               break;
            case EN_COMMON_SINGLELIST_SLEEP_TIMER:
               MApp_ZUI_API_ShowWindow(HWND_MENU_TIME_PAGE, SW_SHOW);
               //MApp_ZUI_ACT_ShowMainMenuBackground(HWND_MENU_BOTTOM_BALL_FOCUS_TIME);
               MApp_ZUI_API_SetFocus(HWND_MENU_TIME_SET_SLEEP_TIMER);
               break;
            case EN_COMMON_SINGLELIST_PARENTAL_GUIDANCE:
               MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_PAGE, SW_SHOW);
              // MApp_ZUI_ACT_ShowMainMenuBackground(HWND_MENU_BOTTOM_BALL_FOCUS_LOCK);
               #if 0//fix compiling error  //Roger.li###
               MApp_ZUI_API_SetFocus(HWND_MENU_LOCK_PARENTAL_GUIDANCE);
               #endif
               break;

	#if  (ATSC_CC == ATV_CC)
            case EN_COMMON_SINGLELIST_CC_OPTION:
                MApp_ZUI_API_ShowWindow(HWND_MENU_OPTION_PAGE, SW_SHOW);
                //MApp_ZUI_ACT_ShowMainMenuBackground(HWND_MENU_BOTTOM_BALL_FOCUS_OPTION);
                MApp_ZUI_API_SetFocus(HWND_MENU_OPTION_CC_OPTION);
                break;
        #endif

            #if ENABLE_3D_PROCESS
            case EN_COMMON_SINGLELIST_3D_OPTION:
                MApp_ZUI_API_ShowWindow(HWND_MENU_OPTION_PAGE, SW_SHOW);
                //MApp_ZUI_ACT_ShowMainMenuBackground(HWND_MENU_BOTTOM_BALL_FOCUS_OPTION);
                MApp_ZUI_API_SetFocus(HWND_MENU_OPTION_3D_TYPE);
                break;
            #endif

            default:
               break;
        }

        _eCommonSingleMode = EN_COMMON_SINGLELIST_INVALID;

    }
    else if(MApp_ZUI_API_IsSuccessor(HWND_MENU_OPTIONLIST_COMMON_PAGE, MApp_ZUI_API_GetFocus()))
    {
        MApp_ZUI_API_ShowWindow(HWND_MENU_OPTIONLIST_COMMON_PAGE, SW_HIDE);
#ifdef NETWORK_CONFIG
        MApp_ZUI_API_ShowWindow(HWND_MENU_CHECK_NETWORK, SW_HIDE);//must
#endif
        switch(_eCommonOptionMode)
        {
            case EN_COMMON_OPTIONLIST_NETWORK_DNS:
                MApp_ZUI_API_ShowWindow(HWND_MENU_OPTIONLIST_COMMON_PAGE, SW_SHOW);
                MApp_ZUI_API_SetFocus(HWND_MENU_OPTIONLIST_ITEM5);
                _eCommonOptionMode = EN_COMMON_OPTIONLIST_NETWORK_CONFIG;
                return;
            case EN_COMMON_OPTIONLIST_NETWORK_GW:
                MApp_ZUI_API_ShowWindow(HWND_MENU_OPTIONLIST_COMMON_PAGE, SW_SHOW);
                MApp_ZUI_API_SetFocus(HWND_MENU_OPTIONLIST_ITEM4);
                _eCommonOptionMode = EN_COMMON_OPTIONLIST_NETWORK_CONFIG;
                return;
            case EN_COMMON_OPTIONLIST_NETWORK_IP:
                MApp_ZUI_API_ShowWindow(HWND_MENU_OPTIONLIST_COMMON_PAGE, SW_SHOW);
                MApp_ZUI_API_SetFocus(HWND_MENU_OPTIONLIST_ITEM2);
                _eCommonOptionMode = EN_COMMON_OPTIONLIST_NETWORK_CONFIG;
                return;
            case EN_COMMON_OPTIONLIST_NETWORK_NETMASK:
                MApp_ZUI_API_ShowWindow(HWND_MENU_OPTIONLIST_COMMON_PAGE, SW_SHOW);
                MApp_ZUI_API_SetFocus(HWND_MENU_OPTIONLIST_ITEM3);
                _eCommonOptionMode = EN_COMMON_OPTIONLIST_NETWORK_CONFIG;
                return;
            case EN_COMMON_OPTIONLIST_NETWORK_CONFIG:
                MS_DEBUG_MSG(printf("setting network config\n"));
#ifdef NETWORK_CONFIG
                MApp_Network_Config();
#endif

                //MApp_ZUI_ACT_ShowMainMenuBackground(HWND_MENU_BOTTOM_BALL_FOCUS_OPTION);
                MApp_ZUI_API_ShowWindow(HWND_MENU_OPTION_PAGE, SW_SHOW);
                //MApp_ZUI_API_SetFocus(HWND_MENU_OPTION_NET_CONFIG);
                break;

            case EN_COMMON_OPTIONLIST_SOUND_BALANCE:
                //MApp_ZUI_ACT_ShowMainMenuBackground(HWND_MENU_BOTTOM_BALL_FOCUS_SOUND);
                MApp_ZUI_API_ShowWindow(HWND_MENU_SOUND_PAGE, SW_SHOW);
                MApp_ZUI_API_SetFocus(HWND_MENU_SOUND_BALANCE);
                break;

            default:
               break;
        }
        _eCommonOptionMode = EN_COMMON_OPTIONLIST_INVALID;
    }
  #if ENABLE_DTV
    else if(MApp_ZUI_API_IsSuccessor(HWND_MENU_TIME_TIMEZONE_PAGE, MApp_ZUI_API_GetFocus()))
    {
        MApp_ZUI_API_ShowWindow(HWND_MENU_TIME_TIMEZONE_PAGE, SW_HIDE);
        MApp_ZUI_API_ShowWindow(HWND_MENU_TIME_PAGE, SW_SHOW);
        //MApp_ZUI_ACT_ShowMainMenuBackground(HWND_MENU_BOTTOM_BALL_FOCUS_TIME);
        MApp_ZUI_API_SetFocus(HWND_MENU_TIME_SET_TIMEZONE);
    }
  #endif
#endif

    else if(HWND_MENU_PIC_ADJ_CONTRAST == MApp_ZUI_API_GetFocus()    ||
            HWND_MENU_PIC_ADJ_BRIGHTNESS == MApp_ZUI_API_GetFocus()  ||
            HWND_MENU_PIC_ADJ_COLOR == MApp_ZUI_API_GetFocus()       ||
            HWND_MENU_PIC_ADJ_SHARPNESS== MApp_ZUI_API_GetFocus()    ||
            HWND_MENU_PIC_ADJ_TINT== MApp_ZUI_API_GetFocus()         ||

            HWND_MENU_PIC_ADJ_TEMP_RED == MApp_ZUI_API_GetFocus()   ||
            HWND_MENU_PIC_ADJ_TEMP_GREEN == MApp_ZUI_API_GetFocus() ||
            HWND_MENU_PIC_ADJ_TEMP_BLUE == MApp_ZUI_API_GetFocus()
            )
    {
        HWND TempWND = MApp_ZUI_API_GetFocus();

        if(
            HWND_MENU_PIC_ADJ_TEMP_RED == MApp_ZUI_API_GetFocus()   ||
            HWND_MENU_PIC_ADJ_TEMP_GREEN == MApp_ZUI_API_GetFocus() ||
            HWND_MENU_PIC_ADJ_TEMP_BLUE == MApp_ZUI_API_GetFocus()
           )
        {
            MApp_ZUI_API_ShowWindow(HWND_MENU_PICTURE_ADJUST, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_TEMP_RED, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_TEMP_GREEN, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_TEMP_BLUE, SW_HIDE);

            MApp_ZUI_API_ShowWindow(HWND_MENU_PICTURE_COLOR_PAGE, SW_SHOW);

            switch(TempWND)
            {
                case HWND_MENU_PIC_ADJ_TEMP_RED:
                    MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_PICTURE_COLOR_PAGE_LIST, HWND_MENU_PICCOLOR_COLOR_RED);
                    break;
                case HWND_MENU_PIC_ADJ_TEMP_GREEN:
                    MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_PICTURE_COLOR_PAGE_LIST, HWND_MENU_PICCOLOR_COLOR_GREEN);
                    break;
                case HWND_MENU_PIC_ADJ_TEMP_BLUE:
                    MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_PICTURE_COLOR_PAGE_LIST, HWND_MENU_PICCOLOR_COLOR_BLUE);
                    break;
            }
        }
        else
        {
            MApp_ZUI_API_ShowWindow(HWND_MENU_PICTURE_ADJUST, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_CONTRAST, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_BRIGHTNESS, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_COLOR, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_SHARPNESS, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_TINT, SW_HIDE);

            MApp_ZUI_API_ShowWindow(HWND_MENU_PICTURE_MODE_PAGE, SW_SHOW);

            switch(TempWND)
            {
                case HWND_MENU_PIC_ADJ_CONTRAST:
                    MApp_ZUI_API_SetFocus(HWND_MENU_PICMODE_CONTRAST);
                    break;
                case HWND_MENU_PIC_ADJ_BRIGHTNESS:
                    MApp_ZUI_API_SetFocus(HWND_MENU_PICMODE_BRIGHTNESS);
                    break;
                case HWND_MENU_PIC_ADJ_COLOR:
                    MApp_ZUI_API_SetFocus(HWND_MENU_PICMODE_COLOR);
                    break;
                case HWND_MENU_PIC_ADJ_SHARPNESS:
                    MApp_ZUI_API_SetFocus(HWND_MENU_PICMODE_SHARPNESS);
                    break;
                case HWND_MENU_PIC_ADJ_TINT:
                    MApp_ZUI_API_SetFocus(HWND_MENU_PICMODE_TINT);
                    break;
                default:
                    MApp_ZUI_API_SetFocus(HWND_MENU_PICMODE_PICMODE);
                    break;
            }
        }
    }
    else if(MApp_ZUI_API_IsSuccessor(HWND_MENU_HDMI_CEC_PAGE, MApp_ZUI_API_GetFocus()))
    {
        MApp_ZUI_API_ShowWindow(HWND_MENU_HDMI_CEC_PAGE, SW_HIDE);
        MApp_ZUI_API_ShowWindow(HWND_MENU_OPTION_PAGE, SW_SHOW);
        //MApp_ZUI_ACT_ShowMainMenuBackground(HWND_MENU_BOTTOM_BALL_FOCUS_OPTION);
        MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_OPTION_PAGE_LIST, HWND_MENU_OPTION_HDMI_CEC);

    }
    else if(MApp_ZUI_API_IsSuccessor(HWND_MENU_HDMI_CEC_DEVICE_LIST_PAGE, MApp_ZUI_API_GetFocus()))
    {
        MApp_ZUI_API_ShowWindow(HWND_MENU_HDMI_CEC_DEVICE_LIST_PAGE, SW_HIDE);
        MApp_ZUI_API_ShowWindow(HWND_MENU_TRANSPARENT_BG, SW_SHOW);
        MApp_ZUI_API_ShowWindow(HWND_MENU_HDMI_CEC_PAGE, SW_SHOW);
        MApp_ZUI_API_SetFocus(HWND_MENU_HDMI_CEC_DEVICE_LIST);
    }

    else if(MApp_ZUI_API_IsSuccessor(HWND_MENU_LOCK_INPUT_MAINSUBPAGE, MApp_ZUI_API_GetFocus()))
    {
        MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_INPUT_SUBPAGE, SW_HIDE);
        MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_SUBPAGE, SW_SHOW);
        MApp_ZUI_API_SetFocus(HWND_MENU_LOCK_MAINSUBPAGE_ITEM_INPUTBLOCK);
    }
    else if(MApp_ZUI_API_IsSuccessor(HWND_MENU_LOCK_MAINSUBPAGE, MApp_ZUI_API_GetFocus()))
    {
        MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_SUBPAGE, SW_HIDE);
        MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_PAGE, SW_SHOW);
        MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_PAGE_CHECKPWD_ERROR_MSG, SW_HIDE);
        MApp_ZUI_API_SetFocus(HWND_MENU_LOCK_ENTER_PASSWORD);
    }

    MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_BG_MENUPAGE_INFO); //refresh mainmenu page info text
}

#if 1//(ENABLE_ATV_VCHIP)
static void _MApp_ZUI_ACT_PasswordHandler(VIRTUAL_KEY_CODE key)
{
    HWND hwnd = MApp_ZUI_API_GetFocus();
	#if(UI_SKIN_SEL==UI_SKIN_1366X768X565_HAIER_CN)  // CUS_xm zHIHE 20120807 modify
    if(HWND_MENU_LOCK_ENTER_PASSWORD == hwnd||
		HWND_MENU_LOCK_NEWPSW == hwnd||
		HWND_MENU_LOCK_CONFIMNEWPSW == hwnd
        ||HWND_MENU_LOCK_ENTER_PASSWORD_OPTION==hwnd
        ||HWND_MENU_LOCK_ENTER_PASSWORD_OPTION_1==hwnd
        ||HWND_MENU_LOCK_ENTER_PASSWORD_OPTION_2==hwnd
        ||HWND_MENU_LOCK_ENTER_PASSWORD_OPTION_3==hwnd
	)
	#else
	if(HWND_MENU_LOCK_ENTER_PASSWORD == hwnd||
		HWND_MENU_LOCK_NEWPSW == hwnd||
		HWND_MENU_LOCK_CONFIMNEWPSW == hwnd
	)
	#endif
    {
        printf("Position:%d\n",g_u8PasswordPosition);
        g_u8PasswordCount++;
        g_u8PasswordPosition++;
        g_u16Password = (g_u16Password<<4)|(key-VK_NUM_0);
        if (g_u8PasswordCount == PASSWORD_SIZE)
        {
            #if(UI_SKIN_SEL==UI_SKIN_1366X768X565_HAIER_CN)  // CUS_xm zHIHE 20120807 modify
			if(HWND_MENU_LOCK_ENTER_PASSWORD == hwnd||HWND_MENU_LOCK_ENTER_PASSWORD_OPTION_3==hwnd)
            #else
            if(HWND_MENU_LOCK_ENTER_PASSWORD == hwnd)
		    #endif
     //       MApp_ZUI_API_IsSuccessor(HWND_MENU_LOCK_CHANGEPWSUBPAGE_ITEM_OLDPW, hwnd))
            {
				U16 u16SuperPassword = 0;
				U16 u16SuperPassword_1 = 0;
				U32 u32SuperPassword_Macro = SUPER_PASSWORD;
				U32 u32SuperPassword_Macro_1 = SUPER_PASSWORD_1;
				u16SuperPassword = (u32SuperPassword_Macro/1000)<<12;
				u16SuperPassword = u16SuperPassword | (((u32SuperPassword_Macro%1000)/100)<<8);
				u16SuperPassword = u16SuperPassword | (((u32SuperPassword_Macro%100)/10)<<4);
				u16SuperPassword = u16SuperPassword | ((u32SuperPassword_Macro%10));
				
				u16SuperPassword_1= (u32SuperPassword_Macro_1/1000)<<12;
				u16SuperPassword_1= u16SuperPassword_1| (((u32SuperPassword_Macro_1%1000)/100)<<8);
				u16SuperPassword_1= u16SuperPassword_1| (((u32SuperPassword_Macro_1%100)/10)<<4);
				u16SuperPassword_1= u16SuperPassword_1| ((u32SuperPassword_Macro_1%10));
				
				if ((g_u16Password == stGenSetting.g_VChipSetting.u16VChipPassword) ||
					(g_u16Password == u16SuperPassword) || (g_u16Password == u16SuperPassword_1))
                {
                    #if(UI_SKIN_SEL==UI_SKIN_1366X768X565_HAIER_CN)  // CUS_xm zHIHE 20120807 modify
					if(HWND_MENU_LOCK_ENTER_PASSWORD == hwnd||HWND_MENU_LOCK_ENTER_PASSWORD_OPTION_3==hwnd)
                    #else
                    if(HWND_MENU_LOCK_ENTER_PASSWORD == hwnd )
				    #endif
                    {
                        g_u8PasswordPosition = 0;
                        #if ENABLE_CUS_BLOCK_SYS
                        if((bEnterPW2ChannelsList) && MApp_UiMenuFunc_CheckInputLockAudioVideo())
                        {
                            g_u16PasswordCheckSource &= (~INPUT_BLOCK_TV);
                            if((stGenSetting.g_VChipSetting.u8InputBlockItem & INPUT_BLOCK_TV) == 0x00)
                            {
                                msAPI_ATV_SetLockedCHCheckPwdFlag(msAPI_ATV_GetCurrentProgramNumber(),TRUE);
                            }
                            MApp_MuteAvByLock(E_SCREEN_MUTE_INPUT, FALSE);
                            if(MApp_IsSrcHasSignal(MAIN_WINDOW))// || IsATVInUse())
                            {
                                msAPI_Scaler_SetScreenMute(E_SCREEN_MUTE_TEMPORARY, DISABLE, 0, MAIN_WINDOW);
                                if((msAPI_Scaler_GetScreenMute(MAIN_WINDOW)&E_SCREEN_MUTE_FREERUN))
                                {
                                    msAPI_Scaler_SetBlueScreen( DISABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
                                }
                            }
                            MApp_CheckBlockProgramme();
                        }
                        #endif
                        MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_GOTO_SUBPAGE);
                    }
                    else //HWND_MENU_LOCK_CHANGEPWSUBPAGE_ITEM_OLDPW
                    {

           //             MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_CHANGEPWSUBPAGE_ITEM_OLDPW, FALSE);
                   //     MApp_ZUI_API_SetFocus(HWND_MENU_LOCK_CHANGEPWSUBPAGE_PW1_1);
                    }
                }
                else
                {
                    g_u8PasswordPosition = 0;
					#if(UI_SKIN_SEL==UI_SKIN_1366X768X565_HAIER_CN)  // CUS_xm zHIHE 20120807 modify
					if(HWND_MENU_LOCK_ENTER_PASSWORD == hwnd||HWND_MENU_LOCK_ENTER_PASSWORD_OPTION_3==hwnd)
					 {
                        MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_PAGE_CHECKPWD_ERROR_MSG, SW_SHOW);
                        MApp_ZUI_API_SetTimer(HWND_MENU_LOCK_PAGE_CHECKPWD_ERROR_MSG,1, 3000);
                        g_u8PasswordPosition = 4;
    					MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_LOCK_ENTER_PASSWORD);
						MApp_ZUI_API_SetFocus(HWND_MENU_LOCK_ENTER_PASSWORD);
                    }
                    #else
                    if(HWND_MENU_LOCK_ENTER_PASSWORD == hwnd )

                    {
                        MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_PAGE_CHECKPWD_ERROR_MSG, SW_SHOW);
                        MApp_ZUI_API_SetTimer(HWND_MENU_LOCK_PAGE_CHECKPWD_ERROR_MSG,1, 3000);
                        g_u8PasswordPosition = 4;
    					MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_LOCK_ENTER_PASSWORD);
                    }
					#endif
                    else
                    {
					;
					}
                }
            }
            else if(HWND_MENU_LOCK_NEWPSW== hwnd)
            {
                g_u16PasswordTemp = g_u16Password;
                MApp_ZUI_API_SetFocus(HWND_MENU_LOCK_CONFIMNEWPSW);

            }
            else //HWND_MENU_LOCK_CONFIMNEWPSW
            {
                if(g_u16PasswordTemp == g_u16Password)
                {
                    stGenSetting.g_VChipSetting.u16VChipPassword = g_u16PasswordTemp;
                    MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_GOTO_PARENTPAGE);
                    g_u8PasswordPosition = 0;
                }
                else
                {
                    MApp_ZUI_API_ShowWindow(HWND_MENU_CONFIMNEWPSW_TEXT_1, SW_SHOW);
                    MApp_ZUI_API_SetTimer(HWND_MENU_CONFIMNEWPSW_TEXT_1,1, 3000);
                    g_u8PasswordPosition = 4;
					MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_LOCK_PAGE_CHANGEPW);
                }
            }
            g_u16Password = 0;
            g_u8PasswordCount = 0;
        }
        else
        {;
        }
        MApp_ZUI_API_InvalidateAllSuccessors(hwnd);
}
}
#endif

static void _MApp_ZUI_ACT_MainpageNumKeyHandler(VIRTUAL_KEY_CODE key)
{
    HWND hwnd = MApp_ZUI_API_GetFocus();
    if(HWND_MENU_TIME_SET_DATE == hwnd )
    {
        ST_TIME _stTime;
        U16 u16TimeValue;
        MApp_ConvertSeconds2StTime(MApp_GetLocalSystemTime(),&_stTime);

        //printf("\r\n 1.g_u8IdleMainpageDigitKeyCount =[%bu], ",g_u8IdleMainpageDigitKeyCount);
        // YEAR
        if(g_u8IdleMainpageDigitKeyCount <2)
        {
            g_u8TimeInfo_Flag  |= UI_TIME_YEAR_SET;
            u16TimeValue = stLMGenSetting.stMD.u16Option_Info_Year;
        }
        else if(g_u8IdleMainpageDigitKeyCount == 2)
        {
            g_u8TimeInfo_Flag  |= UI_TIME_YEAR_SET;
            u16TimeValue =2000+(key-VK_NUM_0)*10+((stLMGenSetting.stMD.u16Option_Info_Year - 2000)%10);
            stLMGenSetting.stMD.u16Option_Info_Year = u16TimeValue;
        }
        else if(g_u8IdleMainpageDigitKeyCount == 3)
        {
            g_u8TimeInfo_Flag  |= UI_TIME_YEAR_SET;
            u16TimeValue = stLMGenSetting.stMD.u16Option_Info_Year - (stLMGenSetting.stMD.u16Option_Info_Year%10)+(key-VK_NUM_0);
            stLMGenSetting.stMD.u16Option_Info_Year = u16TimeValue;
        }
        // MONTH
        else if(g_u8IdleMainpageDigitKeyCount == 4)
        {
            g_u8TimeInfo_Flag  |= UI_TIME_MONTH_SET;
            u16TimeValue = (key-VK_NUM_0)*10+stLMGenSetting.stMD.u16Option_Info_Month%10;
            if(u16TimeValue < 1)
            {
                u16TimeValue = 1;
            }
            else if(u16TimeValue > 12)
            {
                u16TimeValue = 12;
            }
            stLMGenSetting.stMD.u16Option_Info_Month = u16TimeValue;

            if(stLMGenSetting.stMD.u16Option_Info_Month == 2)
            {
                U8 U8Maxday;
                U8Maxday = MApp_GetDaysOfThisMonth(stLMGenSetting.stMD.u16Option_Info_Year,stLMGenSetting.stMD.u16Option_Info_Month);
                if(stLMGenSetting.stMD.u16Option_Info_Day >U8Maxday)
                {
                    stLMGenSetting.stMD.u16Option_Info_Day = U8Maxday;
                }
            }
        }
        else if(g_u8IdleMainpageDigitKeyCount == 5)
        {
            g_u8TimeInfo_Flag  |= UI_TIME_MONTH_SET;
            u16TimeValue = (key-VK_NUM_0) + stLMGenSetting.stMD.u16Option_Info_Month-(stLMGenSetting.stMD.u16Option_Info_Month%10);
            if(u16TimeValue < 1)
            {
                u16TimeValue = 1;
            }
            else if(u16TimeValue > 12)
            {
                u16TimeValue = 12;
            }
            stLMGenSetting.stMD.u16Option_Info_Month = u16TimeValue;
            if(stLMGenSetting.stMD.u16Option_Info_Month == 2)
            {
                U8 U8Maxday;
                U8Maxday = MApp_GetDaysOfThisMonth(stLMGenSetting.stMD.u16Option_Info_Year,stLMGenSetting.stMD.u16Option_Info_Month);
                if(stLMGenSetting.stMD.u16Option_Info_Day >U8Maxday)
                {
                    stLMGenSetting.stMD.u16Option_Info_Day = U8Maxday;
                }
            }
        }
        //DAY
        else if(g_u8IdleMainpageDigitKeyCount == 6)
        {
            U8 U8Maxday;
            g_u8TimeInfo_Flag  |= UI_TIME_DAY_SET;
            U8Maxday = MApp_GetDaysOfThisMonth(stLMGenSetting.stMD.u16Option_Info_Year,stLMGenSetting.stMD.u16Option_Info_Month);
            u16TimeValue = (key-VK_NUM_0)*10+stLMGenSetting.stMD.u16Option_Info_Day%10;
            if(u16TimeValue <1)
            {
                u16TimeValue = 1;
            }
            else if(u16TimeValue > U8Maxday)
            {
                u16TimeValue = U8Maxday;
            }
            stLMGenSetting.stMD.u16Option_Info_Day= u16TimeValue;
        }
        else if(g_u8IdleMainpageDigitKeyCount == 7)
        {
            U8 U8Maxday;
            g_u8TimeInfo_Flag  |= UI_TIME_DAY_SET;
            u16TimeValue = (key-VK_NUM_0) +stLMGenSetting.stMD.u16Option_Info_Day-(stLMGenSetting.stMD.u16Option_Info_Day%10);
            U8Maxday = MApp_GetDaysOfThisMonth(stLMGenSetting.stMD.u16Option_Info_Year,stLMGenSetting.stMD.u16Option_Info_Month);
            if(u16TimeValue <1)
            {
                u16TimeValue = 1;
            }
            else if(u16TimeValue > U8Maxday)
            {
                u16TimeValue = U8Maxday;
            }
            stLMGenSetting.stMD.u16Option_Info_Day= u16TimeValue;
        }
        else
        {
            stLMGenSetting.stMD.u16Option_Info_Year = 2010;
            stLMGenSetting.stMD.u16Option_Info_Month = 01;
            stLMGenSetting.stMD.u16Option_Info_Day = 01;
        }

        g_u8IdleMainpageDigitKeyCount++;
        if(g_u8IdleMainpageDigitKeyCount >7)
        {
            g_u8IdleMainpageDigitKeyCount = 7;
        }


        _stTime.u16Year = stLMGenSetting.stMD.u16Option_Info_Year;
        _stTime.u8Month = stLMGenSetting.stMD.u16Option_Info_Month;
        _stTime.u8Day= stLMGenSetting.stMD.u16Option_Info_Day;
        _stTime.u8Hour= 0;
        _stTime.u8Min= 0;
        _stTime.u8Sec= 0;
        MApp_SetLocalSystemTime(MApp_ConvertStTime2Seconds(&_stTime));
        //printf("\r\n Set Date:YYYY/MM/DD = %04u/%02u/%02u",stLMGenSetting.stMD.u16Option_Info_Year,
            //stLMGenSetting.stMD.u16Option_Info_Month,
            //stLMGenSetting.stMD.u16Option_Info_Day);
        MApp_ZUI_API_InvalidateAllSuccessors(hwnd);
    }
    else if(HWND_MENU_TIME_SET_CLOCK == hwnd )
    {
        ST_TIME _stTime;
        U16 u16TimeValue;
        MApp_ConvertSeconds2StTime(MApp_GetLocalSystemTime(),&_stTime);
        // Hour
        if(g_u8IdleMainpageDigitKeyCount ==0)
        {
            g_u8TimeInfo_Flag  |= UI_TIME_HOUR_SET;
            u16TimeValue = stLMGenSetting.stMD.u16Option_Info_Hour;
            u16TimeValue = (key-VK_NUM_0)*10+(u16TimeValue%10);
            stLMGenSetting.stMD.u16Option_Info_Hour = u16TimeValue;
            if(stLMGenSetting.stMD.u16Option_Info_Hour >23)
            {
                stLMGenSetting.stMD.u16Option_Info_Hour = 23;
            }
        }
        else if(g_u8IdleMainpageDigitKeyCount == 1)
        {
            g_u8TimeInfo_Flag  |= UI_TIME_HOUR_SET;
            u16TimeValue = stLMGenSetting.stMD.u16Option_Info_Hour - (stLMGenSetting.stMD.u16Option_Info_Hour%10);
            u16TimeValue = (key-VK_NUM_0) +u16TimeValue;
            stLMGenSetting.stMD.u16Option_Info_Hour = u16TimeValue;
            if(stLMGenSetting.stMD.u16Option_Info_Hour >23)
            {
                stLMGenSetting.stMD.u16Option_Info_Hour = 23;
            }
        }
        // Minute
        else if(g_u8IdleMainpageDigitKeyCount == 2)
        {
            g_u8TimeInfo_Flag  |= UI_TIME_MINUTE_SET;
            u16TimeValue = stLMGenSetting.stMD.u16Option_Info_Min;
            u16TimeValue = (key-VK_NUM_0)*10+(u16TimeValue%10);
            stLMGenSetting.stMD.u16Option_Info_Min = u16TimeValue;
            if(stLMGenSetting.stMD.u16Option_Info_Min >59)
            {
                stLMGenSetting.stMD.u16Option_Info_Min = 59;
            }
        }
        else if(g_u8IdleMainpageDigitKeyCount == 3)
        {
            g_u8TimeInfo_Flag  |= UI_TIME_MINUTE_SET;
            u16TimeValue = stLMGenSetting.stMD.u16Option_Info_Min - (stLMGenSetting.stMD.u16Option_Info_Min%10);
            u16TimeValue = (key-VK_NUM_0) +u16TimeValue;
            stLMGenSetting.stMD.u16Option_Info_Min = u16TimeValue;
            if(stLMGenSetting.stMD.u16Option_Info_Min >59)
            {
                stLMGenSetting.stMD.u16Option_Info_Min = 59;
            }
        }
        //Second
        else if(g_u8IdleMainpageDigitKeyCount == 4)
        {
            g_u8TimeInfo_Flag  |= UI_TIME_MINUTE_SET;
            u16TimeValue = stLMGenSetting.stMD.u16Option_Info_Sec;
            u16TimeValue = (key-VK_NUM_0)*10+(u16TimeValue%10);
            stLMGenSetting.stMD.u16Option_Info_Sec = u16TimeValue;
            if(stLMGenSetting.stMD.u16Option_Info_Sec >59)
            {
                stLMGenSetting.stMD.u16Option_Info_Sec = 59;
            }
        }
        else if(g_u8IdleMainpageDigitKeyCount == 5)
        {
            g_u8TimeInfo_Flag  |= UI_TIME_MINUTE_SET;
            u16TimeValue = stLMGenSetting.stMD.u16Option_Info_Sec - (stLMGenSetting.stMD.u16Option_Info_Sec%10);
            u16TimeValue = (key-VK_NUM_0) +u16TimeValue;
            stLMGenSetting.stMD.u16Option_Info_Sec = u16TimeValue;
            if(stLMGenSetting.stMD.u16Option_Info_Sec >59)
            {
                stLMGenSetting.stMD.u16Option_Info_Sec = 59;
            }
        }
        else
        {
            stLMGenSetting.stMD.u16Option_Info_Hour= 0;
            stLMGenSetting.stMD.u16Option_Info_Min= 0;
            stLMGenSetting.stMD.u16Option_Info_Sec= 0;
        }

        g_u8IdleMainpageDigitKeyCount++;
        if(g_u8IdleMainpageDigitKeyCount >5)
        {
            g_u8IdleMainpageDigitKeyCount = 5;
        }

        _stTime.u16Year = stLMGenSetting.stMD.u16Option_Info_Year;
        _stTime.u8Month = stLMGenSetting.stMD.u16Option_Info_Month;
        _stTime.u8Day= stLMGenSetting.stMD.u16Option_Info_Day;
        _stTime.u8Hour= stLMGenSetting.stMD.u16Option_Info_Hour;
        _stTime.u8Min= stLMGenSetting.stMD.u16Option_Info_Min;
        _stTime.u8Sec= stLMGenSetting.stMD.u16Option_Info_Sec;
        MApp_SetLocalSystemTime(MApp_ConvertStTime2Seconds(&_stTime));
        //printf("\r\n Set Date:HH/MM/SS = %02u/%02u/%02u",stLMGenSetting.stMD.u16Option_Info_Hour,
            //stLMGenSetting.stMD.u16Option_Info_Min,
            //stLMGenSetting.stMD.u16Option_Info_Sec);
        MApp_ZUI_API_InvalidateAllSuccessors(hwnd);

        MApp_Time_SetOnTime();
    }
    else if(HWND_MENU_TIME_SET_ONTIME == hwnd )
    {
        U16 u16TimeValue;
        // Hour
        if(g_u8IdleMainpageDigitKeyCount ==0)
        {
            u16TimeValue = stGenSetting.g_Time.u16OnTimer_Info_Hour;
            u16TimeValue = (key-VK_NUM_0)*10+(u16TimeValue%10);
            stGenSetting.g_Time.u16OnTimer_Info_Hour = u16TimeValue;
            if(stGenSetting.g_Time.u16OnTimer_Info_Hour >23)
            {
                stGenSetting.g_Time.u16OnTimer_Info_Hour = 23;
            }
        }
        else if(g_u8IdleMainpageDigitKeyCount == 1)
        {
            u16TimeValue = stGenSetting.g_Time.u16OnTimer_Info_Hour - (stGenSetting.g_Time.u16OnTimer_Info_Hour%10);
            u16TimeValue = (key-VK_NUM_0) +u16TimeValue;
            stGenSetting.g_Time.u16OnTimer_Info_Hour = u16TimeValue;
            if(stGenSetting.g_Time.u16OnTimer_Info_Hour >23)
            {
                stGenSetting.g_Time.u16OnTimer_Info_Hour = 23;
            }
        }
        // Minute
        else if(g_u8IdleMainpageDigitKeyCount == 2)
        {
            u16TimeValue = stGenSetting.g_Time.u16OnTimer_Info_Min;
            u16TimeValue = (key-VK_NUM_0)*10+(u16TimeValue%10);
            stGenSetting.g_Time.u16OnTimer_Info_Min = u16TimeValue;
            if(stGenSetting.g_Time.u16OnTimer_Info_Min >59)
            {
                stGenSetting.g_Time.u16OnTimer_Info_Min = 59;
            }
        }
        else if(g_u8IdleMainpageDigitKeyCount == 3)
        {
            u16TimeValue = stGenSetting.g_Time.u16OnTimer_Info_Min - (stGenSetting.g_Time.u16OnTimer_Info_Min%10);
            u16TimeValue = (key-VK_NUM_0) +u16TimeValue;
            stGenSetting.g_Time.u16OnTimer_Info_Min = u16TimeValue;
            if(stGenSetting.g_Time.u16OnTimer_Info_Min >59)
            {
                stGenSetting.g_Time.u16OnTimer_Info_Min = 59;
            }
        }
        //Second
        else if(g_u8IdleMainpageDigitKeyCount == 4)
        {
            u16TimeValue = stGenSetting.g_Time.u16OnTimer_Info_Sec;
            u16TimeValue = (key-VK_NUM_0)*10+(u16TimeValue%10);
            stGenSetting.g_Time.u16OnTimer_Info_Sec = u16TimeValue;
            if(stGenSetting.g_Time.u16OnTimer_Info_Sec >59)
            {
                stGenSetting.g_Time.u16OnTimer_Info_Sec = 59;
            }
        }
        // MONTH
        else if(g_u8IdleMainpageDigitKeyCount == 5)
        {
            u16TimeValue = stGenSetting.g_Time.u16OnTimer_Info_Sec - (stGenSetting.g_Time.u16OnTimer_Info_Sec%10);
            u16TimeValue = (key-VK_NUM_0) +u16TimeValue;
            stGenSetting.g_Time.u16OnTimer_Info_Sec = u16TimeValue;
            if(stGenSetting.g_Time.u16OnTimer_Info_Sec >59)
            {
                stGenSetting.g_Time.u16OnTimer_Info_Sec = 59;
            }
        }
        else
        {
            stGenSetting.g_Time.u16OnTimer_Info_Hour= 0;
            stGenSetting.g_Time.u16OnTimer_Info_Min= 0;
            stGenSetting.g_Time.u16OnTimer_Info_Sec= 0;
        }

        g_u8IdleMainpageDigitKeyCount++;
        if(g_u8IdleMainpageDigitKeyCount >5)
        {
            g_u8IdleMainpageDigitKeyCount = 5;
        }

        MApp_ZUI_API_InvalidateAllSuccessors(hwnd);
        MApp_Time_SetOnTime();
    }
    else if(HWND_MENU_TIME_SET_OFFTIME == hwnd )
    {
        U16 u16TimeValue;
        // Hour
        if(g_u8IdleMainpageDigitKeyCount ==0)
        {
            u16TimeValue = stGenSetting.g_Time.u16OffTimer_Info_Hour;
            u16TimeValue = (key-VK_NUM_0)*10+(u16TimeValue%10);
            stGenSetting.g_Time.u16OffTimer_Info_Hour = u16TimeValue;
            if(stGenSetting.g_Time.u16OffTimer_Info_Hour >23)
            {
                stGenSetting.g_Time.u16OffTimer_Info_Hour = 23;
            }
        }
        else if(g_u8IdleMainpageDigitKeyCount == 1)
        {
            u16TimeValue = stGenSetting.g_Time.u16OffTimer_Info_Hour - (stGenSetting.g_Time.u16OffTimer_Info_Hour%10);
            u16TimeValue = (key-VK_NUM_0) +u16TimeValue;
            stGenSetting.g_Time.u16OffTimer_Info_Hour = u16TimeValue;
            if(stGenSetting.g_Time.u16OffTimer_Info_Hour >23)
            {
                stGenSetting.g_Time.u16OffTimer_Info_Hour = 23;
            }
        }
        // Minute
        else if(g_u8IdleMainpageDigitKeyCount == 2)
        {
            u16TimeValue = stGenSetting.g_Time.u16OffTimer_Info_Min;
            u16TimeValue = (key-VK_NUM_0)*10+(u16TimeValue%10);
            stGenSetting.g_Time.u16OffTimer_Info_Min = u16TimeValue;
            if(stGenSetting.g_Time.u16OffTimer_Info_Min >59)
            {
                stGenSetting.g_Time.u16OffTimer_Info_Min = 59;
            }
        }
        else if(g_u8IdleMainpageDigitKeyCount == 3)
        {
            u16TimeValue = stGenSetting.g_Time.u16OffTimer_Info_Min - (stGenSetting.g_Time.u16OffTimer_Info_Min%10);
            u16TimeValue = (key-VK_NUM_0) +u16TimeValue;
            stGenSetting.g_Time.u16OffTimer_Info_Min = u16TimeValue;
            if(stGenSetting.g_Time.u16OffTimer_Info_Min >59)
            {
                stGenSetting.g_Time.u16OffTimer_Info_Min = 59;
            }
        }
        //Second
        else if(g_u8IdleMainpageDigitKeyCount == 4)
        {
            u16TimeValue = stGenSetting.g_Time.u16OffTimer_Info_Sec;
            u16TimeValue = (key-VK_NUM_0)*10+(u16TimeValue%10);
            stGenSetting.g_Time.u16OffTimer_Info_Sec = u16TimeValue;
            if(stGenSetting.g_Time.u16OffTimer_Info_Sec >59)
            {
                stGenSetting.g_Time.u16OffTimer_Info_Sec = 59;
            }
        }
        // MONTH
        else if(g_u8IdleMainpageDigitKeyCount == 5)
        {
            u16TimeValue = stGenSetting.g_Time.u16OffTimer_Info_Sec - (stGenSetting.g_Time.u16OffTimer_Info_Sec%10);
            u16TimeValue = (key-VK_NUM_0) +u16TimeValue;
            stGenSetting.g_Time.u16OffTimer_Info_Sec = u16TimeValue;
            if(stGenSetting.g_Time.u16OffTimer_Info_Sec >59)
            {
                stGenSetting.g_Time.u16OffTimer_Info_Sec = 59;
            }
        }
        else
        {
            stGenSetting.g_Time.u16OffTimer_Info_Hour= 0;
            stGenSetting.g_Time.u16OffTimer_Info_Min= 0;
            stGenSetting.g_Time.u16OffTimer_Info_Sec= 0;
        }

        g_u8IdleMainpageDigitKeyCount++;
        if(g_u8IdleMainpageDigitKeyCount >5)
        {
            g_u8IdleMainpageDigitKeyCount = 5;
        }

        if (stGenSetting.g_Time.cOffTimerFlag !=EN_Time_OffTimer_Off)
        {
            g_u8TimeInfo_Flag  |= UI_TIME_MANUAL_SET;
            MApp_Sleep_SetOffTime(TRUE);
        }
        MApp_ZUI_API_InvalidateAllSuccessors(hwnd);
    }
    else if(HWND_MENU_CHANNEL_SCAN_PAGE_MANUAL_FREQ_BEGIN == hwnd)
    {
        U32 u32FreqValue;
        if(g_u8IdleMainpageDigitKeyCount ==0)
        {
            u32FreqValue = (key-VK_NUM_0)*1000;
        }
        else if(g_u8IdleMainpageDigitKeyCount == 1)
        {
            u32FreqValue = msAPI_Tuner_GetManualScanStartFreq()*10 + (key-VK_NUM_0)*1000;
        }
        else if(g_u8IdleMainpageDigitKeyCount == 2)
        {
            u32FreqValue = msAPI_Tuner_GetManualScanStartFreq()*10 + (key-VK_NUM_0)*1000;
        }
        else
        {
            u32FreqValue = (key-VK_NUM_0)*1000;
            g_u8IdleMainpageDigitKeyCount = 0;
        }

        g_u8IdleMainpageDigitKeyCount++;
        if(g_u8IdleMainpageDigitKeyCount >3)
        {
            g_u8IdleMainpageDigitKeyCount = 0;
        }
        msAPI_Tuner_SetManualScanStartFreq(u32FreqValue);
        MApp_ZUI_API_InvalidateAllSuccessors(hwnd);
    }
    else if(HWND_MENU_CHANNEL_SCAN_PAGE_MANUAL_FREQ_END== hwnd )
    {
        U32 u32FreqValue;
        if(g_u8IdleMainpageDigitKeyCount ==0)
        {
            u32FreqValue = (key-VK_NUM_0)*1000;
        }
        else if(g_u8IdleMainpageDigitKeyCount == 1)
        {
            u32FreqValue = msAPI_Tuner_GetManualScanEndFreq()*10 + (key-VK_NUM_0)*1000;
        }
        else if(g_u8IdleMainpageDigitKeyCount == 2)
        {
            u32FreqValue = msAPI_Tuner_GetManualScanEndFreq()*10 + (key-VK_NUM_0)*1000;
        }
        else
        {
            u32FreqValue = (key-VK_NUM_0)*1000;
            g_u8IdleMainpageDigitKeyCount = 0;
        }

        g_u8IdleMainpageDigitKeyCount++;
        if(g_u8IdleMainpageDigitKeyCount >3)
        {
            g_u8IdleMainpageDigitKeyCount = 0;
        }
        msAPI_Tuner_SetManualScanEndFreq(u32FreqValue);
        MApp_ZUI_API_InvalidateAllSuccessors(hwnd);
    }
    else if(HWND_MENU_CHANNEL_INFO_CH_NUM == hwnd )
    {
        U16 U16CHNumber;

        if(g_u8IdleMainpageDigitKeyCount ==0)
        {
            U16CHNumber = (key-VK_NUM_0);
        }
        else if(g_u8IdleMainpageDigitKeyCount == 1)
        {
            U16CHNumber = msAPI_ATV_ChannelInfoEdit_GetCHNum()*10 + (key-VK_NUM_0);
        }
        else if(g_u8IdleMainpageDigitKeyCount == 2)
        {
            U16CHNumber = msAPI_ATV_ChannelInfoEdit_GetCHNum()*10 + (key-VK_NUM_0);
        }
        else
        {
            U16CHNumber = (key-VK_NUM_0);
        }

        g_u8IdleMainpageDigitKeyCount++;
        if(g_u8IdleMainpageDigitKeyCount >3)
        {
            g_u8IdleMainpageDigitKeyCount = 0;
        }

        if((U16CHNumber <= MAX_ATVPROGRAM) && (U16CHNumber > 0))
        {
            msAPI_ATV_ChannelInfoEdit_SetCHNum(U16CHNumber);
        }


        MApp_ZUI_API_InvalidateAllSuccessors(hwnd);
    }


    else if(HWND_MENU_CHANNEL_INFO_FREQ == hwnd )
    {
        U32 u32FreqValue;
        if(g_u8IdleMainpageDigitKeyCount ==0)
        {
            u32FreqValue = (key-VK_NUM_0)*1000;
        }
        else if(g_u8IdleMainpageDigitKeyCount == 1)
        {
            u32FreqValue = msAPI_CFT_ConvertPLLtoFrequency(msAPI_ATV_ChannelInfoEdit_GetPLL())*10 + (key-VK_NUM_0)*1000;
        }
        else if(g_u8IdleMainpageDigitKeyCount == 2)
        {
            u32FreqValue = msAPI_CFT_ConvertPLLtoFrequency(msAPI_ATV_ChannelInfoEdit_GetPLL())*10 + (key-VK_NUM_0)*1000;
        }
        else
        {
            u32FreqValue = (key-VK_NUM_0)*1000;
        }

        g_u8IdleMainpageDigitKeyCount++;
        if(g_u8IdleMainpageDigitKeyCount >3)
        {
            g_u8IdleMainpageDigitKeyCount = 0;
            if((u32FreqValue < MAX_MANUAL_END_FREQ) && (u32FreqValue > MIN_MANUAL_START_FREQ))
            {
                msAPI_ATV_ChannelInfoEdit_SetPLL(msAPI_Tuner_GetManualScanFreqConvertToPLL(u32FreqValue));
            }
        }
        else
        {
            msAPI_ATV_ChannelInfoEdit_SetPLL(msAPI_Tuner_GetManualScanFreqConvertToPLL(u32FreqValue));
        }
        MApp_ZUI_API_InvalidateAllSuccessors(hwnd);
    }
}

typedef struct _MENU_KEY2BTN_STRUCT
{
    VIRTUAL_KEY_CODE key;
    HWND hwnd;
} MENU_KEY2BTN_STRUCT;

static void _MApp_ZUI_ACT_Menu_SwUpdate_Progress(U8 percent)
{
    U8 u8tmp = 0;
    static const HWND aUpdateWindows[] =
    {
        HWND_MENU_FWUPGRADE_TEXT1,
        HWND_MENU_FWUPGRADE_TEXT2,
        HWND_MENU_FWUPGRADE_PROGRESS_BAR,
        HWND_MENU_FWUPGRADE_PROGRESS_VALUE,
    };
    u8tmp = sizeof(aUpdateWindows)/sizeof(HWND);
    Menu_USB_Upgrade_Percent = percent;
   // MApp_ZUI_CTL_PercentProgressBar_SetPercentage(percent);
    _MApp_ZUI_API_ForceUpdateWindows((HWND*)aUpdateWindows,u8tmp);

    //Updating Need LED Blink ???
    if((percent/2) % 2 == 0)
    {
        LED_RED_ON();
        LED_GREEN_OFF();
    }
    else
    {
        LED_RED_OFF();
        LED_GREEN_ON();
    }

    return;
}


///////////////////////////////////////////////////////////////////////////////
///  private  MApp_ZUI_ACT_HandleMainPageKey
///  [OSD page handler] global key handler for MENU application
///
///  @param [in]       key VIRTUAL_KEY_CODE      key code
///
///  @return BOOLEAN    true for accept, false for ignore
///
///  @author MStarSemi @date 2007/1/25
///////////////////////////////////////////////////////////////////////////////
extern void MApp_CHChange_SetChChgKey (U8 u8Key);
extern void MApp_TV_SetTVKey (U8 u8Key);

BOOLEAN MApp_ZUI_ACT_HandleMainPageKey(VIRTUAL_KEY_CODE key)
{
	//note: this function will be called in running state

    //reset timer if any key
    MApp_ZUI_API_ResetTimer(HWND_MENU_MASK_BACKGROUND, 0);
    MApp_ZUI_API_ResetTimer(HWND_MENU_PICTURE_ADJUST_SUBMENU, 0);

   //only show click animation in page items, not for dialogs...
    if (MApp_ZUI_API_IsSuccessor(HWND_MENU_CHANNEL_PAGE_LIST, MApp_ZUI_API_GetFocus()) ||
        MApp_ZUI_API_IsSuccessor(HWND_MENU_SOUND_PAGE_LIST, MApp_ZUI_API_GetFocus()) ||
        MApp_ZUI_API_IsSuccessor(HWND_MENU_PICTURE_PAGE_LIST, MApp_ZUI_API_GetFocus()) ||
        MApp_ZUI_API_IsSuccessor(HWND_MENU_TIME_PAGE_LIST, MApp_ZUI_API_GetFocus()) ||
        MApp_ZUI_API_IsSuccessor(HWND_MENU_OPTION_TIME_SUBPAGE_LIST, MApp_ZUI_API_GetFocus()) ||
        MApp_ZUI_API_IsSuccessor(HWND_MENU_LOCK_PAGE_LIST, MApp_ZUI_API_GetFocus()) ||
        MApp_ZUI_API_IsSuccessor(HWND_MENU_OPTION_PAGE_LIST, MApp_ZUI_API_GetFocus())
#if (ENABLE_CUS_UI_SPEC == DISABLE) /*Creass.liu at 2012-06-02*/
         ||MApp_ZUI_API_IsSuccessor(HWND_MENU_APP_PAGE_LIST, MApp_ZUI_API_GetFocus()) ||
        #if (ENABLE_PIP)
        (IsPIPSupported() && MApp_ZUI_API_IsSuccessor(HWND_MENU_PIP_PAGE_LIST, MApp_ZUI_API_GetFocus())) ||
        #endif
        MApp_ZUI_API_IsSuccessor(HWND_MENU_PCMODE_PAGE_LIST, MApp_ZUI_API_GetFocus())
#endif
        )
    {
    #if 0
        static  MENU_KEY2BTN_STRUCT _ZUI_TBLSEG _key2btn[] =
        {
            {VK_MENU, HWND_MENU_BOTTOM_HALF_MENU_BG},
            {VK_SELECT, HWND_MENU_BOTTOM_HALF_OK_BG},
            {VK_EXIT, HWND_MENU_BOTTOM_HALF_EXIT_BG},
            {VK_UP, HWND_MENU_BOTTOM_HALF_UP_ARROW},
            {VK_DOWN, HWND_MENU_BOTTOM_HALF_DOWN_ARROW},
            {VK_LEFT, HWND_MENU_BOTTOM_HALF_LEFT_ARROW},
            {VK_RIGHT, HWND_MENU_BOTTOM_HALF_RIGHT_ARROW},
        };
        U8 i;

        for (i = 0; i < COUNTOF(_key2btn); i++)
        {
            if (_key2btn[i].key == key)
            {
                MApp_ZUI_API_SetTimer(_key2btn[i].hwnd, 0, BUTTONANICLICK_PERIOD);
                MApp_ZUI_API_InvalidateWindow(_key2btn[i].hwnd);
                break;
            }
        }
    #endif
    }
    //MENU_DLG_COMMON
    else if(MApp_ZUI_API_IsSuccessor(HWND_MENU_DLG_PASSWORD_PANE0, MApp_ZUI_API_GetFocus()) ||
            MApp_ZUI_API_IsSuccessor(HWND_MENU_DLG_PASSWORD_PANE1, MApp_ZUI_API_GetFocus()) ||
            MApp_ZUI_API_IsSuccessor(HWND_MENU_DLG_PASSWORD_PANE1, MApp_ZUI_API_GetFocus())
            )
    {
        static  MENU_KEY2BTN_STRUCT _ZUI_TBLSEG _PicAdjkey2btn[] =
        {
            {VK_LEFT, HWND_MENU_DLG_COMMON_BTN_OK},
            {VK_RIGHT, HWND_MENU_DLG_COMMON_BTN_CANCEL},
        };
        U8 i;

        for (i = 0; i < COUNTOF(_PicAdjkey2btn); i++)
        {
            if (_PicAdjkey2btn[i].key == key)
            {
                MApp_ZUI_API_SetTimer(_PicAdjkey2btn[i].hwnd, 0, BUTTONANICLICK_PERIOD);
                MApp_ZUI_API_InvalidateWindow(_PicAdjkey2btn[i].hwnd);
                break;
            }
        }
    }
    else if(HWND_MENU_DLG_COMMON_BAR == MApp_ZUI_API_GetFocus())
    {
        static  MENU_KEY2BTN_STRUCT _ZUI_TBLSEG _PicAdjkey2btn[] =
        {
            {VK_LEFT, HWND_MENU_DLG_COMMON_BTN_YES},
            {VK_RIGHT, HWND_MENU_DLG_COMMON_BTN_NO},
        };
        U8 i;

        for (i = 0; i < COUNTOF(_PicAdjkey2btn); i++)
        {
            if (_PicAdjkey2btn[i].key == key)
            {
                MApp_ZUI_API_SetTimer(_PicAdjkey2btn[i].hwnd, 0, BUTTONANICLICK_PERIOD);
                MApp_ZUI_API_InvalidateWindow(_PicAdjkey2btn[i].hwnd);
                break;
            }
        }
    }

    if((key == VK_SELECT) && MApp_ZUI_API_IsSuccessor(HWND_MENU_LOCK_PAGE_LIST_CHANGEPW, MApp_ZUI_API_GetFocus()))
    {
       return TRUE;
    }

    if((key==VK_MENU)||(key==VK_RIGHT)||(key==VK_LEFT)||(key==VK_UP)||(key==VK_DOWN)||(key==VK_BACK)||(key==VK_SELECT))
    {
        //refresh help info
        MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_BOTTOM_HALF_BAR);
        MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_BG_MENUPAGE_INFO);
    }

//////////////////////////////////////////////
    //launch code for factory menu, instart menu, media player(testing)
    #if(UI_SKIN_SEL==UI_SKIN_1366X768X565_HAIER_CN)  // CUS_xm zHIHE 20120807 modify

    if(HWND_MENU_TOP_ICON_PICTURE == MApp_ZUI_API_GetFocus()||HWND_MENU_TOP_ICON_PICTURE_BIG == MApp_ZUI_API_GetFocus())
	#else
    if(HWND_MENU_TOP_ICON_PICTURE == MApp_ZUI_API_GetFocus()
        ||HWND_MENU_TOP_ICON_AUDIO== MApp_ZUI_API_GetFocus()
        ||HWND_MENU_TOP_ICON_SETUP== MApp_ZUI_API_GetFocus()
        ||HWND_MENU_TOP_ICON_LOCK== MApp_ZUI_API_GetFocus()
        ||HWND_MENU_TOP_ICON_CHANNEL == MApp_ZUI_API_GetFocus()
        ||HWND_MENU_LOCK_ENTER_PASSWORD== MApp_ZUI_API_GetFocus()
        ||(0x14 == MApp_ZUI_API_GetFocus())
        ||HWND_MENU_LOCK_PAGE_CHANGEPW == MApp_ZUI_API_GetFocus())
   // if(HWND_MENU_TOP_ICON_PICTURE == MApp_ZUI_API_GetFocus()||HWND_MENU_TOP_ICON_AUDIO==MApp_ZUI_API_GetFocus()||)
	#endif
    {

       // if (VK_UP <= key && key <= VK_NUM_9)
      if ((key==VK_RIGHT)||(key==VK_LEFT)||(key==VK_UP)||(key==VK_DOWN))
        {
          
          
         if(key==VK_LEFT)
         	{
			_u16FacKeys=0x01;  
			printf("VK_LEFT\r\n");
         	}
		 else if (key==VK_UP)
		 	{
				_u16FacKeys = (_u16FacKeys == 0x01) ? (_u16FacKeys|0x02) : 0x00;
				printf("VK_UP\r\n");
		 	}
		 else if (key==VK_RIGHT)
		 	{
		  	      _u16FacKeys = (_u16FacKeys == 0x03) ? (_u16FacKeys|0x04) : 0x00;
				  
				  	printf("VK_RIGHT\r\n");
					//if(_u16FacKeys==0x07)
					//	key=VK_NULL;
		 	}
		  	    
		  else if  (key==VK_DOWN)
		  	{
		  
		  	if (_u16FacKeys == 0x07)
		  	{
				_u16FacKeys=0;
				g_bGotoCUSMenu = 0;
					printf("VK_DOWN\r\n");
				MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_GOTO_FACTORY_MENU);
				return TRUE;
			    }
		  	}
	//ZUI_MSG(printf("_u16FacKeys:=%xl\n",_u16FacKeys););	
	       	printf("MApp_ZUI_API_GetFocus():=0x%lx\n",MApp_ZUI_API_GetFocus()); 
           	printf("_u16FacKeys:=%x\n",_u16FacKeys);
            //_u32LaunchKeys = (_u32LaunchKeys<<4)|(key-VK_UP);
            /*
			ZUI_MSG(printf("_u16LaunchKeys:=%xl\n",_u16LaunchKeys););
			if(_u32LaunchKeys==0x0457||_u32LaunchKeys==)//
				{
				_u32LaunchKeys=0;
				g_bGotoCUSMenu = 0;
				MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_GOTO_FACTORY_MENU);
				return TRUE;
			    }
			    */
        }
#if 0
        else if ( key == VK_CHANNEL_RETURN)
#else
	    else if ( key == VK_ZOOM)
#endif
        {
            switch (_u32LaunchKeys)
            {
                case 0x1999:
                    _u32LaunchKeys=0;
                    g_bGotoCUSMenu = 2;
                    MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_GOTO_FACTORY_MENU);
                    break;
                case 0x2580:
                    _u32LaunchKeys=0;
                    g_bGotoCUSMenu = 0;
                    MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_GOTO_FACTORY_MENU);
                    break;
                case 0x2588:
                    _u32LaunchKeys=0;
                    MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_GOTO_EXPERT_MENU);
                    break;
                // CUS_XM Xue 20120724: show preset channel tabel
                case 0x1997:
                    MApp_ZUI_ACT_ExecuteMainMenuAction(E_OSD_FACTORY_HOTKEY_OPTION);
                    break;

                case 0x456987: //cus_xm: zb add at 2012-7-12 enter csm menu
                {
                #ifdef ENABLE_CUS_FIRMWARE_UPGRADE_FUNCTION
                    #if ( ENABLE_SW_UPGRADE && ENABLE_FILESYSTEM )

                    U8 u8PortEnStatus = 0;

                    #if ENABLE_DMP
                    // for dmp
                    if((UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_DMP)
                #if( ENABLE_DMP_SWITCH )
                          ||(UI_INPUT_SOURCE_DMP1 == UI_INPUT_SOURCE_TYPE)
                          ||(UI_INPUT_SOURCE_DMP2 == UI_INPUT_SOURCE_TYPE)
                        #endif
                      )
                    {
                        if((MApp_MPlayer_IsMediaFileInPlaying()||MApp_MPlayer_QueryCurrentMediaType()==E_MPLAYER_TYPE_TEXT)
                            &&(MApp_DMP_GetDmpFlag()& DMP_FLAG_MEDIA_FILE_PLAYING))
                        {
                            MApp_MPlayer_Stop();
                            switch(MApp_MPlayer_QueryCurrentMediaType())
                            {
                                case E_MPLAYER_TYPE_MOVIE:
                                    MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_STOP);
                                    break;
                                default:
                                    break;
                            }
                        }
                    }
                    #endif // #if ENABLE_DMP

                    #if ENABLE_DMP_SWITCH
               //     MDrv_USBSetPortSwitch(0x00); // TODO:
                    #if 1//minglin1231
			      MDrv_USBSetPortSwitch(INPUT_USB1_PORT);
				#else
                    MDrv_USBSetPortSwitch(0x01);
					#endif
                    #endif

                    u8PortEnStatus = MDrv_USBGetPortEnableStatus();
                    //MApp_ZUI_API_StoreFocusCheckpoint();

                    if((u8PortEnStatus & BIT0) == BIT0)
                    {
                        MDrv_UsbDeviceConnect();
                        if (!MDrv_UsbDeviceConnect())
                        {
                            MsOS_DelayTask(1000);
                        }

                        if (!MDrv_UsbDeviceConnect())
                        {
                            if((u8PortEnStatus & BIT1) != BIT1)
                            {
                                printf("\r\n [USB1]Device is not detected and Goto CSM menu!!! \n");
                                g_bGotoCUSMenu = 1;
                                MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_GOTO_FACTORY_MENU);
                                return TRUE;
                            }
                        }
                        else
                        {
                            MApp_UsbDownload_Init(BIT0, _MApp_ZUI_ACT_Menu_SwUpdate_Progress);

                            if (MW_UsbDownload_Search())
                            {
                                MApp_ZUI_API_StoreFocusCheckpoint();
                                MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_MENU_GOTO_SW_UPGRADE_CONFIRM);
                                return TRUE;
                            }
                            else //no sw file detected
                            {
                                MS_VE_Output_Ctrl OutputCtrl;

                                // enable VE
                                OutputCtrl.bEnable = ENABLE;

                                msAPI_VE_SetOutputCtrl(&OutputCtrl);

                                // enable DNR buffer
                                MApi_XC_DisableInputSource(FALSE, MAIN_WINDOW);

                                if(!msAPI_AUD_IsAudioMutedByUser())
                                {
                                MW_AUD_SetSoundMute(SOUND_MUTE_ALL, E_MUTE_OFF);
                                }

                                MApp_DMP_SetDMPStat(DMP_STATE_RESET);

                                if((u8PortEnStatus & BIT1) != BIT1)
                                {
                                    printf("\r\n [USB1]File is not detected and Goto CSM menu!!! \n");
                                    g_bGotoCUSMenu = 1;
                                    //              printf("\r\n!!!!!!!g_bGotoCUSMenu");
                                    MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_GOTO_FACTORY_MENU);
                                    return TRUE;
                                }
                            }
                        }
                    }

                    if((u8PortEnStatus & BIT1) == BIT1)
                    {
                        if (!MDrv_UsbDeviceConnect_Port2())
                        {
                            MsOS_DelayTask(1000);
                        }

                        if (!MDrv_UsbDeviceConnect_Port2())
                        {
                            g_bGotoCUSMenu = 1;
                            printf("\r\n [USB2]device is not detected and Goto CSM menu!!! \n");
                            //printf("\r\n!!!!!!!g_bGotoCUSMenu");
                            MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_GOTO_FACTORY_MENU);
                            return TRUE;
                        }
                        else
                        {
                            MApp_UsbDownload_Init(BIT1, _MApp_ZUI_ACT_Menu_SwUpdate_Progress);

                            if (MW_UsbDownload_Search())
                            {
                                MApp_ZUI_API_StoreFocusCheckpoint();
                                MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_MENU_GOTO_SW_UPGRADE_CONFIRM);
                            }
                            else //no sw file detected
                            {
                                {
                                    MS_VE_Output_Ctrl OutputCtrl;
                                    // enable VE
                                    OutputCtrl.bEnable = ENABLE;
                                    msAPI_VE_SetOutputCtrl(&OutputCtrl);
                                    // enable DNR buffer
                                    MApi_XC_DisableInputSource(FALSE, MAIN_WINDOW);
                                    if(!msAPI_AUD_IsAudioMutedByUser())
                                    {
                                        MW_AUD_SetSoundMute(SOUND_MUTE_ALL, E_MUTE_OFF);
                                    }
                                }
                                printf("\r\n [USB2]File is not detected and Goto CSM menu!!! \n");
                                g_bGotoCUSMenu = 1;
                                MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_GOTO_FACTORY_MENU);
                                return TRUE;
                            }
                        }
                    }
                    return TRUE;
                #endif
                #else
                _u32LaunchKeys=0;
                g_bGotoCUSMenu = 1;
                MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_GOTO_FACTORY_MENU);
                break
                #endif
                }

                    break;

#if ENABLE_6M30_3D_PROCESS
    case 0x123654:
    {
    #if ( (ENABLE_USB || ENABLE_USB_2) && ENABLE_FILESYSTEM )
        U8 u8PortEnStatus = 0;

        MDrv_Ursa_USB_Update_SetChipType(SWUpdateForMFC);
        printf("USB MFC SW Update!\n");
        u8PortEnStatus = MDrv_USBGetPortEnableStatus();
        if((u8PortEnStatus & BIT0) == BIT0)
        {
            MApp_UsbDownload_Init(BIT0, NULL);//MApp_ZUI_SwUpdate_ProgressBar);
        }
        else if((u8PortEnStatus & BIT1) == BIT1)
        {
            MApp_UsbDownload_Init(BIT1, NULL);//MApp_ZUI_SwUpdate_ProgressBar);
        }
        else
        {
            MDrv_Ursa_USB_Update_SetChipType(SWUpdateForHK);
            printf("Error> Unknown USB port\n");
            break;
        }

        if(!MW_UsbDownload_Search())
        {
            MDrv_Ursa_USB_Update_SetChipType(SWUpdateForHK);
            break;
        }

        if (MW_UsbDownload_Start())
        {
            msAPI_BLoader_Reboot();
        }
        MDrv_Ursa_USB_Update_SetChipType(SWUpdateForHK);
    #endif
        _u32LaunchKeys=0;
    }
    break;
#endif

                default:
                    _u32LaunchKeys=0;
                    break;
            }
        }
        else
        {
            _u32LaunchKeys=0;
        }
    }

    switch(key)
    {
        case VK_MENU:
            PasswordInput1=PasswordInput2=0;
            g_u8PasswordPosition = 0;
            g_u16Password = 0;
            g_u8PasswordCount = 0;
            MApp_ZUI_ACT_MainPageMenuKey();
            //#if (ENABLE_ATV_VCHIP)
            MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_GOTO_PARENTPAGE);
            //#endif
            return TRUE;
	//zhiqin add to use left key to return current page to parentpage instead of goto subpage action 2012-7-10
    	case VK_LEFT:
    	    switch(MApp_ZUI_API_GetFocus())
    		{
                case HWND_MENU_PC_PICTURE_ADVANCE_PICTURE:
    			case HWND_MENU_PICTURE_ADVANCE_PICTURE:
    			case HWND_MENU_CHANNEL_PAGE2_CHANNEL:
    			case HWND_MENU_CHANNEL_AUTOTUNE:
    			case HWND_MENU_CHANNEL_UPDATE_SCAN:
    			case HWND_MENU_CHANNEL_ATV_MAN_TUNE:
    			case HWND_MENU_CHANNEL_PROGRAM_EDIT:
    			case HWND_MENU_CHANNEL_CLEAN_CH_LIST:
    			case HWND_MENU_OPTION_TIME_SETTING:
    			case HWND_MENU_OPTION_3D_MODE_SETTING:
    			case HWND_MENU_OPTION_FACTORY_RESET:
    			case HWND_MENU_OP_TIME_SUBPAGE_TIME:
    			case HWND_MENU_LOCK_MAINSUBPAGE_ITEM_CHANNELBLOCK:
    			case HWND_MENU_LOCK_MAINSUBPAGE_ITEM_INPUTBLOCK:
    			case HWND_MENU_LOCK_MAINSUBPAGE_ITEM_CHANGEPW:
    			case HWND_MENU_LOCK_MAINSUBPAGE_ITEM_CLEAN_ALL:
			#if CUS_SMC_ENABLE_HOTEL_MODE
				case HWND_MENU_LOCK_MAINSUBPAGE_ITEM_HOTEL:
			#endif
    			case HWND_MENU_PC_PICTURE_PC_ADJUST:
    			case HWND_MENU_PCMODE_ADJUST_AUTO_ADJUST:
			#if CHANNEL_PAGE_HIDE_MTS
				case HWND_MENU_LOCK_ENTER_PASSWORD:
			#endif
    			{
                    MApp_ZUI_ACT_MainPageMenuKey();
                    MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_GOTO_PARENTPAGE);
                    return TRUE;
    			}

    		}
    	return FALSE;

        case VK_EXIT:
            PasswordInput1=PasswordInput2=0;
            g_u8PasswordPosition = 0;
            g_u16Password = 0;
            g_u8PasswordCount = 0;
            MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_CLOSE_CURRENT_OSD);
            return TRUE;
#ifdef ENABLE_BUTTON_LOCK
        case VK_KEY_BUTTON_LOCK:
            if(IsStorageInUse())
            {
                u8KeyCode = KEY_NULL;
                return TRUE;
            }
            else
            {
                PasswordInput1=PasswordInput2=0;
                g_u8PasswordPosition = 0;
                g_u16Password = 0;
                g_u8PasswordCount = 0;
                MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_CLOSE_CURRENT_OSD);
            }
            return TRUE;
#endif
#if CUS_SMC_ENABLE_HOTEL_MODE
				case VK_KEY_SOURCE_KEY_LOCK:
					if(IsStorageInUse())
					{
						u8KeyCode = KEY_NULL;
						return TRUE;
					}
					else
					{
						PasswordInput1=PasswordInput2=0;
						g_u8PasswordPosition = 0;
						g_u16Password = 0;
						g_u8PasswordCount = 0;
						MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_CLOSE_CURRENT_OSD);
					}
					return TRUE;
#endif
        case VK_POWER:
            MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_POWEROFF);
            return TRUE;

        case VK_MTS:
            if(!IsStorageInUse())
            {
                #if ENABLE_DTV
                MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_GOTO_AUDIO_LANG);
                #endif
            }
            return TRUE;

        case VK_INPUT_SOURCE:
            PasswordInput1=PasswordInput2=0;
            g_u8PasswordPosition = 0;
            g_u16Password = 0;
            g_u8PasswordCount = 0;
            MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_SHOW_SOURCE_BANNER);
            return TRUE;

        case VK_CHANNEL_LIST:
            if(!IsStorageInUse())
            {
                MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_GOTO_CHANNEL_LIST);
            }
            return TRUE;

        case VK_CHANNEL_FAV_LIST:
            if(!IsStorageInUse())
            {
                if(MApp_ZUI_API_GetParent(MApp_ZUI_API_GetFocus())==HWND_MENU_PREDIT_LIST_PANE)
					return FALSE;
				
                MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_GOTO_FAVORITE_LIST);
            }
            return TRUE;

        #if ENABLE_DTV
        case VK_EPG:
        {
            #if NORDIG_FUNC //for Nordig Spec v2.0
                U16 u16TotalProNum = msAPI_CM_CountProgram(E_SERVICETYPE_DTV, E_PROGACESS_INCLUDE_VISIBLE_ONLY) + msAPI_CM_CountProgram(E_SERVICETYPE_RADIO, E_PROGACESS_INCLUDE_VISIBLE_ONLY) + msAPI_CM_CountProgram(E_SERVICETYPE_DATA, E_PROGACESS_INCLUDE_VISIBLE_ONLY);
            #else
                U16 u16TotalProNum = msAPI_CM_CountProgram(E_SERVICETYPE_DTV, E_PROGACESS_INCLUDE_VISIBLE_ONLY) + msAPI_CM_CountProgram(E_SERVICETYPE_RADIO, E_PROGACESS_INCLUDE_VISIBLE_ONLY);
            #endif

            if(!IsStorageInUse()
                #if (ENABLE_PIP)
                && !IsPIPEnable()
                #endif
                &&(u16TotalProNum && IsDTVInUse())
                )
            {
                MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_EPG_SHOW_PROGRAMMEGUIDE_TIME_PAGE);
                return TRUE;
            }
            break;
        }
        #endif

        case VK_INFO:
            if(!IsStorageInUse())
            {
                MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_SHOW_BRIEF_CH_INFO);
            }
            return TRUE;

#ifdef NETWORK_CONFIG
          case VK_RED:
            if((MApp_ZUI_API_GetFocus() == HWND_MENU_OPTIONLIST_ITEM1)||
                (MApp_ZUI_API_GetFocus() == HWND_MENU_OPTIONLIST_ITEM2)||
                (MApp_ZUI_API_GetFocus() == HWND_MENU_OPTIONLIST_ITEM3)||
                (MApp_ZUI_API_GetFocus() == HWND_MENU_OPTIONLIST_ITEM4)||
                (MApp_ZUI_API_GetFocus() == HWND_MENU_OPTIONLIST_ITEM5))
            {
                MApp_Check_Network(HW_STATUS);
                MApp_Check_Network(INTRANET_STATUS);
                MApp_Check_Network(INTERNET_STATUS);
                MApp_Check_Network(DNS_STATUS);
                MApp_ZUI_API_ShowWindow(HWND_MENU_CHECK_NETWORK, SW_SHOW);//must
             }
           return TRUE;
#endif

#if 1//(ENABLE_ATV_VCHIP)
        case VK_NUM_0:
        case VK_NUM_1:
        case VK_NUM_2:
        case VK_NUM_3:
        case VK_NUM_4:
        case VK_NUM_5:
        case VK_NUM_6:
        case VK_NUM_7:
        case VK_NUM_8:
        case VK_NUM_9:
            _MApp_ZUI_ACT_PasswordHandler(key);
            _MApp_ZUI_ACT_MainpageNumKeyHandler(key);
            return TRUE;
#endif

        case VK_CHANNEL_MINUS:
        case VK_CHANNEL_PLUS:
            if(IsATVInUse())
            {
                if(MApp_ZUI_API_IsSuccessor(HWND_MENU_PREDIT_LIST_PANE,MApp_ZUI_API_GetFocus()))
                    break;
                MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_MENU_CH_CHANGE);
                if(key==VK_CHANNEL_MINUS)
                    MApp_CHChange_SetChChgKey(KEY_CHANNEL_MINUS);
                else if(key==VK_CHANNEL_PLUS)
                    MApp_CHChange_SetChChgKey(KEY_CHANNEL_PLUS);
                return TRUE;
            }
            break;
            case VK_VOLUME_MINUS:
            case VK_VOLUME_PLUS:
                    MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_CLOSE_CURRENT_OSD);
                    if(key==VK_VOLUME_MINUS)
                        MApp_TV_SetTVKey(KEY_VOLUME_MINUS);
                    else if(key==VK_VOLUME_PLUS)
                        MApp_TV_SetTVKey(KEY_VOLUME_PLUS);
                    return TRUE;
                break;

        case VK_TV:
        case VK_AV:
        case VK_HDMI:
        case VK_PC:
        case VK_COMPONENT:
        case VK_DMP:
            switch(key)
            {
                case VK_TV:
                MApp_TV_SetTVKey(KEY_TV);
                break;
                case VK_AV:
                MApp_TV_SetTVKey(KEY_AV);
                break;
                case VK_HDMI:
                MApp_TV_SetTVKey(KEY_HDMI);
                break;
                case VK_PC:
                MApp_TV_SetTVKey(KEY_PC);
                break;
                case VK_COMPONENT:
                MApp_TV_SetTVKey(KEY_COMPONENT);
                break;
                case VK_DMP:
                MApp_TV_SetTVKey(KEY_DMP);
                break;
                default:
                    break;
            }
            MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_CLOSE_CURRENT_OSD);
            break;

        default:
            break;
    }


    return FALSE;
}


#ifdef NETWORK_CONFIG
BOOLEAN MApp_Network_Config(void)
{
                 if(stGenSetting.g_SysSetting.g_Network.Net_Config_mode == EN_NET_DHCP )
                {
                // dhcp
                    printf("dhcp\n");
                    system("ifconfig eth0 up");
                    FILE *pFile;
                    pFile = popen("ps | grep udhcpc","r");
                    char temp[256];
                    BOOLEAN IsUdhcpcExist = FALSE;

                    while(fgets(temp,256,pFile))
                    {
                        temp[255] = 0;

                        if(strstr(temp,"udhcpc") &&
                        !strstr(temp,"grep"))
                        {
                            IsUdhcpcExist = TRUE;
                            break;
                        }

                    }
                    pclose(pFile);
                    if(!IsUdhcpcExist)
                    {
                       // system("udhcpc");
                       popen("udhcpc","r");

                    }

                }
                else if (stGenSetting.g_SysSetting.g_Network.Net_Config_mode == EN_NET_STATIC)
                {
                // static
                    printf("static\n");
                    system("ifconfig eth0 up");
                    {
                        FILE *pFile;
                        pFile = popen("ps | grep udhcpc","r");
                        char temp[256];
                        while(fgets(temp,256,pFile))
                        {
                            temp[255] = 0;
                            // find udhcpc process and kill....
                            if(strstr(temp,"udhcpc") &&
                            !strstr(temp,"grep"))
                            {
                                U32 i;
                                for( i = 0; i < strlen(temp);i++)
                                {
                                    if(temp[i]>=48 && temp[i]<=57) // check is DIGIT
                                    {
                                        char kill_cmd[32];
                                        snprintf(kill_cmd, 32,"kill -9 %d",atoi( &temp[i]));
                                        printf("%s\n",kill_cmd);
                                        system(kill_cmd);
                                        break;
                                    }
                                }
                            }
                        }
                        pclose(pFile);
                    }
                    // Net IP settings
                    {
                        char ipaddr[16];
                        ipaddr[15] = 0;
                        snprintf(ipaddr,15,"%d.%d.%d.%d",
                        stGenSetting.g_SysSetting.g_Network.g_NetIP.u8Net_Addr_Class_A,
                        stGenSetting.g_SysSetting.g_Network.g_NetIP.u8Net_Addr_Class_B,
                        stGenSetting.g_SysSetting.g_Network.g_NetIP.u8Net_Addr_Class_C,
                        stGenSetting.g_SysSetting.g_Network.g_NetIP.u8Net_Addr_Class_D
                        );

                        char strCommand[128];
                        snprintf(strCommand, COUNTOF(strCommand),
                            "ifconfig eth0 %s",
                            ipaddr);
                        system(strCommand);
                        printf("Static IP = %s\n", ipaddr);
                    }
                    // Net Mask settings
                    {
                        char ipaddr[16];
                        ipaddr[15] = 0;
                        snprintf(ipaddr,15,"%d.%d.%d.%d",
                        stGenSetting.g_SysSetting.g_Network.g_NetNetmask.u8Net_Addr_Class_A,
                        stGenSetting.g_SysSetting.g_Network.g_NetNetmask.u8Net_Addr_Class_B,
                        stGenSetting.g_SysSetting.g_Network.g_NetNetmask.u8Net_Addr_Class_C,
                        stGenSetting.g_SysSetting.g_Network.g_NetNetmask.u8Net_Addr_Class_D
                        );

                        char strCommand[128];
                        snprintf(strCommand, COUNTOF(strCommand),
                            "ifconfig eth0 netmask %s",
                            ipaddr);
                        system(strCommand);
                        printf("mask = %s\n", ipaddr);
                    }

                    // Gateway settings
                    {
                        char ipaddr[16];
                        ipaddr[15] = 0;
                        snprintf(ipaddr,15,"%d.%d.%d.%d",
                        stGenSetting.g_SysSetting.g_Network.g_NetGateway.u8Net_Addr_Class_A,
                        stGenSetting.g_SysSetting.g_Network.g_NetGateway.u8Net_Addr_Class_B,
                        stGenSetting.g_SysSetting.g_Network.g_NetGateway.u8Net_Addr_Class_C,
                        stGenSetting.g_SysSetting.g_Network.g_NetGateway.u8Net_Addr_Class_D
                        );

                        char strCommand[128];
                        snprintf(strCommand, COUNTOF(strCommand),
                            "route add default gw  %s",
                            ipaddr);
                        system(strCommand);
                        printf("gw = %s\n", ipaddr);
                    }

                    // DNS settings
                    {
                        char ipaddr[16];
                        ipaddr[15] = 0;
                        FILE *pFile;
                        // TODO: search the old nameserver in resolve.conf
                        pFile = fopen("/etc/resolv.conf","r");
                        if(pFile == NULL)
                        {
                            printf("open /etc/resolv.conf fail");
                            return true;
                        }
                        snprintf(ipaddr,15,"%d.%d.%d.%d",
                        stGenSetting.g_SysSetting.g_Network.g_NetDNS.u8Net_Addr_Class_A,
                        stGenSetting.g_SysSetting.g_Network.g_NetDNS.u8Net_Addr_Class_B,
                        stGenSetting.g_SysSetting.g_Network.g_NetDNS.u8Net_Addr_Class_C,
                        stGenSetting.g_SysSetting.g_Network.g_NetDNS.u8Net_Addr_Class_D
                        );
                        // search in /etc/resolv.conf if there exists the same nameserver already
                        char strCommand1[128];
                        snprintf(strCommand1, COUNTOF(strCommand1),"nameserver %s",ipaddr);
                        BOOLEAN DNS1exist = FALSE;

                        char strtemp[128];
                        while( fgets(strtemp,128,pFile) )
                        {
                            strtemp[127] = 0;
                            if ( strstr(strtemp,strCommand1) )
                            {
                                DNS1exist = TRUE;
                                break;
                            }
                        }
                        fclose(pFile);
                        pFile = NULL;
                        if( ! DNS1exist)
                        {
                            pFile = fopen("/etc/resolv.conf","a");
                            if(pFile == NULL)
                            {
                                printf("open /etc/resolv.conf fail");
                                return true;
                            }
                            if (fputs(strCommand1,pFile) == EOF)
                            {
                                printf("write /etc/resolv.conf fail");
                                fclose(pFile);
                                return true;
                            }
                            fputc('\n',pFile);
                            fclose(pFile);
                            pFile = NULL;
                        }
                    }
                }
                else
                {
                    system("ifconfig eth0 down");
                }

return true;
}


BOOLEAN MApp_UDHCPC_Reset(void)
{
    // dhcp

    system( "killall udhcpc" );
    printf("\n>>>>>>>restart dhcp\n");
    system( "udhcpc &" );

    return true;
}

BOOLEAN MApp_Check_IP_Status(void)
{
    bNetworkIPStatus=false;
    FILE *pFile;
    char  buf[1024];
     memset( buf, '\0', sizeof(buf) );
    system( "ifconfig eth0 >ifconfig.log" );
    pFile= popen("cat ifconfig.log","r");
    while(fgets(buf,20,pFile))
    {
         if(strstr(buf,"inet addr"))
         {
             bNetworkIPStatus=true;
             printf("\n >>>>>>>>IP Pass\n");
             pclose( pFile);
             return true;

         }
         else
         {
            printf("\n >>>>>>>>IP Fail\n");
         }
    }
    pclose( pFile);

    return false;
}

BOOLEAN MApp_Check_Network(eNetwork_Mode eMode)
{
    printf("====================================\n");
    FILE *stream=NULL;
    FILE *wstream=NULL;
    FILE *pFile=NULL;
    char  buf[1024],temp[1024];
    memset( buf, '\0', sizeof(buf) ); //??§K¶?½X
    memset( temp, '\0', sizeof(buf) ); //??§K¶?½X

    switch(eMode)
    {
        case HW_STATUS:
            printf("Test Network Network:\n");
            bNetworkHWStatus=false;
            bNetworkHWStatus = MAdp_Detect_Eth0_NetworkCable_State();
            if(bNetworkHWStatus==true )
            {
                printf(">>>>>>>>>>>>>Network Hardware : OK\n");

                MApp_Check_IP_Status();
                if(bNetworkIPStatus==true)
                {
                    printf(">>>>>>>>>>>>>IP get success!\n");
                }
                else
                {
                    printf(">>>>>>>>>>>>>IP get failed!\n\n");
                    printf(">>>>>>>>>>>>>Reset UDHCPC\n");
                    MApp_UDHCPC_Reset();
                    printf(">>>>>>>>>>>>>waiting for get IP.....\n");
                    MsOS_DelayTask(10000);
                    printf("\n\n>>>>>>>>>>>>>waiting Over\n");
                    printf(">>>>>>>>>>>>>Check the IP Status\n");
                    MApp_Check_IP_Status();
                    if(bNetworkIPStatus==true)
                    {
                        printf(">>>>>>>>>>>>>IP get still success!\n");
                    }
                    else
                        printf(">>>>>>>>>>>>>IP get still failed!\n");
                }
            }
            else
            {
                printf(">>>>>>>>>>>>>Network Hardware : fail\n");
            }
            return TRUE;
            break;
        case INTRANET_STATUS:
            bNetworkIntranetStatus=false;
            printf("Test Intranet:\n");
            if((MAdp_Detect_Eth0_NetworkCable_State()==true)&&(bNetworkIPStatus==true))
            {
                stream = popen( "ping -c 3 172.16.90.254", "r" );  //gateway
            wstream = fopen( "Network_Intranet.log", "w+"); //write to file
            }
            break;
        case INTERNET_STATUS:
            bNetworkInternetStatus=false;
            printf("Test Internet:\n");
            if((MAdp_Detect_Eth0_NetworkCable_State()==true)&&(bNetworkIPStatus==true))
            {
            stream = popen( "ping -c 3 203.84.202.164", "r" ); //203.84.202.164 => YAHOO
            wstream = fopen( "Network_Internet.log", "w+"); //write to file
            }
            break;
        case DNS_STATUS:
            bNetworkDNSStatus=false;
            printf("Test DNS:\n");
            if((MAdp_Detect_Eth0_NetworkCable_State()==true)&&(bNetworkIPStatus==true))
            {
            stream = popen( "ping -c 3 www.mstarsemi.com", "r" );
            wstream = fopen( "Network_DNS.log", "w+"); //write to file
            }
            break;
        default:
            return FALSE;
            break;
    }

    if((MAdp_Detect_Eth0_NetworkCable_State()==true)&&(bNetworkIPStatus==true)&&((eMode == INTRANET_STATUS)||(eMode == INTERNET_STATUS)||(eMode == DNS_STATUS)))
    {
        fread( temp, sizeof(char), sizeof(temp),  stream);
        fwrite( temp, 1, sizeof(temp), wstream );
        pclose( stream );
        fclose( wstream );

        //find the Network key word
        switch(eMode)
        {
            case HW_STATUS:
                break;
            case INTRANET_STATUS:
                pFile= popen("cat Network_Intranet.log","r");
                break;
            case INTERNET_STATUS:
                pFile= popen("cat Network_Internet.log","r");
                break;
            case DNS_STATUS:
                pFile= popen("cat Network_DNS.log","r");
                break;
            default:
                break;
        }

        while(fgets(buf,20,pFile))
        {
            if(strstr(buf,"0%"))
            {
                switch(eMode)
                {
                    case HW_STATUS:
                        break;
                    case INTRANET_STATUS:
                         bNetworkIntranetStatus = true;
                         break;
                    case INTERNET_STATUS:
                         bNetworkInternetStatus = true;
                         break;
                    case DNS_STATUS:
                         bNetworkDNSStatus = true;
                         break;
                    default:
                        break;
                }
            }
            if(strstr(buf,"100%")) //Define 100% packet lost => network failed.
            {
                switch(eMode)
                {
                    case HW_STATUS:
                        break;
                    case INTRANET_STATUS:
                         bNetworkIntranetStatus = false;
                         break;
                    case INTERNET_STATUS:
                         bNetworkInternetStatus = false;
                         break;
                    case DNS_STATUS:
                         bNetworkDNSStatus = false;
                         break;
                    default:
                        break;
                }
                break;
            }
        }
        pclose( pFile);

        switch(eMode)
        {
            case HW_STATUS:
                break;
            case INTRANET_STATUS:
                if(bNetworkIntranetStatus)
                     printf(">>>>>>>>>>>>>Intranet : OK\n");
                else
                     printf(">>>>>>>>>>>>>Intranet : fail\n");
                break;
            case INTERNET_STATUS:
                if(bNetworkInternetStatus)
                     printf(">>>>>>>>>>>>>Internet : OK\n");
                else
                     printf(">>>>>>>>>>>>>Internet : fail\n");
                break;
            case DNS_STATUS:
                if(bNetworkDNSStatus)
                     printf(">>>>>>>>>>>>>DNS : OK\n");
                else
                     printf(">>>>>>>>>>>>>DNS : fail\n");
                break;
            default:
                break;
        }
         return TRUE;
    }
#if 1
    else if(MAdp_Detect_Eth0_NetworkCable_State()==false||bNetworkIPStatus==false)
    {
        switch(eMode)
        {
            case HW_STATUS:
                break;
            case INTRANET_STATUS:
                     printf(">>>>>>>>>>>>>Intranet : fail\n");
                break;
            case INTERNET_STATUS:
                     printf(">>>>>>>>>>>>>Internet :fail\n");
                break;
            case DNS_STATUS:
                     printf(">>>>>>>>>>>>>DNS : fail\n");
                break;
            default:
                break;
         }
    }
#endif

    return FALSE;
}
#endif
///////////////////////////////////////////////////////////////////////////////
///  private  MApp_ZUI_ACT_TerminateMainMenu
///  [OSD page handler] terminate MENU application
///
///  @return no return value
///
///  @author MStarSemi @date 2007/1/25
///////////////////////////////////////////////////////////////////////////////
void MApp_ZUI_ACT_TerminateMainMenu(void)
{
    ZUI_MSG(printf("[]term:enMainMenuState=%u, _enTargetMenuState=%u\n", enMainMenuState, _enTargetMenuState);)

    // Check valid?
#if ( ENABLE_DMP )
    if( (STATE_MENU_GOTO_DMP == _enTargetMenuState)&&(!IsStorageInUse()) )
    {
        MS_DEBUG_MSG(printf("!!Error at %u:%s\n", __LINE__, __FILE__));
        enMainMenuState = STATE_MENU_INIT;
    }
    else
#endif
    {
        enMainMenuState = _enTargetMenuState;
    }
    msAPI_Tuner_SetAFTNeeded(TRUE);

}

void _MApp_ZUI_ACT_OpenCommonDialog(COMMON_DLG_MODE dlg)
{
    //note: please set previous focus and target focus before calling this function...
  	MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON, SW_HIDE); //in order to invoke MSG_NOTIFY_SHOW event...
    _eCommonDlgMode = dlg;
    MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON, SW_SHOW);

    switch(dlg)
    {
        case EN_COMMON_DLG_MODE_CHANNEL_INFO_SAVE_CHANGED:
        case EN_COMMON_DLG_MODE_CH_LIST_CLEAN_ALL_CONFIRM:
        case EN_COMMON_DLG_MODE_USB_UPDATE_CONFIRM:
        case EN_COMMON_DLG_MODE_FACTORY_RESET_CONFIRM:
		case EN_COMMON_DLG_MODE_CLEAN_LOCK:
            //a dialog with "yes" and "no" buttons
            MApp_ZUI_API_ShowWindow(HWND_MENU_BACKGROUND, SW_HIDE);
            if((dlg == EN_COMMON_DLG_MODE_USB_UPDATE_CONFIRM) ||(dlg == EN_COMMON_DLG_MODE_CH_LIST_CLEAN_ALL_CONFIRM))
            {
               MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_PAGE, SW_HIDE);
            }
            else if(dlg == EN_COMMON_DLG_MODE_FACTORY_RESET_CONFIRM)
            {
               MApp_ZUI_API_ShowWindow(HWND_MENU_OPTION_PAGE, SW_HIDE);
            }
            else if(dlg == EN_COMMON_DLG_MODE_CHANNEL_INFO_SAVE_CHANGED)
            {
               MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_INFO_PAGE, SW_HIDE);
            }
			else
			{
				MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_SUBPAGE, SW_HIDE);
			}

            MApp_ZUI_API_ShowWindow(HWND_MENU_MASK_BACKGROUND, SW_HIDE);
            #if (ENABLE_CUS_UI_SPEC == FALSE)
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_BG_C_SETPW, SW_HIDE);
            #endif

            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PANE0, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PANE1, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PANE2, SW_HIDE);

            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PRESSED_PANE0, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PRESSED_PANE1, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PRESSED_PANE2, SW_HIDE);

            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_LOADANIMATION, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_LOADANIMATION_BG, SW_HIDE);

            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_BTN_PANE, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_TRANSPARENT_BG, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_BTN_YES, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_BTN_NO, SW_SHOW);
            MApp_ZUI_API_SetFocus(HWND_MENU_DLG_COMMON_BTN_NO);


            break;

        case EN_COMMON_DLG_MODE_DEACTIVATION:
        case EN_COMMON_DLG_MODE_DEACTIVATION_CONFIRM:
            //a dialog with "ok" and "cancel" buttons
            MApp_ZUI_API_ShowWindow(HWND_MENU_OPTION_PAGE, SW_HIDE);

            MApp_ZUI_API_ShowWindow(HWND_MENU_MASK_BACKGROUND, SW_HIDE);
            #if (ENABLE_CUS_UI_SPEC == FALSE)
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_BG_C_SETPW, SW_HIDE);
            #endif

            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PANE0, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PANE1, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PANE2, SW_HIDE);

            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PRESSED_PANE0, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PRESSED_PANE1, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PRESSED_PANE2, SW_HIDE);

            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_LOADANIMATION, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_LOADANIMATION_BG, SW_HIDE);

            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_BTN_PANE, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_TRANSPARENT_BG, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_BTN_YES, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_BTN_CANCEL, SW_SHOW);
            MApp_ZUI_API_SetFocus(HWND_MENU_DLG_COMMON_BAR);
            break;

        case EN_COMMON_DLG_MODE_DIVX:
            //a dialog with "clear" button
            MApp_ZUI_API_ShowWindow(HWND_MENU_OPTION_PAGE, SW_HIDE);

            MApp_ZUI_API_ShowWindow(HWND_MENU_MASK_BACKGROUND, SW_HIDE);
            #if (ENABLE_CUS_UI_SPEC == FALSE)
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_BG_C_SETPW, SW_HIDE);
            #endif

            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PANE0, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PANE1, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PANE2, SW_HIDE);

            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PRESSED_PANE0, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PRESSED_PANE1, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PRESSED_PANE2, SW_HIDE);

            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_LOADANIMATION, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_LOADANIMATION_BG, SW_HIDE);

            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_BTN_PANE, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_TRANSPARENT_BG, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_BTN_OK, SW_SHOW);
            MApp_ZUI_API_SetFocus(HWND_MENU_DLG_COMMON_BAR);
            break;

        case EN_COMMON_DLG_MODE_FACTORY_RESET:
            //a dialog with no button
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PANE0, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PANE1, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PANE2, SW_HIDE);

            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PRESSED_PANE0, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PRESSED_PANE1, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PRESSED_PANE2, SW_HIDE);

            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_BTN_PANE, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_BAR, SW_HIDE);

            #if (ENABLE_CUS_UI_SPEC == FALSE)
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_BG_R, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_BG_C, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_BG_L, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_BG_C_SETPW, SW_HIDE);

            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_NEW_BG_L, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_NEW_BG_C, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_NEW_BG_R, SW_SHOW);
            #endif

            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_LOADANIMATION, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_LOADANIMATION_BG, SW_SHOW);
            break;

        case EN_COMMON_DLG_MODE_WRONG_PASSWORD:
            //a dialog with "ok" button
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PANE0, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PANE1, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_INPUT1_TEXT, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PANE2, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PRESSED_PANE0, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PRESSED_PANE1, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PRESSED_PANE2, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_LOADANIMATION, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_LOADANIMATION_BG, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_BTN_PANE, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_BTN_YES, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_BTN_NO, SW_HIDE);
            MApp_ZUI_API_SetFocus(HWND_MENU_DLG_PASSWORD_INPUT1_1);
            break;

        case EN_COMMON_DLG_MODE_MISMATCH_PASSWORD:
            //a dialog with "ok" button

            #if (ENABLE_CUS_UI_SPEC == FALSE)
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_BG_C, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_BG_C_SETPW, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_BTN_YES, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_BTN_NO, SW_HIDE);
            #endif
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PANE0, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_LOADANIMATION, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_LOADANIMATION_BG, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PRESSED_PANE1, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PRESSED_PANE2, SW_HIDE);

            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PANE1, SW_SHOW);
            MApp_ZUI_API_SetFocus(HWND_MENU_DLG_PASSWORD_INPUT1_1);
            break;

        case EN_COMMON_DLG_MODE_SET_PASSWORD:
            //a dialog with "cancel" button
            MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_PAGE, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_MASK_BACKGROUND, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_TRANSPARENT_BG, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_TEXT1, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_TEXT5, SW_HIDE);
            #if (ENABLE_CUS_UI_SPEC == FALSE)
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_BG_C, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_BG_C_SETPW, SW_SHOW);
            #endif
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PANE0, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PANE1, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PANE2, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PRESSED_PANE0, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PRESSED_PANE1, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PRESSED_PANE2, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_LOADANIMATION, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_LOADANIMATION_BG, SW_HIDE);

            MApp_ZUI_API_EnableWindow(HWND_MENU_DLG_PASSWORD_INPUT0_TEXT, ENABLE);
            MApp_ZUI_API_EnableWindow(HWND_MENU_DLG_PASSWORD_INPUT0_1, ENABLE);
            MApp_ZUI_API_EnableWindow(HWND_MENU_DLG_PASSWORD_INPUT0_2, ENABLE);
            MApp_ZUI_API_EnableWindow(HWND_MENU_DLG_PASSWORD_INPUT0_3, ENABLE);
            MApp_ZUI_API_EnableWindow(HWND_MENU_DLG_PASSWORD_INPUT0_4, ENABLE);
            MApp_ZUI_API_EnableWindow(HWND_MENU_DLG_PASSWORD_INPUT1_TEXT, DISABLE);
            MApp_ZUI_API_EnableWindow(HWND_MENU_DLG_PASSWORD_INPUT1_1, DISABLE);
            MApp_ZUI_API_EnableWindow(HWND_MENU_DLG_PASSWORD_INPUT1_2, DISABLE);
            MApp_ZUI_API_EnableWindow(HWND_MENU_DLG_PASSWORD_INPUT1_3, DISABLE);
            MApp_ZUI_API_EnableWindow(HWND_MENU_DLG_PASSWORD_INPUT1_4, DISABLE);
            MApp_ZUI_API_EnableWindow(HWND_MENU_DLG_PASSWORD_INPUT2_TEXT, DISABLE);
            MApp_ZUI_API_EnableWindow(HWND_MENU_DLG_PASSWORD_INPUT2_1, DISABLE);
            MApp_ZUI_API_EnableWindow(HWND_MENU_DLG_PASSWORD_INPUT2_1, DISABLE);
            MApp_ZUI_API_EnableWindow(HWND_MENU_DLG_PASSWORD_INPUT2_2, DISABLE);
            MApp_ZUI_API_EnableWindow(HWND_MENU_DLG_PASSWORD_INPUT2_3, DISABLE);
            MApp_ZUI_API_EnableWindow(HWND_MENU_DLG_PASSWORD_INPUT2_4, DISABLE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_BTN_PANE, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_BTN_CANCEL, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_BTN_OK, SW_SHOW);
            MApp_ZUI_API_SetFocus(HWND_MENU_DLG_PASSWORD_INPUT0_1);
            PasswordInput0=PasswordInput1=PasswordInput2=0;
            break;

        case EN_COMMON_DLG_MODE_INPUT_PASSWORD:
        case EN_COMMON_DLG_MODE_SCAN_INPUT_PASSWORD:
        case EN_COMMON_DLG_MODE_DTV_TUNING_INPUT_PASSWORD:
        case EN_COMMON_DLG_MODE_ATV_TUNING_INPUT_PASSWORD:
        case EN_COMMON_DLG_MODE_FACTORY_RESET_INPUT_PASSWORD:
        case EN_COMMON_DLG_MODE_ENTER_MENU_LOCK_PAGE_INPUT_PASSWORD:
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_LOADANIMATION, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_LOADANIMATION_BG, SW_HIDE);
            switch(dlg)
            {
                case EN_COMMON_DLG_MODE_SCAN_INPUT_PASSWORD:
                case EN_COMMON_DLG_MODE_DTV_TUNING_INPUT_PASSWORD:
                case EN_COMMON_DLG_MODE_ATV_TUNING_INPUT_PASSWORD:
                    MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_PAGE, SW_HIDE);
                    break;
                case EN_COMMON_DLG_MODE_FACTORY_RESET_INPUT_PASSWORD:
                    MApp_ZUI_API_ShowWindow(HWND_MENU_OPTION_PAGE, SW_HIDE);
                    break;
                case EN_COMMON_DLG_MODE_ENTER_MENU_LOCK_PAGE_INPUT_PASSWORD:
                    MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_PAGE, SW_HIDE);
                    break;
                default:
                    break;
            }

            MApp_ZUI_API_ShowWindow(HWND_MENU_MASK_BACKGROUND, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_TRANSPARENT_BG, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PANE0, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PANE2, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PRESSED_PANE0, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PRESSED_PANE1, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PRESSED_PANE2, SW_HIDE);

            //note: don't show "new" text
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_INPUT1_TEXT, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_BTN_PANE, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_BTN_OK, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_BTN_CANCEL, SW_SHOW);
            MApp_ZUI_API_SetFocus(HWND_MENU_DLG_PASSWORD_INPUT1_1);
            PasswordInput1=PasswordInput2=0;
            break;

        case EN_COMMON_DLG_MODE_USB_NOT_DETECTED:
        case EN_COMMON_DLG_MODE_SW_FILE_NOT_DETECTED:
            MApp_ZUI_API_ShowWindow(HWND_MENU_MASK_BACKGROUND, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_PAGE, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_TRANSPARENT_BG, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PANE0, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PANE1, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PANE2, SW_HIDE);

            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PRESSED_PANE0, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PRESSED_PANE1, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PRESSED_PANE2, SW_HIDE);

            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_LOADANIMATION, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_LOADANIMATION_BG, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_BTN_PANE, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_BAR, SW_HIDE);
            #if (ENABLE_CUS_UI_SPEC == FALSE)
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_BG_R, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_BG_C, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_BG_L, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_BG_C_SETPW, SW_HIDE);

            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_NEW_BG_L, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_NEW_BG_C, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_NEW_BG_R, SW_SHOW);
            #endif

            break;

        case EN_COMMON_DLG_MODE_USB_UPGRADING:
            MApp_ZUI_API_ShowWindow(HWND_MENU_MASK_BACKGROUND, SW_HIDE);
            #if 1//minglin1124
				MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_PAGE, SW_HIDE);
			#endif
            MApp_ZUI_API_ShowWindow(HWND_MENU_TRANSPARENT_BG, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PANE0, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PANE1, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PANE2, SW_HIDE);

            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PRESSED_PANE0, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PRESSED_PANE1, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PRESSED_PANE2, SW_HIDE);

            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_LOADANIMATION, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_LOADANIMATION_BG, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_BTN_PANE, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_BAR, SW_HIDE);

            #if (ENABLE_CUS_UI_SPEC == FALSE)
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_BG_R, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_BG_C, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_BG_L, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_BG_C_SETPW, SW_HIDE);

            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_NEW_BG_L, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_NEW_BG_C, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_NEW_BG_R, SW_SHOW);
            #endif

            break;

        default:
            ZUI_DBG_FAIL(printf("[ZUI]COMDLGOP\n"));
            ABORT();
            break;
    }
}

///////////////////////////////////////////////////////////////////////////////
///  private  MApp_ZUI_ACT_TV_Rating_Disable_BG
///
///  @author MStarSemi @date 2007/1/25
///////////////////////////////////////////////////////////////////////////////
#if (ENABLE_ATV_VCHIP)
void MApp_ZUI_ACT_TV_Rating_Disable_BG(void)
{
     // TV-Y & TV-Y7
     if (stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_Y & VCHIP_TVRATING_ALL)
     {
         MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVY_ALL_BG, FALSE);
         MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVY7_ALL_BG, FALSE);
         MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVY7_FV_BG, FALSE);
     }
     else if (stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_Y7 & VCHIP_TVRATING_ALL)
     {
         MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVY7_ALL_BG, FALSE);
         MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVY7_FV_BG, FALSE);
     }
     else if(stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_Y7 & VCHIP_TVRATING_FV)
     {
         MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVY7_FV_BG, FALSE);
     }

     // TV-G
     if (stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_G & VCHIP_TVRATING_ALL)
     {
         MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVG_ALL_BG, FALSE);
         MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_ALL_BG, FALSE);
         MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_ALL_BG, FALSE);
         MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVMA_ALL_BG, FALSE);
         MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_V_BG, FALSE);
         MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_V_BG, FALSE);
         MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVMA_V_BG, FALSE);
         MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_S_BG, FALSE);
         MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_S_BG, FALSE);
         MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVMA_S_BG, FALSE);
         MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_L_BG, FALSE);
         MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_L_BG, FALSE);
         MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVMA_L_BG, FALSE);
         MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_D_BG, FALSE);
         MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_D_BG, FALSE);
     }
     else
     {
        if (stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_PG & VCHIP_TVRATING_ALL)
        {
            MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_ALL_BG, FALSE);
            MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_ALL_BG, FALSE);
            MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVMA_ALL_BG, FALSE);
            MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_V_BG, FALSE);
            MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_V_BG, FALSE);
            MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVMA_V_BG, FALSE);
            MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_S_BG, FALSE);
            MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_S_BG, FALSE);
            MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVMA_S_BG, FALSE);
            MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_L_BG, FALSE);
            MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_L_BG, FALSE);
            MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVMA_L_BG, FALSE);
            MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_D_BG, FALSE);
            MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_D_BG, FALSE);
        }
        else if(stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_14 & VCHIP_TVRATING_ALL)
        {
            MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_ALL_BG, FALSE);
            MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVMA_ALL_BG, FALSE);
            MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_V_BG, FALSE);
            MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVMA_V_BG, FALSE);
            MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_S_BG, FALSE);
            MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVMA_S_BG, FALSE);
            MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_L_BG, FALSE);
            MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVMA_L_BG, FALSE);
            MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_D_BG, FALSE);
        }
        else if(stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_MA & VCHIP_TVRATING_ALL)
        {
            MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVMA_ALL_BG, FALSE);
            MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVMA_V_BG, FALSE);
            MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVMA_S_BG, FALSE);
            MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVMA_L_BG, FALSE);
        }
     }

     // TVRating V
     if(stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_PG & VCHIP_TVRATING_V)
     {
         MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_V_BG, FALSE);
         MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_V_BG, FALSE);
         MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVMA_V_BG, FALSE);
     }
     else if(stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_14 & VCHIP_TVRATING_V)
     {
         MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_V_BG, FALSE);
         MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVMA_V_BG, FALSE);
     }
     else if(stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_MA & VCHIP_TVRATING_V)
     {
         MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVMA_V_BG, FALSE);
     }

     // TVRating S
     if(stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_PG & VCHIP_TVRATING_S)
     {
         MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_S_BG, FALSE);
         MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_S_BG, FALSE);
         MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVMA_S_BG, FALSE);
     }
     else if(stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_14 & VCHIP_TVRATING_S)
     {
         MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_S_BG, FALSE);
         MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVMA_S_BG, FALSE);
     }
     else if(stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_MA & VCHIP_TVRATING_S)
     {
         MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVMA_S_BG, FALSE);
     }

     // TVRating L
     if(stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_PG & VCHIP_TVRATING_L)
     {
         MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_L_BG, FALSE);
         MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_L_BG, FALSE);
         MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVMA_L_BG, FALSE);
     }
     else if(stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_14 & VCHIP_TVRATING_L)
     {
         MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_L_BG, FALSE);
         MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVMA_L_BG, FALSE);
     }
     else if(stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_14 & VCHIP_TVRATING_D)
     {
         MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_D_BG, FALSE);
     }

     // TVRating D
     if(stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_PG & VCHIP_TVRATING_D)
     {
         MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_D_BG, FALSE);
         MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_D_BG, FALSE);
     }
     else if(stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_MA & VCHIP_TVRATING_L)
     {
         MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVMA_L_BG, FALSE);
     }

}
#endif

extern void _MApp_ZUI_ACT_CheckTimeInfo(void);

#if ENABLE_DRM
BOOLEAN MApp_VDPlayer_CheckAndGenDRMData(void);
BOOLEAN MApp_VDPlayer_Deactivate(void);
#endif
///////////////////////////////////////////////////////////////////////////////
///  private  MApp_ZUI_ACT_ExecuteMainMenuAction
///  [OSD page handler] execute a specific action in MENU application
///
///  @param [in]       act U16      action ID
///
///  @return BOOLEAN     true for accept, false for ignore
///
///  @author MStarSemi @date 2007/1/25
///////////////////////////////////////////////////////////////////////////////
extern BOOLEAN _MApp_ZUI_API_WindowProcOnIdle(void);
BOOLEAN MApp_ZUI_ACT_ExecuteMainMenuAction(U16 act)
{
    HWND hwnd,prev_hwnd;
    #if(UI_SKIN_SEL==UI_SKIN_1366X768X565_HAIER_CN)  // CUS_xm zHIHE 20120807 modify
	static const HWND _ZUI_TBLSEG icon2pageBIG[MAIN_MENU_ICON_NUM][2] =
    {
        { HWND_MENU_TOP_ICON_PICTURE_BIG, HWND_MENU_PICTURE_PAGE},
        { HWND_MENU_TOP_ICON_AUDIO_BIG, HWND_MENU_SOUND_PAGE},
        { HWND_MENU_TOP_ICON_CHANNEL_BIG, HWND_MENU_CHANNEL_PAGE2},
        { HWND_MENU_TOP_ICON_SETUP_BIG, HWND_MENU_OPTION_PAGE},
        { HWND_MENU_TOP_ICON_LOCK_BIG, HWND_MENU_LOCK_PAGE},// FOR TEMP UI
    };
    #else
    static const HWND _ZUI_TBLSEG icon2page[MAIN_MENU_ICON_NUM][2] =
    {
        { HWND_MENU_TOP_ICON_PICTURE, HWND_MENU_PICTURE_PAGE},
        { HWND_MENU_TOP_ICON_AUDIO, HWND_MENU_SOUND_PAGE},
     #if CHANNEL_PAGE_HIDE_MTS
	    { HWND_MENU_TOP_ICON_CHANNEL, HWND_MENU_CHANNEL_PAGE},
	 #else
        { HWND_MENU_TOP_ICON_CHANNEL, HWND_MENU_CHANNEL_PAGE2},
     #endif
        { HWND_MENU_TOP_ICON_SETUP, HWND_MENU_OPTION_PAGE},
        { HWND_MENU_TOP_ICON_LOCK, HWND_MENU_LOCK_PAGE},// FOR TEMP UI
    };
	#endif
    switch(act)
    {
#if CUS_SMC_ENABLE_HOTEL_MODE
       case EN_EXE_ENTER_HOTEL:
		_u32LaunchKeys=0;
		g_bGotoCUSMenu = 3;
		MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_GOTO_FACTORY_MENU);
		return TRUE;
#endif

#if (ENABLE_CUS_UI_SPEC == FALSE) /*Creass.liu at 2012-06-27*/
        case EN_EXE_GOTO_ASPECT_RATIO_PAGE:
            _eCommonSingleMode = EN_COMMON_SINGLELIST_ASPECT_RATIO;
            MApp_ZUI_API_ShowWindow(HWND_MENU_MASK_BACKGROUND, SW_HIDE);
            //MApp_ZUI_API_ShowWindow(HWND_MENU_BACKGROUND, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PICTURE_PAGE, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_TRANSPARENT_BG, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_MENU_SINGLELIST_COMMON_PAGE, SW_SHOW);

            switch(ST_VIDEO.eAspectRatio)
            {
                case EN_AspectRatio_Original:
                    MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM1);
                    break;
                case EN_AspectRatio_4X3:
                    MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM2);
                    break;
                case EN_AspectRatio_16X9:
                    MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM3);
                    break;
                case EN_AspectRatio_Zoom1:
                    MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM5);
                    break;
                case EN_AspectRatio_Zoom2:
                    MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM6);
                    break;
                case EN_AspectRatio_JustScan:
                    MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM7);
                    break;
                case EN_AspectRatio_Panorama:
                    MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM8);
                    break;
      #if VGA_HDMI_YUV_POINT_TO_POINT
                case EN_AspectRatio_point_to_point:
                    MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM9);
                    break;
      #endif
                default:
                    MApp_ZUI_API_SetFocus(HWND_MENU_SINGLELIST_ITEM1);
                    break;
            }
            return 0;

        case EN_EXE_GOTO_NOISE_REDUCTION_PAGE:
            _eCommonSingleMode = EN_COMMON_SINGLELIST_NOISE_REDUCTION;
            MApp_ZUI_API_ShowWindow(HWND_MENU_MASK_BACKGROUND, SW_HIDE);
            //MApp_ZUI_API_ShowWindow(HWND_MENU_BACKGROUND, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PICTURE_PAGE, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_TRANSPARENT_BG, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_MENU_SINGLELIST_COMMON_PAGE, SW_SHOW);
#if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
            switch(ST_PICTURE.eNRMode.eNR)
#else
            switch(ST_VIDEO.eNRMode.eNR)
#endif
            {
                case MS_NR_OFF:
                   MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM1);
                   break;
                case MS_NR_LOW:
                   MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM2);
                   break;
                case MS_NR_MIDDLE:
                   MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM3);
                   break;
                case MS_NR_HIGH:
                   MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM4);
                   break;
#if(_AutoNR_EN_)
                case MS_NR_AUTO:
                   MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM5);
                   break;
                case MS_NR_DEFAULT:
                   MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM6);
                   break;

#else
                case MS_NR_DEFAULT:
                   MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM5);
                   break;
#endif
                default:
                   MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM1);
                   break;
            }
            return 0;

        case EN_EXE_GOTO_SURROUND_SOUND_PAGE:
            _eCommonSingleMode = EN_COMMON_SINGLELIST_SURROUND_SOUND;
            MApp_ZUI_API_ShowWindow(HWND_MENU_MASK_BACKGROUND, SW_HIDE);
            //MApp_ZUI_API_ShowWindow(HWND_MENU_BACKGROUND, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_SOUND_PAGE, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_TRANSPARENT_BG, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_MENU_SINGLELIST_COMMON_PAGE, SW_SHOW);

#if (ENABLE_CUS_SURROUND_FOLLOW_SNDMODE == DISABLE)
                switch(stGenSetting.g_SoundSetting.SurroundSoundMode & SURROUND_SYSTEM_TYPE_MASK)
#else
                switch(stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].SurroundSoundMode & SURROUND_SYSTEM_TYPE_MASK)
#endif
            {
                case SURROUND_SYSTEM_OFF:
                    MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM1);
                   break;
                case SURROUND_SYSTEM_SURROUNDMAX:
                    MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM2);
                   break;
                #if (ENABLE_AUDIO_SURROUND_SRS  == ENABLE )
                case SURROUND_SYSTEM_SRS:
                    MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM3);
                   break;
                #endif
                #if (ENABLE_AUDIO_SURROUND_BBE  == ENABLE )
                case SURROUND_SYSTEM_BBE:
                    MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM4);
                   break;
                #endif
                #if (ENABLE_AUDIO_SURROUND_VDS  == ENABLE )
                case SURROUND_SYSTEM_VDS:
                    MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM5);
                   break;
                #endif
                #if (ENABLE_AUDIO_SURROUND_VSPK == ENABLE )
                case ENABLE_AUDIO_SURROUND_VSPK:
                    MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM6);
                   break;
                #endif
                default:
                    MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM1);
                   break;
            }
            return 0;

        case EN_EXE_GOTO_SLEEP_TIMER_PAGE:
            _eCommonSingleMode = EN_COMMON_SINGLELIST_SLEEP_TIMER;
            MApp_ZUI_API_ShowWindow(HWND_MENU_MASK_BACKGROUND, SW_HIDE);
            //MApp_ZUI_API_ShowWindow(HWND_MENU_BACKGROUND, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_TIME_PAGE, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_TRANSPARENT_BG, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_MENU_SINGLELIST_COMMON_PAGE, SW_SHOW);
            switch(MApp_Sleep_GetCurrentSleepState())
            {
                case STATE_SLEEP_OFF:
                   MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM1);
                   break;
                case STATE_SLEEP_10MIN:
                   MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM2);
                   break;
                case STATE_SLEEP_20MIN:
                   MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM3);
                   break;
                case STATE_SLEEP_30MIN:
                   MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM4);
                   break;
                case STATE_SLEEP_60MIN:
                   MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM5);
                   break;
                case STATE_SLEEP_90MIN:
                   MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM6);
                   break;
                case STATE_SLEEP_120MIN:
                   MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM7);
                   break;
                //case STATE_SLEEP_180MIN:
                //   MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM8);
                //   break;
                //case STATE_SLEEP_240MIN:
                //   MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM9);
                //   break;

                default:
                   MApp_ZUI_API_SetFocus(HWND_MENU_SINGLELIST_ITEM1);
                   break;
            }
            return 0;

        case EN_EXE_GOTO_PARENTAL_GUIDANCE_PAGE:
            _eCommonSingleMode = EN_COMMON_SINGLELIST_PARENTAL_GUIDANCE;
            MApp_ZUI_API_ShowWindow(HWND_MENU_MASK_BACKGROUND, SW_HIDE);
            //MApp_ZUI_API_ShowWindow(HWND_MENU_BACKGROUND, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_PAGE, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_TRANSPARENT_BG, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_MENU_SINGLELIST_COMMON_PAGE, SW_SHOW);
            if (stGenSetting.g_BlockSysSetting.u8ParentalControl <= EN_F4_ParentalControl_Off)
            {
                MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM1);
                return 0;
            }

            switch(stGenSetting.g_BlockSysSetting.u8ParentalControl)
            {
                case 4:
                   MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM2);
                   break;
                case 5:
                   MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM3);
                   break;
                case 6:
                   MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM4);
                   break;
                case 7:
                   MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM5);
                   break;
                case 8:
                   MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM6);
                   break;
                case 9:
                   MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM7);
                   break;
                case 10:
                #if ENABLE_SBTVD_BRAZIL_APP
                   MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM2);
                #else
                   MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM8);
                #endif
                   break;
                case 11:
                   MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM9);
                   break;
                case 12:
                #if ENABLE_SBTVD_BRAZIL_APP
                   MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM3);
                #else
                   MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM10);
                #endif
                   break;
                case 13:
                   MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM11);
                   break;
                case 14:
                #if ENABLE_SBTVD_BRAZIL_APP
                   MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM4);
                #else
                   MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM12);
                #endif
                   break;
                case 15:
                   MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM13);
                   break;
                case 16:
                #if ENABLE_SBTVD_BRAZIL_APP
                   MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM5);
                #else
                   MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM14);
                #endif
                   break;
                case 17:
                   MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM15);
                   break;
                case 18:
                #if ENABLE_SBTVD_BRAZIL_APP
                   MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM6);
                #else
                   MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM16);
                #endif
                   break;

                default:
                   MApp_ZUI_API_SetFocus(HWND_MENU_SINGLELIST_ITEM1);
                   break;
            }
            return 0;
#endif
#if 1//minglin1224
	   //cus_xm:zb modify  at 2012-7-16
		  case EN_EXE_MENU_GOTO_SW_UPGRADE_CONFIRM:

	            MApp_ZUI_API_ShowWindow(HWND_MAINFRAME, SW_HIDE);
	            MApp_ZUI_API_ShowWindow(HWND_MENU_MASK_BACKGROUND, SW_SHOW);
	            MApp_ZUI_API_ShowWindow(HWND_MENU_FWUPGRADE_BG, SW_SHOW);
	            MApp_ZUI_API_SetFocus(HWND_MENU_FWUPGRADE_NO);
	            return TRUE;

        	case EN_EXE_MENU_DO_SW_UPGRADE:
           	 {
                MApp_ZUI_API_KillTimer(HWND_MENU_TRANSPARENT_BG, 0);

                Menu_USB_Upgrade_Percent = 0;

                if(IsSrcTypeATV(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW))||IsSrcTypeDTV(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)))
                {
                    MApp_ChannelChange_DisableChannel(TRUE,MAIN_WINDOW);
                }

            #if ENABLE_DMP
                // for dmp
                if(( UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_DMP)
               #if( ENABLE_DMP_SWITCH )
                     ||(UI_INPUT_SOURCE_DMP1 == UI_INPUT_SOURCE_TYPE)
                     ||(UI_INPUT_SOURCE_DMP2 == UI_INPUT_SOURCE_TYPE)
                  #endif
                 )
                {
                    //MApp_DMP_SetDMPStat(DMP_STATE_GOTO_PREV_SRC);
                    MApp_DMP_Exit();
                }
            #endif // #if ENABLE_DMP

            #if ( ENABLE_SW_UPGRADE && ENABLE_FILESYSTEM )
                    if(!_bOCPFromMem)
                    {
                        msAPI_OCP_LoadAllStringToMem();
                    }

            #if (OBA2!=1)

                _MApp_ZUI_API_WindowProcOnIdle();
                if (MW_UsbDownload_Start())
                {
                    msAPI_BLoader_Reboot();
                }
                else
                {
                    //Screen will Blue & Red flash
                }
            #endif
            #endif
            }
		 return TRUE;
             case EN_EXE_MENU_CANCEL_SW_UPGRADE:
            {
                MS_VE_Output_Ctrl OutputCtrl;
                // enable VE
                OutputCtrl.bEnable = TRUE;
                msAPI_VE_SetOutputCtrl(&OutputCtrl);
                // enable DNR buffer
                MApi_XC_DisableInputSource(FALSE, MAIN_WINDOW);
                MW_AUD_SetSoundMute(SOUND_MUTE_ALL, E_MUTE_OFF);
            }
            MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
            //_enTargetInputSourceState = STATE_INPUTSOURCE_CLEAN_UP;
             return TRUE;

#endif
#if 0 // no used for CUS
        case EN_EXE_EXECUTE_APP:
            {
                S16 s16Index = 0;
                hwnd = MApp_ZUI_API_GetFocus();
                if ( hwnd == HWND_INVALID )
                    return FALSE;
                s16Index = MApp_ZUI_API_GetChildIndex(hwnd);

                MS_DEBUG_MSG(printf("Execute App %d\n", s16Index));
                {
                    if ( s16Index < 0 )
                    {
                        break;
                    }
                #if ENABLE_PVR
                if ( (UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_DTV) )
                {
                    if(MApp_PVR_IsRecording())
                    {
                        MS_DEBUG_MSG(printf("\r\n PVR is recording...."));
                        #if 0
                        //Can add one message page at this place
                        MApp_ZUI_API_ShowWindow(HWND_PVR_APP_CHANGE_CHECK_PANE, SW_SHOW);
                        MApp_ZUI_API_SetFocus(HWND_PVR_APP_CHANGE_CHECK_TXT_2);
                        #endif
                        break;
                    }
                }
                #endif
                MApp_ZUI_ACT_ExecuteInputSourceAction(EN_EXE_SWITCH_INPUTSOURCE);
                MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
                switch(MApp_ZUI_ACT_GetAppItemString(s16Index))
                {
                  #if ENABLE_DMP
                       case en_str_DMP:
                            MS_DEBUG_MSG(printf("APP [DMP]\n"));
                                _enTargetMenuState = STATE_MENU_GOTO_DMP;
                                MDrv_USBSetPortAutoSwitchStatus(1);
                                MApp_OSDPage_SetOSDPage(E_OSD_DMP);
                                break;
                  #endif
                  #ifdef ENABLE_BT
                       case en_str_BT:
                                _enTargetMenuState = STATE_MENU_GOTO_BT;
                                break;
                  #endif
                  #ifdef ENABLE_YOUTUBE
                       case en_str_YOUTUBE:
                                _enTargetMenuState = STATE_MENU_GOTO_YOUTUBE;
                                break;
                  #endif
                  #ifdef ENABLE_RSS
                       case en_str_RSS:
                                _enTargetMenuState = STATE_MENU_GOTO_RSS;
                                break;
                  #endif
           //       #ifdef ENABLE_NETFLIX
           //            case en_str_Netflix:
           //                     _enTargetMenuState = STATE_MENU_GOTO_NETFLIX;
           //                     break;
           //       #endif
                       case en_str_GYM:
                                break;
                  #ifdef ENABLE_KTV
                       case en_str_KTV:
                                _enTargetMenuState = STATE_MENU_GOTO_KTV;
                                break;
                  #endif
                       case en_str_PLUG_IN:
                                break;
                                #if (ENABLE_GAME)
                       case en_str_Game:
                                _enTargetMenuState = STATE_MENU_GOTO_GAME;
                                break;
                  #endif
                  #ifdef ENABLE_EXTENSION
                       case en_str_EXTENSION:
                                _enTargetMenuState = STATE_MENU_GOTO_EXTENSION;
                                break;
                  #endif
                       default:
                                break;
                }
                }
                #if 0 //enable this if you want to hide main menu
                MApp_ZUI_API_ShowWindow(HWND_MENU_APP_PAGE, SW_HIDE);
                MApp_ZUI_API_ShowWindow(HWND_MENU_BACKGROUND, SW_HIDE);
                MApp_ZUI_API_ShowWindow(HWND_MENU_MASK_BACKGROUND, SW_HIDE);
                MApp_ZUI_API_ShowWindow(HWND_MENU_TRANSPARENT_BG, SW_SHOW);
                #endif
            }
            return TRUE;
#endif
        case EN_EXE_GOTO_MAIN_MENU:
            MApp_ZUI_API_ShowWindow(HWND_MENU_MASK_BACKGROUND, SW_SHOW);
            //MApp_ZUI_API_ShowWindow(HWND_MENU_PAGE_INDICATOR_UP, SW_HIDE);
            //MApp_ZUI_API_SetFocus(HWND_MENU_TOP_ICON_CHANNEL);
            MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_PAGE, SW_SHOW);
            return TRUE;

        case EN_EXE_GOTO_FACTORY_MENU:
            MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
            _enTargetMenuState = STATE_MENU_GOTO_OSDPAGE;
            MApp_OSDPage_SetOSDPage(E_OSD_FACTORY_MENU);
            return TRUE;
		// CUS_XM Xue 20120723: show preset channel table
       case E_OSD_FACTORY_HOTKEY_OPTION:
		MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
		_enTargetMenuState =STATE_MENU_GOTO_OSDPAGE;
		MApp_ZUI_ACT_SetFactoryHotkeyMode(EN_FACTORY_HOTKEY_MODE_FACTORY_RC_PRE_CH);
		MApp_OSDPage_SetOSDPage(E_OSD_FACTORY_HOTKEY_OPTION);
        return TRUE;

		case EN_EXE_GOTO_HOTEL_MENU://goto hotel menu 2012-07-24
			#if CUS_SMC_ENABLE_HOTEL_MODE
				MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
	            _enTargetMenuState = STATE_MENU_GOTO_OSDPAGE;
	            MApp_OSDPage_SetOSDPage(E_OSD_FACTORY_MENU);
			#endif
			return TRUE;

        case EN_EXE_GOTO_BLOCK_PROGRAM:
            #if ENABLE_CUS_UI_SPEC
            MApp_ProgramEdit_SetMode(MODE_PREDIT_BLOCK);
            MApp_ZUI_ACT_Mainpage_AppShowProgramEdit();
            #else
            MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
            MApp_ProgramEdit_SetMode(MODE_PREDIT_BLOCK);
            _enTargetMenuState = STATE_MENU_GOTO_OSDPAGE;
            MApp_OSDPage_SetOSDPage(E_OSD_PROGRAM_EDIT);
            #endif
            return TRUE;

        case EN_EXE_GOTO_PROGRAMEDIT:
            #if ENABLE_CUS_UI_SPEC
            MApp_ProgramEdit_SetMode(MODE_PREDIT_NORMAL);
            MApp_ZUI_ACT_Mainpage_AppShowProgramEdit();
            #else
            MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
            MApp_ProgramEdit_SetMode(MODE_PREDIT_NORMAL);
            _enTargetMenuState = STATE_MENU_GOTO_OSDPAGE;
            MApp_OSDPage_SetOSDPage(E_OSD_PROGRAM_EDIT);
            #endif
            return TRUE;

        case EN_EXE_CLOSE_CURRENT_OSD:
            #if (ENABLE_CUS_UI_SPEC == FALSE)/*Creass.liu at 2012-06-27*/
            if (MApp_ZUI_API_IsSuccessor(HWND_MENU_DLG_TUNE_CONFIRM, MApp_ZUI_API_GetFocus()))
                MApp_ZUI_ACT_ExecuteTuningConfirmDialogAction(EN_EXE_CLOSE_TUNING_CONFIRM);
            else
            #endif
            if (MApp_ZUI_API_IsSuccessor(HWND_MENU_DLG_COMMON, MApp_ZUI_API_GetFocus()))
                MApp_ZUI_ACT_ExecuteMenuCommonDialogAction(EN_EXE_CLOSE_CURRENT_OSD);
            #if 0 // no used for CUS
            else if (MApp_ZUI_API_IsSuccessor(HWND_MENU_TIME_OFFTIME_PAGE, MApp_ZUI_API_GetFocus()))
                MApp_ZUI_ACT_ExecuteSetOffTimeDialogAction(EN_EXE_CLOSE_SET_OFFTIME);
            #endif
            else if (MApp_ZUI_API_IsSuccessor(HWND_MENU_TIME_ONTIME_PAGE, MApp_ZUI_API_GetFocus()))
                MApp_ZUI_ACT_ExecuteSetOnTimeDialogAction(EN_EXE_CLOSE_SET_ONTIME);
#if ENABLE_T_C_COMBO
            else if(MApp_ZUI_API_IsSuccessor(HWND_MENU_DLG_DVB_SELECT_MENU, MApp_ZUI_API_GetFocus()))
                MApp_ZUI_ACT_ExecuteTuningConfirmDialogAction(EN_EXE_CLOSE_DVB_SELECT);
#endif
            else
            {
                MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
                #if ENABLE_DMP
                //printf("%d %d\n",UI_INPUT_SOURCE_TYPE, MApp_DMP_GetDMPStat());
                if(((UI_INPUT_SOURCE_DMP == UI_INPUT_SOURCE_TYPE)
                #if( ENABLE_DMP_SWITCH )
                     ||(UI_INPUT_SOURCE_DMP1 == UI_INPUT_SOURCE_TYPE)
                     ||(UI_INPUT_SOURCE_DMP2 == UI_INPUT_SOURCE_TYPE)
               #endif
                    )
                &&(( MApp_DMP_GetDMPStat() == DMP_STATE_RETURN_FROM_MENU)
                     ||( MApp_DMP_GetDMPStat() == DMP_STATE_GOTO_PREV_SRC)
                     ||( MApp_DMP_GetDMPStat() == DMP_STATE_RESET)))
                {
                    _enTargetMenuState = STATE_MENU_GOTO_DMP;
                }
                else
                #endif
                {
                    #if ENABLE_CUS_UI_SPEC
                    if(IsATVInUse() && (MApp_IsSrcHasSignal(MAIN_WINDOW)))
                    {
                        if(msAPI_ATV_ChannelInfoEdit_GetVideoStandard() != msAPI_ATV_GetVideoStandardOfProgram(msAPI_ATV_GetCurrentProgramNumber()))
                        {
                            AVD_VideoStandardType eVideoStandard;
                            #if (TV_FREQ_SHIFT_CLOCK)
                            msAPI_Tuner_Patch_ResetTVShiftClk();
                            #endif
                            eVideoStandard = msAPI_ATV_GetVideoStandardOfProgram(msAPI_ATV_GetCurrentProgramNumber());

                            if(eVideoStandard == E_VIDEOSTANDARD_AUTO)
                            {
                                AVD_VideoStandardType eStandard;
                                MDrv_AVD_SetVideoStandard(eVideoStandard, FALSE);
                                msAPI_AVD_StartAutoStandardDetection();
                                eStandard = msAPI_AVD_GetStandardDetection();
                            }
                            else
                            {
                                msAPI_AVD_ForceVideoStandard(eVideoStandard);
                                MDrv_AVD_SetVideoStandard(eVideoStandard, FALSE );
                            }
                        }
                    }
                    #endif
                  _enTargetMenuState = STATE_MENU_CLEAN_UP;
                }
            }
            return TRUE;

        case EN_EXE_POWEROFF:
            MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
            _enTargetMenuState = STATE_MENU_GOTO_STANDBY;
            return TRUE;

        case EN_EXE_GOTO_ATV_TUNING_INPUT_PASSWORD_DLG:
            #if (ENABLE_CUS_UI_SPEC == FALSE)
            if(stGenSetting.g_BlockSysSetting.u8BlockSysLockMode==1)
            {
                MApp_ZUI_API_StoreFocusCheckpoint();
                _MApp_ZUI_ACT_OpenCommonDialog(EN_COMMON_DLG_MODE_ATV_TUNING_INPUT_PASSWORD);

            }
            else
            #endif
            {
                MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_GOTO_ATV_TUNING);
            }
            return TRUE;

        case EN_EXE_GOTO_ATV_TUNING:
            #if (ENABLE_CUS_UI_SPEC == FALSE)
            if(stGenSetting.g_BlockSysSetting.u8BlockSysLockMode==1 &&
                _MApp_ZUI_ACT_PasswordConvertToSystemFormat(PasswordInput1) !=
                stGenSetting.g_BlockSysSetting.u16BlockSysPassword)
            {
                // password wrong
                _ePrevCommonDlgMode = EN_COMMON_DLG_MODE_ATV_TUNING_INPUT_PASSWORD;
                _MApp_ZUI_ACT_OpenCommonDialog(EN_COMMON_DLG_MODE_WRONG_PASSWORD);
            }
            else
            #endif
            {
               #if ENABLE_CUS_UI_SPEC
                MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_PAGE, SW_HIDE);
                MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_SCAN_PAGE, SW_SHOW);
                MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_SCAN_PAGE_SCAN_STATE_TEXT, SW_HIDE);
                MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_SCAN_PAGE_SCAN_STATE_VALUE, SW_HIDE);
                MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_SCAN_PAGE_FREQ_TEXT, SW_HIDE);
                MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_SCAN_PAGE_FREQ_VALUE, SW_HIDE);
                MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_SCAN_PAGE_CH_NUM_TEXT, SW_HIDE);
                MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_SCAN_PAGE_CH_NUM_VALUE, SW_HIDE);
                MApp_ZUI_API_SetFocus(HWND_MENU_CHANNEL_SCAN_PAGE_MANUAL_FREQ_BEGIN);
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_BG_MENUPAGE_INFO); //refresh mainmenu page info text
                #if ENABLE_CUS_MANUAL_SCAN
                {
                    U32 u32Freq;
                    U16 u16PLL;
                    u16PLL = msAPI_ATV_GetProgramPLLData(msAPI_ATV_GetCurrentProgramNumber());
		            if(u16PLL>=(UHF_MAX_PLL+10))
                        msAPI_Tuner_SetManualScanStartFreq(MIN_MANUAL_START_FREQ);
			        else
                    {
                        #if TN_FREQ_STEP == FREQ_STEP_62_5KHz
                        u32Freq = ( ( (DWORD)u16PLL*625/10 ));
                        #elif TN_FREQ_STEP == FREQ_STEP_50KHz
                        u32Freq = ( ( (DWORD)u16PLL*50 ));
                        #else
                        u32Freq = ( ( (DWORD)u16PLL*3125/100 ));
                        #endif // TN_FREQ_STEP
                        msAPI_Tuner_SetManualScanStartFreq(u32Freq);
                    }
                    msAPI_Tuner_SetManualScanEndFreq(MAX_MANUAL_END_FREQ);
                }
                #endif
               #else
                MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
               #endif
                _enTargetMenuState = STATE_MENU_GOTO_ATV_MANUALTUNING;
            }
            return TRUE;

	#if DVB_C_ENABLE
        case EN_EXE_GOTO_CADTV_TUNING_INPUT_PASSWORD_DLG:
        case EN_EXE_GOTO_CADTV_TUNING:
#if (ENABLE_T_C_COMBO || DVB_T_C_DIFF_DB)
            if(!IsCATVInUse())
            {
                MApp_ChannelChange_DisableChannel(TRUE,MAIN_WINDOW);
                stGenSetting.stScanMenuSetting.u8DVBCTvConnectionType=EN_DVB_C_TYPE;
                MApp_SaveScanMenuSetting();
                msAPI_Tuner_SwitchSource((EN_DVB_TYPE)stGenSetting.stScanMenuSetting.u8DVBCTvConnectionType, TRUE);
                //stGenSetting.stScanMenuSetting.u8RFChannelNumber=stGenSetting.stScanMenuSetting.u8PreRFChannelNumber=INVALID_IDINDEX;
            #if (!ENABLE_T_C_COMBO)
                msAPI_CM_ResetAllProgram();
            #endif
            }
#endif
      #if ENABLE_T_C_COMBO
            //printf("setCurrenType : DVBC\n");
            MApp_DVBType_SetCurrentType(EN_DVB_C_TYPE);
            MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
             _enTargetMenuState = STATE_MENU_GOTO_CADTV_MANUALTUNING;
             bIsDVBCScan = FALSE;
             break;
      #endif
            MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
             _enTargetMenuState = STATE_MENU_GOTO_CADTV_MANUALTUNING;
            break;
	#endif

        case EN_EXE_GOTO_DTV_TUNING_INPUT_PASSWORD_DLG:
            if(stGenSetting.g_BlockSysSetting.u8BlockSysLockMode==1)
            {
                MApp_ZUI_API_StoreFocusCheckpoint();
                _MApp_ZUI_ACT_OpenCommonDialog(EN_COMMON_DLG_MODE_DTV_TUNING_INPUT_PASSWORD);

            }
            else
            {
                MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_GOTO_DTV_TUNING);
            }
            return TRUE;

#if(ENABLE_PVR ==1)
        case EN_EXE_GOTO_PVR_CHECK_FS:
        #if (ENABLE_UI_3D_PROCESS)
            MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
        #else
            MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_PAGE_EXIT, E_ZUI_STATE_TERMINATE);
        #endif
            _enTargetMenuState = STATE_MENU_GOTO_PVR_CHECK_FS;
            MApp_UiPvr_CheckFS_Initial();
            return TRUE;
#endif

        case EN_EXE_GOTO_DTV_TUNING:
#if (ENABLE_T_C_COMBO || DVB_T_C_DIFF_DB)
            if(IsCATVInUse())
            {
                MApp_ChannelChange_DisableChannel(TRUE,MAIN_WINDOW);
                stGenSetting.stScanMenuSetting.u8DVBCTvConnectionType=EN_DVB_T_TYPE;
                MApp_SaveScanMenuSetting();
                msAPI_Tuner_SwitchSource((EN_DVB_TYPE)stGenSetting.stScanMenuSetting.u8DVBCTvConnectionType, TRUE);
                //stGenSetting.stScanMenuSetting.u8RFChannelNumber=stGenSetting.stScanMenuSetting.u8PreRFChannelNumber=INVALID_IDINDEX;
            #if (!ENABLE_T_C_COMBO)
                msAPI_CM_ResetAllProgram();
            #endif
            }
#endif
        #if ENABLE_T_C_COMBO
            //printf("setCurrenType : DVBT\n");
            MApp_DVBType_SetCurrentType(EN_DVB_T_TYPE);
        #endif
            if(stGenSetting.g_BlockSysSetting.u8BlockSysLockMode==1 &&
                _MApp_ZUI_ACT_PasswordConvertToSystemFormat(PasswordInput1) !=
                stGenSetting.g_BlockSysSetting.u16BlockSysPassword)
            {
                // password wrong
                _ePrevCommonDlgMode = EN_COMMON_DLG_MODE_DTV_TUNING_INPUT_PASSWORD;
                _MApp_ZUI_ACT_OpenCommonDialog(EN_COMMON_DLG_MODE_WRONG_PASSWORD);
            }
            else
            {
                MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
                _enTargetMenuState = STATE_MENU_GOTO_DTV_MANUALTUNING;
            }
            return TRUE;

        case EN_EXE_GOTO_CHANNEL_SIGNAL_INFORMAT:
            {
                #if ENABLE_DTV
                WORD ModulMode;
                #endif

                MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_PAGE, SW_HIDE);
                MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_SIGNAL_INFORMAT, SW_SHOW);
                MApp_ZUI_API_ShowWindow(HWND_MENU_MASK_BACKGROUND, SW_HIDE);
                //MApp_ZUI_API_ShowWindow(HWND_MENU_BACKGROUND, SW_HIDE);
                MApp_ZUI_API_ShowWindow(HWND_MENU_TRANSPARENT_BG, SW_SHOW);
                MApp_ZUI_API_SetFocus(HWND_MENU_DLG_SIGNAL_INFORMAT_TITLE_TXT);

                #if ENABLE_DTV
                if (!msAPI_Tuner_GetSignalModulMode(&ModulMode))
                #endif
                    MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_SIGNAL_INFORMAT_MODULATION, SW_HIDE);
            }
            return TRUE;

        case EN_EXE_UPDATE_SIGNAL_INFORMAT:
            if(IsDTVInUse())
            {
                static U16 u16SignalRedrawlop = 0;

                if(u16SignalRedrawlop)
                {
                    u16SignalRedrawlop--;
                    return TRUE;
                }
                u16SignalRedrawlop = 2000;

                if(MApp_ZUI_API_IsSuccessor(HWND_MENU_DLG_SIGNAL_INFORMAT, MApp_ZUI_API_GetFocus()))
                {
                    MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_DLG_SIGNAL_INFORMAT_NETWORK_NAME);
                    MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_DLG_SIGNAL_INFORMAT_MODULATION_NAME);

                    MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_DLG_SIGNAL_INFORMAT_QUALITY_PERCENT_VAL);
                    MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_DLG_SIGNAL_INFORMAT_STRENGTH_PERCENT_VAL);
                }
            }
            return TRUE;


        case EN_EXE_GOTO_CI_INFORMATION:
#if ENABLE_CI
            _MApp_ZUI_ACT_CheckTimeInfo();
            msAPI_CI_MMIEnterMenu();
            MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
            _enTargetMenuState = STATE_MENU_GOTO_CIMMI;
#endif
            return TRUE;

#if (ENABLE_CUS_UI_SPEC == DISABLE)/*Creass.liu at 2012-06-27*/
        case EN_EXE_GOTO_PICTURE_MODE_PAGE:
            MApp_ZUI_API_ShowWindow(HWND_MENU_PICTURE_PAGE, SW_HIDE);
            //MApp_ZUI_API_ShowWindow(HWND_MENU_BACKGROUND, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_MASK_BACKGROUND, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_TRANSPARENT_BG, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PICTURE_MODE_PAGE, SW_SHOW);
            MApp_ZUI_API_SetFocus(HWND_MENU_PICMODE_PICMODE);
            return TRUE;

        case EN_EXE_RETURN_PICTURE_COLOR_PAGE:
        {
            HWND _hwnd = MApp_ZUI_API_GetFocus();
            MApp_ZUI_API_ShowWindow(HWND_MENU_PICTURE_ADJUST, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PICTURE_COLOR_PAGE, SW_SHOW);
            switch(_hwnd)
            {
                case HWND_MENU_PIC_ADJ_TEMP_RED:
                    MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_PICTURE_COLOR_PAGE_LIST, HWND_MENU_PICCOLOR_COLOR_RED);
                    break;
                case HWND_MENU_PIC_ADJ_TEMP_GREEN:
                    MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_PICTURE_COLOR_PAGE_LIST, HWND_MENU_PICCOLOR_COLOR_GREEN);
                    break;
                case HWND_MENU_PIC_ADJ_TEMP_BLUE:
                    MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_PICTURE_COLOR_PAGE_LIST, HWND_MENU_PICCOLOR_COLOR_BLUE);
                    break;
                default:
                    break;
            }
        }
            return TRUE;

        case EN_EXE_RETURN_PICTURE_MODE_PAGE:
        {
            hwnd = MApp_ZUI_API_GetFocus();
            MApp_ZUI_API_ShowWindow(HWND_MENU_PICTURE_ADJUST, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PICTURE_MODE_PAGE, SW_SHOW);
            switch(hwnd)
            {
                case HWND_MENU_PIC_ADJ_CONTRAST:
                    MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_PICTURE_MODE_PAGE_LIST, HWND_MENU_PICMODE_CONTRAST);
                    break;
                case HWND_MENU_PIC_ADJ_BRIGHTNESS:
                    MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_PICTURE_MODE_PAGE_LIST, HWND_MENU_PICMODE_BRIGHTNESS);
                    break;
                case HWND_MENU_PIC_ADJ_COLOR:
                    MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_PICTURE_MODE_PAGE_LIST, HWND_MENU_PICMODE_COLOR);
                    break;
                case HWND_MENU_PIC_ADJ_SHARPNESS:
                    MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_PICTURE_MODE_PAGE_LIST, HWND_MENU_PICMODE_SHARPNESS);
                    break;
                case HWND_MENU_PIC_ADJ_TINT:
                    MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_PICTURE_MODE_PAGE_LIST, HWND_MENU_PICMODE_TINT);
                    break;
                default:
                    break;
            }
        }
            return TRUE;

        case EN_EXE_GOTO_PICTURE_COLOR_PAGE:
            MApp_ZUI_API_ShowWindow(HWND_MENU_PICTURE_PAGE, SW_HIDE);
            //MApp_ZUI_API_ShowWindow(HWND_MENU_BACKGROUND, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_MASK_BACKGROUND, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_TRANSPARENT_BG, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PICTURE_COLOR_PAGE, SW_SHOW);
            MApp_ZUI_API_SetFocus(HWND_MENU_PICCOLOR_COLOR_TEMP);
            return TRUE;

        case EN_EXE_GOTO_PICTURE_BACKLIGHT_PAGE:
            MApp_ZUI_API_ShowWindow(HWND_MENU_PICTURE_PAGE, SW_HIDE);
            //MApp_ZUI_API_ShowWindow(HWND_MENU_BACKGROUND, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_MASK_BACKGROUND, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_TRANSPARENT_BG, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PICTURE_BACKLIGHT_PAGE, SW_SHOW);
            MApp_ZUI_API_SetFocus(HWND_MENU_PICTURE_BACKLIGHT_ADJUST);
            return TRUE;

        case EN_EXE_GOTO_SOUND_MODE_PAGE:
            MApp_ZUI_API_ShowWindow(HWND_MENU_SOUND_PAGE, SW_HIDE);
            //MApp_ZUI_API_ShowWindow(HWND_MENU_BACKGROUND, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_MASK_BACKGROUND, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_TRANSPARENT_BG, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_MENU_SOUND_MODE_PAGE, SW_SHOW);
            MApp_ZUI_API_SetFocus(HWND_MENU_SNDMODE_SNDMODE);
            return TRUE;

        case EN_EXE_GOTO_SOUND_BALANCE_PAGE:
            MApp_ZUI_API_ShowWindow(HWND_MENU_SOUND_PAGE, SW_HIDE);
            //MApp_ZUI_API_ShowWindow(HWND_MENU_BACKGROUND, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_MASK_BACKGROUND, SW_HIDE);

            MApp_ZUI_API_EnableWindow(HWND_OPTIONLIST_COMMON_UP_ARROW, FALSE);
            MApp_ZUI_API_EnableWindow(HWND_OPTIONLIST_COMMON_DOWN_ARROW, FALSE);

            MApp_ZUI_API_ShowWindow(HWND_MENU_TRANSPARENT_BG, SW_SHOW);
            _eCommonOptionMode = EN_COMMON_OPTIONLIST_SOUND_BALANCE;
            MApp_ZUI_API_ShowWindow(HWND_MENU_OPTIONLIST_COMMON_PAGE, SW_SHOW);
            MApp_ZUI_API_SetFocus(HWND_MENU_OPTIONLIST_ITEM2);
            return TRUE;

        case EN_EXE_GOTO_SOUND_EQ_PAGE:
            MApp_ZUI_API_ShowWindow(HWND_MENU_SOUND_PAGE, SW_HIDE);
            //MApp_ZUI_API_ShowWindow(HWND_MENU_BACKGROUND, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_MASK_BACKGROUND, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_TRANSPARENT_BG, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_MENU_SOUND_EQ_PAGE, SW_SHOW);
            MApp_ZUI_API_SetFocus(HWND_MENU_SNDEQ_120_HZ);
            return TRUE;

	#if  (ATSC_CC == ATV_CC)
	    case EN_EXE_GOTO_OPTION_CC_OPTION_PAGE:
            _eCommonSingleMode = EN_COMMON_SINGLELIST_CC_OPTION;
            MApp_ZUI_API_ShowWindow(HWND_MENU_MASK_BACKGROUND, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_OPTION_PAGE, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_TRANSPARENT_BG, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_MENU_SINGLELIST_COMMON_PAGE, SW_SHOW);
            switch(stGenSetting.g_SysSetting.enATVCaptionType)
            {
                case ATV_CAPTION_TYPE_OFF:
                    MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM1);
                    break;
                case ATV_CAPTION_TYPE_CC1:
                    MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM2);
                    break;
                case ATV_CAPTION_TYPE_CC2:
                    MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM3);
                    break;
                case ATV_CAPTION_TYPE_CC3:
                    MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM4);
                    break;
                case ATV_CAPTION_TYPE_CC4:
                    MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM5);
                    break;
                case ATV_CAPTION_TYPE_TEXT1:
                    MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM6);
                    break;
                case ATV_CAPTION_TYPE_TEXT2:
                    MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM7);
                    break;
                case ATV_CAPTION_TYPE_TEXT3:
                    MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM8);
                    break;
                case ATV_CAPTION_TYPE_TEXT4:
                    MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM9);
                    break;
                default:
                    MApp_ZUI_API_SetFocus(HWND_MENU_SINGLELIST_ITEM1);
                    break;
            }
	        return TRUE;
	#endif // #if  (ATSC_CC == ATV_CC)
    #if ENABLE_3D_PROCESS
        case EN_EXE_GOTO_OPTION_3D_OPTION_PAGE:
            _eCommonSingleMode = EN_COMMON_SINGLELIST_3D_OPTION;
            MApp_ZUI_API_ShowWindow(HWND_MENU_MASK_BACKGROUND, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_OPTION_PAGE, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_TRANSPARENT_BG, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_MENU_SINGLELIST_COMMON_PAGE, SW_SHOW);
            switch(ST_3D_TYPE)
            {
                case EN_3D_BYPASS:
                    MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM1);
                    break;
                case EN_3D_FRAME_PARKING:
                    MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM2);
                    break;
                case EN_3D_SIDE_BY_SIDE:
                    MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM3);
                    break;
                case EN_3D_TOP_BOTTOM:
                    MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM4);
                    break;
                case EN_3D_LINE_BY_LINE:
                    MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM5);
                    break;
                case EN_3D_FRAME_ALTERNATIVE:
                    MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM6);
                    break;
                case EN_3D_NORMAL_2D:
                    MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM7);
                    break;
                case EN_3D_3D_TO_2D:
                    MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM8);
                    break;
                default:
                    MApp_ZUI_API_SetFocus(HWND_MENU_SINGLELIST_ITEM1);
                    break;
            }
            return TRUE;
    #endif // #if  ENABLE_3D_PROCESS
        case EN_EXE_GOTO_SOUND_SWITCH_PAGE:
            MApp_ZUI_API_ShowWindow(HWND_MENU_SOUND_PAGE, SW_HIDE);
            //MApp_ZUI_API_ShowWindow(HWND_MENU_BACKGROUND, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_MASK_BACKGROUND, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_TRANSPARENT_BG, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_MENU_SOUND_SWITCH_PAGE, SW_SHOW);
            MApp_ZUI_API_SetFocus(HWND_MENU_SOUND_SWITCH_AD_SWITCH);
            return TRUE;
#endif // endif (ENABLE_CUS_UI_SPEC == DISABLE)

        case EN_EXE_GOTO_PIC_ADJUST_CONTRAST:
            //MApp_ZUI_API_ShowWindow(HWND_MENU_BACKGROUND, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PICTURE_MODE_PAGE, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_MASK_BACKGROUND, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_TRANSPARENT_BG, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PICTURE_ADJUST, SW_SHOW);

            MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_CONTRAST, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_BRIGHTNESS, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_COLOR, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_SHARPNESS, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_TINT, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_TEMP_RED, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_TEMP_GREEN, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_TEMP_BLUE, SW_HIDE);

            MApp_ZUI_API_SetFocus(HWND_MENU_PIC_ADJ_CONTRAST);
            return TRUE;

        case EN_EXE_GOTO_PIC_ADJUST_BRIGHTNESS:
            //MApp_ZUI_API_ShowWindow(HWND_MENU_BACKGROUND, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PICTURE_MODE_PAGE, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_MASK_BACKGROUND, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_TRANSPARENT_BG, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PICTURE_ADJUST, SW_SHOW);

            MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_CONTRAST, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_BRIGHTNESS, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_COLOR, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_SHARPNESS, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_TINT, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_TEMP_RED, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_TEMP_GREEN, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_TEMP_BLUE, SW_HIDE);

            MApp_ZUI_API_SetFocus(HWND_MENU_PIC_ADJ_BRIGHTNESS);
            return TRUE;

        case EN_EXE_GOTO_PIC_ADJUST_COLOR:
            //MApp_ZUI_API_ShowWindow(HWND_MENU_BACKGROUND, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PICTURE_MODE_PAGE, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_MASK_BACKGROUND, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_TRANSPARENT_BG, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PICTURE_ADJUST, SW_SHOW);

            MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_CONTRAST, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_BRIGHTNESS, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_COLOR, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_SHARPNESS, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_TINT, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_TEMP_RED, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_TEMP_GREEN, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_TEMP_BLUE, SW_HIDE);

            MApp_ZUI_API_SetFocus(HWND_MENU_PIC_ADJ_COLOR);
            return TRUE;

        case EN_EXE_GOTO_PIC_ADJUST_SHARPNESS:
            MApp_ZUI_API_ShowWindow(HWND_MENU_PICTURE_MODE_PAGE, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_MASK_BACKGROUND, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_TRANSPARENT_BG, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PICTURE_ADJUST, SW_SHOW);

            MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_CONTRAST, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_BRIGHTNESS, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_COLOR, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_SHARPNESS, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_TINT, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_TEMP_RED, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_TEMP_GREEN, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_TEMP_BLUE, SW_HIDE);

            MApp_ZUI_API_SetFocus(HWND_MENU_PIC_ADJ_SHARPNESS);
            return TRUE;

        case EN_EXE_GOTO_PIC_ADJUST_TINT:
            if(MApp_ZUI_API_GetFocus()==HWND_MENU_PIC_ADJ_SHARPNESS)
            {
                if((IsAVInUse() || IsATVInUse())
                &&((mvideo_vd_get_videosystem()==SIG_NTSC)||(mvideo_vd_get_videosystem()==SIG_NTSC_443)))
                {
                     MApp_ZUI_API_ShowWindow(HWND_MENU_PICTURE_MODE_PAGE, SW_HIDE);
                     MApp_ZUI_API_ShowWindow(HWND_MENU_MASK_BACKGROUND, SW_HIDE);
                     MApp_ZUI_API_ShowWindow(HWND_MENU_TRANSPARENT_BG, SW_SHOW);
                     MApp_ZUI_API_ShowWindow(HWND_MENU_PICTURE_ADJUST, SW_SHOW);

                     MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_CONTRAST, SW_HIDE);
                     MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_BRIGHTNESS, SW_HIDE);
                     MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_COLOR, SW_HIDE);
                     MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_SHARPNESS, SW_HIDE);
                     MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_TINT, SW_SHOW);
                     MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_TEMP_RED, SW_HIDE);
                     MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_TEMP_GREEN, SW_HIDE);
                     MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_TEMP_BLUE, SW_HIDE);
                     MApp_ZUI_API_SetFocus(HWND_MENU_PIC_ADJ_TINT);
                }
                else  //go to contrast adjust
                {
                    MApp_ZUI_API_ShowWindow(HWND_MENU_PICTURE_MODE_PAGE, SW_HIDE);
                    MApp_ZUI_API_ShowWindow(HWND_MENU_MASK_BACKGROUND, SW_HIDE);
                    MApp_ZUI_API_ShowWindow(HWND_MENU_TRANSPARENT_BG, SW_SHOW);
                    MApp_ZUI_API_ShowWindow(HWND_MENU_PICTURE_ADJUST, SW_SHOW);
                    MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_CONTRAST, SW_SHOW);
                    MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_BRIGHTNESS, SW_HIDE);
                    MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_COLOR, SW_HIDE);
                    MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_SHARPNESS, SW_HIDE);
                    MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_TINT, SW_HIDE);
                    MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_TEMP_RED, SW_HIDE);
                    MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_TEMP_GREEN, SW_HIDE);
                    MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_TEMP_BLUE, SW_HIDE);
                    MApp_ZUI_API_SetFocus(HWND_MENU_PIC_ADJ_CONTRAST);
                }
            }
            else if(MApp_ZUI_API_GetFocus()==HWND_MENU_PIC_ADJ_CONTRAST)
            {
                if((IsAVInUse() || IsATVInUse())
                &&((mvideo_vd_get_videosystem()==SIG_NTSC)||(mvideo_vd_get_videosystem()==SIG_NTSC_443)))
                {
                     MApp_ZUI_API_ShowWindow(HWND_MENU_PICTURE_MODE_PAGE, SW_HIDE);
                     MApp_ZUI_API_ShowWindow(HWND_MENU_MASK_BACKGROUND, SW_HIDE);
                     MApp_ZUI_API_ShowWindow(HWND_MENU_TRANSPARENT_BG, SW_SHOW);
                     MApp_ZUI_API_ShowWindow(HWND_MENU_PICTURE_ADJUST, SW_SHOW);

                     MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_CONTRAST, SW_HIDE);
                     MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_BRIGHTNESS, SW_HIDE);
                     MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_COLOR, SW_HIDE);
                     MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_SHARPNESS, SW_HIDE);
                     MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_TINT, SW_SHOW);
                     MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_TEMP_RED, SW_HIDE);
                     MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_TEMP_GREEN, SW_HIDE);
                     MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_TEMP_BLUE, SW_HIDE);
                     MApp_ZUI_API_SetFocus(HWND_MENU_PIC_ADJ_TINT);
                }
                else //go to sharpness adjust
                {
                   MApp_ZUI_API_ShowWindow(HWND_MENU_PICTURE_MODE_PAGE, SW_HIDE);
                   MApp_ZUI_API_ShowWindow(HWND_MENU_MASK_BACKGROUND, SW_HIDE);
                   MApp_ZUI_API_ShowWindow(HWND_MENU_TRANSPARENT_BG, SW_SHOW);
                   MApp_ZUI_API_ShowWindow(HWND_MENU_PICTURE_ADJUST, SW_SHOW);

                   MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_CONTRAST, SW_HIDE);
                   MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_BRIGHTNESS, SW_HIDE);
                   MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_COLOR, SW_HIDE);
                   MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_SHARPNESS, SW_SHOW);
                   MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_TINT, SW_HIDE);
                   MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_TEMP_RED, SW_HIDE);
                   MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_TEMP_GREEN, SW_HIDE);
                   MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_TEMP_BLUE, SW_HIDE);
                   MApp_ZUI_API_SetFocus(HWND_MENU_PIC_ADJ_SHARPNESS);
                }
            }
	     else
	     {
                if((IsAVInUse() || IsATVInUse())
                &&((mvideo_vd_get_videosystem()==SIG_NTSC)||(mvideo_vd_get_videosystem()==SIG_NTSC_443)))
                {
                     MApp_ZUI_API_ShowWindow(HWND_MENU_PICTURE_MODE_PAGE, SW_HIDE);
                     MApp_ZUI_API_ShowWindow(HWND_MENU_MASK_BACKGROUND, SW_HIDE);
                     MApp_ZUI_API_ShowWindow(HWND_MENU_TRANSPARENT_BG, SW_SHOW);
                     MApp_ZUI_API_ShowWindow(HWND_MENU_PICTURE_ADJUST, SW_SHOW);

                     MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_CONTRAST, SW_HIDE);
                     MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_BRIGHTNESS, SW_HIDE);
                     MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_COLOR, SW_HIDE);
                     MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_SHARPNESS, SW_HIDE);
                     MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_TINT, SW_SHOW);
                     MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_TEMP_RED, SW_HIDE);
                     MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_TEMP_GREEN, SW_HIDE);
                     MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_TEMP_BLUE, SW_HIDE);
                     MApp_ZUI_API_SetFocus(HWND_MENU_PIC_ADJ_TINT);
                }
	     }
            return TRUE;

        case EN_EXE_GOTO_PIC_ADJUST_TEMP_RED:
            MApp_ZUI_API_ShowWindow(HWND_MENU_PICTURE_COLOR_PAGE, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_MASK_BACKGROUND, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_TRANSPARENT_BG, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PICTURE_ADJUST, SW_SHOW);

            MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_CONTRAST, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_BRIGHTNESS, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_COLOR, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_SHARPNESS, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_TINT, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_TEMP_RED, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_TEMP_GREEN, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_TEMP_BLUE, SW_HIDE);

            MApp_ZUI_API_SetFocus(HWND_MENU_PIC_ADJ_TEMP_RED);
            return TRUE;

        case EN_EXE_GOTO_PIC_ADJUST_TEMP_GREEN:
            MApp_ZUI_API_ShowWindow(HWND_MENU_PICTURE_COLOR_PAGE, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_MASK_BACKGROUND, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_TRANSPARENT_BG, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PICTURE_ADJUST, SW_SHOW);

            MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_CONTRAST, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_BRIGHTNESS, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_COLOR, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_SHARPNESS, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_TINT, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_TEMP_RED, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_TEMP_GREEN, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_TEMP_BLUE, SW_HIDE);

            MApp_ZUI_API_SetFocus(HWND_MENU_PIC_ADJ_TEMP_GREEN);
            return TRUE;

        case EN_EXE_GOTO_PIC_ADJUST_TEMP_BLUE:
            MApp_ZUI_API_ShowWindow(HWND_MENU_PICTURE_COLOR_PAGE, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_MASK_BACKGROUND, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_TRANSPARENT_BG, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PICTURE_ADJUST, SW_SHOW);

            MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_CONTRAST, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_BRIGHTNESS, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_COLOR, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_SHARPNESS, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_TINT, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_TEMP_RED, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_TEMP_GREEN, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PIC_ADJ_TEMP_BLUE, SW_SHOW);

            MApp_ZUI_API_SetFocus(HWND_MENU_PIC_ADJ_TEMP_BLUE);
            return TRUE;

        case EN_EXE_GOTO_PC_ADJUST:
            MApp_ZUI_API_ShowWindow(HWND_MENU_PICTURE_PAGE, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_MASK_BACKGROUND, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_TRANSPARENT_BG, SW_SHOW);
          #if (ENABLE_CUS_UI_SPEC == DISABLE)
            MApp_ZUI_API_ShowWindow(HWND_MENU_PCMODE_PAGE, SW_SHOW);
            MApp_ZUI_API_SetFocus(HWND_MENU_PCMODE_AUTO_ADJUST);
          #endif
            return TRUE;

        #if (ENABLE_PIP)
        case EN_EXE_GOTO_PIP:
            if(IsPIPSupported())
            {
                MApp_ZUI_API_ShowWindow(HWND_MENU_PICTURE_PAGE, SW_HIDE);
                MApp_ZUI_API_ShowWindow(HWND_MENU_MASK_BACKGROUND, SW_HIDE);
                MApp_ZUI_API_ShowWindow(HWND_MENU_TRANSPARENT_BG, SW_SHOW);
                MApp_ZUI_API_ShowWindow(HWND_MENU_PIP_PAGE, SW_SHOW);
                MApp_ZUI_API_SetFocus(HWND_MENU_PIP_PIPMODE);
                return TRUE;
            }
            return FALSE;
        #endif

        case EN_EXE_GOTO_AUTO_TUNING:
            {
                //from case MIA_START_SCAN
                MApp_SetOSDCountrySetting(MApp_ZUI_ACT_GetTuningCountry(), TRUE);
                u8ScanAtvChNum = 0;
#if ENABLE_SBTVD_BRAZIL_APP
                u8ScanCATVChNum = 0;
                u8ScanAirTVChNum = 0;
#endif
                u16ScanDtvChNum = 0;
                u16ScanRadioChNum = 0;
#if NORDIG_FUNC //for Nordig Spec v2.0
                u16ScanDataChNum = 0;
#endif
                u8ScanPercentageNum = 0;

#if  ENABLE_SBTVD_BRAZIL_APP
                if( eTuneType == OSD_TUNE_TYPE_AIR_PLUS_CABLE)
#else
                if( eTuneType == OSD_TUNE_TYPE_DTV_ONLY)
#endif
                {
                    MApp_ChannelChange_DisableChannel(TRUE,MAIN_WINDOW);

                    #if (ENABLE_PIP)
                    if(IsPIPEnable())
                    {
                        if(stGenSetting.g_stPipSetting.enPipSoundSrc==EN_PIP_SOUND_SRC_SUB)
                        {
                            stGenSetting.g_stPipSetting.enPipSoundSrc=EN_PIP_SOUND_SRC_MAIN;
                            MApp_InputSource_PIP_ChangeAudioSource(MAIN_WINDOW);
                        }
                        UI_SUB_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_NONE;
                        MApp_InputSource_ChangeInputSource(SUB_WINDOW);
                        stGenSetting.g_stPipSetting.enPipMode = EN_PIP_MODE_OFF;
                        UI_SUB_INPUT_SOURCE_TYPE = MApp_InputSource_GetUIInputSourceType(MApp_InputSource_PIP_Get1stCompatibleSrc(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)));
                    }
                    #endif

#if DVB_C_ENABLE
#if ENABLE_T_C_COMBO
                    if(!IsCATVInUse())
                        UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_DTV;
                    else
                        UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_CADTV;
#else
                    UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_CADTV;
#endif
#else
                    UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_DTV;
#endif

#if  ENABLE_SBTVD_BRAZIL_APP
                    MApp_InputSource_SwitchSource( UI_INPUT_SOURCE_DTV, MAIN_WINDOW );
#else
                    MApp_InputSource_ChangeInputSource(MAIN_WINDOW );
#endif
                    msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_INTERNAL_2_MUTEON, E_AUDIOMUTESOURCE_ACTIVESOURCE);
                }
                else
                {
                    mvideo_vd_set_videosystem(SIG_PAL); //dealut value for DVB
                    msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_INTERNAL_2_MUTEON, E_AUDIOMUTESOURCE_ACTIVESOURCE);
                    //MApp_Scaler_Setting_SetVDScale(EN_AspectRatio_16X9, MAIN_WINDOW);
		      ST_VIDEO.eAspectRatio=EN_AspectRatio_16X9;
          MApp_Scaler_SetWindow(NULL, NULL, NULL,
                MApp_Scaler_GetAspectRatio(ST_VIDEO.eAspectRatio), SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW), MAIN_WINDOW);
                }

            #if ENABLE_T_C_COMBO
            if(IsCATVInUse())
            {
                if(g_enScanType == SCAN_TYPE_AUTO)
                    stGenSetting.stScanMenuSetting.u8ScanType = SCAN_TYPE_AUTO;
                else if(g_enScanType == SCAN_TYPE_NETWORK)
                    stGenSetting.stScanMenuSetting.u8ScanType = SCAN_TYPE_NETWORK;
            }
            else
                stGenSetting.stScanMenuSetting.u8ScanType = SCAN_TYPE_AUTO;
            #else
                stGenSetting.stScanMenuSetting.u8ScanType = SCAN_TYPE_AUTO;
            #endif

            #if ENABLE_CUS_UI_SPEC
               #if ENABLE_CUS_UPDATE_SCAN
                if(MApp_ZUI_API_GetFocus() == HWND_MENU_CHANNEL_UPDATE_SCAN)
                {
                    g_bGotoUpdateScan = TRUE;
                }
                else
                {
                    g_bGotoUpdateScan = FALSE;
                }
               #endif
                MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_PAGE, SW_HIDE);
                MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_SCAN_PAGE, SW_SHOW);
                MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_SCAN_PAGE_MANUAL_LIST, SW_HIDE);
                MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_SCAN_PAGE_TITLE, SW_HIDE);
                MApp_ZUI_API_SetFocus(HWND_MENU_CHANNEL_SCAN_PAGE_PROGRESS_BAR);
                enMainMenuState = STATE_MENU_GOTO_SCAN;
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_BG_MENUPAGE_INFO); //refresh mainmenu page info text
            #else
                MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
            #endif
                _enTargetMenuState = STATE_MENU_GOTO_SCAN;
            }
            return TRUE;

        case EN_EXE_SW_USB_UPDATE:
        {
        #if ( ENABLE_SW_UPGRADE && ENABLE_FILESYSTEM )

            U8 u8PortEnStatus = 0;

            #if ENABLE_DMP
            // for dmp
            if((UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_DMP)
		#if( ENABLE_DMP_SWITCH )
                  ||(UI_INPUT_SOURCE_DMP1 == UI_INPUT_SOURCE_TYPE)
                  ||(UI_INPUT_SOURCE_DMP2 == UI_INPUT_SOURCE_TYPE)
                #endif
              )
            {
                if((MApp_MPlayer_IsMediaFileInPlaying()||MApp_MPlayer_QueryCurrentMediaType()==E_MPLAYER_TYPE_TEXT)
					&&(MApp_DMP_GetDmpFlag()& DMP_FLAG_MEDIA_FILE_PLAYING))
                {
                	MApp_MPlayer_Stop();
                    switch(MApp_MPlayer_QueryCurrentMediaType())
                    {
                        case E_MPLAYER_TYPE_MOVIE:
		                    MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_STOP);
                            break;
                        default:
                            break;
                    }
                }
            }
            #endif // #if ENABLE_DMP

            u8PortEnStatus = MDrv_USBGetPortEnableStatus();
            MApp_ZUI_API_StoreFocusCheckpoint();

            if((u8PortEnStatus & BIT0) == BIT0)
            {
                MDrv_UsbDeviceConnect();
                if (!MDrv_UsbDeviceConnect())
                {
                    MsOS_DelayTask(1000);
                }

                if (!MDrv_UsbDeviceConnect())
                {
                    if((u8PortEnStatus & BIT1) != BIT1)
                    {
                        _MApp_ZUI_ACT_OpenCommonDialog(EN_COMMON_DLG_MODE_USB_NOT_DETECTED);
                        MApp_ZUI_API_SetTimer(HWND_MENU_DLG_COMMON,0,6000);
                        return TRUE;
                    }
                }
                else
                {
                    MApp_UsbDownload_Init(BIT0, MApp_ZUI_SwUpdate_ProgressBar);

                    if (MW_UsbDownload_Search())
                    {
                        MApp_ZUI_API_StoreFocusCheckpoint();
                        _MApp_ZUI_ACT_OpenCommonDialog(EN_COMMON_DLG_MODE_USB_UPDATE_CONFIRM);
                        return TRUE;
                    }
                    else //no sw file detected
                    {
                            MS_VE_Output_Ctrl OutputCtrl;

                            // enable VE
                            OutputCtrl.bEnable = ENABLE;

                            msAPI_VE_SetOutputCtrl(&OutputCtrl);

                            // enable DNR buffer
                            MApi_XC_DisableInputSource(FALSE, MAIN_WINDOW);

							if(!msAPI_AUD_IsAudioMutedByUser())
							{
                            	MW_AUD_SetSoundMute(SOUND_MUTE_ALL, E_MUTE_OFF);
							}

                        MApp_DMP_SetDMPStat(DMP_STATE_RESET);

                        if((u8PortEnStatus & BIT1) != BIT1)
                        {
                            _MApp_ZUI_ACT_OpenCommonDialog(EN_COMMON_DLG_MODE_SW_FILE_NOT_DETECTED);
                            MApp_ZUI_API_SetTimer(HWND_MENU_DLG_COMMON,0,6000);

                            return TRUE;
                        }
                    }
                }
            }

            if((u8PortEnStatus & BIT1) == BIT1)
            {
                if (!MDrv_UsbDeviceConnect_Port2())
                {
                    MsOS_DelayTask(1000);
                }

                if (!MDrv_UsbDeviceConnect_Port2())
                {
                    _MApp_ZUI_ACT_OpenCommonDialog(EN_COMMON_DLG_MODE_USB_NOT_DETECTED);
                    MApp_ZUI_API_SetTimer(HWND_MENU_DLG_COMMON,0,6000);
                }
                else
                {
                    MApp_UsbDownload_Init(BIT1, MApp_ZUI_SwUpdate_ProgressBar);

                    if (MW_UsbDownload_Search())
                    {
                        MApp_ZUI_API_StoreFocusCheckpoint();
                        _MApp_ZUI_ACT_OpenCommonDialog(EN_COMMON_DLG_MODE_USB_UPDATE_CONFIRM);
                    }
                    else //no sw file detected
                    {
                        {
                            MS_VE_Output_Ctrl OutputCtrl;
                            // enable VE
                            OutputCtrl.bEnable = ENABLE;
                            msAPI_VE_SetOutputCtrl(&OutputCtrl);
                            // enable DNR buffer
                            MApi_XC_DisableInputSource(FALSE, MAIN_WINDOW);
							if(!msAPI_AUD_IsAudioMutedByUser())
							{
                            	MW_AUD_SetSoundMute(SOUND_MUTE_ALL, E_MUTE_OFF);
							}
						}
                        _MApp_ZUI_ACT_OpenCommonDialog(EN_COMMON_DLG_MODE_SW_FILE_NOT_DETECTED);
                        MApp_ZUI_API_SetTimer(HWND_MENU_DLG_COMMON,0,6000);
                    }
                }
            }
            return TRUE;
        }
    #endif // #if ( ENABLE_SW_UPGRADE && ENABLE_FILESYSTEM )

  #if BOE_USB_UPGRADE_FACTROY//minglin1206
             case EN_EXE_SW_USB_UPDATE2:
	   printf("dddddddddddddddddddddddddddd\n");		 	
            #if ( ENABLE_SW_UPGRADE && ENABLE_FILESYSTEM )
           // MApp_ZUI_ACT_ExecuteMenuCommonDialogAction(EN_EXE_CLOSE_USB_UPGRADE_CONFIRM_DLG);
             _MApp_ZUI_ACT_OpenCommonDialog(EN_COMMON_DLG_MODE_USB_UPGRADING);
            MApp_ZUI_API_SetTimer(HWND_MENU_DLG_COMMON,0,100);
            return TRUE;
            #endif // #if ( ENABLE_SW_UPGRADE && ENABLE_FILESYSTEM )
            break;
  #endif 
        case EN_EXE_GOTO_DVB_SELECT_INPUT_PASSWORD_DLG:
            MApi_AUTH_Process(Customer_info,Customer_hash);
            if(MDrv_AUTH_IPCheck(IPAUTH_CONTROL_XC_DVBC) == TRUE )
            {
			#if ENABLE_T_C_COMBO
				if(stGenSetting.g_BlockSysSetting.u8BlockSysLockMode==1)
				{
				    MApp_ZUI_API_StoreFocusCheckpoint();
				    _MApp_ZUI_ACT_OpenCommonDialog(EN_COMMON_DLG_MODE_SCAN_INPUT_PASSWORD);
				}
				else
				{
				    MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_GOTO_DVB_SELECT);
				}
			#elif DVB_C_ENABLE
				MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_GOTO_SCAN_INPUT_PASSWORD_DLG);
			#endif
            }
            else
            {
                MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_GOTO_SCAN_INPUT_PASSWORD_DLG);
            }
            return TRUE;


        case EN_EXE_GOTO_SCAN_INPUT_PASSWORD_DLG:
            if(stGenSetting.g_BlockSysSetting.u8BlockSysLockMode==1)
            {
                MApp_ZUI_API_StoreFocusCheckpoint();
                _MApp_ZUI_ACT_OpenCommonDialog(EN_COMMON_DLG_MODE_SCAN_INPUT_PASSWORD);
            }
            else
            {
            #if (ENABLE_ATV_CHINA_APP || ENABLE_SBTVD_BRAZIL_APP)//china will not use country adjust option
                MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_GOTO_AUTO_TUNING);
            #else
              #if ENABLE_T_C_COMBO
                if(MApp_DVBType_GetCurrentType() == EN_DVB_T_TYPE)
                    MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_GOTO_TUNING_CONFIRM);
                else
                    MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_GOTO_DVBC_SCAN_PAGE);
              #else
                MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_GOTO_TUNING_CONFIRM);
              #endif // #if ENABLE_T_C_COMBO
            #endif
            }
            return TRUE;

    #if ENABLE_T_C_COMBO
        case EN_EXE_GOTO_DVB_SELECT:
            //printf("Exe MianMenu::> EN_EXE_GOTO_DVB_SELECT\n");
            _eCommonSingleMode = EN_COMMON_SINGLELIST_DVB_SELECT;
            if(stGenSetting.g_BlockSysSetting.u8BlockSysLockMode==1 &&
                _MApp_ZUI_ACT_PasswordConvertToSystemFormat(PasswordInput1) !=
                stGenSetting.g_BlockSysSetting.u16BlockSysPassword)
            {
                    // password wrong
                    _ePrevCommonDlgMode = EN_COMMON_DLG_MODE_SCAN_INPUT_PASSWORD;
                    _MApp_ZUI_ACT_OpenCommonDialog(EN_COMMON_DLG_MODE_WRONG_PASSWORD);
            }
            else
            {
                MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_PAGE, SW_HIDE);
                MApp_ZUI_API_ShowWindow(HWND_MENU_MASK_BACKGROUND, SW_HIDE);
                MApp_ZUI_API_ShowWindow(HWND_MENU_TRANSPARENT_BG, SW_SHOW);
                MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_DVB_SELECT_MENU, SW_SHOW);
                switch(stGenSetting.stScanMenuSetting.u8DVBCTvConnectionType)
                {
                    case EN_DVB_T_TYPE:
                        MApp_ZUI_API_SetFocus(HWND_SELECTED_DVBT_BG);
                        break;
                    case EN_DVB_C_TYPE:
                        MApp_ZUI_API_SetFocus(HWND_SELECTED_DVBC_BG);
                        break;
                    default:
                        MApp_ZUI_API_SetFocus(HWND_SELECTED_DVBT_BG);
                        break;
                }
            }
            return TRUE;

        case EN_EXE_GOTO_DVBC_SCAN_PAGE :
            //printf("Exe MianMenu::> EN_EXE_GOTO_DVBC_SCAN_PAGE\n");
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_DVB_SELECT_MENU, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_TRANSPARENT_BG, SW_SHOW);
            MApp_ZUI_ACT_ShowDVBCScanPage();
            return TRUE;
    #endif // #if ENABLE_T_C_COMBO

#if (ENABLE_CUS_UI_SPEC == FALSE) /*Creass.liu at 2012-06-27*/
        case EN_EXE_GOTO_TUNING_CONFIRM:
            if(stGenSetting.g_BlockSysSetting.u8BlockSysLockMode==1 &&
                _MApp_ZUI_ACT_PasswordConvertToSystemFormat(PasswordInput1) !=
                stGenSetting.g_BlockSysSetting.u16BlockSysPassword)
            {
                    // password wrong
                    _ePrevCommonDlgMode = EN_COMMON_DLG_MODE_SCAN_INPUT_PASSWORD;
                    _MApp_ZUI_ACT_OpenCommonDialog(EN_COMMON_DLG_MODE_WRONG_PASSWORD);
            }
            else
            {
                MApp_ZUI_ACT_SetTuningCountry(OSD_COUNTRY_SETTING); //initial temp country

            #if ENABLE_T_C_COMBO
                if(MApp_DVBType_GetCurrentType() == EN_DVB_T_TYPE)
                    MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_DVB_SELECT_MENU, SW_HIDE);
            #else
                MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_PAGE, SW_HIDE);
                MApp_ZUI_API_ShowWindow(HWND_MENU_MASK_BACKGROUND, SW_HIDE);
            #endif

                MApp_ZUI_API_ShowWindow(HWND_MENU_TRANSPARENT_BG, SW_SHOW);
                MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_TUNE_CONFIRM, SW_SHOW);
                MApp_ZUI_CTL_Grid_SetIndex(HWND_MENU_DLG_TUNE_CONFIRM_COUNTRY_GRID, MApp_ZUI_ACT_GetTuningCountryIndex, MApp_ZUI_ACT_SetTuningCountryIndex, OSD_COUNTRY_AUSTRALIA, OSD_COUNTRY_NUMS-1);
                MApp_ZUI_CTL_Grid_SetFnGetTextByIndex(HWND_MENU_DLG_TUNE_CONFIRM_COUNTRY_GRID, MApp_ZUI_ACT_GetCountryStringByIndex);

            #if ENABLE_SBTVD_BRAZIL_APP
                MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_TUNE_CONFIRM_COUNTRY_GRID, SW_HIDE);
                MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_TUNE_CONFIRM_TUNE_TYPE, SW_HIDE);
                MApp_ZUI_API_SetFocus(HWND_MENU_DLG_TUNE_CONFIRM);
            #else
                MApp_ZUI_API_SetFocus(HWND_MENU_DLG_TUNE_CONFIRM_TUNE_TYPE);
            #endif

            #if (ENABLE_DTV == 0)
                MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_TUNE_CONFIRM_TUNE_TYPE, SW_HIDE);
                MApp_ZUI_API_SetFocus(HWND_MENU_DLG_TUNE_CONFIRM_COUNTRY_GRID);
            #endif
            }
            return TRUE;
#endif

        case EN_EXE_GOTO_MENU_LOCK_PAGE:
          #if ENABLE_DTV
            if(/*stGenSetting.g_BlockSysSetting.u8BlockSysLockMode==1 &&*/
                _MApp_ZUI_ACT_PasswordConvertToSystemFormat(PasswordInput1) !=
                stGenSetting.g_BlockSysSetting.u16BlockSysPassword)
            {
                    // password wrong
                    _ePrevCommonDlgMode = EN_COMMON_DLG_MODE_ENTER_MENU_LOCK_PAGE_INPUT_PASSWORD;
                    _MApp_ZUI_ACT_OpenCommonDialog(EN_COMMON_DLG_MODE_WRONG_PASSWORD);
            }
            else
            {
                MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_PAGE_DTV, SW_SHOW);
                MApp_ZUI_ACT_ShowMainMenuBackground(HWND_MENU_BOTTOM_BALL_FOCUS_LOCK);
		        MApp_ZUI_API_ShowWindow(HWND_MENU_TRANSPARENT_BG, SW_SHOW);
                MApp_ZUI_API_SetFocus(HWND_MENU_LOCK_SYSTEM);
            }
          #endif // #if ENABLE_DTV
          #if ENABLE_ATV_VCHIP
            if(/*stGenSetting.g_BlockSysSetting.u8BlockSysLockMode==1 &&*/
                _MApp_ZUI_ACT_PasswordConvertToSystemFormat(PasswordInput1) !=
                stGenSetting.g_BlockSysSetting.u16BlockSysPassword)
            {
                    // password wrong
                    _ePrevCommonDlgMode = EN_COMMON_DLG_MODE_ENTER_MENU_LOCK_PAGE_INPUT_PASSWORD;
                    _MApp_ZUI_ACT_OpenCommonDialog(EN_COMMON_DLG_MODE_WRONG_PASSWORD);
            }
            else
            {
                MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_PAGE, SW_SHOW);
                MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_PAGE_CHECKPWD_ERROR_MSG, SW_HIDE);
                MApp_ZUI_ACT_ShowMainMenuBackground(HWND_MENU_BOTTOM_BALL_FOCUS_LOCK);
		        MApp_ZUI_API_ShowWindow(HWND_MENU_TRANSPARENT_BG, SW_SHOW);
                MApp_ZUI_API_SetFocus(HWND_MENU_LOCK_ENTER_PASSWORD);
            }
          #endif // #if ENABLE_ATV_VCHIP
            return TRUE;

#if (ENABLE_CUS_UI_SPEC == FALSE) /*Creass.liu at 2012-06-27*/
        case EN_EXE_GOTO_SET_CLOCK:
            MApp_Sleep_SetOffTime(FALSE);  //disable off timer
            MApp_ZUI_API_ShowWindow(HWND_MENU_TIME_PAGE, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_MASK_BACKGROUND, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_TRANSPARENT_BG, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_MENU_TIME_CLOCK_PAGE, SW_SHOW);
            MApp_ZUI_API_SetFocus(HWND_MENU_TIME_CLOCK_DAY);
            MApp_ZUI_ACT_ResetTimeMenuTenKey();//init ten key input value
            MApp_ZUI_API_PostMessage(HWND_MENU_TIME_CLOCK_PAGE, MSG_EFFECT_SPREADOUT, 0);
            return TRUE;


        case EN_EXE_GOTO_SET_OFF_TIMER:
            MApp_Sleep_SetOffTime(FALSE); //disable off timer

            MApp_ZUI_API_ShowWindow(HWND_MENU_TIME_PAGE, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_MASK_BACKGROUND, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_TRANSPARENT_BG, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_MENU_TIME_OFFTIME_PAGE, SW_SHOW);
            MApp_ZUI_API_SetFocus(HWND_MENU_TIME_OFFTIME);
            if (stGenSetting.g_Time.cOffTimerFlag == EN_Time_OffTimer_Off)
            {
                MApp_ZUI_API_EnableWindow(HWND_MENU_TIME_OFFTIME_HOUR, DISABLE);
                MApp_ZUI_API_EnableWindow(HWND_MENU_TIME_OFFTIME_MINUTE, DISABLE);
            }
            else
            {
                MApp_ZUI_API_EnableWindow(HWND_MENU_TIME_OFFTIME_PAGE, ENABLE);
            }

            MApp_ZUI_ACT_ResetTimeMenuTenKey();//init ten key input value
            return TRUE;


        case EN_EXE_GOTO_SET_ON_TIMER:
            MApp_ZUI_API_ShowWindow(HWND_MENU_TIME_PAGE, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_MASK_BACKGROUND, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_TRANSPARENT_BG, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_MENU_TIME_ONTIME_PAGE, SW_SHOW);
            MApp_ZUI_API_SetFocus(HWND_MENU_TIME_ONTIME_REPEAT);
            if(stGenSetting.g_Time.cOnTimerSourceFlag == EN_Time_OnTimer_Source_RADIO
                || stGenSetting.g_Time.cOnTimerSourceFlag == EN_Time_OnTimer_Source_DTV
                #if NORDIG_FUNC //for Nordig Spec v2.0
                || stGenSetting.g_Time.cOnTimerSourceFlag == EN_Time_OnTimer_Source_DATA
                #endif
                || stGenSetting.g_Time.cOnTimerSourceFlag == EN_Time_OnTimer_Source_ATV)
            {
                MApp_ZUI_API_EnableWindow(HWND_MENU_TIME_ONTIME_CHANNEL, TRUE);
            }
            else
            {
                MApp_ZUI_API_EnableWindow(HWND_MENU_TIME_ONTIME_CHANNEL, FALSE);
            }
            if(stGenSetting.g_Time.cOnTimerFlag==EN_Time_OnTimer_Off)
            {
                MApp_ZUI_API_EnableWindow(HWND_MENU_TIME_ONTIME_HOUR, DISABLE);
                MApp_ZUI_API_EnableWindow(HWND_MENU_TIME_ONTIME_MINUTE, DISABLE);
                MApp_ZUI_API_EnableWindow(HWND_MENU_TIME_ONTIME_SOURCE, DISABLE);
                MApp_ZUI_API_EnableWindow(HWND_MENU_TIME_ONTIME_CHANNEL, DISABLE);
                MApp_ZUI_API_EnableWindow(HWND_MENU_TIME_ONTIME_VOLUME, DISABLE);
            }
            else
            {
                MApp_ZUI_API_EnableWindow(HWND_MENU_TIME_ONTIME_PAGE, ENABLE);
            }

            MApp_ZUI_ACT_ResetTimeMenuTenKey();//init ten key input value
            return TRUE;

        case EN_EXE_GOTO_AUDIOLANG_PAGE:
            MApp_ZUI_API_ShowWindow(HWND_MENU_OPTION_PAGE, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_MASK_BACKGROUND, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_TRANSPARENT_BG, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_MENU_OPTION_AUDIOLANG_PAGE, SW_SHOW);
            if(OSD_COUNTRY_SETTING == E_NEWZEALAND)
            {
                MApp_ZUI_CTL_Grid_SetIndex(HWND_MENU_OPTION_AUDIOLANG_GRID, MApp_ZUI_ACT_GetAudioLanguageIndex, MApp_ZUI_ACT_SetAudioLanguageIndex, LANGUAGE_CZECH, LANGUAGE_AUDIO_MAX_NZ);
            }
            else
            {
                MApp_ZUI_CTL_Grid_SetIndex(HWND_MENU_OPTION_AUDIOLANG_GRID, MApp_ZUI_ACT_GetAudioLanguageIndex, MApp_ZUI_ACT_SetAudioLanguageIndex, LANGUAGE_CZECH, LANGUAGE_AUDIO_MAX_EU);
            }
            MApp_ZUI_CTL_Grid_SetFnGetTextByIndex(HWND_MENU_OPTION_AUDIOLANG_GRID, MApp_ZUI_ACT_GetLanguageStringByIndex);
            MApp_ZUI_API_SetFocus(HWND_MENU_OPTION_AUDIOLANG_PRIMARY);
            return TRUE;


        case EN_EXE_GOTO_SET_AUDIO_LAN:
            if(OSD_COUNTRY_SETTING == E_NEWZEALAND)
            {
                MApp_ZUI_CTL_Grid_SetIndex(HWND_MENU_OPTION_AUDIOLANG_GRID, MApp_ZUI_ACT_GetAudioLanguageIndex, MApp_ZUI_ACT_SetAudioLanguageIndex, LANGUAGE_CZECH, LANGUAGE_AUDIO_MAX_NZ);
            }
            else
            {
                MApp_ZUI_CTL_Grid_SetIndex(HWND_MENU_OPTION_AUDIOLANG_GRID, MApp_ZUI_ACT_GetAudioLanguageIndex, MApp_ZUI_ACT_SetAudioLanguageIndex, LANGUAGE_CZECH, LANGUAGE_AUDIO_MAX_EU);
            }
            MApp_ZUI_CTL_Grid_SetFnGetTextByIndex(HWND_MENU_OPTION_AUDIOLANG_GRID, MApp_ZUI_ACT_GetLanguageStringByIndex);
            MApp_ZUI_API_SetFocus(HWND_MENU_OPTION_AUDIOLANG_GRID);
            return TRUE;


        case EN_EXE_GOTO_SUBLANG_PAGE:
            MApp_ZUI_API_ShowWindow(HWND_MENU_OPTION_PAGE, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_MASK_BACKGROUND, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_TRANSPARENT_BG, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_MENU_OPTION_SUBLANG_PAGE, SW_SHOW);
            if(OSD_COUNTRY_SETTING == E_NEWZEALAND)
            {
                MApp_ZUI_CTL_Grid_SetIndex(HWND_MENU_OPTION_SUBLANG_GRID, MApp_ZUI_ACT_GetSubLanguageIndex, MApp_ZUI_ACT_SetSubLanguageIndex, LANGUAGE_CZECH, LANGUAGE_SUBTITLE_MAX_NZ);
            }
            else
            {
                MApp_ZUI_CTL_Grid_SetIndex(HWND_MENU_OPTION_SUBLANG_GRID, MApp_ZUI_ACT_GetSubLanguageIndex, MApp_ZUI_ACT_SetSubLanguageIndex, LANGUAGE_CZECH, LANGUAGE_SUBTITLE_MAX_EU);
            }
            MApp_ZUI_CTL_Grid_SetFnGetTextByIndex(HWND_MENU_OPTION_SUBLANG_GRID, MApp_ZUI_ACT_GetSubtitleLanguageStringByIndex);
            MApp_ZUI_API_SetFocus(HWND_MENU_OPTION_SUBLANG_PRIMARY);
            return TRUE;


        case EN_EXE_GOTO_SET_SUBTITLE_LAN:
            if(OSD_COUNTRY_SETTING == E_NEWZEALAND)
            {
                MApp_ZUI_CTL_Grid_SetIndex(HWND_MENU_OPTION_SUBLANG_GRID, MApp_ZUI_ACT_GetSubLanguageIndex, MApp_ZUI_ACT_SetSubLanguageIndex, LANGUAGE_CZECH, LANGUAGE_SUBTITLE_MAX_NZ);
            }
            else
            {
                MApp_ZUI_CTL_Grid_SetIndex(HWND_MENU_OPTION_SUBLANG_GRID, MApp_ZUI_ACT_GetSubLanguageIndex, MApp_ZUI_ACT_SetSubLanguageIndex, LANGUAGE_CZECH, LANGUAGE_SUBTITLE_MAX_EU);
            }
            MApp_ZUI_CTL_Grid_SetFnGetTextByIndex(HWND_MENU_OPTION_SUBLANG_GRID, MApp_ZUI_ACT_GetSubtitleLanguageStringByIndex);
            MApp_ZUI_API_SetFocus(HWND_MENU_OPTION_SUBLANG_GRID);
            return TRUE;

        case EN_EXE_GOTO_SET_OSD_LAN:
            MApp_ZUI_CTL_Grid_SetIndex(HWND_MENU_OPTION_OSDLANG_GRID, MApp_ZUI_ACT_GetOsdLanguageIndex, MApp_ZUI_ACT_SetOsdLanguageIndex, LANGUAGE_MENU_MIN, LANGUAGE_MENU_MAX);
            MApp_ZUI_CTL_Grid_SetFnGetTextByIndex(HWND_MENU_OPTION_OSDLANG_GRID, MApp_ZUI_ACT_GetMenuLanguageStringByIndex);
            MApp_ZUI_API_ShowWindow(HWND_MENU_OPTION_PAGE, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_MASK_BACKGROUND, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_TRANSPARENT_BG, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_MENU_OPTION_OSDLANG_PAGE, SW_SHOW);
            MApp_ZUI_API_SetFocus(HWND_MENU_OPTION_OSDLANG_GRID);
            return TRUE;

        case EN_EXE_GOTO_SET_TIMEZONE:
            #if  ENABLE_SBTVD_BRAZIL_APP
                MApp_ZUI_CTL_Grid_SetIndex(HWND_MENU_TIME_TIMEZONE_GRID, MApp_ZUI_ACT_GetTimezoneIndex, MApp_ZUI_ACT_SetTimezoneIndex, TIMEZONE_GMT_Minus5_START, TIMEZONE_GMT_Minus2_END);
            #else
                MApp_ZUI_CTL_Grid_SetIndex(HWND_MENU_TIME_TIMEZONE_GRID, MApp_ZUI_ACT_GetTimezoneIndex, MApp_ZUI_ACT_SetTimezoneIndex, TIMEZONE_GMT_0_START, TIMEZONE_NUM-1);
            #endif
            MApp_ZUI_CTL_Grid_SetFnGetTextByIndex(HWND_MENU_TIME_TIMEZONE_GRID, MApp_ZUI_ACT_GetTimezoneStringByIndex);
            MApp_ZUI_API_ShowWindow(HWND_MENU_TIME_PAGE, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_MASK_BACKGROUND, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_TRANSPARENT_BG, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_MENU_TIME_TIMEZONE_PAGE, SW_SHOW);
            MApp_ZUI_API_SetFocus(HWND_MENU_TIME_TIMEZONE_GRID);
            return TRUE;

        case EN_EXE_SET_AUTOTUNING_COUNTRY:
            MApp_ZUI_CTL_Grid_SetIndex(HWND_MENU_DLG_TUNE_CONFIRM_COUNTRY_GRID, MApp_ZUI_ACT_GetTuningCountryIndex, MApp_ZUI_ACT_SetTuningCountryIndex, OSD_COUNTRY_AUSTRALIA, OSD_COUNTRY_NUMS-1);
            MApp_ZUI_CTL_Grid_SetFnGetTextByIndex(HWND_MENU_DLG_TUNE_CONFIRM_COUNTRY_GRID, MApp_ZUI_ACT_GetCountryStringByIndex);
            MApp_ZUI_API_SetFocus(HWND_MENU_DLG_TUNE_CONFIRM_COUNTRY_GRID);
            return TRUE;
#endif
        case EN_EXE_GOTO_OPTION_HDMI_CEC_PAGE:
            MApp_ZUI_API_ShowWindow(HWND_MENU_OPTION_PAGE, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_MASK_BACKGROUND, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_TRANSPARENT_BG, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_MENU_HDMI_CEC_PAGE, SW_SHOW);
            MApp_ZUI_API_SetFocus(HWND_MENU_HDMI_CEC_DEVICE_LIST);
            return TRUE;

        case EN_EXE_PASS_PASSWORD:
        {
             switch(_ePrevCommonDlgMode)
             {
                case EN_COMMON_DLG_MODE_FACTORY_RESET_INPUT_PASSWORD:
                    MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_GOTO_FACTORY_RESET_CONFIRM_DLG);
                    break;

                case EN_COMMON_DLG_MODE_ATV_TUNING_INPUT_PASSWORD:
                    MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_GOTO_ATV_TUNING);
                    break;

                case EN_COMMON_DLG_MODE_DTV_TUNING_INPUT_PASSWORD:
                    MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_GOTO_DTV_TUNING);
                    break;

                case EN_COMMON_DLG_MODE_SCAN_INPUT_PASSWORD:
                  #if ENABLE_ATV_CHINA_APP//china will not use country adjust option
                    MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_GOTO_AUTO_TUNING);
                  #else
                    MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_GOTO_TUNING_CONFIRM);
                  #endif
                break;

                case EN_COMMON_DLG_MODE_ENTER_MENU_LOCK_PAGE_INPUT_PASSWORD:
                    MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_GOTO_MENU_LOCK_PAGE);
                    break;

                default:
                    return 0;
             }
             break;
        }
        return TRUE;


        case EN_EXE_GOTO_CONFIRM_FACTORY_RESET:
            #if (ENABLE_CUS_UI_SPEC == FALSE)
            if(stGenSetting.g_BlockSysSetting.u8BlockSysLockMode==1)
            {
                MApp_ZUI_API_StoreFocusCheckpoint();
                _MApp_ZUI_ACT_OpenCommonDialog(EN_COMMON_DLG_MODE_FACTORY_RESET_INPUT_PASSWORD);

            }
            else
            #endif
            {
                MApp_ZUI_API_StoreFocusCheckpoint();
                MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_GOTO_FACTORY_RESET_CONFIRM_DLG);
            }
            return TRUE;
		case EN_EXE_CLEAN_ALL_LOCK:
			MApp_ZUI_API_StoreFocusCheckpoint();
			MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_GOTO_CLEAN_LOCK_CONFIRM_DLG);
			return TRUE;
        case EN_EXE_GOTO_FACTORY_RESET_CONFIRM_DLG:
            #if (ENABLE_CUS_UI_SPEC == FALSE)
            if(stGenSetting.g_BlockSysSetting.u8BlockSysLockMode==1 &&
                _MApp_ZUI_ACT_PasswordConvertToSystemFormat(PasswordInput1) !=
                stGenSetting.g_BlockSysSetting.u16BlockSysPassword)
            {
                // password wrong
                _ePrevCommonDlgMode = EN_COMMON_DLG_MODE_FACTORY_RESET_INPUT_PASSWORD;
                _MApp_ZUI_ACT_OpenCommonDialog(EN_COMMON_DLG_MODE_WRONG_PASSWORD);
            }
            else
            #endif
            {
                //store previous focus...
                //_hwndCommonDlgPrevFocus = MApp_ZUI_API_GetFocus();
                _MApp_ZUI_ACT_OpenCommonDialog(EN_COMMON_DLG_MODE_FACTORY_RESET_CONFIRM);
            }
            return TRUE;
		case EN_EXE_GOTO_CLEAN_LOCK_CONFIRM_DLG:
			printf("\r\n############");
			_MApp_ZUI_ACT_OpenCommonDialog(EN_COMMON_DLG_MODE_CLEAN_LOCK);
			return TRUE;
        case EN_EXE_GOTO_CH_LIST_CLEAN_ALL_DLG:
            _MApp_ZUI_ACT_OpenCommonDialog(EN_COMMON_DLG_MODE_CH_LIST_CLEAN_ALL_CONFIRM);
            return TRUE;
        case EN_EXE_GOTO_CH_INFO_SAVE_CHANGED_DLG:
            _MApp_ZUI_ACT_OpenCommonDialog(EN_COMMON_DLG_MODE_CHANNEL_INFO_SAVE_CHANGED);
            return TRUE;

#if (ENABLE_CUS_UI_SPEC == FALSE)/*Creass.liu at 2012-06-27*/
        case EN_EXE_GOTO_CONFIRM_DIVX:
            MApp_ZUI_API_StoreFocusCheckpoint();
            MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_GOTO_DIVX_DLG);
            return TRUE;

        case EN_EXE_GOTO_DIVX_DLG:
            //put drm divx here
            MS_DEBUG_MSG(printf("put drm divx code here!\n"));
          #if ENABLE_DRM
            MDrv_AVD_Set3dComb(DISABLE);
            MApp_VDPlayer_CheckAndGenDRMData();
            if (IsATVInUse()||IsAVInUse())
            {
                MDrv_AVD_Set3dComb(ENABLE);
            }
          #endif
            _MApp_ZUI_ACT_OpenCommonDialog(EN_COMMON_DLG_MODE_DIVX);
            return TRUE;

        case EN_EXE_GOTO_CONFIRM_DEACTIVATION:
            MApp_ZUI_API_StoreFocusCheckpoint();
            MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_GOTO_DEACTIVATION_CONFIRM_DLG);
            return TRUE;

        case EN_EXE_GOTO_DEACTIVATION_CONFIRM_DLG:
            _MApp_ZUI_ACT_OpenCommonDialog(EN_COMMON_DLG_MODE_DEACTIVATION_CONFIRM);
            return TRUE;
#endif

        case EN_EXE_GOTO_COMMON_DLG_YES:
            //store previous focus...
            if(_eCommonDlgMode == EN_COMMON_DLG_MODE_FACTORY_RESET_CONFIRM)
            {
                MApp_ZUI_API_StoreFocusCheckpoint();
                _enTargetMenuState = STATE_MENU_INIT;
                _MApp_ZUI_ACT_OpenCommonDialog(EN_COMMON_DLG_MODE_FACTORY_RESET);
            }
            else if(_eCommonDlgMode == EN_COMMON_DLG_MODE_CLEAN_LOCK)
            {
                MApp_ZUI_API_StoreFocusCheckpoint();
                _enTargetMenuState = STATE_MENU_INIT;
                #if ENABLE_CUS_BLOCK_SYS
                if(MApp_UiMenuFunc_CheckInputLockAudioVideo())
                {
                    switch(UI_INPUT_SOURCE_TYPE)
                    {
                        case UI_INPUT_SOURCE_ATV:
                            #if ENABLE_CUS_BLOCK_SYS
                            if((stGenSetting.g_VChipSetting.u8InputBlockItem & INPUT_BLOCK_TV) == 0x00)
                            {
                                msAPI_ATV_SetLockedCHCheckPwdFlag(msAPI_ATV_GetCurrentProgramNumber(),TRUE);
                            }
                            #endif
                            MApp_MuteAvByLock(E_SCREEN_MUTE_INPUT, FALSE);
                            if(1) //(MApp_IsSrcHasSignal(MAIN_WINDOW))
                            {
                                msAPI_Scaler_SetScreenMute(E_SCREEN_MUTE_TEMPORARY, DISABLE, 0, MAIN_WINDOW);
                                if((msAPI_Scaler_GetScreenMute(MAIN_WINDOW)&E_SCREEN_MUTE_FREERUN))
                                {
                                    msAPI_Scaler_SetBlueScreen( DISABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
                                }
                            }
                            break;
                            case UI_INPUT_SOURCE_HDMI:
                    #if (INPUT_HDMI_VIDEO_COUNT >= 2)
                        case UI_INPUT_SOURCE_HDMI2:
                    #endif
                    #if (INPUT_HDMI_VIDEO_COUNT >= 3)
                        case UI_INPUT_SOURCE_HDMI3:
                    #endif
                    #if (INPUT_HDMI_VIDEO_COUNT >= 4)
                        case UI_INPUT_SOURCE_HDMI4:
                    #endif
                            msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_PERMANENT_MUTEOFF, E_AUDIOMUTESOURCE_ACTIVESOURCE);
                            MApp_MuteAvByLock(E_SCREEN_MUTE_INPUT, FALSE);
                            if(MApp_IsSrcHasSignal(MAIN_WINDOW))
                            {
                                if((msAPI_Scaler_GetScreenMute(MAIN_WINDOW)&E_SCREEN_MUTE_FREERUN))
                                {
                                    msAPI_Scaler_SetBlueScreen( DISABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
                                }
                            }
                            break;
                        case UI_INPUT_SOURCE_AV:
                        #if (INPUT_AV_VIDEO_COUNT >= 2)
                        case UI_INPUT_SOURCE_AV2:
                        #endif
                        case UI_INPUT_SOURCE_COMPONENT:
                        #if (INPUT_YPBPR_VIDEO_COUNT >= 2)
                        case UI_INPUT_SOURCE_COMPONENT2:
                        #endif
                        case UI_INPUT_SOURCE_RGB:
                            MApp_MuteAvByLock(E_SCREEN_MUTE_INPUT, FALSE);
                            if(MApp_IsSrcHasSignal(MAIN_WINDOW))
                            {
                                if((msAPI_Scaler_GetScreenMute(MAIN_WINDOW)&E_SCREEN_MUTE_FREERUN))
                                {
                                    msAPI_Scaler_SetBlueScreen( DISABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
                                }
                            }
                            break;
                        default:
                            break;
                    }
                }

                #endif

                g_u16PasswordCheckSource = 0x0000;
		        //stGenSetting.g_VChipSetting.u16VChipPassword = 0; //SMC jayden.chen add for clean password 20130308
		        stGenSetting.g_VChipSetting.u8InputBlockItem=0;
                stGenSetting.g_SysSetting.g_enKeyPadLock = EN_E5_KeyLock_Off;// 2012-07-05 CUS add
                msAPI_ATV_LockProgram_Clear();
                MApp_SaveVshipSetting();
			#if CUS_SMC_ENABLE_HOTEL_MODE
				stGenSetting.g_FactorySetting.HotelMenuHotelModeOperationEnable = DISABLE;
			    MApp_SaveFactorySetting();
			#endif
                #if ENABLE_CUS_BLOCK_SYS
                MApp_BlockSys_Monitor(MAIN_WINDOW,BLOCKSYS_CHECK_AV,FALSE);
                #endif
                MApp_ZUI_ACT_ExecuteMenuCommonDialogAction(EN_EXE_CLEAN_ALL_LOCK);
            }
            else if(_eCommonDlgMode == EN_COMMON_DLG_MODE_CH_LIST_CLEAN_ALL_CONFIRM)
            {
                MApp_ZUI_API_StoreFocusCheckpoint();
                _enTargetMenuState = STATE_MENU_INIT;
                MApp_ZUI_ACT_ExecuteMenuCommonDialogAction(EN_EXE_DO_CLEAN_CH_LIST);
            }
            else if(_eCommonDlgMode == EN_COMMON_DLG_MODE_CHANNEL_INFO_SAVE_CHANGED)
            {
                MApp_ZUI_API_StoreFocusCheckpoint();
                _enTargetMenuState = STATE_MENU_INIT;
                MApp_ZUI_ACT_ExecuteMenuCommonDialogAction(EN_EXE_DO_SAVE_CHANNEL_INFO_CHANGED);
            }
#if (ENABLE_CUS_UI_SPEC == DISABLE) /*Creass.liu at 2012-06-02*/
            else if(_eCommonDlgMode == EN_COMMON_DLG_MODE_DEACTIVATION_CONFIRM)
            {
                //put drm deactivation here
                MS_DEBUG_MSG(printf("put drm deactivation code here!\n"));
                #if ENABLE_DRM
                MApp_VDPlayer_Deactivate();
                #endif
                _MApp_ZUI_ACT_OpenCommonDialog(EN_COMMON_DLG_MODE_DEACTIVATION);
            }
            else if(_eCommonDlgMode == EN_COMMON_DLG_MODE_DIVX)
            {
                MApp_ZUI_API_ShowWindow(HWND_MENU_OPTION_PAGE, SW_SHOW);
                //MApp_ZUI_ACT_ShowMainMenuBackground(HWND_MENU_BOTTOM_BALL_FOCUS_OPTION);
                //MApp_ZUI_API_RestoreFocusCheckpoint();
                MApp_ZUI_ACT_ExecuteMenuCommonDialogAction(EN_EXE_CLOSE_CURRENT_OSD);
                MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_OPTION_PAGE_LIST, HWND_MENU_OPTION_DIVX);
            }
            else if(_eCommonDlgMode == EN_COMMON_DLG_MODE_DEACTIVATION )
            {
                MApp_ZUI_API_ShowWindow(HWND_MENU_OPTION_PAGE, SW_SHOW);
                //MApp_ZUI_ACT_ShowMainMenuBackground(HWND_MENU_BOTTOM_BALL_FOCUS_OPTION);
                MApp_ZUI_API_RestoreFocusCheckpoint();
                MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_GOTO_DIVX_DLG);
            }
  #endif
            else
            {
                _MApp_ZUI_ACT_OpenCommonDialog(EN_COMMON_DLG_MODE_USB_UPGRADING);
                MApp_ZUI_API_SetTimer(HWND_MENU_DLG_COMMON,0,100);
            }
            return TRUE;


        case EN_EXE_GOTO_COMMON_DLG_NO:
            switch(_eCommonDlgMode)
            {
                case EN_COMMON_DLG_MODE_FACTORY_RESET_CONFIRM:
                    MApp_ZUI_API_ShowWindow(HWND_MENU_BACKGROUND, SW_SHOW);
                    MApp_ZUI_API_ShowWindow(HWND_MENU_OPTION_PAGE, SW_SHOW);
                    //MApp_ZUI_ACT_ShowMainMenuBackground(HWND_MENU_BOTTOM_BALL_FOCUS_OPTION);
                    #if(UI_SKIN_SEL==UI_SKIN_1366X768X565_HAIER_CN)  // CUS_xm zHIHE 20120807 modify
					MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_SETUP_BIG, FALSE);// CUS_xm zHIHE 20120807 modify
					#endif
                    MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_OPTION_PAGE_LIST,HWND_MENU_OPTION_FACTORY_RESET);
                    //MApp_ZUI_API_RestoreFocusCheckpoint();
                    break;
				case EN_COMMON_DLG_MODE_CLEAN_LOCK:
					//MApp_ZUI_ACT_ShowMainMenuBackground(HWND_MENU_BOTTOM_BALL_FOCUS_OPTION);
					MApp_ZUI_API_ShowWindow(HWND_MENU_BACKGROUND, SW_SHOW);
					MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_SUBPAGE, SW_SHOW);
					#if(UI_SKIN_SEL==UI_SKIN_1366X768X565_HAIER_CN)  // CUS_xm zHIHE 20120807 modify
					MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_LOCK_BIG, FALSE);// CUS_xm zHIHE 20120807 modify
					#endif
					MApp_ZUI_API_SetFocus(HWND_MENU_LOCK_MAINSUBPAGE_ITEM_CLEAN_ALL);
					break;
                case EN_COMMON_DLG_MODE_CH_LIST_CLEAN_ALL_CONFIRM:
                    MApp_ZUI_API_ShowWindow(HWND_MENU_BACKGROUND, SW_SHOW);
                    MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_PAGE, SW_SHOW);
                    //MApp_ZUI_ACT_ShowMainMenuBackground(HWND_MENU_BOTTOM_BALL_FOCUS_OPTION);
                    MApp_ZUI_API_RestoreFocusCheckpoint();
                    break;
                case EN_COMMON_DLG_MODE_CHANNEL_INFO_SAVE_CHANGED:
                    MApp_ZUI_API_ShowWindow(HWND_MENU_BACKGROUND, SW_SHOW);
                    MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_INFO_PAGE, SW_SHOW);
                    //MApp_ZUI_ACT_ShowMainMenuBackground(HWND_MENU_BOTTOM_BALL_FOCUS_OPTION);
                    MApp_ZUI_API_RestoreFocusCheckpoint();
                    break;

                case EN_COMMON_DLG_MODE_USB_UPDATE_CONFIRM:
                    MApp_ZUI_API_ShowWindow(HWND_MENU_BACKGROUND, SW_SHOW);
                    MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_PAGE, SW_SHOW);
                    //MApp_ZUI_ACT_ShowMainMenuBackground(HWND_MENU_BOTTOM_BALL_FOCUS_CHANNEL);
                    MApp_ZUI_API_SetFocus(HWND_MENU_CHANNEL_SW_USB_UPGRADE);
                    break;

#if (ENABLE_CUS_UI_SPEC == DISABLE) /*Creass.liu at 2012-06-02*/
                case EN_COMMON_DLG_MODE_DIVX:
                    MApp_ZUI_API_ShowWindow(HWND_MENU_OPTION_PAGE, SW_SHOW);
                    //MApp_ZUI_ACT_ShowMainMenuBackground(HWND_MENU_BOTTOM_BALL_FOCUS_OPTION);
                    //MApp_ZUI_API_RestoreFocusCheckpoint();
                    MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_OPTION_PAGE_LIST, HWND_MENU_OPTION_DIVX);
                    break;

                case EN_COMMON_DLG_MODE_DEACTIVATION:
                case EN_COMMON_DLG_MODE_DEACTIVATION_CONFIRM:
                    MApp_ZUI_API_ShowWindow(HWND_MENU_OPTION_PAGE, SW_SHOW);
                    //MApp_ZUI_ACT_ShowMainMenuBackground(HWND_MENU_BOTTOM_BALL_FOCUS_OPTION);
                    //MApp_ZUI_API_RestoreFocusCheckpoint();
                    MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_OPTION_PAGE_LIST, HWND_MENU_OPTION_DEACTIVATION);
                    break;
#endif
                default:
                    break;
            }
           MApp_ZUI_ACT_ExecuteMenuCommonDialogAction(EN_EXE_CLOSE_CURRENT_OSD);
            return TRUE;


        case EN_EXE_GOTO_WRONG_PASSWORD_DLG:
            //store previous focus...
            //_hwndCommonDlgPrevFocus = MApp_ZUI_API_GetFocus();
            MApp_ZUI_API_StoreFocusCheckpoint();
            _MApp_ZUI_ACT_OpenCommonDialog(EN_COMMON_DLG_MODE_WRONG_PASSWORD);
            return TRUE;

        case EN_EXE_GOTO_MISMATCH_PASSWORD_DLG:
            //store previous focus...
            //_hwndCommonDlgPrevFocus = MApp_ZUI_API_GetFocus();
            MApp_ZUI_API_StoreFocusCheckpoint();
            _MApp_ZUI_ACT_OpenCommonDialog(EN_COMMON_DLG_MODE_MISMATCH_PASSWORD);
            return TRUE;

        case EN_EXE_GOTO_SET_PASSWORD_DLG:
            //store previous focus...
            //_hwndCommonDlgPrevFocus = MApp_ZUI_API_GetFocus();
            MApp_ZUI_API_StoreFocusCheckpoint();
            _hwndCommonDlgTargetFocus = MApp_ZUI_API_GetFocus();
            _MApp_ZUI_ACT_OpenCommonDialog(EN_COMMON_DLG_MODE_SET_PASSWORD);
            return TRUE;

        case EN_EXE_ENTER_MENU_LOCK_PAGE:
            MApp_ZUI_API_StoreFocusCheckpoint();
            #if (ENABLE_DTV)
            _hwndCommonDlgTargetFocus = HWND_MENU_LOCK_SYSTEM;
	        MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_PAGE_DTV, SW_HIDE);
            _MApp_ZUI_ACT_OpenCommonDialog(EN_COMMON_DLG_MODE_ENTER_MENU_LOCK_PAGE_INPUT_PASSWORD);
            #elif (ENABLE_ATV_VCHIP)
            _hwndCommonDlgTargetFocus = HWND_MENU_LOCK_ENTER_PASSWORD;
            MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_PAGE, SW_HIDE);
            #endif


            return TRUE;

        case EN_EXE_GOTO_INPUT_PASSWORD_DLG:
            //store previous focus...
            //_hwndCommonDlgPrevFocus = MApp_ZUI_API_GetFocus();
            MApp_ZUI_API_StoreFocusCheckpoint();

          #if 0
            if (stGenSetting.g_BlockSysSetting.u8BlockSysLockMode != 0)
            {
                _hwndCommonDlgTargetFocus = HWND_MENU_LOCK_SYSTEM;
                _MApp_ZUI_ACT_OpenCommonDialog(EN_COMMON_DLG_MODE_INPUT_PASSWORD);
            }
            else
            {
                 _hwndCommonDlgTargetFocus = HWND_MENU_LOCK_SYSTEM;
                 MApp_ZUI_API_SetFocus(HWND_MENU_LOCK_SYSTEM);
            }
          #else
           #if (ENABLE_DTV)
            _hwndCommonDlgTargetFocus = HWND_MENU_LOCK_SYSTEM;
            MApp_ZUI_API_SetFocus(HWND_MENU_LOCK_SYSTEM);
           #elif (ENABLE_ATV_VCHIP)
            _hwndCommonDlgTargetFocus = HWND_MENU_LOCK_ENTER_PASSWORD;
            MApp_ZUI_API_SetFocus(HWND_MENU_LOCK_ENTER_PASSWORD);
           #endif
      #endif

            return TRUE;


        case EN_EXE_CHECK_INPUT_PASSWORD:
            _eCommonDlgMode = EN_COMMON_DLG_MODE_INVALID;
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON, SW_HIDE);

            if (_MApp_ZUI_ACT_PasswordConvertToSystemFormat(PasswordInput1) ==
                stGenSetting.g_BlockSysSetting.u16BlockSysPassword)
            {
                //password correct
                MApp_ZUI_API_SetFocus(_hwndCommonDlgTargetFocus);
            }
            else
            {
                //password wrong...
                _ePrevCommonDlgMode = EN_COMMON_DLG_MODE_INPUT_PASSWORD;
                _MApp_ZUI_ACT_OpenCommonDialog(EN_COMMON_DLG_MODE_WRONG_PASSWORD);
            }
            return TRUE;

        case EN_EXE_CHECK_SET_PASSWORD_CHECKOLDPW:
            if((_MApp_ZUI_ACT_PasswordConvertToSystemFormat(PasswordInput0) ==
                stGenSetting.g_BlockSysSetting.u16BlockSysPassword) && PasswordInput1 == 0)
            {
                PasswordInput0 = 0;
                MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_TEXT5, SW_HIDE);
                MApp_ZUI_API_EnableWindow(HWND_MENU_DLG_PASSWORD_INPUT1_TEXT,ENABLE);
                MApp_ZUI_API_EnableWindow(HWND_MENU_DLG_PASSWORD_INPUT1_1, ENABLE);
                MApp_ZUI_API_EnableWindow(HWND_MENU_DLG_PASSWORD_INPUT1_2, ENABLE);
                MApp_ZUI_API_EnableWindow(HWND_MENU_DLG_PASSWORD_INPUT1_3, ENABLE);
                MApp_ZUI_API_EnableWindow(HWND_MENU_DLG_PASSWORD_INPUT1_4, ENABLE);
                MApp_ZUI_API_EnableWindow(HWND_MENU_DLG_PASSWORD_INPUT2_TEXT,ENABLE);
                MApp_ZUI_API_EnableWindow(HWND_MENU_DLG_PASSWORD_INPUT2_1, ENABLE);
                MApp_ZUI_API_EnableWindow(HWND_MENU_DLG_PASSWORD_INPUT2_1, ENABLE);
                MApp_ZUI_API_EnableWindow(HWND_MENU_DLG_PASSWORD_INPUT2_2, ENABLE);
                MApp_ZUI_API_EnableWindow(HWND_MENU_DLG_PASSWORD_INPUT2_3, ENABLE);
                MApp_ZUI_API_EnableWindow(HWND_MENU_DLG_PASSWORD_INPUT2_4, ENABLE);
                MApp_ZUI_API_EnableWindow(HWND_MENU_DLG_PASSWORD_INPUT0_TEXT,DISABLE);
                MApp_ZUI_API_EnableWindow(HWND_MENU_DLG_PASSWORD_INPUT0_1, DISABLE);
                MApp_ZUI_API_EnableWindow(HWND_MENU_DLG_PASSWORD_INPUT0_2, DISABLE);
                MApp_ZUI_API_EnableWindow(HWND_MENU_DLG_PASSWORD_INPUT0_3, DISABLE);
                MApp_ZUI_API_EnableWindow(HWND_MENU_DLG_PASSWORD_INPUT0_4, DISABLE);
                MApp_ZUI_API_EnableWindow(HWND_MENU_DLG_PASSWORD_PRESSED_PANE0, DISABLE);
                MApp_ZUI_API_SetFocus(HWND_MENU_DLG_PASSWORD_INPUT1_1);
            }
            else
            {
                MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON_TEXT5, SW_SHOW);
                MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PRESSED_PANE0, SW_HIDE);
                MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PANE0, SW_SHOW);
                MApp_ZUI_API_SetFocus(HWND_MENU_DLG_PASSWORD_INPUT0_1);
            }
            return TRUE;

        case EN_EXE_CHECK_SET_PASSWORD:
            _eCommonDlgMode = EN_COMMON_DLG_MODE_INVALID;
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON, SW_HIDE);
            if (PasswordInput1 == PasswordInput2)
            {
                //password match
                //MApp_ZUI_ACT_ShowMainMenuBackground(HWND_MENU_BOTTOM_BALL_FOCUS_LOCK);
                MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_PAGE, SW_SHOW);
                MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_PAGE_CHECKPWD_ERROR_MSG, SW_HIDE);
                MApp_ZUI_API_SetFocus(_hwndCommonDlgTargetFocus);

                //apply change...
                stGenSetting.g_BlockSysSetting.u16BlockSysPassword =
                    _MApp_ZUI_ACT_PasswordConvertToSystemFormat(PasswordInput1);
            }
            else
            {
                //password not match...
                _MApp_ZUI_ACT_OpenCommonDialog(EN_COMMON_DLG_MODE_MISMATCH_PASSWORD);
            }
            return TRUE;

        case EN_EXE_GOTO_AUDIO_LANG:
            MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
            _enTargetMenuState = STATE_MENU_GOTO_OSDPAGE;
            MApp_OSDPage_SetOSDPage(E_OSD_AUDIO_LANGUAGE);
            return TRUE;

        case EN_EXE_SHOW_SOURCE_BANNER:
            MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
            _enTargetMenuState = STATE_MENU_GOTO_INPUT_SOURCE;
            return TRUE;

        case EN_EXE_GOTO_CHANNEL_LIST:
            MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
            _enTargetMenuState = STATE_MENU_GOTO_CHANNEL_LIST;
            return TRUE;

        case EN_EXE_GOTO_FAVORITE_LIST:
             MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
            _enTargetMenuState = STATE_MENU_GOTO_FAVORITE_LIST;
            return TRUE;

        case EN_EXE_EPG_SHOW_PROGRAMMEGUIDE_TIME_PAGE:
             MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
            _enTargetMenuState = STATE_MENU_GOTO_EPG;
            return TRUE;

        case EN_EXE_SHOW_BRIEF_CH_INFO:
             MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
            _enTargetMenuState = STATE_MENU_GOTO_INFO;
            return TRUE;

#if (ENABLE_CUS_UI_SPEC == FALSE)
        case EN_EXE_GOTO_NET_CONFIG:
            MApp_ZUI_API_ShowWindow(HWND_MENU_MASK_BACKGROUND, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_OPTION_PAGE, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_TRANSPARENT_BG, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_MENU_OPTIONLIST_COMMON_PAGE, SW_SHOW);
            MApp_ZUI_API_SetFocus(HWND_MENU_OPTIONLIST_ITEM1);
            _eCommonOptionMode = EN_COMMON_OPTIONLIST_NETWORK_CONFIG;
            return TRUE;

        case EN_EXE_EFFECT_POPUP:
            MApp_ZUI_API_PostMessage(MApp_ZUI_API_GetFocus(), MSG_EFFECT_POPUP, (WPARAM)NULL);
            return TRUE;
#endif
        case EN_EXE_EFFECT_SLIDEITEM:
            {
                HWND srchWnd = MApp_ZUI_API_GetFocus();
                MApp_ZUI_API_PostMessage(MApp_ZUI_API_GetFocus(), MSG_EFFECT_SLIDEITEM, srchWnd);
                return TRUE;
            }

        case EN_EXE_EFFECT_FLIPPAGE_LEFT:
        case EN_EXE_EFFECT_FLIPPAGE_RIGHT:
            {
                static HWND hwndTop[] =
                {
                #if CHANNEL_PAGE_HIDE_MTS
					HWND_MENU_CHANNEL_PAGE,//HWND_MENU_CHANNEL_PAGE,
				#else
                    HWND_MENU_CHANNEL_PAGE2,//HWND_MENU_CHANNEL_PAGE,
                #endif
                    HWND_MENU_PICTURE_PAGE,
                    HWND_MENU_SOUND_PAGE,
                    HWND_MENU_TIME_PAGE,
                    HWND_MENU_OPTION_PAGE,
                #if (ENABLE_ATV_VCHIP||ENABLE_DTV)
                    HWND_MENU_LOCK_PAGE,
                #endif
                #if (ENABLE_CUS_UI_SPEC == DISABLE) /*Creass.liu at 2012-06-02*/
                    HWND_MENU_APP_PAGE,
                #endif
                };

                HWND hwndFocus = MApp_ZUI_API_GetFocus();
                HWND hwndEffect = hwndFocus;
                HWND hwndNext = HWND_INVALID;
                EN_FLIPPAGE dir = EN_FLIPPAGE_NONE;

                while ( (hwndEffect=MApp_ZUI_API_GetParent(hwndEffect)) != HWND_MAINFRAME )
                {
                    if ( MApp_ZUI_API_GetWindowProcId(hwndEffect) == EN_ZUI_FLIPPAGE_WINPROC )
                        break;
                }
                if ( hwndEffect == HWND_MAINFRAME )
                    return TRUE;

                U32 u32Data = MApp_ZUI_API_GetWindowData(hwndEffect);
                if ( u32Data == 0 )
                    return TRUE;

                U32 i;
                for (i=0; i<COUNTOF(hwndTop); i++)
                {
                    if ( hwndTop[i] == hwndEffect )
                        break;
                }
                if ( i >= COUNTOF(hwndTop) )
                    return TRUE;

                if (act == EN_EXE_EFFECT_FLIPPAGE_LEFT)
                {
                    if ( i < 1 )
                        i = COUNTOF(hwndTop) - 1;
                #if (ENABLE_CUS_UI_SPEC == DISABLE) /*Creass.liu at 2012-06-02*/
                #if ENABLE_DTV
                    else if((hwndTop[i]==HWND_MENU_APP_PAGE)&&(!IsDTVInUse()))
                        i-=2;
                #endif
                #endif
                    else
                        i--;
                    hwndNext = hwndTop[i];
                    dir = EN_FLIPPAGE_LEFT;
                }
                else if (act == EN_EXE_EFFECT_FLIPPAGE_RIGHT)
                {
                    if ( i+1 >= COUNTOF(hwndTop) )
                        i = 0;
                 #if ENABLE_DTV
                    else if((hwndTop[i]==HWND_MENU_OPTION_PAGE)&&(!IsDTVInUse()))
                        i+=2;
                #endif
                    else
                        i++;
                    hwndNext = hwndTop[i];
                    dir = EN_FLIPPAGE_RIGHT;
                }

                HWND child, last_succ; //2008/4/12: get last successor once
                HWND listwn = hwndNext+2;
                last_succ = MApp_ZUI_API_GetLastSuccessor(listwn);
                for (child = listwn+1; child <= last_succ; child++)
                {
                    if (MApp_ZUI_API_GetParent(child) != listwn)
                        continue;

                    if (MApp_ZUI_ACT_QueryDynamicListItemStatus(child) != EN_DL_STATE_NORMAL)
                        continue;
                    else
                        break;
                }

                GUI_DATA_FLIPPAGE *windata = (GUI_DATA_FLIPPAGE *) u32Data;
                windata->pVarData->hwndCurrent = hwndEffect;
                windata->pVarData->hwndNext = hwndNext;
/*
                if(windata->pVarData->hwndNext == HWND_MENU_LOCK_PAGE)
                {   // if focus on HWND_MENU_LOCK_PAGE, set focus on HWND_MENU_LOCK_TITLE
                    // Press Enter to invoke input password dialog and to input password to use HWND_MENU_LOCK_PAGE's functions.
                    child = windata->pVarData->hwndNext +1;
                }
*/
             #if ENABLE_DTV
                if(windata->pVarData->hwndNext == HWND_MENU_LOCK_PAGE_DTV)
             #elif ENABLE_ATV_VCHIP
                if(windata->pVarData->hwndNext == HWND_MENU_LOCK_PAGE)
             #endif
                    stGenSetting.g_BlockSysSetting.u8EnterLockPage = 0;

                if(child == last_succ)
                    windata->pVarData->hwndNextFocus = windata->pVarData->hwndNext+3;
                else
                    windata->pVarData->hwndNextFocus = child;
                windata->pVarData->dir = dir;

                //MApp_ZUI_API_PostMessage(windata->pVarData->hwndCurrent, MSG_EFFECT, 0);
                MApp_ZUI_API_SendMessage(windata->pVarData->hwndCurrent, MSG_EFFECT, 0);
                //MApp_ZUI_API_InvalidateWindow(HWND_MENU_MAIN_BOTTON_INFO_BAR);
                return TRUE;
            }

       #if (ENABLE_ATV_VCHIP)
        case EN_EXE_GOTO_SUBPAGE:
        {
           HWND hwnd;
           U16 u16Temp;

            hwnd = MApp_ZUI_API_GetFocus();

            switch(hwnd)
            {
                 case HWND_MENU_LOCK_ENTER_PASSWORD:
                 MApp_ZUI_API_ShowWindow(MApp_ZUI_API_GetParent(hwnd), SW_HIDE);
                 MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_MAINSUBPAGE, SW_SHOW);
                 MApp_ZUI_API_SetFocus(HWND_MENU_LOCK_MAINSUBPAGE_ITEM_CHANGEPW);
                 break;

                case HWND_MENU_LOCK_MAINSUBPAGE_ITEM_CHANGEPW:
                    MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_MAINSUBPAGE, SW_HIDE);
                    MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_PAGE, SW_HIDE);
                    MApp_ZUI_API_ShowWindow(HWND_MENU_MASK_BACKGROUND, SW_HIDE);
                    MApp_ZUI_API_ShowWindow(HWND_MENU_TRANSPARENT_BG, SW_SHOW);
                    break;

                case HWND_MENU_LOCK_MAINSUBPAGE_ITEM_INPUTBLOCK:
                    MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_MAINSUBPAGE, SW_HIDE);
                    MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_PAGE, SW_HIDE);
                    MApp_ZUI_API_ShowWindow(HWND_MENU_MASK_BACKGROUND, SW_HIDE);
                    MApp_ZUI_API_ShowWindow(HWND_MENU_TRANSPARENT_BG, SW_SHOW);
                    MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_INPUTBLOCKSUBPAGE, SW_SHOW);

                    MApp_ZUI_API_SetFocus(HWND_MENU_LOCK_INPUTBLOCKSUBPAGE_ITEM_TV);
                    break;

                default:
                    //
                    break;

            }
             break;
       }

        case EN_EXE_GOTO_PARENTPAGE:
        {
            HWND hwnd;
            hwnd = MApp_ZUI_API_GetFocus();

            switch(hwnd)
            {
                case HWND_MENU_LOCK_MAINSUBPAGE_ITEM_CHANGEPW:
                case HWND_MENU_LOCK_MAINSUBPAGE_ITEM_SYSTEMLOCK:
                case HWND_MENU_LOCK_MAINSUBPAGE_ITEM_INPUTBLOCK:
                case HWND_MENU_LOCK_MAINSUBPAGE_ITEM_US:
                case HWND_MENU_LOCK_MAINSUBPAGE_ITEM_CANADA:
                case HWND_MENU_LOCK_MAINSUBPAGE_ITEM_RRTSETTING:
                    MApp_ZUI_API_ShowWindow(MApp_ZUI_API_GetParent(hwnd), SW_HIDE);
                    MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_PAGE_LIST, SW_SHOW);
                    MApp_ZUI_API_SetFocus(HWND_MENU_LOCK_ENTER_PASSWORD);
                    break;



                case HWND_MENU_LOCK_INPUTBLOCKSUBPAGE_ITEM_TV:
                case HWND_MENU_LOCK_INPUTBLOCKSUBPAGE_ITEM_AV:
                case HWND_MENU_LOCK_INPUTBLOCKSUBPAGE_ITEM_SVIDEO:
                case HWND_MENU_LOCK_INPUTBLOCKSUBPAGE_ITEM_COMPONENT:
                case HWND_MENU_LOCK_INPUTBLOCKSUBPAGE_ITEM_HDMI:
                case HWND_MENU_LOCK_INPUTBLOCKSUBPAGE_ITEM_PC:
                    MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_INPUTBLOCKSUBPAGE, SW_HIDE);
                    MApp_ZUI_API_ShowWindow(HWND_MENU_MASK_BACKGROUND, SW_SHOW);
                    MApp_ZUI_ACT_ShowMainMenuBackground(HWND_MENU_BOTTOM_BALL_FOCUS_LOCK);
                    MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_TITLE, SW_SHOW);
                    MApp_ZUI_API_ShowWindow(HWND_MENU_ICON_LOCK,SW_SHOW);
                    MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_MAINSUBPAGE, SW_SHOW);
                    MApp_ZUI_API_SetFocus(HWND_MENU_LOCK_MAINSUBPAGE_ITEM_INPUTBLOCK);
                    break;

                case HWND_MENU_LOCK_USSUBPAGE_ITEM_TV:
                case HWND_MENU_LOCK_USSUBPAGE_ITEM_MPAA:
                    MApp_ZUI_API_ShowWindow(MApp_ZUI_API_GetParent(hwnd), SW_HIDE);
                    MApp_ZUI_API_ShowWindow(HWND_MENU_MASK_BACKGROUND, SW_SHOW);
                    MApp_ZUI_ACT_ShowMainMenuBackground(HWND_MENU_BOTTOM_BALL_FOCUS_LOCK);
                    MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_MAINSUBPAGE, SW_SHOW);
                    MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_TITLE, SW_SHOW);
                    MApp_ZUI_API_ShowWindow(HWND_MENU_ICON_LOCK,SW_SHOW);
                    MApp_ZUI_API_SetFocus(HWND_MENU_LOCK_MAINSUBPAGE_ITEM_US);
                    break;

                case HWND_MENU_LOCK_CANADASUBPAGE_ITEM_ENG:
                case HWND_MENU_LOCK_CANADASUBPAGE_ITEM_FRE:
                    MApp_ZUI_API_ShowWindow(MApp_ZUI_API_GetParent(hwnd), SW_HIDE);
                    MApp_ZUI_API_ShowWindow(HWND_MENU_MASK_BACKGROUND, SW_SHOW);
                    MApp_ZUI_ACT_ShowMainMenuBackground(HWND_MENU_BOTTOM_BALL_FOCUS_LOCK);
                    MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_MAINSUBPAGE, SW_SHOW);
                    MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_TITLE, SW_SHOW);
                    MApp_ZUI_API_ShowWindow(HWND_MENU_ICON_LOCK,SW_SHOW);
                    MApp_ZUI_API_SetFocus(HWND_MENU_LOCK_MAINSUBPAGE_ITEM_CANADA);
                    break;

                case HWND_MENU_LOCK_VCHIPSUBPAGE_ITEM1:
                case HWND_MENU_LOCK_VCHIPSUBPAGE_ITEM2:
                case HWND_MENU_LOCK_VCHIPSUBPAGE_ITEM3:
                case HWND_MENU_LOCK_VCHIPSUBPAGE_ITEM4:
                case HWND_MENU_LOCK_VCHIPSUBPAGE_ITEM5:
                case HWND_MENU_LOCK_VCHIPSUBPAGE_ITEM6:
                case HWND_MENU_LOCK_VCHIPSUBPAGE_ITEM7:
                    MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_VCHIPSUBPAGE, SW_HIDE);
                    if(g_vchipPageType == EN_VCHIP_MPAA)
                    {
                        MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_USSUBPAGE, SW_SHOW);
                        MApp_ZUI_API_SetFocus(HWND_MENU_LOCK_USSUBPAGE_ITEM_MPAA);
                    }
                    else if(g_vchipPageType == EN_VCHIP_CANADAENG)
                    {
                        MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_CANADASUBPAGE, SW_SHOW);
                        MApp_ZUI_API_SetFocus(HWND_MENU_LOCK_CANADASUBPAGE_ITEM_ENG);
                    }
                    else if(g_vchipPageType == EN_VCHIP_CANADAFRE)
                    {
                        MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_CANADASUBPAGE, SW_SHOW);
                        MApp_ZUI_API_SetFocus(HWND_MENU_LOCK_CANADASUBPAGE_ITEM_FRE);
                    }
                    break;

                case HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVY_ALL:
                case HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVY7_ALL:
                case HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVG_ALL:
                case HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_ALL:
                case HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_ALL:
                case HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVMA_ALL:
                case HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVY7_FV:
                case HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_V:
                case HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_V:
                case HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVMA_V:
                case HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_S:
                case HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_S:
                case HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVMA_S:
                case HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_L:
                case HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_L:
                case HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVMA_L:
                case HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_D:
                case HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_D:
                    MApp_ZUI_API_ShowWindow(MApp_ZUI_API_GetParent(hwnd), SW_HIDE);
                    //MApp_ZUI_API_ShowWindow(HWND_MENU_BACKGROUND, SW_HIDE);//wait to be verified!!
                    MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_USSUBPAGE, SW_SHOW);
                    MApp_ZUI_API_SetFocus(HWND_MENU_LOCK_USSUBPAGE_ITEM_TV);
                    break;

                default:
                    //
                    break;
            }
            break;
        }   //EN_EXE_GOTO_PARENTPAGE

        case EN_EXE_CLEAR_PW:

        break;
        case EN_EXE_FUNCTION:
        {
            HWND hwnd;
            hwnd = MApp_ZUI_API_GetFocus();
            switch(hwnd)
            {
                case HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVY_ALL:
                    MApp_UiMenuFunc_SetVChip_TVRating_TV_Y_ALL();
                    MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_LOCK_TVRATINGSUBPAGE);
                    break;
                case HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVY7_ALL:
                    MApp_UiMenuFunc_SetVChip_TVRating_TV_Y7_ALL();
                    MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_LOCK_TVRATINGSUBPAGE);
                    break;
                case HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVG_ALL:
                    MApp_UiMenuFunc_SetVChip_TVRating_TV_G_ALL();
                    MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_LOCK_TVRATINGSUBPAGE);
                    break;
                case HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_ALL:
                    MApp_UiMenuFunc_SetVChip_TVRating_TV_PG_ALL();
                    MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_LOCK_TVRATINGSUBPAGE);
                    break;
                case HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_ALL:
                    MApp_UiMenuFunc_SetVChip_TVRating_TV_14_ALL();
                    MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_LOCK_TVRATINGSUBPAGE);
                    break;
                case HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVMA_ALL:
                    MApp_UiMenuFunc_SetVChip_TVRating_TV_MA_ALL();
                    MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_LOCK_TVRATINGSUBPAGE);
                    break;
                case HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVY7_FV:
                    MApp_UiMenuFunc_SetVChip_TVRating_TV_Y7_FV();
                    MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_LOCK_TVRATINGSUBPAGE);
                    break;
                case HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_V:
                    MApp_UiMenuFunc_SetVChip_TVRating_TV_PG_V();
                    MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_LOCK_TVRATINGSUBPAGE);
                    break;
                case HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_V:
                    MApp_UiMenuFunc_SetVChip_TVRating_TV_14_V();
                    MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_LOCK_TVRATINGSUBPAGE);
                    break;
                case HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVMA_V:
                    MApp_UiMenuFunc_SetVChip_TVRating_TV_MA_V();
                    MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_LOCK_TVRATINGSUBPAGE);
                    break;
                case HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_S:
                     MApp_UiMenuFunc_SetVChip_TVRating_TV_PG_S();
                    MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_LOCK_TVRATINGSUBPAGE);
                    break;
                case HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_S:
                    MApp_UiMenuFunc_SetVChip_TVRating_TV_14_S();
                    MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_LOCK_TVRATINGSUBPAGE);
                    break;
                case HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVMA_S:
                    MApp_UiMenuFunc_SetVChip_TVRating_TV_MA_S();
                    MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_LOCK_TVRATINGSUBPAGE);
                    break;
                case HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_L:
                    MApp_UiMenuFunc_SetVChip_TVRating_TV_PG_L();
                    MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_LOCK_TVRATINGSUBPAGE);
                    break;
                case HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_L:
                    MApp_UiMenuFunc_SetVChip_TVRating_TV_14_L();
                    MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_LOCK_TVRATINGSUBPAGE);
                    break;
                case HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVMA_L:
                    MApp_UiMenuFunc_SetVChip_TVRating_TV_MA_L();
                    MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_LOCK_TVRATINGSUBPAGE);
                    break;
                case HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_D:
                    MApp_UiMenuFunc_SetVChip_TVRating_TV_PG_D();
                    MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_LOCK_TVRATINGSUBPAGE);
                    break;
                case HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_D:
                    MApp_UiMenuFunc_SetVChip_TVRating_TV_14_D();
                    MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_LOCK_TVRATINGSUBPAGE);
                    break;
                default:
                    //
                    break;

            }
            break;
        }   //EN_EXE_FUNCTION

        case EN_EXE_DEC_VALUE:
        {
            HWND hwnd;
            hwnd = MApp_ZUI_API_GetFocus();
            switch(hwnd)
            {
               //3Lock page
                case HWND_MENU_LOCK_MAINSUBPAGE_ITEM_SYSTEMLOCK:
                    MApp_UiMenuFunc_AdjSystemLockMode();
                    MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_MAINSUBPAGE, SW_HIDE);
                    MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_MAINSUBPAGE, SW_SHOW);
                    MApp_ZUI_API_SetFocus(HWND_MENU_LOCK_MAINSUBPAGE_ITEM_SYSTEMLOCK);
                    //MApp_ZUI_CTL_DynamicListRefreshContent(HWND_MENU_LOCK_MAINSUBPAGE);
                    break;


                #if ENABLE_INPUT_LOCK
                case HWND_MENU_LOCK_INPUTBLOCKSUBPAGE_ITEM_TV:
                    MApp_UiMenuFunc_AdjustInputLockTV();
                    break;
                case HWND_MENU_LOCK_INPUTBLOCKSUBPAGE_ITEM_AV:
                    MApp_UiMenuFunc_AdjustInputLockAV();
                    break;
                case HWND_MENU_LOCK_INPUTBLOCKSUBPAGE_ITEM_SVIDEO:
                    MApp_UiMenuFunc_AdjustInputLockSV();
                    break;
                case HWND_MENU_LOCK_INPUTBLOCKSUBPAGE_ITEM_COMPONENT:
                    MApp_UiMenuFunc_AdjustInputLockYPbPr();
                    break;
                case HWND_MENU_LOCK_INPUTBLOCKSUBPAGE_ITEM_HDMI:
                    MApp_UiMenuFunc_AdjustInputLockHDMI();
                    break;
                case HWND_MENU_LOCK_INPUTBLOCKSUBPAGE_ITEM_PC:
                    MApp_UiMenuFunc_AdjustInputLockPC();
                    break;
               #endif
//                case HWND_MENU_LOCK_VCHIPSUBPAGE_ITEM1:
                case HWND_MENU_LOCK_VCHIPSUBPAGE_ITEM2:
                case HWND_MENU_LOCK_VCHIPSUBPAGE_ITEM3:
                case HWND_MENU_LOCK_VCHIPSUBPAGE_ITEM4:
                case HWND_MENU_LOCK_VCHIPSUBPAGE_ITEM5:
                case HWND_MENU_LOCK_VCHIPSUBPAGE_ITEM6:
                case HWND_MENU_LOCK_VCHIPSUBPAGE_ITEM7:
                    if(g_vchipPageType == EN_VCHIP_MPAA)
                    {
                        MApp_UiMenuFunc_SetVChip_Level(FALSE, VCHIP_RATING_TYPE_MPAA);
                    }
                    else if(g_vchipPageType == EN_VCHIP_CANADAENG)
                    {
                        MApp_UiMenuFunc_SetVChip_Level(FALSE, VCHIP_RATING_TYPE_CANADA_ENG);

                    }
                    else if(g_vchipPageType == EN_VCHIP_CANADAFRE)
                    {
                        MApp_UiMenuFunc_SetVChip_Level(FALSE, VCHIP_RATING_TYPE_CANADA_FRE);
                    }
                    break;
            }
            MApp_ZUI_API_InvalidateAllSuccessors(hwnd);
            return TRUE;//break;
        }//EN_EXE_DEC_VALUE

        case EN_EXE_INC_VALUE:
        {
            HWND hwnd;
            hwnd = MApp_ZUI_API_GetFocus();
            switch(hwnd)
            {
                //Lock page
                case HWND_MENU_LOCK_MAINSUBPAGE_ITEM_SYSTEMLOCK:
                    MApp_UiMenuFunc_AdjSystemLockMode();
                    MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_MAINSUBPAGE, SW_HIDE);
                    MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_MAINSUBPAGE, SW_SHOW);
                    MApp_ZUI_API_SetFocus(HWND_MENU_LOCK_MAINSUBPAGE_ITEM_SYSTEMLOCK);
                    //MApp_ZUI_CTL_DynamicListRefreshContent(HWND_MENU_LOCK_MAINSUBPAGE);
                    break;

               #if ENABLE_INPUT_LOCK
                case HWND_MENU_LOCK_INPUTBLOCKSUBPAGE_ITEM_TV:
                    MApp_UiMenuFunc_AdjustInputLockTV();
                    break;
                case HWND_MENU_LOCK_INPUTBLOCKSUBPAGE_ITEM_AV:
                    MApp_UiMenuFunc_AdjustInputLockAV();
                    break;
                case HWND_MENU_LOCK_INPUTBLOCKSUBPAGE_ITEM_SVIDEO:
                    MApp_UiMenuFunc_AdjustInputLockSV();
                    break;
                case HWND_MENU_LOCK_INPUTBLOCKSUBPAGE_ITEM_COMPONENT:
                    MApp_UiMenuFunc_AdjustInputLockYPbPr();
                    break;
                case HWND_MENU_LOCK_INPUTBLOCKSUBPAGE_ITEM_HDMI:
                    MApp_UiMenuFunc_AdjustInputLockHDMI();
                    break;
                case HWND_MENU_LOCK_INPUTBLOCKSUBPAGE_ITEM_PC:
                    MApp_UiMenuFunc_AdjustInputLockPC();
                    break;
                #endif
                case HWND_MENU_LOCK_VCHIPSUBPAGE_ITEM1:
                case HWND_MENU_LOCK_VCHIPSUBPAGE_ITEM2:
                case HWND_MENU_LOCK_VCHIPSUBPAGE_ITEM3:
                case HWND_MENU_LOCK_VCHIPSUBPAGE_ITEM4:
                case HWND_MENU_LOCK_VCHIPSUBPAGE_ITEM5:
                case HWND_MENU_LOCK_VCHIPSUBPAGE_ITEM6:
                case HWND_MENU_LOCK_VCHIPSUBPAGE_ITEM7:
                    if(g_vchipPageType == EN_VCHIP_MPAA)
                    {
                        if (hwnd != HWND_MENU_LOCK_VCHIPSUBPAGE_ITEM7)
                            MApp_UiMenuFunc_SetVChip_Level(TRUE, VCHIP_RATING_TYPE_MPAA);
                    }
                    else if(g_vchipPageType == EN_VCHIP_CANADAENG)
                    {
                        if (hwnd != HWND_MENU_LOCK_VCHIPSUBPAGE_ITEM7)
                            MApp_UiMenuFunc_SetVChip_Level(TRUE, VCHIP_RATING_TYPE_CANADA_ENG);
                    }
                    else if(g_vchipPageType == EN_VCHIP_CANADAFRE)
                    {
                        if (hwnd != HWND_MENU_LOCK_VCHIPSUBPAGE_ITEM6)
                            MApp_UiMenuFunc_SetVChip_Level(TRUE, VCHIP_RATING_TYPE_CANADA_FRE);
                    }
                    break;

            }
            MApp_ZUI_API_InvalidateAllSuccessors(hwnd);
            return TRUE;
            //break;
        }//EN_EXE_INC_VALUE

#else //2 else ENABLE_ATV_VCHIP
            case EN_EXE_ADJUST_KEYLOCK_VALUE:
                #ifdef ENABLE_BUTTON_LOCK
                stGenSetting.g_SysSetting.g_enKeyPadLock =
                            (EN_MENU_E5_KeyLock)MApp_ZUI_ACT_DecIncValue_Cycle(TRUE,
                                (U16)stGenSetting.g_SysSetting.g_enKeyPadLock,EN_E5_KeyLock_Off,(U16)(EN_E5_KeyLock_Num-1),1);
                MApp_ZUI_API_InvalidateWindow(HWND_MENU_LOCK_MAINSUBPAGE_ITEM_KEYBDLOCK_OPTION);
                #endif
                break;
            case EN_EXE_GOTO_SUBPAGE:
                hwnd = MApp_ZUI_API_GetFocus();
    		    printf("www EN_EXE_GOTO_SUBPAGE focus=[[%d]] \n",hwnd);
                switch(hwnd)
                {
                    case HWND_MENU_PICTURE_ADVANCE_PICTURE:
                        MApp_ZUI_API_ShowWindow(MApp_ZUI_API_GetParent(hwnd), SW_HIDE);
                        MApp_ZUI_API_ShowWindow(HWND_MENU_ADVANCE_PICTURE_PAGE, SW_SHOW);

                    #if ENABLE_CUS_USB_OSD
                        if(MApp_Scaler_CheckDBC_DLCAvailable() == FALSE)
                    #else
                        if(MApp_Scaler_CheckDBC_DLCAvailable() == FALSE || IsStorageInUse())
                    #endif
                        {
                            MApp_ZUI_API_EnableWindow(HWND_MENU_ADVANCE_PICTURE_PC_BACKLIGHT,TRUE);
                            MApp_ZUI_API_SetFocus(HWND_MENU_ADVANCE_PICTURE_PC_BACKLIGHT);
                        }
                        else
                        {
                            MApp_ZUI_API_SetFocus(HWND_MENU_ADVANCE_PICTURE_NOISE_REDUCTION);
                        }
                        break;
                    case HWND_MENU_PC_PICTURE_ADVANCE_PICTURE:
                        if(IsVgaInUse())
                        {
                            MApp_ZUI_API_ShowWindow(MApp_ZUI_API_GetParent(hwnd), SW_HIDE);
                            MApp_ZUI_API_ShowWindow(HWND_MENU_ADVANCE_PICTURE_PAGE, SW_SHOW);
                            {
                                MApp_ZUI_API_SetFocus(HWND_MENU_ADVANCE_PICTURE_PC_BACKLIGHT);
                            }
                        }
                        break;

                    case HWND_MENU_PICTURE_ITEM_CONTRAST:
                    case HWND_MENU_PICTURE_ITEM_BRIGHTNESS:
                    case HWND_MENU_PICTURE_ITEM_COLOR:
                    case HWND_MENU_PICTURE_ITEM_TINT:
                    case HWND_MENU_PICTURE_ITEM_SHARPNESS:
                    //case HWND_MENU_PICTURE_PC_SHARPNESS:
                    case HWND_MENU_ADVANCE_PICTURE_PC_BACKLIGHT:
                    case HWND_MENU_SOUND_BALANCE:
                    case HWND_MENU_SOUND_BASS:
                    case HWND_MENU_SOUND_TREBLE:
                    case HWND_MENU_SOUND_AUDIO_DELAY:
                        prePictureHWND = hwnd;
                        MApp_ZUI_API_ShowWindow(MApp_ZUI_API_GetParent(hwnd), SW_HIDE);
                        MApp_ZUI_API_ShowWindow(HWND_MENU_MASK_BACKGROUND, SW_HIDE);
                        MApp_ZUI_API_ShowWindow(HWND_MENU_BACKGROUND, SW_HIDE);
                        MApp_ZUI_API_ShowWindow(HWND_MENU_PICTURE_PAGE, SW_HIDE);
                        MApp_ZUI_API_ShowWindow(HWND_MENU_SOUND_PAGE, SW_HIDE); // Added by smc-steven, for Menu Spec 2.0, 20100909
                        MApp_ZUI_API_ShowWindow(HWND_MENU_TRANSPARENT_BG, SW_SHOW);
                        MApp_ZUI_API_ShowWindow(HWND_MENU_PICTURE_ADJUST_SUBMENU, SW_SHOW);

                        MApp_ZUI_API_SetFocus(HWND_MENU_PICTURE_ADJUST_BAR);
                        MApp_ZUI_API_KillTimer(HWND_MENU_BACKGROUND, 0);
                        MApp_ZUI_API_SetTimer(HWND_MENU_PICTURE_ADJUST_SUBMENU, 0, PICTURE_SETTING_TIME_OUT_MS);

                        break;
                    case HWND_MENU_PC_PICTURE_ITEM_BRIGHTNESS:
                    case HWND_MENU_PC_PICTURE_ITEM_CONTRAST:
                    case HWND_MENU_PCMODE_ADJUST_H_POS:
                    case HWND_MENU_PCMODE_ADJUST_V_POS:
                    case HWND_MENU_PCMODE_ADJUST_PHASE:
                    case HWND_MENU_PCMODE_ADJUST_CLOCK:
                        prePictureHWND = hwnd;
                        MApp_ZUI_API_ShowWindow(MApp_ZUI_API_GetParent(hwnd), SW_HIDE);
                        MApp_ZUI_API_ShowWindow(HWND_MENU_MASK_BACKGROUND, SW_HIDE);
                        MApp_ZUI_API_ShowWindow(HWND_MENU_BACKGROUND, SW_HIDE);
                        MApp_ZUI_API_ShowWindow(HWND_MENU_PC_PICTURE_PAGE, SW_HIDE);
                        MApp_ZUI_API_ShowWindow(HWND_MENU_PCMODE_ADJUST_PAGE, SW_HIDE);
                        MApp_ZUI_API_ShowWindow(HWND_MENU_TRANSPARENT_BG, SW_SHOW);
                        MApp_ZUI_API_ShowWindow(HWND_MENU_PICTURE_ADJUST_SUBMENU, SW_SHOW);

                        MApp_ZUI_API_SetFocus(HWND_MENU_PICTURE_ADJUST_BAR);
                        MApp_ZUI_API_KillTimer(HWND_MENU_BACKGROUND, 0);
                        MApp_ZUI_API_SetTimer(HWND_MENU_PICTURE_ADJUST_SUBMENU, 0, PICTURE_SETTING_TIME_OUT_MS);
                        break;
                    case HWND_MENU_PC_PICTURE_PC_ADJUST:
                        MApp_ZUI_API_ShowWindow(MApp_ZUI_API_GetParent(hwnd), SW_HIDE);
                        MApp_ZUI_API_ShowWindow(HWND_MENU_PCMODE_ADJUST_PAGE, SW_SHOW);
                        //MApp_ZUI_CTL_DynamicListRefreshContent(HWND_MENU_PCMODE_ADJUST_PAGE_LIST);
                        MApp_ZUI_API_SetFocus(HWND_MENU_PCMODE_ADJUST_AUTO_ADJUST);
                        break;

                    case HWND_MENU_OPTION_TIME_SETTING:
                        MApp_ZUI_API_ShowWindow(MApp_ZUI_API_GetParent(hwnd), SW_HIDE);
                        MApp_ZUI_API_ShowWindow(HWND_MENU_OPTION_TIME_SUBPAGE, SW_SHOW);
                        MApp_ZUI_API_SetFocus(HWND_MENU_OP_TIME_SUBPAGE_TIME);
                        break;
                    case HWND_MENU_OP_TIME_SUBPAGE_TIME:
                        {
                            ST_TIME _stTime;
                            g_u8IdleMainpageDigitKeyCount = 0;
                            MApp_ConvertSeconds2StTime(MApp_GetLocalSystemTime(),&_stTime);
                            stLMGenSetting.stMD.u16Option_Info_Year = _stTime.u16Year;
                            stLMGenSetting.stMD.u16Option_Info_Month = _stTime.u8Month;
                            stLMGenSetting.stMD.u16Option_Info_Day = _stTime.u8Day;
                            stLMGenSetting.stMD.u16Option_Info_Hour = _stTime.u8Hour;
                            stLMGenSetting.stMD.u16Option_Info_Min =_stTime.u8Min;
                            stLMGenSetting.stMD.u16Option_Info_Sec=_stTime.u8Sec;
                            MApp_ZUI_API_ShowWindow(MApp_ZUI_API_GetParent(hwnd), SW_HIDE);
                            MApp_ZUI_API_ShowWindow(HWND_MENU_TIME_PAGE, SW_SHOW);
                            MApp_ZUI_API_SetFocus(HWND_MENU_TIME_SET_DATE);
                        }
                        break;
                    case HWND_MENU_CHANNEL_PAGE2_CHANNEL:
                        MApp_ZUI_API_ShowWindow(MApp_ZUI_API_GetParent(hwnd), SW_HIDE);
                    #if 0
                        if(msAPI_ATV_IsAnyProgramLock()||(stGenSetting.g_VChipSetting.u8InputBlockItem!=0))
                    #else
                        if(msAPI_ATV_IsAnyProgramLock()
                            ||(stGenSetting.g_VChipSetting.u8InputBlockItem&INPUT_BLOCK_TV) != 0)
                    #endif
                        {
                            MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_PAGE, SW_SHOW);
                            MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_PAGE_CHECKPWD_ERROR_MSG, SW_HIDE);
                            MApp_ZUI_API_SetFocus(HWND_MENU_LOCK_ENTER_PASSWORD);
                            bEnterPW2ChannelsList = TRUE;
                        }
                        else
                        {
                            MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_PAGE, SW_SHOW);
                            MApp_ZUI_API_SetFocus(HWND_MENU_CHANNEL_AUTOTUNE);
                        }
                        break;
				    #if(UI_SKIN_SEL==UI_SKIN_1366X768X565_HAIER_CN)  // CUS_xm zHIHE 20120807 modify
					case HWND_MENU_LOCK_ENTER_PASSWORD_OPTION_3:
						MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_PAGE, SW_HIDE);
				    #else
					case HWND_MENU_LOCK_ENTER_PASSWORD:
		            #endif


						MApp_ZUI_API_ShowWindow(MApp_ZUI_API_GetParent(hwnd), SW_HIDE);

                        if(bEnterPW2ChannelsList)
                        {
                        #if CHANNEL_PAGE_HIDE_MTS
							bEnterPW2ChannelsList = FALSE;
						#endif
                            MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_PAGE, SW_SHOW);
                            MApp_ZUI_API_SetFocus(HWND_MENU_CHANNEL_AUTOTUNE);
                        }
                        else
                        {
    						MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_SUBPAGE, SW_SHOW);
                            if(msAPI_ATV_GetActiveProgramCount())
                            {
    						    MApp_ZUI_API_SetFocus(HWND_MENU_LOCK_MAINSUBPAGE_ITEM_CHANNELBLOCK);
                            }
                            else
                            {
    						    MApp_ZUI_API_SetFocus(HWND_MENU_LOCK_MAINSUBPAGE_ITEM_INPUTBLOCK);
                            }
                        }
						break;
					case HWND_MENU_LOCK_MAINSUBPAGE_ITEM_INPUTBLOCK:
						MApp_ZUI_API_ShowWindow(MApp_ZUI_API_GetParent(hwnd), SW_HIDE);
						MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_INPUT_SUBPAGE, SW_SHOW);
						MApp_ZUI_API_SetFocus(HWND_MENU_LOCK_MAINSUBPAGE_ITEM_TV);

						break;
					case HWND_MENU_LOCK_MAINSUBPAGE_ITEM_CHANGEPW:
						MApp_ZUI_API_ShowWindow(MApp_ZUI_API_GetParent(hwnd), SW_HIDE);
						MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_PAGE_CHANGEPW, SW_SHOW);
						MApp_ZUI_API_SetFocus(HWND_MENU_LOCK_NEWPSW);
						MApp_ZUI_API_ShowWindow(HWND_MENU_CONFIMNEWPSW_TEXT_1, SW_HIDE);
						break;
				#if ENABLE_3D_PROCESS
                    case HWND_MENU_OPTION_3D_MODE_SETTING:
						MApp_ZUI_API_ShowWindow(MApp_ZUI_API_GetParent(hwnd), SW_HIDE);
						MApp_ZUI_API_ShowWindow(HWND_MENU_OPTION_3D_SETUP_PAGE, SW_SHOW);
                        if((stGenSetting.g_SysSetting.en3DDetectMode == EN_3D_DETECT_AUTO) && (IsHDMIInUse() && g_HdmiPollingStatus.bIsHDMIMode))
                        {
                            MApp_ZUI_API_SetFocus(HWND_MENU_OPTION_3D_DETECT);
                        }
                        else
                        {
                            MApp_ZUI_API_SetFocus(HWND_MENU_OPTION_3D_TYPE);
                        }
						break;
			    #endif
                    case HWND_MENU_CHANNEL_INFO_CH_NAME:
						MApp_ZUI_API_ShowWindow(MApp_ZUI_API_GetParent(hwnd), SW_HIDE);
						MApp_ZUI_API_ShowWindow(HWND_MENU_PREDIT_CHANNEL_NAME_PAGE, SW_SHOW);
                        msAPI_ATV_ChannelInfoEdit_InitStationName_temp();
                        MApp_ZUI_CTL_Keyboard_SetFnEditText(HWND_MENU_PREDIT_KEYBOARD,HWND_MENU_PREDIT_INFO_MSG_BOX,HWND_MENU_PREDIT_INFO_MSG_BOX,
                            msAPI_ATV_ChannelInfoEdit_GetStationName_temp,msAPI_ATV_ChannelInfoEdit_SetStationName_temp);
                        MApp_ZUI_API_SetFocus(HWND_MENU_PREDIT_KEY_A);
                        break;
				    case HWND_MENU_TIME_ON_TIME_SETUP:
						MApp_ZUI_API_ShowWindow(MApp_ZUI_API_GetParent(hwnd), SW_HIDE);
                        if(stGenSetting.g_Time.cOnTimerSourceFlag == EN_Time_OnTimer_Source_ATV)
                        {
                            MApp_ProgramEdit_SetMode(MODE_PREDIT_ONTIME_CHANNEL);
                            MApp_ZUI_ACT_Mainpage_AppShowProgramEdit();
                        }
						MApp_ZUI_API_ShowWindow(HWND_MENU_TIME_ONTIME_PAGE_ITEM, SW_SHOW);
                        MApp_ZUI_API_SetFocus(HWND_MENU_TIME_ONTIME_PAGE_ITEM);
                        break;
                    case HWND_MENU_CHANNEL_INFO_FINETUNE:
                        {
                            MApp_ZUI_API_ShowWindow(MApp_ZUI_API_GetParent(hwnd), SW_HIDE);
                            MApp_ZUI_API_ShowWindow(HWND_MENU_MASK_BACKGROUND, SW_HIDE);
                            MApp_ZUI_API_ShowWindow(HWND_MENU_BACKGROUND, SW_HIDE);
                            MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_INFO_PAGE, SW_HIDE);
                            MApp_ZUI_API_ShowWindow(HWND_MENU_TRANSPARENT_BG, SW_SHOW);
                            MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_FINETUNE_PAGE, SW_SHOW);
                            MApp_ZUI_API_SetFocus(HWND_MENU_CHANNEL_FINETUNE_CH_FREQ_VALUE);
                            MApp_ZUI_API_KillTimer(HWND_MENU_BACKGROUND, 0);
                        }
                        break;

						default:
                        break;
                }
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_BG_MENUPAGE_INFO); //refresh mainmenu page info text
		        break;//2012-7-9 add
        case EN_EXE_INC_VALUE:
            {
                U8 i;
                hwnd = MApp_ZUI_API_GetFocus();
                switch(hwnd)
                {



                   #if(UI_SKIN_SEL==UI_SKIN_1366X768X565_HAIER_CN)  // CUS_xm zHIHE 20120807 modify
					case HWND_MENU_TOP_ICON_PICTURE_BIG:
                    case HWND_MENU_TOP_ICON_AUDIO_BIG:
                    case HWND_MENU_TOP_ICON_SETUP_BIG:
                    case HWND_MENU_TOP_ICON_CHANNEL_BIG:
                    case HWND_MENU_TOP_ICON_LOCK_BIG:
						{
                            prev_hwnd = hwnd;
                            for(i = 0; i < MAIN_MENU_ICON_NUM;i++)
                            {
                                hwnd = (hwnd==HWND_MENU_TOP_ICON_LOCK_BIG)? HWND_MENU_TOP_ICON_PICTURE_BIG: hwnd+2;
                                if(MApp_ZUI_API_IsWindowEnabled(hwnd))
                                {
                                    break;
                                }
                            }

                           // MApp_ZUI_API_ShowWindow(prev_hwnd,SW_HIDE);
                            if(!(IsDTVInUse()||IsATVInUse())&&HWND_MENU_TOP_ICON_CHANNEL_BIG==hwnd)
							  {


							     hwnd+=2;
                              }
							MApp_ZUI_API_ShowWindow(prev_hwnd-30,SW_SHOW);
							MApp_ZUI_API_ShowWindow(hwnd-30,SW_HIDE);
                            MApp_ZUI_API_SetFocus(hwnd);
                            for(i = 0; i < MAIN_MENU_ICON_NUM;i++)
                            {
                                if(prev_hwnd == icon2pageBIG[i][0])
                                {
                                    if((icon2pageBIG[i][0] == HWND_MENU_TOP_ICON_PICTURE_BIG) && IsVgaInUse())
                                    {
                                        MApp_ZUI_API_ShowWindow(HWND_MENU_PC_PICTURE_PAGE, SW_HIDE);
                                    }
                                    else
                                    {
                                        MApp_ZUI_API_ShowWindow(icon2pageBIG[i][1], SW_HIDE);
                                    }
                                }
                                if(hwnd == icon2pageBIG[i][0])
                                {
                                    if((icon2pageBIG[i][0] == HWND_MENU_TOP_ICON_PICTURE_BIG) && IsVgaInUse())
                                    {
                                        MApp_ZUI_API_ShowWindow(HWND_MENU_PC_PICTURE_PAGE, SW_SHOW);
                                    }
                                    else
                                    {
                                        MApp_ZUI_API_ShowWindow(icon2pageBIG[i][1], SW_SHOW);
                                    }
                                }
                            }
                            //MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_BG_MENUPAGE_INFO); //refresh mainmenu page info text

                            return TRUE;
                        }

                        break;

			//CUS_XM zhihe 20120807 modify
                  #else
					case HWND_MENU_TOP_ICON_PICTURE:
                    case HWND_MENU_TOP_ICON_AUDIO:
                    case HWND_MENU_TOP_ICON_SETUP:
                    case HWND_MENU_TOP_ICON_LOCK:
                    case HWND_MENU_TOP_ICON_CHANNEL:
                        #if CUS_SMC_ENABLE_HOTEL_MODE
                          if((stGenSetting.g_FactorySetting.HotelMenuHotelModeOperationEnable == ENABLE)&&stGenSetting.g_FactorySetting.HotelMenuOSDDisplayEnable == DISABLE)
							  return TRUE;
                        #endif
                        {
                            prev_hwnd = hwnd;
                            for(i = 0; i < MAIN_MENU_ICON_NUM;i++)
                            {
                                hwnd = (hwnd==HWND_MENU_TOP_ICON_LOCK)? HWND_MENU_TOP_ICON_PICTURE: hwnd+2;
                                if(MApp_ZUI_API_IsWindowEnabled(hwnd))
                                {
                                    break;
                                }
                            }

                            MApp_ZUI_API_SetFocus(hwnd);
                            for(i = 0; i < MAIN_MENU_ICON_NUM;i++)
                            {
                                if(prev_hwnd == icon2page[i][0])
                                {
                                    if((icon2page[i][0] == HWND_MENU_TOP_ICON_PICTURE) && IsVgaInUse())
                                    {
                                        MApp_ZUI_API_ShowWindow(HWND_MENU_PC_PICTURE_PAGE, SW_HIDE);
                                    }
#if CHANNEL_PAGE_HIDE_MTS
								   else if(icon2page[i][0] == HWND_MENU_TOP_ICON_CHANNEL)
								   {
#if 0
								   if(msAPI_ATV_IsAnyProgramLock()||(stGenSetting.g_VChipSetting.u8InputBlockItem!=0))
#else
								   if(msAPI_ATV_IsAnyProgramLock()
									   ||(stGenSetting.g_VChipSetting.u8InputBlockItem&INPUT_BLOCK_TV) != 0)
#endif
								   {
									   MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_PAGE, SW_HIDE);
									   bEnterPW2ChannelsList = FALSE;
								   }
									   MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_PAGE, SW_HIDE);
				
								   }
#endif
                                    else
                                    {
                                        MApp_ZUI_API_ShowWindow(icon2page[i][1], SW_HIDE);
                                    }
                                }
                                if(hwnd == icon2page[i][0])
                                {
                                    if((icon2page[i][0] == HWND_MENU_TOP_ICON_PICTURE) && IsVgaInUse())
                                    {
                                        MApp_ZUI_API_ShowWindow(HWND_MENU_PC_PICTURE_PAGE, SW_SHOW);
                                    }
								#if CHANNEL_PAGE_HIDE_MTS
                                    else if(icon2page[i][0] == HWND_MENU_TOP_ICON_CHANNEL)
                                    {
#if 0
									if(msAPI_ATV_IsAnyProgramLock()||(stGenSetting.g_VChipSetting.u8InputBlockItem!=0))
#else
									if(msAPI_ATV_IsAnyProgramLock()
										||(stGenSetting.g_VChipSetting.u8InputBlockItem&INPUT_BLOCK_TV) != 0)
#endif
									{
										MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_PAGE, SW_SHOW);
										MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_PAGE_CHECKPWD_ERROR_MSG, SW_HIDE);
										//MApp_ZUI_API_SetFocus(HWND_MENU_LOCK_ENTER_PASSWORD);
										bEnterPW2ChannelsList = TRUE;
									}
									else
									{
										MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_PAGE, SW_SHOW);
										//MApp_ZUI_API_SetFocus(HWND_MENU_CHANNEL_AUTOTUNE);
									}

									}
								#endif
                                    else
                                    {
                                        MApp_ZUI_API_ShowWindow(icon2page[i][1], SW_SHOW);
                                    }
                                }
                            }
                            MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_BG_MENUPAGE_INFO); //refresh mainmenu page info text

                            return TRUE;
                        }
                        break;
				    #endif
                    case HWND_MENU_PICTURE_ADJUST_BAR:
                        {
                            switch (prePictureHWND)
                            {
                                case HWND_MENU_PC_PICTURE_ITEM_CONTRAST:
                                case HWND_MENU_PICTURE_ITEM_CONTRAST:
                                    {
                                        MApp_ZUI_ACT_ExecuteMenuItemAction(EN_EXE_INC_CONTRAST);
                                        return TRUE;
                                    }
                                    break;
                                case HWND_MENU_PC_PICTURE_ITEM_BRIGHTNESS:
                                case HWND_MENU_PICTURE_ITEM_BRIGHTNESS:
                                    {
                                        MApp_ZUI_ACT_ExecuteMenuItemAction(EN_EXE_INC_BRIGHTNESS);
                                        return TRUE;
                                    }
                                    break;
                                case HWND_MENU_PICTURE_ITEM_SHARPNESS:
                                    {
                                        MApp_ZUI_ACT_ExecuteMenuItemAction(EN_EXE_INC_SHARPNESS);
                                        return TRUE;
                                    }
                                    break;
                                case HWND_MENU_PICTURE_ITEM_TINT:
                                    {
                                        MApp_ZUI_ACT_ExecuteMenuItemAction(EN_EXE_INC_TINT);
                                        return TRUE;
                                    }
                                    break;
                                case HWND_MENU_PICTURE_ITEM_COLOR:
                                    {
                                        MApp_ZUI_ACT_ExecuteMenuItemAction(EN_EXE_INC_SATURATION);
                                        return TRUE;
                                    }
                                    break;
                                case HWND_MENU_ADVANCE_PICTURE_PC_BACKLIGHT:
                                    {
                                        MApp_ZUI_ACT_ExecuteMenuItemAction(EN_EXE_GOTO_PICTURE_BACKLIGHT_ADJUST_INC);
                                        return TRUE;
                                    }
                                case HWND_MENU_SOUND_BALANCE:
                                    {
                                        MApp_ZUI_ACT_ExecuteMenuItemAction(EN_EXE_INC_BALANCE);
                                        return TRUE;
                                    }
                                case HWND_MENU_SOUND_BASS:
                                    {
                                        MApp_ZUI_ACT_ExecuteMenuItemAction(EN_EXE_INC_BASS);
                                        return TRUE;
                                    }
                                case HWND_MENU_SOUND_TREBLE:
                                    {
                                        MApp_ZUI_ACT_ExecuteMenuItemAction(EN_EXE_INC_TREBLE);
                                        return TRUE;
                                    }
                                case HWND_MENU_SOUND_AUDIO_DELAY:
                                    {
                                        MApp_ZUI_ACT_ExecuteMenuItemAction(EN_EXE_INC_AUDIO_DELAY);
                                        return TRUE;
                                    }
                                    break;
                                case HWND_MENU_PCMODE_ADJUST_H_POS:
                                    {
                                        MApp_ZUI_ACT_ExecuteMenuItemAction(EN_EXE_INC_PCMODE_HPOS);
                                        return TRUE;
                                    }
                                case HWND_MENU_PCMODE_ADJUST_V_POS:
                                    {
                                        MApp_ZUI_ACT_ExecuteMenuItemAction(EN_EXE_INC_PCMODE_VPOS);
                                        return TRUE;
                                    }
                                case HWND_MENU_PCMODE_ADJUST_PHASE:
                                    {
                                        MApp_ZUI_ACT_ExecuteMenuItemAction(EN_EXE_INC_PCMODE_PHASE);
                                        return TRUE;
                                    }
                                case HWND_MENU_PCMODE_ADJUST_CLOCK:
                                    {
                                        MApp_ZUI_ACT_ExecuteMenuItemAction(EN_EXE_INC_PCMODE_SIZE);
                                        return TRUE;
                                    }
                                 default:
                                    break;
                            }
                        }
                    case HWND_MENU_OPTION_HDMI_MODE:
                        MApp_ZUI_ACT_ExecuteMenuItemAction(EN_EXE_INC_HDMI_MODE);
                        return TRUE;
                    case HWND_MENU_OPTION_VIDEO_COLOR_SYSTEM:
                    case HWND_MENU_CHANNEL_INFO_COLOR_SYSTEM:
                        MApp_ZUI_ACT_ExecuteMenuItemAction(EN_EXE_INC_COLORSYSTEM_OPTION);
                        break;
                    case HWND_MENU_CHANNEL_INFO_SOUND_SYSTEM:
                        MApp_ZUI_ACT_ExecuteMenuItemAction(EN_EXE_INC_SYSTEM_OPTION);
                        break;
                    case HWND_MENU_CHANNEL_INFO_AFT:
                        if(IsATVInUse())
                        {
                            if(msAPI_ATV_ChannelInfoEdit_GetAFT())
                            {
                                msAPI_ATV_ChannelInfoEdit_SetAFT(FALSE);
                            }
                            else
                            {
                                msAPI_ATV_ChannelInfoEdit_SetAFT(TRUE);
                            }
                        }
                        break;
                    case HWND_MENU_CHANNEL_INFO_SKIP:
                        if(IsATVInUse())
                        {
                            if(msAPI_ATV_ChannelInfoEdit_GetSkip())
                            {
                                msAPI_ATV_ChannelInfoEdit_SetSkip(FALSE);
                            }
                            else
                            {
                                msAPI_ATV_ChannelInfoEdit_SetSkip(TRUE);
                            }
                        }
                        break;
                    case HWND_MENU_OPTION_POWER_STATUS:
                        stGenSetting.g_FactorySetting.u8PowerOnMode =
                            (POWERON_MODE_TYPE)MApp_ZUI_ACT_DecIncValue_Cycle(TRUE,
                                (U16)stGenSetting.g_FactorySetting.u8PowerOnMode,POWERON_MODE_SAVE,(U16)(POWERON_MODE_NUMS-1),1);
                        MApp_SaveFactorySetting();
                        break;
                    case HWND_MENU_OPTION_FREEZE_SWITCH:
                        #if (ENABLE_SW_CH_FREEZE_SCREEN)
                        if(stGenSetting.g_SysSetting.u8SwitchMode ==ATV_SWITCH_CH_FREEZE_SCREEN)
                        {
                            stGenSetting.g_SysSetting.u8SwitchMode =ATV_SWITCH_CH_BLACK_SCREEN;
                        }
                        else
                        {
                            stGenSetting.g_SysSetting.u8SwitchMode =ATV_SWITCH_CH_FREEZE_SCREEN;
                        }
                        #endif
                        break;

                    case HWND_MENU_OPTION_BLUE_SCREEN:
                        #if (ENABLE_SZ_BLUESCREEN_FUNCTION)
                        if(stGenSetting.g_SysSetting.bIsBluescreenOn == ENABLE)
                        {
                            stGenSetting.g_SysSetting.bIsBluescreenOn =DISABLE;
                        }
                        else
                        {
                            stGenSetting.g_SysSetting.bIsBluescreenOn =ENABLE;
                        }

						if(IsATVInUse() && (!IsVDHasSignal()))
						{
						    if(stGenSetting.g_SysSetting.bIsBluescreenOn)
							msAPI_Scaler_SetBlueScreen(ENABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
							else
							msAPI_Scaler_SetBlueScreen(DISABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
						}
						else
                        if(MApi_XC_IsBlackVideoEnable(MAIN_WINDOW))
                        {
                            msAPI_Scaler_SetBlueScreen(ENABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
                        }
                        #endif
                        break;
                default:
                    break;
                }
                MApp_ZUI_API_InvalidateAllSuccessors(hwnd);
            }
            break;


        case EN_EXE_DEC_VALUE:
            {
                U8 i;
                hwnd = MApp_ZUI_API_GetFocus();
                switch(hwnd)
                {
                    #if(UI_SKIN_SEL==UI_SKIN_1366X768X565_HAIER_CN)  // CUS_xm zHIHE 20120807 modify
					case HWND_MENU_TOP_ICON_PICTURE_BIG:
                    case HWND_MENU_TOP_ICON_AUDIO_BIG:
                    case HWND_MENU_TOP_ICON_SETUP_BIG:
                    case HWND_MENU_TOP_ICON_CHANNEL_BIG:
                    case HWND_MENU_TOP_ICON_LOCK_BIG:
                        {
                            prev_hwnd= hwnd;
                            for(i = 0; i < MAIN_MENU_ICON_NUM;i++)
                            {
                                hwnd = (hwnd==HWND_MENU_TOP_ICON_PICTURE_BIG)? HWND_MENU_TOP_ICON_LOCK_BIG: hwnd-2;
                                if(MApp_ZUI_API_IsWindowEnabled(hwnd))
                                {
                                    break;
                                }
                            }

							//MApp_ZUI_API_ShowWindow(prev_hwnd,SW_HIDE);

                            if(!(IsDTVInUse()||IsATVInUse())&&HWND_MENU_TOP_ICON_CHANNEL_BIG==hwnd)
							   hwnd-=2;
							MApp_ZUI_API_ShowWindow(prev_hwnd-30,SW_SHOW);
							MApp_ZUI_API_ShowWindow(hwnd-30,SW_HIDE);
                            MApp_ZUI_API_SetFocus(hwnd);

                            for(i = 0; i < MAIN_MENU_ICON_NUM;i++)
                            {
                                if(prev_hwnd == icon2pageBIG[i][0])
                                {
                                    if((icon2pageBIG[i][0] == HWND_MENU_TOP_ICON_PICTURE_BIG) && IsVgaInUse())
                                    {
                                        MApp_ZUI_API_ShowWindow(HWND_MENU_PC_PICTURE_PAGE, SW_HIDE);
                                    }
                                    else
                                    {
                                        MApp_ZUI_API_ShowWindow(icon2pageBIG[i][1], SW_HIDE);
                                    }
                                }
                                if(hwnd == icon2pageBIG[i][0])
                                {
                                    if((icon2pageBIG[i][0] == HWND_MENU_TOP_ICON_PICTURE_BIG) && IsVgaInUse())
                                    {
                                        MApp_ZUI_API_ShowWindow(HWND_MENU_PC_PICTURE_PAGE, SW_SHOW);
                                    }
                                    else
                                    {
                                        MApp_ZUI_API_ShowWindow(icon2pageBIG[i][1], SW_SHOW);
                                    }
                                }
				            }
                           // MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_BG_MENUPAGE_INFO); //refresh mainmenu page info text
                            return TRUE;
                        }
                        break;
                    #else
                    case HWND_MENU_TOP_ICON_PICTURE:
                    case HWND_MENU_TOP_ICON_AUDIO:
                    case HWND_MENU_TOP_ICON_SETUP:
                    case HWND_MENU_TOP_ICON_CHANNEL:
                    case HWND_MENU_TOP_ICON_LOCK:
                     #if CUS_SMC_ENABLE_HOTEL_MODE
                       if((stGenSetting.g_FactorySetting.HotelMenuHotelModeOperationEnable == ENABLE)&&stGenSetting.g_FactorySetting.HotelMenuOSDDisplayEnable == DISABLE)
						   return TRUE;
					 #endif
                        {
                            prev_hwnd= hwnd;
                            for(i = 0; i < MAIN_MENU_ICON_NUM;i++)
                            {
                                hwnd = (hwnd==HWND_MENU_TOP_ICON_PICTURE)? HWND_MENU_TOP_ICON_LOCK: hwnd-2;
                                if(MApp_ZUI_API_IsWindowEnabled(hwnd))
                                {
                                    break;
                                }
                            }
                            MApp_ZUI_API_SetFocus(hwnd);
                            for(i = 0; i < MAIN_MENU_ICON_NUM;i++)
                            {
                                if(prev_hwnd == icon2page[i][0])
                                {
                                    if((icon2page[i][0] == HWND_MENU_TOP_ICON_PICTURE) && IsVgaInUse())
                                    {
                                        MApp_ZUI_API_ShowWindow(HWND_MENU_PC_PICTURE_PAGE, SW_HIDE);
                                    }
#if CHANNEL_PAGE_HIDE_MTS
								   else if(icon2page[i][0] == HWND_MENU_TOP_ICON_CHANNEL)
								   {
#if 0
								   if(msAPI_ATV_IsAnyProgramLock()||(stGenSetting.g_VChipSetting.u8InputBlockItem!=0))
#else
								   if(msAPI_ATV_IsAnyProgramLock()
									   ||(stGenSetting.g_VChipSetting.u8InputBlockItem&INPUT_BLOCK_TV) != 0)
#endif
								   {
									   MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_PAGE, SW_HIDE);
									   bEnterPW2ChannelsList = FALSE;
								   }
									   MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_PAGE, SW_HIDE);
				
								   }
#endif
                                    else
                                    {
                                        MApp_ZUI_API_ShowWindow(icon2page[i][1], SW_HIDE);
                                    }
                                }
                                if(hwnd == icon2page[i][0])
                                {
                                    if((icon2page[i][0] == HWND_MENU_TOP_ICON_PICTURE) && IsVgaInUse())
                                    {
                                        MApp_ZUI_API_ShowWindow(HWND_MENU_PC_PICTURE_PAGE, SW_SHOW);
                                    }
	             #if CHANNEL_PAGE_HIDE_MTS
	             					else if(icon2page[i][0] == HWND_MENU_TOP_ICON_CHANNEL)
	             					{
	             #if 0
	             					if(msAPI_ATV_IsAnyProgramLock()||(stGenSetting.g_VChipSetting.u8InputBlockItem!=0))
	             #else
	             					if(msAPI_ATV_IsAnyProgramLock()
	             						||(stGenSetting.g_VChipSetting.u8InputBlockItem&INPUT_BLOCK_TV) != 0)
	             #endif
	             					{
	             						MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_PAGE, SW_SHOW);
	             						MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_PAGE_CHECKPWD_ERROR_MSG, SW_HIDE);
	             						//MApp_ZUI_API_SetFocus(HWND_MENU_LOCK_ENTER_PASSWORD);
	             						bEnterPW2ChannelsList = TRUE;
	             					}
	             					else
	             					{
	             						MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_PAGE, SW_SHOW);
	             						//MApp_ZUI_API_SetFocus(HWND_MENU_CHANNEL_AUTOTUNE);
	             					}
	             
	             					}
	             #endif
                                    else
                                    {
                                        MApp_ZUI_API_ShowWindow(icon2page[i][1], SW_SHOW);
                                    }
                                }
				            }
                            MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_BG_MENUPAGE_INFO); //refresh mainmenu page info text
                            return TRUE;
                        }
                        break;

			  #endif

                    case HWND_MENU_PICTURE_ADJUST_BAR:
                        {
                            switch (prePictureHWND)
                            {
                                case HWND_MENU_PC_PICTURE_ITEM_CONTRAST:
                                case HWND_MENU_PICTURE_ITEM_CONTRAST:
                                    {
                                        MApp_ZUI_ACT_ExecuteMenuItemAction(EN_EXE_DEC_CONTRAST);
                                        return TRUE;
                                    }
                                    break;
                                case HWND_MENU_PC_PICTURE_ITEM_BRIGHTNESS:
                                case HWND_MENU_PICTURE_ITEM_BRIGHTNESS:
                                    {
                                        MApp_ZUI_ACT_ExecuteMenuItemAction(EN_EXE_DEC_BRIGHTNESS);
                                        return TRUE;
                                    }
                                    break;
                                case HWND_MENU_PICTURE_ITEM_SHARPNESS:
                                    {
                                        MApp_ZUI_ACT_ExecuteMenuItemAction(EN_EXE_DEC_SHARPNESS);
                                        return TRUE;
                                    }
                                    break;
                                case HWND_MENU_PICTURE_ITEM_TINT:
                                    {
                                        MApp_ZUI_ACT_ExecuteMenuItemAction(EN_EXE_DEC_TINT);
                                        return TRUE;
                                    }
                                    break;
                                case HWND_MENU_PICTURE_ITEM_COLOR:
                                    {
                                        MApp_ZUI_ACT_ExecuteMenuItemAction(EN_EXE_DEC_SATURATION);
                                        return TRUE;
                                    }
                                    break;
                                case HWND_MENU_ADVANCE_PICTURE_PC_BACKLIGHT:
                                    {
                                        MApp_ZUI_ACT_ExecuteMenuItemAction(EN_EXE_GOTO_PICTURE_BACKLIGHT_ADJUST_DEC);
                                        return TRUE;
                                    }
                                case HWND_MENU_SOUND_BALANCE:
                                    {
                                        MApp_ZUI_ACT_ExecuteMenuItemAction(EN_EXE_DEC_BALANCE);
                                        return TRUE;
                                    }
                                case HWND_MENU_SOUND_BASS:
                                    {
                                        MApp_ZUI_ACT_ExecuteMenuItemAction(EN_EXE_DEC_BASS);
                                        return TRUE;
                                    }
                                case HWND_MENU_SOUND_TREBLE:
                                    {
                                        MApp_ZUI_ACT_ExecuteMenuItemAction(EN_EXE_DEC_TREBLE);
                                        return TRUE;
                                    }
                                case HWND_MENU_SOUND_AUDIO_DELAY:
                                    {
                                        MApp_ZUI_ACT_ExecuteMenuItemAction(EN_EXE_DEC_AUDIO_DELAY);
                                        return TRUE;
                                    }
                                    break;
                                case HWND_MENU_PCMODE_ADJUST_H_POS:
                                    {
                                        MApp_ZUI_ACT_ExecuteMenuItemAction(EN_EXE_DEC_PCMODE_HPOS);
                                        return TRUE;
                                    }
                                case HWND_MENU_PCMODE_ADJUST_V_POS:
                                    {
                                        MApp_ZUI_ACT_ExecuteMenuItemAction(EN_EXE_DEC_PCMODE_VPOS);
                                        return TRUE;
                                    }
                                case HWND_MENU_PCMODE_ADJUST_PHASE:
                                    {
                                        MApp_ZUI_ACT_ExecuteMenuItemAction(EN_EXE_DEC_PCMODE_PHASE);
                                        return TRUE;
                                    }
                                case HWND_MENU_PCMODE_ADJUST_CLOCK:
                                    {
                                        MApp_ZUI_ACT_ExecuteMenuItemAction(EN_EXE_DEC_PCMODE_SIZE);
                                        return TRUE;
                                    }
                                 default:
                                    break;
                            }
                        }

                    case HWND_MENU_OPTION_HDMI_MODE:
                        MApp_ZUI_ACT_ExecuteMenuItemAction(EN_EXE_DEC_HDMI_MODE);
                        return TRUE;
                    case HWND_MENU_OPTION_VIDEO_COLOR_SYSTEM:
                    case HWND_MENU_CHANNEL_INFO_COLOR_SYSTEM:
                        MApp_ZUI_ACT_ExecuteMenuItemAction(EN_EXE_DEC_COLORSYSTEM_OPTION);
                        break;
                    case HWND_MENU_CHANNEL_INFO_SOUND_SYSTEM:
                        MApp_ZUI_ACT_ExecuteMenuItemAction(EN_EXE_DEC_SYSTEM_OPTION);
                        break;
                    case HWND_MENU_CHANNEL_INFO_AFT:
                        if(IsATVInUse())
                        {
                            if(msAPI_ATV_ChannelInfoEdit_GetAFT())
                            {
                                msAPI_ATV_ChannelInfoEdit_SetAFT(FALSE);
                            }
                            else
                            {
                                msAPI_ATV_ChannelInfoEdit_SetAFT(TRUE);
                            }
                        }
                        break;
                    case HWND_MENU_CHANNEL_INFO_SKIP:
                        if(IsATVInUse())
                        {
                            if(msAPI_ATV_ChannelInfoEdit_GetSkip())
                            {
                                msAPI_ATV_ChannelInfoEdit_SetSkip(FALSE);
                            }
                            else
                            {
                                msAPI_ATV_ChannelInfoEdit_SetSkip(TRUE);
                            }
                        }
                        break;
                    case HWND_MENU_OPTION_POWER_STATUS:
                        stGenSetting.g_FactorySetting.u8PowerOnMode =
                            (POWERON_MODE_TYPE)MApp_ZUI_ACT_DecIncValue_Cycle(FALSE,
                                (U16)stGenSetting.g_FactorySetting.u8PowerOnMode,POWERON_MODE_SAVE,(U16)(POWERON_MODE_NUMS-1),1);
                        MApp_SaveFactorySetting();
                        break;
                    case HWND_MENU_OPTION_FREEZE_SWITCH:
                        #if (ENABLE_SW_CH_FREEZE_SCREEN)
                        if(stGenSetting.g_SysSetting.u8SwitchMode ==ATV_SWITCH_CH_FREEZE_SCREEN)
                        {
                            stGenSetting.g_SysSetting.u8SwitchMode =ATV_SWITCH_CH_BLACK_SCREEN;
                        }
                        else
                        {
                            stGenSetting.g_SysSetting.u8SwitchMode =ATV_SWITCH_CH_FREEZE_SCREEN;
                        }
                        #endif
                        break;
                    case HWND_MENU_OPTION_BLUE_SCREEN:
                        #if (ENABLE_SZ_BLUESCREEN_FUNCTION)
                        if(stGenSetting.g_SysSetting.bIsBluescreenOn == ENABLE)
                        {
                            stGenSetting.g_SysSetting.bIsBluescreenOn =DISABLE;
                        }
                        else
                        {
                            stGenSetting.g_SysSetting.bIsBluescreenOn =ENABLE;
                        }
						if(IsATVInUse() && (!IsVDHasSignal()))
						{
						    if(stGenSetting.g_SysSetting.bIsBluescreenOn)
							msAPI_Scaler_SetBlueScreen(ENABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
							else
							msAPI_Scaler_SetBlueScreen(DISABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
						}
						else
                        if(MApi_XC_IsBlackVideoEnable(MAIN_WINDOW))
                        {
                            msAPI_Scaler_SetBlueScreen(ENABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
                        }
                        #endif
                        break;

                    default:
                        break;
                }
                MApp_ZUI_API_InvalidateAllSuccessors(hwnd);
            }
            break;
        case EN_EXE_GOTO_PARENTPAGE:
            {
                hwnd = MApp_ZUI_API_GetFocus();
                //printf("www EN_EXE_GOTO_PARENTPAGE focus=[[%d]]",hwnd);
                switch(hwnd)
                {

                    case HWND_MENU_PICTURE_ADJUST_BAR:
                        {
                            MApp_ZUI_API_ShowWindow(HWND_MENU_PICTURE_ADJUST_SUBMENU, SW_HIDE);
							MApp_ZUI_API_ShowWindow(HWND_MENU_BACKGROUND, SW_SHOW);

                            MApp_ZUI_API_ShowWindow(HWND_MENU_MASK_BACKGROUND, SW_SHOW);
                            MApp_ZUI_ACT_InitializeMainMenu();

                            switch(MApp_ZUI_API_GetParent(prePictureHWND))
                            {
                                case HWND_MENU_PC_PICTURE_PAGE_LIST:
                                case HWND_MENU_PCMODE_ADJUST_PAGE_LIST:
                                case HWND_MENU_PICTURE_PAGE_LIST:
                                case HWND_MENU_ADVANCE_PICTURE_PAGE_LIST:
									#if(UI_SKIN_SEL==UI_SKIN_1366X768X565_HAIER_CN)  // CUS_xm zHIHE 20120807 modify
									MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_PICTURE_BIG,FALSE);
									MApp_ZUI_API_ShowWindow(HWND_MENU_TOP_ICON_PICTURE,SW_HIDE);
                                    #else
                                    MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_PICTURE,FALSE);
									#endif
                                    break;
                                case HWND_MENU_SOUND_PAGE_LIST:
									#if(UI_SKIN_SEL==UI_SKIN_1366X768X565_HAIER_CN)  // CUS_xm zHIHE 20120807 modify
									MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_AUDIO_BIG,FALSE);
									MApp_ZUI_API_ShowWindow(HWND_MENU_TOP_ICON_AUDIO,SW_HIDE);
                                    #else
                                    MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_AUDIO,FALSE);
									#endif
                                    break;
                                default:
                                    break;
                            }
                            MApp_ZUI_API_ShowWindow(MApp_ZUI_API_GetParent(prePictureHWND), SW_SHOW);
                            MApp_ZUI_API_SetFocus(prePictureHWND);
                            break;
                        }
                    case HWND_MENU_CHANNEL_SCAN_PAGE_PROGRESS_BAR:
                        if(msAPI_Tuner_IsTuningProcessorBusy())
                        {
                            return TRUE;
                        }
                        else
                        {
                            MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_SCAN_PAGE, SW_HIDE);
                            MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_PAGE, SW_SHOW);
                           #if ENABLE_CUS_UPDATE_SCAN
                            if(g_bGotoUpdateScan)
                            {
                                g_bGotoUpdateScan = FALSE;
                                MApp_ZUI_API_SetFocus(HWND_MENU_CHANNEL_UPDATE_SCAN);
                            }
                            else
                           #endif
                            {
                                MApp_ZUI_API_SetFocus(HWND_MENU_CHANNEL_AUTOTUNE);
                            }
                        }
                        break;

                    case HWND_MENU_PREDIT_ITEM0:
                    case HWND_MENU_PREDIT_ITEM1:
                    case HWND_MENU_PREDIT_ITEM2:
                    case HWND_MENU_PREDIT_ITEM3:
                    case HWND_MENU_PREDIT_ITEM4:
                    case HWND_MENU_PREDIT_ITEM5:
                        MApp_ZUI_API_ShowWindow(HWND_MENU_PREDIT_CHANNEL_LIST_PAGE, SW_HIDE);
                        if(_eProgramEditMode == MODE_PREDIT_BLOCK)
                        {
                            MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_SUBPAGE, SW_SHOW);
                            MApp_ZUI_API_SetFocus(HWND_MENU_LOCK_MAINSUBPAGE_ITEM_CHANNELBLOCK);
                        }
                        else if(_eProgramEditMode == MODE_PREDIT_ONTIME_CHANNEL)
                        {
                            MApp_ZUI_API_ShowWindow(HWND_MENU_TIME_ONTIME_PAGE, SW_HIDE);
                            MApp_ZUI_API_ShowWindow(HWND_MENU_TIME_PAGE, SW_SHOW);
                            MApp_ZUI_API_SetFocus(HWND_MENU_TIME_ON_TIME_SETUP);
                        }
                        else
                        {
                            MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_PAGE, SW_SHOW);
                            if(MApp_Mainpage_Predit_QueryChCount() == 0)
                            MApp_ZUI_API_SetFocus(HWND_MENU_CHANNEL_AUTOTUNE);
                            else
                            MApp_ZUI_API_SetFocus(HWND_MENU_CHANNEL_PROGRAM_EDIT);
                        }
                        break;
					case HWND_MENU_LOCK_CONFIMNEWPSW:
                        MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_PAGE_CHANGEPW, SW_HIDE);
						MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_SUBPAGE, SW_SHOW);
                        MApp_ZUI_API_SetFocus(HWND_MENU_LOCK_MAINSUBPAGE_ITEM_CHANGEPW);
						break;
                    case HWND_MENU_CHANNEL_INFO_CH_NUM:
                    case HWND_MENU_CHANNEL_INFO_CH_NAME:
                    case HWND_MENU_CHANNEL_INFO_FREQ:
                    case HWND_MENU_CHANNEL_INFO_COLOR_SYSTEM:
                    case HWND_MENU_CHANNEL_INFO_SOUND_SYSTEM:
                    case HWND_MENU_CHANNEL_INFO_AFT:
                    case HWND_MENU_CHANNEL_INFO_FINETUNE:
                    case HWND_MENU_CHANNEL_INFO_SKIP:
                    case HWND_MENU_CHANNEL_INFO_SAVE_CHANGED:
                        {
                            MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_INFO_PAGE, SW_HIDE);
                            //MApp_ZUI_ACT_ShowMainMenuBackground(HWND_MENU_BOTTOM_BALL_FOCUS_OPTION);
                            MApp_ZUI_API_ShowWindow(HWND_MENU_PREDIT_CHANNEL_LIST_PAGE, SW_SHOW);
                            MApp_ZUI_ACT_Mainpage_AppShowProgramEdit();
                            if(IsATVInUse() && (MApp_IsSrcHasSignal(MAIN_WINDOW)))
                            {
                                if(msAPI_ATV_ChannelInfoEdit_GetVideoStandard() != msAPI_ATV_GetVideoStandardOfProgram(msAPI_ATV_GetCurrentProgramNumber()))
                                {
                                    AVD_VideoStandardType eVideoStandard;
                                    #if (TV_FREQ_SHIFT_CLOCK)
                                    msAPI_Tuner_Patch_ResetTVShiftClk();
                                    #endif
                                    eVideoStandard = msAPI_ATV_GetVideoStandardOfProgram(msAPI_ATV_GetCurrentProgramNumber());

                                    if(eVideoStandard == E_VIDEOSTANDARD_AUTO)
                                    {
                                        AVD_VideoStandardType eStandard;
                                        MDrv_AVD_SetVideoStandard(eVideoStandard, FALSE);
                                        msAPI_AVD_StartAutoStandardDetection();
                                        eStandard = msAPI_AVD_GetStandardDetection();
                                    }
                                    else
                                    {
                                        msAPI_AVD_ForceVideoStandard(eVideoStandard);
                                        MDrv_AVD_SetVideoStandard(eVideoStandard, FALSE );
                                    }
                                }
                            }
                            MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_BG_MENUPAGE_INFO); //refresh mainmenu page info text
                            return TRUE;
                        }
                        break;
				    case HWND_MENU_TIME_ONTIME_PAGE_ITEM:
                        {
                            MApp_ZUI_API_ShowWindow(HWND_MENU_TIME_ONTIME_PAGE, SW_HIDE);
                            //MApp_ZUI_ACT_ShowMainMenuBackground(HWND_MENU_BOTTOM_BALL_FOCUS_OPTION);
                            if(stGenSetting.g_Time.cOnTimerSourceFlag == EN_Time_OnTimer_Source_ATV)
                            {
                                MApp_ZUI_API_ShowWindow(HWND_MENU_PREDIT_CHANNEL_LIST_PAGE, SW_HIDE);
                            }
                            MApp_ZUI_API_ShowWindow(HWND_MENU_TIME_PAGE, SW_SHOW);
                            MApp_ZUI_API_SetFocus(HWND_MENU_TIME_ON_TIME_SETUP);
                            MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_BG_MENUPAGE_INFO); //refresh mainmenu page info text
                            return TRUE;
                        }
                        break;
                    case HWND_MENU_CHANNEL_FINETUNE_CH_FREQ_VALUE:
                        msAPI_Tuner_SetAFTNeeded(TRUE);
                        MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_FINETUNE_PAGE, SW_HIDE);
                        MApp_ZUI_API_ShowWindow(HWND_MENU_BACKGROUND, SW_SHOW);
                        MApp_ZUI_API_ShowWindow(HWND_MENU_MASK_BACKGROUND, SW_SHOW);
                        MApp_ZUI_ACT_InitializeMainMenu();
			 #if(UI_SKIN_SEL==UI_SKIN_1366X768X565_HAIER_CN)                         //CUS_XM zhihe  20120807 modify
			   MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_CHANNEL_BIG,FALSE);
			 #endif
                        MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_CHANNEL,FALSE);

                        MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_INFO_PAGE, SW_SHOW);
                        MApp_ZUI_API_SetFocus(HWND_MENU_CHANNEL_INFO_FINETUNE);
                        break;

                    default:
                        break;
                  }
            }
            MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_BG_MENUPAGE_INFO); //refresh mainmenu page info text
            break;
#endif  //2 endif ENABLE_ATV_VCHIP

        case EN_EXE_SPECIAL_CASE:
            {
                hwnd = MApp_ZUI_API_GetFocus();
                MApp_ZUI_API_EnableWindow(hwnd, FALSE);
                switch(hwnd)
                {
                    #if(UI_SKIN_SEL==UI_SKIN_1366X768X565_HAIER_CN)  // CUS_xm zHIHE 20120807 modify
					case HWND_MENU_TOP_ICON_PICTURE_BIG:
                    #endif
                    case HWND_MENU_TOP_ICON_PICTURE:
                        if(IsVgaInUse())
                        {
                            MApp_ZUI_API_SetFocus(HWND_MENU_PC_PICTURE_ITEM_BRIGHTNESS);
                        }
                        else
                        {
                            MApp_ZUI_API_SetFocus(HWND_MENU_PICTURE_PICMODE);
                        }
                        break;
				    #if(UI_SKIN_SEL==UI_SKIN_1366X768X565_HAIER_CN)  // CUS_xm zHIHE 20120807 modify
					case HWND_MENU_TOP_ICON_AUDIO_BIG:
                    #endif
                    case HWND_MENU_TOP_ICON_AUDIO:
                        MApp_ZUI_API_SetFocus(HWND_MENU_SOUND_SNDMODE);
                        break;
					#if(UI_SKIN_SEL==UI_SKIN_1366X768X565_HAIER_CN)  // CUS_xm zHIHE 20120807 modify
					case HWND_MENU_TOP_ICON_SETUP_BIG:
                    #endif
                    case HWND_MENU_TOP_ICON_SETUP:
                        MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_OPTION_PAGE_LIST,HWND_MENU_OPTION_OSD_LANG);
                        break;
					#if(UI_SKIN_SEL==UI_SKIN_1366X768X565_HAIER_CN)  // CUS_xm zHIHE 20120807 modify
					case HWND_MENU_TOP_ICON_LOCK_BIG:
                    #endif
                    case HWND_MENU_TOP_ICON_LOCK:
                        bEnterPW2ChannelsList = FALSE;
                        MApp_ZUI_API_SetFocus(HWND_MENU_LOCK_ENTER_PASSWORD);
                        break;
					#if(UI_SKIN_SEL==UI_SKIN_1366X768X565_HAIER_CN)  // CUS_xm zHIHE 20120807 modify
					case HWND_MENU_TOP_ICON_CHANNEL_BIG:
                    #endif
                    case HWND_MENU_TOP_ICON_CHANNEL:
					 #if CHANNEL_PAGE_HIDE_MTS
#if 0
						 if(msAPI_ATV_IsAnyProgramLock()||(stGenSetting.g_VChipSetting.u8InputBlockItem!=0))
#else
						 //if(msAPI_ATV_IsAnyProgramLock()
						//	 ||(stGenSetting.g_VChipSetting.u8InputBlockItem&INPUT_BLOCK_TV) != 0)
						if(bEnterPW2ChannelsList)
#endif
						 {
 						   MApp_ZUI_API_SetFocus(HWND_MENU_LOCK_ENTER_PASSWORD);
						 }
						 else
					 	   MApp_ZUI_API_SetFocus(HWND_MENU_CHANNEL_AUTOTUNE);
					 #else
                        if(MApp_AUDIO_IsSifSoundModeExist(SOUND_MTS_STEREO))
                        {
                            MApp_ZUI_API_SetFocus(HWND_MENU_CHANNEL_PAGE2_MTS);
                        }
                        else
                        {
                            MApp_ZUI_API_SetFocus(HWND_MENU_CHANNEL_PAGE2_CHANNEL);
                        }
                        break;
					  #endif
                    default:
                        break;
                }
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_BG_MENUPAGE_INFO); //refresh mainmenu page info text
            }
            break;
        case EN_EXE_ADJUST_BAR_ITEM_UP:
            {
                BOOLEAN bIsShowTintAdjustBar = FALSE;
                if(IsAVInUse() || IsATVInUse())
                {
                    if((mvideo_vd_get_videosystem() == SIG_NTSC) || (mvideo_vd_get_videosystem() == SIG_NTSC_443))
                    {
                        bIsShowTintAdjustBar = TRUE;
                    }
                }

                if(HWND_MENU_PICTURE_ADJUST_BAR == MApp_ZUI_API_GetFocus())
                {
                    //////FOR VIDEO ITEM
                    if(prePictureHWND == HWND_MENU_PICTURE_ITEM_BRIGHTNESS)
                    {
                        if(bIsShowTintAdjustBar)
                        {
                            prePictureHWND = HWND_MENU_PICTURE_ITEM_TINT;
                        }
                        else
                        {
                            if(MApp_Scaler_CheckDBC_DLCAvailable())
                            {
                                prePictureHWND = HWND_MENU_PICTURE_ITEM_SHARPNESS;
                            }
                            else
                            {
                                if((IsHDMIInUse()&&(g_HdmiPollingStatus.bIsHDMIMode == TRUE) && (ST_VIDEO.eAspectRatio == EN_AspectRatio_point_to_point))
                                #if VGA_HDMI_YUV_POINT_TO_POINT
                                || (IsHDMIInUse()&&MDrv_PQ_Check_PointToPoint_Mode() && (ST_VIDEO.eAspectRatio == EN_AspectRatio_point_to_point))
                                #endif
                                )
                                {
                                    prePictureHWND = HWND_MENU_PICTURE_ITEM_CONTRAST;
                                }
                                else
                                {
                                    prePictureHWND = HWND_MENU_PICTURE_ITEM_COLOR;
                                }
                            }

                        }
                    }
                    else if(prePictureHWND == HWND_MENU_PICTURE_ITEM_CONTRAST)
                    {
                        prePictureHWND = HWND_MENU_PICTURE_ITEM_BRIGHTNESS;

                    }
                    else if(prePictureHWND == HWND_MENU_PICTURE_ITEM_COLOR)
                    {
                        prePictureHWND = HWND_MENU_PICTURE_ITEM_CONTRAST;

                    }
                    else if(prePictureHWND == HWND_MENU_PICTURE_ITEM_SHARPNESS)
                    {
                        prePictureHWND = HWND_MENU_PICTURE_ITEM_COLOR;

                    }
                    else if((prePictureHWND == HWND_MENU_PICTURE_ITEM_TINT) && (bIsShowTintAdjustBar == TRUE))
                    {
                        if(MApp_Scaler_CheckDBC_DLCAvailable())
                        {
                            prePictureHWND = HWND_MENU_PICTURE_ITEM_SHARPNESS;
                        }
                        else
                        {
                            prePictureHWND = HWND_MENU_PICTURE_ITEM_COLOR;
                        }

                    }
                    else if(prePictureHWND == HWND_MENU_ADVANCE_PICTURE_PC_BACKLIGHT)
                    {
                        prePictureHWND = HWND_MENU_ADVANCE_PICTURE_PC_BACKLIGHT;

                    }
                    ////////For AUDIO ITEM
                    else if(prePictureHWND == HWND_MENU_SOUND_BALANCE)
                    {
					  if(stGenSetting.g_SoundSetting.SoundMode==EN_SoundMode_User)
                        prePictureHWND = HWND_MENU_SOUND_TREBLE;

                    }
                    else if(prePictureHWND == HWND_MENU_SOUND_TREBLE)
                    {
                        prePictureHWND = HWND_MENU_SOUND_BASS;

                    }
                    else if(prePictureHWND == HWND_MENU_SOUND_BASS)
                    {
                        prePictureHWND = HWND_MENU_SOUND_BALANCE;

                    }
                    /////////////FOR PC adjust
                    else if(prePictureHWND == HWND_MENU_PCMODE_ADJUST_H_POS)
                    {
                        prePictureHWND = HWND_MENU_PCMODE_ADJUST_CLOCK;

                    }
                    else if(prePictureHWND == HWND_MENU_PCMODE_ADJUST_V_POS)
                    {
                        prePictureHWND = HWND_MENU_PCMODE_ADJUST_H_POS;

                    }
                    else if(prePictureHWND == HWND_MENU_PCMODE_ADJUST_PHASE)
                    {
                        prePictureHWND = HWND_MENU_PCMODE_ADJUST_V_POS;

                    }
                    else if(prePictureHWND == HWND_MENU_PCMODE_ADJUST_CLOCK)
                    {
                        prePictureHWND = HWND_MENU_PCMODE_ADJUST_PHASE;

                    }
                    /////////////FOR PC PICTURE adjust
                    else if(prePictureHWND == HWND_MENU_PC_PICTURE_ITEM_BRIGHTNESS)
                    {
                        prePictureHWND = HWND_MENU_PC_PICTURE_ITEM_CONTRAST;

                    }
                    else if(prePictureHWND == HWND_MENU_PC_PICTURE_ITEM_CONTRAST)
                    {
                        prePictureHWND = HWND_MENU_PC_PICTURE_ITEM_BRIGHTNESS;

                    }
                    else
                    {
                        prePictureHWND = HWND_MENU_PICTURE_ITEM_BRIGHTNESS;
                    }
                    MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_PICTURE_ADJUST_BAR);
                }
            }
            break;
        case EN_EXE_ADJUST_BAR_ITEM_DOWN:
            {
                BOOLEAN bIsShowTintAdjustBar = FALSE;
                if(IsAVInUse() || IsATVInUse())
                {
                    if((mvideo_vd_get_videosystem() == SIG_NTSC) || (mvideo_vd_get_videosystem() == SIG_NTSC_443))
                    {
                        bIsShowTintAdjustBar = TRUE;
                    }
                }

                if(HWND_MENU_PICTURE_ADJUST_BAR == MApp_ZUI_API_GetFocus())
                {
                    //////FOR VIDEO ITEM
                    if(prePictureHWND == HWND_MENU_PICTURE_ITEM_BRIGHTNESS)
                    {
                        prePictureHWND = HWND_MENU_PICTURE_ITEM_CONTRAST;

                    }
                    else if(prePictureHWND == HWND_MENU_PICTURE_ITEM_CONTRAST)
                    {
                        if((IsHDMIInUse()&&(g_HdmiPollingStatus.bIsHDMIMode == TRUE) && (ST_VIDEO.eAspectRatio == EN_AspectRatio_point_to_point))
                        #if VGA_HDMI_YUV_POINT_TO_POINT
                        || (IsHDMIInUse()&&MDrv_PQ_Check_PointToPoint_Mode() && (ST_VIDEO.eAspectRatio == EN_AspectRatio_point_to_point))
                        #endif
                        )
                        {
                            prePictureHWND = HWND_MENU_PICTURE_ITEM_BRIGHTNESS;
                        }
                        else
                        {
                            prePictureHWND = HWND_MENU_PICTURE_ITEM_COLOR;
                        }

                    }
                    else if(prePictureHWND == HWND_MENU_PICTURE_ITEM_COLOR)
                    {
                        if(MApp_Scaler_CheckDBC_DLCAvailable())
                        {
                            prePictureHWND = HWND_MENU_PICTURE_ITEM_SHARPNESS;
                        }
                        else
                        {
                            prePictureHWND = HWND_MENU_PICTURE_ITEM_BRIGHTNESS;
                        }

                    }
                    else if(prePictureHWND == HWND_MENU_PICTURE_ITEM_SHARPNESS)
                    {
                        if(bIsShowTintAdjustBar == TRUE)
                        {
                            prePictureHWND = HWND_MENU_PICTURE_ITEM_TINT;
                        }
                        else
                        {
                            prePictureHWND = HWND_MENU_PICTURE_ITEM_BRIGHTNESS;
                        }
                    }
                    else if((prePictureHWND == HWND_MENU_PICTURE_ITEM_TINT) && (bIsShowTintAdjustBar == TRUE))
                    {
                        prePictureHWND = HWND_MENU_PICTURE_ITEM_BRIGHTNESS;

                    }
                    else if(prePictureHWND == HWND_MENU_ADVANCE_PICTURE_PC_BACKLIGHT)
                    {
                        prePictureHWND = HWND_MENU_ADVANCE_PICTURE_PC_BACKLIGHT;

                    }
                    ////////For AUDIO ITEM
                    else if(prePictureHWND == HWND_MENU_SOUND_BALANCE)
                    {
                      if(stGenSetting.g_SoundSetting.SoundMode==EN_SoundMode_User)
                        prePictureHWND = HWND_MENU_SOUND_BASS;

                    }
                    else if(prePictureHWND == HWND_MENU_SOUND_BASS)
                    {
                        prePictureHWND = HWND_MENU_SOUND_TREBLE;

                    }
                    else if(prePictureHWND == HWND_MENU_SOUND_TREBLE)
                    {
                        prePictureHWND = HWND_MENU_SOUND_BALANCE;

                    }                /////////////FOR PC adjust
                    else if(prePictureHWND == HWND_MENU_PCMODE_ADJUST_H_POS)
                    {
                        prePictureHWND = HWND_MENU_PCMODE_ADJUST_V_POS;

                    }
                    else if(prePictureHWND == HWND_MENU_PCMODE_ADJUST_V_POS)
                    {
                        prePictureHWND = HWND_MENU_PCMODE_ADJUST_PHASE;

                    }
                    else if(prePictureHWND == HWND_MENU_PCMODE_ADJUST_PHASE)
                    {
                        prePictureHWND = HWND_MENU_PCMODE_ADJUST_CLOCK;

                    }
                    else if(prePictureHWND == HWND_MENU_PCMODE_ADJUST_CLOCK)
                    {
                        prePictureHWND = HWND_MENU_PCMODE_ADJUST_H_POS;

                    }
                    /////////////FOR PC PICTURE adjust
                    else if(prePictureHWND == HWND_MENU_PC_PICTURE_ITEM_BRIGHTNESS)
                    {
                        prePictureHWND = HWND_MENU_PC_PICTURE_ITEM_CONTRAST;

                    }
                    else if(prePictureHWND == HWND_MENU_PC_PICTURE_ITEM_CONTRAST)
                    {
                        prePictureHWND = HWND_MENU_PC_PICTURE_ITEM_BRIGHTNESS;

                    }
                    else
                    {
                        prePictureHWND = HWND_MENU_PICTURE_ITEM_BRIGHTNESS;
                    }
                    MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_PICTURE_ADJUST_BAR);
                }
            }
            break;

        case EN_EXE_INC_OSD_LAN:
        case EN_EXE_DEC_OSD_LAN:
            {
               #if (ENABLE_CUS_OSD_LANGUAGE && (CUS_AREA_ID == AREA_ID_CHINA))
			   sds
			   if(stGenSetting.g_SysSetting.Language == LANGUAGE_ENGLISH)
			   {
				   stGenSetting.g_SysSetting.Language = LANGUAGE_RUSSIAN;
			   g_bFactoryLanguageBack=LANGUAGE_RUSSIAN;
			    printf("LANGUAGE_RUSSIAN\r\n");
			   }
			   else if(stGenSetting.g_SysSetting.Language == LANGUAGE_RUSSIAN)
			   {
				   stGenSetting.g_SysSetting.Language = LANGUAGE_GERMAN;
			   g_bFactoryLanguageBack=LANGUAGE_GERMAN;
			   printf("LANGUAGE_GERMAN\r\n");
			   }
			   else if(stGenSetting.g_SysSetting.Language == LANGUAGE_GERMAN)
			   {
				   stGenSetting.g_SysSetting.Language = LANGUAGE_ITALIAN;
			   g_bFactoryLanguageBack=LANGUAGE_ITALIAN;
			   printf("LANGUAGE_ITALIAN\r\n");
			   }
			   else if(stGenSetting.g_SysSetting.Language == LANGUAGE_ITALIAN)
			   {
				   stGenSetting.g_SysSetting.Language = LANGUAGE_FRENCH;
			   g_bFactoryLanguageBack=LANGUAGE_FRENCH;
			   printf("LANGUAGE_FRENCH\r\n");
			   }
			   else if(stGenSetting.g_SysSetting.Language == LANGUAGE_FRENCH)
			   {
				   stGenSetting.g_SysSetting.Language = LANGUAGE_CHINESE;
			   g_bFactoryLanguageBack=LANGUAGE_CHINESE;
			   printf("LANGUAGE_CHINESE\r\n");
			   }
			   else
			   {
				   stGenSetting.g_SysSetting.Language = LANGUAGE_ENGLISH;
				   g_bFactoryLanguageBack=LANGUAGE_ENGLISH;
				   printf("LANGUAGE_ENGLISH\r\n");
			   }
               #elif (ENABLE_CUS_OSD_LANGUAGE && (CUS_AREA_ID ==AREA_ID_INDIA))
			   if(stGenSetting.g_SysSetting.Language == LANGUAGE_ENGLISH)
			   {
				   stGenSetting.g_SysSetting.Language = LANGUAGE_CHINESE;
			   g_bFactoryLanguageBack=LANGUAGE_CHINESE;
			    printf("LANGUAGE_RUSSIAN\r\n");
			   }else
			   	{
			   				   stGenSetting.g_SysSetting.Language = LANGUAGE_ENGLISH;
				   g_bFactoryLanguageBack=LANGUAGE_ENGLISH;
				   printf("LANGUAGE_ENGLISH\r\n");
			   	}
               #else
                stGenSetting.g_SysSetting.Language =
                (EN_LANGUAGE)MApp_ZUI_ACT_DecIncValue_Cycle(act == EN_EXE_INC_OSD_LAN , stGenSetting.g_SysSetting.Language, LANGUAGE_MENU_MIN, LANGUAGE_MENU_MAX, 1);
               #endif
                SET_OSD_MENU_LANGUAGE(GET_OSD_MENU_LANGUAGE());
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_OPTION_PAGE);
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_BACKGROUND);
                {
                    if(u8CoexistWinType == COWIN_ID_MUTE)
                    {
                        if(msAPI_AUD_IsAudioMutedByUser()==1)
                        {
                            MApp_UiMenu_MuteWin_Hide();
                            MApp_UiMenu_MuteWin_Show();
                        }
                        else
                        {
                            MApp_UiMenu_MuteWin_Hide();
                        }
                    }
                }
            }
            break;
			#if(UI_SKIN_SEL==UI_SKIN_1366X768X565_HAIER_CN)  // CUS_xm zHIHE 20120811 modify
			case EN_EXE_INC_TTX_LAN:
			case EN_EXE_DEC_TTX_LAN:

				stGenSetting.g_SysSetting.TTX_Language= (TT_Charset_Group)MApp_ZUI_ACT_DecIncValue_Cycle(
                act==EN_EXE_INC_TTX_LAN,
                stGenSetting.g_SysSetting.TTX_Language, TT_Charset_Group_West,TT_Charset_Group_Arabic, 1);
				SET_TTX_LANGUAGE(stGenSetting.g_SysSetting.TTX_Language);
				MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_OPTION_PAGE);
                break;
			#endif
            case EN_EXE_ATV_MANUAL_SCAN_SHOW_INFO:
            case EN_EXE_REPAINT_AUTOTUNING_PROGRESS:
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_CHANNEL_SCAN_PAGE_PROGRESS_BAR);
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_CHANNEL_SCAN_PAGE_SCAN_STATE_VALUE);
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_CHANNEL_SCAN_PAGE_FREQ_VALUE);
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_CHANNEL_SCAN_PAGE_CH_NUM_VALUE);
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_CHANNEL_SCAN_PAGE_PERCENT);
                break;

            case EN_EXE_AUTO_SCAN_FINISH:
                //printf("\r\n EN_EXE_AUTO_SCAN_FINISH ... ");
                if(MApp_ZUI_API_IsExistTimer(HWND_MENU_MASK_BACKGROUND,0))
                {
                    MApp_ZUI_API_ResetTimer(HWND_MENU_MASK_BACKGROUND, 0);
                }

                if(MApp_ZUI_API_IsExistTimer(HWND_MENU_PICTURE_ADJUST_SUBMENU,0))
                {
                    MApp_ZUI_API_ResetTimer(HWND_MENU_PICTURE_ADJUST_SUBMENU, 0);
                }
                if(g_bCancelAutoscanByUser)
                {
                    g_bCancelAutoscanByUser = FALSE;
                    MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_CHANNEL_SCAN_PAGE_PROGRESS_BAR);
                    MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_CHANNEL_SCAN_PAGE_SCAN_STATE_VALUE);
                    MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_CHANNEL_SCAN_PAGE_FREQ_VALUE);
                    MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_CHANNEL_SCAN_PAGE_CH_NUM_VALUE);
                    MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_CHANNEL_SCAN_PAGE_PERCENT);
                }
                else
                {
                    MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_SCAN_PAGE, SW_HIDE);
                    MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_PAGE, SW_SHOW);
                    #if ENABLE_CUS_UPDATE_SCAN
                    if(g_bGotoUpdateScan)
                    {
                        g_bGotoUpdateScan = FALSE;
                        MApp_ZUI_API_SetFocus(HWND_MENU_CHANNEL_UPDATE_SCAN);
                    }
                    else
                    #endif
                    {
                        MApp_ZUI_API_SetFocus(HWND_MENU_CHANNEL_AUTOTUNE);
                    }
                }
                break;

            case EN_EXE_ATV_MANUAL_SCAN_FINISH:
                //printf("\r\n EN_EXE_ATV_MANUAL_SCAN_FINISH ... ");
                if(MApp_ZUI_API_IsExistTimer(HWND_MENU_MASK_BACKGROUND,0))
                {
                    MApp_ZUI_API_ResetTimer(HWND_MENU_MASK_BACKGROUND, 0);
                }

                if(MApp_ZUI_API_IsExistTimer(HWND_MENU_PICTURE_ADJUST_SUBMENU,0))
                {
                    MApp_ZUI_API_ResetTimer(HWND_MENU_PICTURE_ADJUST_SUBMENU, 0);
                }

                MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_SCAN_PAGE_CH_NUM_TEXT, SW_HIDE);
                MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_SCAN_PAGE_CH_NUM_VALUE, SW_HIDE);
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_CHANNEL_SCAN_PAGE_PROGRESS_BAR);
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_CHANNEL_SCAN_PAGE_SCAN_STATE_VALUE);
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_CHANNEL_SCAN_PAGE_FREQ_VALUE);
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_CHANNEL_SCAN_PAGE_CH_NUM_VALUE);
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_CHANNEL_SCAN_PAGE_PERCENT);
                MApp_ZUI_API_SetFocus(HWND_MENU_CHANNEL_SCAN_PAGE_MANUAL_FREQ_BEGIN);
                break;

            case EN_EXE_ATV_MANUAL_SCAN_FINISH_EXIT_TO_CHANNEL_PAGE:
                if(MApp_ZUI_API_IsExistTimer(HWND_MENU_MASK_BACKGROUND,0))
                {
                    MApp_ZUI_API_ResetTimer(HWND_MENU_MASK_BACKGROUND, 0);
                }

                if(MApp_ZUI_API_IsExistTimer(HWND_MENU_PICTURE_ADJUST_SUBMENU,0))
                {
                    MApp_ZUI_API_ResetTimer(HWND_MENU_PICTURE_ADJUST_SUBMENU, 0);
                }

                //printf("\r\n EN_EXE_ATV_MANUAL_SCAN_FINISH_EXIT_TO_CHANNEL_PAGE ... ");
                MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_SCAN_PAGE, SW_HIDE);
                MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_PAGE, SW_SHOW);
                MApp_ZUI_API_SetFocus(HWND_MENU_CHANNEL_ATV_MAN_TUNE);
                break;

            case EN_EXE_DEC_ATV_MANUAL_SCAN_START_FREQ:
                #if ENABLE_CUS_MANUAL_SCAN
                {
                    U32 u32Freq;
                    u32Freq = msAPI_Tuner_GetManualScanStartFreq() -5000;
                    if(u32Freq < MIN_MANUAL_START_FREQ)
                    {
                        u32Freq = MIN_MANUAL_START_FREQ;
                    }
                    msAPI_Tuner_SetManualScanStartFreq(u32Freq);
                }
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_CHANNEL_SCAN_PAGE_MANUAL_FREQ_BEGIN);
                #endif
                break;

            case EN_EXE_INC_ATV_MANUAL_SCAN_START_FREQ:
                #if ENABLE_CUS_MANUAL_SCAN
                {
                    U32 u32Freq;
                    u32Freq = msAPI_Tuner_GetManualScanStartFreq() +5000;
                    if(u32Freq > MAX_MANUAL_END_FREQ)
                    {
                        u32Freq = MAX_MANUAL_END_FREQ;
                    }
                    msAPI_Tuner_SetManualScanStartFreq(u32Freq);
                }
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_CHANNEL_SCAN_PAGE_MANUAL_FREQ_BEGIN);
                #endif
                break;
            case EN_EXE_DEC_ATV_MANUAL_SCAN_END_FREQ:
                #if ENABLE_CUS_MANUAL_SCAN
                {
                    U32 u32Freq;
                    u32Freq = msAPI_Tuner_GetManualScanEndFreq() -5000;
                    if(u32Freq < MIN_MANUAL_START_FREQ)
                    {
                        u32Freq = MIN_MANUAL_START_FREQ;
                    }
                    msAPI_Tuner_SetManualScanEndFreq(u32Freq);
                }
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_CHANNEL_SCAN_PAGE_MANUAL_FREQ_END);
                #endif
                break;
            case EN_EXE_INC_ATV_MANUAL_SCAN_END_FREQ:
                #if ENABLE_CUS_MANUAL_SCAN
                {
                    U32 u32Freq;
                    u32Freq = msAPI_Tuner_GetManualScanEndFreq() +5000;
                    if(u32Freq > MAX_MANUAL_END_FREQ)
                    {
                        u32Freq = MAX_MANUAL_END_FREQ;
                    }
                    msAPI_Tuner_SetManualScanEndFreq(u32Freq);
                }
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_CHANNEL_SCAN_PAGE_MANUAL_FREQ_END);
                #endif
                break;

            case EN_EXE_INC_ATV_MANUAL_REFRESH_AND_CHECK_FREQ:
                #if ENABLE_CUS_MANUAL_SCAN
                g_u8IdleMainpageDigitKeyCount = 0;
                msAPI_Tuner_CheckManualScanStartAndEndFreq();
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_CHANNEL_SCAN_PAGE_MANUAL_FREQ_BEGIN);
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_CHANNEL_SCAN_PAGE_MANUAL_FREQ_END);
                #endif
                break;

            case EN_EXE_DEC_ATV_MANUAL_SCAN_START_SEARCH:
                MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_SCAN_PAGE, SW_SHOW);
                MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_SCAN_PAGE_TITLE, SW_HIDE);
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_BG_MENUPAGE_INFO); //refresh mainmenu page info text

                MApp_ZUI_API_SetFocus(HWND_MENU_CHANNEL_SCAN_PAGE_MANUA_GOTO_SCAN);
                enMainMenuState = _enTargetMenuState = STATE_MENU_GOTO_ATV_MANUALTUNING;
                break;

            case EN_EXE_TIME_SET_PAGE_KEY_RIGHT:
                g_u8IdleMainpageDigitKeyCount++;
                if(HWND_MENU_TIME_SET_DATE == MApp_ZUI_API_GetFocus())
                {
                    if(g_u8IdleMainpageDigitKeyCount >7)
                    {
                        g_u8IdleMainpageDigitKeyCount = 7;
                    }
                }
                else
                {
                    if(g_u8IdleMainpageDigitKeyCount >5)
                    {
                        g_u8IdleMainpageDigitKeyCount = 5;
                    }
                }
                printf("\r\n 2.g_u8IdleMainpageDigitKeyCount =[%bu], ",g_u8IdleMainpageDigitKeyCount);
                MApp_ZUI_API_InvalidateAllSuccessors(MApp_ZUI_API_GetFocus());
                return TRUE;

            case EN_EXE_TIME_SET_PAGE_KEY_LEFT:
                if(g_u8IdleMainpageDigitKeyCount > 1)
                {
                    g_u8IdleMainpageDigitKeyCount--;
                }
                else
                {
                    g_u8IdleMainpageDigitKeyCount = 0;
                }

                printf("\r\n 3.g_u8IdleMainpageDigitKeyCount =[%bu], ",g_u8IdleMainpageDigitKeyCount);
                MApp_ZUI_API_InvalidateAllSuccessors(MApp_ZUI_API_GetFocus());
                return TRUE;

            case EN_EXE_TIME_SET_PAGE_KEY_UP:
            case EN_EXE_TIME_SET_PAGE_KEY_DOWN:
                g_u8IdleMainpageDigitKeyCount = 0;
                return FALSE;
                break;

            case EN_EXE_DEC_SET_OFFTIME_REPEAT:
            case EN_EXE_INC_SET_OFFTIME_REPEAT:
                {
                    stGenSetting.g_Time.cOffTimerFlag =
                        (EN_MENU_TIME_OffTimer)MApp_ZUI_ACT_DecIncValue_Cycle(act==EN_EXE_INC_SET_OFFTIME_REPEAT,
                            stGenSetting.g_Time.cOffTimerFlag,(U16) EN_Time_OnTimer_Off, (U16)(EN_Time_OnTimer_Everyday), 1);


                    if (stGenSetting.g_Time.cOffTimerFlag==EN_Time_OffTimer_Off)
                    {
                        MApp_Sleep_SetOffTime(FALSE);
                        MApp_ZUI_API_EnableWindow(HWND_MENU_TIME_SET_OFFTIME, DISABLE);
                    }
                    else
                    {
                        g_u8TimeInfo_Flag  |= UI_TIME_MANUAL_SET;
                        MApp_Sleep_SetOffTime(TRUE);
                        MApp_ZUI_API_EnableWindow(HWND_MENU_TIME_SET_OFFTIME, ENABLE);
                    }
                    MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_TIME_SET_OFFTIME);
                    MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_TIME_OFF_TIME_SWITCH);

                    return TRUE;
                }

            case EN_EXE_DEC_SET_ONTIME_REPEAT:
            case EN_EXE_INC_SET_ONTIME_REPEAT:
                {
                    stGenSetting.g_Time.cOnTimerFlag =
                        (EN_MENU_TIME_OnTimer)MApp_ZUI_ACT_DecIncValue_Cycle(act==EN_EXE_INC_SET_ONTIME_REPEAT,
                            stGenSetting.g_Time.cOnTimerFlag,(U16) EN_Time_OnTimer_Off, (U16)(EN_Time_OnTimer_Everyday), 1);

                    MApp_Time_SetOnTime();

                    if (stGenSetting.g_Time.cOnTimerFlag==EN_Time_OnTimer_Off)
                    {
                        MApp_ZUI_API_EnableWindow(HWND_MENU_TIME_SET_ONTIME, DISABLE);
                        MApp_ZUI_API_EnableWindow(HWND_MENU_TIME_ON_TIME_SETUP, DISABLE);
                    }
                    else
                    {
                        MApp_ZUI_API_EnableWindow(HWND_MENU_TIME_SET_ONTIME, ENABLE);
                        MApp_ZUI_API_EnableWindow(HWND_MENU_TIME_ON_TIME_SETUP, ENABLE);
                    }
                    MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_TIME_SET_ONTIME);
                    MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_TIME_ON_TIME_SETUP);
                    MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_TIME_ON_TIME_SWTICH);

                    return TRUE;
                }
            case EN_EXE_DEC_SET_ONTIME_SOURCE:
            case EN_EXE_INC_SET_ONTIME_SOURCE:
                {
                    U8 i = EN_Time_OnTimer_Source_Num;
                    U16 u16AtvCount=0;
                    #if NORDIG_FUNC //for Nordig Spec v2.0
                    U16 u16DataCount=0;
                    #endif

                    #if ENABLE_DTV
                    U16 u16DtvCount=0, u16RadioCount=0;
                    u16DtvCount = msAPI_CM_CountProgram(E_SERVICETYPE_DTV, E_PROGACESS_INCLUDE_VISIBLE_ONLY);
                    u16RadioCount = msAPI_CM_CountProgram(E_SERVICETYPE_RADIO, E_PROGACESS_INCLUDE_VISIBLE_ONLY);
                    #endif

                    #if NORDIG_FUNC //for Nordig Spec v2.0
                    u16DataCount = msAPI_CM_CountProgram(E_SERVICETYPE_DATA, E_PROGACESS_INCLUDE_VISIBLE_ONLY);
                    #endif
                    u16AtvCount = msAPI_ATV_GetActiveProgramCount();

                    while (i>0)
                    {
                        BOOLEAN bNext = FALSE;

                        i--;
                        stGenSetting.g_Time.cOnTimerSourceFlag =(EN_MENU_TIME_OnTimer_Source) MApp_ZUI_ACT_DecIncValue_Cycle((act==EN_EXE_INC_SET_ONTIME_SOURCE), (U16)stGenSetting.g_Time.cOnTimerSourceFlag,(U16) EN_Time_OnTimer_Source_DTV, (U16)(EN_Time_OnTimer_Source_Num-1), 1);
                        switch (stGenSetting.g_Time.cOnTimerSourceFlag)
                        {
                            #if ENABLE_DTV
                            case EN_Time_OnTimer_Source_DTV:
                                if (u16DtvCount == 0)
                                {
                                    //bNext = TRUE;
                                }
                                break;
                            case EN_Time_OnTimer_Source_RADIO:
                                if (u16RadioCount == 0)
                                {
                                    //bNext = TRUE;
                                }
                                break;
                            #else
                            case EN_Time_OnTimer_Source_DTV:
                            case EN_Time_OnTimer_Source_RADIO:
                                bNext = TRUE;
                                break;
                            #endif

                            #if (ENABLE_DMP)
                            #if( ENABLE_DMP_SWITCH )
                            #ifdef ENABLE_DMP_ONE_PORT     // CUS_XM Sea 20120629:
                            case EN_Time_OnTimer_Source_MPLAYER1:
                                bNext = TRUE;
                                break;
                            #endif
                            #else
                            case EN_Time_OnTimer_Source_MPLAYER:
                                bNext = TRUE;
                                break;
                            #endif
                            #endif

                            #if NORDIG_FUNC //for Nordig Spec v2.0
                            case EN_Time_OnTimer_Source_DATA:
                                if (u16DataCount == 0)
                                {
                                    bNext = TRUE;
                                }
                                break;
                            #endif

                            case EN_Time_OnTimer_Source_ATV:
                                if (u16AtvCount == 0)
                                {
                                    // bNext = TRUE; // Steven.Xu remark
                                }
                                break;
                            default:
                                break;
                        }
                        if (!bNext)
                        {
                            break;
                        }
                    }
                    // Fist Channel auto detect
                    switch(stGenSetting.g_Time.cOnTimerSourceFlag)
                    {
                        case EN_Time_OnTimer_Source_RADIO:
                            stGenSetting.g_Time.cOnTimerChannel = 0;//msAPI_CM_GetLogicalChannelNumber(E_SERVICETYPE_RADIO, 0);
                            break;

                        case EN_Time_OnTimer_Source_DTV:
                            stGenSetting.g_Time.cOnTimerChannel = 0;//msAPI_CM_GetLogicalChannelNumber(E_SERVICETYPE_DTV, 0);
                            break;

                        #if NORDIG_FUNC //for Nordig Spec v2.0
                        case EN_Time_OnTimer_Source_DATA:
                            stGenSetting.g_Time.cOnTimerChannel = 0;//msAPI_CM_GetLogicalChannelNumber(E_SERVICETYPE_DATA, 0);
                            break;
                        #endif

                        case EN_Time_OnTimer_Source_ATV:
                            stGenSetting.g_Time.cOnTimerChannel = msAPI_ATV_GetChannelMin()-1;//msAPI_ATV_GetFirstProgramNumber(FALSE);
                            break;
                        default:
                            break;
                    }

                    if(stGenSetting.g_Time.cOnTimerSourceFlag == EN_Time_OnTimer_Source_ATV)
                    {
                        MApp_ProgramEdit_SetMode(MODE_PREDIT_ONTIME_CHANNEL);

						if(msAPI_ATV_GetActiveProgramCount())
                        MApp_ZUI_ACT_Mainpage_AppShowProgramEdit();
                        //MApp_ZUI_API_ShowWindow(HWND_MENU_TIME_ONTIME_PAGE, SW_SHOW);
                        MApp_ZUI_API_SetFocus(HWND_MENU_TIME_ONTIME_PAGE_ITEM);
                        //MApp_ZUI_API_ShowWindow(HWND_MENU_PREDIT_CHANNEL_LIST_PAGE, SW_SHOW);
                    }
                    else
                    {
                        MApp_ZUI_API_ShowWindow(HWND_MENU_PREDIT_CHANNEL_LIST_PAGE, SW_HIDE);
                        MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_TIME_ONTIME_PAGE);
                    }

                    return TRUE;
                }
                case EN_EXE_GOTO_SET_ONTIME_CHANNEL:
                {
                    if((stGenSetting.g_Time.cOnTimerSourceFlag == EN_Time_OnTimer_Source_ATV)&&(msAPI_ATV_GetActiveProgramCount()))
                    {
                        MApp_ZUI_API_SetFocus(HWND_MENU_PREDIT_ITEM0);
                    }
                    return TRUE;
                }
                case EN_EXE_CLEAN_MAINPAGE_DIGIT_KEY_COUNT:
                    g_u8IdleMainpageDigitKeyCount = 0;
                    break;

        case EN_EXE_MENU_CH_CHANGE:
            MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
            _enTargetMenuState = STATE_MENU_GOTO_CHANNELCHANGE;
            return TRUE;
        case EN_EXE_CLEAN_PWD:
            if(MApp_ZUI_API_GetFocus() == HWND_MENU_LOCK_NEWPSW)
            {
                g_u16PasswordTemp = g_u16Password;
            }
            else
            {
                g_u16PasswordTemp = 0;
            }
            PasswordInput1=PasswordInput2=0;
            g_u8PasswordPosition = 0;
            g_u16Password = 0;
            g_u8PasswordCount = 0;
            return FALSE;

        default:
            #if 0 // no used for CUS
            if (MApp_ZUI_API_IsWindowVisible(HWND_MENU_TIME_CLOCK_PAGE))
                return MApp_ZUI_ACT_ExecuteSetClockDialogAction(act);
            if (MApp_ZUI_API_IsWindowVisible(HWND_MENU_TIME_OFFTIME_PAGE))
                return MApp_ZUI_ACT_ExecuteSetOffTimeDialogAction(act);
            #endif
            if (MApp_ZUI_API_IsWindowVisible(HWND_MENU_TIME_ONTIME_PAGE))
                return MApp_ZUI_ACT_ExecuteSetOnTimeDialogAction(act);
#if (ENABLE_CUS_UI_SPEC == FALSE)/*Creass.liu at 2012-06-27*/
            if (MApp_ZUI_API_IsWindowVisible(HWND_MENU_OPTION_AUDIOLANG_PAGE))
                return MApp_ZUI_ACT_ExecuteSetAudLangDialogAction(act);
        #if ENABLE_SUBTITLE
            if (MApp_ZUI_API_IsWindowVisible(HWND_MENU_OPTION_SUBLANG_PAGE))
                return MApp_ZUI_ACT_ExecuteSetSubLangDialogAction(act);
        #endif
            if (MApp_ZUI_API_IsWindowVisible(HWND_MENU_DLG_TUNE_CONFIRM))
                return MApp_ZUI_ACT_ExecuteTuningConfirmDialogAction(act);
#endif
            if (MApp_ZUI_API_IsWindowVisible(HWND_MENU_DLG_COMMON))
                return MApp_ZUI_ACT_ExecuteMenuCommonDialogAction(act);
            if (MApp_ZUI_API_IsWindowVisible(HWND_MENU_PREDIT_CHANNEL_LIST_PAGE))
                return MApp_ZUI_ACT_Mainpage_ExecuteProgramEditAction(act);
            return MApp_ZUI_ACT_ExecuteMenuItemAction(act);

    }
    return FALSE;
}

///////////////////////////////////////////////////////////////////////////////
///  private  MApp_ZUI_ACT_GetMainMenuDynamicBitmap
///  [OSD page handler] dynamic bitmap content provider in MENU application
///
///  @param [in]       hwnd HWND     window handle we are processing
///
///  @return U16     bitmap index
///
///  @author MStarSemi @date 2007/1/25
///////////////////////////////////////////////////////////////////////////////

U16 MApp_ZUI_ACT_GetMainMenuDynamicBitmap(HWND hwnd, DRAWSTYLE_TYPE ds_type)
{
    ds_type = ds_type;
    if (MApp_ZUI_API_IsSuccessor(HWND_MENU_PREDIT_CHANNEL_LIST_PAGE, hwnd))
        return MApp_ZUI_ACT_Mainpage_GetProgramEditDynamicBitmap(hwnd,ds_type);
    switch(hwnd)
    {
		case HWND_MENU_TV_ICON:
		 	if(stGenSetting.g_VChipSetting.u8InputBlockItem&INPUT_BLOCK_TV)
				return E_BMP_NAV_LIST_ICON_SCRAMBLE_HLT; //cus_xm:zb modify at 2012-8-10
			else
				return 0xFFFF;
			break;

		case HWND_MENU_AV1_ICON:
		   if(stGenSetting.g_VChipSetting.u8InputBlockItem&INPUT_BLOCK_AV1)
			   return E_BMP_NAV_LIST_ICON_SCRAMBLE_HLT;
		   else
			   return 0xFFFF;
		   break;
		case HWND_MENU_AV2_ICON:
		  if(stGenSetting.g_VChipSetting.u8InputBlockItem&INPUT_BLOCK_AV2)
			  return E_BMP_NAV_LIST_ICON_SCRAMBLE_HLT;
		  else
			  return 0xFFFF;
		  break;
		case HWND_MENU_YPBPR1_ICON:
		 if(stGenSetting.g_VChipSetting.u8InputBlockItem&INPUT_BLOCK_YPBPR1)
			 return E_BMP_NAV_LIST_ICON_SCRAMBLE_HLT;
		 else
			 return 0xFFFF;
		 break;
		 case HWND_MENU_YPBPR2_ICON:
			if(stGenSetting.g_VChipSetting.u8InputBlockItem&INPUT_BLOCK_YPBPR2)
				return E_BMP_NAV_LIST_ICON_SCRAMBLE_HLT;
			else
				return 0xFFFF;
			break;
		case HWND_MENU_PC_ICON:
		   if(stGenSetting.g_VChipSetting.u8InputBlockItem&INPUT_BLOCK_PC)
			   return E_BMP_NAV_LIST_ICON_SCRAMBLE_HLT;
		   else
			   return 0xFFFF;
		   break;
	   case HWND_MENU_HDMI1_ICON:
		  if(stGenSetting.g_VChipSetting.u8InputBlockItem&INPUT_BLOCK_HDMI1)
			  return E_BMP_NAV_LIST_ICON_SCRAMBLE_HLT;
		  else
			  return 0xFFFF;
		  break;
		case HWND_MENU_HDMI2_ICON:
            if(stGenSetting.g_VChipSetting.u8InputBlockItem&INPUT_BLOCK_HDMI2)
                return E_BMP_NAV_LIST_ICON_SCRAMBLE_HLT;
            else
                return 0xFFFF;
		case HWND_MENU_HDMI3_ICON:
            if(stGenSetting.g_VChipSetting.u8InputBlockItem&INPUT_BLOCK_HDMI3)
                return E_BMP_NAV_LIST_ICON_SCRAMBLE_HLT;
            else
                return 0xFFFF;
		case HWND_MENU_HDMI4_ICON:
            if(stGenSetting.g_VChipSetting.u8InputBlockItem&INPUT_BLOCK_HDMI4)
                return E_BMP_NAV_LIST_ICON_SCRAMBLE_HLT;
            else
                return 0xFFFF;
        case HWND_MENU_BOTTOM_HALF_SELECT_BG:
        {
            switch(MApp_ZUI_API_GetFocus())
            {
                case HWND_MENU_PC_PICTURE_ADVANCE_PICTURE:
                case HWND_MENU_PICTURE_ADVANCE_PICTURE:
                case HWND_MENU_CHANNEL_INFO_SAVE_CHANGED:
                case HWND_MENU_CHANNEL_PAGE2_CHANNEL:
                case HWND_MENU_OP_TIME_SUBPAGE_TIME:
                case HWND_MENU_PC_PICTURE_PC_ADJUST:
                case HWND_MENU_TOP_ICON_PICTURE:
                case HWND_MENU_TOP_ICON_AUDIO:
                case HWND_MENU_TOP_ICON_CHANNEL:
                case HWND_MENU_TOP_ICON_SETUP:
                case HWND_MENU_TOP_ICON_LOCK:
                #if((UI_SKIN_SEL == UI_SKIN_1366X768X565_SMC_India)||(UI_SKIN_SEL==UI_SKIN_1366X768X565_HAIER_CN))
                    return E_BMP_OTS_ITEM_MOVE;
                #else
                    return E_BMP_PIONEER_MENU_ENTER;
                #endif
            default:
                return 0xFFFF;

            }
        }
		break;
        default:
            //
            break;

    }
    return 0xFFFF; //for empty bitmap....
}
///////////////////////////////////////////////////////////////////////////////
///  private  MApp_ZUI_ACT_GetMainMenuDynamicText
///  [OSD page handler] dynamic text content provider in MENU application
///
///  @param [in]       hwnd HWND     window handle we are processing
///
///  @return LPCTSTR     string content
///
///  @author MStarSemi @date 2007/1/25
///////////////////////////////////////////////////////////////////////////////
LPTSTR MApp_ZUI_ACT_GetMenuLockDynamicText(HWND hwnd)
{
		U16 u16TempID = Empty;

		switch(hwnd)
		{
			case HWND_MENU_LOCK_SOURCE1:
				return MApp_ZUI_API_GetU16String(1);
				break;
			case HWND_MENU_LOCK_SOURCE2:
				return MApp_ZUI_API_GetU16String(2);
				break;
			case HWND_MENU_LOCK_SOURCE3:
				return MApp_ZUI_API_GetU16String(3);
				break;
#if(INPUT_AV_VIDEO_COUNT>=2)
			case HWND_MENU_LOCK_SOURCE4:
				return MApp_ZUI_API_GetU16String(4);
				break;
			case HWND_MENU_LOCK_SOURCE5:
				return MApp_ZUI_API_GetU16String(5);
				break;
#if(INPUT_YPBPR_VIDEO_COUNT>=2)
			case HWND_MENU_LOCK_SOURCE6:
				return MApp_ZUI_API_GetU16String(6);
				break;
			case HWND_MENU_LOCK_SOURCE7:
				return MApp_ZUI_API_GetU16String(7);
				break;
			case HWND_MENU_LOCK_SOURCE8:
				return MApp_ZUI_API_GetU16String(8);
				break;
        #if (INPUT_HDMI_VIDEO_COUNT >= 3)
            case HWND_MENU_LOCK_SOURCE9:
                return MApp_ZUI_API_GetU16String(9);
                break;
          #if (INPUT_HDMI_VIDEO_COUNT >= 4)
            case HWND_MENU_LOCK_SOURCE10:
                return MApp_ZUI_API_GetU16String(10);
                break;
          #endif
        #endif
#else
            case HWND_MENU_LOCK_SOURCE6:
                return MApp_ZUI_API_GetU16String(5);
                break;
            case HWND_MENU_LOCK_SOURCE7:
                return MApp_ZUI_API_GetU16String(6);
                break;
            case HWND_MENU_LOCK_SOURCE8:
                return MApp_ZUI_API_GetU16String(7);
                break;
        #if (INPUT_HDMI_VIDEO_COUNT >= 3)
            case HWND_MENU_LOCK_SOURCE9:
                return MApp_ZUI_API_GetU16String(8);
                break;
          #if (INPUT_HDMI_VIDEO_COUNT >= 4)
            case HWND_MENU_LOCK_SOURCE10:
                return MApp_ZUI_API_GetU16String(9);
                break;
          #endif
        #endif
#endif
#else
            case HWND_MENU_LOCK_SOURCE4:
                return MApp_ZUI_API_GetU16String(3);
                break;
            case HWND_MENU_LOCK_SOURCE5:
                return MApp_ZUI_API_GetU16String(4);
                break;
#if(INPUT_YPBPR_VIDEO_COUNT>=2)
            case HWND_MENU_LOCK_SOURCE6:
                return MApp_ZUI_API_GetU16String(5);
                break;
            case HWND_MENU_LOCK_SOURCE7:
                return MApp_ZUI_API_GetU16String(6);
                break;
            case HWND_MENU_LOCK_SOURCE8:
                return MApp_ZUI_API_GetU16String(7);
                break;
        #if (INPUT_HDMI_VIDEO_COUNT >= 3)
            case HWND_MENU_LOCK_SOURCE9:
                return MApp_ZUI_API_GetU16String(8);
                break;
          #if (INPUT_HDMI_VIDEO_COUNT >= 4)
            case HWND_MENU_LOCK_SOURCE10:
                return MApp_ZUI_API_GetU16String(9);
                break;
          #endif
        #endif
#else
            case HWND_MENU_LOCK_SOURCE6:
                return MApp_ZUI_API_GetU16String(4);
                break;
            case HWND_MENU_LOCK_SOURCE7:
                return MApp_ZUI_API_GetU16String(5);
                break;
            case HWND_MENU_LOCK_SOURCE8:
                return MApp_ZUI_API_GetU16String(6);
                break;
        #if (INPUT_HDMI_VIDEO_COUNT >= 3)
            case HWND_MENU_LOCK_SOURCE9:
                return MApp_ZUI_API_GetU16String(7);
                break;
          #if (INPUT_HDMI_VIDEO_COUNT >= 4)
            case HWND_MENU_LOCK_SOURCE10:
                return MApp_ZUI_API_GetU16String(8);
                break;
          #endif
        #endif
#endif
#endif
            case HWND_MENU_LOCK_MAINSUBPAGE_ITEM_AV1_TEXT:
                #if(INPUT_AV_VIDEO_COUNT>=2)
                u16TempID =en_strInputSourceAv1Text;
                #else
                u16TempID =en_strInputSourceAvText;
                #endif
                break;
            case HWND_MENU_LOCK_MAINSUBPAGE_ITEM_YPBPR1_TEXT:
                #if(INPUT_YPBPR_VIDEO_COUNT>=2)
                u16TempID =en_strYPbPrText;
                #else
                u16TempID =en_str_InputSource_Component;
                #endif
                break;
            case HWND_MENU_LOCK_MAINSUBPAGE_ITEM_HDMI1_TEXT:
                #if(INPUT_HDMI_VIDEO_COUNT>=2)
                u16TempID =en_strInputSourceHdmi1Text;
                #else
                u16TempID =en_strInputSourceHdmiText;
                #endif
                break;

			default:
				return 0;
				break;
		}
		if (u16TempID != Empty)
			return MApp_ZUI_API_GetString(u16TempID);
		return 0; //for empty string....

}

LPTSTR MApp_ZUI_ACT_GetMenupageInfoDynamicText(HWND hwnd)
{
    U16 u16TempID = Empty;

    switch(hwnd)
    {
      case HWND_MENU_BG_MENUPAGE_INFO_PAGE_TITLE:
      if(MApp_ZUI_API_IsSuccessor(HWND_MENU_PREDIT_CHANNEL_NAME_PAGE,MApp_ZUI_API_GetFocus()))
        {
            u16TempID = en_str_Channel_Text;
        }
      else
        {
            switch(MApp_ZUI_API_GetParent(MApp_ZUI_API_GetFocus()))
            {
                case HWND_MENU_BACKGROUND:
                    switch(MApp_ZUI_API_GetFocus())
                    {
                        case HWND_MENU_TOP_ICON_PICTURE:
                            u16TempID = en_str_Picture_Text;
                            break;
                        case HWND_MENU_TOP_ICON_SETUP:
                            u16TempID = en_str_Option_Text;
                            break;
                        case HWND_MENU_TOP_ICON_AUDIO:
                            u16TempID = en_str_Sound_Text;
                            break;
                        case HWND_MENU_TOP_ICON_CHANNEL:
                            u16TempID = en_str_Channel_Text;
                            break;
                        case HWND_MENU_TOP_ICON_LOCK:
                            u16TempID = en_str_Lock_Text;
                            break;
                        default:
                            break;
                    }
                    break;
                case HWND_MENU_ADVANCE_PICTURE_PAGE_LIST:
                case HWND_MENU_PICTURE_PAGE_LIST:
                    u16TempID = en_str_Picture_Text;
                    break;
                case HWND_MENU_PCMODE_ADJUST_PAGE_LIST:
                case HWND_MENU_PC_PICTURE_PAGE_LIST:
                    u16TempID = en_str_Picture_Text;
                    break;
                case HWND_MENU_SOUND_PAGE_LIST:
                    u16TempID = en_str_Sound_Text;
                    break;
                case HWND_MENU_LOCK_PAGE_LIST:
                    if(bEnterPW2ChannelsList)
                    {
                        u16TempID = en_str_Channel_Text;
                    }
                    else
                    {
                        u16TempID = en_str_Lock_Text;
                    }
                    break;
                case HWND_MENU_LOCK_INPUT_LOCK_PAGE_LIST:
                case HWND_MENU_LOCK_INPUT_MAINSUBPAGE:
                case HWND_MENU_LOCK_MAINSUBPAGE:
                case HWND_MENU_LOCK_PAGE_LIST_CHANGEPW:
                    u16TempID = en_str_Lock_Text;
                    break;

                case HWND_MENU_PREDIT_LIST_PANE:
                    if(_eProgramEditMode==MODE_PREDIT_BLOCK)
                        u16TempID = en_str_Lock_Text;
                    else if(_eProgramEditMode==MODE_PREDIT_ONTIME_CHANNEL)
                        u16TempID = en_str_Option_Text;
                    else
                        u16TempID = en_str_Channel_Text;

                    break;

                case HWND_MENU_CHANNEL_PAGE2_LIST:
                case HWND_MENU_CHANNEL_PAGE_LIST:
                case HWND_MENU_CHANNEL_INFO_PAGE_LIST:
                case HWND_MENU_PREDIT_CHANNEL_NAME_PAGE:
                case HWND_MENU_CHANNEL_SCAN_PAGE:
                case HWND_MENU_CHANNEL_PAGE2:
                case HWND_MENU_CHANNEL_SCAN_PAGE_SCAN_INFO:
                case HWND_MENU_CHANNEL_SCAN_PAGE_MANUAL_LIST:
                    u16TempID = en_str_Channel_Text;
                    break;
/*                // XM CUS ADD
                case HWND_MENU_CHANNEL_PAGE:
                    switch(MApp_ZUI_API_GetFocus())
                    {
                case HWND_MENU_CHANNEL_AUTOTUNE:
                    u16TempID = en_str_Scan;
                    break;
                case HWND_MENU_CHANNEL_UPDATE_SCAN:
                    u16TempID = en_str_Channel_Update_Scan;
                    break;
                case HWND_MENU_CHANNEL_ATV_MAN_TUNE:
                    u16TempID = en_str_AtvManualScan;
                    break;
                default:
                    break;
                        }
                    break;
*/
                case HWND_MENU_TIME_PAGE_LIST:
                case HWND_MENU_OPTION_PAGE_LIST:
                case HWND_MENU_OPTION_TIME_SUBPAGE_LIST:
                case HWND_MENU_POWERON_SETTING_PAGE_LIST:
                case HWND_MENU_POWERON_SETTING_PAGE:
                case HWND_MENU_OPTION_3D_SETUP_PAGE_LIST:
                case HWND_MENU_TIME_ONTIME_PAGE:
                    u16TempID = en_str_Option_Text;
                    break;

            }
        }
            break;

        case HWND_MENU_BG_MENUPAGE_INFO_PAGE_NUM:
            break;
      	//cus_xm:zb modify at 2012-7-17
      #ifdef ENABLE_CUS_FIRMWARE_UPGRADE_FUNCTION
       case HWND_MENU_FWUPGRADE_TEXT1:
            if(Menu_USB_Upgrade_Percent <=100)
            {
                u16TempID = en_strFwUpgradeInProgressText1;
            }
            else
            {
                u16TempID = en_str_SW_USB_Upgrade;
            }
            break;
       case HWND_MENU_FWUPGRADE_PROGRESS_VALUE:
           if(Menu_USB_Upgrade_Percent<=100)
           {
               MApp_ZUI_API_GetU16String((U16)Menu_USB_Upgrade_Percent);
               if(Menu_USB_Upgrade_Percent < 10 )
               {
                   CHAR_BUFFER[1] = CHAR_SPACE;
                   CHAR_BUFFER[2] = CHAR_SPACE;
               }
               else if(Menu_USB_Upgrade_Percent < 100)
               {
                   CHAR_BUFFER[2] = CHAR_SPACE;
               }
               CHAR_BUFFER[3] = CHAR_PERCENT;
               CHAR_BUFFER[4] = '\0';
           }
           else
           {
               MApp_ZUI_API_GetU16String((U16)0);
               CHAR_BUFFER[1] = CHAR_SPACE;
               CHAR_BUFFER[2] = CHAR_SPACE;
               CHAR_BUFFER[3] = CHAR_PERCENT;
               CHAR_BUFFER[4] = '\0';

           }
           return CHAR_BUFFER;


            break;
       case HWND_MENU_FWUPGRADE_TEXT2:
           if(Menu_USB_Upgrade_Percent != 0xFF)
           {
               if(Menu_USB_Upgrade_Percent == 0xFE)
               {
                   U8 str[] = {"CRC Error"};
                   MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER,str, strlen((const char *)str));
               }
               else if(Menu_USB_Upgrade_Percent == 0xFD)
               {
                   U8 str[] = {"Fail to Burn AP Code"};
                   MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, str, strlen((const char *)str));
               }
               else if(Menu_USB_Upgrade_Percent == 0xFC)
               {
                   U8 str[] = {"Unknown image type"};
                   MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, str, strlen((const char *)str));
               }
               else if(Menu_USB_Upgrade_Percent == 0xFB)
               {
                   U8 str[] = {"Reboot fail"};
                   MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, str, strlen((const char *)str));
               }
               else if(Menu_USB_Upgrade_Percent == 0xFA)
               {
                   U8 str[] = {"Failed to update software"};
                   MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, str, strlen((const char *)str));
               }
               else if(Menu_USB_Upgrade_Percent <=100)
               {
                   u16TempID = en_strFwUpgradeInProgressText2;
                   break;
               }
               else
               {
                   return 0;
               }
               return CHAR_BUFFER;
           }
           else
           {
               #ifdef ENABLE_CUS_SW_VERSION
                U8 u8strlen;
                MS_IMG_INFO ImgInfo;
                U8 u8SW_VersionHight,u8SW_VersionLow;
                MApp_ImgInfo_GetAppInfo(&ImgInfo);//read from flash.
                u8SW_VersionHight = (ImgInfo.u16SW_Version&0xFF00)>>8;
                u8SW_VersionLow = ImgInfo.u16SW_Version&0x00FF;

                MApp_ZUI_API_LoadString(en_strDoYouWantUpgrade, CHAR_BUFFER);
                u8strlen = MApp_ZUI_API_Strlen(CHAR_BUFFER);
                CHAR_BUFFER[u8strlen++] = ((u8SW_VersionHight/100) == 0) ? ' ' : '0'+(u8SW_VersionHight/100);
                CHAR_BUFFER[u8strlen++] = (((u8SW_VersionHight%100)/10) == 0) ? ' ' : '0'+((u8SW_VersionHight%100)/10);
                CHAR_BUFFER[u8strlen++] = '0'+(u8SW_VersionHight%10);
                CHAR_BUFFER[u8strlen++] = CHAR_DOT;
                CHAR_BUFFER[u8strlen++] = ((u8SW_VersionLow/100) == 0) ? ' ' : '0'+(u8SW_VersionLow/100);
                CHAR_BUFFER[u8strlen++] = '0'+((u8SW_VersionLow%100)/10);
                CHAR_BUFFER[u8strlen++] = '0'+(u8SW_VersionLow%10);
                CHAR_BUFFER[u8strlen++] = CHAR_SPACE;
                CHAR_BUFFER[u8strlen++]= CHAR_t;
                CHAR_BUFFER[u8strlen++] = CHAR_o;
                CHAR_BUFFER[u8strlen++] = CHAR_SPACE;
                CHAR_BUFFER[u8strlen++] = 'x'; // TODO:
                CHAR_BUFFER[u8strlen++] = '.';
                CHAR_BUFFER[u8strlen++] = 'x'; // TODO:
                CHAR_BUFFER[u8strlen++] = '?';

#if  0
#ifdef  CUS_USB_UPDATE_FW
                CHAR_BUFFER[u8strlen++] = '\n';

		  {

	            U8 i;
	            U8 l ;
	            U8* pu8cusUpdateAllFileName;

			if (MW_UsbDownloadFullName() == TRUE)
			{
	           		pu8cusUpdateAllFileName = CUS_USB_DOWNLOAD_FILE_FULL_NAME;
	            		l = strlen(CUS_USB_DOWNLOAD_FILE_FULL_NAME);
			}
			else
			{
	           		pu8cusUpdateAllFileName = CUS_USB_UPDATE_ALL_FW;
	            		l = strlen(CUS_USB_UPDATE_ALL_FW);

			}

	            for (i=0; i<l; i++)
	            {
                		CHAR_BUFFER[u8strlen++] = *(pu8cusUpdateAllFileName+i);
	            }

		  }

#endif
#endif

                CHAR_BUFFER[u8strlen++] = 0;

                return CHAR_BUFFER;
              #else
                u16TempID = en_str_AreYouSure;
                break;
              #endif
           }
           break;

       #endif



        default:
            break;

    }

    if (u16TempID != Empty)
        return MApp_ZUI_API_GetString(u16TempID);
    return 0; //for empty string....

    }

///////////////////////////////////////////////////////////////////////////////
///  private  MApp_ZUI_ACT_GetMainMenuDynamicText
///  [OSD page handler] dynamic text content provider in MENU application
///
///  @param [in]       hwnd HWND     window handle we are processing
///
///  @return LPCTSTR     string content
///
///  @author MStarSemi @date 2007/1/25
///////////////////////////////////////////////////////////////////////////////
LPTSTR MApp_ZUI_ACT_GetMainMenuDynamicText(HWND hwnd)
{
#if (ENABLE_CUS_UI_SPEC == DISABLE) /*Creass.liu at 2012-06-02*/
    if (MApp_ZUI_API_IsSuccessor(HWND_MENU_APP_PAGE, hwnd))
        return MApp_ZUI_ACT_GetAppDynamicText(hwnd);

    if (MApp_ZUI_API_IsSuccessor(HWND_MENU_TIME_CLOCK_PAGE, hwnd))
        return MApp_ZUI_ACT_GetSetClockDynamicText(hwnd);

    if (MApp_ZUI_API_IsSuccessor(HWND_MENU_TIME_OFFTIME_PAGE, hwnd))
        return MApp_ZUI_ACT_GetSetOffTimeDynamicText(hwnd);
#endif

    if(HWND_MENU_BOTTOM_SELECT_TEXT==hwnd)
    {
        switch(MApp_ZUI_API_GetFocus())
        {
            case HWND_MENU_PC_PICTURE_ADVANCE_PICTURE:
            case HWND_MENU_PICTURE_ADVANCE_PICTURE:
            case HWND_MENU_CHANNEL_INFO_SAVE_CHANGED:
            case HWND_MENU_CHANNEL_PAGE2_CHANNEL:
            case HWND_MENU_OP_TIME_SUBPAGE_TIME:
            case HWND_MENU_PC_PICTURE_PC_ADJUST:

	   #if(UI_SKIN_SEL==UI_SKIN_1366X768X565_HAIER_CN)  // CUS_xm zHIHE 20120807 modify
	        case HWND_MENU_TOP_ICON_PICTURE_BIG:
            case HWND_MENU_TOP_ICON_AUDIO_BIG:
            case HWND_MENU_TOP_ICON_CHANNEL_BIG:
            case HWND_MENU_TOP_ICON_SETUP_BIG:
            case HWND_MENU_TOP_ICON_LOCK_BIG:
       #else
            case HWND_MENU_TOP_ICON_PICTURE:
            case HWND_MENU_TOP_ICON_AUDIO:
            case HWND_MENU_TOP_ICON_CHANNEL:
            case HWND_MENU_TOP_ICON_SETUP:
            case HWND_MENU_TOP_ICON_LOCK:
	   #endif
                return MApp_ZUI_API_GetString(en_str_Button_OK);
            default:
                return 0;
        }
    }

    if(HWND_MENU_BOTTOM_EXIT_TEXT==hwnd || HWND_MENU_BOTTOM_HALF_EXIT_BG==hwnd)
    {
        switch(MApp_ZUI_API_GetFocus())
        {
#if(UI_SKIN_SEL==UI_SKIN_1366X768X565_HAIER_CN)  // CUS_xm zHIHE 20120807 modify
				 case HWND_MENU_TOP_ICON_PICTURE_BIG:
				 case HWND_MENU_TOP_ICON_AUDIO_BIG:
				 case HWND_MENU_TOP_ICON_CHANNEL_BIG:
				 case HWND_MENU_TOP_ICON_SETUP_BIG:
				 case HWND_MENU_TOP_ICON_LOCK_BIG:
#else
				 case HWND_MENU_TOP_ICON_PICTURE:
				 case HWND_MENU_TOP_ICON_AUDIO:
				 case HWND_MENU_TOP_ICON_CHANNEL:
				 case HWND_MENU_TOP_ICON_SETUP:
				 case HWND_MENU_TOP_ICON_LOCK:
#endif

                return MApp_ZUI_API_GetString(en_str_Button_Exit);
            default:
                return MApp_ZUI_API_GetString(en_str_Button_Back);
        }
    }

    if (MApp_ZUI_API_IsSuccessor(HWND_MENU_TIME_ONTIME_PAGE, hwnd))
        return MApp_ZUI_ACT_GetSetOnTimeDynamicText(hwnd);

#if (ENABLE_CUS_UI_SPEC == FALSE)/*Creass.liu at 2012-06-27*/
    if (MApp_ZUI_API_IsSuccessor(HWND_MENU_OPTION_AUDIOLANG_PRIMARY, hwnd))
        return MApp_ZUI_ACT_GetSetAudLangDynamicText(hwnd);
#if ENABLE_SUBTITLE
    if (MApp_ZUI_API_IsSuccessor(HWND_MENU_OPTION_SUBLANG_PRIMARY, hwnd))
        return MApp_ZUI_ACT_GetSetSubLangDynamicText(hwnd);
#endif
    if (MApp_ZUI_API_IsSuccessor(HWND_MENU_DLG_TUNE_CONFIRM_TUNE_TYPE, hwnd))
        return MApp_ZUI_ACT_GetTuningConfirmDynamicText(hwnd);

    if (MApp_ZUI_API_IsSuccessor(HWND_MENU_DLG_TUNE_CONFIRM_COUNTRY_GRID, hwnd))
        return MApp_ZUI_CTL_GridGetDynamicText(HWND_MENU_DLG_TUNE_CONFIRM_COUNTRY_GRID, hwnd);
#endif
    if (MApp_ZUI_API_IsSuccessor(HWND_MENU_DLG_COMMON, hwnd))
        return MApp_ZUI_ACT_GetMenuCommonDynamicText(hwnd);

#if (ENABLE_CUS_UI_SPEC == FALSE) /*Creass.liu at 2012-06-27*/
    if (MApp_ZUI_API_IsSuccessor(HWND_MENU_OPTION_OSDLANG_GRID, hwnd))
        return MApp_ZUI_CTL_GridGetDynamicText(HWND_MENU_OPTION_OSDLANG_GRID, hwnd);
    if (MApp_ZUI_API_IsSuccessor(HWND_MENU_OPTION_AUDIOLANG_GRID, hwnd))
        return MApp_ZUI_CTL_GridGetDynamicText(HWND_MENU_OPTION_AUDIOLANG_GRID, hwnd);

    if (MApp_ZUI_API_IsSuccessor(HWND_MENU_OPTION_SUBLANG_GRID, hwnd))
        return MApp_ZUI_CTL_GridGetDynamicText(HWND_MENU_OPTION_SUBLANG_GRID, hwnd);

    if (MApp_ZUI_API_IsSuccessor(HWND_MENU_TIME_TIMEZONE_GRID, hwnd))
        return MApp_ZUI_CTL_GridGetDynamicText(HWND_MENU_TIME_TIMEZONE_GRID, hwnd);

    if (MApp_ZUI_API_IsSuccessor(HWND_MENU_SINGLELIST_COMMON_PAGE, hwnd))
        return MApp_ZUI_ACT_GetSingleListDynamicText(hwnd);

    if (MApp_ZUI_API_IsSuccessor(HWND_MENU_OPTIONLIST_COMMON_PAGE, hwnd))
        return MApp_ZUI_ACT_GetOptionListDynamicText(hwnd);
#ifdef NETWORK_CONFIG
    if (MApp_ZUI_API_IsSuccessor(HWND_MENU_CHECK_NETWORK, hwnd))
        return  MApp_ZUI_ACT_GetNetworkDynamicText(hwnd);
#endif
#endif
    if (MApp_ZUI_API_IsSuccessor(HWND_MENU_PREDIT_CHANNEL_LIST_PAGE, hwnd))
        return MApp_ZUI_ACT_Mainpage_GetProgramEditDynamicText(hwnd);
   if (MApp_ZUI_API_IsSuccessor(HWND_MENU_LOCK_INPUT_SUBPAGE, hwnd))
        return  MApp_ZUI_ACT_GetMenuLockDynamicText(hwnd);
   if(MApp_ZUI_API_IsSuccessor(HWND_MENU_PREDIT_KEYBOARD,hwnd) || MApp_ZUI_API_IsSuccessor(HWND_MENU_PREDIT_INFO_MSG_BOX,hwnd))
       return MApp_ZUI_CTL_KeyboardGetDynamicText(HWND_MENU_PREDIT_KEYBOARD,hwnd);
   if(MApp_ZUI_API_IsSuccessor(HWND_MENU_BG_MENUPAGE_INFO, hwnd))
       return MApp_ZUI_ACT_GetMenupageInfoDynamicText(hwnd);
   //cus_xm:zb add 2012-7-17 get USB update fw text
   if(MApp_ZUI_API_IsSuccessor(HWND_MENU_FWUPGRADE_BG, hwnd))
       return MApp_ZUI_ACT_GetMenupageInfoDynamicText(hwnd);

    return MApp_ZUI_ACT_GetMenuItemDynamicText(hwnd);
}
/////////////////////////////////////////////////////////
// Customize Window Procedures

///////////////////////////////////////////////////////////////////////////////
///  global  MApp_ZUI_ACT_ButtonAniClickWinProc
///  [MENU application customization] right bottom key icon animation
///
///  @param [in]       hwnd HWND     window handle we are processing
///  @param [in]       msg PMSG     message type
///
///  @return S32 message execute result
///
///  @author MStarSemi @date 2007/1/25
///////////////////////////////////////////////////////////////////////////////
S32 MApp_ZUI_ACT_ButtonAniClickWinProc(HWND hwnd, PMSG msg)
{
    switch(msg->message)
    {
        case MSG_PAINT:
            {
                //if a timer registered, then paint as pressing (focus state)
                if (MApp_ZUI_API_IsExistTimer(hwnd, 0))
                {
                    PAINT_PARAM * param = (PAINT_PARAM *)msg->wParam;
                    param->bIsFocus = TRUE;
                    DEFAULTWINPROC(hwnd, msg);
                    param->bIsFocus = FALSE;
                    return 0;
                }
            }
            break;

        case MSG_TIMER:
            {
                //if the time is up, kill the timer and then repaint again!
                MApp_ZUI_API_KillTimer(hwnd, 0);
                MApp_ZUI_API_InvalidateWindow(hwnd);
            }
            break;
        default:
            break;


    }

    return DEFAULTWINPROC(hwnd, msg);
}

S32 MApp_ZUI_ACT_TEXTHIDEWinProc(HWND hwnd, PMSG msg)
{
    switch(msg->message)
    {
        case MSG_TIMER:
            {
                //if the time is up, kill the timer and then repaint again!
                if(hwnd == HWND_MENU_CONFIMNEWPSW_TEXT_1 )
                {
                    MApp_ZUI_API_KillTimer(HWND_MENU_CONFIMNEWPSW_TEXT_1, 1);
    				MApp_ZUI_API_ShowWindow(HWND_MENU_CONFIMNEWPSW_TEXT_1, SW_HIDE);
    				MApp_ZUI_API_SetFocus(HWND_MENU_LOCK_NEWPSW);
                }
                else if(hwnd == HWND_MENU_LOCK_PAGE_CHECKPWD_ERROR_MSG )
                {
                    #if(UI_SKIN_SEL==UI_SKIN_1366X768X565_HAIER_CN)  // CUS_xm zHIHE 20120817 modify
                    MApp_ZUI_API_KillTimer(HWND_MENU_LOCK_PAGE_CHECKPWD_ERROR_MSG, 1);
    				MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_PAGE_CHECKPWD_ERROR_MSG, SW_HIDE);
    				MApp_ZUI_API_SetFocus(HWND_MENU_LOCK_ENTER_PASSWORD);
					MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_LOCK_BIG,FALSE);
					#else
					MApp_ZUI_API_KillTimer(HWND_MENU_LOCK_PAGE_CHECKPWD_ERROR_MSG, 1);
    				MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_PAGE_CHECKPWD_ERROR_MSG, SW_HIDE);
    				MApp_ZUI_API_SetFocus(HWND_MENU_LOCK_ENTER_PASSWORD);
					#endif

                }
	#if CUS_SMC_ENABLE_HOTEL_MODE
				else if(hwnd == HWND_HOTEL_MENU_CLONE_CONFIRM_WAITTING)
					{
					    MApp_ZUI_API_KillTimer(HWND_HOTEL_MENU_CLONE_CONFIRM_WAITTING, 1);
						MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_CLONE_CONFIRM_WAITTING, SW_HIDE);
						   //stGenSetting.g_FactorySetting.HotelMenuUSBCloneUsedFlag=TRUE;
                     if(MApp_ZUI_API_GetFocus()==HWND_HOTEL_MENU_ITEM_CAPTURE_LOGO)
					 	;
					 else
						MApp_ZUI_ACT_ExecuteFactoryMenuAction(EN_EXE_HOTEL_USB_CLONE);

					}
				else if(hwnd == HWND_HOTEL_MENU_CLONE_CONFIRM_COMPLETE)
					{
					    MApp_ZUI_API_KillTimer(HWND_HOTEL_MENU_CLONE_CONFIRM_COMPLETE, 2);
						MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_CLONE_CONFIRM_COMPLETE, SW_HIDE);
					}
				else if(hwnd == HWND_HOTEL_MENU_CHANGE_PW)
					{
					MApp_ZUI_API_KillTimer(HWND_HOTEL_MENU_CHANGE_PW, 1);
					PasswordInput1=PasswordInput2=0;
					g_u8PasswordPosition = 0;
					g_u16Password = 0;
					g_u8PasswordCount = 0;
					MApp_ZUI_API_ShowWindow(HWND_HOTEL_MENU_CHANGE_PW,SW_HIDE);
					MApp_ZUI_API_SetFocus(HWND_HOTEL_MENU_ITEM_PW_CHANGE);
				    }
	#endif
            }
            break;
        default:
            break;


    }

    return DEFAULTWINPROC(hwnd, msg);
}


///////////////////////////////////////////////////////////////////////////////
///  global  MApp_ZUI_ACT_ButtonAniClickChildWinProc
///  [MENU application customization] right bottom key icon animation (apply "focus" state if parent is button animation click
///
///  @param [in]       hwnd HWND     window handle we are processing
///  @param [in]       msg PMSG     message type
///
///  @return S32 message execute result
///
///  @author MStarSemi @date 2007/1/25
///////////////////////////////////////////////////////////////////////////////
S32 MApp_ZUI_ACT_ButtonAniClickChildWinProc(HWND hwnd, PMSG msg)
{
    switch(msg->message)
    {
        case MSG_PAINT:
            {
                HWND parent = MApp_ZUI_API_GetParent(hwnd);
                //if a timer registered, then paint as pressing (focus state)
                if (MApp_ZUI_API_IsExistTimer(parent, 0))
                {
                    PAINT_PARAM * param = (PAINT_PARAM *)msg->wParam;
                    param->bIsFocus = TRUE;
                    DEFAULTWINPROC(hwnd, msg);
                    param->bIsFocus = FALSE;
                    return 0;
                }
            }
            break;
        default:
            break;

    }

    return DEFAULTWINPROC(hwnd, msg);
}

#if 0 // no used/*Creass.liu at 2012-06-02*/
S32 MApp_ZUI_ACT_Mainpage_DynamicListWinProc(HWND hWnd, PMSG pMsg)
{
    GUI_DATA_DYNAMIC_LIST * windata = (GUI_DATA_DYNAMIC_LIST*) GETWNDDATA(hWnd);

    //no dynamic list setting data...
    if (windata == 0 || windata->pVarData == 0)
        return DEFAULTWINPROC(hWnd, pMsg);

    switch (pMsg->message)
    {
        case MSG_NOTIFY_SHOW:
        case MSG_USER:
        case MSG_NOTIFY_KEYDOWN:
        case MSG_NOTIFY_HIDE:
            {
                MApp_ZUI_CTL_DynamicListWinProc(hWnd, pMsg);

                HWND child, last_succ, first, second;
                RECT rect_first, rect_second;
                last_succ = MApp_ZUI_API_GetLastSuccessor(hWnd);
                for (child = hWnd+1; child <= last_succ; child++)
                {
                    if ( hWnd != MApp_ZUI_API_GetParent(child) ) continue;
                    if ( FALSE == MApp_ZUI_API_IsWindowVisible(child) ) continue;
                    if ( MApp_ZUI_API_CountChildren(child) < 2 ) continue;
                    first = child + 1;
                    second = child + 2;
                    MApp_ZUI_API_GetWindowRect(first, &rect_first);
                    U16 u16TextIndex = _MApp_ZUI_API_FindFirstComponentIndex(first, DS_NORMAL, CP_TEXT_OUT);
                    DRAW_TEXT_OUT draw;
                    _MApp_ZUI_API_ConvertComponentToDynamic(CP_TEXT_OUT, u16TextIndex, &draw);
                    OSDClrBtn clrBtn;
                    LPTSTR pstr = MApp_ZUI_API_GetString(draw.StringID);
                    clrBtn.bStringIndexWidth = CHAR_IDX_2BYTE;
                    clrBtn.Fontfmt.flag = draw.flag;
                    clrBtn.Fontfmt.ifont_gap = draw.u8dis;
                    U16 u16Width = msAPI_OSD_GetStrWidth(Font[draw.eSystemFont].fHandle, (U8*)pstr, &clrBtn);
                    MApp_ZUI_API_GetWindowRect(second, &rect_second);
                    rect_second.left = rect_first.left + u16Width + 10 ;
                    MApp_ZUI_API_MoveWindow(second, &rect_second);
                }
            }
            return 0;

        default:
            break;
    }

    return MApp_ZUI_CTL_DynamicListWinProc(hWnd, pMsg);
}

#endif
/*
COMMON_SINGLELIST_MODE MApp_ZUI_ACT_GetSingleListMode(void)
{
    return _eCommonSingleMode;
}
*/
void _MApp_ZUI_ACT_CombineSleepTimerString(LPTSTR str, U32 TIMER)
{
    U32 u32SleepTime = TIMER;
    U8 u8SleepDigits = MApp_GetNoOfDigit(u32SleepTime);
    __MApp_UlongToString(u32SleepTime, str, u8SleepDigits);
    MApp_ZUI_API_LoadString(en_str_SleepTimer_Min, str + u8SleepDigits);
}

#if (ENABLE_CUS_UI_SPEC == FALSE) /*Creass.liu at 2012-06-27*/
COMMON_SINGLELIST_MODE MApp_ZUI_ACT_GetSingleListMode(void)
{
    return _eCommonSingleMode;
}

LPTSTR MApp_ZUI_ACT_GetAppDynamicText(HWND hwnd)
{
    switch (hwnd)
    {
        case HWND_MENU_APP1_TEXT:
        case HWND_MENU_APP2_TEXT:
        case HWND_MENU_APP3_TEXT:
        case HWND_MENU_APP4_TEXT:
        case HWND_MENU_APP5_TEXT:
        case HWND_MENU_APP6_TEXT:
        case HWND_MENU_APP7_TEXT:
        case HWND_MENU_APP8_TEXT:
        case HWND_MENU_APP9_TEXT:
        case HWND_MENU_APP10_TEXT:
        case HWND_MENU_APP11_TEXT:
        case HWND_MENU_APP12_TEXT:
        case HWND_MENU_APP13_TEXT:
        case HWND_MENU_APP14_TEXT:
        case HWND_MENU_APP15_TEXT:
        case HWND_MENU_APP16_TEXT:
        case HWND_MENU_APP17_TEXT:
            {
#if OBA2
                APP_INFO info;
                bool bSucc = false;
                HWND hParent;
                int nIndex = 0;

                hParent = MApp_ZUI_API_GetParent(hwnd);
                nIndex = MApp_ZUI_API_GetChildIndex(hParent);
                if ( nIndex < 0 ) break;

                bSucc = MAdp_APMNG_GetApInfoByIndex(au8VisibleAPPList[nIndex], &info);
                if (bSucc == false ) break;

                return MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, (U8*)info.name, 255);
#else
                HWND hParent;
                int nIndex = 0;
                hParent = MApp_ZUI_API_GetParent(hwnd);
                nIndex = MApp_ZUI_API_GetChildIndex(hParent);
                if ( nIndex < 0 ) break;
                return MApp_ZUI_API_GetString(MApp_ZUI_ACT_GetAppItemString(nIndex));
#endif
            }
            break;

        default:
            break;
    }

    return 0; //for empty string....
}

LPTSTR MApp_ZUI_ACT_GetSingleListDynamicText(HWND hwnd)
{
    U16 u16TempID = Empty;

    switch(hwnd)
    {
        case HWND_MENU_SINGLELIST_TITLE_OPTION:
            switch(_eCommonSingleMode)
            {
                case EN_COMMON_SINGLELIST_ASPECT_RATIO:
                    u16TempID = en_str_AspectRatio;
                    break;
                case EN_COMMON_SINGLELIST_NOISE_REDUCTION:
                    u16TempID = en_str_NR;
                    break;
                case EN_COMMON_SINGLELIST_SURROUND_SOUND:
                    u16TempID = en_str_SurroundSound;
                    break;
                case EN_COMMON_SINGLELIST_SLEEP_TIMER:
                    u16TempID = en_str_SleepTimer;
                    break;
                case EN_COMMON_SINGLELIST_PARENTAL_GUIDANCE:
                    u16TempID = en_str_ParentalGuidance;
                    break;

            #if (ATSC_CC == ATV_CC)
                case EN_COMMON_SINGLELIST_CC_OPTION:
                    u16TempID = en_str_Caption;
                    break;
            #endif
            #if ENABLE_3D_PROCESS
                case EN_COMMON_SINGLELIST_3D_OPTION:
                    u16TempID = en_str3DType;
                    break;
            #endif

                default:
                    break;
            }
            break;

        case HWND_MENU_SINGLELIST_ITEM1_OPTION:
            switch(_eCommonSingleMode)
            {
                case EN_COMMON_SINGLELIST_ASPECT_RATIO:
                    u16TempID = en_str_AspectRatio_Original;
                    break;
                case EN_COMMON_SINGLELIST_NOISE_REDUCTION:
                    u16TempID = en_str_Off;
                    break;
                case EN_COMMON_SINGLELIST_SURROUND_SOUND:
                    u16TempID = en_str_Off;
                    break;
                case EN_COMMON_SINGLELIST_SLEEP_TIMER:
                    u16TempID = en_str_SleepTimer_Cancel;
                    break;
                case EN_COMMON_SINGLELIST_PARENTAL_GUIDANCE:
                    u16TempID = en_str_Off;
                    break;

            #if (ATSC_CC == ATV_CC)
                case EN_COMMON_SINGLELIST_CC_OPTION:
                    u16TempID = en_str_Off;
                    break;
            #endif
            #if ENABLE_3D_PROCESS
                case EN_COMMON_SINGLELIST_3D_OPTION:
                    u16TempID = en_strbypass;
                    break;
            #endif

                default:
                    break;
            }
            break;
        case HWND_MENU_SINGLELIST_ITEM2_OPTION:
             switch(_eCommonSingleMode)
            {
                case EN_COMMON_SINGLELIST_ASPECT_RATIO:
                    u16TempID = en_str_AspectRatio_4X3;
                    break;
                case EN_COMMON_SINGLELIST_NOISE_REDUCTION:
                    u16TempID = en_str_LOW;
                    break;
                case EN_COMMON_SINGLELIST_SURROUND_SOUND:
                    u16TempID = en_str_Surround_Max;
                    break;
                case EN_COMMON_SINGLELIST_SLEEP_TIMER:
                    _MApp_ZUI_ACT_CombineSleepTimerString(CHAR_BUFFER, 10);
                    return CHAR_BUFFER;

                case EN_COMMON_SINGLELIST_PARENTAL_GUIDANCE:
                  #if ENABLE_SBTVD_BRAZIL_APP
                    return MApp_ZUI_API_GetU16String(EN_F4_LockSystem_Min+2);
                  #else
                    return MApp_ZUI_API_GetU16String(EN_F4_LockSystem_Min+1);
                  #endif

            #if (ATSC_CC == ATV_CC)
                case EN_COMMON_SINGLELIST_CC_OPTION:
                    u16TempID = en_str_CC1;
                    break;
            #endif
            #if ENABLE_3D_PROCESS
                case EN_COMMON_SINGLELIST_3D_OPTION:
                    u16TempID = en_strFrame_parking;
                    break;
            #endif

                default:
                    break;
            }
            break;
        case HWND_MENU_SINGLELIST_ITEM3_OPTION:
             switch(_eCommonSingleMode)
            {
                case EN_COMMON_SINGLELIST_ASPECT_RATIO:
                    u16TempID = en_str_AspectRatio_16X9;
                    break;
                case EN_COMMON_SINGLELIST_NOISE_REDUCTION:
                    u16TempID = en_str_MIDDLE;
                    break;

            #if (ENABLE_AUDIO_SURROUND_SRS == ENABLE )
                case EN_COMMON_SINGLELIST_SURROUND_SOUND:
                    u16TempID = en_str_SRSTruSurroundXT;
                    break;
            #endif

                case EN_COMMON_SINGLELIST_SLEEP_TIMER:
                    _MApp_ZUI_ACT_CombineSleepTimerString(CHAR_BUFFER, 20);
                    return CHAR_BUFFER;

                case EN_COMMON_SINGLELIST_PARENTAL_GUIDANCE:
                  #if ENABLE_SBTVD_BRAZIL_APP
                    return MApp_ZUI_API_GetU16String(EN_F4_LockSystem_Min+4);
                  #else
                    return MApp_ZUI_API_GetU16String(EN_F4_LockSystem_Min+2);
                  #endif

            #if (ATSC_CC == ATV_CC)
                case EN_COMMON_SINGLELIST_CC_OPTION:
                    u16TempID = en_str_CC2;
                    break;
            #endif
            #if ENABLE_3D_PROCESS
                case EN_COMMON_SINGLELIST_3D_OPTION:
                    u16TempID = en_strside_by_side;
                    break;
            #endif

                default:
                    break;
            }
            break;

        case HWND_MENU_SINGLELIST_ITEM4_OPTION:
             switch(_eCommonSingleMode)
            {
                case EN_COMMON_SINGLELIST_ASPECT_RATIO:
                    u16TempID = en_str_AspectRatio_14x9;
                    break;
                case EN_COMMON_SINGLELIST_NOISE_REDUCTION:
                    u16TempID = en_str_HIGH;
                    break;

            #if (ENABLE_AUDIO_SURROUND_BBE == ENABLE )
                case EN_COMMON_SINGLELIST_SURROUND_SOUND:
                    u16TempID = en_str_BBE;
                    break;
            #endif

                case EN_COMMON_SINGLELIST_SLEEP_TIMER:
                    _MApp_ZUI_ACT_CombineSleepTimerString(CHAR_BUFFER, 30);
                    return CHAR_BUFFER;

                case EN_COMMON_SINGLELIST_PARENTAL_GUIDANCE:
                  #if ENABLE_SBTVD_BRAZIL_APP
                    return MApp_ZUI_API_GetU16String(EN_F4_LockSystem_Min+6);
                  #else
                    return MApp_ZUI_API_GetU16String(EN_F4_LockSystem_Min+3);
                  #endif

            #if (ATSC_CC == ATV_CC)
                case EN_COMMON_SINGLELIST_CC_OPTION:
                    u16TempID = en_str_CC3;
                    break;
            #endif
            #if ENABLE_3D_PROCESS
                case EN_COMMON_SINGLELIST_3D_OPTION:
                    u16TempID = en_strtop_bottom;
                    break;
            #endif

                default:
                    break;
            }
            break;

        case HWND_MENU_SINGLELIST_ITEM5_OPTION:
             switch(_eCommonSingleMode)
            {
                case EN_COMMON_SINGLELIST_ASPECT_RATIO:
                    u16TempID = en_str_AspectRatio_Zoom1;
                    break;

                case EN_COMMON_SINGLELIST_NOISE_REDUCTION:
                  #if(_AutoNR_EN_)
                    u16TempID = en_str_AUTO;
                  #else
                    u16TempID = en_str_DEFAULT;
                  #endif
                    break;

            #if (ENABLE_AUDIO_SURROUND_VDS  == ENABLE )
                case EN_COMMON_SINGLELIST_SURROUND_SOUND:
                    u16TempID = en_str_DolbyVirtual;
                    break;
            #endif

                case EN_COMMON_SINGLELIST_SLEEP_TIMER:
                    _MApp_ZUI_ACT_CombineSleepTimerString(CHAR_BUFFER, 60);
                    return CHAR_BUFFER;

                case EN_COMMON_SINGLELIST_PARENTAL_GUIDANCE:
                  #if ENABLE_SBTVD_BRAZIL_APP
                    return MApp_ZUI_API_GetU16String(EN_F4_LockSystem_Min+8);
                  #else
                    return MApp_ZUI_API_GetU16String(EN_F4_LockSystem_Min+4);
                  #endif

            #if (ATSC_CC == ATV_CC)
                case EN_COMMON_SINGLELIST_CC_OPTION:
                    u16TempID = en_str_CC4;
                    break;
            #endif
            #if ENABLE_3D_PROCESS
                case EN_COMMON_SINGLELIST_3D_OPTION:
                    u16TempID = en_strline_by_line;
                    break;
            #endif

                default:
                    break;
            }
            break;
        case HWND_MENU_SINGLELIST_ITEM6_OPTION:
             switch(_eCommonSingleMode)
            {
                case EN_COMMON_SINGLELIST_ASPECT_RATIO:
                    u16TempID = en_str_AspectRatio_Zoom2;
                    break;

                case EN_COMMON_SINGLELIST_NOISE_REDUCTION:
                  #if(_AutoNR_EN_)
                    u16TempID = en_str_DEFAULT;
                  #endif
                    break;

            #if (ENABLE_AUDIO_SURROUND_VSPK  == ENABLE )
                case EN_COMMON_SINGLELIST_SURROUND_SOUND:
                    u16TempID = en_str_DolbyVS;
                    break;
            #endif

                case EN_COMMON_SINGLELIST_SLEEP_TIMER:
                    _MApp_ZUI_ACT_CombineSleepTimerString(CHAR_BUFFER, 90);
                    return CHAR_BUFFER;

                case EN_COMMON_SINGLELIST_PARENTAL_GUIDANCE:
                  #if ENABLE_SBTVD_BRAZIL_APP
                    return MApp_ZUI_API_GetU16String(EN_F4_LockSystem_Min+10);
                  #else
                    return MApp_ZUI_API_GetU16String(EN_F4_LockSystem_Min+5);
                  #endif

            #if (ATSC_CC == ATV_CC)
                case EN_COMMON_SINGLELIST_CC_OPTION:
                    u16TempID = en_str_Text1;
                    break;
            #endif
            #if ENABLE_3D_PROCESS
                case EN_COMMON_SINGLELIST_3D_OPTION:
                    u16TempID = en_strFrame_alternative;
                    break;
            #endif

                default:
                    break;
            }
            break;

        case HWND_MENU_SINGLELIST_ITEM7_OPTION:
             switch(_eCommonSingleMode)
            {
                case EN_COMMON_SINGLELIST_ASPECT_RATIO:
                    u16TempID = en_str_AspectRatio_JustScan;
                    break;
                case EN_COMMON_SINGLELIST_SLEEP_TIMER:
                    _MApp_ZUI_ACT_CombineSleepTimerString(CHAR_BUFFER, 120);
                    return CHAR_BUFFER;
                case EN_COMMON_SINGLELIST_PARENTAL_GUIDANCE:
                    return MApp_ZUI_API_GetU16String(EN_F4_LockSystem_Min+6);

            #if (ATSC_CC == ATV_CC)
                case EN_COMMON_SINGLELIST_CC_OPTION:
                    u16TempID = en_str_Text2;
                    break;
            #endif
            #if ENABLE_3D_PROCESS
                case EN_COMMON_SINGLELIST_3D_OPTION:
                    u16TempID = en_strnormal_2d;
                    break;
            #endif

                default:
                    break;
            }
            break;
        case HWND_MENU_SINGLELIST_ITEM8_OPTION:
             switch(_eCommonSingleMode)
            {
                case EN_COMMON_SINGLELIST_ASPECT_RATIO:
                    u16TempID = en_str_AspectRatio_Panorama;
                    break;
                case EN_COMMON_SINGLELIST_SLEEP_TIMER:
                    _MApp_ZUI_ACT_CombineSleepTimerString(CHAR_BUFFER, 180);
                    return CHAR_BUFFER;
                case EN_COMMON_SINGLELIST_PARENTAL_GUIDANCE:
                    return MApp_ZUI_API_GetU16String(EN_F4_LockSystem_Min+7);

		#if  (ATSC_CC == ATV_CC)
                case EN_COMMON_SINGLELIST_CC_OPTION:
                    u16TempID = en_str_Text3;
                    break;
		#endif
            #if ENABLE_3D_PROCESS
                case EN_COMMON_SINGLELIST_3D_OPTION:
                    u16TempID = en_str3D_2D;
                    break;
            #endif

                default:
                    break;
            }
            break;
        case HWND_MENU_SINGLELIST_ITEM9_OPTION:
             switch(_eCommonSingleMode)
            {
      #if VGA_HDMI_YUV_POINT_TO_POINT
               case EN_COMMON_SINGLELIST_ASPECT_RATIO:
                    u16TempID = en_str_AspectRatio_PointToPoint;
                    break;
     #endif
                case EN_COMMON_SINGLELIST_SLEEP_TIMER:
                    _MApp_ZUI_ACT_CombineSleepTimerString(CHAR_BUFFER, 240);
                    return CHAR_BUFFER;
                case EN_COMMON_SINGLELIST_PARENTAL_GUIDANCE:
                    return MApp_ZUI_API_GetU16String(EN_F4_LockSystem_Min+8);

			#if  (ATSC_CC == ATV_CC)
                case EN_COMMON_SINGLELIST_CC_OPTION:
                    u16TempID = en_str_Text4;
                    break;
			#endif

                default:
                    break;
            }
            break;
        case HWND_MENU_SINGLELIST_ITEM10_OPTION:
             switch(_eCommonSingleMode)
            {
                case EN_COMMON_SINGLELIST_PARENTAL_GUIDANCE:
                    return MApp_ZUI_API_GetU16String(EN_F4_LockSystem_Min+9);
                default:
                    break;
            }
            break;
        case HWND_MENU_SINGLELIST_ITEM11_OPTION:
             switch(_eCommonSingleMode)
            {
                case EN_COMMON_SINGLELIST_PARENTAL_GUIDANCE:
                    return MApp_ZUI_API_GetU16String(EN_F4_LockSystem_Min+10);;
                default:
                    break;
            }
            break;
        case HWND_MENU_SINGLELIST_ITEM12_OPTION:
             switch(_eCommonSingleMode)
            {
                case EN_COMMON_SINGLELIST_PARENTAL_GUIDANCE:
                    return MApp_ZUI_API_GetU16String(EN_F4_LockSystem_Min+11);;
                default:
                    break;
            }
            break;
        case HWND_MENU_SINGLELIST_ITEM13_OPTION:
             switch(_eCommonSingleMode)
            {
                case EN_COMMON_SINGLELIST_PARENTAL_GUIDANCE:
                    return MApp_ZUI_API_GetU16String(EN_F4_LockSystem_Min+12);
                default:
                    break;
            }
            break;
        case HWND_MENU_SINGLELIST_ITEM14_OPTION:
             switch(_eCommonSingleMode)
            {
                case EN_COMMON_SINGLELIST_PARENTAL_GUIDANCE:
                    return MApp_ZUI_API_GetU16String(EN_F4_LockSystem_Min+13);
                default:
                    break;
            }
            break;
        case HWND_MENU_SINGLELIST_ITEM15_OPTION:
             switch(_eCommonSingleMode)
            {
                case EN_COMMON_SINGLELIST_PARENTAL_GUIDANCE:
                    return MApp_ZUI_API_GetU16String(EN_F4_LockSystem_Min+14);
                default:
                    break;
            }
            break;
        case HWND_MENU_SINGLELIST_ITEM16_OPTION:
             switch(_eCommonSingleMode)
            {
                case EN_COMMON_SINGLELIST_PARENTAL_GUIDANCE:
                    return MApp_ZUI_API_GetU16String(EN_F4_LockSystem_Min+15);
                default:
                    break;
            }
            break;
        default:
            break;
    }

    if (u16TempID != Empty)
        return MApp_ZUI_API_GetString(u16TempID);
    return 0; //for empty string....
}

COMMON_OPTIONLIST_MODE MApp_ZUI_ACT_GetOptionListMode(void)
{
    return _eCommonOptionMode;
}

void  MApp_ZUI_ACT_SetOptionListMode(COMMON_OPTIONLIST_MODE mode)
{
    _eCommonOptionMode = mode;
}


LPTSTR MApp_ZUI_ACT_GetOptionListDynamicText(HWND hwnd)
{
    U16 u16TempID = Empty;

    switch(hwnd)
    {
        case HWND_MENU_OPTIONLIST_TITLE_OPTION:
            switch(_eCommonOptionMode)
            {
#ifdef NETWORK_CONFIG
                case EN_COMMON_OPTIONLIST_NETWORK_DNS:
                    u16TempID = en_str_DNS;
                    break;
                case EN_COMMON_OPTIONLIST_NETWORK_GW:
                    u16TempID = en_str_GW;
                    break;
                case EN_COMMON_OPTIONLIST_NETWORK_IP:
                    u16TempID = en_str_IP;
                    break;
                case EN_COMMON_OPTIONLIST_NETWORK_NETMASK:
                    u16TempID = en_str_NETMASK;
                    break;
 #endif
                case EN_COMMON_OPTIONLIST_SOUND_BALANCE:
                    u16TempID = en_str_Balance;
                    break;
                default:
                    break;
            }
            break;

        case HWND_MENU_OPTIONLIST_ITEM1_TEXT:
            switch(_eCommonOptionMode)
            {
#ifdef NETWORK_CONFIG
                case EN_COMMON_OPTIONLIST_NETWORK_CONFIG:
                    u16TempID = en_str_NET_CONFIG;
                    break;
#endif
                default:
                    break;
            }
            break;

        case HWND_MENU_OPTIONLIST_ITEM1_OPTION:
            switch(_eCommonOptionMode)
            {
#ifdef NETWORK_CONFIG
                case EN_COMMON_OPTIONLIST_NETWORK_CONFIG:
                    return MApp_ZUI_ACT_GetNetConfigDynamicText(HWND_MENU_OPTIONLIST_ITEM1_OPTION);
#endif
                default:
                    break;
            }
            break;

        case HWND_MENU_OPTIONLIST_ITEM2_OPTION:
            switch(_eCommonOptionMode)
            {
#ifdef NETWORK_CONFIG
                case EN_COMMON_OPTIONLIST_NETWORK_DNS:
                    return MApp_ZUI_ACT_GetNetDNSDynamicText(HWND_MENU_OPTIONLIST_ITEM2_OPTION);
                case EN_COMMON_OPTIONLIST_NETWORK_GW:
                    return MApp_ZUI_ACT_GetNetGatewayDynamicText(HWND_MENU_OPTIONLIST_ITEM2_OPTION);
                case EN_COMMON_OPTIONLIST_NETWORK_IP:
                    return MApp_ZUI_ACT_GetNetIPDynamicText(HWND_MENU_OPTIONLIST_ITEM2_OPTION);
                case EN_COMMON_OPTIONLIST_NETWORK_NETMASK:
                    return MApp_ZUI_ACT_GetNetNetmaskDynamicText(HWND_MENU_OPTIONLIST_ITEM2_OPTION);
                case EN_COMMON_OPTIONLIST_NETWORK_CONFIG:
                    return MApp_ZUI_ACT_GetNetConfigDynamicText(HWND_MENU_OPTIONLIST_ITEM2_OPTION);
#endif
                case EN_COMMON_OPTIONLIST_SOUND_BALANCE:
                    return MApp_ZUI_API_GetS16SignString((S16)_MApp_ZUI_ACT_GetBalanceValue()-50);
                default:
                    break;
            }
            break;
        case HWND_MENU_OPTIONLIST_ITEM3_OPTION:
             switch(_eCommonOptionMode)
            {
#ifdef NETWORK_CONFIG
                case EN_COMMON_OPTIONLIST_NETWORK_DNS:
                    return MApp_ZUI_ACT_GetNetDNSDynamicText(HWND_MENU_OPTIONLIST_ITEM3_OPTION);
                case EN_COMMON_OPTIONLIST_NETWORK_GW:
                    return MApp_ZUI_ACT_GetNetGatewayDynamicText(HWND_MENU_OPTIONLIST_ITEM3_OPTION);
                case EN_COMMON_OPTIONLIST_NETWORK_IP:
                    return MApp_ZUI_ACT_GetNetIPDynamicText(HWND_MENU_OPTIONLIST_ITEM3_OPTION);
                case EN_COMMON_OPTIONLIST_NETWORK_NETMASK:
                    return MApp_ZUI_ACT_GetNetNetmaskDynamicText(HWND_MENU_OPTIONLIST_ITEM3_OPTION);
                case EN_COMMON_OPTIONLIST_NETWORK_CONFIG:
                    return MApp_ZUI_ACT_GetNetConfigDynamicText(HWND_MENU_OPTIONLIST_ITEM3_OPTION);
#endif
                default:
                    break;
            }
            break;
        case HWND_MENU_OPTIONLIST_ITEM4_OPTION:
             switch(_eCommonOptionMode)
            {
#ifdef NETWORK_CONFIG
                case EN_COMMON_OPTIONLIST_NETWORK_DNS:
                   return MApp_ZUI_ACT_GetNetDNSDynamicText(HWND_MENU_OPTIONLIST_ITEM4_OPTION);
                case EN_COMMON_OPTIONLIST_NETWORK_GW:
                    return MApp_ZUI_ACT_GetNetGatewayDynamicText(HWND_MENU_OPTIONLIST_ITEM4_OPTION);
                case EN_COMMON_OPTIONLIST_NETWORK_IP:
                    return MApp_ZUI_ACT_GetNetIPDynamicText(HWND_MENU_OPTIONLIST_ITEM4_OPTION);
                case EN_COMMON_OPTIONLIST_NETWORK_NETMASK:
                    return MApp_ZUI_ACT_GetNetNetmaskDynamicText(HWND_MENU_OPTIONLIST_ITEM4_OPTION);
                case EN_COMMON_OPTIONLIST_NETWORK_CONFIG:
                    return MApp_ZUI_ACT_GetNetConfigDynamicText(HWND_MENU_OPTIONLIST_ITEM4_OPTION);
#endif
                default:
                    break;
            }
            break;
        case HWND_MENU_OPTIONLIST_ITEM5_OPTION:
             switch(_eCommonOptionMode)
            {
#ifdef NETWORK_CONFIG
                case EN_COMMON_OPTIONLIST_NETWORK_DNS:
                   return MApp_ZUI_ACT_GetNetDNSDynamicText(HWND_MENU_OPTIONLIST_ITEM5_OPTION);
                case EN_COMMON_OPTIONLIST_NETWORK_GW:
                    return MApp_ZUI_ACT_GetNetGatewayDynamicText(HWND_MENU_OPTIONLIST_ITEM5_OPTION);
                case EN_COMMON_OPTIONLIST_NETWORK_IP:
                    return MApp_ZUI_ACT_GetNetIPDynamicText(HWND_MENU_OPTIONLIST_ITEM5_OPTION);
                case EN_COMMON_OPTIONLIST_NETWORK_NETMASK:
                    return MApp_ZUI_ACT_GetNetNetmaskDynamicText(HWND_MENU_OPTIONLIST_ITEM5_OPTION);
                case EN_COMMON_OPTIONLIST_NETWORK_CONFIG:
                    return MApp_ZUI_ACT_GetNetConfigDynamicText(HWND_MENU_OPTIONLIST_ITEM5_OPTION);
#endif
                default:
                    break;
            }
            break;
        case HWND_MENU_OPTIONLIST_ITEM6_OPTION:
             switch(_eCommonOptionMode)
            {
#ifdef NETWORK_CONFIG
                case EN_COMMON_OPTIONLIST_NETWORK_CONFIG:
                    return MApp_ZUI_ACT_GetNetConfigDynamicText(HWND_MENU_OPTIONLIST_ITEM6_OPTION);;
#endif
                default:
                    break;
            }
            break;
        case HWND_MENU_OPTIONLIST_ITEM7_OPTION:
             switch(_eCommonOptionMode)
            {
#ifdef NETWORK_CONFIG
                case EN_COMMON_OPTIONLIST_NETWORK_CONFIG:
                    u16TempID = en_str_MAC;
                    break;
#endif
                default:
                    break;
            }
            break;

    }

    if (u16TempID != Empty)
        return MApp_ZUI_API_GetString(u16TempID);
    return 0; //for empty string....
}
#endif /*Creass.liu at 2012-06-27*/

#if ENABLE_SUBTITLE
BOOLEAN MApp_ZUI_ACT_ExecuteSetSubLangDialogAction(U16 act)
{
    switch(act)
    {
        case EN_EXE_SUBLANG_SET:
            stGenSetting.g_SysSetting.fSUBLANG_FLAG = !stGenSetting.g_SysSetting.fSUBLANG_FLAG;
            MApp_ZUI_API_InvalidateWindow(HWND_MENU_OPTION_SUBLANG_PRIMARY_OPTION);
            return true;

                  default:
             ZUI_DBG_FAIL(printf("[ZUI]SetSubtitleLangACT\n"));
             ABORT();
    }
    return FALSE;
}

LPTSTR MApp_ZUI_ACT_GetSetSubLangDynamicText(HWND hwnd)
{
    U16 u16TempID = Empty;

    switch(hwnd)
    {
        case HWND_MENU_OPTION_SUBLANG_PRIMARY_OPTION:
         {
            if(!stGenSetting.g_SysSetting.fSUBLANG_FLAG)
                u16TempID=en_str_Primary;
            else
                u16TempID=en_str_Secondary;
            break;
         }
    }

   if (u16TempID != Empty)
             return MApp_ZUI_API_GetString(u16TempID);

   return 0; //for empty string....
}
#endif

void  MApp_ZUI_ACT_SetTargetMenuState(EN_MENU_STATE MenuState)
{
    _enTargetMenuState=MenuState;
}

#if ENABLE_3D_PROCESS
void msAPI_Process3DHotKey(void)
{
    MApp_ZUI_ACT_StartupOSD(E_OSD_MAIN_MENU);
    enMainMenuState = STATE_MENU_WAIT;
    MApp_TopStateMachine_SetTopState(STATE_TOP_MENU);

    MApp_ZUI_API_ShowWindow(HWND_MENU_PICTURE_PAGE, SW_HIDE);
    MApp_ZUI_API_ShowWindow(HWND_MENU_PC_PICTURE_PAGE, SW_HIDE);//cus_xm:zb add at 2012-8-11
    MApp_ZUI_API_ShowWindow(HWND_MENU_OPTION_3D_SETUP_PAGE,SW_SHOW);
    MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_SETUP,FALSE);

    if((stGenSetting.g_SysSetting.en3DDetectMode == EN_3D_DETECT_AUTO) && (IsHDMIInUse() && g_HdmiPollingStatus.bIsHDMIMode))
    {
        MApp_ZUI_API_SetFocus(HWND_MENU_OPTION_3D_DETECT);
    }
    else
    {
        MApp_ZUI_API_SetFocus(HWND_MENU_OPTION_3D_TYPE);
    }
    u8KeyCode = KEY_NULL;
}
#endif

#if ENABLE_UI_3D_PROCESS
void msAPI_Process3Dui(void)
{
    if(stGenSetting.g_SysSetting.en3DUIMODE == E_UI_3D_UI_MODE_NUM)
    {
        extern void MApp_ZUI_ACT_SetEnv3DOutputMode(E_UI_3D_UI_MODE eDirectType);
        extern EN_MENU_STATE enMainMenuState;
        static U32 ucLoop = 0;
        //printf("ucLoop = %d\n", ucLoop);
        //msAPI_Timer_Delayms(10);
        if(ucLoop > 3)
        {
            ucLoop = 0;
            //msAPI_Scaler_SetBlueScreen( ENABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
            if(ST_3D_TYPE == EN_3D_TOP_BOTTOM)
                stGenSetting.g_SysSetting.en3DUIMODE = E_UI_3D_UI_TOP_BOTTOM;
            else if(ST_3D_TYPE == EN_3D_SIDE_BY_SIDE)
                stGenSetting.g_SysSetting.en3DUIMODE = E_UI_3D_UI_SIDE_BY_SIDE_HALF;
            else
                stGenSetting.g_SysSetting.en3DUIMODE = E_UI_3D_UI_MODE_NONE;
            MApp_ZUI_ACT_SetEnv3DOutputMode(stGenSetting.g_SysSetting.en3DUIMODE);
            //printf("m_enDmpVar.enDmpState = %d\n", MApp_DMP_GetDMPStat());

            if(g_bIsImageFrozen)
            {
                g_bIsImageFrozen = FALSE;
                MApi_XC_FreezeImg(g_bIsImageFrozen, MAIN_WINDOW);
            }
            MApp_ZUI_ACT_StartupOSD(E_OSD_MAIN_MENU);
			enMainMenuState = STATE_MENU_WAIT;
            MApp_TopStateMachine_SetTopState(STATE_TOP_MENU);

            _eCommonSingleMode = EN_COMMON_SINGLELIST_3D_OPTION;
            MApp_ZUI_API_ShowWindow(HWND_MAINFRAME, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_MASK_BACKGROUND, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_OPTION_PAGE, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_SINGLELIST_COMMON_PAGE, SW_SHOW);
            if(IsSrcTypeStorage(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)))
            {
                MApp_ZUI_API_ShowWindow(HWND_DMP_ROOT_TRANSPARENT_BG, SW_SHOW);
                MApp_DMP_SetDMPStat(DMP_STATE_RETURN_FROM_MENU);
            }
            else
                MApp_ZUI_API_ShowWindow(HWND_MENU_TRANSPARENT_BG, SW_SHOW);
            switch(ST_3D_TYPE)
            {
                case EN_3D_BYPASS:
                    MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM1);
                    break;
                case EN_3D_FRAME_PARKING:
                    MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM2);
                    break;
                case EN_3D_SIDE_BY_SIDE:
                    MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM3);
                    break;
                case EN_3D_TOP_BOTTOM:
                    MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM4);
                    break;
                case EN_3D_LINE_BY_LINE:
                    MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM5);
                    break;
                case EN_3D_FRAME_ALTERNATIVE:
                    MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM6);
                    break;
                case EN_3D_NORMAL_2D:
                    MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM7);
                    break;
		  case EN_3D_3D_TO_2D:
                    MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST, HWND_MENU_SINGLELIST_ITEM8);
                    break;
                default:
                    MApp_ZUI_API_SetFocus(HWND_MENU_SINGLELIST_ITEM1);
                    break;
            }
            msAPI_Scaler_SetBlueScreen( DISABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
        }
        ucLoop++;
    }
}
#endif

#if ENABLE_CUS_UI_SPEC
BOOLEAN MApp_ZUI_ACT_bIsCurrentOSDisAutoScanPage(void)
{
    if((MApp_ZUI_GetActiveOSD() == E_OSD_MAIN_MENU) && (MApp_ZUI_API_GetFocus() == HWND_MENU_CHANNEL_SCAN_PAGE_PROGRESS_BAR))
    {
        return TRUE;
    }
    else
    {
        return FALSE;;
    }
}

#endif
OSD_COLOR MApp_ZUI_ACT_GetMenuMainDynamicColor(HWND hwnd, DRAWSTYLE_TYPE type, OSD_COLOR colorOriginal)
{
    UNUSED(type);
		// CUS_XM Xue 20120730: modify follow item show white issue,so update blue different
    if(HWND_MENU_TIME_SET_DATE == MApp_ZUI_API_GetFocus())
    {
        switch(hwnd)
        {
            case HWND_MENU_TIME_SET_DATE_OPTION_YEAR_1:
                if(g_u8IdleMainpageDigitKeyCount < 1)
                {
                    return 0x0000ff;
                }
                break;
            case HWND_MENU_TIME_SET_DATE_OPTION_YEAR_2:
                if(g_u8IdleMainpageDigitKeyCount == 1)
                {
                    return 0x0000ff;
                }
                break;
            case HWND_MENU_TIME_SET_DATE_OPTION_YEAR_3:
                if(g_u8IdleMainpageDigitKeyCount == 2)
                {
                    return 0x0000ff;
                }
                break;
            case HWND_MENU_TIME_SET_DATE_OPTION_YEAR_4:
                if(g_u8IdleMainpageDigitKeyCount == 3)
                {
                    return 0x0000ff;
                }
                break;
            case HWND_MENU_TIME_SET_DATE_OPTION_MONTH_1:
                if(g_u8IdleMainpageDigitKeyCount == 4)
                {
                    return 0x0000ff;
                }
                break;
            case HWND_MENU_TIME_SET_DATE_OPTION_MONTH_2:
                if(g_u8IdleMainpageDigitKeyCount == 5)
                {
                    return 0x0000ff;
                }
                break;
            case HWND_MENU_TIME_SET_DATE_OPTION_DAY_1:
                if(g_u8IdleMainpageDigitKeyCount == 6)
                {
                    return 0x0000ff;
                }
                break;
            case HWND_MENU_TIME_SET_DATE_OPTION_DAY_2:
                if(g_u8IdleMainpageDigitKeyCount == 7)
                {
                    return 0x0000ff;
                }
                break;
            default:
                break;
            }
    }
    else if(HWND_MENU_TIME_SET_CLOCK== MApp_ZUI_API_GetFocus())
    {
        switch(hwnd)
        {
            case HWND_MENU_TIME_SET_CLOCK_OPTION_HH_1:
                if(g_u8IdleMainpageDigitKeyCount < 1)
                {
                    return 0x0000ff;
                }
                break;
            case HWND_MENU_TIME_SET_CLOCK_OPTION_HH_2:
                if(g_u8IdleMainpageDigitKeyCount == 1)
                {
                    return 0x0000ff;
                }
                break;
            case HWND_MENU_TIME_SET_CLOCK_OPTION_MM_1:
                if(g_u8IdleMainpageDigitKeyCount == 2)
                {
                    return 0x0000ff;
                }
                break;
            case HWND_MENU_TIME_SET_CLOCK_OPTION_MM_2:
                if(g_u8IdleMainpageDigitKeyCount == 3)
                {
                    return 0x0000ff;
                }
                break;
            case HWND_MENU_TIME_SET_CLOCK_OPTION_SS_1:
                if(g_u8IdleMainpageDigitKeyCount == 4)
                {
                    return 0x0000ff;
                }
                break;
            case HWND_MENU_TIME_SET_CLOCK_OPTION_SS_2:
                if(g_u8IdleMainpageDigitKeyCount == 5)
                {
                    return 0x0000ff;
                }
                break;
            default:
                break;
            }
    }
    else if(HWND_MENU_TIME_SET_ONTIME== MApp_ZUI_API_GetFocus())
    {
        switch(hwnd)
        {
            case HWND_MENU_TIME_SET_ONTIME_OPTION_HH_1:
                if(g_u8IdleMainpageDigitKeyCount < 1)
                {
                    return 0x0000ff;
                }
                break;
            case HWND_MENU_TIME_SET_ONTIME_OPTION_HH_2:
                if(g_u8IdleMainpageDigitKeyCount == 1)
                {
                    return 0x0000ff;
                }
                break;
            case HWND_MENU_TIME_SET_ONTIME_OPTION_MM_1:
                if(g_u8IdleMainpageDigitKeyCount == 2)
                {
                    return 0x0000ff;
                }
                break;
            case HWND_MENU_TIME_SET_ONTIME_OPTION_MM_2:
                if(g_u8IdleMainpageDigitKeyCount == 3)
                {
                    return 0x0000ff;
                }
                break;
            case HWND_MENU_TIME_SET_ONTIME_OPTION_SS_1:
                if(g_u8IdleMainpageDigitKeyCount == 4)
                {
                    return 0x0000ff;
                }
                break;
            case HWND_MENU_TIME_SET_ONTIME_OPTION_SS_2:
                if(g_u8IdleMainpageDigitKeyCount == 5)
                {
                    return 0x0000ff;
                }
                break;
            default:
                break;
            }
    }
    else if(HWND_MENU_TIME_SET_OFFTIME== MApp_ZUI_API_GetFocus())
    {
        switch(hwnd)
        {
            case HWND_MENU_TIME_SET_OFFTIME_OPTION_HH_1:
                if(g_u8IdleMainpageDigitKeyCount < 1)
                {
                    return 0x0000ff;
                }
                break;
            case HWND_MENU_TIME_SET_OFFTIME_OPTION_HH_2:
                if(g_u8IdleMainpageDigitKeyCount == 1)
                {
                    return 0x0000ff;
                }
                break;
            case HWND_MENU_TIME_SET_OFFTIME_OPTION_MM_1:
                if(g_u8IdleMainpageDigitKeyCount == 2)
                {
                    return 0x0000ff;
                }
                break;
            case HWND_MENU_TIME_SET_OFFTIME_OPTION_MM_2:
                if(g_u8IdleMainpageDigitKeyCount == 3)
                {
                    return 0x0000ff;
                }
                break;
            case HWND_MENU_TIME_SET_OFFTIME_OPTION_SS_1:
                if(g_u8IdleMainpageDigitKeyCount == 4)
                {
                    return 0x0000ff;
                }
                break;
            case HWND_MENU_TIME_SET_OFFTIME_OPTION_SS_2:
                if(g_u8IdleMainpageDigitKeyCount == 5)
                {
                    return 0x0000ff;
                }
                break;
            default:
                break;
            }
    }
		// CUS_XM Xue 20120730: end modify

    return colorOriginal;
}

S16 MApp_ZUI_ACT_GetMenuDynamicValue(HWND hwnd)
{
   switch(hwnd)
    {
    #if 1//minglin1224
        case HWND_MENU_FWUPGRADE_PROGRESS_BAR: //case EN_DNUM_GetenA1_ScanPercentageValue:

	{
            if(Menu_USB_Upgrade_Percent>100)
            {
                if(Menu_USB_Upgrade_Percent == 0xff)
                {
                    return 0;
                }
                return 100;
            }
            return Menu_USB_Upgrade_Percent;
        }
   
        default:
        break;
     #endif  
    }

    return 0; //for empty  data
}

BOOLEAN Mapp_IsBacklightAdj(void)
{
if (MApp_ZUI_API_GetFocus() == HWND_MENU_PICTURE_ADJUST_BAR && prePictureHWND==HWND_MENU_ADVANCE_PICTURE_PC_BACKLIGHT)
    return TRUE;

    return FALSE;
}
#undef MAPP_ZUI_ACTMAINPAGE_C
