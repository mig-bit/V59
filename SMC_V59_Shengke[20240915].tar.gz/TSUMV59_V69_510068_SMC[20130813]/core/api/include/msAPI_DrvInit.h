////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (MStar Confidential Information!�L) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef MSAPI_DRVINIT_H
#define MSAPI_DRVINIT_H
#include "datatype.h"

#if (!BLOADER)
#if ( ENABLE_DIP_PWS)
#include "drvPWS.h"
#include "apiXC.h"
#endif
#endif

#ifdef _MSAPI_DRVINIT_C_
#define INTERFACE
#else
#define INTERFACE extern
#endif

INTERFACE void msAPI_ChipInit(void);
INTERFACE void msAPI_Interrupt_Init(void);
#if (!BLOADER)
#if ENABLE_POWER_SAVING_DPMS
INTERFACE MS_BOOL g_bVGANoSignalPowerDown; // For control PM mode
#endif
#endif

INTERFACE void msAPI_Power_PowerDown_EXEC(void);
INTERFACE void msAPI_PowerON_EXEC(void);
INTERFACE void msAPI_DrvInit(void);
INTERFACE void msAPI_DrvInitStep1(void);
INTERFACE void msAPI_DrvInitStep2(void);
INTERFACE void msAPI_DrvSetClock(void);
INTERFACE void MsAPISetDefautlbako1data(void);

#define msAPI_Sys_UartControl(x)        //MDrv_Sys_UartControl(x)
INTERFACE void MDrv_Sys_UartControl(BOOLEAN bEnable);

//#define  msAPI_BEON_Init(u16AeonBinID,u32BEON_MEM_ADR,u32BEON_MEM_LEN)    MDrv_BEON_Init(u16AeonBinID,u32BEON_MEM_ADR,u32BEON_MEM_LEN)
INTERFACE void msAPI_AEON_Disable(void);
INTERFACE void msAPI_Aeon_ReInitial(U16 u16AeonBinID);
INTERFACE void msAPI_BEON_Disable(void);

INTERFACE void msAPI_ShowWarningMessage(BOOLEAN bShow, const char *warningMsg);

#if OBA2
INTERFACE U32 msAPI_DrvGetSYSBinAddr(void);
INTERFACE void msAPI_DrvSetSYSBinAddr(U32 u32BinAddr);
#endif

INTERFACE void msAPI_WaitObamaInit(void);
INTERFACE BOOLEAN msAPI_Sys_IsNexusReady(void);
INTERFACE void msAPI_Sys_SetNexusReady(BOOLEAN ready);
#if (!BLOADER)
#if (ENABLE_DIP_PWS)
INTERFACE void MApp_Load_Input_Source_Setting(void);
E_PWS_DIGITALIP_API_SouceInfo  msAPI_SysInputSource2PWSInputSource(INPUT_SOURCE_TYPE_t src);
#endif
#endif




#undef INTERFACE
#endif /* MSAPI_DRVINIT_H */

