////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (MStar Confidential Information) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#define MAPP_ZUI_ACTMENUFUNC_C
#define _ZUI_INTERNAL_INSIDE_ //NOTE: for ZUI internal


//-------------------------------------------------------------------------------------------------
// Include Files
//-------------------------------------------------------------------------------------------------
#include <string.h>
#include "Board.h"

// Common Definition
#include "MsCommon.h"
#include "apiXC.h"
#include "msAPI_Timer.h"

#include"msAPI_VD.h"
#include "msAPI_Video.h"

#include "MApp_ZUI_Main.h"
#include "MApp_ZUI_APIcommon.h"
#include "MApp_ZUI_APIstrings.h"
#include "MApp_ZUI_APIwindow.h"
#include "ZUI_tables_h.inl"
#include "MApp_ZUI_APIgdi.h"
#include "MApp_ZUI_APIcontrols.h"
#include "MApp_GlobalSettingSt.h"
#include "MApp_ZUI_ACTmainpage.h"
#include "MApp_ZUI_ACTeffect.h"
#include "MApp_ZUI_APIdraw.h"
#include "MApp_ZUI_ACTglobal.h"
#include "OSDcp_String_EnumIndex.h"
#include "ZUI_exefunc.h"
#include "MApp_ZUI_ACTmenufunc.h"
#include"MApp_ZUI_ACTcoexistWin.h"
#include "apiXC_Sys.h"
#include "apiXC_Adc.h"
#include "apiAUDIO.h"
#include "MApp_Menu_Main.h"
#include "MApp_BlockSys.h"
#include "MApp_UiMenuDef.h"
#include "msAPI_Mode.h"
#include "apiXC_Ace.h"
#include "MApp_Scaler.h"
#include "MApp_XC_PQ.h"
#include "MApp_GlobalFunction.h"
#include "MApp_MVDMode.h"
#if MHEG5_ENABLE
#include "msAPI_MHEG5.h"
#include "MApp_MHEG5_Main.h"
#endif
#include "MApp_MultiTasks.h"
#include "MApp_Audio.h"
#include "MApp_Sleep.h"
#include "MApp_PCMode.h"
#include "MApp_DataBase.h"
#include "MApp_ChannelChange.h"
#include "apiXC_Hdmi.h"
#include "apiGOP.h"
#if (ENABLE_DTV)
#include "mapp_demux.h"
#include "mapp_si.h"
#include "msAPI_FreqTableDTV.h"
#endif

#include "MApp_RestoreToDefault.h"

#include "MApp_SaveData.h"
#include "msAPI_audio.h"
#if ENABLE_SBTVD_BRAZIL_APP
#if (BRAZIL_CC)
#include "mapp_closedcaption.h"
#endif
#endif
#if ENABLE_CI
#include "msAPI_CI.h"
#endif
#include "MApp_Version.h"
#include "drvpower_if.h"
#include "MApp_PVR.h"
#include "MApp_InputSource.h" //switch audio source when enable pip mode
#if ENABLE_TTX
#include "mapp_ttx.h"
#endif
#if (MWE_FUNCTION)
#include "apiXC_Ace.h"
#endif
#include "MApp_ZUI_ACTnetconfig.h"
#include "MApp_CustomerInfoInclude.h"
#if OBA2
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "madp.h"
#endif
#if ENABLE_DLC
#include "apiXC_Dlc.h"
#endif

#include "drvPQ.h"
#include "drvIPAUTH.h"
#include "drvPWM.h"

#include "msAPI_Tuning.h"
#include "MApp_UiMenuDef.h"
#include "msAPI_FreqTableDTV.h"
#include "MApp_SaveData.h"
#include "msAPI_FreqTableATV.h"
#include "MApp_ZUI_ACTautotuning.h"

#if DVB_C_ENABLE
#include "MApp_CADTV_Proc.h"
#endif

#if (ENABLE_DMP)
#include "mapp_mplayer.h"
#endif

#if ENABLE_CEC
#include "msAPI_CEC.h"
#endif
#if(ENABLE_6M30_3D_PROCESS)
#include "drvUrsa6M30.h"
#endif

#if (ENABLE_NEW_AUTO_NR == 1)
#include "msAPI_NR.h"
#endif
extern BOOLEAN bStopMonitorBlock;
extern BOOLEAN bParentalPWPassCheck;
extern unsigned char code Customer_hash[];
extern unsigned char Customer_info[];
BOOLEAN g_bInputBlocked = FALSE;
extern AUDIOMODE_TYPE   m_eAudioMode;
extern BOOLEAN bIsAtuneActive;
#if ENABLE_ZOOM_AVOUT_NOTMUTE
extern BOOLEAN bIsAspectMute;
#endif

/////////////////////////////////////////////////////////////////////
static const char SWVersionName[]      = _CODE_MAIN_VERSION_;
static const char SWCompileDate[]      = {_CODE_DATE_};
static const char SWCompileTime[]      = {_CODE_TIME_};

//////////////////////////////////////////////////////////////////////
#if ENABLE_AUTOTEST
extern BOOLEAN g_bAutobuildDebug;
#endif
U16 tempcheck2 =0;
U16 tempcheck3 =0;

// 4
U16 PicMode =0;
U16 PicContrast =0;
U16 PicBright =0;
U16 PicColor =0;
U16 PicSharpness =0;
U16 PicTint =0;

U16 ColorTem =0;
U16 ColorR =0;
U16 ColorG =0;
U16 ColorB =0;

U16 AspectR =0;
U16 NoiseR =0;

// 5
U16 SoundMenu =0;
U16 SoundMenuT =0;
U16 SoundMenuB =0;
U16 AutoVolume =0;
U16 SurroundSound =0;

//6
U16 OSDClock =0;
U16 OffTime =0;
U16 OnTime =0;

U16 AutoSleep =0;
U16 TimeZone =0;

// 7
U16 OSD_L =0;
U16 Audio_L =0;
U16 Subtitle_L =0;
U16 Headphone_L =0;
U16 Country =0;

//8
U16 LockS =0;
U16 ParentalG =0;
/////////////////////////////////////////////////////////////////////
#ifdef MSOS_TYPE_LINUX
#define UI_App_Num 18
U8 au8VisibleAPPList[UI_App_Num];
U8 u8PreVisibleAPPIndex;
#endif

#if ENABLE_CEC
static U8* u8HDMI_CEC_DevicesName[15];
static U8 u8HDMI_CEC_Devices_Count = 0;
static HWND _ZUI_TBLSEG hdmi_cec_UI_list[] =
{
    HWND_MENU_HDMI_CEC_DEVICE_LIST_A,
    HWND_MENU_HDMI_CEC_DEVICE_LIST_B,
    HWND_MENU_HDMI_CEC_DEVICE_LIST_C,
    HWND_MENU_HDMI_CEC_DEVICE_LIST_D,
    HWND_MENU_HDMI_CEC_DEVICE_LIST_E,
    HWND_MENU_HDMI_CEC_DEVICE_LIST_F,
    HWND_MENU_HDMI_CEC_DEVICE_LIST_G,
    HWND_MENU_HDMI_CEC_DEVICE_LIST_H,
    HWND_MENU_HDMI_CEC_DEVICE_LIST_I,
    HWND_MENU_HDMI_CEC_DEVICE_LIST_J,
};

#endif
/////////////////////////////////////////////////////////////////////

code U8 AspectRatioItem[][2]=
{
        //{TRUE, EN_AspectRatio_Original}, //0
        //{TRUE, EN_AspectRatio_4X3},// 1
        //{TRUE, EN_AspectRatio_16X9}, // 2
        {TRUE, EN_AspectRatio_16X9}, //0
        {TRUE, EN_AspectRatio_Original},// 1
        {TRUE, EN_AspectRatio_4X3}, // 2
        {TRUE, EN_AspectRatio_Zoom1}, // 3
        {TRUE, EN_AspectRatio_Zoom2}, // 4
        {TRUE, EN_AspectRatio_JustScan}, // 5
        {TRUE, EN_AspectRatio_Panorama}, // 6
        #if VGA_HDMI_YUV_POINT_TO_POINT
        {TRUE, EN_AspectRatio_point_to_point}, // 7
        #endif
};

void _MApp_ZUI_ACT_DecIncAspectRatio_Cycle(BOOLEAN bInc)
{
    //modify for aspect ratio,bein
    U8 cunt0,cunt1,DataLenth;
    BOOLEAN NextAspectRatio =FALSE;

    //EN_AspectRatio_Original
    if ( IsVgaInUse()
        #if (INPUT_HDMI_VIDEO_COUNT > 0)
        || ( IsHDMIInUse() && !g_HdmiPollingStatus.bIsHDMIMode )
        #endif
        )
    {
        //AspectRatioItem[0][0] = FALSE;
        AspectRatioItem[1][0] = FALSE;
    }
    else if(IsDTVInUse() && MApi_XC_IsCurrentFrameBufferLessMode())
    {
        //AspectRatioItem[0][0] = FALSE;
        AspectRatioItem[1][0] = FALSE;
    }
    else
    {
        //AspectRatioItem[0][0] = TRUE;
        AspectRatioItem[1][0] = TRUE;
    }

    //EN_AspectRatio_Zoom1
    if ( IsVgaInUse()
        || IsStorageInUse()
        #if (INPUT_HDMI_VIDEO_COUNT > 0)
        || ( IsHDMIInUse() && !g_HdmiPollingStatus.bIsHDMIMode )
        #if ENABLE_CUS_HDMI_MODE
        || (IsHDMIInUse() && (stGenSetting.g_SysSetting.bIsHDMIVideoMode == FALSE) && (MApp_Scaler_CheckHDMIModeAvailable() == TRUE))
        #endif
        #endif
        )
    {
        AspectRatioItem[3][0] = FALSE;
    }
    else if(IsDTVInUse() && MApi_XC_IsCurrentFrameBufferLessMode())
    {
        AspectRatioItem[3][0] = FALSE;
    }
    else
    {
        AspectRatioItem[3][0] = TRUE;
    }

    //EN_AspectRatio_Zoom2
    if ( IsVgaInUse()
        || IsStorageInUse()
        #if (INPUT_HDMI_VIDEO_COUNT > 0)
        || ( IsHDMIInUse() && !g_HdmiPollingStatus.bIsHDMIMode )
        #if ENABLE_CUS_HDMI_MODE
        || (IsHDMIInUse() && (stGenSetting.g_SysSetting.bIsHDMIVideoMode == FALSE) && (MApp_Scaler_CheckHDMIModeAvailable() == TRUE))
        #endif
        #endif
        )
    {
        AspectRatioItem[4][0] = FALSE;
    }
    else if(IsDTVInUse() && MApi_XC_IsCurrentFrameBufferLessMode())
    {
        AspectRatioItem[4][0] = FALSE;
    }
    else
    {
        AspectRatioItem[4][0] = TRUE;
	printf("zb show zoom2");
    }

    //EN_AspectRatio_JustScan
    if ( IsVgaInUse()
        || IsStorageInUse()
        || IsDigitalSourceInUse()
        || ( IsYPbPrInUse() && !MApi_XC_Sys_IsSrcHD(MAIN_WINDOW) )
        #if (INPUT_HDMI_VIDEO_COUNT > 0)
        || ( IsHDMIInUse() && !g_HdmiPollingStatus.bIsHDMIMode )
        #if ENABLE_CUS_HDMI_MODE
        || (IsHDMIInUse() && (stGenSetting.g_SysSetting.bIsHDMIVideoMode == FALSE) && (MApp_Scaler_CheckHDMIModeAvailable() == TRUE))
        #endif
        #endif
        )
    {
         AspectRatioItem[5][0] = FALSE;
    }
    else if(IsDTVInUse() && MApi_XC_IsCurrentFrameBufferLessMode())
    {
         AspectRatioItem[5][0] = FALSE;
    }
    else
    {
        AspectRatioItem[5][0] = TRUE;
    }

    //EN_AspectRatio_Panorama
    if ( IsVgaInUse()
        || IsStorageInUse()
        #if (INPUT_HDMI_VIDEO_COUNT > 0)
        || ( IsHDMIInUse() && !g_HdmiPollingStatus.bIsHDMIMode )
        #if ENABLE_CUS_HDMI_MODE
        || (IsHDMIInUse() && (stGenSetting.g_SysSetting.bIsHDMIVideoMode == FALSE) && (MApp_Scaler_CheckHDMIModeAvailable() == TRUE))
        #endif
        #endif
        )
    {
        AspectRatioItem[6][0] = FALSE;
    }
    else if(IsDTVInUse() && MApi_XC_IsCurrentFrameBufferLessMode())
    {
        AspectRatioItem[6][0] = FALSE;
    }
    else
    {
        AspectRatioItem[6][0] = TRUE;
    }

    //EN_AspectRatio_point_to_point
    #if VGA_HDMI_YUV_POINT_TO_POINT
    if ( IsVgaInUse()
        #if (INPUT_HDMI_VIDEO_COUNT > 0)
        #if (MEMORY_MAP <= MMAP_32MB)
        || ( IsHDMIInUse() && MDrv_PQ_Check_PointToPoint_Mode() )
        #endif
        || ( IsHDMIInUse() && (!MApi_XC_IsCurrentFrameBufferLessMode()) && ( !MApi_XC_IsCurrentRequest_FrameBufferLessMode()) )
        #if ENABLE_CUS_HDMI_MODE
        || (IsHDMIInUse() && (stGenSetting.g_SysSetting.bIsHDMIVideoMode == TRUE) && (MApp_Scaler_CheckHDMIModeAvailable() == TRUE))
        #endif
        #endif
        )
    {
        AspectRatioItem[7][0] = FALSE;
    }
    else if(IsDTVInUse() && MApi_XC_IsCurrentFrameBufferLessMode())
    {
        AspectRatioItem[7][0] = FALSE;
    }
    else
    {
        AspectRatioItem[7][0] = FALSE;
    }
    #endif

    #if ENABLE_CUS_UI_SPEC
    //AspectRatioItem[0][0] = FALSE;
    AspectRatioItem[1][0] = FALSE;
    AspectRatioItem[6][0] = FALSE;
	
	if(IsHDMIInUse())
	AspectRatioItem[5][0] = TRUE;
	else
    AspectRatioItem[5][0] = FALSE;
	
    //if(IsVgaInUse())
    //{
        AspectRatioItem[7][0] = FALSE;
    //}
    #endif
    DataLenth = sizeof(AspectRatioItem)/sizeof(AspectRatioItem[0]);

    for(cunt0=0;cunt0<DataLenth;cunt0++)
    {
        if(ST_VIDEO.eAspectRatio == (EN_MENU_AspectRatio)AspectRatioItem[cunt0][1])
            break;
    }

    for(cunt1=0;cunt1<DataLenth;cunt1++)
    {
        if(bInc)
        {
            if(cunt0==0)
            {
               cunt0=DataLenth-1;
            }
            else
            {
               cunt0--;
            }
            NextAspectRatio = AspectRatioItem[cunt0 %DataLenth][0];
        }
        else
        {
             if(cunt0==DataLenth-1)
            {
                cunt0=0;
            }
            else
            {
                cunt0++;
            }
            NextAspectRatio = AspectRatioItem[cunt0%DataLenth][0];

        }

        if(NextAspectRatio)
            break;
    }

    ST_VIDEO.eAspectRatio = (EN_MENU_AspectRatio)AspectRatioItem[(cunt0 + DataLenth)%DataLenth][1];

    switch(ST_VIDEO.eAspectRatio)
    {
        case EN_AspectRatio_JustScan:
        #if VGA_HDMI_YUV_POINT_TO_POINT
        case EN_AspectRatio_point_to_point:
        #endif
            MApp_Scaler_EnableOverScan(DISABLE);
            break;

        case EN_AspectRatio_Zoom1:
        case EN_AspectRatio_Zoom2:
        case EN_AspectRatio_Panorama:
            //MApp_Scaler_ResetZoomFactor(ST_VIDEO.eAspectRatio);
        default:
            MApp_Scaler_EnableOverScan(ENABLE);
            break;
    }

    MApp_Scaler_Setting_SetVDScale( ST_VIDEO.eAspectRatio , MAIN_WINDOW );
}

extern void _MApp_ZUI_ACT_DecIncSleepTimer_Cycle(BOOLEAN bInc);
#if ENABLE_T_C_COMBO
extern void _MApp_ZUI_ACT_DecIncDVBType_Cycle(void);
#endif

void _MApp_ZUI_ACT_CheckTimeInfo(void)
{
    if (!(g_u8TimeInfo_Flag & UI_TIME_MANUAL_SET))
    {
        g_u8TimeInfo_Flag = 0;
    }
}




#if 0//MWE_FUNCTION
void MApp_ZUI_ACT_AdjustEngineSetting(void)
{
      switch(stGenSetting.g_SysSetting.u8EngineSetting)
      {
                case EN_MWE_OFF:
                    MApi_XC_ACE_MWEFuncSel(MAIN_WINDOW,E_XC_ACE_MWE_MODE_OFF);
                    MApi_XC_ACE_EnableMWE(FALSE);
                    MDrv_MWE_SetOffQuality();
                    MDrv_MWE_RestoreEnhanceQuality();
                    break;
                case EN_MWE_OPTIMIZE:
                    MApi_XC_ACE_MWEFuncSel(MAIN_WINDOW,E_XC_ACE_MWE_MODE_OFF);
                    MApi_XC_ACE_EnableMWE(FALSE);
                    MDrv_MWE_RestoreOffQuality();
                    MDrv_MWE_RestoreEnhanceQuality();
                    break;
                case EN_MWE_ENHANCE:
                    MApi_XC_ACE_MWEFuncSel(MAIN_WINDOW,E_XC_ACE_MWE_MODE_OFF);
                    MApi_XC_ACE_EnableMWE(FALSE);
                    MDrv_MWE_RestoreOffQuality();
                    MDrv_MWE_SetEnhanceQuality();
                    break;
                case EN_MWE_SPLIT:
                    MApi_XC_ACE_MWEFuncSel(MAIN_WINDOW,E_XC_ACE_MWE_MODE_H_SPLIT);
                    MApi_XC_ACE_EnableMWE(TRUE);
                    MDrv_MWE_RestoreOffQuality();
                    MDrv_MWE_RestoreEnhanceQuality();
                    break;
                case EN_MWE_DYNIMIAC:
                    MApi_XC_ACE_MWEFuncSel(MAIN_WINDOW,E_XC_ACE_MWE_MODE_H_SCAN);
                    MApi_XC_ACE_EnableMWE(TRUE);
                    MDrv_MWE_RestoreOffQuality();
                    MDrv_MWE_RestoreEnhanceQuality();
                    break;
     }
}

void MApp_Engine_Setting_Reset(void)
{
     if ( EN_MWE_SPLIT == stGenSetting.g_SysSetting.u8EngineSetting)
     {
           stGenSetting.g_SysSetting.u8EngineSetting = EN_MWE_OPTIMIZE;
           MApp_ZUI_ACT_AdjustEngineSetting();
           MApp_SaveSysSetting();
     }
}
#endif

#if (ENABLE_ATV_VCHIP)
static const HWND _ZUI_TBLSEG _lock_items[] =
{
    HWND_MENU_LOCK_MAINSUBPAGE_ITEM_CHANGEPW,
    HWND_MENU_LOCK_MAINSUBPAGE_ITEM_SYSTEMLOCK,
#if ENABLE_INPUT_LOCK
    HWND_MENU_LOCK_MAINSUBPAGE_ITEM_INPUTBLOCK,
#endif
    HWND_MENU_LOCK_MAINSUBPAGE_ITEM_US,
    HWND_MENU_LOCK_MAINSUBPAGE_ITEM_CANADA,
    HWND_MENU_LOCK_MAINSUBPAGE_ITEM_RRTSETTING,
    HWND_MENU_LOCK_MAINSUBPAGE_ITEM_RESETRRT,

};

static const HWND _ZUI_TBLSEG _lock_source_items[] =
{
    HWND_MENU_LOCK_INPUTBLOCKSUBPAGE_ITEM_TV,

#if (INPUT_AV_VIDEO_COUNT >= 1)
    HWND_MENU_LOCK_INPUTBLOCKSUBPAGE_ITEM_AV,
#endif

#if (INPUT_SV_VIDEO_COUNT >= 2)
    HWND_MENU_LOCK_INPUTBLOCKSUBPAGE_ITEM_SVIDEO,
#endif

#if (INPUT_YPBPR_VIDEO_COUNT>=1)
    HWND_MENU_LOCK_INPUTBLOCKSUBPAGE_ITEM_COMPONENT,
#endif

#if (ENABLE_HDMI)
    HWND_MENU_LOCK_INPUTBLOCKSUBPAGE_ITEM_HDMI,
#endif

    HWND_MENU_LOCK_INPUTBLOCKSUBPAGE_ITEM_PC
};

static const HWND _ZUI_TBLSEG _vchip_items[] =
{
    HWND_MENU_LOCK_VCHIPSUBPAGE_ITEM1,
    HWND_MENU_LOCK_VCHIPSUBPAGE_ITEM2,
    HWND_MENU_LOCK_VCHIPSUBPAGE_ITEM3,
    HWND_MENU_LOCK_VCHIPSUBPAGE_ITEM4,
    HWND_MENU_LOCK_VCHIPSUBPAGE_ITEM5,
    HWND_MENU_LOCK_VCHIPSUBPAGE_ITEM6,
    HWND_MENU_LOCK_VCHIPSUBPAGE_ITEM7
};

static U8 _MApp_ZUI_ACT_VchipWindowMapToIndex(HWND hwnd)
{
    U8 i;
    U8 u8Num = COUNTOF(_vchip_items);
    for (i = 0; i < u8Num; i++)
    {
        if (hwnd == _vchip_items[i] ||
            MApp_ZUI_API_IsSuccessor(_vchip_items[i], hwnd))
        {
            return i;
        }
    }
    return 0;
}

HWND _MApp_ZUI_ACT_VchipIdMapToWindow(U8 u8Index)
{
    return _vchip_items[u8Index];
}
#endif

#if (ENABLE_UI_3D_PROCESS)
void  MApp_ZUI_ACT_SetEnv3DOutputMode(E_UI_3D_UI_MODE eDirectType)
{
    //printf("set env 3DOutputMode\n");
    if(eDirectType == E_UI_3D_UI_TOP_BOTTOM)
    {
         MApp_ZUI_Set_UI_3D_Mode(E_UI_3D_OUTPUT_TOP_BOTTOM);
    }
    else if(eDirectType == E_UI_3D_UI_SIDE_BY_SIDE_HALF)
    {
         MApp_ZUI_Set_UI_3D_Mode(E_UI_3D_OUTPUT_SIDE_BY_SIDE_HALF);
    }
    else
    {
         MApp_ZUI_Set_UI_3D_Mode(E_UI_3D_OUTPUT_MODE_NONE);
    }
}
#endif
#if 1
void MApp_MuteAvByLock(U8 u8ScreenMute, BOOLEAN bMuteEnable)
{
    if ( u8ScreenMute & (E_SCREEN_MUTE_RATING|E_SCREEN_MUTE_INPUT) )
    {
        if (bMuteEnable)
        {
            // mute the aduio.......
            msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_BYBLOCK_MUTEON, E_AUDIOMUTESOURCE_ACTIVESOURCE);
            #if ENABLE_NEW_SPDIF_MUTE_METHOD
            MApp_Audio_SPDIF_SetMute(TRUE, NORMAL_MUTE);
            #else
            MApi_AUDIO_SPDIF_SetMute(TRUE);
            #endif
            // mute the video.......
            msAPI_Scaler_SetScreenMute( (E_SCREEN_MUTE_STATUS)u8ScreenMute, ENABLE, NULL, MAIN_WINDOW);

        }
        else
        {

            #if ENABLE_NEW_SPDIF_MUTE_METHOD
            MApp_Audio_SPDIF_SetMute(FALSE, NORMAL_MUTE);
            #else
            MApi_AUDIO_SPDIF_SetMute(FALSE);
            #endif

            msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_BYBLOCK_MUTEOFF, E_AUDIOMUTESOURCE_ACTIVESOURCE);
            // un-mute the video.......
            msAPI_Scaler_SetScreenMute((E_SCREEN_MUTE_STATUS)u8ScreenMute, DISABLE, NULL, MAIN_WINDOW);

        }
    }
}

BOOLEAN MApp_UiMenuFunc_CheckInputLock(void)
{
    if ( IsAnyTVSourceInUse() )
    {
        if( stGenSetting.g_VChipSetting.u8InputBlockItem & INPUT_BLOCK_TV)
        {
            return TRUE;
        }
    }
    else if ( IsVgaInUse() )
    {
        if( stGenSetting.g_VChipSetting.u8InputBlockItem & INPUT_BLOCK_PC)
        {
            return TRUE;
        }
    }
    else if ( UI_INPUT_SOURCE_TYPE==UI_INPUT_SOURCE_COMPONENT )
    {
        if( stGenSetting.g_VChipSetting.u8InputBlockItem & INPUT_BLOCK_YPBPR1)
        {
            return TRUE;
        }
    }
#if (INPUT_YPBPR_VIDEO_COUNT >= 2)
    else if ( UI_INPUT_SOURCE_TYPE==UI_INPUT_SOURCE_COMPONENT2 )
    {
        if( stGenSetting.g_VChipSetting.u8InputBlockItem & INPUT_BLOCK_YPBPR2)
        {
            return TRUE;
        }
    }
#endif
    else if ( UI_INPUT_SOURCE_TYPE==UI_INPUT_SOURCE_AV)
    {
        if( stGenSetting.g_VChipSetting.u8InputBlockItem & INPUT_BLOCK_AV1)
        {
            return TRUE;
        }
    }

#if (INPUT_AV_VIDEO_COUNT >= 2)
    else if ( UI_INPUT_SOURCE_TYPE==UI_INPUT_SOURCE_AV2)
    {
        if( stGenSetting.g_VChipSetting.u8InputBlockItem & INPUT_BLOCK_AV2)
        {
            return TRUE;
        }
    }
#endif

#if (ENABLE_HDMI)
    else if ( UI_INPUT_SOURCE_TYPE==UI_INPUT_SOURCE_HDMI)
    {
        if( stGenSetting.g_VChipSetting.u8InputBlockItem & INPUT_BLOCK_HDMI1)
        {
            return TRUE;
        }
    }

#if (INPUT_HDMI_VIDEO_COUNT >= 2)
    else if ( UI_INPUT_SOURCE_TYPE==UI_INPUT_SOURCE_HDMI2)
    {
        if( stGenSetting.g_VChipSetting.u8InputBlockItem & INPUT_BLOCK_HDMI2)
        {
            return TRUE;
        }
    }
#endif
  #if (INPUT_HDMI_VIDEO_COUNT >= 3)
    else if ( UI_INPUT_SOURCE_TYPE==UI_INPUT_SOURCE_HDMI3)
    {
        if( stGenSetting.g_VChipSetting.u8InputBlockItem & INPUT_BLOCK_HDMI3)
        {
            return TRUE;
        }
    }
  #endif
  #if (INPUT_HDMI_VIDEO_COUNT >= 4)
    else if ( UI_INPUT_SOURCE_TYPE==UI_INPUT_SOURCE_HDMI4)
    {
        if( stGenSetting.g_VChipSetting.u8InputBlockItem & INPUT_BLOCK_HDMI4)
        {
            return TRUE;
        }
    }
  #endif
#endif

#if (ENABLE_SCART_VIDEO)
    else if ( IsScartInUse() )
    {
        if( stGenSetting.g_VChipSetting.u8InputBlockItem & INPUT_BLOCK_SCART)
        {
            return TRUE;
        }
    }
#endif

    return FALSE;
}
BOOLEAN MApp_UiMenuFunc_CheckInputLockAudioVideo(void)
{
    if(IsAnyTVSourceInUse())
    {
        if(IsATVInUse())
        {
            U8 cCurrentProgramNumber;
            cCurrentProgramNumber = msAPI_ATV_GetCurrentProgramNumber();
            if(stGenSetting.g_VChipSetting.u8InputBlockItem & INPUT_BLOCK_TV)
            {
                if((g_u16PasswordCheckSource & INPUT_BLOCK_TV))
                {
                    return TRUE;
                }
                else
                {
                    return FALSE;
                }
            }
            else
            {
                if((msAPI_ATV_IsProgramLocked((BYTE)cCurrentProgramNumber) == TRUE)
                    #if ENABLE_CUS_BLOCK_SYS
                    && (msAPI_ATV_IsLockedCHCheckPwdSucess((BYTE)cCurrentProgramNumber) == FALSE)
                    #endif
                    )
                {
                    return TRUE;
                }
                else
                {
                    return FALSE;
                }
            }
        }
        else
        {
            if((( stGenSetting.g_VChipSetting.u8InputBlockItem & INPUT_BLOCK_TV) && ( g_u16PasswordCheckSource& INPUT_BLOCK_TV)))
            {
                return TRUE;
            }
        }
    }
    else if ( IsVgaInUse() )
    {
        if(( stGenSetting.g_VChipSetting.u8InputBlockItem & INPUT_BLOCK_PC) && ( g_u16PasswordCheckSource & INPUT_BLOCK_PC))
        {
            return TRUE;
        }
    }
    else if ( UI_INPUT_SOURCE_TYPE==UI_INPUT_SOURCE_COMPONENT )
    {
        if(( stGenSetting.g_VChipSetting.u8InputBlockItem & INPUT_BLOCK_YPBPR1) && ( g_u16PasswordCheckSource & INPUT_BLOCK_YPBPR1))
        {
            return TRUE;
        }
    }
#if (INPUT_YPBPR_VIDEO_COUNT >= 2)
    else if ( UI_INPUT_SOURCE_TYPE==UI_INPUT_SOURCE_COMPONENT2 )
    {
        if(( stGenSetting.g_VChipSetting.u8InputBlockItem & INPUT_BLOCK_YPBPR2) && ( g_u16PasswordCheckSource & INPUT_BLOCK_YPBPR2))
        {
            return TRUE;
        }
    }
#endif
    else if ( UI_INPUT_SOURCE_TYPE==UI_INPUT_SOURCE_AV)
    {
        if(( stGenSetting.g_VChipSetting.u8InputBlockItem & INPUT_BLOCK_AV1) && (g_u16PasswordCheckSource & INPUT_BLOCK_AV1))
        {
            return TRUE;
        }
    }

#if (INPUT_AV_VIDEO_COUNT >= 2)
    else if ( UI_INPUT_SOURCE_TYPE==UI_INPUT_SOURCE_AV2)
    {
        if(( stGenSetting.g_VChipSetting.u8InputBlockItem & INPUT_BLOCK_AV2) && ( g_u16PasswordCheckSource & INPUT_BLOCK_AV2))
        {
            return TRUE;
        }
    }
#endif

#if (ENABLE_HDMI)
    else if ( UI_INPUT_SOURCE_TYPE==UI_INPUT_SOURCE_HDMI)
    {
        if(( stGenSetting.g_VChipSetting.u8InputBlockItem & INPUT_BLOCK_HDMI1) && ( g_u16PasswordCheckSource & INPUT_BLOCK_HDMI1))
        {
            return TRUE;
        }
    }

    #if (INPUT_HDMI_VIDEO_COUNT >= 2)
    else if ( UI_INPUT_SOURCE_TYPE==UI_INPUT_SOURCE_HDMI2)
    {
        if(( stGenSetting.g_VChipSetting.u8InputBlockItem & INPUT_BLOCK_HDMI2) && ( g_u16PasswordCheckSource & INPUT_BLOCK_HDMI2))
        {
            return TRUE;
        }
    }
    #endif
  #if (INPUT_HDMI_VIDEO_COUNT >= 3)
    else if ( UI_INPUT_SOURCE_TYPE==UI_INPUT_SOURCE_HDMI3)
    {
        if(( stGenSetting.g_VChipSetting.u8InputBlockItem & INPUT_BLOCK_HDMI3) && ( g_u16PasswordCheckSource & INPUT_BLOCK_HDMI3))
        {
            return TRUE;
        }
    }
  #endif
  #if (INPUT_HDMI_VIDEO_COUNT >= 3)
    else if ( UI_INPUT_SOURCE_TYPE==UI_INPUT_SOURCE_HDMI4)
    {
        if(( stGenSetting.g_VChipSetting.u8InputBlockItem & INPUT_BLOCK_HDMI4) && ( g_u16PasswordCheckSource & INPUT_BLOCK_HDMI4))
        {
            return TRUE;
        }
    }
  #endif
#endif

#if (ENABLE_SCART_VIDEO)
    else if ( IsScartInUse() )
    {
        if(( stGenSetting.g_VChipSetting.u8InputBlockItem & INPUT_BLOCK_SCART) && ( g_u16PasswordCheckSource & INPUT_BLOCK_SCART))
        {
            return TRUE;
        }
    }
#endif

    return FALSE;
}


BOOLEAN MApp_UiMenuFunc_AdjustInputLockTV(void)
{
    g_bInputBlocked = MApp_UiMenuFunc_CheckInputLockAudioVideo();

    if ( IsAnyTVSourceInUse() )
    {
        #if 1
        MApp_MuteAvByLock(E_SCREEN_MUTE_INPUT, g_bInputBlocked);
        #else
        MApp_MuteAvByLock(g_bInputBlocked);
        #endif
    }
    return TRUE;
}

BOOLEAN MApp_UiMenuFunc_AdjustInputLockAV1(void)
{
    g_bInputBlocked = MApp_UiMenuFunc_CheckInputLockAudioVideo();

    if ( UI_INPUT_SOURCE_TYPE==UI_INPUT_SOURCE_AV)
    {
        #if 1
        MApp_MuteAvByLock(E_SCREEN_MUTE_INPUT, g_bInputBlocked);
        #else
        MApp_MuteAvByLock(g_bInputBlocked);
        #endif
    }
    return TRUE;
}
BOOLEAN MApp_UiMenuFunc_AdjustInputLockAV2(void)
{
    g_bInputBlocked = MApp_UiMenuFunc_CheckInputLockAudioVideo();
#if (INPUT_AV_VIDEO_COUNT >= 2)

    if ( UI_INPUT_SOURCE_TYPE==UI_INPUT_SOURCE_AV2)
    {
        #if 1
        MApp_MuteAvByLock(E_SCREEN_MUTE_INPUT, g_bInputBlocked);
        #else
        MApp_MuteAvByLock(g_bInputBlocked);
        #endif
    }
#endif
    return TRUE;
}

BOOLEAN MApp_UiMenuFunc_AdjustInputLockSV(void)
{
    g_bInputBlocked = MApp_UiMenuFunc_CheckInputLockAudioVideo();

    if ( IsSVInUse() )
    {
        #if 1
        MApp_MuteAvByLock(E_SCREEN_MUTE_INPUT, g_bInputBlocked);
        #else
        MApp_MuteAvByLock(g_bInputBlocked);
        #endif
    }
    return TRUE;
}

BOOLEAN MApp_UiMenuFunc_AdjustInputLockYPbPr1(void)
{
    g_bInputBlocked = MApp_UiMenuFunc_CheckInputLockAudioVideo();

    if ( UI_INPUT_SOURCE_TYPE==UI_INPUT_SOURCE_COMPONENT )
    {
        #if 1
        MApp_MuteAvByLock(E_SCREEN_MUTE_INPUT, g_bInputBlocked);
        #else
        MApp_MuteAvByLock(g_bInputBlocked);
        #endif
    }
    return TRUE;
}
BOOLEAN MApp_UiMenuFunc_AdjustInputLockYPbPr2(void)
{
    g_bInputBlocked = MApp_UiMenuFunc_CheckInputLockAudioVideo();
#if (INPUT_YPBPR_VIDEO_COUNT >= 2)
    if ( UI_INPUT_SOURCE_TYPE==UI_INPUT_SOURCE_COMPONENT2 )
    {
        #if 1
        MApp_MuteAvByLock(E_SCREEN_MUTE_INPUT, g_bInputBlocked);
        #else
        MApp_MuteAvByLock(g_bInputBlocked);
        #endif
    }
#endif
    return TRUE;
}

BOOLEAN MApp_UiMenuFunc_AdjustInputLockSCART(void)
{
    g_bInputBlocked = MApp_UiMenuFunc_CheckInputLockAudioVideo();

#if (ENABLE_SCART_VIDEO)
    if ( IsScartInUse() )
    {
        #if 1
        MApp_MuteAvByLock(E_SCREEN_MUTE_INPUT, g_bInputBlocked);
        #else
        MApp_MuteAvByLock(g_bInputBlocked);
        #endif
    }
#endif

    return TRUE;
}

BOOLEAN MApp_UiMenuFunc_AdjustInputLockHDMI1(void)
{
    g_bInputBlocked = MApp_UiMenuFunc_CheckInputLockAudioVideo();

#if (ENABLE_HDMI)
    if ( UI_INPUT_SOURCE_TYPE==UI_INPUT_SOURCE_HDMI)
    {
        #if 1
        MApp_MuteAvByLock(E_SCREEN_MUTE_INPUT, g_bInputBlocked);
        #else
        MApp_MuteAvByLock(g_bInputBlocked);
        #endif
    }
#endif

    return TRUE;
}
BOOLEAN MApp_UiMenuFunc_AdjustInputLockHDMI2(void)
{
    g_bInputBlocked = MApp_UiMenuFunc_CheckInputLockAudioVideo();

#if (ENABLE_HDMI)
#if (INPUT_HDMI_VIDEO_COUNT >= 2)
    if ( UI_INPUT_SOURCE_TYPE==UI_INPUT_SOURCE_HDMI2)
    {
        #if 1
        MApp_MuteAvByLock(E_SCREEN_MUTE_INPUT, g_bInputBlocked);
        #else
        MApp_MuteAvByLock(g_bInputBlocked);
        #endif
    }
#endif
#endif

    return TRUE;
}
BOOLEAN MApp_UiMenuFunc_AdjustInputLockHDMI3(void)
{
    g_bInputBlocked = MApp_UiMenuFunc_CheckInputLockAudioVideo();

#if (ENABLE_HDMI) && (INPUT_HDMI_VIDEO_COUNT >= 3)
    if ( UI_INPUT_SOURCE_TYPE==UI_INPUT_SOURCE_HDMI3)
    {
        #if 1
        MApp_MuteAvByLock(E_SCREEN_MUTE_INPUT, g_bInputBlocked);
        #else
        MApp_MuteAvByLock(g_bInputBlocked);
        #endif
    }
#endif

    return TRUE;
}
BOOLEAN MApp_UiMenuFunc_AdjustInputLockHDMI4(void)
{
    g_bInputBlocked = MApp_UiMenuFunc_CheckInputLockAudioVideo();

#if (ENABLE_HDMI) && (INPUT_HDMI_VIDEO_COUNT >= 4)
    if ( UI_INPUT_SOURCE_TYPE==UI_INPUT_SOURCE_HDMI4)
    {
        #if 1
        MApp_MuteAvByLock(E_SCREEN_MUTE_INPUT, g_bInputBlocked);
        #else
        MApp_MuteAvByLock(g_bInputBlocked);
        #endif
    }
#endif

    return TRUE;
}

BOOLEAN MApp_UiMenuFunc_AdjustInputLockPC(void)
{
    g_bInputBlocked = MApp_UiMenuFunc_CheckInputLockAudioVideo();

    if ( IsVgaInUse() )
    {
        #if 1
        MApp_MuteAvByLock(E_SCREEN_MUTE_INPUT, g_bInputBlocked);
        #else
        MApp_MuteAvByLock(g_bInputBlocked);
        #endif
    }
    return TRUE;
}
#endif // end of ENABLE_INPUT_LOCK

///////////////////////////////////////////////////////////////////////////////
///  private  MApp_ZUI_ACT_ExecuteMenuItemAction
///  execute a specific action in menu items
///
///  @param [in]       act U16      action ID
///
///  @return BOOLEAN     true for accept, false for ignore
///
///  @author MStarSemi @date 2007/1/25
///////////////////////////////////////////////////////////////////////////////
//CUS_XM:xue add for factory RC CTC key 2012-6-13
void Mapp_FactoryRCCTCKey(void)
{
	printf("handle Factory CTC  key");
	MApp_ZUI_ACT_ExecuteMenuItemAction(EN_EXE_INC_COLOR_TEMP);

}
void Mapp_BalanceVolLeft(void)
{
	printf("handle Factory BalanceVolLeft key");
	//MApp_ZUI_ACT_DecIncValue(TRUE,stGenSetting.g_SoundSetting.Balance, 0, 100, 0);
	stGenSetting.g_SoundSetting.Balance=0;
	MApi_AUDIO_SetBalance(stGenSetting.g_SoundSetting.Balance);
}
void Mapp_BalanceVolRight(void)
{
	printf("handle Factory BalanceVolRight key");
	stGenSetting.g_SoundSetting.Balance=100;
	MApi_AUDIO_SetBalance(stGenSetting.g_SoundSetting.Balance);
}
void Mapp_AdjustPictureMode(void)
{
	printf("handle Factory PIC key");
	MApp_ZUI_ACT_ExecuteMenuItemAction(EN_EXE_INC_PICTURE_MODE);
}
void Mapp_AdjustAudioMode(void)
{
	printf("handle Factory Audio key");
	MApp_ZUI_ACT_ExecuteMenuItemAction(EN_EXE_INC_SOUND_MODE);
}

//CUS_XM:xue add for factory RC DCR key function 2012-6-22
void Mapp_SwitchDCRMode(void)
{
	printf("handle Factory DCR key");
	MApp_ZUI_ACT_ExecuteMenuItemAction(EN_EXE_INC_DBC);
}



BOOLEAN MApp_ZUI_ACT_ExecuteMenuItemAction(U16 act)
{
#if ENABLE_CUS_3D_SOURCE_MEMORY
    static  BOOLEAN isSceneValueOver;
#endif
#if (ENABLE_PIP)
    MS_WINDOW_TYPE tTempSubWin,stPOPSubWin,stPOPMainWin;
    U8 u8TempPIP_Offset = 3;

    //First calculate the large sub window width and height
    U16 u16TempPIP_Width = (PANEL_WIDTH - SCREEN_SAVER_FRAME_WIDTH)/2 - u8TempPIP_Offset;
    U16 u16TempPIP_Height = u16TempPIP_Width*PANEL_HEIGHT/PANEL_WIDTH;

    if(IsPIPSupported())
    {
        // Added it by coverity_0542
        tTempSubWin.x = 0;
        tTempSubWin.y = 0;
        tTempSubWin.width = u16TempPIP_Width;
        tTempSubWin.height = u16TempPIP_Height;
    }
#endif

    switch(act)
    {

#if (ENABLE_CUS_UI_SPEC == FALSE)
        case EN_EXE_ONOFF_SWUPDATE:
#if(ENABLE_SOFTWAREUPDATE)
            //from case MAPP_UIMENUFUNC_ADJA7_SoftwareUpdateOFF
            stGenSetting.g_SysSetting.fSoftwareUpdate = !stGenSetting.g_SysSetting.fSoftwareUpdate;
            MApp_ZUI_API_InvalidateWindow(HWND_MENU_CHANNEL_SW_OAD_UPGRADE_OPTION);
#endif
            return TRUE;
#if 0//(NTV_FUNCTION_ENABLE) // wait to do
        case EN_EXE_INC_DTV_BANDWIDTH:
        case EN_EXE_DEC_DTV_BANDWIDTH:
            if(stGenSetting.stScanMenuSetting.u8BandWidth == E_RF_CH_BAND_8MHz)
               stGenSetting.stScanMenuSetting.u8BandWidth = E_RF_CH_BAND_7MHz;
            else if(stGenSetting.stScanMenuSetting.u8BandWidth == E_RF_CH_BAND_7MHz)
               stGenSetting.stScanMenuSetting.u8BandWidth = E_RF_CH_BAND_8MHz;
            if(OSD_COUNTRY_SETTING == OSD_COUNTRY_NORWAY)
            {
                msAPI_DFT_SetBandwidth(stGenSetting.stScanMenuSetting.u8BandWidth);
            }
            MApp_ZUI_API_InvalidateWindow(HWND_MENU_CHANNEL_DTV_BANDWIDTH_OPTION);
            return TRUE;
#endif

        case EN_EXE_ONOFF_5VANTENNA:
#ifdef ENABLE_5VANTENNA
            //from case MAPP_UIMENUFUNC_ADJ5VAntennaPowerOFF:
            stGenSetting.g_SysSetting.f5VAntennaPower = !stGenSetting.g_SysSetting.f5VAntennaPower;
            // 5V Antenna Monitor
            AdjustAntenna5VMonitor((EN_MENU_5V_AntennaPower)stGenSetting.g_SysSetting.f5VAntennaPower);
            MApp_ZUI_API_InvalidateWindow(HWND_MENU_CHANNEL_5V_ANTENNA_OPTION);
#endif
            return TRUE;
#endif
        case EN_EXE_DEC_NOISE_REDUCTION:
        case EN_EXE_INC_NOISE_REDUCTION:
            //from case MAPP_UIMENUFUNC_ADJENB3_NR:
 #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
             ST_PICTURE.eNRMode.eNR=
                 (EN_MS_NR)MApp_ZUI_ACT_DecIncValue_Cycle(
                     act==EN_EXE_INC_NOISE_REDUCTION,
                      ST_PICTURE.eNRMode.eNR,MS_NR_MIN, MS_NR_HIGH, 1);

#if(!_AutoNR_EN_)
             if (ST_PICTURE.eNRMode.eNR == MS_NR_AUTO)
             {
                 ST_PICTURE.eNRMode.eNR=
                 (EN_MS_NR)MApp_ZUI_ACT_DecIncValue_Cycle(
                     act==EN_EXE_INC_NOISE_REDUCTION,
                      ST_PICTURE.eNRMode.eNR,MS_NR_MIN, MS_NR_HIGH, 1);
             }
#endif

#if(ENABLE_NEW_AUTO_NR == 1)
             msAPI_NR_SetDNRDefault();
             if( MS_NR_LOW == ST_PICTURE.eNRMode.eNR )
             {
                 msAPI_NR_SetDNRStatus(E_MAPI_AUTO_NR_STATUS_LOW,E_MAPI_AUTO_NR_STATUS_LOW);
                 MDrv_PQ_LoadNRTable(PQ_MAIN_WINDOW, PQ_3D_NR_AUTO_LOW_L);
             }
             else if( MS_NR_MIDDLE == ST_PICTURE.eNRMode.eNR )
             {
                 msAPI_NR_SetDNRStatus(E_MAPI_AUTO_NR_STATUS_MID,E_MAPI_AUTO_NR_STATUS_MID);
                 MDrv_PQ_LoadNRTable(PQ_MAIN_WINDOW, PQ_3D_NR_AUTO_MID_M);
             }
             else if( MS_NR_HIGH == ST_PICTURE.eNRMode.eNR )
             {
                 msAPI_NR_SetDNRStatus(E_MAPI_AUTO_NR_STATUS_HIGH,E_MAPI_AUTO_NR_STATUS_HIGH);
                 MDrv_PQ_LoadNRTable(PQ_MAIN_WINDOW, PQ_3D_NR_AUTO_HIGH_H);
             }
             else if( MS_NR_OFF == ST_PICTURE.eNRMode.eNR )
             {
             MApp_PicSetNR( (T_MS_NR_MODE*) &ST_PICTURE.eNRMode, SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW) );
             }
#else
             MApp_PicSetNR( (T_MS_NR_MODE*) &ST_PICTURE.eNRMode, SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW) );
#endif


 #else // else ENABLE_CUS_NR_MODE_FOLLOW_PICMODE

            ST_VIDEO.eNRMode.eNR=
                (EN_MS_NR)MApp_ZUI_ACT_DecIncValue_Cycle(
                    act==EN_EXE_INC_NOISE_REDUCTION,
                     ST_VIDEO.eNRMode.eNR,MS_NR_MIN, MS_NR_NUM-1, 1);

#if(!_AutoNR_EN_)
            if (ST_VIDEO.eNRMode.eNR == MS_NR_AUTO)
            {
                ST_VIDEO.eNRMode.eNR=
                (EN_MS_NR)MApp_ZUI_ACT_DecIncValue_Cycle(
                    act==EN_EXE_INC_NOISE_REDUCTION,
                     ST_VIDEO.eNRMode.eNR,MS_NR_MIN, MS_NR_NUM-1, 1);
            }
#endif

#if(ENABLE_NEW_AUTO_NR == 1)
            msAPI_NR_SetDNRDefault();
            if( MS_NR_LOW == ST_VIDEO.eNRMode.eNR )
            {
                msAPI_NR_SetDNRStatus(E_MAPI_AUTO_NR_STATUS_LOW,E_MAPI_AUTO_NR_STATUS_LOW);
                MDrv_PQ_LoadNRTable(PQ_MAIN_WINDOW, PQ_3D_NR_AUTO_LOW_L);
            }
            else if( MS_NR_MIDDLE == ST_VIDEO.eNRMode.eNR )
            {
                msAPI_NR_SetDNRStatus(E_MAPI_AUTO_NR_STATUS_MID,E_MAPI_AUTO_NR_STATUS_MID);
                MDrv_PQ_LoadNRTable(PQ_MAIN_WINDOW, PQ_3D_NR_AUTO_MID_M);
            }
            else if( MS_NR_HIGH == ST_VIDEO.eNRMode.eNR )
            {
                msAPI_NR_SetDNRStatus(E_MAPI_AUTO_NR_STATUS_HIGH,E_MAPI_AUTO_NR_STATUS_HIGH);
                MDrv_PQ_LoadNRTable(PQ_MAIN_WINDOW, PQ_3D_NR_AUTO_HIGH_H);
            }
            else if( MS_NR_OFF == ST_VIDEO.eNRMode.eNR )
            {
            MApp_PicSetNR( (T_MS_NR_MODE*) &ST_VIDEO.eNRMode, SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW) );
            }
#else
            MApp_PicSetNR( (T_MS_NR_MODE*) &ST_VIDEO.eNRMode, SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW) );
#endif
#endif
            #if ENABLE_3D_PROCESS /*Creass.liu at 2012-08-01*/
            MDrv_PQ_3DCloneforPIP(TRUE);
            #endif

            //MApp_PicSetNR( (T_MS_NR_MODE*) &ST_VIDEO.eNRMode, SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW) );
            if(MApp_ZUI_API_IsSuccessor(HWND_MENU_ADVANCE_PICTURE_PAGE_LIST, MApp_ZUI_API_GetFocus()))
            {
            	MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_ADVANCE_PICTURE_NOISE_REDUCTION);
            }
            #if (ENABLE_CUS_UI_SPEC == DISABLE)/*Creass.liu at 2012-06-27*/
            else
            {
                MApp_ZUI_API_InvalidateWindow(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST);
                MApp_ZUI_API_InvalidateWindow(HWND_MENU_ADVANCE_PICTURE_NOISE_REDUCTION_OPTION);
            }
            #endif
            return TRUE;

        case EN_EXE_DEC_FLESH_TONE:
        case EN_EXE_INC_FLESH_TONE:
       #if ENABLE_FLESH_TONE
               if( ST_VIDEO.ePicture != PICTURE_USER)
               {
                   ST_VIDEO.astPicture[PICTURE_USER].u8Backlight = ST_PICTURE.u8Backlight;
                   ST_VIDEO.astPicture[PICTURE_USER].u8Contrast = ST_PICTURE.u8Contrast;
                   ST_VIDEO.astPicture[PICTURE_USER].u8Brightness = ST_PICTURE.u8Brightness;
                   ST_VIDEO.astPicture[PICTURE_USER].u8Saturation = ST_PICTURE.u8Saturation;
                   ST_VIDEO.astPicture[PICTURE_USER].u8Sharpness = ST_PICTURE.u8Sharpness;
                   ST_VIDEO.astPicture[PICTURE_USER].u8Hue = ST_PICTURE.u8Hue;
                   ST_VIDEO.astPicture[PICTURE_USER].eColorTemp = ST_PICTURE.eColorTemp;
                  #if (ENABLE_CUS_NR_MODE_FOLLOW_PICMODE == ENABLE)
                   ST_VIDEO.astPicture[PICTURE_USER].eNRMode.eNR = ST_PICTURE.eNRMode.eNR;
                  #endif
                   ST_VIDEO.astPicture[PICTURE_USER].eFleshToneMode = ST_PICTURE.eFleshToneMode;
                  #if 0//ENABLE_CUS_DBC
                   ST_VIDEO.astPicture[PICTURE_USER].bDBCStatus =ST_PICTURE.bDBCStatus;
                  #endif
                  #if ENABLE_CUS_DLC
                   ST_VIDEO.astPicture[PICTURE_USER].bDLCStatus =ST_PICTURE.bDLCStatus;
                  #endif
                   ST_VIDEO.ePicture = PICTURE_USER;
               }
                ST_PICTURE.eFleshToneMode=
                    (EN_MS_FLESH_TONE_MODE)MApp_ZUI_ACT_DecIncValue_Cycle(
                        act==EN_EXE_INC_FLESH_TONE,
                         ST_PICTURE.eFleshToneMode,MS_FLESH_TONE_MIN, MS_FLESH_TONE_NUM-1, 1);
                // TODO:

                MApp_ST_VIDEO_SetDMPUserDate();

            	MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_ADVANCE_PICTURE_FLESH_TONE);
        #endif
            return TRUE;

        case EN_EXE_DEC_DBC:
        case EN_EXE_INC_DBC:

#if ENABLE_CUS_DBC
#if 0
                if( ST_VIDEO.ePicture != PICTURE_USER)
                {
                    ST_VIDEO.astPicture[PICTURE_USER].u8Backlight = ST_PICTURE.u8Backlight;
                    ST_VIDEO.astPicture[PICTURE_USER].u8Contrast = ST_PICTURE.u8Contrast;
                    ST_VIDEO.astPicture[PICTURE_USER].u8Brightness = ST_PICTURE.u8Brightness;
                    ST_VIDEO.astPicture[PICTURE_USER].u8Saturation = ST_PICTURE.u8Saturation;
                    ST_VIDEO.astPicture[PICTURE_USER].u8Sharpness = ST_PICTURE.u8Sharpness;
                    ST_VIDEO.astPicture[PICTURE_USER].u8Hue = ST_PICTURE.u8Hue;
                    ST_VIDEO.astPicture[PICTURE_USER].eColorTemp = ST_PICTURE.eColorTemp;
                   #if (ENABLE_CUS_NR_MODE_FOLLOW_PICMODE == ENABLE)
                    ST_VIDEO.astPicture[PICTURE_USER].eNRMode.eNR = ST_PICTURE.eNRMode.eNR;
                   #endif
                   #if ENABLE_FLESH_TONE
                    ST_VIDEO.astPicture[PICTURE_USER].eFleshToneMode = ST_PICTURE.eFleshToneMode;
                   #endif
                   #if ENABLE_CUS_DBC
                    ST_VIDEO.astPicture[PICTURE_USER].bDBCStatus =ST_PICTURE.bDBCStatus;
                   #endif
                   #if ENABLE_CUS_DLC
                    ST_VIDEO.astPicture[PICTURE_USER].bDLCStatus =ST_PICTURE.bDLCStatus;
                   #endif
                    ST_VIDEO.ePicture = PICTURE_USER;
                }
#endif
                ST_PICTURE.bDBCStatus=
                    (EN_DBC_STATUS)MApp_ZUI_ACT_DecIncValue_Cycle(
                    act==EN_EXE_INC_DBC,
                    ST_PICTURE.bDBCStatus,DBC_STATUS_OFF, DBC_STATUS_NUM-1, 1);
                // TODO:

                if(ST_PICTURE.bDBCStatus == DBC_STATUS_ON)
                {
                    MApp_ZUI_API_EnableWindow(HWND_MENU_ADVANCE_PICTURE_PC_BACKLIGHT,ENABLE); // smc.truth modify always enable.
                }
                else
                {
                    MApp_ZUI_API_EnableWindow(HWND_MENU_ADVANCE_PICTURE_PC_BACKLIGHT,ENABLE);
                    //Panel_Backlight_PWM_ADJ(msAPI_Mode_PictureBackLightN100toReallyValue(ST_PICTURE.u8Backlight));//ADD 2012-8-1
                }
                MApi_XC_Sys_DLC_DBC_OnOff( );

                MApp_ST_VIDEO_SetDMPUserDate();

                MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_ADVANCE_PICTURE_PC_BACKLIGHT);
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_ADVANCE_PICTURE_DCR);
                //MApp_ZUI_CTL_DynamicListRefreshContent(HWND_MENU_ADVANCE_PICTURE_PAGE_LIST);
 #endif
             return TRUE;

         case EN_EXE_DEC_DLC:
         case EN_EXE_INC_DLC:

 #if ENABLE_CUS_DLC
 #if 0
                 if( ST_VIDEO.ePicture != PICTURE_USER)
                 {
                     ST_VIDEO.astPicture[PICTURE_USER].u8Backlight = ST_PICTURE.u8Backlight;
                     ST_VIDEO.astPicture[PICTURE_USER].u8Contrast = ST_PICTURE.u8Contrast;
                     ST_VIDEO.astPicture[PICTURE_USER].u8Brightness = ST_PICTURE.u8Brightness;
                     ST_VIDEO.astPicture[PICTURE_USER].u8Saturation = ST_PICTURE.u8Saturation;
                     ST_VIDEO.astPicture[PICTURE_USER].u8Sharpness = ST_PICTURE.u8Sharpness;
                     ST_VIDEO.astPicture[PICTURE_USER].u8Hue = ST_PICTURE.u8Hue;
                     ST_VIDEO.astPicture[PICTURE_USER].eColorTemp = ST_PICTURE.eColorTemp;
                    #if (ENABLE_CUS_NR_MODE_FOLLOW_PICMODE == ENABLE)
                     ST_VIDEO.astPicture[PICTURE_USER].eNRMode.eNR = ST_PICTURE.eNRMode.eNR;
                    #endif
                    #if ENABLE_FLESH_TONE
                     ST_VIDEO.astPicture[PICTURE_USER].eFleshToneMode = ST_PICTURE.eFleshToneMode;
                    #endif
                    #if 0//ENABLE_CUS_DBC
                     ST_VIDEO.astPicture[PICTURE_USER].bDBCStatus =ST_PICTURE.bDBCStatus;
                    #endif
                    #if ENABLE_CUS_DLC
                     ST_VIDEO.astPicture[PICTURE_USER].bDLCStatus =ST_PICTURE.bDLCStatus;
                    #endif
                     ST_VIDEO.ePicture = PICTURE_USER;
                 }
#endif
                 ST_PICTURE.bDLCStatus=
                     (EN_DLC_STATUS)MApp_ZUI_ACT_DecIncValue_Cycle(
                     act==EN_EXE_INC_DLC,
                     ST_PICTURE.bDLCStatus,DLC_STATUS_OFF, DLC_STATUS_NUM-1, 1);

                 g_bEnableDLC = ST_PICTURE.bDLCStatus;
                 MApi_XC_DLC_SetOnOff(g_bEnableDLC, MAIN_WINDOW);
                 MApp_ST_VIDEO_SetDMPUserDate();

                 MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_ADVANCE_PICTURE_DCR_ADV);
                 //MApp_ZUI_CTL_DynamicListRefreshContent(HWND_MENU_ADVANCE_PICTURE_PAGE_LIST);
  #endif
              return TRUE;

        case EN_EXE_ONOFF_AUTO_VOLUME:
            stGenSetting.g_SysSetting.fAutoVolume = !stGenSetting.g_SysSetting.fAutoVolume;

            // add AVL function
            msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_MOMENT_MUTEON, E_AUDIOMUTESOURCE_ACTIVESOURCE);

	    #ifdef CUS_AUDIO_AVL_ALWAYS_ON
	    MApi_AUDIO_EnableAutoVolume(DEFAULT_AUTO_VOLUME);
	    #else
	    MApi_AUDIO_EnableAutoVolume((BOOLEAN)stGenSetting.g_SysSetting.fAutoVolume);
	    #endif

           #ifdef CUS_AUDIO_DRC_ADJUST

	    MApi_SND_ProcessEnable(Sound_ENABL_Type_DRC, ENABLE); // DRC		// CUS_XM Sea 20120709:

	    if (stGenSetting.g_SysSetting.fAutoVolume)
	    {
		    MApi_SND_SetParam1(Sound_SET_PARAM_Drc_Threshold, 0x1a, 0); // -8 dBFS		// CUS_XM Sea 20120725: 0X112D34
	    }
	    else
	    {
		    MApi_SND_SetParam1(Sound_SET_PARAM_Drc_Threshold, 0x10, 0); // -8 dBFS		// CUS_XM Sea 20120725: 0X112D34
	    }

	    #endif

            msAPI_Timer_Delayms(256);

            msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_MOMENT_MUTEOFF, E_AUDIOMUTESOURCE_ACTIVESOURCE);

            MApp_ZUI_API_InvalidateWindow(HWND_MENU_SOUND_AUTO_VOLUME_OPTION);
            return TRUE;


        case EN_EXE_ONOFF_HARD_HEARING:
        #if ENABLE_DTV
            //from case MAPP_UIMENUFUNC_ADJUST_SUBTITILE_LANGUAGE_HEARING:
            stGenSetting.g_SysSetting.fHardOfHearing = !stGenSetting.g_SysSetting.fHardOfHearing;
            MApp_ZUI_API_InvalidateWindow(HWND_MENU_OPTION_HARD_HEARING_OPTION);
        #endif
            return TRUE;

#ifdef OPTION_RSS
        case EN_EXE_ONOFF_RSS:
            //from case MAPP_UIMENUFUNC_ADJUST_SUBTITILE_LANGUAGE_HEARING:
            stGenSetting.g_SysSetting.fRSS = !stGenSetting.g_SysSetting.fRSS;
            MApp_ZUI_API_InvalidateWindow(HWND_MENU_OPTION_RSS_OPTION);
            return TRUE;
#endif

#ifdef OPTION_EXTENSION
        case EN_EXE_ONOFF_EXTENSION:
            //from case MAPP_UIMENUFUNC_ADJUST_SUBTITILE_LANGUAGE_HEARING:
            stGenSetting.g_SysSetting.fEXTENSION = !stGenSetting.g_SysSetting.fEXTENSION;
            MApp_ZUI_API_InvalidateWindow(HWND_MENU_OPTION_EXTENSION_OPTION);
            return TRUE;
#endif

        case EN_EXE_DEC_OSD_EFFECT_MODE:
        case EN_EXE_INC_OSD_EFFECT_MODE:
            #if (ENABLE_CUS_UI_SPEC == FALSE)
            stGenSetting.g_SysSetting.fEnableOsdAnimation =(U8) MApp_ZUI_ACT_DecIncValue_Cycle(
                act==EN_EXE_INC_OSD_EFFECT_MODE,
                stGenSetting.g_SysSetting.fEnableOsdAnimation, 0, EN_OSD_EFFECT_NUM-1, 1);
            MApp_ZUI_API_InvalidateWindow(HWND_MENU_OPTION_OSD_EFFECT_OPTION);
            #endif
            return TRUE;

        case EN_EXE_ONOFF_LOCK_SYSTEM:
            //from case MAPP_UIMENUFUNC_ADJSYSTEMLOCKMODE_ON:

            if(!stGenSetting.g_BlockSysSetting.u8EnterLockPage)
            {
                MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_ENTER_MENU_LOCK_PAGE);
                stGenSetting.g_BlockSysSetting.u8EnterLockPage = !stGenSetting.g_BlockSysSetting.u8EnterLockPage;
                break;
            }
            stGenSetting.g_BlockSysSetting.u8BlockSysLockMode=!stGenSetting.g_BlockSysSetting.u8BlockSysLockMode;
            if( stGenSetting.g_BlockSysSetting.u8BlockSysLockMode == 0 )
            {
                //bIsBlocked = FALSE;
                bStopMonitorBlock = TRUE;
                bParentalPWPassCheck = TRUE;
                MApp_Set_MonitorParental(FALSE);
                MApp_EnableBlockProgramme(FALSE);
                MApp_ParentalControl_SetBlockStatus(FALSE);
            }
            else
            {
                bStopMonitorBlock = FALSE;
                MApp_Set_MonitorParental(TRUE);
            }
            MApp_CheckBlockProgramme();
            //MApp_ZUI_API_InvalidateWindow(HWND_MENU_LOCK_SYSTEM_OPTION);
            return TRUE;

        case EN_EXE_DEC_TINT:
        case EN_EXE_INC_TINT:
            if( ST_VIDEO.ePicture != PICTURE_USER)
            {
                ST_VIDEO.astPicture[PICTURE_USER].u8Backlight = ST_PICTURE.u8Backlight;
                ST_VIDEO.astPicture[PICTURE_USER].u8Contrast = ST_PICTURE.u8Contrast;
                ST_VIDEO.astPicture[PICTURE_USER].u8Brightness = ST_PICTURE.u8Brightness;
                ST_VIDEO.astPicture[PICTURE_USER].u8Saturation = ST_PICTURE.u8Saturation;
                ST_VIDEO.astPicture[PICTURE_USER].u8Sharpness = ST_PICTURE.u8Sharpness;
                ST_VIDEO.astPicture[PICTURE_USER].u8Hue = ST_PICTURE.u8Hue;
                ST_VIDEO.astPicture[PICTURE_USER].eColorTemp = ST_PICTURE.eColorTemp;
               #if (ENABLE_CUS_NR_MODE_FOLLOW_PICMODE == ENABLE)
                ST_VIDEO.astPicture[PICTURE_USER].eNRMode.eNR = ST_PICTURE.eNRMode.eNR;
               #endif
               #if ENABLE_FLESH_TONE
                ST_VIDEO.astPicture[PICTURE_USER].eFleshToneMode = ST_PICTURE.eFleshToneMode;
               #endif
               #if 0//ENABLE_CUS_DBC
                ST_VIDEO.astPicture[PICTURE_USER].bDBCStatus =ST_PICTURE.bDBCStatus;
               #endif
               #if ENABLE_CUS_DLC
                ST_VIDEO.astPicture[PICTURE_USER].bDLCStatus =ST_PICTURE.bDLCStatus;
               #endif
                ST_VIDEO.ePicture = PICTURE_USER;
            }
            ST_PICTURE.u8Hue = MApp_ZUI_ACT_DecIncValue(
                act==EN_EXE_INC_TINT,
                ST_PICTURE.u8Hue, 0, 100, 1);
            MApi_XC_ACE_PicSetHue( MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), msAPI_Mode_PictureHueN100toReallyValue(ST_PICTURE.u8Hue) );

            MApp_ST_VIDEO_SetDMPUserDate();

            if (MApp_ZUI_API_GetFocus() == HWND_MENU_PICTURE_ADJUST_BAR)
            {
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_PICTURE_ADJUST_BAR);
            }
            else
            {
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_PIC_ADJ_TINT);
            }
            return TRUE;

        case EN_EXE_DEC_BRIGHTNESS:
        case EN_EXE_INC_BRIGHTNESS:
        {
            U8 u8BR, u8BG, u8BB;

            if( ST_VIDEO.ePicture != PICTURE_USER)
            {
                ST_VIDEO.astPicture[PICTURE_USER].u8Backlight = ST_PICTURE.u8Backlight;
                ST_VIDEO.astPicture[PICTURE_USER].u8Contrast = ST_PICTURE.u8Contrast;
                ST_VIDEO.astPicture[PICTURE_USER].u8Brightness = ST_PICTURE.u8Brightness;
                ST_VIDEO.astPicture[PICTURE_USER].u8Saturation = ST_PICTURE.u8Saturation;
                ST_VIDEO.astPicture[PICTURE_USER].u8Sharpness = ST_PICTURE.u8Sharpness;
                ST_VIDEO.astPicture[PICTURE_USER].u8Hue = ST_PICTURE.u8Hue;
                ST_VIDEO.astPicture[PICTURE_USER].eColorTemp = ST_PICTURE.eColorTemp;
               #if (ENABLE_CUS_NR_MODE_FOLLOW_PICMODE == ENABLE)
                ST_VIDEO.astPicture[PICTURE_USER].eNRMode.eNR = ST_PICTURE.eNRMode.eNR;
               #endif
               #if ENABLE_FLESH_TONE
                ST_VIDEO.astPicture[PICTURE_USER].eFleshToneMode = ST_PICTURE.eFleshToneMode;
               #endif
               #if 0//ENABLE_CUS_DBC
                ST_VIDEO.astPicture[PICTURE_USER].bDBCStatus =ST_PICTURE.bDBCStatus;
               #endif
               #if ENABLE_CUS_DLC
                ST_VIDEO.astPicture[PICTURE_USER].bDLCStatus =ST_PICTURE.bDLCStatus;
               #endif
                ST_VIDEO.ePicture = PICTURE_USER;
            }

            ST_PICTURE.u8Brightness = MApp_ZUI_ACT_DecIncValue(
                act==EN_EXE_INC_BRIGHTNESS,
                ST_PICTURE.u8Brightness, 0, 100, 1);

            u8BR = MApi_XC_Sys_ACE_transfer_Bri((MApp_Scaler_FactoryAdjBrightness(msAPI_Mode_PictureBrightnessN100toReallyValue(ST_PICTURE.u8Brightness),ST_SUBCOLOR.u8SubBrightness)), BRIGHTNESS_R);
            u8BG = MApi_XC_Sys_ACE_transfer_Bri((MApp_Scaler_FactoryAdjBrightness(msAPI_Mode_PictureBrightnessN100toReallyValue(ST_PICTURE.u8Brightness),ST_SUBCOLOR.u8SubBrightness)), BRIGHTNESS_G);
            u8BB = MApi_XC_Sys_ACE_transfer_Bri((MApp_Scaler_FactoryAdjBrightness(msAPI_Mode_PictureBrightnessN100toReallyValue(ST_PICTURE.u8Brightness),ST_SUBCOLOR.u8SubBrightness)), BRIGHTNESS_B);

            MApi_XC_ACE_PicSetBrightnessInVsync(MAIN_WINDOW, u8BR, u8BG, u8BB);
            MApp_ST_VIDEO_SetDMPUserDate();

            if (MApp_ZUI_API_GetFocus() == HWND_MENU_PICTURE_ADJUST_BAR)
            {
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_PICTURE_ADJUST_BAR);
            }
            else
            {
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_PIC_ADJ_BRIGHTNESS);
            }
            return TRUE;
        }

        case EN_EXE_DEC_SHARPNESS:
        case EN_EXE_INC_SHARPNESS:

            if( ST_VIDEO.ePicture != PICTURE_USER)
            {
                ST_VIDEO.astPicture[PICTURE_USER].u8Backlight = ST_PICTURE.u8Backlight;
                ST_VIDEO.astPicture[PICTURE_USER].u8Contrast = ST_PICTURE.u8Contrast;
                ST_VIDEO.astPicture[PICTURE_USER].u8Brightness = ST_PICTURE.u8Brightness;
                ST_VIDEO.astPicture[PICTURE_USER].u8Saturation = ST_PICTURE.u8Saturation;
                ST_VIDEO.astPicture[PICTURE_USER].u8Sharpness = ST_PICTURE.u8Sharpness;
                ST_VIDEO.astPicture[PICTURE_USER].u8Hue = ST_PICTURE.u8Hue;
                ST_VIDEO.astPicture[PICTURE_USER].eColorTemp = ST_PICTURE.eColorTemp;
               #if (ENABLE_CUS_NR_MODE_FOLLOW_PICMODE == ENABLE)
                ST_VIDEO.astPicture[PICTURE_USER].eNRMode.eNR = ST_PICTURE.eNRMode.eNR;
               #endif
               #if ENABLE_FLESH_TONE
                ST_VIDEO.astPicture[PICTURE_USER].eFleshToneMode = ST_PICTURE.eFleshToneMode;
               #endif
               #if 0//ENABLE_CUS_DBC
                ST_VIDEO.astPicture[PICTURE_USER].bDBCStatus =ST_PICTURE.bDBCStatus;
               #endif
               #if ENABLE_CUS_DLC
                ST_VIDEO.astPicture[PICTURE_USER].bDLCStatus =ST_PICTURE.bDLCStatus;
               #endif
                ST_VIDEO.ePicture = PICTURE_USER;
            }
            ST_PICTURE.u8Sharpness = MApp_ZUI_ACT_DecIncValue(
                act==EN_EXE_INC_SHARPNESS,
                ST_PICTURE.u8Sharpness, 0, 100, 1);
            MApi_XC_ACE_PicSetSharpness( MAIN_WINDOW, msAPI_Mode_PictureSharpnessN100toReallyValue(ST_PICTURE.u8Sharpness) );
            MApp_ST_VIDEO_SetDMPUserDate();
            if (MApp_ZUI_API_GetFocus() == HWND_MENU_PICTURE_ADJUST_BAR)
            {
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_PICTURE_ADJUST_BAR);
            }
            else
            {
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_PIC_ADJ_SHARPNESS);
            }
            return TRUE;

        case EN_EXE_DEC_SATURATION:
        case EN_EXE_INC_SATURATION:

            if( ST_VIDEO.ePicture != PICTURE_USER)
            {
                ST_VIDEO.astPicture[PICTURE_USER].u8Backlight = ST_PICTURE.u8Backlight;
                ST_VIDEO.astPicture[PICTURE_USER].u8Contrast = ST_PICTURE.u8Contrast;
                ST_VIDEO.astPicture[PICTURE_USER].u8Brightness = ST_PICTURE.u8Brightness;
                ST_VIDEO.astPicture[PICTURE_USER].u8Saturation = ST_PICTURE.u8Saturation;
                ST_VIDEO.astPicture[PICTURE_USER].u8Sharpness = ST_PICTURE.u8Sharpness;
                ST_VIDEO.astPicture[PICTURE_USER].u8Hue = ST_PICTURE.u8Hue;
                ST_VIDEO.astPicture[PICTURE_USER].eColorTemp = ST_PICTURE.eColorTemp;
               #if (ENABLE_CUS_NR_MODE_FOLLOW_PICMODE == ENABLE)
                ST_VIDEO.astPicture[PICTURE_USER].eNRMode.eNR = ST_PICTURE.eNRMode.eNR;
               #endif
               #if ENABLE_FLESH_TONE
                ST_VIDEO.astPicture[PICTURE_USER].eFleshToneMode = ST_PICTURE.eFleshToneMode;
               #endif
               #if 0//ENABLE_CUS_DBC
                ST_VIDEO.astPicture[PICTURE_USER].bDBCStatus =ST_PICTURE.bDBCStatus;
               #endif
               #if ENABLE_CUS_DLC
                ST_VIDEO.astPicture[PICTURE_USER].bDLCStatus =ST_PICTURE.bDLCStatus;
               #endif
                ST_VIDEO.ePicture = PICTURE_USER;
            }

            ST_PICTURE.u8Saturation = MApp_ZUI_ACT_DecIncValue(
                act==EN_EXE_INC_SATURATION,
                ST_PICTURE.u8Saturation, 0, 100, 1);


            // if(IsHDMIInUse()&&MDrv_PQ_Get_HDMIPCMode())
             if((IsHDMIInUse()&&(g_HdmiPollingStatus.bIsHDMIMode == TRUE) && (ST_VIDEO.eAspectRatio == EN_AspectRatio_point_to_point))
                #if VGA_HDMI_YUV_POINT_TO_POINT
                || (IsHDMIInUse()&&MDrv_PQ_Check_PointToPoint_Mode() && (ST_VIDEO.eAspectRatio == EN_AspectRatio_point_to_point))
                #endif
                )
            {
               ;// do nothing
            }
            else
            {
                MApi_XC_ACE_PicSetSaturation(MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW),  msAPI_Mode_PictureSaturationN100toReallyValue(ST_PICTURE.u8Saturation) );
            }
            MApp_ST_VIDEO_SetDMPUserDate();

            if (MApp_ZUI_API_GetFocus() == HWND_MENU_PICTURE_ADJUST_BAR)
            {
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_PICTURE_ADJUST_BAR);
            }
            else
            {
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_PIC_ADJ_COLOR);
            }
            return TRUE;

        case EN_EXE_DEC_CONTRAST:
        case EN_EXE_INC_CONTRAST:

            if( ST_VIDEO.ePicture != PICTURE_USER)
            {
                ST_VIDEO.astPicture[PICTURE_USER].u8Backlight = ST_PICTURE.u8Backlight;
                ST_VIDEO.astPicture[PICTURE_USER].u8Contrast = ST_PICTURE.u8Contrast;
                ST_VIDEO.astPicture[PICTURE_USER].u8Brightness = ST_PICTURE.u8Brightness;
                ST_VIDEO.astPicture[PICTURE_USER].u8Saturation = ST_PICTURE.u8Saturation;
                ST_VIDEO.astPicture[PICTURE_USER].u8Sharpness = ST_PICTURE.u8Sharpness;
                ST_VIDEO.astPicture[PICTURE_USER].u8Hue = ST_PICTURE.u8Hue;
                ST_VIDEO.astPicture[PICTURE_USER].eColorTemp = ST_PICTURE.eColorTemp;
               #if (ENABLE_CUS_NR_MODE_FOLLOW_PICMODE == ENABLE)
                ST_VIDEO.astPicture[PICTURE_USER].eNRMode.eNR = ST_PICTURE.eNRMode.eNR;
               #endif
               #if ENABLE_FLESH_TONE
                ST_VIDEO.astPicture[PICTURE_USER].eFleshToneMode = ST_PICTURE.eFleshToneMode;
               #endif
               #if 0//ENABLE_CUS_DBC
                ST_VIDEO.astPicture[PICTURE_USER].bDBCStatus =ST_PICTURE.bDBCStatus;
               #endif
               #if ENABLE_CUS_DLC
                ST_VIDEO.astPicture[PICTURE_USER].bDLCStatus =ST_PICTURE.bDLCStatus;
               #endif
                ST_VIDEO.ePicture = PICTURE_USER;
            }

             ST_PICTURE.u8Contrast = MApp_ZUI_ACT_DecIncValue(
                act==EN_EXE_INC_CONTRAST,
                ST_PICTURE.u8Contrast, 0, 100, 1);
        #if 0//VGA_HDMI_YUV_POINT_TO_POINT
            if(IsHDMIInUse()&&MDrv_PQ_Get_HDMIPCMode())
            {
                MApi_XC_ACE_SetPCYUV2RGB(MAIN_WINDOW, FALSE);
                MApi_XC_ACE_PicSetContrast(MAIN_WINDOW, FALSE, MApp_Scaler_FactoryContrast(msAPI_Mode_PictureContrastN100toReallyValue(ST_PICTURE.u8Contrast),ST_SUBCOLOR.u8SubContrast));
            }
            else
        #endif
            {
                MApi_XC_ACE_PicSetContrast(MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), MApp_Scaler_FactoryContrast(msAPI_Mode_PictureContrastN100toReallyValue(ST_PICTURE.u8Contrast),ST_SUBCOLOR.u8SubContrast));
            }
            MApp_ST_VIDEO_SetDMPUserDate();

            if (MApp_ZUI_API_GetFocus() == HWND_MENU_PICTURE_ADJUST_BAR)
            {
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_PICTURE_ADJUST_BAR);
            }
            else
            {
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_PIC_ADJ_CONTRAST);
            }
            return TRUE;

        case EN_EXE_DEC_PICTURE_MODE:
        case EN_EXE_INC_PICTURE_MODE:
            ST_VIDEO.ePicture = (EN_MS_PICTURE)MApp_ZUI_ACT_DecIncValue_Cycle(
                act==EN_EXE_INC_PICTURE_MODE,
                ST_VIDEO.ePicture, PICTURE_MIN, PICTURE_NUMS-1, 1);
            //XM CUS ZHIQIN 2012-7-28 FOR TEST
            //MApi_XC_DLC_SetOnOff(DLC_STATUS_ON, MAIN_WINDOW);
            //Panel_Backlight_PWM_ADJ(msAPI_Mode_PictureBackLightN100toReallyValue(ST_PICTURE.u8Backlight));

#if 0//VGA_HDMI_YUV_POINT_TO_POINT
            MDrv_PQ_SetUserColorMode(ENABLE);
#endif
            MApp_Picture_Setting_SetColor(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW), MAIN_WINDOW);  //MApp_PicSetPicture( (T_MS_PICTURE *) &ST_PICTURE, SYS_INPUT_SOURCE_TYPE);
#if 0//VGA_HDMI_YUV_POINT_TO_POINT
            MDrv_PQ_SetUserColorMode(DISABLE);
#endif
            Panel_Backlight_PWM_ADJ(msAPI_Mode_PictureBackLightN100toReallyValue(ST_PICTURE.u8Backlight));
            if(MApp_ZUI_API_IsSuccessor(HWND_MENU_PICTURE_PAGE_LIST, MApp_ZUI_API_GetFocus()))
            {
            	MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_PICTURE_PICMODE);
            	MApp_ZUI_CTL_DynamicListRefreshContent(HWND_MENU_PICTURE_PAGE_LIST);
            }
            else
			{
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_PICMODE_PICMODE);
                MApp_ZUI_CTL_DynamicListRefreshContent(HWND_MENU_PICTURE_MODE_PAGE_LIST);
			}

            return TRUE;

        case EN_EXE_DEC_COLOR_TEMP:
        case EN_EXE_INC_COLOR_TEMP:
            if( ST_VIDEO.ePicture != PICTURE_USER)
            {
                ST_VIDEO.astPicture[PICTURE_USER].u8Backlight = ST_PICTURE.u8Backlight;
                ST_VIDEO.astPicture[PICTURE_USER].u8Contrast = ST_PICTURE.u8Contrast;
                ST_VIDEO.astPicture[PICTURE_USER].u8Brightness = ST_PICTURE.u8Brightness;
                ST_VIDEO.astPicture[PICTURE_USER].u8Saturation = ST_PICTURE.u8Saturation;
                ST_VIDEO.astPicture[PICTURE_USER].u8Sharpness = ST_PICTURE.u8Sharpness;
                ST_VIDEO.astPicture[PICTURE_USER].u8Hue = ST_PICTURE.u8Hue;
                ST_VIDEO.astPicture[PICTURE_USER].eColorTemp = ST_PICTURE.eColorTemp;
               #if (ENABLE_CUS_NR_MODE_FOLLOW_PICMODE == ENABLE)
                ST_VIDEO.astPicture[PICTURE_USER].eNRMode.eNR = ST_PICTURE.eNRMode.eNR;
               #endif
               #if ENABLE_FLESH_TONE
                ST_VIDEO.astPicture[PICTURE_USER].eFleshToneMode = ST_PICTURE.eFleshToneMode;
               #endif
               #if 0//ENABLE_CUS_DBC
                ST_VIDEO.astPicture[PICTURE_USER].bDBCStatus =ST_PICTURE.bDBCStatus;
               #endif
               #if ENABLE_CUS_DLC
                ST_VIDEO.astPicture[PICTURE_USER].bDLCStatus =ST_PICTURE.bDLCStatus;
               #endif
                ST_VIDEO.ePicture = PICTURE_USER;
            }

            ST_PICTURE.eColorTemp = (EN_MS_COLOR_TEMP)MApp_ZUI_ACT_DecIncValue_Cycle(
                act==EN_EXE_INC_COLOR_TEMP,
                ST_PICTURE.eColorTemp, MS_COLOR_TEMP_MIN, MS_COLOR_TEMP_MAX, 1);

        #if 0//VGA_HDMI_YUV_POINT_TO_POINT
          if(IsHDMIInUse()&&MDrv_PQ_Get_HDMIPCMode())
          {
                 MApi_XC_ACE_SetPCYUV2RGB(MAIN_WINDOW, FALSE);

              #if ENABLE_NEW_COLORTEMP_METHOD
                #if ENABLE_PRECISE_RGBBRIGHTNESS
                    MApi_XC_ACE_PicSetColorTemp(MAIN_WINDOW, FALSE, (XC_ACE_color_temp_ex *) &ST_COLOR_TEMP);
                #else
                    MApi_XC_ACE_PicSetColorTemp(MAIN_WINDOW, FALSE, (XC_ACE_color_temp *) &ST_COLOR_TEMP);
                #endif
              #else
                #if ENABLE_PRECISE_RGBBRIGHTNESS
                    MApi_XC_ACE_PicSetColorTemp( MAIN_WINDOW, FALSE, (XC_ACE_color_temp_ex *) &ST_COLOR_TEMP );
                    MApi_XC_ACE_PicSetBrightnessPreciseInVsync(MAIN_WINDOW, MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cRedOffset, BRIGHTNESS_R ), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cGreenOffset, BRIGHTNESS_G), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cBlueOffset, BRIGHTNESS_B));
                #else
                    MApi_XC_ACE_PicSetColorTemp( MAIN_WINDOW, FALSE, (XC_ACE_color_temp *) &ST_COLOR_TEMP );
                    MApi_XC_ACE_PicSetBrightnessInVsync(MAIN_WINDOW, MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cRedOffset, BRIGHTNESS_R ), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cGreenOffset, BRIGHTNESS_G), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cBlueOffset, BRIGHTNESS_B));
                #endif
             #endif
          }
         else
        #endif
          {
            #if ENABLE_NEW_COLORTEMP_METHOD
                #if ENABLE_PRECISE_RGBBRIGHTNESS
                    MApi_XC_ACE_PicSetColorTemp(MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), (XC_ACE_color_temp_ex *) &ST_COLOR_TEMP);
                #else
                    MApi_XC_ACE_PicSetColorTemp(MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), (XC_ACE_color_temp *) &ST_COLOR_TEMP);
                #endif
            #else
        #if ENABLE_PRECISE_RGBBRIGHTNESS
            MApi_XC_ACE_PicSetColorTemp( MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), (XC_ACE_color_temp_ex *) &ST_COLOR_TEMP );
            MApi_XC_ACE_PicSetBrightnessPreciseInVsync(MAIN_WINDOW, MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cRedOffset, BRIGHTNESS_R ), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cGreenOffset, BRIGHTNESS_G), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cBlueOffset, BRIGHTNESS_B));
        #else
            MApi_XC_ACE_PicSetColorTemp( MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), (XC_ACE_color_temp *) &ST_COLOR_TEMP );
            MApi_XC_ACE_PicSetBrightnessInVsync(MAIN_WINDOW, MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cRedOffset, BRIGHTNESS_R ), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cGreenOffset, BRIGHTNESS_G), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cBlueOffset, BRIGHTNESS_B));
        #endif
            #endif
            #ifdef ENABLE_GAMMA_FOR_COLORTEMP
                MApi_XC_Sys_AdjustGammaTbl(FORCE_SET_VALUE);
            #endif
           }

            MApp_ST_VIDEO_SetDMPUserDate();

            if(MApp_ZUI_API_IsSuccessor(HWND_MENU_PICTURE_PAGE_LIST, MApp_ZUI_API_GetFocus()))
            {
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_PICTURE_COLOR_TEMP);
            }
            else if(MApp_ZUI_API_IsSuccessor(HWND_MENU_PC_PICTURE_PAGE_LIST, MApp_ZUI_API_GetFocus()))
            {
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_PC_PICTURE_COLOR_TEMP);
            }
            else
            {
                MApp_ZUI_CTL_DynamicListRefreshContent(HWND_MENU_PICTURE_COLOR_PAGE_LIST);
            }
            return TRUE;

#if (ENABLE_CUS_UI_SPEC == FALSE)
        case EN_EXE_DEC_COLOR_RED:
        case EN_EXE_INC_COLOR_RED:
            //from case MAPP_UIMENUFUNC_ADJU16B2_COLORTEMP_USER_RED:
            {
                BOOLEAN bIsNeedToReset = FALSE;
                //U8 u8TmpRedScaleValue = ST_COLOR_TEMP.cRedScaleValue;
                U8 u8ValueTmp = ST_COLOR_TEMP.cRedColor;
                ST_COLOR_TEMP.cRedColor = MApp_ZUI_ACT_DecIncValue(
                    act==EN_EXE_INC_COLOR_RED,
                    ST_COLOR_TEMP.cRedColor, MIN_USER_RGB, MAX_USER_RGB, 1);

                ST_COLOR_TEMP.cRedScaleValue = GetColorTemperatureScale100Value(
                    u8ValueTmp, ST_COLOR_TEMP.cRedColor,
                    MIN_USER_RGB, MAX_USER_RGB, ST_COLOR_TEMP.cRedScaleValue, &bIsNeedToReset);
                if (bIsNeedToReset == TRUE) ST_COLOR_TEMP.cRedColor = u8ValueTmp;

                if ((ST_COLOR_TEMP.cRedColor == u8ValueTmp) && !bIsNeedToReset)
                {
                    //bRet = FALSE;
                }
                else
                {
               #if 0//VGA_HDMI_YUV_POINT_TO_POINT
                    if(IsHDMIInUse()&&MDrv_PQ_Get_HDMIPCMode())
                    {
                         MApi_XC_ACE_SetPCYUV2RGB(MAIN_WINDOW, FALSE);

                       #if ENABLE_NEW_COLORTEMP_METHOD
                            #if ENABLE_PRECISE_RGBBRIGHTNESS
                               MApi_XC_ACE_PicSetColorTemp(MAIN_WINDOW, FALSE, (XC_ACE_color_temp_ex *) &ST_COLOR_TEMP);
                            #else
                               MApi_XC_ACE_PicSetColorTemp(MAIN_WINDOW, FALSE, (XC_ACE_color_temp *) &ST_COLOR_TEMP);
                            #endif
                      #else
                            #if ENABLE_PRECISE_RGBBRIGHTNESS
                               MApi_XC_ACE_PicSetColorTemp( MAIN_WINDOW, FALSE, (XC_ACE_color_temp_ex *) &ST_COLOR_TEMP );
                               MApi_XC_ACE_PicSetBrightnessPreciseInVsync(MAIN_WINDOW, MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cRedOffset, BRIGHTNESS_R ), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cGreenOffset, BRIGHTNESS_G), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cBlueOffset, BRIGHTNESS_B));
                            #else
                               MApi_XC_ACE_PicSetColorTemp( MAIN_WINDOW, FALSE, (XC_ACE_color_temp *) &ST_COLOR_TEMP );
                               MApi_XC_ACE_PicSetBrightnessInVsync(MAIN_WINDOW, MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cRedOffset, BRIGHTNESS_R ), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cGreenOffset, BRIGHTNESS_G), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cBlueOffset, BRIGHTNESS_B));
                            #endif
                      #endif
                  }
                  else
                 #endif
                    {
                    #if ENABLE_NEW_COLORTEMP_METHOD
                        #if ENABLE_PRECISE_RGBBRIGHTNESS
                            MApi_XC_ACE_PicSetColorTemp(MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), (XC_ACE_color_temp_ex *) &ST_COLOR_TEMP);
                        #else
                            MApi_XC_ACE_PicSetColorTemp(MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), (XC_ACE_color_temp *) &ST_COLOR_TEMP);
                        #endif
                    #else
                #if ENABLE_PRECISE_RGBBRIGHTNESS
                    MApi_XC_ACE_PicSetColorTemp( MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), (XC_ACE_color_temp_ex *) &ST_COLOR_TEMP );
                    MApi_XC_ACE_PicSetBrightnessPreciseInVsync(MAIN_WINDOW, MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cRedOffset, BRIGHTNESS_R ), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cGreenOffset, BRIGHTNESS_G), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cBlueOffset, BRIGHTNESS_B));
                #else
                    MApi_XC_ACE_PicSetColorTemp( MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), (XC_ACE_color_temp *) &ST_COLOR_TEMP );
                    MApi_XC_ACE_PicSetBrightnessInVsync(MAIN_WINDOW, MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cRedOffset, BRIGHTNESS_R ), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cGreenOffset, BRIGHTNESS_G), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cBlueOffset, BRIGHTNESS_B));
                #endif
                    #endif
                    }
                    //bRet = TRUE;
                }
            }
            MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_PIC_ADJ_TEMP_RED);
            return TRUE;


        case EN_EXE_DEC_COLOR_GREEN:
        case EN_EXE_INC_COLOR_GREEN:
            //from case MAPP_UIMENUFUNC_ADJU16B2_COLORTEMP_USER_GREEN:
            {
                BOOLEAN bIsNeedToReset = FALSE;
                //U8 u8TmpGreenScaleValue = ST_COLOR_TEMP.cGreenScaleValue;
                U8 u8ValueTmp = ST_COLOR_TEMP.cGreenColor;
                ST_COLOR_TEMP.cGreenColor = MApp_ZUI_ACT_DecIncValue(
                    act==EN_EXE_INC_COLOR_GREEN,
                    ST_COLOR_TEMP.cGreenColor, MIN_USER_RGB, MAX_USER_RGB, 1);

                ST_COLOR_TEMP.cGreenScaleValue = GetColorTemperatureScale100Value(
                    u8ValueTmp, ST_COLOR_TEMP.cGreenColor,
                    MIN_USER_RGB, MAX_USER_RGB, ST_COLOR_TEMP.cGreenScaleValue, &bIsNeedToReset);
                if (bIsNeedToReset == TRUE) ST_COLOR_TEMP.cGreenColor = u8ValueTmp;

                if ((ST_COLOR_TEMP.cGreenColor == u8ValueTmp) && !bIsNeedToReset)
                {
                    //bRet = FALSE;
                }
                else
                {
               #if 0//VGA_HDMI_YUV_POINT_TO_POINT
                    if(IsHDMIInUse()&&MDrv_PQ_Get_HDMIPCMode())
                    {
                         MApi_XC_ACE_SetPCYUV2RGB(MAIN_WINDOW, FALSE);

                       #if ENABLE_NEW_COLORTEMP_METHOD
                            #if ENABLE_PRECISE_RGBBRIGHTNESS
                               MApi_XC_ACE_PicSetColorTemp(MAIN_WINDOW, FALSE, (XC_ACE_color_temp_ex *) &ST_COLOR_TEMP);
                            #else
                               MApi_XC_ACE_PicSetColorTemp(MAIN_WINDOW, FALSE, (XC_ACE_color_temp *) &ST_COLOR_TEMP);
                            #endif
                      #else
                            #if ENABLE_PRECISE_RGBBRIGHTNESS
                               MApi_XC_ACE_PicSetColorTemp( MAIN_WINDOW, FALSE, (XC_ACE_color_temp_ex *) &ST_COLOR_TEMP );
                               MApi_XC_ACE_PicSetBrightnessPreciseInVsync(MAIN_WINDOW, MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cRedOffset, BRIGHTNESS_R ), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cGreenOffset, BRIGHTNESS_G), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cBlueOffset, BRIGHTNESS_B));
                            #else
                               MApi_XC_ACE_PicSetColorTemp( MAIN_WINDOW, FALSE, (XC_ACE_color_temp *) &ST_COLOR_TEMP );
                               MApi_XC_ACE_PicSetBrightnessInVsync(MAIN_WINDOW, MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cRedOffset, BRIGHTNESS_R ), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cGreenOffset, BRIGHTNESS_G), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cBlueOffset, BRIGHTNESS_B));
                            #endif
                      #endif
                  }
                  else
                 #endif
                 {
                    #if ENABLE_NEW_COLORTEMP_METHOD
                        #if ENABLE_PRECISE_RGBBRIGHTNESS
                            MApi_XC_ACE_PicSetColorTemp(MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), (XC_ACE_color_temp_ex *) &ST_COLOR_TEMP);
                        #else
                            MApi_XC_ACE_PicSetColorTemp(MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), (XC_ACE_color_temp *) &ST_COLOR_TEMP);
                        #endif
                    #else
                #if ENABLE_PRECISE_RGBBRIGHTNESS
                    MApi_XC_ACE_PicSetColorTemp( MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), (XC_ACE_color_temp_ex *) &ST_COLOR_TEMP );
                    MApi_XC_ACE_PicSetBrightnessPreciseInVsync(MAIN_WINDOW, MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cRedOffset, BRIGHTNESS_R ), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cGreenOffset, BRIGHTNESS_G), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cBlueOffset, BRIGHTNESS_B));
                #else
                    MApi_XC_ACE_PicSetColorTemp( MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), (XC_ACE_color_temp *) &ST_COLOR_TEMP );
                    MApi_XC_ACE_PicSetBrightnessInVsync(MAIN_WINDOW, MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cRedOffset, BRIGHTNESS_R ), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cGreenOffset, BRIGHTNESS_G), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cBlueOffset, BRIGHTNESS_B));
                #endif
                    #endif
                  }
                    //bRet = TRUE;
                }
            }
            MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_PIC_ADJ_TEMP_GREEN);
            return TRUE;

        case EN_EXE_DEC_COLOR_BLUE:
        case EN_EXE_INC_COLOR_BLUE:
            //from case MAPP_UIMENUFUNC_ADJU16B2_COLORTEMP_USER_BLUE:
            {
                BOOLEAN bIsNeedToReset = FALSE;
                //U8 u8TmpBlueScaleValue = ST_COLOR_TEMP.cBlueScaleValue;
                U8 u8ValueTmp = ST_COLOR_TEMP.cBlueColor;
                ST_COLOR_TEMP.cBlueColor = MApp_ZUI_ACT_DecIncValue(
                    act==EN_EXE_INC_COLOR_BLUE,
                    ST_COLOR_TEMP.cBlueColor, MIN_USER_RGB, MAX_USER_RGB, 1);

                ST_COLOR_TEMP.cBlueScaleValue = GetColorTemperatureScale100Value(
                    u8ValueTmp, ST_COLOR_TEMP.cBlueColor,
                    MIN_USER_RGB, MAX_USER_RGB, ST_COLOR_TEMP.cBlueScaleValue, &bIsNeedToReset);
                if (bIsNeedToReset == TRUE) ST_COLOR_TEMP.cBlueColor = u8ValueTmp;

                if ((ST_COLOR_TEMP.cBlueColor == u8ValueTmp) && !bIsNeedToReset)
                {
                    //bRet = FALSE;
                }
                else
                {
               #if 0//VGA_HDMI_YUV_POINT_TO_POINT
                    if(IsHDMIInUse()&&MDrv_PQ_Get_HDMIPCMode())
                    {
                         MApi_XC_ACE_SetPCYUV2RGB(MAIN_WINDOW, FALSE);

                       #if ENABLE_NEW_COLORTEMP_METHOD
                            #if ENABLE_PRECISE_RGBBRIGHTNESS
                               MApi_XC_ACE_PicSetColorTemp(MAIN_WINDOW, FALSE, (XC_ACE_color_temp_ex *) &ST_COLOR_TEMP);
                            #else
                               MApi_XC_ACE_PicSetColorTemp(MAIN_WINDOW, FALSE, (XC_ACE_color_temp *) &ST_COLOR_TEMP);
                            #endif
                      #else
                            #if ENABLE_PRECISE_RGBBRIGHTNESS
                               MApi_XC_ACE_PicSetColorTemp( MAIN_WINDOW, FALSE, (XC_ACE_color_temp_ex *) &ST_COLOR_TEMP );
                               MApi_XC_ACE_PicSetBrightnessPreciseInVsync(MAIN_WINDOW, MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cRedOffset, BRIGHTNESS_R ), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cGreenOffset, BRIGHTNESS_G), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cBlueOffset, BRIGHTNESS_B));
                            #else
                               MApi_XC_ACE_PicSetColorTemp( MAIN_WINDOW, FALSE, (XC_ACE_color_temp *) &ST_COLOR_TEMP );
                               MApi_XC_ACE_PicSetBrightnessInVsync(MAIN_WINDOW, MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cRedOffset, BRIGHTNESS_R ), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cGreenOffset, BRIGHTNESS_G), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cBlueOffset, BRIGHTNESS_B));
                            #endif
                      #endif
                  }
                  else
                 #endif
                 {
                    #if ENABLE_NEW_COLORTEMP_METHOD
                        #if ENABLE_PRECISE_RGBBRIGHTNESS
                            MApi_XC_ACE_PicSetColorTemp(MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), (XC_ACE_color_temp_ex *) &ST_COLOR_TEMP);
                        #else
                            MApi_XC_ACE_PicSetColorTemp(MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), (XC_ACE_color_temp *) &ST_COLOR_TEMP);
                        #endif
                    #else
                #if ENABLE_PRECISE_RGBBRIGHTNESS
                    MApi_XC_ACE_PicSetColorTemp( MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), (XC_ACE_color_temp_ex *) &ST_COLOR_TEMP );
                    MApi_XC_ACE_PicSetBrightnessPreciseInVsync(MAIN_WINDOW, MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cRedOffset, BRIGHTNESS_R ), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cGreenOffset, BRIGHTNESS_G), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cBlueOffset, BRIGHTNESS_B));
                #else
                    MApi_XC_ACE_PicSetColorTemp( MAIN_WINDOW, MApi_XC_IsYUVSpace(MAIN_WINDOW), (XC_ACE_color_temp *) &ST_COLOR_TEMP );
                    MApi_XC_ACE_PicSetBrightnessInVsync(MAIN_WINDOW, MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cRedOffset, BRIGHTNESS_R ), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cGreenOffset, BRIGHTNESS_G), MApi_XC_Sys_ACE_transferRGB_Bri(ST_COLOR_TEMP.cBlueOffset, BRIGHTNESS_B));
                #endif
                    #endif
                    }
                    //bRet = TRUE;
                }
            }
            MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_PIC_ADJ_TEMP_BLUE);
            return TRUE;
#endif
        case EN_EXE_COLOR_RANGE_SETTING:
            stGenSetting.g_SysSetting.fCOLORRANGE = !stGenSetting.g_SysSetting.fCOLORRANGE;
            if(stGenSetting.g_SysSetting.fCOLORRANGE == 0)
            {
                 MDrv_PQ_SetColorRange(PQ_MAIN_WINDOW, FALSE);
            }
            else
            {
                 MDrv_PQ_SetColorRange(PQ_MAIN_WINDOW, TRUE);
            }
            MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_ADVANCE_PICTURE_COLOR_RANGE);
            return TRUE;

#if (ENABLE_CUS_UI_SPEC == FALSE)
        case EN_EXE_SINGLELIST_UP:
            switch(MApp_ZUI_ACT_GetSingleListMode())
            {
                case EN_COMMON_SINGLELIST_ASPECT_RATIO:
                    MApp_ZUI_ACT_ExecuteMenuItemAction(EN_EXE_INC_ASPECT_RATIO);
                    break;
                case EN_COMMON_SINGLELIST_NOISE_REDUCTION:
                    MApp_ZUI_ACT_ExecuteMenuItemAction(EN_EXE_DEC_NOISE_REDUCTION);
                    break;
                case EN_COMMON_SINGLELIST_SURROUND_SOUND:
                    MApp_ZUI_ACT_ExecuteMenuItemAction(EN_EXE_INC_SURROUND_SOUND);
                    break;
                case EN_COMMON_SINGLELIST_SLEEP_TIMER:
                    MApp_ZUI_ACT_ExecuteMenuItemAction(EN_EXE_DEC_SLEEP_TIMER);
                    break;
                case EN_COMMON_SINGLELIST_PARENTAL_GUIDANCE:
                    MApp_ZUI_ACT_ExecuteMenuItemAction(EN_EXE_DEC_PARENTAL_GUIDANCE);
                    break;

            #if ENABLE_T_C_COMBO
                case EN_COMMON_SINGLELIST_DVB_SELECT:
                    MApp_ZUI_ACT_ExecuteMenuItemAction(EN_EXE_DVB_TYPE_SELECT);
                    break;
            #endif

            #if (ATSC_CC == ATV_CC)
                case EN_COMMON_SINGLELIST_CC_OPTION:
                    MApp_ZUI_ACT_ExecuteMenuItemAction(EN_EXE_DEC_OPTION_CC_OPTION);
                    break;
            #endif
            #if ENABLE_3D_PROCESS
                case EN_COMMON_SINGLELIST_3D_OPTION:
                    MApp_ZUI_ACT_ExecuteMenuItemAction(EN_EXE_DEC_3DTYPE_MODE);
                    break;
            #endif

                default:
                    break;
             }
            return TRUE;

        case EN_EXE_SINGLELIST_DOWN:
            switch(MApp_ZUI_ACT_GetSingleListMode())
            {
                case EN_COMMON_SINGLELIST_ASPECT_RATIO:
                    MApp_ZUI_ACT_ExecuteMenuItemAction(EN_EXE_DEC_ASPECT_RATIO);
                    break;
                case EN_COMMON_SINGLELIST_NOISE_REDUCTION:
                    MApp_ZUI_ACT_ExecuteMenuItemAction(EN_EXE_INC_NOISE_REDUCTION);
                    break;
                case EN_COMMON_SINGLELIST_SURROUND_SOUND:
                    MApp_ZUI_ACT_ExecuteMenuItemAction(EN_EXE_DEC_SURROUND_SOUND);
                    break;
                case EN_COMMON_SINGLELIST_SLEEP_TIMER:
                    MApp_ZUI_ACT_ExecuteMenuItemAction(EN_EXE_INC_SLEEP_TIMER);
                    break;
                case EN_COMMON_SINGLELIST_PARENTAL_GUIDANCE:
                    MApp_ZUI_ACT_ExecuteMenuItemAction(EN_EXE_INC_PARENTAL_GUIDANCE);
                    break;

            #if ENABLE_T_C_COMBO
                case EN_COMMON_SINGLELIST_DVB_SELECT:
                    MApp_ZUI_ACT_ExecuteMenuItemAction(EN_EXE_DVB_TYPE_SELECT);
                    break;
            #endif

            #if (ATSC_CC == ATV_CC)
                case EN_COMMON_SINGLELIST_CC_OPTION:
                    MApp_ZUI_ACT_ExecuteMenuItemAction(EN_EXE_INC_OPTION_CC_OPTION);
                    break;
            #endif
            #if ENABLE_3D_PROCESS
                case EN_COMMON_SINGLELIST_3D_OPTION:
                    MApp_ZUI_ACT_ExecuteMenuItemAction(EN_EXE_INC_3DTYPE_MODE);
                    break;
            #endif

                default:
                    break;
            }
            return TRUE;

            case EN_EXE_OPTIONLIST_LEFT:
            switch(MApp_ZUI_ACT_GetOptionListMode())
            {

#ifdef NETWORK_CONFIG
                case EN_COMMON_OPTIONLIST_NETWORK_DNS:
                    switch (MApp_ZUI_API_GetFocus())
                    {
                          case HWND_MENU_OPTIONLIST_ITEM2:
                            MApp_ZUI_ACT_ExecuteNetDNSDialogAction(EN_EXE_DEC_NET_DNS_A);
                            break;
                          case HWND_MENU_OPTIONLIST_ITEM3:
                            MApp_ZUI_ACT_ExecuteNetDNSDialogAction(EN_EXE_DEC_NET_DNS_B);
                            break;
                          case HWND_MENU_OPTIONLIST_ITEM4:
                            MApp_ZUI_ACT_ExecuteNetDNSDialogAction(EN_EXE_DEC_NET_DNS_C);
                            break;
                          case HWND_MENU_OPTIONLIST_ITEM5:
                            MApp_ZUI_ACT_ExecuteNetDNSDialogAction(EN_EXE_DEC_NET_DNS_D);
                            break;
                          default:
                            break;
                    }
                    break;
                case EN_COMMON_OPTIONLIST_NETWORK_GW:
                    switch (MApp_ZUI_API_GetFocus())
                    {
                          case HWND_MENU_OPTIONLIST_ITEM2:
                            MApp_ZUI_ACT_ExecuteNetGatewayDialogAction(EN_EXE_DEC_NET_GATEWAY_A);
                            break;
                          case HWND_MENU_OPTIONLIST_ITEM3:
                            MApp_ZUI_ACT_ExecuteNetGatewayDialogAction(EN_EXE_DEC_NET_GATEWAY_B);
                            break;
                          case HWND_MENU_OPTIONLIST_ITEM4:
                            MApp_ZUI_ACT_ExecuteNetGatewayDialogAction(EN_EXE_DEC_NET_GATEWAY_C);
                            break;
                          case HWND_MENU_OPTIONLIST_ITEM5:
                            MApp_ZUI_ACT_ExecuteNetGatewayDialogAction(EN_EXE_DEC_NET_GATEWAY_D);
                            break;
                          default:
                            break;
                    }
                    break;
                case EN_COMMON_OPTIONLIST_NETWORK_IP:
                    switch (MApp_ZUI_API_GetFocus())
                    {
                          case HWND_MENU_OPTIONLIST_ITEM2:
                            MApp_ZUI_ACT_ExecuteNetIPDialogAction(EN_EXE_DEC_NET_IP_A);
                            break;
                          case HWND_MENU_OPTIONLIST_ITEM3:
                            MApp_ZUI_ACT_ExecuteNetIPDialogAction(EN_EXE_DEC_NET_IP_B);
                            break;
                          case HWND_MENU_OPTIONLIST_ITEM4:
                            MApp_ZUI_ACT_ExecuteNetIPDialogAction(EN_EXE_DEC_NET_IP_C);
                            break;
                          case HWND_MENU_OPTIONLIST_ITEM5:
                            MApp_ZUI_ACT_ExecuteNetIPDialogAction(EN_EXE_DEC_NET_IP_D);
                            break;
                          default:
                            break;
                    }
                    break;
                case EN_COMMON_OPTIONLIST_NETWORK_NETMASK:
                    switch (MApp_ZUI_API_GetFocus())
                    {
                          case HWND_MENU_OPTIONLIST_ITEM2:
                            MApp_ZUI_ACT_ExecuteNetNetmaskDialogAction(EN_EXE_DEC_NET_NETMASK_A);
                            break;
                          case HWND_MENU_OPTIONLIST_ITEM3:
                            MApp_ZUI_ACT_ExecuteNetNetmaskDialogAction(EN_EXE_DEC_NET_NETMASK_B);
                            break;
                          case HWND_MENU_OPTIONLIST_ITEM4:
                            MApp_ZUI_ACT_ExecuteNetNetmaskDialogAction(EN_EXE_DEC_NET_NETMASK_C);
                            break;
                          case HWND_MENU_OPTIONLIST_ITEM5:
                            MApp_ZUI_ACT_ExecuteNetNetmaskDialogAction(EN_EXE_DEC_NET_NETMASK_D);
                            break;
                          default:
                            break;
                    }
                    break;
                case EN_COMMON_OPTIONLIST_NETWORK_CONFIG:
                    MApp_ZUI_API_ShowWindow(HWND_MENU_CHECK_NETWORK, SW_HIDE);//close network status osd
                    switch (MApp_ZUI_API_GetFocus())
                    {
                          case HWND_MENU_OPTIONLIST_ITEM1:
                            MApp_ZUI_ACT_ExecuteNetConfigDialogAction(EN_EXE_DEC_NET_CONFIG);
                            break;
                          case HWND_MENU_OPTIONLIST_ITEM2:
                            MApp_ZUI_ACT_ExecuteNetConfigDialogAction(EN_EXE_GOTO_NET_CONFIG_IP);
                            break;
                          case HWND_MENU_OPTIONLIST_ITEM3:
                            MApp_ZUI_ACT_ExecuteNetConfigDialogAction(EN_EXE_GOTO_NET_CONFIG_NETMASK);
                            break;
                          case HWND_MENU_OPTIONLIST_ITEM4:
                            MApp_ZUI_ACT_ExecuteNetConfigDialogAction(EN_EXE_GOTO_NET_CONFIG_GW);
                            break;
                          case HWND_MENU_OPTIONLIST_ITEM5:
                            MApp_ZUI_ACT_ExecuteNetConfigDialogAction(EN_EXE_GOTO_NET_CONFIG_DNS);
                            break;
                          case HWND_MENU_OPTIONLIST_ITEM6:
                            MApp_ZUI_ACT_ExecuteNetConfigDialogAction(EN_EXE_ONOFF_NET_CONFIG_PROXY);
                            break;
                          default:
                            break;
                    }
                    break;
  #endif
                    case EN_COMMON_OPTIONLIST_SOUND_BALANCE:
                    switch (MApp_ZUI_API_GetFocus())
                    {
                          case HWND_MENU_OPTIONLIST_ITEM2:
                            MApp_ZUI_ACT_ExecuteMenuItemAction(EN_EXE_DEC_BALANCE);
                            break;
                          default:
                            break;
                    }
                    break;
                default:
                    break;
             }
            return TRUE;

           case EN_EXE_OPTIONLIST_RIGHT:
            switch(MApp_ZUI_ACT_GetOptionListMode())
            {
#ifdef NETWORK_CONFIG
                case EN_COMMON_OPTIONLIST_NETWORK_DNS:
                    switch (MApp_ZUI_API_GetFocus())
                    {
                          case HWND_MENU_OPTIONLIST_ITEM2:
                            MApp_ZUI_ACT_ExecuteNetDNSDialogAction(EN_EXE_INC_NET_DNS_A);
                            break;
                          case HWND_MENU_OPTIONLIST_ITEM3:
                            MApp_ZUI_ACT_ExecuteNetDNSDialogAction(EN_EXE_INC_NET_DNS_B);
                            break;
                          case HWND_MENU_OPTIONLIST_ITEM4:
                            MApp_ZUI_ACT_ExecuteNetDNSDialogAction(EN_EXE_INC_NET_DNS_C);
                            break;
                          case HWND_MENU_OPTIONLIST_ITEM5:
                            MApp_ZUI_ACT_ExecuteNetDNSDialogAction(EN_EXE_INC_NET_DNS_D);
                            break;
                          default:
                            break;
                    }
                    break;
                case EN_COMMON_OPTIONLIST_NETWORK_GW:
                    switch (MApp_ZUI_API_GetFocus())
                    {
                          case HWND_MENU_OPTIONLIST_ITEM2:
                            MApp_ZUI_ACT_ExecuteNetGatewayDialogAction(EN_EXE_INC_NET_GATEWAY_A);
                            break;
                          case HWND_MENU_OPTIONLIST_ITEM3:
                            MApp_ZUI_ACT_ExecuteNetGatewayDialogAction(EN_EXE_INC_NET_GATEWAY_B);
                            break;
                          case HWND_MENU_OPTIONLIST_ITEM4:
                            MApp_ZUI_ACT_ExecuteNetGatewayDialogAction(EN_EXE_INC_NET_GATEWAY_C);
                            break;
                          case HWND_MENU_OPTIONLIST_ITEM5:
                            MApp_ZUI_ACT_ExecuteNetGatewayDialogAction(EN_EXE_INC_NET_GATEWAY_D);
                            break;
                          default:
                            break;
                    }
                    break;
                case EN_COMMON_OPTIONLIST_NETWORK_IP:
                    switch (MApp_ZUI_API_GetFocus())
                    {
                          case HWND_MENU_OPTIONLIST_ITEM2:
                            MApp_ZUI_ACT_ExecuteNetIPDialogAction(EN_EXE_INC_NET_IP_A);
                            break;
                          case HWND_MENU_OPTIONLIST_ITEM3:
                            MApp_ZUI_ACT_ExecuteNetIPDialogAction(EN_EXE_INC_NET_IP_B);
                            break;
                          case HWND_MENU_OPTIONLIST_ITEM4:
                            MApp_ZUI_ACT_ExecuteNetIPDialogAction(EN_EXE_INC_NET_IP_C);
                            break;
                          case HWND_MENU_OPTIONLIST_ITEM5:
                            MApp_ZUI_ACT_ExecuteNetIPDialogAction(EN_EXE_INC_NET_IP_D);
                            break;
                          default:
                            break;
                    }
                    break;
                case EN_COMMON_OPTIONLIST_NETWORK_NETMASK:
                    switch (MApp_ZUI_API_GetFocus())
                    {
                          case HWND_MENU_OPTIONLIST_ITEM2:
                            MApp_ZUI_ACT_ExecuteNetNetmaskDialogAction(EN_EXE_INC_NET_NETMASK_A);
                            break;
                          case HWND_MENU_OPTIONLIST_ITEM3:
                            MApp_ZUI_ACT_ExecuteNetNetmaskDialogAction(EN_EXE_INC_NET_NETMASK_B);
                            break;
                          case HWND_MENU_OPTIONLIST_ITEM4:
                            MApp_ZUI_ACT_ExecuteNetNetmaskDialogAction(EN_EXE_INC_NET_NETMASK_C);
                            break;
                          case HWND_MENU_OPTIONLIST_ITEM5:
                            MApp_ZUI_ACT_ExecuteNetNetmaskDialogAction(EN_EXE_INC_NET_NETMASK_D);
                            break;
                          default:
                            break;
                    }
                    break;
                case EN_COMMON_OPTIONLIST_NETWORK_CONFIG:
#ifdef NETWORK_CONFIG
                    MApp_ZUI_API_ShowWindow(HWND_MENU_CHECK_NETWORK, SW_HIDE);
#endif
                    switch (MApp_ZUI_API_GetFocus())
                    {
                          case HWND_MENU_OPTIONLIST_ITEM1:
                            MApp_ZUI_ACT_ExecuteNetConfigDialogAction(EN_EXE_INC_NET_CONFIG);
                            break;
                          case HWND_MENU_OPTIONLIST_ITEM2:
                            MApp_ZUI_ACT_ExecuteNetConfigDialogAction(EN_EXE_GOTO_NET_CONFIG_IP);
                            break;
                          case HWND_MENU_OPTIONLIST_ITEM3:
                            MApp_ZUI_ACT_ExecuteNetConfigDialogAction(EN_EXE_GOTO_NET_CONFIG_NETMASK);
                            break;
                          case HWND_MENU_OPTIONLIST_ITEM4:
                            MApp_ZUI_ACT_ExecuteNetConfigDialogAction(EN_EXE_GOTO_NET_CONFIG_GW);
                            break;
                          case HWND_MENU_OPTIONLIST_ITEM5:
                            MApp_ZUI_ACT_ExecuteNetConfigDialogAction(EN_EXE_GOTO_NET_CONFIG_DNS);
                            break;
                          case HWND_MENU_OPTIONLIST_ITEM6:
                            MApp_ZUI_ACT_ExecuteNetConfigDialogAction(EN_EXE_ONOFF_NET_CONFIG_PROXY);
                            break;
                          default:
                            break;
                    }
                    break;
#endif
                case EN_COMMON_OPTIONLIST_SOUND_BALANCE:
                    switch (MApp_ZUI_API_GetFocus())
                    {
                          case HWND_MENU_OPTIONLIST_ITEM2:
                            MApp_ZUI_ACT_ExecuteMenuItemAction(EN_EXE_INC_BALANCE);
                            break;
                          default:
                            break;
                    }
                    break;
                default:
                    break;
            }
            return TRUE;
#endif
        case EN_EXE_DEC_ASPECT_RATIO:
        case EN_EXE_INC_ASPECT_RATIO:
          #if 0// (!ENABLE_FBL_ASPECT_RATIO_BY_MVOP)
            if(MApi_XC_IsCurrentFrameBufferLessMode())
            {
                MS_DEBUG_MSG(printf("FrameBuffer less mode\n"));
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_PICTURE_MODE_PAGE);
                MApp_ZUI_API_ShowWindow(HWND_MENU_ALERT_WINDOW, SW_SHOW);
                break;
            }
          #endif
          #if ENABLE_ZOOM_AVOUT_NOTMUTE
            bIsAspectMute = TRUE;
          #endif
            _MApp_ZUI_ACT_DecIncAspectRatio_Cycle(act==EN_EXE_INC_ASPECT_RATIO);
          #if ENABLE_ZOOM_AVOUT_NOTMUTE
            bIsAspectMute = FALSE;
          #endif
            MApp_ZUI_API_InvalidateWindow(HWND_MENU_OPTION_ASPECT_RATIO);
            return TRUE;

        case EN_EXE_DEC_SURROUND_SOUND:
        case EN_EXE_INC_SURROUND_SOUND:
            {
                EN_SURROUND_SYSTEM_TYPE enSurroundSoundMode;

                if(stGenSetting.g_SoundSetting.SoundMode != SOUND_MODE_USER)
                {
                    stGenSetting.g_SoundSetting.astSoundModeSetting[SOUND_MODE_USER] =
                        stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode];
                    stGenSetting.g_SoundSetting.SoundMode = SOUND_MODE_USER;
                }
#if (ENABLE_CUS_SURROUND_FOLLOW_SNDMODE == DISABLE)
                enSurroundSoundMode = stGenSetting.g_SoundSetting.SurroundSoundMode;
#else
                enSurroundSoundMode = stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].SurroundSoundMode;
#endif
#if ENABLE_CUS_UI_SPEC
                if(enSurroundSoundMode == SURROUND_SYSTEM_OFF)
                {
                    enSurroundSoundMode = SURROUND_SYSTEM_SURROUNDMAX;
                }
                else
                {
                    enSurroundSoundMode = SURROUND_SYSTEM_OFF;
                }
#else
                do{
                    enSurroundSoundMode =(EN_SURROUND_SYSTEM_TYPE)MApp_ZUI_ACT_DecIncValue_Cycle(
                        act==EN_EXE_INC_SURROUND_SOUND,
                        enSurroundSoundMode, SURROUND_SYSTEM_OFF, SURROUND_SYSTEM_NUMS-1, 1);

                #if (ENABLE_AUDIO_SURROUND_SRS)
                    if ( enSurroundSoundMode == SURROUND_SYSTEM_SRS   )
                        break;
                    #endif

                #if ( ENABLE_AUDIO_SURROUND_BBE)
                    if ( enSurroundSoundMode == SURROUND_SYSTEM_BBE   )
                        break;
                    #endif

                #if (ENABLE_AUDIO_SURROUND_VDS)
                    if ( enSurroundSoundMode == SURROUND_SYSTEM_VDS   )
                        break;
                    #endif

                #if (ENABLE_AUDIO_SURROUND_VSPK)
                    if ( enSurroundSoundMode == SURROUND_SYSTEM_VSPK )
                        break;
                    #endif

                }while (enSurroundSoundMode != SURROUND_SYSTEM_SURROUNDMAX &&
                              enSurroundSoundMode !=  SURROUND_SYSTEM_OFF    );
#endif
                msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_MOMENT_MUTEON, E_AUDIOMUTESOURCE_ACTIVESOURCE);
                MApp_Aud_SetSurroundMode( enSurroundSoundMode );

#if (ENABLE_CUS_SURROUND_FOLLOW_SNDMODE == DISABLE)
                stGenSetting.g_SoundSetting.SurroundSoundMode = enSurroundSoundMode;
#else
                stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].SurroundSoundMode = enSurroundSoundMode ;
#endif
                msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_MOMENT_MUTEOFF, E_AUDIOMUTESOURCE_ACTIVESOURCE);
            }

            MApp_ZUI_CTL_DynamicListRefreshContent(HWND_MENU_SOUND_PAGE_LIST);
            return TRUE;

#if (ENABLE_CUS_UI_SPEC == FALSE)
        case EN_EXE_DEC_SOUND_AD_FADE:
        case EN_EXE_INC_SOUND_AD_FADE:
            stGenSetting.g_SoundSetting.ADVolume =
                MApp_ZUI_ACT_DecIncValue(
                    act==EN_EXE_INC_SOUND_AD_FADE,
                    stGenSetting.g_SoundSetting.ADVolume, 0, 100, 1);
            if(IsDTVInUse())
            {
                MApi_AUDIO_SetADAbsoluteVolume(MApi_AUDIO_ConvertVolumeUnit(stGenSetting.g_SoundSetting.ADVolume));
            }
            MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_SOUND_SWITCH_AD_FADE);
            return TRUE;
#endif
        /*
        case EN_EXE_DEC_SOUND_AD_PAN:
        case EN_EXE_INC_SOUND_AD_PAN:
            //from case MAPP_UIMENUFUNC_ADJUST_SOUND_AD_OUTPUT:
            stGenSetting.g_SoundSetting.ADOutput=
            (EN_SOUND_AD_OUTPUT)MApp_ZUI_ACT_DecIncValue(
                act==EN_EXE_INC_SOUND_AD_PAN,
                stGenSetting.g_SoundSetting.ADOutput, AD_SPEAKER, AD_BOTH, 1);
            if(IsDTVInUse())
            {
            msAPI_AUD_SetADOutputMode(stGenSetting.g_SoundSetting.ADOutput);
            }
            MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_SOUND_AD_PAN);
            return TRUE;
        */
        case EN_EXE_SPDIF_MODE_PCM_AUTO:
            #if ENABLE_CUS_SPDIF_MODE
            // PCM <--> OFF
            if(stGenSetting.g_SysSetting.fSPDIFMODE == 0) //PCM
            {
                stGenSetting.g_SysSetting.fSPDIFMODE = 2; // OFF
            }
            else
            {
                stGenSetting.g_SysSetting.fSPDIFMODE = 0; //PCM
            }
            #else
            stGenSetting.g_SysSetting.fSPDIFMODE = !stGenSetting.g_SysSetting.fSPDIFMODE;
            #endif

            #if ENABLE_NEW_SPDIF_MUTE_METHOD
            MApp_Audio_SPDIF_SetMute(TRUE, FORCE_MUTE);
            #else
            MApi_AUDIO_SPDIF_SetMute(TRUE);
            #endif

            if ( IsHDMIInUse())
            {
                if ((MApi_AUDIO_HDMI_Monitor() & 0xC0) == 0x40) // Non-PCM received
                {
                    if ( stGenSetting.g_SysSetting.fSPDIFMODE==1 ) // non-PCM
                    {
                        MApi_AUDIO_SPDIF_SetMode(MSAPI_AUD_SPDIF_NONPCM); //msAPI_AUD_SPDIF_SetMode(MSAPI_AUD_SPDIF_NONPCM);
                    }
                    #if ENABLE_CUS_SPDIF_MODE
                    else if(stGenSetting.g_SysSetting.fSPDIFMODE >1)
                    {
                        MApi_AUDIO_SPDIF_SetMode(MSAPI_AUD_SPDIF_PCM);
                    }
                    #endif
                    else
                    {
                        MApi_AUDIO_SPDIF_SetMode(MSAPI_AUD_SPDIF_PCM); //msAPI_AUD_SPDIF_SetMode(MSAPI_AUD_SPDIF_PCM);
                    }
                }
                else
                {
                    MApi_AUDIO_SetCommand(MSAPI_AUD_DVB_DECCMD_STOP); //MApi_AUDIO_SetCommand(MSAPI_AUD_STOP);
                    MApi_AUDIO_SPDIF_SetMode(MSAPI_AUD_SPDIF_PCM); //msAPI_AUD_SPDIF_SetMode(MSAPI_AUD_SPDIF_PCM);
                }
            }
            else
            {
                if (!MApi_AUDIO_GetAC3Info(Audio_AC3_infoType_DecStatus))
                {
                    MApi_AUDIO_SPDIF_SetMode(MSAPI_AUD_SPDIF_PCM); // msAPI_AUD_SPDIF_SetMode(MSAPI_AUD_SPDIF_PCM);
                }
                else
                {
                if ( stGenSetting.g_SysSetting.fSPDIFMODE==1 ) // non-PCM
                {
                    MApi_AUDIO_SPDIF_SetMode(MSAPI_AUD_SPDIF_NONPCM); //msAPI_AUD_SPDIF_SetMode(MSAPI_AUD_SPDIF_NONPCM);
                }
                #if ENABLE_CUS_SPDIF_MODE
                else if(stGenSetting.g_SysSetting.fSPDIFMODE >1)
                {
                    MApi_AUDIO_SPDIF_SetMode(MSAPI_AUD_SPDIF_PCM);
                }
                #endif
                else
                {
                    MApi_AUDIO_SPDIF_SetMode(MSAPI_AUD_SPDIF_PCM); //msAPI_AUD_SPDIF_SetMode(MSAPI_AUD_SPDIF_PCM);
                }
            }
            }

            #if ENABLE_NEW_SPDIF_MUTE_METHOD
            MApp_Audio_SPDIF_SetMute(FALSE, FORCE_MUTE);
            #else
            MApi_AUDIO_SPDIF_SetMute(FALSE);
            #endif
            MApp_ZUI_API_InvalidateWindow(HWND_MENU_SOUND_SPDIF_MODE_OPTION);
            if(stGenSetting.g_SysSetting.fSPDIFMODE)
            {
                MApp_ZUI_API_EnableWindow(HWND_MENU_SOUND_AUDIO_DELAY,DISABLE);
            }
            else
            {
                MApp_ZUI_API_EnableWindow(HWND_MENU_SOUND_AUDIO_DELAY,ENABLE);
            }
            MApp_ZUI_API_InvalidateWindow(HWND_MENU_SOUND_AUDIO_DELAY);
            return TRUE;

#if (ENABLE_CUS_UI_SPEC == FALSE) /*Creass.liu at 2012-06-27*/
        case EN_EXE_ONOFF_SOUND_AD:
            stGenSetting.g_SoundSetting.bEnableAD=
                !stGenSetting.g_SoundSetting.bEnableAD;
#if ENABLE_DTV
            if(IsDTVInUse())
            {
                if (stGenSetting.g_SoundSetting.bEnableAD)
                {
                    MApp_Audio_SearchAdAudio();

                    // if ad exist
                    if (g_u8AdAudSelected != 0xFF)
                    {
                        MApp_Audio_SetAdAudio(g_u8AdAudSelected);
                        MApi_AUDIO_SetADOutputMode(AD_OUT_BOTH);
                        MApi_AUDIO_SetADAbsoluteVolume(MApi_AUDIO_ConvertVolumeUnit(stGenSetting.g_SoundSetting.ADVolume));
                        //MApi_AUDIO_SetCommand(MSAPI_AUD_DVB2_DECCMD_PLAY);
                    }
                }
                else
                {
                    MApi_AUDIO_SetADOutputMode(AD_OUT_NONE);
                    MApi_AUDIO_SetCommand(MSAPI_AUD_DVB2_DECCMD_STOP);
                    msAPI_DMX_Stop(*MApp_Dmx_GetFid(EN_AD_FID));
                }

            }
#endif
            MApp_ZUI_CTL_DynamicListRefreshContent(HWND_MENU_SOUND_SWITCH_PAGE_LIST);
            return TRUE;
#endif
        case EN_EXE_DEC_SOUND_MODE:
        case EN_EXE_INC_SOUND_MODE:
            stGenSetting.g_SoundSetting.SoundMode = (EN_SOUND_MODE)MApp_ZUI_ACT_DecIncValue_Cycle(
                act==EN_EXE_INC_SOUND_MODE,
                stGenSetting.g_SoundSetting.SoundMode, EN_SoundMode_Standard, EN_SoundMode_Num-1, 1);
#if (ENABLE_CUS_SURROUND_FOLLOW_SNDMODE == DISABLE)
            MApp_Aud_SetSurroundMode( stGenSetting.g_SoundSetting.SurroundSoundMode );
#else
            MApp_Aud_SetSurroundMode( stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].SurroundSoundMode );
#endif
            msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_MOMENT_MUTEON, E_AUDIOMUTESOURCE_ACTIVESOURCE);
            MApp_Audio_AdjustSoundMode();
            msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_MOMENT_MUTEOFF, E_AUDIOMUTESOURCE_ACTIVESOURCE);

            if(MApp_ZUI_API_IsSuccessor(HWND_MENU_SOUND_PAGE_LIST, MApp_ZUI_API_GetFocus()))
            {
                MApp_ZUI_CTL_DynamicListRefreshContent(HWND_MENU_SOUND_PAGE_LIST);
            }
            else
            {
                MApp_ZUI_CTL_DynamicListRefreshContent(HWND_MENU_SOUND_MODE_PAGE_LIST);
            }
            return TRUE;

        case EN_EXE_DEC_TREBLE:
        case EN_EXE_INC_TREBLE:
            {
                //MApp_UiMenuFunc_CheckAudioMode();
                U8 u8ValueTmp = stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].Treble;
		//XM CUS ZHIQIN
            if(stGenSetting.g_SoundSetting.SoundMode != SOUND_MODE_USER)
            {
                stGenSetting.g_SoundSetting.astSoundModeSetting[SOUND_MODE_USER] =
                    stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode];
                stGenSetting.g_SoundSetting.SoundMode = SOUND_MODE_USER;
            }

                stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].Treble =
                    MApp_ZUI_ACT_DecIncValue(
                        act==EN_EXE_INC_TREBLE,
                        stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].Treble, 0, 100, 1);

                if(stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].Treble == u8ValueTmp)
                {
                    //bRet = FALSE;
                }
                else
                {
                    MApi_AUDIO_EnableEQ(FALSE);
                    MApi_AUDIO_EnableTone(TRUE);
		#ifdef CUS_AUDIO_TREBLE_BASS_LIMIT
     			MApi_AUDIO_SetTrebleLimit(stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].Treble);
		#else
                    MApi_AUDIO_SetTreble(stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].Treble);
		#endif
                    //bRet = TRUE;
                }
            }
/*
            if(stGenSetting.g_SoundSetting.SoundMode != SOUND_MODE_USER)
            {
                stGenSetting.g_SoundSetting.astSoundModeSetting[SOUND_MODE_USER] =
                    stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode];
                stGenSetting.g_SoundSetting.SoundMode = SOUND_MODE_USER;
            }
*/
            if (MApp_ZUI_API_GetFocus() == HWND_MENU_PICTURE_ADJUST_BAR)
            {
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_PICTURE_ADJUST_BAR);
            }
            else
            {
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_SNDMODE_TREBLE);
            }
            return TRUE;

        case EN_EXE_GOTO_PICTURE_BACKLIGHT_ADJUST_DEC:
        case EN_EXE_GOTO_PICTURE_BACKLIGHT_ADJUST_INC:
            // U8 u8ValueTmp = stGenSetting.g_SysSetting.u8Backlight;

		//XM CUS ZHIQIN
		#if 1
            if( ST_VIDEO.ePicture != PICTURE_USER)
            {
                ST_VIDEO.astPicture[PICTURE_USER].u8Backlight = ST_PICTURE.u8Backlight;
                ST_VIDEO.astPicture[PICTURE_USER].u8Contrast = ST_PICTURE.u8Contrast;
                ST_VIDEO.astPicture[PICTURE_USER].u8Brightness = ST_PICTURE.u8Brightness;
                ST_VIDEO.astPicture[PICTURE_USER].u8Saturation = ST_PICTURE.u8Saturation;
                ST_VIDEO.astPicture[PICTURE_USER].u8Sharpness = ST_PICTURE.u8Sharpness;
                ST_VIDEO.astPicture[PICTURE_USER].u8Hue = ST_PICTURE.u8Hue;
                ST_VIDEO.astPicture[PICTURE_USER].eColorTemp = ST_PICTURE.eColorTemp;
               #if (ENABLE_CUS_NR_MODE_FOLLOW_PICMODE == ENABLE)
                ST_VIDEO.astPicture[PICTURE_USER].eNRMode.eNR = ST_PICTURE.eNRMode.eNR;
               #endif
               #if ENABLE_FLESH_TONE
                ST_VIDEO.astPicture[PICTURE_USER].eFleshToneMode = ST_PICTURE.eFleshToneMode;
               #endif
               #if 0//ENABLE_CUS_DBC
                ST_VIDEO.astPicture[PICTURE_USER].bDBCStatus =ST_PICTURE.bDBCStatus;
               #endif
               #if ENABLE_CUS_DLC
                ST_VIDEO.astPicture[PICTURE_USER].bDLCStatus =ST_PICTURE.bDLCStatus;
               #endif
                ST_VIDEO.ePicture = PICTURE_USER;
            }
        #endif
        #if 1
            ST_PICTURE.u8Backlight= MApp_ZUI_ACT_DecIncValue(act==EN_EXE_GOTO_PICTURE_BACKLIGHT_ADJUST_INC,
               ST_PICTURE.u8Backlight, 0, 100, 1);
            Panel_Backlight_PWM_ADJ(msAPI_Mode_PictureBackLightN100toReallyValue(ST_PICTURE.u8Backlight));
        #else
            ST_PICTURE.u8Backlight= MApp_ZUI_ACT_DecIncValue(act==EN_EXE_GOTO_PICTURE_BACKLIGHT_ADJUST_INC,
               ST_PICTURE.u8Backlight, 0, 255, 1);
            Panel_Backlight_PWM_ADJ(ST_PICTURE.u8Backlight);
        #endif

            if (MApp_ZUI_API_GetFocus() == HWND_MENU_PICTURE_ADJUST_BAR)
            {
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_PICTURE_ADJUST_BAR);
            }
#if (ENABLE_CUS_UI_SPEC == DISABLE) /*Creass.liu at 2012-06-02*/
            else
            {
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_PICTURE_BACKLIGHT_ADJUST);
            }
#endif
            return TRUE;

        case EN_EXE_DEC_BASS:
        case EN_EXE_INC_BASS:
            {
                U8 u8ValueTmp = stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].Bass;
		//XM CUS ZHIQIN
            if(stGenSetting.g_SoundSetting.SoundMode != SOUND_MODE_USER)
            {
                stGenSetting.g_SoundSetting.astSoundModeSetting[SOUND_MODE_USER] =
                    stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode];
                stGenSetting.g_SoundSetting.SoundMode = SOUND_MODE_USER;
            }

                stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].Bass =
                    MApp_ZUI_ACT_DecIncValue(
                        act==EN_EXE_INC_BASS,
                        stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].Bass, 0, 100, 1);

                if(stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].Bass == u8ValueTmp)
                {
                    //bRet = FALSE;
                }
                else
                {
                    MApi_AUDIO_EnableEQ(FALSE);
                    MApi_AUDIO_EnableTone(TRUE);

		#ifdef CUS_AUDIO_TREBLE_BASS_LIMIT
     			MApi_AUDIO_SetBassLimit(stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].Bass);
		#else
                    MApi_AUDIO_SetBass(stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].Bass);
		#endif
                }

            }
/*
            if(stGenSetting.g_SoundSetting.SoundMode != SOUND_MODE_USER)
            {
                stGenSetting.g_SoundSetting.astSoundModeSetting[SOUND_MODE_USER] =
                    stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode];
                stGenSetting.g_SoundSetting.SoundMode = SOUND_MODE_USER;
            }
*/
            if (MApp_ZUI_API_GetFocus() == HWND_MENU_PICTURE_ADJUST_BAR)
            {
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_PICTURE_ADJUST_BAR);
            }
            else
            {
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_SNDMODE_BASS);
            }
            return TRUE;

        case EN_EXE_DEC_BALANCE:
        case EN_EXE_INC_BALANCE:
            {
                U8 u8ValueTmp = stGenSetting.g_SoundSetting.Balance;
				printf("xue trace BALANCE value %d/n/r",u8ValueTmp );
                stGenSetting.g_SoundSetting.Balance = MApp_ZUI_ACT_DecIncValue(
                    act==EN_EXE_INC_BALANCE,
                    stGenSetting.g_SoundSetting.Balance, 0, 100, 1);

                if (stGenSetting.g_SoundSetting.Balance == u8ValueTmp)
                {
                    //bRet = FALSE;
                }
                else
                {
                    MApi_AUDIO_SetBalance(stGenSetting.g_SoundSetting.Balance);
                    //bRet = TRUE;
                }

                #if (ENABLE_CUS_UI_SPEC == FALSE)
                   if(msAPI_AUD_IsAudioMutedByUser()==1)
                        MApp_UiMenu_MuteWin_Hide();
                // Force to disable mute no matter what the current mute state is
                msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_BYUSER_MUTEOFF, E_AUDIOMUTESOURCE_ACTIVESOURCE);
                #endif

            }

            if (MApp_ZUI_API_GetFocus() == HWND_MENU_PICTURE_ADJUST_BAR)
            {
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_PICTURE_ADJUST_BAR);
            }
            #if (ENABLE_CUS_UI_SPEC == DISABLE)/*Creass.liu at 2012-06-27*/
            else
            {
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_OPTIONLIST_ITEM2_OPTION);
            }
            #endif
            return TRUE;



#if (ENABLE_CUS_UI_SPEC == FALSE) /*Creass.liu at 2012-06-27*/
        case EN_EXE_DEC_AUDIO_DELAY:
        case EN_EXE_INC_AUDIO_DELAY:
            #if ENABLE_CUS_AUDIO_DELAY
            stGenSetting.g_SoundSetting.LipSyncDelayTime =
                MApp_ZUI_ACT_DecIncValue(act==EN_EXE_INC_AUDIO_DELAY,stGenSetting.g_SoundSetting.LipSyncDelayTime, 0, 250, 10);
            MApp_Aud_SetBufferProcess(stGenSetting.g_SoundSetting.LipSyncDelayTime);
            MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_PICTURE_ADJUST_BAR);
            #endif
            break;
        case EN_EXE_DEC_SOUND_120_HZ:
        case EN_EXE_INC_SOUND_120_HZ:
            {
                //U8 u8ValueTmp = stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].u8120HZ;
                stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].u8120HZ =
                    MApp_ZUI_ACT_DecIncValue(
                        act==EN_EXE_INC_SOUND_120_HZ,
                        stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].u8120HZ, 0, 100, 1);
                MApi_AUDIO_EnableEQ(TRUE);
                MApi_AUDIO_SetEq(E_EQUALIZER_BAND_1, stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].u8120HZ);
            }
            if(stGenSetting.g_SoundSetting.SoundMode != SOUND_MODE_USER)
            {
                stGenSetting.g_SoundSetting.astSoundModeSetting[SOUND_MODE_USER] =
                    stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode];
                stGenSetting.g_SoundSetting.SoundMode = SOUND_MODE_USER;
            }
            MApp_ZUI_API_InvalidateWindow(HWND_MENU_SNDEQ_120_HZ);
            return TRUE;

       /*
        case EN_EXE_DEC_SOUND_200_HZ:
        case EN_EXE_INC_SOUND_200_HZ:
            {
                //U8 u8ValueTmp = stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].u8200HZ;
                stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].u8200HZ =
                    MApp_ZUI_ACT_DecIncValue(
                        act==EN_EXE_INC_SOUND_200_HZ,
                        stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].u8200HZ, 0, 100, 1);
                MApi_AUDIO_EnableEQ(TRUE);
                MApi_AUDIO_SetEq(E_EQUALIZER_BAND_2, stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].u8200HZ);
            }
            MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_SNDEQ_200_HZ);
            return TRUE;
          */
        case EN_EXE_DEC_SOUND_500_HZ:
        case EN_EXE_INC_SOUND_500_HZ:
            {
                //U8 u8ValueTmp = stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].u8500HZ;
                stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].u8500HZ =
                    MApp_ZUI_ACT_DecIncValue(
                        act==EN_EXE_INC_SOUND_500_HZ,
                        stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].u8500HZ, 0, 100, 1);
                MApi_AUDIO_EnableEQ(TRUE);
                MApi_AUDIO_SetEq(E_EQUALIZER_BAND_2, stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].u8500HZ);
            }
            if(stGenSetting.g_SoundSetting.SoundMode != SOUND_MODE_USER)
            {
                stGenSetting.g_SoundSetting.astSoundModeSetting[SOUND_MODE_USER] =
                    stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode];
                stGenSetting.g_SoundSetting.SoundMode = SOUND_MODE_USER;
            }
            MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_SNDEQ_500_HZ);
            return TRUE;

        case EN_EXE_DEC_SOUND_1_2_KHZ:
        case EN_EXE_INC_SOUND_1_2_KHZ:
            {
                //U8 u8ValueTmp = stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].u8_1_dot_5_KHZ;
                stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].u8_1_dot_5_KHZ =
                    MApp_ZUI_ACT_DecIncValue(
                        act==EN_EXE_INC_SOUND_1_2_KHZ, stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].u8_1_dot_5_KHZ, 0, 100, 1);
                MApi_AUDIO_EnableEQ(TRUE);
                MApi_AUDIO_SetEq(E_EQUALIZER_BAND_3, stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].u8_1_dot_5_KHZ);
            }
            if(stGenSetting.g_SoundSetting.SoundMode != SOUND_MODE_USER)
            {
                stGenSetting.g_SoundSetting.astSoundModeSetting[SOUND_MODE_USER] =
                    stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode];
                stGenSetting.g_SoundSetting.SoundMode = SOUND_MODE_USER;
            }
            MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_SNDEQ_1_2_KHZ);
            return TRUE;
        /*
        case EN_EXE_DEC_SOUND_3_KHZ:
        case EN_EXE_INC_SOUND_3_KHZ:
            {
                //U8 u8ValueTmp = stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].u8_3KHZ;
                stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].u8_3KHZ =
                    MApp_ZUI_ACT_DecIncValue(
                        act==EN_EXE_INC_SOUND_3_KHZ,
                        stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].u8_3KHZ, 0, 100, 1);
                MApi_AUDIO_EnableEQ(TRUE);
                MApi_AUDIO_SetEq(E_EQUALIZER_BAND_5, stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].u8_3KHZ);
            }
            MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_SNDEQ_3_KHZ);
            return TRUE;
        */
        case EN_EXE_DEC_SOUND_7_5_KHZ:
        case EN_EXE_INC_SOUND_7_5_KHZ:
            {
                //U8 u8ValueTmp = stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].u8_5KHZ;
                stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].u8_5KHZ =
                    MApp_ZUI_ACT_DecIncValue(
                        act==EN_EXE_INC_SOUND_7_5_KHZ,
                        stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].u8_5KHZ, 0, 100, 1);
                // equalizer
                MApi_AUDIO_EnableEQ(TRUE);
                MApi_AUDIO_SetEq(E_EQUALIZER_BAND_4, stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].u8_5KHZ);
            }
            if(stGenSetting.g_SoundSetting.SoundMode != SOUND_MODE_USER)
            {
                stGenSetting.g_SoundSetting.astSoundModeSetting[SOUND_MODE_USER] =
                    stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode];
                stGenSetting.g_SoundSetting.SoundMode = SOUND_MODE_USER;
            }
            MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_SNDEQ_7_5_KHZ);
            return TRUE;

        case EN_EXE_DEC_SOUND_12_KHZ:
        case EN_EXE_INC_SOUND_12_KHZ:
            {
                  //U8 u8ValueTmp = stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].u810KHZ;
                stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].u810KHZ =
                    MApp_ZUI_ACT_DecIncValue(
                        act==EN_EXE_INC_SOUND_12_KHZ,
                        stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].u810KHZ, 0, 100, 1);
                // equalizer
                MApi_AUDIO_EnableEQ(TRUE);
                MApi_AUDIO_SetEq(E_EQUALIZER_BAND_5, stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].u810KHZ);
            }
            if(stGenSetting.g_SoundSetting.SoundMode != SOUND_MODE_USER)
            {
                stGenSetting.g_SoundSetting.astSoundModeSetting[SOUND_MODE_USER] =
                    stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode];
                stGenSetting.g_SoundSetting.SoundMode = SOUND_MODE_USER;
            }
            MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_SNDEQ_12_KHZ);
            return TRUE;
#endif
        case EN_EXE_GOTO_SET_PASSWORD_DLG:
            //ZUI_TODO: not yet
            return TRUE;

#if (ENABLE_CUS_AUTO_SLEEP_MODE == DISABLE)
        case EN_EXE_ONOFF_AUTO_SLEEP:
            stGenSetting.g_Time.cAutoSleepFlag=(EN_MENU_TIME_AutoOff)!stGenSetting.g_Time.cAutoSleepFlag;
            MApp_NoSignal_SetAutoSleep((BOOLEAN)stGenSetting.g_Time.cAutoSleepFlag);
            MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_OP_TIME_SUBPAGE_AUTO_SLEEP);

            return TRUE;
#else
         case EN_EXE_DEC_AUTO_SLEEP:
         case EN_EXE_INC_AUTO_SLEEP:
            stGenSetting.g_Time.cAutoSleepFlag = (EN_MENU_TIME_AutoOff)MApp_ZUI_ACT_DecIncValue_Cycle(
                    (act==EN_EXE_INC_AUTO_SLEEP),
                    stGenSetting.g_Time.cAutoSleepFlag,
                    EN_Time_AutoOff_Off, EN_Time_AutoOff_Num-1, 1);

            if (stGenSetting.g_Time.cAutoSleepFlag == EN_Time_AutoOff_Off)
            {
                MApp_Sleep_SetAutoOn_OffTime(DISABLE);
            }
            else
            {
                MApp_Sleep_SetAutoOn_OffTime(ENABLE);
            }
            MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_OP_TIME_SUBPAGE_AUTO_SLEEP);
            return TRUE;
#endif
        case EN_EXE_DEC_SLEEP_TIMER:
        case EN_EXE_INC_SLEEP_TIMER:
            _MApp_ZUI_ACT_DecIncSleepTimer_Cycle(act==EN_EXE_INC_SLEEP_TIMER);
            if (MApp_ZUI_API_GetFocus() == HWND_MENU_OP_TIME_SUBPAGE_SLEEP_TIME)
            {
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_OP_TIME_SUBPAGE_SLEEP_TIME);
            }
#if (ENABLE_CUS_UI_SPEC == DISABLE)/*Creass.liu at 2012-06-27*/
            else
            {
                MApp_ZUI_API_InvalidateWindow(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST);
            }
#endif
            return TRUE;

#if ENABLE_T_C_COMBO
        case EN_EXE_DVB_TYPE_SELECT:
            _MApp_ZUI_ACT_DecIncDVBType_Cycle();
            return TRUE;
#endif


#if (ENABLE_CUS_UI_SPEC == FALSE) /*Creass.liu at 2012-06-27*/
        case EN_EXE_DEC_TIMEZONE:
        case EN_EXE_INC_TIMEZONE:
#if ENABLE_SBTVD_BRAZIL_APP

            stGenSetting.g_Time.enTimeZone = (EN_MENU_TIMEZONE)MApp_ZUI_ACT_DecIncValue_Cycle(
                act==EN_EXE_INC_TIMEZONE,
                stGenSetting.g_Time.enTimeZone, TIMEZONE_GMT_Minus5_START, TIMEZONE_GMT_Minus2_END, 1);

            if(MENU_TIMEZONE<=TIMEZONE_GMT_Minus5_END)
            {
                stGenSetting.g_Time.en_Clock_TimeZone=EN_Clock_TimeZone_20;
            }
            else if(MENU_TIMEZONE>=TIMEZONE_GMT_Minus4_START && MENU_TIMEZONE<=TIMEZONE_GMT_Minus4_END)
            {
                stGenSetting.g_Time.en_Clock_TimeZone=EN_Clock_TimeZone_22;
            }
            else if(MENU_TIMEZONE>=TIMEZONE_GMT_Minus3_START && MENU_TIMEZONE<=TIMEZONE_GMT_Minus3_END)
            {
                stGenSetting.g_Time.en_Clock_TimeZone=EN_Clock_TimeZone_24;
            }
            else if(MENU_TIMEZONE>=TIMEZONE_GMT_Minus2_START && MENU_TIMEZONE<=TIMEZONE_GMT_Minus2_END)
            {
                stGenSetting.g_Time.en_Clock_TimeZone=EN_Clock_TimeZone_26;
            }
            else
            {
                stGenSetting.g_Time.en_Clock_TimeZone=EN_Clock_TimeZone_24;
            }
#else
            stGenSetting.g_Time.enTimeZone = (EN_MENU_TIMEZONE)MApp_ZUI_ACT_DecIncValue_Cycle(
                act==EN_EXE_INC_TIMEZONE,
                stGenSetting.g_Time.enTimeZone, TIMEZONE_GMT_0_START, TIMEZONE_NUM-1, 1);

            if((MENU_TIMEZONE<=TIMEZONE_GMT_0_END))
            {
                stGenSetting.g_Time.en_Clock_TimeZone=EN_Clock_TimeZone_24;
            }
            else if(MENU_TIMEZONE>=TIMEZONE_GMT_1_START && MENU_TIMEZONE<=TIMEZONE_GMT_1_END)
            {
                stGenSetting.g_Time.en_Clock_TimeZone=EN_Clock_TimeZone_26;
            }
            else if(MENU_TIMEZONE>=TIMEZONE_GMT_2_START && MENU_TIMEZONE<=TIMEZONE_GMT_2_END)
            {
                stGenSetting.g_Time.en_Clock_TimeZone=EN_Clock_TimeZone_28;
            }
            else if(MENU_TIMEZONE>=TIMEZONE_GMT_3_START && MENU_TIMEZONE<=TIMEZONE_GMT_3_END)
            {
                stGenSetting.g_Time.en_Clock_TimeZone=EN_Clock_TimeZone_30;
            }
            else if(MENU_TIMEZONE>=TIMEZONE_GMT_8_START && MENU_TIMEZONE<=TIMEZONE_GMT_8_END)
            {
                stGenSetting.g_Time.en_Clock_TimeZone=EN_Clock_TimeZone_40;
            }
            else if(MENU_TIMEZONE>=TIMEZONE_GMT_9Point5_START && MENU_TIMEZONE<=TIMEZONE_GMT_9Point5_END)
            {
                stGenSetting.g_Time.en_Clock_TimeZone=EN_Clock_TimeZone_43;
            }
            else if(MENU_TIMEZONE>=TIMEZONE_GMT_10_START && MENU_TIMEZONE<=TIMEZONE_GMT_10_END)
            {
                stGenSetting.g_Time.en_Clock_TimeZone=EN_Clock_TimeZone_44;
            }
            else if(MENU_TIMEZONE>=TIMEZONE_GMT_12_START && MENU_TIMEZONE<=TIMEZONE_GMT_12_END)
            {
                stGenSetting.g_Time.en_Clock_TimeZone=EN_Clock_TimeZone_48;
            }

#endif
#if ENABLE_DTV
            MApp_SI_SetTimeZone(MApp_GetSITimeZone(stGenSetting.g_Time.enTimeZone));
            MApp_SI_SetClockTimeZone(MApp_GetSIClockTimeZone(stGenSetting.g_Time.en_Clock_TimeZone));
            MApp_SI_Update_Time(MApp_GetAutoSystemTimeFlag());
#endif
            MApp_Time_SetOnTime();

            MApp_ZUI_API_InvalidateWindow(HWND_MENU_TIME_SET_TIMEZONE_OPTION);
            MApp_ZUI_API_InvalidateWindow(HWND_MENU_TIME_SET_CLOCK);
            return TRUE;
#endif

        case EN_EXE_DEC_PARENTAL_GUIDANCE:
        case EN_EXE_INC_PARENTAL_GUIDANCE:
#if ENABLE_SBTVD_BRAZIL_APP
            stGenSetting.g_BlockSysSetting.u8ParentalControl=
               (U8) MApp_ZUI_ACT_DecIncValue_Cycle(
                    act==EN_EXE_INC_PARENTAL_GUIDANCE,
                    stGenSetting.g_BlockSysSetting.u8ParentalControl,EN_F4_LockSystem_Min, EN_F4_LockSystem_Max, 2);
#else
            stGenSetting.g_BlockSysSetting.u8ParentalControl=
               (U8) MApp_ZUI_ACT_DecIncValue_Cycle(
                    act==EN_EXE_INC_PARENTAL_GUIDANCE,
                    stGenSetting.g_BlockSysSetting.u8ParentalControl,EN_F4_LockSystem_Min, EN_F4_LockSystem_Max, 1);
#endif
#if 0//fix compiling error  //Roger.li###
            MApp_ZUI_API_InvalidateWindow(HWND_MENU_LOCK_PARENTAL_GUIDANCE_OPTION);
#endif
            return TRUE;

#if ENABLE_SBTVD_BRAZIL_APP
        case EN_EXE_DEC_OPTION_CAPTION:
        case EN_EXE_INC_OPTION_CAPTION:

            if(IsDTVInUse())
            {
                stGenSetting.g_SysSetting.enDTVCaptionType=
                (EN_DTV_CAPTION_TYPE) MApp_ZUI_ACT_DecIncValue_Cycle(
                    act==EN_EXE_INC_OPTION_CAPTION,
                    stGenSetting.g_SysSetting.enDTVCaptionType, DTV_CAPTION_OFF, DTV_CAPTION_ON, 1);
            }
            else if (IsATVInUse() || IsAVInUse() )
            {
                stGenSetting.g_SysSetting.enATVCaptionType=
                (EN_ATV_CAPTION_TYPE) MApp_ZUI_ACT_DecIncValue_Cycle(
                    act==EN_EXE_INC_OPTION_CAPTION,
                    stGenSetting.g_SysSetting.enATVCaptionType, ATV_CAPTION_TYPE_OFF, ATV_CAPTION_TYPE_NUM-1, 1);
            }
            MApp_ZUI_API_InvalidateWindow(HWND_MENU_OPTION_CAPTION_OPTION);
            return TRUE;
#endif
        case EN_EXE_CLOSE_PCMODE_PAGE:
        #if (ENABLE_CUS_UI_SPEC == DISABLE)
            MApp_ZUI_API_ShowWindow(HWND_MENU_PCMODE_PAGE, SW_HIDE);
        #endif
            MApp_ZUI_API_ShowWindow(HWND_MENU_PICTURE_PAGE, SW_SHOW);
            return FALSE; //note: don't eat this action and navigate...
        #if (ENABLE_PIP)
         case EN_EXE_CLOSE_PIP_PAGE:
            if(IsPIPSupported())
            {
                MApp_ZUI_API_ShowWindow(HWND_MENU_PIP_PAGE, SW_HIDE);
                MApp_ZUI_API_ShowWindow(HWND_MENU_PICTURE_PAGE, SW_SHOW);
            }
            return FALSE; //note: don't eat this action and navigate...
        #endif

         case EN_EXE_PCMODE_AUTO_ADJ:
            //from void MAPP_UiMenu_AutoConfig(void)
            {
               // U8 u8ModeIndex;
                if((MApp_IsSrcHasSignal(MAIN_WINDOW)) == FALSE)
                {
                    return TRUE;
                }
                if(IsVgaInUse())
                {
                    if(IsSrcTypeVga(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)))
                    {
                        if(MApp_PCMode_Enable_SelfAuto(ENABLE, MAIN_WINDOW))
                        {   // to do Auto adjust
                            MApp_ZUI_ACT_StartupOSD(E_OSD_MESSAGE_BOX);
                            MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_SHOW_AUTO_ADJUSTING_MSGBOX);
                            //MApp_PCMode_RunSelfAuto(MAIN_WINDOW);
                        }
                    }
                    else
                    {
                        if(MApp_PCMode_Enable_SelfAuto(ENABLE, SUB_WINDOW))
                        {   // to do Auto adjust
                            MApp_PCMode_RunSelfAuto(SUB_WINDOW);
                        }
                    }
                }

                //note: all values will be changed!
                //MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_PCMODE_PAGE_LIST);
            }
            return TRUE;

        case EN_EXE_DEC_PCMODE_HPOS:                     ///< decrease pcmode h-pos
        case EN_EXE_INC_PCMODE_HPOS:                     ///< increase pcmode h-pos
            if(IsSrcTypeVga(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW))||IsSrcTypeYPbPr(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)))
            {
                U16 u16ValueTmp = g_PcadcModeSetting[MAIN_WINDOW].u16HorizontalStart;
                U16 u16step;
                u16step = (MAX_PC_H_START(MAIN_WINDOW)- MIN_PC_H_START(MAIN_WINDOW));
                if(u16step >100)
                {
                    u16step = u16step /100;
                }
                else
                {
                    u16step = 1;
                }
                g_PcadcModeSetting[MAIN_WINDOW].u16HorizontalStart =
                    MApp_ZUI_ACT_DecIncValue(
                        act==EN_EXE_INC_PCMODE_HPOS,
                        g_PcadcModeSetting[MAIN_WINDOW].u16HorizontalStart, MIN_PC_H_START(MAIN_WINDOW), MAX_PC_H_START(MAIN_WINDOW), (U8)u16step);

                if( IsSrcTypeYPbPr(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)) )
                    MApi_XC_Set_Ypbpr_HPosition(u16ValueTmp, g_PcadcModeSetting[MAIN_WINDOW].u16HorizontalStart, MAIN_WINDOW);
                else
                    MApi_XC_Set_PC_HPosition((g_PcadcModeSetting[MAIN_WINDOW].u16DefaultHStart* 2 -g_PcadcModeSetting[MAIN_WINDOW].u16HorizontalStart), MAIN_WINDOW);

                MApp_SetSaveModeDataFlag();
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_PICTURE_ADJUST_BAR);

                //MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_PCMODE_HPOS);

            }
            #if (ENABLE_PIP)
            else if(IsPIPEnable() && (IsSrcTypeVga(SYS_INPUT_SOURCE_TYPE(SUB_WINDOW))||IsSrcTypeYPbPr(SYS_INPUT_SOURCE_TYPE(SUB_WINDOW)))/*IsVgaInUse() || IsYPbPrInUse()*/)
            {
                U16 u16ValueTmp = g_PcadcModeSetting[SUB_WINDOW].u16HorizontalStart;
                g_PcadcModeSetting[SUB_WINDOW].u16HorizontalStart =
                    MApp_ZUI_ACT_DecIncValue(
                        act==EN_EXE_INC_PCMODE_HPOS,
                        g_PcadcModeSetting[SUB_WINDOW].u16HorizontalStart, MIN_PC_H_START(SUB_WINDOW), MAX_PC_H_START(SUB_WINDOW), 1);

                if( IsSrcTypeYPbPr(SYS_INPUT_SOURCE_TYPE(SUB_WINDOW)) )
                    MApi_XC_Set_Ypbpr_HPosition(u16ValueTmp, g_PcadcModeSetting[SUB_WINDOW].u16HorizontalStart, SUB_WINDOW);
                else
                    MApi_XC_Set_PC_HPosition(g_PcadcModeSetting[SUB_WINDOW].u16HorizontalStart, SUB_WINDOW);

                MApp_SetSaveModeDataFlag();

                //MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_PCMODE_HPOS);

            }
            #endif
            return TRUE;

        case EN_EXE_DEC_PCMODE_VPOS:                     ///< decrease pcmode V-pos
        case EN_EXE_INC_PCMODE_VPOS:                     ///< increase pcmode V-pos
            if(IsSrcTypeVga(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW))||IsSrcTypeYPbPr(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)))
            {

                U16 u16ValueTmp = g_PcadcModeSetting[MAIN_WINDOW].u16VerticalStart;
                U16 u16step;
                u16step = (MAX_PC_V_START(MAIN_WINDOW)- MIN_PC_V_START);
                if(u16step >100)
                {
                    u16step = u16step /100;
                }
                else
                {
                    u16step = 1;
                }
                g_PcadcModeSetting[MAIN_WINDOW].u16VerticalStart =
                    MApp_ZUI_ACT_DecIncValue(
                        act==EN_EXE_INC_PCMODE_VPOS,
                        g_PcadcModeSetting[MAIN_WINDOW].u16VerticalStart, MIN_PC_V_START, MAX_PC_V_START(MAIN_WINDOW), (U8)u16step);

                if(IsSrcTypeYPbPr(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)))
                    MApi_XC_Set_Ypbpr_VPosition(u16ValueTmp, g_PcadcModeSetting[MAIN_WINDOW].u16VerticalStart, MAIN_WINDOW);
                else
                    MApi_XC_Set_PC_VPosition(g_PcadcModeSetting[MAIN_WINDOW].u16VerticalStart,MAIN_WINDOW);

                MApp_SetSaveModeDataFlag();
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_PICTURE_ADJUST_BAR);

                //MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_PCMODE_VPOS);

            }
            #if (ENABLE_PIP)
            else if(IsPIPEnable()&&(IsSrcTypeVga(SYS_INPUT_SOURCE_TYPE(SUB_WINDOW))||IsSrcTypeYPbPr(SYS_INPUT_SOURCE_TYPE(SUB_WINDOW))))
            {

                U16 u16ValueTmp = g_PcadcModeSetting[SUB_WINDOW].u16VerticalStart;
                g_PcadcModeSetting[SUB_WINDOW].u16VerticalStart =
                    MApp_ZUI_ACT_DecIncValue(
                        act==EN_EXE_INC_PCMODE_VPOS,
                        g_PcadcModeSetting[SUB_WINDOW].u16VerticalStart, MIN_PC_V_START, MAX_PC_V_START(SUB_WINDOW), 1);

                if(IsSrcTypeYPbPr(SYS_INPUT_SOURCE_TYPE(SUB_WINDOW)))
                    MApi_XC_Set_Ypbpr_VPosition(u16ValueTmp, g_PcadcModeSetting[SUB_WINDOW].u16VerticalStart, SUB_WINDOW);
                else
                    MApi_XC_Set_PC_VPosition(g_PcadcModeSetting[SUB_WINDOW].u16VerticalStart,SUB_WINDOW);

                MApp_SetSaveModeDataFlag();

                //MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_PCMODE_VPOS);

            }
            #endif
            return TRUE;

        case EN_EXE_DEC_PCMODE_SIZE:                     ///< decrease pcmode size
        case EN_EXE_INC_PCMODE_SIZE:                     ///< increase pcmode size
            if(IsSrcTypeVga(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)))
            {
                U16 u16ValueTmp = g_PcadcModeSetting[MAIN_WINDOW].u16HorizontalTotal;
                U16 u16step;
                u16step = (MAX_PC_CLOCK(MAIN_WINDOW) - MIN_PC_CLOCK(MAIN_WINDOW));
                if(u16step >100)
                {
                    u16step = u16step /100;
                }
                else
                {
                    u16step = 1;
                }
                if(IsSrcTypeVga(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)))
                {
                    g_PcadcModeSetting[MAIN_WINDOW].u16HorizontalTotal =
                        MApp_ZUI_ACT_DecIncValue(
                            act==EN_EXE_INC_PCMODE_SIZE,
                            g_PcadcModeSetting[MAIN_WINDOW].u16HorizontalTotal, MIN_PC_CLOCK(MAIN_WINDOW), MAX_PC_CLOCK(MAIN_WINDOW), (U8)u16step);
                    stLMGenSetting.stMB.u16B7_PCMenu_Size = g_PcadcModeSetting[MAIN_WINDOW].u16HorizontalTotal;
                }

                if(g_PcadcModeSetting[MAIN_WINDOW].u16HorizontalTotal == u16ValueTmp)
                {
                    //bRet = FALSE;
                }
                else
                {
                    MApi_XC_ADC_SetPcClock(stLMGenSetting.stMB.u16B7_PCMenu_Size);
                }

                MApp_SetSaveModeDataFlag();
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_PICTURE_ADJUST_BAR);

                //MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_PCMODE_SIZE);

            }
            #if (ENABLE_PIP)
            else if(IsPIPEnable()&&(IsSrcTypeVga(SYS_INPUT_SOURCE_TYPE(SUB_WINDOW))))
            {
                U16 u16ValueTmp = g_PcadcModeSetting[SUB_WINDOW].u16HorizontalTotal;
                if(IsSrcTypeVga(SYS_INPUT_SOURCE_TYPE(SUB_WINDOW)))
                {
                    g_PcadcModeSetting[SUB_WINDOW].u16HorizontalTotal =
                        MApp_ZUI_ACT_DecIncValue(
                            act==EN_EXE_INC_PCMODE_SIZE,
                            g_PcadcModeSetting[SUB_WINDOW].u16HorizontalTotal, MIN_PC_CLOCK(SUB_WINDOW), MAX_PC_CLOCK(SUB_WINDOW), 1);
                    stLMGenSetting.stMB.u16B7_PCMenu_Size = g_PcadcModeSetting[SUB_WINDOW].u16HorizontalTotal;
                }

                if(g_PcadcModeSetting[SUB_WINDOW].u16HorizontalTotal == u16ValueTmp)
                {
                    //bRet = FALSE;
                }
                else
                {
                    MApi_XC_ADC_SetPcClock(stLMGenSetting.stMB.u16B7_PCMenu_Size);
                }

                MApp_SetSaveModeDataFlag();

                //MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_PCMODE_SIZE);

            }
            #endif
            return TRUE;

        case EN_EXE_DEC_PCMODE_PHASE:                     ///< decrease pcmode phase
        case EN_EXE_INC_PCMODE_PHASE:                     ///< increase pcmode phase
            if(IsSrcTypeVga(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)))
            {
                U16 u16ValueTmp = g_PcadcModeSetting[MAIN_WINDOW].u16Phase;
                U16 u16step;
                u16step = (MAX_PC_PHASE - MIN_PC_PHASE);
                if(u16step >100)
                {
                    u16step = u16step /100;
                }
                else
                {
                    u16step = 1;
                }

                g_PcadcModeSetting[MAIN_WINDOW].u16Phase = MApp_ZUI_ACT_DecIncValue(
                    act==EN_EXE_INC_PCMODE_PHASE,
                    g_PcadcModeSetting[MAIN_WINDOW].u16Phase, MIN_PC_PHASE, MAX_PC_PHASE, (U8)u16step);
                stLMGenSetting.stMB.u16B7_PCMenu_Phase = g_PcadcModeSetting[MAIN_WINDOW].u16Phase;
                if(g_PcadcModeSetting[MAIN_WINDOW].u16Phase == u16ValueTmp)
                {
                    //bRet = FALSE;
                }
                else
                {
                    MApi_XC_ADC_SetPhaseEx(stLMGenSetting.stMB.u16B7_PCMenu_Phase);
                }
                MApp_SetSaveModeDataFlag();
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_PICTURE_ADJUST_BAR);

                //MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_PCMODE_PHASE);

            }
            #if (ENABLE_PIP)
            else if(IsPIPEnable()&&(IsSrcTypeVga(SYS_INPUT_SOURCE_TYPE(SUB_WINDOW))))
            {
                U16 u16ValueTmp = g_PcadcModeSetting[SUB_WINDOW].u16Phase;
                g_PcadcModeSetting[SUB_WINDOW].u16Phase = MApp_ZUI_ACT_DecIncValue(
                    act==EN_EXE_INC_PCMODE_PHASE,
                    g_PcadcModeSetting[SUB_WINDOW].u16Phase, MIN_PC_PHASE, MAX_PC_PHASE, 1);
                stLMGenSetting.stMB.u16B7_PCMenu_Phase = g_PcadcModeSetting[SUB_WINDOW].u16Phase;
                if(g_PcadcModeSetting[SUB_WINDOW].u16Phase == u16ValueTmp)
                {
                    //bRet = FALSE;
                }
                else
                {
                    MApi_XC_ADC_SetPhase(stLMGenSetting.stMB.u16B7_PCMenu_Phase);
                }
                MApp_SetSaveModeDataFlag();

                //MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_PCMODE_PHASE);

            }
            #endif
            return TRUE;

#if (ENABLE_CUS_UI_SPEC == FALSE) /*Creass.liu at 2012-06-27*/
        #if (ENABLE_PIP)
        case EN_EXE_DEC_PIP_SOUND_SRC:
        case EN_EXE_INC_PIP_SOUND_SRC:
            if(IsPIPSupported())
            {
                    stGenSetting.g_stPipSetting.enPipSoundSrc=
                (EN_PIP_SOUND_SRC) MApp_ZUI_ACT_DecIncValue_Cycle(
                    act==EN_EXE_INC_PIP_SOUND_SRC,
                    stGenSetting.g_stPipSetting.enPipSoundSrc, EN_PIP_SOUND_SRC_MAIN, EN_PIP_SOUND_SRC_SUB, 1);

                if(stGenSetting.g_stPipSetting.enPipSoundSrc==EN_PIP_SOUND_SRC_MAIN)
                {
                    MApp_InputSource_PIP_ChangeAudioSource(MAIN_WINDOW);
                }
                else if(stGenSetting.g_stPipSetting.enPipSoundSrc==EN_PIP_SOUND_SRC_SUB)
                {
                    MApp_InputSource_PIP_ChangeAudioSource(SUB_WINDOW);
                }
                MApp_ZUI_API_InvalidateWindow(HWND_MENU_PIP_SOUND_SRC_OPTION);
                return TRUE;
            }
            return FALSE;

        case EN_EXE_DEC_PIP_BORDER:
        case EN_EXE_INC_PIP_BORDER:
            if(IsPIPSupported())
            {
                stGenSetting.g_stPipSetting.bBolderEnable = !stGenSetting.g_stPipSetting.bBolderEnable;
                MApi_XC_EnableBorder(stGenSetting.g_stPipSetting.bBolderEnable, SUB_WINDOW);
                MApp_ZUI_API_InvalidateWindow(HWND_MENU_PIP_BORDER_OPTION);
                return TRUE;
            }
            return FALSE;

        case EN_EXE_DEC_PIPMODE:
        case EN_EXE_INC_PIPMODE:
            if(IsPIPSupported())
            {
                EN_PIP_MODE enPreMode = stGenSetting.g_stPipSetting.enPipMode;
                stGenSetting.g_stPipSetting.enPipMode=
                (EN_PIP_MODE) MApp_ZUI_ACT_DecIncValue_Cycle(
                    act==EN_EXE_INC_PIPMODE,
                    stGenSetting.g_stPipSetting.enPipMode, EN_PIP_MODE_PIP, EN_PIP_MODE_OFF, 1);

                //PIP Limitations: TTX, TTX Subtitle, Closed Caption, MHEG5, MWE should be disabled here.
                //                 EPG should be closed in MApp_ZUI_ACTepg.c
                if(IsPIPEnable())
                {
                    //Close TTX, TTX Subtitle
                    #if (ENABLE_TTX)
                    if(MApp_TTX_IsTeletextOn())
                    {
                        MApp_TTX_TeletextCommand(TTX_TV);
                    }
                    #endif
                    //Close MHEG5
                    #if MHEG5_ENABLE
                    if(MApp_MHEG5_CheckGoMHEG5Process())
                    {
                        MApi_MHEG5_Disable(EN_MHEG5_DM_DISABLE_WITH_AUTOBOOT_LATER);
                    }
                    #endif
                    //Disable MWE
                    #if (MWE_FUNCTION)
                    if(MApi_XC_ACE_MWEStatus())
                    {
                           MApi_XC_ACE_EnableMWE(FALSE);
                    }
                    #endif
                }

                stPOPMainWin.x = 0;
                stPOPMainWin.y = 0;
                stPOPMainWin.width = PANEL_WIDTH;
                stPOPMainWin.height = PANEL_HEIGHT;

                {
                    PQ_DISPLAY_TYPE enDisplaType = PQ_DISPLAY_ONE;

                    switch(stGenSetting.g_stPipSetting.enPipMode)
                    {
                        case EN_PIP_MODE_PIP:
                            enDisplaType = PQ_DISPLAY_PIP;
                            printf("PQ_DISPLAY_PIP\n");
                        break;
                        case EN_PIP_MODE_POP_FULL:
                        case EN_PIP_MODE_POP:
                            enDisplaType = PQ_DISPLAY_POP;
                            printf("PQ_DISPLAY_POP\n");
                        break;
                        case EN_PIP_MODE_OFF:
                        case EN_PIP_MODE_INVALID:
                            printf("PQ_DISPLAY_ONE\n");
                            enDisplaType = PQ_DISPLAY_ONE;
                        break;
                    }
                    MDrv_PQ_Set_DisplayType(g_IPanel.Width(), enDisplaType);
                    printf("Change PQ mode\n");
                }

                msAPI_Scaler_SetScreenMute(E_SCREEN_MUTE_FREERUN, ENABLE, 0, MAIN_WINDOW);
                msAPI_Scaler_SetScreenMute(E_SCREEN_MUTE_FREERUN, ENABLE, 0, SUB_WINDOW);

                if(enPreMode == EN_PIP_MODE_OFF)
                {
                    //Check sub src compatible with main src,
                    // if not compatible, find src for sub win.
                    if(!MApp_InputSource_PIP_IsSrcCompatible(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW),
                                MApp_InputSource_GetInputSourceType(UI_SUB_INPUT_SOURCE_TYPE)))
                    {
                        stGenSetting.g_stPipSetting.enSubInputSourceType = MApp_InputSource_GetUIInputSourceType(MApp_InputSource_PIP_Get1stCompatibleSrc(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)));
                    }

                    MApp_InputSource_ChangeInputSource(SUB_WINDOW);
                }
                else if(enPreMode == EN_PIP_MODE_PIP)
                {
                    MApi_XC_EnableBorder(DISABLE, SUB_WINDOW);
                }

                if(stGenSetting.g_stPipSetting.enPipMode == EN_PIP_MODE_OFF)
                {
                    //Audio Source Switch
                    if(stGenSetting.g_stPipSetting.enPipSoundSrc==EN_PIP_SOUND_SRC_SUB)
                    {
                        stGenSetting.g_stPipSetting.enPipSoundSrc=EN_PIP_SOUND_SRC_MAIN;
                        MApp_InputSource_PIP_ChangeAudioSource(MAIN_WINDOW);
                    }
                    MApp_ZUI_API_InvalidateWindow(HWND_MENU_PIP_SOUND_SRC_OPTION);
                    E_UI_INPUT_SOURCE ePreSrc = UI_SUB_INPUT_SOURCE_TYPE;
                    UI_SUB_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_NONE;
                    MApp_InputSource_ChangeInputSource(SUB_WINDOW);
                    UI_SUB_INPUT_SOURCE_TYPE = ePreSrc;
                }

                //sub window info : x, y, width, height for scaler
                if(stGenSetting.g_stPipSetting.enPipMode == EN_PIP_MODE_PIP)
                {
                    switch(stGenSetting.g_stPipSetting.enPipSize)
                    {
                        default:
                        case EN_PIP_SIZE_LARGE: //125%
                               tTempSubWin.width = u16TempPIP_Width;
                               tTempSubWin.height = u16TempPIP_Height;
                               break;
                        case EN_PIP_SIZE_MEDIUM: //100%
                               tTempSubWin.width = u16TempPIP_Width/5*4;
                               tTempSubWin.height = tTempSubWin.width*PANEL_HEIGHT/PANEL_WIDTH;
                               break;
                        case EN_PIP_SIZE_SMALL: //75%
                               tTempSubWin.width = u16TempPIP_Width/5*3;
                               tTempSubWin.height = tTempSubWin.width*PANEL_HEIGHT/PANEL_WIDTH;
                               break;
                    }

                    switch(stGenSetting.g_stPipSetting.enPipPosition)
                    {
                        default:
                        case EN_PIP_POSITION_LEFT_TOP:
                            tTempSubWin.x = 0;
                            tTempSubWin.y = 0;
                            break;
                        case EN_PIP_POSITION_RIGHT_TOP:
                            tTempSubWin.x = (PANEL_WIDTH - tTempSubWin.width);
                            tTempSubWin.y = 0;
                            break;
                        case EN_PIP_POSITION_LEFT_BOTTOM:
                            tTempSubWin.x = 0;
                            tTempSubWin.y = (PANEL_HEIGHT - tTempSubWin.height);
                            break;
                        case EN_PIP_POSITION_RIGHT_BOTTOM:
                            tTempSubWin.x = (PANEL_WIDTH - tTempSubWin.width);
                            tTempSubWin.y = (PANEL_HEIGHT - tTempSubWin.height);
                            break;
                    }

                    MApp_Scaler_SetWindow(
                        NULL,
                        NULL,
                        &stPOPMainWin,
                        stSystemInfo[MAIN_WINDOW].enAspectRatio,
                        SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW),
                        MAIN_WINDOW);

                    MDrv_PQ_LoadSettings(PQ_MAIN_WINDOW);

                    if (IsSrcTypeHDMI(SYS_INPUT_SOURCE_TYPE(SUB_WINDOW)))
                    {
                        //we need do Mode Detect here for SUB to confirm HDMI/DVI
                        //reason: the sub-win monitor thread will be started after this routine for previous MApp_InputSource_ChangeInputSource
                        MApi_XC_HDMI_CheckModeChanged(TRUE, SUB_WINDOW);
                    }
                    MApp_Scaler_SetWindow(
                        NULL,
                        NULL,                        //NULL,
                        &tTempSubWin,
                        stSystemInfo[MAIN_WINDOW].enAspectRatio,
                        SYS_INPUT_SOURCE_TYPE(SUB_WINDOW),
                        SUB_WINDOW);
                    MDrv_PQ_LoadSettings(PQ_SUB_WINDOW);
                    MApi_XC_EnableBorder(stGenSetting.g_stPipSetting.bBolderEnable, SUB_WINDOW);
                }
                else if(stGenSetting.g_stPipSetting.enPipMode == EN_PIP_MODE_POP_FULL)
                {
                    stPOPMainWin.width = PANEL_WIDTH/2;
                    stPOPMainWin.height = PANEL_HEIGHT;
                    stPOPSubWin.width = stPOPMainWin.width;
                    stPOPSubWin.height = stPOPMainWin.height;

                    stPOPMainWin.x = 0;
                    stPOPMainWin.y = 0;
                    stPOPSubWin.x = PANEL_WIDTH/2;
                    stPOPSubWin.y = 0;

                    MApp_Scaler_SetWindow(
                        NULL,
                        NULL,//                        NULL,
                        &stPOPMainWin,
                        stSystemInfo[MAIN_WINDOW].enAspectRatio,
                        SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW),
                        MAIN_WINDOW);
                    MDrv_PQ_LoadSettings(PQ_MAIN_WINDOW);

                    MApp_Scaler_SetWindow(
                        NULL,
                        NULL,//                        NULL,
                        &stPOPSubWin,
                        stSystemInfo[MAIN_WINDOW].enAspectRatio,
                        SYS_INPUT_SOURCE_TYPE(SUB_WINDOW),
                        SUB_WINDOW);
                    MDrv_PQ_LoadSettings(PQ_SUB_WINDOW);
                }
                else if(stGenSetting.g_stPipSetting.enPipMode == EN_PIP_MODE_POP)
                {
                    stPOPMainWin.width = PANEL_WIDTH/2;
                    stPOPMainWin.height = stPOPMainWin.width * PANEL_HEIGHT / PANEL_WIDTH;
                    stPOPSubWin.width = stPOPMainWin.width;
                    stPOPSubWin.height = stPOPMainWin.height;

                    stPOPMainWin.x = 0;
                    stPOPMainWin.y = PANEL_HEIGHT/2-stPOPSubWin.height/2;
                    stPOPSubWin.y = stPOPMainWin.y;
                    stPOPSubWin.x = PANEL_WIDTH/2;

                    MApp_Scaler_SetWindow(
                        NULL,
                        NULL,//                        NULL,
                        &stPOPMainWin,
                        stSystemInfo[MAIN_WINDOW].enAspectRatio,
                        SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW),
                        MAIN_WINDOW);
                    MDrv_PQ_LoadSettings(PQ_MAIN_WINDOW);

                    MApp_Scaler_SetWindow(
                        NULL,
                        NULL,//                        NULL,
                        &stPOPSubWin,
                        stSystemInfo[MAIN_WINDOW].enAspectRatio,
                        SYS_INPUT_SOURCE_TYPE(SUB_WINDOW),
                        SUB_WINDOW);
                    MDrv_PQ_LoadSettings(PQ_SUB_WINDOW);
                }
                else
                {
                    //if(act == EN_EXE_DEC_PIPMODE)//switch from EN_PIP_MODE_PIP to EN_PIP_MODE_OFF
                    {
                        MApp_Scaler_SetWindow(
                            NULL,
                            NULL,
                            NULL,
                            stSystemInfo[MAIN_WINDOW].enAspectRatio,
                            SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW),
                            MAIN_WINDOW);
                    }
                    SYS_SCREEN_SAVER_TYPE(SUB_WINDOW) = EN_SCREENSAVER_NULL; //pip off, set sub-win SS status as NULL
                }

                msAPI_Scaler_SetScreenMute(E_SCREEN_MUTE_FREERUN, DISABLE, 0, MAIN_WINDOW);

                // Do not open video when first time turn on PIP.
                // Wait timing stable.
                if(enPreMode != EN_PIP_MODE_OFF)
                {
                    msAPI_Scaler_SetScreenMute(E_SCREEN_MUTE_FREERUN, DISABLE, 0, SUB_WINDOW);
                }

                MApp_ZUI_API_InvalidateWindow(HWND_MENU_PIP_PIPMODE_OPTION);
                MApp_ZUI_CTL_DynamicListRefreshContent(HWND_MENU_PIP_PAGE_LIST);
                return TRUE;
            }
            return FALSE;

        case EN_EXE_DEC_SUBSRC:
        case EN_EXE_INC_SUBSRC:
            if(IsPIPSupported())
            {
                do{
                stGenSetting.g_stPipSetting.enSubInputSourceType=
                    (E_UI_INPUT_SOURCE) MApp_ZUI_ACT_DecIncValue_Cycle(
                      act==EN_EXE_INC_SUBSRC,
                #if(ENABLE_DTV)
                      stGenSetting.g_stPipSetting.enSubInputSourceType, UI_INPUT_SOURCE_DTV, UI_INPUT_SOURCE_NUM-1, 1);
                #else
                      stGenSetting.g_stPipSetting.enSubInputSourceType, UI_INPUT_SOURCE_ATV, UI_INPUT_SOURCE_NUM-1, 1);
                #endif
                }while(!MApp_InputSource_PIP_IsSrcCompatible(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW),
                            MApp_InputSource_GetInputSourceType(stGenSetting.g_stPipSetting.enSubInputSourceType)));
                //printf("\n[PIP] src = %d\n", stGenSetting.g_stPipSetting.enSubInputSourceType);
                MApp_InputSource_ChangeInputSource(SUB_WINDOW);
                MApp_ZUI_API_InvalidateWindow(HWND_MENU_PIP_SUBSRC_OPTION);
                return TRUE;
            }
            return FALSE;

        case EN_EXE_DEC_PIP_SIZE:
        case EN_EXE_INC_PIP_SIZE:
            if(IsPIPSupported())
            {
                stGenSetting.g_stPipSetting.enPipSize=
                    (EN_PIP_SIZE) MApp_ZUI_ACT_DecIncValue_Cycle(
                        act==EN_EXE_INC_PIP_SIZE,
                        stGenSetting.g_stPipSetting.enPipSize, EN_PIP_SIZE_SMALL, EN_PIP_SIZE_LARGE, 1);

                switch(stGenSetting.g_stPipSetting.enPipSize)
                {
                    default:
                    case EN_PIP_SIZE_LARGE: //125%
                        tTempSubWin.width = u16TempPIP_Width;
                        tTempSubWin.height = u16TempPIP_Height;
                        break;
                    case EN_PIP_SIZE_MEDIUM: //100%
                        tTempSubWin.width = u16TempPIP_Width/5*4;
                        tTempSubWin.height = tTempSubWin.width*PANEL_HEIGHT/PANEL_WIDTH;
                        break;
                    case EN_PIP_SIZE_SMALL: //75%
                        tTempSubWin.width = u16TempPIP_Width/5*3;
                        tTempSubWin.height = tTempSubWin.width*PANEL_HEIGHT/PANEL_WIDTH;
                        break;
                }
                switch(stGenSetting.g_stPipSetting.enPipPosition)
                {
                    default:
                    case EN_PIP_POSITION_LEFT_TOP:
                        tTempSubWin.x = 0;
                        tTempSubWin.y = 0;
                        break;
                    case EN_PIP_POSITION_RIGHT_TOP:
                        tTempSubWin.x = (PANEL_WIDTH - tTempSubWin.width);
                        tTempSubWin.y = 0;
                        break;
                    case EN_PIP_POSITION_LEFT_BOTTOM:
                        tTempSubWin.x = 0;
                        tTempSubWin.y = (PANEL_HEIGHT - tTempSubWin.height);
                        break;
                    case EN_PIP_POSITION_RIGHT_BOTTOM:
                        tTempSubWin.x = (PANEL_WIDTH - tTempSubWin.width);
                        tTempSubWin.y = (PANEL_HEIGHT - tTempSubWin.height);
                        break;
                }
                MApp_Scaler_SetWindow(NULL, NULL, &tTempSubWin,
                    stSystemInfo[MAIN_WINDOW].enAspectRatio,
                    SYS_INPUT_SOURCE_TYPE(SUB_WINDOW),
                    SUB_WINDOW);
                MApp_ZUI_API_InvalidateWindow(HWND_MENU_PIP_SIZE_OPTION);
                return TRUE;
            }
            return FALSE;

        case EN_EXE_DEC_PIP_POSITION:
        case EN_EXE_INC_PIP_POSITION:
            if(IsPIPSupported())
            {
                stGenSetting.g_stPipSetting.enPipPosition=
                    (EN_PIP_POSITION) MApp_ZUI_ACT_DecIncValue_Cycle(
                    act==EN_EXE_INC_PIP_POSITION,
                    stGenSetting.g_stPipSetting.enPipPosition, EN_PIP_POSITION_LEFT_TOP, EN_PIP_POSITION_RIGHT_BOTTOM, 1);

                switch(stGenSetting.g_stPipSetting.enPipSize)
                {
                    default:
                    case EN_PIP_SIZE_LARGE: //125%
                        tTempSubWin.width = u16TempPIP_Width;
                        tTempSubWin.height = u16TempPIP_Height;
                        break;
                    case EN_PIP_SIZE_MEDIUM: //100%
                        tTempSubWin.width = u16TempPIP_Width/5*4;
                        tTempSubWin.height = tTempSubWin.width*PANEL_HEIGHT/PANEL_WIDTH;
                        break;
                    case EN_PIP_SIZE_SMALL: //75%
                        tTempSubWin.width = u16TempPIP_Width/5*3;
                        tTempSubWin.height = tTempSubWin.width*PANEL_HEIGHT/PANEL_WIDTH;
                        break;
                }
                switch(stGenSetting.g_stPipSetting.enPipPosition)
                {
                    default:
                    case EN_PIP_POSITION_LEFT_TOP:
                        tTempSubWin.x = 0;
                        tTempSubWin.y = 0;
                        break;
                    case EN_PIP_POSITION_RIGHT_TOP:
                        tTempSubWin.x = (PANEL_WIDTH - tTempSubWin.width);
                        tTempSubWin.y = 0;
                        break;
                    case EN_PIP_POSITION_LEFT_BOTTOM:
                        tTempSubWin.x = 0;
                        tTempSubWin.y = (PANEL_HEIGHT - tTempSubWin.height);
                        break;
                    case EN_PIP_POSITION_RIGHT_BOTTOM:
                        tTempSubWin.x = (PANEL_WIDTH - tTempSubWin.width);
                        tTempSubWin.y = (PANEL_HEIGHT - tTempSubWin.height);
                        break;
                }
                MApp_Scaler_SetWindow(NULL, NULL, &tTempSubWin,
                    stSystemInfo[MAIN_WINDOW].enAspectRatio,
                    SYS_INPUT_SOURCE_TYPE(SUB_WINDOW),
                    SUB_WINDOW);

                MApp_ZUI_API_InvalidateWindow(HWND_MENU_PIP_POSITION_OPTION);
                return TRUE;
            }
            return FALSE;

        case EN_EXE_PIP_SWAP:
            if(IsPIPSupported())
            {
                //printf("Enter PIP swap api...\n");
                MApp_InputSource_PIP_Swap();
                MApp_ZUI_API_InvalidateWindow(HWND_MENU_PIP_SUBSRC_OPTION);
                return TRUE;
            }
            return FALSE;
        #endif //#if (ENABLE_PIP)
#endif
    #if (ATSC_CC == ATV_CC)
        case EN_EXE_DEC_OPTION_CC_OPTION:
        case EN_EXE_INC_OPTION_CC_OPTION:
            stGenSetting.g_SysSetting.enATVCaptionType=
                (EN_ATV_CAPTION_TYPE)MApp_ZUI_ACT_DecIncValue_Cycle(
                    act==EN_EXE_INC_OPTION_CC_OPTION,
                     (U16)(stGenSetting.g_SysSetting.enATVCaptionType),0, (U16)ATV_CAPTION_TYPE_NUM-1, 1);
            MApp_ZUI_API_InvalidateWindow(HWND_MENU_SINGLELIST_COMMON_PAGE_LIST);
            MApp_ZUI_API_InvalidateWindow(HWND_MENU_OPTION_CC_OPTION_OPTION);
            break;
    #endif // #if (ATSC_CC == ATV_CC)

    #if ENABLE_3D_PROCESS
        case EN_EXE_DEC_3DTYPE_MODE:
        case EN_EXE_INC_3DTYPE_MODE:
        {
         #if ENABLE_ZOOM_AVOUT_NOTMUTE
            bIsAspectMute = TRUE;
         #endif
            #if ENABLE_CUS_3D_SOURCE_MEMORY
            if((IsHDMIInUse()) && (g_HdmiPollingStatus.bIsHDMIMode == FALSE))
            {
                E_XC_3D_INPUT_MODE eInput3DMode;
                if(ST_VGA_3D_TYPE != EN_3D_BYPASS)
                {
                    ST_VGA_3D_TYPE = EN_3D_BYPASS;
                }
                else
                {
                    ST_VGA_3D_TYPE = EN_3D_NORMAL_2D;
                }

            #if (ENABLE_6M30_3D_PROCESS)
                MDrv_Ursa_6M30_3D_MODE(ST_VGA_3D_TYPE);
            #endif
                eInput3DMode = MAPP_Scaler_MapUI3DModeToXC3DMode(ST_VGA_3D_TYPE);
                MApp_Scaler_EnableManualDetectTiming(TRUE);
                msAPI_Scaler_SetBlueScreen(ENABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
                MApp_Scaler_SetVideo3DMode(MAPP_Scaler_Map3DFormatTo3DUserMode(eInput3DMode));
                MApp_ZUI_CTL_DynamicListRefreshContent(HWND_MENU_OPTION_3D_SETUP_PAGE_LIST);


              #if ENABLE_UI_3D_PROCESS
                MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_CLOSE_CURRENT_OSD);
                stGenSetting.g_SysSetting.en3DUIMODE = E_UI_3D_UI_MODE_NUM;
              #else
                msAPI_Scaler_SetBlueScreen(DISABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
              #endif
            }
            else
            #endif
            {
                E_XC_3D_INPUT_MODE eInput3DMode;
                #if ENABLE_CUS_3D_SETTING
                if(act==EN_EXE_INC_3DTYPE_MODE)
                {
                    if(ST_3D_TYPE == EN_3D_BYPASS)
                    {
                        if((IsHDMIInUse() && g_HdmiPollingStatus.bIsHDMIMode) || IsStorageInUse())
                        {
                            ST_3D_TYPE = EN_3D_FRAME_PARKING;
                        }
                        else
                        {
                            ST_3D_TYPE = EN_3D_NORMAL_2D;
                        }
                    }
                    else if(ST_3D_TYPE == EN_3D_FRAME_PARKING)
                    {
                        ST_3D_TYPE = EN_3D_SIDE_BY_SIDE;
                    }
                    else if(ST_3D_TYPE == EN_3D_SIDE_BY_SIDE)
                    {
                        ST_3D_TYPE = EN_3D_TOP_BOTTOM;
                    }
                    else if(ST_3D_TYPE == EN_3D_TOP_BOTTOM)
                    {
                        ST_3D_TYPE = EN_3D_NORMAL_2D;
                    }
                    else if(ST_3D_TYPE == EN_3D_NORMAL_2D)
                    {
                        if((IsHDMIInUse() && g_HdmiPollingStatus.bIsHDMIMode) || IsStorageInUse())
                        {
                            ST_3D_TYPE = EN_3D_3D_TO_2D;
                        }
                        else
                        {
                            ST_3D_TYPE = EN_3D_BYPASS;
                        }
                    }
                    else if(ST_3D_TYPE == EN_3D_3D_TO_2D)
                    {
                        ST_3D_TYPE = EN_3D_BYPASS;
                    }
                    else
                    {
                        ST_3D_TYPE = EN_3D_BYPASS;
                    }
                }
                else
                {
                    if(ST_3D_TYPE == EN_3D_BYPASS)
                    {
                        if((IsHDMIInUse() && g_HdmiPollingStatus.bIsHDMIMode) || IsStorageInUse())
                        {
                            ST_3D_TYPE = EN_3D_3D_TO_2D;
                        }
                        else
                        {
                            ST_3D_TYPE = EN_3D_NORMAL_2D;
                        }
                    }
                    else if(ST_3D_TYPE == EN_3D_3D_TO_2D)
                    {
                        ST_3D_TYPE = EN_3D_NORMAL_2D;
                    }

                    else if(ST_3D_TYPE == EN_3D_NORMAL_2D)
                    {
                        if((IsHDMIInUse() && g_HdmiPollingStatus.bIsHDMIMode) || IsStorageInUse())
                        {
                            ST_3D_TYPE = EN_3D_TOP_BOTTOM;
                        }
                        else
                        {
                            ST_3D_TYPE = EN_3D_BYPASS;
                        }
                    }
                    else if(ST_3D_TYPE == EN_3D_TOP_BOTTOM)
                    {
                        ST_3D_TYPE = EN_3D_SIDE_BY_SIDE;
                    }
                    else if(ST_3D_TYPE == EN_3D_SIDE_BY_SIDE)
                    {
                        ST_3D_TYPE = EN_3D_FRAME_PARKING;
                    }
                    else if(ST_3D_TYPE == EN_3D_FRAME_PARKING)
                    {
                        ST_3D_TYPE = EN_3D_BYPASS;
                    }
                    else
                    {
                        ST_3D_TYPE = EN_3D_BYPASS;
                    }
                }
                #else
                ST_3D_TYPE=
                    (EN_3D_TYPE)MApp_ZUI_ACT_DecIncValue_Cycle(
                        act==EN_EXE_INC_3DTYPE_MODE,
                         (U16)(ST_3D_TYPE),EN_3D_BYPASS, (U16)EN_3D_TYPE_NUM-1, 1);

                #endif

            #if (ENABLE_6M30_3D_PROCESS)
                MDrv_Ursa_6M30_3D_MODE(ST_3D_TYPE);
            #endif
                eInput3DMode = MAPP_Scaler_MapUI3DModeToXC3DMode(ST_3D_TYPE);
                MApp_Scaler_EnableManualDetectTiming(TRUE);
                msAPI_Scaler_SetBlueScreen(ENABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
                MApp_Scaler_SetVideo3DMode(MAPP_Scaler_Map3DFormatTo3DUserMode(eInput3DMode));
                MApp_ZUI_CTL_DynamicListRefreshContent(HWND_MENU_OPTION_3D_SETUP_PAGE_LIST);


              #if ENABLE_UI_3D_PROCESS
                MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_CLOSE_CURRENT_OSD);
                stGenSetting.g_SysSetting.en3DUIMODE = E_UI_3D_UI_MODE_NUM;
              #else
                msAPI_Scaler_SetBlueScreen(DISABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
              #endif
               // break;
            }
         #if ENABLE_ZOOM_AVOUT_NOTMUTE
            bIsAspectMute = FALSE;
         #endif
        }
		break;

        case EN_EXE_INC_3DDETECT_MODE:
            stGenSetting.g_SysSetting.en3DDetectMode=
                (EN_3D_DETECT_MODE)MApp_ZUI_ACT_DecIncValue_Cycle(
                    act==EN_EXE_INC_3DDETECT_MODE,
                     (U16)(stGenSetting.g_SysSetting.en3DDetectMode),EN_3D_DETECT_AUTO, (U16)EN_3D_DETECT_NUM-1, 1);
            MApp_Scaler_EnableManualDetectTiming(MAPP_Scaler_MapUIDetectMode(stGenSetting.g_SysSetting.en3DDetectMode));
        #if ENABLE_CUS_3D_SOURCE_MEMORY
            if(stGenSetting.g_SysSetting.en3DDetectMode == EN_3D_DETECT_AUTO)
            {
                #if (ENABLE_6M30_3D_PROCESS)
                MDrv_Ursa_6M30_3D_MODE(MAPP_Scaler_Map3DFormatTo3DUserMode(g_HdmiInput3DFormat));
                #endif
                msAPI_Scaler_SetBlueScreen(ENABLE,E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
                MApp_Scaler_SetVideo3DMode(MAPP_Scaler_Map3DFormatTo3DUserMode(g_HdmiInput3DFormat));
                #if ENABLE_UI_3D_PROCESS
                MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_CLOSE_CURRENT_OSD);
                stGenSetting.g_SysSetting.en3DUIMODE = E_UI_3D_UI_MODE_NUM;
                #else
                msAPI_Scaler_SetBlueScreen(DISABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
                #endif
            }
        #endif
            MApp_ZUI_CTL_DynamicListRefreshContent(HWND_MENU_OPTION_3D_SETUP_PAGE_LIST);
            break;
        case EN_EXE_INC_3D_LR_MODE:
            #if ENABLE_CUS_3D_SOURCE_MEMORY
            if(IsHDMIInUse() && (g_HdmiPollingStatus.bIsHDMIMode == FALSE)) //dvi
            {
                 ST_VGA_3D_LRMODE=
                     (EN_3D_LR_MODE)MApp_ZUI_ACT_DecIncValue_Cycle(
                         act==EN_EXE_INC_3D_LR_MODE,
                          (U16)ST_VGA_3D_LRMODE,EN_3D_LR_L, (U16)EN_3D_LR_NUM-1, 1);
            }
            else
            #endif
            {
                ST_3D_LRMODE=
                    (EN_3D_LR_MODE)MApp_ZUI_ACT_DecIncValue_Cycle(
                        act==EN_EXE_INC_3D_LR_MODE,
                         (U16)(ST_3D_LRMODE),EN_3D_LR_L, (U16)EN_3D_LR_NUM-1, 1);
            }
            MApi_XC_Set_3D_LR_Frame_Exchg(MAIN_WINDOW);
            MApp_ZUI_API_InvalidateWindow(HWND_MENU_OPTION_3D_LR_OPTION);
            break;

         case EN_EXE_DEC_3D_SCENE:
         case EN_EXE_INC_3D_SCENE:
#if ENABLE_CUS_3D_SETTING

	#if ENABLE_CUS_3D_SOURCE_MEMORY    //cus_xm:zb add at 2012-8-22
            if(IsHDMIInUse() && (g_HdmiPollingStatus.bIsHDMIMode == FALSE)) //dvi
            {
		  if(ST_VGA_3DScene==0||ST_VGA_3DScene==10)
					isSceneValueOver=TRUE;
				else
					isSceneValueOver=FALSE;
		 }
            else
            #endif
            {
                  if(ST_3D_3DScene==0||ST_3D_3DScene==10)
					isSceneValueOver=TRUE;
				else
					isSceneValueOver=FALSE;
	      }

	  #if ENABLE_CUS_3D_SOURCE_MEMORY
            if(IsHDMIInUse() && (g_HdmiPollingStatus.bIsHDMIMode == FALSE)) //dvi
            {
                ST_VGA_3DScene=
                    MApp_ZUI_ACT_DecIncValue(
                        act==EN_EXE_INC_3D_SCENE,
                         (U16)(ST_VGA_3DScene),0, 10, 1);
		 if(ST_VGA_3DScene>0&&ST_VGA_3DScene<10)//cus_xm:zb add at 2012-8-22
		      isSceneValueOver=FALSE;
            }
            else
            #endif
            {
                 ST_3D_3DScene=
                     MApp_ZUI_ACT_DecIncValue(
                         act==EN_EXE_INC_3D_SCENE,
                          (U16)(ST_3D_3DScene),0, 10, 1);
		 if(ST_3D_3DScene>0&&ST_3D_3DScene<10)//cus_xm:zb add at 2012-8-22
		      isSceneValueOver=FALSE;
            }

#if ENABLE_3D_PROCESS
          if(isSceneValueOver==FALSE)  //cus_xm:zb add at 2012-8-22
          {
              MApp_Scaler_EnableManualDetectTiming(TRUE);
              msAPI_Scaler_SetBlueScreen(ENABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
           }
	     #if ENABLE_CUS_3D_SOURCE_MEMORY
            if(IsHDMIInUse() && (g_HdmiPollingStatus.bIsHDMIMode == FALSE)) //dvi
            {
                MApp_Scaler_SetVideo3DMode(MAPP_Scaler_Map3DFormatTo3DUserMode(MAPP_Scaler_MapUI3DModeToXC3DMode(ST_VGA_3D_TYPE)));
            }
            else
            #endif
            {
                MApp_Scaler_SetVideo3DMode(MAPP_Scaler_Map3DFormatTo3DUserMode(MAPP_Scaler_MapUI3DModeToXC3DMode(ST_3D_TYPE)));
            }

            #if ENABLE_UI_3D_PROCESS
            MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_CLOSE_CURRENT_OSD);
            stGenSetting.g_SysSetting.en3DUIMODE = E_UI_3D_UI_MODE_NUM;
            #else
            msAPI_Scaler_SetBlueScreen(DISABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
            #endif
#endif

            MApp_Scaler_Set3DScene_CUS();
            MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_OPTION_3D_SCENE);
            return TRUE;
             #endif
             break;

    #endif
        case EN_EXE_DEC_OSD_TRAN:
        case EN_EXE_INC_OSD_TRAN:
            {
                stGenSetting.g_SysSetting.OsdBlending=
                    (EN_OSD_TRAN)MApp_ZUI_ACT_DecIncValue_Cycle(
                        act==EN_EXE_INC_OSD_TRAN,
                        stGenSetting.g_SysSetting.OsdBlending, EN_OSD_TRAN_OFF, EN_OSD_TRAN_HIGH, 1);
            }
            OSDPAGE_BLENDING_VALUE = (63 - stGenSetting.g_SysSetting.OsdBlending*10);
            MApi_GOP_GWIN_SetBlending(MApp_ZUI_API_QueryGWinID(), TRUE, OSDPAGE_BLENDING_VALUE);
            MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_OPTION_BLENDING_OPTION);
            return TRUE;

        case EN_EXE_DEC_POWER_ON_MUSIC:
        case EN_EXE_INC_POWER_ON_MUSIC:
           #if (ENABLE_DMP)
            {
                stGenSetting.g_SysSetting.UsrPowerOnMusic=
                    MApp_ZUI_ACT_DecIncValue_Cycle(
                        act==EN_EXE_INC_POWER_ON_MUSIC,
                        stGenSetting.g_SysSetting.UsrPowerOnMusic, POWERON_MUSIC_OFF, POWERON_MUSIC_DEFAULT, 1);
            }
           #endif
            MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_OPTION_POWERON_MUSIC);
            return TRUE;

        case EN_EXE_DEC_POWER_ON_LOGO:
        case EN_EXE_INC_POWER_ON_LOGO:
           #if (ENABLE_DMP)
            {
                stGenSetting.g_SysSetting.UsrLogo=
                    MApp_ZUI_ACT_DecIncValue_Cycle(
                        act==EN_EXE_INC_POWER_ON_LOGO,
                        stGenSetting.g_SysSetting.UsrLogo, POWERON_LOGO_OFF, (POWERON_LOGO_DEFAULT + stGenSetting.g_SysSetting.u8UsrLogoCnt), 1);
            }
           #endif
            MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_OPTION_POWERON_LOGO);
            return TRUE;

        case EN_EXE_DEC_HDMI_MODE:
        case EN_EXE_INC_HDMI_MODE:
            #if ENABLE_CUS_HDMI_MODE
            if(stGenSetting.g_SysSetting.bIsHDMIVideoMode)
            {
                stGenSetting.g_SysSetting.bIsHDMIVideoMode = FALSE;
            }
            else
            {
                stGenSetting.g_SysSetting.bIsHDMIVideoMode = TRUE;
            }
            {
                #if ENABLE_3D_PROCESS
                BOOLEAN bSet3DVideoSetting = FALSE;
                EN_3D_TYPE    en3DType;
                #if ENABLE_CUS_3D_SOURCE_MEMORY
                if(IsHDMIInUse() && (g_HdmiPollingStatus.bIsHDMIMode == FALSE)) //dvi
                {
                    en3DType = ST_VGA_3D_TYPE;
                }
                else
                #endif
                {
                    en3DType = ST_3D_TYPE;
                }

                if(IsHDMIInUse() && g_HdmiPollingStatus.bIsHDMIMode)
                {
                    if(stGenSetting.g_SysSetting.en3DDetectMode == EN_3D_DETECT_AUTO)
                    {
                        if(g_HdmiInput3DFormatStatus !=E_XC_3D_INPUT_MODE_NONE)
                        {
                            bSet3DVideoSetting = TRUE;
                        }
                    }
                    else if(ST_3D_TYPE != EN_3D_BYPASS)
                    {
                        bSet3DVideoSetting = TRUE;
                    }
                }

                if(bSet3DVideoSetting)
                {
                    msAPI_Scaler_SetBlueScreen(ENABLE, E_XC_FREE_RUN_COLOR_BLACK, 500, MAIN_WINDOW);
                }
                #endif

                MApp_Scaler_Setting_ForceSetVDScale( ST_VIDEO.eAspectRatio , MAIN_WINDOW );

                #if ENABLE_3D_PROCESS
                if(bSet3DVideoSetting)
                {
                #if (ENABLE_6M30_3D_PROCESS)
                    MDrv_Ursa_6M30_3D_MODE(en3DType);
                #endif
                    MApp_Scaler_EnableManualDetectTiming(TRUE);
                    MApp_Scaler_SetVideo3DMode(MAPP_Scaler_Map3DFormatTo3DUserMode(MAPP_Scaler_MapUI3DModeToXC3DMode(en3DType)));

                  #if ENABLE_UI_3D_PROCESS
                    MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_CLOSE_CURRENT_OSD);
                    stGenSetting.g_SysSetting.en3DUIMODE = E_UI_3D_UI_MODE_NUM;
                  #else
                    msAPI_Scaler_SetBlueScreen(DISABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
                  #endif
                }
                #endif
            }

            //MApp_Scaler_Setting_SetVDScale( ST_VIDEO.eAspectRatio , MAIN_WINDOW );
            MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_OPTION_HDMI_MODE);
            #endif

            return TRUE;
        case EN_EXE_DEC_OSD_TIME:
        case EN_EXE_INC_OSD_TIME:
              stGenSetting.g_SysSetting.OsdDuration= (EN_OSD_TIME)MApp_ZUI_ACT_DecIncValue_Cycle(
                act==EN_EXE_INC_OSD_TIME,
                stGenSetting.g_SysSetting.OsdDuration, EN_OSD_TIME_MIN, EN_OSD_TIME_NUM-1, 1);
               MApp_ZUI_API_InvalidateWindow(HWND_MENU_OPTION_DUETIME_OPTION);
               if(stGenSetting.g_SysSetting.OsdDuration==EN_OSD_TIME_ALWAYS)
               {
                    MApp_ZUI_API_KillTimer(HWND_MENU_MASK_BACKGROUND,0);
                    MApp_ZUI_API_KillTimer(HWND_MENU_TRANSPARENT_BG,0);
                    MApp_ZUI_API_KillTimer(HWND_MENU_PICTURE_ADJUST_SUBMENU,0);
               }
               else
               {
                #if ENABLE_CUS_OSD_TIMEOUT
                    MApp_ZUI_API_SetTimer(HWND_MENU_MASK_BACKGROUND, 0, stGenSetting.g_SysSetting.OsdDuration*10000);
                    MApp_ZUI_API_SetTimer(HWND_MENU_TRANSPARENT_BG, 0, stGenSetting.g_SysSetting.OsdDuration*10000);
                    MApp_ZUI_API_SetTimer(HWND_MENU_PICTURE_ADJUST_SUBMENU, 0, stGenSetting.g_SysSetting.OsdDuration*10000);
                #else
                    MApp_ZUI_API_SetTimer(HWND_MENU_MASK_BACKGROUND, 0, stGenSetting.g_SysSetting.OsdDuration*5000);
                    MApp_ZUI_API_SetTimer(HWND_MENU_TRANSPARENT_BG, 0, stGenSetting.g_SysSetting.OsdDuration*5000);
                    MApp_ZUI_API_SetTimer(HWND_MENU_PICTURE_ADJUST_SUBMENU, 0, stGenSetting.g_SysSetting.OsdDuration*5000);
                #endif
               }
            return TRUE;

#if ENABLE_CEC
         case EN_EXE_HDMI_CEC_FUNCTION:
            {
                U8 name_index = 0, j = 0, active_device = 0, focus_item = 0;

                active_device = msAPI_CEC_GetActiveDevice();
                u8HDMI_CEC_Devices_Count = 0;

                for( name_index=0; name_index<15; name_index++)
                {
                    if (msAPI_CEC_IsDeviceExist((MsCEC_DEVICELA)name_index) == TRUE)
                    {
                        u8HDMI_CEC_DevicesName[j] = msAPI_CEC_GetDeviceName(name_index); // Get string pointer
                        if(active_device == name_index)
                        {
                            focus_item = j;
                            printf(" CEC set focus = %d (Start from 0)\n", focus_item);
                        }

                        j++;
                        u8HDMI_CEC_Devices_Count++;
                    }
                }

                for( name_index=u8HDMI_CEC_Devices_Count; name_index < (15 - u8HDMI_CEC_Devices_Count); name_index++)
                {
                    u8HDMI_CEC_DevicesName[name_index] = NULL; // put NULL pointer into unused name structure
                }

                MApp_ZUI_API_ShowWindow(HWND_MENU_HDMI_CEC_PAGE, SW_HIDE);
                MApp_ZUI_API_ShowWindow(HWND_MENU_TRANSPARENT_BG, SW_SHOW);
                MApp_ZUI_API_ShowWindow(HWND_MENU_HDMI_CEC_DEVICE_LIST_PAGE, SW_SHOW);
                MApp_ZUI_API_SetFocus(hdmi_cec_UI_list[focus_item]);
            }
            return TRUE;

         case EN_EXE_HDMI_CEC_SELECT:
            {
                if(MApp_ZUI_API_GetFocus() == HWND_MENU_HDMI_CEC_HDMI)
                {
                   if (stGenSetting.g_SysSetting.g_enHDMICEC == EN_E4_HDMICEC_On)
                       stGenSetting.g_SysSetting.g_enHDMICEC = EN_E4_HDMICEC_Off;
                   else
                       stGenSetting.g_SysSetting.g_enHDMICEC = EN_E4_HDMICEC_On;

                    MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_HDMI_CEC_HDMI);
                }
                else if(MApp_ZUI_API_GetFocus() == HWND_MENU_HDMI_CEC_AUTO_STANDBY)
                {
                    if (stGenSetting.g_SysSetting.g_bHdmiCecDeviceAutoStandby == TRUE)
                       stGenSetting.g_SysSetting.g_bHdmiCecDeviceAutoStandby = FALSE;
                   else
                       stGenSetting.g_SysSetting.g_bHdmiCecDeviceAutoStandby = TRUE;

                    MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_HDMI_CEC_AUTO_STANDBY);
                }
            }
            return TRUE;

         case EN_EXE_CHANGE_DEVICES:
         case EN_EXE_SELECT_UP_DEVICES:
         case EN_EXE_SELECT_DOWN_DEVICES:
            {
                HWND hwnd = MApp_ZUI_API_GetFocus();
                U8 i = 0, max_list = 15, j = 0;

                if(u8HDMI_CEC_Devices_Count == 0)
                    return TRUE;

                for( i=0; i<max_list; i++)
                {
                    if(hwnd == hdmi_cec_UI_list[i]) // get index in CEC UI list
                        break;
                }


                if(act == EN_EXE_CHANGE_DEVICES)
                {
                    for( j=0; j<max_list; j++)
                    {
                        // DevicesName and UI are one by one mapping
                        if(u8HDMI_CEC_DevicesName[i] == msAPI_CEC_GetDeviceName(j))
                            msAPI_RoutingControl_DeviceChange((MsCEC_DEVICELA)j);
                    }
                    MApp_ZUI_API_ShowWindow(HWND_MENU_HDMI_CEC_DEVICE_LIST_PAGE, SW_HIDE);
                    MApp_ZUI_API_ShowWindow(HWND_MENU_TRANSPARENT_BG, SW_SHOW);
                    MApp_ZUI_API_ShowWindow(HWND_MENU_HDMI_CEC_PAGE, SW_SHOW);
                    MApp_ZUI_API_SetFocus(HWND_MENU_HDMI_CEC_DEVICE_LIST);
                }
                else if(act == EN_EXE_SELECT_UP_DEVICES)
                {
                    if(i == 0)
                        MApp_ZUI_API_SetFocus(hdmi_cec_UI_list[(u8HDMI_CEC_Devices_Count -1)]); // now is 1st, Set focus to final devices
                    else
                        MApp_ZUI_API_SetFocus(hdmi_cec_UI_list[(i -1)]); // Set focus to up devices

                    MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_HDMI_CEC_DEVICE_LIST_PAGE);
                }
                else if(act == EN_EXE_SELECT_DOWN_DEVICES)
                {
                    if(i  == (u8HDMI_CEC_Devices_Count-1))
                        MApp_ZUI_API_SetFocus(hdmi_cec_UI_list[0]); // now is final, Set focus to 1st devices
                    else
                        MApp_ZUI_API_SetFocus(hdmi_cec_UI_list[(i + 1)]); // Set focus to down devices

                    MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_HDMI_CEC_DEVICE_LIST_PAGE);
                }
            }
            return TRUE;
#endif
		case EN_EXE_BLOCK_SOURCE:
			switch(MApp_ZUI_API_GetFocus())
				{
				case HWND_MENU_LOCK_MAINSUBPAGE_ITEM_TV:
					if(stGenSetting.g_VChipSetting.u8InputBlockItem&INPUT_BLOCK_TV)
						stGenSetting.g_VChipSetting.u8InputBlockItem &= (~INPUT_BLOCK_TV);
					else
						stGenSetting.g_VChipSetting.u8InputBlockItem |= INPUT_BLOCK_TV;
                    g_u16PasswordCheckSource |= INPUT_BLOCK_TV;
					MApp_UiMenuFunc_AdjustInputLockTV();
					break;
				case HWND_MENU_LOCK_MAINSUBPAGE_ITEM_AV1:
					if(stGenSetting.g_VChipSetting.u8InputBlockItem&INPUT_BLOCK_AV1)
						stGenSetting.g_VChipSetting.u8InputBlockItem &= (~INPUT_BLOCK_AV1);
					else
						stGenSetting.g_VChipSetting.u8InputBlockItem |= INPUT_BLOCK_AV1;
                    g_u16PasswordCheckSource |= INPUT_BLOCK_AV1;
					MApp_UiMenuFunc_AdjustInputLockAV1();
					break;
				case HWND_MENU_LOCK_MAINSUBPAGE_ITEM_AV2:
					if(stGenSetting.g_VChipSetting.u8InputBlockItem&INPUT_BLOCK_AV2)
						stGenSetting.g_VChipSetting.u8InputBlockItem &= (~INPUT_BLOCK_AV2);
					else
						stGenSetting.g_VChipSetting.u8InputBlockItem |= INPUT_BLOCK_AV2;
                    g_u16PasswordCheckSource |= INPUT_BLOCK_AV2;
					MApp_UiMenuFunc_AdjustInputLockAV2();
					break;
				case HWND_MENU_LOCK_MAINSUBPAGE_ITEM_YPBPR1:
					if(stGenSetting.g_VChipSetting.u8InputBlockItem&INPUT_BLOCK_YPBPR1)
						stGenSetting.g_VChipSetting.u8InputBlockItem &= (~INPUT_BLOCK_YPBPR1);
					else
						stGenSetting.g_VChipSetting.u8InputBlockItem |= INPUT_BLOCK_YPBPR1;
                    g_u16PasswordCheckSource |= INPUT_BLOCK_YPBPR1;
					MApp_UiMenuFunc_AdjustInputLockYPbPr1();
					break;
				case HWND_MENU_LOCK_MAINSUBPAGE_ITEM_YPBPR2:
					if(stGenSetting.g_VChipSetting.u8InputBlockItem&INPUT_BLOCK_YPBPR2)
						stGenSetting.g_VChipSetting.u8InputBlockItem &= (~INPUT_BLOCK_YPBPR2);
					else
						stGenSetting.g_VChipSetting.u8InputBlockItem |= INPUT_BLOCK_YPBPR2;
                    g_u16PasswordCheckSource |= INPUT_BLOCK_YPBPR2;
					MApp_UiMenuFunc_AdjustInputLockYPbPr2();
					break;
				case HWND_MENU_LOCK_MAINSUBPAGE_ITEM_PC:
					if(stGenSetting.g_VChipSetting.u8InputBlockItem&INPUT_BLOCK_PC)
						stGenSetting.g_VChipSetting.u8InputBlockItem &= (~INPUT_BLOCK_PC);
					else
						stGenSetting.g_VChipSetting.u8InputBlockItem |= INPUT_BLOCK_PC;
                    g_u16PasswordCheckSource |= INPUT_BLOCK_PC;
					MApp_UiMenuFunc_AdjustInputLockPC();
					break;
				case HWND_MENU_LOCK_MAINSUBPAGE_ITEM_HDMI1:
					if(stGenSetting.g_VChipSetting.u8InputBlockItem&INPUT_BLOCK_HDMI1)
						stGenSetting.g_VChipSetting.u8InputBlockItem &= (~INPUT_BLOCK_HDMI1);
					else
						stGenSetting.g_VChipSetting.u8InputBlockItem |= INPUT_BLOCK_HDMI1;
                    g_u16PasswordCheckSource |= INPUT_BLOCK_HDMI1;
					MApp_UiMenuFunc_AdjustInputLockHDMI1();
					break;
				case HWND_MENU_LOCK_MAINSUBPAGE_ITEM_HDMI2:
					if(stGenSetting.g_VChipSetting.u8InputBlockItem&INPUT_BLOCK_HDMI2)
						stGenSetting.g_VChipSetting.u8InputBlockItem &= (~INPUT_BLOCK_HDMI2);
					else
						stGenSetting.g_VChipSetting.u8InputBlockItem |= INPUT_BLOCK_HDMI2;
                    g_u16PasswordCheckSource |= INPUT_BLOCK_HDMI2;
					MApp_UiMenuFunc_AdjustInputLockHDMI2();
					break;
				case HWND_MENU_LOCK_MAINSUBPAGE_ITEM_HDMI3:
					if(stGenSetting.g_VChipSetting.u8InputBlockItem&INPUT_BLOCK_HDMI3)
						stGenSetting.g_VChipSetting.u8InputBlockItem &= (~INPUT_BLOCK_HDMI3);
					else
						stGenSetting.g_VChipSetting.u8InputBlockItem |= INPUT_BLOCK_HDMI3;
                    g_u16PasswordCheckSource |= INPUT_BLOCK_HDMI3;
					MApp_UiMenuFunc_AdjustInputLockHDMI3();
					break;
				case HWND_MENU_LOCK_MAINSUBPAGE_ITEM_HDMI4:
					if(stGenSetting.g_VChipSetting.u8InputBlockItem&INPUT_BLOCK_HDMI4)
						stGenSetting.g_VChipSetting.u8InputBlockItem &= (~INPUT_BLOCK_HDMI4);
					else
						stGenSetting.g_VChipSetting.u8InputBlockItem |= INPUT_BLOCK_HDMI4;
                    g_u16PasswordCheckSource |= INPUT_BLOCK_HDMI4;
					MApp_UiMenuFunc_AdjustInputLockHDMI4();
					break;
				}
			
			if(!MApp_UiMenuFunc_CheckInputLockAudioVideo())
			{
			  if(MApp_IsSrcHasSignal(MAIN_WINDOW) && !IsStorageInUse())  //tudy added 20130508
			  {
			   if((msAPI_Scaler_GetScreenMute(MAIN_WINDOW)&E_SCREEN_MUTE_FREERUN))
				 msAPI_Scaler_SetBlueScreen( DISABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
			  }
			}
            MApp_SaveVshipSetting();
			MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_LOCK_INPUT_SUBPAGE);
                break;

         case EN_EXE_DEC_SYSTEM_OPTION:
         case EN_EXE_INC_SYSTEM_OPTION:
         #ifdef ENABLE_CUS_AUTO_AUDIO_SYSTEM_DETECT
            #if ( ENABLE_DVB_TAIWAN_APP || ENABLE_SBTVD_BRAZIL_APP )
            stGenSetting.stScanMenuSetting.u8SoundSystem = EN_ATV_SystemType_M;
            #else
            if(msAPI_AUD_IsEnableRealtimeAudioDetection())
            {
                if(EN_EXE_INC_SYSTEM_OPTION == act)
                {
                    stGenSetting.stScanMenuSetting.u8SoundSystem = EN_ATV_SystemType_BG;
                }
                else
                {
                    stGenSetting.stScanMenuSetting.u8SoundSystem = EN_ATV_SystemType_M;
                }
                msAPI_AUD_EnableRealtimeAudioDetection(FALSE); //AUTO
                msAPI_ATV_ChannelInfoEdit_EnableRealtimeAudioDetection(FALSE);
            }
            else
            {

                 if(EN_EXE_INC_SYSTEM_OPTION == act)
                 {
                     if(stGenSetting.stScanMenuSetting.u8SoundSystem == EN_ATV_SystemType_M)
                     {
                         msAPI_AUD_EnableRealtimeAudioDetection(TRUE); //AUTO
                         msAPI_ATV_ChannelInfoEdit_EnableRealtimeAudioDetection(TRUE);
                     }
                     else
                     {
                        stGenSetting.stScanMenuSetting.u8SoundSystem=
                                (U8) MApp_ZUI_ACT_DecIncValue_Cycle(
                                            act==EN_EXE_INC_SYSTEM_OPTION,
                                            stGenSetting.stScanMenuSetting.u8SoundSystem,
                                            EN_ATV_SystemType_BG,
                                            EN_ATV_SystemType_MAX-1,
                                            1);
                     }
                 }
                 else
                 {
                     if(stGenSetting.stScanMenuSetting.u8SoundSystem == EN_ATV_SystemType_BG)
                     {
                        msAPI_AUD_EnableRealtimeAudioDetection(TRUE); //AUTO
                        msAPI_ATV_ChannelInfoEdit_EnableRealtimeAudioDetection(TRUE);
                     }
                     else
                     {
                        stGenSetting.stScanMenuSetting.u8SoundSystem=
                                (U8) MApp_ZUI_ACT_DecIncValue_Cycle(
                                            act==EN_EXE_INC_SYSTEM_OPTION,
                                            stGenSetting.stScanMenuSetting.u8SoundSystem,
                                            EN_ATV_SystemType_BG,
                                            EN_ATV_SystemType_MAX-1,
                                            1);
                     }
                 }
             }
            #endif

            if(msAPI_AUD_IsEnableRealtimeAudioDetection())
            {
                //msAPI_AUD_ATV_BeginAudioSystemAutoDetect(TRUE);
            }
            else
            {
                AUDIOSTANDARD_TYPE eSoundSystem;
                bIsAtuneActive = TRUE;
                switch (stGenSetting.stScanMenuSetting.u8SoundSystem)
                {
                    case EN_ATV_SystemType_BG:
                         eSoundSystem = E_AUDIOSTANDARD_BG;
                        break;

                    case EN_ATV_SystemType_I:
                         eSoundSystem = E_AUDIOSTANDARD_I;
                        break;

                    case EN_ATV_SystemType_DK:
                         eSoundSystem = E_AUDIOSTANDARD_DK;
                        break;

#if ( ENABLE_DTMB_CHINA_APP || ENABLE_DVB_TAIWAN_APP || ENABLE_ATV_CHINA_APP || ENABLE_SBTVD_BRAZIL_APP || ENABLE_DVBC_PLUS_DTMB_CHINA_APP || (TV_SYSTEM == TV_NTSC) )
                    case EN_ATV_SystemType_M:
                         eSoundSystem = E_AUDIOSTANDARD_M;
                        break;
#else
                    case EN_ATV_SystemType_L:
                         eSoundSystem = E_AUDIOSTANDARD_L;
                        break;
#endif
                    default:
      #if ( ENABLE_DTMB_CHINA_APP || ENABLE_ATV_CHINA_APP )
                         eSoundSystem = E_AUDIOSTANDARD_DK;
      #else
                         eSoundSystem = E_AUDIOSTANDARD_BG;
      #endif
                         break;
                }

                msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_INTERNAL_4_MUTEON, E_AUDIOMUTESOURCE_ATV);

                msAPI_Timer_Delayms(DELAY_FOR_ENTERING_MUTE);
                msAPI_AUD_EnableRealtimeAudioDetection(FALSE);
                msAPI_AUD_ForceAudioStandard((AUDIOSTANDARD_TYPE)eSoundSystem);
                msAPI_Tuner_UpdateMediumAndChannelNumber();
                msAPI_ATV_ChannelInfoEdit_SetAudioStandard(msAPI_AUD_GetAudioStandard());
                msAPI_Tuner_SetIF();

                msAPI_SetTunerPLL_KeepFreq();

                #if 0//((FRONTEND_IF_DEMODE_TYPE == MSTAR_VIF_MSB1210)||(FRONTEND_IF_DEMODE_TYPE == MSTAR_VIF)||(FRONTEND_IF_DEMODE_TYPE == MSTAR_INTERN_VIF))
                msAPI_SetTunerPLL();
                #endif
                msAPI_Timer_Delayms(DELAY_FOR_STABLE_SIF);
                msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_INTERNAL_4_MUTEOFF, E_AUDIOMUTESOURCE_ATV);
            }

         #else
             {
                 AUDIOSTANDARD_TYPE eSoundSystem;
                 EN_ATV_SYSTEM_TYPE enMaxATVsystemType;
                 #if ( ENABLE_DTMB_CHINA_APP || ENABLE_DVB_TAIWAN_APP || ENABLE_ATV_CHINA_APP || ENABLE_SBTVD_BRAZIL_APP || ENABLE_DVBC_PLUS_DTMB_CHINA_APP || (TV_SYSTEM == TV_NTSC) )
                 enMaxATVsystemType = EN_ATV_SystemType_M;
                 #else
                 enMaxATVsystemType = EN_ATV_SystemType_MAX-1;
                 #endif
                 bIsAtuneActive = TRUE;
#if ( ENABLE_DVB_TAIWAN_APP || ENABLE_SBTVD_BRAZIL_APP )
                 stGenSetting.stScanMenuSetting.u8SoundSystem = EN_ATV_SystemType_M;
#else
                 stGenSetting.stScanMenuSetting.u8SoundSystem=
                         (U8) MApp_ZUI_ACT_DecIncValue_Cycle(
                                     act==EN_EXE_INC_SYSTEM_OPTION,
                                     stGenSetting.stScanMenuSetting.u8SoundSystem,
                                     EN_ATV_SystemType_BG,
                                     enMaxATVsystemType,
                                     1);
#endif
                 switch (stGenSetting.stScanMenuSetting.u8SoundSystem)
                 {
                     case EN_ATV_SystemType_BG:
                          eSoundSystem = E_AUDIOSTANDARD_BG;
                         break;

                     case EN_ATV_SystemType_I:
                          eSoundSystem = E_AUDIOSTANDARD_I;
                         break;

                     case EN_ATV_SystemType_DK:
                          eSoundSystem = E_AUDIOSTANDARD_DK;
                         break;

 #if ( ENABLE_DTMB_CHINA_APP || ENABLE_DVB_TAIWAN_APP || ENABLE_ATV_CHINA_APP || ENABLE_SBTVD_BRAZIL_APP || ENABLE_DVBC_PLUS_DTMB_CHINA_APP || (TV_SYSTEM == TV_NTSC) )
                     case EN_ATV_SystemType_M:
                          eSoundSystem = E_AUDIOSTANDARD_M;
                         break;
 #else
                     case EN_ATV_SystemType_L:
                          eSoundSystem = E_AUDIOSTANDARD_L;
                         break;
 #endif
                     default:
       #if ( ENABLE_DTMB_CHINA_APP || ENABLE_ATV_CHINA_APP )
                          eSoundSystem = E_AUDIOSTANDARD_DK;
       #else
                          eSoundSystem = E_AUDIOSTANDARD_BG;
       #endif
                          break;
                 }

                 msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_INTERNAL_4_MUTEON, E_AUDIOMUTESOURCE_ATV);

                 msAPI_Timer_Delayms(DELAY_FOR_ENTERING_MUTE);
                 msAPI_AUD_EnableRealtimeAudioDetection(FALSE);
                 msAPI_AUD_ForceAudioStandard((AUDIOSTANDARD_TYPE)eSoundSystem);
                 msAPI_Tuner_UpdateMediumAndChannelNumber();
                 msAPI_ATV_ChannelInfoEdit_SetAudioStandard(msAPI_AUD_GetAudioStandard());
                 msAPI_Tuner_SetIF();

                 msAPI_SetTunerPLL_KeepFreq();

                 #if 0//((FRONTEND_IF_DEMODE_TYPE == MSTAR_VIF_MSB1210)||(FRONTEND_IF_DEMODE_TYPE == MSTAR_VIF)||(FRONTEND_IF_DEMODE_TYPE == MSTAR_INTERN_VIF))
                 msAPI_SetTunerPLL();
                 #endif
                 msAPI_Timer_Delayms(DELAY_FOR_STABLE_SIF);
                 msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_INTERNAL_4_MUTEOFF, E_AUDIOMUTESOURCE_ATV);

             }
         #endif
             MApp_ZUI_API_InvalidateWindow(HWND_MENU_CHANNEL_INFO_SOUND_SYSTEM);
             return TRUE;

            case EN_EXE_DEC_COLORSYSTEM_OPTION:
            case EN_EXE_INC_COLORSYSTEM_OPTION:
                {
    #if ( ENABLE_DVB_TAIWAN_APP || ENABLE_SBTVD_BRAZIL_APP )
                    if(msAPI_ATV_IsProgramAutoColorSystem(msAPI_ATV_GetCurrentProgramNumber()))
                    {
                        stGenSetting.stScanMenuSetting.u8VideoSystem_Brazil=E_VIDEOSTANDARD_BRAZIL_AUTO;
                    }
                    else
                    {
                        switch(msAPI_ATV_GetVideoStandardOfProgram(msAPI_ATV_GetCurrentProgramNumber()))
                        {
                            case E_VIDEOSTANDARD_NTSC_M:
                                stGenSetting.stScanMenuSetting.u8VideoSystem_Brazil=E_VIDEOSTANDARD_BRAZIL_NTSC_M;
                                break;
                            case E_VIDEOSTANDARD_PAL_N:
                                stGenSetting.stScanMenuSetting.u8VideoSystem_Brazil=E_VIDEOSTANDARD_BRAZIL_PAL_N;
                                break;
                            case E_VIDEOSTANDARD_PAL_M:
                                stGenSetting.stScanMenuSetting.u8VideoSystem_Brazil=E_VIDEOSTANDARD_BRAZIL_PAL_M;
                                break;
                            default:
                                ASSERT(0);
                                stGenSetting.stScanMenuSetting.u8VideoSystem_Brazil=E_VIDEOSTANDARD_BRAZIL_NTSC_M;
                                break;
                        }
                    }
                    stGenSetting.stScanMenuSetting.u8VideoSystem_Brazil=
                       (U8) MApp_ZUI_ACT_DecIncValue_Cycle(
                            act==EN_EXE_INC_SYSTEM_OPTION,
                            stGenSetting.stScanMenuSetting.u8VideoSystem_Brazil,
                            E_VIDEOSTANDARD_BRAZIL_NTSC_M,
                            E_VIDEOSTANDARD_BRAZIL_AUTO,
                            1);

                    if(stGenSetting.stScanMenuSetting.u8VideoSystem_Brazil==E_VIDEOSTANDARD_BRAZIL_AUTO)
                        msAPI_ATV_SetProgramAutoColorSystem(msAPI_ATV_GetCurrentProgramNumber(),TRUE);
                    else
                        msAPI_ATV_SetProgramAutoColorSystem(msAPI_ATV_GetCurrentProgramNumber(),FALSE);

                    msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_INTERNAL_4_MUTEON, E_AUDIOMUTESOURCE_ATV);
                    msAPI_Timer_Delayms(DELAY_FOR_ENTERING_MUTE);

                    switch(stGenSetting.stScanMenuSetting.u8VideoSystem_Brazil)
                    {
                        case E_VIDEOSTANDARD_BRAZIL_NTSC_M:
                           msAPI_AVD_SetVideoStandard (E_VIDEOSTANDARD_NTSC_M);
                           msAPI_ATV_SetVideoStandardOfProgram(msAPI_ATV_GetCurrentProgramNumber(),E_VIDEOSTANDARD_NTSC_M);
                        break;

                        case E_VIDEOSTANDARD_BRAZIL_PAL_M:
                           msAPI_AVD_SetVideoStandard (E_VIDEOSTANDARD_PAL_M);
                           msAPI_ATV_SetVideoStandardOfProgram(msAPI_ATV_GetCurrentProgramNumber(),E_VIDEOSTANDARD_PAL_M);
                        break;

                        case E_VIDEOSTANDARD_BRAZIL_PAL_N:
                           msAPI_AVD_SetVideoStandard (E_VIDEOSTANDARD_PAL_N);
                           msAPI_ATV_SetVideoStandardOfProgram(msAPI_ATV_GetCurrentProgramNumber(),E_VIDEOSTANDARD_PAL_N);
                        break;

                        default:
                           msAPI_AVD_StartAutoStandardDetection();
                           msAPI_AVD_GetResultOfAutoStandardDetection();
                           msAPI_ATV_SetVideoStandardOfProgram(msAPI_ATV_GetCurrentProgramNumber(),msAPI_AVD_GetResultOfAutoStandardDetection());
                        break;
                    }

                    msAPI_Tuner_UpdateMediumAndChannelNumber();
                    msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_INTERNAL_4_MUTEOFF, E_AUDIOMUTESOURCE_ATV);

                    stGenSetting.stScanMenuSetting.u8RFChannelNumber = msAPI_Tuner_GetChannelNumber();
                    stGenSetting.stScanMenuSetting.u8ATVMediumType = (EN_ATV_BAND_TYPE)msAPI_Tuner_GetMedium();
                    stGenSetting.stScanMenuSetting.u8LSystem = FALSE;
                    MApp_ZUI_API_InvalidateWindow(HWND_ATUNE_VIDEOSYSTEM_OPTION);
    #else
                #ifdef ENABLE_CUS_AV_COLOR_SYSTEM
                    if(IsAVInUse())
                    {
                        AVD_VideoStandardType eVideoStandard;
                        stGenSetting.g_SysSetting.enAVColorSystem = (EN_ATV_COLOR_SYSTEM)MApp_ZUI_ACT_DecIncValue_Cycle(
                                (BOOLEAN)(act==EN_EXE_INC_COLORSYSTEM_OPTION),(U16)stGenSetting.g_SysSetting.enAVColorSystem,
                                (U16)ATV_COLOR_AUTO,(U16)ATV_COLOR_SECAM,1);
                        //printf("==eColorSystem=%d==\n",eColorSystem);
                        if((stGenSetting.g_SysSetting.enAVColorSystem == ATV_COLOR_PAL_M) || (stGenSetting.g_SysSetting.enAVColorSystem == ATV_COLOR_PAL_N))
                        {
                            if(act==EN_EXE_INC_COLORSYSTEM_OPTION)
                            {
                                stGenSetting.g_SysSetting.enAVColorSystem = ATV_COLOR_PAL_60;
                            }
                            else
                            {
                                stGenSetting.g_SysSetting.enAVColorSystem = ATV_COLOR_PAL;
                            }
                        }

                        switch(stGenSetting.g_SysSetting.enAVColorSystem)
                        {
                            case ATV_COLOR_PAL:
                                eVideoStandard = E_VIDEOSTANDARD_PAL_BGHI;
                                break;
                            case ATV_COLOR_PAL_M:
                                eVideoStandard = E_VIDEOSTANDARD_PAL_M;
                                break;
                            case ATV_COLOR_PAL_N:
                                eVideoStandard = E_VIDEOSTANDARD_PAL_N;
                                break;
                            case ATV_COLOR_PAL_60:
                                eVideoStandard = E_VIDEOSTANDARD_PAL_60;
                                break;
                            case ATV_COLOR_NTSC:
                                eVideoStandard = E_VIDEOSTANDARD_NTSC_M;
                                break;
                            case ATV_COLOR_NTSC_44:
                                eVideoStandard = E_VIDEOSTANDARD_NTSC_44;
                                break;
                            case ATV_COLOR_SECAM:
                                eVideoStandard = E_VIDEOSTANDARD_SECAM;
                                break;
                            case ATV_COLOR_AUTO:
                            default:
                                eVideoStandard = E_VIDEOSTANDARD_AUTO;
                                break;
                        }

                        if(eVideoStandard == E_VIDEOSTANDARD_AUTO)
                        {
                            AVD_VideoStandardType eStandard;
                            MDrv_AVD_SetVideoStandard(eVideoStandard, FALSE);
                            msAPI_AVD_StartAutoStandardDetection();
                            eStandard = msAPI_AVD_GetStandardDetection();
                        }
                        else
                        {
                            msAPI_AVD_ForceVideoStandard(eVideoStandard);
                            MDrv_AVD_SetVideoStandard(eVideoStandard, FALSE );
                        }
                        MApp_ZUI_API_InvalidateWindow(MApp_ZUI_API_GetFocus());
                        return TRUE;
                    }
                    else if(IsATVInUse())
                    {
                        AVD_VideoStandardType eVideoStandard;
                        #if (TV_FREQ_SHIFT_CLOCK)
                        msAPI_Tuner_Patch_ResetTVShiftClk();
                        #endif
                        eVideoStandard = msAPI_ATV_ChannelInfoEdit_GetVideoStandard();
                        if(EN_EXE_INC_COLORSYSTEM_OPTION == act)
                        {
                            if(eVideoStandard == E_VIDEOSTANDARD_AUTO)
                            {
                                eVideoStandard = E_VIDEOSTANDARD_PAL_BGHI;
                            }
                            else if(eVideoStandard == E_VIDEOSTANDARD_PAL_BGHI)
                            {
                                eVideoStandard = E_VIDEOSTANDARD_PAL_60;
                            }
                            else if(eVideoStandard == E_VIDEOSTANDARD_PAL_60)
                            {
                                eVideoStandard = E_VIDEOSTANDARD_NTSC_M;
                            }
                            else if(eVideoStandard == E_VIDEOSTANDARD_NTSC_M)
                            {
                                eVideoStandard = E_VIDEOSTANDARD_NTSC_44;
                            }
                            else if(eVideoStandard == E_VIDEOSTANDARD_NTSC_44)
                            {
                                eVideoStandard = E_VIDEOSTANDARD_SECAM;
                            }
                            else if(eVideoStandard == E_VIDEOSTANDARD_SECAM)
                            {
                                eVideoStandard = E_VIDEOSTANDARD_AUTO;
                            }
                        }
                        else
                        {
                            if(eVideoStandard == E_VIDEOSTANDARD_AUTO)
                            {
                                eVideoStandard = E_VIDEOSTANDARD_SECAM;
                            }
                            else if(eVideoStandard == E_VIDEOSTANDARD_SECAM)
                            {
                                eVideoStandard = E_VIDEOSTANDARD_NTSC_44;
                            }
                            else if(eVideoStandard == E_VIDEOSTANDARD_NTSC_44)
                            {
                                eVideoStandard = E_VIDEOSTANDARD_NTSC_M;
                            }
                            else if(eVideoStandard == E_VIDEOSTANDARD_NTSC_M)
                            {
                                eVideoStandard = E_VIDEOSTANDARD_PAL_60;
                            }
                            else if(eVideoStandard == E_VIDEOSTANDARD_PAL_60)
                            {
                                eVideoStandard = E_VIDEOSTANDARD_PAL_BGHI;
                            }
                            else if(eVideoStandard == E_VIDEOSTANDARD_PAL_BGHI)
                            {
                                eVideoStandard = E_VIDEOSTANDARD_AUTO;
                            }
                        }

                        if(eVideoStandard == E_VIDEOSTANDARD_AUTO)
                        {
                            AVD_VideoStandardType eStandard;
                            MDrv_AVD_SetVideoStandard(eVideoStandard, FALSE);
                            msAPI_AVD_StartAutoStandardDetection();
                            eStandard = msAPI_AVD_GetStandardDetection();
                            msAPI_ATV_ChannelInfoEdit_SetVideoStandard(eVideoStandard);
                        }
                        else
                        {
                            msAPI_AVD_ForceVideoStandard(eVideoStandard);
                            MDrv_AVD_SetVideoStandard(eVideoStandard, FALSE );
                            msAPI_ATV_ChannelInfoEdit_SetVideoStandard(eVideoStandard);
                        }
                        MApp_ZUI_API_InvalidateWindow(MApp_ZUI_API_GetFocus());
                        return TRUE;
                    }
                #endif

#endif
                }
                return TRUE;

            case EN_EXE_PREDIT_MENU:
                MApp_ZUI_API_ShowWindow(HWND_MENU_PREDIT_CHANNEL_NAME_PAGE, SW_HIDE);
                MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_INFO_PAGE, SW_SHOW);
                MApp_ZUI_API_SetFocus(HWND_MENU_CHANNEL_INFO_CH_NAME);
                return TRUE;
            case EN_EXE_DEC_ATV_MTS_HOTKEY_OPTION:
            case EN_EXE_INC_ATV_MTS_HOTKEY_OPTION:
                {
                    msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_INTERNAL_4_MUTEON, E_AUDIOMUTESOURCE_ACTIVESOURCE);
                    msAPI_Timer_Delayms(DELAY_FOR_ENTERING_MUTE);
                    msAPI_AUD_AdjustAudioFactor(E_ADJUST_CHANGE_AUDIOMODE, 0, 0);
                    msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_INTERNAL_4_MUTEOFF, E_AUDIOMUTESOURCE_ACTIVESOURCE);

                    MApp_ZUI_API_InvalidateWindow(HWND_MENU_CHANNEL_PAGE2_MTS);
                }
                return TRUE;

            case EN_EXE_ATV_MANUAL_SCAN_FINETUNE_UP:
                bIsAtuneActive = FALSE;
                if(g_bIsImageFrozen)
                {
                    g_bIsImageFrozen = FALSE;
                    MApi_XC_FreezeImg(g_bIsImageFrozen, MAIN_WINDOW);
                }
                msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE,E_AUDIO_INTERNAL_2_MUTEON,E_AUDIOMUTESOURCE_ATV);
                msAPI_Tuner_SetTunerPLLValue(msAPI_ATV_ChannelInfoEdit_GetPLL());
                msAPI_Tuner_AdjustUnlimitedFineTune(DIRECTION_UP);
                msAPI_Timer_Delayms(20);
                msAPI_ATV_ChannelInfoEdit_SetPLL(msAPI_Tuner_GetCurrentChannelPLL());
                msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE,E_AUDIO_INTERNAL_2_MUTEOFF,E_AUDIOMUTESOURCE_ATV);
                MApp_ZUI_API_InvalidateWindow(HWND_MENU_CHANNEL_FINETUNE_CH_FREQ_VALUE);
                return TRUE;

            case EN_EXE_ATV_MANUAL_SCAN_FINETUNE_DOWN:
                bIsAtuneActive = FALSE;
                if(g_bIsImageFrozen)
                {
                    g_bIsImageFrozen = FALSE;
                    MApi_XC_FreezeImg(g_bIsImageFrozen, MAIN_WINDOW);
                }
                msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE,E_AUDIO_INTERNAL_2_MUTEON,E_AUDIOMUTESOURCE_ATV);
                msAPI_Tuner_SetTunerPLLValue(msAPI_ATV_ChannelInfoEdit_GetPLL());
                msAPI_Tuner_AdjustUnlimitedFineTune(DIRECTION_DOWN);
                msAPI_Timer_Delayms(20);
                msAPI_ATV_ChannelInfoEdit_SetPLL(msAPI_Tuner_GetCurrentChannelPLL());
                msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE,E_AUDIO_INTERNAL_2_MUTEOFF,E_AUDIOMUTESOURCE_ATV);
                MApp_ZUI_API_InvalidateWindow(HWND_MENU_CHANNEL_FINETUNE_CH_FREQ_VALUE);
                return TRUE;

            case EN_EXE_SAVE_ATV_MANUAL_SCAN:
                {
                    msAPI_ATV_SetProgramPLLData(msAPI_ATV_GetCurrentProgramNumber(), msAPI_Tuner_GetCurrentChannelPLL());
                    msAPI_ATV_ChannelInfoEdit_SetPLL(msAPI_Tuner_GetCurrentChannelPLL());
                    msAPI_ATV_ChannelInfoEdit_SetAFT(FALSE);
                    msAPI_ATV_NeedAFT((msAPI_ATV_ChannelInfoEdit_GetCHNum()-1), FALSE);
                }
                MApp_ZUI_API_InvalidateWindow(HWND_MENU_CHANNEL_FINETUNE_CH_FREQ_VALUE);
		  MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_GOTO_PARENTPAGE);
                return TRUE;
        default:
            ZUI_DBG_FAIL(printf("[ZUI]MENUACT:%u/%u\n", act,(U16)EN_EXE_MAX));
            //ABORT();


    }
    return FALSE;
}

U16 _MApp_ZUI_ACT_GetAudioModeStringID(void)
{
    U16 u16TempID = Empty;
    {
        switch(stGenSetting.g_SoundSetting.SoundMode)
        {
            case EN_SoundMode_Standard:
                u16TempID=en_str_AudioStandardText;
                break;
            case EN_SoundMode_Music:
                u16TempID=en_str_AudioMusicText;
                break;
            case EN_SoundMode_Movie:
                u16TempID=en_str_AudioFilmText;
                break;
            case EN_SoundMode_Sports:
                u16TempID= en_str_AudioSpeechText;//en_str_AudioSportsText;
                break;
            case EN_SoundMode_User:
                u16TempID=en_str_Sound_User;
                break;
            default:
            break;

        }
    }
    #if ENABLE_AUTOTEST
    if(g_bAutobuildDebug)
    {
        if(SoundMenu != u16TempID)
        {
            printf("51_SoundMenu\n");
        }
        SoundMenu = u16TempID;
    }
    #endif
    return u16TempID;
}

U16 _MApp_ZUI_ACT_GetAspectRatioStringID(void)
{
    U16 u16TempID = Empty;
    //from case B5_ASPECTRATIO_SELECTTEXT:

    switch(ST_VIDEO.eAspectRatio) //MApp_UiMenuFunc_GetenB5_AspectRatioValue())
    {
        case EN_AspectRatio_Original:
            u16TempID=en_str_AspectRatio_Original;
            break;
        case EN_AspectRatio_4X3:
            u16TempID=en_str_AspectRatio_4X3;
            break;
        case EN_AspectRatio_16X9:
            u16TempID=en_str_AspectRatio_16X9;
            break;
        case EN_AspectRatio_14X9:
            u16TempID=en_str_AspectRatio_14x9;
            break;
        case EN_AspectRatio_Zoom1:
            u16TempID=en_str_AspectRatio_Zoom1;
            break;
        case EN_AspectRatio_Zoom2:
            u16TempID=en_str_AspectRatio_Zoom2;
            break;
        case EN_AspectRatio_JustScan:
            u16TempID=en_str_AspectRatio_JustScan;
            break;
       case EN_AspectRatio_Panorama:
            u16TempID=en_str_AspectRatio_Panorama;
            break;
        #if VGA_HDMI_YUV_POINT_TO_POINT
        case EN_AspectRatio_point_to_point:
            u16TempID=en_str_AspectRatio_PointToPoint;
            break;
      #endif
        default: //wrong aspect radio
            u16TempID=en_strLL;
            break;
    }

    #if ENABLE_AUTOTEST
    if(g_bAutobuildDebug)
    {
        switch(tempcheck2)
        {
            case HWND_MENU_PICTURE_ASPECT_RATIO_OPTION:
                if(AspectR != u16TempID)
                {
                    printf("43_AspectRatio\n");
                }
                AspectR = u16TempID;
                break;

            default:
                break;
        }
    }
    #endif
    return u16TempID;
}

U16 _MApp_ZUI_ACT_GetPictureModeStringID(void)
{
    U16 u16TempID = Empty;
    //from case B1_PICTURE_SELECTTEXT:
    switch(ST_VIDEO.ePicture)
    {
        default:
        case PICTURE_DYNAMIC:
            u16TempID=en_str_Picture_Daylight;
            break;
        case PICTURE_NORMAL:
            u16TempID=en_str_Picture_Normal;
            break;
        case PICTURE_MILD:
            u16TempID=en_str_Picture_NightTime;
            break;
    #if ENABLE_PICTURE_MODE_ENERGY_SAVING
        case PICTURE_ENERGY_SAVING:
            u16TempID=en_str_Picture_Energysaving;
            break;
    #endif
        case PICTURE_USER:
    #if PICTURE_USER_2
             u16TempID=en_str_Picture_User;
    #else
            u16TempID=en_str_Sound_User;
    #endif
            break;
    #if PICTURE_USER_2
        case PICTURE_USER2:
            u16TempID=en_str_Picture_User2;
            break;
    #endif
    }
    #if ENABLE_AUTOTEST
    if(g_bAutobuildDebug)
    {
        switch(tempcheck2)
        {
            case HWND_MENU_PICTURE_PICMODE_OPTION:
                if(PicMode != u16TempID)
                {
                    printf("41_PictureMode\n");
                }
                PicMode = u16TempID;
                break;

            default:
                break;
        }
    }
    #endif
    return u16TempID;
}

#if(UI_SKIN_SEL==UI_SKIN_1366X768X565_HAIER_CN) // cus_xm helen add 20120809
U16 _MApp_ZUI_ACT_GetREPEATStringID(void)// helen add
{
    U16 u16TempID = Empty;
    //from case B1_PICTURE_SELECTTEXT:
    enumMPlayerRepeatMode eRepeatMode = MApp_MPlayer_QueryRepeatMode();
    switch(eRepeatMode)
    {
        default:
        case E_MPLAYER_REPEAT_NONE:
            u16TempID=en_str_DMP_AB_NONE;
            break;
        case E_MPLAYER_REPEAT_1:
            u16TempID=en_str_RepeatOne;
            break;
        case E_MPLAYER_REPEAT_ALL:
            u16TempID=en_str_RepeatAll;
            break;

    }

    return u16TempID;
}
#endif
static U16 _MApp_ZUI_ACT_GetColorTempColorValue(HWND hwnd)
{
    switch(hwnd)
    {
        case HWND_MENU_PIC_ADJ_TEMP_RED_OPTION:
        case HWND_MENU_PICCOLOR_COLOR_RED_OPTION:
            //from case EN_DNUM_Getu16B2_ColorTemp_User_RedValue_Percent:
        #if(MS_COLOR_TEMP_COUNT ==4)
            if (ST_PICTURE.eColorTemp == MS_COLOR_TEMP_USER)
                return ST_COLOR_TEMP.cRedScaleValue;
            else
        #endif
                return GetScale100Value(ST_COLOR_TEMP.cRedColor,MIN_USER_RGB, MAX_USER_RGB);

        case HWND_MENU_PIC_ADJ_TEMP_GREEN_OPTION:
        case HWND_MENU_PICCOLOR_COLOR_GREEN_OPTION:
            //from case EN_DNUM_Getu16B2_ColorTemp_User_GreenValue_Percent:
        #if(MS_COLOR_TEMP_COUNT ==4)
            if (ST_PICTURE.eColorTemp == MS_COLOR_TEMP_USER)
                return ST_COLOR_TEMP.cGreenScaleValue;
            else
        #endif
                return GetScale100Value(ST_COLOR_TEMP.cGreenColor,MIN_USER_RGB, MAX_USER_RGB);

        case HWND_MENU_PIC_ADJ_TEMP_BLUE_OPTION:
        case HWND_MENU_PICCOLOR_COLOR_BLUE_OPTION:
            //from case EN_DNUM_Getu16B2_ColorTemp_User_BlueValue_Percent:
        #if(MS_COLOR_TEMP_COUNT ==4)
            if (ST_PICTURE.eColorTemp == MS_COLOR_TEMP_USER)
                return ST_COLOR_TEMP.cBlueScaleValue;
            else
        #endif
                return GetScale100Value(ST_COLOR_TEMP.cBlueColor,MIN_USER_RGB, MAX_USER_RGB);

    }
    return 0;
}

static U16 MApp_ZUI_ACT_GetPcModeAdjustValue(HWND hwnd)
{
    switch(hwnd)
    {
        //case HWND_MENU_PCMODE_SIZE_BAR:
        case HWND_MENU_PCMODE_ADJUST_CLOCK :
        case HWND_MENU_PCMODE_ADJUST_CLOCK_SLIDER_BAR :
        case HWND_MENU_PCMODE_ADJUST_CLOCK_VALUE:
        //from case EN_DNUM_Getu16B7_PCMenu_SizeValue:
        {
            if(IsSrcTypeVga(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW))||IsSrcTypeYPbPr(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)))
            {
                stLMGenSetting.stMB.u16B7_PCMenu_Size = msAPI_Mode_GetPcClockValue( MAIN_WINDOW, g_PcadcModeSetting[MAIN_WINDOW].u16HorizontalTotal);
            }
            #if (ENABLE_PIP)
            else if(IsPIPEnable()&& (IsSrcTypeVga(SYS_INPUT_SOURCE_TYPE(SUB_WINDOW))||IsSrcTypeYPbPr(SYS_INPUT_SOURCE_TYPE(SUB_WINDOW))))
            {
                stLMGenSetting.stMB.u16B7_PCMenu_Size = msAPI_Mode_GetPcClockValue( SUB_WINDOW, g_PcadcModeSetting[SUB_WINDOW].u16HorizontalTotal);
            }
            #endif
            return stLMGenSetting.stMB.u16B7_PCMenu_Size;
        } break;

        //case HWND_MENU_PCMODE_PHASE_BAR:
        case HWND_MENU_PCMODE_ADJUST_PHASE:
        case HWND_MENU_PCMODE_ADJUST_PHASE_SLIDER_BAR:
        case HWND_MENU_PCMODE_ADJUST_PHASE_VALUE:
        //from case EN_DNUM_Getu16B7_PCMenu_PhaseValue:
        {
            if(IsSrcTypeVga(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW))||IsSrcTypeYPbPr(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)))
            {
                stLMGenSetting.stMB.u16B7_PCMenu_Phase = msAPI_Mode_GetPcPhaseValue(g_PcadcModeSetting[MAIN_WINDOW].u16Phase);
            }
            #if (ENABLE_PIP)
            else if(IsPIPEnable()&& (IsSrcTypeVga(SYS_INPUT_SOURCE_TYPE(SUB_WINDOW))||IsSrcTypeYPbPr(SYS_INPUT_SOURCE_TYPE(SUB_WINDOW))))
            {
                stLMGenSetting.stMB.u16B7_PCMenu_Phase = msAPI_Mode_GetPcPhaseValue(g_PcadcModeSetting[SUB_WINDOW].u16Phase);
            }
            #endif
            return stLMGenSetting.stMB.u16B7_PCMenu_Phase;
        } break;

        //case HWND_MENU_PCMODE_HPOS_BAR:
        case HWND_MENU_PCMODE_ADJUST_H_POS:
        case HWND_MENU_PCMODE_ADJUST_H_POS_SLIDER_BAR:
        case HWND_MENU_PCMODE_ADJUST_H_POS_VALUE:
        //from case EN_DNUM_Getu16B7_PCMenu_PositionH:
        {
            U32 tmp;
            #if (ENABLE_PIP)
            if(IsPIPEnable()&& (IsSrcTypeVga(SYS_INPUT_SOURCE_TYPE(SUB_WINDOW))||IsSrcTypeYPbPr(SYS_INPUT_SOURCE_TYPE(SUB_WINDOW))))
            {
                tmp = g_PcadcModeSetting[SUB_WINDOW].u16HorizontalStart;
                tmp = (tmp - MIN_PC_H_START(SUB_WINDOW) ) * 100 / ( MAX_PC_H_START(SUB_WINDOW) - MIN_PC_H_START(SUB_WINDOW) );//46lu) * 100lu / 292lu;
            }
            else
            #endif
            {
                tmp = g_PcadcModeSetting[MAIN_WINDOW].u16HorizontalStart;
                tmp = (tmp - MIN_PC_H_START(MAIN_WINDOW) ) * 100 / ( MAX_PC_H_START(MAIN_WINDOW) - MIN_PC_H_START(MAIN_WINDOW) );//46lu) * 100lu / 292lu;
            }

            return tmp;
        } break;

        //case HWND_MENU_PCMODE_VPOS_BAR:
        case HWND_MENU_PCMODE_ADJUST_V_POS:
        case HWND_MENU_PCMODE_ADJUST_V_POS_SLIDER_BAR:
        case HWND_MENU_PCMODE_ADJUST_V_POS_VALUE:
        //from case EN_DNUM_Getu16B7_PCMenu_PositionV:
        {
            U32 tmp;
            #if (ENABLE_PIP)
            if(IsPIPEnable()&& (IsSrcTypeVga(SYS_INPUT_SOURCE_TYPE(SUB_WINDOW))||IsSrcTypeYPbPr(SYS_INPUT_SOURCE_TYPE(SUB_WINDOW))))
            {
                tmp = g_PcadcModeSetting[SUB_WINDOW].u16VerticalStart;
                tmp = (tmp - MIN_PC_V_START ) * 100 / ( MAX_PC_V_START(SUB_WINDOW) - MIN_PC_V_START );//46lu) * 100lu / 292lu;
            }
            else
            #endif
            {
                tmp = g_PcadcModeSetting[MAIN_WINDOW].u16VerticalStart;
                tmp = (tmp - MIN_PC_V_START ) * 100 / ( MAX_PC_V_START(MAIN_WINDOW) - MIN_PC_V_START );//46lu) * 100lu / 292lu;
            }


            return tmp;
        } break;
    }
    return 0;
}

static U16 _MApp_ZUI_ACT_GetSoundAdjustValue(HWND hwnd)
{
    #if ENABLE_AUTOTEST
    if(g_bAutobuildDebug)
    {
        switch(tempcheck2)
        {
            case HWND_MENU_SNDMODE_TREBLE_OPTION:
                if(SoundMenuT != stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].Treble)
                {
                    printf("51_SoundMenuTreble\n");
                }
                SoundMenuT = stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].Treble;
                break;

            case HWND_MENU_SNDMODE_BASS_OPTION:
                if(SoundMenuB != stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].Bass)
                {
                    printf("51_SoundMenuBass\n");
                }
                SoundMenuB = stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].Bass;
                break;

            default:
                break;
        }
    }
    #endif

    switch(hwnd)
    {
        case HWND_MENU_SNDMODE_TREBLE_OPTION:
            return (
                stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].Treble);

        case HWND_MENU_SNDMODE_BASS_OPTION:
            return (
                stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].Bass);

        case HWND_MENU_SNDEQ_120_HZ_OPTION:
            return (
                stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].u8120HZ);

        case HWND_MENU_SNDEQ_500_HZ_OPTION:
            return (
                stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].u8500HZ);

        case HWND_MENU_SNDEQ_1_2_KHZ_OPTION:
            return (
                stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].u8_1_dot_5_KHZ);

        case HWND_MENU_SNDEQ_7_5_KHZ_OPTION:
            return (
                stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].u8_5KHZ);

        case HWND_MENU_SNDEQ_12_KHZ_OPTION:
            return (
                stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].u810KHZ);

        case HWND_MENU_SOUND_BALANCE_OPTION:
            return (
                stGenSetting.g_SoundSetting.Balance);

    }
    return 0;
}

U16 _MApp_ZUI_ACT_GetBalanceValue(void)
{
       return (stGenSetting.g_SoundSetting.Balance);
}

static  OSDCP_EN_STRING_INDEX _ZUI_TBLSEG _WeekString[7]=
{
    en_str_Sunday,
    en_str_Monday,
    en_str_Tuesday,
    en_str_Wednesday,
    en_str_Thursday,
    en_str_Friday,
    en_str_Saturday,
};

void _MApp_ZUI_ACT_LoadWeekString(U8 month, LPTSTR str)
{
    MApp_ZUI_API_LoadString(_WeekString[month], str);
}


static  OSDCP_EN_STRING_INDEX _ZUI_TBLSEG _MonthString[12] =
{
    en_str_Month_Jan,
    en_str_Month_Feb,
    en_str_Month_Mar,
    en_str_Month_Apr,
    en_str_Month_May,
    en_str_Month_Jun,
    en_str_Month_Jul,
    en_str_Month_Aug,
    en_str_Month_Sep,
    en_str_Month_Oct,
    en_str_Month_Nov,
    en_str_Month_Dec
};

void _MApp_ZUI_ACT_LoadMonthString(U8 month, LPTSTR str)
{
    MApp_ZUI_API_LoadString(_MonthString[month], str);
}

LPTSTR _MApp_ZUI_ACT_GetLocalClockDateString(LPTSTR str)
{
    ST_TIME _stTime;

        //format:  DAY/MON     HOUR:MIN
        //format:   --   --      --   --

    //only do it just one time...
    MApp_ConvertSeconds2StTime(MApp_GetLocalSystemTime(),&_stTime);


    //from case D1_OPTION_DAYVALUETEXT:
    if((g_u8TimeInfo_Flag & UI_TIME_DAY_SET)
#if ENABLE_DTV
        || MApp_SI_IsAutoClockValid()
#endif
        )
    {
        stLMGenSetting.stMD.u16Option_Info_Day=_stTime.u8Day;
        __MApp_UlongToString((U16)stLMGenSetting.stMD.u16Option_Info_Day, str, 2);
        str += 2;
    }
    else
    {
        MApp_ZUI_API_LoadString(en_strLL, str);
        str += MApp_ZUI_API_Strlen(str);
    }

    //from case D1_OPTION_DAYSLASHTEXT:
    //from case D1_OPTION_MONTHVALUETEXT:
    if(((g_u8TimeInfo_Flag & UI_TIME_MONTH_SET) && (g_u8TimeInfo_Flag & UI_TIME_MINUTE_SET))
#if ENABLE_DTV
        || MApp_SI_IsAutoClockValid()
#endif
        )
    {
        MApp_ZUI_API_LoadString(en_strSlash, str);
        str += MApp_ZUI_API_Strlen(str);

        stLMGenSetting.stMD.u16Option_Info_Month=_stTime.u8Month;
        _MApp_ZUI_ACT_LoadMonthString(stLMGenSetting.stMD.u16Option_Info_Month-1, str);
        str += MApp_ZUI_API_Strlen(str);
    }
    else
    {
        *str++ = CHAR_SPACE;
        *str++ = CHAR_SPACE;

        MApp_ZUI_API_LoadString(en_strLL, str);
        str += MApp_ZUI_API_Strlen(str);
    }

    return str;

}

LPTSTR _MApp_ZUI_ACT_GetLocalClockTimeString(LPTSTR str)
{
    ST_TIME _stTime;

        //format:  DAY/MON     HOUR:MIN
        //format:   --   --      --   --

    //only do it just one time...
    MApp_ConvertSeconds2StTime(MApp_GetLocalSystemTime(),&_stTime);

    //from case D1_OPTION_HOURVALUETEXT:
    //U16 u16Hour;
    /*
    if ((g_u8TimeInfo_Flag & UI_TIME_HOUR_SET)
#if ENABLE_DTV
        || MApp_SI_IsAutoClockValid()
#endif
        )
        */
    {
        MApp_ConvertSeconds2StTime(MApp_GetLocalSystemTime(), &_stTime);
        stLMGenSetting.stMD.u16Option_Info_Hour=_stTime.u8Hour;
        //u16Hour = stLMGenSetting.stMD.u16Option_Info_Hour;
        if (stLMGenSetting.stMD.u16Option_Info_Hour >= 12)
        {
            //u16Hour = stLMGenSetting.stMD.u16Option_Info_Hour - 12;
            stLMGenSetting.stMD.bTimer_Info_PM |= UI_TIME_CLOCK_PM;
        }
        else
        {
           // u16Hour = stLMGenSetting.stMD.u16Option_Info_Hour;
            stLMGenSetting.stMD.bTimer_Info_PM &= ~UI_TIME_CLOCK_PM;
        }

        //if(u16Hour == 0)
        //    u16Hour = 12;

        __MApp_UlongToString((U16)stLMGenSetting.stMD.u16Option_Info_Hour, str, 2);
        str += 2;
    }
	/*
    else
    {
        MApp_ZUI_API_LoadString(en_strLL, str);
        str += MApp_ZUI_API_Strlen(str);
    }
*/
    //from case D_OPTION_TIME_INFO_COLON_TEXT:
    //from case D1_OPTION_MINVALUETEXT:
    /*
    if ((g_u8TimeInfo_Flag & UI_TIME_MINUTE_SET)
#if ENABLE_DTV
        || MApp_SI_IsAutoClockValid()
#endif
        )
        */
    {
        MApp_ZUI_API_LoadString(en_strColonText, str);
        str += MApp_ZUI_API_Strlen(str);

        stLMGenSetting.stMD.u16Option_Info_Min = _stTime.u8Min;
        __MApp_UlongToString((U16)stLMGenSetting.stMD.u16Option_Info_Min, str, 2);
        str += 2;
    }
	/*
    else
    {
        *str++ = CHAR_SPACE;
        *str++ = CHAR_SPACE;

        MApp_ZUI_API_LoadString(en_strLL, str);
        str += MApp_ZUI_API_Strlen(str);
    }
*/
    return str;
}

#if 0 // no used
static LPTSTR _MApp_ZUI_ACT_GetLocalClockString(void)
{
    LPTSTR str = CHAR_BUFFER;
    str = _MApp_ZUI_ACT_GetLocalClockDateString(str);

    *str++ = CHAR_SPACE;
    *str++ = CHAR_SPACE;
    *str++ = CHAR_SPACE;
    *str++ = CHAR_SPACE;

    str = _MApp_ZUI_ACT_GetLocalClockTimeString(str);
    *str = 0;
    #if ENABLE_AUTOTEST
    if(g_bAutobuildDebug)
    {
        if(OSDClock == 1)
        {
            printf("61_Clock\n");
            OSDClock = 0;
        }
        else
            OSDClock = 1;
    }
    #endif
    return CHAR_BUFFER;
}
#endif
extern void _MApp_ZUI_ACT_GetSleepTimerString(LPTSTR str);
#if ENABLE_CUS_AUTO_SLEEP_MODE
extern void _MApp_ZUI_ACT_GetAutosleepString(LPTSTR str);
#endif

#if (ENABLE_CUS_UI_SPEC == FALSE) /*Creass.liu at 2012-06-27*/
#if (ENABLE_SBTVD_BRAZIL_APP ==0)
static  OSDCP_EN_STRING_INDEX _ZUI_TBLSEG _TimezoneString[] =
{
    en_str_TimeZone_Text_G00,
    en_str_TimeZone_Text_G01,
    en_str_TimeZone_Text_G02,
    en_str_TimeZone_Text_G03,
    en_str_TimeZone_Text_G10,
    en_str_TimeZone_Text_G11,
    en_str_TimeZone_Text_G12,
    en_str_TimeZone_Text_G13,
    en_str_TimeZone_Text_G14,
    en_str_TimeZone_Text_G20,
    en_str_TimeZone_Text_G21,
    en_str_TimeZone_Text_G22,
    en_str_TimeZone_Text_G30,
    en_str_TimeZone_Text_G31,
    en_str_TimeZone_Text_G32,
    en_str_TimeZone_Text_G40,
    en_str_TimeZone_Text_G41,
    en_str_TimeZone_Text_G42,
    en_str_TimeZone_Text_G43,
    en_str_TimeZone_Text_G44,
    en_str_TimeZone_Text_G50,
    en_str_TimeZone_Text_G51,
    en_str_TimeZone_Text_G52,
    en_str_TimeZone_Text_G60,
    en_str_TimeZone_Text_G61,
    en_str_TimeZone_Text_G62,
    en_str_TimeZone_Text_G70,
    en_str_TimeZone_Text_G71,
    en_str_TimeZone_Text_G72,
    en_str_TimeZone_Text_G73,
    en_str_TimeZone_Text_G74,
    en_str_TimeZone_Text_G76,
    en_str_TimeZone_Text_G77,
    en_str_TimeZone_Text_G75,
    en_str_TimeZone_Text_G80,
    en_str_TimeZone_Text_G78,
    en_str_TimeZone_Text_G79,
    en_str_TimeZone_Text_G85,
    en_str_TimeZone_Text_G97,
    en_str_TimeZone_Text_G84,
    en_str_TimeZone_Text_G87,
    en_str_TimeZone_Text_G81,
    en_str_TimeZone_Text_G82,
    en_str_TimeZone_Text_G83,
    en_str_TimeZone_Text_G86,
    en_str_TimeZone_Text_G88,
    en_str_TimeZone_Text_G89,
};
#endif

U16 _MApp_ZUI_ACT_GetTimeZoneStringID(EN_MENU_TIMEZONE timezone)
{
#if (ENABLE_SBTVD_BRAZIL_APP ==0)
        if(TIMEZONE_NUM <= timezone )
        {
            return 0;
        }
        else
        {
            if(timezone < (EN_MENU_TIMEZONE)(sizeof(_TimezoneString)/sizeof(OSDCP_EN_STRING_INDEX)))
            {
                return _TimezoneString[timezone];
            }
            else
            {
                return 0;
            }
        }
#else
        switch(timezone)
        {
           case TIMEZONE_AM_WEST:
                return en_str_TimeZone_Text_G90;

           case TIMEZONE_ACRE:
                return en_str_TimeZone_Text_G91;

           case TIMEZONE_M_GROSSO:
                return en_str_TimeZone_Text_G92;

           case TIMEZONE_NORTH:
                return en_str_TimeZone_Text_G93;

           case TIMEZONE_BRASILIA:
                return en_str_TimeZone_Text_G94;

           case TIMEZONE_NORTHEAST:
                return en_str_TimeZone_Text_G95;

           case TIMEZONE_F_NORONHA:
                return en_str_TimeZone_Text_G96;

            default:
                return 0;
        }
#endif

}
#endif

U16 _MApp_ZUI_ACT_GetLanguageStringID(EN_LANGUAGE lang, BOOLEAN bDefaultEnglish)
{
    U16 u16TempID;

    //from case MENULANGUAGESELECTTEXT:
    //from function MApp_UiMenu_GetLanguageStringID()
    switch(lang)
    {
        case LANGUAGE_CZECH:
            u16TempID=en_strMenuLanguageCzechText;
            break;
        case LANGUAGE_DANISH:
            u16TempID=en_strMenuLanguageDanishText;
            break;
        case LANGUAGE_GERMAN:
            u16TempID=en_strMenuLanguageGermanText;
            break;
      #if 0
        default:
            if (!bDefaultEnglish)
                return Empty;
       #else // Modified by coverity_331
        default:
            if (!bDefaultEnglish)
                return Empty;

            u16TempID=en_strMenuLanguageEnglishText;
            break;
       #endif
        case LANGUAGE_ENGLISH:
            u16TempID=en_strMenuLanguageEnglishText;
            break;
        case LANGUAGE_SPANISH:
            u16TempID=en_strMenuLanguageSpanishText;
            break;
        case LANGUAGE_GREEK:

            u16TempID=en_strMenuLanguageGreekText;
            break;
        case LANGUAGE_FRENCH:
            u16TempID=en_strMenuLanguageFrenchText;
            break;
        case LANGUAGE_CROATIAN:
            u16TempID=en_strMenuLanguageCroatianText;
            break;
        case LANGUAGE_ITALIAN:
            u16TempID=en_strMenuLanguageItalianText;
            break;
        case LANGUAGE_HUNGARIAN:
            u16TempID=en_strMenuLanguageHungarianText;
            break;
        case LANGUAGE_DUTCH:
            u16TempID=en_strMenuLanguageDutchText;
            break;
        case LANGUAGE_NORWEGIAN:
            u16TempID=en_strMenuLanguageNorwegianText;
            break;
        case LANGUAGE_POLISH:
            u16TempID=en_strMenuLanguagePolishText;
            break;
        case LANGUAGE_PORTUGUESE:
            u16TempID=en_strMenuLanguagePortugueseText;
            break;
        case LANGUAGE_RUSSIAN:
            u16TempID=en_strMenuLanguageRussianText;
            break;
        case LANGUAGE_ROMANIAN:
            u16TempID=en_strMenuLanguageRomanianText;
            break;
        case LANGUAGE_SLOVENIAN:
            u16TempID=en_strMenuLanguageSloveneText;
            break;
        case LANGUAGE_SERBIAN:
            u16TempID=en_strMenuLanguageSerbianText;
            break;
        case LANGUAGE_FINNISH:
            u16TempID=en_strMenuLanguageFinnishText;
            break;
        case LANGUAGE_SWEDISH:
            u16TempID=en_strMenuLanguageSwedishText;
            break;
        case LANGUAGE_BULGARIAN:
            u16TempID=en_strMenuLanguageBulgarianText;
            break;
        case LANGUAGE_SLOVAK:
            u16TempID=en_strMenuLanguageSlovakText;
            break;
        case LANGUAGE_GAELIC:
            u16TempID=en_strMenuLanguageGaelicText;
            break;
        case LANGUAGE_WELSH:
            u16TempID=en_strMenuLanguageWelshText;
            break;
#if (ENABLE_DTMB_CHINA_APP || ENABLE_ATV_CHINA_APP || ENABLE_DVBC_PLUS_DTMB_CHINA_APP||CHINESE_SIMP_FONT_ENABLE ||CHINESE_BIG5_FONT_ENABLE)
        case LANGUAGE_CHINESE:
            u16TempID=en_strMenuLanguageChineseText;
            break;
#endif
        case LANGUAGE_IRISH:
            u16TempID=en_strMenuLanguageIrishText;
            break;
        case LANGUAGE_KOREAN:
            u16TempID=en_strMenuLanguageKoreanText;
            break;
        case LANGUAGE_JAPAN:
            u16TempID=en_strMenuLanguageJapaneseText;
            break;
        case LANGUAGE_HINDI:
            u16TempID=en_strMenuLanguageHindiText;
            break;
        case LANGUAGE_MAORI:
            u16TempID=en_strMenuLanguageMaoriText;
            break;
        case LANGUAGE_MANDARIN:
            u16TempID=en_strMenuLanguageMandarinText;
            break;
        case LANGUAGE_CANTONESE:
            u16TempID=en_strMenuLanguageCantoneseText;
            break;
        case LANGUAGE_ARABIC:
            u16TempID=en_strMenuLanguageArabicText;
            break;

		#if(UI_SKIN_SEL==UI_SKIN_1366X768X565_HAIER_CN)  // CUS_xm zHIHE 20120812 modify
		case  LANGUAGE_INDONESIAN:

            u16TempID=en_strMenuLanguageINDONESIANText;
            break;
		case  LANGUAGE_FARSI:

            u16TempID=en_strMenuLanguageFARSIText;
            break;
		case  LANGUAGE_HEBREW:

            u16TempID=en_strMenuLanguageHEBREWText;
            break;
		case  LANGUAGE_THAI:
            u16TempID=en_strMenuLanguageTHAIText;
            break;
		#endif

    }

    return u16TempID;
}

U16 _MApp_ZUI_ACT_GetCountryStringID(EN_OSD_COUNTRY_SETTING country)
{
    U16 u16TempID;
    switch(country)
    {
        case OSD_COUNTRY_AUSTRIA:
            u16TempID=en_str_Country_Text_G00;
            break;

        case OSD_COUNTRY_BELGIUM:
            u16TempID=en_str_Country_Text_G01;
            break;

        case OSD_COUNTRY_BULGARIA:
            u16TempID=en_str_Country_Text_G02;
            break;

        case OSD_COUNTRY_CROATIA:
            u16TempID=en_str_Country_Text_G10;
            break;

        case OSD_COUNTRY_CZECH:
            u16TempID=en_str_Country_Text_G11;
            break;

        case OSD_COUNTRY_DENMARK:
            u16TempID=en_str_Country_Text_G12;
            break;

        case OSD_COUNTRY_FINLAND:
            u16TempID=en_str_Country_Text_G20;
            break;

        case OSD_COUNTRY_FRANCE:
            u16TempID=en_str_Country_Text_G21;
            break;

        case OSD_COUNTRY_GERMANY:
            u16TempID=en_str_Country_Text_G22;
            break;

        case OSD_COUNTRY_GREECE:
            u16TempID=en_str_Country_Text_G30;
            break;

        case OSD_COUNTRY_HUNGARY:
            u16TempID=en_str_Country_Text_G31;
            break;

        case OSD_COUNTRY_ITALY:
            u16TempID=en_str_Country_Text_G32;
            break;

        case OSD_COUNTRY_LUXEMBOURG:
            u16TempID=en_str_Country_Text_G40;
            break;

        case OSD_COUNTRY_NETHERLANDS:
            u16TempID=en_str_Country_Text_G41;
            break;

        case OSD_COUNTRY_NORWAY:
            u16TempID=en_str_Country_Text_G42;
            break;

        case OSD_COUNTRY_POLAND:
            u16TempID=en_str_Country_Text_G50;
            break;

        case OSD_COUNTRY_PORTUGAL:
            u16TempID=en_str_Country_Text_G51;
            break;

        case OSD_COUNTRY_RUMANIA:
            u16TempID=en_str_Country_Text_G52;
            break;

        case OSD_COUNTRY_RUSSIA:
            u16TempID=en_str_Country_Text_G60;
            break;

        case OSD_COUNTRY_SERBIA:
            u16TempID=en_str_Country_Text_G61;
            break;

        case OSD_COUNTRY_SLOVENIA:
            u16TempID=en_str_Country_Text_G62;
            break;

        case OSD_COUNTRY_SPAIN:
            u16TempID=en_str_Country_Text_G70;
            break;

        case OSD_COUNTRY_SWEDEN:
            u16TempID=en_str_Country_Text_G71;
            break;

        case OSD_COUNTRY_SWITZERLAND:
            u16TempID=en_str_Country_Text_G72;
            break;

        case OSD_COUNTRY_CHINA:
            u16TempID=en_str_Country_Text_China;
            break;

        case OSD_COUNTRY_ESTONIA:
            u16TempID=en_str_Country_Text_Estonia;
            break;

        case OSD_COUNTRY_TURKEY:
            u16TempID=en_str_Country_Text_Turkey;
            break;

        case OSD_COUNTRY_UK:
            u16TempID=en_str_Country_Text_G80;
            break;

        case OSD_COUNTRY_AUSTRALIA:
            u16TempID=en_str_Country_Text_G81;
            break;

        case OSD_COUNTRY_NEWZEALAND:
            u16TempID=en_str_Country_Text_G82;
            break;

        case OSD_COUNTRY_MOROCCO:
            u16TempID=en_str_Country_Text_G90;
            break;

        case OSD_COUNTRY_TUNIS:
            u16TempID=en_str_Country_Text_G91;
            break;

        case OSD_COUNTRY_ALGERIA:
            u16TempID=en_str_Country_Text_G92;
            break;

        case OSD_COUNTRY_EGYPT:
            u16TempID=en_str_Country_Text_G93;
            break;

        case OSD_COUNTRY_SOUTH_AFRICA:
            u16TempID=en_str_Country_Text_G94;
            break;

        case OSD_COUNTRY_ISRAEL:
            u16TempID=en_str_Country_Text_G95;
            break;

        case OSD_COUNTRY_IRAN:
            u16TempID=en_str_Country_Text_G96;
            break;

        case OSD_COUNTRY_UNITED_ARAB_EMIRATES:
            u16TempID=en_str_Country_Text_G97;
            break;

        case OSD_COUNTRY_SLOVAKIA:
            u16TempID=en_str_Country_Text_G98;
            break;

        #if (ENABLE_SBTVD_BRAZIL_APP)
        case OSD_COUNTRY_BRAZIL:
            u16TempID=en_str_Country_Text_Brazil;
            break;
        #endif

        #if (ENABLE_DVB_TAIWAN_APP)
        case OSD_COUNTRY_TAIWAN:
            u16TempID=en_str_Country_Text_Taiwan;
            break;
        #endif

        default:
            u16TempID=Empty;
            break;

    }
    #if ENABLE_AUTOTEST
    if(g_bAutobuildDebug)
    {
        switch(tempcheck2)
        {
            case HWND_MENU_OPTION_COUNTRY_OPTION:
                if(Country != u16TempID)
                {
                    printf("73_Country\n");
                }
                Country = u16TempID;
                break;
            default:

                break;
        }
    }
    #endif
    return u16TempID;
}

LPTSTR _MApp_ZUI_ACT_CombineTextAndOption(HWND hwnd)
{
    LPTSTR u16str = CHAR_BUFFER;
    U16 u16len = 0;
    U16 u16TextID = 0;
    U32 u16OptionID = 0;
    U16 u16con_buffer[32];
    BOOLEAN Load_Flag = FALSE;

    switch (hwnd)
    {
        case HWND_MENU_PIC_ADJ_TEMP_RED_OPTION:
        case HWND_MENU_PICCOLOR_COLOR_RED_OPTION:
            u16TextID = en_strCCRedText;
            u16OptionID = _MApp_ZUI_ACT_GetColorTempColorValue(hwnd);
            #if ENABLE_AUTOTEST
            if(g_bAutobuildDebug)
            {
                if(ColorR != u16OptionID)
                {
                    printf("42_ColorR\n");
                }
                ColorR = u16OptionID;
            }
            #endif
            break;
        case HWND_MENU_PIC_ADJ_TEMP_GREEN_OPTION:
        case HWND_MENU_PICCOLOR_COLOR_GREEN_OPTION:
            u16TextID = en_strCCGreenText;
            u16OptionID = _MApp_ZUI_ACT_GetColorTempColorValue(hwnd);
            #if ENABLE_AUTOTEST
            if(g_bAutobuildDebug)
            {
                if(ColorG != u16OptionID)
                {
                    printf("42_ColorG\n");
                }
                ColorG = u16OptionID;
            }
            #endif
            break;
        case HWND_MENU_PIC_ADJ_TEMP_BLUE_OPTION:
        case HWND_MENU_PICCOLOR_COLOR_BLUE_OPTION:
            u16TextID = en_strCCBlueText;
            u16OptionID = _MApp_ZUI_ACT_GetColorTempColorValue(hwnd);
            #if ENABLE_AUTOTEST
            if(g_bAutobuildDebug)
            {
                if(ColorB != u16OptionID)
                {
                    printf("42_ColorB\n");
                }
                ColorB = u16OptionID;
            }
            #endif
            break;
        case HWND_MENU_PIC_ADJ_CONTRAST_OPTION:
        case HWND_MENU_PICMODE_CONTRAST_OPTION:
            u16TextID = en_str_Picture_User_Contrast;
            u16OptionID = ST_PICTURE.u8Contrast;
            #if ENABLE_AUTOTEST
            if(g_bAutobuildDebug)
            {
                if(PicContrast != u16OptionID)
                {
                    printf("41_PicContrast\n");
                }
                PicContrast = u16OptionID;
            }
            #endif
            break;
        case HWND_MENU_PIC_ADJ_BRIGHTNESS_OPTION:
        case HWND_MENU_PICMODE_BRIGHTNESS_OPTION:
            u16TextID = en_str_Picture_User_Brightness;
            u16OptionID = ST_PICTURE.u8Brightness;
            #if ENABLE_AUTOTEST
            if(g_bAutobuildDebug)
            {
                if(PicBright != u16OptionID)
                {
                    printf("41_PicBright\n");
                }
                PicBright = u16OptionID;
            }
            #endif
            break;
        case HWND_MENU_PIC_ADJ_COLOR_OPTION:
        case HWND_MENU_PICMODE_COLOR_OPTION:
            u16TextID = en_str_Picture_User_Color;
            u16OptionID = ST_PICTURE.u8Saturation;
            #if ENABLE_AUTOTEST
            if(g_bAutobuildDebug)
            {
                if(PicColor != u16OptionID)
                {
                    printf("41_PicColor\n");
                }
                PicColor = u16OptionID;
            }
            #endif
            break;
        case HWND_MENU_PIC_ADJ_SHARPNESS_OPTION:
        case HWND_MENU_PICMODE_SHARPNESS_OPTION:
            u16TextID = en_str_Picture_User_Sharpness;
            u16OptionID = ST_PICTURE.u8Sharpness;
            #if ENABLE_AUTOTEST
            if(g_bAutobuildDebug)
            {
                if(PicSharpness != u16OptionID)
                {
                    printf("41_PicSharpness\n");
                }
                PicSharpness = u16OptionID;
            }
            #endif
            break;
        case HWND_MENU_PIC_ADJ_TINT_OPTION:
        case HWND_MENU_PICMODE_TINT_OPTION:
            u16TextID = en_str_Picture_User_Tint;
            u16OptionID = ST_PICTURE.u8Hue;
            #if ENABLE_AUTOTEST
            if(g_bAutobuildDebug)
            {
                if(PicTint != u16OptionID)
                {
                    printf("41_PicTint\n");
                }
                PicTint = u16OptionID;
            }
            #endif
            break;
        case HWND_MENU_SNDMODE_TREBLE_OPTION:
            u16TextID = en_str_Sound_User_Treble;
            u16OptionID = _MApp_ZUI_ACT_GetSoundAdjustValue(hwnd);
            break;
        case HWND_MENU_SNDMODE_BASS_OPTION:
            u16TextID = en_str_Sound_User_Bass;
            u16OptionID = _MApp_ZUI_ACT_GetSoundAdjustValue(hwnd);
            break;
        case HWND_MENU_SNDEQ_120_HZ_OPTION:
            u16TextID = en_str_120HZ;
            u16OptionID = _MApp_ZUI_ACT_GetSoundAdjustValue(hwnd);
            break;
        case HWND_MENU_SNDEQ_200_HZ_OPTION:
            u16TextID = en_str_200HZ;
            u16OptionID = _MApp_ZUI_ACT_GetSoundAdjustValue(hwnd);
            break;
        case HWND_MENU_SNDEQ_500_HZ_OPTION:
            u16TextID = en_str_500HZ;
            u16OptionID = _MApp_ZUI_ACT_GetSoundAdjustValue(hwnd);
            break;
        case HWND_MENU_SNDEQ_1_2_KHZ_OPTION:
            u16TextID = en_str_1_dot_5_KHZ;
            u16OptionID = _MApp_ZUI_ACT_GetSoundAdjustValue(hwnd);
            break;
        case HWND_MENU_SNDEQ_3_KHZ_OPTION:
            u16TextID = en_str_3KHZ;
            u16OptionID = _MApp_ZUI_ACT_GetSoundAdjustValue(hwnd);
            break;
        case HWND_MENU_SNDEQ_7_5_KHZ_OPTION:
            u16TextID = en_str_5KHZ;
            u16OptionID = _MApp_ZUI_ACT_GetSoundAdjustValue(hwnd);
            break;
        case HWND_MENU_SNDEQ_12_KHZ_OPTION:
            u16TextID = en_str_10KHZ;
            u16OptionID = _MApp_ZUI_ACT_GetSoundAdjustValue(hwnd);
            break;
#if (ENABLE_CUS_UI_SPEC == DISABLE)/*Creass.liu at 2012-06-27*/
         case HWND_MENU_SOUND_SWITCH_AD_FADE_OPTION:
            u16TextID = en_str_ADFade;
            u16OptionID = stGenSetting.g_SoundSetting.ADVolume;
            break;
#endif

#if (ENABLE_PIP)
         case HWND_MENU_PIP_SUBSRC_OPTION:
            if(IsPIPSupported())
            {
                u16TextID = en_str_PIP_SubSrc;
                //Check source compatibility here
                if(!MApp_InputSource_PIP_IsSrcCompatible(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW),
                            MApp_InputSource_GetInputSourceType(UI_SUB_INPUT_SOURCE_TYPE)))
                {
                    stGenSetting.g_stPipSetting.enSubInputSourceType = MApp_InputSource_GetUIInputSourceType(MApp_InputSource_PIP_Get1stCompatibleSrc(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)));
                }
                switch(stGenSetting.g_stPipSetting.enSubInputSourceType)
                {
                    default:
                    #if(ENABLE_DTV)
                    case UI_INPUT_SOURCE_DTV:
                        u16OptionID = en_strInputSourceDtvText;
                        break;
                    #endif
                    case UI_INPUT_SOURCE_ATV:
                        u16OptionID = en_strInputSourceAtvText;
                        break;
                    case UI_INPUT_SOURCE_RGB:
                        u16OptionID = en_strInputSource_RGB_PC;
                        break;
                #if (INPUT_AV_VIDEO_COUNT >= 1)
                    case UI_INPUT_SOURCE_AV:
                        u16OptionID = en_strInputSourceAv1Text;
                        break;
                #endif
                #if (INPUT_AV_VIDEO_COUNT >= 2)
                    case UI_INPUT_SOURCE_AV2:
                        u16OptionID = en_strInputSourceAv2Text;
                        break;
                #endif
                #if (INPUT_AV_VIDEO_COUNT >= 3)
                    case UI_INPUT_SOURCE_AV3:
                        u16OptionID = en_strInputSourceAv3Text;
                        break;
                #endif
                #if (INPUT_YPBPR_VIDEO_COUNT >= 1)
                    case UI_INPUT_SOURCE_COMPONENT:
                        u16OptionID = en_strYPbPrText;
                        break;
                #endif
                #if (INPUT_YPBPR_VIDEO_COUNT >= 2)
                    case UI_INPUT_SOURCE_COMPONENT2:
                        u16OptionID = en_strYPbPr2Text;
                        break;
                #endif
                #if (INPUT_HDMI_VIDEO_COUNT >= 1)
                    case UI_INPUT_SOURCE_HDMI:
                        u16OptionID = en_strInputSourceHdmi1Text;
                        break;
                #endif
                #if (INPUT_HDMI_VIDEO_COUNT >= 2)
                    case UI_INPUT_SOURCE_HDMI2:
                        u16OptionID = en_strInputSourceHdmi2Text;
                        break;
                #endif
                #if (INPUT_HDMI_VIDEO_COUNT >= 3)
                    case UI_INPUT_SOURCE_HDMI3:
                        u16OptionID = en_strInputSourceHdmi3Text;
                        break;
                #endif
                #if (INPUT_HDMI_VIDEO_COUNT >= 4)
                    case UI_INPUT_SOURCE_HDMI4:
                        u16OptionID = en_strInputSourceHdmi4Text;
                        break;
                #endif
                #if (INPUT_SCART_VIDEO_COUNT >= 1)
                    case UI_INPUT_SOURCE_SCART:
                        u16OptionID = en_strInputSourceScart1Text;
                        break;
                #endif
                #if (INPUT_SCART_VIDEO_COUNT >= 2)
                    case UI_INPUT_SOURCE_SCART2:
                        u16OptionID = en_strInputSourceScart2Text;
                        break;
                #endif
                #if (INPUT_SV_VIDEO_COUNT >= 1)
                    case UI_INPUT_SOURCE_SVIDEO:
                         u16OptionID = en_strInputSourceSv1Text;
                        break;
                #endif
                #if (INPUT_SV_VIDEO_COUNT >= 2)
                    case UI_INPUT_SOURCE_SVIDEO2:
                        u16OptionID = en_strInputSourceSv2Text;
                        break;
                #endif
                }
                MApp_ZUI_API_LoadString(u16OptionID, u16con_buffer);
                Load_Flag = TRUE;
            }
            break;

         case HWND_MENU_PIP_SIZE_OPTION:
            if(IsPIPSupported())
            {
                u16TextID = en_str_PCMenu_Size;
                switch(stGenSetting.g_stPipSetting.enPipSize)
                {
                    default:
                    case EN_PIP_SIZE_SMALL:
                        u16OptionID = en_str_PIP_Size_Small;
                        break;
                    case EN_PIP_SIZE_MEDIUM:
                        u16OptionID = en_str_PIP_Size_Medium;
                        break;
                    case EN_PIP_SIZE_LARGE:
                        u16OptionID = en_str_PIP_Size_Large;
                        break;
                }
                MApp_ZUI_API_LoadString(u16OptionID, u16con_buffer);
                Load_Flag = TRUE;
            }
            break;
         case HWND_MENU_PIP_POSITION_OPTION:
            if(IsPIPSupported())
            {
                u16TextID = en_str_PIP_Position;
                switch(stGenSetting.g_stPipSetting.enPipPosition)
                {
                    default:
                    case EN_PIP_POSITION_LEFT_TOP:
                        u16OptionID = en_str_PIP_Position_Left_Top;
                        break;
                    case EN_PIP_POSITION_RIGHT_TOP:
                        u16OptionID = en_str_PIP_Position_Right_Top;
                        break;
                    case EN_PIP_POSITION_LEFT_BOTTOM:
                        u16OptionID = en_str_PIP_Position_Left_Bottom;
                        break;
                    case EN_PIP_POSITION_RIGHT_BOTTOM:
                        u16OptionID = en_str_PIP_Position_Right_Bottom;
                        break;
                }
                MApp_ZUI_API_LoadString(u16OptionID, u16con_buffer);
                Load_Flag = TRUE;
            }
            break;
         case HWND_MENU_PIP_SOUND_SRC_OPTION:
            if(IsPIPSupported())
            {
                u16TextID = en_str_PIP_Sound_Src;
                if(!stGenSetting.g_stPipSetting.enPipSoundSrc)
                    u16OptionID=en_str_PIP_Sound_Src_Main;
                else
                    u16OptionID=en_str_PIP_Sound_Src_Sub;

                MApp_ZUI_API_LoadString(u16OptionID, u16con_buffer);
                Load_Flag = TRUE;
            }
            break;
        case HWND_MENU_PIP_BORDER_OPTION:
            if(IsPIPSupported())
            {
                u16TextID = en_str_PIP_Border;
                if(!stGenSetting.g_stPipSetting.bBolderEnable)
                    u16OptionID=en_str_Off;
                else
                    u16OptionID=en_str_On;

                MApp_ZUI_API_LoadString(u16OptionID, u16con_buffer);
                Load_Flag = TRUE;
            }
            break;
#endif //#if (ENABLE_PIP)

#if (ENABLE_CUS_UI_SPEC == DISABLE)
        case HWND_MENU_PCMODE_HPOS_OPTION:
            u16TextID = en_str_PCMenu_PositionH;
            u16OptionID = MApp_ZUI_ACT_GetPcModeAdjustValue(hwnd);
            break;
        case HWND_MENU_PCMODE_VPOS_OPTION:
            u16TextID = en_str_PCMenu_PositionV;
            u16OptionID = MApp_ZUI_ACT_GetPcModeAdjustValue(hwnd);
            break;
        case HWND_MENU_PCMODE_SIZE_OPTION:
            u16TextID = en_str_PCMenu_Size;
            u16OptionID = MApp_ZUI_ACT_GetPcModeAdjustValue(hwnd);
            break;
        case HWND_MENU_PCMODE_PHASE_OPTION:
            u16TextID = en_str_PCMenu_Phase;
            u16OptionID = MApp_ZUI_ACT_GetPcModeAdjustValue(hwnd);
            break;
 #endif

    #if(ENABLE_DTV)
        case HWND_MENU_DLG_SIGNAL_INFORMAT_MODULATION_NAME:
        {
            WORD ModulMode;
            WORD SignalStrength;
            u16TextID = en_str_Modulation;
            msAPI_Tuner_CheckSignalStrength(&SignalStrength);

            if(SignalStrength>3)
            {
                if (msAPI_Tuner_GetSignalModulMode(&ModulMode))
                {

                    if(ModulMode == 0)
                        u16OptionID = en_str_QPSK;

                    else if(ModulMode == 1)
                        u16OptionID = en_str_16QAM;

                    else if(ModulMode == 2)
                        u16OptionID = en_str_64QAM;

                    else
                        u16OptionID = en_str_Unknow;
                }
                else
                {
                    u16OptionID = en_str_Unknow;
                }

            }
            else
                u16OptionID = en_str_Unknow;

            MApp_ZUI_API_LoadString(u16OptionID, u16con_buffer);
            Load_Flag = TRUE;
            break;
        }
        #if(ENABLE_DTV)
         case HWND_MENU_DLG_SIGNAL_INFORMAT_CHANNEL_NAME:
		#if DVB_C_ENABLE
		 	if(IsCATVInUse())
		 	{
	            u16TextID   = en_strManualScan_FrequencyText;
				u16OptionID = MApp_CadtvManualTuning_GetFrequency();
			}
			else
		#endif
			{
	            u16TextID   = en_str_Channel;
	            u16OptionID = msAPI_CM_GetPhysicalChannelNumber(msAPI_CM_GetCurrentServiceType(),msAPI_CM_GetCurrentPosition(msAPI_CM_GetCurrentServiceType()));
			}
            break;
        #endif
        case HWND_MENU_DLG_SIGNAL_INFORMAT_QUALITY_PERCENT_VAL:
            u16TextID = en_str_Quality;
            u16OptionID = msAPI_Tuner_GetSignalQualityPercentage();
            break;
        case HWND_MENU_DLG_SIGNAL_INFORMAT_STRENGTH_PERCENT_VAL:
        {
            WORD SignalStrength;
            u16TextID = en_str_Strength;
            msAPI_Tuner_CheckSignalStrength(&SignalStrength);
            u16OptionID = SignalStrength;
            break;
        }
    #endif

    }

    MApp_ZUI_API_LoadString(u16TextID, u16str);
    u16len = MApp_ZUI_API_Strlen(u16str);
    u16str[u16len++] = CHAR_SPACE;
    u16str[u16len++] = 0;
    if(Load_Flag == FALSE)
    {
       MApp_UlongToU16String(u16OptionID, (U16*)u16con_buffer, MApp_GetNoOfDigit(u16OptionID));
    }

    MApp_ZUI_API_Strcat(u16str,(U16*)u16con_buffer);
    return u16str;
}
void _MApp_ZUI_ACT_CombineDureTimerString(LPTSTR str, U32 TIMER)
{
    U32 u32SleepTime = TIMER;
    U8 u8SleepDigits = MApp_GetNoOfDigit(u32SleepTime);
    __MApp_UlongToString(u32SleepTime, str, u8SleepDigits);
    MApp_ZUI_API_LoadString(en_str_SleepTimer_Sec, str + u8SleepDigits);
}

///////////////////////////////////////////////////////////////////////////////
///  private  MApp_ZUI_ACT_GetMenuItemDynamicText
///  dynamic text content provider in menu items
///
///  @param [in]       hwnd HWND     window handle we are processing
///
///  @return LPCTSTR     string content
///
///  @author MStarSemi @date 2007/1/25
///////////////////////////////////////////////////////////////////////////////



LPTSTR MApp_ZUI_ACT_GetMenuItemDynamicText(HWND hwnd)
{
    U16 u16TempID = Empty;
    tempcheck2 = hwnd;
  #if (ENABLE_ATV_VCHIP)
     #define VCHIP_MPAA_ITEMNUM 7
     #define VCHIP_CANADAENG_ITEMNUM 7
     #define VCHIP_CANADAFRE_ITEMNUM 6
#endif
	U16 u16Value;

    switch(hwnd)
    {
    #if ENABLE_CI
        case HWND_MENU_CHANNEL_CI_INFORMATION_OPTION:
        {
            U8 SmartCard_Name[32];
            U8 i=0;

            msAPI_CI_GetSmartCardName(SmartCard_Name,32);

            if (msAPI_CI_CardDetect())
            {
                for(i=0;i<32;i++)
                {
                    if ((SmartCard_Name[i]==0)||(i>19)) break;
                }

                if (i>19)
                {
                    SmartCard_Name[i++] = CHAR_DOT;
                    SmartCard_Name[i++] = CHAR_DOT;
                    SmartCard_Name[i++] = CHAR_DOT;
                }
                SmartCard_Name[i] = 0;
                return MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, SmartCard_Name, 32);
             }
        }
        break;
    #endif
        case HWND_MENU_LOCK_MAINSUBPAGE_ITEM_KEYBDLOCK_OPTION:
            #ifdef ENABLE_BUTTON_LOCK
            if(stGenSetting.g_SysSetting.g_enKeyPadLock == EN_E5_KeyLock_On)
            {
                u16TempID =en_str_On;
            }
            else
            {
                u16TempID = en_str_Off;
            }
            #endif
            break;
	    //SCM jayden.chen add for show AV when AV couter>1 20130308		
		case HWND_MENU_LOCK_MAINSUBPAGE_ITEM_AV1_TEXT:
				#if (INPUT_AV_VIDEO_COUNT >1)
				{
					u16TempID =en_strInputSourceAv1Text;
				}
				#else
				{
					u16TempID =en_strInputSourceAvText;
				}
				#endif
			break;

        case HWND_MENU_CHANNEL_SW_OAD_UPGRADE_OPTION:
            //from case A7_OPTION_SOFTWAREUPDATETEXT:
            if(!stGenSetting.g_SysSetting.fSoftwareUpdate)
                u16TempID = en_str_Off;
            else
                u16TempID = en_str_On;
            break;
#if 0//NTV_FUNCTION_ENABLE //wait to do
        case HWND_MENU_CHANNEL_DTV_BANDWIDTH_OPTION:
        {
            char BandWidth[5];
            U8  Ptr= 0;

            if(stGenSetting.stScanMenuSetting.u8BandWidth == E_RF_CH_BAND_8MHz)
                BandWidth[Ptr++] = '8';
            else if(stGenSetting.stScanMenuSetting.u8BandWidth == E_RF_CH_BAND_7MHz)
                BandWidth[Ptr++] = '7';

            BandWidth[Ptr++] = 'M';
            BandWidth[Ptr++] = 'H';
            BandWidth[Ptr++] = 'z';
            BandWidth[Ptr++] = NULL;

            return MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, (U8 *)BandWidth, strlen(BandWidth));
            break;
        }
#endif
#if (ENABLE_CUS_UI_SPEC == DISABLE)
        case HWND_MENU_SW_VERSION_TEXT:
#if 1
           /* {
            char *ptr;
            char ptr_head[128];


            unsigned char * pu8Temp;
            U8 u8Data,u8Temp_i,u8Temp_j;
            U8 u8ASCII_Mapping[16] = {'0','1','2','3','4','5','6','7','8','9','A',
                'B','C','D','E','F'};
            unsigned char Customer_info_others[48];
            U32 u32Temp;

            ptr = ptr_head;



            //<1>.For Customer ID
            //ptr = strcpy(ptr, "CID:" );
            //ptr +=4;

            ptr = memcpy(ptr, &Customer_info[0],4);
            ptr +=4;
            *ptr = '-';
            ptr++;

            //<2>.For Customer ID
            //ptr = strcpy(ptr, "MID:" );
            //ptr +=4;
            ptr = memcpy(ptr, &Customer_info[4],4);
            ptr +=4;
            *ptr = '-';
            ptr++;

            //<3>.For Customer ID
            //ptr = strcpy(ptr, "Chip:" );
            //ptr +=5;

            ptr = memcpy(ptr, &Customer_info[8],4);
            ptr +=4;
            *ptr = '-';
            ptr++;



        //<3>.To prepare the Customer Info Others
            u8Temp_i=0;
            //Get SW Project Name:01 => Chakra
            pu8Temp = &CID_Buf[CUSTOMER_INFO_START_SW_PROJECT];
            u8Data = ((*(pu8Temp))>> 4);
            Customer_info_others[u8Temp_i++] = u8ASCII_Mapping[u8Data];
            u8Data = (*(pu8Temp) & 0x0F);
            Customer_info_others[u8Temp_i++] =  u8ASCII_Mapping[u8Data];
            Customer_info_others[u8Temp_i++] =  '-';

            //Get SW Project Generation:01 => 1.0
            pu8Temp = &CID_Buf[CUSTOMER_INFO_START_SW_PROJECT_GENERATION];
            u8Data = ((*(pu8Temp))>> 4);
            Customer_info_others[u8Temp_i++] = u8ASCII_Mapping[u8Data];
            u8Data = (*(pu8Temp) & 0x0F);
            Customer_info_others[u8Temp_i++] =  u8ASCII_Mapping[u8Data];
            Customer_info_others[u8Temp_i++] =  '-';

            //Get Product Type:TV-01
            pu8Temp = &CID_Buf[CUSTOMER_INFO_START_PRODUCT];
            u8Data = ((*(pu8Temp))>> 4);
            Customer_info_others[u8Temp_i++] = u8ASCII_Mapping[u8Data];
            u8Data = (*(pu8Temp) & 0x0F);
            Customer_info_others[u8Temp_i++] =  u8ASCII_Mapping[u8Data];
            Customer_info_others[u8Temp_i++] =  '-';

            //Get TV System
            pu8Temp = &CID_Buf[CUSTOMER_INFO_START_TV_SYSTEM];
            u8Data = ((*(pu8Temp))>> 4);
            Customer_info_others[u8Temp_i++] = u8ASCII_Mapping[u8Data];
            u8Data = (*(pu8Temp) & 0x0F);
            Customer_info_others[u8Temp_i++] =  u8ASCII_Mapping[u8Data];
            Customer_info_others[u8Temp_i++] =  '-';

            pu8Temp = &CID_Buf[CUSTOMER_INFO_START_LABEL];
            u32Temp = ((*(pu8Temp+2))<<16)|((*(pu8Temp+1))<<8)|((*(pu8Temp+0)));

            for (u8Temp_j=0;u8Temp_j<6;u8Temp_j++)
            {
                u8Data = u32Temp%10;
                u32Temp = u32Temp/10;
                Customer_info_others[u8Temp_i+5-u8Temp_j] = u8ASCII_Mapping[u8Data];
            }
            u8Temp_i +=6;
            Customer_info_others[u8Temp_i++] =  '-';


            pu8Temp = &CID_Buf[CUSTOMER_INFO_START_CL];
            u32Temp = ((*(pu8Temp+2))<<16)|((*(pu8Temp+1))<<8)|((*(pu8Temp+0)));
            for (u8Temp_j=0;u8Temp_j<8;u8Temp_j++)
            {
                u8Data = u32Temp%10;
                u32Temp = u32Temp/10;
                Customer_info_others[u8Temp_i+7-u8Temp_j] = u8ASCII_Mapping[u8Data];
            }
            u8Temp_i +=8;
            Customer_info_others[u8Temp_i++] =  '-';



            //Get SW Release Purpose:01 => 1.0
            pu8Temp = &CID_Buf[CUSTOMER_INFO_START_RELEASE_PURPOSE];
            u8Data = ((*(pu8Temp))>> 4);
            Customer_info_others[u8Temp_i++] = u8ASCII_Mapping[u8Data];
            u8Data = (*(pu8Temp) & 0x0F);
            Customer_info_others[u8Temp_i++] =  u8ASCII_Mapping[u8Data];

            ptr = memcpy(ptr, &Customer_info_others[0],(u8Temp_i));


            ptr +=(u8Temp_i);
            *ptr = 0;




            return MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, (U8 *)ptr_head, strlen(ptr_head));
        }*/

        break;

#else
        {
          #if 0
            char *ptr;
            char ptr_head[128];

            ptr = ptr_head;
            ptr = strcpy(ptr, SWVersionName );
            return MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, (U8 *)ptr_head, strlen(ptr_head));
          #else // Modifed it by coverity_0544
            char ptr_head[128];
            strcpy(ptr_head, SWVersionName );
            return MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, (U8 *)ptr_head, strlen(ptr_head));
          #endif
        }
        break;
#endif
        case HWND_MENU_SW_BUILD_TIME_TEXT:
        {
            /*char *ptr;
            char ptr_head[128];

            ptr = ptr_head;
          #if 0
            strcpy(ptr, SWCompileDate );
            strcat(ptr, ", ");
            strcat(ptr, SWCompileTime);
          #else // Modified by coverity_683
            strncpy(ptr, SWCompileDate, sizeof(SWCompileDate) );
            strncat(ptr, ", ", 2);
            strncat(ptr, SWCompileTime, sizeof(SWCompileTime));
          #endif

            return MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, (U8 *)ptr_head, strlen(ptr_head));*/
        }
        break;
#endif
        case HWND_MENU_CHANNEL_5V_ANTENNA_OPTION:
            //from case A6_OPTION_5VANTENNAPOWERTEXT:
            if(!stGenSetting.g_SysSetting.f5VAntennaPower)
                u16TempID=en_str_Off;
            else
                u16TempID=en_str_On;
            break;

#if (ENABLE_PIP)
        case HWND_MENU_PIP_PIPMODE_OPTION:
        case HWND_MENU_PICTURE_PIP_OPTION:
            if(IsPIPSupported())
            {
                switch(stGenSetting.g_stPipSetting.enPipMode)
                {
                   default:
                   case EN_PIP_MODE_PIP:
                        u16TempID = en_str_PIP_Mode_PIP;
                        break;
                   case EN_PIP_MODE_POP_FULL:
                        u16TempID = en_str_PIP_Mode_POP_FULL;
                        break;
                   case EN_PIP_MODE_POP:
                        u16TempID = en_str_PIP_Mode_POP;
                        break;
                   case EN_PIP_MODE_OFF:
                        u16TempID = en_str_Off;
                        break;
                }
            }
            break;

        case HWND_MENU_PIP_BORDER_OPTION:
        case HWND_MENU_PIP_SOUND_SRC_OPTION:
        case HWND_MENU_PIP_SUBSRC_OPTION:
        case HWND_MENU_PIP_SIZE_OPTION:
        case HWND_MENU_PIP_POSITION_OPTION:
            if(IsPIPSupported())
            {
                return _MApp_ZUI_ACT_CombineTextAndOption(hwnd);
            }
            break;
#endif

        case HWND_MENU_PICTURE_PICMODE_OPTION:
            u16TempID = _MApp_ZUI_ACT_GetPictureModeStringID();
            break;

        case HWND_MENU_PICMODE_PICMODE_OPTION:
            u16TempID = _MApp_ZUI_ACT_GetPictureModeStringID();
            break;

        case HWND_MENU_OPTION_ASPECT_RATIO_OPTION:
            u16TempID = _MApp_ZUI_ACT_GetAspectRatioStringID();
            break;

        case HWND_MENU_PIC_ADJ_TEMP_RED_OPTION:
        case HWND_MENU_PICCOLOR_COLOR_RED_OPTION:
        case HWND_MENU_PIC_ADJ_TEMP_GREEN_OPTION:
        case HWND_MENU_PICCOLOR_COLOR_GREEN_OPTION:
        case HWND_MENU_PIC_ADJ_TEMP_BLUE_OPTION:
        case HWND_MENU_PICCOLOR_COLOR_BLUE_OPTION:
            return _MApp_ZUI_ACT_CombineTextAndOption(hwnd);
        case HWND_MENU_ADVANCE_PICTURE_PC_BACKLIGHT_OPTION:
#if (ENABLE_CUS_UI_SPEC == DISABLE) /*Creass.liu at 2012-06-02*/
    case HWND_MENU_PICTURE_BACKLIGHT_OPTION:
#endif
           MApp_UlongToU16String(ST_PICTURE.u8Backlight, CHAR_BUFFER, (S8)MApp_GetNoOfDigit(ST_PICTURE.u8Backlight));
           return CHAR_BUFFER;
            break;
    case HWND_MENU_ADVANCE_PICTURE_COLOR_RANGE_OPTION:
            if (stGenSetting.g_SysSetting.fCOLORRANGE)
                  u16TempID=en_str_Color_Range_0_255;
            else
                  u16TempID=en_str_Color_Range_16_235;
            break;

        case HWND_MENU_ADVANCE_PICTURE_NOISE_REDUCTION_OPTION:
           #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
            switch(ST_PICTURE.eNRMode.eNR)
           #else
            switch(ST_VIDEO.eNRMode.eNR)
           #endif
            {
                default:
                case MS_NR_OFF:
                    u16TempID=en_str_Off;
                    break;
                case MS_NR_LOW:
                    u16TempID=en_str_LOW;
                    break;
                case MS_NR_MIDDLE:
                    u16TempID=en_str_MIDDLE;
                    break;
                case MS_NR_HIGH:
                    u16TempID=en_str_HIGH;
                    break;
#if(_AutoNR_EN_)
                case MS_NR_AUTO:
                    u16TempID=en_str_AUTO;
                    break;
#endif
                case MS_NR_DEFAULT:
                    u16TempID=en_str_DEFAULT;
                    break;
            }
            #if ENABLE_AUTOTEST
            if(g_bAutobuildDebug)
            {
                if(NoiseR != u16TempID)
                {
                    printf("44_NoiseReduction\n");
                }
                NoiseR = u16TempID;
            }
            #endif
            break;
        case HWND_MENU_ADVANCE_PICTURE_FLESH_TONE_OPTION:
            #if ENABLE_FLESH_TONE
            switch(ST_PICTURE.eFleshToneMode)
            {
                default:
                case MS_FLESH_TONE_OFF:
                    u16TempID=en_str_Off;
                    break;
                case MS_FLESH_TONE_LOW:
                    u16TempID=en_str_LOW;
                    break;
                case MS_FLESH_TONE_MIDDLE:
                    u16TempID=en_str_MIDDLE;
                    break;
                case MS_FLESH_TONE_HIGH:
                    u16TempID=en_str_HIGH;
                    break;
            }
            #endif
            break;
         case HWND_MENU_ADVANCE_PICTURE_DCR_OPTION:
    #if ENABLE_CUS_DBC
                switch(ST_PICTURE.bDBCStatus)
                {

                    default:
                    case DBC_STATUS_OFF:
                        u16TempID=en_str_Off;
                        break;
                    case DBC_STATUS_ON:
                        u16TempID=en_str_On;
                        break;
                }
    #endif
                break;
         case HWND_MENU_ADVANCE_PICTURE_DCR_OPTION_ADV:
#if ENABLE_CUS_DLC
                switch(ST_PICTURE.bDLCStatus)
                {

                    default:
                    case DLC_STATUS_OFF:
                        u16TempID=en_str_Off;
                        break;
                    case DLC_STATUS_ON:
                        u16TempID=en_str_On;
                        break;
                }
#endif
                break;

        case HWND_MENU_PICTURE_COLOR_TEMP_OPTION:
        case HWND_MENU_PC_PICTURE_COLOR_TEMP_OPTION:
            switch( ST_PICTURE.eColorTemp )
            {
                default:
                case MS_COLOR_TEMP_COOL:

                    u16TempID=en_str_ColorTemp_Cool;
                    break;
                case MS_COLOR_TEMP_MEDIUM:
                    u16TempID=en_str_ColorTemp_Medium;
                    break;
                case MS_COLOR_TEMP_WARM:
                    u16TempID=en_str_ColorTemp_Warm;
                    break;
            #if(MS_COLOR_TEMP_COUNT ==4)
                case MS_COLOR_TEMP_USER:
                    u16TempID=en_str_ColorTemp_User;
                    break;
            #endif
            }
            #if ENABLE_AUTOTEST
            if(g_bAutobuildDebug)
            {
                if(ColorTem != u16TempID)
                {
                    printf("42_ColorTemperature\n");
                }
                ColorTem = u16TempID;
            }
            #endif
            break;

        case HWND_MENU_PICCOLOR_COLOR_TEMP_OPTION:
            switch( ST_PICTURE.eColorTemp )
            {
                default:
                case MS_COLOR_TEMP_COOL:

                    u16TempID=en_str_ColorTemp_Cool;
                    break;
                case MS_COLOR_TEMP_MEDIUM:
                    u16TempID=en_str_ColorTemp_Medium;
                    break;
                case MS_COLOR_TEMP_WARM:
                    u16TempID=en_str_ColorTemp_Warm;
                    break;
            #if(MS_COLOR_TEMP_COUNT ==4)
                case MS_COLOR_TEMP_USER:
                    u16TempID=en_str_ColorTemp_User;
                    break;
            #endif
            }
            break;

        case HWND_MENU_PIC_ADJ_CONTRAST_OPTION:
        case HWND_MENU_PICMODE_CONTRAST_OPTION:
        case HWND_MENU_PIC_ADJ_BRIGHTNESS_OPTION:
        case HWND_MENU_PICMODE_BRIGHTNESS_OPTION:
        case HWND_MENU_PIC_ADJ_COLOR_OPTION:
        case HWND_MENU_PICMODE_COLOR_OPTION:
        case HWND_MENU_PIC_ADJ_SHARPNESS_OPTION:
        case HWND_MENU_PICMODE_SHARPNESS_OPTION:
        case HWND_MENU_PIC_ADJ_TINT_OPTION:
        case HWND_MENU_PICMODE_TINT_OPTION:
            return _MApp_ZUI_ACT_CombineTextAndOption(hwnd);
        case HWND_MENU_PC_PICTURE_ITEM_BRIGHTNESS_VALUE:
        case HWND_MENU_PICTURE_ITEM_BRIGHTNESS_VALUE:
            return MApp_ZUI_API_GetU16String(ST_PICTURE.u8Brightness);
        case HWND_MENU_PC_PICTURE_ITEM_CONTRAST_VALUE:
        case HWND_MENU_PICTURE_ITEM_CONTRAST_VALUE:
            return MApp_ZUI_API_GetU16String(ST_PICTURE.u8Contrast);
        case HWND_MENU_PICTURE_ITEM_COLOR_VALUE:
            return MApp_ZUI_API_GetU16String(ST_PICTURE.u8Saturation);
        case HWND_MENU_PICTURE_ITEM_SHARPNESS_VALUE:
            return MApp_ZUI_API_GetU16String(ST_PICTURE.u8Sharpness);
        case HWND_MENU_PICTURE_ITEM_TINT_VALUE:
            return MApp_ZUI_API_GetU16String(ST_PICTURE.u8Hue);

        case HWND_MENU_SOUND_SNDMODE_OPTION:
        case HWND_MENU_SNDMODE_SNDMODE_OPTION:
            u16TempID = _MApp_ZUI_ACT_GetAudioModeStringID();
            break;

        case HWND_MENU_SNDMODE_TREBLE_OPTION:
        case HWND_MENU_SNDMODE_BASS_OPTION:
        case HWND_MENU_SNDEQ_120_HZ_OPTION:
        case HWND_MENU_SNDEQ_200_HZ_OPTION:
        case HWND_MENU_SNDEQ_500_HZ_OPTION:
        case HWND_MENU_SNDEQ_1_2_KHZ_OPTION:
        case HWND_MENU_SNDEQ_3_KHZ_OPTION:
        case HWND_MENU_SNDEQ_7_5_KHZ_OPTION:
        case HWND_MENU_SNDEQ_12_KHZ_OPTION:
            return _MApp_ZUI_ACT_CombineTextAndOption(hwnd);

        case HWND_MENU_SOUND_BALANCE_OPTION:
            return MApp_ZUI_API_GetS16SignString(
                (S16)_MApp_ZUI_ACT_GetSoundAdjustValue(hwnd)-50);
        case HWND_MENU_SOUND_AUDIO_DELAY_VALUE:
            #if ENABLE_CUS_AUDIO_DELAY
            return MApp_ZUI_API_GetU16String(stGenSetting.g_SoundSetting.LipSyncDelayTime);
            #else
            return 0;
            #endif

        case HWND_MENU_SOUND_TREBLE_VALUE:
            return MApp_ZUI_API_GetU16String(stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].Treble);
        case HWND_MENU_SOUND_BASS_VALUE:
            return MApp_ZUI_API_GetU16String(stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].Bass);

        case HWND_MENU_SOUND_AUTO_VOLUME_OPTION:
            //from case C2_OPTION_AUTOVOLUMETEXT:
            if(!stGenSetting.g_SysSetting.fAutoVolume)
                u16TempID=en_str_Off;
            else
                u16TempID=en_str_On;
            #if ENABLE_AUTOTEST
            if(g_bAutobuildDebug)
            {
                if(AutoVolume != u16TempID)
                    {
                        printf("52_AutoVolume\n");
                    }
                    AutoVolume = u16TempID;
            }
            #endif
            break;

        case HWND_MENU_SOUND_SPDIF_MODE_OPTION:
            if(stGenSetting.g_SysSetting.fSPDIFMODE == 0)
            {
                u16TempID=en_str_SPDIF_PCM;
            }
            #if ENABLE_CUS_SPDIF_MODE
            else if(stGenSetting.g_SysSetting.fSPDIFMODE >1)
            {
                u16TempID = en_str_Off;
            }
            #endif
            else
            {
                u16TempID=en_str_SPDIF_AUTO;
            }
            break;

        case HWND_MENU_SOUND_SURROUND_OPTION:
            //from case SOUND_SURROUNDSOUND_SELECTTEXT:
#if (ENABLE_CUS_SURROUND_FOLLOW_SNDMODE == DISABLE)
            switch(stGenSetting.g_SoundSetting.SurroundSoundMode & SURROUND_SYSTEM_TYPE_MASK)
#else
            switch(stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].SurroundSoundMode & SURROUND_SYSTEM_TYPE_MASK)
#endif
            {
                case SURROUND_SYSTEM_SURROUNDMAX:
                    #if ENABLE_CUS_UI_SPEC
                    u16TempID = en_str_On;
                    #else
                    u16TempID = en_str_Surround_Max;
                    #endif
                break;

                #if (ENABLE_AUDIO_SURROUND_BBE  == ENABLE )
                case SURROUND_SYSTEM_BBE:
                    u16TempID = en_str_BBE;
                break;
                #endif

                #if (ENABLE_AUDIO_SURROUND_SRS  == ENABLE )
                case SURROUND_SYSTEM_SRS:
                    u16TempID = en_str_SRSTruSurroundXT;
                break;
                #endif

                #if (ENABLE_AUDIO_SURROUND_VDS  == ENABLE )
                case SURROUND_SYSTEM_VDS:
                    u16TempID = en_str_DolbyVirtual;
                break;
                #endif

                #if (ENABLE_AUDIO_SURROUND_VSPK == ENABLE )
                case SURROUND_SYSTEM_VSPK:
                    u16TempID = en_str_DolbyVS;
                break;
                #endif


                default:
                    u16TempID = en_str_Off;

            }
            #if ENABLE_AUTOTEST
            if(g_bAutobuildDebug)
            {
                if(SurroundSound != u16TempID)
                    {
                        printf("53_SurroundSound\n");
                    }
                    SurroundSound = u16TempID;
            }
            #endif
            break;

        case HWND_MENU_SOUND_AD_SWITCH_OPTION:
#if (ENABLE_CUS_UI_SPEC == DISABLE)/*Creass.liu at 2012-06-27*/
        case HWND_MENU_SOUND_SWITCH_AD_SWITCH_OPTION:
#endif
        #if ENABLE_DTV
            //from case OPTION_SOUND_AD_SWITCH_TEXT:
            if(stGenSetting.g_SoundSetting.bEnableAD)
            {
                u16TempID = en_str_On;
            }
            else
            {
                u16TempID = en_str_Off;
            }
         #endif
            break;
 #if (ENABLE_CUS_UI_SPEC == DISABLE)/*Creass.liu at 2012-06-27*/
        case HWND_MENU_SOUND_SWITCH_AD_FADE_OPTION:
            //from case EN_DNUM_AD_FADE_VALUE:
            return _MApp_ZUI_ACT_CombineTextAndOption(hwnd);
 #endif
        /*
        case HWND_MENU_SOUND_AD_PAN_OPTION:
            //from case EN_DNUM_AD_PAN_VALUE:
            switch(stGenSetting.g_SoundSetting.ADOutput)
            {
                case AD_SPEAKER:
                    u16TempID = en_str_Speaker;
                    break;
                case AD_HEADPHONE:
                    u16TempID = en_str_HeadPhone;
                    break;
                case AD_BOTH:
                    u16TempID = en_str_Speaker_Plus_HeadPhone;
                    break;
            }
            break;
        */
#if 0 // no used
        case HWND_MENU_TIME_SET_CLOCK_OPTION:
            return _MApp_ZUI_ACT_GetLocalClockString();

        case HWND_MENU_TIME_SET_OFFTIME_OPTION:
            //from case D2_OPTION_OFFTIMER_SELECTTEXT:
            if(!stGenSetting.g_Time.cOffTimerFlag)
                u16TempID=en_str_Off;
            else
            {
                LPTSTR str = CHAR_BUFFER;
                MApp_UlongToU16String( (U32)stGenSetting.g_Time.u16OffTimer_Info_Hour , str , 2);
                str += 2;

                *str ++ = CHAR_COLON;

                MApp_UlongToU16String( (U32)stGenSetting.g_Time.u16OffTimer_Info_Min , str , 2);
                //str += 2;

                //*str=0;
                return CHAR_BUFFER;
            }
            break;

        case HWND_MENU_TIME_SET_ONTIME_OPTION:
            //from case D3_OPTION_ONTIMER_SELECTTEXT:
            if(!stGenSetting.g_Time.cOnTimerFlag)
                u16TempID=en_str_Off;
            else
            {
                LPTSTR str = CHAR_BUFFER;

                MApp_UlongToU16String( (U32)stGenSetting.g_Time.u16OnTimer_Info_Hour  , str , 2);
                str += 2;

                *str ++ = CHAR_COLON;

                MApp_UlongToU16String( (U32)stGenSetting.g_Time.u16OnTimer_Info_Min , str , 2);
                //str += 2;

                //*str=0;
                return CHAR_BUFFER;
            }
            break;
#endif
        case HWND_MENU_OP_TIME_SUBPAGE_SLEEP_TIME_OPTION:
            _MApp_ZUI_ACT_GetSleepTimerString(CHAR_BUFFER);
            return CHAR_BUFFER;

        case HWND_MENU_OP_TIME_SUBPAGE_AUTO_SLEEP_OPTION:
          #if ENABLE_CUS_AUTO_SLEEP_MODE
            _MApp_ZUI_ACT_GetAutosleepString(CHAR_BUFFER);
            return CHAR_BUFFER;
          #else
            if(!stGenSetting.g_Time.cAutoSleepFlag)
                u16TempID=en_str_Off;
            else
                u16TempID=en_str_On;

            #if ENABLE_AUTOTEST
            if(g_bAutobuildDebug)
            {
                if(AutoSleep != u16TempID)
                    {
                        printf("61_AutoSleep\n");
                    }
                    AutoSleep = u16TempID;
            }
            #endif
         #endif
            break;

#if (ENABLE_CUS_UI_SPEC == FALSE) /*Creass.liu at 2012-06-27*/
        case HWND_MENU_TIME_SET_TIMEZONE_OPTION:
        #if ENABLE_DTV
            //from D1_CLOCK_TIMEZONE_SELECTTEXT:
            {
                U8 u8index = stGenSetting.g_Time.enTimeZone;
                if (u8index >= TIMEZONE_NUM)
                {
                    u8index = 0;
                }
                //u16TempID = _TimezoneString[u8index];
                u16TempID = _MApp_ZUI_ACT_GetTimeZoneStringID((EN_MENU_TIMEZONE)u8index);

            }
            #if ENABLE_AUTOTEST
            if(g_bAutobuildDebug)
            {
                if(TimeZone != u16TempID)
                    {
                        printf("61_TimeZone\n");
                    }
                    TimeZone = u16TempID;
            }
            #endif
            break;
        #else
            break;
        #endif
#endif
        case HWND_MENU_OPTION_OSD_LANG_OPTION:
            u16TempID = _MApp_ZUI_ACT_GetLanguageStringID(
                GET_OSD_MENU_LANGUAGE_DTG(), TRUE);
            #if ENABLE_AUTOTEST
            if(g_bAutobuildDebug)
            {
                if(OSD_L != u16TempID)
                {
                     printf("71_OSD_Language\n");
                }
                OSD_L = u16TempID;
            }
            #endif
            break;
     #if(UI_SKIN_SEL==UI_SKIN_1366X768X565_HAIER_CN)  // CUS_xm zHIHE 20120807 modify
		#if ENABLE_TTX
        case HWND_MENU_OPTION_TELETEXT_OPTION:
             switch(GET_TTX_LANGUAGE())
             {
                case TT_Charset_Group_West:
					 u16TempID=en_str_TTX_Language_West;
					 break;
				case TT_Charset_Group_East:
					 u16TempID=en_str_TTX_Language_East;
					 break;
			    case TT_Charset_Group_Russian:
					 u16TempID=en_str_TTX_Language_Russian;
					 break;
			    case TT_Charset_Group_Arabic:
					 u16TempID=en_str_TTX_Language_Arabic;
					 break;
			    default: break;
             }
             break;
		 #endif
	  #endif
        case HWND_MENU_OPTION_AUDIO_LANG_OPTION:
        #if ENABLE_DTV
            //from case AUDIOLANGUAGESELECTTEXT:
            u16TempID = _MApp_ZUI_ACT_GetLanguageStringID(
                (EN_LANGUAGE)stGenSetting.g_SoundSetting.enSoundAudioLan1, TRUE);
            #if ENABLE_AUTOTEST
            if(g_bAutobuildDebug)
            {
                if(Audio_L != u16TempID)
                {
                     printf("71_Audio_Language\n");
                }
                Audio_L = u16TempID;
            }
            #endif
            break;
        #else
            break;
        #endif

        case HWND_MENU_OPTION_SUBTITLE_LANG_OPTION:
        #if ENABLE_DTV
            //from case SUBTITLELANGUAGESELECTTEXT:
            u16TempID=_MApp_ZUI_ACT_GetLanguageStringID(
                (EN_LANGUAGE)SUBTITLE_DEFAULT_LANGUAGE_1, TRUE);
            #if ENABLE_AUTOTEST
            if(g_bAutobuildDebug)
            {
                if(Subtitle_L != u16TempID)
                {
                     printf("71_Subtitle_Language\n");
                }
                Subtitle_L = u16TempID;
            }
            #endif
            break;
        #else
            break;
        #endif

#if (ENABLE_CUS_UI_SPEC == DISABLE) /*Creass.liu at 2012-06-02*/
        case HWND_MENU_OPTION_HARD_HEARING_OPTION:
        #if ENABLE_DTV
            //from case LANGUAGE_SUBTITLE_MODE_HEARING_SELECTTEXT:
            switch (stGenSetting.g_SysSetting.fHardOfHearing)
            {
                case EN_SUBTITILE_SYSTEM_OFF:
                    u16TempID=en_str_Off;
                    break;
                case EN_SUBTITILE_SYSTEM_ON:
                    u16TempID=en_str_On;
                    break;
            }
            #if ENABLE_AUTOTEST
            if(g_bAutobuildDebug)
            {
                if(Headphone_L != u16TempID)
                    {
                        printf("72_Headphone\n");
                    }
                    Headphone_L = u16TempID;
            }
            #endif
            break;
        #else
            break;
        #endif


        case HWND_MENU_OPTION_DIVX:
            {
#if ENABLE_DRM
                u16TempID=en_str_DivX;
#else
                u16TempID=Empty;
#endif
                break;
            }

        case HWND_MENU_OPTION_DEACTIVATION:
            {
#if ENABLE_DRM
                u16TempID=en_str_Deactivaton;
#else
                u16TempID=Empty;
#endif
                break;
            }
#endif

        case HWND_MENU_OPTION_OSD_EFFECT_OPTION:
            switch (stGenSetting.g_SysSetting.fEnableOsdAnimation)
            {
                case EN_OSD_EFFECT_ON:
                    u16TempID=en_str_On;
                    break;
                case EN_OSD_EFFECT_ROTATION_ONLY:
                    u16TempID=en_str_OSD_Rotation_only;
                    break;
            }
            break;

        case HWND_MENU_OPTION_COUNTRY_OPTION:
            u16TempID = _MApp_ZUI_ACT_GetCountryStringID(OSD_COUNTRY_SETTING);
            break;
#if 0
        case HWND_MENU_LOCK_SYSTEM_OPTION:
            if(!stGenSetting.g_BlockSysSetting.u8EnterLockPage)
            {
                MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_SET_PASSWORD, DISABLE);
                MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_BLOCK_PROGRAM, DISABLE);
                MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_PARENTAL_GUIDANCE, DISABLE);

                MApp_ZUI_API_InvalidateWindow(HWND_MENU_LOCK_PAGE_LIST_DTV);
                //MApp_ZUI_API_InvalidateWindow(HWND_MENU_LOCK_PAGE_LIST);

                break;
            }
            else
            {
                MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_SET_PASSWORD, ENABLE);
                MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_BLOCK_PROGRAM, ENABLE);
                MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_PARENTAL_GUIDANCE, ENABLE);
                MApp_ZUI_API_InvalidateWindow(HWND_MENU_LOCK_PAGE_LIST_DTV);
                //MApp_ZUI_API_InvalidateWindow(HWND_MENU_LOCK_PAGE_LIST);
            }

            if(!stGenSetting.g_BlockSysSetting.u8BlockSysLockMode)
                u16TempID=en_str_Off;
            else
                u16TempID=en_str_On;
            #if ENABLE_AUTOTEST
            if(g_bAutobuildDebug)
            {
                if(LockS != u16TempID)
                {
                    printf("81_LockSystem\n");
                }
                LockS = u16TempID;
            }
            #endif
            break;
        case HWND_MENU_LOCK_PARENTAL_GUIDANCE_OPTION:
            #if ENABLE_AUTOTEST
            if(g_bAutobuildDebug)
            {
                if(ParentalG != stGenSetting.g_BlockSysSetting.u8ParentalControl)
                {
                    printf("81_ParentalGuidance\n");
                }
                ParentalG = stGenSetting.g_BlockSysSetting.u8ParentalControl;
            }
            #endif

            if(stGenSetting.g_BlockSysSetting.u8ParentalControl<=EN_F4_ParentalControl_Off )
            {
                stGenSetting.g_BlockSysSetting.u8ParentalControl= EN_F4_ParentalControl_Off;
                u16TempID=en_str_Off;
            }
            else
            {
                return MApp_ZUI_API_GetU16String(stGenSetting.g_BlockSysSetting.u8ParentalControl);
            }
            break;
#endif
#if ENABLE_SBTVD_BRAZIL_APP
        case HWND_MENU_OPTION_CAPTION_OPTION:

            if(IsDTVInUse())
            {
                if(stGenSetting.g_SysSetting.enDTVCaptionType == DTV_CAPTION_ON)
                {
                    u16TempID=en_str_On;
                }
                else
                {
                    u16TempID=en_str_Off;
                }
            }
            else
            {
                if(stGenSetting.g_SysSetting.enATVCaptionType == ATV_CAPTION_TYPE_CC1)
                {
                    u16TempID=en_str_CC1;
                }
                else if(stGenSetting.g_SysSetting.enATVCaptionType == ATV_CAPTION_TYPE_CC2)
                {
                    u16TempID=en_str_CC2;
                }
                else if(stGenSetting.g_SysSetting.enATVCaptionType == ATV_CAPTION_TYPE_CC3)
                {
                    u16TempID=en_str_CC3;
                }
                else if(stGenSetting.g_SysSetting.enATVCaptionType == ATV_CAPTION_TYPE_CC4)
                {
                    u16TempID=en_str_CC4;
                }
                else if(stGenSetting.g_SysSetting.enATVCaptionType == ATV_CAPTION_TYPE_TEXT1)
                {
                    u16TempID=en_str_Text1;
                }
                else if(stGenSetting.g_SysSetting.enATVCaptionType == ATV_CAPTION_TYPE_TEXT2)
                {
                    u16TempID=en_str_Text2;
                }
                else if(stGenSetting.g_SysSetting.enATVCaptionType == ATV_CAPTION_TYPE_TEXT3)
                {
                    u16TempID=en_str_Text3;
                }
                else if(stGenSetting.g_SysSetting.enATVCaptionType == ATV_CAPTION_TYPE_TEXT4)
                {
                    u16TempID=en_str_Text4;
                }
                else
                {
                    stGenSetting.g_SysSetting.enATVCaptionType = ATV_CAPTION_TYPE_OFF;
                    u16TempID=en_str_Off;
                }
            }
            break;
#endif
#if (ENABLE_CUS_UI_SPEC == DISABLE)
        case HWND_MENU_PCMODE_HPOS_OPTION:
        case HWND_MENU_PCMODE_VPOS_OPTION:
        case HWND_MENU_PCMODE_SIZE_OPTION:
        case HWND_MENU_PCMODE_PHASE_OPTION:
            return _MApp_ZUI_ACT_CombineTextAndOption(hwnd);
#endif
        case HWND_MENU_DLG_SIGNAL_INFORMAT_CHANNEL_UHF:
            return 0;// can return Freq here,if need be

      #if ENABLE_DTV
        case HWND_MENU_DLG_SIGNAL_INFORMAT_NETWORK_NAME:
        {

            U8  i;
            WORD SignalStrength;
            U8  au8NetWorkName[MAX_NETWORK_NAME];
            U8 len;
            U16 u16NetLen;
            LPTSTR u16NetStr = CHAR_BUFFER;
            msAPI_Tuner_CheckSignalStrength(&SignalStrength);

            MApp_ZUI_API_LoadString(en_str_Network, u16NetStr);
            u16NetLen = MApp_ZUI_API_Strlen(u16NetStr);
            u16NetStr[u16NetLen++] = CHAR_SPACE;
            memset(au8NetWorkName,0,MAX_NETWORK_NAME);
            if ((TRUE == MApp_SI_Get_NetWorkName(au8NetWorkName,&len,MAX_NETWORK_NAME)) && (0!=au8NetWorkName[0]))
            {
                msAPI_CM_SetCurrentNetworkName(au8NetWorkName, len);
            }
            if(msAPI_CM_GetCurrentNetworkName(au8NetWorkName,&len,MAX_NETWORK_NAME) && SignalStrength>2)
            {
                for(i=0; i<len; i++)
                   u16NetStr[u16NetLen+i] = au8NetWorkName[i];

                u16NetStr[u16NetLen+i] = 0;
            }
            else
            {
                u16NetStr[u16NetLen++] = '.';
                u16NetStr[u16NetLen++] = '.';
                u16NetStr[u16NetLen++] = '.';
                u16NetStr[u16NetLen++] = 0;
            }
            return u16NetStr;

        }
      #endif // #if ENABLE_DTV

      #if ENABLE_DTV
        case HWND_MENU_DLG_SIGNAL_INFORMAT_CHANNEL_NAME:
      #endif

        case HWND_MENU_DLG_SIGNAL_INFORMAT_QUALITY_PERCENT_VAL:
        case HWND_MENU_DLG_SIGNAL_INFORMAT_STRENGTH_PERCENT_VAL:
        case HWND_MENU_DLG_SIGNAL_INFORMAT_MODULATION_NAME:
            return _MApp_ZUI_ACT_CombineTextAndOption(hwnd);
      #if ENABLE_3D_PROCESS
        case HWND_MENU_OPTION_3D_TYPE_OPTION:
           {
                EN_3D_TYPE    en3DType;
                #if ENABLE_CUS_3D_SOURCE_MEMORY
                if(IsHDMIInUse() && (g_HdmiPollingStatus.bIsHDMIMode == FALSE)) //dvi
                {
                    en3DType = ST_VGA_3D_TYPE;
                }
                else
                #endif
                {
                    en3DType = ST_3D_TYPE;
                }
                switch(en3DType)
                {
                   case EN_3D_BYPASS:
                        u16TempID = en_strbypass;
                        break;
                    case EN_3D_FRAME_PARKING:
                         u16TempID = en_strFrame_parking;
                         break;
                   case EN_3D_SIDE_BY_SIDE:
                        u16TempID = en_strside_by_side;
                        break;
                    case EN_3D_TOP_BOTTOM:
                        u16TempID = en_strtop_bottom;
                        break;
                    case EN_3D_LINE_BY_LINE:
                        u16TempID = en_strline_by_line;
                        break;
                    case EN_3D_FRAME_ALTERNATIVE:
                         u16TempID = en_strFrame_alternative;
                         break;
                    case EN_3D_NORMAL_2D:
                        u16TempID = en_strnormal_2d;
                        break;
                    case EN_3D_3D_TO_2D:
                        u16TempID = en_str3D_2D;
                        break;
                    default:
                         u16TempID = en_strbypass;
                        break;
                }
            }
            break ;
          case HWND_MENU_OPTION_3D_DETECT_OPTION:
            switch(stGenSetting.g_SysSetting.en3DDetectMode)
            {
                case EN_3D_DETECT_AUTO:
                     u16TempID = en_str_AUTO;
                     break;
               case EN_3D_DETECT_MANUAL:
                    u16TempID = en_strManual;
                    break;
                default:
                     u16TempID = en_str_AUTO;
                    break;
            }
            break ;
          case HWND_MENU_OPTION_3D_LR_OPTION:
            {
                EN_3D_LR_MODE enLRMODE;
                #if ENABLE_CUS_3D_SOURCE_MEMORY
                if(IsHDMIInUse() && (g_HdmiPollingStatus.bIsHDMIMode == FALSE)) //dvi
                {
                    enLRMODE = ST_VGA_3D_LRMODE;
                }
                else
                #endif
                {
                    enLRMODE = ST_3D_LRMODE;
                }
                switch(enLRMODE)
                {
                    case EN_3D_LR_L:
                         u16TempID = en_str_3D_LRSwap_LR;
                         break;
                   case EN_3D_LR_R:
                        u16TempID = en_str_3D_LRSwap_RL;
                        break;
                    default:
                         u16TempID = en_str_3D_LRSwap_LR;
                        break;
                }
            }
            break ;

      #endif
           case HWND_MENU_OPTION_BLENDING_OPTION:
            switch(stGenSetting.g_SysSetting.OsdBlending)
            {
                  case EN_OSD_TRAN_OFF:
                     u16TempID = en_str_Off;
                    break;

                 case EN_OSD_TRAN_LOW:
                     u16TempID = en_str_LOW;
                    break;
                 case EN_OSD_TRAN_MIDDLE:
                      u16TempID = en_str_MIDDLE;
                    break;
                 case EN_OSD_TRAN_HIGH:
                     u16TempID = en_str_HIGH;
                    break;
                 default:
                     u16TempID = en_str_Off;
                    break;
            }
            break;

           case HWND_MENU_OPTION_POWERON_MUSIC_OPTION:
              #if (ENABLE_DMP)
               switch(stGenSetting.g_SysSetting.UsrPowerOnMusic)
               {
                    case POWERON_MUSIC_OFF:
                        u16TempID = en_str_Off;
                       break;
                    case POWERON_MUSIC_DEFAULT:
                         u16TempID = en_str_On;
                       break;
                    case POWERON_MUSIC_USER:
                        u16TempID = en_str_USB;
                       break;
                    default:
                        u16TempID = en_str_Off;
                       break;
               }
              #endif
               break;

           case HWND_MENU_OPTION_POWERON_LOGO_OPTION:
              #if (ENABLE_DMP)
               switch(stGenSetting.g_SysSetting.UsrLogo)
               {
                    case POWERON_LOGO_OFF:
                        u16TempID = en_str_DMP_AB_NONE;
                       break;
                    case POWERON_LOGO_DEFAULT:
                         u16TempID = en_str_DEFAULT;
                       break;
                    case POWERON_LOGO_USER:
                        u16TempID = en_str_Capture_Logo1;
                       break;
                    default:
                        u16TempID = en_str_Off;
                       break;
               }
              #endif
               break;

           case HWND_MENU_OPTION_DUETIME_OPTION:
                switch(stGenSetting.g_SysSetting.OsdDuration)
                {
                #if ENABLE_CUS_OSD_TIMEOUT
                    case EN_OSD_TIME_10:
                        _MApp_ZUI_ACT_CombineDureTimerString(CHAR_BUFFER, 10);
                        return CHAR_BUFFER;
                    case EN_OSD_TIME_20:
                        _MApp_ZUI_ACT_CombineDureTimerString(CHAR_BUFFER, 20);
                        return CHAR_BUFFER;
                    case EN_OSD_TIME_30:
                        _MApp_ZUI_ACT_CombineDureTimerString(CHAR_BUFFER, 30);
                        return CHAR_BUFFER;
                    case EN_OSD_TIME_40:
                        _MApp_ZUI_ACT_CombineDureTimerString(CHAR_BUFFER, 40);
                        return CHAR_BUFFER;
                    case EN_OSD_TIME_50:
                        _MApp_ZUI_ACT_CombineDureTimerString(CHAR_BUFFER, 50);
                        return CHAR_BUFFER;
                    case EN_OSD_TIME_60:
                        _MApp_ZUI_ACT_CombineDureTimerString(CHAR_BUFFER, 60);
                        return CHAR_BUFFER;
                #else
                    case EN_OSD_TIME_5:
                        _MApp_ZUI_ACT_CombineDureTimerString(CHAR_BUFFER, 5);
                        return CHAR_BUFFER;
                    case EN_OSD_TIME_10:
                        _MApp_ZUI_ACT_CombineDureTimerString(CHAR_BUFFER, 10);
                        return CHAR_BUFFER;
                    case EN_OSD_TIME_15:
                        _MApp_ZUI_ACT_CombineDureTimerString(CHAR_BUFFER, 15);
                        return CHAR_BUFFER;
                #endif
                    case EN_OSD_TIME_ALWAYS:
                        u16TempID=en_str_Off;
                        break;
                    default:
                        break;

                }
                break;
      #if (ATSC_CC == ATV_CC)
        case HWND_MENU_OPTION_CC_OPTION_OPTION:
            switch(stGenSetting.g_SysSetting.enATVCaptionType)
            {
                case ATV_CAPTION_TYPE_OFF:
                     u16TempID = en_str_Off;
                     break;
               case ATV_CAPTION_TYPE_CC1:
                    u16TempID = en_str_CC1;
                    break;
                case ATV_CAPTION_TYPE_CC2:
                    u16TempID = en_str_CC2;
                    break;
                case ATV_CAPTION_TYPE_CC3:
                    u16TempID = en_str_CC3;
                    break;
                case ATV_CAPTION_TYPE_CC4:
                    u16TempID = en_str_CC4;
                    break;
                case ATV_CAPTION_TYPE_TEXT1:
                    u16TempID = en_str_Text1;
                    break;
                case ATV_CAPTION_TYPE_TEXT2:
                    u16TempID = en_str_Text2;
                    break;
                case ATV_CAPTION_TYPE_TEXT3:
                    u16TempID = en_str_Text3;
                    break;
                case ATV_CAPTION_TYPE_TEXT4:
                    u16TempID = en_str_Text4;
                    break;
                default:
                    break;
            }
            break ;
      #endif // #ifdef NTSC_CC_ON_DVB
	  #if(UI_SKIN_SEL==UI_SKIN_1366X768X565_HAIER_CN)  // CUS_xm zHIHE 20120807 modify
	  /*
	  case HWND_MENU_LOCK_ENTER_PASSWORD_OPTION:
	  	        if(g_u8PasswordCount==0)
					break;
				else if(g_u8PasswordCount==1)
                u16TempID = en_str_On;
				MApp_ZUI_API_SetFocus(HWND_MENU_LOCK_ENTER_PASSWORD_OPTION_1);
            break;
	  case HWND_MENU_LOCK_ENTER_PASSWORD_OPTION_1:
	  		  	if(g_u8PasswordCount!=2)
					break;
				else if(g_u8PasswordCount==2)
                u16TempID = en_str_On;
				MApp_ZUI_API_SetFocus(HWND_MENU_LOCK_ENTER_PASSWORD_OPTION_2);

            break;
	 case HWND_MENU_LOCK_ENTER_PASSWORD_OPTION_2:
                if(g_u8PasswordCount!=3)
					break;
				else if(g_u8PasswordCount==3)
                u16TempID = en_str_On;
				MApp_ZUI_API_SetFocus(HWND_MENU_LOCK_ENTER_PASSWORD_OPTION_3);
            break;

	case HWND_MENU_LOCK_ENTER_PASSWORD_OPTION_3:
		        if(g_u8PasswordCount!=4)
					break;
				else if(g_u8PasswordCount==4)
                u16TempID = en_str_On;
				//MApp_ZUI_API_SetFocus(HWND_MENU_LOCK_ENTER_PASSWORD);
            break;
	*/
			case HWND_MENU_LOCK_ENTER_PASSWORD_OPTION:
                if(g_u8PasswordCount<1)

                CHAR_BUFFER[0] = '_';
				else if(g_u8PasswordCount<5)
				{
				   CHAR_BUFFER[0] = '*';

				  MApp_ZUI_API_SetFocus(HWND_MENU_LOCK_ENTER_PASSWORD_OPTION_1);
				}
				CHAR_BUFFER[1] = 0;
				return CHAR_BUFFER;

			case HWND_MENU_LOCK_ENTER_PASSWORD_OPTION_1:
                if(g_u8PasswordCount<2)

                CHAR_BUFFER[0] = '_';
				else if(g_u8PasswordCount<5)
				{
				   CHAR_BUFFER[0] = '*';

				  MApp_ZUI_API_SetFocus(HWND_MENU_LOCK_ENTER_PASSWORD_OPTION_2);
				}
				CHAR_BUFFER[1] = 0;

				return CHAR_BUFFER;

		   case HWND_MENU_LOCK_ENTER_PASSWORD_OPTION_2:
			   if(g_u8PasswordCount<3)

			   CHAR_BUFFER[0] = '_';
			   else if(g_u8PasswordCount<5)
			   {
				   CHAR_BUFFER[0] = '*';

				  MApp_ZUI_API_SetFocus(HWND_MENU_LOCK_ENTER_PASSWORD_OPTION_3);
				}
			   CHAR_BUFFER[1] = 0;

			   return CHAR_BUFFER;


		  case HWND_MENU_LOCK_ENTER_PASSWORD_OPTION_3:
			   if(g_u8PasswordCount<4)

			   CHAR_BUFFER[0] = '_';
			   else if(g_u8PasswordCount<5)
			   CHAR_BUFFER[0] = '*';
			   CHAR_BUFFER[1] = 0;
			  // MApp_ZUI_API_SetFocus(HWND_MENU_LOCK_ENTER_PASSWORD_OPTION_1);
			   return CHAR_BUFFER;


      #else
	  case HWND_MENU_LOCK_ENTER_PASSWORD_OPTION:
		  for(u16Value = 0; u16Value < PASSWORD_SIZE; u16Value++)
		  {
			  if(u16Value < g_u8PasswordCount)
				  CHAR_BUFFER[u16Value] = '*';
			  else
				  CHAR_BUFFER[u16Value] = '_';
		  }
		  CHAR_BUFFER[PASSWORD_SIZE] = 0;
		  return CHAR_BUFFER;
	  #endif
	  case HWND_MENU_LOCK_NEWPSW_OPTION:
		  for(u16Value = 0; u16Value < PASSWORD_SIZE; u16Value++)
		  {
			  if(u16Value < g_u8PasswordCount)
				  CHAR_BUFFER[u16Value] = '*';
			  else
				  CHAR_BUFFER[u16Value] = ' ';
		  }
		  CHAR_BUFFER[PASSWORD_SIZE] = 0;
		  return CHAR_BUFFER;
	  case HWND_MENU_LOCK_CONFIMNEWPSW_OPTION:
		  for(u16Value = 0; u16Value < PASSWORD_SIZE; u16Value++)
		  {
			  if(u16Value < g_u8PasswordCount)
				  CHAR_BUFFER[u16Value] = '*';
			  else
				  CHAR_BUFFER[u16Value] = ' ';
		  }
		  CHAR_BUFFER[PASSWORD_SIZE] = 0;
		  return CHAR_BUFFER;

       #if (ENABLE_ATV_VCHIP)
        //Lock Page
        case HWND_MENU_LOCK_MAINSUBPAGE_ITEM_SYSTEMLOCK_OPTION:
            if (stGenSetting.g_VChipSetting.u8VChipLockMode==0)
                u16TempID = en_str_Off;
            else
                u16TempID = en_str_On;
            break;


        case HWND_MENU_LOCK_CHANGEPWSUBPAGE_ITEM_OLDPW_OPTION:
            break;
        case HWND_MENU_LOCK_CHANGEPWSUBPAGE_ITEM_NEWPW_OPTION:
            break;
        case HWND_MENU_LOCK_CHANGEPWSUBPAGE_ITEM_COMFIRM_OPTION:
            break;
        case HWND_MENU_LOCK_INPUTBLOCKSUBPAGE_ITEM_TV_OPTION:
            if (stGenSetting.g_VChipSetting.u8InputBlockItem & INPUT_BLOCK_TV)
                u16TempID = en_strInputLockBlockedText;
            else
                u16TempID = en_strInputLockUnBlockedText;
            break;
        case HWND_MENU_LOCK_INPUTBLOCKSUBPAGE_ITEM_AV_OPTION:
            if (stGenSetting.g_VChipSetting.u8InputBlockItem & INPUT_BLOCK_AV)
                u16TempID = en_strInputLockBlockedText;
            else
                u16TempID = en_strInputLockUnBlockedText;
            break;
        case HWND_MENU_LOCK_INPUTBLOCKSUBPAGE_ITEM_SVIDEO_OPTION:
            if (stGenSetting.g_VChipSetting.u8InputBlockItem & INPUT_BLOCK_SV)
                u16TempID = en_strInputLockBlockedText;
            else
                u16TempID = en_strInputLockUnBlockedText;
            break;
        case HWND_MENU_LOCK_INPUTBLOCKSUBPAGE_ITEM_COMPONENT_OPTION:
            if (stGenSetting.g_VChipSetting.u8InputBlockItem & INPUT_BLOCK_YPBPR)
                u16TempID = en_strInputLockBlockedText;
            else
                u16TempID = en_strInputLockUnBlockedText;
            break;
        case HWND_MENU_LOCK_INPUTBLOCKSUBPAGE_ITEM_HDMI_OPTION:
            if (stGenSetting.g_VChipSetting.u8InputBlockItem & INPUT_BLOCK_HDMI)
                u16TempID = en_strInputLockBlockedText;
            else
                u16TempID = en_strInputLockUnBlockedText;
            break;
        case HWND_MENU_LOCK_INPUTBLOCKSUBPAGE_ITEM_PC_OPTION:
            if (stGenSetting.g_VChipSetting.u8InputBlockItem & INPUT_BLOCK_PC)
                u16TempID = en_strInputLockBlockedText;
            else
                u16TempID = en_strInputLockUnBlockedText;
            break;

        case HWND_MENU_LOCK_VCHIPSUBPAGE_TITLE:
            if(g_vchipPageType == EN_VCHIP_MPAA)
            {
                u16TempID = en_strVChipUSMPAAText;
            }
            else if(g_vchipPageType == EN_VCHIP_CANADAENG)
            {
                u16TempID = en_strCanadaCEText;
            }
            else if(g_vchipPageType == EN_VCHIP_CANADAFRE)
            {
                u16TempID = en_strCanadaCFText;
            }
            break;
        case HWND_MENU_LOCK_VCHIPSUBPAGE_ITEM1_TEXT:
            if(g_vchipPageType == EN_VCHIP_MPAA)
            {
                u16TempID = en_strMPAA_G_Text;
            }
            else if(g_vchipPageType == EN_VCHIP_CANADAENG)
            {
                u16TempID = en_strCANADA_VChip_C_Text;
            }
            else if(g_vchipPageType == EN_VCHIP_CANADAFRE)
            {
                u16TempID = en_strCANADA_VChip_G_Text;
            }
            break;
        case HWND_MENU_LOCK_VCHIPSUBPAGE_ITEM2_TEXT:
            if(g_vchipPageType == EN_VCHIP_MPAA)
            {
                u16TempID = en_strMPAA_PG_Text;
            }
            else if(g_vchipPageType == EN_VCHIP_CANADAENG)
            {
                u16TempID = en_strCANADA_VChip_C8_Text;
            }
            else if(g_vchipPageType == EN_VCHIP_CANADAFRE)
            {
                u16TempID = en_strCANADA_VChip_8ans_Text;
            }
            break;
        case HWND_MENU_LOCK_VCHIPSUBPAGE_ITEM3_TEXT:
            if(g_vchipPageType == EN_VCHIP_MPAA)
            {
                u16TempID = en_strMPAA_PG13_Text;
            }
            else if(g_vchipPageType == EN_VCHIP_CANADAENG)
            {
                u16TempID = en_strCANADA_VChip_G_Text;
            }
            else if(g_vchipPageType == EN_VCHIP_CANADAFRE)
            {
                u16TempID = en_strCANADA_VChip_13ans_Text;
            }
            break;
        case HWND_MENU_LOCK_VCHIPSUBPAGE_ITEM4_TEXT:
            if(g_vchipPageType == EN_VCHIP_MPAA)
            {
                u16TempID = en_strMPAA_R_Text;
            }
            else if(g_vchipPageType == EN_VCHIP_CANADAENG)
            {
                u16TempID = en_strCANADA_VChip_PG_Text;
            }
            else if(g_vchipPageType == EN_VCHIP_CANADAFRE)
            {
                u16TempID = en_strCANADA_VChip_16ans_Text;
            }
            break;
        case HWND_MENU_LOCK_VCHIPSUBPAGE_ITEM5_TEXT:
            if(g_vchipPageType == EN_VCHIP_MPAA)
            {
                u16TempID = en_strMPAA_NC17_Text;
            }
            else if(g_vchipPageType == EN_VCHIP_CANADAENG)
            {
                u16TempID = en_strCANADA_VChip_14_Text;
            }
            else if(g_vchipPageType == EN_VCHIP_CANADAFRE)
            {
                u16TempID = en_strCANADA_VChip_18ans_Text;
            }
            break;
        case HWND_MENU_LOCK_VCHIPSUBPAGE_ITEM6_TEXT:
            if(g_vchipPageType == EN_VCHIP_MPAA)
            {
                u16TempID = en_strMPAA_X_Text;
            }
            else if(g_vchipPageType == EN_VCHIP_CANADAENG)
            {
                u16TempID = en_strCANADA_VChip_18_Text;
            }
            else if(g_vchipPageType == EN_VCHIP_CANADAFRE)
            {
                u16TempID = en_strCANADA_VChip_EXEMPT_Text;
            }
            break;
        case HWND_MENU_LOCK_VCHIPSUBPAGE_ITEM7_TEXT:
            if(g_vchipPageType == EN_VCHIP_MPAA)
            {
                u16TempID = en_strMPAA_NA_Text;
            }
            else if(g_vchipPageType == EN_VCHIP_CANADAENG)
            {
                u16TempID = en_strCANADA_VChip_EXEMPT_Text;
            }
            break;
        case HWND_MENU_LOCK_VCHIPSUBPAGE_ITEM1_OPTION:
        case HWND_MENU_LOCK_VCHIPSUBPAGE_ITEM2_OPTION:
        case HWND_MENU_LOCK_VCHIPSUBPAGE_ITEM3_OPTION:
        case HWND_MENU_LOCK_VCHIPSUBPAGE_ITEM4_OPTION:
        case HWND_MENU_LOCK_VCHIPSUBPAGE_ITEM5_OPTION:
        case HWND_MENU_LOCK_VCHIPSUBPAGE_ITEM6_OPTION:
        case HWND_MENU_LOCK_VCHIPSUBPAGE_ITEM7_OPTION:
            u16Value = _MApp_ZUI_ACT_VchipWindowMapToIndex(hwnd);
            if(g_vchipPageType == EN_VCHIP_MPAA && u16Value >= VCHIP_MPAA_ITEMNUM-1)
            {
                break;
            }
            else if(g_vchipPageType == EN_VCHIP_CANADAENG && u16Value >= VCHIP_CANADAENG_ITEMNUM-1)
            {
                break;
            }
            else if(g_vchipPageType == EN_VCHIP_CANADAFRE && u16Value >= VCHIP_CANADAFRE_ITEMNUM-1)
            {
                break;
            }
            if(u16Value >= _MApp_ZUI_ACT_VchipWindowMapToIndex(MApp_ZUI_API_GetFocus()))
            {
                u16TempID = en_strLockTitleText;
            }
            break;
            #endif

#if ENABLE_CEC
        case HWND_MENU_HDMI_CEC_HDMI_OPTION:
            if (stGenSetting.g_SysSetting.g_enHDMICEC == EN_E4_HDMICEC_On)
                u16TempID = en_str_On;
            else
                u16TempID = en_str_Off;
            break;

        case HWND_MENU_HDMI_CEC_AUTO_STANDBY_OPTION:
            if (stGenSetting.g_SysSetting.g_bHdmiCecDeviceAutoStandby)
                u16TempID = en_str_On;
            else
                u16TempID = en_str_Off;
            break;


        case HWND_MENU_HDMI_CEC_DEVICE_LIST_A:
            if(u8HDMI_CEC_DevicesName[0] != NULL)
                return MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, u8HDMI_CEC_DevicesName[0], strlen((const char *)u8HDMI_CEC_DevicesName[0]));
            break;

        case HWND_MENU_HDMI_CEC_DEVICE_LIST_B:
            if(u8HDMI_CEC_DevicesName[1] != NULL)
                return MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, u8HDMI_CEC_DevicesName[1], strlen((const char *)u8HDMI_CEC_DevicesName[1]));
            break;

        case HWND_MENU_HDMI_CEC_DEVICE_LIST_C:
            if(u8HDMI_CEC_DevicesName[2] != NULL)
                return MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, u8HDMI_CEC_DevicesName[2], strlen((const char *)u8HDMI_CEC_DevicesName[2]));
            break;

        case HWND_MENU_HDMI_CEC_DEVICE_LIST_D:
            if(u8HDMI_CEC_DevicesName[3] != NULL)
                return MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, u8HDMI_CEC_DevicesName[3], strlen((const char *)u8HDMI_CEC_DevicesName[3]));
            break;

        case HWND_MENU_HDMI_CEC_DEVICE_LIST_E:
            if(u8HDMI_CEC_DevicesName[4] != NULL)
                return MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, u8HDMI_CEC_DevicesName[4], strlen((const char *)u8HDMI_CEC_DevicesName[4]));
            break;

        case HWND_MENU_HDMI_CEC_DEVICE_LIST_F:
            if(u8HDMI_CEC_DevicesName[5] != NULL)
                return MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, u8HDMI_CEC_DevicesName[5], strlen((const char *)u8HDMI_CEC_DevicesName[5]));
            break;

        case HWND_MENU_HDMI_CEC_DEVICE_LIST_G:
            if(u8HDMI_CEC_DevicesName[6] != NULL)
                return MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, u8HDMI_CEC_DevicesName[6], strlen((const char *)u8HDMI_CEC_DevicesName[6]));
            break;

        case HWND_MENU_HDMI_CEC_DEVICE_LIST_H:
            if(u8HDMI_CEC_DevicesName[7] != NULL)
                return MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, u8HDMI_CEC_DevicesName[7], strlen((const char *)u8HDMI_CEC_DevicesName[7]));
            break;

        case HWND_MENU_HDMI_CEC_DEVICE_LIST_I:
            if(u8HDMI_CEC_DevicesName[8] != NULL)
                return MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, u8HDMI_CEC_DevicesName[8], strlen((const char *)u8HDMI_CEC_DevicesName[8]));
            break;

        case HWND_MENU_HDMI_CEC_DEVICE_LIST_J:
            if(u8HDMI_CEC_DevicesName[9] != NULL)
                return MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, u8HDMI_CEC_DevicesName[9], strlen((const char *)u8HDMI_CEC_DevicesName[9]));
            break;
            // Temp define 10 devices in UI and source code
#endif

        case HWND_MENU_PICTURE_ADJUST_TEXT:
            switch (prePictureHWND)
            {
                case HWND_MENU_PC_PICTURE_ITEM_CONTRAST:
                case HWND_MENU_PICTURE_ITEM_CONTRAST:
                    u16TempID = en_str_Picture_User_Contrast;
                    break;
                case HWND_MENU_PC_PICTURE_ITEM_BRIGHTNESS:
                case HWND_MENU_PICTURE_ITEM_BRIGHTNESS:
                    u16TempID = en_str_Picture_User_Brightness;
                    break;
                case HWND_MENU_PICTURE_ITEM_SHARPNESS:
                    u16TempID = en_str_Picture_User_Sharpness;
                    break;
                case HWND_MENU_PICTURE_ITEM_TINT:
                    u16TempID = en_str_Picture_User_Tint;
                    break;
                case HWND_MENU_PICTURE_ITEM_COLOR:
                    u16TempID = en_str_Picture_User_Color;
                    break;
               case HWND_MENU_ADVANCE_PICTURE_PC_BACKLIGHT:
                    u16TempID = en_str_Backlight;
                    break;
                case HWND_MENU_SOUND_BALANCE:
                    u16TempID = en_str_Balance;
                    break;
                case HWND_MENU_SOUND_AUDIO_DELAY:
                    u16TempID = en_str_AudioDelay;
                    break;
                case HWND_MENU_SOUND_TREBLE:
                    u16TempID = en_str_Sound_User_Treble;
                    break;
                case HWND_MENU_SOUND_BASS:
                    u16TempID = en_str_Sound_User_Bass;
                    break;

                case HWND_MENU_PCMODE_ADJUST_H_POS:
                    u16TempID = en_str_PCMenu_PositionH;
                    break;
                case HWND_MENU_PCMODE_ADJUST_V_POS:
                    u16TempID = en_str_PCMenu_PositionV;
                    break;
                case HWND_MENU_PCMODE_ADJUST_PHASE:
                    u16TempID = en_str_PCMenu_Phase;
                    break;
                case HWND_MENU_PCMODE_ADJUST_CLOCK:
                    u16TempID = en_str_PCMenu_Size;
                    break;
               default:
                    break;
            }
            break;
        case HWND_MENU_PICTURE_ADJUST_VALUE:
            switch (prePictureHWND)
            {
                case HWND_MENU_PC_PICTURE_ITEM_CONTRAST:
                case HWND_MENU_PICTURE_ITEM_CONTRAST:
                    return MApp_ZUI_API_GetU16String(ST_PICTURE.u8Contrast);
                    break;
                case HWND_MENU_PC_PICTURE_ITEM_BRIGHTNESS:
                case HWND_MENU_PICTURE_ITEM_BRIGHTNESS:
                    return MApp_ZUI_API_GetU16String(ST_PICTURE.u8Brightness);
                    break;
                case HWND_MENU_PICTURE_ITEM_SHARPNESS:
                    return MApp_ZUI_API_GetU16String(ST_PICTURE.u8Sharpness);
                    break;
                case HWND_MENU_PICTURE_ITEM_TINT:
                    return MApp_ZUI_API_GetU16String(ST_PICTURE.u8Hue);
                    break;
                case HWND_MENU_PICTURE_ITEM_COLOR:
                    return MApp_ZUI_API_GetU16String(ST_PICTURE.u8Saturation);
                    break;
               case HWND_MENU_ADVANCE_PICTURE_PC_BACKLIGHT:
                    return MApp_ZUI_API_GetU16String(ST_PICTURE.u8Backlight);
                    break;
                case HWND_MENU_SOUND_BALANCE:
                    return MApp_ZUI_API_GetS16SignString(
                        (S16)stGenSetting.g_SoundSetting.Balance-50);
                case HWND_MENU_SOUND_AUDIO_DELAY:
#if ENABLE_CUS_AUDIO_DELAY
                    return MApp_ZUI_API_GetU16String(stGenSetting.g_SoundSetting.LipSyncDelayTime);
#else
                    return 0;
#endif

                case HWND_MENU_SOUND_TREBLE:
                    return MApp_ZUI_API_GetU16String(stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].Treble);
                case HWND_MENU_SOUND_BASS:
                    return MApp_ZUI_API_GetU16String(stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].Bass);

                case HWND_MENU_PCMODE_ADJUST_H_POS:
                case HWND_MENU_PCMODE_ADJUST_V_POS:
                case HWND_MENU_PCMODE_ADJUST_PHASE:
                case HWND_MENU_PCMODE_ADJUST_CLOCK:
                    return MApp_ZUI_API_GetU16String(MApp_ZUI_ACT_GetPcModeAdjustValue(prePictureHWND));
               default:
                    break;
            }
            case HWND_MENU_OPTION_HDMI_MODE_OPTION:
                #if ENABLE_CUS_HDMI_MODE
                    if(stGenSetting.g_SysSetting.bIsHDMIVideoMode)
                    {
                        u16TempID = en_str_Option_HDMI_Mode_VIDEO;
                    }
                    else
                #endif
                    {
                        u16TempID = en_str_Option_HDMI_Mode_PC;
                    }
                break;
                // for auto tune
            case HWND_MENU_CHANNEL_SCAN_PAGE_SCAN_STATE_VALUE:
                if(msAPI_Tuner_IsTuningProcessorBusy())
                {
                    u16TempID = en_str_ChannelScanStatus_Scanning;
                }
                else
                {

                    u16TempID = en_str_ChannelScanStatus_Cancel;
                }
                break;
            case HWND_MENU_CHANNEL_SCAN_PAGE_FREQ_VALUE:
                if(IsATVInUse() /*&& (MApp_ZUI_ACT_AutoTuningGetPercentValue() != 0)*/ )
                {
                    // Show Freqency
                    WORD wTunerPLL,wTunerPLLI,wTunerPLLF;
                    wTunerPLL = msAPI_Tuner_GetCurrentChannelPLL2UiStr();
                    wTunerPLLI = msAPI_CFT_ConvertPLLtoIntegerOfFrequency(wTunerPLL);
                    wTunerPLLF = msAPI_CFT_ConvertPLLtoFractionOfFrequency(wTunerPLL);

                    CHAR_BUFFER[0] = ((wTunerPLLI/100) == 0) ? ' ' : '0'+(wTunerPLLI/100);
                    CHAR_BUFFER[1] = '0'+((wTunerPLLI%100)/10);
                    CHAR_BUFFER[2] = '0'+(wTunerPLLI%10);
                    CHAR_BUFFER[3] = '.';
                    CHAR_BUFFER[4] = '0'+(wTunerPLLF/100);
                    CHAR_BUFFER[5] = '0'+((wTunerPLLF%100)/10);
                    CHAR_BUFFER[6] = CHAR_SPACE;
                    CHAR_BUFFER[7] = CHAR_M;
                    CHAR_BUFFER[8] = CHAR_H;
                    CHAR_BUFFER[9] = CHAR_z;
                    CHAR_BUFFER[10] = 0;
                    return CHAR_BUFFER;
                }
                else
                {
                    CHAR_BUFFER[0]=0;
                    return CHAR_BUFFER;
                }
                break;
            case HWND_MENU_CHANNEL_SCAN_PAGE_CH_NUM_VALUE:
               #if ENABLE_SBTVD_BRAZIL_APP
                if(MApp_TopStateMachine_GetTopState() == STATE_TOP_ATV_SCAN )
                {
                    u8ScanAirTVChNum = msAPI_Tuner_GetNumberOfChBeFound_WhileAutoScan();
                }
                return MApp_ZUI_API_GetU16String(u8ScanAirTVChNum);
               #else

               #if ENABLE_CUS_UPDATE_SCAN
                if(g_bGotoUpdateScan)
                {
                    return MApp_ZUI_API_GetU16String(msAPI_ATV_GetFoundCHCount_ByUpdateScan());
                }
                else
               #endif
                {
                    return MApp_ZUI_API_GetU16String(u8ScanAtvChNum);
                }
               #endif
                break;

            case HWND_MENU_CHANNEL_SCAN_PAGE_MANUAL_FREQ_BEGIN_VALUE:
                if(IsATVInUse())
                {
                   // Show Freqency
                   WORD wTunerPLLI,wTunerPLLF;
                   #if ENABLE_CUS_MANUAL_SCAN
                   wTunerPLLI = msAPI_Tuner_GetManualScanStartFreq()/1000;
                   wTunerPLLF = msAPI_Tuner_GetManualScanStartFreq()%1000;
                   #else
                   wTunerPLLI = 55;
                   wTunerPLLF = 25;
                   #endif

                   CHAR_BUFFER[0] = ((wTunerPLLI/100) == 0) ? ' ' : '0'+(wTunerPLLI/100);
                   CHAR_BUFFER[1] = '0'+((wTunerPLLI%100)/10);
                   CHAR_BUFFER[2] = '0'+(wTunerPLLI%10);
                   CHAR_BUFFER[3] = '.';
                   CHAR_BUFFER[4] = '0'+(wTunerPLLF/100);
                   CHAR_BUFFER[5] = '0'+((wTunerPLLF%100)/10);
                   CHAR_BUFFER[6] = 0;
                   return CHAR_BUFFER;
                }
                else
                {
                   CHAR_BUFFER[0]=0;
                   return CHAR_BUFFER;
                }
                break;

            case HWND_MENU_CHANNEL_SCAN_PAGE_MANUAL_FREQ_END_VALUE:
                if(IsATVInUse())
                {
                    // Show Freqency
                    WORD wTunerPLLI,wTunerPLLF;
                #if ENABLE_CUS_MANUAL_SCAN
                    wTunerPLLI = msAPI_Tuner_GetManualScanEndFreq()/1000;
                    wTunerPLLF = msAPI_Tuner_GetManualScanEndFreq()%1000;
                #else
                    wTunerPLLI = 863;
                    wTunerPLLF = 25;
                #endif

                    CHAR_BUFFER[0] = ((wTunerPLLI/100) == 0) ? ' ' : '0'+(wTunerPLLI/100);
                    CHAR_BUFFER[1] = '0'+((wTunerPLLI%100)/10);
                    CHAR_BUFFER[2] = '0'+(wTunerPLLI%10);
                    CHAR_BUFFER[3] = '.';
                    CHAR_BUFFER[4] = '0'+(wTunerPLLF/100);
                    CHAR_BUFFER[5] = '0'+((wTunerPLLF%100)/10);
                    CHAR_BUFFER[6] = 0;
                    return CHAR_BUFFER;
                }
                else
                {
                    CHAR_BUFFER[0]=0;
                    return CHAR_BUFFER;
                }
                break;

            case HWND_MENU_CHANNEL_SCAN_PAGE_PERCENT:
                return MApp_ZUI_API_GetU16String(MApp_ZUI_ACT_AutoTuningGetPercentValue());
                break;

            case HWND_MENU_CHANNEL_SCAN_PAGE_TITLE:
                u16TempID = en_str_ChannelScanStatus_scan_ATV;
                break;
            case HWND_MENU_CHANNEL_FINETUNE_CH_NUMBER:
                {
                    LPTSTR str = CHAR_BUFFER;
                    U8 u8Index;
                    U8 u8CHnum;
                    u8CHnum = msAPI_ATV_ChannelInfoEdit_GetCHNum();

                    MApp_ZUI_API_Strcpy(&str[0], MApp_ZUI_API_GetString(en_strChannel_AtvScan_CurrentChText));
                    u8Index = MApp_ZUI_API_Strlen(str);
                    str[u8Index] = CHAR_SPACE;
                    u8Index += 1;
                    {
                        str[u8Index++] = ((u8CHnum/100) == 0) ? ' ' : '0'+(u8CHnum/100);
                        str[u8Index++] =(((u8CHnum%100)/10) == 0) ? ' ' : '0'+((u8CHnum%100)/10);
                        str[u8Index++] = '0'+(u8CHnum%10);
                    }
                    str[u8Index++] = 0;
                    return CHAR_BUFFER;
                }
            case HWND_MENU_CHANNEL_INFO_CH_NUM_OPTION:
                {
                    LPTSTR str = CHAR_BUFFER;
                    MApp_ZUI_API_GetU16String(msAPI_ATV_ChannelInfoEdit_GetCHNum());
                    str += MApp_ZUI_API_Strlen(str);

                    if ((str-CHAR_BUFFER) > 16)
                    {
                        (CHAR_BUFFER)[16] = 0;
                    }

                    return CHAR_BUFFER;

                }
                break;

            case HWND_MENU_CHANNEL_FINETUNE_CH_NAME_VALUE:
            case HWND_MENU_CHANNEL_INFO_CH_NAME_OPTION:
                {
                    LPTSTR str = CHAR_BUFFER;

                    {
                        U8 u8Temp[MAX_STATION_NAME];
                        msAPI_ATV_ChannelInfoEdit_GetStationName(u8Temp);
                        MApp_U8StringToU16String(u8Temp, str, MAX_STATION_NAME);
                        str += MApp_ZUI_API_Strlen(str);
                    }

                    if ((str-CHAR_BUFFER) > 16)
                    {
                        (CHAR_BUFFER)[16] = 0;
                    }

                    return CHAR_BUFFER;

                }
                break;
            case HWND_MENU_CHANNEL_INFO_FREQ_OPTION:
                {
                    LPTSTR str = CHAR_BUFFER;
                    U8 u8Index;
                    WORD wPLL;
                    WORD wTunerPLLI,wTunerPLLF;

                    wPLL = msAPI_ATV_ChannelInfoEdit_GetPLL();

                    u8Index = 0;

                    wTunerPLLI = msAPI_CFT_ConvertPLLtoIntegerOfFrequency(wPLL);
                    wTunerPLLF = msAPI_CFT_ConvertPLLtoFractionOfFrequency(wPLL);
                    {
                        str[u8Index++] = ((wTunerPLLI/100) == 0) ? ' ' : '0'+(wTunerPLLI/100);
                        str[u8Index++] = '0'+((wTunerPLLI%100)/10);
                        str[u8Index++] = '0'+(wTunerPLLI%10);
                        str[u8Index++] = '.';
                        str[u8Index++] = '0'+(wTunerPLLF/100);
                        str[u8Index++] = '0'+((wTunerPLLF%100)/10);
                    }
                    str[u8Index++] = 0;

                    if ((str-CHAR_BUFFER) > 16)
                    {
                        (CHAR_BUFFER)[16] = 0;
                    }

                    return CHAR_BUFFER;

                }
                break;

            case HWND_MENU_CHANNEL_FINETUNE_CH_FREQ_VALUE:
                {
                    WORD wTunerPLL,wTunerPLLI,wTunerPLLF;
                    LPTSTR str = CHAR_BUFFER;
                    U8 u8Index;

                    MApp_ZUI_API_Strcpy(&str[0], MApp_ZUI_API_GetString(en_strManualScan_FrequencyText));
                    u8Index = MApp_ZUI_API_Strlen(str);
                    str[u8Index] = CHAR_SPACE;
                    u8Index += 1;

                    wTunerPLL = msAPI_ATV_ChannelInfoEdit_GetPLL();//msAPI_Tuner_GetCurrentChannelPLL();
                    wTunerPLLI = msAPI_CFT_ConvertPLLtoIntegerOfFrequency(wTunerPLL);
                    wTunerPLLF = msAPI_CFT_ConvertPLLtoFractionOfFrequency(wTunerPLL);

                    {
                        str[u8Index++] = ((wTunerPLLI/100) == 0) ? ' ' : '0'+(wTunerPLLI/100);
                        str[u8Index++] = '0'+((wTunerPLLI%100)/10);
                        str[u8Index++] = '0'+(wTunerPLLI%10);
                        str[u8Index++] = '.';
                        str[u8Index++] = '0'+(wTunerPLLF/100);
                        str[u8Index++] = '0'+((wTunerPLLF%100)/10);
                    }
                    str[u8Index++] = 0;
                    return CHAR_BUFFER;
                }

                break;
            case HWND_MENU_CHANNEL_INFO_COLOR_SYSTEM_OPTION:
                {
                    AVD_VideoStandardType eVideoStandard;
                    eVideoStandard = msAPI_ATV_ChannelInfoEdit_GetVideoStandard();
                    switch( eVideoStandard )
                    {
                        case E_VIDEOSTANDARD_PAL_BGHI:
                            u16TempID=en_str_PAL;
                            break;
                        case E_VIDEOSTANDARD_PAL_M:
                            u16TempID=en_str_PAL_M;
                            break;
                        case E_VIDEOSTANDARD_PAL_N:
                            u16TempID=en_str_PAL_N;
                            break;
                        case E_VIDEOSTANDARD_PAL_60:
                            u16TempID=en_str_PAL_60;
                            break;
                        case E_VIDEOSTANDARD_NTSC_M:
                            u16TempID=en_str_NTSC;
                            break;
                        case E_VIDEOSTANDARD_NTSC_44:
                            u16TempID=en_str_NTSC_44;
                            break;
                        case E_VIDEOSTANDARD_SECAM:
                            u16TempID=en_str_SECAM;
                            break;
                        default:
                            u16TempID=en_str_AUTO;
                            break;

                    }
                }
                break;
            case HWND_MENU_CHANNEL_INFO_SOUND_SYSTEM_OPTION:
                #ifdef ENABLE_CUS_AUTO_AUDIO_SYSTEM_DETECT
                if(msAPI_ATV_ChannelInfoEdit_IsEnableRealtimeAudioDetection())
                {
                    u16TempID = en_str_AUTO;
                }
                else
                #endif
                {
                    AUDIOSTANDARD_TYPE eAudioStandardType;
                    eAudioStandardType = msAPI_ATV_ChannelInfoEdit_GetAudioStandard();
                    switch(eAudioStandardType)
                    {
                        case E_AUDIOSTANDARD_BG:
                        case E_AUDIOSTANDARD_BG_A2:
                        case E_AUDIOSTANDARD_BG_NICAM:
                            u16TempID=en_str_AudioStandard_BG;
                            break;
                        case E_AUDIOSTANDARD_I:
                            u16TempID=en_str_AudioStandard_I;
                            break;
                        case E_AUDIOSTANDARD_DK:
                        case E_AUDIOSTANDARD_DK1_A2:
                        case E_AUDIOSTANDARD_DK2_A2:
                        case E_AUDIOSTANDARD_DK3_A2:
                        case E_AUDIOSTANDARD_DK_NICAM:
                            u16TempID=en_str_AudioStandard_DK;
                            break;
                        case E_AUDIOSTANDARD_M:
                        case E_AUDIOSTANDARD_M_BTSC:
                            u16TempID=en_str_AudioStandard_M;
                            break;
                        case E_AUDIOSTANDARD_L:
                            u16TempID=en_str_AudioStandard_L;
                            break;
                        default:
#if ( ENABLE_DTMB_CHINA_APP || ENABLE_ATV_CHINA_APP )
                            u16TempID=en_str_AudioStandard_DK;
#else
                            u16TempID=en_str_AudioStandard_BG;
#endif
                            break;

                     }
                }
                break;
            case HWND_MENU_CHANNEL_INFO_AFT_OPTION:
                if(msAPI_ATV_ChannelInfoEdit_GetAFT())
                {
                    u16TempID = en_str_On;
                }
                else
                {
                    u16TempID = en_str_Off;
                }
                break;
            case HWND_MENU_CHANNEL_INFO_SKIP_OPTION:
                if(msAPI_ATV_ChannelInfoEdit_GetSkip())
                {
                    u16TempID = en_str_On;
                }
                else
                {
                    u16TempID = en_str_Off;
                }
                break;
            case HWND_MENU_TIME_SET_DATE_OPTION_YEAR_1:
                MApp_UlongToU16String((stLMGenSetting.stMD.u16Option_Info_Year/1000), CHAR_BUFFER, (S8)MApp_GetNoOfDigit(stLMGenSetting.stMD.u16Option_Info_Year/1000));
                return CHAR_BUFFER;
            case HWND_MENU_TIME_SET_DATE_OPTION_YEAR_2:
                {
                    U16 u16temp;
                    u16temp = stLMGenSetting.stMD.u16Option_Info_Year%1000;
                    u16temp = u16temp/100;
                    MApp_UlongToU16String(u16temp, CHAR_BUFFER, (S8)MApp_GetNoOfDigit(u16temp));
                    return CHAR_BUFFER;
                }
            case HWND_MENU_TIME_SET_DATE_OPTION_YEAR_3:
                {
                    U16 u16temp;
                    u16temp = stLMGenSetting.stMD.u16Option_Info_Year%1000;
                    u16temp = u16temp%100;
                    u16temp = u16temp/10;
                    MApp_UlongToU16String(u16temp, CHAR_BUFFER, (S8)MApp_GetNoOfDigit(u16temp));
                    return CHAR_BUFFER;
                }
            case HWND_MENU_TIME_SET_DATE_OPTION_YEAR_4:
                {
                    U16 u16temp;
                    u16temp = stLMGenSetting.stMD.u16Option_Info_Year%1000;
                    u16temp = u16temp%100;
                    u16temp = u16temp%10;
                    MApp_UlongToU16String(u16temp, CHAR_BUFFER, (S8)MApp_GetNoOfDigit(u16temp));
                    return CHAR_BUFFER;
                }
            case HWND_MENU_TIME_SET_DATE_OPTION_MONTH_1:
                {
                    U16 u16temp;
                    u16temp = stLMGenSetting.stMD.u16Option_Info_Month/10;
                    MApp_UlongToU16String(u16temp, CHAR_BUFFER, (S8)MApp_GetNoOfDigit(u16temp));
                    return CHAR_BUFFER;
                }
            case HWND_MENU_TIME_SET_DATE_OPTION_MONTH_2:
                {
                    U16 u16temp;
                    u16temp = stLMGenSetting.stMD.u16Option_Info_Month%10;
                    MApp_UlongToU16String(u16temp, CHAR_BUFFER, (S8)MApp_GetNoOfDigit(u16temp));
                    return CHAR_BUFFER;
                }
            case HWND_MENU_TIME_SET_DATE_OPTION_DAY_1:
                {
                    U16 u16temp;
                    u16temp = stLMGenSetting.stMD.u16Option_Info_Day/10;
                    MApp_UlongToU16String(u16temp, CHAR_BUFFER, (S8)MApp_GetNoOfDigit(u16temp));
                    return CHAR_BUFFER;
                }
            case HWND_MENU_TIME_SET_DATE_OPTION_DAY_2:
                {
                    U16 u16temp;
                    u16temp = stLMGenSetting.stMD.u16Option_Info_Day%10;
                    MApp_UlongToU16String(u16temp, CHAR_BUFFER, (S8)MApp_GetNoOfDigit(u16temp));
                    return CHAR_BUFFER;
                }
                break;
            case HWND_MENU_TIME_SET_DATE_OPTION_SLASH_1:
            case HWND_MENU_TIME_SET_DATE_OPTION_SLASH_2:
                CHAR_BUFFER[0] = '/';
                CHAR_BUFFER[1] = 0;
                return CHAR_BUFFER;
                break;

            case HWND_MENU_TIME_SET_OFFTIME_OPTION_HH_1:
                MApp_UlongToU16String((stGenSetting.g_Time.u16OffTimer_Info_Hour/10), CHAR_BUFFER, (S8)MApp_GetNoOfDigit((stGenSetting.g_Time.u16OffTimer_Info_Hour/10)));
                return CHAR_BUFFER;
            case HWND_MENU_TIME_SET_OFFTIME_OPTION_HH_2:
                MApp_UlongToU16String((stGenSetting.g_Time.u16OffTimer_Info_Hour%10), CHAR_BUFFER, (S8)MApp_GetNoOfDigit((stGenSetting.g_Time.u16OffTimer_Info_Hour%10)));
                return CHAR_BUFFER;
            case HWND_MENU_TIME_SET_OFFTIME_OPTION_MM_1:
                MApp_UlongToU16String((stGenSetting.g_Time.u16OffTimer_Info_Min/10), CHAR_BUFFER, (S8)MApp_GetNoOfDigit(stGenSetting.g_Time.u16OffTimer_Info_Min/10));
                return CHAR_BUFFER;
            case HWND_MENU_TIME_SET_OFFTIME_OPTION_MM_2:
                MApp_UlongToU16String((stGenSetting.g_Time.u16OffTimer_Info_Min%10), CHAR_BUFFER, (S8)MApp_GetNoOfDigit((stGenSetting.g_Time.u16OffTimer_Info_Min%10)));
                return CHAR_BUFFER;
            case HWND_MENU_TIME_SET_OFFTIME_OPTION_SS_1:
                MApp_UlongToU16String((stGenSetting.g_Time.u16OffTimer_Info_Sec/10), CHAR_BUFFER, (S8)MApp_GetNoOfDigit((stGenSetting.g_Time.u16OffTimer_Info_Sec/10)));
                return CHAR_BUFFER;
            case HWND_MENU_TIME_SET_OFFTIME_OPTION_SS_2:
                MApp_UlongToU16String((stGenSetting.g_Time.u16OffTimer_Info_Sec%10), CHAR_BUFFER, (S8)MApp_GetNoOfDigit((stGenSetting.g_Time.u16OffTimer_Info_Sec%10)));
                return CHAR_BUFFER;

            case HWND_MENU_TIME_SET_ONTIME_OPTION_HH_1:
                MApp_UlongToU16String((stGenSetting.g_Time.u16OnTimer_Info_Hour/10), CHAR_BUFFER, (S8)MApp_GetNoOfDigit((stGenSetting.g_Time.u16OnTimer_Info_Hour/10)));
                return CHAR_BUFFER;
            case HWND_MENU_TIME_SET_ONTIME_OPTION_HH_2:
                MApp_UlongToU16String((stGenSetting.g_Time.u16OnTimer_Info_Hour%10), CHAR_BUFFER, (S8)MApp_GetNoOfDigit((stGenSetting.g_Time.u16OnTimer_Info_Hour%10)));
                return CHAR_BUFFER;
            case HWND_MENU_TIME_SET_ONTIME_OPTION_MM_1:
                MApp_UlongToU16String((stGenSetting.g_Time.u16OnTimer_Info_Min/10), CHAR_BUFFER, (S8)MApp_GetNoOfDigit(stGenSetting.g_Time.u16OnTimer_Info_Min/10));
                return CHAR_BUFFER;
            case HWND_MENU_TIME_SET_ONTIME_OPTION_MM_2:
                MApp_UlongToU16String((stGenSetting.g_Time.u16OnTimer_Info_Min%10), CHAR_BUFFER, (S8)MApp_GetNoOfDigit((stGenSetting.g_Time.u16OnTimer_Info_Min%10)));
                return CHAR_BUFFER;
            case HWND_MENU_TIME_SET_ONTIME_OPTION_SS_1:
                MApp_UlongToU16String((stGenSetting.g_Time.u16OnTimer_Info_Sec/10), CHAR_BUFFER, (S8)MApp_GetNoOfDigit((stGenSetting.g_Time.u16OnTimer_Info_Sec/10)));
                return CHAR_BUFFER;
            case HWND_MENU_TIME_SET_ONTIME_OPTION_SS_2:
                MApp_UlongToU16String((stGenSetting.g_Time.u16OnTimer_Info_Sec%10), CHAR_BUFFER, (S8)MApp_GetNoOfDigit((stGenSetting.g_Time.u16OnTimer_Info_Sec%10)));
                return CHAR_BUFFER;

            case HWND_MENU_TIME_SET_CLOCK_OPTION_HH_1:
                MApp_UlongToU16String((stLMGenSetting.stMD.u16Option_Info_Hour/10), CHAR_BUFFER, (S8)MApp_GetNoOfDigit((stLMGenSetting.stMD.u16Option_Info_Hour/10)));
                return CHAR_BUFFER;
            case HWND_MENU_TIME_SET_CLOCK_OPTION_HH_2:
                MApp_UlongToU16String((stLMGenSetting.stMD.u16Option_Info_Hour%10), CHAR_BUFFER, (S8)MApp_GetNoOfDigit((stLMGenSetting.stMD.u16Option_Info_Hour%10)));
                return CHAR_BUFFER;
            case HWND_MENU_TIME_SET_CLOCK_OPTION_MM_1:
                MApp_UlongToU16String((stLMGenSetting.stMD.u16Option_Info_Min/10), CHAR_BUFFER, (S8)MApp_GetNoOfDigit((stLMGenSetting.stMD.u16Option_Info_Min/10)));
                return CHAR_BUFFER;
            case HWND_MENU_TIME_SET_CLOCK_OPTION_MM_2:
                MApp_UlongToU16String((stLMGenSetting.stMD.u16Option_Info_Min%10), CHAR_BUFFER, (S8)MApp_GetNoOfDigit((stLMGenSetting.stMD.u16Option_Info_Min%10)));
                return CHAR_BUFFER;
            case HWND_MENU_TIME_SET_CLOCK_OPTION_SS_1:
                MApp_UlongToU16String((stLMGenSetting.stMD.u16Option_Info_Sec/10), CHAR_BUFFER, (S8)MApp_GetNoOfDigit((stLMGenSetting.stMD.u16Option_Info_Sec/10)));
                return CHAR_BUFFER;
            case HWND_MENU_TIME_SET_CLOCK_OPTION_SS_2:
                MApp_UlongToU16String((stLMGenSetting.stMD.u16Option_Info_Sec%10), CHAR_BUFFER, (S8)MApp_GetNoOfDigit((stLMGenSetting.stMD.u16Option_Info_Sec%10)));
                return CHAR_BUFFER;

            case HWND_MENU_TIME_SET_OFFTIME_OPTION_COLON_1:
            case HWND_MENU_TIME_SET_OFFTIME_OPTION_COLON_2:
            case HWND_MENU_TIME_SET_ONTIME_OPTION_COLON_1:
            case HWND_MENU_TIME_SET_ONTIME_OPTION_COLON_2:
            case HWND_MENU_TIME_SET_CLOCK_OPTION_COLON_1:
            case HWND_MENU_TIME_SET_CLOCK_OPTION_COLON_2:
                CHAR_BUFFER[0] = ':';
                CHAR_BUFFER[1] = 0;
                return CHAR_BUFFER;
                break;

            case HWND_MENU_TIME_ON_TIME_SWTICH_OPTION:
                {

                    switch (stGenSetting.g_Time.cOnTimerFlag)
                    {
                        case EN_Time_OnTimer_Once:
                            u16TempID = en_str_Timer_Once;
                            break;
                        case EN_Time_OnTimer_Everyday:
                            u16TempID = en_str_On;
                            break;
                        case EN_Time_OnTimer_Mon2Fri:
                            u16TempID = en_str_Timer_Mon2Fri;
                            break;
                        case EN_Time_OnTimer_Mon2Sat:
                            u16TempID = en_str_Timer_Mon2Sat;
                            break;
                        case EN_Time_OnTimer_Sat2Sun:
                            u16TempID = en_str_Timer_Sat2Sun;
                            break;
                        case EN_Time_OnTimer_Sun:
                            u16TempID = en_str_Timer_Sun;
                            break;
                        case EN_Time_OnTimer_Off:
                        default:
                            u16TempID = en_str_Off;
                            break;
                    }
                }
                break;

            case HWND_MENU_TIME_OFF_TIME_SWITCH_OPTION:
                {
                    switch (stGenSetting.g_Time.cOffTimerFlag)
                    {
                        case EN_Time_OffTimer_Once:
                            u16TempID = en_str_Timer_Once;
                            break;
                        case EN_Time_OffTimer_Everyday:
                            u16TempID = en_str_On;//en_str_Timer_Everyday;
                            break;
                        case EN_Time_OffTimer_Mon2Fri:
                            u16TempID = en_str_Timer_Mon2Fri;
                            break;
                        case EN_Time_OffTimer_Mon2Sat:
                            u16TempID = en_str_Timer_Mon2Sat;
                            break;
                        case EN_Time_OffTimer_Sat2Sun:
                            u16TempID = en_str_Timer_Sat2Sun;
                            break;
                        case EN_Time_OffTimer_Sun:
                            u16TempID = en_str_Timer_Sun;
                            break;
                        case EN_Time_OffTimer_Off:
                        default:
                            u16TempID = en_str_Off;
                            break;
                    }
                    break;
                }
                break;
            case HWND_MENU_PCMODE_ADJUST_H_POS_VALUE:
            case HWND_MENU_PCMODE_ADJUST_V_POS_VALUE:
            case HWND_MENU_PCMODE_ADJUST_PHASE_VALUE:
            case HWND_MENU_PCMODE_ADJUST_CLOCK_VALUE:
                MApp_UlongToU16String(MApp_ZUI_ACT_GetPcModeAdjustValue(hwnd), CHAR_BUFFER, (S8)MApp_GetNoOfDigit(MApp_ZUI_ACT_GetPcModeAdjustValue(hwnd)));
                return CHAR_BUFFER;
          #if ENABLE_3D_PROCESS
            #if ENABLE_CUS_3D_SETTING
            case HWND_MENU_OPTION_3D_SCENE_VALUE:
                #if ENABLE_CUS_3D_SOURCE_MEMORY
                if(IsHDMIInUse() && (g_HdmiPollingStatus.bIsHDMIMode == FALSE)) //dvi
                {
                    MApp_UlongToU16String(ST_VGA_3DScene, CHAR_BUFFER, (S8)MApp_GetNoOfDigit(ST_VGA_3DScene));
                }
                else
                #endif
                {
                    MApp_UlongToU16String(ST_3D_3DScene, CHAR_BUFFER, (S8)MApp_GetNoOfDigit(ST_3D_3DScene));
                }
                return CHAR_BUFFER;
          #endif
          #endif
            case HWND_MENU_CHANNEL_PAGE2_MTS_OPTION:
                switch(m_eAudioMode)
                {
                    case E_AUDIOMODE_INVALID:
                    case E_AUDIOMODE_MONO:
                        u16TempID=en_strMtsMonoText;
                        break;

                    case E_AUDIOMODE_FORCED_MONO:
                        u16TempID=en_strMtsMonoText;
                        break;

                    case E_AUDIOMODE_G_STEREO:
                        u16TempID=en_strMtsStereoText;
                        break;

                    case E_AUDIOMODE_K_STEREO:
                        u16TempID=en_strMtsStereoText;
                        break;

                    case E_AUDIOMODE_MONO_SAP:
                    case E_AUDIOMODE_STEREO_SAP:
                        u16TempID=en_strMtsSapText;
                        break;

                    case E_AUDIOMODE_DUAL_A:
                        u16TempID=en_strMtsDUAL_A_Text;
                        break;

                    case E_AUDIOMODE_DUAL_B:
                        u16TempID=en_strMtsDUAL_B_Text;
                        break;

                    case E_AUDIOMODE_DUAL_AB:
                        u16TempID=en_strMtsDUAL_AB_Text;
                        break;

                    case E_AUDIOMODE_NICAM_MONO:
                        u16TempID=en_strMtsNICAM_MONO_Text;
                        break;

                    case E_AUDIOMODE_NICAM_STEREO:
                        u16TempID=en_strMtsNICAM_STEREO_Text;
                        break;
                    break;

                    case E_AUDIOMODE_NICAM_DUAL_A:
                        u16TempID=en_strMtsNICAM_DUAL_A_Text;
                        break;

                    case E_AUDIOMODE_NICAM_DUAL_B:
                        u16TempID=en_strMtsNICAM_DUAL_B_Text;
                        break;

                    case E_AUDIOMODE_NICAM_DUAL_AB:
                        u16TempID=en_strMtsNICAM_DUAL_AB_Text;
                        break;

                    case E_AUDIOMODE_HIDEV_MONO:
                        u16TempID=en_strMtsHIDEV_MONO_Text;
                        break;

                    case E_AUDIOMODE_LEFT_LEFT:
                        u16TempID=en_strMtsLEFT_LEFT_Text;
                        break;

                    case E_AUDIOMODE_RIGHT_RIGHT:
                        u16TempID=en_strMtsRIGHT_RIGHT_Text;
                        break;

                    case E_AUDIOMODE_LEFT_RIGHT:
                        u16TempID=en_strMtsLEFT_RIGHT_Text;
                        break;
                    default:
                        break;


                }
                break;

            case HWND_MENU_OPTION_POWER_STATUS_OPTION:
                if (stGenSetting.g_FactorySetting.u8PowerOnMode == POWERON_MODE_OFF)//standby
                {
                    u16TempID=en_str_Option_PowerOnStatus_Off;
                }
                else if (stGenSetting.g_FactorySetting.u8PowerOnMode == POWERON_MODE_ON)//on
                {
                    u16TempID=en_str_Option_PowerOnStatus_ON;
                }
                else//last status
                {
                    u16TempID=en_str_Option_PowerOnStatus_Last;
                }
                break;
            case HWND_MENU_OPTION_FREEZE_SWITCH_OPTION:
                #if (ENABLE_SW_CH_FREEZE_SCREEN)
                if(stGenSetting.g_SysSetting.u8SwitchMode ==ATV_SWITCH_CH_FREEZE_SCREEN)
                {
                    u16TempID=en_str_On;
                }
                else
                {
                    u16TempID=en_str_Off;
                }
                #endif
                break;

            case HWND_MENU_OPTION_BLUE_SCREEN_OPTION:
                #if ENABLE_SZ_BLUESCREEN_FUNCTION
                if(stGenSetting.g_SysSetting.bIsBluescreenOn == ENABLE)
                {
                    u16TempID=en_str_On;
                }
                else
                {
                    u16TempID=en_str_Off;
                }
                #endif
                break;

            case HWND_MENU_OPTION_VIDEO_COLOR_SYSTEM_OPTION:
                {
                    #ifdef ENABLE_CUS_AV_COLOR_SYSTEM
                    switch( stGenSetting.g_SysSetting.enAVColorSystem )
                    {
                        case ATV_COLOR_PAL:
                            u16TempID=en_str_PAL;
                            break;
                        case ATV_COLOR_PAL_M:
                            u16TempID=en_str_PAL_M;
                            break;
                        case ATV_COLOR_PAL_N:
                            u16TempID=en_str_PAL_N;
                            break;
                        case ATV_COLOR_PAL_60:
                            u16TempID=en_str_PAL_60;
                            break;
                        case ATV_COLOR_NTSC:
                            u16TempID=en_str_NTSC;
                            break;
                        case ATV_COLOR_NTSC_44:
                            u16TempID=en_str_NTSC_44;
                            break;
                        case ATV_COLOR_SECAM:
                            u16TempID=en_str_SECAM;
                            break;
                        default:
                            u16TempID=en_str_AUTO;
                            break;
                    }
                    #endif
                }
                break;
            default:
                break;

    }

    if (u16TempID != Empty)
        return MApp_ZUI_API_GetString(u16TempID);

    return 0; //for empty string....
}

///////////////////////////////////////////////////////////////////////////////
///  private  MApp_ZUI_ACT_GetMainMenuDynamicValue
///  [OSD page handler] dynamic integer value provider in MENU application
///
///  @param [in]       hwnd HWND     window handle we are processing
///
///  @return S16 integer value
///
///  @author MStarSemi @date 2007/1/25
///////////////////////////////////////////////////////////////////////////////
S16 MApp_ZUI_ACT_GetMainMenuDynamicValue(HWND hwnd)
{
    switch(hwnd)
    {
        case HWND_MENU_PC_PICTURE_ITEM_BRIGHTNESS_SLIDER_BAR:
        case HWND_MENU_PICTURE_ITEM_BRIGHTNESS_SLIDER_BAR:
            return ST_PICTURE.u8Brightness;
        case HWND_MENU_PC_PICTURE_ITEM_CONTRAST_SLIDER_BAR:
        case HWND_MENU_PICTURE_ITEM_CONTRAST_SLIDER_BAR:
            return ST_PICTURE.u8Contrast;
        case HWND_MENU_PICTURE_ITEM_COLOR_SLIDER_BAR:
            return ST_PICTURE.u8Saturation;
        case HWND_MENU_PICTURE_ITEM_SHARPNESS_SLIDER_BAR:
            return ST_PICTURE.u8Sharpness;
        case HWND_MENU_PICTURE_ITEM_TINT_SLIDER_BAR:
            if(MApp_IsSrcHasSignal(MAIN_WINDOW) == FALSE)
            {
                return 50;
            }

            if(IsAVInUse() || IsATVInUse())
            {
                switch (mvideo_vd_get_videosystem() )
                {
                    case SIG_NTSC:
                    case SIG_NTSC_443:

                    return ST_PICTURE.u8Hue;
                    case SIG_PAL:
                    case SIG_PAL_M:
                    case SIG_PAL_NC:
                    case SIG_SECAM:
                    return 50;
                default:
                    return 50;
                }
            }
            else
            {
                return 50;
            }

        case HWND_MENU_PCMODE_ADJUST_H_POS_SLIDER_BAR:
        case HWND_MENU_PCMODE_ADJUST_V_POS_SLIDER_BAR:
        case HWND_MENU_PCMODE_ADJUST_PHASE_SLIDER_BAR:
        case HWND_MENU_PCMODE_ADJUST_CLOCK_SLIDER_BAR :
            return MApp_ZUI_ACT_GetPcModeAdjustValue(hwnd);
            break;

        case HWND_MENU_PICTURE_ADJUST_OPTION:
            switch (prePictureHWND)
            {

                case HWND_MENU_PC_PICTURE_ITEM_BRIGHTNESS:
                case HWND_MENU_PICTURE_ITEM_BRIGHTNESS:
                    return ST_PICTURE.u8Brightness;
                case HWND_MENU_PC_PICTURE_ITEM_CONTRAST:
                case HWND_MENU_PICTURE_ITEM_CONTRAST:
                    return ST_PICTURE.u8Contrast;
                case HWND_MENU_PICTURE_ITEM_COLOR:
                    return ST_PICTURE.u8Saturation;
                case HWND_MENU_PICTURE_ITEM_SHARPNESS:
                    return ST_PICTURE.u8Sharpness;
                case HWND_MENU_PICTURE_ITEM_TINT:
                    return ST_PICTURE.u8Hue;
                case HWND_MENU_ADVANCE_PICTURE_PC_BACKLIGHT:
                    return ST_PICTURE.u8Backlight;
                case HWND_MENU_SOUND_BALANCE:
                    return stGenSetting.g_SoundSetting.Balance;
                case HWND_MENU_SOUND_AUDIO_DELAY:
#if ENABLE_CUS_AUDIO_DELAY
                    return ((U16)stGenSetting.g_SoundSetting.LipSyncDelayTime*100/250);
#else
                    return 0;
#endif

                case HWND_MENU_SOUND_TREBLE:
                    return (stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].Treble);
                case HWND_MENU_SOUND_BASS:
                    return (stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].Bass);
                case HWND_MENU_PCMODE_ADJUST_H_POS:
                case HWND_MENU_PCMODE_ADJUST_V_POS:
                case HWND_MENU_PCMODE_ADJUST_PHASE:
                case HWND_MENU_PCMODE_ADJUST_CLOCK :
                    return MApp_ZUI_ACT_GetPcModeAdjustValue(prePictureHWND);
                default:
                    break;
            }
         case HWND_MENU_ADVANCE_PICTURE_PC_BACKLIGHT_SLIDEBAR:
             return ST_PICTURE.u8Backlight;
         case HWND_MENU_SOUND_BALANCE_SLIDER_BAR:
             return stGenSetting.g_SoundSetting.Balance;
         case HWND_MENU_SOUND_BASS_SLIDER_BAR:
             return (stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].Bass);
         case HWND_MENU_SOUND_TREBLE_SLIDER_BAR:
             return (stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].Treble);
         case HWND_MENU_SOUND_AUDIO_DELAY_SLIDER_BAR:
            #if ENABLE_CUS_AUDIO_DELAY
             return ((U16)stGenSetting.g_SoundSetting.LipSyncDelayTime*100/250);
            #else
             return 0;
            #endif
         case HWND_MENU_CHANNEL_SCAN_PAGE_PROGRESS_BAR:
             return MApp_ZUI_ACT_AutoTuningGetPercentValue();

        #if ENABLE_3D_PROCESS
        #if ENABLE_CUS_3D_SETTING
         case HWND_MENU_OPTION_3D_SCENE_SLIDER_BAR:
             #if ENABLE_CUS_3D_SOURCE_MEMORY
             if(IsHDMIInUse() && (g_HdmiPollingStatus.bIsHDMIMode == FALSE)) //dvi
             {
                 return ST_VGA_3DScene*10;
             }
             else
             #endif
             {
                return ST_3D_3DScene*10;
             }
        #endif
        #endif
	  case HWND_MENU_FWUPGRADE_PROGRESS_BAR:
	  	return MApp_ZUI_ACT_GetMenuDynamicValue(hwnd);

         default:
            break;

    }

    return 0; //for empty  data
}

GUI_ENUM_DYNAMIC_LIST_STATE MApp_ZUI_ACT_QueryMainMenuItemStatus(HWND hwnd)
{
    //printf("[]query=%u\n", hwnd);

    switch(hwnd)
    {
        case HWND_MENU_LOCK_MAINSUBPAGE_ITEM_HOTEL:
         #if CUS_SMC_ENABLE_HOTEL_MODE
             return EN_DL_STATE_HIDDEN;
         #else
             return EN_DL_STATE_HIDDEN;
         #endif
		 
        case HWND_MENU_OPTION_POWERON_LOGO:
            #if ENABLE_MPLAYER_CAPTURE_LOGO
			#if CUS_SMC_ENABLE_HOTEL_MODE
            //if(stGenSetting.g_FactorySetting.HotelCaptureLogo)
			//	return EN_DL_STATE_NORMAL;
			//else
				return EN_DL_STATE_HIDDEN;
			#endif
            return EN_DL_STATE_NORMAL;
            #else
            return EN_DL_STATE_HIDDEN;
            #endif

        case HWND_MENU_OPTION_POWERON_MUSIC:
            #if ENABLE_POWERON_MUSIC
            return EN_DL_STATE_NORMAL;
            #else
            return EN_DL_STATE_HIDDEN;
            #endif

        case HWND_MENU_LOCK_MAINSUBPAGE_ITEM_YPBPR2:
            #if (INPUT_YPBPR_VIDEO_COUNT >= 2)
            return EN_DL_STATE_NORMAL;
            #else
            return EN_DL_STATE_HIDDEN;
            #endif
        case HWND_MENU_LOCK_MAINSUBPAGE_ITEM_AV2:
            #if (INPUT_AV_VIDEO_COUNT >= 2)
            return EN_DL_STATE_NORMAL;
            #else
            return EN_DL_STATE_HIDDEN;
            #endif
        case HWND_MENU_LOCK_MAINSUBPAGE_ITEM_HDMI2:
            #if (INPUT_HDMI_VIDEO_COUNT >= 2)
            return EN_DL_STATE_NORMAL;
            #else
            return EN_DL_STATE_HIDDEN;
            #endif
    	 case HWND_MENU_LOCK_MAINSUBPAGE_ITEM_HDMI3:
        	 #if (INPUT_HDMI_VIDEO_COUNT >= 3)
        	 	return EN_DL_STATE_NORMAL;
        	 #else
        	 	return EN_DL_STATE_HIDDEN;
        	 #endif
		 case HWND_MENU_LOCK_MAINSUBPAGE_ITEM_HDMI4:
             #if (INPUT_HDMI_VIDEO_COUNT >= 4)
              return EN_DL_STATE_NORMAL;
             #else
              return EN_DL_STATE_HIDDEN;
             #endif
        case HWND_MENU_OPTION_FREEZE_SWITCH:
            if(IsATVInUse())
            {
                return EN_DL_STATE_NORMAL;
            }
            else
            {
                return EN_DL_STATE_HIDDEN;
            }

        case HWND_MENU_OPTION_VIDEO_COLOR_SYSTEM:
            if(IsAVInUse())
            {
                return EN_DL_STATE_NORMAL;
            }
            else
            {
                return EN_DL_STATE_HIDDEN;
            }

        case HWND_MENU_CHANNEL_PAGE2_MTS:
            if(MApp_AUDIO_IsSifSoundModeExist(SOUND_MTS_STEREO))
            {
                return EN_DL_STATE_NORMAL;
            }
            else
            {
                return EN_DL_STATE_DISABLED;
            }
#if 0
        case HWND_MENU_SOUND_TREBLE:
        case HWND_MENU_SOUND_BASS:
        {
#if (ENABLE_CUS_SURROUND_FOLLOW_SNDMODE == DISABLE)
            if(stGenSetting.g_SoundSetting.SurroundSoundMode != SURROUND_SYSTEM_OFF)
 #else
            if(stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].SurroundSoundMode != SURROUND_SYSTEM_OFF)
 #endif
            {

                return EN_DL_STATE_DISABLED;
            }
            else
            {
                return EN_DL_STATE_NORMAL;
            }
        }

#endif
        case HWND_MENU_PCMODE_ADJUST_AUTO_ADJUST:
            return EN_DL_STATE_NORMAL;
        case HWND_MENU_PCMODE_ADJUST_H_POS:
        case HWND_MENU_PCMODE_ADJUST_V_POS:
        case HWND_MENU_PCMODE_ADJUST_PHASE:
        case HWND_MENU_PCMODE_ADJUST_CLOCK:
            if(MApp_IsSrcHasSignal(MAIN_WINDOW))
            {
                return EN_DL_STATE_NORMAL;
            }
            else
            {
                return EN_DL_STATE_DISABLED;
            }
            break;

        case HWND_MENU_SOUND_EQMODE:
            #if ENABLE_CUS_UI_SPEC
            return EN_DL_STATE_HIDDEN;
            #else
            return EN_DL_STATE_NORMAL;
            #endif
        case HWND_MENU_ADVANCE_PICTURE_PC_BACKLIGHT:
            if(MApp_Scaler_CheckDBC_DLCAvailable() == FALSE)
            {
                return EN_DL_STATE_NORMAL;
            }
            #if 0//ENABLE_CUS_DBC
            else if(ST_PICTURE.bDBCStatus == DBC_STATUS_ON)
            {
                return EN_DL_STATE_DISABLED;
            }
            else
            #endif
            {
                return EN_DL_STATE_NORMAL;
            }
        //from MENU_VIDEO_B =========================
        case HWND_MENU_PICMODE_BRIGHTNESS:
        case HWND_MENU_PICMODE_COLOR:
        case HWND_MENU_PICMODE_CONTRAST:
        case HWND_MENU_PICMODE_TINT:
        case HWND_MENU_PICMODE_SHARPNESS:
            #if PICTURE_USER_2
            if((ST_VIDEO.ePicture==PICTURE_USER) || (ST_VIDEO.ePicture==PICTURE_USER2) )
            #else
            if(ST_VIDEO.ePicture==PICTURE_USER)
            #endif
            {
                 if((hwnd ==HWND_MENU_PICMODE_COLOR)||(hwnd ==HWND_MENU_PICMODE_SHARPNESS))
                {
                   #if VGA_HDMI_YUV_POINT_TO_POINT
                     // if(IsHDMIInUse()&&MDrv_PQ_Get_HDMIPCMode())
                    if(IsHDMIInUse()&&MDrv_PQ_Check_PointToPoint_Mode())
                    {
                        return EN_DL_STATE_DISABLED;
                    }
                    else if(IsVgaInUse())
                    {
                        return EN_DL_STATE_DISABLED;
                    }
                    else
                    #endif
                    {
                       return EN_DL_STATE_NORMAL;
                    }
                }

                if(hwnd ==HWND_MENU_PICMODE_TINT)
                {
                    if(IsAVInUse() || IsATVInUse())
                    {
                        switch (mvideo_vd_get_videosystem() )
                        {
                            case SIG_NTSC:
                            case SIG_NTSC_443:
                                return EN_DL_STATE_NORMAL;

                            case SIG_PAL:
                            case SIG_PAL_M:
                            case SIG_PAL_NC:
                            case SIG_SECAM:
                                return EN_DL_STATE_DISABLED;

                            default:
                                return EN_DL_STATE_DISABLED;
                        }
                    }
                    else
                    {
                        return EN_DL_STATE_DISABLED;
                    }
                }

                return EN_DL_STATE_NORMAL;
            }
            else
            {
                return EN_DL_STATE_DISABLED;
            }
            break;

        case HWND_MENU_PICTURE_ITEM_COLOR:
            if((IsHDMIInUse()&&(g_HdmiPollingStatus.bIsHDMIMode == TRUE) && (ST_VIDEO.eAspectRatio == EN_AspectRatio_point_to_point))
               #if VGA_HDMI_YUV_POINT_TO_POINT
               || (IsHDMIInUse()&&MDrv_PQ_Check_PointToPoint_Mode() && (ST_VIDEO.eAspectRatio == EN_AspectRatio_point_to_point))
               #endif
               )
            {
                return EN_DL_STATE_HIDDEN;
            }
            else
            {
                return EN_DL_STATE_NORMAL;
            }

        case HWND_MENU_PICTURE_ITEM_SHARPNESS:
            if(MApp_Scaler_CheckDBC_DLCAvailable() == FALSE)
            {
                //return EN_DL_STATE_HIDDEN;
                return EN_DL_STATE_DISABLED;
            }
            else
            {
                return EN_DL_STATE_NORMAL;
            }

        case HWND_MENU_PICTURE_ITEM_TINT:
            if(IsAVInUse() || IsATVInUse())
            {
                switch (mvideo_vd_get_videosystem() )
                {
                    case SIG_NTSC:
                    case SIG_NTSC_443:
                        return EN_DL_STATE_NORMAL;

                    case SIG_PAL:
                    case SIG_PAL_M:
                    case SIG_PAL_NC:
                    case SIG_SECAM:
                        return EN_DL_STATE_HIDDEN;

                    default:
                        return EN_DL_STATE_HIDDEN;
                }
            }
            else
            {
                return EN_DL_STATE_HIDDEN;
            }
            break;

#if (ENABLE_CUS_UI_SPEC == FALSE) /*Creass.liu at 2012-06-27*/
        case HWND_MENU_SINGLELIST_ITEM1:
            switch(MApp_ZUI_ACT_GetSingleListMode())
            {
                case EN_COMMON_SINGLELIST_ASPECT_RATIO: // en_str_AspectRatio_Original
                    {
                    if ( IsVgaInUse()
                  #if (INPUT_HDMI_VIDEO_COUNT > 0)
                      || ( IsHDMIInUse() && !g_HdmiPollingStatus.bIsHDMIMode )
                  #endif
                       )
                         return EN_DL_STATE_DISABLED;
		     else if(IsDTVInUse()&&MApi_XC_IsCurrentFrameBufferLessMode())
                         return EN_DL_STATE_DISABLED;
                     else
                         return EN_DL_STATE_NORMAL;
                    }

                default:
                   return EN_DL_STATE_NORMAL;
            }
            break;

        case HWND_MENU_SINGLELIST_ITEM2:
            switch (MApp_ZUI_ACT_GetSingleListMode())
            {
                case EN_COMMON_SINGLELIST_ASPECT_RATIO: // en_str_AspectRatio_4X3
                {
                   /* if ( MApi_XC_IsCurrentFrameBufferLessMode()
                      && ( IsVgaInUse()
                  #if (INPUT_HDMI_VIDEO_COUNT > 0)
                        || ( IsHDMIInUse() && !g_HdmiPollingStatus.bIsHDMIMode )
                  #endif
                         )
                       )
                        return EN_DL_STATE_DISABLED;
                    else
                    */
                        return EN_DL_STATE_NORMAL;
                }

                default:
                    break;
            }
            break;

        case HWND_MENU_SINGLELIST_ITEM3:
            switch(MApp_ZUI_ACT_GetSingleListMode())
            {
                case EN_COMMON_SINGLELIST_ASPECT_RATIO: // en_str_AspectRatio_16X9
                    break;

                case EN_COMMON_SINGLELIST_SURROUND_SOUND:
                  #if (ENABLE_AUDIO_SURROUND_SRS)
                     return EN_DL_STATE_NORMAL;
                #else
                     return EN_DL_STATE_HIDDEN;
                #endif
                   break;

                default:
                   return EN_DL_STATE_NORMAL;
            }
            break;

        case HWND_MENU_SINGLELIST_ITEM4:
            switch(MApp_ZUI_ACT_GetSingleListMode())
            {
                case EN_COMMON_SINGLELIST_ASPECT_RATIO: //en_str_AspectRatio_14x9
                   return EN_DL_STATE_HIDDEN;

                case EN_COMMON_SINGLELIST_SURROUND_SOUND:
                {
                  #if (ENABLE_AUDIO_SURROUND_BBE)
                     return EN_DL_STATE_NORMAL;
                  #else
                     return EN_DL_STATE_HIDDEN;
                  #endif
                }
                break;

                default:
                   return EN_DL_STATE_NORMAL;
            }
            break;

        case HWND_MENU_SINGLELIST_ITEM5:
            switch(MApp_ZUI_ACT_GetSingleListMode())
            {
                case EN_COMMON_SINGLELIST_ASPECT_RATIO: //en_str_AspectRatio_Zoom1
                     {
                    if ( IsVgaInUse()
                      || IsStorageInUse()
                  #if (INPUT_HDMI_VIDEO_COUNT > 0)
                      || ( IsHDMIInUse() && !g_HdmiPollingStatus.bIsHDMIMode )
                  #endif
                       )
                         return EN_DL_STATE_DISABLED;
		     else if(IsDTVInUse()&&MApi_XC_IsCurrentFrameBufferLessMode())
                         return EN_DL_STATE_DISABLED;
                     else
                         return EN_DL_STATE_NORMAL;
                     }

                case EN_COMMON_SINGLELIST_SURROUND_SOUND:
                {
                  #if (ENABLE_AUDIO_SURROUND_VDS)
                     return EN_DL_STATE_NORMAL;
                #else
                     return EN_DL_STATE_HIDDEN;
                #endif
                }
                break;

                default:
                   return EN_DL_STATE_NORMAL;
            }
            break;

        case HWND_MENU_SINGLELIST_ITEM6:
            switch(MApp_ZUI_ACT_GetSingleListMode())
            {
                case EN_COMMON_SINGLELIST_ASPECT_RATIO: //en_str_AspectRatio_Zoom2
                     {
                    if ( IsVgaInUse()
                      || IsStorageInUse()
                  #if (INPUT_HDMI_VIDEO_COUNT > 0)
                      || ( IsHDMIInUse() && !g_HdmiPollingStatus.bIsHDMIMode )
                  #endif
                       )
                         return EN_DL_STATE_DISABLED;
		     else if(IsDTVInUse()&&MApi_XC_IsCurrentFrameBufferLessMode())
                         return EN_DL_STATE_DISABLED;
                     else
                         return EN_DL_STATE_NORMAL;
                     }

            #if(!_AutoNR_EN_)
                case EN_COMMON_SINGLELIST_NOISE_REDUCTION:
                   return EN_DL_STATE_HIDDEN;
            #endif

                case EN_COMMON_SINGLELIST_SURROUND_SOUND:
                   {
                  #if (ENABLE_AUDIO_SURROUND_VSPK)
                        return EN_DL_STATE_NORMAL;
                   #else
                        return EN_DL_STATE_HIDDEN;
                   #endif
                   }
                   break;

                default:
                   return EN_DL_STATE_NORMAL;
            }
            break;

        case HWND_MENU_SINGLELIST_ITEM7:
             switch(MApp_ZUI_ACT_GetSingleListMode())
            {
                case EN_COMMON_SINGLELIST_ASPECT_RATIO: // en_str_AspectRatio_JustScan
                     {
                    if ( IsVgaInUse()
                      || IsStorageInUse()
                      || IsDigitalSourceInUse()
                      || ( IsYPbPrInUse() && !MApi_XC_Sys_IsSrcHD(MAIN_WINDOW) )
                  #if (INPUT_HDMI_VIDEO_COUNT > 0)
                      || ( IsHDMIInUse() && !g_HdmiPollingStatus.bIsHDMIMode )
                  #endif
                       )
                         return EN_DL_STATE_DISABLED;
		     else if(IsDTVInUse()&&MApi_XC_IsCurrentFrameBufferLessMode())
                         return EN_DL_STATE_DISABLED;
                     else
                         return EN_DL_STATE_NORMAL;
                     }


                case EN_COMMON_SINGLELIST_NOISE_REDUCTION:
                case EN_COMMON_SINGLELIST_SURROUND_SOUND:
                   return EN_DL_STATE_HIDDEN;

                case EN_COMMON_SINGLELIST_PARENTAL_GUIDANCE:
                  #if (ENABLE_SBTVD_BRAZIL_APP)
                   return EN_DL_STATE_HIDDEN;
                #else
                   return EN_DL_STATE_NORMAL;
                #endif

                default:
                   return EN_DL_STATE_NORMAL;
            }
            break;

        case HWND_MENU_SINGLELIST_ITEM8:
            switch(MApp_ZUI_ACT_GetSingleListMode())
            {
                case EN_COMMON_SINGLELIST_ASPECT_RATIO: //en_str_AspectRatio_Panorama
                     {
                    if ( IsVgaInUse()
                      || IsStorageInUse()
                  #if (INPUT_HDMI_VIDEO_COUNT > 0)
                      || ( IsHDMIInUse() && !g_HdmiPollingStatus.bIsHDMIMode )
                  #endif
                       )
                         return EN_DL_STATE_DISABLED;
		     else if(IsDTVInUse()&&MApi_XC_IsCurrentFrameBufferLessMode())
                         return EN_DL_STATE_DISABLED;
                     else
                         return EN_DL_STATE_NORMAL;
                     }

                case EN_COMMON_SINGLELIST_NOISE_REDUCTION:
                case EN_COMMON_SINGLELIST_SURROUND_SOUND:
                   return EN_DL_STATE_HIDDEN;

                case EN_COMMON_SINGLELIST_PARENTAL_GUIDANCE:
                  #if (ENABLE_SBTVD_BRAZIL_APP)
                   return EN_DL_STATE_HIDDEN;
                  #else
                   return EN_DL_STATE_NORMAL;
                  #endif

                default:
                   return EN_DL_STATE_NORMAL;
            }
            break;

        case HWND_MENU_SINGLELIST_ITEM9:
            switch(MApp_ZUI_ACT_GetSingleListMode())
            {
                case EN_COMMON_SINGLELIST_ASPECT_RATIO:
                {
                #if VGA_HDMI_YUV_POINT_TO_POINT
                    if ( IsVgaInUse()
                  #if (INPUT_HDMI_VIDEO_COUNT > 0)
                    #if (MEMORY_MAP <= MMAP_32MB)
                      || ( IsHDMIInUse() && MDrv_PQ_Check_PointToPoint_Mode() )
                    #endif
                      || (  IsHDMIInUse() && (!MApi_XC_IsCurrentFrameBufferLessMode())
                         && (!MApi_XC_IsCurrentRequest_FrameBufferLessMode()) )
                  #endif
                       )
                    {
                        return EN_DL_STATE_NORMAL;
                    }
		    else if(IsDTVInUse()&&MApi_XC_IsCurrentFrameBufferLessMode())
                         return EN_DL_STATE_DISABLED;
                    else
                    {
                        return EN_DL_STATE_HIDDEN;
                    }
                #else
                    return EN_DL_STATE_HIDDEN;
                #endif
                }

                case EN_COMMON_SINGLELIST_NOISE_REDUCTION:
                case EN_COMMON_SINGLELIST_SURROUND_SOUND:
                   return EN_DL_STATE_HIDDEN;

                case EN_COMMON_SINGLELIST_PARENTAL_GUIDANCE:
                  #if ENABLE_SBTVD_BRAZIL_APP
                   return EN_DL_STATE_HIDDEN;
                  #else
                   return EN_DL_STATE_NORMAL;
                  #endif

            #if ENABLE_3D_PROCESS
                case EN_COMMON_SINGLELIST_3D_OPTION:
                   return EN_DL_STATE_HIDDEN;
            #endif

                default:
                   return EN_DL_STATE_NORMAL;
            }
            break;

        case HWND_MENU_SINGLELIST_ITEM10:
            switch(MApp_ZUI_ACT_GetSingleListMode())
            {
                case EN_COMMON_SINGLELIST_ASPECT_RATIO:
                case EN_COMMON_SINGLELIST_NOISE_REDUCTION:
                case EN_COMMON_SINGLELIST_SURROUND_SOUND:
                case EN_COMMON_SINGLELIST_SLEEP_TIMER:
                   return EN_DL_STATE_HIDDEN;

                case EN_COMMON_SINGLELIST_PARENTAL_GUIDANCE:
                  #if ENABLE_SBTVD_BRAZIL_APP
                   return EN_DL_STATE_HIDDEN;
                  #else
                   return EN_DL_STATE_NORMAL;
                  #endif

            #if (ATSC_CC == ATV_CC)
                case EN_COMMON_SINGLELIST_CC_OPTION:
                   return EN_DL_STATE_HIDDEN;
            #endif
            #if ENABLE_3D_PROCESS
                case EN_COMMON_SINGLELIST_3D_OPTION:
                   return EN_DL_STATE_HIDDEN;
            #endif

                default:
                   return EN_DL_STATE_NORMAL;
            }
            break;

        case HWND_MENU_SINGLELIST_ITEM11:
            switch(MApp_ZUI_ACT_GetSingleListMode())
            {
                case EN_COMMON_SINGLELIST_ASPECT_RATIO:
                case EN_COMMON_SINGLELIST_NOISE_REDUCTION:
                case EN_COMMON_SINGLELIST_SURROUND_SOUND:
                case EN_COMMON_SINGLELIST_SLEEP_TIMER:
                   return EN_DL_STATE_HIDDEN;

                case EN_COMMON_SINGLELIST_PARENTAL_GUIDANCE:
                  #if ENABLE_SBTVD_BRAZIL_APP
                   return EN_DL_STATE_HIDDEN;
                  #else
                   return EN_DL_STATE_NORMAL;
                  #endif

            #if (ATSC_CC == ATV_CC)
                case EN_COMMON_SINGLELIST_CC_OPTION:
                   return EN_DL_STATE_HIDDEN;
            #endif
            #if ENABLE_3D_PROCESS
                case EN_COMMON_SINGLELIST_3D_OPTION:
                   return EN_DL_STATE_HIDDEN;
            #endif

                default:
                   return EN_DL_STATE_NORMAL;
            }
            break;

        case HWND_MENU_SINGLELIST_ITEM12:
            switch(MApp_ZUI_ACT_GetSingleListMode())
            {
                case EN_COMMON_SINGLELIST_ASPECT_RATIO:
                case EN_COMMON_SINGLELIST_NOISE_REDUCTION:
                case EN_COMMON_SINGLELIST_SURROUND_SOUND:
                case EN_COMMON_SINGLELIST_SLEEP_TIMER:
                   return EN_DL_STATE_HIDDEN;
                case EN_COMMON_SINGLELIST_PARENTAL_GUIDANCE:
                #if ENABLE_SBTVD_BRAZIL_APP
                   return EN_DL_STATE_HIDDEN;
                #else
                   return EN_DL_STATE_NORMAL;
                #endif

            #if (ATSC_CC == ATV_CC)
                case EN_COMMON_SINGLELIST_CC_OPTION:
                   return EN_DL_STATE_HIDDEN;
            #endif
            #if ENABLE_3D_PROCESS
                case EN_COMMON_SINGLELIST_3D_OPTION:
                   return EN_DL_STATE_HIDDEN;
            #endif

                default:
                   return EN_DL_STATE_NORMAL;
            }
            break;

        case HWND_MENU_SINGLELIST_ITEM13:
            switch(MApp_ZUI_ACT_GetSingleListMode())
            {
                case EN_COMMON_SINGLELIST_ASPECT_RATIO:
                case EN_COMMON_SINGLELIST_NOISE_REDUCTION:
                case EN_COMMON_SINGLELIST_SURROUND_SOUND:
                case EN_COMMON_SINGLELIST_SLEEP_TIMER:
                   return EN_DL_STATE_HIDDEN;

                case EN_COMMON_SINGLELIST_PARENTAL_GUIDANCE:
                  #if ENABLE_SBTVD_BRAZIL_APP
                   return EN_DL_STATE_HIDDEN;
                  #else
                   return EN_DL_STATE_NORMAL;
                  #endif

            #if (ATSC_CC == ATV_CC)
                case EN_COMMON_SINGLELIST_CC_OPTION:
                   return EN_DL_STATE_HIDDEN;
            #endif
            #if ENABLE_3D_PROCESS
                case EN_COMMON_SINGLELIST_3D_OPTION:
                   return EN_DL_STATE_HIDDEN;
            #endif

                default:
                   return EN_DL_STATE_NORMAL;
            }
            break;

        case HWND_MENU_SINGLELIST_ITEM14:
            switch(MApp_ZUI_ACT_GetSingleListMode())
            {
                case EN_COMMON_SINGLELIST_ASPECT_RATIO:
                case EN_COMMON_SINGLELIST_NOISE_REDUCTION:
                case EN_COMMON_SINGLELIST_SURROUND_SOUND:
                case EN_COMMON_SINGLELIST_SLEEP_TIMER:
                   return EN_DL_STATE_HIDDEN;

                case EN_COMMON_SINGLELIST_PARENTAL_GUIDANCE:
                  #if ENABLE_SBTVD_BRAZIL_APP
                   return EN_DL_STATE_HIDDEN;
                  #else
                   return EN_DL_STATE_NORMAL;
                  #endif

            #if (ATSC_CC == ATV_CC)
                case EN_COMMON_SINGLELIST_CC_OPTION:
                   return EN_DL_STATE_HIDDEN;
            #endif
            #if ENABLE_3D_PROCESS
                case EN_COMMON_SINGLELIST_3D_OPTION:
                   return EN_DL_STATE_HIDDEN;
            #endif

                default:
                   return EN_DL_STATE_NORMAL;
            }
            break;

        case HWND_MENU_SINGLELIST_ITEM15:
            switch(MApp_ZUI_ACT_GetSingleListMode())
            {
                case EN_COMMON_SINGLELIST_ASPECT_RATIO:
                case EN_COMMON_SINGLELIST_NOISE_REDUCTION:
                case EN_COMMON_SINGLELIST_SURROUND_SOUND:
                case EN_COMMON_SINGLELIST_SLEEP_TIMER:
                   return EN_DL_STATE_HIDDEN;

                case EN_COMMON_SINGLELIST_PARENTAL_GUIDANCE:
                  #if ENABLE_SBTVD_BRAZIL_APP
                   return EN_DL_STATE_HIDDEN;
                  #else
                   return EN_DL_STATE_NORMAL;
                  #endif

            #if (ATSC_CC == ATV_CC)
                case EN_COMMON_SINGLELIST_CC_OPTION:
                   return EN_DL_STATE_HIDDEN;
            #endif
            #if ENABLE_3D_PROCESS
                case EN_COMMON_SINGLELIST_3D_OPTION:
                   return EN_DL_STATE_HIDDEN;
            #endif

                default:
                   return EN_DL_STATE_NORMAL;
            }
            break;

        case HWND_MENU_SINGLELIST_ITEM16:
            switch(MApp_ZUI_ACT_GetSingleListMode())
            {
                case EN_COMMON_SINGLELIST_ASPECT_RATIO:
                case EN_COMMON_SINGLELIST_NOISE_REDUCTION:
                case EN_COMMON_SINGLELIST_SURROUND_SOUND:
                case EN_COMMON_SINGLELIST_SLEEP_TIMER:
                   return EN_DL_STATE_HIDDEN;

                case EN_COMMON_SINGLELIST_PARENTAL_GUIDANCE:
                #if ENABLE_SBTVD_BRAZIL_APP
                   return EN_DL_STATE_HIDDEN;
                #else
                   return EN_DL_STATE_NORMAL;
                #endif

            #if (ATSC_CC == ATV_CC)
                case EN_COMMON_SINGLELIST_CC_OPTION:
                   return EN_DL_STATE_HIDDEN;
            #endif
            #if ENABLE_3D_PROCESS
                case EN_COMMON_SINGLELIST_3D_OPTION:
                   return EN_DL_STATE_HIDDEN;
            #endif

                default:
                   return EN_DL_STATE_NORMAL;
            }
            break;

          case HWND_MENU_OPTIONLIST_ITEM1:
            switch(MApp_ZUI_ACT_GetOptionListMode())
            {
                case EN_COMMON_OPTIONLIST_NETWORK_DNS:
                case EN_COMMON_OPTIONLIST_NETWORK_GW:
                case EN_COMMON_OPTIONLIST_NETWORK_IP:
                case EN_COMMON_OPTIONLIST_NETWORK_NETMASK:
                case EN_COMMON_OPTIONLIST_SOUND_BALANCE:
                   return EN_DL_STATE_DISABLED;
                default:
                   return EN_DL_STATE_NORMAL;
            }
            break;

        case HWND_MENU_OPTIONLIST_ITEM2:
            switch(MApp_ZUI_ACT_GetOptionListMode())
            {
                case EN_COMMON_OPTIONLIST_NETWORK_CONFIG:
                    if(stGenSetting.g_SysSetting.g_Network.Net_Config_mode == EN_NET_STATIC)
                    {
                        return EN_DL_STATE_NORMAL;
                    }
                    else
                    {
                        return EN_DL_STATE_DISABLED;
                    }
                default:
                   return EN_DL_STATE_NORMAL;
            }
            break;

        case HWND_MENU_OPTIONLIST_ITEM3:
            switch(MApp_ZUI_ACT_GetOptionListMode())
            {
                case EN_COMMON_OPTIONLIST_NETWORK_CONFIG:
                    if(stGenSetting.g_SysSetting.g_Network.Net_Config_mode == EN_NET_STATIC)
                    {
                        return EN_DL_STATE_NORMAL;
                    }
                    else
                    {
                        return EN_DL_STATE_DISABLED;
                    }
                 case EN_COMMON_OPTIONLIST_SOUND_BALANCE:
                    return EN_DL_STATE_DISABLED;
                default:
                   return EN_DL_STATE_NORMAL;
            }
            break;

        case HWND_MENU_OPTIONLIST_ITEM4:
            switch(MApp_ZUI_ACT_GetOptionListMode())
            {
                case EN_COMMON_OPTIONLIST_NETWORK_CONFIG:
                    if(stGenSetting.g_SysSetting.g_Network.Net_Config_mode == EN_NET_STATIC)
                    {
                        return EN_DL_STATE_NORMAL;
                    }
                    else
                    {
                        return EN_DL_STATE_DISABLED;
                    }
                case EN_COMMON_OPTIONLIST_SOUND_BALANCE:
                    return EN_DL_STATE_DISABLED;
                default:
                   return EN_DL_STATE_NORMAL;
            }
            break;

        case HWND_MENU_OPTIONLIST_ITEM5:
            switch(MApp_ZUI_ACT_GetOptionListMode())
            {
                case EN_COMMON_OPTIONLIST_NETWORK_CONFIG:
                    if(stGenSetting.g_SysSetting.g_Network.Net_Config_mode == EN_NET_STATIC)
                    {
                        return EN_DL_STATE_NORMAL;
                    }
                    else
                    {
                        return EN_DL_STATE_DISABLED;
                    }
                case EN_COMMON_OPTIONLIST_SOUND_BALANCE:
                    return EN_DL_STATE_DISABLED;
                default:
                   return EN_DL_STATE_NORMAL;
            }
            break;

        case HWND_MENU_OPTIONLIST_ITEM6:
            switch(MApp_ZUI_ACT_GetOptionListMode())
            {
                case EN_COMMON_OPTIONLIST_NETWORK_DNS:
                case EN_COMMON_OPTIONLIST_NETWORK_GW:
                case EN_COMMON_OPTIONLIST_NETWORK_IP:
                case EN_COMMON_OPTIONLIST_NETWORK_NETMASK:
                case EN_COMMON_OPTIONLIST_SOUND_BALANCE:
                case EN_COMMON_OPTIONLIST_NETWORK_CONFIG:
                   return EN_DL_STATE_DISABLED;
                default:
                   return EN_DL_STATE_NORMAL;
            }
            break;

        case HWND_MENU_OPTIONLIST_ITEM7:
            switch(MApp_ZUI_ACT_GetOptionListMode())
            {
                case EN_COMMON_OPTIONLIST_NETWORK_DNS:
                case EN_COMMON_OPTIONLIST_NETWORK_GW:
                case EN_COMMON_OPTIONLIST_NETWORK_IP:
                case EN_COMMON_OPTIONLIST_NETWORK_NETMASK:
                case EN_COMMON_OPTIONLIST_SOUND_BALANCE:
                case EN_COMMON_OPTIONLIST_NETWORK_CONFIG:
                   return EN_DL_STATE_DISABLED;
                default:
                   return EN_DL_STATE_NORMAL;
            }
            break;
#endif
        case HWND_MENU_PICCOLOR_COLOR_RED:
        case HWND_MENU_PICCOLOR_COLOR_GREEN:
        case HWND_MENU_PICCOLOR_COLOR_BLUE:
#if(MS_COLOR_TEMP_COUNT ==4)
            if (ST_PICTURE.eColorTemp == MS_COLOR_TEMP_USER)
            {
                return EN_DL_STATE_NORMAL;
            }
            else
#endif
            {
                return EN_DL_STATE_DISABLED;
            }
            break;

        case HWND_MENU_ADVANCE_PICTURE_FLESH_TONE_OPTION:
#if ENABLE_CUS_USB_OSD
        case HWND_MENU_ADVANCE_PICTURE_NOISE_REDUCTION:
#endif
        case HWND_MENU_ADVANCE_PICTURE_DCR_ADV:
#if ENABLE_CUS_DBC
        case HWND_MENU_ADVANCE_PICTURE_DCR:
#endif
            if(MApp_Scaler_CheckDBC_DLCAvailable())
            {
                return EN_DL_STATE_NORMAL;
            }
            else
            {
                //return EN_DL_STATE_HIDDEN;
                return EN_DL_STATE_DISABLED;
            }
            break;

#if !ENABLE_CUS_DBC
        case HWND_MENU_ADVANCE_PICTURE_DCR:
            return EN_DL_STATE_HIDDEN;
#endif

#if !ENABLE_CUS_USB_OSD
        case HWND_MENU_ADVANCE_PICTURE_NOISE_REDUCTION:
            if(MApp_Scaler_CheckDBC_DLCAvailable() && !IsStorageInUse())
            {
                return EN_DL_STATE_NORMAL;
            }
            else
            {
                //return EN_DL_STATE_HIDDEN;
                return EN_DL_STATE_DISABLED;
            }
            break;
#endif

        case HWND_MENU_ADVANCE_PICTURE_COLOR_RANGE:
            return EN_DL_STATE_HIDDEN; //for TVP spec.
            if(IsHDMIInUse())
            {
                return EN_DL_STATE_NORMAL;
            }
            else
            {
                return EN_DL_STATE_DISABLED;
            }
            break;
#if (ENABLE_CUS_UI_SPEC == DISABLE)
        case HWND_MENU_PICTURE_PC_ADJUST:
            if(IsVgaInUse())
            {
                return EN_DL_STATE_NORMAL;
            }
            else
            {
                return EN_DL_STATE_HIDDEN;
            }
            break;
 #endif
        case HWND_MENU_OPTION_ASPECT_RATIO:
            {
                #if ENABLE_DMP
                    if (IsStorageInUse())// && MApp_MPlayer_QueryMoviePlayMode() == E_MPLAYER_MOVIE_PAUSE)
                    {
                        return EN_DL_STATE_HIDDEN;
                    }
                    else
                #endif
                #if ENABLE_CUS_UI_SPEC
                    if(MApp_IsSrcHasSignal(MAIN_WINDOW) != TRUE)
                    {
                        return EN_DL_STATE_DISABLED;
                    }
                    else
                #endif
                    {
                        #if ENABLE_3D_PROCESS
                        if(IsHDMIInUse())
                        {
                            #if ENABLE_CUS_3D_SOURCE_MEMORY
                            if(g_HdmiPollingStatus.bIsHDMIMode == FALSE)
                            {
                                if(ST_VGA_3D_TYPE != EN_3D_BYPASS)
                                {
                                    return EN_DL_STATE_DISABLED;
                                }
                            }
                            else
                            #endif
                            {
                                if(stGenSetting.g_SysSetting.en3DDetectMode == EN_3D_DETECT_AUTO)
                                {
                                    if(g_HdmiInput3DFormatStatus==E_XC_3D_INPUT_MODE_NONE)
                                        return EN_DL_STATE_NORMAL;
                                    else
                                        return EN_DL_STATE_DISABLED;
                                }
                                else if(ST_3D_TYPE != EN_3D_BYPASS)
                                {
                                    return EN_DL_STATE_DISABLED;
                                }
                            }
                            return EN_DL_STATE_NORMAL;
                        }
                        else if(ST_3D_TYPE != EN_3D_BYPASS)
                        {
                            return EN_DL_STATE_DISABLED;
                        }
                        #endif
                        {
                            return EN_DL_STATE_NORMAL;
                        }
                    }
            }
            break;
        case HWND_MENU_PICTURE_PIP:
        #if (ENABLE_PIP)
            //PIP Limitations: If current input source is MM or Internet APs, do not allow entering PIP/POP mode.
            if(IsPIPSupported())
            {
                if(IsStorageInUse())
                {
                    return EN_DL_STATE_DISABLED;
                }
                return EN_DL_STATE_NORMAL;
            }
            else
            #endif
            {
                return EN_DL_STATE_HIDDEN;
            }
            break;

        #if (ENABLE_PIP)
        case HWND_MENU_PIP_SUBSRC:
        case HWND_MENU_PIP_SOUND_SRC:
        case HWND_MENU_PIP_SWAP:
            if(!IsPIPEnable())
                return EN_DL_STATE_DISABLED;
            else
                return EN_DL_STATE_NORMAL;

        case HWND_MENU_PIP_SIZE:
        case HWND_MENU_PIP_POSITION:
        case HWND_MENU_PIP_BORDER:
            if(IsPIPSupported() && stGenSetting.g_stPipSetting.enPipMode == EN_PIP_MODE_PIP )
                return EN_DL_STATE_NORMAL;
            else
                return EN_DL_STATE_DISABLED;
        #endif

#if (ENABLE_CUS_UI_SPEC == FALSE)
        //from MENU_CHANNEL_A ===========================
        case HWND_MENU_CHANNEL_CI_INFORMATION:
        {
#if(ENABLE_CI_FUNCTION)
     #if (ENABLE_DTV == 0)
            return EN_DL_STATE_HIDDEN;
     #else
            return EN_DL_STATE_NORMAL;
     #endif
#else
            return EN_DL_STATE_HIDDEN;
#endif
        }
#endif

        case HWND_MENU_CHANNEL_SW_OAD_UPGRADE:
        {
        #if ENABLE_DTV
         #if ENABLE_SBTVD_BRAZIL_APP
            return EN_DL_STATE_HIDDEN;
         #else
          #if(ENABLE_SOFTWAREUPDATE)
            if (IsDTVInUse())
            {
                return EN_DL_STATE_NORMAL;
            }
            else
            {
                return EN_DL_STATE_DISABLED;
            }
          #else
            return EN_DL_STATE_HIDDEN;
          #endif
         #endif
        #else
            return EN_DL_STATE_HIDDEN;
        #endif
        }

    case HWND_MENU_CHANNEL_SW_USB_UPGRADE:
           #if ENABLE_CUS_UI_SPEC == FALSE
            return EN_DL_STATE_NORMAL;
           #else
            return EN_DL_STATE_HIDDEN;
           #endif

    case HWND_MENU_CHANNEL_5V_ANTENNA:
        {
        #if ENABLE_SBTVD_BRAZIL_APP
            return EN_DL_STATE_HIDDEN;
        #else
          #ifdef ENABLE_5VANTENNA
            if(IsAnyTVSourceInUse())
            {
                return EN_DL_STATE_NORMAL;
            }
            else
            {
                return EN_DL_STATE_DISABLED;
            }
          #else
            return EN_DL_STATE_HIDDEN;
          #endif
        #endif
        }
#if ( ENABLE_SBTVD_BRAZIL_APP)
       #if (ENABLE_CUS_UI_SPEC == DISABLE)
        case HWND_MENU_CHANNEL_CADTV_MAN_TUNE:
                return EN_DL_STATE_HIDDEN;
       #endif


        case HWND_MENU_CHANNEL_DTV_MAN_TUNE:

            if (msAPI_ATV_GetCurrentAntenna() == ANT_CATV)
            {
                return EN_DL_STATE_DISABLED;
            }
        #if (DVB_C_ENABLE)
            if (IsCATVInUse() && hwnd == HWND_MENU_CHANNEL_DTV_MAN_TUNE)
            {
                return EN_DL_STATE_HIDDEN;
            }
            else if (!IsCATVInUse() && hwnd == HWND_MENU_CHANNEL_CADTV_MAN_TUNE)
            {
                return EN_DL_STATE_HIDDEN;
            }
        #else
            if(hwnd == HWND_MENU_CHANNEL_CADTV_MAN_TUNE)
            {
                return EN_DL_STATE_HIDDEN;
            }
        #endif
        #if ENABLE_PVR
            if( MApp_PVR_IsPlaybacking() || MApp_PVR_IsRecording())
            {
                return EN_DL_STATE_DISABLED;
            }
            //go on  next check
        #endif
        {
            #if (DVB_C_ENABLE)
            MApi_AUTH_Process(Customer_info,Customer_hash);
            if(MDrv_AUTH_IPCheck(IPAUTH_CONTROL_XC_DVBC) != TRUE && hwnd == HWND_MENU_CHANNEL_CADTV_MAN_TUNE)
                return EN_DL_STATE_HIDDEN;
            #endif

        #if (ENABLE_DTV == 0)
            if((hwnd == HWND_MENU_CHANNEL_DTV_MAN_TUNE)||(hwnd == HWND_MENU_CHANNEL_SIGNAL_INFORMAT))
            {
                return EN_DL_STATE_HIDDEN;
            }
            else
            {
                //from case MI_TV_ONLY:
                if( IsAnyTVSourceInUse() )
                {
                    return EN_DL_STATE_NORMAL;
                }
                else
                {
                    return EN_DL_STATE_DISABLED;
                }
            }
        #else
            //from case MI_TV_ONLY:
            if( IsAnyTVSourceInUse() )
            {
                if( IsATVInUse() && hwnd == HWND_MENU_CHANNEL_SIGNAL_INFORMAT)
                {
                    return EN_DL_STATE_DISABLED;
                }
                return EN_DL_STATE_NORMAL;
            }
            else
            {
                return EN_DL_STATE_DISABLED;
            }
            #endif
        }
        break;
#else
        case HWND_MENU_CHANNEL_DTV_MAN_TUNE:
       #if (ENABLE_CUS_UI_SPEC == DISABLE)
        case HWND_MENU_CHANNEL_CADTV_MAN_TUNE:
       #endif
        #if (DVB_C_ENABLE)
            if (IsCATVInUse() && hwnd == HWND_MENU_CHANNEL_DTV_MAN_TUNE)
            {
                return EN_DL_STATE_HIDDEN;
            }
          #if (ENABLE_CUS_UI_SPEC == DISABLE)
            else if (!IsCATVInUse() && hwnd == HWND_MENU_CHANNEL_CADTV_MAN_TUNE)
            {
                return EN_DL_STATE_HIDDEN;
            }
           #endif
        #else
           #if (ENABLE_CUS_UI_SPEC == DISABLE)
            if(hwnd == HWND_MENU_CHANNEL_CADTV_MAN_TUNE)
            {
                return EN_DL_STATE_HIDDEN;
            }
           #endif
        #endif
        #if ENABLE_PVR
            if( MApp_PVR_IsPlaybacking() || MApp_PVR_IsRecording())
            {
                return EN_DL_STATE_DISABLED;
            }
            //go on  next check
        #endif
        {
            #if (DVB_C_ENABLE)
            MApi_AUTH_Process(Customer_info,Customer_hash);
            if(MDrv_AUTH_IPCheck(IPAUTH_CONTROL_XC_DVBC) != TRUE && hwnd == HWND_MENU_CHANNEL_CADTV_MAN_TUNE)
                return EN_DL_STATE_HIDDEN;
            #endif

        #if (ENABLE_DTV == 0)
            if((hwnd == HWND_MENU_CHANNEL_DTV_MAN_TUNE)||(hwnd == HWND_MENU_CHANNEL_SIGNAL_INFORMAT))
            {
                return EN_DL_STATE_HIDDEN;
            }
            else
            {
                //from case MI_TV_ONLY:
                if( IsAnyTVSourceInUse() )
                {
                    return EN_DL_STATE_NORMAL;
                }
                else
                {
                    return EN_DL_STATE_DISABLED;
                }
            }
        #else
            //from case MI_TV_ONLY:
            if( IsAnyTVSourceInUse() )
            {
                if( IsATVInUse() && hwnd == HWND_MENU_CHANNEL_SIGNAL_INFORMAT)
                {
                    return EN_DL_STATE_DISABLED;
                }
                return EN_DL_STATE_NORMAL;
            }
            else
            {
                return EN_DL_STATE_DISABLED;
            }
            #endif
        }
        break;
#endif
        case HWND_MENU_CHANNEL_AUTOTUNE:
        case HWND_MENU_CHANNEL_ATV_MAN_TUNE:
          #if ENABLE_PVR
            if( MApp_PVR_IsPlaybacking() || MApp_PVR_IsRecording())
            {
                return EN_DL_STATE_DISABLED;
            }
            //go on  next check
          #endif
        case HWND_MENU_CHANNEL_SIGNAL_INFORMAT:
	#if 0//fix compiling error  //Roger.li###
        case HWND_MENU_LOCK_BLOCK_PROGRAM:
        #endif
        {
            #if (DVB_C_ENABLE)
            MApi_AUTH_Process(Customer_info,Customer_hash);
            if(MDrv_AUTH_IPCheck(IPAUTH_CONTROL_XC_DVBC) != TRUE && hwnd == HWND_MENU_CHANNEL_CADTV_MAN_TUNE)
                return EN_DL_STATE_HIDDEN;
            #endif

        #if (ENABLE_DTV == 0)
            if((hwnd == HWND_MENU_CHANNEL_DTV_MAN_TUNE)||(hwnd == HWND_MENU_CHANNEL_SIGNAL_INFORMAT))
            {
                return EN_DL_STATE_HIDDEN;
            }
            else
            {
                //from case MI_TV_ONLY:
                if( IsAnyTVSourceInUse() )
                {
                    return EN_DL_STATE_NORMAL;
                }
                else
                {
                    return EN_DL_STATE_DISABLED;
                }
            }
        #else
            //from case MI_TV_ONLY:
            if( IsAnyTVSourceInUse() )
            {
                if( IsATVInUse() && hwnd == HWND_MENU_CHANNEL_SIGNAL_INFORMAT)
                {
                    return EN_DL_STATE_DISABLED;
                }
                return EN_DL_STATE_NORMAL;
            }
            else
            {
                return EN_DL_STATE_DISABLED;
            }
            #endif
         }
         break;
         case HWND_MENU_CHANNEL_PROGRAM_EDIT:
         case HWND_MENU_CHANNEL_CLEAN_CH_LIST:
         case HWND_MENU_LOCK_MAINSUBPAGE_ITEM_CHANNELBLOCK:
    #if ENABLE_CUS_UI_SPEC // onlay ATV
             if(msAPI_ATV_GetActiveProgramCount())
             {
                 return EN_DL_STATE_NORMAL;
             }
             else
             {
                return EN_DL_STATE_DISABLED;
             }
    #endif

             break;

        case HWND_MENU_LOCK_MAINSUBPAGE_ITEM_KEYBDLOCK:
            return EN_DL_STATE_HIDDEN;
            break;

        case HWND_MENU_SOUND_SPDIF_MODE:
            #if ENABLE_CUS_UI_SPEC
            return EN_DL_STATE_HIDDEN;
            #endif

            if ( (PADS_SPDIF_IN == Unknown_pad_mux) && (PADS_SPDIF_OUT == Unknown_pad_mux) )
                return EN_DL_STATE_DISABLED;
            break;
        case HWND_MENU_SOUND_AUDIO_DELAY:
            if(stGenSetting.g_SysSetting.fSPDIFMODE)
            {
                return EN_DL_STATE_HIDDEN;
            }
            else
            {
                return EN_DL_STATE_HIDDEN;
            }

        //from MMI_C2_Audio ===============================
        case HWND_MENU_SNDEQ_12_KHZ:
        case HWND_MENU_SNDEQ_1_2_KHZ:
        case HWND_MENU_SNDEQ_7_5_KHZ:
        case HWND_MENU_SNDEQ_120_HZ:
        case HWND_MENU_SNDEQ_500_HZ:
        {
#ifdef ENABLE_AUDIO_FREQ
            return EN_DL_STATE_NORMAL;
#else
            return EN_DL_STATE_HIDDEN;
#endif
        }

        case HWND_MENU_SNDEQ_200_HZ:
        case HWND_MENU_SNDEQ_3_KHZ:
            return EN_DL_STATE_HIDDEN;

        case HWND_MENU_SNDMODE_BASS:
        case HWND_MENU_SNDMODE_TREBLE:
        case HWND_MENU_SOUND_BASS:
        case HWND_MENU_SOUND_TREBLE:
            if(stGenSetting.g_SoundSetting.SoundMode==SOUND_MODE_USER)
            {
                return EN_DL_STATE_NORMAL;
            }
            else
            {
                return EN_DL_STATE_DISABLED;
            }

        case HWND_MENU_SOUND_AD_SWITCH:
#if (ENABLE_CUS_UI_SPEC == DISABLE)/*Creass.liu at 2012-06-27*/
        case HWND_MENU_SOUND_SWITCH_AD_SWITCH:
#endif
#if ENABLE_SBTVD_BRAZIL_APP
            return EN_DL_STATE_HIDDEN;
#else
      #if ENABLE_DTV
            if(IsDTVInUse())
            {
                return EN_DL_STATE_NORMAL;
            }
            else
            {
                return EN_DL_STATE_DISABLED;
            }
      #else
            return EN_DL_STATE_HIDDEN;
      #endif
#endif

#if (ENABLE_CUS_UI_SPEC == DISABLE)/*Creass.liu at 2012-06-27*/
        case HWND_MENU_SOUND_SWITCH_AD_FADE:
#if ENABLE_SBTVD_BRAZIL_APP
            return EN_DL_STATE_HIDDEN;
#else
            if(stGenSetting.g_SoundSetting.bEnableAD)
            {
                return EN_DL_STATE_NORMAL;
            }
            else
            {
                return EN_DL_STATE_DISABLED;
            }
#endif
#endif

        //from MENU_TIME_D ==================================
        case HWND_MENU_TIME_SET_CLOCK:
        {
#if ENABLE_DTV
            if (!MApp_SI_IsAutoClockValid())
            {
                return EN_DL_STATE_NORMAL;
            }
            else
            {
                return EN_DL_STATE_DISABLED;
            }
#else
            return EN_DL_STATE_NORMAL;
#endif
        }

        case HWND_MENU_TIME_SET_ONTIME:
        case HWND_MENU_TIME_ON_TIME_SETUP:
            if (stGenSetting.g_Time.cOnTimerFlag==EN_Time_OnTimer_Off)
            {
                return EN_DL_STATE_DISABLED;
            }
            else
            {
                return EN_DL_STATE_NORMAL;
            }

        case HWND_MENU_TIME_SET_OFFTIME:
            if (stGenSetting.g_Time.cOffTimerFlag==EN_Time_OffTimer_Off)
            {
                return EN_DL_STATE_DISABLED;
            }
            else
            {
                return EN_DL_STATE_NORMAL;
            }

        //from MENU_OPTION ===============================
        case HWND_MENU_OPTION_OSD_EFFECT:
        {
            return EN_DL_STATE_HIDDEN;
        }
        case HWND_MENU_OPTION_COUNTRY:
        {
 #if ENABLE_SBTVD_BRAZIL_APP
            return EN_DL_STATE_HIDDEN;
 #elif ENABLE_ATV_CHINA_APP
            return EN_DL_STATE_HIDDEN;
 #else
            return EN_DL_STATE_DISABLED;
 #endif
        }

      case HWND_MENU_OPTION_FACTORY_RESET:
#if ENABLE_CUS_UI_SPEC
            return EN_DL_STATE_NORMAL;
#else
  #if ENABLE_PVR
            if( MApp_PVR_IsPlaybacking() || MApp_PVR_IsRecording())
            {
                return EN_DL_STATE_DISABLED;
            }
            else
             {
                return EN_DL_STATE_NORMAL;
            }
  #endif
  #endif

        case HWND_MENU_OPTION_AUDIO_LANG:
        {
      #if ENABLE_DTV
            if(IsDTVInUse())
            {
                return EN_DL_STATE_NORMAL;
            }
            else
            {
                return EN_DL_STATE_DISABLED;
            }
      #else
            return EN_DL_STATE_HIDDEN;
      #endif
        }

#if ENABLE_CUS_UI_SPEC
        case HWND_MENU_OPTION_HDMI_MODE:
#if 0//ENABLE_CUS_HDMI_MODE
            if(IsHDMIInUse())
            {
                if(MApp_Scaler_CheckHDMIModeAvailable() == TRUE)
                {
                    return EN_DL_STATE_NORMAL;
                }
                else
                {
                    return EN_DL_STATE_HIDDEN;
                }
            }
            else
            {
                return EN_DL_STATE_HIDDEN;
            }
#else
            return EN_DL_STATE_HIDDEN;
#endif
        #if(UI_SKIN_SEL==UI_SKIN_1366X768X565_HAIER_CN)  // CUS_xm zHIHE 20120817modify
        case HWND_MENU_OPTION_TELETEXT:
			#if ENABLE_TTX
			return EN_DL_STATE_NORMAL;
			#else
			return EN_DL_STATE_HIDDEN;
			#endif
	    #endif
        case HWND_MENU_OPTION_3D_MODE_SETTING:
#if ENABLE_3D_PROCESS
            {
                if(IsStorageInUse())
                {
                    if(MApp_MPlayer_IsMoviePlaying()||MApp_MPlayer_IsPhotoPlaying())
                    {
                        return EN_DL_STATE_NORMAL;
                    }
                    else
                    {
                        return EN_DL_STATE_DISABLED;
                    }
                }
                else
                {
                    if(MApp_IsSrcHasSignal(MAIN_WINDOW))
                    {
                        return EN_DL_STATE_NORMAL;
                    }
                    else
                    {
                        return EN_DL_STATE_DISABLED;
                    }
                }
            }
#else
            return EN_DL_STATE_HIDDEN;
#endif
#endif

        case HWND_MENU_OPTION_HDMI_CEC:
#if ENABLE_CUS_UI_SPEC
            return EN_DL_STATE_HIDDEN;
#else
#if ENABLE_CEC
            return EN_DL_STATE_NORMAL;
#else
            return EN_DL_STATE_HIDDEN;
#endif
#endif

        case HWND_MENU_OPTION_SUBTITLE_LANG:
        {
 #if ENABLE_SBTVD_BRAZIL_APP
            return EN_DL_STATE_HIDDEN;
 #else
      #if ENABLE_DTV
            if(IsDTVInUse())
            {
                return EN_DL_STATE_NORMAL;
            }
            else
            {
                return EN_DL_STATE_DISABLED;
            }
      #else
            return EN_DL_STATE_HIDDEN;
      #endif
 #endif
        }


#if ENABLE_DTV
     case HWND_MENU_DLG_SIGNAL_INFORMAT_MODULATION:
        {
              WORD ModulMode;

                if (!msAPI_Tuner_GetSignalModulMode(&ModulMode))
               {
                        return EN_DL_STATE_HIDDEN;
               }
                else
               {
                        return EN_DL_STATE_NORMAL;
               }
        }
#endif

#if (ENABLE_CUS_UI_SPEC == DISABLE) /*Creass.liu at 2012-06-02*/
        case HWND_MENU_OPTION_HARD_HEARING:
        {
 #if ENABLE_SBTVD_BRAZIL_APP
            return EN_DL_STATE_HIDDEN;
 #else
      #if ENABLE_DTV
            if(IsDTVInUse())
            {
                return EN_DL_STATE_NORMAL;
            }
            else
            {
                return EN_DL_STATE_DISABLED;
            }
      #else
            return EN_DL_STATE_HIDDEN;
      #endif
 #endif
        }

#if ENABLE_PVR
        case HWND_MENU_OPTION_PVR_FILE_SYSTEM:
        {
    #if (ENABLE_DTV)

            if(IsDTVInUse() && !MApp_PVR_IsRecording() && !MApp_PVR_IsPlaybacking())
            {
                return EN_DL_STATE_NORMAL;
            }
            else
            {
                return EN_DL_STATE_DISABLED;
            }
    #else
            return EN_DL_STATE_HIDDEN;
    #endif
        }
#endif

        case HWND_MENU_OPTION_DIVX:
        {
#if ENABLE_DRM
            return EN_DL_STATE_NORMAL;
#else
            return EN_DL_STATE_HIDDEN;
#endif
        }

        case HWND_MENU_OPTION_DEACTIVATION:
        {
#if ENABLE_DRM
            return EN_DL_STATE_NORMAL;
#else
            return EN_DL_STATE_HIDDEN;
#endif
        }

#endif
       case HWND_MENU_OPTION_CAPTION:
       case HWND_MENU_OPTION_CC_MODE:
          #if  (ATSC_CC == ATV_CC)
            if(IsATVInUse()||IsAVInUse()||IsSVInUse())
            return EN_DL_STATE_HIDDEN;
            else
          #endif
                return EN_DL_STATE_HIDDEN;

        case HWND_MENU_OPTION_CC_OPTION:
          #if  (ATSC_CC == ATV_CC)
            if(IsATVInUse()||IsAVInUse()||IsSVInUse())
            return  EN_DL_STATE_NORMAL;
            else
          #endif
            return EN_DL_STATE_HIDDEN;

       case HWND_MENU_OPTION_3D_TYPE:
           #if ENABLE_3D_PROCESS
            {
                if(IsStorageInUse())
                {
                    if(MApp_MPlayer_IsMoviePlaying()||MApp_MPlayer_IsPhotoPlaying())
                    {
                        return EN_DL_STATE_NORMAL;
                    }
                    else
                    {
                        return EN_DL_STATE_DISABLED;
                    }
                }
                else if(IsHDMIInUse() && (g_HdmiPollingStatus.bIsHDMIMode) && MApp_IsSrcHasSignal(MAIN_WINDOW))
                {
                    if(stGenSetting.g_SysSetting.en3DDetectMode == EN_3D_DETECT_AUTO)
                    {

                        return EN_DL_STATE_DISABLED;
                    }
                    else
                    {
                        return EN_DL_STATE_NORMAL;

                    }
                }
                else
                {
                    if(MApp_IsSrcHasSignal(MAIN_WINDOW))
                    {
                        return EN_DL_STATE_NORMAL;
                    }
                    else
                    {
                        return EN_DL_STATE_DISABLED;
                    }
                }
            }
           #else
                return EN_DL_STATE_HIDDEN;
           #endif

        case HWND_MENU_OPTION_3D_DETECT:
           #if  ENABLE_3D_PROCESS
           if(IsHDMIInUse() && g_HdmiPollingStatus.bIsHDMIMode)
           {
               return EN_DL_STATE_NORMAL;
           }
           else
           {
                #if ENABLE_CUS_UI_SPEC
                return EN_DL_STATE_HIDDEN;
                #else
                return EN_DL_STATE_DISABLED;
                #endif
           }
           #else
                return EN_DL_STATE_HIDDEN;
          #endif
        case HWND_MENU_OPTION_3D_LR:
           #if  ENABLE_3D_PROCESS
            if(IsStorageInUse())
            {
                if(MApp_MPlayer_IsMoviePlaying()||MApp_MPlayer_IsPhotoPlaying())
                {
                     if(ST_3D_TYPE != EN_3D_BYPASS)
                     {
                         return EN_DL_STATE_NORMAL;
                     }
                     else
                     {
                         return EN_DL_STATE_DISABLED;
                     }
                }
                else
                {
                    return EN_DL_STATE_DISABLED;
                }
            }
            else
            {
                EN_3D_TYPE en3DType;
                #if ENABLE_CUS_3D_SOURCE_MEMORY
                if(IsHDMIInUse() && (g_HdmiPollingStatus.bIsHDMIMode == FALSE)) //dvi
                {
                    en3DType = ST_VGA_3D_TYPE;
                }
                else
                #endif
                {
                    en3DType = ST_3D_TYPE;
                }

                if(MApp_IsSrcHasSignal(MAIN_WINDOW))
                {
                    if(en3DType != EN_3D_BYPASS)
                    {
                        return EN_DL_STATE_NORMAL;
                    }
                    else
                    {
                        return EN_DL_STATE_DISABLED;
                    }
                }
                else
                {
                    return EN_DL_STATE_DISABLED;
                }
            }
           #else
                return EN_DL_STATE_HIDDEN;
           #endif

           case HWND_MENU_OPTION_3D_SCENE:
           #if ENABLE_3D_PROCESS
            #if ENABLE_CUS_3D_SETTING
            {
                EN_3D_TYPE en3DType;
                #if ENABLE_CUS_3D_SOURCE_MEMORY
                if(IsHDMIInUse() && (g_HdmiPollingStatus.bIsHDMIMode == FALSE)) //dvi
                {
                    en3DType = ST_VGA_3D_TYPE;
                }
                else
                #endif
                {
                    en3DType = ST_3D_TYPE;
                }

                if(en3DType == EN_3D_NORMAL_2D)
                {
                    return EN_DL_STATE_NORMAL;
                }
                else
                {
                    return EN_DL_STATE_DISABLED;
                }
                break;
            }
            #endif
           #endif
               return EN_DL_STATE_HIDDEN;


        //from menu_time===================================
        case HWND_MENU_TIME_SET_TIMEZONE:
           {
          #if ENABLE_CUS_UI_SPEC
            return EN_DL_STATE_HIDDEN;
          #endif

          #if ENABLE_DTV
            return EN_DL_STATE_NORMAL;
          #else
            return EN_DL_STATE_HIDDEN;
          #endif
        }
#if (ENABLE_CUS_UI_SPEC == DISABLE) /*Creass.liu at 2012-06-02*/
        case HWND_MENU_APP1:
        case HWND_MENU_APP2:
        case HWND_MENU_APP3:
        case HWND_MENU_APP4:
        case HWND_MENU_APP5:
        case HWND_MENU_APP6:
        case HWND_MENU_APP7:
        case HWND_MENU_APP8:
        case HWND_MENU_APP9:
        case HWND_MENU_APP10:
        case HWND_MENU_APP11:
        case HWND_MENU_APP12:
        case HWND_MENU_APP13:
        case HWND_MENU_APP14:
        case HWND_MENU_APP15:
        case HWND_MENU_APP16:
        case HWND_MENU_APP17:
        {
        #ifdef MSOS_TYPE_LINUX
            int nIndex = 0;
            nIndex = MApp_ZUI_API_GetChildIndex(hwnd);
            if((nIndex > MAdp_APMNG_GetAppNum())||(u8PreVisibleAPPIndex >= MAdp_APMNG_GetAppNum()))
            {
                return EN_DL_STATE_HIDDEN;
            }
            else if(nIndex == 0)
            {
                 //start from HWND_MENU_APP1
                 u8PreVisibleAPPIndex = 0;
            }
            else
            {
                u8PreVisibleAPPIndex += 1;
            }


            if ( u8PreVisibleAPPIndex < MAdp_APMNG_GetAppNum() )
            {
                APP_INFO stAppInfo;
                MAdp_APMNG_GetApInfoByIndex(u8PreVisibleAPPIndex, &stAppInfo);

            #if 0 //must
                char DLNA[10]={'D','L','N','A'};
                if(strcmp(stAppInfo.name,DLNA)==0)
                {
                    printf(">>>>>>>>DLNA disable\n");
                    u8PreVisibleAPPIndex += 1;
                    if(!MAdp_APMNG_GetApInfoByIndex(u8PreVisibleAPPIndex, &stAppInfo))
                    {
                         u8PreVisibleAPPIndex -= 1;
                         return EN_DL_STATE_HIDDEN;
                    }
                }

              #if(ENABLE_NETFLIX==1)
                printf(">>>>>>>>NETFLIX Enable\n");
              #else
                char NETFLIX[10]={'N','E','T','F','L','I','X'};
                if(strcmp(stAppInfo.name,NETFLIX)==0)
                {
                    printf(">>>>>>>>NETFLIX disable\n");
                    u8PreVisibleAPPIndex += 1;
                    if(!MAdp_APMNG_GetApInfoByIndex(u8PreVisibleAPPIndex, &stAppInfo))
                    {
                         u8PreVisibleAPPIndex -= 1;
                         return EN_DL_STATE_HIDDEN;
                    }
                }
              #endif // #if(ENABLE_NETFLIX==1)
            #endif

                while(stAppInfo.bHidden == 1)
                {
                     u8PreVisibleAPPIndex += 1;
                     if(!MAdp_APMNG_GetApInfoByIndex(u8PreVisibleAPPIndex, &stAppInfo))
                     {
                          u8PreVisibleAPPIndex -= 1;
                          return EN_DL_STATE_HIDDEN;
                     }
                }
                au8VisibleAPPList[nIndex] = u8PreVisibleAPPIndex;
                return EN_DL_STATE_NORMAL;
            }
            else
            {
                u8PreVisibleAPPIndex -= 1;
                return EN_DL_STATE_HIDDEN;
            }
        #else
           S16 s16Index = MApp_ZUI_API_GetChildIndex(hwnd);
           if(MApp_ZUI_ACT_GetAppItemString(s16Index) == Empty)
            {
                    return EN_DL_STATE_HIDDEN;
             }
            else
            {
                    return EN_DL_STATE_NORMAL;
            }
        #endif // #ifdef MSOS_TYPE_LINUX

            return EN_DL_STATE_HIDDEN;
        }
        break;
#endif

    #if (ENABLE_ATV_VCHIP)
    U16 u16CurrentIndex;
    U8 i;

    case HWND_MENU_LOCK_MAINSUBPAGE_ITEM_CHANGEPW:
    case HWND_MENU_LOCK_MAINSUBPAGE_ITEM_SYSTEMLOCK:
    #if ENABLE_INPUT_LOCK
    case HWND_MENU_LOCK_MAINSUBPAGE_ITEM_INPUTBLOCK:
    #endif
    case HWND_MENU_LOCK_MAINSUBPAGE_ITEM_US:
    case HWND_MENU_LOCK_MAINSUBPAGE_ITEM_CANADA:
    {
        for (i = 0; i < COUNTOF(_lock_items); i++)
        {
            if (hwnd == _lock_items[i])
            {

                if(hwnd == HWND_MENU_LOCK_MAINSUBPAGE_ITEM_US ||
                   hwnd == HWND_MENU_LOCK_MAINSUBPAGE_ITEM_CANADA)
                {
                    if (IsVBISrcInUse() && stGenSetting.g_VChipSetting.u8VChipLockMode!= 0)
                    {
                        return EN_DL_STATE_NORMAL;
                    }
                    else
                    {
                        return EN_DL_STATE_DISABLED;
                    }
    }

                if(hwnd == HWND_MENU_LOCK_MAINSUBPAGE_ITEM_INPUTBLOCK)
                {
                    if (stGenSetting.g_VChipSetting.u8VChipLockMode!= 0)
                    {
                        return EN_DL_STATE_NORMAL;
                    }
                    else
                    {
                        return EN_DL_STATE_DISABLED;
                    }
                }
                return EN_DL_STATE_NORMAL;
            }
        }
        return EN_DL_STATE_HIDDEN;
    }

   case     HWND_MENU_LOCK_INPUTBLOCKSUBPAGE_ITEM_TV:
   #if (INPUT_AV_VIDEO_COUNT >= 1)
   case  HWND_MENU_LOCK_INPUTBLOCKSUBPAGE_ITEM_AV:
   #endif
   #if (INPUT_SV_VIDEO_COUNT >= 2)
   case  HWND_MENU_LOCK_INPUTBLOCKSUBPAGE_ITEM_SVIDEO:
   #endif
   #if (INPUT_YPBPR_VIDEO_COUNT>=1)
   case  HWND_MENU_LOCK_INPUTBLOCKSUBPAGE_ITEM_COMPONENT:
   #endif
   #if (ENABLE_HDMI)
   case  HWND_MENU_LOCK_INPUTBLOCKSUBPAGE_ITEM_HDMI:
   #endif
    case  HWND_MENU_LOCK_INPUTBLOCKSUBPAGE_ITEM_PC:
    {
        for (i = 0; i < COUNTOF(_lock_source_items); i++)
        {
            if (hwnd == _lock_source_items[i])
            {
                return EN_DL_STATE_NORMAL;
            }
        }
        return EN_DL_STATE_HIDDEN;
    }

    case  HWND_MENU_LOCK_VCHIPSUBPAGE_ITEM1:
    case  HWND_MENU_LOCK_VCHIPSUBPAGE_ITEM2:
    case  HWND_MENU_LOCK_VCHIPSUBPAGE_ITEM3:
    case  HWND_MENU_LOCK_VCHIPSUBPAGE_ITEM4:
    case  HWND_MENU_LOCK_VCHIPSUBPAGE_ITEM5:
    case  HWND_MENU_LOCK_VCHIPSUBPAGE_ITEM6:
    case  HWND_MENU_LOCK_VCHIPSUBPAGE_ITEM7:
    {
        u16CurrentIndex = _MApp_ZUI_ACT_VchipWindowMapToIndex(hwnd);

        if(g_vchipPageType == EN_VCHIP_MPAA)
        {
            if(u16CurrentIndex >= VCHIP_MPAA_ITEMNUM)
            {
                return EN_DL_STATE_HIDDEN;
            }
        }
        else if(g_vchipPageType == EN_VCHIP_CANADAENG)
        {
            if(u16CurrentIndex >= VCHIP_CANADAENG_ITEMNUM)
            {
                return EN_DL_STATE_HIDDEN;
            }
        }
        else if(g_vchipPageType == EN_VCHIP_CANADAFRE)
        {
            if (u16CurrentIndex >= VCHIP_CANADAFRE_ITEMNUM)
            {
                return EN_DL_STATE_HIDDEN;
            }
        }
        return EN_DL_STATE_NORMAL;
    }

    case  HWND_MENU_LOCK_MAINSUBPAGE_ITEM_RRTSETTING:
    case  HWND_MENU_LOCK_MAINSUBPAGE_ITEM_RESETRRT:
    {
        return EN_DL_STATE_HIDDEN;
    }

    #endif
    case HWND_MENU_ADVANCE_PICTURE_FLESH_TONE:
        return EN_DL_STATE_HIDDEN;
        break;
    }
    return EN_DL_STATE_NORMAL;
}

#if (OBA2 && EN_BABAO_COMMUNICATE)
#define MAX_DATA_CONTENT 512
#define BABAO_CH_NAME "BABAO"

typedef struct
{
    U8 tag[4];
    U8 ver[2];
    U8 type[2];
    U8 datalen[4];
    U8 datacontent[MAX_DATA_CONTENT];
}ST_APPS_DBUS_PACKET;

typedef enum
{
    BABAO_REQUEST_STATUS,
    BABAO_REQUEST_MAX
}EN_BABAO_REQUEST_TYPE;

U8 g_u8babao_request_type=BABAO_REQUEST_MAX;

bool MApp_Babao_Ch_ReceiveMsg(unsigned char * pu8InData, unsigned short u16InDataSize, unsigned char * pu8OutData, unsigned short u16OutDataSize)
{
    U8 MSGBUF[MAX_DATA_CONTENT];
    U8 FILBUF[MAX_DATA_CONTENT];
    U16 type;
    U16 msg_len;
    U16 file_len;
    U16 comm_len;
    U8 *tmp;
    U8 *p;
    U8 var_nums;
    U32 date_len;
    //no detail define yet, add here to prevent warning
    u16InDataSize=u16InDataSize;
    pu8OutData=pu8OutData;
    u16OutDataSize=u16OutDataSize;

    if(pu8InData[0] == 'B' && pu8InData[1] == 'B' && pu8InData[2] == ' ' && pu8InData[3] == ' ')
    {
        type = (((U16)pu8InData[6])<<8) + (U16)(pu8InData[7]);
        date_len = (((U32)pu8InData[8])<<24) + (((U32)pu8InData[9])<<16) + (((U32)pu8InData[10])<<8) + (U32)(pu8InData[11]);

        tmp = pu8InData+12; //pack content addr
        msg_len = (((U16)(tmp[0]))<<8) + (U16)tmp[1]; //msg length
        file_len = (((U16)(tmp[msg_len+2]))<<8) + (U16)tmp[msg_len+3]; //file name length
        comm_len = (((U16)(tmp[4+msg_len+file_len]))<<8)+tmp[5+msg_len+file_len]; //command length
/*
        printf("[%s] type is %x!\n",__FUNCTION__,type);
        printf("[%s] datelen is %d\n",__FUNCTION__,date_len);
        printf("[%s] msg_len is %d!\n",__FUNCTION__,msg_len);
        printf("[%s] file_len is %d!\n",__FUNCTION__,file_len);
        printf("[%s] comm_len is %d!\n",__FUNCTION__,comm_len);
*/
        switch(type)
        {
            case 0x01:  //message
                p = tmp + 2;
                memcpy(MSGBUF,p,msg_len);
                MSGBUF[msg_len] = '\0';

               // printf("[%s] MSG is %s\n",__FUNCTION__,MSGBUF);
                break;

            case 0x02:  //message + file name
                p = tmp + 2;
                memcpy(MSGBUF,p,msg_len);
                MSGBUF[msg_len] = '\0';
              //  printf("[%s] MSG is %s\n",__FUNCTION__,MSGBUF);

                p = tmp + 4 + msg_len;
                memcpy(FILBUF,p,file_len);
                FILBUF[file_len] = '\0';
              //  printf("[%s] FIL is %s\n",__FUNCTION__,FILBUF);

                break;
            case 0x81:  //command
                p = tmp + 6 + msg_len + file_len;
                var_nums = *(p+1);
                switch(*p)  //command id
                {
                    case 0x81:  //ask baoba init status, on/off
                        g_u8babao_request_type = BABAO_REQUEST_STATUS;
                        break;
                    case 0x01:
                        break;
                    case 0x02:
                        break;
                    case 0x03:
                        break;
                    default:
                        g_u8babao_request_type=BABAO_REQUEST_MAX;
                        break;
                }
                break;
        }
    }
    return TRUE;
}

void MApp_InitBabaoCommunicateChannel(void)
{
    MAdp_MSGCH_Init();
    MAdp_MSGCH_SetCallBack(MAdp_MSGCH_GetChannelIndex(BABAO_CH_NAME), MApp_Babao_Ch_ReceiveMsg);
}

BOOLEAN MApp_Babao_CH_SendPacket(ST_APPS_DBUS_PACKET *pk)
{
    U8 u8ChIndex = MAdp_MSGCH_GetChannelIndex(BABAO_CH_NAME);
    U32 date_len;
    //pid_t cur_activated_ap=MAdp_APMNG_GetActivatedAppPid();

    //printf("[%s] cur_activated_ap is %d\n",__FUNCTION__,cur_activated_ap);

    pid_t cur_activated_ap=0xFFFFFFFF;
    date_len = (((U32)pk->datalen[0])<<24) + (((U32)pk->datalen[1])<<16) + (((U32)pk->datalen[2])<<8) + (U32)(pk->datalen[3]);

    if(cur_activated_ap != 0)  // application is running
    {
        if (MAdp_MSGCH_SendSignal(cur_activated_ap,u8ChIndex, (unsigned char *)pk, 12+date_len/*sizeof(ST_APPS_DBUS_PACKET)*/))
        {
            printf("[D-Bus] Send signal to Babao channel OK\n");
            return TRUE;
        }
        else
        {
            printf("[D-Bus] Send signal to Babao channel fail\n");
            return FALSE;
        }
    }
    else
    {
        printf("No AP is running\n");
        return FALSE;
    }
}

BOOLEAN MApp_ZUI_ACT_TurnOnOff_Babao(BOOLEAN on)
{
    ST_APPS_DBUS_PACKET pk;

    pk.tag[0]='C';
    pk.tag[1]='H';
    pk.tag[2]='A';
    pk.tag[3]='K';
    pk.ver[0]=0;
    pk.ver[1]=1;
    pk.type[0]=0;
    pk.type[1]=0x81;
    pk.datalen[0]=0;
    pk.datalen[1]=0;
    pk.datalen[2]=0;
    pk.datalen[3]=8;
    pk.datacontent[0]=0;
    pk.datacontent[1]=0; //message length is 0
    pk.datacontent[2]=0;
    pk.datacontent[3]=0; //file name length is 0
    pk.datacontent[4]=0;
    pk.datacontent[5]=2; //command length is 2
    if(on)
        pk.datacontent[6]=0x01;//turn on babao
    else
        pk.datacontent[6]=0x02;//turn off babao

    pk.datacontent[7]=0; //var num is 0

    return MApp_Babao_CH_SendPacket(&pk);
}

BOOLEAN MApp_ZUI_ACT_SetNetBandWidth_Babao(U8 bw)
{
    ST_APPS_DBUS_PACKET pk;

    pk.tag[0]='C';
    pk.tag[1]='H';
    pk.tag[2]='A';
    pk.tag[3]='K';
    pk.ver[0]=0;
    pk.ver[1]=1;
    pk.type[0]=0;
    pk.type[1]=0x81;
    pk.datalen[0]=0;
    pk.datalen[1]=0;
    pk.datalen[2]=0;
    pk.datalen[3]=9;
    pk.datacontent[0]=0;
    pk.datacontent[1]=0; //message length is 0
    pk.datacontent[2]=0;
    pk.datacontent[3]=0; //file name length is 0
    pk.datacontent[4]=0;
    pk.datacontent[5]=3; //command length is 1
    pk.datacontent[6]=0x03;  //set net bandwidth command
    pk.datacontent[7]=1; //var num
    pk.datacontent[8]=bw;

    return MApp_Babao_CH_SendPacket(&pk);
}


void MApp_Polling_Babao_Request(void)
{
    switch(g_u8babao_request_type)
    {
        case BABAO_REQUEST_STATUS:
            printf("[%s]\n SEND!!!\n",__FUNCTION__);
            MApp_ZUI_ACT_TurnOnOff_Babao(TRUE);
            g_u8babao_request_type = BABAO_REQUEST_MAX;
            break;
        default:
            break;
    }
}
#endif

#if (OBA2)
BOOLEAN MApp_ZUI_ACT_SetEnvLanguage(EN_LANGUAGE elanguage)
{
#ifdef MSOS_TYPE_LINUX
    //printf("set env language\n");
    switch((U8)elanguage)
    {
        case LANGUAGE_ENGLISH:
            if(system("echo enUS>/conf/system_lcid.conf")==0)
                return TRUE;
            break;

    #if (ENABLE_DTMB_CHINA_APP || ENABLE_ATV_CHINA_APP || ENABLE_DVBC_PLUS_DTMB_CHINA_APP||CHINESE_SIMP_FONT_ENABLE ||CHINESE_BIG5_FONT_ENABLE)
        case LANGUAGE_CHINESE:
            if(system("echo zhCN>/conf/system_lcid.conf")==0)
                return TRUE;
           break;
    #endif

        default:
            if(system("echo enUS>/conf/system_lcid.conf")==0)
                return TRUE;
            break;
    }
    return FALSE;
#else
    return TRUE;
#endif
}


/***************************************************************************************************/
// [ in ] address : ram address
// [ In ] filesize : the size of image in ram
// return 0 is success,  -1 is fail
/***************************************************************************************************/
int mAPP_loadDatefromDram_To_fileFormat(int * address,int filesize)
{
    int retvalue=0,fd,size;

    fd=open("/application/chakra.ubifs",O_WRONLY|O_CREAT,0644);

    printf("fd is : %d\n",fd);

    if(fd)
    {
        size = write(fd,address,filesize);
        printf("size is : %d\n",size);
        if(size == filesize)
            {
              printf("This is success!\n");
            }
        else if (size == -1)
            {
              printf("write date error!\n");
            }
        close(fd);
    }
    else
    {
        printf("create .ubifs file fail!\n");
        retvalue = -1;
    }
    //save image to backup partition
    system("mkdir  /backup");
    system("chmod  777  /backup");
    system("cd /dev");
    system("mount -t ubifs ubi0_8   /backup");
    system("cp /application/chakra.ubifs   /backup");
    system("umount -t ubifs");
    system("cd /");
    system("rmdir backup");
    return retvalue;
}

#endif

#if(0)

#define MSG_MAC(x)         //x
#ifndef U64
typedef unsigned long long U64;
#endif
#define MAC_ARRR_MS_INDEX  0
#define MAC_ADDR_LEN       18
#define MAC_ARRR_NAME      "/mac_addr.txt"
#define MAC_SYS_ADDR       "/etc/mac_addr.txt"

extern const char *FS_GetMountPoint(U8 drvID);
//MAC_EX:"21-1F-3C-1F-B1-A8"

U8 ASII_TO_HEX(char x)
{
    if(x>='0'&&x<='9')
    {
        return (x-'0');
    }
    else if(x>='A'&&x<='F')
    {
        return (x-'A')+10;
    }
    else if(x>='a'&&x<='f')
    {
        return (x-'a')+10;
    }
    else
    {
        return 0;
    }
}

char HEX_TO_ASII(U8 x)
{
    if(x<=9)
    {
        return (x+'0');
    }
    else if(x>=10&&x<=15)
    {
        return (x-10+'A');
    }
    else
    {
        return '0';
    }
}

U64 MAC_ADDR_TEXT_TO_HEX(char *pTEXT)
{
    char Mac_Text[MAC_ADDR_LEN];
    U64 Hex=0;
    U8 i=0;
    memcpy(Mac_Text,pTEXT,sizeof(Mac_Text));
    for(i=0;i<(MAC_ADDR_LEN-1);i+=3)
    {
        Hex=(Hex<<8)+(ASII_TO_HEX(Mac_Text[i])<<4)+ASII_TO_HEX(Mac_Text[i+1]);
    }
    return Hex;
}

void MAC_ADDR_HEX_TO_TEXT(U64 MAC_HEX,char *pText)
{
    U64 Hex=MAC_HEX;
    U8 i=0,j=0;
    for(i=0;i<(MAC_ADDR_LEN-1);i+=3)
    {
        j= (Hex>>((5-i/3)*8))&0xFF;
        pText[i]=HEX_TO_ASII(j>>4);
        pText[i+1]=HEX_TO_ASII(j&0x0f);
        pText[i+2]='-';
    }
    pText[MAC_ADDR_LEN-1]='\0';
}


BOOL MApp_ZUI_ACT_ConfigMAC_Address(void)
{
    char MacAddrFileName[256],*p_mp;
    char mac_addr_Data[MAC_ADDR_LEN];
    BOOL rel=FALSE;
    U64 MAC_HEX=0;
    int fd=-1;

    p_mp=MacAddrFileName;
    MSG_MAC(printf("\nMApp_ZUI_ACT_ConfigMAC_Address\n"));

    memset(MacAddrFileName,0x00,sizeof(MacAddrFileName));
    memset(mac_addr_Data,0x00,sizeof(mac_addr_Data));

    memcpy(MacAddrFileName,FS_GetMountPoint(MAC_ARRR_MS_INDEX),sizeof(MacAddrFileName));
    p_mp+=strlen(MacAddrFileName);
    memcpy(p_mp,MAC_ARRR_NAME,strlen(MAC_ARRR_NAME));
    MSG_MAC(printf("\nMP_Name:%s",MacAddrFileName));
    rel=ReadFromFile(MacAddrFileName, 0x00, mac_addr_Data, sizeof(mac_addr_Data));
    MSG_MAC(printf("\nMAC:%s\n",mac_addr_Data));
    MAC_HEX=MAC_ADDR_TEXT_TO_HEX(mac_addr_Data);
    MSG_MAC(printf("\nMAC_HEX:%X\n",MAC_HEX));

    if(1)
    {
        if( (fd=open(MAC_SYS_ADDR,O_WRONLY|O_CREAT|O_TRUNC|O_SYNC)) < 0 )
        {
            perror("INIT MAC_SYS_ADDR FAIL:\n");
            return FALSE;
        }
        if(fd>=0)
        {
            close(fd);
            MSG_MAC(printf("INIT MAC_SYS_ADDR DONE\n"));
        }
        WriteToFile(MAC_SYS_ADDR,0x00,mac_addr_Data, sizeof(mac_addr_Data));
    }
    MAC_HEX += 1;//Mac addr auto inc 1for factory mp
    MAC_ADDR_HEX_TO_TEXT(MAC_HEX,mac_addr_Data);
    MSG_MAC(printf("\nMAC2:%s\n",mac_addr_Data));
    WriteToFile(MacAddrFileName,0x00,mac_addr_Data, sizeof(mac_addr_Data));

    return rel;
}
#endif
void MApp_ST_VIDEO_SetDMPUserDate(void)
{
 #if 0
    E_DATA_INPUT_SOURCE g_enTempSourceType;

        U8 u8TempBacklight;             //backlilght
        U8 u8TempContrast;              // contrast
        U8 u8TempBrightness;            // brightness
        U8 u8TempSaturation;            // Saturation
        U8 u8TempSharpness;             // Sharpness
        U8 u8TempHue;
        EN_MS_COLOR_TEMP eTempColorTemp; // color temperature
    #if ENABLE_FLESH_TONE
        EN_MS_FLESH_TONE_MODE eTempFleshToneMode;
    #endif
    #if ENABLE_CUS_DBC
        EN_DBC_STATUS bTempDBCStatus;
    #endif
    #if ENABLE_CUS_DLC
        EN_DLC_STATUS bTempDLCStatus;
    #endif
    #if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
        EN_MS_NR eTempNR;
    #endif

    g_enTempSourceType=DATA_INPUT_SOURCE_TYPE(MAIN_WINDOW);

    if(g_enTempSourceType != DATA_INPUT_SOURCE_ATV)
      return;

     u8TempBacklight = ST_PICTURE.u8Backlight;
     u8TempContrast = ST_PICTURE.u8Contrast;
     u8TempBrightness = ST_PICTURE.u8Brightness;
     u8TempSaturation = ST_PICTURE.u8Saturation;
     u8TempSharpness = ST_PICTURE.u8Sharpness;
     u8TempHue = ST_PICTURE.u8Hue;
     eTempColorTemp = ST_PICTURE.eColorTemp;
    #if (ENABLE_CUS_NR_MODE_FOLLOW_PICMODE == ENABLE)
     eTempNR = ST_PICTURE.eNRMode.eNR;
    #endif
    #if ENABLE_FLESH_TONE
     eTempFleshToneMode = ST_PICTURE.eFleshToneMode;
    #endif
    #if ENABLE_CUS_DBC
     bTempDBCStatus =ST_PICTURE.bDBCStatus;
    #endif
    #if ENABLE_CUS_DLC
     bTempDLCStatus =ST_PICTURE.bDLCStatus;
    #endif

    DATA_INPUT_SOURCE_TYPE(MAIN_WINDOW)=DATA_INPUT_SOURCE_STORAGE;

    ST_VIDEO.astPicture[PICTURE_USER].u8Backlight = u8TempBacklight;
    ST_VIDEO.astPicture[PICTURE_USER].u8Contrast = u8TempContrast;
    ST_VIDEO.astPicture[PICTURE_USER].u8Brightness = u8TempBrightness;
    ST_VIDEO.astPicture[PICTURE_USER].u8Saturation = u8TempSaturation;
    ST_VIDEO.astPicture[PICTURE_USER].u8Sharpness = u8TempSharpness;
    ST_VIDEO.astPicture[PICTURE_USER].u8Hue = u8TempHue;
    ST_VIDEO.astPicture[PICTURE_USER].eColorTemp = eTempColorTemp;
   #if (ENABLE_CUS_NR_MODE_FOLLOW_PICMODE == ENABLE)
    ST_VIDEO.astPicture[PICTURE_USER].eNRMode.eNR = eTempNR;
   #endif
   #if ENABLE_FLESH_TONE
    ST_VIDEO.astPicture[PICTURE_USER].eFleshToneMode = eTempFleshToneMode;
   #endif
   #if ENABLE_CUS_DBC
    ST_VIDEO.astPicture[PICTURE_USER].bDBCStatus =bTempDBCStatus;
   #endif
   #if ENABLE_CUS_DLC
    ST_VIDEO.astPicture[PICTURE_USER].bDLCStatus =bTempDLCStatus;
   #endif
   MApp_SaveVideoSetting(DATA_INPUT_SOURCE_STORAGE);

   DATA_INPUT_SOURCE_TYPE(MAIN_WINDOW)=g_enTempSourceType;
#endif
}

#undef MAPP_ZUI_ACTMENUFUNC_C

