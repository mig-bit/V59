////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#define MAPP_UI_MENUFUNC_C

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Board.h"
#include "datatype.h"
#include "MsCommon.h"
#include "Panel.h"
#include "apiXC.h"
#include "apiXC_Adc.h"
#include "apiXC_PCMonitor.h"
#include "apiXC_Sys.h"
#include "apiXC_Ace.h"
#include "apiXC_ModeParse.h"
#include "apiXC_Cus.h"
#include "apiPNL.h"
#include "msAPI_Mode.h"
#include "msAPI_audio.h"
#include "msAPI_Timer.h"
#include "apiXC_Auto.h"
#include "apiXC_Adc.h"
#include "apiDMX.h"
#include "drvXC_HDMI_if.h"
#include "apiXC_Hdmi.h"
#include "msAPI_MIU.h"
#include "msAPI_DrvInit.h"
#include "apiXC_Dlc.h"
#include "msAPI_vbi.h"
#include "msAPI_cc_disp.h"
#include "apiXC_Ace.h"
#include "msAPI_Power.h"
#include "msAPI_cc_parser.h"
#include "apiGOP.h"
#include "msAPI_Global.h"

#include "MApp_GlobalVar.h"
#include "MApp_VChip.h"
#include "MApp_UiMenuFunc.h"
#include "MApp_ZUI_APIgdi.h"
#include "MApp_ZUI_APItables.h"
#include "MApp_Sleep.h"
#include "MApp_GlobalFunction.h"
#include "MApp_ChannelChange.h"
#include "MApp_RestoreToDefault.h"
#include "MApp_InputSource.h"
#include "mapp_closedcaption.h"
#include "MApp_Audio.h"
#include "MApp_PCMode.h"
#include "MApp_SaveData.h"
#include "msAPI_Ram.h"
#include "MApp_USBDownload.h"
#include "MApp_GlobalSettingSt.h"
#include "MApp_Scaler.h"
#include "MApp_ZUI_APIstrings.h"
#include "ZUI_strings_enum.h"

#include "MApp_XC_PQ.h"
#if ENABLE_DMP
#include "MApp_DMP_Main.h"
#endif

#include "MApp_GlobalVar.h"

#include "ZUI_tables_h.inl"
#include "ZUI_exefunc.h"
#if ( ENABLE_ATV_VCHIP)
#define OSDDBG(x) //x

//extern EN_SCAN_CHANNEL_TYPE enScanChannelType;
//extern EN_TUNE2RF_SUB_STATE enAtscTune2RfSubState;
//extern U32 g_u32StreamTime;
//extern U8 u8RFCh, u8MaxRFCh;
//extern U16 u16NumOfSrvAdd;
//extern U16 u16NumOfNTSCSrvAdd;
//extern BOOLEAN g_bScanLockPassed;
//extern BOOLEAN g_bInputBlocked;
//extern MS_U8 bPreviousSoundMode, bCurrentSoundMode;

//extern BOOLEAN g_bRatingValuePageNext;
BOOLEAN g_bInputBlocked = FALSE;

//===========================================================================//



//============================================================================
//============================================================================
//============================================================================

//============================================================================

//============================================================================

// ================================== Lock Menu ================================
//============================================================================

BOOLEAN MApp_UiMenuFunc_AdjSystemLockMode(void)
{
    BOOLEAN bPreInputBlock = MApp_UiMenuFunc_CheckInputLock ();
    stGenSetting.g_VChipSetting.u8VChipLockMode ^=1;
    MApp_VChip_Init();
    fVChipPassWordEntered = FALSE;

#if ENABLE_INPUT_LOCK
    g_bInputBlocked = MApp_UiMenuFunc_CheckInputLock ();

    #ifdef LOCK_USE_BLACK_VIDEO
    if (g_bInputBlocked)
    {
        MApp_MuteAvByLock(E_SCREEN_MUTE_INPUT, TRUE);
    }
    else if (bPreInputBlock)
    {
        MApp_MuteAvByLock(E_SCREEN_MUTE_INPUT, FALSE);
    }
    #else
    if (g_bInputBlocked)
    {
        MApp_MuteAvByLock(TRUE);
    }
    else if (bPreInputBlock)
    {
        MApp_MuteAvByLock(FALSE);
    }
    #endif
#endif

    return TRUE;
}

#if 0
// Get RRT description from SDRAM to xdata
BOOLEAN MApp_UiMenuFunc_GetRRT_OptionDescription(U8 u8DimensionIdx, U8 u8OptionIdx)
{
    if( (u8DimensionIdx>=REGION5_DIMENSION_NUM)||(u8OptionIdx>=REGION5_MAX_RATING_OPTION) ) // error checking
        return FALSE;

    msAPI_MIU_Copy((U32)GET_RRT_DESCRIPTOR_ADDRESS(u8DimensionIdx, u8OptionIdx),  (U32)&g_u8CurrentRRT_Descriptor[0], REGION5_RATING_DES_MAX_LENGTH, MIU_SDRAM2SDRAM);
    return TRUE;
}

BOOLEAN MApp_UiMenuFunc_ToggleRRT_DimensionValues(U8 u8ValueIndex)
{
    if( (u8ValueIndex<1)||(u8ValueIndex>REGION5_MAX_RATING_OPTION)||
        (g_u8CurrentRRT_Dimension>=REGION5_DIMENSION_NUM) ) // error checking
        return FALSE;

    stGenSetting.g_VchipRegion5.stRegin5Dimension[g_u8CurrentRRT_Dimension].u16CurrentOption ^= (1<<(u8ValueIndex-1));

    if (stGenSetting.g_VchipRegion5.stRegin5Dimension[g_u8CurrentRRT_Dimension].u16Graduated_Scale)
    {
        if (stGenSetting.g_VchipRegion5.stRegin5Dimension[g_u8CurrentRRT_Dimension].u16CurrentOption & (0x01<<(u8ValueIndex-1)))
        {
            stGenSetting.g_VchipRegion5.stRegin5Dimension[g_u8CurrentRRT_Dimension].u16CurrentOption |= (0xFFFF<<(u8ValueIndex-1));
        }
        else
        {
            stGenSetting.g_VchipRegion5.stRegin5Dimension[g_u8CurrentRRT_Dimension].u16CurrentOption =
            (stGenSetting.g_VchipRegion5.stRegin5Dimension[g_u8CurrentRRT_Dimension].u16CurrentOption>>u8ValueIndex)<<u8ValueIndex;
        }
    }

    if ( (g_stVChipRatingInfo.u8DimVal0 && g_u8CurrentRRT_Dimension == 0) ||
         (g_stVChipRatingInfo.u8DimVal1 && g_u8CurrentRRT_Dimension == 1) ||
         (g_stVChipRatingInfo.u8DimVal2 && g_u8CurrentRRT_Dimension == 2) ||
         (g_stVChipRatingInfo.u8DimVal3 && g_u8CurrentRRT_Dimension == 3) ||
         (g_stVChipRatingInfo.u8DimVal4 && g_u8CurrentRRT_Dimension == 4) ||
         (g_stVChipRatingInfo.u8DimVal5 && g_u8CurrentRRT_Dimension == 5) ||
         (g_stVChipRatingInfo.u8DimVal6 && g_u8CurrentRRT_Dimension == 6) ||
         (g_stVChipRatingInfo.u8DimVal7 && g_u8CurrentRRT_Dimension == 7) ||
         (g_stVChipRatingInfo.u8DimVal8 && g_u8CurrentRRT_Dimension == 8) ||
         (g_stVChipRatingInfo.u8DimVal9 && g_u8CurrentRRT_Dimension == 9) )
    {
        fVChipPassWordEntered = FALSE;
        memset(&g_stVChipRatingInfo, 0, sizeof(g_stVChipRatingInfo));
    }

    return TRUE;
}

BOOLEAN MApp_UiMenuFunc_ResetRatingTable()
{
    //Always unblock CH after reseting RRT.
    for (iu8Loop_i=0 ; iu8Loop_i<REGION5_DIMENSION_NUM ; iu8Loop_i++) // always unblock CH after reseting RRT.
        stGenSetting.g_VchipRegion5.stRegin5Dimension[iu8Loop_i].u16CurrentOption = 0;

    MApp_UiMenuFunc_SaveCurrentRegion5Ratings();
    stGenSetting.g_VchipRegion5.u8VersionNo = INVALID_VERSION_NUM;
    stGenSetting.g_VchipRegion5.u8NoDimension = 0;
    MApp_VChip_Init();
    return TRUE;
}

void MApp_UiMenuFunc_SaveCurrentRegion5Ratings(void)
{
    BOOLEAN bSavedRRT = FALSE;
    U8 u8Loop1=0, u8Loop2=0;
    MS_EZ_REGION5_RATING stEZ_VchipRegion5;

    // Find if this RRT has been saved before........
    for (u8Loop1=0; u8Loop1<stGenSetting.u8NoSavedRRT; u8Loop1++)
    {
        msAPI_MIU_Copy((U32)GET_SAVED_RRT_SETTING_ADDRESS(u8Loop1),  (U32)&stEZ_VchipRegion5, sizeof(MS_EZ_REGION5_RATING), MIU_SDRAM2SDRAM);
        if(strcmp((const char*)stGenSetting.g_VchipRegion5.u8Region5Name, (const char*)stEZ_VchipRegion5.u8Region5Name)==0)
        {
            if((stGenSetting.g_VchipRegion5.u8NoDimension == stEZ_VchipRegion5.u8NoDimension))
            {// this RRT is already in the memory....
                if( (stGenSetting.g_VchipRegion5.u8VersionNo == INVALID_VERSION_NUM) ||
                     (stGenSetting.g_VchipRegion5.u8VersionNo == stEZ_VchipRegion5.u8VersionNo) )
                {
                    bSavedRRT = TRUE;
                    break;
                }
            }
        }
    }

    // fill the structure...
    if(stGenSetting.g_VchipRegion5.u8VersionNo != INVALID_VERSION_NUM)
    {
        stEZ_VchipRegion5.u8VersionNo = stGenSetting.g_VchipRegion5.u8VersionNo;
    }

    memcpy(stEZ_VchipRegion5.u8Region5Name, stGenSetting.g_VchipRegion5.u8Region5Name, sizeof(stEZ_VchipRegion5.u8Region5Name));
    stEZ_VchipRegion5.u8NoDimension = stGenSetting.g_VchipRegion5.u8NoDimension;
    for(u8Loop2=0; u8Loop2<stGenSetting.g_VchipRegion5.u8NoDimension; u8Loop2++)
    {
        stEZ_VchipRegion5.stRegin5Dimension[u8Loop2].u16CurrentOption = stGenSetting.g_VchipRegion5.stRegin5Dimension[u8Loop2].u16CurrentOption;
        stEZ_VchipRegion5.stRegin5Dimension[u8Loop2].u16Graduated_Scale = stGenSetting.g_VchipRegion5.stRegin5Dimension[u8Loop2].u16Graduated_Scale;
        stEZ_VchipRegion5.stRegin5Dimension[u8Loop2].u8Values_Defined = stGenSetting.g_VchipRegion5.stRegin5Dimension[u8Loop2].u8Values_Defined;
    }

    if (!bSavedRRT)
    {
        if (stGenSetting.u8NoSavedRRT == MAX_RRT_SAVED)
        {
            if (stGenSetting.u8IdxLastSavedRRT >= (MAX_RRT_SAVED-1))
            {
                stGenSetting.u8IdxLastSavedRRT = 0;
                u8Loop1 = stGenSetting.u8IdxLastSavedRRT;
            }
            else
            {
                stGenSetting.u8IdxLastSavedRRT++;
                u8Loop1 = stGenSetting.u8IdxLastSavedRRT;
            }
        }
        else
        {
            u8Loop1 = stGenSetting.u8IdxLastSavedRRT;
            stGenSetting.u8NoSavedRRT++;
            stGenSetting.u8IdxLastSavedRRT++;
        }
    }

    msAPI_MIU_Copy((U32)&stEZ_VchipRegion5, (U32)GET_SAVED_RRT_SETTING_ADDRESS(u8Loop1), sizeof(MS_EZ_REGION5_RATING), MIU_SDRAM2SDRAM);
}
#endif

//============================================================================
BOOLEAN MApp_UiMenuFunc_SetVChip_Level(BOOLEAN action, EN_VCHIP_RATING_TYPE vchipPageType)
{
    if (action == TRUE)
    {
        if(vchipPageType == VCHIP_RATING_TYPE_MPAA)
        {
            if (g_stVChipRatingInfo.RatingType == VCHIP_RATING_TYPE_MPAA)
                fVChipPassWordEntered = FALSE;

            if (stGenSetting.g_VChipSetting.u8VChipMPAAItem==VCHIP_MPAARATING_X)
            {
                stGenSetting.g_VChipSetting.u8VChipMPAAItem = 0;
            }
            else
            {
                stGenSetting.g_VChipSetting.u8VChipMPAAItem++;
            }
        }
        else if(vchipPageType == VCHIP_RATING_TYPE_CANADA_ENG)
        {
            if (g_stVChipRatingInfo.RatingType == VCHIP_RATING_TYPE_CANADA_ENG)
                fVChipPassWordEntered = FALSE;

            if (stGenSetting.g_VChipSetting.u8VChipCEItem==VCHIP_ENGRATING_18Plus)
            {
                stGenSetting.g_VChipSetting.u8VChipCEItem = 0;
            }
            else
            {
                stGenSetting.g_VChipSetting.u8VChipCEItem++;
            }
        }
        else if(vchipPageType == VCHIP_RATING_TYPE_CANADA_FRE)
        {
            if (g_stVChipRatingInfo.RatingType == VCHIP_RATING_TYPE_CANADA_FRE)
                fVChipPassWordEntered = FALSE;

            if (stGenSetting.g_VChipSetting.u8VChipCFItem==VCHIP_FRERATING_18ansPlus)
            {
                stGenSetting.g_VChipSetting.u8VChipCFItem = 0;
            }
            else
            {
                stGenSetting.g_VChipSetting.u8VChipCFItem++;
            }
        }

    }
    else if (action == FALSE)
    {
        if(vchipPageType == VCHIP_RATING_TYPE_MPAA)
        {
            if (g_stVChipRatingInfo.RatingType == VCHIP_RATING_TYPE_MPAA)
                fVChipPassWordEntered = FALSE;

            if (stGenSetting.g_VChipSetting.u8VChipMPAAItem==0)
            {
                stGenSetting.g_VChipSetting.u8VChipMPAAItem = VCHIP_MPAARATING_X;
            }
            else
            {
                stGenSetting.g_VChipSetting.u8VChipMPAAItem--;
            }
        }
        else if(vchipPageType == VCHIP_RATING_TYPE_CANADA_ENG)
        {
            if (g_stVChipRatingInfo.RatingType == VCHIP_RATING_TYPE_CANADA_ENG)
                fVChipPassWordEntered = FALSE;

            if (stGenSetting.g_VChipSetting.u8VChipCEItem==0)
            {
                stGenSetting.g_VChipSetting.u8VChipCEItem = VCHIP_ENGRATING_18Plus;
            }
            else
            {
                stGenSetting.g_VChipSetting.u8VChipCEItem--;
            }
        }
        else if(vchipPageType ==VCHIP_RATING_TYPE_CANADA_FRE)
        {
            if (g_stVChipRatingInfo.RatingType == VCHIP_RATING_TYPE_CANADA_FRE)
                fVChipPassWordEntered = FALSE;

            if (stGenSetting.g_VChipSetting.u8VChipCFItem==0)
            {
                stGenSetting.g_VChipSetting.u8VChipCFItem = VCHIP_FRERATING_18ansPlus;
            }
            else
            {
                stGenSetting.g_VChipSetting.u8VChipCFItem--;
            }
        }
    }

    memset(&g_stVChipRatingInfo, 0, sizeof(g_stVChipRatingInfo));
    g_stVChipRatingInfo.u8EIA608Data1 = BIT6;

    return TRUE;

}
static void MApp_UiMenuFunc_CheckVChip_TVRating_TV_PG(void)
{
    if((stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_PG & VCHIP_TVRATING_V)
    &&(stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_PG & VCHIP_TVRATING_S)
    &&(stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_PG & VCHIP_TVRATING_L)
    &&(stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_PG & VCHIP_TVRATING_D)
    &&(!(stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_PG & VCHIP_TVRATING_ALL))
    )
    {
        MApp_UiMenuFunc_SetVChip_TVRating_TV_PG_ALL();
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_ALL_BG, FALSE);
        if(!(stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_14 & VCHIP_TVRATING_ALL))
        {
            MApp_UiMenuFunc_SetVChip_TVRating_TV_14_ALL();
            MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_ALL_BG, FALSE);
        }
        if(!(stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_MA & VCHIP_TVRATING_ALL))
        {
            MApp_UiMenuFunc_SetVChip_TVRating_TV_MA_ALL();
            MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVMA_ALL_BG, FALSE);
        }

    }
    else if((stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_MA & VCHIP_TVRATING_V)
    &&(stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_MA & VCHIP_TVRATING_S)
    &&(stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_MA & VCHIP_TVRATING_L)
    &&(!(stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_MA & VCHIP_TVRATING_ALL)))
    {
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVMA_ALL_BG, FALSE);
    }
}

static void MApp_UiMenuFunc_CheckVChip_TVRating_TV_14(void)
{
    if((stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_14 & VCHIP_TVRATING_V)
    &&(stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_14 & VCHIP_TVRATING_S)
    &&(stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_14 & VCHIP_TVRATING_L)
    &&(stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_14 & VCHIP_TVRATING_D)
    &&(!(stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_14 & VCHIP_TVRATING_ALL))
    )
    {
        MApp_UiMenuFunc_SetVChip_TVRating_TV_14_ALL();
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_ALL_BG, FALSE);
        if(!(stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_MA & VCHIP_TVRATING_ALL))
        {
            MApp_UiMenuFunc_SetVChip_TVRating_TV_MA_ALL();
            MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVMA_ALL_BG, FALSE);
        }
    }
    else if((stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_MA & VCHIP_TVRATING_V)
    &&(stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_MA & VCHIP_TVRATING_S)
    &&(stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_MA & VCHIP_TVRATING_L)
    &&(!(stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_MA & VCHIP_TVRATING_ALL)))
    {
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVMA_ALL_BG, FALSE);
    }
}

static void MApp_UiMenuFunc_CheckVChip_TVRating_TV_MA(void)
{
    if((stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_MA & VCHIP_TVRATING_V)
    &&(stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_MA & VCHIP_TVRATING_S)
    &&(stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_MA & VCHIP_TVRATING_L)
    &&(!(stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_MA & VCHIP_TVRATING_ALL))
    )
    {
        MApp_UiMenuFunc_SetVChip_TVRating_TV_MA_ALL();
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVMA_ALL_BG, FALSE);
    }
}
static void MApp_UiMenuFunc_VChip_CompareRating(void)
{
    BOOLEAN bPreLockStatus = MApp_VChip_GetCurVChipBlockStatus();
    BOOLEAN fVChipPassWordEnteredBk ;

    fVChipPassWordEnteredBk = fVChipPassWordEntered;
    fVChipPassWordEntered = FALSE;
    if (bPreLockStatus != MApp_VChip_CompareRating(&g_stVChipRatingInfo, &stGenSetting.g_VChipSetting))
    {
        fVChipPassWordEntered = FALSE;
        memset(&g_stVChipRatingInfo, 0, sizeof(g_stVChipRatingInfo));
        g_stVChipRatingInfo.u8EIA608Data1 = BIT6;
    }
    else
        fVChipPassWordEntered = fVChipPassWordEnteredBk;
}

BOOLEAN MApp_UiMenuFunc_SetVChip_TVRating_TV_Y_ALL(void)
{
    if (stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_Y & VCHIP_TVRATING_ALL)
    {
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_Y &= ~VCHIP_TVRATING_ALL;
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVY_ALL_BG, TRUE);
    }
    else
    {
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_Y = VCHIP_TVRATING_ALL;
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_Y7 = VCHIP_TVRATING_FV|VCHIP_TVRATING_ALL;
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVY_ALL_BG, FALSE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVY7_ALL_BG, FALSE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVY7_FV_BG, FALSE);
    }
    MApp_UiMenuFunc_VChip_CompareRating();
    return TRUE;
}

BOOLEAN MApp_UiMenuFunc_SetVChip_TVRating_TV_Y7_ALL(void)
{
    if (stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_Y7 & VCHIP_TVRATING_ALL)
    {
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_Y7 = 0;//~VCHIP_TVRATING_ALL;
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_Y = 0;//~VCHIP_TVRATING_ALL;
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVY7_ALL_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVY7_FV_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVY_ALL_BG, TRUE);
    }
    else
    {
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_Y7 = VCHIP_TVRATING_FV|VCHIP_TVRATING_ALL;
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVY7_ALL_BG, FALSE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVY7_FV_BG, FALSE);
    }
    MApp_UiMenuFunc_VChip_CompareRating();
    return TRUE;
}

BOOLEAN MApp_UiMenuFunc_SetVChip_TVRating_TV_G_ALL(void)
{
    if (stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_G & VCHIP_TVRATING_ALL)
    {
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_G = 0;
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVG_ALL_BG, TRUE);
    }
    else
    {
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_G |= VCHIP_TVRATING_ALL;
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_PG = VCHIP_TVRATING_VSLD|VCHIP_TVRATING_ALL;
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_14 = VCHIP_TVRATING_VSLD|VCHIP_TVRATING_ALL;
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_MA = VCHIP_TVRATING_VSL|VCHIP_TVRATING_ALL;
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVG_ALL_BG, FALSE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_ALL_BG, FALSE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_ALL_BG, FALSE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVMA_ALL_BG, FALSE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_V_BG, FALSE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_V_BG, FALSE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVMA_V_BG, FALSE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_S_BG, FALSE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_S_BG, FALSE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVMA_S_BG, FALSE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_L_BG, FALSE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_L_BG, FALSE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVMA_L_BG, FALSE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_D_BG, FALSE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_D_BG, FALSE);
    }
    MApp_UiMenuFunc_VChip_CompareRating();
    return TRUE;
}

BOOLEAN MApp_UiMenuFunc_SetVChip_TVRating_TV_PG_ALL(void)
{
    if (stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_PG & VCHIP_TVRATING_ALL)
    {
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_PG = 0;//~VCHIP_TVRATING_ALL;
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_G = 0;//~VCHIP_TVRATING_ALL;
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_ALL_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_V_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_S_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_L_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_D_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVG_ALL_BG, TRUE);
    }
    else
    {
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_PG = VCHIP_TVRATING_VSLD|VCHIP_TVRATING_ALL;
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_14 = VCHIP_TVRATING_VSLD|VCHIP_TVRATING_ALL;
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_MA = VCHIP_TVRATING_VSL|VCHIP_TVRATING_ALL;
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_ALL_BG, FALSE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_V_BG, FALSE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_S_BG, FALSE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_L_BG, FALSE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_D_BG, FALSE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_ALL_BG, FALSE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_V_BG, FALSE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_S_BG, FALSE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_L_BG, FALSE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_D_BG, FALSE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVMA_ALL_BG, FALSE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVMA_V_BG, FALSE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVMA_S_BG, FALSE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVMA_L_BG, FALSE);
    }
    MApp_UiMenuFunc_VChip_CompareRating();
    return TRUE;
}

BOOLEAN MApp_UiMenuFunc_SetVChip_TVRating_TV_14_ALL(void)
{
    if (stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_14 & VCHIP_TVRATING_ALL)
    {
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_14 = 0;//~VCHIP_TVRATING_ALL;
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_PG = 0;//~VCHIP_TVRATING_ALL;
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_G = 0;//~VCHIP_TVRATING_ALL;
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_ALL_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_V_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_S_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_L_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_D_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_ALL_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_V_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_S_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_L_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_D_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVG_ALL_BG, TRUE);
    }
    else
    {
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_14 = VCHIP_TVRATING_VSLD|VCHIP_TVRATING_ALL;
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_MA = VCHIP_TVRATING_VSL|VCHIP_TVRATING_ALL;
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_ALL_BG, FALSE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_V_BG, FALSE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_S_BG, FALSE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_L_BG, FALSE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_D_BG, FALSE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVMA_ALL_BG, FALSE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVMA_V_BG, FALSE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVMA_S_BG, FALSE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVMA_L_BG, FALSE);
    }
    MApp_UiMenuFunc_VChip_CompareRating();
    return TRUE;
}

BOOLEAN MApp_UiMenuFunc_SetVChip_TVRating_TV_MA_ALL(void)
{
    if (stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_MA & VCHIP_TVRATING_ALL)
    {
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_MA &= 0;//~VCHIP_TVRATING_ALL;
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_14 &= 0;//~VCHIP_TVRATING_ALL;
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_PG &= 0;//~VCHIP_TVRATING_ALL;
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_G &= 0;//~VCHIP_TVRATING_ALL;
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_ALL_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_V_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_S_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_L_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_D_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_ALL_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_V_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_S_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_L_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_D_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVMA_ALL_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVMA_V_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVMA_S_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVMA_L_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVG_ALL_BG, TRUE);
    }
    else
    {
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_MA = VCHIP_TVRATING_VSL|VCHIP_TVRATING_ALL;
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVMA_ALL_BG, FALSE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVMA_V_BG, FALSE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVMA_S_BG, FALSE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVMA_L_BG, FALSE);
    }
    MApp_UiMenuFunc_VChip_CompareRating();
    return TRUE;
}

BOOLEAN MApp_UiMenuFunc_SetVChip_TVRating_TV_Y7_FV(void)
{
    if (stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_Y7 & VCHIP_TVRATING_FV)
    {
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_Y7 = 0;
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_Y = 0;
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVY7_ALL_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVY7_FV_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVY_ALL_BG, TRUE);
    }
    else
    {
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_Y7 = VCHIP_TVRATING_FV|VCHIP_TVRATING_ALL;
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVY7_ALL_BG, FALSE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVY7_FV_BG, FALSE);
    }
    MApp_UiMenuFunc_VChip_CompareRating();
    return TRUE;
}

BOOLEAN MApp_UiMenuFunc_SetVChip_TVRating_TV_PG_V(void)
{
    if (stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_PG & VCHIP_TVRATING_V)
    {
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_PG &= ~(VCHIP_TVRATING_V|VCHIP_TVRATING_ALL);
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_G &= ~VCHIP_TVRATING_ALL;
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_ALL_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_V_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVG_ALL_BG, TRUE);
    }
    else
    {
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_PG |= VCHIP_TVRATING_V;
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_14 |= VCHIP_TVRATING_V;
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_MA |= VCHIP_TVRATING_V;
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_V_BG, FALSE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_V_BG, FALSE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVMA_V_BG, FALSE);
        MApp_UiMenuFunc_CheckVChip_TVRating_TV_PG();
    }
    MApp_UiMenuFunc_VChip_CompareRating();
    return TRUE;
}

BOOLEAN MApp_UiMenuFunc_SetVChip_TVRating_TV_14_V(void)
{
    if (stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_14 & VCHIP_TVRATING_V)
    {
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_14 &= ~(VCHIP_TVRATING_V|VCHIP_TVRATING_ALL);
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_PG &= ~(VCHIP_TVRATING_ALL|VCHIP_TVRATING_V);
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_G &= ~VCHIP_TVRATING_ALL;
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_ALL_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_V_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_ALL_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_V_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVG_ALL_BG, TRUE);
    }
    else
    {
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_14 |= VCHIP_TVRATING_V;
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_MA |= VCHIP_TVRATING_V;
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_V_BG, FALSE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVMA_V_BG, FALSE);
        MApp_UiMenuFunc_CheckVChip_TVRating_TV_14();
    }
    MApp_UiMenuFunc_VChip_CompareRating();
    return TRUE;
}

BOOLEAN MApp_UiMenuFunc_SetVChip_TVRating_TV_MA_V(void)
{
    if (stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_MA & VCHIP_TVRATING_V)
    {
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_MA &= ~(VCHIP_TVRATING_V|VCHIP_TVRATING_ALL);
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_14 &= ~(VCHIP_TVRATING_ALL|VCHIP_TVRATING_V);
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_PG &= ~(VCHIP_TVRATING_ALL|VCHIP_TVRATING_V);
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_G &= ~VCHIP_TVRATING_ALL;
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_ALL_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_V_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_ALL_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_V_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVMA_ALL_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVMA_V_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVG_ALL_BG, TRUE);
    }
    else
    {
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_MA |= VCHIP_TVRATING_V;
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVMA_V_BG, FALSE);
        MApp_UiMenuFunc_CheckVChip_TVRating_TV_MA();
    }
    MApp_UiMenuFunc_VChip_CompareRating();
    return TRUE;
}

BOOLEAN MApp_UiMenuFunc_SetVChip_TVRating_TV_PG_S(void)
{
    if (stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_PG & VCHIP_TVRATING_S)
    {
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_PG &= ~(VCHIP_TVRATING_S|VCHIP_TVRATING_ALL);
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_G &= ~VCHIP_TVRATING_ALL;
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_ALL_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_S_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVG_ALL_BG, TRUE);
    }
    else
    {
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_PG |= VCHIP_TVRATING_S;
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_14 |= VCHIP_TVRATING_S;
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_MA |= VCHIP_TVRATING_S;
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_S_BG, FALSE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_S_BG, FALSE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVMA_S_BG, FALSE);
        MApp_UiMenuFunc_CheckVChip_TVRating_TV_PG();
    }
    MApp_UiMenuFunc_VChip_CompareRating();
    return TRUE;
}

BOOLEAN MApp_UiMenuFunc_SetVChip_TVRating_TV_14_S(void)
{
    if (stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_14 & VCHIP_TVRATING_S)
    {
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_14 &= ~(VCHIP_TVRATING_S|VCHIP_TVRATING_ALL);
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_PG &= ~(VCHIP_TVRATING_ALL|VCHIP_TVRATING_S);
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_G &= ~VCHIP_TVRATING_ALL;
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_ALL_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_S_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_ALL_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_S_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVG_ALL_BG, TRUE);
    }
    else
    {
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_14 |= VCHIP_TVRATING_S;
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_MA |= VCHIP_TVRATING_S;
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_S_BG, FALSE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVMA_S_BG, FALSE);

        MApp_UiMenuFunc_CheckVChip_TVRating_TV_14();
    }
    MApp_UiMenuFunc_VChip_CompareRating();
    return TRUE;
}

BOOLEAN MApp_UiMenuFunc_SetVChip_TVRating_TV_MA_S(void)
{
    if (stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_MA & VCHIP_TVRATING_S)
    {
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_MA &= ~(VCHIP_TVRATING_S|VCHIP_TVRATING_ALL);
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_14 &= ~(VCHIP_TVRATING_ALL|VCHIP_TVRATING_S);
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_PG &= ~(VCHIP_TVRATING_ALL|VCHIP_TVRATING_S);
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_G &= ~VCHIP_TVRATING_ALL;
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_ALL_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_S_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_ALL_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_S_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVMA_ALL_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVMA_S_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVG_ALL_BG, TRUE);
    }
    else
    {
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_MA |= VCHIP_TVRATING_S;
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVMA_S_BG, FALSE);
        MApp_UiMenuFunc_CheckVChip_TVRating_TV_MA();
    }
    MApp_UiMenuFunc_VChip_CompareRating();
    return TRUE;
}

BOOLEAN MApp_UiMenuFunc_SetVChip_TVRating_TV_PG_L(void)
{
    if (stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_PG & VCHIP_TVRATING_L)
    {
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_PG &= ~(VCHIP_TVRATING_L|VCHIP_TVRATING_ALL);
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_G &= ~VCHIP_TVRATING_ALL;
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_ALL_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_L_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVG_ALL_BG, TRUE);
    }
    else
    {

        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_PG |= VCHIP_TVRATING_L;
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_14 |= VCHIP_TVRATING_L;
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_MA |= VCHIP_TVRATING_L;
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_L_BG, FALSE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_L_BG, FALSE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVMA_L_BG, FALSE);
        MApp_UiMenuFunc_CheckVChip_TVRating_TV_PG();
    }
    MApp_UiMenuFunc_VChip_CompareRating();
    return TRUE;
}

BOOLEAN MApp_UiMenuFunc_SetVChip_TVRating_TV_14_L(void)
{
    if (stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_14 & VCHIP_TVRATING_L)
    {
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_14 &= ~(VCHIP_TVRATING_L|VCHIP_TVRATING_ALL);
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_PG &= ~(VCHIP_TVRATING_ALL|VCHIP_TVRATING_L);
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_G &= ~VCHIP_TVRATING_ALL;
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_ALL_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_L_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_ALL_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_L_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVG_ALL_BG, TRUE);
    }
    else
    {
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_14 |= VCHIP_TVRATING_L;
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_MA |=VCHIP_TVRATING_L;
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_L_BG, FALSE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVMA_L_BG, FALSE);
        MApp_UiMenuFunc_CheckVChip_TVRating_TV_14();
    }
    MApp_UiMenuFunc_VChip_CompareRating();
    return TRUE;
}

BOOLEAN MApp_UiMenuFunc_SetVChip_TVRating_TV_MA_L(void)
{
    if (stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_MA & VCHIP_TVRATING_L)
    {
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_MA &= ~(VCHIP_TVRATING_L|VCHIP_TVRATING_ALL);
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_14 &= ~(VCHIP_TVRATING_ALL|VCHIP_TVRATING_L);
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_PG &= ~(VCHIP_TVRATING_ALL|VCHIP_TVRATING_L);
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_G &= ~VCHIP_TVRATING_ALL;
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_ALL_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_L_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_ALL_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_L_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVMA_ALL_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVMA_L_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVG_ALL_BG, TRUE);
    }
    else
    {
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_MA |= VCHIP_TVRATING_L;
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVMA_L_BG, FALSE);
        MApp_UiMenuFunc_CheckVChip_TVRating_TV_MA();
    }
    MApp_UiMenuFunc_VChip_CompareRating();
    return TRUE;
}

BOOLEAN MApp_UiMenuFunc_SetVChip_TVRating_TV_PG_D(void)
{
    if (stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_PG & VCHIP_TVRATING_D)
    {
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_PG &= ~(VCHIP_TVRATING_D|VCHIP_TVRATING_ALL);
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_G &= ~VCHIP_TVRATING_ALL;
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_ALL_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_D_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVG_ALL_BG, TRUE);
    }
    else
    {
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_PG |= VCHIP_TVRATING_D;
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_14 |= VCHIP_TVRATING_D;
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_D_BG, FALSE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_D_BG, FALSE);
        MApp_UiMenuFunc_CheckVChip_TVRating_TV_PG();
    }
    MApp_UiMenuFunc_VChip_CompareRating();
    return TRUE;
}

BOOLEAN MApp_UiMenuFunc_SetVChip_TVRating_TV_14_D(void)
{
    if (stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_14 & VCHIP_TVRATING_D)
    {
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_14 &= ~(VCHIP_TVRATING_D|VCHIP_TVRATING_ALL);
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_PG &= ~(VCHIP_TVRATING_ALL|VCHIP_TVRATING_D);
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_G &= ~VCHIP_TVRATING_ALL;
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_ALL_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_D_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_ALL_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVPG_D_BG, TRUE);
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TVG_ALL_BG, TRUE);
    }
    else
    {
        stGenSetting.g_VChipSetting.stVChipTVItem.Item_TV_14 |= VCHIP_TVRATING_D;
        MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_TVRATINGSUBPAGE_ITEM_TV14_D_BG, FALSE);
        MApp_UiMenuFunc_CheckVChip_TVRating_TV_14();
    }
    MApp_UiMenuFunc_VChip_CompareRating();
    return TRUE;
}
//============================================================================

#endif //end of ENABLE_ATV_VCHIP
#if 0
BOOLEAN MApp_UiMenuFunc_CheckInputLock(void)
{

    if ( IsAnyTVSourceInUse() )
        return ( stGenSetting.g_VChipSetting.u8InputBlockItem & INPUT_BLOCK_TV);
    else if ( IsVgaInUse() )
        return ( stGenSetting.g_VChipSetting.u8InputBlockItem & INPUT_BLOCK_PC);
    else if ( UI_INPUT_SOURCE_TYPE==UI_INPUT_SOURCE_COMPONENT )
        return ( stGenSetting.g_VChipSetting.u8InputBlockItem & INPUT_BLOCK_YPBPR1);
    else if ( UI_INPUT_SOURCE_TYPE==UI_INPUT_SOURCE_COMPONENT2 )
        return ( stGenSetting.g_VChipSetting.u8InputBlockItem & INPUT_BLOCK_YPBPR2);
    else if ( UI_INPUT_SOURCE_TYPE==UI_INPUT_SOURCE_AV)
        return ( stGenSetting.g_VChipSetting.u8InputBlockItem & INPUT_BLOCK_AV1);
    else if ( UI_INPUT_SOURCE_TYPE==UI_INPUT_SOURCE_AV2)
        return ( stGenSetting.g_VChipSetting.u8InputBlockItem & INPUT_BLOCK_AV2);

#if (ENABLE_HDMI)
    else if ( UI_INPUT_SOURCE_TYPE==UI_INPUT_SOURCE_HDMI)
        return ( stGenSetting.g_VChipSetting.u8InputBlockItem & INPUT_BLOCK_HDMI1);
    else if ( UI_INPUT_SOURCE_TYPE==UI_INPUT_SOURCE_HDMI2)
        return ( stGenSetting.g_VChipSetting.u8InputBlockItem & INPUT_BLOCK_HDMI2);
#endif

#if (ENABLE_SCART_VIDEO)
    else if ( IsScartInUse() )
        return ( stGenSetting.g_VChipSetting.u8InputBlockItem & INPUT_BLOCK_SCART);
#endif

    return FALSE;
}

BOOLEAN MApp_UiMenuFunc_AdjustInputLockTV(void)
{
    g_bInputBlocked = MApp_UiMenuFunc_CheckInputLock ();

    if ( IsAnyTVSourceInUse() )
    {
        #if 1
        MApp_MuteAvByLock(E_SCREEN_MUTE_INPUT, g_bInputBlocked);
        #else
        MApp_MuteAvByLock(g_bInputBlocked);
        #endif
    }
    return TRUE;
}

BOOLEAN MApp_UiMenuFunc_AdjustInputLockAV(void)
{
    g_bInputBlocked = MApp_UiMenuFunc_CheckInputLock ();

    if ( IsAVInUse() )
    {
        #if 1
        MApp_MuteAvByLock(E_SCREEN_MUTE_INPUT, g_bInputBlocked);
        #else
        MApp_MuteAvByLock(g_bInputBlocked);
        #endif
    }
    return TRUE;
}

BOOLEAN MApp_UiMenuFunc_AdjustInputLockSV(void)
{
    g_bInputBlocked = MApp_UiMenuFunc_CheckInputLock ();

    if ( IsSVInUse() )
    {
        #if 1
        MApp_MuteAvByLock(E_SCREEN_MUTE_INPUT, g_bInputBlocked);
        #else
        MApp_MuteAvByLock(g_bInputBlocked);
        #endif
    }
    return TRUE;
}

BOOLEAN MApp_UiMenuFunc_AdjustInputLockYPbPr(void)
{
    g_bInputBlocked = MApp_UiMenuFunc_CheckInputLock ();

    if ( IsYPbPrInUse() )
    {
        #if 1
        MApp_MuteAvByLock(E_SCREEN_MUTE_INPUT, g_bInputBlocked);
        #else
        MApp_MuteAvByLock(g_bInputBlocked);
        #endif
    }
    return TRUE;
}

BOOLEAN MApp_UiMenuFunc_AdjustInputLockSCART(void)
{
    g_bInputBlocked = MApp_UiMenuFunc_CheckInputLock ();

#if (ENABLE_SCART_VIDEO)
    if ( IsScartInUse() )
    {
        #if 1
        MApp_MuteAvByLock(E_SCREEN_MUTE_INPUT, g_bInputBlocked);
        #else
        MApp_MuteAvByLock(g_bInputBlocked);
        #endif
    }
#endif

    return TRUE;
}

BOOLEAN MApp_UiMenuFunc_AdjustInputLockHDMI(void)
{
    g_bInputBlocked = MApp_UiMenuFunc_CheckInputLock ();

#if (ENABLE_HDMI)
    if ( IsHDMIInUse() )
    {
        #if 1
        MApp_MuteAvByLock(E_SCREEN_MUTE_INPUT, g_bInputBlocked);
        #else
        MApp_MuteAvByLock(g_bInputBlocked);
        #endif
    }
#endif

    return TRUE;
}

BOOLEAN MApp_UiMenuFunc_AdjustInputLockPC(void)
{
    g_bInputBlocked = MApp_UiMenuFunc_CheckInputLock ();

    if ( IsVgaInUse() )
    {
        #if 1
        MApp_MuteAvByLock(E_SCREEN_MUTE_INPUT, g_bInputBlocked);
        #else
        MApp_MuteAvByLock(g_bInputBlocked);
        #endif
    }
    return TRUE;
}
#endif // end of ENABLE_INPUT_LOCK

#undef  MAPP_UI_MENUFUNC_C

