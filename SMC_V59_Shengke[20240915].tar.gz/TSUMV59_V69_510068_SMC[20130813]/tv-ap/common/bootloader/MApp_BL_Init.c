////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (MStar Confidential Information) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#define MAPP_BL_INIT_C

#include <stdio.h>
#include "Board.h"
#include "msAPI_DrvInit.h"
#include "msAPI_Flash.h"
#include "msAPI_FS_SysInfo.h"
#include "msAPI_Memory.h"
#include "msAPI_Tuner.h"
//#include "msAPI_MIU.h"
//#include "BinInfo.h"
//#include "InfoBlock.h"

//extern void UART_Clear(void);
#if (ENABLE_BL_UI)
//refer from display_logo of MBoot
#include "apiGFX.h"
#include "apiGOP.h"
#include "Panel.h"
#include "DemoFineTune.h"
#include "util_symbol.h"
#include "msAPI_Font.h"
#include "BinInfo.h"
#include "msAPI_OSD.h"
#include "msAPI_OSD_Resource.h"

#include "msAPI_OCP.h"
S16 Osdcp_bmpHandle1[10];

#define DISPLAY_DBG(x) x
#define GOP_BUFFER_ADDR                         GOP_GWIN_RB_ADR //0x6100000

MS_BOOL _sc_is_interlace(void)
{
    return 0;
}

MS_U16 _sc_get_h_cap_start(void)
{
    return 0x60;
}
void _Sys_PQ_ReduceBW_ForOSD(MS_U8 PqWin, MS_BOOL bOSD_On)
{
    PqWin=bOSD_On=0;
}

MS_U16  devPanel_HStart(void)
{
    return g_IPanel.HStart();
}

void gop_stretch(U16 graph_pitch, U16 graph_width, U16 graph_height, MS_BOOL bHorStretch, MS_BOOL bVerStretch)
{
    U32 u32GWinDispX_Max;
    U32 u32GWinDispY_Max;


    u32GWinDispX_Max = devPanel_WIDTH();
    u32GWinDispY_Max = devPanel_HEIGHT();

    if (bHorStretch)
        MApi_GOP_GWIN_Set_HSCALE(TRUE, graph_width, u32GWinDispX_Max);
    if (bVerStretch)
        MApi_GOP_GWIN_Set_VSCALE(TRUE, graph_height, u32GWinDispY_Max);

    MApi_GOP_GWIN_Set_STRETCHWIN(0, E_GOP_DST_OP0, 0, 0, graph_pitch, graph_height);
}

static void BurstInitGOP(U16 u16X, U16 u16Y, U16 u16Pitch, U16 u16Height, U32 u32GopBuffer)
{
    U32 u32DispX;
    U32 u32DispY;
    U32 u32Width;
    U32 u32Height;
    U32 u32Panel_Hstart;
    GOP_InitInfo pGopInit;

    u32DispX = u16X;
    u32DispY = u16Y;
    u32Width = 960;
    u32Height = 540;
    u32Panel_Hstart = devPanel_HStart();

    MApi_GOP_RegisterFBFmtCB(( MS_U32(*)(MS_U16 pitch,MS_U32 addr , MS_U16 fmt ))msAPI_OSD_RESOURCE_SetFBFmt);
    MApi_GOP_RegisterXCIsInterlaceCB(_sc_is_interlace);
    MApi_GOP_RegisterXCGetCapHStartCB(_sc_get_h_cap_start);
    MApi_GOP_RegisterXCReduceBWForOSDCB(_Sys_PQ_ReduceBW_ForOSD);
    pGopInit.u16PanelWidth = u32Width;
    pGopInit.u16PanelHeight = u32Height;
    pGopInit.u16PanelHStr = u32Panel_Hstart;
    pGopInit.u32GOPRBAdr = u32GopBuffer;//((GOP_GWIN_RB_MEMORY_TYPE & MIU1) ? (GOP_GWIN_RB_ADR | MIU_INTERVAL) : (GOP_GWIN_RB_ADR));
    pGopInit.u32GOPRBLen = u32Width*u32Height*2;
    //there is a GOP_REGDMABASE_MIU1_ADR for MIU1
    pGopInit.u32GOPRegdmaAdr = 0;//((GOP_REGDMABASE_MEMORY_TYPE & MIU1) ? (GOP_REGDMABASE_ADR | MIU_INTERVAL) : (GOP_REGDMABASE_ADR));
    pGopInit.u32GOPRegdmaLen = 0;
    pGopInit.bEnableVsyncIntFlip = FALSE;
    MApi_GOP_InitByGOP(&pGopInit, 0);

    U8 u8FbId, u8GwinId;
    u8FbId = MApi_GOP_GWIN_GetFreeFBID();
    u8GwinId =0;

    MApi_GOP_GWIN_CreateFBbyStaticAddr(u8FbId, u32DispX, u32DispY, u16Pitch, u16Height, GFX_FMT_RGB565, u32GopBuffer);
    //printf("%s: u32GopBuffer: 0x%lx, at %d\n", __func__, u32GopBuffer, __LINE__);

    MApi_GOP_GWIN_MapFB2Win(u8FbId, 0);
    MApi_GOP_GWIN_Switch2FB(u8FbId);
    MApi_GOP_GWIN_SetWinDispPosition(u8GwinId, u32DispX, u32DispY);

    MApi_GOP_GWIN_SetBlending(u8GwinId, FALSE, 63);

//    MApi_GOP_GWIN_Enable(u8GwinId, TRUE);

}

void InitGOPEnv(U16 u16X, U16 u16Y, U16 u16Width, U16 u16Height,
    U16 u16Pitch, MS_BOOL bHorStretch, MS_BOOL bVerStretch, U32 u32FramBufferAddr)
{
    //U16 *u16TempAddr;
    GFX_Config tGFXcfg;
    GFX_Point gfxPt0 = { 0, 0 };
    GFX_Point gfxPt1 = { 960, 540 };
    //u16TempAddr = (U16 *)(u32FramBufferAddr|0xA0000000);

    tGFXcfg.bIsCompt = TRUE;
    tGFXcfg.bIsHK = TRUE;
    MApi_GFX_Init(&tGFXcfg);

	gfxPt0.x = u16X;
	gfxPt0.y = u16Y;

	gfxPt1.x = u16X + u16Width;
	gfxPt1.y = u16Y + u16Height;

    MApi_GFX_SetClip(&gfxPt0, &gfxPt1);

    if (bHorStretch)
    {
        u16X = 0;
    }
    if (bVerStretch)
    {
        u16Y = 0;
    }

    BurstInitGOP(u16X, u16Y, u16Pitch, u16Height, u32FramBufferAddr);

    if (bHorStretch||bVerStretch)
        gop_stretch(u16Pitch, u16Width, u16Height, bHorStretch, bVerStretch);

	MApi_GFX_RegisterGetFontCB(msAPI_OSD_RESOURCE_GetFontInfoGFX);
}

void BL_DrawProgressBar(U16 x, U16 y, U16 width, U16 height, U32 t_clr, U32 b_clr, U32 g_clr, U8 u8Gradient, U8 pertvalue)
{
		OSDClrBtn clrBtn2;
		char warningMsg[16];

		clrBtn2.x = x;
		clrBtn2.y = y;
		clrBtn2.radius = 0;
		clrBtn2.width = width;
		clrBtn2.height = height;
		clrBtn2.b_clr = b_clr;
		clrBtn2.g_clr = g_clr;
		clrBtn2.t_clr = t_clr;
		clrBtn2.u8Gradient = u8Gradient;
		clrBtn2.fHighLight = FALSE;
		clrBtn2.Fontfmt.flag = GEFONT_FLAG_VARWIDTH | GEFONT_FLAG_GAP;
		clrBtn2.Fontfmt.ifont_gap = 2;
		clrBtn2.enTextAlign = EN_ALIGNMENT_CENTER;
		clrBtn2.bStringIndexWidth = CHAR_IDX_1BYTE;

		msAPI_OSD_DrawBlock(&clrBtn2);

		memset(warningMsg, 0x00, sizeof(warningMsg));
		snprintf((char *)warningMsg, 14,  "%ld%%", pertvalue);
		msAPI_OSD_DrawText(Font[FONT_0].fHandle, (U8 *)warningMsg, &clrBtn2);
}

void MApp_BL_DisplaySystem_clear(void)
{
    OSDClrBtn clrBtn;

    // clear screen
    clrBtn.x = 0;
    clrBtn.y = 0;
    clrBtn.width = devPanel_WIDTH();
    clrBtn.height = devPanel_HEIGHT();
    clrBtn.b_clr = 0x00080808;
    clrBtn.u8Gradient = CONSTANT_COLOR;
    clrBtn.fHighLight = FALSE;
    msAPI_OSD_DrawBlock(&clrBtn);
}

void MApp_BL_DisplaySystem_setStatus(S8 *status)
{
    OSDClrBtn clrBtn;
    U8 strStatus[32];
    U8 warningMsg[255];

    if(!status)
        return;
    memset(strStatus, 0x00, sizeof(strStatus));
    snprintf((char*)strStatus, strlen((char*)status), "%s", status);

    // draw warning message
	clrBtn.x =  0;
	clrBtn.y =  devPanel_HEIGHT() / 4;
	clrBtn.width = devPanel_WIDTH();
	clrBtn.height = devPanel_HEIGHT() / 4;
	clrBtn.radius = 0;
	clrBtn.u8Gradient = CONSTANT_COLOR;
	clrBtn.b_clr =  COLOR_BLUE;
	clrBtn.fHighLight =  FALSE;
	clrBtn.t_clr = COLOR_WHITE;
	clrBtn.Fontfmt.flag = GEFONT_FLAG_VARWIDTH | GEFONT_FLAG_GAP;
	clrBtn.Fontfmt.ifont_gap = 2;
	clrBtn.enTextAlign = EN_ALIGNMENT_CENTER;

	clrBtn.bStringIndexWidth = CHAR_IDX_1BYTE;
	memset(warningMsg, 0x00, sizeof(warningMsg));
	//memcpy(warningMsg, "SCANING", 16);
	memcpy(warningMsg, strStatus, 24);

	msAPI_OSD_DrawText(Font[FONT_0].fHandle, (U8 *)warningMsg, &clrBtn);
}

void MApp_BL_DisplaySystem(U8 u8Percent)
{
    OSDClrBtn clrBtn;
    //U8 warningMsg[255];
    //U32 i, nStep;

//Thomas update for BOOTLOADER
#if 1
    clrBtn.x = 230;
    clrBtn.y = 332;
    clrBtn.width = u8Percent*5;
    clrBtn.height = 6;
    clrBtn.b_clr = 0x00FFFFFF;
    clrBtn.u8Gradient = CONSTANT_COLOR;
    clrBtn.fHighLight = FALSE;
    msAPI_OSD_DrawBlock(&clrBtn);
#else
    // clear screen
    clrBtn.x = 0;
    clrBtn.y = 0;
    clrBtn.width = devPanel_WIDTH();
    clrBtn.height = devPanel_HEIGHT();
    clrBtn.b_clr = 0x00000000;
    clrBtn.u8Gradient = CONSTANT_COLOR;
    clrBtn.fHighLight = FALSE;
    //msAPI_OSD_DrawBlock(&clrBtn);

	// draw warning message
	clrBtn.x =  0;
	//clrBtn.y =  devPanel_HEIGHT() / 4;
	clrBtn.y =  0;
	clrBtn.width = devPanel_WIDTH();
	clrBtn.height = devPanel_HEIGHT() / 4;
	clrBtn.radius = 0;
	clrBtn.u8Gradient = CONSTANT_COLOR;
	clrBtn.b_clr =  COLOR_BLUE;
	clrBtn.fHighLight =  FALSE;
	clrBtn.t_clr = COLOR_WHITE;
	clrBtn.Fontfmt.flag = GEFONT_FLAG_VARWIDTH | GEFONT_FLAG_GAP;
	clrBtn.Fontfmt.ifont_gap = 2;
	clrBtn.enTextAlign = EN_ALIGNMENT_CENTER;

	clrBtn.bStringIndexWidth = CHAR_IDX_1BYTE;
	memset(warningMsg, 0x00, sizeof(warningMsg));
	memcpy(warningMsg, "DO NOT POWER OFF", 16);

	msAPI_OSD_DrawText(Font[FONT_0].fHandle, (U8 *)warningMsg, &clrBtn);

	MApi_GOP_GWIN_Enable(0, TRUE);

	clrBtn.width = 10;
	//for(i=1;i<=100;i++)
	i = (U32)u8Percent;
	{
		clrBtn.width = 18*i;
		//BL_DrawProgressBar((devPanel_WIDTH()-98*18-10)/2, devPanel_HEIGHT()/2, clrBtn.width, 100, 0xFFFFFFFF, 0xFF123456, 0xFF1234FF, GRADIENT_X_COLOR, i);
		BL_DrawProgressBar((devPanel_WIDTH()-98*18-10)/2, devPanel_HEIGHT()/2, clrBtn.width, 100, 0xFFFFFFFF, 0xFF123456, 0xFF1234FF, GRADIENT_X_COLOR, i);
	}
#endif
}

void Initial_BL_DisplaySystem(void)
{
    OSDClrBtn clrBtn;
    //U8 warningMsg[255];
    GFX_BufferInfo dstbuf;
    MSAPI_GEBitmapFmt gbmpfmt;

    DISPLAY_DBG(printf("logo display start\n"));

    Util_InitSymbolTBL();
    MApi_BD_LVDS_Output_Type(BD_LVDS_CONNECT_TYPE);
    MApi_PNL_Init( MApi_XC_GetPanelSpec(g_PNL_TypeSel));
    g_IPanel.Dump();
    #ifdef ENABLE_GAMMA_FOR_COLORTEMP
    MApi_XC_Sys_AdjustGammaTbl(FORCE_SET_VALUE);
    #else
    g_IPanel.SetGammaTbl(E_APIPNL_GAMMA_12BIT, tAllGammaTab, GAMMA_MAPPING_MODE);
    #endif
    MApi_PNL_En(TRUE);
    MApi_PNL_SetBackLight(BACKLITE_INIT_SETTING);

    msAPI_OCP_Init();
    InitGOPEnv(0, 0, 960, 540, 960, 1, 1, GOP_BUFFER_ADDR);
    //msAPI_Font_VariableInit();
    //Font[0].fHandle = msAPI_Font_LoadFlashFontToSDRAM(BIN_ID_FONT_BL_ENG_50);
    MApi_GFX_RegisterGetBMPCB(msAPI_OSD_RESOURCE_GetBitmapInfoGFX);
    msAPI_OCP_PrepareBitmapBinary();
    msAPI_OCP_LoadBitmap(Osdcp_bmpHandle1);

    dstbuf.u32ColorFmt = GFX_FMT_RGB565;
    dstbuf.u32Addr = GOP_BUFFER_ADDR;
    dstbuf.u32Pitch = 960*2;
    MApi_GFX_SetDstBufferInfo(&dstbuf, 0);

	// clear screen
    clrBtn.x = 0;
    clrBtn.y = 0;
    clrBtn.width = 960;
    clrBtn.height = 540;
    clrBtn.b_clr = 0x00080808;
    clrBtn.u8Gradient = CONSTANT_COLOR;
    clrBtn.fHighLight = FALSE;
    msAPI_OSD_DrawBlock(&clrBtn);

    clrBtn.x = 228;
    clrBtn.y = 330;
    clrBtn.width = 504;
    clrBtn.height = 10;
    clrBtn.b_clr = 0x00FFFFFF;
    clrBtn.u8Gradient = CONSTANT_COLOR;
    clrBtn.fHighLight = FALSE;
    msAPI_OSD_DrawBlock(&clrBtn);

    clrBtn.x = 229;
    clrBtn.y = 331;
    clrBtn.width = 502;
    clrBtn.height = 8;
    clrBtn.b_clr = 0x00080808;
    clrBtn.u8Gradient = CONSTANT_COLOR;
    clrBtn.fHighLight = FALSE;
    msAPI_OSD_DrawBlock(&clrBtn);

    MApi_GFX_SetAlpha(FALSE, COEF_CONST, ABL_FROM_CONST, 0xFF);
    gbmpfmt.width = 244;
    gbmpfmt.height = 200;
    gbmpfmt.bScale = TRUE;
    gbmpfmt.bBmpColorKeyEnable = FALSE;
    msAPI_OSD_DrawColorKeyBitmap(0,  358, 120, gbmpfmt);

	MApi_GOP_GWIN_Enable(0, TRUE);
    DISPLAY_DBG(printf("logo display end\n"));
}
#endif //(ENABLE_BL_UI)

S32 volatile gS32OffsetTime;

#if 1 //from MApp_Init.c
#if (ENABLE_DTV)
//#include "mapp_demux.h"
#include "mapp_si.h"
#include "MApp_SI_Parse.h"
#include "msAPI_DTVSystem.h"
#include "mapp_eit.h"
#include "MApp_EpgTimer.h"
#endif

#if 0//(ENABLE_DTV && ENABLE_BL_OAD_SCAN)
static void _MApp_DTVInit(void)
{
    MS_SI_INIT_PARAMETER sSIParameter;
 #if (ENABLE_DTV_EPG)
    DTV_CM_INIT_PARAMETER sDTVNotify;
  #if (ENABLE_SBTVD_BRAZIL_APP==0)
    MS_EIT_INIT_PARAMETER sEITInitParameter;
  #endif
 #endif // #if (ENABLE_DTV_EPG)

    /*Clear EPG Timer before loading DataBase*/
  #if ENABLE_DTV_EPG //(ENABLE_DTV)
    MApp_EpgTimer_InitTimerSettings(FALSE);
  #endif

 #if (ENABLE_DTV_EPG)
  #if (ENABLE_SBTVD_BRAZIL_APP==0)
    memset(&sEITInitParameter,0,sizeof(MS_EIT_INIT_PARAMETER));
  #endif
 #endif // #if (ENABLE_DTV_EPG)
    memset(&sSIParameter,0,sizeof(MS_SI_INIT_PARAMETER));

    sSIParameter.u32SIBufferStartAddress = _PA2VA(((SI_MONITOR_DB_MEMORY_TYPE & MIU1) ? (SI_MONITOR_DB_ADR | MIU_INTERVAL) : (SI_MONITOR_DB_ADR)));
    sSIParameter.u32SIBufferSize = SI_MONITOR_DB_LEN;
    sSIParameter.u32SINameBufferAddress = _PA2VA(((SRV_NAME_BUF_MEMORY_TYPE & MIU1) ? (SRV_NAME_BUF_ADR | MIU_INTERVAL) : (SRV_NAME_BUF_ADR)));

  #if (ENABLE_SBTVD_BRAZIL_APP == 0)
    sSIParameter.eSI_Type=SI_PARSER_DVB;
  #else
    sSIParameter.eSI_Type=SI_PARSER_ISDB_ABNT;
  #endif

    sSIParameter.bSkipUnsupportService = FALSE;

  #if (NORDIG_FUNC)
    sSIParameter.bDataServiceSupport = TRUE;
  #else
    sSIParameter.bDataServiceSupport = FALSE;
  #endif
   sSIParameter.bEnableNetworkUpdate = FALSE;
   sSIParameter.bEnableSDTOtherMonitor = FALSE;
  #if (ENABLE_DTV_EPG)
   sSIParameter.bEnableEPG=TRUE;
  #endif
  #if (ENABLE_SBTVD_BRAZIL_APP == 0)
    sSIParameter.pfNotify_PMT = MApp_SI_Parse_PMT;
  #endif
  #if 1//ENABLE_TS_FILEIN
    sSIParameter.pfNotify_FileIn_PMT = MApp_SI_FileIn_Parse_PMT;
  #endif
  #if ENABLE_OAD
    sSIParameter.pfNotify_NIT = MApp_SI_Parse_NIT;
  #endif
  #if ENABLE_CI
    sSIParameter.pfNotify_SDT = MApp_SI_Parse_SDT;
  #endif
  #if (ENABLE_UPDATE_MULTIPLEX_VIA_NIT)
    sSIParameter.pfGetNetworkInfo = MApp_GetNetworkInfo;
  #endif

    MApp_SI_Init(&sSIParameter);

    /* init epg database */
#if (ENABLE_DTV_EPG)
 #if (ENABLE_SBTVD_BRAZIL_APP==0)
    sEITInitParameter.u32PF_BufferAddress =_PA2VA(EIT_PF_STRING_BUF_ADR);
    sEITInitParameter.pfNotify_EIT_Cur_PF=MApp_SI_Parse_EIT;
  #if SUPPORT_PVR_CRID
    if(EVENTDB_SDRAM_LEN>=0x0000840000)
    {
        sEITInitParameter.bEnablePVR_CRID=TRUE;
    }
  #endif
  #if ENABLE_SCHE_EXT
    sEITInitParameter.bEnableScheduleExtendEvent=TRUE;
  #endif
    MApp_EIT_Init(&sEITInitParameter);
 #endif // #if (ENABLE_SBTVD_BRAZIL_APP==0)

    memset(&sDTVNotify,0,sizeof(sDTVNotify));
    sDTVNotify.pfNotify_CM_MoveProgram=MApp_Epg_MoveSrvBuffer;
    sDTVNotify.pfNotify_CM_SwapProgram=MApp_Epg_SwapProgram;
    sDTVNotify.pfNotify_SrvPriorityHandler=MApp_Epg_SrvPriorityHandler;
    sDTVNotify.pfNotify_CM_RemoveProgram=MApp_Epg_RemoveProgram;
    msAPI_CM_Init(&sDTVNotify);

    MApp_EIT_All_Sche_ResetFilter();

    {
        U32 u32EventDbMIUAddrGap = ( (EVENTDB_SDRAM_MEMORY_TYPE&MIU1) ? MIU_INTERVAL : 0x0000000 );
        U32 u32EventDbAddr       = EVENTDB_SDRAM_ADR + u32EventDbMIUAddrGap;
        U32 u32ExtDbMIUAddrGap;//   = ( (EPGEXTDB_SDRAM_MEMORY_TYPE&MIU1) ? MIU_INTERVAL : 0x0000000 );
        U32 u32ExtDbAddr;//         = EPGEXTDB_SDRAM_ADR + u32ExtDbMIUAddrGap;
#if ENABLE_SCHE_EXT
        u32ExtDbMIUAddrGap   = ( (EPGEXTDB_SDRAM_MEMORY_TYPE&MIU1) ? MIU_INTERVAL : 0x0000000 );
        u32ExtDbAddr         = EPGEXTDB_SDRAM_ADR + u32ExtDbMIUAddrGap;
#else
        u32ExtDbMIUAddrGap=u32ExtDbAddr=0;
#endif
  #if SUPPORT_PVR_CRID
        if(EVENTDB_SDRAM_LEN>=0x0000840000)
        {
            MAPP_EPG_SetFunctionFlag(eEN_PVR_CRID);
        }
  #endif

  #if ENABLE_SCHE_EXT
        MAPP_EPG_SetFunctionFlag(eEN_SCHE_EXT);
  #endif
        MApp_EPGDB_Setup(MAX_DTVPROGRAM, _PA2VA(u32EventDbAddr), EVENTDB_SDRAM_LEN, _PA2VA(u32ExtDbAddr), EPGEXTDB_SDRAM_LEN);
        MApp_Epg_Init();

    }
#endif //#if (ENABLE_DTV_EPG)
}
#endif // #if(ENABLE_DTV && ENABLE_BL_OAD_SCAN)
#endif

//from MApp_SaveData.c
#if (EEPROM_DB_STORAGE!=EEPROM_SAVE_ALL)
void MApp_CheckFlash(void)
{
#if ENABLE_OAD
    extern void MApp_DB_LoadChDataBase(void);
    MApp_DB_LoadChDataBase(); //load country setting in database
#endif //ENABLE_OAD
}
#endif

void MApp_BL_Init(void)
{
    //BININFO   BinInfo;
    //BOOLEAN bResult;
    /*MDrv_DMA_CB_Init((eDmaType_t) DRAM_BYTEDMA, DUMMY_ADR,DUMMY_LEN,
                          BMP_INFO_POOL_LEN, BMP_INFO_POOL_ADR,
                          FONT_INFO_POOL_LEN, FONT_INFO_POOL_ADR);*/

    /* initialize all device drivers */
    msAPI_ChipInit();

    msAPI_Interrupt_Init();

    //MApp_Panel_Init();

    //Init Scaler, LVDS...etc
    msAPI_DrvInit();

#if (ENABLE_BL_UI)
	Initial_BL_DisplaySystem();
#endif //(ENABLE_BL_UI)

    //printf("#1\n");
    msAPI_Flash_WriteProtect(ENABLE);

    //msAPI_MIU_Get_BinInfo(&BinInfo, &bResult) ;
    //bResult = Get_BinInfo(&BinInfo);

    /* initialize 8K bytes memory pool */
    msAPI_Memory_Init();

#if (EEPROM_DB_STORAGE != EEPROM_SAVE_ALL)
  #if (ENABLE_BOOTTIME)
    gU32BootStepTime = msAPI_Timer_GetTime0();
  #endif
    MApp_CheckFlash();

  #if (ENABLE_BOOTTIME)
    gU32TmpTime = msAPI_Timer_DiffTimeFromNow(gU32BootStepTime);
    printf("[boot step time]MApp_CheckFlash = %ld\n", gU32TmpTime);
  #endif
#endif //
    //UART_Clear();

#if(ENABLE_DTV && ENABLE_BL_OAD_SCAN)
    _MApp_DTVInit();
#endif

    #if ENABLE_OAD
    //init front end
    msAPI_Tuner_Initialization(1);
    msAPI_Tuner_InitExternDemod();
    #endif

    msAPI_FS_Init();
}
#undef MAPP_BL_INIT_C

