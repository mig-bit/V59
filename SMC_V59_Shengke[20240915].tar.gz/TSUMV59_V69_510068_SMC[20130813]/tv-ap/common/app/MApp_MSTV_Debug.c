
#ifdef OBA_MSTV_DEBUG
#include <stdio.h>
#include <string.h>

//#include "MsCommon.h"// for RIU read write
//#include "Enum_Device.h"
#include "drvUartDebug.h"// for MSTV_Tool
//#include "drvMMIO.h"
#include "madp.h"

//#define UNUSED(x) x=x
extern void MDrv_UART_RecvHandler(int c);


typedef enum
{
    MSTV_DBG_MSG_START,
    MSTV_DBG_MSG_END,
    MSTV_DBG_MSG_CMD,
}MSTV_DBG_MSG;


static U8 _u8ChIndex;
static pid_t _MstvAppPid;

BOOLEAN MApp_MSTV_ReceiveMsg(unsigned char * pu8InData, unsigned short u16InDataSize, unsigned char * pu8OutData, unsigned short u16OutDataSize)
{
    UNUSED(pu8OutData);
    UNUSED(u16OutDataSize);

//    printf("MApp_MSTV_ReceiveMsg. pu8InData[0]:%d\n", pu8InData[0]);
    switch (pu8InData[0])
    {
        case MSTV_DBG_MSG_START:
        {
            // app pid
            memcpy((unsigned char*)&_MstvAppPid, &pu8InData[1], sizeof(pid_t));

            //printf("_MstvAppPid: %d\n", _MstvAppPid);
#if 1
            if( freopen("file.txt", "w", stdout) == NULL)    // use "w" to keep file small, "a+" to log all.
            {
                printf("MApp_MSTV_ReceiveMsg:stdout redirect fail\n");
            }
#endif
            //reset command buffer for MSTV_Tool
            //MDrv_UART_DebugInit();

            break;
        }

        case MSTV_DBG_MSG_CMD: //uart message
        {
            int i;
//            printf("MApp_MSTV_ReceiveMsg: MSTV_DBG_MSG_CMD\n");
            for (i=1; i < u16InDataSize; i++)
            {
//                printf("%x ", pu8InData[i]);
                MDrv_UART_RecvHandler(pu8InData[i]);
            }

            // command packet valid. process the cooamd.
            if(g_bUart0Detected == TRUE)
            {
                if (UART_EXT)   // DLC & DBC
                {
                    MDrv_UART_DecodeExtCommand();
                }
                else    // Normal command: XDATA read/write
                {
                    MDrv_UART_DecodeNormalCommand();
                }
                g_bUart0Detected = FALSE;

                //reset command buffer
                //MDrv_UART_DebugInit();
            }
            break;
        }

        case MSTV_DBG_MSG_END:
        {
#if 1
            if( freopen("/dev/ttyS0", "w", stdout) == NULL)    // use "w" to keep file small, "a+" to log all.
            {
                printf("MApp_MSTV_ReceiveMsg:stdout redirect fail\n");
            }
#endif
            break;
        }

    }

    return TRUE;
}

BOOLEAN MApp_MSTV_SendMsg(unsigned char * pu8InData, unsigned short u16InDataSize, unsigned char * pu8OutData, unsigned short u16OutDataSize)
{
    UNUSED(pu8OutData);
    UNUSED(u16OutDataSize);
//    printf("MApp_MSTV_SendMsg\n");
    return MAdp_MSGCH_SendSignal(_MstvAppPid, _u8ChIndex, pu8InData, u16InDataSize);
}

void MApp_MSTV_Debug_Init(void)
{
    printf("MApp_MSTV_Debug_Init\n");

    MAdp_MSGCH_Init();

    _u8ChIndex = MAdp_MSGCH_GetChannelIndex("MSTV_DEBUG");
    MAdp_MSGCH_SetCallBack(_u8ChIndex, MApp_MSTV_ReceiveMsg);
}
#endif

