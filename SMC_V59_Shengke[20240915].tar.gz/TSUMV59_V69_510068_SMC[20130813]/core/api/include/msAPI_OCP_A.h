////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2008 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (MStar Confidential Information!�L) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef MSAPI_OCP_A_H
#define MSAPI_OCP_A_H

//*************************************************************************
//          Enums
//*************************************************************************
typedef enum
{
    DYNAMICLOAD_JPEGPNG_INIT,
    DYNAMICLOAD_JPEGPNG_ADD,
    DYNAMICLOAD_JPEGPNG_RELOADONE,
    DYNAMICLOAD_JPEGPNG_RELEASE,
} DYNAMICLOAD_JPEGPNG_TYPE;

/********************************************************************************/
/*                   Function Prototypes                     */
/********************************************************************************/
#ifdef MSAPI_OCP_A_C
#define INTERFACE
#else
#define INTERFACE extern
#endif

INTERFACE void msAPI_OCP_LoadJpegPng(MSAPI_JPEGPNGHANDLE* pJpegPngHandle, U16 u16JpegPngBinID, U8 u8JpegNum, U32 u32PreDecodeBufAddr, U32 u32PreDecodeBufSize);
INTERFACE BOOLEAN msAPI_OCP_JpegPng_StLoadInit(MSAPI_JPEGPNGHANDLE* pJpegPngHandle, U8 u8TotalHandleNum, U16 u16JpegPngPacketBinID, U8 u8JPPLoadStMax, U32 u32PreDecodeBufAddr, U32 u32PreDecodeBufSize);
INTERFACE BOOLEAN msAPI_OCP_JpegPng_StLoad(U8 u8JPPLoadSt);
INTERFACE void msAPI_OCP_JpegPng_DyLoadInit(MSAPI_JPEGPNGHANDLE* pJpegPngHandle, U8 u8TotalHandleNum,U32 u32PreDecodeBufAddr, U32 u32PreDecodeBufSize);
INTERFACE void msAPI_OCP_JpegPng_DyLoadRelease(void);
INTERFACE U8 msAPI_OCP_JpegPng_DyLoadFromFlash(U16 u16JpegPngBinID, BOOLEAN bJpegFlg);
INTERFACE U8 msAPI_OCP_JpegPng_DyLoadFromDram(U32 u32DramAddr, U32 u32DramSize, U32 u32TmpBufAddr, BOOLEAN bJpegFlg);
INTERFACE U8 msAPI_OCP_ChannelLogo_DyLoad(U32 u32SrcAddr, U32 u32SrcSize, BOOLEAN bFromFlash, BOOLEAN bJpegFlg);
INTERFACE BOOLEAN msAPI_OCP_JpegPng_DyReload(U8 u8HandleIdx);  //output w*h must same with old, input size must use fixed
INTERFACE void msAPI_OCP_DynamicLoadJpegPng(MSAPI_JPEGPNGHANDLE* pJpegPngHandle, U16* u16JpegPngBinIDList, U8 u8TotalNum, U8 u8JpegNum, U32 u32PreDecodeBufAddr, U32 u32PreDecodeBufSize, DYNAMICLOAD_JPEGPNG_TYPE enLoadType);
INTERFACE void msAPI_OCP_JpegPngSetOutBufInfo(BOOLEAN bOSDBuf);
INTERFACE U32 msAPI_OCP_JpegPngGetOutBufPos(void);
INTERFACE U32 msAPI_OCP_JpegPngGetOutBufLen(void);

#define GetBufAddr(Addr)        (_PA2VA(((Addr & MIU1) ? (Addr | MIU_INTERVAL) : (Addr))))

#undef INTERFACE
#endif

