////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MAPP_ZUI_ACTEPG_H
#define _MAPP_ZUI_ACTEPG_H

#ifdef __cplusplus
extern "C" {
#endif  /* __cplusplus */

#ifdef MAPP_ZUI_ACTEPG_C
#define INTERFACE
#else
#define INTERFACE extern
#endif

INTERFACE U8    g_u8MenuMainItemIndex;
INTERFACE U8    g_u8PrevMenuMainItemIndex;
/////////////////////////////////////////
// Cutomize Window Procedures...
//INTERFACE S32 MApp_ZUI_ACT_EpgRootWinProc(HWND, PMSG);

//#define EPGROOT_WINPROC MApp_ZUI_ACT_EpgRootWinProc

INTERFACE S32 MApp_ZUI_ACT_EpgTitleWinProc(HWND, PMSG);

#define EPGPROGRAMMEGUIDE_TITLE_WINPROC MApp_ZUI_ACT_EpgTitleWinProc

INTERFACE S32 MApp_ZUI_ACT_EpgChannelItemWinProc(HWND,PMSG);

#define EPGPROGRAMMEGUIDE_CHANNELITEM_WINPROC MApp_ZUI_ACT_EpgChannelItemWinProc

INTERFACE S32 MApp_ZUI_ACT_EpgTimeItemWinProc(HWND,PMSG);

#define EPGPROGRAMMEGUIDE_TIMEITEM_WINPROC MApp_ZUI_ACT_EpgTimeItemWinProc

INTERFACE S32 MApp_ZUI_ACT_EpgTimeItemEventWinProc(HWND, PMSG);

#define EPGTIMEITEMEVENT_WINPROC MApp_ZUI_ACT_EpgTimeItemEventWinProc

INTERFACE S32 MApp_ZUI_ACT_EpgChannelItemEventWinProc(HWND, PMSG);

#define EPGCHANNELITEMEVENT_WINPROC MApp_ZUI_ACT_EpgChannelItemEventWinProc

INTERFACE S32 MApp_ZUI_EpgUpdateAllTimeItemWinProc(HWND, PMSG);

#define EPG_UPDATEALLTIMEITEM_WINPROC MApp_ZUI_EpgUpdateAllTimeItemWinProc

INTERFACE S32 MApp_ZUI_ACT_EpgTimePaneWinProc(HWND, PMSG);

#define EPGTIMEPANE_WINPROC MApp_ZUI_ACT_EpgTimePaneWinProc

#if 0
INTERFACE S32 MApp_ZUI_ACT_EpgTimerSettingWinProc(HWND, PMSG);

#define EPG_TIMER_SETTING_WINPROC MApp_ZUI_ACT_EpgTimerSettingWinProc
#endif

INTERFACE S32 MApp_ZUI_ACT_EpgTimerListItemWinProc(HWND, PMSG);

#define EPG_TIMER_LIST_ITEM_WINPROC MApp_ZUI_ACT_EpgTimerListItemWinProc

INTERFACE S32 MApp_ZUI_ACT_EpgTimerSaveDialogWinProc(HWND,PMSG);
#define EPG_TIMER_SAVE_DLG_WINPROC MApp_ZUI_ACT_EpgTimerSaveDialogWinProc

/////////////////////////////////////////
// Event Handlers....
INTERFACE void MApp_ZUI_ACT_AppShowEpg(void);
INTERFACE BOOLEAN MApp_ZUI_ACT_HandleEpgKey(VIRTUAL_KEY_CODE key);
INTERFACE void MApp_ZUI_ACT_TerminateEpg(void);
INTERFACE BOOLEAN MApp_ZUI_ACT_ExecuteEpgAction(U16 act);
INTERFACE LPTSTR MApp_ZUI_ACT_GetEpgDynamicText(HWND hwnd);
INTERFACE U16 MApp_ZUI_ACT_GetEpgDynamicBitmap(HWND hwnd, DRAWSTYLE_TYPE ds_type);
//INTERFACE S16 MApp_ZUI_ACT_GetEpgDynamicValue(HWND hwnd);
INTERFACE void MApp_ZUI_EpgTimerCountDown(void);
//INTERFACE U16 MApp_ZUI_ACT_GetEpgDynamicBitmap(HWND hwnd, DRAWSTYLE_TYPE ds_type);


#undef INTERFACE

#ifdef __cplusplus
}
#endif  /* __cplusplus */

#endif /* _MAPP_ZUI_ACTEPG_H */

