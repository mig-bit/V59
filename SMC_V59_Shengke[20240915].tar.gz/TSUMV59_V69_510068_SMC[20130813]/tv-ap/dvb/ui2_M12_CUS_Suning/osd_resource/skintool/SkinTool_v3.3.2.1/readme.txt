***Prepare to run SkinTool.exe***
1. You MUST have SkinTool.ini in the same folder with SkinTool.exe.
2. If you need LZMA compress function, please have 7lzma.exe in the same folder with SkinTool.exe.
	 And please read SkinTool_LZMA_User_Guide.txt for details.

***Can not run SkinTool.exe***
1. If your SkinTool.exe located in path with Chinese, please rename your folder from Chinese to English.
2. Please install "Microsoft Visual C++ 2005 SP1 Redistributable Package".
