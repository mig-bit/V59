////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef MAPP_INPUTSOURCE_H
#define MAPP_INPUTSOURCE_H

#include "MsCommon.h"
#include "MApp_Exit.h"
#include "MApp_GlobalSettingSt.h"


#ifdef MAPP_INPUTSOURCE_C
#define INTERFACE
#else
#define INTERFACE extern
#endif

//*************************************************************************
//              Function prototypes
//*************************************************************************

INTERFACE void MApp_InputSource_ChangeAudioSource( INPUT_SOURCE_TYPE_t enInputSourceType );
INTERFACE void MApp_InputSource_SwitchSource ( E_UI_INPUT_SOURCE enUiInputSourceType,SCALER_WIN eWindow );
INTERFACE void MAPP_InputSource_SwitchHDMI_DVI( U8 Source_Type);

INTERFACE void MApp_InputSource_RecordSource( E_UI_INPUT_SOURCE enUiInputSourceType);
INTERFACE E_UI_INPUT_SOURCE MApp_InputSource_GetRecordSource(void);
INTERFACE void MApp_InputSource_RestoreSource(void);


//ZUI:
INTERFACE void MApp_InputSource_ChangeInputSource(SCALER_WIN eWindow);
#if (INPUT_SCART_VIDEO_COUNT > 0)
INTERFACE void MApp_InputSource_ScartIOMonitor(void);
#endif

INTERFACE void MApp_InputSource_SetSystemmInfo( E_UI_INPUT_SOURCE enUiInputSourceType, MS_SYS_INFO *penMsSysInfo , E_DATA_INPUT_SOURCE *penDataInpSrcType);

/********************************************************************************/
/*                               Macro                                          */
/********************************************************************************/
#if ENABLE_OFFLINE_SIGNAL_DETECTION
#define AIS_DOS_TIMES   6//10
#define TIMER_STOP      0
#define TIMER_GO        1
#define    DETECT_SOURCE_NUM   4

typedef struct
{
    U8 bUISourceID;
    U8 bLevel;
    U8 bChangeFlag:1;
    U8 bHaveSignal:1;
}_stAISSrcList;

typedef struct
{
    E_UI_INPUT_SOURCE bSrcCnt;
    U8 bUICHSourceFlag;
    U8 bAISSrcPush;
    U32 bSysTimeDuty;
    //BOOLEAN bAISLock;    // 1:lock polling;0:Detect; When Switch Source ,Lock AIS Polling;
    U16 dLockCnt;
    U8 bDotimes;
    U8 strResult[AIS_DOS_TIMES];
    U8 bNoSignal;      //1:NoSignal, 0:Signal in
    U8 bDetectCnt;        //
    U8 bDetectStart;        //
}_stAISCtrl;

INTERFACE _stAISCtrl    stAISCtrl;
INTERFACE _stAISSrcList stAISSrcList[UI_INPUT_SOURCE_NUM];
INTERFACE void MApp_OffLineInit(void);
INTERFACE void MApp_AISMonitor(void);
INTERFACE U8 MApp_MapUIInputTypeToCheckSrc(U8 bUIInput);
#endif

//-----------------------------
// PIP Function
//-----------------------------
#if (ENABLE_PIP)
INTERFACE E_UI_INPUT_SOURCE MApp_InputSource_GetUIInputSourceType(INPUT_SOURCE_TYPE_t stInputSrc);
#endif
INTERFACE INPUT_SOURCE_TYPE_t MApp_InputSource_GetInputSourceType(E_UI_INPUT_SOURCE stInputSrc);
#if (ENABLE_PIP)
INTERFACE void MApp_InputSource_PIP_Swap(void);
INTERFACE BOOLEAN MApp_InputSource_PIP_IsSrcCompatible(INPUT_SOURCE_TYPE_t enSrcMain, INPUT_SOURCE_TYPE_t enSrcSub);
INTERFACE INPUT_SOURCE_TYPE_t MApp_InputSource_PIP_Get1stCompatibleSrc(INPUT_SOURCE_TYPE_t enSrc);
INTERFACE BOOLEAN MApp_InputSource_PIP_GetSubWinRect(MS_WINDOW_TYPE *stWinRect);
INTERFACE void MApp_InputSource_PIP_ChangeAudioSource( SCALER_WIN eWindow );
#endif
INTERFACE void MApp_InputSource_EnableReloadDemod(BOOLEAN bRelaod);
#if (ENABLE_CUS_UI_SPEC && ENABLE_SZ_BLUESCREEN_FUNCTION)
INTERFACE BOOLEAN MApp_InputSource_ResetAspectRatio(void);
#endif
#undef INTERFACE
#endif  /*MAPP_INPUTSOURCE_H*/
