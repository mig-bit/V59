////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MAPP_ZUI_ACTFACTORYMENU_H
#define _MAPP_ZUI_ACTFACTORYMENU_H

#ifdef __cplusplus
extern "C" {
#endif  /* __cplusplus */

#include "MApp_ZUI_APIgdi.h"

#ifdef MAPP_ZUI_ACTFACTORYMENU_C
#define INTERFACE
#else
#define INTERFACE extern
#endif

/////////////////////////////////////////
// Cutomize Window Procedures...


/////////////////////////////////////////
// Event Handlers....
INTERFACE void MApp_ZUI_ACT_AppShowFactoryMenu(void);
INTERFACE BOOLEAN MApp_ZUI_ACT_HandleFactoryMenuKey(VIRTUAL_KEY_CODE key);
INTERFACE void MApp_ZUI_ACT_TerminateFactoryMenu(void);
INTERFACE BOOLEAN MApp_ZUI_ACT_ExecuteFactoryMenuAction(U16 act);//minglin1231
INTERFACE LPTSTR MApp_ZUI_ACT_GetFactoryMenuDynamicText(HWND hwnd);
INTERFACE OSD_COLOR MApp_ZUI_ACT_GetFactorymenuDynamicColor(HWND hwnd, DRAWSTYLE_TYPE type, OSD_COLOR colorOriginal);

INTERFACE S16 MApp_ZUI_ACT_GetHotelMenuVolumeDynamicValue(HWND hwnd);
INTERFACE void _MApp_HotelMode_Load_InputSourceChange(void);


#ifdef ENABLE_CUS_FACTORY_ATV_CH_PRSET
INTERFACE void msAPI_ATV_Factory_CH_Preset(void);
#endif
#if BOE_USB_UPGRADE_FACTROY//minglin1210
INTERFACE void MApp_ZUI_ACT_HandleDatabaseMenuKey(VIRTUAL_KEY_CODE Dkey);
INTERFACE BOOLEAN MApp_SaveRegister_Database(void);
INTERFACE BOOLEAN MApp_SaveRegister_LoadScript(U16 *pu16Data);
INTERFACE BOOLEAN MApp_SaveRegister_NewFile(U16 *pu16Data, U32 filelen);
INTERFACE BOOLEAN MApp_WriteRegister_byte(U16 *pu16Data, U32 filelen);
INTERFACE BOOLEAN MApp_WriteRegister_multibyte(U16 *pu16Data, U32 filelen);
INTERFACE BOOLEAN MApp_WriteRegister_WordData(U16 *pu16Data, U32 filelen);
INTERFACE void MApp_SaveRegisger_OneBank(U16 *pu16Data);
INTERFACE U16 MAPP_SaveRegister_ASCIIToU16string(U16 Value);
INTERFACE void MAPP_SaveRegister_ASCIIToBankadr(U8* u8RegisterString);
INTERFACE void MAPP_SaveRegister_SaveNotWord(U16 u16ScriptLen, U16* pu16Data);
#endif
INTERFACE void MApp_ZUI_FactoryAutoRun(void);


#undef INTERFACE

#ifdef __cplusplus
}
#endif  /* __cplusplus */

#endif /* _MAPP_ZUI_ACTFACTORYMENU_H */

