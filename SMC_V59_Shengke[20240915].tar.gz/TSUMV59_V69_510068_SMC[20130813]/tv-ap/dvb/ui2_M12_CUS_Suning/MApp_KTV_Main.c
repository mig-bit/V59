////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#define MAPP_KTV_MAIN_C

/******************************************************************************/
/*                 Header Files                                               */
/* ****************************************************************************/
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#include "Board.h"
#include "datatype.h"
#include "MsCommon.h"
#include "debug.h"

#ifdef ENABLE_KTV
// Common Definition
#include "apiXC.h"
#include "apiXC_Adc.h"
#include "MApp_GlobalSettingSt.h"

#include "drvISR.h"
#include "apiXC_Sys.h"

#include "MApp_Exit.h"
#include "MApp_Key.h"
#include "MApp_UiMenuDef.h"
#include "MApp_ZUI_Main.h"
#include "MApp_KTV_Main.h"
#include "ZUI_tables_h.inl"
#include "mapp_mplayer.h"
#include "MApp_UiMediaPlayer_Define.h"
#include "IOUtil.h"
#include "InfoBlock.h"
#include "drvCPU.h"
#include "msAPI_CPU.h"

#include "MApp_APEngine.h"
#include "msAPI_APEngine.h"
#include "msAPI_Timer.h"
#include "msAPI_Memory.h"
#include "msAPI_MIU.h"
#include "MsOS.h"
#include "MApp_InputSource.h"
#include "ZUI_exefunc.h"
#include "mapp_videoplayer.h"
#include "SysInit.h"
#include "msAPI_MPEG_Subtitle.h"
#include "MApp_ZUI_ACTKTV.h"
#include "MApp_DMP_Main.h"

#include "drvSOUND.h"
///////////////////////////////////////////////////////////

#define KTV_WAITCONNECT_MS      3000

static EN_KTV_STATE eKTVState = KTV_STATE_INIT;

static EN_KTV_FLAG  eKTVflag = E_KTV_FLAG_NONE;

static ST_KTV_DRV_INFO stKTVDrvInfo;


U16  g_KTVBK_VOL;
U16  g_KTVMIC_VOL;

//MicVolumeTable & BckVolumeTable: (0-1023)   Range: (0dB)(0) --- (-127.875dB)(1023)  step:(-0.125dB).
ROM WORD Bk_VolumeTable[] =
{
    0x3ff,
    0x2dd, 0x2ce, 0x2bf, 0x2b0, 0x2a1, 0x292, 0x283, 0x274, 0x265, 0x256,
    0x247, 0x238, 0x22e, 0x224, 0x21a, 0x210, 0x206, 0x1fc, 0x1f2, 0x1e8,
    0x1de, 0x1d4, 0x1d0, 0x1cc, 0x1c8, 0x1c4, 0x1c0, 0x1bc, 0x1b8, 0x1b4,
    0x1b0, 0x1ac, 0x1a8, 0x1a4, 0x1a0, 0x19c, 0x198, 0x194, 0x190, 0x18c,
    0x188, 0x184, 0x180, 0x17c, 0x178, 0x174, 0x170, 0x16c, 0x168, 0x164,
    0x160, 0x15c, 0x158, 0x154, 0x150, 0x14c, 0x148, 0x144, 0x140, 0x13c,
    0x138, 0x134, 0x130, 0x12c, 0x128, 0x124, 0x120, 0x11c, 0x118, 0x114,
    0x110, 0x10c, 0x108, 0x104, 0x100, 0xfc, 0xf8, 0xf4, 0xf0, 0xec,
    0xe8, 0xe4, 0xe0, 0xdc, 0xd8, 0xd4, 0xd0, 0xcc, 0xc8, 0xc4,
    0xc0, 0xbc, 0xb8, 0xb4, 0xb0, 0xac, 0xa8, 0xa4, 0xa0, 0x9c
};

ROM WORD Mic_VolumeTable[] =
{
    0x3ff,
    0x1a7, 0x1a1, 0x19b, 0x195, 0x18f, 0x189, 0x183, 0x17d, 0x177, 0x171,
    0x16b, 0x165, 0x160, 0x15b, 0x156, 0x151, 0x14c, 0x147, 0x142, 0x13d,
    0x138, 0x133, 0x12f, 0x12b, 0x127, 0x123, 0x11f, 0x11b, 0x117, 0x113,
    0x10f, 0x10b, 0x107, 0x103, 0xff, 0xfb, 0xf7, 0xf3, 0xef, 0xeb, 0xe7,
    0xe3, 0xdf, 0xdb, 0xd7, 0xd3, 0xcf, 0xcb, 0xc7, 0xc3, 0xbf, 0xbb, 0xb7,
    0xb3, 0xaf, 0xab, 0xa7, 0xa3, 0x9f, 0x9b, 0x97, 0x93, 0x8f, 0x8b, 0x87,
    0x83, 0x7f, 0x7b, 0x77, 0x73, 0x6f, 0x6b, 0x67, 0x63, 0x5f, 0x5b, 0x57, 0x53,
    0x4f, 0x4b, 0x47, 0x43, 0x3f, 0x3b, 0x37, 0x33, 0x2f, 0x2b, 0x27, 0x23, 0x1f,
    0x1b, 0x17, 0x13, 0xf, 0xb, 0x7, 0x3, 0x02, 0x0
};

#if 0
static enumKTVFlags _eKTVFlag=E_KTV_FLAG_NONE;
static U8           _u8CurrentDriveIdx = 0;

static void _MApp_KTV_Main_Init(void)
{
    if(!(_eKTVFlag&E_KTV_FLAG_INITED))
    {
        MApp_MPlayer_InitializeKernel();
        MApp_DMP_SetCurDrvIdxAndCalPageIdx(0);

       if( LKTM_Init() )
        {
        	printf( "LKTM_Init() call success!" );
        }
        else
        {
        	printf( "LKTM_Init() call failed!" );
        }
        _eKTVFlag |= E_KTV_FLAG_INITED;
    }
}

static void _MApp_KTV_Switch2KTV(void)
{
    MApi_AUDIO_AbsoluteBass(0);  // set the bass to 0 to avoid voice broken
    //add switch KTV AP code in here
    if(_eKTVFlag & E_KTV_FLAG_INITED)
    {
        _eKTVFlag = E_KTV_FLAG_INITED;
        if(MApp_MPlayer_ConnectDrive(_u8CurrentDriveIdx) == E_KTV_RET_OK)
        {
            _eKTVFlag |= E_KTV_FLAG_DRIVE_CONNECT_OK;
        }
    }
    else
    {
        _MApp_KTV_Main_Init();
    }
    eLastKTVState=KTV_STATE_INIT;
}
#endif

void MApp_KTV_SetBGVolume(U8 u8Volume)
{
    g_KTVBK_VOL=Bk_VolumeTable[u8Volume];
    MApi_AUDIO_SetMixModeVolume(E_AUDIO_INFO_KTV_IN, MP3_VOL,(MS_U8)((g_KTVBK_VOL>>3) &0xff), (MS_U8)(g_KTVBK_VOL & 0x07));
}

void MApp_KTV_SetMicVolume(U8 u8Volume)
{
    g_KTVMIC_VOL=Mic_VolumeTable[u8Volume];
    MApi_AUDIO_SetMixModeVolume(E_AUDIO_INFO_KTV_IN, MIC_VOL,(MS_U8)((g_KTVMIC_VOL>>3) &0xff), (MS_U8)(g_KTVMIC_VOL & 0x07));
}

void MApp_KTV_SetMixVolume(U8 u8Volume)
{
    MDrv_SOUND_SetSurroundXA((MS_U8)((u8Volume) &0x03));
    MDrv_SOUND_SetSurroundXB((MS_U8)((u8Volume>>2) &0x03));
    MDrv_SOUND_SetSurroundXK((MS_U8)((u8Volume>>4) &0x03));
}

static void MApp_KTV_Init(void)
{
    if(!(eKTVflag & E_KTV_FLAG_INITED))
    {
        KTV_DBG(printf("MApp_KTV_Init()\n"));

        MApp_MPlayer_InitializeKernel();
        MApp_KTV_SetCurDrvIdxAndCalPageIdx(0);

        MApp_MPlayer_SetRepeatMode(E_MPLAYER_REPEAT_ALL);
        MApp_MPlayer_EnableNotify(E_MPLAYER_NOTIFY_ALL, TRUE);
        // TODO: this line may be redundant?
        //MApp_MPlayer_SetCurrentMediaType(E_MPLAYER_TYPE_PHOTO, FALSE);

        MApp_MPlayer_DisableSubtitle();

      #if defined(MIPS_CHAKRA) || defined(MSOS_TYPE_LINUX) || defined(__AEONR2__)
        msAPI_COPRO_Init(BIN_ID_CODE_VDPLAYER,((AEON_MEM_MEMORY_TYPE & MIU1) ? (AEON_MM_MEM_ADR | MIU_INTERVAL) : (AEON_MM_MEM_ADR)),AEON_MM_MEM_LEN);
      #else
        msAPI_COPRO_Init(BIN_ID_CODE_VDPLAYER,((BEON_MEM_MEMORY_TYPE & MIU1) ? (BEON_MEM_ADR | MIU_INTERVAL) : ( BEON_MEM_ADR)),BEON_MEM_LEN);
      #endif

        eKTVflag |= E_KTV_FLAG_INITED;

        MApi_AUDIO_SetCommAudioInfo(Audio_Comm_infoType_ADC_InputGain, (AUD_ADC_GAIN_TYPE)AUD_ADC_GAIN_9dB, 0);//bill.dong 2011.3.24 for ktv vol
        //MApi_AUDIO_SetMpegInfo(Audio_MPEG_infoType_SoundMode, 3, 0);
        MApp_KTV_SetBGVolume(stGenSetting.g_SoundSetting.KTVBGVolume);
        MApp_KTV_SetMicVolume(stGenSetting.g_SoundSetting.KTVMicVolume);
        if(stGenSetting.g_SoundSetting.KTVMixVolume == 0)
            MApi_AUDIO_EnableSurround(FALSE);
        else
            MApi_AUDIO_EnableSurround(TRUE);
        MApp_KTV_SetMixVolume(stGenSetting.g_SoundSetting.KTVMixVolume);
    }
}


static void MApp_KTV_Switch2KTV(void)
{
    MApi_AUDIO_AbsoluteBass(0);  // set the bass to 0 to avoid voice broken

    if( MApp_MPlayer_SetCurrentMediaType(E_MPLAYER_TYPE_MUSIC, TRUE) == E_MPLAYER_RET_FAIL)
    {
        KTV_DBG(printf("MApp_MPlayer_SetCurrentMediaType fail"););
    }

    if(eKTVflag & E_KTV_FLAG_INITED)
    {
        KTV_DBG(printf("\n\n\n*******************MApp_KTV_Reset()\n"));
        MApp_KTV_Reset();
        MApp_MPlayer_ConnectDrive(stKTVDrvInfo.au8MapTbl[stKTVDrvInfo.u8Idx]);
    }
    else
    {
        KTV_DBG(printf("\n\n\n*******************_MApp_KTV_Init()\n"));
        MApp_KTV_Init();
    }

    return;
}

void  MApp_KTV_LoadCOPRO (void)
{
#if defined(MIPS_CHAKRA) || defined(MSOS_TYPE_LINUX) || defined(__AEONR2__)
    msAPI_COPRO_Init(BIN_ID_CODE_VDPLAYER,((AEON_MEM_MEMORY_TYPE & MIU1) ? (AEON_MM_MEM_ADR | MIU_INTERVAL) : (AEON_MM_MEM_ADR)),AEON_MM_MEM_LEN);
#else
    msAPI_COPRO_Init(BIN_ID_CODE_VDPLAYER,((BEON_MEM_MEMORY_TYPE & MIU1) ? (BEON_MEM_ADR | MIU_INTERVAL) : ( BEON_MEM_ADR)),BEON_MEM_LEN);
#endif
}

void MApp_KTV_Exit(void)
{
    KTV_DBG(printf("\nMApp_KK_KTV_Exit\n"));
    eKTVState = KTV_STATE_INIT;
    MApp_MPlayer_StopPreview();
    if(eKTVflag & E_KTV_FLAG_BGM_MODE)
    {
        MApp_MPlayer_StopMusic();
    }
    if(eKTVflag & E_KTV_FLAG_MEDIA_FILE_PLAYING)
    {
        MApp_MPlayer_Stop();
    }
    eKTVflag = E_KTV_FLAG_NONE;
    //MApp_ZUI_API_StoreFocusCheckpoint(HWND_DMP_MEDIA_TYPE_PHOTO);
    MApp_MPlayer_ExitMediaPlayer();

    MDrv_COPRO_Disable();

    MsOS_EnableInterrupt(E_INT_IRQ_TSP2HK);

    MApi_AUDIO_SetCommAudioInfo(Audio_Comm_infoType_ADC_InputGain, (AUD_ADC_GAIN_TYPE)AUD_ADC_GAIN_NEG_6dB, 0);//bill.dong 2011.3.24 for ktv vol
}

void MApp_KTV_Reset(void)
{
    KTV_DBG(printf("\nMApp_KTV_Reset()\n"));

    MApp_KTV_SetCurDrvIdxAndCalPageIdx(0);

    eKTVflag = E_KTV_FLAG_INITED;

    MApp_MPlayer_SetRepeatMode(E_MPLAYER_REPEAT_ALL);
}

void MApp_KTV_SetState(EN_KTV_STATE eState)
{
    eKTVState = eState;
}

void MApp_KTV_InitKTVStatus(void)
{
    KTV_DBG(printf("MApp_KTV_InitKTVStat\n"));
    eKTVState = KTV_STATE_INIT;
    eKTVflag = E_KTV_FLAG_NONE;
}

EN_RET MApp_KTV_Main(void)
{
    EN_RET enRetVal = EXIT_KTV_NULL;
    static U32 u32time = 0;

    switch(eKTVState)
    {
        case KTV_STATE_INIT:
            srand(msAPI_Timer_GetTime0());
            u32time = msAPI_Timer_GetTime0();
            MApp_ZUI_ACT_StartupOSD(E_OSD_KTV);
            MApp_KTV_Switch2KTV();
            eKTVState = KTV_STATE_CONNECTING;
            break;
        case KTV_STATE_CONNECTING:
            if(msAPI_Timer_DiffTimeFromNow(u32time) > KTV_WAITCONNECT_MS
                || (eKTVflag & E_KTV_FLAG_DRIVE_CONNECT_OK))
                eKTVState = KTV_STATE_WAIT;
            break;
        case KTV_STATE_WAIT:
            MApp_ZUI_ProcessKey(u8KeyCode);
            u8KeyCode = KEY_NULL;
            break;
        case KTV_STATE_CLEAN_UP:
            MApp_ZUI_ACT_ShutdownOSD();
            eKTVState = KTV_STATE_INIT;
            break;
        case KTV_STATE_GOTO_STANDBY:
            MApp_ZUI_ACT_ShutdownOSD();
            u8KeyCode = KEY_POWER;
            enRetVal = EXIT_KTV_GOTO_STANDBY;
            break;
        case KTV_STATE_GOTO_MENU:
            MApp_ZUI_ACT_ShutdownOSD();
            eKTVState = KTV_STATE_INIT;
            enRetVal = EXIT_KTV_GOTO_MENU;
            break;
        case KTV_STATE_GOTO_INPUTSOURCE:
            MApp_ZUI_ACT_ShutdownOSD();
            eKTVState = KTV_STATE_INIT;
            enRetVal = EXIT_KTV_GOTO_INPUTSOURCE;
            break;
        case KTV_STATE_GOTO_PRESOURCE:
            MApp_ZUI_ACT_ShutdownOSD();
            eKTVState = KTV_STATE_INIT;
            enRetVal = EXIT_CLOSE;
            MApp_DMP_Exit();
        #if( ENABLE_DMP_SWITCH )
            if((UI_PREV_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_DMP1)
                ||(UI_PREV_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_DMP2))
        #else
            if(UI_PREV_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_DMP)
        #endif
            {
                UI_PREV_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_ATV;
            }
            MApp_InputSource_RestoreSource();

        #ifdef ATSC_SYSTEM
            MApp_ZUI_ACT_StartupOSD(E_OSD_CHANNEL_INFO);
        #else
            if(IsAnyTVSourceInUse())
            {
                MApp_ZUI_ACT_StartupOSD(E_OSD_CHANNEL_INFO);
                MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_SHOW_BRIEF_CH_INFO);
            }
            else//non DTV/ATV sources
            {
                MApp_ZUI_ACT_StartupOSD(E_OSD_CHANNEL_INFO);
                MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_SHOW_SOURCE_BANNER);
            }
        #endif
            break;
    }
    return enRetVal;
}

void MApp_KTV_SetFlag(EN_KTV_FLAG flag)
{
    KTV_DBG(printf("set Flag %u\n",flag););
    eKTVflag |= (EN_KTV_FLAG)flag;
}

void MApp_KTV_ClearFlag(EN_KTV_FLAG flag)
{
    KTV_DBG(printf("clear Flag %u\n",flag););
    eKTVflag &= (EN_KTV_FLAG)~flag;
}

EN_KTV_FLAG MApp_KTV_GetFlag(void)
{
    return eKTVflag;
}

U8 MApp_KTV_GetCurDrvIdx(void)
{
    return stKTVDrvInfo.u8Idx;      //drive idx is ZERO base
}

U8 MApp_KTV_GetDrvPageIdx(void)
{
    return stKTVDrvInfo.u8PageIdx;  //page idx is NONE-ZERO base
}

void MApp_KTV_SetCurDrvIdxAndCalPageIdx(U8 u8Idx)
{
    stKTVDrvInfo.u8Idx = u8Idx;

    stKTVDrvInfo.u8PageIdx = ((u8Idx+1) / KTV_DRIVE_NUM_PER_PAGE) + 1; //page idx is NONE-ZERO base
}

void MApp_KTV_SetDrvPageIdx(U8 u8Idx)
{
    stKTVDrvInfo.u8PageIdx = u8Idx;
}

U8 MApp_KTV_GetDriveFromMappingTable(U8 u8Idx)
{
    return stKTVDrvInfo.au8MapTbl[u8Idx];
}

BOOLEAN MApp_KTV_RecalculateDriveMappingTable(void)
{
    MPlayerDrive driveInfo;
    BOOLEAN bConnect = FALSE;
    U8 i, /*j,*/ driveIdx, count=0;

    if(MApp_MPlayer_QueryCurrentDeviceIndex() == E_MPLAYER_USB0 ||
        MApp_MPlayer_QueryCurrentDeviceIndex() == E_MPLAYER_USB1)
    {
    // TODO: need to refine for loop!? 20090824
        KTV_DBG(printf("[KTV] Total Drives : %u\n", MApp_MPlayer_QueryTotalDriveNum()));
        memset(stKTVDrvInfo.au8MapTbl, 0xFF, sizeof(U8)*NUM_OF_MAX_DRIVE);
        //for(j = 0; j < NUM_OF_MAX_DRIVE; j++)
        //{//Sorting the partition table.
            for(i = 0; i < NUM_OF_MAX_DRIVE; i++)
            {
                driveIdx = MApp_MPlayer_QueryPartitionIdxInDrive(i, &driveInfo);

                if(driveIdx != 0xFF && driveInfo.eDeviceType != E_MPLAYER_INVALID
                    /*&&j == driveInfo.u8Partition*/)
                {
                    bConnect = TRUE;
                    DMP_DBG(printf("[DMP] %u USB%u  LUN%u   Partition%u\n", driveIdx, (U8)driveInfo.eDeviceType, driveInfo.u8Lun, driveInfo.u8Partition);)
                    {
                        stKTVDrvInfo.au8MapTbl[count++] = driveInfo.u8Partition;
                    }
                }
            } //end of i
        //} //end of j
    }

    return bConnect;
}

#endif

#undef MAPP_KTV_MAIN_C

