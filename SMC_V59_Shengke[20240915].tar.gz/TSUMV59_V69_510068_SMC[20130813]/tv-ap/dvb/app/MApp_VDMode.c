////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#define MAPP_VDMODE_C

//------------------------------------------------------------------------------
// Includes
//------------------------------------------------------------------------------
#include <stdio.h>

#include "Board.h"
#include "datatype.h"
#include "msAPI_Global.h"
#include "msAPI_VD.h"
#include "apiXC.h"
#include "apiXC_Adc.h"
#include "apiXC_Sys.h"

#include "MApp_GlobalSettingSt.h"
#include "MApp_VDMode.h"
#include "MApp_PCMode.h"
#include "MApp_Scaler.h"
#include "MApp_GlobalFunction.h"
#if ENABLE_SW_CH_FREEZE_SCREEN
#include "MApp_GlobalVar.h"
#endif
EN_VD_SIGNALTYPE g_ePreVideoSystem = SIG_NONE; //previous PAL/NTSC standard for ATV channel change
//------------------------------------------------------------------------------
// Function name:        MApp_VD_IsSyncLock
// Passing parameter:    none
// Return parameter:     BOOLEAN:    video decoder sync lock or not
// Description:          Get video decoder sync lock status
//------------------------------------------------------------------------------
BOOLEAN MApp_VD_IsSyncLock(void)
{
    BOOLEAN bIsSyncDetected;

    bIsSyncDetected = msAPI_AVD_IsSyncLocked();

    return bIsSyncDetected;
}

//------------------------------------------------------------------------------
// Function name:        MApp_VD_SetMode
// Passing parameter:    none
// Return parameter:     none
// Description:          Set VD mode settings
//------------------------------------------------------------------------------
BOOLEAN MApp_VD_SetMode ( SCALER_WIN eWindow )
{
    U8 u8TurnOffDestination = DISABLE;

  #if (ENABLE_SW_CH_FREEZE_SCREEN)
    if (MApp_IsSrcHasSignal(eWindow) && IsSrcTypeATV(SYS_INPUT_SOURCE_TYPE(eWindow)))
    {
        msApi_VD_ResetPreVideoSystem();

        if(g_bIsImageFrozen)
        {
            g_bIsImageFrozen = FALSE;
            MApi_XC_FreezeImg(g_bIsImageFrozen, MAIN_WINDOW);
        }
        }
        #endif


    // Trigger sync event. Make all destination setup its own environment
    if (MApp_IsSrcHasSignal(eWindow) || IsSrcTypeATV(SYS_INPUT_SOURCE_TYPE(eWindow)))
        {
            MApi_XC_ADC_Source_Calibrate(SYS_INPUT_SOURCE_TYPE(eWindow));
    #if (ENABLE_SW_CH_FREEZE_SCREEN)
        if((IsSrcTypeATV(SYS_INPUT_SOURCE_TYPE(eWindow)) && (mvideo_vd_get_videosystem() != g_ePreVideoSystem)) ||
           !(IsSrcTypeATV(SYS_INPUT_SOURCE_TYPE(eWindow))))
    #endif
    {
            //No need to set window and timing if same ATV systems
        MApi_XC_Mux_TriggerPathSyncEvent(SYS_INPUT_SOURCE_TYPE(eWindow),NULL);
    }
            if(MApp_IsSrcHasSignal(eWindow) )
            {
                        g_ePreVideoSystem = mvideo_vd_get_videosystem();
            }
            else 
            {
                        g_ePreVideoSystem=SIG_NONE;
            }
    }

    //Set CVBS out ATV for all source without DTV 20100420EL
    if (MApp_IsSrcHasSignal(eWindow) || (IsSrcTypeATV(SYS_INPUT_SOURCE_TYPE(eWindow))))
    {
        u8TurnOffDestination = ENABLE;

        // signal detected. Enable all destination.
        if(IsSrcTypeDigitalVD(SYS_INPUT_SOURCE_TYPE(eWindow)))
        {
            //Set CVBS out ATV for all source without DTV 20100420EL
                MApi_XC_Mux_TriggerDestOnOffEvent(SYS_INPUT_SOURCE_TYPE(eWindow),&u8TurnOffDestination);
            MApi_XC_Mux_TriggerDestOnOffEvent(SYS_CVBS1_OUT_SOURCE_TYPE(eWindow), &u8TurnOffDestination);
            }

#if(PATCH_FOR_V_RANGE)
        if(IsSrcTypeATV(SYS_INPUT_SOURCE_TYPE(eWindow)))
            MApp_VD_StartRangeHandle();
#endif
    }
    else
    {
        u8TurnOffDestination = DISABLE;

        // disable destination
        if(IsSrcTypeDigitalVD(SYS_INPUT_SOURCE_TYPE(eWindow)))
        {
                MApi_XC_Mux_TriggerDestOnOffEvent(SYS_INPUT_SOURCE_TYPE(eWindow),&u8TurnOffDestination);
            }
    }

    return TRUE;
}

#if(PATCH_FOR_V_RANGE)
static U16 u16PreVtotal;

#define	VD_NONST_DEBUG(x)       x

void MApp_VD_RangeReset(void)
{
    u16PreVtotal = 0;
}

void MApp_VD_StartRangeHandle(void)
{
    U16 wVtotal = msAPI_Scaler_VD_GetVTotal(MAIN_WINDOW, SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW), GET_SYNC_DIRECTLY, NULL);
    if ((wVtotal < 675 ) && (wVtotal > 570))
        u16PreVtotal = 625;
    else
        u16PreVtotal = 525;
}

void MApp_VD_SyncRangeHandler(void)
{
    U16 wVtotal = msAPI_Scaler_VD_GetVTotal(MAIN_WINDOW, SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW), GET_SYNC_DIRECTLY, NULL);
    U16 g_cVSizeShift = 0;
    U16 u16V_CapSize;
	U16 u16_VCapSt;
    MS_WINDOW_TYPE stCaptureWin;
    static U8 u8SyncStableCounter = 6;

    if (!IsSrcTypeATV(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)))
        return;

    if (!MApp_IsSrcHasSignal(MAIN_WINDOW))
        return;

    if(msAPI_Tuner_IsTuningProcessorBusy())
        return;

    if (u16PreVtotal == 0)
        return;

  #if ENABLE_SW_CH_FREEZE_SCREEN
    if (msApi_VD_ChannelChangeStatus_Check()==FALSE)
        return;
  #endif

    if ((wVtotal < 620) && (wVtotal > 570))
    {
        if (u16PreVtotal != wVtotal)
        {
            u16PreVtotal  = wVtotal;
            u8SyncStableCounter = 0;
        }
        else if (u8SyncStableCounter < 5)
            u8SyncStableCounter ++;
    }
    else if (((wVtotal < 520) && (wVtotal > 470)) || ((wVtotal > 530) && (wVtotal < 570)))
    {
        if (u16PreVtotal != wVtotal)
        {
            u16PreVtotal  = wVtotal;
            u8SyncStableCounter = 0;
        }
        else if (u8SyncStableCounter < 5)
            u8SyncStableCounter ++;
    }
    else if(((wVtotal <= 630) && (wVtotal >= 620)) || ((wVtotal <= 530) && (wVtotal >= 520)))
    {
        if((u16PreVtotal > (wVtotal + 5)) || (u16PreVtotal < (wVtotal - 5)))
        {
            u16PreVtotal  = wVtotal;
            u8SyncStableCounter = 0;
        }
        else if (u8SyncStableCounter < 5)
            u8SyncStableCounter ++;
    }

    if(u8SyncStableCounter == 5)
    {
        VD_NONST_DEBUG(printf("Vtotal[%d]\n",wVtotal));

        MApi_XC_GetCaptureWindow(&stCaptureWin, MAIN_WINDOW);

        u8SyncStableCounter = 6;
        u16V_CapSize = stCaptureWin.height;
	  u16_VCapSt = stCaptureWin.y;

        if (((wVtotal < 620) && (wVtotal > 570)) || ((wVtotal > 630) && (wVtotal < 670)))
        {
            if (wVtotal > 625)
            {
                g_cVSizeShift = wVtotal - 625;
                u16V_CapSize = 576 + g_cVSizeShift;
            }
            else
            {
                g_cVSizeShift = 625 - wVtotal;
                u16V_CapSize = 576 - g_cVSizeShift;     //576 is waite factory menu
            }
        }
        else if (((wVtotal < 520) && (wVtotal > 470)) || ((wVtotal > 530) && (wVtotal < 570)))
        {
            if (wVtotal > 525)
            {
                g_cVSizeShift = wVtotal - 525;
                u16V_CapSize = 480 + g_cVSizeShift;
            }
            else
            {
                g_cVSizeShift = 525 - wVtotal;
                u16V_CapSize = 480 - g_cVSizeShift;
            }
        }

        VD_NONST_DEBUG(printf("x:%d,y:%d,w:%d,h:%d\n",stCaptureWin.x,stCaptureWin.y,stCaptureWin.width,stCaptureWin.height));

        stCaptureWin.height =  u16V_CapSize;
        MApp_Scaler_SetCustomerWindow(&stCaptureWin, NULL, NULL, MAIN_WINDOW);
    }
}
#endif


#undef MAPP_VDMODE_C

