////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#define MAPP_ZUI_ACTFACTORYHOTKEY_C
#define _ZUI_INTERNAL_INSIDE_ //NOTE: for ZUI internal

//-------------------------------------------------------------------------------------------------
// Include Files
//-------------------------------------------------------------------------------------------------
// Common Definition
#include "Board.h"
#include "datatype.h"
#include "MsCommon.h"
#include "apiXC.h"
#include "apiXC_Adc.h"
#include "MApp_GlobalSettingSt.h"
#if ENABLE_CUS_FACTORY_HOTKEY_MENU

#include "msAPI_Video.h"

#include "MApp_ZUI_Main.h"
#include "MApp_ZUI_APIcommon.h"
#include "MApp_ZUI_APIstrings.h"
#include "MApp_ZUI_APIwindow.h"
#include "ZUI_tables_h.inl"
#include "MApp_ZUI_APIgdi.h"
#include "MApp_ZUI_APIcontrols.h"
#include "MApp_ZUI_ACTeffect.h"
#include "MApp_ZUI_ACTglobal.h"
#include "OSDcp_String_EnumIndex.h"
#include "ZUI_exefunc.h"
#include "MApp_ZUI_ACTfactoryhotkey.h"
#include "MApp_UiMenuDef.h"
#include "MApp_SaveData.h"
#include "MApp_Sleep.h"
#include "MApp_GlobalFunction.h"
#include "MApp_Scaler.h"
#include "MApp_XC_PQ.h"
#include "msAPI_audio.h"
#include "MApp_MVDMode.h"
#include "MApp_TopStateMachine.h"
#include "MApp_ZUI_ACTmenufunc.h"
#if MHEG5_ENABLE
#include "MApp_MHEG5_Main.h"
#endif
#include "msAPI_Timer.h"
#include "MApp_PCMode.h"
#include "apiXC.h"
#include "MApp_XC_PQ.h"
#include "MApp_InputSource.h"
#if ENABLE_TTX
#include "mapp_ttx.h"
#endif
#if (MWE_FUNCTION)
#include "apiXC_Ace.h"
#endif
#include "drvPQ.h"
#include "apiXC_Sys.h"
#include "MApp_MultiTasks.h"
#include "MApp_ZUI_ACTfactorymenu.h"
#include "MApp_ZUI_ACTmenufunc.h"

#include "MApp_OSDPage_Main.h"


/////////////////////////////////////////////////////////////////////

static FACTORY_HOTKEY_MODE _eFactoryHotkeyMode;








void MApp_ZUI_ACT_SetFactoryHotkeyMode(FACTORY_HOTKEY_MODE eFactoryHotkeyMode)
{
    printf("set Fac hotkey mode [%bu]\n",(U8)eFactoryHotkeyMode);
    _eFactoryHotkeyMode = eFactoryHotkeyMode;
}

FACTORY_HOTKEY_MODE MApp_ZUI_ACT_GetFactoryHotkeyMode(void)
{
    return _eFactoryHotkeyMode;
}

extern BOOLEAN _MApp_ZUI_API_AllocateVarData(void);


void MApp_ZUI_ACT_AppShowFactoryHotkeyOption(void)
{
    HWND wnd;
    RECT rect;
    E_OSD_ID osd_id = E_OSD_FACTORY_HOTKEY_OPTION;

    g_GUI_WindowList = GetWindowListOfOsdTable(osd_id);
    g_GUI_WinDrawStyleList = GetWindowStyleOfOsdTable(osd_id);
    g_GUI_WindowPositionList = GetWindowPositionOfOsdTable(osd_id);
#if ZUI_ENABLE_ALPHATABLE
    g_GUI_WinAlphaDataList = GetWindowAlphaDataOfOsdTable(osd_id);
#endif
    HWND_MAX = GetWndMaxOfOsdTable(osd_id);
    OSDPAGE_BLENDING_ENABLE = IsBlendingEnabledOfOsdTable(osd_id);
    OSDPAGE_BLENDING_VALUE = GetBlendingValueOfOsdTable(osd_id);

    if (!_MApp_ZUI_API_AllocateVarData())
    {
        ZUI_DBG_FAIL(printf("[ZUI]ALLOC\n"));
        ABORT();
        return;
    }

    RECT_SET(rect,
        ZUI_FACTORY_HOTKEY_OPTION_XSTART, ZUI_FACTORY_HOTKEY_OPTION_YSTART,
        ZUI_FACTORY_HOTKEY_OPTION_WIDTH, ZUI_FACTORY_HOTKEY_OPTION_HEIGHT);

    if (!MApp_ZUI_API_InitGDI(&rect))
    {
        ZUI_DBG_FAIL(printf("[ZUI]GDIINIT\n"));
        ABORT();
        return;
    }

    for (wnd = 0; wnd < HWND_MAX; wnd++)
    {
        //printf("create msg: %lu\n", (U32)wnd);
        MApp_ZUI_API_SendMessage(wnd, MSG_CREATE, 0);
    }

    MApp_ZUI_API_ShowWindow(HWND_MAINFRAME, SW_SHOW);
    MApp_ZUI_API_SetFocus(HWND_FACTORY_HOTKEY_OPTION_TEXT);

    //_eFactoryHotkeyMode = EN_FACTORY_HOTKEY_MODE_INVALID;

    //MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_PAGE_SHOWUP, E_ZUI_STATE_RUNNING);

}


//////////////////////////////////////////////////////////
// Key Handler

BOOLEAN MApp_ZUI_ACT_HandleFactoryHotkeyOptionKey(VIRTUAL_KEY_CODE key)
{
    //note: don't do anything here! keys will be handled in state machines
    //      moved to MApp_TV_ProcessAudioVolumeKey()
    UNUSED(key);
    ZUI_DBG_FAIL(printf("[ZUI]IDLEKEY\n"));
    //ABORT();
    return FALSE;
}

void MApp_ZUI_ACT_TerminateFactoryHotkeyOption(void)
{
    ZUI_MSG(printf("[]term:FactoryHotkey\n");)
    _eFactoryHotkeyMode = EN_FACTORY_HOTKEY_MODE_INVALID;
    //enFactoryHotkeyOptionState = _enTargetFactoryHotkeyOptionState;

}

BOOLEAN MApp_ZUI_ACT_ExecuteFactoryHotkeyOptionAction(U16 act)
{

    switch(act)
    {
        case EN_EXE_CLOSE_CURRENT_OSD:
        case EN_EXE_POWEROFF:
            _eFactoryHotkeyMode = EN_FACTORY_HOTKEY_MODE_INVALID;
			// CUS_XM Xue 20120724: show preset channel tabel 
	     MApp_OSDPage_SetState(STATE_OSDPAGE_EXIT);
            MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
            return TRUE;

        case EN_EXE_RESET_AUTO_CLOSE_TIMER:
            //reset timer if any key
            MApp_ZUI_API_ResetTimer(HWND_FACTORY_HOTKEY_OPTION_BG, 0);
            return FALSE;
    }
    return FALSE;
}
// CUS_XM Xue 20120724: show preset channel tabel 
extern U16 _MApp_ZUI_ACT_GetAudioModeStringID(void);

LPTSTR MApp_ZUI_ACT_GetFactoryHotkeyOptionDynamicText(HWND hwnd)
{
    U16 u16TempID = Empty;
    // TODO:
    //CUS_XM:xue add for factory show key operation information 2012-7-6
	switch(hwnd)
	{
		case HWND_FACTORY_HOTKEY_OPTION_TEXT:
		switch(_eFactoryHotkeyMode)
		{
			case  EN_FACTORY_HOTKEY_MODE_FACTORY_RC_RST:
					u16TempID = en_str_SystemReset;
					Mapp_FactoryRCRST();
					break;
			case  EN_FACTORY_HOTKEY_MODE_FACTORY_RC_BURNIN:
					#if ENABLE_CUS_BURNING_MODE
						if(stGenSetting.g_FactorySetting.fBuringMode)
						{
						stGenSetting.g_FactorySetting.fBuringMode = FALSE;
						MApp_MultiTasks_AdjustBurningMode(DISABLE);
						u16TempID =en_str_factory_burnin_off;
						}
						else
						{
						stGenSetting.g_FactorySetting.fBuringMode = TRUE;
						u16TempID =en_str_factory_burnin_on;
						}
						MApp_SaveFactorySetting();
					#endif
						break;
			case  EN_FACTORY_HOTKEY_MODE_FACTORY_RC_AIRCABLE:
					u16TempID = en_strFunctionNotAvailable;
						break;
			case  EN_FACTORY_HOTKEY_MODE_FACTORY_RC_CTC:
						Mapp_FactoryRCCTCKey();
						switch( ST_PICTURE.eColorTemp )
						{
							default:
							case MS_COLOR_TEMP_COOL:
							u16TempID=en_str_ColorTemp_Cool;
							break;
							case MS_COLOR_TEMP_MEDIUM:
							u16TempID=en_str_ColorTemp_Medium;
							break;
							case MS_COLOR_TEMP_WARM:
							u16TempID=en_str_ColorTemp_Warm;
							break;
						#if(MS_COLOR_TEMP_COUNT ==4)
							case MS_COLOR_TEMP_USER:
							u16TempID=en_str_ColorTemp_User;
							break;
						#endif
						}
						break;
			case  EN_FACTORY_HOTKEY_MODE_FACTORY_RC_PRE_CH:
						u16TempID = en_str_factory_preset_channel;
						msAPI_ATV_Factory_CH_Preset();
						break;
			case  EN_FACTORY_HOTKEY_MODE_FACTORY_RC_VOL_MAX:
						Mapp_AdjustVolumeMax();
						u16TempID = en_str_factory_volumemax;
						break;
			case  EN_FACTORY_HOTKEY_MODE_FACTORY_RC_VOL_BUZZ:
						Mapp_AdjustVolumeHalt();
						u16TempID = en_str_factory_volumebuzz;
						break;
			case  EN_FACTORY_HOTKEY_MODE_FACTORY_RC_VOL_LEFT:
					Mapp_BalanceVolLeft();
					u16TempID = en_str_factory_volumebalanceleft;
					break;
			case  EN_FACTORY_HOTKEY_MODE_FACTORY_RC_VOL_RIGHT:
					Mapp_BalanceVolRight();
					u16TempID = en_str_factory_volumebalanceright;
					break;
			case  EN_FACTORY_HOTKEY_MODE_FACTORY_RC_PICTURE:
					Mapp_AdjustPictureMode();
					u16TempID =  _MApp_ZUI_ACT_GetPictureModeStringID();
					break;
			case  EN_FACTORY_HOTKEY_MODE_FACTORY_RC_AUDIO:
					Mapp_AdjustAudioMode();
					u16TempID = _MApp_ZUI_ACT_GetAudioModeStringID();
					break;
			case  EN_FACTORY_HOTKEY_MODE_FACTORY_RC_LOG_LED:
					u16TempID = en_strFunctionNotAvailable;
					break;
			case  	EN_FACTORY_HOTKEY_MODE_FACTORY_RC_2D3D:
					u16TempID = en_strFunctionNotAvailable;
					break;
			case  EN_FACTORY_HOTKEY_MODE_FACTORY_RC_ARC:
					u16TempID = en_strFunctionNotAvailable;
					break;
			case  EN_FACTORY_HOTKEY_MODE_FACTORY_RC_CI_ADD:
					u16TempID = en_strFunctionNotAvailable;
					break;
			case  EN_FACTORY_HOTKEY_MODE_FACTORY_RC_VIRG_IN:
					u16TempID = en_strFunctionNotAvailable;
					break;
			case  EN_FACTORY_HOTKEY_MODE_FACTORY_RC_REGIN:
					u16TempID = en_strFunctionNotAvailable;
					break;
			case  EN_FACTORY_HOTKEY_MODE_FACTORY_RC_CLONE:
					u16TempID = en_strFunctionNotAvailable;
					break;
			case  EN_FACTORY_HOTKEY_MODE_FACTORY_RC_CLK:
					u16TempID = en_strFunctionNotAvailable;
					break;
			case  EN_FACTORY_HOTKEY_MODE_FACTORY_RC_DCR:
					Mapp_SwitchDCRMode();
				#if ENABLE_CUS_DBC
					switch(ST_PICTURE.bDBCStatus)
					{
						default:
						case DBC_STATUS_OFF:
						u16TempID=en_str_factory_dcr_off;
						break;
						case DBC_STATUS_ON:
						u16TempID=en_str_factory_dcr_on;
						break;
					}
				#endif
					break;
			case  EN_FACTORY_HOTKEY_MODE_FACTORY_RC_ADC:
					//Mapp_FactoryRCADC();
					//afmAutoADC();
					//CUS_RS232_DecodeCommand();
					//Mapp_Factory_RC_ADCkey();
					if(stGenSetting.g_SysSetting.bisadccheck)
						{
							u16TempID =en_str_factory_adc_pass;
						}
					else
						{
							u16TempID =en_str_factory_adc_fail;
						}
					break;
			case  EN_FACTORY_HOTKEY_MODE_FACTORY_RC_BLK:
				if(stGenSetting.g_SysSetting.bisreaptbacklight)
					{
						stGenSetting.g_SysSetting.bisreaptbacklight=FALSE;
						Mapp_BackLightAdjust50or100(100);
						u16TempID = en_str_factory_backlightmax;
					}
				else
					{
					stGenSetting.g_SysSetting.bisreaptbacklight=TRUE;
						Mapp_BackLightAdjust50or100(50);
						u16TempID = en_str_factory_backlighthalf;
					}
					break;
			case  EN_FACTORY_HOTKEY_MODE_FACTORY_RC_WP:
					u16TempID = en_strFunctionNotAvailable;
					break;
			case  EN_FACTORY_HOTKEY_MODE_FACTORY_RC_LIGHT_SENSOR:
					u16TempID = en_strFunctionNotAvailable;
					break;
			case  EN_FACTORY_HOTKEY_MODE_FACTORY_RC_USB:
					break;
			case  EN_FACTORY_HOTKEY_MODE_FACTORY_RC_RJ45:
					u16TempID = en_strFunctionNotAvailable;
					break;
			case  EN_FACTORY_HOTKEY_MODE_FACTORY_RC_RS232:
					if (Mapp_SwitchRS232Mode())
					{
						u16TempID = en_str_factory_CSM_RS232_on;
					}
					else
					{
						u16TempID = en_str_factory_CSM_RS232_off;
					}
					break;
							// CUS_XM Xue 20120727: modify XF112PIOCNMS0-797 bug
			case  EN_FACTORY_HOTKEY_MODE_FACTORY_RC_NULL_KEY:
				u16TempID = en_strFunctionNotAvailable;
					break;

			default:
				break;
		}
		break;
	default:
		break;
	}

	if (u16TempID != Empty)
		return MApp_ZUI_API_GetString(u16TempID);
	return 0; //for empty string....
}
#endif
#undef MAPP_ZUI_ACTFACTORYHOTKEY_C

