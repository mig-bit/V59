////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (MStar Confidential Information!�L) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef __MSAPI_TUNING_H__
#define __MSAPI_TUNING_H__


#include "msAPI_ATVSystem.h"
#include "Tuner.h"

#ifdef MSAPI_TUNING_C
#define INTERFACE
#else
#define INTERFACE extern
#endif

#define AUTO_TUNING_ALG_DEFAULT         0
#define AUTO_TUNING_ALG_NTSC            1
#define AUTO_TUNING_ALG_TST             2
#define AUTO_TUNING_ALG_PAL_NEW     3

#define LOWEST_SORTING_PRIORITY        0xFF

#define DIFFERENCE(a,b)             (((a)>=(b))?((a)-(b)):((b)-(a)))
//------  ATV SCAN CUSTOMIZE  ----------------------------------------------------


#if ENABLE_SBTVD_BRAZIL_APP
    #define AUTO_TUNING_TYPE_SEL                AUTO_TUNING_ALG_NTSC
    #define ATVSCAN_SORT_BY_STATION_NAME        0
#elif (ENABLE_DVB_TAIWAN_APP)
    #define AUTO_TUNING_TYPE_SEL                AUTO_TUNING_ALG_NTSC
    #define ATVSCAN_SORT_BY_STATION_NAME        0
#else
  #if (TV_SYSTEM == TV_NTSC)
    #define AUTO_TUNING_TYPE_SEL                AUTO_TUNING_ALG_NTSC
    #define ATVSCAN_SORT_BY_STATION_NAME        0
  #else
    #define AUTO_TUNING_TYPE_SEL                AUTO_TUNING_ALG_PAL_NEW
    #define ATVSCAN_SORT_BY_STATION_NAME        1
  #endif
#endif

#if(FRONTEND_IF_DEMODE_TYPE == MSTAR_VIF || FRONTEND_IF_DEMODE_TYPE == MSTAR_VIF_MSB1210)
    #define AUTO_TUNING_DEFAULT_ALG_WAIT_TIME_SPEEP_UP          WAIT_230ms// WAIT_90ms
    #define AUTO_TUNING_DEFAULT_ALG_WAIT_TIME_0P25MHZ_STEP_L    WAIT_230ms// WAIT_90ms
    #define AUTO_TUNING_DEFAULT_ALG_WAIT_TIME_0P25MHZ_STEP      WAIT_110ms// WAIT_90ms
    #define AUTO_TUNING_DEFAULT_ALG_WAIT_TIME_0P5MHZ_STEP       WAIT_230ms// WAIT_90ms
    #define AUTO_TUNING_DEFAULT_ALG_WAIT_TIME_4MHZ_STEP         WAIT_230ms// WAIT_90ms
    #define AUTO_TUNING_DEFAULT_ALG_WAIT_TIME_MAX_STEP          WAIT_230ms// WAIT_90ms
    #define AUTO_TUNING_DEFAULT_ALG_WAIT_TIME_CROSS_BAND_STEP   WAIT_230ms// WAIT_90ms
#endif

    #define ATVSCAN_USE_TIMER_DELAY     1
    #define ATVSCAN_AUDIO_WAIT_TIME2    900   //unit:ms


#if (VIF_TUNER_TYPE == 0)
    #define ATVSCAN_VIFLOCK_TOTAL_CHECK_TIME   150   //unit:ms
    #define ATVSCAN_VDLOCK_TOTAL_CHECK_TIME    150   //unit:ms
#else
    #define ATVSCAN_VIFLOCK_TOTAL_CHECK_TIME   100   //unit:ms
    #define ATVSCAN_VDLOCK_TOTAL_CHECK_TIME    180   //unit:ms
#endif
    #define ATVSCAN_CNI_TOTAL_CHECK_TIME        3000   //unit:ms
    #define ATVSCAN_VIDEO_WAIT_TIME             300   //unit:ms
    #define ATVSCAN_VIDEO_WAIT_TIME_MAX         800   //unit:ms


//------  ATV SCAN DEFAULT  ----------------------------------------------------

#ifndef AUTO_TUNING_TYPE_SEL
    #define AUTO_TUNING_TYPE_SEL        AUTO_TUNING_ALG_DEFAULT//AUTO_TUNING_ALG_TST//AUTO_TUNING_ALG_DEFAULT
#endif

#ifndef ATVSCAN_SORT_BY_STATION_NAME
    #define ATVSCAN_SORT_BY_STATION_NAME         1
#endif

#if (TV_SYSTEM == TV_PAL)
 #if(FRONTEND_TUNER_TYPE == NXP_TD1616EF_TUNER)
    #define TV_SCAN_PAL_SECAM_ONCE              0
 #else
  #if(AUTO_TUNING_TYPE_SEL ==AUTO_TUNING_ALG_PAL_NEW)
    #define TV_SCAN_PAL_SECAM_ONCE              1
  #else
    #define TV_SCAN_PAL_SECAM_ONCE              0
  #endif
 #endif
#else
    #define TV_SCAN_PAL_SECAM_ONCE              0
#endif

#ifndef FRANCE_SUPPORT_SECAM_BG_SECAM_DK
    #define FRANCE_SUPPORT_SECAM_BG_SECAM_DK    1
#endif

#ifndef ATVSCAN_AUDIO_WAIT_TIME
    #define ATVSCAN_AUDIO_WAIT_TIME             WAIT_770ms
#endif

#ifndef AUTO_TUNING_DEFAULT_ALG_WAIT_TIME_SPEEP_UP
  #if(FRONTEND_IF_DEMODE_TYPE == MSTAR_VIF)
    #define AUTO_TUNING_DEFAULT_ALG_WAIT_TIME_SPEEP_UP          WAIT_230ms// WAIT_90ms
  #else
    #define AUTO_TUNING_DEFAULT_ALG_WAIT_TIME_SPEEP_UP          WAIT_170ms
  #endif
#endif

#ifndef AUTO_TUNING_DEFAULT_ALG_WAIT_TIME_0P25MHZ_STEP_L
  #if(FRONTEND_IF_DEMODE_TYPE == MSTAR_VIF)
    #define AUTO_TUNING_DEFAULT_ALG_WAIT_TIME_0P25MHZ_STEP_L    WAIT_230ms// WAIT_90ms
  #else
    #define AUTO_TUNING_DEFAULT_ALG_WAIT_TIME_0P25MHZ_STEP_L    WAIT_230ms
  #endif
#endif

#ifndef AUTO_TUNING_DEFAULT_ALG_WAIT_TIME_0P25MHZ_STEP
  #if(FRONTEND_IF_DEMODE_TYPE == MSTAR_VIF)
    #define AUTO_TUNING_DEFAULT_ALG_WAIT_TIME_0P25MHZ_STEP      WAIT_110ms// WAIT_90ms
  #else
    #define AUTO_TUNING_DEFAULT_ALG_WAIT_TIME_0P25MHZ_STEP      WAIT_90ms
  #endif
#endif

#ifndef AUTO_TUNING_DEFAULT_ALG_WAIT_TIME_0P5MHZ_STEP
  #if(FRONTEND_IF_DEMODE_TYPE == MSTAR_VIF)
    #define AUTO_TUNING_DEFAULT_ALG_WAIT_TIME_0P5MHZ_STEP       WAIT_230ms// WAIT_90ms
  #else
    #define AUTO_TUNING_DEFAULT_ALG_WAIT_TIME_0P5MHZ_STEP       WAIT_230ms // WAIT_120ms
  #endif
#endif

#ifndef AUTO_TUNING_DEFAULT_ALG_WAIT_TIME_4MHZ_STEP
  #if(FRONTEND_IF_DEMODE_TYPE == MSTAR_VIF)
    #define AUTO_TUNING_DEFAULT_ALG_WAIT_TIME_4MHZ_STEP         WAIT_230ms// WAIT_90ms
  #else
    #define AUTO_TUNING_DEFAULT_ALG_WAIT_TIME_4MHZ_STEP         WAIT_230ms // WAIT_150ms
  #endif
#endif

#ifndef AUTO_TUNING_DEFAULT_ALG_WAIT_TIME_MAX_STEP
  #if(FRONTEND_IF_DEMODE_TYPE == MSTAR_VIF)
    #define AUTO_TUNING_DEFAULT_ALG_WAIT_TIME_MAX_STEP          WAIT_230ms// WAIT_90ms
  #else
    #define AUTO_TUNING_DEFAULT_ALG_WAIT_TIME_MAX_STEP          WAIT_230ms // WAIT_150ms
  #endif
#endif

#ifndef AUTO_TUNING_DEFAULT_ALG_WAIT_TIME_CROSS_BAND_STEP
  #if(FRONTEND_IF_DEMODE_TYPE == MSTAR_VIF)
    #define AUTO_TUNING_DEFAULT_ALG_WAIT_TIME_CROSS_BAND_STEP   WAIT_230ms// WAIT_90ms
  #else
    #define AUTO_TUNING_DEFAULT_ALG_WAIT_TIME_CROSS_BAND_STEP   WAIT_230ms // WAIT_150ms
  #endif
#endif


#ifndef TUNER_PLL_NEXT_CHANNEL_JUMP
    #define TUNER_PLL_NEXT_CHANNEL_JUMP   TUNER_PLL_PLUS_2MHz          // WAIT_150ms
#endif


#if (FRONTEND_IF_DEMODE_TYPE == MSTAR_VIF_MSB1210)
    #define E_AFC_GOOD_MINUS_VALUE      E_AFC_MINUS_37p5KHz
    #define E_AFC_GOOD_PLUS_VALUE       E_AFC_PLUS_12p5KHz
#else
 #ifndef   SPECIFIC_AFC_GOOD_VALUE
    #define E_AFC_GOOD_MINUS_VALUE      E_AFC_MINUS_37p5KHz
    #define E_AFC_GOOD_PLUS_VALUE       E_AFC_PLUS_37p5KHz
 #else
  #if (SPECIFIC_AFC_GOOD_VALUE == 1)
    #define E_AFC_GOOD_MINUS_VALUE      E_AFC_MINUS_62p5KHz
    #define E_AFC_GOOD_PLUS_VALUE       E_AFC_PLUS_62p5KHz
  #else
    #define E_AFC_GOOD_MINUS_VALUE      E_AFC_MINUS_37p5KHz
    #define E_AFC_GOOD_PLUS_VALUE       E_AFC_PLUS_37p5KHz
  #endif
 #endif
#endif

#ifndef ENABLE_AUDIO_AUTO_DETECT
    #define ENABLE_AUDIO_AUTO_DETECT            1
#endif

// AFT external Steps
typedef U32 eAFTSTEP;
#define AFT_EXT_STEP_PERIODIC                   0x00
#define AFT_EXT_STEP_SEARCHALL                  0x01
#define AFT_EXT_STEP_SEARCHONETOUP              0x02
#define AFT_EXT_STEP_SEARCHONETODOWN            0x03
#define AFT_EXT_STEP_SEARCHSTOP                 0x04
#define AFT_TUNING_SUSPEND                      0x05
#define AFT_TUNING_RESUME                       0x06
#ifdef ENABLE_CUS_AUTO_AUDIO_SYSTEM_DETECT
#define AFT_AUDIO_AUTODETECT                    0x07
#endif

#define SCAN_TEST_MODE_ENABLE  0
#if (SCAN_TEST_MODE_ENABLE==1)
#define TEST_MODE_ATV_SCAN_MAX                  50
#define TEST_MODE_ATV_SCAN_STATE_DISABLE         0
#define TEST_MODE_ATV_SCAN_STATE_SAVE_DATA       1
#define TEST_MODE_ATV_SCAN_STATE_VERIFY          2

#define TEST_MODE_ATV_SCAN_Init                  0
#define TEST_MODE_ATV_SCAN_Processing            1
#define TEST_MODE_ATV_SCAN_Finish                2
typedef struct
{
     U16    wPLL;
  //   BYTE  sName[MAX_STATION_NAME];
     WORD eAudioStandard                         : 4;
     WORD eVideoStandard                         : 3;
     WORD bActive                                : 1;
     WORD bFound                                 : 1;
     WORD Reserve                                : 9;

} SCAN_TEST_MODE_ATV_INFO;

typedef struct
{
    U8   u8State;
    U8   u8ActiveProgramNum;
    U8   u16VerifyCount;
    U8   u16VerifyCountInput;
    U8   u16Total_Lost_Channel;
    U8   u16Total_Ghost_Channel;

} SCAN_TEST_MODE_TEST_INFO;

extern SCAN_TEST_MODE_ATV_INFO TestModeScanInfo[TEST_MODE_ATV_SCAN_MAX];
extern SCAN_TEST_MODE_TEST_INFO AutoScanTest;

extern void TestMode_ATV_Scan_Verify(U8 u8VerifyState);
extern void TestMode_ATV_Scan_Save_Info(U8 u8SaveInfoState);
#endif // #if (SCAN_TEST_MODE_ENABLE==1)


typedef enum
{
    DIRECTION_UP,
    DIRECTION_DOWN
} DIRECTION;

#if( TV_FREQ_SHIFT_CLOCK )
typedef enum
{
    SHIFT_CLK_ORIGIN_43d2M,
    SHIFT_CLK_TYPE1_42M,
    SHIFT_CLK_TYPE2_44d4M
} TV_FREQ_SHIFT_MODE;
#endif

#if ( TV_FREQ_SHIFT_CLOCK )
INTERFACE U8 g_u8_ShiftClk_LastMode;
#endif

#ifdef ENABLE_CUS_AUTO_AUDIO_SYSTEM_DETECT
INTERFACE AUDIOSTANDARD_TYPE eAudioStandard_AutoDetect;
INTERFACE BOOLEAN eAudioStandard_AutoDetect_Result;
#define AUDIO_AUTO_STATUS_EXIT      0
#define AUDIO_AUTO_STATUS_ENTER     1
#define AUDIO_AUTO_STATUS_END       2
#endif

//------------------------------------------------------------------------------
// Prototype
//------------------------------------------------------------------------------
INTERFACE void msAPI_Tuner_Init(void);
#if(FRONTEND_IF_DEMODE_TYPE == MSTAR_INTERN_VIF)
INTERFACE void msAPI_ClearTunerFreq_Status(void);
INTERFACE void msAPI_SetTunerPLL(void);  //20100604EL
#endif
INTERFACE BOOLEAN msAPI_Tuner_IsTuningProcessorBusy(void);
INTERFACE BOOLEAN msAPI_Tuner_IsOneProgramDetected(void);
INTERFACE BOOLEAN msAPI_Tuner_PreProgramDeteted(void);
INTERFACE void msAPI_Tuner_SetRealtimeAFTBaseTunerPLL(U16 u16TunerPLL);
INTERFACE void msAPI_Tuner_TuningProcessor(eAFTSTEP eState);
INTERFACE void msAPI_Tuner_AdjustUnlimitedFineTune(DIRECTION eDirection);
INTERFACE U16 msAPI_Tuner_SetSearchManualTune(U16 u16InterFreq);
INTERFACE void msAPI_Tuner_ChangeProgram(void);
//INTERFACE void msAPI_Tuner_ChangeProgramWithoutStable(void);
INTERFACE MEDIUM msAPI_Tuner_GetMedium(void);
INTERFACE void msAPI_Tuner_SetMedium(MEDIUM eMedium);
INTERFACE U8 msAPI_Tuner_GetChannelNumber(void);
INTERFACE void msAPI_Tuner_SetChannelNumber(U8 u8Channel);
INTERFACE void msAPI_Tuner_SetIF(void);
INTERFACE U16 msAPI_Tuner_GetCurrentChannelPLL(void);
INTERFACE U16 msAPI_Tuner_GetCurrentChannelPLL2UiStr(void);
INTERFACE BOOLEAN msAPI_Tuner_IsCurrentChannelAndSavedChannelSame(void);
INTERFACE void msAPI_Tuner_ConvertMediumAndChannelNumberToString(MEDIUM eMedium, U8 u8ChannelNumber, BYTE * sStationName);
INTERFACE U8 msAPI_Tuner_GetTuningProcessPercent(void);
INTERFACE void msAPI_Tuner_GetCurrentStationName(BYTE *sName);
INTERFACE void msAPI_Tuner_ChangeCurrentStationName(BYTE cStationNameChar, U8 u8Position);
INTERFACE BOOLEAN msAPI_Tuner_IsAFTNeeded(void);
INTERFACE void msAPI_Tuner_UpdateMediumAndChannelNumber(void);
INTERFACE void msAPI_Tuner_PrintTVAVSourceInformation(void);
INTERFACE U16 msAPI_Tuner_GetIF(void);
INTERFACE void msAPI_Tuning_IsScanL(BOOLEAN bEnable);
INTERFACE BOOLEAN msAPI_Tuner_IsCurrentAudioLPrime(void);
INTERFACE void msAPI_Tuner_UserSetIF(AUDIOSTANDARD_TYPE  AudioStandard);

#if ENABLE_SBTVD_BRAZIL_APP
INTERFACE U8 msAPI_Tuner_GetNumberOfChBeFound_WhileAutoScan(void);
#endif

#if( TV_FREQ_SHIFT_CLOCK )
INTERFACE void msAPI_Tuner_Patch_TVShiftClk(BOOL bEnable);
INTERFACE void msAPI_Tuner_Patch_ResetTVShiftClk(void);
INTERFACE void msAPI_Tuner_Patch_TVShiftVDClk(BOOL bEnable);
INTERFACE BOOLEAN msAPI_Tuner_Patch_IsTVShiftVDClk(void);
#endif

INTERFACE void msAPI_SetTunerPLL_KeepFreq(void);

#if ENABLE_CUS_MANUAL_SCAN
INTERFACE BOOLEAN msAPI_Tuner_SetManualScanStartFreq(U32 u32Freq);
INTERFACE U32 msAPI_Tuner_GetManualScanStartFreq(void);
INTERFACE BOOLEAN msAPI_Tuner_SetManualScanEndFreq(U32 u32Freq);
INTERFACE BOOLEAN msAPI_Tuner_CheckManualScanStartAndEndFreq(void);
INTERFACE U32 msAPI_Tuner_GetManualScanEndFreq(void);
INTERFACE U16 msAPI_Tuner_GetManualScanFreqConvertToPLL(U32 u32Freq);
INTERFACE void msAPI_Tuner_SetTunerPLLValue(U16 u16Pll);
#endif
INTERFACE void msAPI_Tuner_SetAFTNeeded(BOOLEAN IsAFT);

#undef INTERFACE

#endif // __MSAPI_TUNING_H__

