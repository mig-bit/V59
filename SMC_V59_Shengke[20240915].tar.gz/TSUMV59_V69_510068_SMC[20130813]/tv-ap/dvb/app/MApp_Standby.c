////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#define MAPP_STANDBY_C

//------------------------------------------------------------------------------
//                            Header Files
//------------------------------------------------------------------------------
#include "hwreg.h"
#include "sysinfo.h"
#include "debug.h"
#include "msAPI_Global.h"
#include "msAPI_Power.h"
#include "apiGOP.h"
#include "MsCommon.h"
#include "MsIRQ.h"
#include "MsOS.h"

#if (EEPROM_DB_STORAGE == EEPROM_SAVE_NONE)
#include "msAPI_MIU.h"
#include "msAPI_Flash.h"
#endif

#include "msAPI_IR.h"
#include "msAPI_Timer.h"
#include "msAPI_Ram.h"
#include "msAPI_DrvInit.h"
#include "apiXC.h"
#include "apiXC_Adc.h"
#include "apiXC_Sys.h"

#include "Panel.h"
#include "apiPNL.h"

#include "drvXC_HDMI_if.h"
#include "apiXC_Hdmi.h"
#include "MApp_Exit.h"
#include "MApp_Standby.h"
#include "MApp_Key.h"
#include "MApp_GlobalSettingSt.h"
#include "MApp_GlobalVar.h"
#include "MApp_SaveData.h"

#include "MApp_DataBase.h"

#if (ENABLE_DTV)
#include "mapp_demux.h"
#endif

#include "MApp_SignalMonitor.h"
#include "MApp_ChannelChange.h"
#include "MApp_Audio.h"
#include "msAPI_audio.h"
#include "MApp_ATVProc.h"
#include "MApp_MultiTasks.h"

//For Sleep Timer
#include "MApp_Sleep.h"

#include "MApp_ZUI_Main.h"

#include "GPIO.h"
#ifdef LOCK_ID693_EN
#include "drvIIC.h"     //mig add 2017 1117
#endif
#include "MApp_GlobalFunction.h"
#include "MApp_GlobalSettingSt.h"
#include "msAPI_Flash.h"

//#include "md5.h"
//#include <memory.h>
#include "Utl.h"

#if ENABLE_OAD
#include "MApp_OAD.h"
#endif

#define STDBY_DBGINFO(y)    //y

//------------------------------------------------------------------------------
//                                 Local
//------------------------------------------------------------------------------




/*******************************************************************************************/

// Turn off audio standard flow: (by Cathy)
//  1.DSP mute
//  2.Delay 10ms
//  3.Amp mute on
//  4.Amp power off
void MApp_Standby_Init(void)
{
    ST_TIME _stTime;
    DAYOFWEEK eDayOfWeek;

//    STDBY_DBGINFO(printf("Enter Standby mode\n"));
    printf("Enter PM/Standby mode \n");

    //Turn off AV-OUT
    msAPI_Scaler_SetCVBSMute(ENABLE, E_VE_MUTE_GEN, SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW), OUTPUT_CVBS1);
    #if (INPUT_SCART_VIDEO_COUNT >= 2)
    msAPI_Scaler_SetCVBSMute(ENABLE, E_VE_MUTE_GEN, SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW), OUTPUT_CVBS2);
    #endif

    // Turn off audio: 1.DSP mute
    msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_PERMANENT_MUTEON, E_AUDIOMUTESOURCE_ACTIVESOURCE);

    // Turn off audio: 2.Delay 10ms
	#if BOE_POP_MODIFY//minglin0220
	 msAPI_Timer_Delayms(500);//DELAY_FOR_ENTERING_MUTE);
	#else
    msAPI_Timer_Delayms(10);//DELAY_FOR_ENTERING_MUTE);
    #endif
    // Turn off audio: 3.Amp mute on
    MUTE_On();

    // Turn off audio: 4.Amp power off
    Audio_Amplifier_OFF();


  #if EAR_PHONE_POLLING
    EarPhone_OFF();
  #endif

    MApi_PNL_SetBackLight(DISABLE);

    MApp_ConvertSeconds2StTime(msAPI_Timer_GetSystemTime(),&_stTime);
    eDayOfWeek = (DAYOFWEEK) MApp_GetDayOfWeek(_stTime.u16Year, _stTime.u8Month, _stTime.u8Day);

    MApp_SetDayOfWeek(eDayOfWeek);

  #if (INPUT_HDMI_VIDEO_COUNT > 0)
    MApi_XC_Sys_HDMI_PowerOff( );
  #endif

  #if ENABLE_OAD
    MApp_OAD_SetInfo() ;
  #endif

    MApp_InitRtcWakeUpTimer();

    if (IsAnyTVSourceInUse())
        MApp_ChannelChange_DisableChannel(TRUE, MAIN_WINDOW);

    MApp_ZUI_ACT_ShutdownOSD();

    msAPI_Scaler_SetBlueScreen( ENABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
    #if ENABLE_3D_PROCESS
    MApp_Scaler_Close3DFunction();
    #endif
    #if ENABLE_CUS_BLOCK_SYS
    msAPI_ATV_ClearAllLockedCHCheckPwdFlag();
    #endif
	
#if (ENABLE_CUS_BURNING_MODE)
	stGenSetting.g_FactorySetting.fBuringMode = 0;
#endif
    MApp_SaveGenSetting();


  #if (EEPROM_DB_STORAGE == EEPROM_SAVE_NONE)
    //store to flash immediately
    MApp_DB_SaveNowGenSetting();
  #endif


  #if (EEPROM_DB_STORAGE != EEPROM_SAVE_ALL)
    MApp_DB_SaveDataBase();
  #endif

    msAPI_Power_PowerDown_EXEC();
}
static unsigned char PADDING[64] = 
{  0x80, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
   0x00,  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
   0x00, 0x00,  0x00, 0x00, 0x00, 0x00, 0x00, 
   0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 0x00, 
   0x00, 0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 
   0x00, 0x00, 0x00, 0x00, 0x00,  0x00, 0x00, 
   0x00, 0x00, 0x00, 0x00, 0x00, 0x00,  0x00, 
   0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,  
   0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};




void MD5Init(MD5_CTX *context)
{
	 context->count[0] = 0;
	 context->count[1] = 0;
	 context->state[0] = 0x67452301;
	 context->state[1] = 0xEFCDAB89;
	 context->state[2] = 0x98BADCFE;
	 context->state[3] = 0x10325476;
}

void MD5Update(MD5_CTX *context,unsigned char *input,unsigned int inputlen)
{
    unsigned int i = 0,index = 0,partlen = 0;
    index = (context->count[0] >> 3) & 0x3F;
    partlen = 64 - index;
    context->count[0] += inputlen << 3;
    if(context->count[0] < (inputlen << 3))
       context->count[1]++;
    context->count[1] += inputlen >> 29;
    
    if(inputlen >= partlen)
    {
       UTL_memcpy(&context->buffer[index],input,partlen);
       MD5Transform(context->state,context->buffer);
       for(i = partlen;i+64 <= inputlen;i+=64)
           MD5Transform(context->state,&input[i]);
       index = 0;        
    }  
    else
    {
        i = 0;
    }
    UTL_memcpy(&context->buffer[index],&input[i],inputlen-i);
}

void MD5Final(MD5_CTX *context,unsigned char digest[16])
{
    unsigned int index = 0,padlen = 0;
    unsigned char bits[8];
    index = (context->count[0] >> 3) & 0x3F;
    padlen = (index < 56)?(56-index):(120-index);
    MD5Encode(bits,context->count,8);
    MD5Update(context,PADDING,padlen);
    MD5Update(context,bits,8);
    MD5Encode(digest,context->state,16);
}


void MD5Encode(unsigned char *output,unsigned int *input,unsigned int len)
{
    unsigned int i = 0,j = 0;
    while(j < len)
    {
         output[j] = input[i] & 0xFF;  
         output[j+1] = (input[i] >> 8) & 0xFF;
         output[j+2] = (input[i] >> 16) & 0xFF;
         output[j+3] = (input[i] >> 24) & 0xFF;
         i++;
         j+=4;
    }
}

void MD5Decode(unsigned int *output,unsigned char *input,unsigned int len)
{
     unsigned int i = 0,j = 0;
     while(j < len)
     {
           output[i] = (input[j]) |
                       (input[j+1] << 8) |
                       (input[j+2] << 16) |
                       (input[j+3] << 24);
           i++;
           j+=4; 
     }
}


void MD5Transform(unsigned int state[4],unsigned char block[64])
{
     unsigned int a = state[0];
     unsigned int b = state[1];
     unsigned int c = state[2];
     unsigned int d = state[3];
     unsigned int x[64];
     MD5Decode(x,block,64);
     FF(a, b, c, d, x[ 0], 7, 0xd76aa478); /* 1 */
 FF(d, a, b, c, x[ 1], 12, 0xe8c7b756); /* 2 */
 FF(c, d, a, b, x[ 2], 17, 0x242070db); /* 3 */
 FF(b, c, d, a, x[ 3], 22, 0xc1bdceee); /* 4 */
 FF(a, b, c, d, x[ 4], 7, 0xf57c0faf); /* 5 */
 FF(d, a, b, c, x[ 5], 12, 0x4787c62a); /* 6 */
 FF(c, d, a, b, x[ 6], 17, 0xa8304613); /* 7 */
 FF(b, c, d, a, x[ 7], 22, 0xfd469501); /* 8 */
 FF(a, b, c, d, x[ 8], 7, 0x698098d8); /* 9 */
 FF(d, a, b, c, x[ 9], 12, 0x8b44f7af); /* 10 */
 FF(c, d, a, b, x[10], 17, 0xffff5bb1); /* 11 */
 FF(b, c, d, a, x[11], 22, 0x895cd7be); /* 12 */
 FF(a, b, c, d, x[12], 7, 0x6b901122); /* 13 */
 FF(d, a, b, c, x[13], 12, 0xfd987193); /* 14 */
 FF(c, d, a, b, x[14], 17, 0xa679438e); /* 15 */
 FF(b, c, d, a, x[15], 22, 0x49b40821); /* 16 */
 
 /* Round 2 */
 GG(a, b, c, d, x[ 1], 5, 0xf61e2562); /* 17 */
 GG(d, a, b, c, x[ 6], 9, 0xc040b340); /* 18 */
 GG(c, d, a, b, x[11], 14, 0x265e5a51); /* 19 */
 GG(b, c, d, a, x[ 0], 20, 0xe9b6c7aa); /* 20 */
 GG(a, b, c, d, x[ 5], 5, 0xd62f105d); /* 21 */
 GG(d, a, b, c, x[10], 9,  0x2441453); /* 22 */
 GG(c, d, a, b, x[15], 14, 0xd8a1e681); /* 23 */
 GG(b, c, d, a, x[ 4], 20, 0xe7d3fbc8); /* 24 */
 GG(a, b, c, d, x[ 9], 5, 0x21e1cde6); /* 25 */
 GG(d, a, b, c, x[14], 9, 0xc33707d6); /* 26 */
 GG(c, d, a, b, x[ 3], 14, 0xf4d50d87); /* 27 */
 GG(b, c, d, a, x[ 8], 20, 0x455a14ed); /* 28 */
 GG(a, b, c, d, x[13], 5, 0xa9e3e905); /* 29 */
 GG(d, a, b, c, x[ 2], 9, 0xfcefa3f8); /* 30 */
 GG(c, d, a, b, x[ 7], 14, 0x676f02d9); /* 31 */
 GG(b, c, d, a, x[12], 20, 0x8d2a4c8a); /* 32 */
 
 /* Round 3 */
 HH(a, b, c, d, x[ 5], 4, 0xfffa3942); /* 33 */
 HH(d, a, b, c, x[ 8], 11, 0x8771f681); /* 34 */
 HH(c, d, a, b, x[11], 16, 0x6d9d6122); /* 35 */
 HH(b, c, d, a, x[14], 23, 0xfde5380c); /* 36 */
 HH(a, b, c, d, x[ 1], 4, 0xa4beea44); /* 37 */
 HH(d, a, b, c, x[ 4], 11, 0x4bdecfa9); /* 38 */
 HH(c, d, a, b, x[ 7], 16, 0xf6bb4b60); /* 39 */
 HH(b, c, d, a, x[10], 23, 0xbebfbc70); /* 40 */
 HH(a, b, c, d, x[13], 4, 0x289b7ec6); /* 41 */
 HH(d, a, b, c, x[ 0], 11, 0xeaa127fa); /* 42 */
 HH(c, d, a, b, x[ 3], 16, 0xd4ef3085); /* 43 */
 HH(b, c, d, a, x[ 6], 23,  0x4881d05); /* 44 */
 HH(a, b, c, d, x[ 9], 4, 0xd9d4d039); /* 45 */
 HH(d, a, b, c, x[12], 11, 0xe6db99e5); /* 46 */
 HH(c, d, a, b, x[15], 16, 0x1fa27cf8); /* 47 */
 HH(b, c, d, a, x[ 2], 23, 0xc4ac5665); /* 48 */
 
 /* Round 4 */
 II(a, b, c, d, x[ 0], 6, 0xf4292244); /* 49 */
 II(d, a, b, c, x[ 7], 10, 0x432aff97); /* 50 */
 II(c, d, a, b, x[14], 15, 0xab9423a7); /* 51 */
 II(b, c, d, a, x[ 5], 21, 0xfc93a039); /* 52 */
 II(a, b, c, d, x[12], 6, 0x655b59c3); /* 53 */
 II(d, a, b, c, x[ 3], 10, 0x8f0ccc92); /* 54 */
 II(c, d, a, b, x[10], 15, 0xffeff47d); /* 55 */
 II(b, c, d, a, x[ 1], 21, 0x85845dd1); /* 56 */
 II(a, b, c, d, x[ 8], 6, 0x6fa87e4f); /* 57 */
 II(d, a, b, c, x[15], 10, 0xfe2ce6e0); /* 58 */
 II(c, d, a, b, x[ 6], 15, 0xa3014314); /* 59 */
 II(b, c, d, a, x[13], 21, 0x4e0811a1); /* 60 */
 II(a, b, c, d, x[ 4], 6, 0xf7537e82); /* 61 */
 II(d, a, b, c, x[11], 10, 0xbd3af235); /* 62 */
 II(c, d, a, b, x[ 2], 15, 0x2ad7d2bb); /* 63 */
 II(b, c, d, a, x[ 9], 21, 0xeb86d391); /* 64 */
     state[0] += a;
     state[1] += b;
     state[2] += c;
     state[3] += d;
}


/*******************************************************************************************/
#ifdef LOCK_ID693_EN
/*
BYTE code LockData[64]=
{
	0x3e,0xf0,0xe2,0xd0,0xc8,0xb0,0xa2,0x90,0x84,0x70,0x60,0x52,0x40,0x30,0x22,0x02,
	0x02,0x20,0x32,0x46,0x50,0x68,0x70,0x8a,0x90,0xa2,0xb0,0xc7,0xd0,0xe3,0xf0,0x3e,
	0x20,0x04,0xf0,0x08,0x05,0x3e,0x50,0xd0,0x69,0xc0,0x07,0xb7,0x8a,0xe0,0x08,0xa0,
	0x02,0xf4,0x20,0xa2,0x30,0xe6,0x40,0xd7,0x50,0xc9,0x60,0x70,0x3e,0x80,0x92,0xb0,
};

#define LockIC_W_ADDR		0x7e // Write:0x7e
#define LockIC_R_ADDR		0x7f // Write:0x7F
*/
BYTE code LockData[64]=
{
/*
	0x4a,0x3b,0xd3,0xf6,0xa3,0x3d,0x32,0xa4,0x1b,0x2c,0x2d,0x3c,0x20,0x28,0x3b,0x0a,
	0xac,0x5c,0x62,0x76,0x4d,0x2a,0x4b,0x3f,0x42,0x8b,0x82,0x92,0x96,0xa2,0xaa,0x5a,
	0x38,0xb5,0x8d,0xba,0xc2,0xde,0xdf,0xea,0xe8,0x5f,0x2c,0x6e,0x9d,0x8b,0x79,0xa8,			
	0xf3,0xea,0xb7,0x3c,0x43,0x59,0xd1,0x1a,0x36,0x1f,0x26,0x87,0x98,0x32,0xa7,0xc4,
	*/
};
#define LockIC_W_ADDR		0x7c // Write:0x7e
#define LockIC_R_ADDR		0x7d // Write:0x7F

static void Delayms (int ms) {

    // to do
     msAPI_Timer_Delayms(ms);
 }
//#define i2cWriteByte_LockIC(x,y,z)  MDrv_IIC_WriteByte(U16 u16BusNumSlaveID, U8 u8RegAddr, U8 u8Data);

void Init_LockIC(void)
{
	int i;
       U8 index,temp;
     
	//if(!stGenSetting.g_SysSetting.u8Backlight)
	//	return;
     //printf("\nstGenSetting.g_SysSetting.gId693Cnt=%d\n",stGenSetting.g_SysSetting.gId693Cnt);
	//if(stGenSetting.g_SysSetting.gId693Cnt>=5)
	//{
//		return;
//	}
	
	//MDrv_Sys_DisableWatchDog();
	 index=0;
	for(i=0;i<300;i++);
	
	i2c_SendByte_LockIC(LockIC_W_ADDR, 0x40,index);// 

	Delayms(3);
	//indexSource=index;

	//MDrv_Sys_DisableWatchDog();//WatchDogClear();	
	
	temp=i2c_ReceiveByte_LockIC(LockIC_R_ADDR);
		{
	for(i=0;i<300;i++); //300
		}
	//MsOS_CPU_EnableInterrupt();
	#if 1//_DEBUG_PRINT_EN_
	//printf("\nindexSource is %x",(adcValue&0x3f));
	printf("\nindex is %x",index);
	printf("\nrec is %x\n",temp);
	#endif
	
	if((temp==0xff)||(temp!=LockData[index]))
	{	
		stGenSetting.g_SysSetting.gId693FailCnt++;
		if(stGenSetting.g_SysSetting.gId693FailCnt>=2)
		{
			#if 1//_DEBUG_PRINT_EN_
			printf("\nLock0 failed! power off \n");
			#endif
			MApp_Standby_Init();//PowerOffSystem();
			//printf("\nstGenSetting.g_SysSetting.gId693FailCnt=%d\n",stGenSetting.g_SysSetting.gId693FailCnt);
			return;
		}
	}
	else
	{
		#if 1//_DEBUG_PRINT_EN_
		printf("\nLock2 seccesed power on \n");
		#endif
		
		//g_bLockICFlag=1;
		//stGenSetting.g_SysSetting.gId693Cnt++;
	}
}

#endif




/*******************************************************************************************/
#undef MAPP_STANDBY_C

