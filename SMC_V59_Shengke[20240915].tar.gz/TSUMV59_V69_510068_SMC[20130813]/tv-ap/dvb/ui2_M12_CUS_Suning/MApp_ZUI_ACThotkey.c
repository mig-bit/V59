////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#define MAPP_ZUI_ACTHOTKEY_C
#define _ZUI_INTERNAL_INSIDE_ //NOTE: for ZUI internal


//-------------------------------------------------------------------------------------------------
// Include Files
//-------------------------------------------------------------------------------------------------
// Common Definition
#include "Board.h"
#include "datatype.h"
#include "MsCommon.h"
#include "apiXC.h"
#include "apiXC_Adc.h"
#include "MApp_GlobalSettingSt.h"

#include "msAPI_Video.h"

#include "MApp_ZUI_Main.h"
#include "MApp_ZUI_APIcommon.h"
#include "MApp_ZUI_APIstrings.h"
#include "MApp_ZUI_APIwindow.h"
#include "ZUI_tables_h.inl"
#include "MApp_ZUI_APIgdi.h"
#include "MApp_ZUI_APIcontrols.h"
#include "MApp_ZUI_ACTeffect.h"
#include "MApp_ZUI_ACTglobal.h"
#include "OSDcp_String_EnumIndex.h"
#include "ZUI_exefunc.h"

#include "MApp_ZUI_ACThotkey.h"
#include "MApp_UiMenuDef.h"
#include "MApp_SaveData.h"
#include "MApp_Sleep.h"
#include "MApp_GlobalFunction.h"
#include "MApp_Scaler.h"
#include "MApp_XC_PQ.h"
#include "msAPI_audio.h"
#include "MApp_MVDMode.h"
#include "MApp_TopStateMachine.h"
#include "MApp_ZUI_ACTmenufunc.h"
#if MHEG5_ENABLE
#include "MApp_MHEG5_Main.h"
#endif
#include "msAPI_Timer.h"
#include "MApp_PCMode.h"
#include "apiXC.h"
#include "MApp_XC_PQ.h"
#include "MApp_InputSource.h"
#if ENABLE_TTX
#include "mapp_ttx.h"
#endif
#if (MWE_FUNCTION)
#include "apiXC_Ace.h"
#endif
#include "drvPQ.h"
#include "apiXC_Sys.h"


#if ENABLE_T_C_COMBO
#include "MApp_Scan.h"
#endif
#if (((ENABLE_SBTVD_BRAZIL_APP)&&(BRAZIL_CC))||(ATSC_CC == ATV_CC))
#include "mapp_closedcaption.h"
#endif
//CUS_XM:xue add remove compiler warnings 2012-7-10
#include "MApp_ZUI_ACTmenufunc.h"
#include "drvXC_HDMI_if.h"
#include "MApp_Audio.h"

/////////////////////////////////////////////////////////////////////


typedef enum _HOTKEY_MODE
{
    EN_HOTKEY_MODE_INVALID,
    EN_HOTKEY_MODE_SLEEP,
    EN_HOTKEY_MODE_PICTURE,
    EN_HOTKEY_MODE_AUDIO,
    EN_HOTKEY_MODE_SCALE,
    EN_HOTKEY_MODE_ATV_MTS,
    EN_HOTKEY_MODE_FREEZE,
    EN_HOTKEY_MODE_CC,
    EN_HOTKEY_MODE_PIP,
    EN_HOTKEY_MODE_UNSUPPORT_MSG,
} HOTKEY_MODE;

static HOTKEY_MODE _eHotkeyMode;
extern AUDIOMODE_TYPE   m_eAudioMode;
#if ENABLE_ZOOM_AVOUT_NOTMUTE
extern BOOLEAN bIsAspectMute;
#endif


extern BOOLEAN _MApp_ZUI_API_AllocateVarData(void);

#if ENABLE_DTV
extern void Mapp_DTV_ProcessMTS(void);
#endif

void MApp_ZUI_ACT_AppShowHotkeyOption(void)
{
    HWND wnd;
    RECT rect;
    E_OSD_ID osd_id = E_OSD_HOTKEY_OPTION;

    g_GUI_WindowList = GetWindowListOfOsdTable(osd_id);
    g_GUI_WinDrawStyleList = GetWindowStyleOfOsdTable(osd_id);
    g_GUI_WindowPositionList = GetWindowPositionOfOsdTable(osd_id);
#if ZUI_ENABLE_ALPHATABLE
    g_GUI_WinAlphaDataList = GetWindowAlphaDataOfOsdTable(osd_id);
#endif
    HWND_MAX = GetWndMaxOfOsdTable(osd_id);
    OSDPAGE_BLENDING_ENABLE = IsBlendingEnabledOfOsdTable(osd_id);
    OSDPAGE_BLENDING_VALUE = GetBlendingValueOfOsdTable(osd_id);

    if (!_MApp_ZUI_API_AllocateVarData())
    {
        ZUI_DBG_FAIL(printf("[ZUI]ALLOC\n"));
        ABORT();
        return;
    }

    RECT_SET(rect,
        ZUI_HOTKEY_OPTION_XSTART, ZUI_HOTKEY_OPTION_YSTART,
        ZUI_HOTKEY_OPTION_WIDTH, ZUI_HOTKEY_OPTION_HEIGHT);

    if (!MApp_ZUI_API_InitGDI(&rect))
    {
        ZUI_DBG_FAIL(printf("[ZUI]GDIINIT\n"));
        ABORT();
        return;
    }

    for (wnd = 0; wnd < HWND_MAX; wnd++)
    {
        //printf("create msg: %lu\n", (U32)wnd);
        MApp_ZUI_API_SendMessage(wnd, MSG_CREATE, 0);
    }

    MApp_ZUI_API_ShowWindow(HWND_MAINFRAME, SW_SHOW);

    _eHotkeyMode = EN_HOTKEY_MODE_INVALID;

    //MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_PAGE_SHOWUP, E_ZUI_STATE_RUNNING);

}


//////////////////////////////////////////////////////////
// Key Handler

BOOLEAN MApp_ZUI_ACT_HandleHotkeyOptionKey(VIRTUAL_KEY_CODE key)
{
    //note: don't do anything here! keys will be handled in state machines
    //      moved to MApp_TV_ProcessAudioVolumeKey()
    UNUSED(key);
    ZUI_DBG_FAIL(printf("[ZUI]IDLEKEY\n"));
    //ABORT();
    return FALSE;
}

void MApp_ZUI_ACT_TerminateHotkeyOption(void)
{
    ZUI_MSG(printf("[]term:hotkey\n");)
    //enHotkeyOptionState = _enTargetHotkeyOptionState;

}

extern void _MApp_ZUI_ACT_DecIncAspectRatio_Cycle(BOOLEAN bInc);

void _MApp_ZUI_ACT_DecIncSleepTimer_Cycle(BOOLEAN bInc)
{
    //from case MAPP_UIMENUFUNC_ADJTIMESLEEP:
    EN_SLEEP_TIME_STATE enMaxSleeptimer;
    enMaxSleeptimer = (EN_SLEEP_TIME_STATE)(STATE_SLEEP_TOTAL-1);
    #if ENABLE_CUS_UI_SPEC
    enMaxSleeptimer = STATE_SLEEP_120MIN;
    #endif
    stLMGenSetting.stMD.enD4_SleepTimer = (EN_SLEEP_TIME_STATE)MApp_GetCurSleepTime(bInc);
    stLMGenSetting.stMD.enD4_SleepTimer = (EN_SLEEP_TIME_STATE)MApp_ZUI_ACT_DecIncValue_Cycle(
        bInc,
        stLMGenSetting.stMD.enD4_SleepTimer,
        STATE_SLEEP_OFF, (U16)enMaxSleeptimer, 1);
    enSleepTimeState=(EN_SLEEP_TIME_STATE)(U8)stLMGenSetting.stMD.enD4_SleepTimer;
    MApp_Sleep_SetCurrentSleepTime(enSleepTimeState);

}

#if ENABLE_T_C_COMBO
void _MApp_ZUI_ACT_DecIncDVBType_Cycle(void)
{
    EN_DVB_TYPE CurrentDVBSeletType;
    if(MApp_DVBType_GetCurrentType() == EN_DVB_T_TYPE)
    {
        CurrentDVBSeletType = EN_DVB_C_TYPE;
        MApp_ZUI_API_SetFocus(HWND_SELECTED_DVBC_BG);
    }
    else
    {
        CurrentDVBSeletType = EN_DVB_T_TYPE;
        MApp_ZUI_API_SetFocus(HWND_SELECTED_DVBT_BG);
     }
    printf("setCurrentType = %d\n", CurrentDVBSeletType);
    MApp_DVBType_SetCurrentType(CurrentDVBSeletType);
}
#endif

static void _MApp_ZUI_ACT_ExecuteZoomAction(U16 act)
{
    switch(act)
    {
        case EN_EXE_ZOOM_ARROW_UP:
          #if (ENABLE_CUS_UI_SPEC == DISABLE)
            if(MApi_XC_IsCurrentFrameBufferLessMode())
            {
                break; //Bright@20080911 if Frame buffer less enable no action.
            }

            MApp_Scaler_IncUpZoomfactor(1);
            MApp_Scaler_IncDownZoomfactor(1);

            //printf("ZOOM-UP: %u\n", (U16)stSystemInfo[MAIN_WINDOW].enAspectRatio);

          #if MHEG5_ENABLE
            MApp_MHEG5_SetGraphARCInfo(SENDARC_ARC_CHANGE,stSystemInfo[MAIN_WINDOW].enAspectRatio);
          #endif

            MApp_Scaler_SetWindow(NULL, NULL, NULL,
                                           stSystemInfo[MAIN_WINDOW].enAspectRatio, SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW), MAIN_WINDOW);
          #endif
            break;

        case EN_EXE_ZOOM_ARROW_DOWN:
          #if (ENABLE_CUS_UI_SPEC == DISABLE)
            if(MApi_XC_IsCurrentFrameBufferLessMode())
            {
                break; //Bright@20080911 if Frame buffer less enable no action.
            }

            MApp_Scaler_IncUpZoomfactor(-1);
            MApp_Scaler_IncDownZoomfactor(-1);

            //printf("ZOOM-DOWN: %u\n", (U16)stSystemInfo[MAIN_WINDOW].enAspectRatio);

          #if MHEG5_ENABLE
            MApp_MHEG5_SetGraphARCInfo(SENDARC_ARC_CHANGE,stSystemInfo[MAIN_WINDOW].enAspectRatio);
          #endif

            MApp_Scaler_SetWindow(NULL, NULL, NULL,
                                       stSystemInfo[MAIN_WINDOW].enAspectRatio, SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW), MAIN_WINDOW);
          #endif
            break;

        case EN_EXE_ZOOM_ARROW_RIGHT:
         #if (ENABLE_CUS_UI_SPEC == DISABLE)
            if(MApi_XC_IsCurrentFrameBufferLessMode())
            {
                break; //Bright@20080911 if Frame buffer less enable no action.
            }

            MApp_Scaler_IncLeftZoomfactor(1);
            MApp_Scaler_IncRightZoomfactor(1);

            //printf("ZOOM-RIGHT: %u\n", (U16)stSystemInfo[MAIN_WINDOW].enAspectRatio);

          #if MHEG5_ENABLE
            MApp_MHEG5_SetGraphARCInfo(SENDARC_ARC_CHANGE,stSystemInfo[MAIN_WINDOW].enAspectRatio);
          #endif

            MApp_Scaler_SetWindow(NULL, NULL, NULL,
                                  stSystemInfo[MAIN_WINDOW].enAspectRatio,
                                  SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW), MAIN_WINDOW);
          #endif
            break;

        case EN_EXE_ZOOM_ARROW_LEFT:
          #if (ENABLE_CUS_UI_SPEC == DISABLE)
            if(MApi_XC_IsCurrentFrameBufferLessMode())
            {
                break; //Bright@20080911 if Frame buffer less enable no action.
            }

            MApp_Scaler_IncLeftZoomfactor(-1);
            MApp_Scaler_IncRightZoomfactor(-1);

            //printf("ZOOM-LEFT: %u\n", (U16)stSystemInfo[MAIN_WINDOW].enAspectRatio);

          #if MHEG5_ENABLE
            MApp_MHEG5_SetGraphARCInfo(SENDARC_ARC_CHANGE,stSystemInfo[MAIN_WINDOW].enAspectRatio);
          #endif

            MApp_Scaler_SetWindow(NULL, NULL, NULL,
                                  stSystemInfo[MAIN_WINDOW].enAspectRatio, SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW), MAIN_WINDOW);
          #endif
            break;

        case EN_EXE_INC_SCALE_HOTKEY_OPTION:
		if(MApp_IsSrcHasSignal(MAIN_WINDOW))
			{
                #if ENABLE_ZOOM_AVOUT_NOTMUTE
                  bIsAspectMute = TRUE;
                #endif
         		  _MApp_ZUI_ACT_DecIncAspectRatio_Cycle(FALSE);//cus_xm:zb modify at 2012-7-24
                #if ENABLE_ZOOM_AVOUT_NOTMUTE
                  bIsAspectMute = FALSE;
                #endif
			}
		   break;

        case EN_EXE_DEC_SCALE_HOTKEY_OPTION:
            #if ENABLE_ZOOM_AVOUT_NOTMUTE
            bIsAspectMute = TRUE;
            #endif
            _MApp_ZUI_ACT_DecIncAspectRatio_Cycle(FALSE);
            #if ENABLE_ZOOM_AVOUT_NOTMUTE
              bIsAspectMute = FALSE;
            #endif
            break;

        case EN_EXE_SET_DSC_KEY_ARC4X3:
            ST_VIDEO.eAspectRatio = EN_AspectRatio_4X3;
            MApp_Scaler_Setting_SetVDScale(ST_VIDEO.eAspectRatio, MAIN_WINDOW);
            break;

        case EN_EXE_SET_DSC_KEY_ARC16X9:
            ST_VIDEO.eAspectRatio = EN_AspectRatio_16X9;
            MApp_Scaler_Setting_SetVDScale(ST_VIDEO.eAspectRatio, MAIN_WINDOW);
            break;

        case EN_EXE_SET_DSC_KEY_ARCZOOM:
            ST_VIDEO.eAspectRatio = EN_AspectRatio_Zoom1;
            MApp_Scaler_Setting_SetVDScale(ST_VIDEO.eAspectRatio, MAIN_WINDOW);
            break;
    }
}

BOOLEAN MApp_ZUI_ACT_ExecuteHotkeyOptionAction(U16 act)
{
    #if (ENABLE_PIP)
    MS_WINDOW_TYPE tTempSubWin,stPOPSubWin,stPOPMainWin;
    U8 u8TempPIP_Offset = 3;
    U16 u16TempPIP_Width = (PANEL_WIDTH - SCREEN_SAVER_FRAME_WIDTH)/2 - u8TempPIP_Offset;
    U16 u16TempPIP_Height = u16TempPIP_Width*PANEL_HEIGHT/PANEL_WIDTH;

    if(IsPIPSupported())
    {
        tTempSubWin.x = 0;
        tTempSubWin.y = 0;
        tTempSubWin.width = u16TempPIP_Width;
        tTempSubWin.height = u16TempPIP_Height;
    }
    #endif

    switch(act)
    {
        //cus_xm:zb modify  at 2012-8-16
        case EN_EXE_CLOSE_CURRENT_OSD:
		MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
		return TRUE;
        case EN_EXE_POWEROFF:
            //MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
	      	MApp_ZUI_ACT_ExecuteEffectSettingAction(EN_EXE_POWEROFF);
		return FALSE;

        case EN_EXE_RESET_AUTO_CLOSE_TIMER:
            //reset timer if any key
            MApp_ZUI_API_ResetTimer(HWND_HOTKEY_BG, 0);
            return FALSE;

        case EN_EXE_DEC_SLEEP_HOTKEY_OPTION:
        case EN_EXE_INC_SLEEP_HOTKEY_OPTION:
            {
                if (_eHotkeyMode != EN_HOTKEY_MODE_SLEEP) //do nothing if not sleep mode...
                    return TRUE;

                _MApp_ZUI_ACT_DecIncSleepTimer_Cycle(
                    act==EN_EXE_INC_SLEEP_HOTKEY_OPTION);
                MApp_ZUI_API_InvalidateWindow(HWND_HOTKEY_SLEEP_TIMER_TEXT);
            }
            return TRUE;

        case EN_EXE_SHOW_SLEEP_HOTKEY:
            if (_eHotkeyMode != EN_HOTKEY_MODE_SLEEP)
            {
                _eHotkeyMode = EN_HOTKEY_MODE_SLEEP;
                MApp_ZUI_API_ShowWindow(HWND_MAINFRAME, SW_HIDE);
                MApp_ZUI_API_ShowWindow(HWND_HOTKEY_BG, SW_SHOW);
                MApp_ZUI_API_ShowWindow(HWND_HOTKEY_SLEEP_TIMER, SW_SHOW);
                MApp_ZUI_API_SetFocus(HWND_HOTKEY_SLEEP_TIMER_TEXT);
            }
            return TRUE;

        case EN_EXE_DEC_ATV_MTS_HOTKEY_OPTION:
        case EN_EXE_INC_ATV_MTS_HOTKEY_OPTION:
            {
                if (_eHotkeyMode != EN_HOTKEY_MODE_ATV_MTS) //do nothing if not mts mode...
                    return TRUE;

                msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_INTERNAL_4_MUTEON, E_AUDIOMUTESOURCE_ACTIVESOURCE);
                msAPI_Timer_Delayms(DELAY_FOR_ENTERING_MUTE);
                msAPI_AUD_AdjustAudioFactor(E_ADJUST_CHANGE_AUDIOMODE, 0, 0);
                msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_INTERNAL_4_MUTEOFF, E_AUDIOMUTESOURCE_ACTIVESOURCE);

                MApp_ZUI_API_InvalidateWindow(HWND_HOTKEY_MTS_TEXT);
            }
            return TRUE;

        case EN_EXE_SHOW_ATV_MTS_HOTKEY:
            #if ENABLE_DTV
            if (IsDTVInUse())
            {
                Mapp_DTV_ProcessMTS();
            }
            else
            #endif
            if (_eHotkeyMode != EN_HOTKEY_MODE_ATV_MTS)
            {
                _eHotkeyMode = EN_HOTKEY_MODE_ATV_MTS;
                MApp_ZUI_API_ShowWindow(HWND_MAINFRAME, SW_HIDE);
                MApp_ZUI_API_ShowWindow(HWND_HOTKEY_BG, SW_SHOW);
                MApp_ZUI_API_ShowWindow(HWND_HOTKEY_MTS, SW_SHOW);
                MApp_ZUI_API_SetFocus(HWND_HOTKEY_MTS_TEXT);
            }
            return TRUE;

        case EN_EXE_DEC_PICTURE_HOTKEY_OPTION:
        case EN_EXE_INC_PICTURE_HOTKEY_OPTION:
            {
                if (_eHotkeyMode != EN_HOTKEY_MODE_PICTURE) //do nothing if not picture mode...
                    return TRUE;

                ST_VIDEO.ePicture = (EN_MS_PICTURE) MApp_ZUI_ACT_DecIncValue_Cycle(
                    act==EN_EXE_INC_PICTURE_HOTKEY_OPTION,
                    ST_VIDEO.ePicture, PICTURE_MIN, PICTURE_NUMS-1, 1);
              #if 0//VGA_HDMI_YUV_POINT_TO_POINT
                    MDrv_PQ_SetUserColorMode(ENABLE);
              #endif
                    MApp_Picture_Setting_SetColor(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW), MAIN_WINDOW);  //MApp_PicSetPicture( (T_MS_PICTURE *) &ST_PICTURE, SYS_INPUT_SOURCE_TYPE);
              #if 0//VGA_HDMI_YUV_POINT_TO_POINT
                   MDrv_PQ_SetUserColorMode(DISABLE);
              #endif

                MApp_ZUI_API_InvalidateWindow(HWND_HOTKEY_PICTURE_MODE_TEXT);
            }
            return TRUE;

        case EN_EXE_SHOW_PICTURE_HOTKEY:
            if (_eHotkeyMode != EN_HOTKEY_MODE_PICTURE)
            {
                _eHotkeyMode = EN_HOTKEY_MODE_PICTURE;
                MApp_ZUI_API_ShowWindow(HWND_MAINFRAME, SW_HIDE);
                MApp_ZUI_API_ShowWindow(HWND_HOTKEY_BG, SW_SHOW);
                MApp_ZUI_API_ShowWindow(HWND_HOTKEY_PICTURE_MODE, SW_SHOW);
                MApp_ZUI_API_SetFocus(HWND_HOTKEY_PICTURE_MODE_TEXT);
            }
            return TRUE;

        #if (ENABLE_PIP)
        case EN_EXE_DEC_PIP_HOTKEY_OPTION:
        case EN_EXE_INC_PIP_HOTKEY_OPTION:
            if(IsPIPSupported())
            {
                EN_PIP_MODE enPreMode = stGenSetting.g_stPipSetting.enPipMode;
                stGenSetting.g_stPipSetting.enPipMode=
                (EN_PIP_MODE) MApp_ZUI_ACT_DecIncValue_Cycle(
                    act==EN_EXE_INC_PIPMODE,
                    stGenSetting.g_stPipSetting.enPipMode, EN_PIP_MODE_PIP, EN_PIP_MODE_OFF, 1);

                if(IsPIPEnable())
                {
                    //Close TTX, TTX Subtitle
                    #if (ENABLE_TTX)
                    if(MApp_TTX_IsTeletextOn())
                    {
                        MApp_TTX_TeletextCommand(TTX_TV);
                    }
                    #endif

                    #if MHEG5_ENABLE
                    if(MApp_MHEG5_CheckGoMHEG5Process())
                    {
                        MApi_MHEG5_Disable(EN_MHEG5_DM_DISABLE_WITH_AUTOBOOT_LATER);
                    }
                    #endif
                    //Disable MWE
                    #if (MWE_FUNCTION)
                    if(MApi_XC_ACE_MWEStatus())
                    {
                           MApi_XC_ACE_EnableMWE(FALSE);
                    }
                    #endif
                }

                stPOPMainWin.x = 0;
                stPOPMainWin.y = 0;
                stPOPMainWin.width = PANEL_WIDTH;
                stPOPMainWin.height = PANEL_HEIGHT;

                {
                    PQ_DISPLAY_TYPE enDisplaType = PQ_DISPLAY_ONE;

                    switch(stGenSetting.g_stPipSetting.enPipMode)
                    {
                        case EN_PIP_MODE_PIP:
                            enDisplaType = PQ_DISPLAY_PIP;
                        break;
                        case EN_PIP_MODE_POP_FULL:
                        case EN_PIP_MODE_POP:
                            enDisplaType = PQ_DISPLAY_POP;
                        break;
                        case EN_PIP_MODE_OFF:
                        case EN_PIP_MODE_INVALID:
                            enDisplaType = PQ_DISPLAY_ONE;
                        break;
                    }
                    MDrv_PQ_Set_DisplayType(g_IPanel.Width(), enDisplaType);
                }
                msAPI_Scaler_SetScreenMute(E_SCREEN_MUTE_FREERUN, ENABLE, 0, MAIN_WINDOW);
                msAPI_Scaler_SetScreenMute(E_SCREEN_MUTE_FREERUN, ENABLE, 0, SUB_WINDOW);
                if(enPreMode == EN_PIP_MODE_OFF)
                {
                    //Check sub src compatible with main src,
                    // if not compatible, find src for sub win.
                    if(!MApp_InputSource_PIP_IsSrcCompatible(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW),
                                MApp_InputSource_GetInputSourceType(UI_SUB_INPUT_SOURCE_TYPE)))
                    {
                        stGenSetting.g_stPipSetting.enSubInputSourceType = MApp_InputSource_GetUIInputSourceType(MApp_InputSource_PIP_Get1stCompatibleSrc(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)));
                    }

                    MApp_InputSource_ChangeInputSource(SUB_WINDOW);
                }
                else if(enPreMode == EN_PIP_MODE_PIP)
                {
                    MApi_XC_EnableBorder(DISABLE, SUB_WINDOW);
                }

                if(stGenSetting.g_stPipSetting.enPipMode == EN_PIP_MODE_OFF)
                {
                    //Audio Source Switch
                    if(stGenSetting.g_stPipSetting.enPipSoundSrc==EN_PIP_SOUND_SRC_SUB)
                    {
                        stGenSetting.g_stPipSetting.enPipSoundSrc=EN_PIP_SOUND_SRC_MAIN;
                        MApp_InputSource_PIP_ChangeAudioSource(MAIN_WINDOW);
                    }
                    MApp_ZUI_API_InvalidateWindow(HWND_MENU_PIP_SOUND_SRC_OPTION);
                    E_UI_INPUT_SOURCE ePreSrc = UI_SUB_INPUT_SOURCE_TYPE;
                    UI_SUB_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_NONE;
                    MApp_InputSource_ChangeInputSource(SUB_WINDOW);
                    UI_SUB_INPUT_SOURCE_TYPE = ePreSrc;
                }

                //sub window info : x, y, width, height for scaler
                if(stGenSetting.g_stPipSetting.enPipMode == EN_PIP_MODE_PIP)
                {
                    switch(stGenSetting.g_stPipSetting.enPipSize)
                    {
                        default:
                        case EN_PIP_SIZE_LARGE: //125%
                               tTempSubWin.width = u16TempPIP_Width;
                               tTempSubWin.height = u16TempPIP_Height;
                               break;
                        case EN_PIP_SIZE_MEDIUM: //100%
                               tTempSubWin.width = u16TempPIP_Width/5*4;
                               tTempSubWin.height = tTempSubWin.width*PANEL_HEIGHT/PANEL_WIDTH;
                               break;
                        case EN_PIP_SIZE_SMALL: //75%
                               tTempSubWin.width = u16TempPIP_Width/5*3;
                               tTempSubWin.height = tTempSubWin.width*PANEL_HEIGHT/PANEL_WIDTH;
                               break;
                    }

                    switch(stGenSetting.g_stPipSetting.enPipPosition)
                    {
                        default:
                        case EN_PIP_POSITION_LEFT_TOP:
                            tTempSubWin.x = 0;
                            tTempSubWin.y = 0;
                            break;
                        case EN_PIP_POSITION_RIGHT_TOP:
                            tTempSubWin.x = (PANEL_WIDTH - tTempSubWin.width);
                            tTempSubWin.y = 0;
                            break;
                        case EN_PIP_POSITION_LEFT_BOTTOM:
                            tTempSubWin.x = 0;
                            tTempSubWin.y = (PANEL_HEIGHT - tTempSubWin.height);
                            break;
                        case EN_PIP_POSITION_RIGHT_BOTTOM:
                            tTempSubWin.x = (PANEL_WIDTH - tTempSubWin.width);
                            tTempSubWin.y = (PANEL_HEIGHT - tTempSubWin.height);
                            break;
                    }

                    MApp_Scaler_SetWindow(
                        NULL,
                        NULL,
                        &stPOPMainWin,
                        stSystemInfo[MAIN_WINDOW].enAspectRatio,
                        SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW),
                        MAIN_WINDOW);
                    MDrv_PQ_LoadSettings(PQ_MAIN_WINDOW);

                    MApp_Scaler_SetWindow(
                        NULL,
                        NULL,
                        &tTempSubWin,
                        stSystemInfo[MAIN_WINDOW].enAspectRatio,
                        SYS_INPUT_SOURCE_TYPE(SUB_WINDOW),
                        SUB_WINDOW);
                    MDrv_PQ_LoadSettings(PQ_SUB_WINDOW);
                    MApi_XC_EnableBorder(stGenSetting.g_stPipSetting.bBolderEnable, SUB_WINDOW);
                }
                else if(stGenSetting.g_stPipSetting.enPipMode == EN_PIP_MODE_POP_FULL)
                {
                    stPOPMainWin.width = PANEL_WIDTH/2;
                    stPOPMainWin.height = PANEL_HEIGHT;
                    stPOPSubWin.width = stPOPMainWin.width;
                    stPOPSubWin.height = stPOPMainWin.height;

                    stPOPMainWin.x = 0;
                    stPOPMainWin.y = 0;
                    stPOPSubWin.x = PANEL_WIDTH/2;
                    stPOPSubWin.y = 0;

                    MApp_Scaler_SetWindow(
                        NULL,
                        NULL,
                        &stPOPMainWin,
                        stSystemInfo[MAIN_WINDOW].enAspectRatio,
                        SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW),
                        MAIN_WINDOW);
                    MDrv_PQ_LoadSettings(PQ_MAIN_WINDOW);

                    MApp_Scaler_SetWindow(
                        NULL,
                        NULL,
                        &stPOPSubWin,
                        stSystemInfo[MAIN_WINDOW].enAspectRatio,
                        SYS_INPUT_SOURCE_TYPE(SUB_WINDOW),
                        SUB_WINDOW);
                    MDrv_PQ_LoadSettings(PQ_SUB_WINDOW);
                }
                else if(stGenSetting.g_stPipSetting.enPipMode == EN_PIP_MODE_POP)
                {
                    stPOPMainWin.width = PANEL_WIDTH/2;
                    stPOPMainWin.height = stPOPMainWin.width * PANEL_HEIGHT / PANEL_WIDTH;
                    stPOPSubWin.width = stPOPMainWin.width;
                    stPOPSubWin.height = stPOPMainWin.height;

                    stPOPMainWin.x = 0;
                    stPOPMainWin.y = PANEL_HEIGHT/2-stPOPSubWin.height/2;
                    stPOPSubWin.y = stPOPMainWin.y;
                    stPOPSubWin.x = PANEL_WIDTH/2;

                    MApp_Scaler_SetWindow(
                        NULL,
                        NULL,
                        &stPOPMainWin,
                        stSystemInfo[MAIN_WINDOW].enAspectRatio,
                        SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW),
                        MAIN_WINDOW);
                    MDrv_PQ_LoadSettings(PQ_MAIN_WINDOW);

                    MApp_Scaler_SetWindow(
                        NULL,
                        NULL,
                        &stPOPSubWin,
                        stSystemInfo[MAIN_WINDOW].enAspectRatio,
                        SYS_INPUT_SOURCE_TYPE(SUB_WINDOW),
                        SUB_WINDOW);
                    MDrv_PQ_LoadSettings(PQ_SUB_WINDOW);
                }
                else
                {
                    //if(act == EN_EXE_DEC_PIPMODE)//switch from EN_PIP_MODE_PIP to EN_PIP_MODE_OFF
                    {
                        MApp_Scaler_SetWindow(
                            NULL,
                            NULL,
                            NULL,
                            stSystemInfo[MAIN_WINDOW].enAspectRatio,
                            SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW),
                            MAIN_WINDOW);
                    }
                    SYS_SCREEN_SAVER_TYPE(SUB_WINDOW) = EN_SCREENSAVER_NULL; //pip off, set sub-win SS status as NULL
                }

                msAPI_Scaler_SetScreenMute(E_SCREEN_MUTE_FREERUN, DISABLE, 0, MAIN_WINDOW);
                msAPI_Scaler_SetScreenMute(E_SCREEN_MUTE_FREERUN, DISABLE, 0, SUB_WINDOW);
                MApp_ZUI_API_InvalidateWindow(HWND_HOTKEY_PIP_MODE_TEXT);
                return TRUE;
            }
            return TRUE;

        case EN_EXE_SHOW_PIP_HOTKEY:
            if (_eHotkeyMode != EN_HOTKEY_MODE_PIP)
            {
                _eHotkeyMode = EN_HOTKEY_MODE_PIP;
                MApp_ZUI_API_ShowWindow(HWND_MAINFRAME, SW_HIDE);
                MApp_ZUI_API_ShowWindow(HWND_HOTKEY_BG, SW_SHOW);
                MApp_ZUI_API_ShowWindow(HWND_HOTKEY_PIP_MODE, SW_SHOW);
                MApp_ZUI_API_SetFocus(HWND_HOTKEY_PIP_MODE_TEXT);
            }
            return TRUE;
        #endif

        case EN_EXE_DEC_AUDIO_HOTKEY_OPTION:
        case EN_EXE_INC_AUDIO_HOTKEY_OPTION:
            {
                if (_eHotkeyMode != EN_HOTKEY_MODE_AUDIO) //do nothing if not sund mode...
                    return TRUE;

                stGenSetting.g_SoundSetting.SoundMode =
                   (EN_SOUND_MODE) MApp_ZUI_ACT_DecIncValue_Cycle(
                        act==EN_EXE_INC_AUDIO_HOTKEY_OPTION,
                        stGenSetting.g_SoundSetting.SoundMode,
                        EN_SoundMode_Standard, EN_SoundMode_Num-1, 1);

#if (ENABLE_CUS_SURROUND_FOLLOW_SNDMODE == DISABLE)
                MApp_Aud_SetSurroundMode( stGenSetting.g_SoundSetting.SurroundSoundMode );
#else
                MApp_Aud_SetSurroundMode( stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].SurroundSoundMode );
#endif

                MApp_Audio_AdjustSoundMode();		// CUS_XM Sea 20120725:

                MApp_ZUI_API_InvalidateWindow(HWND_HOTKEY_SOUND_MODE_TEXT);
            }
            return TRUE;

        case EN_EXE_SHOW_AUDIO_HOTKEY:
            if (_eHotkeyMode != EN_HOTKEY_MODE_AUDIO)
            {
                _eHotkeyMode = EN_HOTKEY_MODE_AUDIO;
                MApp_ZUI_API_ShowWindow(HWND_MAINFRAME, SW_HIDE);
                MApp_ZUI_API_ShowWindow(HWND_HOTKEY_BG, SW_SHOW);
                MApp_ZUI_API_ShowWindow(HWND_HOTKEY_SOUND_MODE, SW_SHOW);
                MApp_ZUI_API_SetFocus(HWND_HOTKEY_SOUND_MODE_TEXT);
            }
            return TRUE;

        case EN_EXE_DEC_SCALE_HOTKEY_OPTION:
        case EN_EXE_INC_SCALE_HOTKEY_OPTION:
        case EN_EXE_SET_DSC_KEY_ARC4X3:
        case EN_EXE_SET_DSC_KEY_ARC16X9:
        case EN_EXE_SET_DSC_KEY_ARCZOOM:
            #if (ENABLE_PIP)
            if(IsPIPEnable()&&((stGenSetting.g_stPipSetting.enPipMode==EN_PIP_MODE_POP)||(stGenSetting.g_stPipSetting.enPipMode==EN_PIP_MODE_POP_FULL)))
                return TRUE;
            #endif

            if (_eHotkeyMode != EN_HOTKEY_MODE_SCALE) //do nothing if not sleep mode...
                return TRUE;

            #if ENABLE_3D_PROCESS
            if(IsHDMIInUse())
            {
			    #if ENABLE_CUS_3D_SOURCE_MEMORY
                if(g_HdmiPollingStatus.bIsHDMIMode == FALSE)
                {
                    if(ST_VGA_3D_TYPE != EN_3D_BYPASS)
                    {
                        return TRUE;
                    }
                }
                else
				#endif
                {
                    if(stGenSetting.g_SysSetting.en3DDetectMode == EN_3D_DETECT_AUTO)
                    {
                        if(g_HdmiInput3DFormatStatus!=E_XC_3D_INPUT_MODE_NONE)
                            return TRUE;
                    }
                    else if(ST_3D_TYPE != EN_3D_BYPASS)
                    {
                        return TRUE;
                    }
                }
            }
            else
            {
                if(ST_3D_TYPE != EN_3D_BYPASS)
                {
                    return TRUE;
                }
            }
            #endif

#if 0//(MHEG5_ENABLE) //from MApp_MHEG5_Main.c
            if (MApp_TopStateMachine_GetTopState()==STATE_TOP_TTX)
            {
                g_MHEG5Video.bARCChange = TRUE;
            }
#endif       //from MApp_MHEG5_Main.c
            if(g_bIsImageFrozen)
            {
                g_bIsImageFrozen = FALSE;
                MApi_XC_FreezeImg(g_bIsImageFrozen, MAIN_WINDOW);
            }

            _MApp_ZUI_ACT_ExecuteZoomAction(act);

#if 0//(MHEG5_ENABLE) //from MApp_MHEG5_Main.c
            if (MApp_TopStateMachine_GetTopState()==STATE_TOP_TTX)
            {
                g_MHEG5Video.bARCChange = FALSE;
            }
#endif       //from MApp_MHEG5_Main.c


            MApp_ZUI_API_InvalidateWindow(HWND_HOTKEY_ZOOM_TEXT);
            return TRUE;

        case EN_EXE_ZOOM_ARROW_RIGHT:
        case EN_EXE_ZOOM_ARROW_LEFT:

            if (_eHotkeyMode != EN_HOTKEY_MODE_SCALE) //do nothing if not sleep mode...
                return TRUE;

#if 0//(MHEG5_ENABLE) //from MApp_MHEG5_Main.c
            if (MApp_TopStateMachine_GetTopState()==STATE_TOP_TTX)
            {
                g_MHEG5Video.bARCAdj_H = TRUE;
            }
#endif       //from MApp_MHEG5_Main.c

            _MApp_ZUI_ACT_ExecuteZoomAction(act);

#if 0//(MHEG5_ENABLE) //from MApp_MHEG5_Main.c
            if (MApp_TopStateMachine_GetTopState()==STATE_TOP_TTX)
            {
                msAPI_MHEG5_SetGraphARCInfoDefault(SENDARC_ARC_CHANGE,stSystemInfo.enAspectRatio);
                g_MHEG5Video.bARCAdj_H = FALSE;
            }
#endif       //from MApp_MHEG5_Main.c

            MApp_ZUI_API_InvalidateWindow(HWND_HOTKEY_ZOOM_TEXT);
            return TRUE;

        case EN_EXE_ZOOM_ARROW_UP:
        case EN_EXE_ZOOM_ARROW_DOWN:

            if (_eHotkeyMode != EN_HOTKEY_MODE_SCALE) //do nothing if not sleep mode...
                return TRUE;

#if (MHEG5_ENABLE) //from MApp_MHEG5_Main.c
            if (MApp_TopStateMachine_GetTopState()==STATE_TOP_TTX)
            {
                g_MHEG5Video.bARCAdj_V = TRUE;
            }
#endif       //from MApp_MHEG5_Main.c

            _MApp_ZUI_ACT_ExecuteZoomAction(act);

#if (MHEG5_ENABLE) //from MApp_MHEG5_Main.c
            if (MApp_TopStateMachine_GetTopState()==STATE_TOP_TTX)
            {
                MApp_MHEG5_SetGraphARCInfo(SENDARC_ARC_CHANGE,stSystemInfo[MAIN_WINDOW].enAspectRatio);
                g_MHEG5Video.bARCAdj_V = FALSE;
            }
#endif       //from MApp_MHEG5_Main.c

            MApp_ZUI_API_InvalidateWindow(HWND_HOTKEY_ZOOM_TEXT);
            return TRUE;

        case EN_EXE_SHOW_SCALE_HOTKEY:
            if (_eHotkeyMode != EN_HOTKEY_MODE_SCALE)
            {
                _eHotkeyMode = EN_HOTKEY_MODE_SCALE;
                MApp_ZUI_API_ShowWindow(HWND_MAINFRAME, SW_HIDE);
                MApp_ZUI_API_ShowWindow(HWND_HOTKEY_BG, SW_SHOW);
                MApp_ZUI_API_ShowWindow(HWND_HOTKEY_ZOOM, SW_SHOW);
                MApp_ZUI_API_SetFocus(HWND_HOTKEY_ZOOM_TEXT);
            }
            return TRUE;

        case EN_EXE_ONOFF_FREEZE_HOTKEY_OPTION:
            if (_eHotkeyMode != EN_HOTKEY_MODE_FREEZE) //do nothing if not free mode...
                return TRUE;

            if (g_bIsImageFrozen)
            {
                g_bIsImageFrozen = FALSE;
            }
            else
            {
                g_bIsImageFrozen = TRUE;
            }
            MApi_XC_FreezeImg(g_bIsImageFrozen, MAIN_WINDOW);

            MApp_ZUI_API_InvalidateWindow(HWND_HOTKEY_FREEZE_TEXT);
            return TRUE;

        case EN_EXE_SHOW_FREEZE_HOTKEY:
            #if 0//ENABLE_CUS_UI_SPEC
            if(IsVgaInUse() || (IsHDMIInUse() && g_HdmiPollingStatus.bIsHDMIMode == FALSE) || (MApp_IsSrcHasSignal(MAIN_WINDOW) == FALSE)||MApp_UiMenuFunc_CheckInputLockAudioVideo())//cus_xm:zb modify at 2012-8-16
            #else
            if(MApp_Scaler_CheckDBC_DLCAvailable() || (MApp_IsSrcHasSignal(MAIN_WINDOW) == FALSE))
            #endif
            {
                if (_eHotkeyMode != EN_HOTKEY_MODE_UNSUPPORT_MSG)
                {
                    _eHotkeyMode = EN_HOTKEY_MODE_UNSUPPORT_MSG;
                    MApp_ZUI_API_ShowWindow(HWND_MAINFRAME, SW_HIDE);
                    MApp_ZUI_API_ShowWindow(HWND_HOTKEY_BG, SW_SHOW);
                    MApp_ZUI_API_ShowWindow(HWND_HOTKEY_PIP_MODE, SW_SHOW);
                    MApp_ZUI_API_SetFocus(HWND_HOTKEY_PIP_MODE_TEXT);
                }
            }
            else
            {
                if (_eHotkeyMode != EN_HOTKEY_MODE_FREEZE)
                {
                    _eHotkeyMode = EN_HOTKEY_MODE_FREEZE;
                    MApp_ZUI_API_ShowWindow(HWND_MAINFRAME, SW_HIDE);
                    MApp_ZUI_API_ShowWindow(HWND_HOTKEY_BG, SW_SHOW);
                    MApp_ZUI_API_ShowWindow(HWND_HOTKEY_FREEZE, SW_SHOW);
                    MApp_ZUI_API_SetFocus(HWND_HOTKEY_FREEZE_TEXT);
                }
            }
            return TRUE;
 #if (ENABLE_SBTVD_BRAZIL_APP || (ATSC_CC == DTV_CC))
    case EN_EXE_INC_CC_HOTKEY_OPTION:
        if (IsATVInUse() || IsAVInUse()  || IsSVInUse() || IsDTVInUse())
        {
        if (_eHotkeyMode != EN_HOTKEY_MODE_CC) //do nothing if not CCD...
            return TRUE;

        if(IsDTVInUse())
        {
            stGenSetting.g_SysSetting.enDTVCaptionType=
            (EN_DTV_CAPTION_TYPE) MApp_ZUI_ACT_DecIncValue_Cycle(
                act==EN_EXE_INC_CC_HOTKEY_OPTION,
                stGenSetting.g_SysSetting.enDTVCaptionType, DTV_CAPTION_OFF, DTV_CAPTION_ON, 1);

            if (stGenSetting.g_SysSetting.enDTVCaptionType == DTV_CAPTION_OFF
                && MApp_CC_GetInfo(CC_SELECTOR_STATUS_CODE) == STATE_CAPTION_PARSER)
            {
                MApp_CC_StopParser();
                MApp_Dmx_PES_Stop();
            }
        }
        else if (IsATVInUse() || IsAVInUse()  || IsSVInUse() )
        {
            stGenSetting.g_SysSetting.enATVCaptionType=
            (EN_ATV_CAPTION_TYPE) MApp_ZUI_ACT_DecIncValue_Cycle(
                act==EN_EXE_INC_CC_HOTKEY_OPTION,
                stGenSetting.g_SysSetting.enATVCaptionType, ATV_CAPTION_TYPE_OFF, ATV_CAPTION_TYPE_NUM-1, 1);

            if (stGenSetting.g_SysSetting.enATVCaptionType == ATV_CAPTION_TYPE_OFF
                && MApp_CC_GetInfo(CC_SELECTOR_STATUS_CODE) == STATE_CAPTION_PARSER)
            {
                MApp_CC_StopParser();
                MApp_Dmx_PES_Stop();
            }
        }
        MApp_ZUI_API_InvalidateWindow(HWND_HOTKEY_CC_TEXT);
        }
        return TRUE;

    case EN_EXE_SHOW_CC_HOTKEY:
        if (IsATVInUse() || IsAVInUse()  || IsSVInUse() || IsDTVInUse())
        {
        if (_eHotkeyMode != EN_HOTKEY_MODE_CC)
        {
            _eHotkeyMode = EN_HOTKEY_MODE_CC;
            MApp_ZUI_API_ShowWindow(HWND_MAINFRAME, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_HOTKEY_BG, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_HOTKEY_CC, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_HOTKEY_CC_TEXT, SW_SHOW);
            MApp_ZUI_API_SetFocus(HWND_HOTKEY_CC_TEXT);
        }
        }
        return TRUE;
    case EN_EXE_SHOW_HOTKEY_UNSUPPORT_MSG:
        if (_eHotkeyMode != EN_HOTKEY_MODE_UNSUPPORT_MSG)
        {
            _eHotkeyMode = EN_HOTKEY_MODE_UNSUPPORT_MSG;
            MApp_ZUI_API_ShowWindow(HWND_MAINFRAME, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_HOTKEY_BG, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_HOTKEY_PIP_MODE, SW_SHOW);
            MApp_ZUI_API_SetFocus(HWND_HOTKEY_PIP_MODE_TEXT);
        }
        return TRUE;

#endif

    }
    return FALSE;
}

void _MApp_ZUI_ACT_GetSleepTimerString(LPTSTR str)
{
    if(MApp_Sleep_GetCurrentSleepState() == STATE_SLEEP_OFF)
    {
		//MApp_ZUI_API_LoadString(en_str_Sleep, str);
		//str += MApp_ZUI_API_Strlen(str);
		//*str++ = CHAR_SPACE;
		//*str++ = CHAR_COLON;
		//*str++ = CHAR_SPACE;
        if(E_OSD_HOTKEY_OPTION == MApp_ZUI_GetActiveOSD())
        {
    		MApp_ZUI_API_LoadString(en_str_Sleep, str);
    		str += MApp_ZUI_API_Strlen(str);
    		*str++ = CHAR_SPACE;
    		*str++ = CHAR_COLON;
    		*str++ = CHAR_SPACE;
        }
        MApp_ZUI_API_LoadString(en_str_SleepTimer_Cancel, str);
    }
    else
    {
		MApp_ZUI_API_LoadString(en_str_Sleep, str);
        U32 u32SleepTime = MApp_Sleep_GetSleepTimeRemainTime();
        U8 u8SleepDigits = MApp_GetNoOfDigit(u32SleepTime);
        if(E_OSD_HOTKEY_OPTION == MApp_ZUI_GetActiveOSD()||E_OSD_DMP==MApp_ZUI_GetActiveOSD())//cus_xm:zb modify at 2012-8-8
        {
    		MApp_ZUI_API_LoadString(en_str_Sleep, str);

    		str += MApp_ZUI_API_Strlen(str);
    		*str++ = CHAR_SPACE;
    		*str++ = CHAR_COLON;
    		*str++ = CHAR_SPACE;
        }
        __MApp_UlongToString(u32SleepTime, str, u8SleepDigits);
        MApp_ZUI_API_LoadString(en_str_SleepTimer_Min, str + u8SleepDigits);
    }
}

#if ENABLE_CUS_AUTO_SLEEP_MODE
void _MApp_ZUI_ACT_GetAutosleepString(LPTSTR str)
{
    if(stGenSetting.g_Time.cAutoSleepFlag == EN_Time_AutoOff_Off)
    {
        MApp_ZUI_API_LoadString(en_str_Off, str);
    }
    else
    {
        U32 u32SleepTime = 0;
        if(stGenSetting.g_Time.cAutoSleepFlag == EN_Time_AutoOff_On_1Hour)
        {
            u32SleepTime = 1;
        }
        else if(stGenSetting.g_Time.cAutoSleepFlag == EN_Time_AutoOff_On_2Hours)
        {
            u32SleepTime = 2;
        }
        else if(stGenSetting.g_Time.cAutoSleepFlag == EN_Time_AutoOff_On_5Hours)
        {
            u32SleepTime = 5;
        }

        U8 u8SleepDigits = MApp_GetNoOfDigit(u32SleepTime);
        __MApp_UlongToString(u32SleepTime, str, u8SleepDigits);

        if(u32SleepTime < 2)
        {
            MApp_ZUI_API_LoadString(en_str_SleepTimer_1_Hour, str + u8SleepDigits);
        }
        else
        {
            MApp_ZUI_API_LoadString(en_str_SleepTimer_Hours, str + u8SleepDigits);
        }
    }
}

#endif
static LPTSTR _MApp_ZUI_ACT_GeHotkeySleepDynamicText(void)
{
    _MApp_ZUI_ACT_GetSleepTimerString(CHAR_BUFFER);

    return CHAR_BUFFER;
}

static LPTSTR _MApp_ZUI_ACT_GeHotkeyFreezeDynamicText(void)
{
    LPTSTR str = CHAR_BUFFER;

    MApp_ZUI_API_LoadString(en_str_Freeze, str);
    str += MApp_ZUI_API_Strlen(str);
    *str++ = CHAR_SPACE;
    *str++ = CHAR_COLON;
    *str++ = CHAR_SPACE;

    if (g_bIsImageFrozen)
        MApp_ZUI_API_LoadString(en_str_On, str);
    else
        MApp_ZUI_API_LoadString(en_str_Off, str);

    return CHAR_BUFFER;
}

static U16 _MApp_ZUI_ACT_GetATVMTSStringID(void)
{
    U16 u16TempID = Empty;
    //from case HOTKEYMTSTEXT:
    switch(m_eAudioMode)
    {
        case E_AUDIOMODE_INVALID:
        break;

        case E_AUDIOMODE_MONO:
            u16TempID=en_strMtsMonoText;
            break;

        case E_AUDIOMODE_FORCED_MONO:
            u16TempID=en_strMtsMonoText;
            break;

        case E_AUDIOMODE_G_STEREO:
            u16TempID=en_strMtsStereoText;
            break;

        case E_AUDIOMODE_K_STEREO:
            u16TempID=en_strMtsStereoText;
            break;

        case E_AUDIOMODE_MONO_SAP:
        case E_AUDIOMODE_STEREO_SAP:
            u16TempID=en_strMtsSapText;
            break;

        case E_AUDIOMODE_DUAL_A:
            u16TempID=en_strMtsDUAL_A_Text;
            break;

        case E_AUDIOMODE_DUAL_B:
            u16TempID=en_strMtsDUAL_B_Text;
            break;

        case E_AUDIOMODE_DUAL_AB:
            u16TempID=en_strMtsDUAL_AB_Text;
            break;

        case E_AUDIOMODE_NICAM_MONO:
            u16TempID=en_strMtsNICAM_MONO_Text;
            break;

        case E_AUDIOMODE_NICAM_STEREO:
            u16TempID=en_strMtsNICAM_STEREO_Text;
            break;
        break;

        case E_AUDIOMODE_NICAM_DUAL_A:
            u16TempID=en_strMtsNICAM_DUAL_A_Text;
            break;

        case E_AUDIOMODE_NICAM_DUAL_B:
            u16TempID=en_strMtsNICAM_DUAL_B_Text;
            break;

        case E_AUDIOMODE_NICAM_DUAL_AB:
            u16TempID=en_strMtsNICAM_DUAL_AB_Text;
            break;

        case E_AUDIOMODE_HIDEV_MONO:
            u16TempID=en_strMtsHIDEV_MONO_Text;
            break;

        case E_AUDIOMODE_LEFT_LEFT:
            u16TempID=en_strMtsLEFT_LEFT_Text;
            break;

        case E_AUDIOMODE_RIGHT_RIGHT:
            u16TempID=en_strMtsRIGHT_RIGHT_Text;
            break;

        case E_AUDIOMODE_LEFT_RIGHT:
            u16TempID=en_strMtsLEFT_RIGHT_Text;
            break;
        default:
            break;


    }
    return u16TempID;
}

//extern U16 _MApp_ZUI_ACT_GetPictureModeStringID(void);
//extern U16 _MApp_ZUI_ACT_GetAudioModeStringID(void);
extern U16 _MApp_ZUI_ACT_GetAspectRatioStringID(void);

LPTSTR MApp_ZUI_ACT_GetHotkeyOptionDynamicText(HWND hwnd)
{
    U16 u16TempID = Empty;
    switch(hwnd)
    {
        case HWND_HOTKEY_CC_TEXT:
        {
            switch(_eHotkeyMode)
            {
             #if ENABLE_SBTVD_BRAZIL_APP
                case EN_HOTKEY_MODE_CC:
                    if(IsDTVInUse())
                    {
                        LPTSTR str = CHAR_BUFFER;
                        MApp_ZUI_API_LoadString(en_str_Caption, str);
                        str += MApp_ZUI_API_Strlen(str);
                        *str++ = CHAR_SPACE;
                        *str++ = CHAR_COLON;
                        *str++ = CHAR_SPACE;
                        if(stGenSetting.g_SysSetting.enDTVCaptionType == DTV_CAPTION_ON)
                            MApp_ZUI_API_LoadString(en_str_On,str);
                        else
                            MApp_ZUI_API_LoadString(en_str_Off,str);
                            return CHAR_BUFFER;
                    }
                    else
                    {
                        LPTSTR str = CHAR_BUFFER;
                        MApp_ZUI_API_LoadString(en_str_Caption, str);
                        str += MApp_ZUI_API_Strlen(str);
                        *str++ = CHAR_SPACE;
                        *str++ = CHAR_COLON;
                        *str++ = CHAR_SPACE;
                        if(stGenSetting.g_SysSetting.enATVCaptionType == ATV_CAPTION_TYPE_CC1)
                            MApp_ZUI_API_LoadString(en_str_CC1,str);
                        else if(stGenSetting.g_SysSetting.enATVCaptionType == ATV_CAPTION_TYPE_CC2)
                            MApp_ZUI_API_LoadString(en_str_CC2,str);
                        else if(stGenSetting.g_SysSetting.enATVCaptionType == ATV_CAPTION_TYPE_CC3)
                            MApp_ZUI_API_LoadString(en_str_CC3,str);
                        else if(stGenSetting.g_SysSetting.enATVCaptionType == ATV_CAPTION_TYPE_CC4)
                            MApp_ZUI_API_LoadString(en_str_CC4,str);
                        else if(stGenSetting.g_SysSetting.enATVCaptionType == ATV_CAPTION_TYPE_TEXT1)
                            MApp_ZUI_API_LoadString(en_str_Text1,str);
                        else if(stGenSetting.g_SysSetting.enATVCaptionType == ATV_CAPTION_TYPE_TEXT2)
                            MApp_ZUI_API_LoadString(en_str_Text2,str);
                        else if(stGenSetting.g_SysSetting.enATVCaptionType == ATV_CAPTION_TYPE_TEXT3)
                            MApp_ZUI_API_LoadString(en_str_Text3,str);
                        else if(stGenSetting.g_SysSetting.enATVCaptionType == ATV_CAPTION_TYPE_TEXT4)
                            MApp_ZUI_API_LoadString(en_str_Text4,str);
                        else
                        {
                          stGenSetting.g_SysSetting.enATVCaptionType = ATV_CAPTION_TYPE_OFF;
                          MApp_ZUI_API_LoadString(en_str_Off,str);
                        }
                          return CHAR_BUFFER;
                    }
             #endif

            default:
                break;
            }
        }
        case HWND_HOTKEY_PICTURE_MODE_TEXT:
            u16TempID = _MApp_ZUI_ACT_GetPictureModeStringID();
            break;

        case HWND_HOTKEY_SOUND_MODE_TEXT:
            u16TempID = _MApp_ZUI_ACT_GetAudioModeStringID();
            break;


        case HWND_HOTKEY_ZOOM_TEXT:
	   if(MApp_IsSrcHasSignal(MAIN_WINDOW))//cus_xm:zb modify at 2012-7-25
            u16TempID = _MApp_ZUI_ACT_GetAspectRatioStringID();
	   else
	     u16TempID = en_str_SS_Invalid_Format;
         break;

        case HWND_HOTKEY_SLEEP_TIMER_TEXT:
            return _MApp_ZUI_ACT_GeHotkeySleepDynamicText();

        case HWND_HOTKEY_MTS_TEXT:
            u16TempID = _MApp_ZUI_ACT_GetATVMTSStringID();
            break;

        case HWND_HOTKEY_FREEZE_TEXT:
            return _MApp_ZUI_ACT_GeHotkeyFreezeDynamicText();

        #if (ENABLE_PIP)
        case HWND_HOTKEY_PIP_MODE_TEXT:
            if(IsPIPSupported())
            {
                switch(stGenSetting.g_stPipSetting.enPipMode)
                {
                   default:
                   case EN_PIP_MODE_PIP:
                        u16TempID = en_str_PIP_Mode_PIP;
                        break;
                   case EN_PIP_MODE_POP_FULL:
                        u16TempID = en_str_PIP_Mode_POP_FULL;
                        break;
                   case EN_PIP_MODE_POP:
                        u16TempID = en_str_PIP_Mode_POP;
                        break;
                   case EN_PIP_MODE_OFF:
                        u16TempID = en_str_Off;
                        break;
                }
            }
            break;
        #else
        case HWND_HOTKEY_PIP_MODE_TEXT:
            u16TempID = en_str_SS_Invalid_Format;
            break;
        #endif

        default:
            break;

    }

    if (u16TempID != Empty)
        return MApp_ZUI_API_GetString(u16TempID);
    return 0; //for empty string....
}
BOOL Mapp_ZUI_ACT_Hotkey_IsFreeze(void)
{
  if(MApp_ZUI_GetActiveOSD() != E_OSD_HOTKEY_OPTION)
     return FALSE;
  
  if(MApi_XC_IsFreezeImg(MAIN_WINDOW) && _eHotkeyMode == EN_HOTKEY_MODE_FREEZE)
  return TRUE;
  
  return FALSE;
}
void Mapp_ZUI_ACT_Hotkey_Freeze(void)
{
  if(MApp_ZUI_GetActiveOSD() != E_OSD_EMPTY)
	return;
  if(MApp_Scaler_CheckDBC_DLCAvailable() || (MApp_IsSrcHasSignal(MAIN_WINDOW) == FALSE))
  	return;
  
  if(MApi_XC_IsFreezeImg(MAIN_WINDOW))
  	{	
  		MApp_ZUI_ACT_StartupOSD(E_OSD_HOTKEY_OPTION);
  	    MApp_ZUI_ACT_ExecuteHotkeyOptionAction(EN_EXE_SHOW_FREEZE_HOTKEY);
  	}
}

#undef MAPP_ZUI_ACTHOTKEY_C
