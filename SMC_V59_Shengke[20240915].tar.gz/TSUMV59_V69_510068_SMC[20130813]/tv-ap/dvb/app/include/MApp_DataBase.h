////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef MAPP_DATABASE_H
#define MAPP_DATABASE_H



#include "msAPI_Mode.h"
#include "MsTypes.h"

//ZUI: #include "MApp_DispMenu.h"


/********************************************************************************/
/*                               Macro                                          */
/********************************************************************************/


/**********************************************************************************/


//*************************************************************************
//              Function prototypes
//*************************************************************************

#ifdef MAPP_DATABASE_C
#define INTERFACE
#else
#define INTERFACE extern
#endif

#if ENABLE_DUAL_DATABASE
INTERFACE U8 u8DataBaseBank;
#endif
INTERFACE U8 u8DataBaseSerialNumber; //move out of '#if ENABLE_DUAL_DATABASE' to fix logical error in MApp_DB_SaveDataBase() when disable 'ENABLE_DUAL_DATABASE'

//INTERFACE void MApp_DB_ResetGenSettingExt(void);
INTERFACE void MApp_DB_ResetGenSettingExt(U8 u8RestoreMask);
INTERFACE void MApp_DB_LoadGenSettingExt(void);

#if (EEPROM_DB_STORAGE!=EEPROM_SAVE_ALL)
INTERFACE void MApp_DB_SaveDataBase(void);
INTERFACE void MApp_DB_LoadChDataBase(void);
INTERFACE void MApp_DB_QuickDatabaseMonitor(void);
#endif

#if (HDCP_KEY_TYPE==HDCP_KEY_IN_DB)
void MApp_DB_LoadHDCP_KEY(MS_U8 *u8HdcpKey);
void MApp_DB_SaveHDCP_KEY( U32 u16Offset);
#endif


#undef INTERFACE
#endif
