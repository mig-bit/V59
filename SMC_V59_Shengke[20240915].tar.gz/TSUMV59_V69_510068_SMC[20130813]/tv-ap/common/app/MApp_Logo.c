////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#define MAPP_LOGO_C

///////////////////////////////////////////////////////////////////////////////
#include <stdlib.h>
#include <stdio.h>
#include "datatype.h"
#include "Board.h"

#if (DISPLAY_LOGO)|| defined(ENABLE_SANYO_WB_JPG)
// Common Definition
#include "MsCommon.h"
#include "apiXC.h"
#include "apiXC_Adc.h"

#include "drvCPU.h"
#include "msAPI_CPU.h"

#include "msAPI_MIU.h"
#include "msAPI_Timer.h"
#include "BinInfo.h"

#include "msAPI_Flash.h"

#include "MApp_Logo.h"
#include "MApp_GlobalSettingSt.h"
#include "MApp_ChannelChange.h"
#include "MApp_GlobalVar.h"
#include "MApp_GlobalFunction.h"
#include "MApp_InputSource.h"

#include "mapp_photo.h"
#include "mapp_photo_display.h"

/////////////////////////////////////////////////////

#define LOGO_DISPLAY_RESOLUTION     DTVRES_704x480_60P

#define LOGO_DBG(x)      x

#ifdef MSOS_TYPE_LINUX
char LOGO_FILE[] = "/chakra/LOGO.bin";
#endif

//**********************************************************
//static U32          g_u32LogoStartTime;         // used for boot logo only
static U32          g_u32LogoShowDuration_MS = 0;   // used for boot logo only
//static LOGO_INFO    g_BootLogoInfo;
#if (ENABLE_DMP == DISABLE)
U32 handshakeCnt;
#endif
//**********************************************************
#ifdef MSOS_TYPE_LINUX
BOOLEAN _MApp_Logo_LoadJpeg_From_File(U32 u32LogoAddr)
{
    extern BOOLEAN ReadFromFile(const char* fname,U32 offset,void* dest,U32 len);
    FILE *logo_fptr = NULL;
    U32 u32len;
    BOOLEAN bResult;

    logo_fptr = fopen(LOGO_FILE, "r");
    if(logo_fptr != NULL)
    {
        fseek(logo_fptr , 0 , SEEK_END);
        u32len = ftell(logo_fptr);
        rewind(logo_fptr);
        fclose(logo_fptr);
        bResult = ReadFromFile(LOGO_FILE, 0, (void *)_PA2VA(u32LogoAddr), u32len);
        return bResult;
    }

    return FALSE;
}
#endif
BOOLEAN _MApp_Logo_LoadJpeg(U16 u16LogoBinID)
{
    BININFO BinInfo;
    BOOLEAN bResult;
    U32 u32LogoAddr = ((MAD_JPEG_DISPLAY_MEMORY_TYPE & MIU1) ? (MAD_JPEG_DISPLAY_ADR | MIU_INTERVAL) : (MAD_JPEG_DISPLAY_ADR));

#if(ENABLE_MPLAYER_CAPTURE_LOGO)
    if(stGenSetting.g_SysSetting.UsrLogo == POWERON_LOGO_USER)
    {
        BinInfo.B_FAddr = USER_LOGO_FLASH_START_ADDR + stGenSetting.g_SysSetting.u8UsrLogoIdx * USER_LOGO_LENGTH_PER_LOGO;
        BinInfo.B_Len = USER_LOGO_LENGTH_PER_LOGO;

        //msAPI_Flash_ChipSelect(E_FLASH_CHIP_SELECT_1);
        //MDrv_SERFLASH_Init();
        msAPI_Flash_Read(BinInfo.B_FAddr, BinInfo.B_Len, (U8 *)_PA2VA(u32LogoAddr));
        //msAPI_Flash_ChipSelect(E_FLASH_CHIP_SELECT_0);
        //MDrv_SERFLASH_Init();
    }
    else
    {
        BinInfo.B_ID = u16LogoBinID;//(U32)BIN_ID_JPEG_BOOT_LOGO;
        MDrv_Sys_Get_BinInfo(&BinInfo, &bResult);
        if (bResult != PASS)
        {
            LOGO_DBG( printf( "could not find logo binary on flash.\n" ) );
            return FALSE;
        }

        msAPI_MIU_LoadLogo(BinInfo.B_FAddr, u32LogoAddr, GE_ALIGNED_VALUE(BinInfo.B_Len, 8));
    }
#else
    BinInfo.B_ID = u16LogoBinID;//(U32)BIN_ID_JPEG_BOOT_LOGO;
    MDrv_Sys_Get_BinInfo(&BinInfo, &bResult);

    if (bResult != PASS)
    {
        LOGO_DBG( printf( "could not find logo binary on flash.\n" ) );
        return FALSE;
    }

    msAPI_MIU_LoadLogo(BinInfo.B_FAddr, u32LogoAddr, GE_ALIGNED_VALUE(BinInfo.B_Len, 8));
#endif // #if(ENABLE_MPLAYER_CAPTURE_LOGO)

    return TRUE;
}

BOOLEAN MApp_Logo_Load(void)
{
    BOOLEAN bRet = FALSE;

    CAL_TIME_FUNC_START();

    if(!_MApp_Logo_LoadJpeg(BIN_ID_JPEG_BOOT_LOGO))
    {
        LOGO_DBG(printf(" msAPI_Logo_LoadJpeg failed\n"));
        return FALSE;
    }

    CAL_TIME_FUNC_("LogoLoad");
    {
        LOGO_DBG(printf("load co-processor code\n"));

#if defined(MIPS_CHAKRA) || defined(MSOS_TYPE_LINUX) || defined(__AEONR2__)
        msAPI_COPRO_Init(BIN_ID_CODE_VDPLAYER,((AEON_MEM_MEMORY_TYPE & MIU1) ? (AEON_MM_MEM_ADR | MIU_INTERVAL) : (AEON_MM_MEM_ADR)),AEON_MM_MEM_LEN);
#else
        msAPI_COPRO_Init(BIN_ID_CODE_VDPLAYER,((BEON_MEM_MEMORY_TYPE & MIU1) ? (BEON_MEM_ADR | MIU_INTERVAL) : ( BEON_MEM_ADR)),BEON_MEM_LEN);
#endif

        msAPI_Timer_Delayms(70);
    }

    CAL_TIME_FUNC_("LogoLoad");

    MApp_Photo_MemCfg(
            ((MAD_JPEG_DISPLAY_MEMORY_TYPE & MIU1) ? (MAD_JPEG_DISPLAY_ADR | MIU_INTERVAL) : (MAD_JPEG_DISPLAY_ADR)), MAD_JPEG_DISPLAY_LEN,
            ((MAD_JPEG_OUT_MEMORY_TYPE & MIU1) ? (MAD_JPEG_OUT_ADR | MIU_INTERVAL) : (MAD_JPEG_OUT_ADR)), MAD_JPEG_OUT_LEN,
            ((MAD_JPEG_INTERBUFF_MEMORY_TYPE & MIU1) ? (MAD_JPEG_INTERBUFF_ADR | MIU_INTERVAL) : (MAD_JPEG_INTERBUFF_ADR)), MAD_JPEG_INTERBUFF_LEN);

    CAL_TIME_FUNC_("LogoLoad");

    if (MApp_Photo_DecodeMemory_Init(FALSE, NULL))
    {
        EN_RET enPhotoRet;

        while ((enPhotoRet = MApp_Photo_Main()) == EXIT_PHOTO_DECODING)
            ;

        if ((enPhotoRet == EXIT_PHOTO_DECODE_DONE) && (MApp_Photo_GetErrCode() == E_PHOTO_ERR_NONE))
        {
            bRet = TRUE;
        }
    }
    CAL_TIME_FUNC_("LogoLoad");

    MApp_Photo_Stop();

    if (bRet == FALSE)
    {
        LOGO_DBG(printf("logo decode failed\n"));
    }

    CAL_TIME_FUNC_END();

    return bRet;
}

void MApp_Logo_Display(BOOLEAN bDisplayLogo)
{
    CAL_TIME_FUNC_START();

    if (bDisplayLogo)
    {
        MApp_InputSource_SwitchSource(UI_INPUT_SOURCE_DMP, MAIN_WINDOW);

        MApp_Photo_InitFullScreenDisplay();
        MApp_Photo_SlideShow(FALSE);
        MApp_Photo_DisplayLogo();
        g_u32LogoShowDuration_MS = MsOS_GetSystemTime();
        printf("MApp_PowerOnLogo_WaitStop(0) %lu\n", g_u32LogoShowDuration_MS);
    }
    else
    {
        g_u32LogoShowDuration_MS = 0;
        MApp_Photo_Display_Stop();

        //restore original input source setting
        //MApp_InputSource_SwitchSource(UI_INPUT_SOURCE_TYPE, MAIN_WINDOW);

        MApp_Photo_SlideShow(TRUE);
    }

    CAL_TIME_FUNC_END();
}

void MApp_PowerOnLogo_WaitStop(U32 u32RequestTime)
{
    //U32 u32CurTime = MsOS_GetSystemTime();

    //printf("MApp_PowerOnLogo_WaitStop(1) u32RequestTime %lu\n", u32RequestTime);
    //printf("MApp_PowerOnLogo_WaitStop(2) at %lu\n", u32CurTime);
    CAL_TIME_FUNC_START();

    if( g_u32LogoShowDuration_MS == 0 )
        return;

    while(1)
    {
        msAPI_Timer_ResetWDT();

        if( (MsOS_GetSystemTime() - g_u32LogoShowDuration_MS) >= u32RequestTime ) // Already play XXX ms
        {
            //printf("MApp_PowerOnLogo_WaitStop(3) at %lu\n", MsOS_GetSystemTime());
            g_u32LogoShowDuration_MS = 0;
            break;
        }
    }
    CAL_TIME_FUNC_END();
}

#if ENABLE_DMP
BOOLEAN MApp_SaveLogo_EraseFlash(U32 u32FlashStartAddr, U32 u32DataSize)
{
    U32     u32StartSector, u32EndSector, u32CurSector, u32FlashEndAddr;

    if (u32DataSize == 0)
    {
        return FALSE;
    }

/*    [TODO] Need to disable write protect when use code area flash to save Logo
    if (!msAPI_Flash_WriteProtect(DISABLE))
    {
        printf("Failed to disable flash write protection\n");
        return FALSE;
    }
*/

    u32FlashEndAddr = u32FlashStartAddr + u32DataSize - 1;

    if (!msAPI_Flash_AddressToBlock(u32FlashStartAddr, &u32StartSector))
    {
        return FALSE;
    }

    if (!msAPI_Flash_AddressToBlock(u32FlashEndAddr, &u32EndSector))
    {
        return FALSE;
    }

    LOGO_DBG(printf("u32FlashStartAddr=0x%lx, u32FlashEndAddr=0x%lx\n", u32FlashStartAddr, u32FlashEndAddr));
    LOGO_DBG(printf("u16StartSector=%d, u32EndSector=%d\n", u32StartSector, u32EndSector));

    for (u32CurSector = u32StartSector; u32CurSector <= u32EndSector; u32CurSector++)
    {
        if (!msAPI_Flash_BlockErase(u32CurSector, u32CurSector, TRUE))
        {
            return FALSE;
        }
    }

    LOGO_DBG(printf("MApp_SaveLogo_EraseFlash OK\n");)

    return TRUE;
}

 BOOLEAN MApp_SaveLogo_WriteFlash(U32 u32SrcAddr, U32 u32FlashAddr, U32 u32DataSize)
{
    U32     u32LeftSize;
    U16     u32CopySize;

    u32LeftSize = u32DataSize;
    u32CopySize = XDATA_WIN1_SIZE;

    while (u32LeftSize > 0)
    {
        if (u32LeftSize < XDATA_WIN1_SIZE)
        {
            u32CopySize = u32LeftSize;
        }

        if (!msAPI_Flash_Write(u32FlashAddr, u32CopySize, (U8 *)_PA2VA(u32SrcAddr)))
        {
            LOGO_DBG(printf("MApp_SaveLogo_WriteFlash: Writing error\n"));
            return FALSE;
        }

        u32SrcAddr += u32CopySize;
        u32FlashAddr += u32CopySize;
        u32LeftSize -= u32CopySize;

    }

    LOGO_DBG(printf("MApp_SaveLogo_WriteFlash OK\n");)

    return TRUE;
}
#endif  // EANBLE_DMP
#ifdef ENABLE_SANYO_WB_JPG

BOOLEAN MApp_Jpg_Load(U32 u32BinID)
{
    BOOLEAN bRet = FALSE;

    if(!_MApp_Logo_LoadJpeg(u32BinID))
    {
        LOGO_DBG(printf(" msAPI_Logo_LoadJpeg failed\n"));
        return FALSE;
    }

    {
        LOGO_DBG(printf("load co-processor code\n"));
    //#if( VD_PLAYER_IS_IN_CROP_CPU )
    //    MApp_VDPlayer_LoadBinToCrop();
   // #endif
        msAPI_Timer_Delayms(70);
    }

    MApp_Photo_MemCfg(
            ((MAD_JPEG_DISPLAY_MEMORY_TYPE & MIU1) ? (MAD_JPEG_DISPLAY_ADR | MIU_INTERVAL) : (MAD_JPEG_DISPLAY_ADR)), MAD_JPEG_DISPLAY_LEN,
            ((MAD_JPEG_OUT_MEMORY_TYPE & MIU1) ? (MAD_JPEG_OUT_ADR | MIU_INTERVAL) : (MAD_JPEG_OUT_ADR)), MAD_JPEG_OUT_LEN,
            ((MAD_JPEG_INTERBUFF_MEMORY_TYPE & MIU1) ? (MAD_JPEG_INTERBUFF_ADR | MIU_INTERVAL) : (MAD_JPEG_INTERBUFF_ADR)), MAD_JPEG_INTERBUFF_LEN);

    if (MApp_Photo_DecodeMemory_Init(FALSE, NULL))
    {
        EN_RET enPhotoRet;

        while ((enPhotoRet = MApp_Photo_Main()) == EXIT_PHOTO_DECODING)
            ;

        if ((enPhotoRet == EXIT_PHOTO_DECODE_DONE) && (MApp_Photo_GetErrCode() == E_PHOTO_ERR_NONE))
        {
            bRet = TRUE;
        }
    }

    MApp_Photo_Stop();

    if (bRet == FALSE)
    {
        LOGO_DBG(printf("logo decode failed\n"));
    }

    return bRet;
}
#endif

//----------------------------------------------------
#endif  //#if (DISPLAY_LOGO)

#undef MAPP_LOGO_C
