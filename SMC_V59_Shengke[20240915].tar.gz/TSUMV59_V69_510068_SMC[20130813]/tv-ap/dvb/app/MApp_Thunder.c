////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
/// @file MApp_Thunder.c
/// @brief Thunder download kernel
/// @author MStar Semiconductor Inc.
///
/// Thunder download kernel provide a simple interface to let users implement
/// Thunder download on MStar chip.
///
///////////////////////////////////////////////////////////////////////////////
#include "Board.h"

#ifdef ENABLE_BT
#if (ENABLE_THUNDER_DOWNLOAD)

#define MAPP_THUNDER_C
#include <stdio.h>
#include <string.h>
#include "ctype.h"
#include "datatype.h"

#include "msAPI_MailBox.h"
#include "drvCPU.h"
#include "MsTypes.h"
#include "drvBDMA.h"
#include "sysinfo.h"
#include "BinInfo.h"
//#include "IOUtil.h"
#include "FSUtil.h"

#include "msAPI_Timer.h"
#include "msAPI_APEngine.h"
#include "MApp_APEngine.h"
#include "msAPI_JPEG_MM.h"
#include "apiGOP.h"

#include "MApp_Thunder.h"
#include "MApp_GlobalVar.h"
#include "mapp_jpeg_mm.h"
#include "MApp_Thunder_Main.h"

#if NEW_PHOTO
#include "mapp_photo.h"
#endif // #if NEW_PHOTO

#define THUNDER_DBG(x)                  x

U8 *u8UTF8Sting;
BOOLEAN bThunderBuffLock = FALSE;
MB_BTC_ERROR uThunderErrorState[NUM_OF_ERROR];
static U32 u32MailBoxTimeID = 0;
U8 u8Thunder_MainBox[14];
U8 u8ThunderMailBoxOKState = 0;
U8 u8ThunderSearchTimeCounter = 0;
Thunder_Init_State uThunderInitState = STATE_SYSTEM_INIT_NONE;
THUNDER_JPEG_State u8Thunder_JPEG_State = STATE_THUNDER_JPEG_NONE;
THUNDER_MAINLINK_State uThunder_MainLink_State = STATE_THUNDER_MAINLINK_NONE;
static ThunderMainLink0Status m_Thunder_MainLink0Status[NUM_OF_MAINLINK0_ITEM_PER_PAGE];
static ThunderMainLink1Status m_Thunder_MainLink1Status[NUM_OF_MAINLINK1_ITEM_PER_PAGE];


#define CHAR_CONVER_BUFFER ((LPTSTR)CHAR_BUFFER)


/******************************************************************************/
///-Convert  UCS2 to UTF8
///@param pu16srcStr \b IN
///@param pu8dstStr \b IN
///@param srcWideCharLen \b IN
///@param dstByteLen \b IN
///- pu16srcStr ...
///- pu8dstStr ...
///- srcWideCharLen ...
///- dstByteLen ...
/******************************************************************************/
void msAPI_MappinUCS2ToUTF8(U16 *pu16srcStr, U8 *pu8dstStr, U16 srcWideCharLen, U16 dstByteLen)
{
    U16 u16Value, i, j;

    if ((pu16srcStr == 0) || (srcWideCharLen == 0) || (pu8dstStr == 0) || (dstByteLen <= 1)) return;

    for (i=0, j=0; i<srcWideCharLen && j<dstByteLen-1; i++, j++)
    {
        u16Value = pu16srcStr[i];
        if (u16Value == 0)
        {
            break;
        }

        if(u16Value < 0x80)
        {
            // 0000 - 007F -> 0xxxxxxx
            pu8dstStr[j] = (U8)u16Value;
        }
        else if( u16Value < 0x800)
        {
            //0080 - 07FF -> 110xxxxx 10xxxxxx
            pu8dstStr[j] = (U8)( (0x80) | (u16Value & 0x3F) );
            pu8dstStr[j+1] = (U8)( (0xC0) | ((u16Value>>6) & 0x1F) );
            j +=1;
        }
        else if(u16Value> 0x7FF)
        {
            //0800 - FFFF - > 1110xxxx 10xxxxxx 10xxxxxx
            pu8dstStr[j+2] = (U8)( (0x80) | (u16Value & 0x3F) );
            pu8dstStr[j+1] = (U8)( (0x80) | ((u16Value>>6) & 0x3F) );
            pu8dstStr[j] = (U8)( (0xE0) | ((u16Value>>12) & 0x0F) );
            j +=2;
        }
        else
        {
            // Unknown, skip
            if( j>0 )
                j--;
        }
    }

    // NULL termination character
    pu8dstStr[j] = 0;
}

/******************************************************************************/
// Function:        msAPI_Mappin_UCS2ToHEX
// Description:     This function will convert UCS2 encoded string to Hex encoded string.
//                        If the UCS2 character is the readable one, convert to one-byte ASCII. If not,
//                        convert to 2 Hex string, such as %4E00.
///@param pu16srcStrUCS2 \b IN          //UCS2 encoded string
///@param pu8dstStrHex \b OUT           // Hex encoded string
/******************************************************************************/
void msAPI_Mappin_UCS2ToHEX(U16 *pu16srcStrUCS2, U8 *pu8dstStrHex)
{
    if(pu16srcStrUCS2)
    {
        int i,j;

        for(i=0,j=0;pu16srcStrUCS2[i]!=0x0000;i++)
        {
            if(((pu16srcStrUCS2[i]>=0x0061)&&(pu16srcStrUCS2[i]<=0x007A))||    /* a~z */
               ((pu16srcStrUCS2[i]>=0x0041)&&(pu16srcStrUCS2[i]<=0x005A))||    /* A~Z */
               ((pu16srcStrUCS2[i]>=0x0030)&&(pu16srcStrUCS2[i]<=0x0039))||    /* 0~9 */
               (pu16srcStrUCS2[i]==0x005F)||(pu16srcStrUCS2[i]==0x002E))       /* _ . */
            {
                pu8dstStrHex[j++]=(char)pu16srcStrUCS2[i];
            }
            else
            {
                snprintf((char *)(pu8dstStrHex+j),  5, "%%%04X", pu16srcStrUCS2[i]);
                j+=5;
            }
        }
        pu8dstStrHex[j]=0x00;
    }
}


//*****************************************************************************
//Sender: AEON
//Receiver: BEON
//@param uBtMailBoxPara \b IN
//*****************************************************************************
BOOLEAN MApp_Thunder_SendMailBox(MBX_Msg uThunderMailBoxPara)
{
    U8 u8Cont, u8Max;
    U32 u32Timer;
    MBX_Msg mbxMsg;

    //printf("MApp_BT_SetDamonParam!\n");
    mbxMsg.eMsgType = E_MBX_MSG_TYPE_NORMAL;
    mbxMsg.u8MsgClass = MB_CLASS_BTPD;
    mbxMsg.u8Index = uThunderMailBoxPara.u8Index;
    mbxMsg.u8ParameterCount = uThunderMailBoxPara.u8ParameterCount;

    u8Max = uThunderMailBoxPara.u8ParameterCount;
    if(u8Max> 10)
        u8Max = 10;
    for(u8Cont = 0; u8Cont<u8Max; u8Cont++)
        mbxMsg.u8Parameters[u8Cont] = uThunderMailBoxPara.u8Parameters[u8Cont];

    u32Timer  = msAPI_Timer_GetTime0();
    while(msAPI_Timer_DiffTimeFromNow(u32Timer) < 500)
    {
        #if( WATCH_DOG == ENABLE )
        msAPI_Timer_ResetWDT();
        #endif

        if(E_MBX_SUCCESS == MApi_MBX_SendMsg(&mbxMsg))
        {
            break;
        }
    }
    return FALSE;
}

//*****************************************************************************
//Sender: AEON
//Receiver: BEON
//Receiver requests Sender to unlock memory.
//*****************************************************************************
BOOLEAN MApp_Thunder_SendUnLockMemory(void)
{
    BOOLEAN bRet;
    MBX_Msg uMailBoxPara;

    uMailBoxPara.u8Index        = MB_BTC_UNLOCKMEM_A;
    uMailBoxPara.u8ParameterCount        = 0;
    bRet = MApp_Thunder_SendMailBox(uMailBoxPara);

    if(!bRet)
        printf("MApp_Thunder_SendUnLockMemory Failed\n");

    return bRet;
}

//*****************************************************************************
//Sender: AEON
//Receiver: BEON
//ParamCount = 8
//Params[0]~[3] = Memory Size (big-endian)
//Params[4]~[7] = Memory Address (big-endian)
//*****************************************************************************
BOOLEAN MApp_Thunder_Set_HK_To_Beon_Memory_Addr(void)
{
    BOOLEAN bRet;
    U32 u32addr;
    MBX_Msg uMailBoxPara;

    //printf("MApp_BT_Set_HK_To_Beon_Memory_Addr!\n");
    printf("Addr1[%lx]!\n", BT_HK_TO_BEON_SHAER_BUFFER_ADR);
    printf("Addr1Size[%lx]!\n", BT_HK_TO_BEON_SHAER_BUFFER_LEN);

    u8UTF8Sting = (U8 *)((BT_HK_TO_BEON_SHAER_BUFFER_MEMORY_TYPE & MIU1) ? (BT_HK_TO_BEON_SHAER_BUFFER_ADR | MIU_INTERVAL) : (BT_HK_TO_BEON_SHAER_BUFFER_ADR));

    // set Parameter
    uMailBoxPara.u8Index        = MB_BTC_SETMEMADDR1;
    uMailBoxPara.u8ParameterCount        = 8;

    // set size
    uMailBoxPara.u8Parameters[0] = (U8)(BT_HK_TO_BEON_SHAER_BUFFER_LEN>>24);
    uMailBoxPara.u8Parameters[1] = (U8)(BT_HK_TO_BEON_SHAER_BUFFER_LEN>>16);
    uMailBoxPara.u8Parameters[2] = (U8)(BT_HK_TO_BEON_SHAER_BUFFER_LEN>>8);
    uMailBoxPara.u8Parameters[3] = (U8)(BT_HK_TO_BEON_SHAER_BUFFER_LEN);

    // set address
    u32addr = (((BT_HK_TO_BEON_SHAER_BUFFER_MEMORY_TYPE & MIU1) ? (BT_HK_TO_BEON_SHAER_BUFFER_ADR | MIU_INTERVAL) : (BT_HK_TO_BEON_SHAER_BUFFER_ADR))|0x80000000UL);
    uMailBoxPara.u8Parameters[4] = (U8)(u32addr>>24);
    uMailBoxPara.u8Parameters[5] = (U8)(u32addr>>16);
    uMailBoxPara.u8Parameters[6] = (U8)(u32addr>>8);
    uMailBoxPara.u8Parameters[7] = (U8)(u32addr) ;

    bRet = MApp_Thunder_SendMailBox(uMailBoxPara);


    if(!bRet)
        printf("MApp_Thunder_Set_HK_To_Beon_Memory_Addr Failed\n");

    return bRet;
}

//*****************************************************************************
//Sender: AEON
//Receiver: BEON
//ParamCount = 8
//Params[0]~[3] = Memory Size (big-endian)
//Params[4]~[7] = Memory Address (big-endian)
//*****************************************************************************
BOOLEAN  MApp_Thunder_Set_Beon_To_HK_Memory_Addr(void)
{
    BOOLEAN bRet;
    U32 u32addr;
    MBX_Msg uMailBoxPara;

    //printf("MApp_BT_Set_Beon_To_HK_Memory_Addr!\n");
    printf("Addr2[%lx]!\n", ((BT_BEON_TO_HK_SHAER_BUFFER_MEMORY_TYPE & MIU1) ? (BT_BEON_TO_HK_SHAER_BUFFER_ADR | MIU_INTERVAL) : (BT_BEON_TO_HK_SHAER_BUFFER_ADR)));
    printf("Addr2Size[%lx]!\n", BT_BEON_TO_HK_SHAER_BUFFER_LEN);

    // set Parameter
    uMailBoxPara.u8Index        = MB_BTC_SETMEMADDR2;
    uMailBoxPara.u8ParameterCount        = 8;

    // set size
    uMailBoxPara.u8Parameters[0] = (U8)(BT_BEON_TO_HK_SHAER_BUFFER_LEN>>24);
    uMailBoxPara.u8Parameters[1] = (U8)(BT_BEON_TO_HK_SHAER_BUFFER_LEN>>16);
    uMailBoxPara.u8Parameters[2] = (U8)(BT_BEON_TO_HK_SHAER_BUFFER_LEN>>8);
    uMailBoxPara.u8Parameters[3] = (U8)BT_BEON_TO_HK_SHAER_BUFFER_LEN;

    // set address
    u32addr = (((BT_BEON_TO_HK_SHAER_BUFFER_MEMORY_TYPE & MIU1) ? (BT_BEON_TO_HK_SHAER_BUFFER_ADR | MIU_INTERVAL) : (BT_BEON_TO_HK_SHAER_BUFFER_ADR)) |0x80000000UL);
    uMailBoxPara.u8Parameters[4] = (U8)(u32addr>>24);
    uMailBoxPara.u8Parameters[5] = (U8)(u32addr>>16);
    uMailBoxPara.u8Parameters[6] = (U8)(u32addr>>8);
    uMailBoxPara.u8Parameters[7] = (U8)(u32addr);

    bRet = MApp_Thunder_SendMailBox(uMailBoxPara);

    if(!bRet)
        printf("MApp_Thunder_Set_Beon_To_HK_Memory_Addr Failed\n");

    return bRet;
}

//*****************************************************************************
//Sender: AEON
//Receiver: BEON
//ParamCount = 7
//Params[0]~[1] = Port Number (big-endian)
//Params[2]~[3] = Net In BandWidth (big-endian)
//Params[4]~[5] = Net Out BandWidth (big-endian)
//Params[6] = Max tasks
//*****************************************************************************
BOOLEAN MApp_Thunder_SetDamonParam(MS_TorrentSetupInfo *pTorrentSetup)
{
    BOOLEAN bRet;
    MBX_Msg uMailBoxPara;

    // set Parameter
    uMailBoxPara.u8Index        = MB_BTC_SETDAEMONPARAM;
    uMailBoxPara.u8ParameterCount        = 7;

    // Port Number (big-endian)
    uMailBoxPara.u8Parameters[0] = (U8)((pTorrentSetup->u16port)>>8) ;
    uMailBoxPara.u8Parameters[1] = (U8)(pTorrentSetup->u16port);
    //Net In BandWidth (big-endian)
    uMailBoxPara.u8Parameters[2] = (U8)((pTorrentSetup->u16DownloadLimit)>>8);
    uMailBoxPara.u8Parameters[3] = (U8)(pTorrentSetup->u16DownloadLimit);
    //Net Out BandWidth (big-endian)
    uMailBoxPara.u8Parameters[4] = (U8)((pTorrentSetup->u16UploadLimit)>>8);
    uMailBoxPara.u8Parameters[5] = (U8)(pTorrentSetup->u16UploadLimit);
    //Max tasks
    uMailBoxPara.u8Parameters[6] = (U8)(pTorrentSetup->u8MaxSession);

    bRet = MApp_Thunder_SendMailBox(uMailBoxPara);

    if(!bRet)
        printf("MApp_BT_SetDamonParam Failed\n");

    return bRet;
}


//*****************************************************************************
//Sender: AEON
//Receiver: BEON
//ParamCount = 0
//*****************************************************************************
BOOLEAN MApp_Thunder_StarDamon(void)
{
    BOOLEAN bRet;
    MBX_Msg uMailBoxPara;

    // set Parameter
    uMailBoxPara.u8Index        = MB_BTC_STARTDAEMON;
    uMailBoxPara.u8ParameterCount        = 0;
    bRet = MApp_Thunder_SendMailBox(uMailBoxPara);

    if(!bRet)
        printf("MApp_BT_StarDamon Failed\n");

    return bRet;
}

//*****************************************************************************
//Sender: AEON
//Receiver: BEON
//ParamCount = 0
//*****************************************************************************
BOOLEAN MApp_Thunder_StopDamon(void)
{
    BOOLEAN bRet;
    MBX_Msg uMailBoxPara;

    // set Parameter
    uMailBoxPara.u8Index        = MB_BTC_STOPDAEMON;
    uMailBoxPara.u8ParameterCount        = 0;
    bRet = MApp_Thunder_SendMailBox(uMailBoxPara);

    if(!bRet)
        printf("MApp_BT_StopDamon Failed\n");

    return bRet;
}

//*****************************************************************************
//Sender: AEON
//Receiver: BEON
//ParamCount = 0
//*****************************************************************************
BOOLEAN MApp_Thunder_CheckNetWork(void)
{
    BOOLEAN bRet;
    MBX_Msg uMailBoxPara;

    // set Parameter
    uMailBoxPara.u8Index        = MB_BTC_CHECK_NETWORK;
    uMailBoxPara.u8ParameterCount        = 0;
    bRet = MApp_Thunder_SendMailBox(uMailBoxPara);

    if(!bRet)
        printf("MApp_BT_CheckNetWork Failed\n");

    return bRet;
}

//*****************************************************************************
//Sender: AEON
//Receiver: BEON
//ParamCount = 0
//*****************************************************************************
BOOLEAN MApp_Thunder_CheckStorage(void)
{
    BOOLEAN bRet;
    MBX_Msg uMailBoxPara;

    // set Parameter
    uMailBoxPara.u8Index        = MB_BTC_CHECK_STORAGE;
    uMailBoxPara.u8ParameterCount        = 0;
    bRet = MApp_Thunder_SendMailBox(uMailBoxPara);

    if(!bRet)
        printf("MApp_BT_CheckStorage Failed\n");

    return bRet;
}

//*****************************************************************************
//Sender: AEON
//Receiver: MIPS
//ParamCount @ Memory buffer.
//Refer to Torrent Client HTTP Commands
//*****************************************************************************
BOOLEAN MApp_Thunder_SetTorrentServerAddr(U16 *pu16UnicodeString)
{
    BOOLEAN bRet;
    U16 u16Cont, u16Len;
    MBX_Msg uMailBoxPara;

    if(bThunderBuffLock)
    {
        if(MApp_Thunder_MailBoxHandle(500, MB_BTC_UNLOCKMEM_M, &uMailBoxPara))
            bThunderBuffLock = FALSE;
        else
            return FALSE;
    }

    for( u16Cont = 0, u16Len = 0; u16Cont<256; u16Cont++)
    {
        if(pu16UnicodeString[u16Cont]==0)
        {
            u16Len = u16Cont;
            break;
        }
    }

    bThunderBuffLock = TRUE;

    msAPI_MappinUCS2ToUTF8(pu16UnicodeString, (U8 *)u8UTF8Sting, u16Len, 255);

    // set Parameter
    uMailBoxPara.u8Index        = MB_BTC_SETTORRENTSVR;
    uMailBoxPara.u8ParameterCount        = 0;
    bRet = MApp_Thunder_SendMailBox(uMailBoxPara);

    if(!bRet)
        printf("MApp_Thunder_SetTorrentServerAddr Failed\n");

    return bRet;
}


void MApp_Thunder_MailBoxErrorStateInit(void)
{
    U8 i;
    for(i = 0; i< NUM_OF_ERROR; i++)
        uThunderErrorState[i] = MB_BTC_ERR_NONE;
}


/******************************************************************************/
/// Handle System Error
/******************************************************************************/
MB_BTC_ERROR MApp_ThunderSystemErrorHandle(void)
{
    MB_BTC_ERROR uErrorState;
    U8 u8Count;
    MBX_Msg mbxMsg;

    for(u8Count = 0; u8Count< NUM_OF_ERROR; u8Count++)
    {
        if(uThunderErrorState[u8Count] == MB_BTC_ERR_NONE )
        {
            break;
        }
    }

    if(u8Count >= NUM_OF_ERROR )
        return MB_BTC_ERR_NONE;

    MApp_Thunder_MailBoxHandle(10, 0, &mbxMsg);

    uErrorState = uThunderErrorState[u8Count];
     switch( uThunderErrorState[u8Count] )
     {
        case MB_BTC_ERR_DN_TOR: //Error while downloading the torrent file
        case MB_BTC_ERR_DN_IMG: //Error while downloading the image file
        case MB_BTC_ERR_DN_DES: //Error while downloading the description file
        case MB_BTC_ERR_START_TOR: //Error while starting the torrent
        case MB_BTC_ERR_STOP_TOR: //Error while stopping the torrent
        case MB_BTC_ERR_ADD_TOR: //Error while adding the torrent
        case MB_BTC_ERR_DEL_TOR: //Error while deleting the torrent
        case MB_BTC_ERR_DEL_TORDATA: //Error while deleting the torrent and downloaded data
        case MB_BTC_ERR_START_DAEM: //Error while starting the daemon
        case MB_BTC_ERR_STOP_DAEM: //Error while stopping the daemon
        case MB_BTC_ERR_SET_PARAM: //Error while setting the daemon parameters
        case MB_BTC_ERR_NETWORK: //Error for network
        case MB_BTC_ERR_STORAGE: //Error for storage
        case MB_BTC_ERR_UNRESOLVED_HOST:  //Error while resolving the host name of the torrent server
        case MB_BTC_ERR_DECODE_IMG: //Error while decoding the image
        case MB_BTC_ERR_UNKNOWN: //Unknown error
            uThunderErrorState[u8Count] = MB_BTC_ERR_NONE;
            break;
        default :
            break;

     }

    return uErrorState;
}

//*****************************************************************************
//Sender: BEON
//Receiver: AEON
//Get Mail Box Message
//*****************************************************************************
BOOLEAN MApp_Thunder_MailBoxHandle(U32 u32WaitMs, U8 u8CommandIndex, MBX_Msg *pMsg)
{
    U32 u32Timer  = msAPI_Timer_GetTime0();
    U8 i = 0, j = 0;
    BOOLEAN bRet = FALSE;
    MBX_MSGQ_Status mbxMsgQStatus;

    if(NULL == pMsg)
        return FALSE;

    while(msAPI_Timer_DiffTimeFromNow(u32Timer) < u32WaitMs)
    {
        MApi_MBX_GetMsgQueueStatus(E_MBX_CLASS_BTPD, &mbxMsgQStatus);
        for (i=0; i<mbxMsgQStatus.u32NormalMsgCount; i++)
        {
            #if( WATCH_DOG == ENABLE )
            msAPI_Timer_ResetWDT();
            #endif

            if(MApi_MBX_RecvMsg(E_MBX_CLASS_BTPD, pMsg, 0, MBX_CHECK_NORMAL_MSG) == E_MBX_SUCCESS)
            {
                // for Usre requst
                if(pMsg->u8Index == u8CommandIndex)
                {
                    bRet = TRUE;
                    break;
                }

                switch(pMsg->u8Index)
                {
                    case MB_BTC_UNLOCKMEM_M:
                        bThunderBuffLock = FALSE;
                        break;

                    case MB_BTC_OK:
                        printf("MB: [%02x][%02x][%02x][%02x][%02x]\n", pMsg->u8Parameters[0], pMsg->u8Parameters[1], pMsg->u8Parameters[2], pMsg->u8Parameters[3], pMsg->u8Parameters[4]);
                        u8ThunderMailBoxOKState = pMsg->u8Parameters[0];
                        break;

                    case MB_BTC_FAIL:
                        {
                            for(j = 0; j< NUM_OF_ERROR; j++)
                            {
                                if( uThunderErrorState[j] == MB_BTC_ERR_NONE )
                                    break;
                            }
                            if(j >= NUM_OF_ERROR)
                                printf("uThunderErrorState Over Flow", j, uThunderErrorState[j]);

                            uThunderErrorState[j] = (MB_BTC_ERROR)pMsg->u8Parameters[0];
                            printf("u8BTErrortState[%d]: [%d]\n", j, uThunderErrorState[j]);
                            printf("MB: [%02x][%02x][%02x][%02x]\n", pMsg->u8Parameters[1], pMsg->u8Parameters[2], pMsg->u8Parameters[3], pMsg->u8Parameters[4]);
                        }
                        break;
                    case MB_BTC_RESPONSE_NUM:
                        break;
                    case MB_BTC_RESPONSE_LIST:
                        break;
                    case MB_BTC_LISTTORRENT_RESPONSE:
                        break;
                    case MB_BTC_SENDIMGRAWDATA:
                        break;
                    case MB_BTC_SENDDESTXT:
                        break;

                    default :
                        break;

                }
            }
        }
    }

#if 0
    if(msAPI_Timer_DiffTimeFromNow(u32Timer)  >= u32WaitMs)
    {
        printf("Wait MBX_Msg TimeOut!\n");
        if(i<u8Count)
            printf("MainlBox Item to Large[%d] <-[%d]!\n", u8Count, i);
    }
#endif
    return bRet;

}

/******************************************************************************/
/// Set  System Init  State.
/// @return None
/******************************************************************************/
void MApp_Thunder_SetSystemInitState(Thunder_Init_State uState)
{
    uThunderInitState = uState;
}

/******************************************************************************/
/// Read back System Init State.
/// @return System Init State
/******************************************************************************/
Thunder_Init_State MApp_Thunder_GetSystemInitState(void)
{
    return uThunderInitState;
}


/******************************************************************************/
/// Init BT
/******************************************************************************/
void MApp_Thunder_CoProcesser_Init(void)//Co-processer
{
    MBX_Msg mbxMsg;
    switch(MApp_Thunder_GetSystemInitState())
    {
        case STATE_SYSTEM_INIT_LOAD_BIN:
            printf("MApp_Thunder_CoProcesser_Init!\n");
            MApp_Thunder_MailBoxErrorStateInit();
            #ifdef ENABLE_LOAD_APP_FROM_USB
            U8 name[]="btpd.bin";
            LoadAppbyFileNameFromUSB(name);
            #else
            MApp_APEngine_RegisterByID(BIN_ID_CODE_AEON_BT_CAPE, NONE_HANDLE, ((BEON_MEM_MEMORY_TYPE & MIU1) ? (BEON_MEM_ADR | MIU_INTERVAL) : ( BEON_MEM_ADR)), BEON_MEM_LEN);
            #endif
            MApp_Thunder_SetSystemInitState(STATE_SYSTEM_INIT_WAIT_LOAD_OK);

            //MsOS_DelayTask(100);
            //MDrv_WriteByte(0x1EAA, 0x0C);
            //MsOS_DelayTask(100);

            break;
        case STATE_SYSTEM_INIT_WAIT_LOAD_OK:
            if(MApp_Thunder_MailBoxHandle(10, MB_BTC_OK, &mbxMsg))
            {
                printf("Load Bin OK!\n");
                MApp_Thunder_SetSystemInitState(STATE_SYSTEM_INIT_SET_PARAMETER);
            }
            break;
        case STATE_SYSTEM_INIT_SET_PARAMETER:
            printf("SET PARAMETER!\n");

            // set Memory addr and size
            MApp_Thunder_Set_HK_To_Beon_Memory_Addr();
            MApp_Thunder_Set_Beon_To_HK_Memory_Addr();

            // set Daemon parameter
            MApp_Thunder_SetDamonParam((MS_TorrentSetupInfo *) &stGenSetting.TorrentSetupInfo);
            MApp_Thunder_StarDamon();

            // set Torrent Server address
            memcpy(CHAR_CONVER_BUFFER, stGenSetting.TorrentSetupInfo.u8ServerName, sizeof(stGenSetting.TorrentSetupInfo.u8ServerName));
            FS_ASCII2Unicode((U8*)CHAR_CONVER_BUFFER);
            MApp_Thunder_SetTorrentServerAddr((U16 *)CHAR_CONVER_BUFFER);

            MApp_Thunder_CheckNetWork();
            MApp_Thunder_SetSystemInitState(STATE_SYSTEM_INIT_CHECK_NETWORK);

            break;
        case STATE_SYSTEM_INIT_CHECK_NETWORK:
            if(MApp_Thunder_MailBoxHandle(10, MB_BTC_OK, &mbxMsg))
            {

                printf("MB: [%02x][%02x][%02x][%02x][%02x]\n", mbxMsg.u8Parameters[0], mbxMsg.u8Parameters[1], mbxMsg.u8Parameters[2], mbxMsg.u8Parameters[3], mbxMsg.u8Parameters[4]);
                u8ThunderMailBoxOKState = mbxMsg.u8Parameters[0];

                if( u8ThunderMailBoxOKState == MB_BTC_CHECK_NETWORK )
                {
                    printf("Check Network OK!\n");
                    MApp_Thunder_SetSystemInitState(STATE_SYSTEM_INIT_OK);
                }
                else
                {
                    printf("Check Network temp!\n");
                }
            }
            break;
        case STATE_SYSTEM_INIT_OK:
            break;

        default :
            break;
    }
}



/******************************************************************************/
/// Thunder Search state
/******************************************************************************/
void MApp_SetThunderSearchSate(EN_THUNDER_SEARCH_STATE enState)
{
    enThunderSearchState = enState;
}

EN_THUNDER_SEARCH_STATE MApp_GetThunderSearchSate(void)
{
    return enThunderSearchState;
}


U32 MApp_GetThunderSearchResultCounter(void)
{
    return (U32)ResultCounter;
}

//*****************************************************************************
//Sender: AEON
//Receiver: MIPS
//ParamCount @ Memory buffer.
//Send http command to get the Image file
//Refer to Torrent Client HTTP Commands
//*****************************************************************************
#if 1
BOOLEAN MApp_Thunder_GetAnySearch(char *skey,int num,int page)
{
#if  1
    BOOLEAN bRet = FALSE;
    MBX_Msg uMailBoxPara;
    U32 u32TimeID;

    switch( MApp_GetThunderSearchSate() )
    {
        case THUNDER_SEARCH_STATE_INIT:
            {
                MApp_Thunder_SendUnLockMemory();

                u8UTF8Sting = (U8 *)(((BT_HK_TO_BEON_SHAER_BUFFER_MEMORY_TYPE & MIU1) ? (BT_HK_TO_BEON_SHAER_BUFFER_ADR | MIU_INTERVAL) : (BT_HK_TO_BEON_SHAER_BUFFER_ADR))|0x80000000UL);
                memset(u8UTF8Sting,0,128);

                 if((num==0)&&(page==0))
                    snprintf((char *)u8UTF8Sting,128,"http://ac.gougou.com/ac_box?ac=%s",skey);
                else
                    snprintf((char *)u8UTF8Sting,128,"http://dy.gougou.com/btinfo?keyword=%s&num=%d&page=%d",skey,num,page);

                printf("MApp_BT_GetAnySearch cmd=%s\n",(char *)u8UTF8Sting);

                bThunderBuffLock = TRUE;

                u32MailBoxTimeID = msAPI_Timer_GetTime0();

                // set Parameter
                uMailBoxPara.u8Index        = MB_BTC_HTTPCMD_ALL;
                //uMailBoxPara.u8ParameterCount        = 0;
                uMailBoxPara.u8ParameterCount        = 8;
                uMailBoxPara.u8Parameters[0] = 0;
                uMailBoxPara.u8Parameters[1] = 0;
                uMailBoxPara.u8Parameters[2] = 0;
                uMailBoxPara.u8Parameters[3] = 0 ;

                uMailBoxPara.u8Parameters[4] = (U8)(u32MailBoxTimeID>>24);
                uMailBoxPara.u8Parameters[5] = (U8)(u32MailBoxTimeID>>16);
                uMailBoxPara.u8Parameters[6] = (U8)(u32MailBoxTimeID>>8);
                uMailBoxPara.u8Parameters[7] = (U8)(u32MailBoxTimeID) ;

                bRet = MApp_Thunder_SendMailBox(uMailBoxPara);

                if(!bRet)
                {
                    printf("MApp_BT_GetAnySearch Failed\n");
                    return FALSE;
                }

                MApp_SetThunderSearchSate(THUNDER_SEARCH_STATE_WAIT);
                u8ThunderSearchTimeCounter = 0;
                return TRUE;
            }
            break;
        case THUNDER_SEARCH_STATE_WAIT:
            {
                char *p; U32 len;

                if( u8ThunderSearchTimeCounter < THUNDER_SEARCH_WAIT_TIME)
                    u8ThunderSearchTimeCounter++;
                else
                {
                    MApp_SetThunderSearchSate( THUNDER_SEARCH_STATE_TIME_OUT );
                }

                if( !MApp_Thunder_MailBoxHandle(10, MB_BTC_SENDALL, &uMailBoxPara))
                    return FALSE;

                len = ((((U32)uMailBoxPara.u8Parameters[0]) << 24)&0xFF000000)|
                        ((((U32)uMailBoxPara.u8Parameters[1]) << 16)&0x00FF0000)|
                        ((((U32)uMailBoxPara.u8Parameters[2]) << 8 )&0x0000FF00)|
                        ((((U32)uMailBoxPara.u8Parameters[3])      )&0x000000FF);

                printf("MApp_BT_GetAnyData Size [%lx]\n", len);

                u32TimeID = ((((U32)uMailBoxPara.u8Parameters[4]) << 24)&0xFF000000)|
                                ((((U32)uMailBoxPara.u8Parameters[5]) << 16)&0x00FF0000)|
                                ((((U32)uMailBoxPara.u8Parameters[6]) << 8 )&0x0000FF00)|
                                ((((U32)uMailBoxPara.u8Parameters[7])      )&0x000000FF);

                if( u32MailBoxTimeID != u32TimeID )
                {
                    printf("FAIL!!!  TimeID(org:[%lx])  [%lx]\n", u32MailBoxTimeID, u32TimeID);
                    return FALSE;
                }

                p=(char *)((BT_BEON_TO_HK_SHAER_BUFFER_MEMORY_TYPE & MIU1) ? (BT_BEON_TO_HK_SHAER_BUFFER_ADR | MIU_INTERVAL) : (BT_BEON_TO_HK_SHAER_BUFFER_ADR));
                //PrintfInfo(p,(char *)(p+len));
                DataParser(p,len);

                printf("DataParser finished!\n");

            #if 1
                {
                    int i,j;
                    for(i=0;i<NUM_OF_SEARCH_LIST_PER_PAGE;i++)
                    {
                        for(j=EN_CID;j<EN_MAX_FILEINFO;j++)
                        {
                            PrintfInfo(SearchResult[i][j][EN_START],SearchResult[i][j][EN_END]);
                        }
                    }
                }
            #endif

                if( MApp_GetThunderSearchResultCounter() == 0 )
                    MApp_SetThunderSearchSate(THUNDER_SEARCH_STATE_NOTHING);
                else
                    MApp_SetThunderSearchSate(THUNDER_SEARCH_STATE_SHOW);

                printf("MApp_BT_GetAnySearch ok\n");
                return TRUE;
            }
            break;
        case THUNDER_SEARCH_STATE_NOTHING:
            break;
        case THUNDER_SEARCH_STATE_SHOW:
            break;
        default:
            break;
    }
    return FALSE;


#else
    BOOLEAN bRet = FALSE;
    MBX_Msg uMailBoxPara;
    U16 u16Cont;
    U32 u32TimeID;
    U8 u8Cont;


    MApp_Thunder_SendUnLockMemory();

    u8UTF8Sting = (U8 *)(((BT_HK_TO_BEON_SHAER_BUFFER_MEMORY_TYPE & MIU1) ? (BT_HK_TO_BEON_SHAER_BUFFER_ADR | MIU_INTERVAL) : (BT_HK_TO_BEON_SHAER_BUFFER_ADR))|0x80000000UL);
    memset(u8UTF8Sting,0,128);
    snprintf((char *)u8UTF8Sting,128,"http://dy.gougou.com/btinfo?keyword=%s&num=%d&page=%d",skey,num,page);

    printf("MApp_BT_GetAnySearch cmd=%s\n",(char *)u8UTF8Sting);

    bThunderBuffLock = TRUE;

    u32MailBoxTimeID = msAPI_Timer_GetTime0();

    // set Parameter
    uMailBoxPara.u8Index        = MB_BTC_HTTPCMD_ALL;
    //uMailBoxPara.u8ParameterCount        = 0;
    uMailBoxPara.u8ParameterCount        = 8;
    uMailBoxPara.u8Parameters[0] = 0;
    uMailBoxPara.u8Parameters[1] = 0;
    uMailBoxPara.u8Parameters[2] = 0;
    uMailBoxPara.u8Parameters[3] = 0 ;

    uMailBoxPara.u8Parameters[4] = (U8)(u32MailBoxTimeID>>24);
    uMailBoxPara.u8Parameters[5] = (U8)(u32MailBoxTimeID>>16);
    uMailBoxPara.u8Parameters[6] = (U8)(u32MailBoxTimeID>>8);
    uMailBoxPara.u8Parameters[7] = (U8)(u32MailBoxTimeID) ;

    bRet = MApp_Thunder_SendMailBox(uMailBoxPara);

    if(!bRet)
    {
        printf("MApp_BT_GetAnySearch Failed\n");
        return FALSE;
    }

    for(u8Cont = 0; u8Cont<3; u8Cont++)
    {
        for(u16Cont = 0; u16Cont<300; u16Cont++)
        {
            if(MApp_Thunder_MailBoxHandle(10, MB_BTC_SENDALL))
                break;
        }

        if(u16Cont<1000)
        {
            char *p; U32 len;
            len = ((((U32)u8Thunder_MainBox[2]) << 24)&0xFF000000)|
                    ((((U32)u8Thunder_MainBox[3]) << 16)&0x00FF0000)|
                    ((((U32)u8Thunder_MainBox[4]) << 8 )&0x0000FF00)|
                    ((((U32)u8Thunder_MainBox[5])      )&0x000000FF);

            printf("MApp_BT_GetAnyData Size [%lx]\n", len);

            u32TimeID = ((((U32)u8Thunder_MainBox[6]) << 24)&0xFF000000)|
                    ((((U32)u8Thunder_MainBox[7]) << 16)&0x00FF0000)|
                    ((((U32)u8Thunder_MainBox[8]) << 8 )&0x0000FF00)|
                    ((((U32)u8Thunder_MainBox[9])      )&0x000000FF);

            if(u32MailBoxTimeID != u32TimeID)
            {
                printf("FAIL!!!  TimeID(org:[%lx])  [%lx]\n", u32MailBoxTimeID, u32TimeID);
                continue;
            }

            p=(char *)((BT_BEON_TO_HK_SHAER_BUFFER_MEMORY_TYPE & MIU1) ? (BT_BEON_TO_HK_SHAER_BUFFER_ADR | MIU_INTERVAL) : (BT_BEON_TO_HK_SHAER_BUFFER_ADR));
            //PrintfInfo(p,(char *)(p+len));
            DataParser(p,len);

            printf("DataParser finished!\n");
#if 1
            {
                int i,j;
                for(i=0;i<NUM_OF_SEARCH_LIST_PER_PAGE;i++)
                {
                    for(j=EN_CID;j<EN_MAX_FILEINFO;j++)
                    {
                        PrintfInfo(SearchResult[i][j][EN_START],SearchResult[i][j][EN_END]);
                    }
                }
            }
#endif
            break;
        }
        else
        {
            printf("MApp_BT_GetAnySearch Failed0\n");
            return FALSE;
        }
    }

    printf("MApp_BT_GetAnySearch ok\n");
    return TRUE;
#endif
}
#else
BOOLEAN MApp_Thunder_GetAnySearch(char *skey,int num,int page)
{
    BOOLEAN bRet = FALSE;
    MBX_Msg uMailBoxPara;
    U16 u16Cont;

    MApp_Thunder_SendUnLockMemory();

    u8UTF8Sting = (U8 *)((BT_HK_TO_BEON_SHAER_BUFFER_MEMORY_TYPE & MIU1) ? (BT_HK_TO_BEON_SHAER_BUFFER_ADR | MIU_INTERVAL) : (BT_HK_TO_BEON_SHAER_BUFFER_ADR));
    memset(u8UTF8Sting,0,128);
    snprintf((char *)u8UTF8Sting,128,"http://dy.gougou.com/btinfo?keyword=%s&num=%d&page=%d",skey,num,page);
    //strncpy((char *)u8UTF8Sting,"http://dy.gougou.com/btinfo?keyword=007&num=5&page=1",128);

    printf("MApp_BT_GetAnySearch cmd=%s\n",(char *)u8UTF8Sting);

    bThunderBuffLock = TRUE;

    // set Parameter
    uMailBoxPara.u8Index        = MB_BTC_HTTPCMD_ALL;
    uMailBoxPara.u8ParameterCount        = 0;

    bRet = MApp_Thunder_SendMailBox(uMailBoxPara);

    if(!bRet)
    {
        printf("MApp_BT_GetAnySearch Failed\n");
        return FALSE;
    }

    for(u16Cont = 0; u16Cont<300; u16Cont++)
    {
        if(MApp_Thunder_MailBoxHandle(10, MB_BTC_SENDALL))
            break;
    }

    if(u16Cont<300)
    {
        char *p; U32 len;
        len = ((((U32)u8Thunder_MainBox[2]) << 24)&0xFF000000)|
                ((((U32)u8Thunder_MainBox[3]) << 16)&0x00FF0000)|
                ((((U32)u8Thunder_MainBox[4]) << 8 )&0x0000FF00)|
                ((((U32)u8Thunder_MainBox[5])      )&0x000000FF);
        printf("MApp_BT_GetAnyData Size [%lx]\n", len);

        p=(char *)((BT_BEON_TO_HK_SHAER_BUFFER_MEMORY_TYPE & MIU1) ? (BT_BEON_TO_HK_SHAER_BUFFER_ADR | MIU_INTERVAL) : (BT_BEON_TO_HK_SHAER_BUFFER_ADR));
        //PrintfInfo(p,(char *)(p+len));
        DataParser(p,len);

        printf("DataParser finished!\n");
        {
            int i,j;
            for(i=0;i<NUM_OF_SEARCH_LIST_PER_PAGE;i++)
            {
                for(j=EN_CID;j<EN_MAX_FILEINFO;j++)
                {
                    PrintfInfo(SearchResult[i][j][EN_START],SearchResult[i][j][EN_END]);
                }
            }
        }
    }
    else
    {
        printf("MApp_BT_GetAnySearch Failed0\n");
        return FALSE;
    }

    printf("MApp_BT_GetAnySearch ok\n");
    return TRUE;
}
#endif
//*****************************************************************************
//Sender: AEON
//Receiver: MIPS
//ParamCount @ Memory buffer.
//Send http command to get the Image file
//Refer to Torrent Client HTTP Commands
//*****************************************************************************
//#if     1
THUNDER_MAINLINK_State MApp_GetThunderMainLinkState(void)
{
    return uThunder_MainLink_State;
}


#define THUNDER_GET_ANY_DATA_WAIT_COUNT_DEF     100
BOOLEAN MApp_Thunder_GetAnyData2( BOOLEAN IsTopMovieList)
{
    BOOLEAN bRet = FALSE;
    MBX_Msg uMailBoxPara;
    U32 u32len, u32TimeID;
    static U32 u32addr;
    static U8 u8WaitCount = 0;
    static U8 u8CmdCount = 0;

    switch( uThunder_MainLink_State )
    {
        case STATE_THUNDER_MAINLINK_CMD_1:
            {
                MApp_Thunder_SendUnLockMemory();

                u8UTF8Sting = (U8 *)(((BT_HK_TO_BEON_SHAER_BUFFER_MEMORY_TYPE & MIU1) ? (BT_HK_TO_BEON_SHAER_BUFFER_ADR | MIU_INTERVAL) : (BT_HK_TO_BEON_SHAER_BUFFER_ADR))|0x80000000UL);
                memset(u8UTF8Sting,0,128);

                if(IsTopMovieList)
                    strncpy((char *)u8UTF8Sting,"http://dy.gougou.com/top_movie?num=10",128);
                else
                    strncpy((char *)u8UTF8Sting,"http://dy.gougou.com/rank_list/rank1.xml",128);

                printf("MApp_BT_GetAnyData cmd=%s\n",(char *)u8UTF8Sting);

                bThunderBuffLock = TRUE;

                u32MailBoxTimeID = msAPI_Timer_GetTime0();

                // set Parameter
                uMailBoxPara.u8Index        = MB_BTC_HTTPCMD_ALL;
                uMailBoxPara.u8ParameterCount        = 8;
                uMailBoxPara.u8Parameters[0] = 0;
                uMailBoxPara.u8Parameters[1] = 0;
                uMailBoxPara.u8Parameters[2] = 0;
                uMailBoxPara.u8Parameters[3] = 0 ;

                uMailBoxPara.u8Parameters[4] = (U8)(u32MailBoxTimeID>>24);
                uMailBoxPara.u8Parameters[5] = (U8)(u32MailBoxTimeID>>16);
                uMailBoxPara.u8Parameters[6] = (U8)(u32MailBoxTimeID>>8);
                uMailBoxPara.u8Parameters[7] = (U8)(u32MailBoxTimeID) ;

                bRet = MApp_Thunder_SendMailBox(uMailBoxPara);

                if(!bRet)
                {
                    printf("MApp_BT_GetAnyData Failed\n");
                    return FALSE;
                }
                uThunder_MainLink_State = STATE_THUNDER_MAINLINK_WAIT_1;
                u8WaitCount = THUNDER_GET_ANY_DATA_WAIT_COUNT_DEF;
                return TRUE;
            }
            break;
        case STATE_THUNDER_MAINLINK_WAIT_1:
            {
                char *p;

                if((u8WaitCount --) == 0)
                {
                    printf("MApp_BT_GetAnyData Failed0\n");
                    return FALSE;
                }

                if( !MApp_Thunder_MailBoxHandle(10, MB_BTC_SENDALL, &uMailBoxPara))
                    return FALSE;

                u32len = ((((U32)uMailBoxPara.u8Parameters[0]) << 24)&0xFF000000)|
                        ((((U32)uMailBoxPara.u8Parameters[1]) << 16)&0x00FF0000)|
                        ((((U32)uMailBoxPara.u8Parameters[2]) << 8 )&0x0000FF00)|
                        ((((U32)uMailBoxPara.u8Parameters[3])      )&0x000000FF);
                printf("MApp_BT_GetAnyData Size [%lx]\n", u32len);

                u32TimeID = ((((U32)uMailBoxPara.u8Parameters[4]) << 24)&0xFF000000)|
                        ((((U32)uMailBoxPara.u8Parameters[5]) << 16)&0x00FF0000)|
                        ((((U32)uMailBoxPara.u8Parameters[6]) << 8 )&0x0000FF00)|
                        ((((U32)uMailBoxPara.u8Parameters[7])      )&0x000000FF);

                if(u32MailBoxTimeID != u32TimeID)
                {
                    printf("FAIL!!!  TimeID1(org:[%lx])  [%lx]\n", u32MailBoxTimeID, u32TimeID);
                    return FALSE;
                }

                p=(char *)((BT_BEON_TO_HK_SHAER_BUFFER_MEMORY_TYPE & MIU1) ? (BT_BEON_TO_HK_SHAER_BUFFER_ADR | MIU_INTERVAL) : (BT_BEON_TO_HK_SHAER_BUFFER_ADR));
                //PrintfInfo(p,(char *)(p+len));
                DataParser(p,u32len);

                printf("DataParser finished!\n");
                uThunder_MainLink_State = STATE_THUNDER_MAINLINK_CMD_2;
                u32addr = ((BT_HK_IMAGE_DATA_BUFFER_MEMORY_TYPE & MIU1) ? (BT_HK_IMAGE_DATA_BUFFER_ADR | MIU_INTERVAL) : (BT_HK_IMAGE_DATA_BUFFER_ADR));
                u8CmdCount = 0;
                return TRUE;

            }
            break;
        case STATE_THUNDER_MAINLINK_CMD_2:
            {
                MApp_Thunder_SendUnLockMemory();
                u8UTF8Sting = (U8 *)(((BT_HK_TO_BEON_SHAER_BUFFER_MEMORY_TYPE & MIU1) ? (BT_HK_TO_BEON_SHAER_BUFFER_ADR | MIU_INTERVAL) : (BT_HK_TO_BEON_SHAER_BUFFER_ADR))|0x80000000UL);
                memset(u8UTF8Sting,0,128);
                CopyString((char *)u8UTF8Sting, MovieList[u8CmdCount][EN_PIC][EN_START], MovieList[u8CmdCount][EN_PIC][EN_END]);
                printf("MApp_BT_GetAnyData cmd[%d]=%s\n", u8CmdCount, (char *)u8UTF8Sting);

                bThunderBuffLock = TRUE;

                u32MailBoxTimeID = msAPI_Timer_GetTime0();

                // set Parameter
                uMailBoxPara.u8Index        = MB_BTC_HTTPCMD_ALL;
                uMailBoxPara.u8ParameterCount        = 8;

                uMailBoxPara.u8Parameters[0] = (U8)(u32addr>>24)|0x80;
                uMailBoxPara.u8Parameters[1] = (U8)(u32addr>>16);
                uMailBoxPara.u8Parameters[2] = (U8)(u32addr>>8);
                uMailBoxPara.u8Parameters[3] = (U8)(u32addr) ;

                uMailBoxPara.u8Parameters[4] = (U8)(u32MailBoxTimeID>>24);
                uMailBoxPara.u8Parameters[5] = (U8)(u32MailBoxTimeID>>16);
                uMailBoxPara.u8Parameters[6] = (U8)(u32MailBoxTimeID>>8);
                uMailBoxPara.u8Parameters[7] = (U8)(u32MailBoxTimeID) ;

                bRet = MApp_Thunder_SendMailBox(uMailBoxPara);

                if(!bRet)
                {
                    printf("MApp_BT_GetAnyData Failed1\n");
                    return FALSE;
                }

                uThunder_MainLink_State = STATE_THUNDER_MAINLINK_WAIT_2;
                u8WaitCount = THUNDER_GET_ANY_DATA_WAIT_COUNT_DEF;
                return TRUE;
            }
            break;
        case STATE_THUNDER_MAINLINK_WAIT_2:
            {
                BOOLEAN bGetInfoError = FALSE;

                if((u8WaitCount --) == 0)
                {
                    printf("MApp_BT_GetAnyData Failed2\n");
                    bRet = FALSE;
                }

                if( !MApp_Thunder_MailBoxHandle(10, MB_BTC_SENDALL, &uMailBoxPara))
                {
                    U8 u8Count;
                    for(u8Count = 0; u8Count< NUM_OF_ERROR; u8Count++)
                    {
                        if(uThunderErrorState[u8Count] == MB_BTC_ERR_DN_ALL )
                        {
                            uThunderErrorState[u8Count] = MB_BTC_ERR_NONE;
                            printf("Get Info Error!\n");
                            bGetInfoError = TRUE;
                            break;
                        }
                    }

                    bRet = FALSE;
                }
                else
                {
                    bRet = TRUE;
                }

                if(bRet || bGetInfoError)
                {
                    if(bGetInfoError)
                    {
                        u32len = 0;
                    }
                    else
                    {
                        u32len = ((((U32)uMailBoxPara.u8Parameters[0]) << 24)&0xFF000000)|
                            ((((U32)uMailBoxPara.u8Parameters[1]) << 16)&0x00FF0000)|
                            ((((U32)uMailBoxPara.u8Parameters[2]) << 8 )&0x0000FF00)|
                            ((((U32)uMailBoxPara.u8Parameters[3])      )&0x000000FF);

                        u32TimeID = ((((U32)uMailBoxPara.u8Parameters[4]) << 24)&0xFF000000)|
                                ((((U32)uMailBoxPara.u8Parameters[5]) << 16)&0x00FF0000)|
                                ((((U32)uMailBoxPara.u8Parameters[6]) << 8 )&0x0000FF00)|
                                ((((U32)uMailBoxPara.u8Parameters[7])      )&0x000000FF);

                        if(u32MailBoxTimeID != u32TimeID)
                        {
                            printf("FAIL!!!  TimeID2(org:[%lx])  [%lx]\n", u32MailBoxTimeID, u32TimeID);
                            return FALSE;
                        }

                    }
                    printf("MApp_BT_GetPic [%d]Size [%lx]\n",u8CmdCount, u32len);

                    MoviePIC[u8CmdCount][EN_START]=(char *)u32addr;
                    u32addr += u32len;
                    MoviePIC[u8CmdCount][EN_END]=(char *)u32addr;
                    u32addr=(u32addr+8)&0xfffffff8;

                    u8CmdCount++;
                    if(u8CmdCount == 10)
                    {
                        uThunder_MainLink_State = STATE_THUNDER_MAINLINK_DONE;
                        u8Thunder_JPEG_State = STATE_THUNDER_JPEG_INIT;
                    }
                    else
                        uThunder_MainLink_State = STATE_THUNDER_MAINLINK_CMD_2;
                }

                return bRet;
            }
            break;
        case STATE_THUNDER_MAINLINK_DONE:
            printf("MApp_BT_GetAnyData ok\n");
            return TRUE;
            break;
        case STATE_THUNDER_MAINLINK_NONE:
            return FALSE;
            break;
    }

    return FALSE;
}
//#else
BOOLEAN MApp_Thunder_GetAnyData(void)//(THUNDER_MAINLINK_State uStep, BOOLEAN IsTopMovieList)
{
    BOOLEAN bRet = FALSE;
    MBX_Msg uMailBoxPara;
    U16 u16Cont;
    int i;U32 u32addr;

    MApp_Thunder_SendUnLockMemory();

    u8UTF8Sting = (U8 *)((BT_HK_TO_BEON_SHAER_BUFFER_MEMORY_TYPE & MIU1) ? (BT_HK_TO_BEON_SHAER_BUFFER_ADR | MIU_INTERVAL) : (BT_HK_TO_BEON_SHAER_BUFFER_ADR));
    memset(u8UTF8Sting,0,128);
    strncpy((char *)u8UTF8Sting,"http://dy.gougou.com/top_movie?num=10",128);
    //strncpy((char *)u8UTF8Sting,"http://dy.gougou.com/rank_list/rank1.xml",128);
    printf("MApp_BT_GetAnyData cmd=%s\n",(char *)u8UTF8Sting);

    bThunderBuffLock = TRUE;

    // set Parameter
    uMailBoxPara.u8Index        = MB_BTC_HTTPCMD_ALL;
    uMailBoxPara.u8ParameterCount        = 0;

    bRet = MApp_Thunder_SendMailBox(uMailBoxPara);

    if(!bRet)
    {
        printf("MApp_BT_GetAnyData Failed\n");
        return FALSE;
    }

    for(u16Cont = 0; u16Cont<300; u16Cont++)
    {
        if(MApp_Thunder_MailBoxHandle(10, MB_BTC_SENDALL, &uMailBoxPara))
            break;
    }

    if(u16Cont<300)
    {
        char *p; U32 len;
        len = ((((U32)uMailBoxPara.u8Parameters[0]) << 24)&0xFF000000)|
                ((((U32)uMailBoxPara.u8Parameters[1]) << 16)&0x00FF0000)|
                ((((U32)uMailBoxPara.u8Parameters[2]) << 8 )&0x0000FF00)|
                ((((U32)uMailBoxPara.u8Parameters[3])      )&0x000000FF);
        printf("MApp_BT_GetAnyData Size [%lx]\n", len);

        p=(char *)((BT_BEON_TO_HK_SHAER_BUFFER_MEMORY_TYPE & MIU1) ? (BT_BEON_TO_HK_SHAER_BUFFER_ADR | MIU_INTERVAL) : (BT_BEON_TO_HK_SHAER_BUFFER_ADR));
        //PrintfInfo(p,(char *)(p+len));
        DataParser(p,len);

        printf("DataParser finished!\n");
    }
    else
    {
        printf("MApp_BT_GetAnyData Failed0\n");
        return FALSE;
    }

//------------------------------------------------------------------------------------------
    u32addr = ((BT_HK_IMAGE_DATA_BUFFER_MEMORY_TYPE & MIU1) ? (BT_HK_IMAGE_DATA_BUFFER_ADR | MIU_INTERVAL) : (BT_HK_IMAGE_DATA_BUFFER_ADR));
    for(i=0;i<10;i++)
    {
        MApp_Thunder_SendUnLockMemory();
        u8UTF8Sting = (U8 *)((BT_HK_TO_BEON_SHAER_BUFFER_MEMORY_TYPE & MIU1) ? (BT_HK_TO_BEON_SHAER_BUFFER_ADR | MIU_INTERVAL) : (BT_HK_TO_BEON_SHAER_BUFFER_ADR));
        memset(u8UTF8Sting,0,128);
        CopyString((char *)u8UTF8Sting,MovieList[i][EN_PIC][EN_START],MovieList[i][EN_PIC][EN_END]);
        printf("MApp_BT_GetAnyData cmd[%d]=%s\n",i,(char *)u8UTF8Sting);

        bThunderBuffLock = TRUE;

        // set Parameter
        uMailBoxPara.u8Index        = MB_BTC_HTTPCMD_ALL;
        uMailBoxPara.u8ParameterCount        = 4;
        uMailBoxPara.u8Parameters[0] = (U8)(u32addr>>24)|0x80;
        uMailBoxPara.u8Parameters[1] = (U8)(u32addr>>16);
        uMailBoxPara.u8Parameters[2] = (U8)(u32addr>>8);
        uMailBoxPara.u8Parameters[3] = (U8)(u32addr) ;

        bRet = MApp_Thunder_SendMailBox(uMailBoxPara);

        if(!bRet)
        {
            printf("MApp_BT_GetAnyData Failed1\n");
            return FALSE;
        }

        for(u16Cont = 0; u16Cont<300; u16Cont++)
        {
            if(MApp_Thunder_MailBoxHandle(10, MB_BTC_SENDALL, &uMailBoxPara))
                break;
        }

        if(u16Cont<300)
        {
            U32 len;
            len = ((((U32)uMailBoxPara.u8Parameters[0]) << 24)&0xFF000000)|
                ((((U32)uMailBoxPara.u8Parameters[1]) << 16)&0x00FF0000)|
                ((((U32)uMailBoxPara.u8Parameters[2]) << 8 )&0x0000FF00)|
                ((((U32)uMailBoxPara.u8Parameters[3])      )&0x000000FF);
            printf("MApp_BT_GetPic [%d]Size [%lx]\n",i, len);

            MoviePIC[i][EN_START]=(char *)u32addr;
            u32addr+=len;
            MoviePIC[i][EN_END]=(char *)u32addr;
            u32addr=(u32addr+8)&0xfffffff8;
        }
        else
        {
            printf("MApp_BT_GetAnyData Failed2\n");
            return FALSE;
        }
    }
        printf("MApp_BT_GetAnyData ok\n");

        uThunder_MainLink_State = STATE_THUNDER_MAINLINK_DONE;
        u8Thunder_JPEG_State = STATE_THUNDER_JPEG_INIT;

    return TRUE;
}
//#endif

//----------------------------------------------------------------------
// strstrn --
//     Locate the first instance of a substring in a string before ppstringend
// Results:
//     If string contains substring, the return value is the
//     location of the first matching instance of substring
//     in string. If string doesn't contain substring, the
//     return value is 0. Matching is done on an exact
//     character-for-character basis with no wildcards or special
//     characters.
// Side effects:
//     None.
//----------------------------------------------------------------------
int strstrn(char **ppstringstart,char **ppstringend,char *psubstring)
{
    char *a,*b;
    //First scan quickly through the two strings looking for a
    //single-character match. When it's found, then compare the
    //rest of the substring.
    b = psubstring;
    if(*b==0)
        return 1;
    if(*ppstringstart>=*ppstringend)
        return 0;

    for(;(**ppstringstart!=0)&&(*ppstringstart<*ppstringend);(*ppstringstart)++)
    {
        if(**ppstringstart != *b)
            continue;
        a = *ppstringstart;
        while(1)
        {
            if(*b == 0)
                return 1;

            if(*a++ != *b++)
                break;
        }
        b = psubstring;
    }
    return 0;
}
// find out how many keyword blocks from pstringstart to pstringend
// return the number
int strnum(char *pstringstart,char *pstringend,char *pskeyword)
{
    char key1[32],key2[32];
    char **s1,**s2;
    int counter=0;

    s1=&pstringstart;
    s2=&pstringend;
    snprintf(key1,32,"<%s",pskeyword);
    snprintf(key2,32,"</%s>",pskeyword);
    while(*s1<*s2)
    {
        if(0==strstrn(s1,s2,key1))
            break;

        if(0==strstrn(s1,s2,key2))
            break;
        counter++;
    }

    return counter;
}
// find out which place the No.n keyword blocks is from pstringstart to pstringend
// return the true or false, the start & end pointer.
int strkeyn(char **ppstringstart,char **ppstringend,char *pskeyword,int counter)
{
    char key1[32],key2[32];
    char *pstemp;

    snprintf(key1,32,"<%s",pskeyword);
    snprintf(key2,32,"</%s>",pskeyword);

    if(counter<=0)
        return 0;

    while(--counter>0)
    {
        if(0==strstrn(ppstringstart,ppstringend,key1))
            return 0;

        if(0==strstrn(ppstringstart,ppstringend,key2))
            return 0;
    }

    if(0==strstrn(ppstringstart,ppstringend,key1))
        return 0;

    pstemp=strchr(*ppstringstart,'>');
    if( (unsigned int)(pstemp-*ppstringstart)==(strlen(pskeyword)+1) )
        *ppstringstart=1+pstemp;

    pstemp=*ppstringstart;
    if(strstrn(&pstemp,ppstringend,key2))
    {
        *ppstringend = pstemp;
        return 1;
    }

    return 0;
}
// find out <keyword1 keyword2=" ">
// return the true or false, the start & end pointer.
int strdata(char **ppstringstart,char **ppstringend,char *pskeyword1,char *pskeyword2)
{
    char key1[32],key2[32];

    snprintf(key1,32,"<%s",pskeyword1);
    snprintf(key2,32,"%s=\"",pskeyword2);

    if(0==strstrn(ppstringstart,ppstringend,key1))
        return 0;

    *ppstringend=strchr(*ppstringstart,'>');
    if(*ppstringend==0)
        return 0;

    if(0==strstrn(ppstringstart,ppstringend,key2))
        return 0;
    *ppstringstart+=strlen(key2);

    *ppstringend=strchr(*ppstringstart,'"');

    if(*ppstringend)
        return 1;
    else
        return 0;
}

/////////////////////////////////////////////////////////////////////////////////////
void CopyString(char *dst, char *s1, char *s2)
{
    int i,max;
    max = s2-s1;
    for(i=0;i<max;i++)
        *dst++=*s1++;
    *dst='\0';
}
void PrintfInfo(char *s1,char *s2)
{
    int i=0,max;
    max = s2-s1;
        while((*s1!=0)&&(*(s1+1)!=0)&&(++i<(max+1)))
            putchar((int)(*s1++));
        printf("\n");
}
int StrToInt(char * str)
{
    int value = 0;
    int sign = 1;
    if(*str == '-')
    {
            sign = -1;
            str++;
    }
    while(*str)
    {
            value = value * 10 + *str - '0';
            str++;
    }
    return sign*value;
}

/////////////////////////////////////////////////////////////////////////////////////

int DataParser(char *sInputBuffer, int iLength)
{
    char *sStartBuffer,*sEndBuffer;
    int i,j,total;

    sStartBuffer=sInputBuffer;
    sEndBuffer=sInputBuffer+iLength;

    if(strnum(sStartBuffer,sEndBuffer,"ResultSet"))
    {
        {
            char *pcounterStart,*pcounterEnd;char temp[32];
            pcounterStart=sStartBuffer;
            pcounterEnd=sEndBuffer;
            strdata(&pcounterStart,&pcounterEnd,"Query","Count");
            //PrintfInfo(pcounterStart,pcounterEnd);
            memset(temp,0,32);
            CopyString(temp,pcounterStart,pcounterEnd);
            ResultCounter = StrToInt(temp);
        }
        strkeyn(&sStartBuffer,&sEndBuffer,"ResultSet",1);
        total=strnum(sStartBuffer,sEndBuffer,"FileInfo");
        for(i=0;(i<total)&&(i<10);i++)
        {
            SearchResult[i][EN_BLOCKR][EN_START]=sStartBuffer;
            SearchResult[i][EN_BLOCKR][EN_END]=sEndBuffer;
            strkeyn(&SearchResult[i][EN_BLOCKR][EN_START],&SearchResult[i][EN_BLOCKR][EN_END],"FileInfo",i+1);
            for(j=EN_BLOCKR+1;j<EN_MAX_FILEINFO;j++)
            {
                SearchResult[i][j][EN_START]=SearchResult[i][EN_BLOCKR][EN_START];
                SearchResult[i][j][EN_END]=SearchResult[i][EN_BLOCKR][EN_END];
            }
            strkeyn(&SearchResult[i][EN_CID][EN_START],&SearchResult[i][EN_CID][EN_END],"Cid",1);
            strkeyn(&SearchResult[i][EN_TITLE][EN_START],&SearchResult[i][EN_TITLE][EN_END],"Title",1);
            SearchResult[i][EN_TITLE][EN_START]+=strlen("<![CDATA[");
            SearchResult[i][EN_TITLE][EN_END]-=strlen("]]>");
            strkeyn(&SearchResult[i][EN_SIZE][EN_START],&SearchResult[i][EN_SIZE][EN_END],"Size",1);
            strkeyn(&SearchResult[i][EN_FORMAT][EN_START],&SearchResult[i][EN_FORMAT][EN_END],"Format",1);
            strkeyn(&SearchResult[i][EN_PLAYTIME][EN_START],&SearchResult[i][EN_PLAYTIME][EN_END],"PlayTime",1);
            strkeyn(&SearchResult[i][EN_BITRATE][EN_START],&SearchResult[i][EN_BITRATE][EN_END],"BitRate",1);
            strkeyn(&SearchResult[i][EN_TORRENT][EN_START],&SearchResult[i][EN_TORRENT][EN_END],"Torrent",1);
            strkeyn(&SearchResult[i][EN_TONUM][EN_START],&SearchResult[i][EN_TONUM][EN_END],"TorrentNum",1);
        }
    }
    else if(strnum(sStartBuffer,sEndBuffer,"moviesets"))
    {
        strkeyn(&sStartBuffer,&sEndBuffer,"moviesets",1);
        total=strnum(sStartBuffer,sEndBuffer,"movie");
        for(i=0;(i<total)&&(i<10);i++)
        {
            MovieList[i][EN_BLOCKM][EN_START]=sStartBuffer;
            MovieList[i][EN_BLOCKM][EN_END]=sEndBuffer;
            strkeyn(&MovieList[i][EN_BLOCKM][EN_START],&MovieList[i][EN_BLOCKM][EN_END],"movie",i+1);
            for(j=EN_BLOCKM+1;j<EN_MAX_MOVEINFO;j++)
            {
                MovieList[i][j][EN_START]=MovieList[i][EN_BLOCKM][EN_START];
                MovieList[i][j][EN_END]=MovieList[i][EN_BLOCKM][EN_END];
            }
            strdata(&MovieList[i][EN_MID][EN_START],&MovieList[i][EN_MID][EN_END],"movie","id");
            if(0==strkeyn(&MovieList[i][EN_NAME][EN_START],&MovieList[i][EN_NAME][EN_END],"key",1))
            {
                MovieList[i][EN_NAME][EN_START]=MovieList[i][EN_BLOCKM][EN_START];
                MovieList[i][EN_NAME][EN_END]=MovieList[i][EN_BLOCKM][EN_END];
                strkeyn(&MovieList[i][EN_NAME][EN_START],&MovieList[i][EN_NAME][EN_END],"name",1);
            }
            strkeyn(&MovieList[i][EN_DESC][EN_START],&MovieList[i][EN_DESC][EN_END],"desc",1);
            strkeyn(&MovieList[i][EN_PIC][EN_START],&MovieList[i][EN_PIC][EN_END],"pic",1);
        }
    }
    else if(strnum(sStartBuffer,sEndBuffer,"Suggest"))
    {
        strkeyn(&sStartBuffer,&sEndBuffer,"Suggest",1);
        total=strnum(sStartBuffer,sEndBuffer,"SuggestWord");
        ResultCounter = total;
        for(i=0;(i<total)&&(i<10);i++)
        {
            MovieKeyword[i][EN_START]=sStartBuffer;
            MovieKeyword[i][EN_END]=sEndBuffer;
            strkeyn(&MovieKeyword[i][EN_START],&MovieKeyword[i][EN_END],"SuggestWord",i+1);
            //PrintfInfo(MovieKeyword[i][EN_START],MovieKeyword[i][EN_END]);
        }
    }
    else
    {
            printf("Can not matched!\n");
        return 0;
    }

    return 1;
}


/******************************************************************************/
/// Bit-torrent init
/******************************************************************************/
void MApp_Thunder_MainLink0_Init(void)
{
    U8 i;

    for(i=0;i<NUM_OF_MAINLINK0_ITEM_PER_PAGE;i++)
        m_Thunder_MainLink0Status[i].bLinkPicFile_Show = TRUE;

    uThunder_MainLink_State = STATE_THUNDER_MAINLINK_CMD_1;
    MApp_Thunder_SetLink0Flags(TRUE);
    MApp_Thunder_SetLink1Flags(FALSE);
}

void MApp_Thunder_MainLink1_Init(void)
{
    U8 i;

    for(i=0;i<NUM_OF_MAINLINK0_ITEM_PER_PAGE;i++)
        m_Thunder_MainLink1Status[i].bLinkPicFile_Show = TRUE;

    uThunder_MainLink_State = STATE_THUNDER_MAINLINK_CMD_1;
    MApp_Thunder_SetLink0Flags(FALSE);
    MApp_Thunder_SetLink1Flags(TRUE);
}


void MApp_Thunder_Init(void)
{
    MApp_Thunder_MainLink0_Init();
    MApp_Thunder_MainLink1_Init();
    //MApp_BT_CoProcesser_Init();
}


/******************************************************************************/
/// Read back Image  File Size.
/// @return Image File Size
/******************************************************************************/
U32 MApp_Thunder_GetPictureFileSize(U8 u8Item)
{
    return (U32)(MoviePIC[u8Item][EN_END] - MoviePIC[u8Item][EN_START]);
}

void MApp_Thunder_GetPictureFileData(U8 u8Item)
{
    U32 u32DstAddr = (U32)(((MAD_JPEG_READBUFF_MEMORY_TYPE & MIU1) ? (MAD_JPEG_READBUFF_ADR | MIU_INTERVAL) : (MAD_JPEG_READBUFF_ADR))|0x80000000UL);
    char *pDst;

    pDst= (char *)u32DstAddr;

    CopyString(pDst, MoviePIC[u8Item][EN_START], MoviePIC[u8Item][EN_END]);

    printf("Addr: [%lx]\n", u32DstAddr);
    printf("Size: [%lx]\n", (U32)(MoviePIC[u8Item][EN_END] - MoviePIC[u8Item][EN_START]));

}


#define THUNDER_MOVIE_PHOTO_X    100
#define THUNDER_MOVIE_PHOTO_Y    160
#define THUNDER_MOVIE_PHOTO_W    (g_IPanel.Width()/6)
#define THUNDER_MOVIE_PHOTO_H    (g_IPanel.Height()/6)
#define THUNDER_MOVIE_PHOTO_X_DIS    10
#define THUNDER_MOVIE_PHOTO_Y_DIS   90
extern void MApp_Thunder_ClearTopOrNewListPhotoBG(U8 u8Item);
U32 u32Thunder_time;
//BOOLEAN bBTJpegTest = FALSE;
/******************************************************************************/
/// dispaly JPEG on GOP/VOP
/// @param  u8Idx \b IN Specify the index offset.
/// @param  bEnable \b IN display or un-display on VOP,only valid on VOP mode
/// @return  true or false
/******************************************************************************/
static BOOLEAN _MApp_Thunder_DisplayMoviePhoto(U8 u8Idx, BOOLEAN bEnable)
{
    BOOLEAN  bRet = FALSE;

    printf("Jpeg Idx [%d] s:[%d]\n", u8Idx, u8Thunder_JPEG_State);

    switch(u8Thunder_JPEG_State)
    {
        case STATE_THUNDER_JPEG_INIT:
            {
            #if 0   // load Logo bin to test.
                    U32 u32SrcPhotoAddr;
                    U32 u32SrcPhotoLen;
                    MEMCOPYTYPE mPhotoCopyType;
                    BOOLEAN bResult;

                // temperoly load logo jpeg from flash
                    BININFO   BinInfo;
                    BinInfo.B_ID = BIN_ID_JPEG_BOOT_LOGO;
                    MDrv_Sys_Get_BinInfo(&BinInfo, &bResult);
                    if ( bResult != PASS)
                    {
                        THUNDER_DBG(printf( "could not find logo binary on flash.\n" ));
                        return FALSE;
                    }
                    u32SrcPhotoAddr = BinInfo.B_FAddr;
                    u32SrcPhotoLen = BinInfo.B_Len;
                    mPhotoCopyType = MIU_FLASH2SDRAM;// MIU_SRAM2SDRAM
                // temperoly load logo jpeg from flash

                    MDrv_BDMA_CopyHnd(u32SrcPhotoAddr, (U32)((MAD_JPEG_READBUFF_MEMORY_TYPE & MIU1) ? (MAD_JPEG_READBUFF_ADR | MIU_INTERVAL) : (MAD_JPEG_READBUFF_ADR)), GE_ALIGNED_VALUE(u32SrcPhotoLen,8), MIU_FLASH2SDRAM);
            #else
                // for jpeg Error or No Image file handle
                if(MApp_Thunder_GetPictureFileSize( u8Idx ) == 0)
                {
                    u8Thunder_JPEG_State = STATE_THUNDER_JPEG_NONE;
                    bRet = TRUE;
                    break;
                }
                else
                {
                    MApp_Thunder_GetPictureFileData( u8Idx );
                }
            #endif

#if NEW_PHOTO
                MApp_Photo_MemCfg(
                        ((MAD_JPEG_READBUFF_MEMORY_TYPE & MIU1) ? (MAD_JPEG_READBUFF_ADR | MIU_INTERVAL) : (MAD_JPEG_READBUFF_ADR)), MAD_JPEG_READBUFF_LEN,
                        ((MAD_JPEG_OUT_MEMORY_TYPE & MIU1) ? (MAD_JPEG_OUT_ADR | MIU_INTERVAL) : (MAD_JPEG_OUT_ADR)), MAD_JPEG_OUT_LEN,
                        ((MAD_JPEG_INTERBUFF_MEMORY_TYPE & MIU1) ? (MAD_JPEG_INTERBUFF_ADR | MIU_INTERVAL) : (MAD_JPEG_INTERBUFF_ADR)), MAD_JPEG_INTERBUFF_LEN);

                if (MApp_Photo_DecodeMemory_Init(FALSE, NULL) == FALSE)
                {
                    u8Thunder_JPEG_State = STATE_THUNDER_JPEG_NONE;
                    bRet = TRUE;
                    break;
                }

#else // #if NEW_PHOTO
                if (!msAPI_JPEG_Init(JPEG_INIT_DECODE))
                {
                    THUNDER_DBG(printf(" JPEG init failed\n"));
                    break;
                }

                msAPI_JPEG_StartDecode(
                        ((MAD_JPEG_INTERBUFF_MEMORY_TYPE & MIU1) ? (MAD_JPEG_INTERBUFF_ADR | MIU_INTERVAL) : (MAD_JPEG_INTERBUFF_ADR)), MAD_JPEG_INTERBUFF_LEN, // internal used memory addr
                        ((MAD_JPEG_READBUFF_MEMORY_TYPE & MIU1) ? (MAD_JPEG_READBUFF_ADR | MIU_INTERVAL) : (MAD_JPEG_READBUFF_ADR)), MAD_JPEG_READBUFF_LEN, // input data memory addr
                        ((MAD_JPEG_OUT_MEMORY_TYPE & MIU1) ? (MAD_JPEG_OUT_ADR | MIU_INTERVAL) : (MAD_JPEG_OUT_ADR)), // output jpeg memory addr
                        0);

#endif // #if NEW_PHOTO
                u8Thunder_JPEG_State = STATE_THUNDER_JPEG_DECODE;
                u32Thunder_time = msAPI_Timer_GetTime0();
            }
            break;

        case STATE_THUNDER_JPEG_DECODE:
            {
#if NEW_PHOTO
                EN_RET enPhotoRet;

                if ((enPhotoRet = MApp_Photo_Main()) != EXIT_PHOTO_DECODING)
                {
                    if ((enPhotoRet == EXIT_PHOTO_DECODE_DONE) && (MApp_Photo_GetErrCode() == E_PHOTO_ERR_NONE))
                    {
                        u8Thunder_JPEG_State = STATE_THUNDER_JPEG_SHOW;
                        MApp_Thunder_ClearTopOrNewListPhotoBG(u8Idx);
                    }
                    else
                    {
                        u8Thunder_JPEG_State = STATE_THUNDER_JPEG_NONE;
                        bRet = TRUE;
                    }

                    MApp_Photo_Stop();
                }

#else // #if NEW_PHOTO
                JPEG_DECODE_STATUS u8DecodeStatus=JPEG_DECODE_RUNNING;
                U32 u32RequestDataAddr, u32RequestDataSize;

                switch (msAPI_JPEG_GetDecoderState(&u32RequestDataAddr, &u32RequestDataSize))
                {
                    case JPEG_DECODER_STATE_INPUT:
                        // report no more data
                        msAPI_JPEG_ProceedDecode(0);
                        break;

                    case JPEG_DECODER_STATE_OUTPUT:
                        u8DecodeStatus = msAPI_JPEG_GetDecodeStatus();
                        break;

                    case JPEG_DECODER_STATE_DECODE:
                    default:
                        break;
                }

                if( u8DecodeStatus == JPEG_DECODE_RUNNING )
                {
                }
                else if(u8DecodeStatus == JPEG_DECODE_DONE)
                {
                    u8Thunder_JPEG_State = STATE_THUNDER_JPEG_SHOW;
                    MApp_Thunder_ClearTopOrNewListPhotoBG(u8Idx);
                }
                else  // Jpeg decode fail!
                {
                    u8Thunder_JPEG_State = STATE_THUNDER_JPEG_NONE;
                    bRet = TRUE;
                }

                if((msAPI_Timer_GetTime0() - u32Thunder_time) > 3000)
                    u8Thunder_JPEG_State = STATE_THUNDER_JPEG_INIT;
#endif // #if NEW_PHOTO
            }
            break;

        case STATE_THUNDER_JPEG_SHOW:
            {
                ST_JPEG_CAPTURE_RECT stTo, stFrom;
                EN_JPEG_COLOR_FORMAT eJpegColorFormat=EN_JPEG_COLOR_RGB;
                BOOLEAN bShowOnOtherGWIN=FALSE;// if enable ,please take attention GWIN priority

                if(bEnable)
                {
                    memset(&stTo, 0, sizeof(stTo));
                    memset(&stFrom, 0, sizeof(stFrom));
                    MApp_Jpeg_GetImageInfo(&stFrom.u16RectW, &stFrom.u16RectH, NULL);
                    stTo.u16RectX = THUNDER_MOVIE_PHOTO_X+(u8Idx%3)*(THUNDER_MOVIE_PHOTO_X_DIS+THUNDER_MOVIE_PHOTO_W);
                    stTo.u16RectY = THUNDER_MOVIE_PHOTO_Y+(u8Idx/3)*(THUNDER_MOVIE_PHOTO_Y_DIS+THUNDER_MOVIE_PHOTO_H);
                    stTo.u16RectW = THUNDER_MOVIE_PHOTO_W;
                    stTo.u16RectH = THUNDER_MOVIE_PHOTO_H;
                    if(eJpegColorFormat==EN_JPEG_COLOR_YUV)
                        stTo.u8FbFmt = GFX_FMT_YUV422;
                    else
                        stTo.u8FbFmt = GFX_FMT_ARGB1555;

                    THUNDER_DBG(printf("\n u16RectX , u16RectY , u8Idx = %d, %d, %d",stTo.u16RectX,stTo.u16RectY,(U16)u8Idx));
                    if(!bShowOnOtherGWIN)//get FB firstly,because MApp_Jpeg_Display2 didn't set FB when RGB show on current GWIN
                    {
                        GOP_GwinFBAttr stFbAttr;
                        U8 u8FbId , u8GwinId;

                        u8FbId = MApi_GOP_GWIN_GetCurrentFBID();
                        u8GwinId = MApi_GOP_GWIN_GetCurrentWinId();
                        THUNDER_DBG(printf("\n BT page u8GwinId=%d\n",(U16)u8GwinId));
                        if ((u8FbId >= MAX_GWIN_FB_SUPPORT) || (u8GwinId >= MAX_GWIN_SUPPORT))
                        {
                            THUNDER_DBG(printf("No FB or GW\n"));
                            return FALSE;
                        }

                        MApi_GOP_GWIN_MapFB2Win(u8FbId, u8GwinId);
                        MApi_GOP_GWIN_GetFBInfo(u8FbId, &stFbAttr);

                        stTo.u16BuffW = stFbAttr.width;
                        stTo.u16BuffH = stFbAttr.height;
                        stTo.u32BuffAddr = stFbAttr.addr;
                    }

                    MApp_Jpeg_Display2(TRUE, eJpegColorFormat, bShowOnOtherGWIN, &stTo, &stFrom, EN_JPEG_ALIGN_MIDDLE_CENTERED, EN_JPEG_FIT_BOUNDARY);

                    u8Thunder_JPEG_State = STATE_THUNDER_JPEG_NONE;
                    bRet = TRUE;
                }
            }
            break;

        default:
            break;

    }

    return bRet;
}


/******************************************************************************/
/// Thunder download task
/******************************************************************************/
void MApp_Thunder_Task(void)
{
    U8 i;

    if(MApp_Thunder_GetSystemInitState() != STATE_SYSTEM_INIT_NONE && MApp_Thunder_GetSystemInitState() != STATE_SYSTEM_INIT_OK)
    {
        MApp_Thunder_CoProcesser_Init();
        return;
    }

    if(MApp_Thunder_GetThunderFlags()&E_THUNDER_FLAG_LINK0PHOTO_MODE)
    {
#if 1
        for(i=0; (i<NUM_OF_MAINLINK0_ITEM_PER_PAGE) && (uThunder_MainLink_State == STATE_THUNDER_MAINLINK_DONE); i++)
        {
            if(m_Thunder_MainLink0Status[i].bLinkPicFile_Show)
            {
                if(_MApp_Thunder_DisplayMoviePhoto(i, TRUE))
                {
                    m_Thunder_MainLink0Status[i].bLinkPicFile_Show=FALSE;
                    if(i == (NUM_OF_MAINLINK0_ITEM_PER_PAGE -1))
                    {
                         //uThunder_MainLink_State = STATE_THUNDER_MAINLINK_NONE;
                    }
                    else
                         u8Thunder_JPEG_State = STATE_THUNDER_JPEG_INIT;
                }
                break;//draw next photo on next loop
            }
        }
#endif

    }
    else if(MApp_Thunder_GetThunderFlags()&E_THUNDER_FLAG_LINK1PHOTO_MODE)
    {
#if 1
        for(i=0; (i<NUM_OF_MAINLINK1_ITEM_PER_PAGE) && (uThunder_MainLink_State == STATE_THUNDER_MAINLINK_DONE); i++)
        {
            if(m_Thunder_MainLink1Status[i].bLinkPicFile_Show)
            {
                if(_MApp_Thunder_DisplayMoviePhoto(i, TRUE))
                {
                    m_Thunder_MainLink1Status[i].bLinkPicFile_Show=FALSE;
                    if(i == (NUM_OF_MAINLINK0_ITEM_PER_PAGE -1))
                    {
                         //uThunder_MainLink_State = STATE_THUNDER_MAINLINK_NONE;
                     }
                    else
                         u8Thunder_JPEG_State = STATE_THUNDER_JPEG_INIT;
                }
                break;//draw next photo on next loop
            }
        }
#endif
    }

}

#undef MAPP_THUNDER_C

#endif//#if (ENABLE_THUNDER_DOWNLOAD)
#endif//#ifdef ENABLE_BT
