////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#define MAPP_LOADFONTINIT_C


#include <stdlib.h>
#include <stdio.h>
#include "MsCommon.h"
#include "msAPI_MIU.h"

// Common Definition
#include "apiXC.h"
#include "MApp_LoadFontInit.h"
#include "MApp_Font.h"
#include "MApp_ZUI_ACTglobal.h"
#include "BinInfo.h"
#include "InfoBlock.h"

///////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////

//**********************************************************
#if (VECTOR_FONT_ENABLE && !(OBA2))
extern BOOLEAN msAPI_MVF_init_mempool (void *pool, U32 size);
#endif

//**********************************************************
#if FONT_SUPPORT_VECTOR_AND_BITMAP
LOADFONT_STRUCT font_info[] =
{
    {
        .FontID = FONT_1,
        .output_bpp = 2,
        .output_size =18,
        .output_width = 18,
        .output_height = 23,
        .unicode_from = { 0x0020, 0},
        .unicode_to = { 0xFFFF, 0},
    },

};
#else

LOADFONT_STRUCT font_info[] =
{
    {
        .FontID = FONT_0,
        .output_bpp = 2,
        .output_size =18,
        .output_width = 18,
        .output_height = 23,
        .unicode_from = { 0x0020, 0},
        .unicode_to = { 0xFFFF, 0},
    },
    {
        .FontID = FONT_1,
        .output_bpp = 2,
        .output_size = 24.5,
        .output_width = 21,
        .output_height = 28,
        .unicode_from = { 0x0020, 0},
        .unicode_to = { 0xFFFF, 0},
    },

    {
        .FontID = FONT_2,
        .output_bpp = 2,
        .output_size = 35,
        .output_width = 30,
        .output_height = 40,
        .unicode_from = { 0x0020, 0},
        .unicode_to = { 0xFFFF, 0},
    },
#if 0
    {
        .FontID = FONT_0,
        .output_bpp = 2,
        .output_size = 35,
        .output_width = 30,
        .output_height = 40,
        .unicode_from = { 0x0020, 0},
        .unicode_to = { 0xFFFF, 0},
    },
    {
        .FontID = FONT_1,
        .output_bpp = 2,
        .output_size = 24.5,
        .output_width = 21,
        .output_height = 28,
        .unicode_from = { 0x0020, 0},
        .unicode_to = { 0xFFFF, 0},
    },
    {
        .FontID = FONT_2,
        .output_bpp = 2,
        .output_size = 17.6,
        .output_width = 15.2,
        .output_height = 20,
        .unicode_from = { 0x0020, 0},
        .unicode_to = { 0xFFFF, 0},
    },
 #endif
};
#endif

LOADFONT_PAIR fontpair[] =
{
#if (ENABLE_ATV_ASIA_FONT)
    {FONT_ASIA,FONT_ASIA_I2},
#elif (ENABLE_DVB_TAIWAN_APP  ||CHINESE_BIG5_FONT_ENABLE)
    {FONT_BIG5,FONT_BIG5_I2},
#elif (ENABLE_DTMB_CHINA_APP \
       || ENABLE_ATV_CHINA_APP \
       || ENABLE_DVBC_PLUS_DTMB_CHINA_APP \
       ||CHINESE_SIMP_FONT_ENABLE \
       ||ENABLE_SBTVD_BRAZIL_APP \
       )
    {FONT_CHINESE,FONT_CHINESE_I2},
#if ENABLE_CUS_SUPPORT_SIMP_CH_ARABIC_FONT
    {FONT_ASIA,FONT_ASIA_I2},
#endif
    {FONT_CHINESE_SIMP_SUPERBIG,FONT_CHINESE_SIMP_SUPERBIG_I2},
    {FONT_CHINESE_SIMP_BIG_24,FONT_CHINESE_SIMP_BIG24_I2},
#endif
};

#if VECTOR_FONT_ENABLE
void MApp_LoadFontInit_VEC(void)
{
    U8 u8num = sizeof(font_info)/sizeof(LOADFONT_STRUCT) - 1;
    MApp_LoadFont_SetVecFontInfo(font_info, 0, u8num);

}

#if FONT_SUPPORT_VECTOR_AND_BITMAP
static void MApp_LoadFontInit_BMP(void)
{
    U8 u8num = sizeof(fontpair)/sizeof(LOADFONT_PAIR);
    MApp_LoadFont_SetBMPFontInfo(fontpair,u8num);
}
#endif

#else
static void MApp_LoadFontInit_BMP(void)
{
    U8 u8num = sizeof(fontpair)/sizeof(LOADFONT_PAIR);

    MApp_LoadFont_SetBMPFontInfo(fontpair,u8num);
}
#endif

void MApp_LoadFontInit(void)
{
    CAL_TIME_FUNC_START();

    msAPI_Font_VariableInit();

  #if VECTOR_FONT_ENABLE

    #if (!OBA2)
        #if (!COPRO_MVF_ENABLE)
        msAPI_MVF_init_mempool((void*)_PA2VA(((POOL_BUFFER_MEMORY_TYPE&MIU1)?POOL_BUFFER_ADR|MIU_INTERVAL:POOL_BUFFER_ADR)), POOL_BUFFER_LEN);
        #endif
    #endif

    MApp_LoadFontInit_VEC();
    #if FONT_SUPPORT_VECTOR_AND_BITMAP
    MApp_LoadFontInit_BMP();
    #endif
  #else

    MApp_LoadFontInit_BMP();

  #endif

    CAL_TIME_FUNC_END();
}

#ifdef DVBT_MMBOX
void MApp_Load2ndFontGroup(void)
{
    font_info[0].output_size = 26;
    font_info[0].output_width = 23;
    font_info[0].output_height = 30;
    font_info[1].output_size = 20;
    font_info[1].output_width = 18;
    font_info[1].output_height = 23;
    font_info[2].output_size = 18;
    font_info[2].output_width = 16;
    font_info[2].output_height = 20;
    msAPI_OSD_RESOURCE_ResetFontVar();
    msAPI_Font_Set2ndFontAddr();
    MApp_LoadFontInit_VEC();
}
#endif


