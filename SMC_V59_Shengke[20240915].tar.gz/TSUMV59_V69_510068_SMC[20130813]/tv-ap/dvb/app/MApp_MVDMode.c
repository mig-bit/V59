////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#define MAPP_MVDMODE_C

#include <stdio.h>
#include <string.h>
#include "Board.h"
#include "datatype.h"
#include "msAPI_Global.h"

#include "debug.h"
#if (ENABLE_CI)
#include "msAPI_CI.h"
#endif

#include "apiXC.h"
#include "apiXC_Adc.h"

#include "apiXC_Sys.h"
#include "msAPI_Global.h"
#include "msAPI_Video.h"
#include "msAPI_Timer.h"
#include "apiGOP.h"
#include "apiXC_Ace.h"
#include "apiXC.h"

#include "MApp_GlobalSettingSt.h"
#include "MApp_GlobalVar.h"
#include "msAPI_audio.h"

//ZUI: #include "MApp_DispMenu.h"
#if (ENABLE_DTV)
#include "mapp_demux.h"
#endif

#include "MApp_Scaler.h"
#include "MApp_MVDMode.h"
#include "MApp_TV.h"
#include "MApp_MultiTasks.h"
#include "MApp_PCMode.h"

#include "MApp_ChannelChange.h"

//for Audio mute issue
#include "MApp_Audio.h"
//for Audio mute issue

#include "MApp_ATVProc.h"
#include "msAPI_DTVSystem.h"
//ZUI_TODO: #include "MApp_UiMenu.h"
#include "MApp_BlockSys.h" //ZUI:
#include "MApp_TopStateMachine.h"
#if ENABLE_PVR
#include "MApp_PVR.h"
#endif
//#define DBG_VIDEO_APP
#define MVD_DEBUG(msg) //msg


/********************************************************************************/
/*                     Local                    */
/********************************************************************************/

#define MVD_TIMING_STABLE_COUNT 1
#define MVD_BAD_VIDEO_COUNT 3 // 3s
#define MVD_BAD_PICTUR_COUNT 1


BOOLEAN sbIsAspectRatioWide    = FALSE;
static U32 u32MonitorMVDValidTimer;

static U32 PictureCounter;

static U8   BadPictureCounter;
static U32  u32PicCounterTimer;

// calvin 070130, add a timeout for MVD first frame check
#define MVD_FF_READY_TIMEOUT 15000 //071210_daniel set timeout to 15sec for Audio_tests_Layer_2_256-384kbps.mpg
static U32 u32FFReadyTimer;


// enable this if we want to freeze image when bitstream has error
#define FREEZE_VIDEO_ENABLE  0

#if FREEZE_VIDEO_ENABLE
#define MVD_BAD_VIDEO_FREEZE_TIMEOUT 600
static BOOLEAN bEnErrFreeze;
static BOOLEAN bEnErrMute;
static U8 u8ErrCnt;
static U32 u32ErrFreezeCounter;
static U32 u32ErrMuteCounter;
#endif

#if DTV_HD_USE_FBL
#define FBLMSG(fmt, args...)   printf("[MApp_MVDmode][%d]" fmt, __LINE__, ## args)
#endif

#if ENABLE_AUTOTEST
extern BOOLEAN g_bAutobuildDebug;
#endif
/********************************************************************************/
/*                   Functions                      */
/********************************************************************************/
//*************************************************************************
//Function name:  _MApp_VID_CheckVideoStatus
//Passing parameter: none
//Return parameter: none
//Description: polling codec decode status.
//*************************************************************************
static void _MApp_VID_CheckVideoStatus(void)
{
    if ( msAPI_Timer_DiffTimeFromNow( u32PicCounterTimer ) > 1000 && enMVDVideoStatus != MVD_UNKNOWN_VIDEO )
    {
        U32 u32PictureNumber = 0;
//        if ( msAPI_VID_GetPicCount() < PictureCounter )
        if ( MApi_VDEC_GetFrameCnt() < PictureCounter )
        {
//            u32PictureNumber = 0xFFFFFFFF - PictureCounter + msAPI_VID_GetPicCount();
            u32PictureNumber = 0xFFFFFFFF - PictureCounter + MApi_VDEC_GetFrameCnt();
        }
        else
        {
//            u32PictureNumber = msAPI_VID_GetPicCount() - PictureCounter;
            u32PictureNumber = MApi_VDEC_GetFrameCnt() - PictureCounter;
        }

        if ( u32PictureNumber < MVD_BAD_PICTUR_COUNT )
        {
            BadPictureCounter++;
            if ( BadPictureCounter > MVD_BAD_VIDEO_COUNT )
            {
                enMVDVideoStatus = MVD_BAD_VIDEO;
                BadPictureCounter = 0;
            }
        }
        else
        {
            enMVDVideoStatus = MVD_GOOD_VIDEO;
            BadPictureCounter = 0;
        #if (ENABLE_AUTOTEST || ENABLE_BOOTTIME)
        #if (ENABLE_BOOTTIME==DISABLE)
            if (g_bAutobuildDebug == TRUE)
        #endif
            {
                if (gbBootTimeFinish == FALSE)
                {
                    gU32TmpTime = msAPI_Timer_DiffTimeFromNow(gU32BootTime);
                    printf("[boot time]Good video status = %ld\n", gU32TmpTime);
                }
            }
        #endif
        }

        u32PicCounterTimer = msAPI_Timer_GetTime0();
//        PictureCounter = msAPI_VID_GetPicCount();
        PictureCounter = MApi_VDEC_GetFrameCnt();
    }
}

//*************************************************************************
//Function name:    MApp_VID_VariableInit
//Passing parameter:    none
//Return parameter:    none
//Description:
//*************************************************************************
void MApp_VID_VariableInit(void)
{
//printf("MApp_VID_VariableInit()\n");
//    if(bAVCH264)
    if(IS_HVD_CODEC(g_eCodecType))//msAPI_VID_GetCodecType() == E_VDEC_CODEC_TYPE_H264)
        MApp_AVCH264_VariableInit();
    else
        MApp_MVD_VariableInit();

    BadPictureCounter = 0;
//    PictureCounter = msAPI_VID_GetPicCount();
    PictureCounter = MApi_VDEC_GetFrameCnt();
    u32PicCounterTimer = msAPI_Timer_GetTime0();

}

//*************************************************************************
//Function name:    MApp_MVD_VariableInit
//Passing parameter:    none
//Return parameter:    none
//Description:
//*************************************************************************
void MApp_MVD_VariableInit ( void )
{
    //printf("MApp_MVD_VariableInit()\n");

    bMVDTimingChange = TRUE;
    bFastTimingCheck = TRUE;
    u8MVDTimingStableCount = 0;
    u8MVDDecodeCount = 0;
    bMVDDoSetMode = FALSE;
#if FREEZE_VIDEO_ENABLE
    bEnErrFreeze = FALSE;
    bEnErrMute = FALSE;
#endif

    bPrepareChange = FALSE;
    bFirstTimeCheck = FALSE;
    fCurMVDValidFlag = TRUE;
    u32MonitorMVDValidTimer = ( msAPI_Timer_GetTime0() - 3000 );

    #if AUTO_ASPECT_RATIO
    sbIsAspectRatioWide = FALSE;
    #endif

    memset( &gstVidStatus, 0, sizeof( VDEC_DispInfo ) );
    memset( &gstPreVidStatus, 0, sizeof( VDEC_DispInfo ) );

    //Init PreVidStatus.u8AFD to 0xFF for AFD monitor;
    gstPreVidStatus.u8AFD = 0xFF;

    enMVDVideoStatus = MVD_UNKNOWN_VIDEO;

    u32FFReadyTimer=msAPI_Timer_GetTime0();
}

//*************************************************************************
//Function name:    MApp_VID_TimingMonitor
//Passing parameter:    none
//Return parameter:    none
//Description:
//*************************************************************************
void MApp_VID_TimingMonitor(SCALER_WIN eWindow)
{
//    if(bAVCH264)
    if((msAPI_VID_GetPlayMode() == MSAPI_VID_STOP)
        || (msAPI_VID_GetPlayMode() == MSAPI_VID_RESET))
    {
        return;
    }
    if(IS_HVD_CODEC(msAPI_VID_GetCodecType()))//msAPI_VID_GetCodecType() == E_VDEC_CODEC_TYPE_H264)
        MApp_AVCH264_TimingMonitor();
    else
        MApp_MVD_TimingMonitor(eWindow);

}


//*************************************************************************
//Function name:    MApp_MVD_TimingMonitor
//Passing parameter:    none
//Return parameter:    none
//Description:
//*************************************************************************
#if (ENABLE_VE)
#define ENABLE_MVD_TWICEFRC FALSE
#else
#define ENABLE_MVD_TWICEFRC FALSE
#endif
void MApp_MVD_TimingMonitor ( SCALER_WIN eWindow )
{
#if ENABLE_DTV
    MEMBER_SERVICETYPE bServiceType;
    U16 u16CurPosition;
#endif
//    U8              PictureNumber;
#if FREEZE_VIDEO_ENABLE
    U8              u8CurrErrCnt;

//    u8CurrErrCnt = msAPI_VID_GetErrCnt();

    if(IS_MVD_CODEC(msAPI_VID_GetCodecType())){//msAPI_VID_GetCodecType()==E_VDEC_CODEC_TYPE_MPEG2){
        u8CurrErrCnt = MApi_VDEC_GetErrCnt();
    }
    else{
        SHOW_VIDEO_ERR(("Driver Layer do not support this function yet"));
    }
    if (u8ErrCnt != u8CurrErrCnt)
    {
        MApi_XC_FreezeImg(TRUE, eWindow);
        bEnErrFreeze = TRUE;
        u8ErrCnt = u8CurrErrCnt;
        u32ErrFreezeCounter = msAPI_Timer_GetTime0();
    }
    else if (bEnErrFreeze && msAPI_Timer_DiffTimeFromNow(u32ErrFreezeCounter) >
    MVD_BAD_VIDEO_FREEZE_TIMEOUT)
    {
        MApi_XC_FreezeImg(FALSE, eWindow);
        bEnErrFreeze = FALSE;
    }
#endif

    // fast timing check for speedup channel change
    if(TRUE==bFastTimingCheck)
    {
        if(E_VDEC_OK == MApi_VDEC_CheckDispInfoRdy() && TRUE == msAPI_VID_GetVidInfo(&gstVidStatus))
        {
#if ENABLE_MVD_TWICEFRC
            //let MVOP do double FRC if 25P/30P signal, it will fix the subtitle of VE ouput shaking issue
            //because the VE do not has good FRC capability
            if((gstVidStatus.u32FrameRate < 35000) && (gstVidStatus.u8Interlace==FALSE))
            {
                gstVidStatus.u32FrameRate *=2;
            }
#endif
            gstPreVidStatus.u16HorSize = gstVidStatus.u16HorSize;
            gstPreVidStatus.u16VerSize = gstVidStatus.u16VerSize;
            gstPreVidStatus.u8AspectRate = gstVidStatus.u8AspectRate;
            gstPreVidStatus.u32FrameRate = gstVidStatus.u32FrameRate;
            gstPreVidStatus.u8Interlace = gstVidStatus.u8Interlace;

            // 2007.12.20 Daniel.Huang: code refine
            #if 0
            (printf( "MVD fast timing change\n" ));
            (printf( "H=%u\n", gstVidStatus.u16HorSize ));
            (printf( "V=%u\n", gstVidStatus.u16VerSize ));
            (printf( "F=%u\n", gstVidStatus.u32FrameRate ));
            (printf( "A=%bu\n", gstVidStatus.u8AspectRate ));
            (printf( "I=%bu\n", gstVidStatus.u8Interlace ));
            #endif

            MApp_MVD_PrepareTimingChange(eWindow);
            bMVDDoSetMode = TRUE;
            bFastTimingCheck=FALSE;
            bMVDTimingChange=FALSE; //2007-11-9[daniel.huang]: solve 2 times setmode
            return;
        }

        if(msAPI_Timer_DiffTimeFromNow(u32FFReadyTimer)>MVD_FF_READY_TIMEOUT)
        {
            MApp_MVD_VariableInit();
            bFastTimingCheck = FALSE;
            enMVDVideoStatus = MVD_BAD_VIDEO;
        }
        return;
    }

    //--------------------------------------------
    if ( bMVDTimingChange==TRUE )
    {
        bMVDTimingChange = FALSE;
        bPrepareChange = TRUE;
        MApp_MVD_PrepareTimingChange(eWindow);
        return;
    }

    if ( FALSE == bFirstTimeCheck )
    {
        bFirstTimeCheck=TRUE;
        u8MVDDecodeCount = 0;
    }

//    if(msAPI_VID_GetDispRdy())
    if(E_VDEC_OK == MApi_VDEC_CheckDispInfoRdy())
    {
#if ENABLE_DTV
        bServiceType = msAPI_CM_GetCurrentServiceType();
        u16CurPosition = msAPI_CM_GetCurrentPosition(bServiceType);
#endif
        if( (
#if ENABLE_DTV
            msAPI_CM_GetProgramAttribute(bServiceType,u16CurPosition, E_ATTRIBUTE_IS_STILL_PICTURE) == FALSE &&
#endif
            E_VDEC_FAIL == MApi_VDEC_IsWithValidStream())
           || FALSE == msAPI_VID_GetVidInfo(&gstVidStatus))
        {
            MVD_DEBUG(printf( "invalid mpeg or video info\n"));
            MApp_MVD_VariableInit();
            bFastTimingCheck = FALSE;
            enMVDVideoStatus = MVD_BAD_VIDEO;

            return;
        }
#if ENABLE_MVD_TWICEFRC
        else
        {
            //let MVOP do double FRC if 25P/30P signal, it will fix the subtitle of VE ouput shaking issue
            //because the VE do not has good FRC capability
            if((gstVidStatus.u32FrameRate < 35000) && (gstVidStatus.u8Interlace==FALSE))
            {
                gstVidStatus.u32FrameRate *=2;
            }
        }
#endif
    }
    else
    {
        if(msAPI_Timer_DiffTimeFromNow(u32FFReadyTimer)>MVD_FF_READY_TIMEOUT)
        {
            MVD_DEBUG(printf("wait FF ready timeout \n"));
            enMVDVideoStatus = MVD_BAD_VIDEO;
            u8MVDTimingStableCount = 0;
            u32FFReadyTimer=msAPI_Timer_GetTime0();
        }
        else
        {
            MVD_DEBUG(printf( "FF not ready \n" ));
            return;
        }
    }

    //--------------------------------------------
    // Check timing stable

    if ( ( gstPreVidStatus.u16HorSize != gstVidStatus.u16HorSize ) || ( gstPreVidStatus.u16VerSize != gstVidStatus.u16VerSize ) ||
    #if AUTO_ASPECT_RATIO
        //( (gstPreVidStatus.u8AspectRate != gstVidStatus.u8AspectRate) && (stGenSetting.g_SysSetting.u8AspectRatioMode==1)) ||
        ( gstPreVidStatus.u8AspectRate != gstVidStatus.u8AspectRate)||
    #endif
        ( gstPreVidStatus.u32FrameRate != gstVidStatus.u32FrameRate ) || ( gstPreVidStatus.u8Interlace != gstVidStatus.u8Interlace ) ) // calvin 070131
    {
        bMVDTimingChange = TRUE;    // Not stable
        u8MVDTimingStableCount = 0;
        gstPreVidStatus.u16HorSize = gstVidStatus.u16HorSize;
        gstPreVidStatus.u16VerSize = gstVidStatus.u16VerSize;
        gstPreVidStatus.u8AspectRate = gstVidStatus.u8AspectRate;
        gstPreVidStatus.u32FrameRate = gstVidStatus.u32FrameRate;
        gstPreVidStatus.u8Interlace = gstVidStatus.u8Interlace; // calvin 070131
    }
    else
    {
        if ( bPrepareChange==TRUE )
        {
            u8MVDTimingStableCount++;

            MVD_DEBUG(printf( "Prepare Change! \n" ));
            if ( u8MVDTimingStableCount > MVD_TIMING_STABLE_COUNT )
            {
                // Do set mode here
                // 2007.12.20 Daniel.Huang: code refine
#if 0
                (printf( "MVD timing change\n" ));
                (printf( "H=%u\n", gstVidStatus.u16HorSize ));
                (printf( "V=%u\n", gstVidStatus.u16VerSize ));
                (printf( "F=%u\n", gstVidStatus.u32FrameRate ));
                (printf( "A=%bu\n", gstVidStatus.u8AspectRate ));
                (printf( "I=%bu\n", gstVidStatus.u8Interlace ));
#endif
               MApi_VDEC_AVSyncOn(TRUE, 120 ,25);          //Sync offset will influence DTV lip-sync timing
                                                           //if you want to change sync offset, please inform audio team and video team


                bMVDDoSetMode = TRUE;
                bPrepareChange = FALSE;
                u8MVDTimingStableCount = 0;
            }
        }
        else
        {
            _MApp_VID_CheckVideoStatus();
        }
    }

  #if (ENABLE_BOOTTIME)
    if (gbBootTimeFinish == FALSE && bMVDDoSetMode == TRUE)
    {
        gU32TmpTime = msAPI_Timer_DiffTimeFromNow(gU32BootTime);
        printf("[boot time]get disp info = %d\n", gU32TmpTime);
    }
  #endif
}


//*************************************************************************
//Function name:    MApp_VID_SetMode
//Passing parameter:    none
//Return parameter:    TRUE = MVD has output , FALSE = Mode doesn't have output
//Description:
//*************************************************************************
BOOLEAN MApp_VID_SetMode( SCALER_WIN eWindow)
{
#if ENABLE_FBL_ASPECT_RATIO_BY_MVOP
    memset(&g_tSrcWin, 0, sizeof(MS_WINDOW_TYPE));
    g_bApplyMVOPCrop = FALSE;
    g_u16HorOffset = 0;
    g_u16VerOffset = 0;
#endif
//    if(bAVCH264)
    if(IS_HVD_CODEC(msAPI_VID_GetCodecType()))//msAPI_VID_GetCodecType() == E_VDEC_CODEC_TYPE_H264)
        return MApp_AVCH264_SetMode(eWindow);
    else
        return MApp_MVD_SetMode(eWindow);
}

//*************************************************************************
//Function name:    MApp_MVD_SetMode
//Passing parameter:    none
//Return parameter:    TRUE = MVD has output , FALSE = Mode doesn't have output
//Description:
//*************************************************************************
BOOLEAN MApp_MVD_SetMode ( SCALER_WIN eWindow )
{
    U32 u32MVDPicCounterCheckTimer;
    U8 u8TurnOffDestination = DISABLE;

    if ( FALSE==bMVDDoSetMode )
    {
        return FALSE;
    }
    bMVDDoSetMode = FALSE;

    CAL_TIME_FUNC_START();


#if (ENABLE_CHCHANGETIME)
    gU32TmpTime = msAPI_Timer_DiffTimeFromNow(gU32ChChangeTime);
    printf("[ch change time]MApp_MVD_SetMode start = %ld\n", gU32TmpTime);
#endif

#if AUTO_ASPECT_RATIO
    if(gstVidStatus.u8AspectRate==ASP_4TO3)
    {
        sbIsAspectRatioWide = FALSE;
        MVD_DEBUG(printf( "sbIsAspectRatio 4TO3 \n" ));
    }
    else if(gstVidStatus.u8AspectRate==ASP_16TO9)
    {
        sbIsAspectRatioWide = TRUE;
        MVD_DEBUG(printf( "sbIsAspectRatio WIDE:ASP_16TO9 \n" ));
    }
    else if(gstVidStatus.u8AspectRate==ASP_1TO1)
    {
        //720*480 must be 4:3 ( Input H/ Input V > 1.5 => wide)
        if( ((U32)gstVidStatus.u16HorSize*2) > ((U32)gstVidStatus.u16VerSize*3) )
            sbIsAspectRatioWide = TRUE;
        else
            sbIsAspectRatioWide = FALSE;

        MVD_DEBUG(printf( "sbIsAspectRatio WIDE&ASP_1TO1 \n" ));
    }
    else if(gstVidStatus.u8AspectRate==ASP_221TO100)
    {
        sbIsAspectRatioWide = TRUE;
        MVD_DEBUG(printf( "ASP_221TO100 \n" ));
    }
#endif


#if DTV_HD_USE_FBL

#if (MirrorEnable)
    if(MIRROR_NORMAL != MApi_XC_GetMirrorModeType())
    {
        FBLMSG("Disable Scaler mirror. use mvop mirror\n");
        MApi_XC_EnableMirrorMode(FALSE);
    }
    MDrv_MVOP_SetVOPMirrorMode(ENABLE, E_VOPMIRROR_HORIZONTALL);
    MDrv_MVOP_SetVOPMirrorMode(ENABLE, E_VOPMIRROR_VERTICAL);
#endif
    MApi_XC_Enable_TwoInitFactor(TRUE, MAIN_WINDOW);

#if ENABLE_3D_PROCESS
    MApi_XC_EnableFrameBufferLess(FALSE);
#else
    MApi_XC_EnableFrameBufferLess(FALSE);

    //if(gstVidStatus.u16VerSize> 720 )
    if(msAPI_VID_IsNeedFrameBufferLessMode(&gstVidStatus))
    {
        FBLMSG("Enable FBL\n");
        MApi_XC_EnableFrameBufferLess(TRUE);
        if((gstVidStatus.u32FrameRate > 24500)&&(gstVidStatus.u32FrameRate <= 25000))
        {
            //stVidStatus.u32FrameRate = 25000;
        }
        else if((gstVidStatus.u32FrameRate > 49500)&&(gstVidStatus.u32FrameRate <= 50000))
        {
            gstVidStatus.u32FrameRate=gstVidStatus.u32FrameRate/2; //25
        }
        else if((gstVidStatus.u32FrameRate > 23500)&&(gstVidStatus.u32FrameRate <= 24000) )
        {
            gstVidStatus.u32FrameRate = (U32)gstVidStatus.u32FrameRate*5/4; //30
        }
        else if((gstVidStatus.u32FrameRate > 29500)&&(gstVidStatus.u32FrameRate <= 30000))
        {
            //~30
        }
        else
        {
            gstVidStatus.u32FrameRate = 30000;
        }
        if(gstVidStatus.u8Interlace == 0)
        {
            gstVidStatus.u32FrameRate = gstVidStatus.u32FrameRate << 1;
        }
    }
#endif
    FBLMSG("MVD Video W=%u, H=%u\n\n", gstVidStatus.u16HorSize, gstVidStatus.u16VerSize);
    FBLMSG("MVD vop W=%u, H=%u\n",     MDrv_MVOP_GetHSize(), MDrv_MVOP_GetVSize());

#endif // #if DTV_HD_USE_FBL


#if ENABLE_FBL_ASPECT_RATIO_BY_MVOP
    if(MApi_XC_IsCurrentFrameBufferLessMode())
    {
        enMVOPVideoType = MVOP_MPG;
        MApp_Scaler_EnableOverScan(FALSE);
        MApp_Scaler_Adjust_AspectRatio_FBL(stSystemInfo[eWindow].enAspectRatio, &g_tSrcWin);
        U16 u16VDE = gstVidStatus.u16VerSize - gstVidStatus.u16CropTop - gstVidStatus.u16CropBottom + 2 * g_u16VerOffset;
        MApp_Scaler_SetFixVtotal(gstVidStatus.u8Interlace, (U16)gstVidStatus.u32FrameRate, u16VDE);
    }
#endif

//    msAPI_VID_SetMVDOutput(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW), &gstVidStatus );
    msAPI_VID_SetOutput(&gstVidStatus );

    u32MvdPicCountTimer = msAPI_Timer_GetTime0();

    enMVDVideoStatus = MVD_GOOD_VIDEO;        //move here for MHEG5 check

    // Set ARC 16:9 in Edit mode or Auto Scanning state
    //stSystemInfo.enAspectRatio = MApp_Scaler_GetAspectRatio(ST_VIDEO.eAspectRatio);
    MApi_XC_Mux_TriggerPathSyncEvent(SYS_INPUT_SOURCE_TYPE(eWindow),NULL);

    MApp_CheckBlockProgramme();// Check DTV/ATV LOCK and ENABLE/DISABLE VE OUT

    u8TurnOffDestination = ENABLE;
    // signal detected. Enable all destination.
    MApi_XC_Mux_TriggerDestOnOffEvent(SYS_INPUT_SOURCE_TYPE(eWindow),&u8TurnOffDestination);

    u32MVDPicCounterCheckTimer=msAPI_Timer_GetTime0();

    MVD_DEBUG(printf( "MApp_MVD_SetMode good\n" ));

#if (ENABLE_CHCHANGETIME)
    gU32TmpTime = msAPI_Timer_DiffTimeFromNow(gU32ChChangeTime);
    printf("[ch change time]MApp_MVD_SetMode end = %ld\n", gU32TmpTime);
#endif

    CAL_TIME_FUNC_END();
    return TRUE;
}

//*************************************************************************
//Function name:    MApp_MVD_PrepareTimingChange
//Passing parameter:    none
//Return parameter:    none
//Description:
//*************************************************************************
void MApp_MVD_PrepareTimingChange ( SCALER_WIN eWindow )
{
    msAPI_Scaler_SetBlueScreen( ENABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, eWindow);
    MVD_DEBUG(printf( "MApp_MVD_PrepareTimingChange \n" ));
    // calvin 070130, add a timeout for MVD first frame check
    u32FFReadyTimer=msAPI_Timer_GetTime0();
}

void MApp_MVD_ValidFlagMonitor()
{
    if ( msAPI_Timer_DiffTimeFromNow(u32MonitorMVDValidTimer) > 3000)
    {
        if (MApi_VDEC_IsWithValidStream() == E_VDEC_OK)
        {
            fCurMVDValidFlag = TRUE;
        }
        else
        {
            fCurMVDValidFlag = FALSE;
        }
        u32MonitorMVDValidTimer =  msAPI_Timer_GetTime0();
    }
}

BOOLEAN MApp_MVD_IsAspectRatioWide(void)
{
    if( sbIsAspectRatioWide    == TRUE)
    {
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}

//*************************************************************************
//Function name:    MApp_AVCH264_VariableInit
//Passing parameter:    none
//Return parameter:    none
//Description:
//*************************************************************************
void MApp_AVCH264_VariableInit( void )
{
    //printf("MApp_AVCH264_VariableInit()\n");

    bH264TimingCheck = TRUE;
    bH264DoSetMode = FALSE;
    sbIsAspectRatioWide = FALSE;
    bH264FastReset = TRUE;

    memset( &gstVidStatus, 0, sizeof( VDEC_DispInfo ) );
    memset( &gstPreVidStatus, 0, sizeof( VDEC_DispInfo ) );

    enMVDVideoStatus = MVD_UNKNOWN_VIDEO;
}

//*************************************************************************
//Function name:    MApp_MVD_TimingMonitor
//Passing parameter:    none
//Return parameter:    none
//Description:
//*************************************************************************
#define DEBUG_AVC_MONITOR(x)   // x
void MApp_AVCH264_TimingMonitor( void )
{
    U32 u32DisplayReady = 0;
    VDEC_DispInfo NewVidStatus;


    DEBUG_AVC_MONITOR( printf("[AVC_Mo]"); );
    DEBUG_AVC_MONITOR( printf(" bH264TimingCheck=%u, MApi_VDEC_IsSeqChg()=%u\n", bH264TimingCheck, MApi_VDEC_IsSeqChg()); );


    if(TRUE == bH264TimingCheck || E_VDEC_OK == MApi_VDEC_IsSeqChg())
    {
        u32DisplayReady = MApi_VDEC_CheckDispInfoRdy();
        DEBUG_AVC_MONITOR( printf(" u32DisplayReady=%u\n", u32DisplayReady ); );

        if( E_VDEC_OK == MApi_VDEC_CheckDispInfoRdy() )
        {
            if (!msAPI_VID_GetVidInfo(&NewVidStatus))
            {
                MS_DEBUG_MSG(printf("Get SVD Seq Info failed\n"));
            }

            DEBUG_AVC_MONITOR( printf(" u16HorSize=%u, u16VerSize=%u\n", NewVidStatus.u16HorSize, NewVidStatus.u16VerSize ); );
            DEBUG_AVC_MONITOR( printf(" u32FrameRate=%lu \n", NewVidStatus.u32FrameRate ); );

            if( ( 10000 <= NewVidStatus.u32FrameRate) && ( NewVidStatus.u32FrameRate<= 200000) &&
                 (NewVidStatus.u16HorSize!= 0)  && (NewVidStatus.u16VerSize!= 0)   )
            {
#if ENABLE_MVD_TWICEFRC
                //let MVOP do double FRC if 25P/30P signal, it will fix the subtitle of VE ouput shaking issue
                //because the VE do not has good FRC capability
                if((NewVidStatus.u32FrameRate < 35000) && (NewVidStatus.u8Interlace==FALSE))
                {
                    NewVidStatus.u32FrameRate *=2;
                }
#endif //ENABLE_MVD_TWICEFRC
                memcpy(&gstVidStatus, &NewVidStatus, sizeof(VDEC_DispInfo));

                gstVidStatus.u8AFD = MApi_VDEC_GetActiveFormat();

                memcpy(&gstPreVidStatus, &gstVidStatus, sizeof(VDEC_DispInfo));
                MApi_VDEC_AVSyncOn(TRUE, 120 ,25);          //Sync offset will influence DTV lip-sync timing
                                                            //if you want to change sync offset, please inform audio team and video team
                bH264TimingCheck = FALSE;
                bH264DoSetMode = TRUE;
                bH264FastReset = FALSE;
                bH264FirstTimeCheck = FALSE;
            }
            else
            {
                MS_DEBUG_MSG(printf("h264 get invalid frame rate:%ld\n" , NewVidStatus.u32FrameRate  ));
                if (E_VDEC_OK != MApi_VDEC_SetBlueScreen(FALSE))
                {
                    MS_DEBUG_MSG(printf("MApi_VDEC_SetBlueScreen Fail\n"));
                }
            }
        }

    }
    else
    {
        if (!msAPI_VID_GetVidInfo(&gstVidStatus))
        {
            MS_DEBUG_MSG(printf("Get Vid Info failed\n"));
        }
#if ENABLE_MVD_TWICEFRC
        else
        {
            //let MVOP do double FRC if 25P/30P signal, it will fix the subtitle of VE ouput shaking issue
            //because the VE do not has good FRC capability
            if((gstVidStatus.u32FrameRate < 35000) && (gstVidStatus.u8Interlace==FALSE))
            {
                gstVidStatus.u32FrameRate *=2;
            }
        }
#endif //ENABLE_MVD_TWICEFRC
        gstVidStatus.u8AFD = MApi_VDEC_GetActiveFormat();
        //printf("Check SEQ \n");
        if((gstPreVidStatus.u16HorSize != gstVidStatus.u16HorSize) ||
           (gstPreVidStatus.u16VerSize != gstVidStatus.u16VerSize) ||
           (gstPreVidStatus.u32FrameRate != gstVidStatus.u32FrameRate) ||
           (gstPreVidStatus.u8Interlace != gstVidStatus.u8Interlace))
        {
            memcpy(&gstPreVidStatus, &gstVidStatus, sizeof(VDEC_DispInfo));
            MApi_VDEC_AVSyncOn(TRUE, 120 ,25);          //Sync offset will influence DTV lip-sync timing
                                                        //if you want to change sync offset, please inform audio team and video team
            bH264DoSetMode = TRUE;
            //printf("SEQ Chg \n");
        }

    }

    if(bH264FastReset && !bH264FirstTimeCheck)
    {
        msAPI_VID_Command(MSAPI_VID_STOP);
        MDrv_MVOP_Enable(FALSE);
#if ENABLE_PVR
        if( MApp_PVR_IsPlaybacking())
        {
            msAPI_VID_Init(TRUE, E_VDEC_SRC_MODE_TS_FILE);
        }
        else
#endif
        {
            msAPI_VID_Init(TRUE, E_VDEC_SRC_MODE_DTV);
        }

        msAPI_VID_Command(MSAPI_VID_PLAY);
        bH264FastReset = FALSE;
    }

    if(bH264DoSetMode == FALSE)
    {
        _MApp_VID_CheckVideoStatus();
    }

    #if (ENABLE_BOOTTIME)
    if (gbBootTimeFinish == FALSE && bH264DoSetMode == TRUE)
    {
        gU32TmpTime = msAPI_Timer_DiffTimeFromNow(gU32BootTime);
        printf("[boot time]get disp info = %d\n", gU32TmpTime);
    }
    #endif

//#if DEBUG_H264
//    MDrv_VDEC_DebugMonitor(E_VDEC_SVD);
//#endif
}

//*************************************************************************
//Function name:    MApp_AVCH264_SetMode
//Passing parameter:    none
//Return parameter:    TRUE = H264 has output , FALSE = Mode doesn't have output
//Description:
//*************************************************************************
BOOLEAN MApp_AVCH264_SetMode( SCALER_WIN eWindow )
{
    U8 u8TurnOffDestination = ENABLE;

    if ( FALSE==bH264DoSetMode )
    {
        return FALSE;
    }
    bH264DoSetMode = FALSE;

    CAL_TIME_FUNC_START();


#if (ENABLE_CHCHANGETIME)
    gU32TmpTime = msAPI_Timer_DiffTimeFromNow(gU32ChChangeTime);
    printf("[ch change time]MApp_AVCH264_SetMode start = %ld\n", gU32TmpTime);
#endif

    if(!msAPI_VID_AVCH264IsAspectRatioWide(&gstVidStatus,&sbIsAspectRatioWide))
    {
        MVD_DEBUG( printf( "msAPI_VID_AVCH264IsAspectRatioWide error \n" ) );
    }

#if DTV_HD_USE_FBL
#if (MirrorEnable)
    if(MIRROR_NORMAL != MApi_XC_GetMirrorModeType())
    {
        FBLMSG("Disable Scaler mirror. use mvop mirror\n");
        MApi_XC_EnableMirrorMode(FALSE);
    }
    MDrv_MVOP_SetVOPMirrorMode(ENABLE, E_VOPMIRROR_HORIZONTALL);
    MDrv_MVOP_SetVOPMirrorMode(ENABLE, E_VOPMIRROR_VERTICAL);
#endif
    MApi_XC_Enable_TwoInitFactor(TRUE, MAIN_WINDOW);

#if ENABLE_3D_PROCESS
    MApi_XC_EnableFrameBufferLess(FALSE);
#else
    MApi_XC_EnableFrameBufferLess(FALSE);

    //if(gstVidStatus.u16VerSize> 720 )
    if(msAPI_VID_IsNeedFrameBufferLessMode(&gstVidStatus))
    {
        FBLMSG("Enable FBL\n");
        MApi_XC_EnableFrameBufferLess(TRUE);
        if((gstVidStatus.u32FrameRate > 24500)&&(gstVidStatus.u32FrameRate <= 25000))
        {
            //stVidStatus.u16FrameRate = 25000;
        }
        else if((gstVidStatus.u32FrameRate > 49500)&&(gstVidStatus.u32FrameRate <= 50000))
        {
            gstVidStatus.u32FrameRate=gstVidStatus.u32FrameRate/2; //25
        }
        else if((gstVidStatus.u32FrameRate > 23500)&&(gstVidStatus.u32FrameRate <= 24000) )
        {
            gstVidStatus.u32FrameRate = (U32)gstVidStatus.u32FrameRate*5/4; //30
        }
        else if((gstVidStatus.u32FrameRate > 29500)&&(gstVidStatus.u32FrameRate <= 30000))
        {
            //~30
        }
        else
        {
            gstVidStatus.u32FrameRate = 30000;
        }

        if(gstVidStatus.u8Interlace == 0)
        {
            gstVidStatus.u32FrameRate = gstVidStatus.u32FrameRate << 1;
        }
    }
#endif
    FBLMSG("AVC Video W=%u, H=%u\n\n", gstVidStatus.u16HorSize, gstVidStatus.u16VerSize);
    FBLMSG("AVC vop W=%u, H=%u\n",     MDrv_MVOP_GetHSize(), MDrv_MVOP_GetVSize());

#endif

#if ENABLE_FBL_ASPECT_RATIO_BY_MVOP
    if(MApi_XC_IsCurrentFrameBufferLessMode())
    {
        enMVOPVideoType = MVOP_H264;
        g_u16StripSize = gstVidStatus.u16HorSize;
        MApp_Scaler_EnableOverScan(FALSE);
        MApp_Scaler_Adjust_AspectRatio_FBL(stSystemInfo[eWindow].enAspectRatio, &g_tSrcWin);
        U16 u16VDE = gstVidStatus.u16VerSize - gstVidStatus.u16CropTop - gstVidStatus.u16CropBottom + 2 * g_u16VerOffset;
        MApp_Scaler_SetFixVtotal(gstVidStatus.u8Interlace, (U16)gstVidStatus.u32FrameRate, u16VDE);
    }
#endif

    //    msAPI_VID_SetH264Output(&gstVidStatus);
    msAPI_VID_SetOutput(&gstVidStatus);
    #if 0
       MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_SIDE_BY_SIDE_HALF, E_XC_3D_OUTPUT_FRAME_R, E_XC_3D_PANEL_NONE, MAIN_WINDOW);
    #endif
    // Set ARC 16:9 in Edit mode or Auto Scanning state
    //stSystemInfo.enAspectRatio = MApp_Scaler_GetAspectRatio(ST_VIDEO.eAspectRatio);
    MApi_XC_Mux_TriggerPathSyncEvent(SYS_INPUT_SOURCE_TYPE(eWindow),NULL);

    u8TurnOffDestination = ENABLE;
    // signal detected. Enable all destination.
    MApi_XC_Mux_TriggerDestOnOffEvent(SYS_INPUT_SOURCE_TYPE(eWindow),&u8TurnOffDestination);

//    msAPI_VID_AVCH264GetDispInfoDone();
    if (E_VDEC_OK != MApi_VDEC_SetBlueScreen(FALSE))
    {
        MS_DEBUG_MSG(printf("MApi_VDEC_SetBlueScreen Fail\n"));
    }

    MVD_DEBUG(printf( "MApp_AVCH264_SetMode good\n" ));

    #if (ENABLE_CHCHANGETIME)
    gU32TmpTime = msAPI_Timer_DiffTimeFromNow(gU32ChChangeTime);
    printf("[ch change time]MApp_MVD_SetMode end = %ld\n", gU32TmpTime);
    #endif

    enMVDVideoStatus = MVD_GOOD_VIDEO;

    CAL_TIME_FUNC_END();

    return TRUE;

}

#undef MAPP_MVDMODE_C
