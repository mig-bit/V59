////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#define MAPP_INSTALL_MAIN_C

/******************************************************************************/
/*                 Header Files                                               */
/* ****************************************************************************/
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "Board.h"
#include "datatype.h"
#include "MsCommon.h"

#include "apiXC.h"
#include "apiXC_Adc.h"
#include "MApp_GlobalSettingSt.h"

#include "MApp_Exit.h"
#include "MApp_Key.h"
#include "MApp_UiMenuDef.h"
#include "MApp_ZUI_Main.h"
#include "ZUI_tables_h.inl"
#include "MApp_Install_Main.h"

#if (VECTOR_FONT_ENABLE)
#include "drvCPU.h"
#include "BinInfo.h"
#include "msAPI_Font.h"
#endif //#if (VECTOR_FONT_ENABLE)

///////////////////////////////////////////////////////////

EN_INSTALL_STATE enInstallGuideState;

//////////////////////////////////////////////////////////
#define DEBUG_STATUS_IG     0

#if DEBUG_STATUS_IG
U8 pre_enInstallGuideState;
#endif

EN_RET MApp_InstallGuide_Main(void)
{
    EN_RET enRetVal =EXIT_NULL;

    #if DEBUG_STATUS_IG
    if(pre_enInstallGuideState!=enInstallGuideState)
    {
        printf("enInstallGuideState=%bx\n",enInstallGuideState);
        pre_enInstallGuideState = enInstallGuideState;
    }
    #endif

    switch(enInstallGuideState)
    {
        case STATE_INSTALL_INIT:
            MApp_ZUI_ACT_StartupOSD(E_OSD_INSTALL_GUIDE);
            enInstallGuideState = STATE_INSTALL_WAIT;
            break;

        case STATE_INSTALL_WAIT:
            MApp_ZUI_ProcessKey(u8KeyCode);
            u8KeyCode = KEY_NULL;
            break;

        //case STATE_INSTALL_EPGTIMER_WAIT:
            //MApp_UiMenu_EPGTimer_ProcessUserInput();
            //break;

        case STATE_INSTALL_CLEAN_UP:
            MApp_ZUI_ACT_ShutdownOSD();
            enInstallGuideState = STATE_INSTALL_INIT;
            enRetVal =EXIT_CLOSE;
            break;

        case STATE_INSTALL_GOTO_STANDBY:
            MApp_ZUI_ACT_ShutdownOSD();
            u8KeyCode = KEY_POWER;
            enRetVal =EXIT_GOTO_STANDBY;
            break;

        case STATE_INSTALL_GOTO_SCAN:
            //MApp_ZUI_ACT_ShutdownOSD();
            //MApp_ZUI_ACT_StartupOSD(E_OSD_AUTO_TUNING);
            enInstallGuideState = STATE_INSTALL_INIT;
            enRetVal =EXIT_GOTO_SCAN;
            break;

        case STATE_INSTALL_GOTO_EPG:
            enInstallGuideState = STATE_INSTALL_INIT;
            enRetVal =EXIT_GOTO_EPG;
            break;

        case STATE_INSTALL_GOTO_CHANNELCHANGE:
            enInstallGuideState = STATE_INSTALL_INIT;
            enRetVal = EXIT_GOTO_CHANNELCHANGE;
            break;

        default:
            enInstallGuideState = STATE_INSTALL_WAIT;
            break;
    }
    return enRetVal;
}

#undef MAPP_INSTALL_MAIN_C

