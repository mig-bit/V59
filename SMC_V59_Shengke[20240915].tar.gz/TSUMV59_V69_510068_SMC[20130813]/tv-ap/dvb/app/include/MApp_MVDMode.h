////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef MAPP_MVDMODE_H
#define MAPP_MVDMODE_H

//#include "drvvdec_datatype.h"

#ifdef MAPP_MVDMODE_C
#define INTERFACE
#else
#define INTERFACE extern
#endif

#include "apiVDEC.h"

//#define SD_VIDEO(x)    ((x==DTVRES_720x480_60I)||(x==DTVRES_720x480_60I)||(x==DTVRES_720x576_50I)||(x==DTVRES_704x576_50I))
//*************************************************************************
//          Global variables
//*************************************************************************
INTERFACE VDEC_DispInfo gstVidStatus,  gstPreVidStatus;

INTERFACE U8 u8MVDTimingStableCount;
INTERFACE U8 u8MVDDecodeCount;
INTERFACE BOOLEAN bMVDDoSetMode;
INTERFACE BOOLEAN bMVDTimingChange;
INTERFACE BOOLEAN bFastTimingCheck;
INTERFACE BOOLEAN bPrepareChange;
INTERFACE BOOLEAN bFirstTimeCheck;
INTERFACE BOOLEAN fTVSetModeDone;
INTERFACE BOOLEAN fCurMVDValidFlag;
INTERFACE U32 u32MvdPicCountTimer;

//INTERFACE BOOLEAN bFullScreen;

INTERFACE BOOLEAN bH264TimingCheck;
INTERFACE BOOLEAN bH264DoSetMode;
INTERFACE BOOLEAN bH264FastReset;
INTERFACE BOOLEAN bH264FirstTimeCheck;

typedef enum
{
    MVD_UNKNOWN_VIDEO,
    MVD_GOOD_VIDEO,
    MVD_BAD_VIDEO
} EN_MVD_VIDEO_STATUS;
INTERFACE EN_MVD_VIDEO_STATUS enMVDVideoStatus;


//*************************************************************************
//          Function prototypes
//*************************************************************************
INTERFACE void MApp_VID_TimingMonitor ( SCALER_WIN eWindow );
INTERFACE BOOLEAN MApp_VID_SetMode ( SCALER_WIN eWindow );
INTERFACE void MApp_VID_VariableInit ( void );


INTERFACE void MApp_MVD_TimingMonitor ( SCALER_WIN eWindow );
INTERFACE BOOLEAN MApp_MVD_SetMode ( SCALER_WIN eWindow );
INTERFACE void MApp_MVD_PrepareTimingChange ( SCALER_WIN eWindow );
INTERFACE void MApp_MVD_VariableReset ( void );
INTERFACE void MApp_MVD_ValidFlagMonitor( void );

INTERFACE void MApp_MVD_VariableInit ( void );
INTERFACE BOOLEAN MApp_MVD_IsAspectRatioWide(void);

INTERFACE void MApp_AVCH264_VariableInit( void );
INTERFACE void MApp_AVCH264_TimingMonitor( void );
INTERFACE BOOLEAN MApp_AVCH264_SetMode( SCALER_WIN eWindow );

#undef INTERFACE
#endif
