////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#define MAPP_SCAN_C

//------------------------------------------------------------------------------
//                    Header Files
//------------------------------------------------------------------------------
#include <string.h>
#include <stdio.h>
#include <math.h>
#include "Board.h"
#include "datatype.h"
#include "MsCommon.h"
#include "apiXC.h"
#include "apiXC_Adc.h"

#include "debug.h"

#include "msAPI_Global.h"

#include "apiGOP.h"

#include "msAPI_Memory.h"
#include "msAPI_MIU.h"
#include "msAPI_Timer.h"
#include "msAPI_OSD.h"
#include "msAPI_Tuner.h"

#include "msAPI_IR.h"
#include "msAPI_Ram.h"
#include "msAPI_audio.h"
#include "msAPI_VD.h"
#include "msAPI_Tuning.h"
#include "msAPI_ChProc.h"
#include "msAPI_DrvInit.h"

#include "MApp_GlobalVar.h"
#include "MApp_Exit.h"
#include "MApp_Key.h"

#if (ENABLE_DTV)
#include "mapp_demux.h"
#include "mapp_si.h"
#include "mapp_si_util.h"
#endif

#include "MApp_DataBase.h"
#include "MApp_Scan.h"
#include "MApp_SignalMonitor.h"
#include "MApp_VDMode.h"
#include "MApp_ChannelChange.h"
#include "MApp_InputSource.h"
#include "MApp_TV.h"
#include "MApp_UiMenuDef.h"
#include "MApp_GlobalFunction.h"

#if (ENABLE_DTV_EPG)
#include "MApp_EpgTimer.h"
#include "mapp_eit.h"
#endif

#include "MApp_SaveData.h"
#include "MApp_PlayCard.h"
#include "ZUI_exefunc.h"
#include "MApp_ZUI_Main.h"
#include "ZUI_tables_h.inl"

#if DVB_C_ENABLE
#include "MApp_CADTV_Proc.h"
#include "msAPI_FreqTableCADTV.h"
#include "MApp_IR.h"
#endif
#if (CHANNEL_SCAN_AUTO_TEST)
#include "drvUartDebug.h"
#include "MApp_Main.h"


extern ScanAutoTestData g_ScanAutoTestData;
extern MS_TP_SETTING stTpSettingPC;
#endif

#include "msAPI_DTVSystem.h"
#include "MApp_ATVProc.h"

#include "msAPI_ATVSystem.h"
#include "msAPI_FreqTableDTV.h"
#if ENABLE_CI
#include "MApp_MultiTasks.h"
#endif

#if ENABLE_TARGET_REGION
BOOLEAN bSetTargetRegion = FALSE;
MW_DVB_TARGET_REGION_INFO* pInfo;
#endif

#if (ENABLE_LCN_CONFLICT)
WORD 	wLcnConflictNumber = 1;
WORD    wLCNConflictChCounter = 0;
BOOLEAN bManualDoWithLcn = 1;
BOOLEAN bAlreadyShowConflictMsg = 0;
WORD 	wStartChannelNum=1;
#endif
extern BOOLEAN MApp_ZUI_ACT_ExecuteAutoTuningAction(U16 act);
#if ENABLE_AUTOTEST
extern BOOLEAN g_bAutobuildDebug;
#endif

#if DVB_C_ENABLE
#define ENABLE_NIT_QUICK_SCAN 0
#else
#define ENABLE_NIT_QUICK_SCAN 0
#endif

#if ENABLE_FAVORITE_NETWORK
U32	u32PrevDVB_Frequency=0;
#endif

#if (ENABLE_HIERARCHY)
#error "Use Hierarchy will need to pay the money, please make sure you want to enable it"
#endif
#if (BLOADER)
U8   u8ScanPercentageNum;            // add for Auto Tune menu
U16  u16ScanDtvChNum;                 // add for Auto Tune menu
BOOLEAN MApp_ZUI_ACT_ExecuteWndAction(U16 val)
{
    UNUSED(val);
    return TRUE;
}
void MApp_ChannelChange_DisableChannel (BOOLEAN u8IfStopDsmcc, SCALER_WIN eWindow /*U8 u8ChanBufIdx*/ ) //for change channel
{
    UNUSED(u8IfStopDsmcc);UNUSED(eWindow);
}
//EN_OSD_COUNTRY_SETTING MApp_GetOSDCountrySetting(void){}
#endif
//------------------------------------------------------------------------------
//                     Macro
//------------------------------------------------------------------------------
#if ENABLE_SCAN_ONELINE_MSG
#define SCAN_ONE_LINE_DBINFO(y)          y
#else
#define SCAN_ONE_LINE_DBINFO(y)
#endif
#define SCAN_DBINFO(y)          //y
#define DVBC_SCAN_DBINFO(y)     //y

#define SCAN_DEBUG_CH       0x01
#define SCAN_DEBUG_PAL      0x02
#define SCAN_DEBUG_DVB      0x04

#define SCAN_DEBUG          0x00
#define SCAN_DBG(flag,s)    if (SCAN_DEBUG & flag) { MS_DEBUG_MSG(s); }

#define DEFAULT_MINOR_NUM    1
#define LOSS_SIGNAL_TIMEOUT     30000


//------------------------------------------------------------------------------
//                     Local
//------------------------------------------------------------------------------
static EN_SCAN_STATE enScanState = STATE_SCAN_INIT;
static EN_SCAN_STATE enPreScanState = STATE_SCAN_INIT;
static BOOLEAN fReturnToPrevious=FALSE;
static BOOLEAN fEndHalt=FALSE;


static EN_DVB_SCAN_STATE enDVBScanState = STATE_DVB_SCAN_INIT;

#if ENABLE_T_C_COMBO
static EN_DVB_TYPE enDVBPreSelectType = EN_DVB_T_TYPE;
#endif

#if ENABLE_DTV
static EN_RET enDVBScanRetVal;
MS_TP_SETTING stTPSetting;
static SCAN_TABLE_CONFIG _stScanConfig;
#endif
U8 u8RFCh;
U8 u8NumOfVchFound;
U16 u16NumOfSrvAdd = 0;

U8 u8MuxTotal=0;
#if (ENABLE_UPDATE_MULTIPLEX_VIA_NIT)
typedef struct NetworkChange
{
    U8 bMuxRemove :1;
    U8 bMuxAdd :1;
    U8 bCellRemove :1;
    U8 bFreqChange :1;
    U8 bLossOfSignal :1;
    U8 reserve :3;
} NetworkChange;
static NetworkChange _stNetworkChangInfo={0,0,0,0,0,0};
static U32 _u32CheckMuxUpdateTimer=0;
static U32 _u32MessageDisplayTimer = 0;
static U32 _u32MessageLossSignalTimer = 0;
static U8   _u8FirstRF=0;
BOOLEAN bLossSignalRetune = TRUE;
EN_LOSS_SIGNAL_STATE enLossSignalState = LOSS_SIGNAL_INIT;
static BYTE _cOriginal_ChRF = INVALID_PHYSICAL_CHANNEL_NUMBER;
static BOOLEAN _bFrequency_change = FALSE;
#endif
#if DVB_C_ENABLE
typedef struct
{
    U32 bNITScanAvailable           :1;
    U32 bCheckNewFreqfromNIT    :1;
    U32 bFrontEndLock                   :1;
    U32 bInitScanState                  :1;
    U32 reserved                            :28;
}_DVBC_SCAN_FLAG;

static _DVBC_SCAN_FLAG _stDVBCScanFlags;
static BOOL _bQuickInstallProcessed = FALSE;
U16 u16PorcessedFreqCnt=0,u16RemainFreqCnt=0;
U32 u32ProcessingCentreFreq;

#endif
#if NTV_FUNCTION_ENABLE
static BOOLEAN bScanGoRegion= FALSE;
#endif
//********************************************************************************
//                     local prototype
//********************************************************************************
#if ENABLE_DTV
static void _MApp_DTV_Scan_TableConfig(SCAN_TABLE_CONFIG *pstScanConfig);
#endif
#if DVB_C_ENABLE
static void _MApp_DTV_Scan_InitSymbolRate(void);
#if(CHIP_FAMILY_TYPE != CHIP_FAMILY_S7LD)
static BOOLEAN _MApp_DTV_Scan_IncreaseModulationMode(void);
#endif
static void _MApp_DTV_Scan_InitDVBCScanFlags(void);
static void _MApp_DTV_Scan_InitModulationMode(void);
static void _MApp_DTV_Scan_AddNITFreqIntoScanTbl(void);
static BOOLEAN _MApp_DTV_Scan_GetTPSettingFromNITParams(MS_TP_SETTING *pstTPSetting);
static BOOLEAN _MApp_DTV_Scan_SetCableTPSetting(_DVBC_SCAN_FLAG *stScanFlag, MS_TP_SETTING *pstTPSetting);
static void _MApp_DTV_Scan_SetNITAvailableFlag(BOOLEAN bNITFlag);
static BOOLEAN _MApp_DTV_Scan_GetNITAvailableFlag(void);
static BOOLEAN _MApp_Scan_DVBC_QuickInstall_ProcessKey(void);
static BOOLEAN _MApp_Scan_DVBC_QuickInstall_Init(void);
static BOOLEAN _MApp_Scan_DVBC_QuickInstall_AddOneDTVPchVchs(void);
static void _MApp_Scan_DVBC_QuickInstall_RemoveMismatchedTS(void);
static void _MApp_Scan_DVBC_QuickInstall_End(void);
#endif
//********************************************************************************
//                     Functions
//********************************************************************************

/********************************************************************************************************************************************************/
extern EN_OSD_TUNE_TYPE_SETTING eTuneType;
#if ENABLE_DVBC_PLUS_DTMB_CHINA_APP
extern BOOLEAN _bNITScan;
#endif
#if ENABLE_DTV
static void MApp_Scan_ProcessUserInput( void )
{
    switch ( u8KeyCode )
    {
        case KEY_POWER:
        case DSC_KEY_PWROFF:
            enScanState = STATE_SCAN_GOTO_STANDBY;
            MApp_ZUI_ProcessKey(u8KeyCode);
            break;

        case KEY_EXIT:
        case KEY_MENU:
#if DVB_C_ENABLE
            if ( stGenSetting.stScanMenuSetting.u8ScanType == SCAN_TYPE_AUTO ||
                 stGenSetting.stScanMenuSetting.u8ScanType == SCAN_TYPE_NETWORK )
#else
            if ( stGenSetting.stScanMenuSetting.u8ScanType == SCAN_TYPE_AUTO )
#endif
            {
                if(enScanState ==STATE_SCAN_PAUSE || enScanState ==STATE_SCAN_INIT)
                {
                #if ENABLE_FAVORITE_NETWORK
                     if (g_bSetFavoriteNetwork)
                     {
                         MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_FAVORITE_NETWORK_EXIT_SCAN_PAUSE);
                     }
                #endif
                    u8KeyCode = NULL;
                }
                else
                {
/*#if DVB_C_ENABLE
                    #if (DVB_T_C_DIFF_DB || ENABLE_T_C_COMBO)
                    if((eTuneType == OSD_TUNE_TYPE_CADTV_ONLY) || (eTuneType == OSD_TUNE_TYPE_DTV_ONLY))
                    #else
                    if (eTuneType == OSD_TUNE_TYPE_CADTV_ONLY)
                    #endif
                    {
                        u8KeyCode = KEY_EXIT;
                    }
#else
                    if(eTuneType == OSD_TUNE_TYPE_DTV_ONLY)
                    {
                        u8KeyCode = KEY_EXIT;
                    }
#endif*/
                    if(eTuneType == OSD_TUNE_TYPE_DTV_ONLY)
                    {
                        u8KeyCode = KEY_EXIT;
                    }
                    fEndHalt = FALSE;
                    fReturnToPrevious=FALSE;
                    enPreScanState = enScanState;
                    enScanState = STATE_SCAN_PAUSE;
                    MApp_ZUI_ProcessKey(u8KeyCode);
                }
            }
            break;

        case KEY_SELECT:
#if DVB_C_ENABLE
            if ( stGenSetting.stScanMenuSetting.u8ScanType == SCAN_TYPE_AUTO ||
                 stGenSetting.stScanMenuSetting.u8ScanType == SCAN_TYPE_NETWORK )
#else
            if ( stGenSetting.stScanMenuSetting.u8ScanType == SCAN_TYPE_AUTO )
#endif
            {
                MApp_ZUI_ProcessKey(u8KeyCode);
            }
            break;

        case KEY_LEFT:
        #if ENABLE_FAVORITE_NETWORK
             if (g_bSetFavoriteNetwork)
             {
                 MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_SET_FAVORITE_NETWORK_LEFT);
                 break;
             }
        #endif
        case KEY_RIGHT:
        #if ENABLE_FAVORITE_NETWORK
             if (g_bSetFavoriteNetwork)
             {
                 MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_SET_FAVORITE_NETWORK_RIGHT);
                 break;
             }
        #endif
#if(ENABLE_LCN_CONFLICT)
		case KEY_UP:
		case KEY_DOWN:
#endif
#if DVB_C_ENABLE
            if ( stGenSetting.stScanMenuSetting.u8ScanType == SCAN_TYPE_AUTO ||
                 stGenSetting.stScanMenuSetting.u8ScanType == SCAN_TYPE_NETWORK )
#else
            if ( stGenSetting.stScanMenuSetting.u8ScanType == SCAN_TYPE_AUTO )
#endif
            {
                MApp_ZUI_ProcessKey(u8KeyCode);
            }
            break;

        default:
            break;
    }
    u8KeyCode = KEY_NULL;
}

/********************************************************************************************************************************************************/
BOOLEAN MApp_DTV_Scan_Init( void )
{

    /* initial variables ==============================================*/
#if (ENABLE_UPDATE_MULTIPLEX_VIA_NIT)
    if(g_enScanType !=SCAN_TYPE_NUM)
#endif
    {
        g_enScanType = (EN_SCAN_TYPE) stGenSetting.stScanMenuSetting.u8ScanType;
    }
    g_enChType = (EN_CH_TYPE) stGenSetting.stScanMenuSetting.u8ChType;
    u8MuxTotal = 0;
    SCAN_DBINFO( printf( "MApp_DTV_Scan_Init: g_enScanType=%x\r\n", g_enScanType ) );
    u8NumOfVchFound = 0;
#if ENABLE_FAVORITE_NETWORK
    g_bSetFavoriteNetwork  = FALSE;
#endif
#if ENABLE_TARGET_REGION
    bSetTargetRegion = FALSE;
#endif
#if ENABLE_LCN_CONFLICT
	bManualDoWithLcn = TRUE;
	bAlreadyShowConflictMsg = FALSE;
	wStartChannelNum = 1;
	wLCNConflictChCounter = 0;
#endif
#if ENABLE_DVBC_PLUS_DTMB_CHINA_APP
    if(IsCATVInUse() && (g_enScanType==SCAN_TYPE_AUTO))
    {
        if(_bNITScan)
        {
            g_enScanType=SCAN_TYPE_NETWORK;
            DVBCNetworkIdScanType = 1;   // auto mode
            DVBCFreqScanType = 0;   //manual mode
            DVBCSymbolRateScanType = 1;
        }
        else
            DVBCSymbolRateScanType = 1;
    }
#endif

    MApp_SI_Scan_Init();
    u16NumOfSrvAdd = 0;

#if DVB_C_ENABLE
#if ENABLE_T_C_COMBO
    if(IsCATVInUse())
#endif
    {
        _MApp_DTV_Scan_InitDVBCScanFlags();
    }
#endif

#if DVB_C_ENABLE
    if( SCAN_TYPE_AUTO == g_enScanType || SCAN_TYPE_NETWORK== g_enScanType)
#else
    if( SCAN_TYPE_AUTO == g_enScanType )
#endif
    {
        //reset DTV channel
        //msAPI_CM_ResetAllProgram();
#if (ENABLE_UPDATE_MULTIPLEX_VIA_NIT)
        MApp_SI_ResetNetwork();
#endif
    if(msAPI_CM_GetCountry() == E_NORWAY)
    {
        //stGenSetting.stScanMenuSetting.u8BandWidth = E_RF_CH_BAND_7MHz;
        #if 1
        msAPI_DFT_SetBandwidth(stGenSetting.stScanMenuSetting.u8BandWidth);
        #else
        msAPI_DFT_SetBandwidth(E_RF_CH_BAND_7MHz);
        msAPI_SetCrossBandwidth(TRUE);
        #endif
    }

#if DVB_C_ENABLE
#if ENABLE_T_C_COMBO
    if(!IsCATVInUse())
        u8RFCh = msAPI_DFT_GetFirstPhysicalChannelNumber();
    else
#endif
    {
        _MApp_DTV_Scan_InitSymbolRate();
        _MApp_DTV_Scan_InitModulationMode();
        msAPI_DCFT_SelectBuiltInFreqTableforCountry(MApp_GetOSDCountrySetting());
        msAPI_DCFT_ResetNITNewFreqTbl();
        u8RFCh = INVALID_IDINDEX;     //dummy
     }
#else
        u8RFCh = msAPI_DFT_GetFirstPhysicalChannelNumber();
#endif

        #if ENABLE_SCAN_CM_DEBUG
        //u8ScanDtvChNum = 0;//msAPI_CM_CountProgram(E_SERVICETYPE_DTV, E_PROGACESS_INCLUDE_VISIBLE_ONLY);;
        //u8ScanRadioChNum = 0;//msAPI_CM_CountProgram(E_SERVICETYPE_RADIO, E_PROGACESS_INCLUDE_VISIBLE_ONLY);;
        #endif
    }
    else
    {
        #if DVB_C_ENABLE
        #if ENABLE_T_C_COMBO
        if(!IsCATVInUse())
        {
            u8RFCh = stGenSetting.stScanMenuSetting.u8RFChannelNumber;
        }
        else
        #endif
        {
            u8RFCh = stGenSetting.stScanMenuSetting.u8RFChannelNumber = INVALID_IDINDEX;   //dummy
            msAPI_CM_GetIDIndexWithFreq(MApp_CadtvManualTuning_GetFrequency(), &u8RFCh);
        }
        #else
        u8RFCh = stGenSetting.stScanMenuSetting.u8RFChannelNumber;
        #endif
    }

    MApp_ChannelChange_DisableChannel(TRUE, MAIN_WINDOW);
    MApp_Dmx_CloseAllFilters();

    u8ScanPercentageNum = 0;
#if DVB_C_ENABLE
    u16PorcessedFreqCnt = 0;
    u16RemainFreqCnt = 0;
    u32ProcessingCentreFreq =0;
#endif

    return TRUE;
}

/********************************************************************************************************************************************************/
void MApp_DTV_Scan_End( BOOLEAN bSkipDupSrvRemove )
{
    WORD wPosition;


#if (ENABLE_UPDATE_MULTIPLEX_VIA_NIT)
    if(msAPI_SI_IsSpecificCountry(MApp_GetSICountry(OSD_COUNTRY_SETTING),SI_SUPPORT_NETWORK_UPDATE_SPECIFIC_COUNTRY))
    {
        MApp_SI_Free_NetworkChangeInfo();
    }
#endif


#if (ENABLE_LCN_CONFLICT)
	if ((SCAN_TYPE_AUTO== g_enScanType) && (OSD_COUNTRY_SETTING == OSD_COUNTRY_ITALY))
	{
		DTV_SIMPLE_SERVICE_INFO *pInfoLncConflict;
        MEMBER_SERVICETYPE bServiceType = msAPI_CM_GetCurrentServiceType();
		BOOL bComplete = 1;
		wLCNConflictChCounter = 0;
		while(((pInfoLncConflict=msAPI_CM_GetDuplicateService(bServiceType,wStartChannelNum))!=NULL)&&bManualDoWithLcn)
		{
			bComplete = 0;
			enPreScanState = enScanState;
		    fEndHalt = FALSE;
		    fReturnToPrevious=FALSE;
		    enScanState = STATE_SCAN_PAUSE;
			if(!bAlreadyShowConflictMsg)
			{
				bAlreadyShowConflictMsg = TRUE;
			    MApp_ZUI_ACT_ExecuteAutoTuningAction(EN_EXE_SET_LCN_CONFLICT);
			}
			wStartChannelNum=pInfoLncConflict->wNumber+1;
			while(pInfoLncConflict)
			{
				printf("bServiceToSelect %d lcn %d position %d name %.*s\n",pInfoLncConflict->bServiceToSelect,pInfoLncConflict->wNumber,pInfoLncConflict->dwPosition,MAX_SERVICE_NAME,pInfoLncConflict->bChannelName);
				if(pInfoLncConflict->bServiceToSelect && wLCNConflictChCounter<MAX_SUPPORT_LCN_CONFLICT_NUM)
				{
					wLcnConflictNumber = pInfoLncConflict->wNumber;
			        memcpy(g_ucLcnConflict[wLCNConflictChCounter].bLcnConflictChannelName, pInfoLncConflict->bChannelName, MAX_SERVICE_NAME);
					g_ucLcnConflict[wLCNConflictChCounter].dwLcnConflictPosition = pInfoLncConflict->dwPosition;
					wLCNConflictChCounter++;
				}
				pInfoLncConflict=pInfoLncConflict->next;
			}
			if(wLcnConflictNumber != wStartChannelNum)
				break;
		}
		if(bManualDoWithLcn && !bComplete)
		{
		    MApp_ZUI_ACT_ExecuteAutoTuningAction(EN_EXE_LCN_REFREASH_LCN_CONFILCT_MENU);
			return;
		}
        msAPI_CM_ResetLCNConflictParams();
	}
#endif

#if ENABLE_AUTOTEST
    if(g_bAutobuildDebug)
    {
        printf("31_DTV_Tuning_End_%d\n", u16ScanDtvChNum);
    }
#endif

#if (!ENABLE_DVB_T2 && !ENABLE_HIERARCHY)
    if (SCAN_TYPE_MANUAL == g_enScanType)
    {
        SI_SHORT_DTV_CHANNEL_INFO *pastVirtualCh = MApp_SI_Get_PastVirtualCh();
        WORD *au16ServiceIDs=NULL;//[MAX_VC_PER_PHYSICAL];
        MEMBER_SERVICETYPE *aeServiceType=NULL;//[MAX_VC_PER_PHYSICAL];
        U8   i,u8RemovedChnNum,u8PLP_ID;
        U8 u8ServiceCount=MApp_SI_GetScanNumOfPatItem();
        au16ServiceIDs=(WORD*)msAPI_Memory_Allocate(sizeof(WORD)*MAX_VC_PER_PHYSICAL,(EN_BUFFER_ID)0);
        aeServiceType=(MEMBER_SERVICETYPE*)msAPI_Memory_Allocate(sizeof(MEMBER_SERVICETYPE)*MAX_VC_PER_PHYSICAL,(EN_BUFFER_ID)0);
        if(au16ServiceIDs && aeServiceType)
        {
            for( i = 0; i < u8ServiceCount; i++)
            {
                au16ServiceIDs[i] = pastVirtualCh[i].wService_ID;
                switch(pastVirtualCh[i].stCHAttribute.bServiceType)
                {
                    case E_TYPE_RADIO:
                        aeServiceType[i] =E_SERVICETYPE_RADIO;
                        break;
                    case E_TYPE_DATA:
                        aeServiceType[i] =E_SERVICETYPE_DATA;
                        break;
                    default:
                    case E_TYPE_DTV:
                        aeServiceType[i] =E_SERVICETYPE_DTV;
                        break;
                }
            //aeServiceType[i] = (MEMBER_SERVICETYPE) pastVirtualCh[i].stCHAttribute.bServiceType;
            }
            msAPI_Tuner_Get_PLP_ID(&u8PLP_ID);
            u8RemovedChnNum = msAPI_CM_RemoveMismatchedProgram(u8RFCh, pastVirtualCh[0].wTransportStream_ID, u8PLP_ID, msAPI_Tuner_Get_HpLp(), au16ServiceIDs, aeServiceType, u8ServiceCount);
        }
        else
        {
            ASSERT(0);
        }
        if(au16ServiceIDs)msAPI_Memory_Free(au16ServiceIDs,(EN_BUFFER_ID)0);
        if(aeServiceType)msAPI_Memory_Free(aeServiceType,(EN_BUFFER_ID)0);
        //printf("SCAN_TYPE_MANUAL>> u8RemovedChnNum = %bu\n", u8RemovedChnNum);
    }
#endif

#if ENABLE_TARGET_REGION

	if (SCAN_TYPE_AUTO== g_enScanType && bSetTargetRegion == FALSE && OSD_COUNTRY_SETTING == OSD_COUNTRY_UK)
    {

        bSetTargetRegion = TRUE;
        pInfo=MApp_SI_GetTargetRegionNameInfo();

        if(pInfo != NULL)
        {
            #if 0
            int i,j,k,l;
            for( i=0;i<pInfo->u8CountryNum;i++)
            {
                printf("country %.*s\n",3,pInfo->pCountryInfo[i].au8CountryCode);
                for( j=0;j<pInfo->pCountryInfo[i].u16PrimaryRegionNum;j++)
                {
                    printf("__primary %x %s\n",pInfo->pCountryInfo[i].pPrimaryRegionInfo[j].u8Code
                    ,pInfo->pCountryInfo[i].pPrimaryRegionInfo[j].name);
                    for( k=0;k<pInfo->pCountryInfo[i].pPrimaryRegionInfo[j].u16SecondaryRegionNum;k++)
                    {
                        printf("____secondary %x %s\n",pInfo->pCountryInfo[i].pPrimaryRegionInfo[j].pSecondaryRegionInfo[k].u8Code
                        ,pInfo->pCountryInfo[i].pPrimaryRegionInfo[j].pSecondaryRegionInfo[k].name);
                        for( l=0;l<pInfo->pCountryInfo[i].pPrimaryRegionInfo[j].pSecondaryRegionInfo[k].u16TertiaryRegionNum;l++)
                        {
                            printf("______teritary %x %s\n",pInfo->pCountryInfo[i].pPrimaryRegionInfo[j].pSecondaryRegionInfo[k].pTertiaryRegionInfo[l].u16Code
                            	,pInfo->pCountryInfo[i].pPrimaryRegionInfo[j].pSecondaryRegionInfo[k].pTertiaryRegionInfo[l].name);
                        }
                    }
                }
            }
            #endif

            enPreScanState = enScanState;
            fEndHalt = FALSE;
            fReturnToPrevious=FALSE;
            enScanState = STATE_SCAN_PAUSE;
            MApp_ZUI_ACT_ExecuteAutoTuningAction(EN_EXE_SET_TARGET_REGION);
            return;
        }
    }
#endif

#if (ENABLE_FAVORITE_NETWORK)

    if (SCAN_TYPE_AUTO== g_enScanType && g_bSetFavoriteNetwork == FALSE && OSD_COUNTRY_SETTING == OSD_COUNTRY_NORWAY)
    {
        if (g_u8NetworkTotal > 1)
        {
           g_bSetFavoriteNetwork = 1;
           g_u8NetworkIndex  = 0;
           enPreScanState    = enScanState;
           fEndHalt          = FALSE;
           fReturnToPrevious = FALSE;
           enScanState       = STATE_SCAN_PAUSE;
           MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_SET_FAVORITE_NETWORK);
           printf("\r\n 123 <MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_SET_FAVORITE_NETWORK)>");
           return;
        }
    }
#endif
    MApp_SI_Scan_End();

    if(TRUE != msAPI_CM_ArrangeDataManager(TRUE,bSkipDupSrvRemove))
    {
        SCAN_DBINFO( printf( "MApp_DTV_Scan_End: msAPI_CM_ArrangeDataManager FAIL !! \n" ));
    }

#if DVB_C_ENABLE
#if ENABLE_T_C_COMBO
    if(IsCATVInUse())
#endif
    {
        _MApp_DTV_Scan_SetNITAvailableFlag(FALSE);
    }
#endif

    #if ENABLE_SCAN_CM_DEBUG
    msAPI_CM_PrintAllProgram();
    #endif
    switch( g_enScanType )
    {
#if DVB_C_ENABLE
        case SCAN_TYPE_NETWORK:
#endif
        case SCAN_TYPE_AUTO:
            msAPI_CM_SetCurrentServiceType(E_SERVICETYPE_DTV);
            msAPI_CM_SetCurrentPosition(E_SERVICETYPE_DTV,0);
            msAPI_CM_SetCurrentPosition(E_SERVICETYPE_RADIO,0);
            #if NORDIG_FUNC //for Nordig Spec v.20
            msAPI_CM_SetCurrentPosition(E_SERVICETYPE_DATA,0);
            #endif
            if(msAPI_CM_GetCountry() == E_NORWAY)
            {
                msAPI_SetCrossBandwidth(FALSE);
                msAPI_DFT_SetBandwidth(stGenSetting.stScanMenuSetting.u8BandWidth);
            }
            break;
#if (ENABLE_UPDATE_MULTIPLEX_VIA_NIT)
        case SCAN_TYPE_UPDATE_MUX:
            MApp_SI_ResetNetworkNewService();
            if( TRUE == msAPI_CM_GetFirstPositionInPCN(E_SERVICETYPE_DTV, _u8FirstRF, &wPosition) )
            {
                msAPI_CM_SetCurrentServiceType(E_SERVICETYPE_DTV);
                msAPI_CM_SetCurrentPosition(E_SERVICETYPE_DTV, wPosition);
            }
            else if( TRUE == msAPI_CM_GetFirstPositionInPCN(E_SERVICETYPE_RADIO, _u8FirstRF, &wPosition) )
            {
                msAPI_CM_SetCurrentServiceType(E_SERVICETYPE_RADIO);
                msAPI_CM_SetCurrentPosition(E_SERVICETYPE_RADIO, wPosition);
            }
            #if (NORDIG_FUNC) //for Nordig Spec v2.0
            else if( TRUE == msAPI_CM_GetFirstPositionInPCN(E_SERVICETYPE_DATA, _u8FirstRF, &wPosition) )
            {
                msAPI_CM_SetCurrentServiceType(E_SERVICETYPE_DATA);
                msAPI_CM_SetCurrentPosition(E_SERVICETYPE_DATA, wPosition);
            }
            #endif
            else
            {
                msAPI_CM_SetCurrentServiceType(E_SERVICETYPE_DTV);
                msAPI_CM_SetCurrentPosition(E_SERVICETYPE_DTV,0);
                msAPI_CM_SetCurrentPosition(E_SERVICETYPE_RADIO,0);
#if (NORDIG_FUNC) //for Nordig Spec v.20
                msAPI_CM_SetCurrentPosition(E_SERVICETYPE_DATA,0);
#endif
            }
            break;
#endif

        case SCAN_TYPE_MANUAL:
            /* After manual scan , search the first position(DTV or Radio) in current PCN */
            if( TRUE == msAPI_CM_GetFirstPositionInPCN(E_SERVICETYPE_DTV, u8RFCh, &wPosition) )
            {
                msAPI_CM_SetCurrentServiceType(E_SERVICETYPE_DTV);
                msAPI_CM_SetCurrentPosition(E_SERVICETYPE_DTV, wPosition);
            }
            else if( TRUE == msAPI_CM_GetFirstPositionInPCN(E_SERVICETYPE_RADIO, u8RFCh, &wPosition) )
            {
                msAPI_CM_SetCurrentServiceType(E_SERVICETYPE_RADIO);
                msAPI_CM_SetCurrentPosition(E_SERVICETYPE_RADIO, wPosition);
            }
            #if NORDIG_FUNC //for Nordig Spec v2.0
            else if( TRUE == msAPI_CM_GetFirstPositionInPCN(E_SERVICETYPE_DATA, u8RFCh, &wPosition) )
            {
                msAPI_CM_SetCurrentServiceType(E_SERVICETYPE_DATA);
                msAPI_CM_SetCurrentPosition(E_SERVICETYPE_DATA, wPosition);
            }
            #endif

            MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_DTV_MANUAL_SCAN_END);
#if DVB_C_ENABLE
            MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_CADTV_MANUAL_SCAN_END);
#endif
        default:
            break;
    }

    //MApp_Dmx_EnableTableMonitor();

    #if (ENABLE_DTV_EPG)
    /* init epg database */
    MApp_EIT_All_Sche_ResetFilter();
#if (!BLOADER)
    MApp_Epg_Init();
#endif
#if ENABLE_T_C_COMBO
    if ( stGenSetting.stScanMenuSetting.u8ScanType == SCAN_TYPE_AUTO ||
         stGenSetting.stScanMenuSetting.u8ScanType == SCAN_TYPE_NETWORK )
#else
    if ( stGenSetting.stScanMenuSetting.u8ScanType == SCAN_TYPE_AUTO )
#endif
    {
        MApp_EpgTimer_InitTimerSettings(TRUE);
    }
#endif  //#if (ENABLE_DTV_EPG)

#if (!BLOADER)
    msAPI_ClearIRFIFO();
#endif
    #if ENABLE_SBTVD_BRAZIL_CM_APP
    if(msAPI_CM_CountProgram(E_SERVICETYPE_DTV, E_PROGACESS_INCLUDE_NOT_VISIBLE_ALSO)||msAPI_CM_CountProgram(E_SERVICETYPE_RADIO, E_PROGACESS_INCLUDE_NOT_VISIBLE_ALSO))
        msAPI_CHPROC_CM_InitOridial();
    #endif
}
/*****************************************************************************/


/********************************************************************************************************************************************************/

/*****************************************************************************/
//static void MApp_Scan_SetLCNAssignmentFlag( U16 u16LCN, U8 eService )
//{
//    if(eService == E_SERVICETYPE_DTV)
//    {
//        stGenSetting.g_SysSetting.au8TVLCNAssignment[u16LCN / 8] |= ( 0x01 << ( u16LCN % 8 ) );
//    }
//    else
//    {
//        stGenSetting.g_SysSetting.au8RadioLCNAssignment[u16LCN / 8] |= ( 0x01 << ( u16LCN % 8 ) );
//    }
//}
/*****************************************************************************/
//static void MApp_Scan_UnsetLCNAssignmentFlag( U16 u16LCN,  U8 eService )
//{
//    if(eService == E_SERVICETYPE_DTV)
//    {
//        stGenSetting.g_SysSetting.au8TVLCNAssignment[u16LCN / 8] &= ~( 0x01 << ( u16LCN % 8 ) );
//    }
//    else
//    {
//        stGenSetting.g_SysSetting.au8RadioLCNAssignment[u16LCN / 8] &= ~( 0x01 << ( u16LCN % 8 ) );
//    }
//}
/*****************************************************************************/
//static BOOLEAN MApp_Scan_LCNAssignmentCheck( U16 u16LCN,  U8 eService )
//{
//    BOOLEAN bReturn = FALSE;
//
//    if(eService == E_SERVICETYPE_DTV)
//    {
//        if( ( stGenSetting.g_SysSetting.au8TVLCNAssignment[u16LCN / 8] & ( 0x01 << ( u16LCN % 8 ) ) ) == ( 0x01 << ( u16LCN % 8 ) ) )
//        {
//            bReturn = true;
//        }
//    }
//    else
//    {
//        if( ( stGenSetting.g_SysSetting.au8RadioLCNAssignment[u16LCN / 8] & ( 0x01 << ( u16LCN % 8 ) ) ) == ( 0x01 << ( u16LCN % 8 ) ) )
//        {
//            bReturn = true;
//        }
//    }
//    return bReturn;
//}
/*****************************************************************************/
//static void MApp_Scan_ReAllocateLCN( _DTVPROGRAMDATA *pstService )
//{
//    #if (SI_SCAN_NEW_STRUCT)
//    U8 eService = E_SERVICETYPE_RADIO;
//
//    if(pstService->u16VideoPID != INVALID_PID)
//    {
//        eService = E_SERVICETYPE_DTV;
//    }
//    while( MApp_Scan_LCNAssignmentCheck( stGenSetting.g_SysSetting.u16OverflowLCN, eService) == true )
//    {
//        stGenSetting.g_SysSetting.u16OverflowLCN += 1;
//    }
//    #else
//    while( MApp_Scan_LCNAssignmentCheck( stGenSetting.g_SysSetting.u16OverflowLCN, pstService->stCHAttribute.bServiceType) == true )
//    {
//        stGenSetting.g_SysSetting.u16OverflowLCN += 1;
//    }
//    #endif
//    pstService->u16LogicalChannelNumber = stGenSetting.g_SysSetting.u16OverflowLCN;
//    stGenSetting.g_SysSetting.u16OverflowLCN += 1;
//
//    if( stGenSetting.g_SysSetting.u16OverflowLCN > MAX_NUM_OF_LCN_VALUE )
//    {
//        stGenSetting.g_SysSetting.u16OverflowLCN = MAIN_OVERFLOW_AREA_START_INDEX;
//    }
//}



/********************************************************************************************************************************************************/
/********************************************************************************************************************************************************/
static U8 MApp_Scan_AddOneDTVPchVchs( U16 u16PhysicalChIdx,SI_SHORT_DTV_CHANNEL_INFO *pastVirtualCh,U8 u8NumOfVch,BOOLEAN bCheckServiceInfo ,BOOLEAN *bDBfull)
{
    U8 u8Loop_1;
    U8 u8NumOfActiveCh = 0;
    U8 u8TotalCh = 0;
//    U16 u16VirChInfoIdx = 0;
    BOOLEAN fIsDummyCh;
    BOOLEAN bBackupUsingBuffer;
    BOOLEAN eResult;
    MEMBER_SERVICETYPE bServiceType;
    WORD wPosition,wLCN;
    SI_DTV_CHANNEL_INFO stDtvPgmData;
    SI_DTVPROGRAMID stDtvIDTable;
    #if DVB_C_ENABLE
    MS_TP_SETTING pstCurTPsetting;
    #endif
    U8 au8NetWorkName[MAX_NETWORK_NAME];
    U8 len;

    BOOLEAN bFull=FALSE;
    fIsDummyCh = FALSE;
    bBackupUsingBuffer = FALSE;
#if (ENABLE_UPDATE_MULTIPLEX_VIA_NIT)
    MEMBER_SERVICETYPE eCurServiceType;
    WORD wCurPosition;
    BYTE cLossSignalRF;

    eCurServiceType = msAPI_CM_GetCurrentServiceType();
    wCurPosition = msAPI_CM_GetCurrentPosition(eCurServiceType);
    cLossSignalRF = msAPI_CM_GetOriginalRFnumber(eCurServiceType, wCurPosition);
    //printf("cLossSignalRF   %bu\n",cLossSignalRF);
#endif

#if DVB_C_ENABLE
    // check NID is match or not when Network ID scan was enabled
    if (_stScanConfig.bNetworkIDFilterEn)
    {
        if (pastVirtualCh[0].wNetwork_ID != _stScanConfig.bNetworkID)
        {
            return 0;
        }
    }
#endif

    //#if DVB_C_ENABLE
    memset(&stDtvIDTable, 0, sizeof(stDtvIDTable));
    //#endif
    //MApp_SI_GetDtvPmgData(&pastVirtualCh[0], 0, &stDtvPgmData);
    stDtvIDTable.wNetwork_ID = pastVirtualCh[0].wNetwork_ID;
    stDtvIDTable.wTransportStream_ID = pastVirtualCh[0].wTransportStream_ID;
    stDtvIDTable.wOriginalNetwork_ID = pastVirtualCh[0].wOriginalNetwork_ID;

    for (u8Loop_1=0;u8Loop_1<u8NumOfVch;u8Loop_1++)
    {
        if (pastVirtualCh[u8Loop_1].wNetwork_ID != INVALID_NID && \
            pastVirtualCh[u8Loop_1].wOriginalNetwork_ID!=INVALID_ON_ID &&\
            pastVirtualCh[u8Loop_1].wService_ID!=INVALID_SERVICE_ID)
        {
            stDtvIDTable.wNetwork_ID = pastVirtualCh[u8Loop_1].wNetwork_ID;
            stDtvIDTable.wTransportStream_ID = pastVirtualCh[u8Loop_1].wTransportStream_ID;
            stDtvIDTable.wOriginalNetwork_ID = pastVirtualCh[u8Loop_1].wOriginalNetwork_ID;
            break;
        }
    }

    //if(pastVirtualCh[0].wTransportStream_ID != INVALID_TS_ID )//&& pastVirtualCh[0].wOriginalNetwork_ID != INVALID_ON_ID)
//    if (u8Loop_1<u8NumOfVch)
    {

        stDtvIDTable.cRFChannelNumber = u16PhysicalChIdx;
#if ENABLE_TARGET_REGION
        stDtvIDTable.u8Region=DEFAULT_REGION;
#endif
#if (ENABLE_UPDATE_MULTIPLEX_VIA_NIT)
        if((OSD_COUNTRY_SETTING == OSD_COUNTRY_NORWAY) && (MApp_DTV_Scan_GetLossSignalState() == LOSS_SIGNAL_RETUNE))
        {
            for(u8Loop_1=0; u8Loop_1<u8NumOfVch; u8Loop_1++)
            {
                if(pastVirtualCh[u8Loop_1].wService_ID == msAPI_CM_GetService_ID(eCurServiceType, wCurPosition)
                    &&(pastVirtualCh[u8Loop_1].wOriginalNetwork_ID == msAPI_CM_GetON_ID(eCurServiceType, wCurPosition))
                    &&(cLossSignalRF == INVALID_PHYSICAL_CHANNEL_NUMBER || cLossSignalRF != _cOriginal_ChRF))
                {
                    stDtvIDTable.cOriginal_RF = _cOriginal_ChRF;
                    stDtvIDTable.dwAlternativeTime = 0;
                    if((MApp_SI_IS_GotTDTOrTOT()==TRUE))
                    {
                        stDtvIDTable.dwAlternativeTime = msAPI_Timer_GetSystemTime();
                    }
                    //printf("%s cOriginal_RF %bu, dwAlternativeTime %u\n",__FUNCTION__,stDtvIDTable.cOriginal_RF,stDtvIDTable.dwAlternativeTime);
                    break;
                }
            }
            if(u8Loop_1 == u8NumOfVch)
            {
                stDtvIDTable.cOriginal_RF = INVALID_PHYSICAL_CHANNEL_NUMBER;
                stDtvIDTable.dwAlternativeTime = INVALID_ALTERNATIVETIME;
            }
        }
        else
        {
            stDtvIDTable.cOriginal_RF = INVALID_PHYSICAL_CHANNEL_NUMBER;
            stDtvIDTable.dwAlternativeTime = INVALID_ALTERNATIVETIME;
        }
#endif
        msAPI_Tuner_Get_CELL_ID(&stDtvIDTable.wCellID);
        #if DVB_C_ENABLE
        memset(&pstCurTPsetting, 0, sizeof(MS_TP_SETTING));
        msAPI_Tuner_GetCurTPSetting(&pstCurTPsetting);
        stDtvIDTable.u32Frequency = pstCurTPsetting.u32Frequency ;
        stDtvIDTable.u32SymbRate = pstCurTPsetting.u32Symbol_rate ;
        stDtvIDTable.QamMode = pstCurTPsetting.u8Modulation ;
        #endif
#if (ENABLE_DVB_T2)
        msAPI_Tuner_Get_PLP_ID(&stDtvIDTable.u8PLP_ID);
#endif
#if (ENABLE_HIERARCHY)
        stDtvIDTable.u8HpLp=msAPI_Tuner_Get_HpLp();
#endif
    }
    if ((TRUE == MApp_SI_Get_NetWorkName(au8NetWorkName,&len,MAX_NETWORK_NAME)) /*&& (0!=au8NetWorkName[0])*/)
    {
        msAPI_CM_SetCurrentNetworkName(au8NetWorkName, len);
    }

    for(u8Loop_1=0; u8Loop_1<u8NumOfVch; u8Loop_1++)
    {
		MApp_SI_GetDtvPmgData(&pastVirtualCh[u8Loop_1], u8Loop_1, &stDtvPgmData);
        #if ENABLE_SBTVD_BRAZIL_APP
        if(stDtvPgmData.stLCN.bPhysicalChannel > MAX_PHYSICAL_CHANNEL_NUMBER)
        {
            stDtvPgmData.stLCN.bPhysicalChannel = u16PhysicalChIdx;
        }
        #endif

        if( bCheckServiceInfo == TRUE )
        {
            if( MApp_SI_Action_CheckServiceInfo( &stDtvPgmData ) == FALSE)
            {
                #if ENABLE_SCAN_CM_DEBUG
                printf( "MApp_Scan_CheckServiceInfo %u fail (Null Service)!\n", u8Loop_1 );
                #else
                SCAN_DBINFO( printf( "MApp_Scan_CheckServiceInfo %u fail (Null Service)!\n", u8Loop_1 ) );
                #endif
                continue;
            }

            if(u8NumOfActiveCh != u8Loop_1)
            {
                memcpy(&pastVirtualCh[u8NumOfActiveCh], &pastVirtualCh[u8Loop_1], sizeof(SI_SHORT_DTV_CHANNEL_INFO));
            }
            pastVirtualCh[u8NumOfActiveCh].stCHAttribute.bServiceType = stDtvPgmData.stCHAttribute.bServiceType;
        }

#if DVB_C_ENABLE
        if( g_enScanType == SCAN_TYPE_AUTO || g_enScanType == SCAN_TYPE_NETWORK)
#else
        if( g_enScanType == SCAN_TYPE_AUTO )
#endif
        {
            eResult = msAPI_SI_AddProgram(&stDtvIDTable, &stDtvPgmData,&bFull, FALSE);
            if(TRUE == eResult)
            {
                if(stDtvPgmData.stCHAttribute.bServiceType == E_TYPE_DTV)
                    u16ScanDtvChNum++;
#if NORDIG_FUNC //for Nordig Spec v2.0
                else if(stDtvPgmData.stCHAttribute.bServiceType == E_TYPE_DATA)
                    u16ScanDataChNum++;
#endif
                else if (stDtvPgmData.stCHAttribute.bServiceType == E_TYPE_RADIO)
                    u16ScanRadioChNum++;
            }
        }
        else
        {
            BOOLEAN bServiceExist;
#if DVB_C_ENABLE
#if ENABLE_T_C_COMBO
            if(IsCATVInUse())
#endif
            {
                msAPI_SI_AddProgramIDTable(&stDtvIDTable,&stDtvPgmData.bIDIdex);
                u8RFCh = u16PhysicalChIdx = stDtvPgmData.bIDIdex;
            }
#endif
            bServiceExist=msAPI_CM_GetServiceTypeAndPositionWithPCN(u16PhysicalChIdx, stDtvPgmData.wService_ID, &bServiceType, &wPosition);
            if((bServiceExist == FALSE)
                || (msAPI_SI_ToSI_Service_Type(bServiceType) != stDtvPgmData.stCHAttribute.bServiceType))
            {
#if (ENABLE_UPDATE_MULTIPLEX_VIA_NIT)
                if(g_enScanType == SCAN_TYPE_UPDATE_MUX && msAPI_SI_IsSpecificCountry(MApp_GetSICountry(OSD_COUNTRY_SETTING),SI_SUPPORT_NETWORK_UPDATE_SPECIFIC_COUNTRY))
                {
                    stDtvPgmData.stPSI_SI_Version.bNITVer=INVALID_VERSION_NUM;
                    if(_bFrequency_change)
                    {
                        stDtvPgmData.stCHAttribute.wSignalStrength = 0x7FFF;
                    }
                    eResult = msAPI_SI_AddProgram(&stDtvIDTable, &stDtvPgmData,&bFull, FALSE);
                }
                else
                {
                    eResult = msAPI_SI_AddProgram(&stDtvIDTable, &stDtvPgmData,&bFull, FALSE);
                }
#else
                eResult = msAPI_SI_AddProgram(&stDtvIDTable, &stDtvPgmData,&bFull, FALSE);
#endif
            }
            else
            {
                //if deleted program, then reset all attribute
                if((stDtvPgmData.wLCN == 0) || (stDtvPgmData.wLCN == SI_INVALID_LOGICAL_CHANNEL_NUMBER))
                {
                    stDtvPgmData.stCHAttribute.bValidLCN=FALSE;
                }
                if(msAPI_CM_GetProgramAttribute(bServiceType, wPosition, E_ATTRIBUTE_IS_DELETED) == TRUE)
                {
                    msAPI_CM_ResetAttribute(bServiceType, wPosition);
                }//if moved program, then keep its LCN
                else if(msAPI_CM_GetProgramAttribute(bServiceType, wPosition, E_ATTRIBUTE_IS_MOVED) == TRUE)
                {
                    wLCN = msAPI_CM_GetLogicalChannelNumber(bServiceType, wPosition);//restore back LCN
                    if(wLCN > 0 && wLCN != INVALID_LOGICAL_CHANNEL_NUMBER)
                    {
                        stDtvPgmData.wLCN = wLCN;
                    }
                }
                else
                {
                    wLCN = msAPI_CM_GetLogicalChannelNumber(bServiceType, wPosition);
                    if( stDtvPgmData.wLCN != wLCN)
                    {
                        WORD position;
                        if(msAPI_SI_GetServiceByLogicalChannelNumber(msAPI_SI_ToSI_Service_Type(bServiceType),stDtvPgmData.wLCN,&position))
                        {
                            if(msAPI_CM_GetProgramVideoType(bServiceType,position) != msAPI_SI_ToCM_Video_Type(stDtvPgmData.stCHAttribute.eVideoType))
                            {
                                stDtvPgmData.wLCN=wLCN;
                            }
                        }
                    }
                }

                {
                    MEMBER_SI_SERVICETYPE bType;
                    bType=msAPI_SI_ToSI_Service_Type(bServiceType);
                    eResult = msAPI_SI_UpdateProgram(bType, wPosition, (BYTE *)&stDtvPgmData, E_SI_DATA_ALL);
                }
            }

            if(TRUE == eResult)
            {
                if(stDtvPgmData.stCHAttribute.bServiceType == E_TYPE_DTV)
                    u16ScanDtvChNum++;
#if NORDIG_FUNC //for Nordig Spec v2.0
                else if(stDtvPgmData.stCHAttribute.bServiceType == E_TYPE_DATA)
                    u16ScanDataChNum++;
#endif
                else if (stDtvPgmData.stCHAttribute.bServiceType == E_TYPE_RADIO)
                    u16ScanRadioChNum++;
            }
        }
        u8NumOfActiveCh++;
        if(TRUE != eResult)
        {
            #if ENABLE_SCAN_CM_DEBUG
            printf("store channel to DB fail. Result %u, type %u\n",eResult,stDtvPgmData.stCHAttribute.bServiceType);
            #else
            SCAN_DBINFO( printf("store channel to DB fail. Result %u, type %u\n",eResult,stDtvPgmData.stCHAttribute.bServiceType) );
            #endif

            if( bFull)// == E_RESULT_OUTOF_EEPROM )
            {
                *bDBfull = TRUE;
                break;
            }
            continue;
        }
        u8TotalCh++;

    }

    #if ENABLE_SCAN_CM_DEBUG
    printf("RF %u add %u chs!\n\n", u16PhysicalChIdx, u8NumOfActiveCh);
    #endif

    return u8TotalCh;
}
#endif
/*****************************************************************************/

void MApp_Scan_State_Init( void )
{
    enScanState = STATE_SCAN_INIT;
    enDVBScanState = STATE_DVB_SCAN_INIT;
#if ENABLE_DTV
    MApp_Dmx_GetScanTableStateInit();
#endif
}

#if ENABLE_DTV
static void _MApp_DTV_Scan_TableConfig(SCAN_TABLE_CONFIG *pstScanConfig)
{
    if (NULL == pstScanConfig)
        return;
    memset(pstScanConfig, 0, sizeof(SCAN_TABLE_CONFIG));
#if (ENABLE_UPDATE_MULTIPLEX_VIA_NIT)
    if(msAPI_SI_IsSpecificCountry(MApp_GetSICountry(OSD_COUNTRY_SETTING),SI_SUPPORT_NETWORK_UPDATE_SPECIFIC_COUNTRY))
    {
        pstScanConfig->bUpdateMuxOnly = (SCAN_TYPE_UPDATE_MUX == g_enScanType)? TRUE: FALSE;
    }
    else
    {
        pstScanConfig->bUpdateMuxOnly = FALSE;
    }
#else
    pstScanConfig->bUpdateMuxOnly = FALSE;
#endif

#if DVB_C_ENABLE
    if (SCAN_TYPE_NETWORK == g_enScanType)
    {
        if (DVBCNetworkIdScanType)
        {
            pstScanConfig->bParseNITOther = FALSE;
            pstScanConfig->bNetworkIDFilterEn = FALSE;
            pstScanConfig->bNetworkID = INVALID_NID ;
            _bQuickInstallProcessed = FALSE;
        }
        else
        {
            pstScanConfig->bParseNITOther = TRUE;
            pstScanConfig->bNetworkIDFilterEn = TRUE;
            pstScanConfig->bNetworkID = MApp_CadtvManualTuning_GetNID();
            // don't execute quick install processing, just check NID match or not in saving program stage
            //_bQuickInstallProcessed = TRUE;
            _bQuickInstallProcessed = FALSE;
        }
    }
    else
    {
        pstScanConfig->bParseNITOther = FALSE;
        pstScanConfig->bNetworkIDFilterEn = FALSE;
        pstScanConfig->bNetworkID = INVALID_NID;
        _bQuickInstallProcessed = FALSE;
    }
#else
        pstScanConfig->bParseNITOther = FALSE;
        pstScanConfig->bNetworkIDFilterEn = FALSE;
        pstScanConfig->bNetworkID = INVALID_NID;
#endif
}
EN_RET MApp_DTV_Scan( void )
{
    BOOLEAN ScanResult;
    BOOLEAN fDBFull, bAddService;
    U16 i;
    static U16 u16GetProgramsCnt=0;
    static U8 u8PhysicalChannelCnt=0;
    WORD wSignalQualityStrength;
#if (DVB_C_ENABLE && ENABLE_NIT_QUICK_SCAN)
    static U16 _u16TSID;
#endif
#if 1//NTV_FUNCTION_ENABLE
    U8 u8NetworkTotal = 0xFF;
#endif
    enDVBScanRetVal =EXIT_NULL;


    #if (CHANNEL_SCAN_AUTO_TEST)
    if( ( g_ScanAutoTestData.u2State == 1 ) && ( g_ScanAutoTestData.fCommand == 0 ) )
    {
        enScanState = STATE_SCAN_END;
    }
    #endif
    MApp_Scan_ProcessUserInput();

    /*
    //OAD scan test
    {
        #include "MApp_OAD.h"
        extern EN_OAD_SCAN_STATE MApp_OAD_Scan( U8* percentage );
        EN_OAD_SCAN_STATE bstate;
        U8 dummy;
        bstate=MApp_OAD_Scan(&dummy);
        if(bstate == STATE_OAD_SCAN_END)
        {
            return EXIT_GOTO_CHANNELCHANGE;
        }
        return EXIT_NULL;
    }
    */

    switch( enScanState )
    {
        case STATE_SCAN_INIT:
            u8PhysicalChannelCnt=0;

#if ENABLE_CI
#if (!TS_SERIAL_OUTPUT_IF_CI_REMOVED)
            msAPI_Tuner_Serial_Control(TRUE);
            msAPI_Tuner_SetByPassMode(TRUE, FALSE);
#else
            msAPI_Tuner_Serial_Control(FALSE);
#endif
            MApp_CI_Enable_Process(FALSE);
#endif

            enDVBScanState = STATE_DVB_SCAN_INIT;
#if (ENABLE_UPDATE_MULTIPLEX_VIA_NIT)
            if(msAPI_SI_IsSpecificCountry(MApp_GetSICountry(OSD_COUNTRY_SETTING),SI_SUPPORT_NETWORK_UPDATE_SPECIFIC_COUNTRY))
            {
                MApp_SI_Free_NetworkChangeInfo();
                MApp_SI_SetCheckFreqChange(FALSE);
            }
#endif
            MApp_Dmx_GetScanTableStateInit();

#if ENABLE_OFFLINE_SIGNAL_DETECTION
            MApp_OffLineInit();
#endif

            SCAN_DBINFO( printf( "\nSTATE_SCAN_INIT>>\n" ) );

            SCAN_ONE_LINE_DBINFO( printf( "\n*********************************************************" ) );
            SCAN_ONE_LINE_DBINFO( printf( "\nSTATE_SCAN_INIT" ) );
            SCAN_ONE_LINE_DBINFO( printf( "\n*********************************************************\n" ) );
#if ENABLE_FAVORITE_NETWORK
            u32PrevDVB_Frequency = 0; // Frider 2011/3/24
#endif
            if( MApp_DTV_Scan_Init() == TRUE )
            {
                _MApp_DTV_Scan_TableConfig(&_stScanConfig);
#if DVB_C_ENABLE
                if( g_enScanType == SCAN_TYPE_AUTO || g_enScanType == SCAN_TYPE_NETWORK)
#else
                if( g_enScanType == SCAN_TYPE_AUTO )
#endif
                {
                    MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_REPAINT_AUTOTUNING_PROGRESS);//ZUI: MApp_UiMenu_ExecuteKeyEvent( MIA_ATV_PERCENT ); //draw progress bar
                }
                enScanState = STATE_SCAN_SEARCH_RF_CHANNEL;
#if DVB_C_ENABLE
#if ENABLE_T_C_COMBO
                if(!IsCATVInUse())
                {
                    SCAN_DBINFO(printf("***u8RFCh = %u\n", u8RFCh));
                    msAPI_DFT_GetTSSetting( u8RFCh, &stTPSetting );
                }
                else
#endif
                {
                    if (FALSE == _MApp_DTV_Scan_SetCableTPSetting(&_stDVBCScanFlags, &stTPSetting))
                        enScanState = STATE_SCAN_END;
                    else
                    {
                        SCAN_DBINFO(printf("@@@Freq: %lu\n",stTPSetting.u32Frequency));
                        SCAN_DBINFO(printf("@@@Symbol rate: %lu\n",stTPSetting.u32Symbol_rate));
                        SCAN_DBINFO(printf("@@@Modulation: %u\n",stTPSetting.u8Modulation));
                        SCAN_DBINFO(printf("@@@Bandwidth: %u\n",stTPSetting.enBandWidth));
                    }
                }
#else
                SCAN_DBINFO(printf("***u8RFCh = %u\n", u8RFCh));
                msAPI_DFT_GetTSSetting( u8RFCh, &stTPSetting );
#endif
            }
            else
            {
                enScanState = STATE_SCAN_END;
            }
            break;

        case STATE_SCAN_NEXT_CHANNEL:
            u8KeyCode = KEY_NULL;
            SCAN_DBINFO( printf( "STATE_SCAN_NEXT_CHANNEL>>\n" ) );
#if ENABLE_T_C_COMBO
            if(IsCATVInUse())
            {
                if( g_enScanType == SCAN_TYPE_AUTO || g_enScanType == SCAN_TYPE_NETWORK)
                {
                    if (FALSE == _MApp_DTV_Scan_SetCableTPSetting(&_stDVBCScanFlags, &stTPSetting))
                    {
                        enScanState = STATE_SCAN_END;
                    }
                    else
                    {
                        SCAN_DBINFO(printf("@@@@Freq: %lu\n",stTPSetting.u32Frequency));
                        SCAN_DBINFO(printf("@@@@Symbol rate: %lu\n",stTPSetting.u32Symbol_rate));
                        SCAN_DBINFO(printf("@@@@Modulation: %u\n",stTPSetting.u8Modulation));
                        SCAN_DBINFO(printf("@@@@Bandwidth: %u\n",stTPSetting.enBandWidth));
                        enScanState = STATE_SCAN_SEARCH_RF_CHANNEL;
                        //1TODO: update progress bar
                        u8RFCh = msAPI_DFT_GetNextPhysicalChannelNumber(u8RFCh);
                        u8ScanPercentageNum = msAPI_DCFT_CalculatePercentTbl();
                        MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_REPAINT_AUTOTUNING_PROGRESS);
                    }
                }
                else
                {
                    enScanState = STATE_SCAN_END;
                }
            }
            else
            {
                u8RFCh = msAPI_DFT_GetNextPhysicalChannelNumber(u8RFCh);
                if( u8RFCh == INVALID_PHYSICAL_CHANNEL_NUMBER/*u8MaxRFCh*/ )
                {
#if ENABLE_FAVORITE_NETWORK
To_Invalid_Physical:
#endif
                    enScanState = STATE_SCAN_END;
                    break;
                }

                enScanState = STATE_SCAN_SEARCH_RF_CHANNEL;
                msAPI_DFT_GetTSSetting( u8RFCh, &stTPSetting );
                // this case for avoid the overlap channels especial in Norway DVB-T 7MHz alt 8MHz. Frider 2011/3/24
#if ENABLE_FAVORITE_NETWORK
                while((stTPSetting.u32Frequency - u32PrevDVB_Frequency) < 7000L)
                {
                    u8RFCh = msAPI_DFT_GetNextPhysicalChannelNumber(u8RFCh);

                    if( u8RFCh == INVALID_PHYSICAL_CHANNEL_NUMBER/*u8MaxRFCh*/ )
                    {
                        goto To_Invalid_Physical;
                    }

                    msAPI_DFT_GetTSSetting( u8RFCh, &stTPSetting );
                }
#endif
                if( g_enScanType == SCAN_TYPE_AUTO )
                {
                    u8ScanPercentageNum = msAPI_DFT_GetPercentWithPhysicalChannelNumber(u8RFCh);
                    MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_REPAINT_AUTOTUNING_PROGRESS);
                }
            }
#elif DVB_C_ENABLE

            if( g_enScanType == SCAN_TYPE_AUTO || g_enScanType == SCAN_TYPE_NETWORK)
            {
                if (FALSE == _MApp_DTV_Scan_SetCableTPSetting(&_stDVBCScanFlags, &stTPSetting))
                {
                    enScanState = STATE_SCAN_END;
                }
                else
                {
                    SCAN_DBINFO(printf("@@@@Freq: %lu\n",stTPSetting.u32Frequency));
                    SCAN_DBINFO(printf("@@@@Symbol rate: %lu\n",stTPSetting.u32Symbol_rate));
                    SCAN_DBINFO(printf("@@@@Modulation: %u\n",stTPSetting.u8Modulation));
                    SCAN_DBINFO(printf("@@@@Bandwidth: %u\n",stTPSetting.enBandWidth));
                    enScanState = STATE_SCAN_SEARCH_RF_CHANNEL;
                    //1TODO: update progress bar
                    u8RFCh = msAPI_DFT_GetNextPhysicalChannelNumber(u8RFCh);
                    u8ScanPercentageNum = msAPI_DCFT_CalculatePercentTbl();
                    MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_REPAINT_AUTOTUNING_PROGRESS);
                }
            }
            else
            {
                enScanState = STATE_SCAN_END;
            }
#else
            u8RFCh = msAPI_DFT_GetNextPhysicalChannelNumber(u8RFCh);
            if( u8RFCh == INVALID_PHYSICAL_CHANNEL_NUMBER/*u8MaxRFCh*/ )
            {
                enScanState = STATE_SCAN_END;
                break;
            }

            enScanState = STATE_SCAN_SEARCH_RF_CHANNEL;
            msAPI_DFT_GetTSSetting( u8RFCh, &stTPSetting );
            if( g_enScanType == SCAN_TYPE_AUTO )
            {
                u8ScanPercentageNum = msAPI_DFT_GetPercentWithPhysicalChannelNumber(u8RFCh);
                MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_REPAINT_AUTOTUNING_PROGRESS);
            }
#endif
            break;
        case STATE_SCAN_SEARCH_RF_CHANNEL:
            u8KeyCode = KEY_NULL;
#if 0//for test
			if(u8RFCh!=26&&u8RFCh!=32&&u8RFCh!=38&&u8RFCh!=66)
			{
				if(u8RFCh>62)
				{
					enScanState = STATE_SCAN_END;
					break;
				}
				enScanState = STATE_SCAN_NEXT_CHANNEL;
				break;
			}

#endif
            SCAN_DBINFO( printf( "STATE_SCAN_SEARCH_RF_CHANNEL>>\n" ) );
            SCAN_ONE_LINE_DBINFO( printf( "+"));
            //wNetworkID = INVALID_ON_ID;
        #if DVB_C_ENABLE
        #if ENABLE_T_C_COMBO
            if(!IsCATVInUse())
            {
                DVBC_SCAN_DBINFO( printf( "u8RFCh is %d\n",u8RFCh ) );
                DVBC_SCAN_DBINFO( printf( "stTPSetting.u32Frequency is %d\n",stTPSetting.u32Frequency ) );
                DVBC_SCAN_DBINFO( printf( "stTPSetting.enBandWidth is %d\n",stTPSetting.enBandWidth ) );
            }
            else
        #endif
            {
                DVBC_SCAN_DBINFO( printf( "stTPSetting -- F=%d SR= %d  Q= %d  \n",stTPSetting.u32Frequency,stTPSetting.u32Symbol_rate,stTPSetting.u8Modulation ) );
            }
        #else
            DVBC_SCAN_DBINFO( printf( "u8RFCh is %d\n",u8RFCh ) );
            DVBC_SCAN_DBINFO( printf( "stTPSetting.u32Frequency is %d\n",stTPSetting.u32Frequency ) );
            DVBC_SCAN_DBINFO( printf( "stTPSetting.enBandWidth is %d\n",stTPSetting.enBandWidth ) );
        #endif
            if( MApp_DVB_Scan( &stTPSetting, &ScanResult ) == FALSE )
            {
                break;
            }

            if( ScanResult == FE_LOCK )
            {
                enScanState = STATE_SCAN_GET_PROGRAMS;

            #if (CHANNEL_SCAN_AUTO_TEST)
                if( g_ScanAutoTestData.u2State == 1 && u8NumOfVchFound > 0 )
                    g_ScanAutoTestData.u12ChFoundNum++;
            #endif
#if DVB_C_ENABLE
                msAPI_Tuner_UpdateTPSetting();
                if (g_enScanType == SCAN_TYPE_AUTO || g_enScanType == SCAN_TYPE_NETWORK)
                   _stDVBCScanFlags.bFrontEndLock = 1;
#endif
            }
            else
            {
#if DVB_C_ENABLE
                if (g_enScanType == SCAN_TYPE_AUTO || g_enScanType == SCAN_TYPE_NETWORK)
#else
                if( g_enScanType == SCAN_TYPE_AUTO )
#endif
                {
                    enScanState = STATE_SCAN_NEXT_CHANNEL;
                }
                else
                {
                    enScanState = STATE_SCAN_END;
                }
            }

            #if ENABLE_SCAN_CM_DEBUG
            printf( "g_enScanType = %u u8RFCh = %u ScanResult = %u\n", ( U8 ) g_enScanType, u8RFCh, ( U8 ) ScanResult );
            #endif

          #if 0
            SCAN_DBG( SCAN_DEBUG_CH, printf( "g_enScanType = %bu u8RFCh = %bu ScanResult = %bu\n", ( U8 ) g_enScanType, u8RFCh, ( U8 ) ScanResult ) );
          #else // Modifiedby coverity_0457
            SCAN_DBG( SCAN_DEBUG_CH, printf( "g_enScanType = %u u8RFCh = %u ScanResult = %u\n", ( U8 ) g_enScanType, u8RFCh, ( U8 ) ScanResult ) );
          #endif

            break;

        case STATE_SCAN_GET_PROGRAMS:   //Truman for digital only, analog scan shouldn't go into this state
            u8KeyCode = KEY_NULL;
            SCAN_DBINFO( printf( "STATE_SCAN_GET_PROGRAMS>>\n" ) );

            u8NumOfVchFound = 0;
#if 0//network test code
			{
				extern BOOLEAN MApp_Dmx_GetAllNetwork(U32 u32TimeOut);
				if(MApp_Dmx_GetAllNetwork(30000)==FALSE)
				{
					break;
				}
				printf("finish\n");
			}
			{
				MS_NETWORK_NAME_INFO info;
				MS_CABLE_PARAMETER info2;
				U16 dumy;
				while(MApp_SI_GetNextNetoworkInfo(&info))
				{
					printf("network ID %x name %s\n",info.u16NetworkID,info.au8NetworkName);
				}
				_stScanConfig.bNetworkIDFilterEn=TRUE;
				_stScanConfig.bParseNITOther=TRUE;
				_stScanConfig.bNetworkID=0xa03f;
				MApp_SI_SetNetworkID(_stScanConfig.bNetworkID);

				while(MApp_SI_GetNextCableParameter(&info2,&dumy ))
				{
					printf("frequency %d\n",info2.u32CentreFreq);
				}
			}
#endif
            if( MApp_Dmx_GetScanTables(&_stScanConfig, &u8NumOfVchFound ) == FALSE )
            {
                u16GetProgramsCnt++;
                SCAN_DBINFO( printf( "MApp_Dmx_GetScanTables\n" ) );
                break;
            }

            SCAN_ONE_LINE_DBINFO( printf(" u8NumOfVchFound = %u waitcnt=%u ", u8NumOfVchFound, u16GetProgramsCnt);)


            msAPI_Tuner_CheckSignalStrength(&wSignalQualityStrength);
            wSignalQualityStrength = (wSignalQualityStrength&0xFF)<<8;
            wSignalQualityStrength |= (msAPI_Tuner_GetSignalQualityPercentage()&0xFF);
            SCAN_ONE_LINE_DBINFO( printf( " sq= 0x%x \n", wSignalQualityStrength ) );


            u16GetProgramsCnt=0;  // reset for next round
            #if (ENABLE_SCAN_CM_DEBUG | ENABLE_SCAN_ONELINE_MSG)
            {
                U8 j;
                SI_SHORT_DTV_CHANNEL_INFO *pastVirtualCh=(SI_SHORT_DTV_CHANNEL_INFO *)MApp_SI_Get_PastVirtualCh();

                SCAN_DBINFO(printf("MApp_DTV_Scan>> u8NumOfPatItem = %u\n", u8NumOfVchFound));
                for(j=0; j<u8NumOfVchFound; j++)
                {
                    printf("[%02u] Lcn %05u Sid %05u Vpid %05u Apid %05u Vis %u Sel %u data %u stype %u\n",\
                        j,pastVirtualCh[j].wLCN,pastVirtualCh[j].wService_ID,\
                        pastVirtualCh[j].wVideo_PID,pastVirtualCh[j].stAudInfo[0].wAudPID,\
                        (U8)pastVirtualCh[j].stCHAttribute.bVisibleServiceFlag,(U8)pastVirtualCh[j].stCHAttribute.bNumericSelectionFlag,\
                        (U8)pastVirtualCh[j].stCHAttribute.bIsDataServiceAvailable,
                        (U8)pastVirtualCh[j].stCHAttribute.bServiceType);
                }

            }
            #endif

            MApp_Dmx_GetScanTableStateInit();
            if( u8NumOfVchFound > 0 )
            {
#if DVB_C_ENABLE
#if ENABLE_T_C_COMBO
                if(IsCATVInUse())
#endif
                {
#if ENABLE_NIT_QUICK_SCAN
                    if(_stScanConfig.bEnableNITQuickScan)
                    {
                        enScanState=STATE_SCAN_NIT_QUICK_SCAN_GET_NIT;
                        break;
                    }
#endif
                    _MApp_DTV_Scan_SetNITAvailableFlag(TRUE);
                    if ((g_enScanType == SCAN_TYPE_AUTO) && (!_stDVBCScanFlags.bCheckNewFreqfromNIT))
                    {
                        _MApp_DTV_Scan_AddNITFreqIntoScanTbl();
                        _stDVBCScanFlags.bCheckNewFreqfromNIT = 1;
                    }
                }
#endif
                enScanState = STATE_SCAN_SAVE_PROGRAMS;
            }
            else
            {
#if DVB_C_ENABLE
                if (g_enScanType == SCAN_TYPE_AUTO || g_enScanType == SCAN_TYPE_NETWORK)

#else
                if( g_enScanType == SCAN_TYPE_AUTO )
#endif
                {

                    SCAN_DBG( SCAN_DEBUG_CH, printf( "Can't get channel infomation\n" ) );
                    enScanState = STATE_SCAN_NEXT_CHANNEL;
                }
                else
                {
                    enScanState = STATE_SCAN_END;
                }
#if (ENABLE_HIERARCHY)
                if(msAPI_Tuner_Is_HierarchyOn()&&(msAPI_Tuner_Get_HpLp()==0))
                {
                    stTPSetting.u8HpLp=1;
                    enScanState=STATE_SCAN_SEARCH_RF_CHANNEL;
                    break;

                }
#endif
#if (ENABLE_DVB_T2)
                {
                    U8 u8PLP_ID;
                    if(MApp_SI_GetNextT2Parameter(&u8PLP_ID))
                    {
                        stTPSetting.u8PLPID=u8PLP_ID;
                        enScanState=STATE_SCAN_SEARCH_RF_CHANNEL;
                    }
                }
#endif
            }
            break;
#if (DVB_C_ENABLE && ENABLE_NIT_QUICK_SCAN)
        case STATE_SCAN_NIT_QUICK_SCAN_GET_NIT:

            {
                MS_CABLE_PARAMETER desc;
                if(MApp_SI_GetNextCableParameter(&desc, NULL,NULL,NULL,NULL, FALSE))
                {
                    _u16TSID=desc.u16TSID;
                    enScanState = STATE_SCAN_NIT_QUICK_SCAN_WAIT_SDT;
                    break;
                }
            }
            enScanState = STATE_SCAN_END;
            break;

        case STATE_SCAN_NIT_QUICK_SCAN_WAIT_SDT:
            {
                MS_CABLE_PARAMETER desc;
                U16 u16RemainFreq;
                U16 u16ServiceNumber=0;
                MS_SERVICE_LIST_INFO* pServiceListInfo=NULL;
                MS_SERVICE_LCN_INFO* pLcnInfo=NULL;
                BOOL bGetSDT;
                if(MApp_Dmx_GetSDTScanTables(_u16TSID,&bGetSDT, 6000) == FALSE)
                {
                    break;
                }
                if(MApp_SI_GetNextCableParameter(&desc, &pServiceListInfo,&pLcnInfo,&u16ServiceNumber,&u16RemainFreq, TRUE))
                {
                    SI_DTVPROGRAMID stDtvIDTable;
                    SI_DTV_CHANNEL_INFO stDtvPgmData;
                    BOOLEAN bFull=FALSE;
                    memset(&stDtvIDTable, 0, sizeof(stDtvIDTable));
                    stDtvIDTable.wNetwork_ID = desc.u16NetworkID;
                    stDtvIDTable.wTransportStream_ID = desc.u16TSID;
                    stDtvIDTable.wOriginalNetwork_ID = desc.u16ONID;
                    stDtvIDTable.u32Frequency = desc.u32CentreFreq/10;
                    stDtvIDTable.u32SymbRate = desc.u32Symbol_rate/10 ;
                    stDtvIDTable.QamMode = desc.u8Modulation-1;
                    for(i=0;i<u16ServiceNumber;i++)
                    {
                        if(pServiceListInfo[i].u16ProgramNumber)
                        {
                            msAPI_SI_FillProgramDataWithDefault(&stDtvPgmData);
                            stDtvPgmData.wService_ID=pServiceListInfo[i].u16ProgramNumber;
                            stDtvPgmData.wTS_LCN=stDtvPgmData.wLCN=pLcnInfo[i].u16LCNNumber;
                            stDtvPgmData.wSimu_LCN=pLcnInfo[i].u16SimuLCNNumber;
                            stDtvPgmData.stCHAttribute.bVisibleServiceFlag=pLcnInfo[i].u8fVisable;
                            stDtvPgmData.stCHAttribute.bNumericSelectionFlag=pLcnInfo[i].u8fSelectable;
                            stDtvPgmData.stCHAttribute.bIsSpecialService=pLcnInfo[i].u8IsSpecialService;
                            stDtvPgmData.stCHAttribute.bServiceTypePrio=msAPI_SI_ToCM_Service_Priority(pServiceListInfo[i].u8ServicePriority);
                            if(pServiceListInfo[i].u8ServiceType == E_TYPE_DTV
                                || pServiceListInfo[i].u8ServiceType == E_TYPE_RADIO
                                || pServiceListInfo[i].u8ServiceType == E_TYPE_DATA)
                            {
                                stDtvPgmData.stCHAttribute.bServiceType=pServiceListInfo[i].u8ServiceType;
                            }
                            else
                            {
                                stDtvPgmData.stCHAttribute.bServiceType=E_TYPE_DTV;
                                stDtvPgmData.stCHAttribute.bVisibleServiceFlag=FALSE;
                                stDtvPgmData.stCHAttribute.bNumericSelectionFlag=FALSE;
                                stDtvPgmData.stCHAttribute.bInvalidService=TRUE;
                                stDtvPgmData.stCHAttribute.bIsServiceIdOnly=TRUE;

                            }
                            if(!(bGetSDT && MApp_SI_GetSeviceNameByIndex(stDtvPgmData.bChannelName,SI_MAX_SERVICE_NAME,i)))
                            {
                                if(pServiceListInfo[i].u8ServiceType == E_TYPE_DATA)snprintf((char*)stDtvPgmData.bChannelName,SI_MAX_SERVICE_NAME,"DATA\0");
                                else if(pServiceListInfo[i].u8ServiceType == E_TYPE_RADIO)snprintf((char*)stDtvPgmData.bChannelName,SI_MAX_SERVICE_NAME,"RADIO\0");
                                else snprintf((char*)stDtvPgmData.bChannelName,SI_MAX_SERVICE_NAME,"TV\0");
                            }
                            msAPI_SI_Action_CheckServiceInfo_DVB(&stDtvPgmData);
                            //printf("add service id %x name %s\n",stDtvPgmData.wService_ID, stDtvPgmData.bChannelName);
                            if(msAPI_SI_AddProgram(&stDtvIDTable, &stDtvPgmData,&bFull, TRUE))
                            {
                                if(!stDtvPgmData.stCHAttribute.bInvalidService)
                                {
                                    if(pServiceListInfo[i].u8ServiceType == E_TYPE_DTV)u16ScanDtvChNum++;
                                    else if(pServiceListInfo[i].u8ServiceType == E_TYPE_RADIO)u16ScanRadioChNum++;
                                    else u16ScanDataChNum++;
                                }

                            }
                            else if(bFull)
                            {
                                break;
                            }

                        }
                    }
                    if(bFull)break;

    /*
                    printf("cable =>freq %d sym %d mod %d ONID %x  NID %x TSID %x\n",desc.u32CentreFreq,desc.u32Symbol_rate,desc.u8Modulation,
                    desc.u16ONID,desc.u16NetworkID,desc.u16TSID);
                    for(i=0;i<u16ServiceNumber;i++)
                    if(pServiceListInfo[i].u16ProgramNumber)
                    printf("service => ID %x type %d lcn %d simu %d visible %d selectable %d special %d\n",
                    pServiceListInfo[i].u16ProgramNumber,
                    pServiceListInfo[i].u8ServiceType,
                    pLcnInfo[i].u16LCNNumber,
                    pLcnInfo[i].u16SimuLCNNumber,
                    pLcnInfo[i].u8fVisable,
                    pLcnInfo[i].u8fSelectable,
                    pLcnInfo[i].u8IsSpecialService
                    );
    */

                    pServiceListInfo=NULL;
                    pLcnInfo=NULL;
                    u16ServiceNumber=0;
                }
                enScanState = STATE_SCAN_NIT_QUICK_SCAN_GET_NIT;

            }
            break;
#endif
        case STATE_SCAN_SAVE_PROGRAMS:
#if ENABLE_FAVORITE_NETWORK
            u32PrevDVB_Frequency = stTPSetting.u32Frequency; // Frider 2011/3/24
#endif
            u8KeyCode = KEY_NULL;
            u8PhysicalChannelCnt++;

            SCAN_DBINFO(printf("u8NumOfVchFound = %d\n", u8NumOfVchFound));
//            SCAN_ONE_LINE_DBINFO(printf("\nu8NumOfVchFound = %d ", u8NumOfVchFound));


            bAddService = TRUE;
            msAPI_Tuner_CheckSignalStrength(&wSignalQualityStrength);
            wSignalQualityStrength = (wSignalQualityStrength&0x7F)<<8;
            //wSignalQualityStrength |= (msAPI_Tuner_GetSingalSNRPercentage()&0xFF);
            wSignalQualityStrength |= (msAPI_Tuner_GetSignalQualityPercentage()&0xFF);
//            SCAN_ONE_LINE_DBINFO( printf( " <# %x #> ", wSignalQualityStrength ) );

            fDBFull = FALSE;
            SCAN_DBINFO( printf( "STATE_SCAN_SAVE_PROGRAMS>>\n" ) );
            if(bAddService)
            {
                SI_SHORT_DTV_CHANNEL_INFO *pastVirtualCh=MApp_SI_Get_PastVirtualCh();
                if ( IS_BESTMUX_COUNTRY(OSD_COUNTRY_SETTING) && g_enScanType == SCAN_TYPE_MANUAL)//don't care quality, must replace the same service
                {
                    wSignalQualityStrength = 0x7FFF;
                }

                for(i = 0;i < u8NumOfVchFound ;i++)
                {
                    pastVirtualCh[i].stCHAttribute.wSignalStrength = wSignalQualityStrength;
                }

                u16NumOfSrvAdd += MApp_Scan_AddOneDTVPchVchs(u8RFCh, pastVirtualCh, u8NumOfVchFound, TRUE, &fDBFull);
				//it will cause remove normal service: ex: 1~5 invalid,6~0 valid service
				//if (SCAN_TYPE_MANUAL == g_enScanType)
                  //  u8NumOfVchFound = (U8)u16NumOfSrvAdd;

                #if ENABLE_SCAN_CM_DEBUG

                #if NORDIG_FUNC //for Nordig Spec v2.0
                SCAN_DBINFO(printf("Total u16NumOfSrvAdd %u >> u16ScanDtvChNum %u u16ScanRadioChNum %u u16ScanDataChNum %u\n", u16NumOfSrvAdd, u16ScanDtvChNum, u16ScanRadioChNum, u16ScanDataChNum));
                SCAN_ONE_LINE_DBINFO(printf("Total u16NumOfSrvAdd %u >> u16ScanDtvChNum %u u16ScanRadioChNum %u u16ScanDataChNum %u\n", u16NumOfSrvAdd, u16ScanDtvChNum, u16ScanRadioChNum, u16ScanDataChNum));

                #else
                printf("Total u16NumOfSrvAdd %u >> u16ScanDtvChNum %u u16ScanRadioChNum %u\n", u16NumOfSrvAdd, u16ScanDtvChNum, u16ScanRadioChNum);
                #endif
                #endif

            }

            #if PLAYCARD_DISABLE // if you want use play card turn off this
#if DVB_C_ENABLE
            if ((g_enScanType == SCAN_TYPE_AUTO || g_enScanType == SCAN_TYPE_NETWORK) && !fDBFull)

#else
            if( g_enScanType == SCAN_TYPE_AUTO && !fDBFull)
#endif
            {
                enScanState = STATE_SCAN_NEXT_CHANNEL;
            }
            else
            {
//                u8ScanDtvChNum = msAPI_CM_CountProgram(E_SERVICETYPE_DTV, E_PROGACESS_INCLUDE_VISIBLE_ONLY);;
//                u8ScanRadioChNum = msAPI_CM_CountProgram(E_SERVICETYPE_RADIO, E_PROGACESS_INCLUDE_VISIBLE_ONLY);;
                enScanState = STATE_SCAN_END;
            }
            #else
            {
                u16ScanDtvChNum = msAPI_CM_CountProgram(E_SERVICETYPE_DTV, E_PROGACESS_INCLUDE_VISIBLE_ONLY);
                u16ScanRadioChNum = msAPI_CM_CountProgram(E_SERVICETYPE_RADIO, E_PROGACESS_INCLUDE_VISIBLE_ONLY);
#if NORDIG_FUNC //for Nordig Spec v2.0
                u16ScanDataChNum = msAPI_CM_CountProgram(E_SERVICETYPE_DATA, E_PROGACESS_INCLUDE_VISIBLE_ONLY);
#endif
                enScanState = STATE_SCAN_END;
            }
            #endif

#if (ENABLE_DVB_T2||ENABLE_HIERARCHY)
            if (SCAN_TYPE_MANUAL == g_enScanType)
            {
                SI_SHORT_DTV_CHANNEL_INFO *pastVirtualCh = MApp_SI_Get_PastVirtualCh();
                WORD *au16ServiceIDs=NULL;//[MAX_VC_PER_PHYSICAL];
                MEMBER_SERVICETYPE *aeServiceType=NULL;//[MAX_VC_PER_PHYSICAL];
                U8   j,u8RemovedChnNum,u8PLP_ID;
                U8 u8ServiceCount=MApp_SI_GetScanNumOfPatItem();
                au16ServiceIDs=(WORD*)msAPI_Memory_Allocate(sizeof(WORD)*MAX_VC_PER_PHYSICAL,(EN_BUFFER_ID)0);
                aeServiceType=(MEMBER_SERVICETYPE*)msAPI_Memory_Allocate(sizeof(MEMBER_SERVICETYPE)*MAX_VC_PER_PHYSICAL,(EN_BUFFER_ID)0);
                if(au16ServiceIDs && aeServiceType)
                {
                    for( j = 0; j< u8ServiceCount; j++)
                    {
                        au16ServiceIDs[j] = pastVirtualCh[j].wService_ID;
                        switch(pastVirtualCh[j].stCHAttribute.bServiceType)
                        {
                            case E_TYPE_RADIO:
                                aeServiceType[j] =E_SERVICETYPE_RADIO;
                                break;
                            case E_TYPE_DATA:
                                aeServiceType[j] =E_SERVICETYPE_DATA;
                                break;
                            default:
                            case E_TYPE_DTV:
                                aeServiceType[j] =E_SERVICETYPE_DTV;
                                break;
                        }
                        //aeServiceType[i] = (MEMBER_SERVICETYPE) pastVirtualCh[i].stCHAttribute.bServiceType;
                    }
                    msAPI_Tuner_Get_PLP_ID(&u8PLP_ID);
                    u8RemovedChnNum = msAPI_CM_RemoveMismatchedProgram(u8RFCh, pastVirtualCh[0].wTransportStream_ID, u8PLP_ID ,msAPI_Tuner_Get_HpLp(), au16ServiceIDs, aeServiceType, u8ServiceCount);
                }
                else
                {
                    ASSERT(0);
                }
                if(au16ServiceIDs)msAPI_Memory_Free(au16ServiceIDs,(EN_BUFFER_ID)0);
                if(aeServiceType)msAPI_Memory_Free(aeServiceType,(EN_BUFFER_ID)0);
                //printf("SCAN_TYPE_MANUAL>> u8RemovedChnNum = %bu\n", u8RemovedChnNum);
            }
#if (ENABLE_HIERARCHY)
            if(msAPI_Tuner_Is_HierarchyOn()&&(msAPI_Tuner_Get_HpLp()==0))
            {

                stTPSetting.u8HpLp=1;
                enScanState=STATE_SCAN_SEARCH_RF_CHANNEL;
                break;
            }
#endif
            {
                U8 u8PLP_ID;
                if(MApp_SI_GetNextT2Parameter(&u8PLP_ID))
                {
                    stTPSetting.u8PLPID=u8PLP_ID;
                    enScanState=STATE_SCAN_SEARCH_RF_CHANNEL;
                }
            }
#endif
            break;

        case STATE_SCAN_PAUSE:
            SCAN_DBINFO( printf( "STATE_SCAN_PAUSE>>\n" ) );
            if(fEndHalt)
            {
                SCAN_DBINFO( printf( "End Halt>>\n" ) );
                if(fReturnToPrevious)
                {
                    SCAN_DBINFO( printf( "Return to previous state>>\n" ) );
                    SCAN_DBINFO( printf( "Previous state=0x%x\n",enPreScanState ) );
                    enScanState=enPreScanState;

                }
                else
                {
                    SCAN_DBINFO( printf( "Go to end>>\n" ) );
                    enScanState=STATE_SCAN_END;
                }
                fEndHalt=FALSE;
            }
            else
            {
                SCAN_DBINFO( printf( "Start halt>>\n" ) );
            }
            break;

        case STATE_SCAN_END:
        case STATE_SCAN_EXIT_MAIN_MENU:
            SCAN_ONE_LINE_DBINFO(printf("\n ## u16ScanDtvChNum=%u",u16ScanDtvChNum));
#if NORDIG_FUNC //for Nordig Spec v2.0
            SCAN_ONE_LINE_DBINFO(printf("\n ## u16ScanDataChNum=%u",u16ScanDataChNum));
#endif
            SCAN_ONE_LINE_DBINFO(printf("\n ## u16ScanRadioChNum=%u",u16ScanRadioChNum));
            SCAN_ONE_LINE_DBINFO(printf("\n ## u8PhysicalChannelCnt = %d ", u8PhysicalChannelCnt));


            SCAN_ONE_LINE_DBINFO( printf( "\n*********************************************************" ) );
            SCAN_ONE_LINE_DBINFO( printf( "\n STATE_SCAN_END or STATE_SCAN_EXIT_MAIN_MENU" ) );
            SCAN_ONE_LINE_DBINFO( printf( "\n*********************************************************\n" ) );


#if ENABLE_CI
            if( msAPI_CI_CardDetect())//DEMOD reload cause need to rest CAM, so do bybass in scan mode
            {
#if (!TS_SERIAL_OUTPUT_IF_CI_REMOVED)
#if (!ENABLE_CI_PLUS)
                msAPI_Tuner_Serial_Control(TRUE);
                msAPI_Tuner_SetByPassMode(FALSE, FALSE);
#endif
#endif
                msAPI_CI_ReInitial();
            }
            MApp_CI_Enable_Process(TRUE);
#endif
#if NTV_FUNCTION_ENABLE
            if(msAPI_CM_GetCountry() == E_NORWAY &&
                #if ENABLE_FAVORITE_NETWORK
                 !g_bSetFavoriteNetwork &&
                #endif
                 ((g_enScanType == SCAN_TYPE_AUTO)||(g_enScanType == SCAN_TYPE_MANUAL))
                 )
            {
                U8 k;

                for(k=0;k<MAX_NETWOEK_NUMBER;k++)
                {
                     if(msAPI_CM_IS_NorwegianNetwork(k))
                     {
                          u8NetworkTotal = k+1;
                     }
                }
                if(u8NetworkTotal == 1)
                {
                    msAPI_CM_Set_FavoriteNetwork(0);
                }
            #if ENABLE_FAVORITE_NETWORK
                g_u8NetworkTotal = 0;

                if (u8NetworkTotal != 0xFF)
                   g_u8NetworkTotal = u8NetworkTotal;
            #endif
            }
#endif

            SCAN_DBINFO( printf( "STATE_SCAN_END>>\n" ) );
            MApp_DTV_Scan_End((g_enScanType == SCAN_TYPE_AUTO && u8NetworkTotal!=0xFF && u8NetworkTotal > 1) ? TRUE : FALSE);

            SCAN_DBINFO( printf( "MENU_CHANNEL_DTV_ManualScan>>\n" ) );

#if DVB_C_ENABLE
            if( g_enScanType == SCAN_TYPE_AUTO || g_enScanType == SCAN_TYPE_NETWORK)
#else
            if( g_enScanType == SCAN_TYPE_AUTO )
#endif
            {
#if ENABLE_SBTVD_BRAZIL_APP
                if( enScanState == STATE_SCAN_END )
                {
                    enDVBScanRetVal = EXIT_GOTO_ATVSCAN;
                }
                else if(enScanState == STATE_SCAN_EXIT_MAIN_MENU)  //20100608EL
                {
                    printf("\n>>>>>>>>>>>>>> enScanState == STATE_SCAN_EXIT_MAIN_MENU<<<<<<<\n");
                    SCAN_DBINFO( printf( "MIA_FINISH_SCAN>>\n" ) );
                    MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_AUTO_SCAN_FINISH);


                    if(u16ScanDtvChNum==0)
                    {
                        if ( u8ScanAtvChNum > 0)
                        {
                            if ( UI_INPUT_SOURCE_TYPE != UI_INPUT_SOURCE_ATV)
                            {
                                //PIP behavior: If PIP is enabled, close sub window and turn on ATV in the main window.
                                #if (ENABLE_PIP)
                                if(IsPIPEnable())
                                {
                                    BOOLEAN bResetSrc = FALSE;

                                    if(IsSrcTypeScart(SYS_INPUT_SOURCE_TYPE(SUB_WINDOW))
                                        || IsSrcTypeAV(SYS_INPUT_SOURCE_TYPE(SUB_WINDOW))
                                        || IsSrcTypeSV(SYS_INPUT_SOURCE_TYPE(SUB_WINDOW)))
                                    {
                                        bResetSrc = TRUE;
                                    }
                                    if(stGenSetting.g_stPipSetting.enPipSoundSrc==EN_PIP_SOUND_SRC_SUB)
                                    {
                                        stGenSetting.g_stPipSetting.enPipSoundSrc=EN_PIP_SOUND_SRC_MAIN;
                                        MApp_InputSource_PIP_ChangeAudioSource(MAIN_WINDOW);
                                    }
                                    E_UI_INPUT_SOURCE ePreSrc = UI_SUB_INPUT_SOURCE_TYPE;
                                    UI_SUB_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_NONE;
                                    MApp_InputSource_ChangeInputSource(SUB_WINDOW);
                                    UI_SUB_INPUT_SOURCE_TYPE = ePreSrc;
                                    stGenSetting.g_stPipSetting.enPipMode = EN_PIP_MODE_OFF;
                                    if(bResetSrc)
                                    {//Set sub window source type to 1st compatible src with the main window.
                                        UI_SUB_INPUT_SOURCE_TYPE = MApp_InputSource_GetUIInputSourceType(MApp_InputSource_PIP_Get1stCompatibleSrc(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)));
                                    }
                                }
                                #endif
                                UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_ATV;
                                MApp_InputSource_SwitchSource( UI_INPUT_SOURCE_TYPE, MAIN_WINDOW );

                                msAPI_ATV_SetCurrentProgramNumber(msAPI_ATV_GetFirstProgramNumber(FALSE));
                                msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE_DURING_LIMITED_TIME, DELAY_FOR_STABLE_SIF, E_AUDIOMUTESOURCE_ACTIVESOURCE);
                                //BY 20090406 msAPI_VD_AdjustVideoFactor(E_ADJUST_VIDEOMUTE_DURING_LIMITED_TIME, DELAY_FOR_STABLE_TUNER);
                                msAPI_AVD_TurnOffAutoAV();
                                msAPI_Tuner_ChangeProgram();
                                //msAPI_VD_ClearSyncCheckCounter();
                                msAPI_AVD_ClearAspectRatio();
                                enDVBScanRetVal = EXIT_GOTO_TV;
                            }
                        }
                        else
                        {
                            enDVBScanRetVal = EXIT_GOTO_PREVIOUS;
                        }
                        enScanState = STATE_SCAN_INIT;
                    }
                    else
                    {
                            enScanState = STATE_SCAN_INIT;
                            enDVBScanRetVal = EXIT_GOTO_TV;
                    }
                    msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_INTERNAL_2_MUTEOFF, E_AUDIOMUTESOURCE_ACTIVESOURCE);


                }



#else  //ENABLE_SBTVD_BRAZIL_APP

#if (ENABLE_TARGET_REGION || ENABLE_LCN_CONFLICT)
                if (enScanState == STATE_SCAN_PAUSE /*&& bSetTargetRegion == TRUE*/)
                {
                    return enDVBScanRetVal;
                }
#endif
                if( enScanState == STATE_SCAN_END)
                {
                    SCAN_DBINFO( printf( "MIA_FINISH_SCAN>>\n" ) );
                    MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_AUTO_SCAN_FINISH);
                    SCAN_DBINFO( printf( "u16NumOfSrvAdd = %u\n", u16NumOfSrvAdd ) );
                }

                if(u16ScanDtvChNum==0)
                {
                    if ( u8ScanAtvChNum > 0)
                    {
                        if ( UI_INPUT_SOURCE_TYPE != UI_INPUT_SOURCE_ATV)
                        {
                            //PIP behavior: If PIP is enabled, close sub window and turn on ATV in the main window.
                            #if (ENABLE_PIP)
                            if(IsPIPEnable())
                            {
                                BOOLEAN bResetSrc = FALSE;

                                if(IsSrcTypeScart(SYS_INPUT_SOURCE_TYPE(SUB_WINDOW))
                                    || IsSrcTypeAV(SYS_INPUT_SOURCE_TYPE(SUB_WINDOW))
                                    || IsSrcTypeSV(SYS_INPUT_SOURCE_TYPE(SUB_WINDOW)))
                                {
                                    bResetSrc = TRUE;
                                }
                                if(stGenSetting.g_stPipSetting.enPipSoundSrc==EN_PIP_SOUND_SRC_SUB)
                                {
                                    stGenSetting.g_stPipSetting.enPipSoundSrc=EN_PIP_SOUND_SRC_MAIN;
                                    MApp_InputSource_PIP_ChangeAudioSource(MAIN_WINDOW);
                                }
                                E_UI_INPUT_SOURCE ePreSrc = UI_SUB_INPUT_SOURCE_TYPE;
                                UI_SUB_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_NONE;
                                MApp_InputSource_ChangeInputSource(SUB_WINDOW);
                                UI_SUB_INPUT_SOURCE_TYPE = ePreSrc;
                                stGenSetting.g_stPipSetting.enPipMode = EN_PIP_MODE_OFF;
                                if(bResetSrc)
                                {//Set sub window source type to 1st compatible src with the main window.
                                    UI_SUB_INPUT_SOURCE_TYPE = MApp_InputSource_GetUIInputSourceType(MApp_InputSource_PIP_Get1stCompatibleSrc(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)));
                                }
                            }
                            #endif
                            UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_ATV;
                            MApp_InputSource_SwitchSource( UI_INPUT_SOURCE_TYPE, MAIN_WINDOW );

                            msAPI_ATV_SetCurrentProgramNumber(msAPI_ATV_GetFirstProgramNumber(FALSE));
                            msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE_DURING_LIMITED_TIME, DELAY_FOR_STABLE_SIF, E_AUDIOMUTESOURCE_ACTIVESOURCE);
                            //BY 20090406 msAPI_VD_AdjustVideoFactor(E_ADJUST_VIDEOMUTE_DURING_LIMITED_TIME, DELAY_FOR_STABLE_TUNER);
                            msAPI_AVD_TurnOffAutoAV();
                            msAPI_Tuner_ChangeProgram();
                            //msAPI_VD_ClearSyncCheckCounter();
                            msAPI_AVD_ClearAspectRatio();
                            enDVBScanRetVal = EXIT_GOTO_TV;
                        }
                    }
                    else
                    {
                            enDVBScanRetVal = EXIT_GOTO_PREVIOUS;
                        }
                    enScanState = STATE_SCAN_INIT;
                }
                else
                {
                        enScanState = STATE_SCAN_INIT;
                        enDVBScanRetVal = EXIT_GOTO_TV;
                }
                msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_INTERNAL_2_MUTEOFF, E_AUDIOMUTESOURCE_ACTIVESOURCE);
#endif
            }
            else
            {
                if( enScanState == STATE_SCAN_EXIT_MAIN_MENU )
                {
                        enDVBScanRetVal =EXIT_GOTO_TV;
                     }
                else
                {
                        enDVBScanRetVal =EXIT_GOTO_PREVIOUS;
                    }
                enScanState = STATE_SCAN_INIT;

            }
#if DVB_C_ENABLE
            if( g_enScanType == SCAN_TYPE_AUTO || g_enScanType == SCAN_TYPE_NETWORK|| (g_enScanType==SCAN_TYPE_MANUAL && u8NumOfVchFound>0))
#else
            if(g_enScanType==SCAN_TYPE_AUTO || (g_enScanType==SCAN_TYPE_MANUAL && u8NumOfVchFound>0))
#endif
            {
                if(msAPI_CM_CountProgram(msAPI_CM_GetCurrentServiceType(), E_PROGACESS_INCLUDE_NOT_VISIBLE_ALSO) > 0)
                {
#if NTV_FUNCTION_ENABLE
                    if(OSD_COUNTRY_SETTING == OSD_COUNTRY_NORWAY)
                    {
                        if(u8NetworkTotal != 0xFF)
                        {
                            MApp_Set_ScanGoRegion_Status(TRUE);
                        }
                        else
                        {
                            MApp_ChannelChange_EnableChannel(MAIN_WINDOW);
                        }
                    }
                    else
                    {
                        MApp_ChannelChange_EnableChannel(MAIN_WINDOW);
                    }
#else
                    MApp_ChannelChange_EnableChannel(MAIN_WINDOW);
#endif
                }
            }

#if (CHANNEL_SCAN_AUTO_TEST)
            if(g_ScanAutoTestData.u2State == 1)
            {
                g_ScanAutoTestData.u16SrvFoundNum = u16NumOfSrvAdd;
                g_ScanAutoTestData.fCommand = 0;
                g_ScanAutoTestData.u2State = 2;
            }
#endif
            break;

        case STATE_SCAN_GOTO_STANDBY:
            SCAN_DBINFO( printf( "STATE_SCAN_GOTO_STANDBY>>\n" ) );
            MApp_DTV_Scan_End(FALSE);

#if DVB_C_ENABLE
            if( g_enScanType == SCAN_TYPE_AUTO || g_enScanType == SCAN_TYPE_NETWORK)
#else
            if( g_enScanType == SCAN_TYPE_AUTO )
#endif
            {
                MApp_ZUI_ACT_ShutdownOSD();
            }

            enDVBScanRetVal =EXIT_GOTO_STANDBY;
            enScanState = STATE_SCAN_INIT;
            break;

        default:
            break;
    }

    return enDVBScanRetVal;
}
#endif
#if (ENABLE_UPDATE_MULTIPLEX_VIA_NIT)
void MApp_DTV_Scan_Retune_Confirm_Yes(void)
{
    MEMBER_SERVICETYPE eServiceType;
    WORD wCurPosition,wNID,wONID,wTSID;
    if (_u32MessageLossSignalTimer )
    {
        eServiceType = msAPI_CM_GetCurrentServiceType();
        wCurPosition = msAPI_CM_GetCurrentPosition(eServiceType);
        wNID = msAPI_CM_GetNetwork_ID(eServiceType,wCurPosition);
        wONID = msAPI_CM_GetON_ID(eServiceType,wCurPosition);
        wTSID = msAPI_CM_GetTS_ID(eServiceType,wCurPosition);

        MApp_SI_Recollect_TSRFList2Scan(wNID, wONID, wTSID);
        MApp_DTV_Scan_SetLossSignalState(LOSS_SIGNAL_RETUNE);
        _cOriginal_ChRF = msAPI_CM_GetPhysicalChannelNumber(eServiceType, wCurPosition);
        //printf("_cOriginal_ChRF  %bu\n",_cOriginal_ChRF);
        _u32MessageLossSignalTimer = 0;
        _stNetworkChangInfo.bLossOfSignal = FALSE;
        enScanState = STATE_SCAN_INIT;
    }
}
void MApp_DTV_Scan_Retune_Confirm_No(void)
{
    if (_u32MessageLossSignalTimer )
    {
        if(_u32MessageLossSignalTimer)
        {
            g_enScanType=SCAN_TYPE_NUM;
        }
        MApp_DTV_Scan_SetLossSignalState(LOSS_SIGNAL_NO_RETUNE);
        _u32MessageLossSignalTimer = 0;
        _stNetworkChangInfo.bLossOfSignal = FALSE;
        enScanState = STATE_SCAN_END;
    }
}
void MApp_DTV_Scan_NetworkChange_Cornfim_OK(void)
{
    if(_u32CheckMuxUpdateTimer )  //norway spec. says scan start without confirmation
    {
        if(_stNetworkChangInfo.bMuxAdd)
        {

            enScanState=STATE_SCAN_INIT;
        }
        else
        {
            enScanState=STATE_SCAN_END;
            return;
        }
        if(_stNetworkChangInfo.bMuxRemove)
        {
            MApp_SI_RemoveMismatchedMux();
            //printf("MApp_SI_RemoveMismatchedMux\n");
        }
        if(_stNetworkChangInfo.bCellRemove)
        {
            BOOLEAN bCurCHIsRemoved;
            msAPI_CM_RemoveInvalidService(&bCurCHIsRemoved);
        }
        _u32CheckMuxUpdateTimer=0;
        _stNetworkChangInfo.bCellRemove=_stNetworkChangInfo.bMuxAdd=_stNetworkChangInfo.bMuxRemove=FALSE;
    }
}

EN_LOSS_SIGNAL_STATE MApp_DTV_Scan_GetLossSignalState(void)
{
    return enLossSignalState;
}

void MApp_DTV_Scan_SetLossSignalState(EN_LOSS_SIGNAL_STATE enState)
{
    enLossSignalState = enState;
}

static void MApp_DTV_Scan_NewMux_ProcessUserInput( void )
{

    switch( u8KeyCode )
    {
        case KEY_POWER:
        case DSC_KEY_PWROFF:
            if(_u32CheckMuxUpdateTimer)
            {
                g_enScanType=SCAN_TYPE_NUM;
            }
            _u32CheckMuxUpdateTimer=0;
            if(_stNetworkChangInfo.bMuxRemove)
            {
                MApp_SI_RemoveMismatchedMux();
            }
            if(_stNetworkChangInfo.bCellRemove)
            {
                BOOLEAN bCurCHIsRemoved;
                msAPI_CM_RemoveInvalidService(&bCurCHIsRemoved);
            }
            if(_stNetworkChangInfo.bMuxAdd)
            {
                MApp_SI_AddNewTSService();
            }
            _stNetworkChangInfo.bCellRemove=_stNetworkChangInfo.bMuxAdd=_stNetworkChangInfo.bMuxRemove=FALSE;
            enScanState = STATE_SCAN_GOTO_STANDBY;
            break;
        case KEY_SELECT:
#if 1
            if (MApp_ZUI_GetActiveOSD() == E_OSD_MESSAGE_BOX)
            {
                MApp_ZUI_ProcessKey(u8KeyCode);
            }
#else
            if(_u32CheckMuxUpdateTimer)
            {
                if(_stNetworkChangInfo.bMuxAdd)
                {

                    enScanState=STATE_SCAN_INIT;
                }
                else
                {
                    enScanState=STATE_SCAN_END;
                    break;
                }
                if(_stNetworkChangInfo.bMuxRemove)
                {
                    MApp_SI_RemoveMismatchedMux();
                    //printf("MApp_SI_RemoveMismatchedMux\n");
                }
                if(_stNetworkChangInfo.bCellRemove)
                {
                    BOOLEAN bCurCHIsRemoved;
                    msAPI_CM_RemoveInvalidService(&bCurCHIsRemoved);
                }
                _u32CheckMuxUpdateTimer=0;
                _stNetworkChangInfo.bCellRemove=_stNetworkChangInfo.bMuxAdd=_stNetworkChangInfo.bMuxRemove=FALSE;

            }
#endif
            break;
        case KEY_EXIT:
            if (OSD_COUNTRY_SETTING == OSD_COUNTRY_NORWAY)      //norway spec says it shall not be possible to cancel the scan
                break;
            if(_u32CheckMuxUpdateTimer)
            {
                g_enScanType=SCAN_TYPE_NUM;
            }
            //_u32CheckMuxUpdateTimer=0;
            //_stNetworkChangInfo.bMuxAdd=_stNetworkChangInfo.bMuxRemove=FALSE;
            enScanState=STATE_SCAN_END;
            if(_stNetworkChangInfo.bMuxAdd)
            {
                MApp_SI_AddNewTSService();
            }
            //printf("cancel ....\n");
            break;
        default:
            break;
    }
    u8KeyCode = KEY_NULL;
}
void MApp_DTV_Scan_Set_UpdateMethod(BOOLEAN bAddMux, BOOLEAN bRemoveMux ,BOOLEAN bCellRemove, BOOLEAN bFreqChange)
{
    _stNetworkChangInfo.bMuxAdd=bAddMux;
    _stNetworkChangInfo.bMuxRemove=bRemoveMux;
    _stNetworkChangInfo.bCellRemove=bCellRemove;
    _stNetworkChangInfo.bFreqChange = bFreqChange;
    SCAN_DBINFO(printf("MApp_DTV_Scan_Set_UpdateMethod add %u remove %u cell remove %u  freqChange  %u\n",_stNetworkChangInfo.bMuxAdd,_stNetworkChangInfo.bMuxRemove,bCellRemove,_stNetworkChangInfo.bFreqChange));
}
void MApp_DTV_Scan_Set_LossSignalFlag(BOOLEAN bLossSignal)
{
    _stNetworkChangInfo.bLossOfSignal = bLossSignal;
}

void MApp_DTV_Scan_Update_Mux_State_Init( void )
{
    enScanState = STATE_SCAN_WAIT;
    enDVBScanState = STATE_DVB_SCAN_INIT;
    MApp_Dmx_GetScanTableStateInit();
}
EN_RET MApp_DTV_Scan_Update_Mux( void )
{
    BOOLEAN ScanResult,fDBFull;
    U16 i;
    WORD wSignalQuality;
    SI_SHORT_DTV_CHANNEL_INFO *pastVirtualCh = NULL;
    enDVBScanRetVal =EXIT_NULL;
    BOOLEAN bFindCurServiceInALTFreq = FALSE;

    MApp_DTV_Scan_NewMux_ProcessUserInput();

    switch( enScanState )
    {
        case STATE_SCAN_INIT:
            //earse all osd message
            //display "Scanning..."
            printf("Scanning...\n");

            if(MApp_ZUI_GetActiveOSD() == E_OSD_MESSAGE_BOX)
            {
                MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_CLOSE_CURRENT_OSD);
            }
#if 1   //TODO
            MApp_ZUI_ACT_StartupOSD(E_OSD_MESSAGE_BOX);
            MApp_ZUI_ACT_ExecuteWndAction( EN_EXE_SHOW_SCANNING_MSGBOX );
#else
            uniSys_Funs_MessageBox_Show( EN_EXE_SHOW_SCANNING_MSGBOX );
#endif
            _u8FirstRF=0;
            _u32CheckMuxUpdateTimer=0;
            enDVBScanState = STATE_DVB_SCAN_INIT;
            MApp_Dmx_GetScanTableStateInit();
            _MApp_DTV_Scan_TableConfig(&_stScanConfig);
            if( MApp_DTV_Scan_Init() == TRUE )
            {
                g_enScanType=SCAN_TYPE_UPDATE_MUX;
                enScanState = STATE_SCAN_SEARCH_RF_CHANNEL;
#if DVB_C_ENABLE
#if ENABLE_T_C_COMBO
                if(IsCATVInUse())
#else
                if(1)
#endif
                {
                    BYTE cRFChannelNumber;
                    MEMBER_SERVICETYPE bServiceType;
                    WORD wCurrentPosition;
                    U8 u8PhNum=0;
                    DTVPROGRAMID_M stDPI;

                    bServiceType = msAPI_CM_GetCurrentServiceType();
                    wCurrentPosition = msAPI_CM_GetCurrentPosition(bServiceType);
                    cRFChannelNumber = msAPI_CM_GetPhysicalChannelNumber(bServiceType,wCurrentPosition);
                    if(INVALID_PHYSICAL_CHANNEL_NUMBER == cRFChannelNumber)
                    {
                        enScanState = STATE_SCAN_END;
                        break;
                    }
                    u8PhNum = msAPI_CM_Get_RFChannelIndex(cRFChannelNumber);
                    if(msAPI_CM_GetIDTable(u8PhNum,(BYTE *)&stDPI,E_DATA_ID_TABLE))
                    {
                        stTPSetting.u32Symbol_rate = stDPI.u32SymbRate;
                        stTPSetting.u8Modulation = stDPI.QamMode;
                        stTPSetting.u32Frequency = stDPI.u32Frequency;
                        stTPSetting.enBandWidth = E_RF_CH_BAND_8MHz;
                        stTPSetting.bAutoSRFlag = 0;
                        stTPSetting.bAutoQamFlag = 0;

                    }
                    else
                    {
                        enScanState = STATE_SCAN_END;
                        break;
                    }
                    _stScanConfig.bEnableNITQuickScan=TRUE;
                }
                else
#endif
                {
                    if((MApp_DTV_Scan_GetLossSignalState() == LOSS_SIGNAL_RETURN_ORIGINAL_RF) && (OSD_COUNTRY_SETTING == OSD_COUNTRY_NORWAY))
                    {
                        u8RFCh = msAPI_CM_GetOriginalRFnumber(msAPI_CM_GetCurrentServiceType(),msAPI_CM_GetCurrentPosition(msAPI_CM_GetCurrentServiceType()));
                        //printf("u8RFCh  %bu\n",u8RFCh);
                    }
                    else
                    {
                        u8RFCh=MApp_SI_Get_New_RF_Index();
                        //printf("...u8RFCh  %bu\n",u8RFCh);
                    }
                    if(u8RFCh != SI_INVALID_PHYSICAL_CHANNEL_NUMBER && u8RFCh !=0)
                    {
                        msAPI_DFT_GetTSSetting( u8RFCh, &stTPSetting );
                        //msAPI_Aeon_Disable();
                    }
                    else
                    {
                        enScanState = STATE_SCAN_END;
                    }
                }
            }
            else
            {
                enScanState = STATE_SCAN_END;
            }
            break;
        case STATE_SCAN_NEXT_CHANNEL:
#if DVB_C_ENABLE
#if ENABLE_T_C_COMBO
            if(IsCATVInUse())
#else
            if(1)
#endif
            {
                MS_CABLE_PARAMETER desc;
                //BYTE dummy;
                enScanState = STATE_SCAN_END;
                if(!_MApp_DTV_Scan_GetNITAvailableFlag())break;
#if 1
                if(MApp_SI_GetNextCableParameter(&desc, NULL,NULL,NULL,NULL, TRUE))
                {
                    stTPSetting.u32Symbol_rate = desc.u32Symbol_rate/10;
                    stTPSetting.u8Modulation = desc.u8Modulation-1;
                    stTPSetting.u32Frequency = desc.u32CentreFreq/10;
                    stTPSetting.enBandWidth = E_RF_CH_BAND_8MHz;
                    stTPSetting.bAutoSRFlag = 0;
                    stTPSetting.bAutoQamFlag = 1;
                    enScanState = STATE_SCAN_SEARCH_RF_CHANNEL;
/*
                    printf("scan mux...freq %d KHZ symbolrate %d\n",stTPSetting.u32Frequency,stTPSetting.u32Symbol_rate);
                    switch(desc.u8Modulation)
                    {
                        case 0:
                            printf("modulation not defined\n");
                            break;
                        case 1:
                            printf("16 QAM\n");
                            break;
                        case 2:
                            printf("32 QAM\n");
                            break;
                        case 3:
                            printf("64 QAM\n");
                            break;
                        case 4:
                            printf("128 QAM\n");
                            break;
                        case 5:
                            printf("256 QAM\n");
                            break;
                    }
*/
                    break;
                }
#else
                while(MApp_SI_GetNextCableParameter(&desc, NULL,NULL,NULL,NULL, TRUE))
                {
                    if(msAPI_CM_Is_TSExist(desc.u16ONID, desc.u16TSID, &dummy) == FALSE)
                    {

                        stTPSetting.u32Symbol_rate = desc.u32Symbol_rate/10;
                        stTPSetting.u8Modulation = desc.u8Modulation-1;
                        stTPSetting.u32Frequency = desc.u32CentreFreq/10;
                        stTPSetting.enBandWidth = E_RF_CH_BAND_8MHz;
                        stTPSetting.bAutoSRFlag = 0;
                        stTPSetting.bAutoQamFlag = 0;
                        enScanState = STATE_SCAN_SEARCH_RF_CHANNEL;
                        //printf("new mux...%d\n",stTPSetting.u32Frequency);
                        break;
                    }
                }
#endif

            }
            else
#endif
            {
                u8RFCh=MApp_SI_Get_New_RF_Index();
                if( u8RFCh == SI_INVALID_PHYSICAL_CHANNEL_NUMBER || u8RFCh == 0/*u8MaxRFCh*/ )
                {
                    enScanState = STATE_SCAN_END;
                    break;
                }
                enScanState = STATE_SCAN_SEARCH_RF_CHANNEL;
                msAPI_DFT_GetTSSetting( u8RFCh, &stTPSetting );
            }
            break;
        case STATE_SCAN_SEARCH_RF_CHANNEL:
            if( MApp_DVB_Scan( &stTPSetting, &ScanResult ) == FALSE )
            {
                break;
            }
            if( ScanResult == FE_LOCK )
            {
                enScanState = STATE_SCAN_GET_PROGRAMS;
            }
            else
            {
                if((MApp_DTV_Scan_GetLossSignalState() == LOSS_SIGNAL_RETURN_ORIGINAL_RF) && (OSD_COUNTRY_SETTING == OSD_COUNTRY_NORWAY))
                {
                    enScanState = STATE_SCAN_END;
                }
                else
                {
                    enScanState = STATE_SCAN_NEXT_CHANNEL;
                }
            }
            break;
        case STATE_SCAN_GET_PROGRAMS:   //Truman for digital only, analog scan shouldn't go into this state
            u8NumOfVchFound = 0;
            if( MApp_Dmx_GetScanTables(&_stScanConfig, &u8NumOfVchFound ) == FALSE )
            {
                break;
            }
            MApp_Dmx_GetScanTableStateInit();
#if DVB_C_ENABLE
            if(_stScanConfig.bEnableNITQuickScan)
            {
                if(!_MApp_DTV_Scan_GetNITAvailableFlag())
                {
                    _MApp_DTV_Scan_SetNITAvailableFlag(TRUE);
                    _stScanConfig.bEnableNITQuickScan=FALSE;
                    enScanState=STATE_SCAN_NEXT_CHANNEL;
                    break;

                }

            }
#endif
            if( u8NumOfVchFound > 0 )
                enScanState = STATE_SCAN_SAVE_PROGRAMS;
            else
            {
                enScanState = STATE_SCAN_NEXT_CHANNEL;
#if (ENABLE_HIERARCHY)
                if(msAPI_Tuner_Is_HierarchyOn()&&(msAPI_Tuner_Get_HpLp()==0))
                {
                    stTPSetting.u8HpLp=1;
                    enScanState=STATE_SCAN_SEARCH_RF_CHANNEL;
                    break;
                }
#endif
#if (ENABLE_DVB_T2)
                {
                    U8 u8PLP_ID;
                    if(MApp_SI_GetNextT2Parameter(&u8PLP_ID))
                    {
                        stTPSetting.u8PLPID=u8PLP_ID;
                        enScanState=STATE_SCAN_SEARCH_RF_CHANNEL;
                    }
                }
#endif
            }
            break;
        case STATE_SCAN_SAVE_PROGRAMS:
            if(_u8FirstRF == 0)
            {
                _u8FirstRF=u8RFCh;
            }
            if(u8NumOfVchFound && (MApp_DTV_Scan_GetLossSignalState() == LOSS_SIGNAL_RETURN_ORIGINAL_RF) && (OSD_COUNTRY_SETTING == OSD_COUNTRY_NORWAY))
            {
                msAPI_CM_ResetOriginalRFnumber(msAPI_CM_GetCurrentServiceType(),msAPI_CM_GetCurrentPosition(msAPI_CM_GetCurrentServiceType()));
            }
            MApp_SI_Reset_New_RF_Index(u8RFCh);
            //wSignalQuality = msAPI_Tuner_GetSingalSNRPercentage();
            msAPI_Tuner_CheckSignalStrength(&wSignalQuality);
            wSignalQuality = (wSignalQuality&0x7F)<<8;
            //wSignalQuality |= (msAPI_Tuner_GetSingalSNRPercentage()&0xFF);
            wSignalQuality |= (msAPI_Tuner_GetSignalQualityPercentage()&0xFF);

            fDBFull = FALSE;
            pastVirtualCh = MApp_SI_Get_PastVirtualCh();
            for(i = 0;i < u8NumOfVchFound ;i++)
            {
                if((MApp_DTV_Scan_GetLossSignalState() == LOSS_SIGNAL_RETURN_ORIGINAL_RF || MApp_DTV_Scan_GetLossSignalState() == LOSS_SIGNAL_RETUNE)
                    && (OSD_COUNTRY_SETTING == OSD_COUNTRY_NORWAY))
                {
                    pastVirtualCh[i].stCHAttribute.wSignalStrength = 0x7FFF;
                }
                else
                {
                    pastVirtualCh[i].stCHAttribute.wSignalStrength = wSignalQuality;
                }
                if((MApp_DTV_Scan_GetLossSignalState() == LOSS_SIGNAL_RETUNE)
                    &&((pastVirtualCh[i].wService_ID == msAPI_CM_GetService_ID(msAPI_CM_GetCurrentServiceType(), msAPI_CM_GetCurrentPosition(msAPI_CM_GetCurrentServiceType())))
                    &&(pastVirtualCh[i].wOriginalNetwork_ID == msAPI_CM_GetON_ID(msAPI_CM_GetCurrentServiceType(), msAPI_CM_GetCurrentPosition(msAPI_CM_GetCurrentServiceType())))))
                {
                    bFindCurServiceInALTFreq = TRUE;
                }
            }
            if((MApp_DTV_Scan_GetLossSignalState() != LOSS_SIGNAL_RETUNE) || bFindCurServiceInALTFreq == TRUE)
            {
                u16NumOfSrvAdd += MApp_Scan_AddOneDTVPchVchs(u8RFCh, pastVirtualCh, u8NumOfVchFound, TRUE, &fDBFull);
                {
                    U16  *au16ServiceIDs=NULL;//[MAX_VC_PER_PHYSICAL];
                    MEMBER_SERVICETYPE *aeServiceType=NULL;//[MAX_VC_PER_PHYSICAL];
                    MS_PAT_ITEM *pastPATItem = MApp_SI_Get_PastPATItem();
                    U8 u8PLP_ID=0;
                    U8 u8ServiceCount=MApp_SI_GetScanNumOfPatItem();
                    au16ServiceIDs=(U16*)msAPI_Memory_Allocate(sizeof(U16)*MAX_VC_PER_PHYSICAL,(EN_BUFFER_ID)0);
                    aeServiceType=(MEMBER_SERVICETYPE*)msAPI_Memory_Allocate(sizeof(MEMBER_SERVICETYPE)*MAX_VC_PER_PHYSICAL,(EN_BUFFER_ID)0);

                    if(au16ServiceIDs && aeServiceType)
                    {
                        for( i = 0; i < u8ServiceCount; i++)
                        {
                            au16ServiceIDs[i] = pastPATItem[i].u16ProgramNumber;
                            aeServiceType[i]  = msAPI_SI_ToCM_Service_Type((MEMBER_SI_SERVICETYPE)pastVirtualCh[i].stCHAttribute.bServiceType);
                            //aeServiceType[i] = (MEMBER_SERVICETYPE) pastVirtualCh[i].stCHAttribute.bServiceType;
                        }
                        msAPI_Tuner_Get_PLP_ID(&u8PLP_ID);
                        msAPI_CM_RemoveMismatchedProgram(u8RFCh, pastVirtualCh[0].wTransportStream_ID, u8PLP_ID, msAPI_Tuner_Get_HpLp(), au16ServiceIDs, aeServiceType, u8ServiceCount);
                    }
                    else
                    {
                        ASSERT(0);
                    }
                    if(au16ServiceIDs)msAPI_Memory_Free(au16ServiceIDs,(EN_BUFFER_ID)0);
                    if(aeServiceType)msAPI_Memory_Free(aeServiceType,(EN_BUFFER_ID)0);
                }
            }
            if( !fDBFull)
            {
                enScanState = STATE_SCAN_NEXT_CHANNEL;
#if (ENABLE_HIERARCHY)
                if(msAPI_Tuner_Is_HierarchyOn()&&(msAPI_Tuner_Get_HpLp()==0))
                {
                    stTPSetting.u8HpLp=1;
                    enScanState=STATE_SCAN_SEARCH_RF_CHANNEL;
                    break;

                }
#endif
#if (ENABLE_DVB_T2)
                {
                    U8 u8PLP_ID;
                    if(MApp_SI_GetNextT2Parameter(&u8PLP_ID))
                    {
                        stTPSetting.u8PLPID=u8PLP_ID;
                        enScanState=STATE_SCAN_SEARCH_RF_CHANNEL;
                    }
                }
#endif
            }
            else
            {
                enScanState = STATE_SCAN_END;
            }
            break;
        case STATE_SCAN_END:
            //erase message
#if 1   //TODO
            if(MApp_ZUI_GetActiveOSD() == E_OSD_MESSAGE_BOX)
            {
                MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_CLOSE_CURRENT_OSD);
            }
#endif
            if(_u32CheckMuxUpdateTimer)//cancel
            {
                if(_stNetworkChangInfo.bMuxRemove)
                {
                    MApp_SI_RemoveMismatchedMux();
                }
                if(_stNetworkChangInfo.bCellRemove)
                {
                    BOOLEAN bCurCHIsRemoved;
                    msAPI_CM_RemoveInvalidService(&bCurCHIsRemoved);
                    if(bCurCHIsRemoved)
                    {
                        MApp_ChannelChange_DisableChannel(TRUE,MAIN_WINDOW);
                        MApp_ChannelChange_EnableChannel(MAIN_WINDOW);
                    }
                }
                MApp_SI_ResetNetworkNewService();
                if (OSD_COUNTRY_SETTING == OSD_COUNTRY_NORWAY)
                    MApp_DTV_Scan_SetLossSignalState(LOSS_SIGNAL_INIT);
                _u32CheckMuxUpdateTimer=0;
                enDVBScanRetVal =EXIT_GOTO_PREVIOUS;
                enScanState = STATE_SCAN_INIT;
                g_enScanType = (EN_SCAN_TYPE) stGenSetting.stScanMenuSetting.u8ScanType;
                MApp_SI_EnableNetworkCheck(TRUE);
                break;
            }
            _stNetworkChangInfo.bCellRemove=_stNetworkChangInfo.bMuxAdd=_stNetworkChangInfo.bMuxRemove=_stNetworkChangInfo.bFreqChange = FALSE;
            _bFrequency_change = FALSE;
            MApp_DTV_Scan_End(FALSE);
            #if (MHEG5_ENABLE)
            if ( IsDTVInUse() )
            {
                msAPI_MHEG5_Bean_Init();

                enCheckMHEGLoadingStatus = EN_MHEG5_MONITOR;
                msAPI_MHEG5_SetGoBackMHEG5(false);
            }
            #endif

#if 0
            enUiMainMenuState = STATE_UIMENU_WAIT;
#endif
            // to prevent sound when analog tuning is finished
            msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_INTERNAL_2_MUTEOFF, E_AUDIOMUTESOURCE_ACTIVESOURCE);

            if(msAPI_CM_CountProgram(msAPI_CM_GetCurrentServiceType(), E_PROGACESS_INCLUDE_NOT_VISIBLE_ALSO) != 0)
            {
                MApp_ChannelChange_EnableChannel(MAIN_WINDOW);
            }

            enDVBScanRetVal =EXIT_GOTO_PREVIOUS;
            enScanState = STATE_SCAN_INIT;
            g_enScanType = (EN_SCAN_TYPE) stGenSetting.stScanMenuSetting.u8ScanType;
            MApp_SI_EnableNetworkCheck(TRUE);
            break;
        case STATE_SCAN_GOTO_STANDBY:
            //erase message
#if 1 //TODO
             if(MApp_ZUI_GetActiveOSD() == E_OSD_MESSAGE_BOX)
             {
                 MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_CLOSE_CURRENT_OSD);
             }
#endif
             _stNetworkChangInfo.bCellRemove=_stNetworkChangInfo.bMuxAdd=_stNetworkChangInfo.bMuxRemove=_stNetworkChangInfo.bFreqChange= FALSE;
             _bFrequency_change = FALSE;
            MApp_DTV_Scan_End(FALSE);
#if 0 //TODO
            enUiMainMenuState = STATE_UIMENU_WAIT;
#endif
            enDVBScanRetVal =EXIT_GOTO_STANDBY;
            enScanState = STATE_SCAN_INIT;
            MApp_SI_EnableNetworkCheck(TRUE);
            break;
        case STATE_SCAN_WAIT:
            if ((_u32MessageDisplayTimer && msAPI_Timer_DiffTimeFromNow(_u32MessageDisplayTimer) > 3000) &&
                (OSD_COUNTRY_SETTING == OSD_COUNTRY_NORWAY))
            {
                if(_stNetworkChangInfo.bMuxAdd || _stNetworkChangInfo.bFreqChange)
                {

                    enScanState=STATE_SCAN_INIT;
                    if(_stNetworkChangInfo.bFreqChange)
                        _bFrequency_change = TRUE;
                }
                else
                {
                    enScanState=STATE_SCAN_END;
                    break;
                }
                if(_stNetworkChangInfo.bMuxRemove)
                {
                    MApp_SI_RemoveMismatchedMux();
                    //printf("MApp_SI_RemoveMismatchedMux\n");
                }
                _u32CheckMuxUpdateTimer=0;
                _u32MessageDisplayTimer = 0;
                _stNetworkChangInfo.bFreqChange=_stNetworkChangInfo.bMuxAdd=_stNetworkChangInfo.bMuxRemove=FALSE;
                break;
            }
            else if ((_u32MessageLossSignalTimer && msAPI_Timer_DiffTimeFromNow(_u32MessageLossSignalTimer) > LOSS_SIGNAL_TIMEOUT) &&
                (OSD_COUNTRY_SETTING == OSD_COUNTRY_NORWAY))
            {
                if (LOSS_SIGNAL_CONFIRM_MSG == MApp_DTV_Scan_GetLossSignalState())
                {
#if 1 //TODO
                    MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_CLOSE_CURRENT_OSD);
                    MApp_DTV_Scan_SetLossSignalState(LOSS_SIGNAL_NO_RETUNE);
#endif
                }
                _u32MessageLossSignalTimer = 0;
                _stNetworkChangInfo.bLossOfSignal = FALSE;
                enDVBScanRetVal =EXIT_GOTO_PREVIOUS;
                enScanState = STATE_SCAN_INIT;
                break;
            }
            else if(_u32CheckMuxUpdateTimer && msAPI_Timer_DiffTimeFromNow(_u32CheckMuxUpdateTimer) > 30000)
            {
                //printf("wait time out\n");
                enScanState=STATE_SCAN_END;
                break;
            }
            if((MApp_DTV_Scan_GetLossSignalState() == LOSS_SIGNAL_RETURN_ORIGINAL_RF) && (OSD_COUNTRY_SETTING == OSD_COUNTRY_NORWAY))
            {
                MApp_SI_EnableNetworkCheck(FALSE);
                g_enScanType=SCAN_TYPE_NUM;
                //printf("LOSS_SIGNAL_RETURN_ORIGINAL_RF\n");
                enScanState = STATE_SCAN_INIT;
            }
            else if (0==_u32MessageLossSignalTimer && _stNetworkChangInfo.bLossOfSignal)
            {
                MApp_SI_EnableNetworkCheck(FALSE);
                 g_enScanType=SCAN_TYPE_NUM;
                //printf("display LOSS_OF_SIGNAL_MSGBOX\n");
#if 0 //TODO
                MApp_ZUI_ACT_StartupOSD(E_OSD_MESSAGE_BOX);
                MApp_ZUI_ACT_ExecuteWndAction( EN_EXE_SHOW_LOSS_OF_SIGNAL_MSGBOX );
#else
                MApp_ZUI_ACT_ShutdownOSD();
                MApp_ZUI_ACT_StartupOSD(E_OSD_MESSAGE_BOX);
                MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_SHOW_LOSS_OF_SIGNAL_MSGBOX);
#endif
                _u32MessageLossSignalTimer = msAPI_Timer_GetTime0();
                if(0 == _u32MessageLossSignalTimer)
                {
                    _u32MessageLossSignalTimer=1;
                }
            }
            else if(0 == _u32CheckMuxUpdateTimer && (_stNetworkChangInfo.bFreqChange ||
                _stNetworkChangInfo.bMuxRemove || _stNetworkChangInfo.bMuxAdd || _stNetworkChangInfo.bCellRemove))
            {
                MApp_SI_EnableNetworkCheck(FALSE);
                g_enScanType=SCAN_TYPE_NUM;
                if(_stNetworkChangInfo.bFreqChange)
                {
                    //display "Frequency change! Re-scan is required."
#if 0 //TODO
                    MApp_ZUI_ACT_StartupOSD(E_OSD_MESSAGE_BOX);
                    MApp_ZUI_ACT_ExecuteWndAction( EN_EXE_SHOW_FREQUENCY_CHANGE_MSGBOX );
#else
                    MApp_ZUI_ACT_ShutdownOSD();
                    MApp_ZUI_ACT_StartupOSD(E_OSD_MESSAGE_BOX);
                    MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_SHOW_FREQUENCY_CHANGE_MSGBOX);
#endif
                }
                else if(_stNetworkChangInfo.bMuxAdd)
                {
                    //display "New Multiplex Add. Update now?"
                    if (OSD_COUNTRY_SETTING == OSD_COUNTRY_NEWZEALAND)
                    {
#if 0 //TODO
                        MApp_ZUI_ACT_StartupOSD(E_OSD_MESSAGE_BOX);
                        MApp_ZUI_ACT_ExecuteWndAction( EN_EXE_SHOW_NETWORK_CHANGE_MSGBOX );
#endif
                    }
                    else if (OSD_COUNTRY_SETTING == OSD_COUNTRY_NORWAY)
                    {
                        //display "New Multiplex might be available! Re-scan is required."
#if 0 //TODO
                        MApp_ZUI_ACT_StartupOSD(E_OSD_MESSAGE_BOX);
                        MApp_ZUI_ACT_ExecuteWndAction( EN_EXE_SHOW_NEW_MULTIPLEX_MIGHT_AVAILABLE_MSGBOX );
#endif
                    }
                }
                else if(_stNetworkChangInfo.bMuxRemove)
                {
                    //display "Multiplex is removed. Update now?"
                    if (OSD_COUNTRY_SETTING == OSD_COUNTRY_NEWZEALAND)
                    {
#if (ENABLE_UPDATE_MULTIPLEX_VIA_NIT) //TODO
                        MApp_ZUI_ACT_StartupOSD(E_OSD_MESSAGE_BOX);
                        MApp_ZUI_ACT_ExecuteWndAction( EN_EXE_SHOW_NETWORK_CHANGE_MSGBOX );
#endif
                    }
                    else if (OSD_COUNTRY_SETTING == OSD_COUNTRY_NORWAY)
                    {
                         //display "Multiplex is removed! Update now!"
#if 0 //TODO
                        MApp_ZUI_ACT_StartupOSD(E_OSD_MESSAGE_BOX);
                        MApp_ZUI_ACT_ExecuteWndAction( EN_EXE_SHOW_MULTIPLEX_IS_REMOVED_MSGBOX );
#endif
                    }
                }
                else if(_stNetworkChangInfo.bCellRemove)
                {
                    //display "Transmitter is removed. Update now?"
#if 0 //TODO
                    printf("Transmitter is removed. Update now?\n");
                    MApp_ZUI_ACT_StartupOSD(E_OSD_MESSAGE_BOX);
                    MApp_ZUI_ACT_ExecuteWndAction( EN_EXE_SHOW_NETWORK_CHANGE_MSGBOX );
#endif

                }
                _u32CheckMuxUpdateTimer =  msAPI_Timer_GetTime0();
                _u32MessageDisplayTimer = msAPI_Timer_GetTime0();
                if(0 == _u32CheckMuxUpdateTimer)
                {
                    _u32CheckMuxUpdateTimer=1;
                }
                if(0 == _u32MessageDisplayTimer)
                {
                    _u32MessageDisplayTimer=1;
                }
                //MApp_Dmx_DisableTableMonitor();
            }
            break;
        default:
            break;
    }
    return enDVBScanRetVal;
}
#endif

/*****************************************************************************/
#define NEW_SCAN_APP_DBG(y)  //y


#if (FRONTEND_DEMOD_TYPE == TOSHIBA_TC90512XBG_DEMOD ||\
      FRONTEND_DEMOD_TYPE == TOSHIBA_TC90517FG_DEMOD ||\
      FRONTEND_DEMOD_TYPE == TOSHIBA_TC90527FG_DEMOD)
	#define TUNER_PLL_STABLE_TIME  0    // 56CH * 50mSec = 2800mSec
#else
	#define TUNER_PLL_STABLE_TIME  50   //ms
#endif

#if ENABLE_T_C_COMBO
EN_DVB_TYPE MApp_DVBType_GetCurrentType(void)
{
    return (EN_DVB_TYPE)stGenSetting.stScanMenuSetting.u8DVBCTvConnectionType;//enDVBSelectType;
}
void MApp_DVBType_SetCurrentType(U8 SelectDVBType)
{
    UI_PREV_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_TYPE;
    if (SelectDVBType == EN_DVB_T_TYPE)
        UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_DTV;
    else
        UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_CADTV;

    stGenSetting.stScanMenuSetting.u8DVBCTvConnectionType = (EN_DVB_TYPE)SelectDVBType;
}

EN_DVB_TYPE MApp_DVBType_GetPrevType(void)
{
    return enDVBPreSelectType;
}
void MApp_DVBType_SetPrevType(EN_DVB_TYPE SelectDVBType)
{
	printf("\r\n[-enDVBPreSelectType-]: %d",SelectDVBType);
	enDVBPreSelectType = (EN_DVB_TYPE)SelectDVBType;
}
#endif

BOOLEAN MApp_DVB_Scan( MS_TP_SETTING *pstTPSetting,BOOLEAN *ScanResult )
{
    BOOLEAN Result;

    *ScanResult = FE_NOT_LOCK;

    switch( enDVBScanState )
    {
        case STATE_DVB_SCAN_INIT:
            enDVBScanState = STATE_DVB_SCAN_INIT_DEMODE;
            break;

        case STATE_DVB_SCAN_INIT_DEMODE:
            //Set Tuner
            #if CHANNEL_SCAN_AUTO_TEST
            if(stTpSettingPC.u32Frequency)
            {
                printf("\r\nMApp_Scan: msAPI_Tuner_Tune2RfCh\r\n");
                msAPI_Tuner_Tune2RfCh( &stTpSettingPC );
            }
            else
            {
                msAPI_Tuner_Tune2RfCh( pstTPSetting );
            }
            #else
            msAPI_Tuner_Tune2RfCh( pstTPSetting );
            #endif
            msAPI_Timer_Delayms( TUNER_PLL_STABLE_TIME );
            enDVBScanState = STATE_DVB_SCAN_CHECK_LOCK;
            break;

        case STATE_DVB_SCAN_CHECK_LOCK:
            //Check Lock Loop
#if (ENABLE_UPDATE_MULTIPLEX_VIA_NIT)
            if(g_enScanType==SCAN_TYPE_UPDATE_MUX && msAPI_SI_IsSpecificCountry(MApp_GetSICountry(OSD_COUNTRY_SETTING),SI_SUPPORT_NETWORK_UPDATE_SPECIFIC_COUNTRY))//todo check offset case
            {
                U8 i;
                for(i=0;i<100;i++)
                {
                    msAPI_Timer_Delayms(10);
                    msAPI_Tuner_CheckLock( &Result,FALSE);
                    if( Result == FE_LOCK )break;
                }
                if(i>=100)
                {
                    *ScanResult = FE_NOT_LOCK;
                    enDVBScanState = STATE_DVB_SCAN_INIT;
                    return TRUE;
                }
            }
            else
#endif
            #if (CHIP_FAMILY_TYPE == CHIP_FAMILY_S8)
            msAPI_Timer_Delayms(1500);
            #elif (CHIP_FAMILY_TYPE == CHIP_FAMILY_S7L)
            msAPI_Timer_Delayms(100);
            #endif

            if( msAPI_Tuner_CheckLock( &Result,TRUE) == FALSE )
            {
                NEW_SCAN_APP_DBG( printf( "FE IIC fail \n" ); );
                #if PLAYCARD_DISABLE // if you want use play card turn off this
                *ScanResult = FE_NOT_LOCK;
                #else
                *ScanResult = FE_LOCK;
                #endif
                enDVBScanState = STATE_DVB_SCAN_INIT;
                return TRUE;
                break;
            }

            NEW_SCAN_APP_DBG( printf( "MApp_DVB_Scan Demod Check Lock=%bd \n", ( U8 ) Result ); );
            if( Result == FE_LOCK )
            {
                *ScanResult = FE_LOCK;
                NEW_SCAN_APP_DBG( printf( "FE Locked \n" ); );
                #if ENABLE_AUTOTEST
                if(g_bAutobuildDebug)
                {
                    printf("31_DTV_FE_Locked\n");
                }
                #endif
            }
            else
            {
                #if PLAYCARD_DISABLE // if you want use play card turn off this
                *ScanResult = FE_NOT_LOCK;
                #else
                *ScanResult = FE_LOCK;
                #endif
                NEW_SCAN_APP_DBG( printf( "FE Not Locked \n" ); );
            }
            enDVBScanState = STATE_DVB_SCAN_INIT;
            return TRUE;
            break;
    }

    return FALSE;
}

void MApp_Scan_SetScanState(EN_SCAN_STATE state)
{
    enScanState = state;
}



void MApp_DTV_ExitScanPauseState(void)
{
    fEndHalt = TRUE;
    enScanState = enPreScanState;
    fReturnToPrevious = TRUE;

}

void MApp_DTV_ExitScanPause2End(void)
{
    fEndHalt = TRUE;
    enPreScanState = enScanState;
    enScanState = STATE_SCAN_END;
}

void MApp_DTV_ExitScanPause2Menu(void)
{
    fEndHalt = TRUE;
    enPreScanState = enScanState;
    enScanState = STATE_SCAN_EXIT_MAIN_MENU;
}

#if DVB_C_ENABLE
static void _MApp_DTV_Scan_InitSymbolRate(void)
{
    U16 u16Sym;
    if (g_enScanType == SCAN_TYPE_AUTO || g_enScanType == SCAN_TYPE_NETWORK)
    {
        if (DVBCSymbolRateScanType) //auto mode
        {
            if (IS_NORDIC_COUNTRY(OSD_COUNTRY_SETTING))
                u16Sym = DEFAULT_DVBC_NORDIG_SYMBOL_RATE;
            else if(OSD_COUNTRY_SETTING == E_CHINA)
                u16Sym = DEFAULT_DVBC_CHINA_SYMBOL_RATE;
            else
                u16Sym = DEFAULT_DVBC_SYMBOL_RATE;
            MApp_CadtvManualTuning_SetSymbol(u16Sym);
        }
    }
}

#if(CHIP_FAMILY_TYPE != CHIP_FAMILY_S7LD)
static BOOLEAN _MApp_DTV_Scan_IncreaseModulationMode(void)
{
    EN_CAB_CONSTEL_TYPE eQam = MApp_CadtvManualTuning_GetQamType();
    return MApp_CadtvManualTuning_SetQamType(++eQam);
}
#endif
static void _MApp_DTV_Scan_InitDVBCScanFlags(void)
{
    memset(&_stDVBCScanFlags, 0, sizeof(_DVBC_SCAN_FLAG));
    _stDVBCScanFlags.bInitScanState = 1;
}


static void _MApp_DTV_Scan_InitModulationMode(void)
{
    if (g_enScanType == SCAN_TYPE_AUTO || g_enScanType == SCAN_TYPE_NETWORK)
        MApp_CadtvManualTuning_SetQamType(CAB_QAM16);
}

static void _MApp_DTV_Scan_AddNITFreqIntoScanTbl(void)
{
    MS_CABLE_PARAMETER desc;
    U16 u16RemainFreq;

    while(MApp_SI_GetNextCableParameter(&desc, NULL,NULL,NULL,&u16RemainFreq, TRUE) && u16RemainFreq>0)
    {
        if (FALSE == msAPI_DCFT_IsThisFreqInBuiltinFreqTbl(desc.u32CentreFreq))
        {
            SCAN_DBINFO(printf("@@@%s=>Freq: %lu\n",__FUNCTION__, desc.u32CentreFreq));
            msAPI_DCFT_SetFreqToNITNewFreqTbl(desc.u32CentreFreq);
        }
    }
}

static BOOLEAN _MApp_DTV_Scan_GetTPSettingFromNITParams(MS_TP_SETTING *pstTPSetting)
{
    MS_CABLE_PARAMETER desc;
    U16 u16RemainFreq;
    if (NULL == pstTPSetting)
        return FALSE;

    if (MApp_SI_GetNextCableParameter(&desc, NULL, NULL, NULL, &u16RemainFreq, TRUE))
    {
        pstTPSetting->u32Frequency = desc.u32CentreFreq/10;
        pstTPSetting->u8Modulation = desc.u8Modulation - 1;
        pstTPSetting->u32Symbol_rate = desc.u32Symbol_rate/10;
        pstTPSetting->enBandWidth = E_RF_CH_BAND_8MHz;
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}

static BOOLEAN _MApp_DTV_Scan_SetCableTPSetting(_DVBC_SCAN_FLAG *stScanFlag, MS_TP_SETTING *pstTPSetting)
{
    BOOL bTuenOtherQamMode = FALSE;
    if (NULL == pstTPSetting || NULL == stScanFlag)
        return FALSE;

    if (g_enScanType == SCAN_TYPE_MANUAL)
    {
        pstTPSetting->u32Frequency = MApp_CadtvManualTuning_GetFrequency();
        pstTPSetting->enBandWidth = E_RF_CH_BAND_8MHz;
        pstTPSetting->u32Symbol_rate = MApp_CadtvManualTuning_GetSymbol();
        pstTPSetting->u8Modulation = (U8)MApp_CadtvManualTuning_GetQamType();
        pstTPSetting->bAutoSRFlag = 0;
        pstTPSetting->bAutoQamFlag = 0;
        return TRUE;
    }
    else if (g_enScanType == SCAN_TYPE_AUTO)
    {
        if (stScanFlag->bInitScanState)
        {
            stScanFlag->bInitScanState = 0;
            bTuenOtherQamMode = FALSE;
        }
        else if (!stScanFlag->bFrontEndLock && !stScanFlag->bInitScanState)
        {   //tune the other qam mode when fornt-end unlock
        #if(CHIP_FAMILY_TYPE == CHIP_FAMILY_S7LD)  // T4 support auto qam     //verity 0115
            bTuenOtherQamMode = FALSE;
        #else
            bTuenOtherQamMode = _MApp_DTV_Scan_IncreaseModulationMode();
        #endif
        }
        else
        {
            // tune next frequency
            bTuenOtherQamMode = FALSE;
            stScanFlag->bFrontEndLock = 0;
            MApp_CadtvManualTuning_SetQamType(CAB_QAM16);
        }
        if (FALSE == bTuenOtherQamMode)
        {
            _MApp_DTV_Scan_InitModulationMode();
            if (NULL == (pstTPSetting->u32Frequency = msAPI_DCFT_GetBuiltInNextFreq(0)))
            {
#if 0   //auto(blind) scan don't consider the NIT frequencies
                //Built-in frequencies have been scanned over, change to NIT frequency table
                if (NULL == (pstTPSetting->u32Frequency = msAPI_DCFT_GetNITNextFreq()))
#endif
                    return FALSE;
            }
        }
        pstTPSetting->enBandWidth = E_RF_CH_BAND_8MHz;
        pstTPSetting->u32Symbol_rate = MApp_CadtvManualTuning_GetSymbol();
        pstTPSetting->u8Modulation = (U8)MApp_CadtvManualTuning_GetQamType();
        pstTPSetting->bAutoQamFlag = 1;
        if (DVBCSymbolRateScanType)
            pstTPSetting->bAutoSRFlag = 1;
        else
            pstTPSetting->bAutoSRFlag = 0;

        return TRUE;
    }
    else if (g_enScanType == SCAN_TYPE_NETWORK)
    {
        if (stScanFlag->bInitScanState)
        {
            stScanFlag->bInitScanState = 0;
            bTuenOtherQamMode = FALSE;
            if (!DVBCFreqScanType)  //manual frequency
            {
#if 1   //home channel frequency is independent with built-in frequency
                pstTPSetting->u32Frequency = MApp_CadtvManualTuning_GetFrequency();
                pstTPSetting->enBandWidth = E_RF_CH_BAND_8MHz;
                pstTPSetting->u32Symbol_rate = MApp_CadtvManualTuning_GetSymbol();
                pstTPSetting->u8Modulation = (U8)MApp_CadtvManualTuning_GetQamType();
                pstTPSetting->bAutoQamFlag = 1;
                if (DVBCSymbolRateScanType)
                    pstTPSetting->bAutoSRFlag = 1;
                else
                    pstTPSetting->bAutoSRFlag = 0;

                //init built-in frequency next starting frequency index
                msAPI_DCFT_GetBuiltInNextFreq(MApp_CadtvManualTuning_GetFrequency());
                return TRUE;
#else
                if (NULL == (pstTPSetting->u32Frequency = msAPI_DCFT_GetBuiltInNextFreq(MApp_CadtvManualTuning_GetFrequency())))
                {
                    return FALSE;
                }
                else
                {
                    pstTPSetting->enBandWidth = E_RF_CH_BAND_8MHz;
                    pstTPSetting->u32Symbol_rate = MApp_CadtvManualTuning_GetSymbol();
                    pstTPSetting->u8Modulation = (U8)MApp_CadtvManualTuning_GetQamType();
                    return TRUE;
                }
#endif
            }
        }
        else if (!stScanFlag->bNITScanAvailable && !stScanFlag->bFrontEndLock && !stScanFlag->bInitScanState)
        {   //tune the other qam mode when fornt-end unlock
        #if(CHIP_FAMILY_TYPE == CHIP_FAMILY_S7LD)  // T4 support auto qam
            bTuenOtherQamMode = FALSE;
        #else
            bTuenOtherQamMode = _MApp_DTV_Scan_IncreaseModulationMode();
        #endif
        }
        else
        {
            // tune next frequency
            bTuenOtherQamMode = FALSE;
            stScanFlag->bFrontEndLock = 0;
            if (!stScanFlag->bNITScanAvailable)
                MApp_CadtvManualTuning_SetQamType(CAB_QAM16);
        }
        if (FALSE == bTuenOtherQamMode)
        {
            if (TRUE == _MApp_DTV_Scan_GetNITAvailableFlag())
            {
                //NIT available, get tp setting by NIT parameters
                return _MApp_DTV_Scan_GetTPSettingFromNITParams(pstTPSetting);
            }
            else
            {
                //find built-in frequencies first, and then nit new frequencies again
                _MApp_DTV_Scan_InitModulationMode();
                if (NULL == (pstTPSetting->u32Frequency = msAPI_DCFT_GetBuiltInNextFreq(0)))
                {   //Built-in frequencies have been scanned over, change to NIT frequency table
                   if (NULL == (pstTPSetting->u32Frequency = msAPI_DCFT_GetNITNextFreq()))
                        return FALSE;
                }
            }
        }
        pstTPSetting->enBandWidth = E_RF_CH_BAND_8MHz;
        pstTPSetting->u32Symbol_rate = MApp_CadtvManualTuning_GetSymbol();
        pstTPSetting->u8Modulation = (U8)MApp_CadtvManualTuning_GetQamType();
        pstTPSetting->bAutoQamFlag = 1;
        if (DVBCSymbolRateScanType)
            pstTPSetting->bAutoSRFlag = 1;
        else
            pstTPSetting->bAutoSRFlag = 0;
        return TRUE;
    }
    else
        return FALSE;
}


static void _MApp_DTV_Scan_SetNITAvailableFlag(BOOLEAN bNITFlag)
{
    _stDVBCScanFlags.bNITScanAvailable = bNITFlag;
}

static BOOLEAN _MApp_DTV_Scan_GetNITAvailableFlag(void)
{
    return (_stDVBCScanFlags.bNITScanAvailable) ? TRUE : FALSE;
}


static BOOLEAN _MApp_Scan_DVBC_QuickInstall_ProcessKey(void) // kk 0815-1
{
	MApp_ProcessUserInput();

	switch (u8KeyCode)
	{
            case KEY_POWER:
            case KEY_1:
            case KEY_2:
            case KEY_3:
            case KEY_4:
            case KEY_5:
            case KEY_6:
            case KEY_7:
            case KEY_8:
            case KEY_9:
            case KEY_0:
            case KEY_UP:
            case KEY_DOWN:
            case KEY_CHANNEL_MINUS:
            case KEY_CHANNEL_PLUS:
            case KEY_INPUT_SOURCE:
            case KEY_TV_INPUT:
            case KEY_POWERONLY:
            case KEY_AV:
                u8KeyCode = KEY_NULL;
                return FALSE;
            break;
            default:
                break;
    }
    u8KeyCode = KEY_NULL;
    return TRUE ;
}

static BOOLEAN _MApp_Scan_DVBC_QuickInstall_Init(void)
{
    u8NumOfVchFound = 0;

    if (FALSE == MApp_SI_Scan_Init())
        return FALSE;

    u16NumOfSrvAdd = 0;

    return TRUE;

}

static BOOLEAN _MApp_Scan_DVBC_QuickInstall_AddOneDTVPchVchs(void)
{
    SI_SHORT_DTV_CHANNEL_INFO *pastVirtualCh;
    SI_DTV_CHANNEL_INFO stDtvPgmData;
    SI_DTVPROGRAMID stDtvIDTable;
    MS_CABLE_PARAMETER desc;
    U16 u16RemainFreq;
    U8 u8NumOfVch;
    U8 u8Loop_1;
    U8 u8NumOfActiveCh = 0;
    MEMBER_SERVICETYPE eServiceType;
    WORD wPosition;
    BOOLEAN bFull, bResult;
    U8 au8NetWorkName[MAX_NETWORK_NAME];
    U8 len;

    u8NumOfVch = MApp_SI_GetScanNumOfPatItem();
    pastVirtualCh = MApp_SI_Get_PastVirtualCh();

    memset(&stDtvIDTable, 0, sizeof(stDtvIDTable));
    if (u8NumOfVch>0)
    {

        stDtvIDTable.wNetwork_ID = pastVirtualCh[0].wNetwork_ID;
        stDtvIDTable.wTransportStream_ID = pastVirtualCh[0].wTransportStream_ID;
        stDtvIDTable.wOriginalNetwork_ID = pastVirtualCh[0].wOriginalNetwork_ID;
        stDtvIDTable.cRFChannelNumber = INVALID_IDINDEX;
        msAPI_Tuner_Get_CELL_ID(&stDtvIDTable.wCellID);

        if (MApp_SI_GetNextCableParameter(&desc,NULL,NULL,NULL, &u16RemainFreq, TRUE))
        {
            stDtvIDTable.u32Frequency = desc.u32CentreFreq;
            stDtvIDTable.u32SymbRate = desc.u32Symbol_rate;
            stDtvIDTable.QamMode = desc.u8Modulation;
        }

        if ((TRUE == MApp_SI_Get_NetWorkName(au8NetWorkName,&len,MAX_NETWORK_NAME)) /*&& (0!=au8NetWorkName[0])*/)
        {
            msAPI_CM_SetCurrentNetworkName(au8NetWorkName, len);
        }

        SCAN_DBINFO(printf("@@@NID:%d, TSID:%d, ONID:%d, Freq:%lu, sym:%lu, qam:%d, NetworkName:%s\n",stDtvIDTable.wNetwork_ID,stDtvIDTable.wTransportStream_ID,
        stDtvIDTable.wOriginalNetwork_ID,stDtvIDTable.u32Frequency,stDtvIDTable.u32SymbRate,stDtvIDTable.QamMode,au8NetWorkName));

        msAPI_SI_AddProgramIDTable(&stDtvIDTable,&stDtvPgmData.bIDIdex);
        for(u8Loop_1=0; u8Loop_1<u8NumOfVch; u8Loop_1++)
        {
            MApp_SI_GetDtvPmgData(&pastVirtualCh[u8Loop_1], u8Loop_1, &stDtvPgmData);
            if( MApp_SI_Action_CheckServiceInfo( &stDtvPgmData ) == FALSE )
            {
                continue;
            }
            if(u8NumOfActiveCh != u8Loop_1)
            {
                memcpy(&pastVirtualCh[u8NumOfActiveCh], &pastVirtualCh[u8Loop_1], sizeof(SI_SHORT_DTV_CHANNEL_INFO));
            }

            pastVirtualCh[u8NumOfActiveCh].stCHAttribute.bServiceType = stDtvPgmData.stCHAttribute.bServiceType;

            if( TRUE != msAPI_CM_GetServiceTypeAndPositionWithPCN(stDtvPgmData.bIDIdex, stDtvPgmData.wService_ID, &eServiceType, &wPosition) )
            {
                stDtvPgmData.stCHAttribute.bIsServiceIdOnly = FALSE;////Inancb 02102009: do not show "INVALID SERVICE" popup when tuning the channel first time
                bResult = msAPI_SI_AddProgram(&stDtvIDTable, &stDtvPgmData,&bFull, FALSE);
            }
            else
            {
                MEMBER_SI_SERVICETYPE bType;
                bType=msAPI_SI_ToSI_Service_Type(eServiceType);
                bResult = msAPI_SI_UpdateQuickInstallProgram(bType, wPosition, &stDtvPgmData);
            }
            u8NumOfActiveCh++;
        }

        msAPI_SI_RemoveQuickInstallMismatchedProgram(pastVirtualCh, u8NumOfVch, stDtvPgmData.bIDIdex, msAPI_SI_ToSI_Service_Type(E_SERVICETYPE_DTV));
        msAPI_SI_RemoveQuickInstallMismatchedProgram(pastVirtualCh, u8NumOfVch, stDtvPgmData.bIDIdex, msAPI_SI_ToSI_Service_Type(E_SERVICETYPE_RADIO));
#if (NORDIG_FUNC)
        msAPI_SI_RemoveQuickInstallMismatchedProgram(pastVirtualCh, u8NumOfVch, stDtvPgmData.bIDIdex, msAPI_SI_ToSI_Service_Type(E_SERVICETYPE_DATA));
#endif
    }
    return bResult;
}

static void _MApp_Scan_DVBC_QuickInstall_RemoveMismatchedTS(void)
{
    U16 au16TsId[MAX_MUX_NUMBER];
    U8 u8TsIdNum;
    MApp_Dmx_DVBC_QuickInstallGetTsIDs(au16TsId, &u8TsIdNum, MAX_MUX_NUMBER);
    msAPI_CM_RemoveQuickInstallMismatchedTS(au16TsId, u8TsIdNum);
}

static void _MApp_Scan_DVBC_QuickInstall_End(void)
{
    MApp_SI_Scan_End();
    MApp_Epg_Init();
    MApp_EpgTimer_InitTimerSettings(TRUE);

    if(TRUE != msAPI_CM_ArrangeDataManager(TRUE, FALSE))
    {
        SCAN_DBINFO( printf( "msAPI_CM_ArrangeDataManager FAIL !! \n" ));
    }

#if ENABLE_SCAN_CM_DEBUG
    msAPI_CM_PrintAllProgram();
#endif
}

BOOLEAN MApp_Scan_DVBC_QuickInstall_GetProcessedFlag(void)
{
    return (_bQuickInstallProcessed)? TRUE : FALSE;
}

BOOLEAN MApp_Scan_DVBC_QuickInstall_ChList(void)
{
    DVBC_QUICK_INSTALL_CHLIST_STATE enQuickInstallState;
    DMX_DVBC_QUICK_INSTALL_RET_STATE enDmxScanTblRetState;
    BOOLEAN bContinue = TRUE;
    BOOLEAN retVal = FALSE;

    enQuickInstallState = QUICK_INSTALL_STATE_INIT;
    u8KeyCode = KEY_NULL;

    SCAN_DBINFO(printf("!!!!!!DVBC_QuickInstall Started!!!!!!\n"));

    while (bContinue)
    {
        if(_MApp_Scan_DVBC_QuickInstall_ProcessKey() == FALSE)
        {
            enQuickInstallState = QUICK_INSTALL_STATE_END;
            retVal = TRUE;
        }
        switch (enQuickInstallState)
        {
            case QUICK_INSTALL_STATE_INIT:
            {
                if (TRUE == _MApp_Scan_DVBC_QuickInstall_Init())
                {
                    MApp_Dmx_DVBC_QuickInstallStateInit();
                    enQuickInstallState = QUICK_INSTALL_STATE_SCAN_TABLE;
                }
                break;
            }
            case QUICK_INSTALL_STATE_SCAN_TABLE:
            {
                enDmxScanTblRetState = MApp_Dmx_DVBC_QuickInstallScanTables();
                switch (enDmxScanTblRetState)
                {
                    case DMX_QUICK_INSTALL_RET_STATE_UPDATE_CHLIST:
                    {
                        enQuickInstallState = QUICK_INSTALL_STATE_UPDATE_CHLIST;
                        break;
                    }
                    case DMX_QUICK_INSTALL_RET_STATE_REMOVE_MISSING_MUX:
                    {
                        enQuickInstallState = QUICK_INSTALL_STATE_REMOVE_MISSING_MUX;
                        break;
                    }
                    case DMX_QUICK_INSTALL_RET_STATE_END:
                    {
                        enQuickInstallState = QUICK_INSTALL_STATE_END;
                        break;
                    }
                    case DMX_QUICK_INSTALL_RET_STATE_NONE:
                    {
                        enQuickInstallState = QUICK_INSTALL_STATE_SCAN_TABLE;
                        break;
                    }
                    default:
                    {
                        enQuickInstallState = QUICK_INSTALL_STATE_END;
                        break;
                    }
                }
                break;
            }
            case QUICK_INSTALL_STATE_UPDATE_CHLIST:
            {
                _MApp_Scan_DVBC_QuickInstall_AddOneDTVPchVchs();
                enQuickInstallState = QUICK_INSTALL_STATE_SCAN_TABLE;
                break;
            }
            case QUICK_INSTALL_STATE_REMOVE_MISSING_MUX:
            {
                _MApp_Scan_DVBC_QuickInstall_RemoveMismatchedTS();
                enQuickInstallState = QUICK_INSTALL_STATE_END;
                break;
            }
            case QUICK_INSTALL_STATE_END:
            {
                _MApp_Scan_DVBC_QuickInstall_End();
                bContinue = FALSE;
                break;
            }
            default:
                break;
        }
    }
    SCAN_DBINFO(printf("!!!!!!DVBC_QuickInstall Finished!!!!!!\n"));
    return retVal;
}

#endif
#if NTV_FUNCTION_ENABLE
static U8 _bSelectFavoriteNetwork=INVALID_NETWORKINDEX;
void MApp_DTV_Scan_SetSelectFavoriteNetwork(U8 cNetworkIndex)
{
    _bSelectFavoriteNetwork=cNetworkIndex;
}
U8 MApp_DTV_Scan_GetSelectFavoriteNetwork(void)
{
    return _bSelectFavoriteNetwork;
}
void MApp_Set_ScanGoRegion_Status(BOOLEAN bStatus)
{
    bScanGoRegion = bStatus;
}
BOOLEAN MApp_Get_ScanGoRegion_Status(void)
{
    return bScanGoRegion;
}
#endif

#undef MAPP_SCAN_A_C

