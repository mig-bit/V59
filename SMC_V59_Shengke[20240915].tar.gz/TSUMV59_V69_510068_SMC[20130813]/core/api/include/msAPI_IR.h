////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (MStar Confidential Information!�L) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef MSAPI_IR_H
#define MSAPI_IR_H

#include "datatype.h"

#ifdef MSAPI_IR_C
#define INTERFACE
#else
#define INTERFACE extern
#endif

#ifdef __aeon__
INTERFACE void msAPI_IR_Callback(MS_U8 u8Key, MS_U8 u8Repeat);
INTERFACE void msAPI_KeyPad_Callback(MS_U8 u8Key, MS_U8 u8Repeat);
INTERFACE BOOLEAN msAPI_IR_Initialize(void);
INTERFACE BOOLEAN msAPI_KeyPad_Initialize(void);
#endif

#ifdef __mips__
INTERFACE BOOLEAN msAPI_IR_Initialize(void);
INTERFACE BOOLEAN msAPI_KeyPad_Initialize(void);
#endif

INTERFACE BOOLEAN msAPI_GetIRKey(U8 *u8key,U8 *u8Repstatus);
INTERFACE void msAPI_ClearIRFIFO(void);
INTERFACE BOOLEAN msAPI_GetKeyPad(U8 *u8key,U8 *u8Repstatus);
INTERFACE void msAPI_Key_PowerDown_Mode(U8 u8Mode);
INTERFACE void msAPI_Key_PowerResume(void);

INTERFACE void msAPI_EnableMBIR(BOOLEAN useMailBox);
INTERFACE BOOLEAN msAPI_IsMBIREnabled(void);

#undef INTERFACE

#endif

