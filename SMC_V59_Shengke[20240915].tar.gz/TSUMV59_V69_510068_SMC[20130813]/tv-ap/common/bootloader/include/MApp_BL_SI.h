#ifndef _MAPP_BL_SI_H_
#define _MAPP_BL_SI_H_

#define BL_PAT_MONITOR_PERIOD          2000    /* ms */
#define BL_PMT_MONITOR_PERIOD          500    /* ms */

#define BL_SI_MAX_VC_PER_PHYSICAL      70

// Error Check
#define BL_MAX_NUM_OF_CRC_ERROR    2

/******************************************************************************/
/*                     enum.                                 */
/******************************************************************************/
typedef enum
{
    EN_SI_PARSE_INIT,
    EN_SI_PARSE_WAIT_PAT_READY,
    EN_SI_PARSE_WAIT_ALL_PMT_READY,
}EN_SI_PARSE_STATE;

typedef enum
{
    EN_BL_FIRSTLOOP = 1,
    EN_BL_SECONDLOOP,
} EN_BL_LOOP_TYPE;

typedef enum
{
    EN_BL_PAT,
    EN_BL_PMT,
} EN_BL_PSIP_TABLE;

/* TABLE ID definition */
typedef enum
{
    // MPEG-2 table id
    BL_TID_PAS         = 0x00,             // program_association_section
    BL_TID_PMS         = 0x02,             // program_map_section
} EN_BL_PSIP_TID;

/* Stream Type */
typedef enum
{
    ST_BL_DSMCC_DATA_TYPE_A    = 0x0A,
    ST_BL_DSMCC_DATA_TYPE_B    = 0x0B,
    ST_BL_DSMCC_DATA_TYPE_C    = 0x0C,
    ST_BL_DSMCC_DATA_TYPE_D    = 0x0D,
    ST_BL_DSMCC_DATA_TYPE_E    = 0x0E,
    ST_BL_OP_MPEG2_VID         = 0x80,
} EN_BL_SI_STREAM_TYPE;

/* descriptor tag definition */
typedef enum
{
    TAG_BL_SID             = 0x52,         // stream_identifier_descriptor
    TAG_BL_DBID            = 0x66,            // data_broadcast_id_descriptor
}EN_BL_SI_TAG;

/******************************************************************************/
/*                     struct                                 */
/******************************************************************************/
typedef struct
{
    U8 u8NumOfPatItems;
    U16 u16ProgNum[BL_SI_MAX_VC_PER_PHYSICAL];
    U16 u16PmtPID[BL_SI_MAX_VC_PER_PHYSICAL];
}BL_SI_PAT_INFO;


/******************************************************************************/
/*                       Global Variable Declarations                         */
/******************************************************************************/
#ifdef MAPP_BL_SI_C
#define INTERFACE
#else
#define INTERFACE extern
#endif

/******************************************************************************/
/*                       Global Function Prototypes                           */
/******************************************************************************/
INTERFACE void MApp_BL_SI_PAT_Parse(U8 *pu8Section);
INTERFACE void MApp_BL_SI_PMT_Parse(U8 *pu8Section);
INTERFACE void MApp_BL_SI_Init(U32 u32BufferStart, U32 u32BufferSize);
INTERFACE void MApp_BL_SI_ParseStateInit(void);
INTERFACE void MApp_BL_SI_DisableTableMonitor(void);
INTERFACE BL_SI_PAT_INFO* MApp_BL_SI_GetPatScanInfo(void);
INTERFACE BOOLEAN MApp_BL_SI_Table_Monitor(void);
#undef INTERFACE
#endif

