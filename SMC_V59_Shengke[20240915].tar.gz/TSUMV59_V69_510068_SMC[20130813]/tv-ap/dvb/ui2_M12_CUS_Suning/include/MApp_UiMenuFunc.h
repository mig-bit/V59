////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////
#if ( ENABLE_ATV_VCHIP)
#include "MApp_VChip.h"
#endif
//#include "MApp_Scan_A.h"

#ifndef MAPP_UI_MENUFUNC_H
#define MAPP_UI_MENUFUNC_H

#ifdef MAPP_UI_MENUFUNC_C
#define INTERFACE
#else
#define INTERFACE extern
#endif
#if 0
INTERFACE BOOLEAN MApp_UiMenuFunc_CheckInputLock(void);
INTERFACE BOOLEAN MApp_UiMenuFunc_AdjustInputLockTV(void);
INTERFACE BOOLEAN MApp_UiMenuFunc_AdjustInputLockAV(void);
INTERFACE BOOLEAN MApp_UiMenuFunc_AdjustInputLockSV(void);
INTERFACE BOOLEAN MApp_UiMenuFunc_AdjustInputLockYPbPr(void);
INTERFACE BOOLEAN MApp_UiMenuFunc_AdjustInputLockSCART(void);
INTERFACE BOOLEAN MApp_UiMenuFunc_AdjustInputLockHDMI(void);
INTERFACE BOOLEAN MApp_UiMenuFunc_AdjustInputLockPC(void);
#endif

#if ( ENABLE_ATV_VCHIP)
INTERFACE BOOLEAN MApp_UiMenuFunc_AdjSystemLockMode(void);
INTERFACE BOOLEAN MApp_UiMenuFunc_GetRRT_OptionDescription(U8 u8DimensionIdx, U8 u8OptionIdx);
INTERFACE BOOLEAN MApp_UiMenuFunc_ToggleRRT_DimensionValues(U8 u8ValueIndex);
INTERFACE BOOLEAN MApp_UiMenuFunc_ResetRatingTable(void);
INTERFACE void MApp_UiMenuFunc_SaveCurrentRegion5Ratings(void);


INTERFACE BOOLEAN MApp_UiMenuFunc_SetVChip_Level(BOOLEAN action, EN_VCHIP_RATING_TYPE vchipPageType);
INTERFACE BOOLEAN MApp_UiMenuFunc_SetVChip_TVRating_TV_Y_ALL(void);
INTERFACE BOOLEAN MApp_UiMenuFunc_SetVChip_TVRating_TV_Y7_ALL(void);
INTERFACE BOOLEAN MApp_UiMenuFunc_SetVChip_TVRating_TV_G_ALL(void);
INTERFACE BOOLEAN MApp_UiMenuFunc_SetVChip_TVRating_TV_PG_ALL(void);
INTERFACE BOOLEAN MApp_UiMenuFunc_SetVChip_TVRating_TV_14_ALL(void);
INTERFACE BOOLEAN MApp_UiMenuFunc_SetVChip_TVRating_TV_MA_ALL(void);
INTERFACE BOOLEAN MApp_UiMenuFunc_SetVChip_TVRating_TV_Y7_FV(void);
INTERFACE BOOLEAN MApp_UiMenuFunc_SetVChip_TVRating_TV_PG_V(void);
INTERFACE BOOLEAN MApp_UiMenuFunc_SetVChip_TVRating_TV_14_V(void);
INTERFACE BOOLEAN MApp_UiMenuFunc_SetVChip_TVRating_TV_MA_V(void);
INTERFACE BOOLEAN MApp_UiMenuFunc_SetVChip_TVRating_TV_PG_S(void);
INTERFACE BOOLEAN MApp_UiMenuFunc_SetVChip_TVRating_TV_14_S(void);
INTERFACE BOOLEAN MApp_UiMenuFunc_SetVChip_TVRating_TV_MA_S(void);
INTERFACE BOOLEAN MApp_UiMenuFunc_SetVChip_TVRating_TV_PG_L(void);
INTERFACE BOOLEAN MApp_UiMenuFunc_SetVChip_TVRating_TV_14_L(void);
INTERFACE BOOLEAN MApp_UiMenuFunc_SetVChip_TVRating_TV_MA_L(void);
INTERFACE BOOLEAN MApp_UiMenuFunc_SetVChip_TVRating_TV_PG_D(void);
INTERFACE BOOLEAN MApp_UiMenuFunc_SetVChip_TVRating_TV_14_D(void);
INTERFACE BOOLEAN MApp_UiMenuFunc_CheckInputLock(void);
INTERFACE BOOLEAN MApp_UiMenuFunc_CheckInputLockAudioVideo(void);
// Factory Setting Functions..................
#endif //end of ENABLE_ATV_VCHIP
#undef INTERFACE
#endif
