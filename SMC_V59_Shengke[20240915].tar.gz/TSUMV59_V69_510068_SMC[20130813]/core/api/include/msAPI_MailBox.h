////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (MStar Confidential Information!�L) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef MSAPI_MAILBOX_H
#define MSAPI_MAILBOX_H

#include "drvMBX.h"

#ifdef _MSAPI_MAILBOX_C_
#define INTERFACE
#else
#define INTERFACE extern
#endif

//=============================================================================
// Defines & Macros
//=============================================================================
#define MM_COMMON_MBX_QUEUESIZE    10
#define MHEG5_COMMON_MBX_QUEUESIZE    10

//-------------------------------
// MB_CLASS_INPUT: shared by
// APEngine & MHeg5
//-------------------------------
typedef enum
{
    MB_INPUT_CMD_IR,
    MB_INPUT_CMD_KEYPAD,
    MB_INPUT_CMD_JOYSTICK,
    MB_INPUT_CMD_BIKE_IR

} MB_INPUT_CLASS;

//=============================================================================
INTERFACE MBX_Result MApi_MBX_SetInformation(MS_U8 *pU8Info, MS_U8 u8Size);
INTERFACE MBX_Result MApi_MBX_GetInformation(MS_U8 *pU8Info, MS_U8 u8Size);

INTERFACE MBX_Result MApi_MBX_Init(void);
INTERFACE MBX_Result MApi_MBX_DeInit(void);
INTERFACE MBX_Result MApi_MBX_Enable(MS_BOOL bEnable);

INTERFACE MBX_Result MApi_MBX_RegisterMSG(MBX_Class eMsgClass, MS_U16 u16MsgQueueSize);
INTERFACE MBX_Result MApi_MBX_RegisterMSGWithCallBack(MBX_Class eMsgClass, MS_U16 u16MsgQueueSize, MBX_MAIL_ARRIVE_NOTIFY_FUNC notifier);
INTERFACE MBX_Result MApi_MBX_UnRegisterMSG(MBX_Class eMsgClass);
INTERFACE MBX_Result MApi_MBX_GetMsgQueueStatus(MBX_Class eTargetClass, MBX_MSGQ_Status *pMsgQueueStatus);

INTERFACE MBX_Result MApi_MBX_SendMsg(MBX_Msg *pMsg);
INTERFACE MBX_Result MApi_MBX_RecvMsg(MBX_Class eTargetClass, MBX_Msg *pMsg, MS_U32 u32WaitMillSecs, MS_U32 u32Flag);
INTERFACE MBX_Result MApi_MBX_ClearMSG(MBX_Class eMsgClass);

#undef INTERFACE
#endif /* MSAPI_MAILBOX_H */

