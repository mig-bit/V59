////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////
#define MAPP_ZUI_ACTKTV_C
#define _ZUI_INTERNAL_INSIDE_ //NOTE: for ZUI internal

//-------------------------------------------------------------------------------------------------
// Include Files
//-------------------------------------------------------------------------------------------------
#include "MsCommon.h"
#ifdef ENABLE_KTV
#include "Board.h"
#include "datatype.h"
#include "apiXC.h"
#include "apiXC_Adc.h"
#include "ZUI_exefunc.h"
#include "ZUI_tables_h.inl"
#include "ZUI_bitmap_EnumIndex.h"
#include "OSDcp_String_EnumIndex.h"
#include "MApp_ZUI_Main.h"
#include "MApp_ZUI_APIcommon.h"
#include "MApp_ZUI_APIstrings.h"
#include "MApp_ZUI_APIwindow.h"
#include "MApp_ZUI_APIgdi.h"
#include "MApp_ZUI_APIcontrols.h"
#include "MApp_ZUI_APIcomponent.h"
#include "MApp_ZUI_APIstyletables.h"
#include "MApp_ZUI_APIalphatables.h"
#include "MApp_ZUI_APIdraw.h"
#include "MApp_ZUI_CTLslidebar.h"
#include "MApp_GlobalFunction.h"
#include "MApp_GlobalSettingSt.h"
#include "MApp_TV.h"
#include "MApp_KTV_Main.h"
#include "msAPI_Timer.h"
#include "MApp_MultiTasks.h"
#include "mapp_wma.h"
#include "msAPI_Memory.h"
#include "MApp_ZUI_ACTdmp.h"
#include "mapp_mplayer.h"
#include "MApp_DMP_Main.h"
#include "MApp_ZUI_ACTeffect.h"
#include "MApp_ZUI_ACTglobal.h"
#include "MApp_ZUI_ACTmainpage.h"
#include "MApp_ZUI_ACTKTV.h"
#include "MApp_SaveData.h"

#include "FSUtil.h"
#include "mapp_photo_display.h"

#define KTVACT_DBG(x) // x

/////////////////////////////////////////////////////////////////////
// Local Variable
extern BOOLEAN _MApp_ZUI_API_AllocateVarData(void);

static EN_KTV_UI_TYPE enKTVUiType = E_KTV_UI_NONE;
static EN_KTV_MSG_TYPE enKTVMsgType = E_KTV_MSG_NONE;
static EN_KTV_PLAY_STATE enKTVplayState = E_KTV_PLAY_NONE;
static U16 su16CurFilePageIdx = 0;
static U16 su16CurSelFilePageIdx = 0;
static U16 su16CurSelFileIdx = 0;
static U16 su16CurSelSubPageFilePageIdx = 0;
static U16 su16CurSelSubPageFileIdx = 0;
static BOOLEAN bIsOriginal = TRUE;
//static U8 u8AuidoType = 1;


#if ENABLE_MPLAYER_RECORD_DIR_ENTRY
static U16 su16FileIdxByDir[NUM_OF_MAX_DIRECTORY_DEPTH];
#endif

/////////////////////////////////////////////////////////////////////
// Local Function
static void _MApp_ZUI_ACT_KTV_InitSlideBarParam(void);
static void _MApp_ZUI_ACT_KTV_HandleUsbStatusChanged(void);
static void _MApp_ZUI_ACT_KTV_UIChangedHandle(EN_KTV_UI_TYPE enUiType);


void MApp_ZUI_ACT_AppShowKTV(void)
{
    HWND wnd;
    RECT rect;
    E_OSD_ID osd_id = E_OSD_KTV;

    g_GUI_WindowList = GetWindowListOfOsdTable(osd_id);
    g_GUI_WinDrawStyleList = GetWindowStyleOfOsdTable(osd_id);
    g_GUI_WindowPositionList = GetWindowPositionOfOsdTable(osd_id);
#if ZUI_ENABLE_ALPHATABLE
    g_GUI_WinAlphaDataList = GetWindowAlphaDataOfOsdTable(osd_id);
#endif
    HWND_MAX = GetWndMaxOfOsdTable(osd_id);
    OSDPAGE_BLENDING_ENABLE = IsBlendingEnabledOfOsdTable(osd_id);
    OSDPAGE_BLENDING_VALUE = GetBlendingValueOfOsdTable(osd_id);

    if (!_MApp_ZUI_API_AllocateVarData())
    {
        ZUI_DBG_FAIL(printf("[ZUI]ALLOC\n"));
        ABORT();
        return;
    }

    RECT_SET(rect,
        ZUI_KTV_XSTART, ZUI_KTV_YSTART,
        ZUI_KTV_WIDTH, ZUI_KTV_HEIGHT);

    if (!MApp_ZUI_API_InitGDI(&rect))
    {
        ZUI_DBG_FAIL(printf("[ZUI]GDIINIT\n"));
        ABORT();
        return;
    }

    for (wnd = 0; wnd < HWND_MAX; wnd++)
    {
        //printf("create msg: %lu\n", (U32)wnd);
        MApp_ZUI_API_SendMessage(wnd, MSG_CREATE, 0);
    }

    _MApp_ZUI_ACT_KTV_InitSlideBarParam();

    MApp_Photo_SlideShow(FALSE);
    enKTVUiType = E_KTV_UI_NONE;
    _MApp_ZUI_ACT_KTV_UIChangedHandle(E_KTV_UI_MAIN_PAGE);
}

void MApp_ZUI_ACT_TerminateKTV(void)
{
    ZUI_MSG( printf("[]term:tenkey\n");)
    //MApp_SaveGenSetting();
}

LPTSTR MApp_ZUI_ACT_GetKTVDynamicText(HWND hwnd)
{
    U16 u16TempID = Empty;

    memset((void *)CHAR_BUFFER, 0, sizeof(U16)*STRING_BUFFER_LENGTH);

    switch(hwnd)
    {
        case HWND_KTV_SELECT_SONG_DISK_ITEM1_TEXT:
        case HWND_KTV_SELECT_SONG_DISK_ITEM2_TEXT:
        case HWND_KTV_SELECT_SONG_DISK_ITEM3_TEXT:
        case HWND_KTV_SELECT_SONG_DISK_ITEM4_TEXT:
        case HWND_KTV_SELECT_SONG_DISK_ITEM5_TEXT:
        case HWND_KTV_SELECT_SONG_DISK_ITEM6_TEXT:
        case HWND_KTV_SELECT_SONG_DISK_ITEM7_TEXT:
        case HWND_KTV_SELECT_SONG_DISK_ITEM8_TEXT:
            MApp_ZUI_API_GetString(en_str_Disk);
            {
                U16 au8DrvId[6];

                au8DrvId[0] = 'C' + MApp_KTV_GetDriveFromMappingTable((hwnd-HWND_KTV_SELECT_SONG_DISK_ITEM1_TEXT)/(HWND_KTV_SELECT_SONG_DISK_ITEM2_TEXT-HWND_KTV_SELECT_SONG_DISK_ITEM1_TEXT));
                au8DrvId[1] = 0;
                au8DrvId[2] = 0x3A;
                au8DrvId[3] = 0;
                au8DrvId[4] = 0;
                au8DrvId[5] = 0;
                MApp_ZUI_API_Strcat(CHAR_BUFFER, au8DrvId);
            }
            return CHAR_BUFFER;

        case HWND_KTV_SELECT_SONG_FILES_ITEM1_TEXT:
        case HWND_KTV_SELECT_SONG_FILES_ITEM2_TEXT:
        case HWND_KTV_SELECT_SONG_FILES_ITEM3_TEXT:
        case HWND_KTV_SELECT_SONG_FILES_ITEM4_TEXT:
        case HWND_KTV_SELECT_SONG_FILES_ITEM5_TEXT:
        case HWND_KTV_SELECT_SONG_FILES_ITEM6_TEXT:
        case HWND_KTV_SELECT_SONG_FILES_ITEM7_TEXT:
        case HWND_KTV_SELECT_SONG_FILES_ITEM8_TEXT:
            {
                U8 u8ItemIdx = 0;
                MPlayerFileInfo fileInfo;

                u8ItemIdx = (hwnd-HWND_KTV_SELECT_SONG_FILES_ITEM1_TEXT)/(HWND_KTV_SELECT_SONG_FILES_ITEM2_TEXT-HWND_KTV_SELECT_SONG_FILES_ITEM1_TEXT);
                if((u8ItemIdx < KTV_FILES_NUM_PER_PAGE) &&
                    (MApp_MPlayer_QueryFileInfo(E_MPLAYER_INDEX_CURRENT_DIRECTORY, u8ItemIdx+su16CurFilePageIdx*KTV_FILES_NUM_PER_PAGE, &fileInfo) == E_MPLAYER_RET_OK))
                {
                    //printf("%d. EXT Name : %s\n", u16ItemIdx, fileInfo.u8ExtFileName);
                    if(fileInfo.eAttribute & E_MPLAYER_FILE_DIRECTORY)
                    {
                        if(fileInfo.u8LongFileName[0] == 0x2e &&
                            fileInfo.u8LongFileName[1] == 0x00 &&
                            fileInfo.u8LongFileName[2] == 0x00 &&
                            fileInfo.u8LongFileName[3] == 0x00)
                        {
                            return MApp_ZUI_API_GetString(en_str_DMP_Return);
                        }
                        else if(fileInfo.u8LongFileName[0] == 0x2e &&
                            fileInfo.u8LongFileName[1] == 0x00 &&
                            fileInfo.u8LongFileName[2] == 0x2e &&
                            fileInfo.u8LongFileName[3] == 0x00 &&
                            fileInfo.u8LongFileName[4] == 0x00)
                        {
                            return MApp_ZUI_API_GetString(en_str_DMP_UpFolderText);
                        }
                    }
                    memcpy(CHAR_BUFFER, fileInfo.u8LongFileName, sizeof(fileInfo.u8LongFileName));
                    return CHAR_BUFFER;
                }
            }
            break;

        case HWND_KTV_SELECT_SONG_SELECTED_ITEM1_TEXT:
        case HWND_KTV_SELECT_SONG_SELECTED_ITEM2_TEXT:
        case HWND_KTV_SELECT_SONG_SELECTED_ITEM3_TEXT:
        case HWND_KTV_SELECT_SONG_SELECTED_ITEM4_TEXT:
        case HWND_KTV_SELECT_SONG_SELECTED_ITEM5_TEXT:
        case HWND_KTV_SELECT_SONG_SELECTED_ITEM6_TEXT:
        case HWND_KTV_SELECT_SONG_SELECTED_ITEM7_TEXT:
        case HWND_KTV_SELECT_SONG_SELECTED_ITEM8_TEXT:
            {
                U8 u8ItemIdx = (hwnd-HWND_KTV_SELECT_SONG_SELECTED_ITEM1_TEXT)/(HWND_KTV_SELECT_SONG_SELECTED_ITEM2_TEXT-HWND_KTV_SELECT_SONG_SELECTED_ITEM1_TEXT);
                U16 u16FileIdx = u8ItemIdx+su16CurSelFilePageIdx*KTV_SELFILES_NUM_PER_PAGE;
                if(u16FileIdx < MApp_MPlayer_QuerySelectedFileNum(MApp_MPlayer_QueryCurrentMediaType()))
                {
                    MApp_MPlayer_QueryLongFilenameByPlayingIdx(u16FileIdx, (U8 *)CHAR_BUFFER, 0);
                    return CHAR_BUFFER;
                }
            }
            break;

        case HWND_KTV_SELECTED_SONG_SUBPAGE_ITEM1_TITLE:
        case HWND_KTV_SELECTED_SONG_SUBPAGE_ITEM2_TITLE:
        case HWND_KTV_SELECTED_SONG_SUBPAGE_ITEM3_TITLE:
        case HWND_KTV_SELECTED_SONG_SUBPAGE_ITEM4_TITLE:
        case HWND_KTV_SELECTED_SONG_SUBPAGE_ITEM5_TITLE:
        case HWND_KTV_SELECTED_SONG_SUBPAGE_ITEM6_TITLE:
        case HWND_KTV_SELECTED_SONG_SUBPAGE_ITEM7_TITLE:
        case HWND_KTV_SELECTED_SONG_SUBPAGE_ITEM8_TITLE:
            {
                U8 u8ItemIdx = (hwnd-HWND_KTV_SELECTED_SONG_SUBPAGE_ITEM1_TITLE)/(HWND_KTV_SELECTED_SONG_SUBPAGE_ITEM2_TITLE-HWND_KTV_SELECTED_SONG_SUBPAGE_ITEM1_TITLE);
                U16 u16FileIdx = u8ItemIdx+su16CurSelSubPageFilePageIdx*KTV_SELFILES_NUM_PER_PAGE;
                if(u16FileIdx < MApp_MPlayer_QuerySelectedFileNum(MApp_MPlayer_QueryCurrentMediaType()))
                {
                    MApp_MPlayer_QueryLongFilenameByPlayingIdx(u16FileIdx, (U8 *)CHAR_BUFFER, 0);
                    return CHAR_BUFFER;
                }
            }
            break;

        case HWND_KTV_SETTING_SUBPAGE_ITEM_ACC_VALUE:
            return MApp_ZUI_API_GetU16String(stGenSetting.g_SoundSetting.KTVBGVolume);

        case HWND_KTV_SETTING_SUBPAGE_ITEM_MIC_VALUE:
            return MApp_ZUI_API_GetU16String(stGenSetting.g_SoundSetting.KTVMicVolume);

        case HWND_KTV_SETTING_SUBPAGE_ITEM_MIX_VALUE:
            return MApp_ZUI_API_GetU16String(stGenSetting.g_SoundSetting.KTVMixVolume);

        case HWND_KTV_MESSAGE_BOX_TEXT1:
            if(enKTVMsgType == E_KTV_MSG_EXIT)
                u16TempID = en_str_KTV_exitbanner1;
            break;

        case HWND_KTV_MESSAGE_BOX_TEXT2:
            if(enKTVMsgType == E_KTV_MSG_ACC)
            {
                if(bIsOriginal)
                    u16TempID = en_str_KTV_Orig;
                else
                    u16TempID = en_str_KTV_Acc;
            }
            break;

        case HWND_KTV_MESSAGE_BOX_TEXT3:
            if(enKTVMsgType == E_KTV_MSG_EXIT)
                u16TempID = en_str_KTV_exitbanner2;
            break;

    }

    if (u16TempID != Empty)
        return MApp_ZUI_API_GetString(u16TempID);

    return NULL; //for empty string

}

S16 MApp_ZUI_ACT_GetKTVDynamicValue(HWND hwnd)
{
    switch(hwnd)
    {
        case HWND_KTV_SETTING_SUBPAGE_ITEM_ACC_SLIDE_BAR:
            return stGenSetting.g_SoundSetting.KTVBGVolume;
        case HWND_KTV_SETTING_SUBPAGE_ITEM_MIC_SLIDE_BAR:
            return stGenSetting.g_SoundSetting.KTVMicVolume;
        case HWND_KTV_SETTING_SUBPAGE_ITEM_MIX_SLIDE_BAR:
            return stGenSetting.g_SoundSetting.KTVMixVolume;

        default:
            break;
    }
    return 0; //for empty  data
}

U16 MApp_ZUI_ACT_GetKTVDynamicBitmap(HWND hwnd,DRAWSTYLE_TYPE ds_type)
{
    UNUSED(hwnd);
    UNUSED(ds_type);
    return 0xFFFF;
}

GUI_ENUM_DYNAMIC_LIST_STATE MApp_ZUI_ACT_QueryKTVItemStatus(HWND hwnd)
{
    switch(hwnd)
    {
        case HWND_KTV_SELECT_SONG_DISK_ITEM1:
        case HWND_KTV_SELECT_SONG_DISK_ITEM2:
        case HWND_KTV_SELECT_SONG_DISK_ITEM3:
        case HWND_KTV_SELECT_SONG_DISK_ITEM4:
        case HWND_KTV_SELECT_SONG_DISK_ITEM5:
        case HWND_KTV_SELECT_SONG_DISK_ITEM6:
        case HWND_KTV_SELECT_SONG_DISK_ITEM7:
        case HWND_KTV_SELECT_SONG_DISK_ITEM8:
            {
                U8 u8ItemIdx = (hwnd-HWND_KTV_SELECT_SONG_DISK_ITEM1)/(HWND_KTV_SELECT_SONG_DISK_ITEM2-HWND_KTV_SELECT_SONG_DISK_ITEM1);
                U8 u8CurDrivePageIdx = MApp_KTV_GetDrvPageIdx() - 1;
                U16 u16TotalDriveNum = MApp_MPlayer_QueryTotalDriveNum();
                if(MApp_MPlayer_QueryTotalDriveNum() > 0)
                {
                    if((u8CurDrivePageIdx*KTV_DRIVE_NUM_PER_PAGE+u8ItemIdx) < u16TotalDriveNum)
                        return EN_DL_STATE_NORMAL;
                    else
                        return EN_DL_STATE_HIDDEN;
                }
                else
                {
                    return EN_DL_STATE_HIDDEN;
                }
            }

        case HWND_KTV_SELECT_SONG_FILES_ITEM1:
        case HWND_KTV_SELECT_SONG_FILES_ITEM2:
        case HWND_KTV_SELECT_SONG_FILES_ITEM3:
        case HWND_KTV_SELECT_SONG_FILES_ITEM4:
        case HWND_KTV_SELECT_SONG_FILES_ITEM5:
        case HWND_KTV_SELECT_SONG_FILES_ITEM6:
        case HWND_KTV_SELECT_SONG_FILES_ITEM7:
        case HWND_KTV_SELECT_SONG_FILES_ITEM8:
            {
                U16 u16TotalFileNum = MApp_MPlayer_QueryTotalFileNum();
                if(u16TotalFileNum > 0)
                {
                    U8 u8ItemIdx = (hwnd-HWND_KTV_SELECT_SONG_FILES_ITEM1)/(HWND_KTV_SELECT_SONG_FILES_ITEM2-HWND_KTV_SELECT_SONG_FILES_ITEM1);
                    if((u8ItemIdx+su16CurFilePageIdx*KTV_FILES_NUM_PER_PAGE) < u16TotalFileNum)
                        return EN_DL_STATE_NORMAL;
                    else
                        return EN_DL_STATE_HIDDEN;
                }
                else
                {
                    return EN_DL_STATE_HIDDEN;
                }
            }

        case HWND_KTV_SELECT_SONG_SELECTED_ITEM1:
        case HWND_KTV_SELECT_SONG_SELECTED_ITEM2:
        case HWND_KTV_SELECT_SONG_SELECTED_ITEM3:
        case HWND_KTV_SELECT_SONG_SELECTED_ITEM4:
        case HWND_KTV_SELECT_SONG_SELECTED_ITEM5:
        case HWND_KTV_SELECT_SONG_SELECTED_ITEM6:
        case HWND_KTV_SELECT_SONG_SELECTED_ITEM7:
        case HWND_KTV_SELECT_SONG_SELECTED_ITEM8:
            {
                U16 u16TotalSelFileNum = MApp_MPlayer_QuerySelectedFileNum(MApp_MPlayer_QueryCurrentMediaType());

                printf("===> [KTV][Selected File Status]u16TotalFileNum[%d]\n", u16TotalSelFileNum);
                printf("===> [KTV][Selected File Status]su16CurSelFilePageIdx[%d]\n", su16CurSelFilePageIdx);

                if(u16TotalSelFileNum > 0)
                {
                    U8 u8ItemIdx = (hwnd-HWND_KTV_SELECT_SONG_SELECTED_ITEM1)/(HWND_KTV_SELECT_SONG_SELECTED_ITEM2-HWND_KTV_SELECT_SONG_SELECTED_ITEM1);
                    printf("===> [KTV][File Status]u8ItemIdx[%d]\n", u8ItemIdx);
                    if((u8ItemIdx+su16CurSelFilePageIdx*KTV_FILES_NUM_PER_PAGE) < u16TotalSelFileNum)
                        return EN_DL_STATE_NORMAL;
                    else
                        return EN_DL_STATE_HIDDEN;
                }
                else
                {
                    return EN_DL_STATE_NORMAL;
                }
            }

        case HWND_KTV_SELECTED_SONG_SUBPAGE_ITEM1:
        case HWND_KTV_SELECTED_SONG_SUBPAGE_ITEM2:
        case HWND_KTV_SELECTED_SONG_SUBPAGE_ITEM3:
        case HWND_KTV_SELECTED_SONG_SUBPAGE_ITEM4:
        case HWND_KTV_SELECTED_SONG_SUBPAGE_ITEM5:
        case HWND_KTV_SELECTED_SONG_SUBPAGE_ITEM6:
        case HWND_KTV_SELECTED_SONG_SUBPAGE_ITEM7:
        case HWND_KTV_SELECTED_SONG_SUBPAGE_ITEM8:
            {
                U16 u16TotalSelFileNum = MApp_MPlayer_QuerySelectedFileNum(MApp_MPlayer_QueryCurrentMediaType());

                if(u16TotalSelFileNum > 0)
                {
                    U8 u8ItemIdx = (hwnd-HWND_KTV_SELECTED_SONG_SUBPAGE_ITEM1)/(HWND_KTV_SELECTED_SONG_SUBPAGE_ITEM2-HWND_KTV_SELECTED_SONG_SUBPAGE_ITEM1);
                    printf("===> [KTV][File Status]u8ItemIdx[%d]\n", u8ItemIdx);
                    if((u8ItemIdx+su16CurSelSubPageFilePageIdx*KTV_FILES_NUM_PER_PAGE) < u16TotalSelFileNum)
                        return EN_DL_STATE_NORMAL;
                    else
                        return EN_DL_STATE_HIDDEN;
                }
                else
                {
                    return EN_DL_STATE_HIDDEN;
                }
            }


        default:
            break;
    }

    return EN_DL_STATE_HIDDEN;

}

static void _MApp_ZUI_ACT_KTV_InitSlideBarParam(void)
{
    DRAW_BITMAP stDrawBitmap;
    ST_SLIDEBAR_PARAM stParam;

    //set bitmap style
    stDrawBitmap.u16BitmapIndex = E_ZUI_BMP_MAX;
    stDrawBitmap.bSrcColorKey = FALSE;
    stDrawBitmap.srcColorKeyFrom = 0x0;
    stDrawBitmap.srcColorKeyEnd = 0x0;
    stDrawBitmap.u8Constant_Alpha = 0xFF;

    //set slide bar parameter
    stParam.bVertical = FALSE;
    stParam.enSlideBarStyle = E_SLIDEBAR_STYLE_L_M_R_CENTERBALL;
    stParam.pBitmapStyle = (void *)&stDrawBitmap;

    stParam.stLeft.width = 6;
    stParam.stLeft.height = 15;
    stParam.stLeft.stValue.enNormalIdx = E_BMP_KTV_BAR_LEFT_SEL;
    stParam.stLeft.stValue.enFocusIdx = E_BMP_KTV_BAR_LEFT_SEL;
    stParam.stLeft.stValue.enDisableIdx = E_BMP_KTV_BAR_LEFT_SEL;
    stParam.stLeft.stNonValue.enNormalIdx = E_BMP_KTV_BAR_LEFT_UNSEL;
    stParam.stLeft.stNonValue.enFocusIdx = E_BMP_KTV_BAR_LEFT_UNSEL;
    stParam.stLeft.stNonValue.enDisableIdx = E_BMP_KTV_BAR_LEFT_UNSEL;

    stParam.stMid.width = 3;
    stParam.stMid.height = 15;
    stParam.stMid.stValue.enNormalIdx = E_BMP_KTV_BAR_MID_SEL;
    stParam.stMid.stValue.enFocusIdx = E_BMP_KTV_BAR_MID_SEL;
    stParam.stMid.stValue.enDisableIdx = E_BMP_KTV_BAR_MID_SEL;
    stParam.stMid.stNonValue.enNormalIdx = E_BMP_KTV_BAR_MID_UNSEL;
    stParam.stMid.stNonValue.enFocusIdx = E_BMP_KTV_BAR_MID_UNSEL;
    stParam.stMid.stNonValue.enDisableIdx = E_BMP_KTV_BAR_MID_UNSEL;

    stParam.stRight.width = 6;
    stParam.stRight.height = 15;
    stParam.stRight.stValue.enNormalIdx = E_BMP_KTV_BAR_RIGHT_UNSEL;
    stParam.stRight.stValue.enFocusIdx = E_BMP_KTV_BAR_RIGHT_UNSEL;
    stParam.stRight.stValue.enDisableIdx = E_BMP_KTV_BAR_RIGHT_UNSEL;
    stParam.stRight.stNonValue.enNormalIdx = E_BMP_KTV_BAR_RIGHT_UNSEL;
    stParam.stRight.stNonValue.enFocusIdx = E_BMP_KTV_BAR_RIGHT_UNSEL;
    stParam.stRight.stNonValue.enDisableIdx = E_BMP_KTV_BAR_RIGHT_UNSEL;

    stParam.stCenterBall.width = 14;
    stParam.stCenterBall.height = 25;
    stParam.stCenterBall.stValue.enNormalIdx = E_BMP_KTV_BAR_CENTER;
    stParam.stCenterBall.stValue.enFocusIdx = E_BMP_KTV_BAR_CENTER;
    stParam.stCenterBall.stValue.enDisableIdx = E_BMP_KTV_BAR_CENTER;
    stParam.stCenterBall.stNonValue.enNormalIdx = E_BMP_KTV_BAR_CENTER;
    stParam.stCenterBall.stNonValue.enFocusIdx = E_BMP_KTV_BAR_CENTER;
    stParam.stCenterBall.stNonValue.enDisableIdx = E_BMP_KTV_BAR_CENTER;

    MApp_ZUI_CTL_SlideBarSetParam(stParam);    
}

static void _MApp_ZUI_ACT_KTV_HandleUsbStatusChanged(void)
{
    if(MApp_ZUI_GetActiveOSD() == E_OSD_MAIN_MENU
        || MApp_ZUI_GetActiveOSD() == E_OSD_INPUT_SOURCE)
    {
        MApp_KTV_Reset();
        if(MApp_KTV_RecalculateDriveMappingTable())
        {
            if(MApp_MPlayer_ConnectDrive(MApp_KTV_GetDriveFromMappingTable(MApp_KTV_GetCurDrvIdx())) == E_MPLAYER_RET_OK)
            {
                KTV_DBG(printf("[KTV][1] connect drive %d OK ^_^\n", (int)MApp_KTV_GetCurDrvIdx()));
                MApp_KTV_SetFlag(E_KTV_FLAG_DRIVE_CONNECT_OK);
                MApp_MPlayer_SetCurrentMediaType(E_MPLAYER_TYPE_MUSIC, TRUE);
                su16CurFilePageIdx = 0;
            }
        }
        else
        {
            MApp_KTV_ClearFlag(E_KTV_FLAG_DRIVE_CONNECT_OK);
            MApp_MPlayer_SetCurrentMediaType(E_MPLAYER_TYPE_MUSIC, FALSE);
            su16CurFilePageIdx = 0;
        }
        return;
    }

    if(MApp_KTV_RecalculateDriveMappingTable())
    {
        MApp_KTV_Reset();
        if(MApp_MPlayer_ConnectDrive(MApp_KTV_GetDriveFromMappingTable(MApp_KTV_GetCurDrvIdx())) == E_MPLAYER_RET_OK)
        {
            KTV_DBG(printf("[KTV][2] connect drive %d OK ^_^\n", (int)MApp_KTV_GetCurDrvIdx()));
            MApp_KTV_SetFlag(E_KTV_FLAG_DRIVE_CONNECT_OK);
            MApp_MPlayer_SetCurrentMediaType(E_MPLAYER_TYPE_MUSIC, TRUE);
            su16CurFilePageIdx = 0;
        }
        else
        {
            MApp_MPlayer_SetCurrentMediaType(E_MPLAYER_TYPE_MUSIC, FALSE);
            su16CurFilePageIdx = 0;
        }
    }
    else
    {
        if(MApp_KTV_GetFlag() & E_KTV_FLAG_MEDIA_FILE_PLAYING
            || MApp_KTV_GetFlag() & E_KTV_FLAG_BGM_MODE)
        {
            MApp_MPlayer_Stop();
            MApp_MPlayer_StopMusic();
        }
        MApp_KTV_LoadCOPRO();
        MApp_KTV_ClearFlag(E_KTV_FLAG_DRIVE_CONNECT_OK);
        MApp_KTV_ClearFlag(E_KTV_FLAG_MEDIA_FILE_PLAYING);
        MApp_KTV_ClearFlag(E_KTV_FLAG_BGM_MODE);
        MApp_KTV_Reset();
        MApp_MPlayer_SetCurrentMediaType(E_MPLAYER_TYPE_MUSIC, FALSE);
        su16CurFilePageIdx = 0;
    }
}

static void _MApp_ZUI_ACT_KTV_UIChangedHandle(EN_KTV_UI_TYPE enUiType)
{
    printf("===> [KTV][UI change]enKTVUiType [%d] --> [%d]\n", enKTVUiType, enUiType);
    switch(enKTVUiType)
    {
        case E_KTV_UI_MAIN_PAGE:
            if(enUiType == E_KTV_UI_SELECT_SONG_PAGE)
            {
                MApp_ZUI_API_ShowWindow(HWND_KTV_MAIN_PAGE, SW_HIDE);
                MApp_ZUI_API_ShowWindow(HWND_KTV_SELECT_SONG_PAGE, SW_SHOW);
                MApp_ZUI_API_SetFocus(HWND_KTV_SELECT_SONG_DISK_ITEM1);
            }
            else if(enUiType == E_KTV_UI_SELECTED_SONG_SUBPAGE)
            {
                if(MApp_MPlayer_QuerySelectedFileNum(MApp_MPlayer_QueryCurrentMediaType()) > 0)
                {
                    MApp_ZUI_API_ShowWindow(HWND_KTV_SELECTED_SONG_SUBPAGE, SW_SHOW);
                    MApp_ZUI_API_SetFocus(HWND_KTV_SELECTED_SONG_SUBPAGE_ITEM1_PRIORITY);
                }
                else
                {
                    enUiType = E_KTV_UI_MAIN_PAGE;
                }
            }
            else if(enUiType == E_KTV_UI_AAC_SUBPAGE)
            {
                enKTVMsgType = E_KTV_MSG_ACC;
                MApp_ZUI_API_ShowWindow(HWND_KTV_MESSAGE_BOX, SW_SHOW);
            }
            else if(enUiType == E_KTV_UI_SETTING_SUBPAGE)
            {
                MApp_ZUI_API_ShowWindow(HWND_KTV_SETTING_SUBPAGE, SW_SHOW);
                MApp_ZUI_API_SetFocus(HWND_KTV_SETTING_SUBPAGE_ITEM_ACC);
            }
            else if(enUiType == E_KTV_UI_EXIT_SUBPAGE)
            {
                enKTVMsgType = E_KTV_MSG_EXIT;
                MApp_ZUI_API_ShowWindow(HWND_KTV_MESSAGE_BOX, SW_SHOW);
                MApp_ZUI_API_SetFocus(HWND_KTV_MESSAGE_BOX);
            }
            enKTVUiType = enUiType;
            break;

        case E_KTV_UI_SELECT_SONG_PAGE:
            if(enUiType == E_KTV_UI_MAIN_PAGE)
            {
                MApp_ZUI_API_ShowWindow(HWND_KTV_SELECT_SONG_PAGE, SW_HIDE);
                MApp_ZUI_API_ShowWindow(HWND_KTV_MAIN_PAGE, SW_SHOW);
                MApp_ZUI_API_SetFocus(HWND_KTV_MAIN_PAGE_ITEM_SELECT_SONG);
            }
            enKTVUiType = enUiType;
            break;

        case E_KTV_UI_SELECTED_SONG_SUBPAGE:
            if(enUiType == E_KTV_UI_MAIN_PAGE)
            {
                MApp_ZUI_API_ShowWindow(HWND_KTV_SELECTED_SONG_SUBPAGE, SW_HIDE);
                MApp_ZUI_API_SetFocus(HWND_KTV_MAIN_PAGE_ITEM_SELECTED_SONG);
            }
            enKTVUiType = enUiType;
            break;

        case E_KTV_UI_AAC_SUBPAGE:
            if(enUiType == E_KTV_UI_MAIN_PAGE)
            {
                MApp_ZUI_API_ShowWindow(HWND_KTV_MESSAGE_BOX, SW_HIDE);
                MApp_ZUI_API_SetFocus(HWND_KTV_MAIN_PAGE_ITEM_ORIGACC);
            }
            else if(enUiType == E_KTV_UI_AAC_SUBPAGE)
            {
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_MESSAGE_BOX);
            }
            enKTVUiType = enUiType;
            break;

        case E_KTV_UI_SETTING_SUBPAGE:
            if(enUiType == E_KTV_UI_MAIN_PAGE)
            {
                MApp_ZUI_API_ShowWindow(HWND_KTV_SETTING_SUBPAGE, SW_HIDE);
                MApp_ZUI_API_SetFocus(HWND_KTV_MAIN_PAGE_ITEM_SETTING);
            }
            enKTVUiType = enUiType;
            break;

        case E_KTV_UI_EXIT_SUBPAGE:
            if(enUiType == E_KTV_UI_MAIN_PAGE)
            {
                MApp_ZUI_API_ShowWindow(HWND_KTV_MESSAGE_BOX, SW_HIDE);
                MApp_ZUI_API_SetFocus(HWND_KTV_MAIN_PAGE_ITEM_EXIT);
            }
            enKTVUiType = enUiType;
            enKTVMsgType = E_KTV_MSG_NONE;
            break;

        case E_KTV_UI_NONE:
        default:
            MApp_ZUI_API_ShowWindow(HWND_MAINFRAME,SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_KTV_BG, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_KTV_MAIN_PAGE, SW_SHOW);
            MApp_ZUI_API_SetFocus(HWND_KTV_MAIN_PAGE_ITEM_SELECT_SONG);
            enKTVUiType = E_KTV_UI_MAIN_PAGE;
            break;
    }
}

BOOLEAN MApp_UiMediaPlayer_KTV_Notify(enumMPlayerNotifyType eNotify, void *pInfo)
{
    UNUSED(pInfo);
    if (IsStorageInUse())
    {
        if (MApp_ZUI_GetActiveOSD() == E_OSD_KTV)
        {
            // notification accepted
        }
        else if (((MApp_ZUI_GetActiveOSD() == E_OSD_MAIN_MENU)
                        || (MApp_ZUI_GetActiveOSD() == E_OSD_INPUT_SOURCE))
                && ((eNotify == E_MPLAYER_NOTIFY_USB_DEVICE_STATUS_CHANGE)
                        || (eNotify == E_MPLAYER_NOTIFY_USB_ACTIVE_DEVICE_STATUS_CHANGE)
                        ||(eNotify == E_MPLAYER_NOTIFY_END_OF_PLAY_ALL_FILE)
                        ||(eNotify == E_MPLAYER_NOTIFY_END_OF_PLAY_ONE_FILE)
                        ||(eNotify == E_MPLAYER_NOTIFY_PLAY_NEXT_FILE)
                        ||(eNotify == E_MPLAYER_NOTIFY_PLAY_PREVIOUS_FILE)
                        ||(eNotify == E_MPLAYER_NOTIFY_ERROR_OF_PLAY_FILE)
                        ))
        {
            // notification accepted
        }
        #if 0
        else if((MApp_DMP_GetDMPStat()==DMP_STATE_RETURN_FROM_MENU)
                   &&((eNotify == E_MPLAYER_NOTIFY_ERROR_OF_PLAY_FILE)
                        ))
        {
            // notification accepted
        }
        #endif
        else
        {
            // notification not accepted
            // DMP_DBG(printf("Notification (%d) doesn't accept\n", eNotify));
            return FALSE;
        }
    }

    switch(eNotify)
    {
    #if ENABLE_DRM
        case E_MPLAYER_NOTIFY_DRM_INIT:
            break;
    #endif

        case E_MPLAYER_NOTIFY_USB_DEVICE_STATUS_CHANGE:
            KTV_DBG(printf("E_MPLAYER_NOTIFY_USB_DEVICE_STATUS_CHANGE\n"));
            break;

        case E_MPLAYER_NOTIFY_USB_ACTIVE_DEVICE_STATUS_CHANGE:
            KTV_DBG(printf("E_MPLAYER_NOTIFY_USB_ACTIVE_DEVICE_STATUS_CHANGE\n"));
            _MApp_ZUI_ACT_KTV_HandleUsbStatusChanged();
            break;

        case E_MPLAYER_NOTIFY_DRIVE_CHANGE:
            KTV_DBG(printf("E_MPLAYER_NOTIFY_DRIVE_CHANGE\n"));
            {
                if(MApp_KTV_RecalculateDriveMappingTable())
                {
                    MApp_KTV_SetFlag(E_KTV_FLAG_DRIVE_CONNECT_OK);
                    U8 i;
                    // Search previous mapped drive

                    for(i=0; i<NUM_OF_MAX_DRIVE; i++)
                    {
                        if(MApp_MPlayer_QueryCurrentDriveIndex() == MApp_KTV_GetDriveFromMappingTable(i))
                        {
                            MApp_KTV_SetCurDrvIdxAndCalPageIdx(i);
                        }
                        //printf("[Mappings] %bu. --> drive %bu\n", i, MApp_MediaPlayer_GetDriveFromMappingTable(i));
                    }

                    if(MApp_ZUI_GetActiveOSD() == E_OSD_MAIN_MENU
                        || MApp_ZUI_GetActiveOSD() == E_OSD_INPUT_SOURCE)
                    {
                        return FALSE;
                    }
                }
                else
                {
                    MApp_KTV_ClearFlag(E_KTV_FLAG_DRIVE_CONNECT_OK);
                    //MApp_DMP_UiStateTransition(DMP_UI_STATE_MEDIA_SELECT);
                    MApp_MPlayer_Stop(); // for bgm
                }
            }
            break;

        default:
            //KTV_DBG(printf("    - Unknown notify (%d)\n", (U16)eNotify));
            break;
    }
    return FALSE;
}

BOOLEAN MApp_ZUI_ACT_HandleKTVKey(VIRTUAL_KEY_CODE key)
{
    switch(key)
    {
        case VK_EXIT:
            if(enKTVUiType == E_KTV_UI_MAIN_PAGE)
            {
                _MApp_ZUI_ACT_KTV_UIChangedHandle(E_KTV_UI_EXIT_SUBPAGE);
                return TRUE;
            }
            else
            {
                _MApp_ZUI_ACT_KTV_UIChangedHandle(E_KTV_UI_MAIN_PAGE);
                return TRUE;
            }
            break;

        default:
            break;
    }

    return FALSE;
}

BOOLEAN MApp_ZUI_ACT_ExecuteKTVAction(U16 act)
{
    switch(act)
    {
        case EN_EXE_CLOSE_CURRENT_OSD:
        case EN_EXE_POWEROFF:
            MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
            return TRUE;

        case EN_EXE_KTV_GOTO_SELECT_SONG_PAGE:
            _MApp_ZUI_ACT_KTV_UIChangedHandle(E_KTV_UI_SELECT_SONG_PAGE);
            return TRUE;

        case EN_EXE_KTV_GOTO_SELECTED_SONG_SUBPAGE:
            _MApp_ZUI_ACT_KTV_UIChangedHandle(E_KTV_UI_SELECTED_SONG_SUBPAGE);
            return TRUE;

        case EN_EXE_KTV_GOTO_SETTING_SUBPAGE:
            _MApp_ZUI_ACT_KTV_UIChangedHandle(E_KTV_UI_SETTING_SUBPAGE);
            return TRUE;

#if 0
        case EN_EXE_KTV_EXIT:
            if(enKTVUiType == E_KTV_UI_EXIT_SUBPAGE)
                MApp_KTV_SetState(KTV_STATE_GOTO_PRESOURCE);
            else
                _MApp_ZUI_ACT_KTV_UIChangedHandle(E_KTV_UI_EXIT_SUBPAGE);
            return TRUE;
#endif

        case EN_EXE_KTV_GOTO_DRIVE:
            {
                U8 u8DrvIdx = MApp_KTV_GetCurDrvIdx();
                U8 u8ItemIdx = HWND_KTV_SELECT_SONG_DISK_ITEM1+(u8DrvIdx%KTV_DRIVE_NUM_PER_PAGE)*(HWND_KTV_SELECT_SONG_DISK_ITEM2-HWND_KTV_SELECT_SONG_DISK_ITEM1);
                MApp_ZUI_API_SetFocus(u8ItemIdx);
                return TRUE;
            }
            break;

        case EN_EXE_KTV_GOTO_FILES:
            {
                U16 u16FileIdx = MApp_MPlayer_QueryCurrentFileIndex(E_MPLAYER_INDEX_CURRENT_DIRECTORY);
                U8 u8ItemIdx = HWND_KTV_SELECT_SONG_FILES_ITEM1+(u16FileIdx%KTV_FILES_NUM_PER_PAGE)*(HWND_KTV_SELECT_SONG_FILES_ITEM2-HWND_KTV_SELECT_SONG_FILES_ITEM1);
                MApp_ZUI_API_SetFocus(u8ItemIdx);
                return TRUE;
            }
            break;

        case EN_EXE_KTV_GOTO_SELFILES:
            if(MApp_MPlayer_QuerySelectedFileNum(MApp_MPlayer_QueryCurrentMediaType()))
            {
                U8 u8ItemIdx = HWND_KTV_SELECT_SONG_SELECTED_ITEM1+(su16CurSelFileIdx%KTV_SELFILES_NUM_PER_PAGE)*(HWND_KTV_SELECT_SONG_SELECTED_ITEM2-HWND_KTV_SELECT_SONG_SELECTED_ITEM1);
                MApp_ZUI_API_SetFocus(u8ItemIdx);
                return TRUE;
            }
            break;

        case EN_EXE_KTV_DRIVE_SEL:
            {
                U8 u8Item = (MApp_ZUI_API_GetFocus()-HWND_KTV_SELECT_SONG_DISK_ITEM1)/(HWND_KTV_SELECT_SONG_DISK_ITEM2-HWND_KTV_SELECT_SONG_DISK_ITEM1);

                if(u8Item < KTV_DRIVE_NUM_PER_PAGE)
                {
                    U8 u8Idx = (MApp_KTV_GetDrvPageIdx()-1) * KTV_DRIVE_NUM_PER_PAGE + u8Item;
                    if(MApp_KTV_RecalculateDriveMappingTable())
                    {
                        if(MApp_MPlayer_ConnectDrive(MApp_KTV_GetDriveFromMappingTable(u8Idx)) == E_MPLAYER_RET_OK)
                        {
                            #if EN_DMP_SEARCH_ALL
                            MApp_MPlayer_GetAllFilesInCurDrive();
                            #endif

                            MApp_ZUI_API_SetFocus(HWND_KTV_SELECT_SONG_FILES_ITEM1);
                            MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_SELECT_SONG_FILES_LIST);
                            su16CurFilePageIdx = 0;
                        }
                    }
                    else
                    {
                        //Failed to connect drive, back to media type select page
                        MApp_KTV_ClearFlag(E_KTV_FLAG_DRIVE_CONNECT_OK);
                        _MApp_ZUI_ACT_KTV_UIChangedHandle(E_KTV_UI_MAIN_PAGE);
                    }
                }
            }
            return TRUE;

        case EN_EXE_KTV_DRIVE_UP:
            if ((HWND_KTV_SELECT_SONG_DISK_ITEM1==MApp_ZUI_API_GetFocus()) && (MApp_KTV_GetDrvPageIdx() <= 1))
            {
                return TRUE;
            }
            else
            {
                U8 u8Idx = MApp_KTV_GetCurDrvIdx();
                MApp_KTV_SetCurDrvIdxAndCalPageIdx(u8Idx - 1);
                if(HWND_KTV_SELECT_SONG_DISK_ITEM1 == MApp_ZUI_API_GetFocus())
                    MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_SELECT_SONG_DISK_LIST);
            }
            break;

        case EN_EXE_KTV_DRIVE_DOWN:
            if (MApp_MPlayer_QueryTotalDriveNum() == MApp_KTV_GetCurDrvIdx()+1)
            {
                return TRUE;
            }
            else
            {
                U8 u8Idx = MApp_KTV_GetCurDrvIdx();
                MApp_KTV_SetCurDrvIdxAndCalPageIdx(u8Idx + 1);
                if(HWND_KTV_SELECT_SONG_DISK_ITEM8 == MApp_ZUI_API_GetFocus())
                    MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_SELECT_SONG_DISK_LIST);
            }
            break;

        case EN_EXE_KTV_FILES_SEL:
            {
                U16 u16FileIdx = MApp_MPlayer_QueryCurrentFileIndex(E_MPLAYER_INDEX_CURRENT_DIRECTORY);
                MPlayerFileInfo fileInfo;

                if(MApp_MPlayer_QueryFileInfo(E_MPLAYER_INDEX_CURRENT_DIRECTORY,
                                              u16FileIdx,
                                              &fileInfo) == E_MPLAYER_RET_OK)
                {
                    if(fileInfo.eAttribute & E_MPLAYER_FILE_DIRECTORY)
                    {
                    #if ENABLE_MPLAYER_RECORD_DIR_ENTRY
                        U16 u16DirDepth = MApp_MPlayer_QueryDirectoryDepth();
                        if(!(u16DirDepth > 0 && u16FileIdx == 1))
                        {
                            //printf("Record DIR info ...\n");
                            su16FileIdxByDir[u16DirDepth] = u16FileIdx;
                        }
                    #endif

                        if(MApp_MPlayer_EnterDirectory(E_MPLAYER_INDEX_CURRENT_DIRECTORY,
                                                       u16FileIdx) == E_MPLAYER_RET_OK)
                        {
                            MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_SELECT_SONG_FILES_LIST);
                        #if ENABLE_MPLAYER_RECORD_DIR_ENTRY
                            if(u16DirDepth > 0 && u16FileIdx == 1)
                            {//Go to prev. directory...
                                //printf("Go to prev. directory ... (idx = %d)\n", _u16FileIdxByDir[MApp_MPlayer_QueryDirectoryDepth()]);
                                U8 u8CurItemIdx = HWND_KTV_SELECT_SONG_FILES_ITEM1+(su16FileIdxByDir[MApp_MPlayer_QueryDirectoryDepth()]%KTV_FILES_NUM_PER_PAGE)*(HWND_KTV_SELECT_SONG_FILES_ITEM2-HWND_KTV_SELECT_SONG_FILES_ITEM1);
                                MApp_MPlayer_SetCurrentFile(E_MPLAYER_INDEX_CURRENT_DIRECTORY, su16FileIdxByDir[MApp_MPlayer_QueryDirectoryDepth()]);
                                su16CurFilePageIdx = su16FileIdxByDir[MApp_MPlayer_QueryDirectoryDepth()]/KTV_FILES_NUM_PER_PAGE;
                                MApp_ZUI_API_SetFocus(u8CurItemIdx);
                            }
                            else
                        #endif
                            {
                                MApp_ZUI_API_SetFocus(HWND_KTV_SELECT_SONG_FILES_ITEM1);
                            }
                        }
                    }
                    else
                    {
                        #if 0
                        if(fileInfo.eAttribute & E_MPLAYER_FILE_SELECT)
                        {
                            MApp_MPlayer_SetFileUnselected(E_MPLAYER_INDEX_CURRENT_DIRECTORY, u16FileIdx);
                            //MApp_ZUI_CTL_DynamicListRefreshContent(HWND_KTV_MAIN_RIGHT_LIST);
                            MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_SELECT_SONG_SELECTED_LIST);
                        }
                        else
                        {
                            MApp_MPlayer_SetFileSelected(E_MPLAYER_INDEX_CURRENT_DIRECTORY, u16FileIdx);
                            //MApp_ZUI_CTL_DynamicListRefreshContent(HWND_KTV_MAIN_RIGHT_LIST);
                            MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_SELECT_SONG_SELECTED_LIST);
                        }
                        #endif
                        MApp_MPlayer_KTV_AddFile2PlayList();
                        if(MApp_MPlayer_QuerySelectedFileNum(MApp_MPlayer_QueryCurrentMediaType()) == 1)
                        {
                            // check if there is files need to be played
                            // put some initial variable or initial call before mapp_mplayer_play
                            // TODO: set this flag earlier!!! care this
                            MApp_KTV_ClearFlag(E_KTV_FLAG_MEDIA_FILE_PLAYING);
                            MApp_KTV_ClearFlag(E_KTV_FLAG_MEDIA_FILE_PLAYING_ERROR);
                            MApp_KTV_SetFlag(E_KTV_FLAG_MEDIA_FILE_PLAYING);
                            MApp_MPlayer_SetPlayMode(E_MPLAYER_PLAY_SELECTED_FROM_CURRENT);
                            MApp_MPlayer_Play();
                            enKTVplayState = E_KTV_PLAY_LOADING;
                        }
                        MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_SELECT_SONG_SELECTED_LIST);
                    }
                    return TRUE;
                }
                else
                {
                    printf("===> [KTV][Files Sel]error!!!");
                }
            }
            break;

        case EN_EXE_KTV_FILES_UP:
            {
                U16 u16FileIdx = MApp_MPlayer_QueryCurrentFileIndex(E_MPLAYER_INDEX_CURRENT_DIRECTORY);
                HWND curhwnd = MApp_ZUI_API_GetFocus();
                if(u16FileIdx > 0)
                {
                    u16FileIdx--;
                    MApp_MPlayer_SetCurrentFile(E_MPLAYER_INDEX_CURRENT_DIRECTORY, u16FileIdx);
                    if(curhwnd == HWND_KTV_SELECT_SONG_FILES_ITEM1)
                    {
                        su16CurFilePageIdx = u16FileIdx/KTV_FILES_NUM_PER_PAGE;
                        MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_SELECT_SONG_FILES_LIST);
                    }
                }
                else
                {
                    return TRUE;
                }
            }
            break;

        case EN_EXE_KTV_FILES_DOWN:
            {
                U16 u16FileIdx = MApp_MPlayer_QueryCurrentFileIndex(E_MPLAYER_INDEX_CURRENT_DIRECTORY);
                U16 u16TotalFile = MApp_MPlayer_QueryTotalFileNum() - 1;
                if(u16FileIdx < u16TotalFile)
                {
                    u16FileIdx++;
                    MApp_MPlayer_SetCurrentFile(E_MPLAYER_INDEX_CURRENT_DIRECTORY, u16FileIdx);
                    if(MApp_ZUI_API_GetFocus() == HWND_KTV_SELECT_SONG_FILES_ITEM8)
                    {
                        su16CurFilePageIdx = u16FileIdx/KTV_FILES_NUM_PER_PAGE;
                        MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_SELECT_SONG_FILES_LIST);
                    }
                }
                else
                {
                    return TRUE;
                }
            }
            break;

        case EN_EXE_KTV_SELFILES_UP:
            {
                if(su16CurSelFileIdx > 0)
                {
                    su16CurSelFileIdx--;
                    if(MApp_ZUI_API_GetFocus() == HWND_KTV_SELECT_SONG_SELECTED_ITEM1)
                    {
                        su16CurSelFilePageIdx = su16CurSelFileIdx/KTV_FILES_NUM_PER_PAGE;
                        MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_SELECT_SONG_SELECTED_LIST);
                    }
                }
                else
                {
                    return TRUE;
                }
            }
            break;

        case EN_EXE_KTV_SELFILES_DOWN:
            {
                U16 u16TotalSelFile = MApp_MPlayer_QuerySelectedFileNum(MApp_MPlayer_QueryCurrentMediaType()) - 1;
                if(su16CurSelFileIdx < u16TotalSelFile)
                {
                    su16CurSelFileIdx++;
                    if(MApp_ZUI_API_GetFocus() == HWND_KTV_SELECT_SONG_SELECTED_ITEM8)
                    {
                        su16CurSelFilePageIdx = su16CurSelFileIdx/KTV_FILES_NUM_PER_PAGE;
                        MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_SELECT_SONG_SELECTED_LIST);
                    }
                }
                else
                {
                    return TRUE;
                }
            }
            break;

        case EN_EXE_KTV_SELECTED_SUBPAGE_UP:
            {
                if(su16CurSelSubPageFileIdx > 0)
                {
                    su16CurSelSubPageFileIdx--;
                    if((MApp_ZUI_API_GetFocus() == HWND_KTV_SELECTED_SONG_SUBPAGE_ITEM1_PRIORITY)
                        || (MApp_ZUI_API_GetFocus() == HWND_KTV_SELECTED_SONG_SUBPAGE_ITEM1_DELETE))
                    {
                        su16CurSelSubPageFilePageIdx = su16CurSelSubPageFileIdx/KTV_FILES_NUM_PER_PAGE;
                        MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_SELECTED_SONG_SUBPAGE_LIST);
                    }
                }
                else
                {
                    return TRUE;
                }
            }
            break;

        case EN_EXE_KTV_SELECTED_SUBPAGE_DOWN:
            {
                U16 u16TotalSelFile = MApp_MPlayer_QuerySelectedFileNum(MApp_MPlayer_QueryCurrentMediaType()) - 1;
                if(su16CurSelSubPageFileIdx < u16TotalSelFile)
                {
                    su16CurSelSubPageFileIdx++;
                    if((MApp_ZUI_API_GetFocus() == HWND_KTV_SELECTED_SONG_SUBPAGE_ITEM8_PRIORITY)
                        || (MApp_ZUI_API_GetFocus() == HWND_KTV_SELECTED_SONG_SUBPAGE_ITEM8_DELETE))
                    {
                        su16CurSelSubPageFilePageIdx = su16CurSelSubPageFileIdx/KTV_FILES_NUM_PER_PAGE;
                        MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_SELECTED_SONG_SUBPAGE_LIST);
                    }
                }
                else
                {
                    return TRUE;
                }
            }
            break;

        case EN_EXE_KTV_SELECTED_SUBPAGE_PRIORITY_SEL:
            printf("===> [KTV][PRIORITY_SEL]u16FileIdx[%d]\n", su16CurSelSubPageFileIdx);
            if(MApp_MPlayer_KTV_FilePrioritySet(su16CurSelSubPageFileIdx))
            {
                su16CurSelSubPageFileIdx = 1;
                su16CurSelSubPageFilePageIdx = 0;
                MApp_ZUI_API_SetFocus(HWND_KTV_SELECTED_SONG_SUBPAGE_ITEM2_PRIORITY);
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_SELECTED_SONG_SUBPAGE_LIST);
            }
            return TRUE;

        case EN_EXE_KTV_SELECTED_SUBPAGE_DELETE_SEL:
            if(MApp_MPlayer_KTV_DeleteFile(su16CurSelSubPageFileIdx))
            {
                su16CurSelSubPageFileIdx = 1;
                su16CurSelSubPageFilePageIdx = 0;
                MApp_ZUI_API_SetFocus(HWND_KTV_SELECTED_SONG_SUBPAGE_ITEM2_PRIORITY);
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_SELECTED_SONG_SUBPAGE_LIST);
            }
            return TRUE;

        case EN_EXE_KTV_EXE_ACC:
            {
                bIsOriginal = !bIsOriginal;

                #if 0
                if (u8AuidoType == 1)//left 
                {
                    if(bIsOrigal)
                    {
                        MApi_AUDIO_SetMpegInfo(Audio_MPEG_infoType_SoundMode, 0, 0);
                    }
                    else
                    {
                        //MApi_AUDIO_SetCommAudioInfo(Audio_Comm_infoType_SoundMode, 0, 0);
                        MApi_AUDIO_SetMpegInfo(Audio_MPEG_infoType_SoundMode, 2, 0 );
                    }
                }
                else // if (u8AuidoType == 2) //right
                #endif
                {
                    if(bIsOriginal)
                    {
                        MApi_AUDIO_SetMpegInfo(Audio_MPEG_infoType_SoundMode, 1, 0);
                    }
                    else
                    {
                        MApi_AUDIO_SetMpegInfo(Audio_MPEG_infoType_SoundMode, 2, 0 );
                    }
                }

                printf("\n-----bIsOriginal = %d\n",bIsOriginal);
                _MApp_ZUI_ACT_KTV_UIChangedHandle(E_KTV_UI_AAC_SUBPAGE);
            }
            return TRUE;

        case EN_EXE_KTV_INC_ACC_VOLUME:
        case EN_EXE_KTV_DEC_ACC_VOLUME:
            stGenSetting.g_SoundSetting.KTVBGVolume = 
                MApp_ZUI_ACT_DecIncValue(act==EN_EXE_KTV_INC_ACC_VOLUME,
                    stGenSetting.g_SoundSetting.KTVBGVolume, 0, 100, 1);
            MApp_KTV_SetBGVolume(stGenSetting.g_SoundSetting.KTVBGVolume);
            MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_SETTING_SUBPAGE_ITEM_ACC);
            return TRUE;

        case EN_EXE_KTV_INC_MIC_VOLUME:
        case EN_EXE_KTV_DEC_MIC_VOLUME:
            stGenSetting.g_SoundSetting.KTVMicVolume = 
                MApp_ZUI_ACT_DecIncValue(act==EN_EXE_KTV_INC_MIC_VOLUME,
                    stGenSetting.g_SoundSetting.KTVMicVolume, 0, 100, 1);
            MApp_KTV_SetMicVolume(stGenSetting.g_SoundSetting.KTVMicVolume);
            MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_SETTING_SUBPAGE_ITEM_MIC);
            return TRUE;

        case EN_EXE_KTV_INC_MIX_VOLUME:
        case EN_EXE_KTV_DEC_MIX_VOLUME:
            stGenSetting.g_SoundSetting.KTVMixVolume = 
                MApp_ZUI_ACT_DecIncValue(act==EN_EXE_KTV_INC_MIX_VOLUME,
                    stGenSetting.g_SoundSetting.KTVMixVolume, 0, 100, 1);
            MApp_KTV_SetMixVolume(stGenSetting.g_SoundSetting.KTVMixVolume);
            MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_SETTING_SUBPAGE_ITEM_MIX);
            return TRUE;

        case EN_EXE_KTV_MSG_SEL:
            if(enKTVMsgType == E_KTV_MSG_EXIT)
                MApp_KTV_SetState(KTV_STATE_GOTO_PRESOURCE);
            return TRUE;




#if 0
        case EN_EXE_KTV_DEC_MICVOLUME:
        case EN_EXE_KTV_INC_MICVOLUME:
            if(act == EN_EXE_KTV_INC_MICVOLUME)
            {
                if ( stGenSetting.g_SoundSetting.KTVMicVolume < MAX_NUM_OF_KTVBG_VOL_LEVEL )
                    stGenSetting.g_SoundSetting.KTVMicVolume++;
            }
            else
            {
                if ( stGenSetting.g_SoundSetting.KTVMicVolume > 0 )
                    stGenSetting.g_SoundSetting.KTVMicVolume--;
            }
            _MApp_E_KTV_SetMicVolume(stGenSetting.g_SoundSetting.KTVMicVolume);
            MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_SET_MICORPHONE_VOLUME);
            MApp_SaveSoundSetting();
            return TRUE;

        case EN_EXE_KTV_DEC_MIXVOLUME:
        case EN_EXE_KTV_INC_MIXVOLUME:
            if(act == EN_EXE_KTV_INC_MIXVOLUME)
            {
                if ( stGenSetting.g_SoundSetting.MixVolume < MAX_NUM_OF_KTVMIX_VOL_LEVEL )
                    stGenSetting.g_SoundSetting.MixVolume++;
            }
            else
            {
                if ( stGenSetting.g_SoundSetting.MixVolume > 0 )
                    stGenSetting.g_SoundSetting.MixVolume--;
            }

            if(stGenSetting.g_SoundSetting.MixVolume == 0)
                MApi_AUDIO_EnableSurround(FALSE);
            else
                MApi_AUDIO_EnableSurround(TRUE);

            _MApp_E_KTV_SetMixVolume(stGenSetting.g_SoundSetting.MixVolume);
            MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_SET_MIX_VOLUME);
            MApp_SaveSoundSetting();
            return TRUE;

        case EN_EXE_KTV_SET_AUDIOTYPE:
            {
//				if(u8AuidoType == 2)
//				{
//					u8AuidoType = 0;
//				}
//				else
//				{
//					u8AuidoType++;
//				}

//				printf("\n======u8AuidoType = %d ======\n",u8AuidoType);
//				if (u8AuidoType == 0)
//				{
//					//MApi_AUDIO_SetCommAudioInfo(Audio_Comm_infoType_SoundMode, 0, 0);
//				}
//				else if (u8AuidoType == 1)
//				{
//					//MApi_AUDIO_SetCommAudioInfo(Audio_Comm_infoType_SoundMode, 2, 0);
//					MApi_AUDIO_SetMpegInfo(Audio_MPEG_infoType_SoundMode, 1, 0);
//				}
//				else if (u8AuidoType == 2)
//				{
//					//MApi_AUDIO_SetCommAudioInfo(Audio_Comm_infoType_SoundMode, 1, 0);
//					MApi_AUDIO_SetMpegInfo(Audio_MPEG_infoType_SoundMode, 0, 0);
//				}

                bIsOrigal = !bIsOrigal;

                if (u8AuidoType == 1)//left
                {
                    if(bIsOrigal)
                    {
                        MApi_AUDIO_SetMpegInfo(Audio_MPEG_infoType_SoundMode, 0, 0);
                    }
                    else
                    {
                        //MApi_AUDIO_SetCommAudioInfo(Audio_Comm_infoType_SoundMode, 0, 0);
                        MApi_AUDIO_SetMpegInfo(Audio_MPEG_infoType_SoundMode, 2, 0 );
                    }
                }
                else // if (u8AuidoType == 2) //right
                {
                    if(bIsOrigal)
                    {
                        MApi_AUDIO_SetMpegInfo(Audio_MPEG_infoType_SoundMode, 1, 0);
                    }
                    else
                    {
                        //MApi_AUDIO_SetCommAudioInfo(Audio_Comm_infoType_SoundMode, 0, 0);
                        MApi_AUDIO_SetMpegInfo(Audio_MPEG_infoType_SoundMode, 2, 0 );
                    }
                }

                printf("\n-----bIsOrigal = %d\n",bIsOrigal);
                MApp_ZUI_API_ShowWindow(HWND_KTV_MESSAGE_BOX,SW_SHOW);
            }
            return TRUE;

        case EN_EXE_KTV_SET_BEST:
            {
                msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_BYUSER_MUTEOFF, E_AUDIOMUTESOURCE_ACTIVESOURCE);
                MApp_UiMenu_MuteWin_Hide();
                stGenSetting.g_SoundSetting.BGVolume = SET_BEST_BGVOLUME;
                stGenSetting.g_SoundSetting.KTVMicVolume = SET_BEST_MICVOLUME;
                stGenSetting.g_SoundSetting.MixVolume = SET_BEST_MIXVOLUME;
                MApp_KTV_SetBGVolume(stGenSetting.g_SoundSetting.BGVolume);
                MApp_KTV_SetMicVolume(stGenSetting.g_SoundSetting.KTVMicVolume);
                MApp_KTV_SetMixVolume(stGenSetting.g_SoundSetting.MixVolume);
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_SET_ACC_VOLUME);
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_SET_MICORPHONE_VOLUME);
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_SET_MIX_VOLUME);
            }
            return TRUE;

        case EN_EXE_KTV_PLAY_NEXT:
            {
                TOrderInfo pstOrderSong;
                //delete playing song

                if(0 == KLM_GetOrderNum())
                {
                    if((!MApp_ZUI_API_IsWindowVisible(HWND_KTV_ERROR_INFO_PAGE))
                        &&(!MApp_ZUI_API_IsWindowVisible(HWND_KTV_SET_BANNER))
                        &&(!MApp_ZUI_API_IsWindowVisible(HWND_KTV_SEL_BANNER)))
                    {
                        hwndPrevFocus = MApp_ZUI_API_GetFocus();
                    }
                    //error   the last file zd 20101217
                    //				printf("\n------last song------\n");
                    enKTVErrorInfo = EN_KTV_ERROR_LAST_SONG;
                    MApp_ZUI_ACT_ShowErrorPage();
                    MApp_ZUI_API_ShowWindow(HWND_KTV_LRC_SONGNAME,SW_HIDE);
                    if(IsOpenLrc)
                    {
                        MApp_ZUI_ACT_Endlrc();
                    }
                    return TRUE;
                }
                else
                {
                    if(!MApp_ZUI_API_IsWindowVisible(HWND_KTV_ERROR_INFO_PAGE))
                    {
                        MApp_ZUI_API_ShowWindow(HWND_KTV_MESSAGE_BOX,SW_SHOW);
                    }
                    //get next song
                    //				MApp_ZUI_ACT_DeletePlay();
                    MApp_ZUI_API_ShowWindow(HWND_KTV_LRC_SONGNAME,SW_HIDE);
                    if(IsOpenLrc)
                    {
                        MApp_ZUI_ACT_Endlrc();
                    }
                    MApp_ZUI_ACT_GetKTVOrderSongInfo(&pstOrderSong,0);
                    MApp_ZUI_ACTPlayFile(pstOrderSong);
                }
                }
        return TRUE;
#endif
    }
    return FALSE;
}




#if 0
typedef struct
{
	U32 u32SingSortId;
	char aClassName[40];
}SINGER_SORT_INFO;

typedef struct
{
	U32 u32SingerSortId;
	U32 u32SingListId;
	char cSingerName[40];
}SINGER_LIST_INFO;

typedef struct
{
	U32 u32SongNum;
	U16 u16IsOrgin;
	U16 u16FileType;
	U16 u16ClassId;
	U16 u16SongCount;
	U16 u16LangId;
	U32 u32SingerListId;
	char cSongName[40];
	char cSingerName[40];
	char cSongPath[192];
}SONG_LIST_INFO;

typedef struct
{
    U16 u16SongCount;
    char cSongCountDesc[20];
}SONG_COUNT_INFO;

typedef struct
{
    U16 u16SongSortId;
    char cSongSortName[40];
}SONG_SORT_INFO;

typedef struct
{
    U16 u16LangId;
    char cLangType[20];
}LANG_SORT_INFO;

typedef struct
{
    U16 u16MediaType;
    char cFileName[256];
}MEDIA_FILE_INFO;

typedef enum
{
	EN_SINGER_SORT,				//�����б�
	EN_SINGER_LIST,				//�����б�
	EN_SONG_LIST,				//�����б�
	EN_CHARACTER_SORT,			//�����б�
	EN_SONG_REFER2_CHARACT,		//N�ָ��б�
	EN_LANGUAGE_SORT,			//�����б�
	EN_SONG_REFER2_LANGUAGE,	//���ָ����б�
	EN_SONG_SORT,         		//�����б�
	EN_SONG_REFER2_SORT,		//���ָ����б�
	EN_SONG_PINYIN,				//ƴ���б�
	EN_SONG_BY_DISK,			//�����б�
}DBF_FILE_INFO;

typedef enum
{
    EN_KTV_ERROR_NULL,
	EN_KTV_ERROR_INSERT_USB,
	EN_KTV_ERROR_LAST_SONG,
	EN_KTV_ERROR_PLAY_ALL,
	EN_KTV_ERROR_NO_FILE,
	EN_KTV_ERROR_MORE_20_SONGNUM,
	EN_KTV_ERROR_UNSUPPORT_FILE,
}KTV_ERROR_INFO;

//HWND myhwnd;
//////////////////////////////////////////////////////////

static U8 _u8KFbId=0xFF;
static RECT _stKrcRect = {0x00,0x00,0x00,0x00};
static U16 u_u16TargetWidth = 0x00;
static U16 u_u16PreTargetWidth = 0x00;
static BOOLEAN _bKrcFlag = FALSE;
static U32 _u32KrcTimerCounter = 0x00;


//static IRecordSetBase * pRecordSet = NULL;
static DBF_FILE_INFO eDBFFileInfo = EN_SINGER_SORT;
static HWND hwndCurFocus;
static HWND hwndPrevLeftFocus;
static HWND hwndPrevFocus;
//static TLyricLine LyricLien;
//static TLyricLine LyricLien2;
static BOOLEAN MApp_ZUI_ACT_OpenKTVLrc(const U8 * aFilePath,U16 FileLen);
//static BOOLEAN MApp_ZUI_ACT_GetKTVLrc(TLyricLine *lrc);
//static void MApp_ZUI_ACT_GetKTVLrcSunlength(TLyricLine *lrc);
static BOOLEAN MApp_ZUI_ACT_GetKTVLrcLabel(void);
static void MApp_ZUI_ACT_Endlrc(void);
static void MApp_ZUI_ACT_ChangeExtName( U8 * PathFileName ,U8* szExtName );

static U32 AdjustTime = 0;
static BOOLEAN IsOpenLrc = FALSE;
static BOOLEAN bFirstShowLrc = FALSE;
static BOOLEAN bIsFinished = FALSE;
static U16  wSungLength=0;
static U8 aLabel_TI[128];
static U8 aLabel_AR[128];
static U16 MainMidDepthIndex[3];
static U16 MainMidDiskDepthIndex[10]; //the max depth of mid_disk_list is 10.
static U8* g_u8lrcString = NULL;
static U8 aSearchPath[128]={0};
static U8 enterFileNme[128] ={0};

static SINGER_SORT_INFO stMidTitleSingSortInfo;
static SINGER_LIST_INFO stMidTitleSingerListInfo;
static SONG_COUNT_INFO  stMidTitleSongCountInfo;
static SONG_SORT_INFO stMidTitleSongSortInfo;
static LANG_SORT_INFO stMidTitleLangSortInfo;
static KTV_ERROR_INFO enKTVErrorInfo = EN_KTV_ERROR_NULL;
static U8 szPinYinInputValue[16] = {0};
static U8 *InputChar = NULL;
static BOOLEAN bPinYinInputMode = FALSE;
static BOOLEAN bIsOrigal = FALSE;
static BOOLEAN bUSBHasDateBase = TRUE;
static BOOLEAN bEnterSelPage = FALSE;

extern U16 g_KTVBK_VOL;
extern U16 g_KTVMIC_VOL;
U8 u8AuidoType = 1;
U16 g_PlayFileListIndex;
U16 KLM_CurOrderNum,KLM_PreOrderNum = 0;


static void _MAPP_DMP_KTVFb_Create(HWND hwnd_frame);
static void _MAPP_DMP_KTVFb_Destroy(void);
static void _MAPP_DMP_KTVFb_DrawArea(HWND hWnd);
static void _MAPP_DMP_KTVFb_CopyRegion(MSAPI_OSDRegion * src, MSAPI_OSDRegion * dst);
//static void MApp_ZUI_ACT_GetKTVOrderSongInfo(TOrderInfo *stOrderInfo,U16 u16Index);
//static void MApp_ZUI_ACTPlayFile(TOrderInfo strFile);
static BOOLEAN MApp_ZUI_ACT_SetKTVCurrentMidDepthIndex(void);
static BOOLEAN MApp_ZUI_ACT_SetKTVFocusByCurrentMidDepthIndex(void);
static BOOLEAN MApp_ZUI_ACT_SetKTVCurrentMidDiskDepthIndex(void);
static BOOLEAN MApp_ZUI_ACT_SetKTVFocusByCurrentMidDiskDepthIndex(void);
extern BOOLEAN _MApp_ZUI_API_WindowProcOnIdle(void);
extern void _MApp_ZUI_API_ConvertComponentToDynamic(DRAWCOMPONENT comp, U16 u16CompIndex, void * pDraw);
extern void _MApp_ZUI_API_ConvertTextComponentToDynamic(U16 u16TextOutIndex, DRAW_TEXT_OUT_DYNAMIC * pComp);
BOOLEAN MAPP_ZUI_ACT_KTV_PlayBackPhoto(void);
static void MApp_ZUI_API_InvalidateSelectListItem(void);

/////////////////////////////////////////////////////////////////////
#define UI_KTV_ORDERLIST_NUMBER 10
#define UI_KTV_PINYINORDER_NUMBER 8
#define UI_KTV_CONTROLLIST_NUMBER 6
#define UI_KTV_SETBANNERLIST_NUMBER 4
#define UI_KTV_SELECTEDSONGLIST_NUMBER 6
#define UI_KTV_LEFTITEMS                           6

#define MAX_NUM_OF_KTVBG_VOL_LEVEL		100
#define MAX_NUM_OF_KTVMIX_VOL_LEVEL		63

#define SET_BEST_BGVOLUME	52
#define SET_BEST_MICVOLUME	56
#define SET_BEST_MIXVOLUME	32

static HWND _hwndListOrderLeftlistItem[UI_KTV_ORDERLIST_NUMBER] =
{
	HWND_KTV_MAIN_LEFT_ITEM0,
	HWND_KTV_MAIN_LEFT_ITEM1,
	HWND_KTV_MAIN_LEFT_ITEM2,
	HWND_KTV_MAIN_LEFT_ITEM3,
	HWND_KTV_MAIN_LEFT_ITEM4,
	HWND_KTV_MAIN_LEFT_ITEM5,
	HWND_KTV_MAIN_LEFT_ITEM6,
	HWND_KTV_MAIN_LEFT_ITEM7,
	HWND_KTV_MAIN_LEFT_ITEM8,
	HWND_KTV_MAIN_LEFT_ITEM9,
};
static HWND _hwndListOrderMidlistItem[UI_KTV_ORDERLIST_NUMBER] =
{
	HWND_KTV_MAIN_MID_ITEM0,
	HWND_KTV_MAIN_MID_ITEM1,
	HWND_KTV_MAIN_MID_ITEM2,
	HWND_KTV_MAIN_MID_ITEM3,
	HWND_KTV_MAIN_MID_ITEM4,
	HWND_KTV_MAIN_MID_ITEM5,
	HWND_KTV_MAIN_MID_ITEM6,
	HWND_KTV_MAIN_MID_ITEM7,
	HWND_KTV_MAIN_MID_ITEM8,
	HWND_KTV_MAIN_MID_ITEM9,
};
static HWND _hwndListOrderMidSonglistItem[UI_KTV_ORDERLIST_NUMBER] =
{
	HWND_KTV_MAIN_MID_SONG_ITEM0,
	HWND_KTV_MAIN_MID_SONG_ITEM1,
	HWND_KTV_MAIN_MID_SONG_ITEM2,
	HWND_KTV_MAIN_MID_SONG_ITEM3,
	HWND_KTV_MAIN_MID_SONG_ITEM4,
	HWND_KTV_MAIN_MID_SONG_ITEM5,
	HWND_KTV_MAIN_MID_SONG_ITEM6,
	HWND_KTV_MAIN_MID_SONG_ITEM7,
	HWND_KTV_MAIN_MID_SONG_ITEM8,
	HWND_KTV_MAIN_MID_SONG_ITEM9,
};
static HWND _hwndListOrderRightlistItem[UI_KTV_ORDERLIST_NUMBER] =
{
	HWND_KTV_MAIN_RIGHT_ITEM0,
	HWND_KTV_MAIN_RIGHT_ITEM1,
	HWND_KTV_MAIN_RIGHT_ITEM2,
	HWND_KTV_MAIN_RIGHT_ITEM3,
	HWND_KTV_MAIN_RIGHT_ITEM4,
	HWND_KTV_MAIN_RIGHT_ITEM5,
	HWND_KTV_MAIN_RIGHT_ITEM6,
	HWND_KTV_MAIN_RIGHT_ITEM7,
	HWND_KTV_MAIN_RIGHT_ITEM8,
	HWND_KTV_MAIN_RIGHT_ITEM9,
};

static HWND _hwndListOrderMidDisklistItem[UI_KTV_ORDERLIST_NUMBER] =
{
	HWND_KTV_MAIN_MID_DISK_ITEM0,
	HWND_KTV_MAIN_MID_DISK_ITEM1,
	HWND_KTV_MAIN_MID_DISK_ITEM2,
	HWND_KTV_MAIN_MID_DISK_ITEM3,
	HWND_KTV_MAIN_MID_DISK_ITEM4,
	HWND_KTV_MAIN_MID_DISK_ITEM5,
	HWND_KTV_MAIN_MID_DISK_ITEM6,
	HWND_KTV_MAIN_MID_DISK_ITEM7,
	HWND_KTV_MAIN_MID_DISK_ITEM8,
	HWND_KTV_MAIN_MID_DISK_ITEM9,
};

static HWND _hwndListOrderMidTextListItem[UI_KTV_ORDERLIST_NUMBER] =
{
	HWND_KTV_MAIN_MID_ITEM0_TEXT,
	HWND_KTV_MAIN_MID_ITEM1_TEXT,
	HWND_KTV_MAIN_MID_ITEM2_TEXT,
	HWND_KTV_MAIN_MID_ITEM3_TEXT,
	HWND_KTV_MAIN_MID_ITEM4_TEXT,
	HWND_KTV_MAIN_MID_ITEM5_TEXT,
	HWND_KTV_MAIN_MID_ITEM6_TEXT,
	HWND_KTV_MAIN_MID_ITEM7_TEXT,
	HWND_KTV_MAIN_MID_ITEM8_TEXT,
	HWND_KTV_MAIN_MID_ITEM9_TEXT,
};

static HWND _hwndListOrderMidSongText1ListItem[UI_KTV_ORDERLIST_NUMBER] =
{
	HWND_KTV_MAIN_MID_SONG_ITEM0_TEXT1,
	HWND_KTV_MAIN_MID_SONG_ITEM1_TEXT1,
	HWND_KTV_MAIN_MID_SONG_ITEM2_TEXT1,
	HWND_KTV_MAIN_MID_SONG_ITEM3_TEXT1,
	HWND_KTV_MAIN_MID_SONG_ITEM4_TEXT1,
	HWND_KTV_MAIN_MID_SONG_ITEM5_TEXT1,
	HWND_KTV_MAIN_MID_SONG_ITEM6_TEXT1,
	HWND_KTV_MAIN_MID_SONG_ITEM7_TEXT1,
	HWND_KTV_MAIN_MID_SONG_ITEM8_TEXT1,
	HWND_KTV_MAIN_MID_SONG_ITEM9_TEXT1,
};

static HWND _hwndListOrderMidSongText2ListItem[UI_KTV_ORDERLIST_NUMBER] =
{
	HWND_KTV_MAIN_MID_SONG_ITEM0_TEXT2,
	HWND_KTV_MAIN_MID_SONG_ITEM1_TEXT2,
	HWND_KTV_MAIN_MID_SONG_ITEM2_TEXT2,
	HWND_KTV_MAIN_MID_SONG_ITEM3_TEXT2,
	HWND_KTV_MAIN_MID_SONG_ITEM4_TEXT2,
	HWND_KTV_MAIN_MID_SONG_ITEM5_TEXT2,
	HWND_KTV_MAIN_MID_SONG_ITEM6_TEXT2,
	HWND_KTV_MAIN_MID_SONG_ITEM7_TEXT2,
	HWND_KTV_MAIN_MID_SONG_ITEM8_TEXT2,
	HWND_KTV_MAIN_MID_SONG_ITEM9_TEXT2,
};

static HWND _hwndListOrderMidDiskTextListItem[UI_KTV_ORDERLIST_NUMBER] =
{
	HWND_KTV_MAIN_MID_DISK_ITEM0_TEXT,
	HWND_KTV_MAIN_MID_DISK_ITEM1_TEXT,
	HWND_KTV_MAIN_MID_DISK_ITEM2_TEXT,
	HWND_KTV_MAIN_MID_DISK_ITEM3_TEXT,
	HWND_KTV_MAIN_MID_DISK_ITEM4_TEXT,
	HWND_KTV_MAIN_MID_DISK_ITEM5_TEXT,
	HWND_KTV_MAIN_MID_DISK_ITEM6_TEXT,
	HWND_KTV_MAIN_MID_DISK_ITEM7_TEXT,
	HWND_KTV_MAIN_MID_DISK_ITEM8_TEXT,
	HWND_KTV_MAIN_MID_DISK_ITEM9_TEXT,
};

static HWND _hwndListOrderMidDiskIconListItem[UI_KTV_ORDERLIST_NUMBER] =
{
	HWND_KTV_MAIN_MID_DISK_ITEM0_ICON,
	HWND_KTV_MAIN_MID_DISK_ITEM1_ICON,
	HWND_KTV_MAIN_MID_DISK_ITEM2_ICON,
	HWND_KTV_MAIN_MID_DISK_ITEM3_ICON,
	HWND_KTV_MAIN_MID_DISK_ITEM4_ICON,
	HWND_KTV_MAIN_MID_DISK_ITEM5_ICON,
	HWND_KTV_MAIN_MID_DISK_ITEM6_ICON,
	HWND_KTV_MAIN_MID_DISK_ITEM7_ICON,
	HWND_KTV_MAIN_MID_DISK_ITEM8_ICON,
	HWND_KTV_MAIN_MID_DISK_ITEM9_ICON,
};

static HWND _hwndListOrderRightTextListItem[UI_KTV_ORDERLIST_NUMBER] =
{
	HWND_KTV_MAIN_RIGHT_ITEM0_TEXT,
	HWND_KTV_MAIN_RIGHT_ITEM1_TEXT,
	HWND_KTV_MAIN_RIGHT_ITEM2_TEXT,
	HWND_KTV_MAIN_RIGHT_ITEM3_TEXT,
	HWND_KTV_MAIN_RIGHT_ITEM4_TEXT,
	HWND_KTV_MAIN_RIGHT_ITEM5_TEXT,
	HWND_KTV_MAIN_RIGHT_ITEM6_TEXT,
	HWND_KTV_MAIN_RIGHT_ITEM7_TEXT,
	HWND_KTV_MAIN_RIGHT_ITEM8_TEXT,
	HWND_KTV_MAIN_RIGHT_ITEM9_TEXT,
};

static HWND _hwndListControlButtonListItem[UI_KTV_CONTROLLIST_NUMBER] =
{
	HWND_KTV_BUTTON_ORDER,
	HWND_KTV_BUTTON_SEL,
	HWND_KTV_BUTTON_CUT,
	HWND_KTV_BUTTON_ORIGACC,
	HWND_KTV_BUTTON_SET,
	HWND_KTV_BUTTON_EXIT,
};

static HWND _hwndListSetBannerListItem[UI_KTV_SETBANNERLIST_NUMBER] =
{
	HWND_KTV_SET_ACC_VOLUME,
	HWND_KTV_SET_MICORPHONE_VOLUME,
	HWND_KTV_SET_MIX_VOLUME,
	HWND_KTV_SET_BEST,
};

static HWND _hwndListSelectedSongListItem[UI_KTV_SELECTEDSONGLIST_NUMBER] =
{
       HWND_KTV_SEL_BANNER_ITEM0_TEXT,
       HWND_KTV_SEL_BANNER_ITEM1_TEXT,
       HWND_KTV_SEL_BANNER_ITEM2_TEXT,
       HWND_KTV_SEL_BANNER_ITEM3_TEXT,
       HWND_KTV_SEL_BANNER_ITEM4_TEXT,
       HWND_KTV_SEL_BANNER_ITEM5_TEXT,
};
static HWND _hwndListSelectedSongListTotalItem[UI_KTV_SELECTEDSONGLIST_NUMBER] =
{
       HWND_KTV_SEL_BANNER_ITEM0,
       HWND_KTV_SEL_BANNER_ITEM1,
       HWND_KTV_SEL_BANNER_ITEM2,
       HWND_KTV_SEL_BANNER_ITEM3,
       HWND_KTV_SEL_BANNER_ITEM4,
       HWND_KTV_SEL_BANNER_ITEM5,
};

static HWND _hwndListSelectedSongListBotton2Item[UI_KTV_SELECTEDSONGLIST_NUMBER] =
{
       HWND_SEL_BANNER_ITEM0_BUTTON_2,
       HWND_SEL_BANNER_ITEM1_BUTTON_2,
       HWND_SEL_BANNER_ITEM2_BUTTON_2,
       HWND_SEL_BANNER_ITEM3_BUTTON_2,
       HWND_SEL_BANNER_ITEM4_BUTTON_2,
       HWND_SEL_BANNER_ITEM5_BUTTON_2,
};
static HWND _hwndListSelectedSongListBotton1Item[UI_KTV_SELECTEDSONGLIST_NUMBER] =
{
       HWND_SEL_BANNER_ITEM0_BUTTON_1,
       HWND_SEL_BANNER_ITEM1_BUTTON_1,
       HWND_SEL_BANNER_ITEM2_BUTTON_1,
       HWND_SEL_BANNER_ITEM3_BUTTON_1,
       HWND_SEL_BANNER_ITEM4_BUTTON_1,
       HWND_SEL_BANNER_ITEM5_BUTTON_1,
};

static U16 u8CurrentSingerSortPageIdx;
static U16 u8CurrentSingerlistPageIdx;
static U16 u8CurrentSonglistPageIdx;
static U16 u8CurrentOrderlistPageIdx;
static U16 u8CurrentSongCoutPageIdx;
static U16 u8CurrentSongSortPageIdx;
static U16 u8CurrentLangSortPageIdx;
static U16 u8CurrentVideoItemsPageIdx;

static U8 u8MidDepth=0;
static U16 u8PageIdx = 0;
static U8 u8RightPageIdx = 0;
static U8 u8CurrentMidlistPageIdx = 1;
static U8 u8CurrentMidlistTotalPage = 1;
static U8 u8CurrentRightlistPageIdx = 1;
static U8 u8CurrentRightlistTotalPage = 1;
static U8 u8CurrentSelectedSongListPageIdx = 1;
static U8 u8CurrentSelectedSongListTotalPage = 1;

/////////////////////////////////////////////////////////////////////
extern BOOLEAN _MApp_ZUI_API_AllocateVarData(void);

int findString(char *s,char c)
{
	U16 i;
	U16 temp = 0;
	for(i=0;i<=(int)strlen(s);i++)
	{
		if((s[i]!='\0')&&(s[i]==c))
		{
			temp++;
		}

	}
	return temp;
}

int getstrlen(char *s,char c)
{
	U16 i=0;
	U16 temp1 =0,temp2 = 0,temp3=0;
	temp1 = findString(s,c);
	for(i=0;i<=(int)strlen(s);i++)
	{
		temp3++;
		if(s[i]==c)
		{
			temp2++;
			if(temp2==temp1)
				break;
		}

	}
	return temp3;
}

int getstrlen2(char *s,char c)
{
	U16 i=0;
	U16 temp1 =0,temp2 = 0,temp3=0;
	temp1 = findString(s,c);
	for(i=0;i<=(int)strlen(s);i++)
	{
		temp3++;
		if(s[i]==c)
		{
			temp2++;
			if((temp2+1)==temp1)
				break;
		}

	}
	return temp3;
}

static BOOLEAN MApp_ZUI_ACT_DeletePlay(void)
{
	TOrderInfo pstOrderInfo;
	BOOLEAN bRet;

	MApp_ZUI_ACT_GetKTVOrderSongInfo(&pstOrderInfo,0);
	bRet = KLM_DelSongInfo(0,&pstOrderInfo);
	if( bRet )
	{
		printf( "KLM_DelSongInfo() call success!\n" );
	}
	else
	{
	       printf( "KLM_DelSongInfo() call false!\n" );
	}
	return bRet;
}

static void MApp_ZUI_ACT_ShowErrorPage(void)
{
	MApp_ZUI_API_ShowWindow(HWND_KTV_ERROR_INFO_PAGE,SW_SHOW);
	MApp_ZUI_API_SetFocus(HWND_KTV_ERROR_INFO_BUTTON);
}

static void _MApp_ACTKTVHandleUsbStatusChanged(void)
{
    if(MApp_ZUI_GetActiveOSD() == E_OSD_MAIN_MENU
        || MApp_ZUI_GetActiveOSD() == E_OSD_INPUT_SOURCE)
    {
        MApp_DMP_Reset();
        if(MApp_DMP_RecalculateDriveMappingTable())
        {
            if(MApp_MPlayer_ConnectDrive(MApp_DMP_GetDriveFromMappingTable(MApp_DMP_GetCurDrvIdx())) == E_MPLAYER_RET_OK)
            {
                DMP_DBG(printf("[1] connect drive %d OK ^_^\n", (int)MApp_DMP_GetCurDrvIdx()));
                MApp_DMP_SetDmpFlag(DMP_FLAG_DRIVE_CONNECT_OK);
                MApp_MPlayer_SetCurrentMediaType(E_MPLAYER_TYPE_PHOTO, TRUE);
            }
        }
        return;
    }

    if(MApp_DMP_RecalculateDriveMappingTable())
    {
        MApp_DMP_Reset();
        if(MApp_MPlayer_ConnectDrive(MApp_DMP_GetDriveFromMappingTable(MApp_DMP_GetCurDrvIdx())) == E_MPLAYER_RET_OK)
        {
            DMP_DBG(printf("[2] connect drive %d OK ^_^\n", (int)MApp_DMP_GetCurDrvIdx()));
	     printf("[2] connect drive %d OK ^_^\n", (int)MApp_DMP_GetCurDrvIdx());
            MApp_KTV_SetFlag((EN_E_KTV_FLAG)E_KTV_FLAG_DRIVE_CONNECT_OK);
            MApp_MPlayer_SetCurrentMediaType(E_MPLAYER_TYPE_PHOTO, TRUE);
        }
        else
        {
            MApp_MPlayer_SetCurrentMediaType(E_MPLAYER_TYPE_PHOTO, FALSE);
        }
    }
    else
    {
        if(MApp_KTV_GetFlag() & E_KTV_FLAG_MEDIA_FILE_PLAYING
            || MApp_KTV_GetFlag() & E_KTV_FLAG_BGM_MODE)
        {
            MApp_MPlayer_Stop();
            MApp_MPlayer_StopMusic();
        }
	 	printf("usb not connect!!!\n");

	 enKTVErrorInfo = EN_KTV_ERROR_INSERT_USB;
        MApp_KTV_ClearFlag((EN_KTV_FLAG)E_KTV_FLAG_MEDIA_FILE_PLAYING);
        MApp_KTV_ClearFlag((EN_KTV_FLAG)E_KTV_FLAG_BGM_MODE);
        MApp_DMP_SetCurDrvIdxAndCalPageIdx(0);
        MApp_KTV_Reset();
        MApp_MPlayer_SetRepeatMode(E_MPLAYER_REPEAT_NONE);
        MApp_MPlayer_SetCurrentMediaType(E_MPLAYER_TYPE_PHOTO, FALSE);

	{
			if(MApp_ZUI_API_IsWindowVisible(HWND_KTV_CONTROL_BG)	\
				&&(!MApp_ZUI_API_IsWindowVisible(HWND_KTV_ERROR_INFO_PAGE)) \
				&&(!MApp_ZUI_API_IsWindowVisible(HWND_KTV_SEL_BANNER)) \
				&&(!MApp_ZUI_API_IsWindowVisible(HWND_KTV_SET_BANNER)))
				hwndPrevFocus = MApp_ZUI_API_GetFocus();
			else if(MApp_ZUI_API_IsWindowVisible(HWND_KTV_SEL_BANNER))
				hwndPrevFocus = HWND_KTV_BUTTON_SEL;
			else if(MApp_ZUI_API_IsWindowVisible(HWND_KTV_SET_BANNER))
				hwndPrevFocus = HWND_KTV_BUTTON_SET;
			else
				hwndPrevFocus = HWND_KTV_BUTTON_ORDER;
			MApp_ZUI_API_ShowWindow(HWND_MAINFRAME,SW_HIDE);
			MApp_ZUI_API_ShowWindow(HWND_KTV_CONTROL_BG,SW_SHOW);
			MApp_ZUI_API_ShowWindow(HWND_KTV_ERROR_INFO_PAGE,SW_SHOW);
			MApp_ZUI_API_SetFocus(HWND_KTV_ERROR_INFO_BUTTON);
        }

		if (1)//(enKTVErrorInfo == EN_KTV_ERROR_INSERT_USB)
		{
			unsigned int i;
			U8 uSelectedNum = KLM_GetOrderNum();

			for(i = 0;i < uSelectedNum;i ++)
			{
				MApp_ZUI_ACT_DeletePlay();
			}
			if(IsOpenLrc)
			{
				MApp_ZUI_ACT_Endlrc();
			}

		}

    }
}

BOOLEAN MApp_UiKTV_Notify(enumMPlayerNotifyType eNotify, void *pInfo)
{
    eNotify = eNotify; //backup notify event.
    pInfo = pInfo;
    // TODO: fix me

    if (IsStorageInUse())
    {
        if (MApp_ZUI_GetActiveOSD() == E_OSD_KTV)
        {
            // notification accepted
        }
        else if (((MApp_ZUI_GetActiveOSD() == E_OSD_MAIN_MENU)
                        || (MApp_ZUI_GetActiveOSD() == E_OSD_INPUT_SOURCE))
                && ((eNotify == E_MPLAYER_NOTIFY_USB_DEVICE_STATUS_CHANGE)
                        || (eNotify == E_MPLAYER_NOTIFY_USB_ACTIVE_DEVICE_STATUS_CHANGE)))
        {
            // notification accepted
        }
        else
        {
            // notification not accepted
            // ZUIMM_DBG(printf("Notification (%d) doesn't accept\n", eNotify));
            return FALSE;
        }
    }

    switch(eNotify)
    {
        case E_MPLAYER_NOTIFY_USB_ACTIVE_DEVICE_STATUS_CHANGE:
            KTVACT_DBG(printf("    - E_MPLAYER_NOTIFY_USB_ACTIVE_DEVICE_STATUS_CHANGE\n"));
            _MApp_ACTKTVHandleUsbStatusChanged();
            break;
        case E_MPLAYER_NOTIFY_DRIVE_CHANGE:
            KTVACT_DBG(printf("    - E_MPLAYER_NOTIFY_DRIVE_CHANGE\n"));
            {
                if(MApp_DMP_RecalculateDriveMappingTable())
                {
                    U8 i;
                    // Search previous mapped drive

                    for(i=0; i<NUM_OF_MAX_DRIVE; i++)
                    {
                        if(MApp_MPlayer_QueryCurrentDriveIndex() == MApp_DMP_GetDriveFromMappingTable(i))
                        {
                            MApp_DMP_SetCurDrvIdxAndCalPageIdx(i);
                        }
                        //printf("[Mappings] %bu. --> drive %bu\n", i, MApp_MediaPlayer_GetDriveFromMappingTable(i));
                    }

                    if(MApp_ZUI_GetActiveOSD() == E_OSD_MAIN_MENU
                        || MApp_ZUI_GetActiveOSD() == E_OSD_INPUT_SOURCE)
                    {
                        return FALSE;;
                    }

                }
            }
            break;
        case E_MPLAYER_NOTIFY_SHOW_MUSIC_NFO:
            KTVACT_DBG(printf("    - E_MPLAYER_NOTIFY_SHOW_MUSIC_NFO\n"));

            break;
        case E_MPLAYER_NOTIFY_HIDE_SUBTITLE:
            KTVACT_DBG(printf("    - E_MPLAYER_NOTIFY_HIDE_SUBTITLE\n"));

            break;
        case E_MPLAYER_NOTIFY_SHOW_SUBTITLE:
            KTVACT_DBG(printf("    - E_MPLAYER_NOTIFY_SHOW_SUBTITLE\n"));

            break;
        case E_MPLAYER_NOTIFY_SHOW_LYRIC:
            KTVACT_DBG(printf("    - E_MPLAYER_NOTIFY_SHOW_LYRIC\n"));
            break;
        case E_MPLAYER_NOTIFY_PLAYING_TIME_TICK:
            KTVACT_DBG(printf("    - E_MPLAYER_NOTIFY_PLAYING_TIME_TICK\n"));
            break;
        case E_MPLAYER_NOTIFY_BEFORE_PHOTO_PREVIEW:
            KTVACT_DBG(printf("    - E_MPLAYER_NOTIFY_BEFORE_PHOTO_PREVIEW\n"));

            break;
        case E_MPLAYER_NOTIFY_END_OF_PHOTO_PREVIEW:
            KTVACT_DBG(printf("    - E_MPLAYER_NOTIFY_END_OF_PHOTO_PREVIEW\n"));

            break;
        case E_MPLAYER_NOTIFY_BEFORE_MUSIC_PREVIEW:
            KTVACT_DBG(printf("    - E_MPLAYER_NOTIFY_BEFORE_MUSIC_PREVIEW\n"));
            break;
        case E_MPLAYER_NOTIFY_END_OF_MUSIC_PREVIEW:
            KTVACT_DBG(printf("    - E_MPLAYER_NOTIFY_END_OF_MUSIC_PREVIEW\n"));

            break;
        case E_MPLAYER_NOTIFY_BEFORE_MOVIE_PREVIEW:
            KTVACT_DBG(printf("    - E_MPLAYER_NOTIFY_BEFORE_MOVIE_PREVIEW\n"));

            break;
        case E_MPLAYER_NOTIFY_END_OF_MOVIE_PREVIEW:
            KTVACT_DBG(printf("    - E_MPLAYER_NOTIFY_END_OF_MOVIE_PREVIEW\n"));

            break;
        case E_MPLAYER_NOTIFY_END_OF_TEXT_PREVIEW:
            KTVACT_DBG(printf("    - E_MPLAYER_NOTIFY_END_OF_TEXT_PREVIEW\n"));

            break;
        case E_MPLAYER_NOTIFY_MEDIA_PREDECODE_OK:
	        KTVACT_DBG(printf("    - E_MPLAYER_NOTIFY_MEDIA_PREDECODE_OK\n"));
            break;
        case E_MPLAYER_NOTIFY_BEFORE_PLAY_ONE_FILE:
                KTVACT_DBG(printf("    - E_MPLAYER_NOTIFY_BEFORE_PLAY_ONE_FILE\n"););
                {
                    enumMPlayerMediaType eMediaType = MApp_MPlayer_QueryCurrentMediaType();

                    if(MApp_KTV_GetFlag() & DMP_FLAG_BGM_MODE)
                    {
                        eMediaType = *(enumMPlayerMediaType *)pInfo;
                    }
                    KTVACT_DBG(printf("playing eMediaType %u\n",eMediaType););

                    switch(eMediaType)
                    {
                        case E_MPLAYER_TYPE_MOVIE:
                        {
			 	printf("MOVIE	- E_MPLAYER_NOTIFY_BEFORE_PLAY_ONE_FILE\n");

                            MApp_KTV_ClearFlag(E_KTV_FLAG_MOVIE_REPEATAB_MODE);

                            MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_NORMAL);

                            MApp_MPlayer_EnableSubtitle();
                            MApp_MPlayer_MovieChangeSubtitleTrack(0);
                            if(MApp_MPlayer_IsCurrentExternalSubtitleAvailable() == E_MPLAYER_RET_OK)
                            {
                                KTVACT_DBG(printf("Turn ON external SUBTITLE\n"););
//                                printf("\nFix me! Need Show Subtitle");
                            }

				if(MApp_ZUI_API_IsWindowVisible(HWND_KTV_MAIN_BG))
				{
					if(0 == KLM_GetOrderNum())
					{
						hwndCurFocus= MApp_ZUI_API_GetFocus();
						if(hwndCurFocus >= HWND_KTV_MAIN_RIGHT_ITEM0 && hwndCurFocus <= HWND_KTV_MAIN_RIGHT_ITEM9)
						{
							if(eDBFFileInfo == EN_SONG_BY_DISK)
								MApp_ZUI_API_SetFocus(HWND_KTV_MAIN_MID_DISK_ITEM0);
							else
								MApp_ZUI_API_SetFocus(HWND_KTV_MAIN_MID_ITEM0);
						}
					}

					if(KLM_GetOrderNum()== 0)
					{
						u8CurrentRightlistTotalPage = 1;
						u8CurrentRightlistPageIdx = 1;
					}
					else
					{
						u8CurrentRightlistTotalPage= (KLM_GetOrderNum()+UI_KTV_ORDERLIST_NUMBER-1)/UI_KTV_ORDERLIST_NUMBER;
						if(u8CurrentRightlistPageIdx>u8CurrentRightlistTotalPage)
							u8CurrentRightlistPageIdx=u8CurrentRightlistTotalPage;
						}
						MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_MAIN_RIGHT_PAGE_NUM);
						MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_MAIN_RIGHT_LIST);
						_MApp_ZUI_API_WindowProcOnIdle();
					}

					if(MApp_ZUI_API_IsWindowVisible(HWND_KTV_SEL_BANNER))
					{
						if(0 == KLM_GetOrderNum())
						{
							MApp_ZUI_API_ShowWindow(HWND_KTV_SEL_BANNER,SW_HIDE);
							MApp_ZUI_API_SetFocus(HWND_KTV_BUTTON_SEL);
						}
						u8CurrentSelectedSongListTotalPage = (KLM_GetOrderNum()+UI_KTV_SELECTEDSONGLIST_NUMBER-1)/UI_KTV_SELECTEDSONGLIST_NUMBER;
						if(u8CurrentSelectedSongListPageIdx>u8CurrentSelectedSongListTotalPage)
							u8CurrentSelectedSongListPageIdx=u8CurrentSelectedSongListTotalPage;
						MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_SEL_BANNER_PAGENUM);
						MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_SEL_BANNER);
						_MApp_ZUI_API_WindowProcOnIdle();
					}
                        }
                        break;
                        case E_MPLAYER_TYPE_PHOTO:
					printf("PHOTO	- E_MPLAYER_NOTIFY_BEFORE_PLAY_ONE_FILE\n");

                            break;

                        case E_MPLAYER_TYPE_MUSIC:
				printf("MUSIC	- E_MPLAYER_NOTIFY_BEFORE_PLAY_ONE_FILE\n");

                            if(MApp_MPlayer_IsCurrentLRCLyricAvailable() == E_MPLAYER_RET_OK&&(MApp_MPlayer_QueryCurrentMediaType()==E_MPLAYER_TYPE_MUSIC))
                            {
                                MApp_MPlayer_EnableLRCLyric();
                                printf("\nFix me!! Show LRC");
                            }
                            else
                            {
                                DMP_DBG(printf("MApp_MPlayer_IsCurrentLRCLyricAvailable fail playing stage\n"););
                            }

				if(MApp_ZUI_API_IsWindowVisible(HWND_KTV_MAIN_BG))
				{
					printf("\n--OrderNum=%d\n",KLM_GetOrderNum());
					if(0 == KLM_GetOrderNum())
					{
						hwndCurFocus= MApp_ZUI_API_GetFocus();
						if(hwndCurFocus >= HWND_KTV_MAIN_RIGHT_ITEM0 && hwndCurFocus <= HWND_KTV_MAIN_RIGHT_ITEM9)
						{
							if(eDBFFileInfo == EN_SONG_BY_DISK)
								MApp_ZUI_API_SetFocus(HWND_KTV_MAIN_MID_DISK_ITEM0);
							else
								MApp_ZUI_API_SetFocus(HWND_KTV_MAIN_MID_ITEM0);
						}
					}
					if(KLM_GetOrderNum()== 0)
					{
						u8CurrentRightlistTotalPage = 1;
						u8CurrentRightlistPageIdx = 1;
					}
					else
					{
						u8CurrentRightlistTotalPage= (KLM_GetOrderNum()+UI_KTV_ORDERLIST_NUMBER-1)/UI_KTV_ORDERLIST_NUMBER;
						if(u8CurrentRightlistPageIdx>u8CurrentRightlistTotalPage)
							u8CurrentRightlistPageIdx=u8CurrentRightlistTotalPage;
					}
					MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_MAIN_RIGHT_PAGE_NUM);
					MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_MAIN_RIGHT_LIST);
					_MApp_ZUI_API_WindowProcOnIdle();
				}

				if(MApp_ZUI_API_IsWindowVisible(HWND_KTV_SEL_BANNER))
				{
					if(0 == KLM_GetOrderNum())
					{
						MApp_ZUI_API_ShowWindow(HWND_KTV_SEL_BANNER,SW_HIDE);
						MApp_ZUI_API_SetFocus(HWND_KTV_BUTTON_SEL);
					}
					u8CurrentSelectedSongListTotalPage = (KLM_GetOrderNum()+UI_KTV_SELECTEDSONGLIST_NUMBER-1)/UI_KTV_SELECTEDSONGLIST_NUMBER;
					if(u8CurrentSelectedSongListPageIdx>u8CurrentSelectedSongListTotalPage)
						u8CurrentSelectedSongListPageIdx=u8CurrentSelectedSongListTotalPage;
					MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_SEL_BANNER_PAGENUM);
					MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_SEL_BANNER);
					_MApp_ZUI_API_WindowProcOnIdle();
				}
                            break;
                        case E_MPLAYER_TYPE_TEXT:
                            break;
                        default:
                            break;
                    }
                }
	        break;
        case E_MPLAYER_NOTIFY_END_OF_PLAY_ONE_FILE:
                 KTVACT_DBG(printf("    - E_MPLAYER_NOTIFY_END_OF_PLAY_ONE_FILE\n"););
			{
				enumMPlayerMediaType eMediaType = *(enumMPlayerMediaType *)pInfo;

				if(eMediaType != E_MPLAYER_TYPE_PHOTO)
				{
				    KTVACT_DBG(printf("    - E_MPLAYER_NOTIFY_END_OF_PLAY_ONE_FILE\n"););
					//CurrentOrderNum = KLM_GetOrderNum();
					if(0 == KLM_GetOrderNum())
					{
					   if((!MApp_ZUI_API_IsWindowVisible(HWND_KTV_ERROR_INFO_PAGE))
						 	&&(!MApp_ZUI_API_IsWindowVisible(HWND_KTV_SET_BANNER))
						 	&&(!MApp_ZUI_API_IsWindowVisible(HWND_KTV_SEL_BANNER)))
						    {
								hwndPrevFocus = MApp_ZUI_API_GetFocus();
						    }
						enKTVErrorInfo = EN_KTV_ERROR_PLAY_ALL;
						MApp_MPlayer_Stop();
						MApp_MPlayer_StopMusic();
						MApp_ZUI_ACT_ShowErrorPage();
						MApp_ZUI_API_ShowWindow(HWND_KTV_LRC_SONGNAME,SW_HIDE);
					      if(IsOpenLrc)
						{
							MApp_ZUI_ACT_Endlrc();
						}
						return TRUE;
					}
					else
					{
						TOrderInfo pstOrderSong;
						MApp_ZUI_API_ShowWindow(HWND_KTV_LRC_SONGNAME,SW_HIDE);
						if(IsOpenLrc)
						{
							MApp_ZUI_ACT_Endlrc();
						}
						MApp_ZUI_ACT_GetKTVOrderSongInfo(&pstOrderSong,0);
						MApp_ZUI_ACTPlayFile(pstOrderSong);
					}
				}

	            if(eMediaType == E_MPLAYER_TYPE_PHOTO)
			{
                          U16  temp;
                          HWND PreFocus;
				if(MApp_ZUI_API_IsWindowVisible(HWND_KTV_MAIN_BG))
				{
                                KLM_CurOrderNum = KLM_GetOrderNum();
                                if(KLM_PreOrderNum==0)
                                  	KLM_PreOrderNum = KLM_CurOrderNum;

					if(KLM_PreOrderNum == KLM_CurOrderNum)
						break;

                                PreFocus = MApp_ZUI_API_GetFocus();
                        if((0!=KLM_GetOrderNum())\
                        &&(u8CurrentRightlistPageIdx == u8CurrentRightlistTotalPage)\
                        &&(KLM_GetOrderNum() % UI_KTV_ORDERLIST_NUMBER!=0))
                        {
                            for(temp=0;temp<UI_KTV_ORDERLIST_NUMBER;temp++)
                            {
                            	MApp_ZUI_API_ShowWindow(_hwndListOrderRightlistItem[temp],SW_SHOW);
                            }

                            if((PreFocus >= _hwndListOrderRightlistItem[(KLM_GetOrderNum() % UI_KTV_ORDERLIST_NUMBER)]) && (PreFocus <= (_hwndListOrderRightlistItem[UI_KTV_ORDERLIST_NUMBER - 1])))
                            	MApp_ZUI_API_SetFocus(_hwndListOrderRightlistItem[(KLM_GetOrderNum() % UI_KTV_ORDERLIST_NUMBER)-1]);
                            else
                            	MApp_ZUI_API_SetFocus(PreFocus);
                        }
                        else if((0!=KLM_GetOrderNum())&&(KLM_GetOrderNum() % UI_KTV_ORDERLIST_NUMBER ==0))
                        {
				u8CurrentRightlistTotalPage= (KLM_GetOrderNum()+UI_KTV_ORDERLIST_NUMBER-1)/UI_KTV_ORDERLIST_NUMBER;
                        	if((u8CurrentRightlistPageIdx!=1))
	                     {
                                PreFocus = MApp_ZUI_API_GetFocus();

//                                if((KLM_PreOrderNum != KLM_CurOrderNum))
                                {
                                    KLM_PreOrderNum = KLM_CurOrderNum;

                                    for(temp=0;temp<UI_KTV_ORDERLIST_NUMBER;temp++)
                                    {
						MApp_ZUI_API_ShowWindow(_hwndListOrderRightlistItem[temp],SW_SHOW);
                                    }

                                    if(u8CurrentRightlistPageIdx> u8CurrentRightlistTotalPage)
                                    {
                                        u8CurrentRightlistPageIdx=u8CurrentRightlistTotalPage;
                                        MApp_ZUI_API_SetFocus(HWND_KTV_MAIN_RIGHT_ITEM0);
						MApp_ZUI_API_InvalidateWindow(HWND_KTV_MAIN_RIGHT_PAGE_NUM);
                                    }
                                    else if (u8CurrentRightlistPageIdx == u8CurrentRightlistTotalPage)
                                        MApp_ZUI_API_SetFocus(PreFocus);
                                    else
						MApp_ZUI_API_SetFocus(PreFocus);
                                }
                        	}
                            else
                            	u8CurrentSelectedSongListPageIdx =1;
                        }
                        else
                            MApp_ZUI_API_SetFocus(PreFocus);

	                   MApp_ZUI_API_InvalidateWindow(HWND_KTV_MAIN_RIGHT_BG);
	                }

                    if(MApp_ZUI_API_IsWindowVisible(HWND_KTV_SEL_BANNER))
	                {
                            KLM_CurOrderNum = KLM_GetOrderNum();
                            if(KLM_PreOrderNum==0)
                        	    KLM_PreOrderNum = KLM_CurOrderNum;

				if(KLM_PreOrderNum == KLM_CurOrderNum)
					break;

                        PreFocus = MApp_ZUI_API_GetFocus();
                        if((0!=KLM_GetOrderNum())\
                        &&(u8CurrentSelectedSongListPageIdx == u8CurrentSelectedSongListTotalPage)\
                        &&(KLM_GetOrderNum() % UI_KTV_SELECTEDSONGLIST_NUMBER !=0))
                        {
                            for(temp=0;temp<UI_KTV_SELECTEDSONGLIST_NUMBER;temp++)
                            {
                                MApp_ZUI_API_ShowWindow(_hwndListSelectedSongListTotalItem[temp],SW_HIDE);
                            }
                            for(temp=0;temp<(KLM_GetOrderNum() % UI_KTV_SELECTEDSONGLIST_NUMBER);temp++)
                            {
                            	MApp_ZUI_API_ShowWindow(_hwndListSelectedSongListTotalItem[temp],SW_SHOW);
                            }

                            if((PreFocus >= _hwndListSelectedSongListTotalItem[temp]) && (PreFocus <= (_hwndListSelectedSongListTotalItem[temp]+5)))
                            	MApp_ZUI_API_SetFocus(_hwndListSelectedSongListItem[temp-1]);
                            else
                            	MApp_ZUI_API_SetFocus(PreFocus);
                        }

                        else if(0 == KLM_GetOrderNum())
                        {
                            MApp_ZUI_API_ShowWindow(HWND_KTV_SEL_BANNER, SW_HIDE);
                            MApp_ZUI_API_SetFocus(HWND_KTV_BUTTON_SEL);
                            MApp_ZUI_API_ShowWindow(HWND_KTV_MESSAGE_BOX,SW_SHOW);
                        }
                        else if((0!=KLM_GetOrderNum())&&(KLM_GetOrderNum() % UI_KTV_SELECTEDSONGLIST_NUMBER ==0))
                        {
				u8CurrentSelectedSongListTotalPage = (KLM_GetOrderNum()+UI_KTV_SELECTEDSONGLIST_NUMBER-1)/UI_KTV_SELECTEDSONGLIST_NUMBER;
                        	if((u8CurrentSelectedSongListPageIdx!=1))
	                        {
                                PreFocus = MApp_ZUI_API_GetFocus();

                                if((KLM_PreOrderNum != KLM_CurOrderNum))
                                {
                                        KLM_PreOrderNum = KLM_CurOrderNum;

                                        for(temp=0;temp<UI_KTV_SELECTEDSONGLIST_NUMBER;temp++)
                                        {
                                            MApp_ZUI_API_ShowWindow(_hwndListSelectedSongListTotalItem[temp],SW_HIDE);
                                        }
                                        for(temp=0;temp<UI_KTV_SELECTEDSONGLIST_NUMBER;temp++)
                                        {
                                            MApp_ZUI_API_ShowWindow(_hwndListSelectedSongListTotalItem[temp],SW_SHOW);
                                        }

                                        if(u8CurrentSelectedSongListPageIdx > u8CurrentSelectedSongListTotalPage)
                                        {
                                            u8CurrentSelectedSongListPageIdx-=1;
                                            MApp_ZUI_API_SetFocus(HWND_KTV_SEL_BANNER_ITEM5_TEXT);
                                        }
                                        else if (u8CurrentSelectedSongListPageIdx == u8CurrentSelectedSongListTotalPage)
                                            MApp_ZUI_API_SetFocus(PreFocus);
                                        else
						    MApp_ZUI_API_SetFocus(PreFocus);
                                }
                        	}
                            else
                            	u8CurrentSelectedSongListPageIdx =1;
                        }
                        else
                            MApp_ZUI_API_SetFocus(PreFocus);

	                   MApp_ZUI_API_InvalidateWindow(HWND_KTV_SEL_BANNER_PAGENUM);
	                }
				}
			}
	        break;

        case E_MPLAYER_NOTIFY_END_OF_PLAY_ALL_FILE:
            KTVACT_DBG(printf("    - E_MPLAYER_NOTIFY_END_OF_PLAY_ALL_FILE\n"));
		{
                switch(MApp_MPlayer_QueryCurrentMediaType())
                {
                    case E_MPLAYER_TYPE_PHOTO:
                    case E_MPLAYER_TYPE_MOVIE:
                    case E_MPLAYER_TYPE_MUSIC:
                    case E_MPLAYER_TYPE_TEXT:
                    {
                            msAPI_Scaler_SetBlueScreen(TRUE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
                            MApi_XC_GenerateBlackVideo( ENABLE, MAIN_WINDOW );
                           break;
                    }
                    default:
                        break;
                }
            }
            break;

        case E_MPLAYER_NOTIFY_TEXT_PREV_PAGE:
            KTVACT_DBG(printf("    - E_MPLAYER_NOTIFY_TEXT_PREV_PAGE\n"));
            break;
        case E_MPLAYER_NOTIFY_TEXT_NEXT_PAGE:
            KTVACT_DBG(printf("    - E_MPLAYER_NOTIFY_TEXT_NEXT_PAGE\n"));
            break;
        case E_MPLAYER_NOTIFY_END_OF_ONE_THUMBNAIL:
            KTVACT_DBG(printf("    - E_MPLAYER_NOTIFY_END_OF_ONE_THUMBNAIL\n"));

            break;
            // TODO: fix me
        case E_MPLAYER_NOTIFY_END_OF_THUMBNAIL:
            KTVACT_DBG(printf("    - E_MPLAYER_NOTIFY_END_OF_THUMBNAIL\n"));

            break;
        case E_MPLAYER_NOTIFY_ERROR_OF_PLAY_FILE:
            KTVACT_DBG(printf("    - E_MPLAYER_NOTIFY_ERROR_OF_PLAY_FILE\n"));
            {
            // thumbnail
                if(MApp_KTV_GetFlag()& E_KTV_FLAG_THUMBNAIL_PLAYING)
                {
                    return FALSE;
                }
                enumMPlayerMediaType eMediaType = *(enumMPlayerMediaType *)pInfo;
                {
                    if(MApp_KTV_GetFlag() & E_KTV_FLAG_MEDIA_FILE_PLAYING
                        || MApp_KTV_GetFlag() & E_KTV_FLAG_THUMBNAIL_PLAYING)
                    {
                        KTVACT_DBG(printf("    - _MApp_DMP_ErrorHandling_PLAYING \n"));
                    }
                    else
                    {//Error occured in default page - Preview Mode or BGM Mode(error occured in !MUSIC type)
                        KTVACT_DBG(printf("    - _MApp_DMP_ErrorHandling_NOT playing \n"));
                        MApp_MPlayer_StopPreview();
                        switch(eMediaType)
                        {
                            case E_MPLAYER_TYPE_MUSIC:
                                if(MApp_MPlayer_IsCurrentLRCLyricAvailable() == E_MPLAYER_RET_OK)
                                {
                                    MApp_MPlayer_DisableLRCLyric();
                                }
                                if (MApp_MPlayer_QueryRepeatMode() ==E_MPLAYER_REPEAT_ALL)
                                {
                                    MApp_MPlayer_Stop();
                                    MApp_MPlayer_StopMusic();
                                    MApp_KTV_ClearFlag(E_KTV_FLAG_BGM_MODE);
                                    return FALSE;
                                }
                                 return TRUE;
                                break;
                            case E_MPLAYER_TYPE_TEXT:
                                break;
                            default:
                                break;
                        }

                    }//end of if(MApp_DMP_GetDmpFlag() & DMP_FLAG_MEDIA_FILE_PLAYING|| MApp_DMP_GetDmpFlag() & DMP_FLAG_THUMBNAIL_PLAYING)
                }//end of if(eMediaType!=E_MPLAYER_TYPE_PHOTO)
        }
            break;
        case E_MPLAYER_NOTIFY_PHOTO_INFO_OK:
            KTVACT_DBG(printf("    - E_MPLAYER_NOTIFY_PHOTO_INFO_OK\n"));
            break;
        case E_MPLAYER_NOTIFY_PLAY_NEXT_FILE:
            KTVACT_DBG(printf("    - E_MPLAYER_NOTIFY_PLAY_NEXT_FILE\n"));
            break;
        case E_MPLAYER_NOTIFY_PLAY_PREVIOUS_FILE:
            KTVACT_DBG(printf("    - E_MPLAYER_NOTIFY_PLAY_PREVIOUS_FILE\n"));
            break;
        case E_MPLAYER_NOTIFY_SETUP_DISPLAY:
            KTVACT_DBG(printf("    - E_MPLAYER_NOTIFY_SETUP_DISPLAY\n"));
            break;
       // case E_MPLAYER_NOTIFY_REFRESH_LOADING:
       //     break;
        default:
            KTVACT_DBG(printf("    - Unknown notify (%d)\n", (U16)eNotify));
            break;
    }
    return FALSE;
}

static BOOLEAN MApp_ZUI_ACT_GetKTVOpenDBF(U32 dwIndex,U8 Handle,U16 wStep)
{
	BOOLEAN bOpenFlag;

	switch(eDBFFileInfo)
	{
		case EN_SINGER_SORT:
			dwIndex = 0;
			bOpenFlag = DBAPP_QuerySwanClassInfo(&Handle,wStep,&pRecordSet);
			break;
		case EN_SINGER_LIST:
			bOpenFlag = DBAPP_QuerySwanInfoByClassId(dwIndex,&Handle,wStep,&pRecordSet);
			break;
		case EN_SONG_LIST:
			bOpenFlag = DBAPP_QuerySongInfoBySwanId(dwIndex,&Handle,wStep,&pRecordSet);
			break;
		case EN_CHARACTER_SORT:
		    bOpenFlag = DBAPP_QueryWordCountInfo(&Handle,wStep,&pRecordSet);
		    break;
		case EN_SONG_REFER2_CHARACT:
		    bOpenFlag = DBAPP_QuerySongInfoByWordCountId(dwIndex,&Handle,wStep,&pRecordSet);
		    break;
		case EN_SONG_SORT:
		    bOpenFlag = DBAPP_QuerySongClassInfo(&Handle,wStep,&pRecordSet);
		    break;
		case EN_SONG_REFER2_SORT:
			bOpenFlag = DBAPP_QuerySongInfoBySongClassId(dwIndex,&Handle,wStep,&pRecordSet);
			break;
		case EN_LANGUAGE_SORT:
			bOpenFlag = DBAPP_QueryLangTypeInfo(&Handle,wStep,&pRecordSet);
			break;
		case EN_SONG_REFER2_LANGUAGE:
			bOpenFlag = DBAPP_QuerySongInfoByLangId(dwIndex,&Handle,wStep,&pRecordSet);
			break;
		case EN_SONG_PINYIN:
			bOpenFlag = DBAPP_QuerySongInfoByFirstSpell(szPinYinInputValue,&Handle,wStep,&pRecordSet);
			break;
		default:
			bOpenFlag = 1;
			break;
	}

	if( 0==bOpenFlag )
	{
		KTVACT_DBG(printf( "MApp_ZUI_ACT_GetKTVOpenDBF() call success!\n" ););
		return TRUE;
	}
	else
	{
		KTVACT_DBG(printf( "MApp_ZUI_ACT_GetKTVOpenDBF() call failed!\n" ););
		return FALSE;
	}
}

static BOOLEAN MApp_ZUI_ACT_GetKTVNextPage(U8 u8CurPageNum)
{
	BOOLEAN bOpenFlag = 0;

	switch(eDBFFileInfo)
	{
		case EN_SINGER_LIST:
			bOpenFlag = MApp_ZUI_ACT_GetKTVOpenDBF(stMidTitleSingSortInfo.u32SingSortId,u8CurPageNum,UI_KTV_ORDERLIST_NUMBER);;
			break;
		case EN_SONG_LIST:
			bOpenFlag = MApp_ZUI_ACT_GetKTVOpenDBF(stMidTitleSingerListInfo.u32SingListId,u8CurPageNum,UI_KTV_ORDERLIST_NUMBER);
			break;
		case EN_SONG_REFER2_CHARACT:
		    bOpenFlag = MApp_ZUI_ACT_GetKTVOpenDBF(stMidTitleSongCountInfo.u16SongCount,u8CurPageNum,UI_KTV_ORDERLIST_NUMBER);
		    break;
		case EN_SONG_REFER2_SORT:
			bOpenFlag = MApp_ZUI_ACT_GetKTVOpenDBF(stMidTitleSongSortInfo.u16SongSortId,u8CurPageNum,UI_KTV_ORDERLIST_NUMBER);
			break;
		case EN_SONG_REFER2_LANGUAGE:
			bOpenFlag = MApp_ZUI_ACT_GetKTVOpenDBF(stMidTitleLangSortInfo.u16LangId,u8CurPageNum,UI_KTV_ORDERLIST_NUMBER);
			break;
		case EN_SONG_PINYIN:
			bOpenFlag = MApp_ZUI_ACT_GetKTVOpenDBF(0,u8CurPageNum,UI_KTV_PINYINORDER_NUMBER);
			break;
		default:
			bOpenFlag = 1;
			break;
	}

	if(bOpenFlag )
	{
		KTVACT_DBG(printf( "MApp_ZUI_ACT_GetKTVNextPage() call success!\n" ););
		return TRUE;
	}
	else
	{
		KTVACT_DBG(printf( "MApp_ZUI_ACT_GetKTVNextPage() call failed!\n" ););
		return FALSE;
	}
}

static void MApp_ZUI_ACT_GetKTVReleaseDBF(void)
{
	pRecordSet->Release(pRecordSet);
	pRecordSet = NULL;
	KTVACT_DBG(printf("\n-------------MApp_ZUI_ACT_GetKTVReleaseDBF-----------\n"););
}

static U32 MApp_ZUI_ACT_GetKTVSingerSortCount(void)
{
	U32 dwRecordCount;
	U32 dwTotalNum = 0;

	if(pRecordSet == NULL)
	{
		KTVACT_DBG(printf( "\npRecordSet is NULL\n"););
		return 0;
	}
	dwRecordCount = pRecordSet->GetRecordCount(pRecordSet,&dwTotalNum);
//	printf( "dwRecordCount=%ld\n",dwRecordCount );
//	printf( "dwTotalNum=%ld\n",dwTotalNum );
	return dwTotalNum;
}

static void MApp_ZUI_ACT_GetKTVSingerSortInfo(SINGER_SORT_INFO *SingerSortInfo,U16 u16Index)
{
	if(pRecordSet == NULL)
	{
		KTVACT_DBG(printf( "\npRecordSet is NULL\n"););
		return;
	}

	pRecordSet->SeekPosition(pRecordSet,(U32)u16Index);
	if( !pRecordSet->IsEOF(pRecordSet) )
	{
		U32 Len = sizeof(SingerSortInfo->aClassName);
		memset(SingerSortInfo->aClassName,0,Len);
		SingerSortInfo->u32SingSortId = pRecordSet->GetFieldULng_ByFieldName2(pRecordSet,"CLASS_ID");
		pRecordSet->GetFieldStr_ByFieldName(pRecordSet,"CLASS_NAME",SingerSortInfo->aClassName,Len);
		KTVACT_DBG(printf( "\nMApp_ZUI_ACT_GetKTVSingerSortInfo\ndwClass_Id=%ld,aClassName=%s\n",SingerSortInfo->u32SingSortId,SingerSortInfo->aClassName ););
	}
}

static U32 MApp_ZUI_ACT_GetKTVSingerListCount(void)
{
	U32 dwRecordCount = 0;
	U32 dwTotalNum = 0;
	if(pRecordSet == NULL)
	{
		KTVACT_DBG(printf( "\npRecordSet is NULL\n"););
		return 0;
	}

	dwRecordCount = pRecordSet->GetRecordCount(pRecordSet,&dwTotalNum);
//	KTVACT_DBG(printf( "\nMApp_ZUI_ACT_GetKTVSingerListCount\ndwRecordCount=%ld\n",dwRecordCount ););
//	printf( "dwRecordCount=%ld\n",dwRecordCount );
//	printf( "dwTotalNum=%ld\n",dwTotalNum );
	return dwTotalNum;
}

static void MApp_ZUI_ACT_GetKTVSingerListInfo(SINGER_LIST_INFO *SingerListInfo,U16 u16Index)
{
	if(pRecordSet == NULL)
	{
		KTVACT_DBG(printf( "\npRecordSet is NULL\n"););
		return;
	}

	pRecordSet->SeekPosition(pRecordSet,(U32)u16Index);
	if( !pRecordSet->IsEOF(pRecordSet) )
	{
		U32 Len = sizeof(SingerListInfo->cSingerName);
		memset(SingerListInfo->cSingerName,0,Len);
		SingerListInfo->u32SingerSortId= pRecordSet->GetFieldULng_ByFieldName2(pRecordSet,"CLASS_ID");
		SingerListInfo->u32SingListId = pRecordSet->GetFieldULng_ByFieldName2(pRecordSet,"SWAN_ID");
		pRecordSet->GetFieldStr_ByFieldName(pRecordSet,"SWAN_NAME",SingerListInfo->cSingerName,Len);
		KTVACT_DBG(printf( "\ndwSWAN_ID=%ld,SWAN_NAME=%s\n",SingerListInfo->u32SingListId,SingerListInfo->cSingerName ););
	}
}

static U32 MApp_ZUI_ACT_GetKTVSongListCount(void)
{
	U32 dwRecordCount = 0;
	U32 dwTotalNum = 0;

	if(pRecordSet == NULL)
	{
		KTVACT_DBG(printf( "\npRecordSet is NULL\n"););
		return 0;
	}

	dwRecordCount = pRecordSet->GetRecordCount(pRecordSet,&dwTotalNum);
	printf( "dwRecordCount=%ld\n",dwRecordCount );
	printf( "dwTotalNum=%ld\n",dwTotalNum );
	return dwTotalNum;

//	dwRecordCount = pRecordSet->GetRecordCount(pRecordSet,TNULL);
//	KTVACT_DBG(printf( "dwRecordCount=%ld\n",dwRecordCount ););
//	return dwRecordCount;
}

static void MApp_ZUI_ACT_GetKTVSongListInfo(SONG_LIST_INFO *SongListInfo,U16 u16Index)
{
	if(pRecordSet == NULL)
	{
		KTVACT_DBG(printf( "\npRecordSet is NULL\n"););
		return;
	}

	pRecordSet->SeekPosition(pRecordSet,(U32)u16Index);
	if( !pRecordSet->IsEOF(pRecordSet) )
	{
		U32 Len;
	       SongListInfo->u32SongNum = pRecordSet->GetFieldULng_ByFieldName2(pRecordSet,"SONG_NUM");
		SongListInfo->u16IsOrgin = pRecordSet->GetFieldInt_ByFieldName2(pRecordSet,"IS_ORIGIN");
		SongListInfo->u16FileType= pRecordSet->GetFieldInt_ByFieldName2(pRecordSet,"FILE_TYPE");
		SongListInfo->u32SingerListId= pRecordSet->GetFieldInt_ByFieldName2(pRecordSet,"SWAN_ID");
		SongListInfo->u16ClassId= pRecordSet->GetFieldInt_ByFieldName2(pRecordSet,"CLASS_ID");
		SongListInfo->u16SongCount= pRecordSet->GetFieldInt_ByFieldName2(pRecordSet,"SONG_COUNT");
		SongListInfo->u16LangId= pRecordSet->GetFieldInt_ByFieldName2(pRecordSet,"LANG_ID");
//		printf( "\n----111u16IsOrgin=%d\n",SongListInfo->u16IsOrgin);

		Len = sizeof(SongListInfo->cSongName);
		pRecordSet->GetFieldStr_ByFieldName(pRecordSet,"SONG_NAME",SongListInfo->cSongName,Len);
//		printf( "111aSongName=%s\n",SongListInfo->cSongName);
		Len = sizeof(SongListInfo->cSingerName);
		pRecordSet->GetFieldStr_ByFieldName(pRecordSet,"SWAN_NAME",SongListInfo->cSingerName,Len);
//		printf( "222cSongName=%s\n",SongListInfo->cSongName);
//		printf( "222cSingerName=%s\n",SongListInfo->cSingerName);
		Len = sizeof(SongListInfo->cSongPath);
		pRecordSet->GetFieldStr_ByFieldName(pRecordSet,"SONG_PATH",SongListInfo->cSongPath,Len);
//		printf( "333aSongName=%s\n",SongListInfo->cSongName);
//		printf( "333cSingerName=%s\n",SongListInfo->cSingerName);
//		printf( "333cSongPath=%s\n",SongListInfo->cSongPath);
	}
}
static U32 MApp_ZUI_ACT_GetKTVSongCountCount(void)
{
	U32 dwRecordCount = 0;
	U32 dwTotalNum = 0;

	if(pRecordSet == NULL)
	{
		KTVACT_DBG(printf( "\npRecordSet is NULL\n"););
		return 0;
	}

	dwRecordCount = pRecordSet->GetRecordCount(pRecordSet,&dwTotalNum);
//	printf("\n@@@@recordCount=%d#######\n",dwRecordCount);
//	printf( "dwRecordCount=%ld\n",dwRecordCount );
//	printf( "dwTotalNum=%ld\n",dwTotalNum );
	return dwTotalNum;
}

static void MApp_ZUI_ACT_GetKTVSongCountInfo(SONG_COUNT_INFO *SongCountInfo,U16 u16Index)
{
	if(pRecordSet == NULL)
	{
		KTVACT_DBG(printf( "\npRecordSet is NULL\n"););
		return;
	}

	pRecordSet->SeekPosition(pRecordSet,(U32)u16Index);
	if( !pRecordSet->IsEOF(pRecordSet) )
	{
		U32 Len = sizeof(SongCountInfo->cSongCountDesc);
		memset(SongCountInfo->cSongCountDesc,0,Len);
		SongCountInfo->u16SongCount= pRecordSet->GetFieldULng_ByFieldName2(pRecordSet,"SONG_COUNT");
		pRecordSet->GetFieldStr_ByFieldName(pRecordSet,"COUNT_DESC",SongCountInfo->cSongCountDesc,Len);
	}
}

static U32 MApp_ZUI_ACT_GetKTVSongSortCount(void)
{
	U32 dwRecordCount = 0;
	U32 dwTotalNum = 0;

	if(pRecordSet == NULL)
	{
		KTVACT_DBG(printf( "\npRecordSet is NULL\n"););
		return 0;
	}

	dwRecordCount = pRecordSet->GetRecordCount(pRecordSet,&dwTotalNum);
//	KTVACT_DBG(printf( "\nMApp_ZUI_ACT_GetKTVSingerListCount\ndwRecordCount=%ld\n",dwRecordCount ););
//	printf( "dwRecordCount=%ld\n",dwRecordCount );
//	printf( "dwTotalNum=%ld\n",dwTotalNum );
	return dwTotalNum;
//	dwRecordCount = pRecordSet->GetRecordCount(pRecordSet,TNULL);
//	return dwRecordCount;
}

static void MApp_ZUI_ACT_GetKTVSongSortInfo(SONG_SORT_INFO *SongSortInfo,U16 u16Index)
{
	if(pRecordSet == NULL)
	{
		KTVACT_DBG(printf( "\npRecordSet is NULL\n"););
		return;
	}

	pRecordSet->SeekPosition(pRecordSet,(U32)u16Index);
	if( !pRecordSet->IsEOF(pRecordSet) )
	{
		U32 Len = sizeof(SongSortInfo->cSongSortName);
		memset(SongSortInfo->cSongSortName,0,Len);
		SongSortInfo->u16SongSortId= pRecordSet->GetFieldULng_ByFieldName2(pRecordSet,"CLASS_ID");
		pRecordSet->GetFieldStr_ByFieldName(pRecordSet,"CLASS_NAME",SongSortInfo->cSongSortName,Len);
	}
}

static U32 MApp_ZUI_ACT_GetKTVLanguageSortCount(void)
{
	U32 dwRecordCount = 0;
	U32 dwTotalNum = 0;
	if(pRecordSet == NULL)
	{
		KTVACT_DBG(printf( "\npRecordSet is NULL\n"););
		return 0;
	}

	dwRecordCount = pRecordSet->GetRecordCount(pRecordSet,&dwTotalNum);
//	KTVACT_DBG(printf( "\nMApp_ZUI_ACT_GetKTVSingerListCount\ndwRecordCount=%ld\n",dwRecordCount ););
//	printf( "dwRecordCount=%ld\n",dwRecordCount );
//	printf( "dwTotalNum=%ld\n",dwTotalNum );
	return dwTotalNum;
}

static void MApp_ZUI_ACT_GetKTVLanguageSortInfo(LANG_SORT_INFO *LangSortInfo,U16 u16Index)
{
	if(pRecordSet == NULL)
	{
		KTVACT_DBG(printf( "\npRecordSet is NULL\n"););
		return;
	}

	pRecordSet->SeekPosition(pRecordSet,(U32)u16Index);
	if( !pRecordSet->IsEOF(pRecordSet) )
	{
		U32 Len = sizeof(LangSortInfo->cLangType);
		memset(LangSortInfo->cLangType,0,Len);
		LangSortInfo->u16LangId= pRecordSet->GetFieldULng_ByFieldName2(pRecordSet,"LANG_ID");
		pRecordSet->GetFieldStr_ByFieldName(pRecordSet,"LANG_TYPE",LangSortInfo->cLangType,Len);
	}
}

static U32 MApp_ZUI_ACT_GetKTVVideoItemsInDiskCount(void)
{
    U32 dwRecordCount = 0;

	if(pRecordSet == NULL)
	{
		KTVACT_DBG(printf( "\npRecordSet is NULL\n"););
		return 0;
	}

	dwRecordCount = pRecordSet->GetRecordCount(pRecordSet,TNULL);
    return dwRecordCount;
}

static void MApp_ZUI_ACT_GetKTVVideoItemsInDiskInfo(MEDIA_FILE_INFO *MediaFileInfo,U16 u16Index)
{
	if(pRecordSet == NULL)
	{
		KTVACT_DBG(printf( "\npRecordSet is NULL\n"););
		return;
	}

    pRecordSet->SeekPosition(pRecordSet,(U32)u16Index);
    if( !pRecordSet->IsEOF(pRecordSet) )
    {
        //U8 aFileName[256]={0};//U8 aClassName[41]={0};
        U32 Len = sizeof(MediaFileInfo->cFileName);
        memset(MediaFileInfo->cFileName,0,Len);
        MediaFileInfo->u16MediaType = pRecordSet->GetFieldInt_ByFieldName2(pRecordSet,"MEDIATYPE");
        pRecordSet->GetFieldStr_ByFieldName(pRecordSet,"FILENAME",MediaFileInfo->cFileName,Len);
    }
}

static void MApp_ZUI_ACT_GetKTVOrderSongInfo(TOrderInfo *stOrderInfo,U16 u16Index)
{
	THANDLE Handle = u16Index;
//	for( i=0; i<wOrderNum; i++ )
//	{
//		printf( "\nMApp_ZUI_ACT_GetKTVOrderSongInfo======Handle=%d\n",Handle );
		BOOLEAN bRet = KLM_GetNextOrder(&Handle,stOrderInfo);
//		if(i == u16Index)
//			return;
		if( bRet )
		{
//			printf( "stOrderInfo.szFilePath=%s\n",stOrderInfo->szFilePath );
//			printf( "stOrderInfo.szSongName=%s\n",stOrderInfo->szSongName );
			printf( "\nstOrderInfo.nAudioTrack=%d\n",stOrderInfo->nAudioTrack);
		}
		else
		{
			//if( TBEHIND_LAST_POSITION==Handle )
				printf( "Query List End,finish!" );
		}
//	}
}

//Get String Length
static U16 MApp_ZUI_ACT_GetKTVStringLength(HWND hWnd,DRAWSTYLE_TYPE ds_type)
{
        U16 u16TxtComponentIndex;
        DRAW_TEXT_OUT_DYNAMIC dyna;
        U16 width;
        LPTSTR pStr;

        u16TxtComponentIndex = _MApp_ZUI_API_FindFirstComponentIndex(hWnd, ds_type, CP_TEXT_OUT);
        KTVACT_DBG(printf("\nMApp_ZUI_ACT_GetKTVStringLength\nu16TxtComponentIndex = %d\n",u16TxtComponentIndex););
        _MApp_ZUI_API_ConvertComponentToDynamic(CP_TEXT_OUT, u16TxtComponentIndex, &dyna);
    	pStr = MApp_ZUI_ACT_GetDynamicText(hWnd);//pStr = MApp_ZUI_API_GetString(dyna.pString);
        //KTVACT_DBG(printf("\n----pStr = %s----\n",pStr););
        _MApp_ZUI_API_ConvertTextComponentToDynamic(u16TxtComponentIndex, &dyna);
        clrBtn1.Fontfmt.flag = dyna.flag;
        clrBtn1.Fontfmt.ifont_gap = dyna.u8dis;
        clrBtn1.bStringIndexWidth = CHAR_IDX_2BYTE;
        width = msAPI_OSD_GetStrWidth(Font[dyna.eSystemFont].fHandle, (U8*)pStr, &clrBtn1);
        return width;
}

static BOOLEAN MApp_ZUI_ACT_SetKTVCurrentMidDepthIndex(void)
{
	//printf("u8MidDepth=%d,u8CurrentMidlistPageIdx=%d\n",u8MidDepth,u8CurrentMidlistPageIdx);
	HWND hwndCurMidFocus=MApp_ZUI_API_GetFocus();
	if(hwndCurMidFocus <= HWND_KTV_MAIN_MID_ITEM9 && hwndCurMidFocus >= HWND_KTV_MAIN_MID_ITEM0)
	{
		if(1)//(u8MidDepth>=0)&&(u8MidDepth<=2))
		{
			MainMidDepthIndex[u8MidDepth]=UI_KTV_ORDERLIST_NUMBER*(u8CurrentMidlistPageIdx-1)\
				+(hwndCurMidFocus-_hwndListOrderMidlistItem[0])/2;
//			printf("MainMidDepthIndex[u8MidDepth]=%d\n",MainMidDepthIndex[u8MidDepth]);
			return TRUE;
		}
		else
			return FALSE;
	}
	else
		return FALSE;
}
static BOOLEAN MApp_ZUI_ACT_SetKTVFocusByCurrentMidDepthIndex(void)
{
	//printf("depth=%d\nMainMidDepthIndex[u8MidDepth]=%d\n",u8MidDepth,MainMidDepthIndex[u8MidDepth]);

	if(1)//(u8MidDepth>=0)&&(u8MidDepth<=2))
	{
	    if((!MApp_ZUI_API_IsWindowVisible(HWND_KTV_ERROR_INFO_PAGE))
		 	&&(!MApp_ZUI_API_IsWindowVisible(HWND_KTV_SET_BANNER))
		 	&&(!MApp_ZUI_API_IsWindowVisible(HWND_KTV_SEL_BANNER)))
		    {
				hwndPrevFocus = MApp_ZUI_API_GetFocus();
		    }
		hwndCurFocus=_hwndListOrderMidlistItem[MainMidDepthIndex[u8MidDepth]%UI_KTV_ORDERLIST_NUMBER];
		//printf("hwndCurFocus=%d\n",hwndCurFocus);
//		u8CurrentMidlistPageIdx=MainMidDepthIndex[u8MidDepth]/UI_KTV_ORDERLIST_NUMBER+1;
	}
	else
		return FALSE;
	MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_MAIN_MID_LIST);
	MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_MAIN_MID_PAGE_NUM);
	MApp_ZUI_API_SetFocus(hwndCurFocus);
	MApp_ZUI_ACT_SetKTVCurrentMidDepthIndex();
	return TRUE;
}
static BOOLEAN MApp_ZUI_ACT_SetKTVCurrentMidDiskDepthIndex(void)
{
	//printf("MApp_ZUI_ACT_SetKTVCurrentMidDiskDepthIndex    ********************\n");
	//printf("u8MidDepth=%d,u8CurrentMidlistPageIdx=%d\n",u8MidDepth,u8CurrentMidlistPageIdx);
	HWND hwndCurMidDiskFocus=MApp_ZUI_API_GetFocus();
	//printf("hwndCurMidDiskFocus=%d\n",hwndCurMidDiskFocus);
	if(hwndCurMidDiskFocus <= HWND_KTV_MAIN_MID_DISK_ITEM9&& hwndCurMidDiskFocus >= HWND_KTV_MAIN_MID_DISK_ITEM0)
	{
		MainMidDiskDepthIndex[u8MidDepth]=UI_KTV_ORDERLIST_NUMBER*(u8CurrentMidlistPageIdx-1)\
			+(hwndCurMidDiskFocus-_hwndListOrderMidDisklistItem[0])/3;
		//printf("MainMidDepthIndex[u8MidDepth]=%d\n",MainMidDiskDepthIndex[u8MidDepth]);
		return TRUE;
	}
	else
		return FALSE;
}
static BOOLEAN MApp_ZUI_ACT_SetKTVFocusByCurrentMidDiskDepthIndex(void)
{
	//printf("MApp_ZUI_ACT_SetKTVFocusByCurrentMidDepthIndex    ********************\n");
	//printf("depth=%d\nMainMidDiskDepthIndex[u8MidDepth]=%d\n",u8MidDepth,MainMidDiskDepthIndex[u8MidDepth]);
	if(1)//(u8MidDepth>=0)&&(u8MidDepth<=2))
	{
	    if((!MApp_ZUI_API_IsWindowVisible(HWND_KTV_ERROR_INFO_PAGE))
		 	&&(!MApp_ZUI_API_IsWindowVisible(HWND_KTV_SET_BANNER))
		 	&&(!MApp_ZUI_API_IsWindowVisible(HWND_KTV_SEL_BANNER)))
		    {
				hwndPrevFocus = MApp_ZUI_API_GetFocus();
		    }
		hwndCurFocus=_hwndListOrderMidDisklistItem[MainMidDiskDepthIndex[u8MidDepth]%UI_KTV_ORDERLIST_NUMBER];
		//printf("hwndCurFocus=%d\n",hwndCurFocus);
		u8CurrentMidlistPageIdx=MainMidDiskDepthIndex[u8MidDepth]/UI_KTV_ORDERLIST_NUMBER+1;//ȷ����ǰ��page.
		u8CurrentVideoItemsPageIdx = MApp_ZUI_ACT_GetKTVVideoItemsInDiskCount();
		if(0 == u8CurrentVideoItemsPageIdx)
			u8CurrentVideoItemsPageIdx =1;
		u8CurrentMidlistTotalPage = (u8CurrentVideoItemsPageIdx+UI_KTV_ORDERLIST_NUMBER-1)/UI_KTV_ORDERLIST_NUMBER;//ȷ���ܵ�page.
		MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_MAIN_MID_DISK_LIST);
		MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_MAIN_MID_PAGE_NUM);
		MApp_ZUI_API_SetFocus(hwndCurFocus);
		MApp_ZUI_ACT_SetKTVCurrentMidDiskDepthIndex();
		return TRUE;
	}
	else
		return FALSE;
}

/////////////////////////////////////////////////////////
// Customize Window Procedure
//innit lrc string length throng a hide window
BOOLEAN MApp_ZUI_ACT_GetStingLengthForLrc( U8 * pString,U8 Len,TSIZE * pSize )
{
		UNUSED(Len);
	       g_u8lrcString = pString;
		pSize->cx = MApp_ZUI_ACT_GetKTVStringLength(HWND_KTV_LRC_HIDE,DS_NORMAL);
		pSize->cy = 37;
//		printf("\n&&psize width = %d@@\n",pSize->cx);
		return TRUE;
}

static void MApp_ZUI_ACT_Endlrc(void)
{
	MApp_ZUI_API_ShowWindow(HWND_KTV_LRC_SONGNAME,SW_HIDE);
	MApp_ZUI_API_ShowWindow(HWND_KTV_LRC_SINGERNAME,SW_HIDE);
	MApp_ZUI_API_ShowWindow(HWND_KTV_LRC_LINE1,SW_HIDE);
	MApp_ZUI_API_ShowWindow(HWND_KTV_LRC_LINE2,SW_HIDE);
	AdjustTime = 0;
	if(LyricApi_CloseFile())
	{
	    _MAPP_DMP_KTVFb_Destroy();
		IsOpenLrc = FALSE;
		printf("\nclose lrc success!!!\n");
	}
	else
	{
		printf("\nclose lrc failed!!!\n");
	}
	enKKLrcStatus = KTV_LRC_CLOSE;
	bFirstShowLrc = TRUE;
	memset(LyricLien.szLyric,0,sizeof(LyricLien.szLyric));
	memset(LyricLien2.szLyric,0,sizeof(LyricLien2.szLyric));

}

static void MApp_ZUI_ACT_ChangeExtName( U8 * PathFileName ,U8 * szExtName )
{
	U16 i;
	U8 PathFileLength = strlen((const char *)PathFileName);
	U8 szExtLength = strlen((const char *)szExtName);
	if((PathFileName != NULL)&&(szExtName != NULL))
		{
			for(i=PathFileLength;i>0;i--)
			{
				if(PathFileName[i]=='.')
				{
					 strncpy((char *)(PathFileName+i),(const char *)szExtName,szExtLength) ;
					 *(PathFileName+(i-1)+szExtLength+1)='\0';

				        break;
				}
			}
		}

}


static BOOLEAN MApp_ZUI_ACT_OpenKTVLrc(const U8 * aFilePath,U16 FileLen)
{
	if( LyricApi_OpenFile((const U8*)aFilePath,FileLen))
	{
		printf( "LyricApi_OpenFile() call success!\n" );
		return TRUE;
	}
	else
	{
		printf( "LyricApi_OpenFile() call failed!\n" );
		return FALSE;
	}
}
//get one line lrc

static BOOLEAN MApp_ZUI_ACT_GetKTVLrc(TLyricLine *lrc)
     {
            memset(lrc,0,sizeof(TLyricLine) );
		if( LyricApi_GetLyricLine(lrc) )
		{
				//printf( "LyricApi_GetLyricLine() call success!\n" );
//				printf( "LyricLien.wLineNo=%d,LyricLien.wLyricLen=%d\n",lrc->wLineNo,lrc->wLyricLen );
//				printf( "LyricLien.szLyric=%s\n",lrc->szLyric );
			return TRUE;
		}
		else
		{
				//printf( "LyricApi_GetLyricLine() call failed!\n" );
			return FALSE;
		}
     }
//get sung length
static void MApp_ZUI_ACT_GetKTVLrcSunlength(TLyricLine *lrc)
{
 	U32 WSunTime= MApp_WMA_GetCurrentTimeMs()+AdjustTime/15;
	if(wSungLength>0)
	{
		 AdjustTime = AdjustTime + 1;
	}
			//printf("\nWSunTime= %ld\n",WSunTime);
	if( LyricApi_GetSungLyricLen(lrc->wLineNo,WSunTime,&wSungLength,&bIsFinished) )
	{
				//printf( "\nLyricApi_GetSungLyricLen() call success!\n" );
		printf( "\nwLineNo=%d,dwStreamTime=%ld,wSungLength=%d\n",lrc->wLineNo,WSunTime,wSungLength );
		if( bIsFinished )
		{
			//printf( "\nbIsFinished is TTRUE!\n" );
		}
		else
		{
			//printf( "\nbIsFinished is TFALSE!\n" );
		}
	}
	else
	{
	      // wSungLength = 0;
	       //bIsFinished = TRUE;
		//printf( "\nLyricApi_GetSungLyricLen() call failed!\n" );
		if( bIsFinished )
		{
			//printf( "\nbIsFinished is TTRUE!\n" );
		}
		else
		{
			//printf( "\nbIsFinished is TFALSE!\n" );
		}
	}
}

//get song's name and singer's name
static BOOLEAN MApp_ZUI_ACT_GetKTVLrcLabel(void)
{
	memset(aLabel_TI,0,128 );
	memset(aLabel_AR,0,128 );
	U16 Label_TI_Len = sizeof(aLabel_TI);
	U16 Label_AR_Len = sizeof(aLabel_AR);
	//printf( "Label_TI_Len=%d\n",Label_TI_Len );
	if( LyricApi_GetIdLabel(ID_LABEL_TI,aLabel_TI,&Label_TI_Len)\
		&&LyricApi_GetIdLabel(ID_LABEL_AR,aLabel_AR,&Label_AR_Len))
	{
	   //int a=0;
//	printf( "LyricApi_GetIdLabel() call success!\n" );
//	printf( "aLabel_TI=%s,Len=%d\n",aLabel_TI,Label_TI_Len );
//	printf( "aLabel_AR=%s,Len=%d\n",aLabel_AR,Label_AR_Len );
		//MApp_ZUI_API_ShowWindow(HWND_KTV_LRC_HIDE,SW_SHOW);
		//a=MApp_ZUI_ACT_GetKTVStringLength(HWND_KTV_LRC_HIDE,DS_NORMAL);
       // printf("\na==============:%d\n",a);
		return TRUE;
	}
	else
	{
		//printf( "LyricApi_GetIdLabel() call failed!\n" );
		return FALSE;
	}
}



void MApp_ZUI_ACT_AppShowKTV(void)
{
    HWND wnd;
    RECT rect;
    E_OSD_ID osd_id = E_OSD_KTV;

    g_GUI_WindowList = GetWindowListOfOsdTable(osd_id);
    g_GUI_WinDrawStyleList = GetWindowStyleOfOsdTable(osd_id);
    g_GUI_WindowPositionList = GetWindowPositionOfOsdTable(osd_id);
#if ZUI_ENABLE_ALPHATABLE
    g_GUI_WinAlphaDataList = GetWindowAlphaDataOfOsdTable(osd_id);
#endif
    HWND_MAX = GetWndMaxOfOsdTable(osd_id);
    OSDPAGE_BLENDING_ENABLE = IsBlendingEnabledOfOsdTable(osd_id);
    OSDPAGE_BLENDING_VALUE = GetBlendingValueOfOsdTable(osd_id);

    if (!_MApp_ZUI_API_AllocateVarData())
    {
        ZUI_DBG_FAIL(printf("[ZUI]ALLOC\n"));
        ABORT();
        return;
    }

    RECT_SET(rect,
        ZUI_KTV_XSTART, ZUI_KTV_YSTART,
        ZUI_KTV_WIDTH, ZUI_KTV_HEIGHT);

    if (!MApp_ZUI_API_InitGDI(&rect))
    {
        ZUI_DBG_FAIL(printf("[ZUI]GDIINIT\n"));
        ABORT();
        return;
    }

    for (wnd = 0; wnd < HWND_MAX; wnd++)
    {
        //printf("create msg: %lu\n", (U32)wnd);
        MApp_ZUI_API_SendMessage(wnd, MSG_CREATE, 0);
    }
	MApp_ZUI_API_ShowWindow(HWND_MAINFRAME,SW_HIDE);
	//MApp_ZUI_API_ShowWindow(HWND_KTV_CONTROL_BG,SW_HIDE);
	MApp_ZUI_API_ShowWindow(HWND_KTV_TRANSPARENT_BG, SW_SHOW);
	MApp_ZUI_API_ShowWindow(HWND_KTV_CONTROL_BG, SW_SHOW);
	//MApp_ZUI_API_ShowWindow(HWND_KTV_BOTTOM_SOH_TEXT, SW_SHOW);
	MApp_ZUI_API_SetFocus(HWND_KTV_BUTTON_ORDER);
	MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_PAGE_EXIT, E_ZUI_STATE_RUNNING);
	MApp_Photo_SlideShow(FALSE);
}


//////////////////////////////////////////////////////////
// Key Handler
static void MApp_ActKtv_Main_UpDownKey(bool bSetFoucsOnCurrentPlayingIdx)
{
    // TODO: fix me!!
    U8 i;
    HWND hwndTemp;

    hwndCurFocus = MApp_ZUI_API_GetFocus();
	if(hwndCurFocus <= HWND_KTV_MAIN_LEFT_ITEM9 && hwndCurFocus >= HWND_KTV_MAIN_LEFT_ITEM0)
	{

	    for(i = 0; i < UI_KTV_ORDERLIST_NUMBER; i++)
	    {
	    	if (hwndCurFocus == _hwndListOrderLeftlistItem[i])
				break;
	    }

		if(!bUSBHasDateBase)
			return;

		if(bSetFoucsOnCurrentPlayingIdx)
		{
			if((UI_KTV_LEFTITEMS-1)==i)//if (i == UI_KTV_ORDERLIST_NUMBER - 1)//if you add a new item ,please add one here
				i = 0;
			else
				i ++;
		}
		else
		{
			if (i == 0)
				i = UI_KTV_LEFTITEMS-1;//i = UI_KTV_ORDERLIST_NUMBER - 1;//if you add a new item ,please add one here
			else
				i --;
		}
		MApp_ZUI_API_SetFocus(_hwndListOrderLeftlistItem[i]);
		if(!MApp_ZUI_API_IsWindowVisible(HWND_KTV_MAIN_MID_LIST))
		{
			MApp_ZUI_API_ShowWindow(HWND_KTV_MAIN_MID_LIST,SW_SHOW);
		}
		MApp_ZUI_API_ShowWindow(HWND_KTV_MAIN_MID_PINYIN_BANNER,SW_HIDE);
		MApp_ZUI_API_ShowWindow(HWND_KTV_MAIN_MID_PINYIN_LABLE,SW_HIDE);

	    /////////////////////////////////////////////////////
		u8CurrentMidlistPageIdx = 1;
		switch(i)
		{
		case 0:
			MApp_ZUI_API_ShowWindow(HWND_KTV_MAIN_MID_DISK_LIST,SW_HIDE);
			MApp_ZUI_API_ShowWindow(HWND_KTV_MAIN_MID_SONG_LIST,SW_HIDE);
			MApp_ZUI_API_ShowWindow(HWND_KTV_MAIN_MID_LIST,SW_SHOW);
			MApp_ZUI_API_ShowWindow(HWND_KTV_MAIN_MID_PINYIN_BANNER,SW_HIDE);
			MApp_ZUI_API_ShowWindow(HWND_KTV_MAIN_MID_PINYIN_LABLE,SW_HIDE);
			eDBFFileInfo = EN_SINGER_SORT;
			MApp_ZUI_ACT_GetKTVOpenDBF(0,1,0);
			u8CurrentSingerSortPageIdx = MApp_ZUI_ACT_GetKTVSingerSortCount();
			MApp_ZUI_API_InvalidateWindow(HWND_KTV_MAIN_MID_LIST);
			break;
		case 1:
		    MApp_ZUI_ACT_GetKTVReleaseDBF();
		    eDBFFileInfo = EN_CHARACTER_SORT;
		    MApp_ZUI_ACT_GetKTVOpenDBF(0,1,0);
		    u8CurrentSongCoutPageIdx = MApp_ZUI_ACT_GetKTVSongCountCount();
                 u8CurrentMidlistTotalPage = (u8CurrentSongCoutPageIdx+UI_KTV_ORDERLIST_NUMBER-1)/UI_KTV_ORDERLIST_NUMBER;
			MApp_ZUI_API_InvalidateWindow(HWND_KTV_MAIN_MID_LIST);
		    break;
		case 2:
		    MApp_ZUI_ACT_GetKTVReleaseDBF();
		    eDBFFileInfo = EN_SONG_SORT;
		    MApp_ZUI_ACT_GetKTVOpenDBF(0,1,0);
		    u8CurrentSongSortPageIdx = MApp_ZUI_ACT_GetKTVSongSortCount();
                 u8CurrentMidlistTotalPage = (u8CurrentSongSortPageIdx+UI_KTV_ORDERLIST_NUMBER-1)/UI_KTV_ORDERLIST_NUMBER;
			MApp_ZUI_API_InvalidateWindow(HWND_KTV_MAIN_MID_LIST);
		    break;
		case 3:
			MApp_ZUI_ACT_GetKTVReleaseDBF();
			eDBFFileInfo = EN_LANGUAGE_SORT;
			MApp_ZUI_ACT_GetKTVOpenDBF(0,1,0);
			u8CurrentLangSortPageIdx = MApp_ZUI_ACT_GetKTVLanguageSortCount();
			u8CurrentMidlistTotalPage = (u8CurrentLangSortPageIdx+UI_KTV_ORDERLIST_NUMBER-1)/UI_KTV_ORDERLIST_NUMBER;
			MApp_ZUI_API_ShowWindow(HWND_KTV_MAIN_MID_LIST,SW_SHOW);
			MApp_ZUI_API_ShowWindow(HWND_KTV_MAIN_MID_PINYIN_LABLE,SW_HIDE);
			MApp_ZUI_API_ShowWindow(HWND_KTV_MAIN_MID_PINYIN_BANNER,SW_HIDE);
			MApp_ZUI_API_ShowWindow(HWND_KTV_MAIN_MID_PINYIN_BANNER_STR,SW_HIDE);
                    break;
		case 4:
			memset(szPinYinInputValue,0,16);
			memset(InputChar,0,strlen(InputChar));
			MApp_ZUI_API_ShowWindow(HWND_KTV_MAIN_MID_DISK_LIST,SW_HIDE);
			MApp_ZUI_API_ShowWindow(HWND_KTV_MAIN_MID_SONG_LIST,SW_HIDE);
			MApp_ZUI_API_ShowWindow(HWND_KTV_MAIN_MID_LIST,SW_HIDE);
			MApp_ZUI_API_ShowWindow(HWND_KTV_MAIN_MID_PINYIN_LABLE,SW_SHOW);
			MApp_ZUI_API_ShowWindow(HWND_KTV_MAIN_MID_PINYIN_BANNER,SW_SHOW);
			MApp_ZUI_API_ShowWindow(HWND_KTV_MAIN_MID_PINYIN_BANNER_STR,SW_SHOW);
//			MApp_ZUI_ACT_GetKTVReleaseDBF();
			eDBFFileInfo = EN_SONG_PINYIN;
//			MApp_ZUI_ACT_GetKTVOpenDBF(0);
			u8CurrentLangSortPageIdx = 1;//MApp_ZUI_ACT_GetKTVLanguageSortCount();
			u8CurrentMidlistTotalPage = 1;//(u8CurrentSonglistPageIdx+UI_KTV_PINYINORDER_NUMBER-1)/UI_KTV_PINYINORDER_NUMBER;
			break;
              case 5:
                {
			MApp_ZUI_API_ShowWindow(HWND_KTV_MAIN_MID_LIST,SW_HIDE);
			MApp_ZUI_API_ShowWindow(HWND_KTV_MAIN_MID_DISK_LIST,SW_SHOW);
			MApp_ZUI_API_ShowWindow(HWND_KTV_MAIN_MID_SONG_LIST,SW_HIDE);
                    MApp_ZUI_ACT_GetKTVReleaseDBF();
			U32 Handle=0;//1;
			U16 wStep=0;//UI_KTV_ORDERLIST_NUMBER;
			U8 aTempPath[128]={0};
			strcpy( (char*)aTempPath,(const char *)"\\" );
                    strcpy( (char*)aSearchPath,(const char *)"\\" );
			U16 wPathLen = __ASCIItoUnicode((U8*)aTempPath);
			if( 0==FMI_GetMediaData( aTempPath,wPathLen,FMI_MDT_VIDEO,&Handle,wStep,&pRecordSet ) )
			{
				printf( "FMI_GetMediaData() call success!\n" );
				eDBFFileInfo = EN_SONG_BY_DISK;
				u8CurrentVideoItemsPageIdx = MApp_ZUI_ACT_GetKTVVideoItemsInDiskCount();
				u8CurrentMidlistTotalPage = (u8CurrentVideoItemsPageIdx+UI_KTV_ORDERLIST_NUMBER-1)/UI_KTV_ORDERLIST_NUMBER;
			}
			else
			{
				printf( "FMI_GetMediaData() call failed!\n" );
			}
	          }
                 break;
		default:
			MApp_ZUI_ACT_GetKTVReleaseDBF();
			eDBFFileInfo = EN_SINGER_LIST;
			MApp_ZUI_ACT_GetKTVOpenDBF(0,1,0);
			break;
		}
        MApp_ZUI_API_InvalidateWindow(HWND_KTV_MAIN_MID_PAGE_NUM);
	}
	else if(hwndCurFocus <= HWND_KTV_MAIN_MID_SONG_ITEM9 && hwndCurFocus >= HWND_KTV_MAIN_MID_SONG_ITEM0)
	{
	    for(i = 0; i < UI_KTV_ORDERLIST_NUMBER; i++)
	    {
	    	if (hwndCurFocus == _hwndListOrderMidSonglistItem[i])
				break;
	    }

		if(eDBFFileInfo == EN_SONG_PINYIN)
		{
			if(u8CurrentLangSortPageIdx == 0)
				return;

			if(bSetFoucsOnCurrentPlayingIdx)
			{
			    if(u8PageIdx>=UI_KTV_ORDERLIST_NUMBER)
			    {
					if (i == UI_KTV_ORDERLIST_NUMBER - 1)
					{
						i = 2;
	                               if((u8CurrentMidlistPageIdx)<u8CurrentMidlistTotalPage)
	                                {
	                                        u8CurrentMidlistPageIdx+=1;
							MApp_ZUI_ACT_GetKTVReleaseDBF();
							MApp_ZUI_ACT_GetKTVNextPage((U8)u8CurrentMidlistPageIdx);
	                                }
	                                else
	                                      u8CurrentMidlistPageIdx = u8CurrentMidlistTotalPage;
	                             }
					else
						i ++;
			    }
				else
				{
					if (i == u8PageIdx + 1)
					{
						if(u8CurrentMidlistPageIdx != u8CurrentMidlistTotalPage)
						{
						    i = 2;
						    if((u8CurrentMidlistPageIdx)<u8CurrentMidlistTotalPage)
						    {
						        u8CurrentMidlistPageIdx+=1;
							 MApp_ZUI_ACT_GetKTVReleaseDBF();
							 MApp_ZUI_ACT_GetKTVNextPage((U8)u8CurrentMidlistPageIdx);
						    }
						    else
						         u8CurrentMidlistPageIdx = u8CurrentMidlistTotalPage;
						}
					}
					else
					{
					  i ++;
					}
				}
			}
			else
			{
				if (i == 2)
                           {
					if(u8CurrentMidlistPageIdx!=1)
					{
						{
						    u8CurrentMidlistPageIdx-=1;
							MApp_ZUI_ACT_GetKTVReleaseDBF();
							MApp_ZUI_ACT_GetKTVNextPage((U8)u8CurrentMidlistPageIdx);
						}
                                         u8PageIdx+= UI_KTV_PINYINORDER_NUMBER;

						if(u8PageIdx>=UI_KTV_ORDERLIST_NUMBER)
							i = UI_KTV_ORDERLIST_NUMBER - 1;
						else
							i = (u8PageIdx - 2*u8CurrentMidlistPageIdx)-1;
					}
					else
                                       u8CurrentMidlistPageIdx =1;
                           }
				else
					i --;
			}
			MApp_ZUI_API_SetFocus(_hwndListOrderMidSonglistItem[i]);
			MApp_ZUI_ACT_SetKTVCurrentMidDepthIndex();

			hwndTemp = HWND_KTV_MAIN_MID_SONG_ITEM0;
			do
			{
				MApp_ZUI_API_InvalidateWindow(hwndTemp);
				hwndTemp++;
			}while(hwndTemp <= HWND_KTV_MAIN_MID_SONG_ITEM9 && hwndTemp >= HWND_KTV_MAIN_MID_SONG_ITEM0);
			MApp_ZUI_API_InvalidateWindow(HWND_KTV_MAIN_MID_PAGE_NUM);
		}
		else
		{
			if(bSetFoucsOnCurrentPlayingIdx)
			{
			    if(u8PageIdx>=UI_KTV_ORDERLIST_NUMBER)
			    {
					if (i == UI_KTV_ORDERLIST_NUMBER - 1)
					{
						i = 0;
	                                if((u8CurrentMidlistPageIdx)<u8CurrentMidlistTotalPage)
	                               {
	                                        u8CurrentMidlistPageIdx+=1;
							MApp_ZUI_ACT_GetKTVReleaseDBF();
							MApp_ZUI_ACT_GetKTVNextPage((U8)u8CurrentMidlistPageIdx);
	                                }
	                                else
	                                       u8CurrentMidlistPageIdx = u8CurrentMidlistTotalPage;
	                   }
				else
					i ++;
			    }
				else
				{
					if (i == u8PageIdx - 1)
					{
						if(u8CurrentMidlistPageIdx != u8CurrentMidlistTotalPage)
						{
						    i = 0;
						    if((u8CurrentMidlistPageIdx)<u8CurrentMidlistTotalPage)
						    {
						        u8CurrentMidlistPageIdx+=1;
							 MApp_ZUI_ACT_GetKTVReleaseDBF();
							  MApp_ZUI_ACT_GetKTVNextPage((U8)u8CurrentMidlistPageIdx);
						    }
						    else
						         u8CurrentMidlistPageIdx = u8CurrentMidlistTotalPage;
						}
					}
					else
					{
					    i ++;
					}
				}
			}
			else
			{
				if (i == 0)
                            {
					if(u8CurrentMidlistPageIdx!=1)
					{

					       u8CurrentMidlistPageIdx-=1;
						MApp_ZUI_ACT_GetKTVReleaseDBF();
						MApp_ZUI_ACT_GetKTVNextPage((U8)u8CurrentMidlistPageIdx);

					       u8PageIdx+= UI_KTV_ORDERLIST_NUMBER;

						if(u8PageIdx>=UI_KTV_ORDERLIST_NUMBER)
							i = UI_KTV_ORDERLIST_NUMBER - 1;
						else
							i = u8PageIdx-1;
					}
					else
                                        u8CurrentMidlistPageIdx =1;
                             }
				else
					i --;
			}
			MApp_ZUI_API_SetFocus(_hwndListOrderMidSonglistItem[i]);
			MApp_ZUI_ACT_SetKTVCurrentMidDepthIndex();

			hwndTemp = HWND_KTV_MAIN_MID_SONG_ITEM0;
			do
			{
				MApp_ZUI_API_InvalidateWindow(hwndTemp);
				hwndTemp++;
			}while(hwndTemp <= HWND_KTV_MAIN_MID_SONG_ITEM9 && hwndTemp >= HWND_KTV_MAIN_MID_SONG_ITEM0);
			MApp_ZUI_API_InvalidateWindow(HWND_KTV_MAIN_MID_PAGE_NUM);
		}
	}
	else if(hwndCurFocus <= HWND_KTV_MAIN_MID_ITEM9 && hwndCurFocus >= HWND_KTV_MAIN_MID_ITEM0)
	{
	    for(i = 0; i < UI_KTV_ORDERLIST_NUMBER; i++)
	    {
	    	if (hwndCurFocus == _hwndListOrderMidlistItem[i])
				break;
	    }

		if(eDBFFileInfo == EN_SONG_PINYIN)
		{
			if(u8CurrentLangSortPageIdx == 0)
				return;

			if(bSetFoucsOnCurrentPlayingIdx)
			{
			    if(u8PageIdx>=UI_KTV_ORDERLIST_NUMBER)
			    {
					if (i == UI_KTV_ORDERLIST_NUMBER - 1)
					{
						i = 2;
	                                 if((u8CurrentMidlistPageIdx)<u8CurrentMidlistTotalPage)
	                                  {
	                                        u8CurrentMidlistPageIdx+=1;
							MApp_ZUI_ACT_GetKTVReleaseDBF();
							MApp_ZUI_ACT_GetKTVNextPage((U8)u8CurrentMidlistPageIdx);
	                                   }
	                                 else
	                                       u8CurrentMidlistPageIdx = u8CurrentMidlistTotalPage;
	                           }
					else
						i ++;
			    }
				else
				{
					if (i == u8PageIdx + 1)
					{
						if(u8CurrentMidlistPageIdx != u8CurrentMidlistTotalPage)
						{
						    i = 2;
						    if((u8CurrentMidlistPageIdx)<u8CurrentMidlistTotalPage)
						    {
						             u8CurrentMidlistPageIdx+=1;
								MApp_ZUI_ACT_GetKTVReleaseDBF();
								MApp_ZUI_ACT_GetKTVNextPage((U8)u8CurrentMidlistPageIdx);
						    }
						    else
						         u8CurrentMidlistPageIdx = u8CurrentMidlistTotalPage;
						}
					}
					else
					{
					     i ++;
					}
				}
			}
			else
			{
				if (i == 2)
                          {
					if(u8CurrentMidlistPageIdx!=1)
					{
						{
						    u8CurrentMidlistPageIdx-=1;
							MApp_ZUI_ACT_GetKTVReleaseDBF();
							MApp_ZUI_ACT_GetKTVNextPage((U8)u8CurrentMidlistPageIdx);
						}
					       u8PageIdx+= UI_KTV_PINYINORDER_NUMBER;

						if(u8PageIdx>=UI_KTV_ORDERLIST_NUMBER)
							i = UI_KTV_ORDERLIST_NUMBER - 1;
						else
							i = (u8PageIdx - 2*u8CurrentMidlistPageIdx)-1;
					}
					else
                                       u8CurrentMidlistPageIdx =1;
                            }
				else
					i --;
			}
			MApp_ZUI_API_SetFocus(_hwndListOrderMidlistItem[i]);
			MApp_ZUI_ACT_SetKTVCurrentMidDepthIndex();
		}
		else
		{
			if(bSetFoucsOnCurrentPlayingIdx)
			{
			    if(u8PageIdx>=UI_KTV_ORDERLIST_NUMBER)
			    {
					if (i == UI_KTV_ORDERLIST_NUMBER - 1)
					{
						i = 0;
	                               if((u8CurrentMidlistPageIdx)<u8CurrentMidlistTotalPage)
	                              {
	                                       u8CurrentMidlistPageIdx+=1;
							MApp_ZUI_ACT_GetKTVReleaseDBF();
							MApp_ZUI_ACT_GetKTVNextPage((U8)u8CurrentMidlistPageIdx);
	                               }
	                              else
	                                     u8CurrentMidlistPageIdx = u8CurrentMidlistTotalPage;
	                           }
					else
						i ++;
			    }
				else
				{
					if (i == u8PageIdx - 1)
					{
						if(u8CurrentMidlistPageIdx != u8CurrentMidlistTotalPage)
						{
						    i = 0;
						    if((u8CurrentMidlistPageIdx)<u8CurrentMidlistTotalPage)
						    {
						              u8CurrentMidlistPageIdx+=1;
								MApp_ZUI_ACT_GetKTVReleaseDBF();
								MApp_ZUI_ACT_GetKTVNextPage((U8)u8CurrentMidlistPageIdx);
						    }
						    else
						      u8CurrentMidlistPageIdx = u8CurrentMidlistTotalPage;
						}
					}
					else
					  i ++;
				}
			}
			else
			{
				if (i == 0)
                           {
					if(u8CurrentMidlistPageIdx!=1)
					{

					       u8CurrentMidlistPageIdx-=1;
						MApp_ZUI_ACT_GetKTVReleaseDBF();
						MApp_ZUI_ACT_GetKTVNextPage((U8)u8CurrentMidlistPageIdx);

					      u8PageIdx+= UI_KTV_ORDERLIST_NUMBER;

						if(u8PageIdx>=UI_KTV_ORDERLIST_NUMBER)
							i = UI_KTV_ORDERLIST_NUMBER - 1;
						else
							i = u8PageIdx-1;
					}
					else
                                        u8CurrentMidlistPageIdx =1;
                           }
				else
					i --;
			}
			MApp_ZUI_API_SetFocus(_hwndListOrderMidlistItem[i]);
			MApp_ZUI_ACT_SetKTVCurrentMidDepthIndex();
		}

		hwndTemp = HWND_KTV_MAIN_MID_ITEM0;
		do
		{
			MApp_ZUI_API_InvalidateWindow(hwndTemp);
			hwndTemp++;
		}while(hwndTemp <= HWND_KTV_MAIN_MID_ITEM9 && hwndTemp >= HWND_KTV_MAIN_MID_ITEM0);
		MApp_ZUI_API_InvalidateWindow(HWND_KTV_MAIN_MID_PAGE_NUM);
	}
	else if(hwndCurFocus <= HWND_KTV_MAIN_MID_DISK_ITEM9 && hwndCurFocus >= HWND_KTV_MAIN_MID_DISK_ITEM0)
	{
	    for(i = 0; i < UI_KTV_ORDERLIST_NUMBER; i++)
	    {
	    	if (hwndCurFocus == _hwndListOrderMidDisklistItem[i])
				break;
	    }

		if(bSetFoucsOnCurrentPlayingIdx)
		{
		    if(u8PageIdx>=UI_KTV_ORDERLIST_NUMBER)
		    {
				if (i == UI_KTV_ORDERLIST_NUMBER - 1)
				{
					i = 0;
	                           if((u8CurrentMidlistPageIdx)<u8CurrentMidlistTotalPage)
	                         {
	                               u8CurrentMidlistPageIdx+=1;
//						U16 wPathLen = __ASCIItoUnicode((U8*)TempFilePath);
//						TLONG Handle = u8CurrentMidlistPageIdx;
//						MApp_ZUI_ACT_GetKTVReleaseDBF();
//						FMI_GetMediaData((TU8 *)TempFilePath,wPathLen,FMI_MDT_VIDEO,&Handle,UI_KTV_ORDERLIST_NUMBER,&pRecordSet );
	                         }
	                        else
	                               u8CurrentMidlistPageIdx = u8CurrentMidlistTotalPage;
	                     }
				else
					i ++;
		    }
			else
			{
				if (i == u8PageIdx - 1)
				{
					if(u8CurrentMidlistPageIdx != u8CurrentMidlistTotalPage)
					{
					    i = 0;
					    if((u8CurrentMidlistPageIdx)<u8CurrentMidlistTotalPage)
					    {
					             u8CurrentMidlistPageIdx+=1;
//							U16 wPathLen = __ASCIItoUnicode((U8*)TempFilePath);
//							TLONG Handle = u8CurrentMidlistPageIdx;
//							MApp_ZUI_ACT_GetKTVReleaseDBF();
//							FMI_GetMediaData((TU8 *)TempFilePath,wPathLen,FMI_MDT_VIDEO,&Handle,UI_KTV_ORDERLIST_NUMBER,&pRecordSet );
					    }
					    else
					      u8CurrentMidlistPageIdx = u8CurrentMidlistTotalPage;
					}
				}
				else
					i ++;
			}
		}
		else
		{
			if (i == 0)
            {
               	if(u8CurrentMidlistPageIdx!=1)
			{
					u8CurrentMidlistPageIdx-=1;
//					U16 wPathLen = __ASCIItoUnicode((U8*)TempFilePath);
//					TLONG Handle = u8CurrentMidlistPageIdx;
//					MApp_ZUI_ACT_GetKTVReleaseDBF();
//					FMI_GetMediaData((TU8 *)TempFilePath,wPathLen,FMI_MDT_VIDEO,&Handle,UI_KTV_ORDERLIST_NUMBER,&pRecordSet );
                                 u8PageIdx+= UI_KTV_ORDERLIST_NUMBER;

					if(u8PageIdx>=UI_KTV_ORDERLIST_NUMBER)
						i = UI_KTV_ORDERLIST_NUMBER - 1;
					else
						i = u8PageIdx-1;
                }
               else
                    u8CurrentMidlistPageIdx =1;
            }
			else
				i --;
		}
		MApp_ZUI_API_SetFocus(_hwndListOrderMidDisklistItem[i]);
		MApp_ZUI_ACT_SetKTVCurrentMidDiskDepthIndex();

		hwndTemp = HWND_KTV_MAIN_MID_DISK_ITEM0;
		do
		{
			MApp_ZUI_API_InvalidateWindow(hwndTemp);
			hwndTemp++;
		}while(hwndTemp <= HWND_KTV_MAIN_MID_DISK_ITEM9 && hwndTemp >= HWND_KTV_MAIN_MID_DISK_ITEM0);
		MApp_ZUI_API_InvalidateWindow(HWND_KTV_MAIN_MID_PAGE_NUM);
	}
	else if(hwndCurFocus <= HWND_KTV_MAIN_RIGHT_ITEM9 && hwndCurFocus >= HWND_KTV_MAIN_RIGHT_ITEM0)
	{
	    for(i = 0; i < UI_KTV_ORDERLIST_NUMBER; i++)
	    {
	    	if (hwndCurFocus == _hwndListOrderRightlistItem[i])
				break;
	    }

            if(u8RightPageIdx>0)
            {
		if(bSetFoucsOnCurrentPlayingIdx)
		{
		    if(u8RightPageIdx >=UI_KTV_ORDERLIST_NUMBER)
		    {
				if (i == UI_KTV_ORDERLIST_NUMBER - 1)
	                     {
				    i = 0;
	                          if((u8CurrentRightlistPageIdx)<u8CurrentRightlistTotalPage)
	                               u8CurrentRightlistPageIdx+=1;
	                          else
	                               u8CurrentRightlistPageIdx = u8CurrentRightlistTotalPage;
	                     }
				else
					i ++;
		    }
                 else
			{
				if (i == u8RightPageIdx - 1)
				{
					i = 0;
					if((u8CurrentRightlistPageIdx)<u8CurrentRightlistTotalPage)
						u8CurrentRightlistPageIdx+=1;
					else
						u8CurrentRightlistPageIdx = u8CurrentRightlistTotalPage;
				}
				else
					i ++;
			}
		}
		else
		{
			if (i == 0)
                  {
                      if(u8CurrentRightlistPageIdx!=1)
                      {
                       	u8CurrentRightlistPageIdx-=1;
                          u8RightPageIdx+= UI_KTV_ORDERLIST_NUMBER;
                      }
                       else
                          	u8CurrentRightlistPageIdx =1;

                        if(u8RightPageIdx>=UI_KTV_ORDERLIST_NUMBER)
                             i = UI_KTV_ORDERLIST_NUMBER - 1;
                       else
                             i = u8RightPageIdx-1;
                   }
			else
				i --;
		  }
		}
		MApp_ZUI_API_SetFocus(_hwndListOrderRightlistItem[i]);
	}
}


static void MApp_ActKtv_Main_LeftRightKey(BOOLEAN bFlag)
{
    hwndCurFocus = MApp_ZUI_API_GetFocus();
	if(MApp_ZUI_API_IsWindowVisible(HWND_KTV_MAIN_BG))
	{
		if(hwndCurFocus <= HWND_KTV_MAIN_LEFT_ITEM9 && hwndCurFocus >= HWND_KTV_MAIN_LEFT_ITEM0)
		{
			if(bFlag)
				return;
			else
			{
				if(hwndCurFocus == HWND_KTV_MAIN_LEFT_ITEM4)
				{
					bPinYinInputMode = TRUE;
					hwndPrevLeftFocus = hwndCurFocus;
					MApp_ZUI_API_SetFocus(HWND_KTV_MAIN_MID_PINYIN_BANNER_CUR_CHA);
				}
				else
				{
					hwndPrevLeftFocus = hwndCurFocus;
					if(eDBFFileInfo == EN_SONG_BY_DISK)
					{
						MApp_ZUI_API_SetFocus(_hwndListOrderMidDisklistItem[0]);
						MApp_ZUI_ACT_SetKTVCurrentMidDiskDepthIndex();
					}
					else
					{
						MApp_ZUI_API_SetFocus(_hwndListOrderMidlistItem[0]);
						MApp_ZUI_ACT_SetKTVCurrentMidDepthIndex();
					}
				}
			}
		}
		else if(hwndCurFocus <= HWND_KTV_MAIN_MID_ITEM9 && hwndCurFocus >= HWND_KTV_MAIN_MID_ITEM0)
		{
			if(bFlag)
			{
				if(u8MidDepth==0)
					MApp_ZUI_API_SetFocus(hwndPrevLeftFocus);//_hwndListOrderLeftlistItem[0]);
			}
			else
			{
				if(KLM_GetOrderNum()>0)
					MApp_ZUI_API_SetFocus(_hwndListOrderRightlistItem[0]);
			}
		}
		else if(hwndCurFocus <= HWND_KTV_MAIN_MID_DISK_ITEM9 && hwndCurFocus >= HWND_KTV_MAIN_MID_DISK_ITEM0)
		{
			if(bFlag)
			{
				MApp_ZUI_API_SetFocus(_hwndListOrderLeftlistItem[5]);
			}
			else
			{
				if(KLM_GetOrderNum()>0)
					MApp_ZUI_API_SetFocus(_hwndListOrderRightlistItem[0]);
			}
		}
		else if(hwndCurFocus <= HWND_KTV_MAIN_RIGHT_ITEM9 && hwndCurFocus >= HWND_KTV_MAIN_RIGHT_ITEM0)
		{
			if(bFlag)
			{
				if(eDBFFileInfo == EN_SONG_BY_DISK)
				{
					//MApp_ZUI_API_SetFocus(_hwndListOrderMidDisklistItem[0]);
					//MApp_ZUI_ACT_SetKTVCurrentMidDiskDepthIndex();
					MApp_ZUI_ACT_SetKTVFocusByCurrentMidDiskDepthIndex();
				}
				else
				{
					//MApp_ZUI_API_SetFocus(_hwndListOrderMidlistItem[0]);
					//MApp_ZUI_ACT_SetKTVCurrentMidDepthIndex();
					MApp_ZUI_ACT_SetKTVFocusByCurrentMidDepthIndex();
				}
			}
			else
				return;
		}
	}
	else if(MApp_ZUI_API_IsWindowVisible(HWND_KTV_CONTROL_BG) && !MApp_ZUI_API_IsWindowVisible(HWND_KTV_SET_BANNER)&&(!MApp_ZUI_API_IsWindowVisible(HWND_KTV_SEL_BANNER)))
	{
		int i;
		if(hwndCurFocus <= HWND_KTV_BUTTON_EXIT&& hwndCurFocus >= HWND_KTV_BUTTON_ORDER)
		{
		    for(i = 0; i < UI_KTV_CONTROLLIST_NUMBER; i++)
		    {
		    	if (hwndCurFocus == _hwndListControlButtonListItem[i])
					break;
		    }
			if(bFlag)
			{
				if (i == 0)
					i = UI_KTV_CONTROLLIST_NUMBER-1;
				else
					i --;
			}
			else
			{
				if (i == UI_KTV_CONTROLLIST_NUMBER-1)
					i = 0;
				else
					i ++;
			}
			MApp_ZUI_API_SetFocus(_hwndListControlButtonListItem[i]);
		}
	}
	else if(MApp_ZUI_API_IsWindowVisible(HWND_KTV_SET_BANNER))
	{
		switch(hwndCurFocus)
		{
			case HWND_KTV_SET_ACC_VOLUME:
			{
				if(bFlag)
					MApp_ZUI_ACT_ExecuteKTVAction(EN_EXE_KTV_DEC_BGVOLUME);
				else
					MApp_ZUI_ACT_ExecuteKTVAction(EN_EXE_KTV_INC_BGVOLUME);
			}
				break;
			case HWND_KTV_SET_MICORPHONE_VOLUME:
			{
				if(bFlag)
					MApp_ZUI_ACT_ExecuteKTVAction(EN_EXE_KTV_DEC_MICVOLUME);
				else
					MApp_ZUI_ACT_ExecuteKTVAction(EN_EXE_KTV_INC_MICVOLUME);
			}
				break;
			case HWND_KTV_SET_MIX_VOLUME:
				if(bFlag)
					MApp_ZUI_ACT_ExecuteKTVAction(EN_EXE_KTV_DEC_MIXVOLUME);
				else
					MApp_ZUI_ACT_ExecuteKTVAction(EN_EXE_KTV_INC_MIXVOLUME);

				break;
			default:
				break;
		}
	}
    else if(MApp_ZUI_API_IsWindowVisible(HWND_KTV_SEL_BANNER))
    {
        if(KLM_GetOrderNum()>0)
            {
		switch(hwndCurFocus)
		{
                    case HWND_KTV_SEL_BANNER_ITEM0_TEXT:
                    {
            			if(bFlag)
                               hwndCurFocus = HWND_SEL_BANNER_ITEM0_BUTTON_2;
            			else
                              hwndCurFocus = HWND_SEL_BANNER_ITEM0_BUTTON_1;
                    }
			break;
	             case HWND_SEL_BANNER_ITEM0_BUTTON_1:
	             {
                         if(bFlag)
                              hwndCurFocus = HWND_KTV_SEL_BANNER_ITEM0_TEXT;
                         else
	                       hwndCurFocus = HWND_SEL_BANNER_ITEM0_BUTTON_2;
                     }
                    break;
			case HWND_SEL_BANNER_ITEM0_BUTTON_2:
			{
				if(bFlag)
					hwndCurFocus = HWND_SEL_BANNER_ITEM0_BUTTON_1;
				else
					hwndCurFocus = HWND_KTV_SEL_BANNER_ITEM0_TEXT;
			}
			break;

			case HWND_KTV_SEL_BANNER_ITEM1_TEXT:
			{
				if(bFlag)
					hwndCurFocus = HWND_SEL_BANNER_ITEM1_BUTTON_2;
				else
					hwndCurFocus = HWND_SEL_BANNER_ITEM1_BUTTON_1;
			}
			break;
			case HWND_SEL_BANNER_ITEM1_BUTTON_1:
			{
				if(bFlag)
					hwndCurFocus = HWND_KTV_SEL_BANNER_ITEM1_TEXT;
				else
					hwndCurFocus = HWND_SEL_BANNER_ITEM1_BUTTON_2;
			}
			break;
			case HWND_SEL_BANNER_ITEM1_BUTTON_2:
			{
				if(bFlag)
					hwndCurFocus = HWND_SEL_BANNER_ITEM1_BUTTON_1;
				else
					hwndCurFocus = HWND_KTV_SEL_BANNER_ITEM1_TEXT;
			}
			break;
			case HWND_KTV_SEL_BANNER_ITEM2_TEXT:
			{
				if(bFlag)
					hwndCurFocus = HWND_SEL_BANNER_ITEM2_BUTTON_2;
				else
					hwndCurFocus = HWND_SEL_BANNER_ITEM2_BUTTON_1;
			}
			break;
			case HWND_SEL_BANNER_ITEM2_BUTTON_1:
			{
				if(bFlag)
					hwndCurFocus = HWND_KTV_SEL_BANNER_ITEM2_TEXT;
				else
					hwndCurFocus = HWND_SEL_BANNER_ITEM2_BUTTON_2;
			}
			break;
			case HWND_SEL_BANNER_ITEM2_BUTTON_2:
			{
				if(bFlag)
					hwndCurFocus = HWND_SEL_BANNER_ITEM2_BUTTON_1;
				else
					hwndCurFocus = HWND_KTV_SEL_BANNER_ITEM2_TEXT;
			}
			break;
			case HWND_KTV_SEL_BANNER_ITEM3_TEXT:
			{
				if(bFlag)
					hwndCurFocus = HWND_SEL_BANNER_ITEM3_BUTTON_2;
				else
					hwndCurFocus = HWND_SEL_BANNER_ITEM3_BUTTON_1;
			}
			break;
			case HWND_SEL_BANNER_ITEM3_BUTTON_1:
			{
				if(bFlag)
					hwndCurFocus = HWND_KTV_SEL_BANNER_ITEM3_TEXT;
				else
					hwndCurFocus = HWND_SEL_BANNER_ITEM3_BUTTON_2;
			}
			break;
			case HWND_SEL_BANNER_ITEM3_BUTTON_2:
			{
				if(bFlag)
					hwndCurFocus = HWND_SEL_BANNER_ITEM3_BUTTON_1;
				else
					hwndCurFocus = HWND_KTV_SEL_BANNER_ITEM3_TEXT;
			}
			break;
			case HWND_KTV_SEL_BANNER_ITEM4_TEXT:
			{
				if(bFlag)
					hwndCurFocus = HWND_SEL_BANNER_ITEM4_BUTTON_2;
				else
					hwndCurFocus = HWND_SEL_BANNER_ITEM4_BUTTON_1;
			}
			break;
			case HWND_SEL_BANNER_ITEM4_BUTTON_1:
			{
				if(bFlag)
					hwndCurFocus = HWND_KTV_SEL_BANNER_ITEM4_TEXT;
				else
					hwndCurFocus = HWND_SEL_BANNER_ITEM4_BUTTON_2;
			}
			break;
			case HWND_SEL_BANNER_ITEM4_BUTTON_2:
			{
				if(bFlag)
					hwndCurFocus = HWND_SEL_BANNER_ITEM4_BUTTON_1;
				else
					hwndCurFocus = HWND_KTV_SEL_BANNER_ITEM4_TEXT;
			}
			break;

			case HWND_KTV_SEL_BANNER_ITEM5_TEXT:
			{
				if(bFlag)
				    hwndCurFocus = HWND_SEL_BANNER_ITEM5_BUTTON_2;
				else
				    hwndCurFocus = HWND_SEL_BANNER_ITEM5_BUTTON_1;
			}
			break;
			case HWND_SEL_BANNER_ITEM5_BUTTON_1:
			{
				if(bFlag)
				    hwndCurFocus = HWND_KTV_SEL_BANNER_ITEM5_TEXT;
				else
				    hwndCurFocus = HWND_SEL_BANNER_ITEM5_BUTTON_2;
			}
			break;
			case HWND_SEL_BANNER_ITEM5_BUTTON_2:
			{
				if(bFlag)
				    hwndCurFocus = HWND_SEL_BANNER_ITEM5_BUTTON_1;
				else
				    hwndCurFocus = HWND_KTV_SEL_BANNER_ITEM5_TEXT;
			}
			break;
			default:
				break;
		}
            }
            MApp_ZUI_API_SetFocus(hwndCurFocus);
	}
}

static void MApp_ActKtv_SetBanner_UpDownKey(BOOLEAN bFlag)
{
    hwndCurFocus = MApp_ZUI_API_GetFocus();
	int i;
	if(hwndCurFocus <= HWND_KTV_SET_BEST&& hwndCurFocus >= HWND_KTV_SET_ACC_VOLUME)
	{
	    for(i = 0; i < UI_KTV_SETBANNERLIST_NUMBER; i++)
	    {
	    	if (hwndCurFocus == _hwndListSetBannerListItem[i])
				break;
	    }
		if(bFlag)
		{
			if (i == UI_KTV_SETBANNERLIST_NUMBER-1)
				i = 0;
			else
				i ++;
		}
		else
		{
			if (i == 0)
				i = UI_KTV_SETBANNERLIST_NUMBER-1;
			else
				i --;
		}
		MApp_ZUI_API_SetFocus(_hwndListSetBannerListItem[i]);
	}
}

static void MApp_ActKtv_SelectedSongList_UpDownKey(BOOLEAN bFlag)
{
    HWND hwndTemp;
	int i;

	bEnterSelPage = TRUE;

    hwndCurFocus = MApp_ZUI_API_GetFocus();

	switch(hwndCurFocus)
	{
		case HWND_KTV_SEL_BANNER_ITEM0_TEXT:
		case HWND_KTV_SEL_BANNER_ITEM1_TEXT:
		case HWND_KTV_SEL_BANNER_ITEM2_TEXT:
		case HWND_KTV_SEL_BANNER_ITEM3_TEXT:
		case HWND_KTV_SEL_BANNER_ITEM4_TEXT:
		case HWND_KTV_SEL_BANNER_ITEM5_TEXT:
		{
		    for(i = 0; i < UI_KTV_SELECTEDSONGLIST_NUMBER; i++)
		    {
		    	if (hwndCurFocus == _hwndListSelectedSongListItem[i])
					break;
		    }

			if(KLM_GetOrderNum()>0)
			{
				if(bFlag)
				{
				    if(u8PageIdx>=UI_KTV_SELECTEDSONGLIST_NUMBER)
				    {
						if (i == UI_KTV_SELECTEDSONGLIST_NUMBER-1)
			            {
						    i = 0;
			                if((u8CurrentSelectedSongListPageIdx+1 )<u8CurrentSelectedSongListTotalPage)
			                   u8CurrentSelectedSongListPageIdx+=1;
			                else
			                   u8CurrentSelectedSongListPageIdx = u8CurrentSelectedSongListTotalPage;
			            }
						else
							i ++;
				    }
					else
					{
						if (i == u8PageIdx-1)
						{
							if(u8CurrentSelectedSongListPageIdx != u8CurrentSelectedSongListTotalPage)
							{
								i = 0;
								if((u8CurrentSelectedSongListPageIdx+1 )<u8CurrentSelectedSongListTotalPage)
								   u8CurrentSelectedSongListPageIdx+=1;
								else
								   u8CurrentSelectedSongListPageIdx = u8CurrentSelectedSongListTotalPage;
							}
						}
						else
							i ++;
					}
				}
				else
				{
					if (i == 0)
					{
						if(u8CurrentSelectedSongListPageIdx!=1)
						{
							u8CurrentSelectedSongListPageIdx-=1;
							u8PageIdx+=UI_KTV_SELECTEDSONGLIST_NUMBER;

							if(u8PageIdx>=UI_KTV_SELECTEDSONGLIST_NUMBER)
								i = UI_KTV_SELECTEDSONGLIST_NUMBER-1;
							else
								i = u8PageIdx-1;
						}
						else
							u8CurrentSelectedSongListPageIdx =1;
					}
					else
						i --;
				}
			}
			MApp_ZUI_API_InvalidateSelectListItem();
			MApp_ZUI_API_SetFocus(_hwndListSelectedSongListItem[i]);
			hwndTemp = HWND_KTV_SEL_BANNER_ITEM0_TEXT;
			do
			{
				MApp_ZUI_API_InvalidateWindow(hwndTemp);
				hwndTemp++;
			}while(hwndTemp <= HWND_KTV_SEL_BANNER_ITEM5_TEXT && hwndTemp >= HWND_KTV_SEL_BANNER_ITEM0_TEXT);
		}
		break;

		case HWND_SEL_BANNER_ITEM0_BUTTON_1:
		case HWND_SEL_BANNER_ITEM1_BUTTON_1:
		case HWND_SEL_BANNER_ITEM2_BUTTON_1:
		case HWND_SEL_BANNER_ITEM3_BUTTON_1:
		case HWND_SEL_BANNER_ITEM4_BUTTON_1:
		case HWND_SEL_BANNER_ITEM5_BUTTON_1:
		{
		    for(i = 0; i < UI_KTV_SELECTEDSONGLIST_NUMBER; i++)
		    {
		    	if (hwndCurFocus == _hwndListSelectedSongListBotton1Item[i])
					break;
		    }

			if(KLM_GetOrderNum()>0)
			{
				if(bFlag)
				{
				    if(u8PageIdx>=UI_KTV_SELECTEDSONGLIST_NUMBER)
				    {
						if (i == UI_KTV_SELECTEDSONGLIST_NUMBER-1)
			                    {
						    i = 0;
			                       if((u8CurrentSelectedSongListPageIdx+1 )<u8CurrentSelectedSongListTotalPage)
                                               u8CurrentSelectedSongListPageIdx+=1;
			                       else
			                           u8CurrentSelectedSongListPageIdx = u8CurrentSelectedSongListTotalPage;
			                     }
						else
							i ++;
				    }
					else
					{
						if (i == u8PageIdx-1)
						{
							if(u8CurrentSelectedSongListPageIdx != u8CurrentSelectedSongListTotalPage)
							{
								i = 0;
								if((u8CurrentSelectedSongListPageIdx+1 )<u8CurrentSelectedSongListTotalPage)
								   u8CurrentSelectedSongListPageIdx+=1;
								else
								   u8CurrentSelectedSongListPageIdx = u8CurrentSelectedSongListTotalPage;
							}
						}
						else
							i ++;
					}
				}
				else
				{
					if (i == 0)
					{
						if(u8CurrentSelectedSongListPageIdx!=1)
						{
							u8CurrentSelectedSongListPageIdx-=1;
							u8PageIdx+=UI_KTV_SELECTEDSONGLIST_NUMBER;

							if(u8PageIdx>=UI_KTV_SELECTEDSONGLIST_NUMBER)
								i = UI_KTV_SELECTEDSONGLIST_NUMBER-1;
							else
								i = u8PageIdx-1;
						}
						else
							u8CurrentSelectedSongListPageIdx =1;

					}
					else
						i --;
				}
			}
			MApp_ZUI_API_InvalidateSelectListItem();
			MApp_ZUI_API_SetFocus(_hwndListSelectedSongListBotton1Item[i]);
			hwndTemp = HWND_SEL_BANNER_ITEM0_BUTTON_1;
			do
			{
				MApp_ZUI_API_InvalidateWindow(hwndTemp);
				hwndTemp++;
			}while(hwndTemp <= HWND_SEL_BANNER_ITEM5_BUTTON_1 && hwndTemp >= HWND_SEL_BANNER_ITEM0_BUTTON_1);
		}
		break;

		case HWND_SEL_BANNER_ITEM0_BUTTON_2:
		case HWND_SEL_BANNER_ITEM1_BUTTON_2:
		case HWND_SEL_BANNER_ITEM2_BUTTON_2:
		case HWND_SEL_BANNER_ITEM3_BUTTON_2:
		case HWND_SEL_BANNER_ITEM4_BUTTON_2:
		case HWND_SEL_BANNER_ITEM5_BUTTON_2:
		{
		    for(i = 0; i < UI_KTV_SELECTEDSONGLIST_NUMBER; i++)
		    {
		    	if (hwndCurFocus == _hwndListSelectedSongListBotton2Item[i])
					break;
		    }
			if(KLM_GetOrderNum()>0)
			{
				if(bFlag)
				{
				    if(u8PageIdx>=UI_KTV_SELECTEDSONGLIST_NUMBER)
				    {
						if (i == UI_KTV_SELECTEDSONGLIST_NUMBER-1)
			                    {
						    i = 0;
			                          if((u8CurrentSelectedSongListPageIdx+1 )<u8CurrentSelectedSongListTotalPage)
			                             u8CurrentSelectedSongListPageIdx+=1;
			                         else
			                              u8CurrentSelectedSongListPageIdx = u8CurrentSelectedSongListTotalPage;
			                     }
						else
							i ++;
				    }
					else
					{
						if (i == u8PageIdx-1)
						{
							if(u8CurrentSelectedSongListPageIdx != u8CurrentSelectedSongListTotalPage)
							{
								i = 0;
								if((u8CurrentSelectedSongListPageIdx+1 )<u8CurrentSelectedSongListTotalPage)
								   u8CurrentSelectedSongListPageIdx+=1;
								else
								   u8CurrentSelectedSongListPageIdx = u8CurrentSelectedSongListTotalPage;

							}
						}
						else
							i ++;
					}
				}
				else
				{
					if (i == 0)
					{
						if(u8CurrentSelectedSongListPageIdx!=1)
						{
							u8CurrentSelectedSongListPageIdx-=1;
							u8PageIdx+=UI_KTV_SELECTEDSONGLIST_NUMBER;

							if(u8PageIdx>=UI_KTV_SELECTEDSONGLIST_NUMBER)
								i = UI_KTV_SELECTEDSONGLIST_NUMBER-1;
							else
								i = u8PageIdx-1;
						}
						else
							u8CurrentSelectedSongListPageIdx =1;

					}
					else
						i --;
				}
			}
			MApp_ZUI_API_InvalidateSelectListItem();
			MApp_ZUI_API_SetFocus(_hwndListSelectedSongListBotton2Item[i]);
			hwndTemp = HWND_SEL_BANNER_ITEM0_BUTTON_2;
			do
			{
				MApp_ZUI_API_InvalidateWindow(hwndTemp);
				hwndTemp++;
			}while(hwndTemp <= HWND_SEL_BANNER_ITEM5_BUTTON_2 && hwndTemp >= HWND_SEL_BANNER_ITEM0_BUTTON_2);
		}
		break;
	default:
		return;

	}
		MApp_ZUI_API_InvalidateWindow(HWND_KTV_SEL_BANNER_PAGENUM);
}

static void MApp_ZUI_API_InvalidateSelectListItem(void)
{
	if((0!=KLM_GetOrderNum())\
		&&(u8CurrentSelectedSongListPageIdx == u8CurrentSelectedSongListTotalPage)\
		&&(KLM_GetOrderNum() % UI_KTV_SELECTEDSONGLIST_NUMBER !=0))
		{
			int temp;
			MApp_ZUI_API_ShowWindow(HWND_KTV_SEL_BANNER, SW_SHOW);
			for(temp=0;temp<UI_KTV_SELECTEDSONGLIST_NUMBER;temp++)
				{
					MApp_ZUI_API_ShowWindow(_hwndListSelectedSongListTotalItem[temp],SW_HIDE);
				}
			for(temp=0;temp<(KLM_GetOrderNum() % UI_KTV_SELECTEDSONGLIST_NUMBER);temp++)
				{
					MApp_ZUI_API_ShowWindow(_hwndListSelectedSongListTotalItem[temp],SW_SHOW);
				}
		}
	       else if(0 == KLM_GetOrderNum())
		{
			MApp_ZUI_API_ShowWindow(HWND_KTV_SEL_BANNER, SW_HIDE);
			MApp_ZUI_API_SetFocus(HWND_KTV_BUTTON_SEL);
			MApp_ZUI_API_ShowWindow(HWND_KTV_MESSAGE_BOX,SW_SHOW);

		}
	       else if((0!=KLM_GetOrderNum())&&(KLM_GetOrderNum() % UI_KTV_SELECTEDSONGLIST_NUMBER ==0))
		{
                   u8CurrentSelectedSongListTotalPage = (KLM_GetOrderNum()+UI_KTV_SELECTEDSONGLIST_NUMBER-1)/UI_KTV_SELECTEDSONGLIST_NUMBER;
			if(!bEnterSelPage)
			{
				if(u8CurrentSelectedSongListPageIdx> u8CurrentSelectedSongListTotalPage)
			             u8CurrentSelectedSongListPageIdx = u8CurrentSelectedSongListTotalPage;
			}
			else
				bEnterSelPage=FALSE;
			MApp_ZUI_API_InvalidateWindow(HWND_KTV_SEL_BANNER_PAGENUM);
			MApp_ZUI_API_ShowWindow(HWND_KTV_SEL_BANNER, SW_SHOW);
			MApp_ZUI_API_SetFocus(HWND_SEL_BANNER_ITEM1_BUTTON_2);
		}
	       else
		{
		    MApp_ZUI_API_ShowWindow(HWND_KTV_SEL_BANNER, SW_SHOW);
		}
}


static void MApp_ZUI_ACTPlayFile(TOrderInfo strFile)
{
	MPlayerFileInfo fileInfo;
	enumMPlayerMediaType eMediaType;
	enumMPlayerMediaType ePreMediaType;
	U16 u16FileIdx = 0xFFFF;
	char* pszUniPath;
	U16 nUniPathLen;
	S8 strExt[5] = {0};
	U8 * pstrExt;
	 BOOLEAN bRet;

	printf("\n====strFile.nAudioTrack=%d\n",strFile.nAudioTrack);
	bIsOrigal = FALSE;
	MApi_AUDIO_SetMpegInfo(Audio_MPEG_infoType_SoundMode, 2, 0 );

	memset((U8 *)(&fileInfo),0x00,sizeof(MPlayerFileInfo));

//	nUniPathLen = strlen((const char *)strFilePath)*2;

	pszUniPath = (char*)_PA2VA((MUSIC_LYRIC_BUFFER_MEMORY_TYPE & MIU1) ? (MUSIC_LYRIC_BUFFER_ADR | MIU_INTERVAL) : (MUSIC_LYRIC_BUFFER_ADR)) ;

	memset(pszUniPath,0x00,0xFF);

	strcpy( (char*)pszUniPath,strFile.szFilePath);

	u8AuidoType = strFile.nAudioTrack;
	printf("\n--- u8AuidoType = %d\n\n",u8AuidoType);

	GetFileExtName((const char*)pszUniPath, (char *)strExt);

	printf("\n****************************");
	printf("Ext:%s\n",strExt);

	pstrExt = (U8*)(&strExt[1]);
	//for test need when open a new song to match the lr file and open lrc
	StrToLower((U8 *)strExt);
	if((strcmp((U8 *)strExt,".wma")==0)||(strcmp((U8 *)strExt,".kka")==0))
		{
			U8 lrcPath[256];
			memset(lrcPath,0,sizeof(lrcPath));
			strcpy((char *)lrcPath,(const char *)strFile.szFilePath);
			//ReplaceFileExtName2((U8 *)lrcPath,".lr")
			MApp_ZUI_ACT_ChangeExtName(lrcPath ,(U8 *)".lr" );
			printf( "lrcPath=%s",lrcPath );
			U8 wPathLen = __ASCIItoUnicode((U8 *)lrcPath);
			IsOpenLrc = MApp_ZUI_ACT_OpenKTVLrc((CONST TU8 *)lrcPath,(U16)wPathLen);
			if(IsOpenLrc)
			 {
			      bFirstShowLrc = TRUE;
			      enKKLrcStatus = KTV_LRC_LINE1;
				MApp_ZUI_ACT_GetKTVLrcLabel();
				MApp_ZUI_API_ShowWindow(HWND_KTV_LRC_SONGNAME,SW_SHOW);
				MApp_ZUI_API_ShowWindow(HWND_KTV_LRC_SINGERNAME,SW_SHOW);
				MApp_ZUI_ACT_GetKTVLrc(&LyricLien);
				MApp_ZUI_ACT_GetKTVLrc(&LyricLien2);
			 }
			else
			{
				memset(aLabel_TI,0,128 );
				strcpy((char *)aLabel_TI,(const char*)strFile.szSongName);
				aLabel_TI[strlen(strFile.szSongName)+1] = '\0';
				MApp_ZUI_API_ShowWindow(HWND_KTV_LRC_SONGNAME,SW_SHOW);
			}
	   }
	//end test only can get the last file name
	nUniPathLen = __ASCIItoUnicode(pszUniPath);

	ePreMediaType = MApp_MPlayer_QueryCurrentMediaType();
	{
	    if(MApp_MPlayer_QueryFileType(pstrExt) == E_MPLAYER_TYPE_MOVIE)
	    {
	        printf("\nktv: movie--- :\n");
	        MApp_MPlayer_SetCurrentMediaType(E_MPLAYER_TYPE_MOVIE, FALSE);
			MApp_ZUI_ACT_DeletePlay();
			if(MApp_ZUI_API_IsWindowVisible(HWND_KTV_SEL_BANNER))
		   {
		    bEnterSelPage = FALSE;
			MApp_ZUI_API_InvalidateSelectListItem();
			if(0!=KLM_GetOrderNum())
			  {
				MApp_ZUI_API_SetFocus(HWND_KTV_SEL_BANNER_ITEM0_TEXT);
			  }
		   }
	    }
	    else if(MApp_MPlayer_QueryFileType(pstrExt) == E_MPLAYER_TYPE_MUSIC)
	    {
	        printf("\nktv: music--- :\n");
	        MApp_MPlayer_SetCurrentMediaType(E_MPLAYER_TYPE_MUSIC, FALSE);
			MApp_ZUI_ACT_DeletePlay();
			if(MApp_ZUI_API_IsWindowVisible(HWND_KTV_SEL_BANNER))
		   {
		    bEnterSelPage = FALSE;
			MApp_ZUI_API_InvalidateSelectListItem();
			if(0!=KLM_GetOrderNum())
			  {
				MApp_ZUI_API_SetFocus(HWND_KTV_SEL_BANNER_ITEM0_TEXT);
			  }
		   }
	    }
	    else if(MApp_MPlayer_QueryFileType(pstrExt) == E_MPLAYER_TYPE_PHOTO)
	    {
	        printf("\nktv: photo--- :\n");
	        MApp_MPlayer_SetCurrentMediaType(E_MPLAYER_TYPE_PHOTO, FALSE);
	    }
	    else if(MApp_MPlayer_QueryFileType(pstrExt) == E_MPLAYER_TYPE_TEXT)
	    {
	        printf("\nktv: text--- :\n");
	        MApp_MPlayer_SetCurrentMediaType(E_MPLAYER_TYPE_TEXT, FALSE);
	    }
	}
	eMediaType = MApp_MPlayer_QueryCurrentMediaType();

	MApp_MPlayer_SetIndexFileType(E_MPLAYER_INDEX_FILE_CURRENT_DIRECTORY);

	bRet = MApp_MPlayer_GetFileInfo((U8*)pszUniPath,nUniPathLen,&fileInfo,&u16FileIdx,eMediaType);

	if( FALSE==bRet )
	{
		printf("\n----actplayfile bRet=%d\n",bRet);
		enKTVErrorInfo = EN_KTV_ERROR_UNSUPPORT_FILE;
			   	if((!MApp_ZUI_API_IsWindowVisible(HWND_KTV_ERROR_INFO_PAGE))
		 	&&(!MApp_ZUI_API_IsWindowVisible(HWND_KTV_SET_BANNER))
		 	&&(!MApp_ZUI_API_IsWindowVisible(HWND_KTV_SEL_BANNER)))
		    {
				hwndPrevFocus = MApp_ZUI_API_GetFocus();
		    }
	         if(enKTVErrorInfo != EN_KTV_ERROR_NULL)
	          {
//	        MApp_ZUI_ACT_ShowErrorPage();
			MApp_ZUI_API_ShowWindow(HWND_KTV_ERROR_INFO_PAGE,SW_SHOW);
			MApp_ZUI_API_ShowWindow(HWND_KTV_ERROR_INFO_BUTTON,SW_HIDE);
			_MApp_ZUI_API_WindowProcOnIdle();
			MsOS_DelayTask(1000);
	        }

		//DELETE UNSUPPORT && Play Next Song
		{
			TOrderInfo pstOrderSong;
			//delete playing song

			if(0 == KLM_GetOrderNum())
			{
			     if((!MApp_ZUI_API_IsWindowVisible(HWND_KTV_ERROR_INFO_PAGE))
				 	&&(!MApp_ZUI_API_IsWindowVisible(HWND_KTV_SET_BANNER))
				 	&&(!MApp_ZUI_API_IsWindowVisible(HWND_KTV_SEL_BANNER)))
				    {
						hwndPrevFocus = MApp_ZUI_API_GetFocus();
				    }
				//error   the last file zd 20101217
				enKTVErrorInfo = EN_KTV_ERROR_PLAY_ALL;
				MApp_ZUI_ACT_ShowErrorPage();
				MApp_ZUI_API_ShowWindow(HWND_KTV_LRC_SONGNAME,SW_HIDE);
				if(IsOpenLrc)
				{
					MApp_ZUI_ACT_Endlrc();
				}
				return;
			}
			else
			{
				//get next song
//				MApp_ZUI_ACT_DeletePlay();
                         MApp_ZUI_API_ShowWindow(HWND_KTV_LRC_SONGNAME,SW_HIDE);
                         if(IsOpenLrc)
				{
					MApp_ZUI_ACT_Endlrc();
				}
				MApp_ZUI_ACT_GetKTVOrderSongInfo(&pstOrderSong,0);
				MApp_ZUI_ACTPlayFile(pstOrderSong);
			}
		}
		return;
	}
	else
	{
	    if(enKTVErrorInfo != EN_KTV_ERROR_NULL)
    	    {
    		      enKTVErrorInfo = EN_KTV_ERROR_NULL;
			MApp_ZUI_API_ShowWindow(HWND_KTV_ERROR_INFO_PAGE,SW_HIDE);
			MApp_ZUI_API_SetFocus(hwndPrevFocus);
    	   }
	}

	MApp_MPlayer_SetPlayMode(E_MPLAYER_PLAY_ONE_DIRECTORY_FROM_CURRENT);

	switch(eMediaType)
	{
	    // TODO: fix every mediaType
	    case E_MPLAYER_TYPE_PHOTO:
	        {
	            //need to check if there is selected files...
	            if(MApp_MPlayer_QueryPhotoPlayMode() != E_MPLAYER_PHOTO_NORMAL)
	            {

	            }

	            {
	                //there are some selected files
	                MApp_MPlayer_Stop();
	                if(MApp_MPlayer_SetCurrentFile(E_MPLAYER_INDEX_CURRENT_DIRECTORY,u16FileIdx)!=E_MPLAYER_RET_OK )
	                {
	                    KTVACT_DBG(printf("MApp_MPlayer_SetCurrentFile fail PHOTO\n"););
	                }
	                MApp_MPlayer_Play();
	                //reset timer
	                MApp_MPlayer_SetPhotoSlideShowDelayTime(DEFAULT_PHOTO_SLIDESHOW_DELAY_TIME);
	            }
	        }
	        break;

	    case E_MPLAYER_TYPE_MOVIE:
	        {
	            //need to check if there is selected files...
	            if(MApp_MPlayer_IsCurrentExternalSubtitleAvailable() == E_MPLAYER_RET_OK)
	            {
	                MApp_MPlayer_DisableSubtitle();
	            }

	            if(MApp_MPlayer_QueryMoviePlayMode() != E_MPLAYER_MOVIE_NORMAL)
	            {

	            }

	            {
	                //there are some selected files
	                MApp_MPlayer_Stop();

	                if(MApp_MPlayer_SetCurrentFile(E_MPLAYER_INDEX_CURRENT_DIRECTORY,u16FileIdx)!=E_MPLAYER_RET_OK )
	                {
	                    KTVACT_DBG(printf("MApp_MPlayer_SetCurrentFile fail MOVIE\n"););
	                }
	                    MApp_MPlayer_Play();
	            }
	            MApp_MPlayer_MovieSetRepeatAB(E_MPLAYER_MOVIE_SET_REPEAT_AB_NONE, 0);
	            MApp_KTV_ClearFlag(E_KTV_FLAG_MOVIE_REPEATAB_MODE);

	            MApp_MPlayer_EnableSubtitle();
	            MApp_MPlayer_MovieChangeSubtitleTrack(0);
	            if(MApp_MPlayer_IsCurrentExternalSubtitleAvailable() == E_MPLAYER_RET_OK)
	            {
	                KTVACT_DBG(printf("Turn ON external SUBTITLE\n"););

	            }
	        }
	        break;
	    case E_MPLAYER_TYPE_MUSIC:
	        {
	            if(MApp_MPlayer_QueryMusicPlayMode() != E_MPLAYER_MUSIC_NORMAL)
	            {

	            }
	            {
	                MApp_MPlayer_StopMusic();
	                if(MApp_MPlayer_IsCurrentLRCLyricAvailable() == E_MPLAYER_RET_OK)
	                {
	                    MApp_MPlayer_DisableLRCLyric();
	                }
	                msAPI_Timer_Delayms(50);

	                {
	                    //there are some selected files
	                    if(ePreMediaType != E_MPLAYER_TYPE_MUSIC)
                    	{
	                    	MApp_MPlayer_SetCurrentMediaType(ePreMediaType, FALSE);
		                    MApp_MPlayer_Stop();
							MApp_MPlayer_SetCurrentMediaType(E_MPLAYER_TYPE_MUSIC, FALSE);
                    	}

	                    if(MApp_MPlayer_SetCurrentFile(E_MPLAYER_INDEX_CURRENT_DIRECTORY,u16FileIdx)!=E_MPLAYER_RET_OK )
	                    {
	                        KTVACT_DBG(printf("MApp_MPlayer_SetCurrentFile fail MUSIC\n"););
	                    }
	                    MApp_Mplayer_SetCurrentDirMusic2BGM();
	                    MApp_MPlayer_Play();
	                }
	                msAPI_Timer_Delayms(100);
			   MAPP_ZUI_ACT_KTV_PlayBackPhoto();
	            }
	        }
	        break;

	        case E_MPLAYER_TYPE_TEXT:
	            {
	                //need to check if there is selected files...

	                {
	                    //there are some selected files
	                    MApp_MPlayer_Stop();

	                    if(MApp_MPlayer_SetCurrentFile(E_MPLAYER_INDEX_CURRENT_DIRECTORY,u16FileIdx)!=E_MPLAYER_RET_OK )
	                    {
	                        KTVACT_DBG(printf("MApp_MPlayer_SetCurrentFile fail text\n"););
	                    }
	                    MApp_MPlayer_Play();
	                }
	            }
	            break;
	        default:
	            KTVACT_DBG(printf("unsupport EN_EXE_DMP_PLAYBACK_PLAYLIST_SELECT"););
	            break;

	}
}

BOOLEAN MApp_ZUI_ACT_HandleKTVKey(VIRTUAL_KEY_CODE key)
{
    //note: don't do anything here! keys will be handled in state machines
    //      moved to MApp_TV_ProcessAudioVolumeKey()
//    UNUSED(key);
	if (!bPinYinInputMode)
	{
	    U8 OrderedSongList;//the number of the song in the selected list
		if(MApp_ZUI_API_IsWindowVisible(HWND_KTV_EXIT_BANNER))
		{
			if (VK_SELECT == key)
			{
	                   if(MApp_MPlayer_IsMediaFileInPlaying())
	        	      {
	                          MApp_MPlayer_Stop();
	                          MApp_MPlayer_StopMusic();
					if(IsOpenLrc)
					{
					MApp_ZUI_ACT_Endlrc();
					}
	        	      }
				MApp_Photo_SlideShow(TRUE);
				MApp_KTV_SetState(KTVSTATE_GOTO_INPUTSOURCE);
			}
			else
				MApp_ZUI_API_ShowWindow(HWND_KTV_EXIT_BANNER, SW_HIDE);

			return TRUE;
		}


		switch(key)
		{
			case VK_POWER:
				if(MApp_MPlayer_IsMoviePlaying()||MApp_MPlayer_IsMusicPlaying())
				{
	                          MApp_MPlayer_Stop();
	                          MApp_MPlayer_StopMusic();
					if(IsOpenLrc)
					{
					      MApp_ZUI_ACT_Endlrc();
					}
				}
				MApp_KTV_SetState(KTVSTATE_GOTO_STANDBY);
	                    return TRUE;
			case VK_MENU:
				if(MApp_ZUI_API_IsWindowVisible(HWND_KTV_CONTROL_BG) \
					&& !MApp_ZUI_API_IsWindowVisible(HWND_KTV_SEL_BANNER)\
					&& !MApp_ZUI_API_IsWindowVisible(HWND_KTV_SET_BANNER)\
					&& !MApp_ZUI_API_IsWindowVisible(HWND_KTV_EXIT_BANNER)\
					&& !MApp_ZUI_API_IsWindowVisible(HWND_KTV_ERROR_INFO_PAGE)\
					&& (MApp_MPlayer_IsMoviePlaying()|| MApp_MPlayer_IsMusicPlaying()))
				{
					MApp_ZUI_API_ShowWindow(HWND_KTV_CONTROL_BG,SW_HIDE);
					MApp_ZUI_API_ShowWindow(HWND_KTV_TRANSPARENT_BG,SW_SHOW);
					return TRUE;
				}
				if(MApp_ZUI_API_IsWindowVisible(HWND_KTV_TRANSPARENT_BG) \
					&& !MApp_ZUI_API_IsWindowVisible(HWND_KTV_CONTROL_BG) \
					&& !MApp_ZUI_API_IsWindowVisible(HWND_KTV_MAIN_BG))
				 {
					MApp_ZUI_API_ShowWindow(HWND_KTV_TRANSPARENT_BG,SW_HIDE);
					MApp_ZUI_API_ShowWindow(HWND_KTV_CONTROL_BG,SW_SHOW);
					MApp_ZUI_API_SetFocus(HWND_KTV_BUTTON_ORDER);
					return TRUE;
				 }
				if(MApp_ZUI_API_IsWindowVisible(HWND_KTV_MAIN_BG))
				{
				   MApp_ZUI_API_ShowWindow(HWND_KTV_MAIN_BG,SW_HIDE);
				   MApp_ZUI_API_ShowWindow(HWND_KTV_CONTROL_BG,SW_SHOW);
				   MApp_ZUI_API_SetFocus(HWND_KTV_BUTTON_ORDER);
				   MApp_ZUI_API_ShowWindow(HWND_KTV_TRANSPARENT_BG,SW_SHOW);
				   return TRUE;
				}
				return TRUE;

			case VK_EXIT:
				printf("\n vk_exit");
				U8 u8ItemIndex;
				hwndCurFocus = MApp_ZUI_API_GetFocus();

				if(MApp_ZUI_API_IsWindowVisible(HWND_KTV_ERROR_INFO_PAGE)
					&& enKTVErrorInfo == EN_KTV_ERROR_NO_FILE)
					return TRUE;

			    if(MApp_ZUI_API_IsWindowVisible(HWND_KTV_MAIN_BG))
			    {
			         	if(hwndCurFocus >= HWND_KTV_MAIN_RIGHT_ITEM0 && hwndCurFocus <= HWND_KTV_MAIN_RIGHT_ITEM9)
			          	{
						if(eDBFFileInfo == EN_SONG_BY_DISK)
						{
							MApp_ZUI_ACT_SetKTVFocusByCurrentMidDiskDepthIndex();
						}
						else
						{
							MApp_ZUI_ACT_SetKTVFocusByCurrentMidDepthIndex();
						}
			           	}
					else
					{
						if(u8MidDepth == 0)
				    	{
							if(eDBFFileInfo != EN_SONG_BY_DISK)
							{
								for(u8ItemIndex=0;u8ItemIndex<UI_KTV_ORDERLIST_NUMBER;u8ItemIndex++)
								{
									if(hwndCurFocus == _hwndListOrderMidDisklistItem[u8ItemIndex])
									{
										break;
									}
								}
							}
							else
							{
								for(u8ItemIndex=0;u8ItemIndex<UI_KTV_ORDERLIST_NUMBER;u8ItemIndex++)
								{
									if(hwndCurFocus == _hwndListOrderMidlistItem[u8ItemIndex])
									{
										break;
									}
								}
							}

				    		if(hwndCurFocus >= HWND_KTV_MAIN_MID_ITEM0 && hwndCurFocus <= HWND_KTV_MAIN_MID_ITEM9)
			    			{
								switch(eDBFFileInfo)
								{
								case EN_SINGER_SORT:
									MApp_ZUI_API_SetFocus(HWND_KTV_MAIN_LEFT_ITEM0);
									break;
								case EN_CHARACTER_SORT:
									MApp_ZUI_API_SetFocus(HWND_KTV_MAIN_LEFT_ITEM1);
									break;
								case EN_SONG_SORT:
									MApp_ZUI_API_SetFocus(HWND_KTV_MAIN_LEFT_ITEM2);
									break;
								case EN_LANGUAGE_SORT:
									MApp_ZUI_API_SetFocus(HWND_KTV_MAIN_LEFT_ITEM3);
									break;
								case EN_SONG_PINYIN:
									if(bPinYinInputMode == FALSE)
									{
										bPinYinInputMode = TRUE;
										memset(szPinYinInputValue,0,16);
										memset(InputChar,0,strlen(InputChar));
										MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_MAIN_MID_PINYIN_BANNER);
										MApp_ZUI_API_SetFocus(HWND_KTV_MAIN_MID_PINYIN_BANNER_CUR_CHA);
									}
									else
									{
										bPinYinInputMode = FALSE;
										MApp_ZUI_API_SetFocus(HWND_KTV_MAIN_LEFT_ITEM4);
									}
									break;
								default:
									break;
			    				}
				    		}
				    		else if(hwndCurFocus >= HWND_KTV_MAIN_MID_SONG_ITEM0 && hwndCurFocus <= HWND_KTV_MAIN_MID_SONG_ITEM9)
							{
								switch(eDBFFileInfo)
								{
								case EN_SONG_PINYIN:
									if(bPinYinInputMode == FALSE)
									{
										bPinYinInputMode = TRUE;
										memset(szPinYinInputValue,0,16);
										memset(InputChar,0,strlen(InputChar));
										MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_MAIN_MID_PINYIN_BANNER);
										MApp_ZUI_API_SetFocus(HWND_KTV_MAIN_MID_PINYIN_BANNER_CUR_CHA);
									}
									else
									{
										bPinYinInputMode = FALSE;
										MApp_ZUI_API_SetFocus(HWND_KTV_MAIN_LEFT_ITEM4);
									}
									break;
								default:
									break;
			    				}
				    		}
							else if(hwndCurFocus >= HWND_KTV_MAIN_MID_DISK_ITEM0 && hwndCurFocus <= HWND_KTV_MAIN_MID_DISK_ITEM9)
							{
								if(eDBFFileInfo == EN_SONG_BY_DISK)
									MApp_ZUI_API_SetFocus(HWND_KTV_MAIN_LEFT_ITEM5);
							}
							else
							{
								if(EN_SONG_PINYIN == eDBFFileInfo)
									MApp_ZUI_ACT_GetKTVReleaseDBF();
						        MApp_ZUI_API_ShowWindow(HWND_KTV_CONTROL_BG, SW_SHOW);
							 	MApp_ZUI_API_ShowWindow(HWND_KTV_MAIN_BG, SW_HIDE);
						        MApp_ZUI_API_SetFocus(HWND_KTV_BUTTON_ORDER);
				    		}
					        return TRUE;
				    	}
						else if((u8MidDepth ==1)&&(eDBFFileInfo!=EN_SONG_BY_DISK))
						{
							u8MidDepth = 0;
							switch(eDBFFileInfo)
							{
							case EN_SINGER_LIST:
								MApp_ZUI_API_InvalidateWindow(HWND_KTV_MAIN_MID_TITLE_TEXT);
								MApp_ZUI_ACT_GetKTVReleaseDBF();
								eDBFFileInfo = EN_SINGER_SORT;
								u8CurrentMidlistPageIdx=MainMidDepthIndex[u8MidDepth]/UI_KTV_ORDERLIST_NUMBER+1;//ȷ����ǰ��page.
								MApp_ZUI_ACT_GetKTVOpenDBF(0,(U8)u8CurrentMidlistPageIdx,UI_KTV_ORDERLIST_NUMBER);
								u8CurrentSongCoutPageIdx = MApp_ZUI_ACT_GetKTVSongCountCount();
								u8CurrentMidlistTotalPage = (u8CurrentSongCoutPageIdx+UI_KTV_ORDERLIST_NUMBER-1)/UI_KTV_ORDERLIST_NUMBER;
								break;
							case EN_SONG_REFER2_CHARACT:
								MApp_ZUI_API_InvalidateWindow(HWND_KTV_MAIN_MID_TITLE_TEXT);
								MApp_ZUI_API_ShowWindow(HWND_KTV_MAIN_MID_SONG_LIST,SW_HIDE);
								MApp_ZUI_API_ShowWindow(HWND_KTV_MAIN_MID_LIST,SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_KTV_MAIN_MID_PINYIN_LABLE,SW_HIDE);
								MApp_ZUI_API_ShowWindow(HWND_KTV_MAIN_MID_PINYIN_BANNER,SW_HIDE);
								MApp_ZUI_API_ShowWindow(HWND_KTV_MAIN_MID_PINYIN_BANNER_STR,SW_HIDE);
								MApp_ZUI_ACT_GetKTVReleaseDBF();
								eDBFFileInfo = EN_CHARACTER_SORT;
								u8CurrentMidlistPageIdx=MainMidDepthIndex[u8MidDepth]/UI_KTV_ORDERLIST_NUMBER+1;//ȷ����ǰ��page.
								MApp_ZUI_ACT_GetKTVOpenDBF(0,(U8)u8CurrentMidlistPageIdx,UI_KTV_ORDERLIST_NUMBER);
								u8CurrentSongCoutPageIdx = MApp_ZUI_ACT_GetKTVSongCountCount();
								u8CurrentMidlistTotalPage = (u8CurrentSongCoutPageIdx+UI_KTV_ORDERLIST_NUMBER-1)/UI_KTV_ORDERLIST_NUMBER;
								break;
							case EN_SONG_REFER2_SORT:
								MApp_ZUI_API_InvalidateWindow(HWND_KTV_MAIN_MID_TITLE_TEXT);
								MApp_ZUI_API_ShowWindow(HWND_KTV_MAIN_MID_SONG_LIST,SW_HIDE);
								MApp_ZUI_API_ShowWindow(HWND_KTV_MAIN_MID_LIST,SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_KTV_MAIN_MID_PINYIN_LABLE,SW_HIDE);
								MApp_ZUI_API_ShowWindow(HWND_KTV_MAIN_MID_PINYIN_BANNER,SW_HIDE);
								MApp_ZUI_API_ShowWindow(HWND_KTV_MAIN_MID_PINYIN_BANNER_STR,SW_HIDE);
								MApp_ZUI_ACT_GetKTVReleaseDBF();
								eDBFFileInfo = EN_SONG_SORT;
								u8CurrentMidlistPageIdx=MainMidDepthIndex[u8MidDepth]/UI_KTV_ORDERLIST_NUMBER+1;//ȷ����ǰ��page.
								MApp_ZUI_ACT_GetKTVOpenDBF(0,(U8)u8CurrentMidlistPageIdx,UI_KTV_ORDERLIST_NUMBER);
								u8CurrentSongSortPageIdx = MApp_ZUI_ACT_GetKTVSongSortCount();
								u8CurrentMidlistTotalPage = (u8CurrentSongSortPageIdx+UI_KTV_ORDERLIST_NUMBER-1)/UI_KTV_ORDERLIST_NUMBER;
								break;
	                                          case EN_SONG_REFER2_LANGUAGE:
								MApp_ZUI_API_InvalidateWindow(HWND_KTV_MAIN_MID_TITLE_TEXT);
								MApp_ZUI_API_ShowWindow(HWND_KTV_MAIN_MID_SONG_LIST,SW_HIDE);
								MApp_ZUI_API_ShowWindow(HWND_KTV_MAIN_MID_LIST,SW_SHOW);
								MApp_ZUI_API_ShowWindow(HWND_KTV_MAIN_MID_PINYIN_LABLE,SW_HIDE);
								MApp_ZUI_API_ShowWindow(HWND_KTV_MAIN_MID_PINYIN_BANNER,SW_HIDE);
								MApp_ZUI_API_ShowWindow(HWND_KTV_MAIN_MID_PINYIN_BANNER_STR,SW_HIDE);
	                                               MApp_ZUI_ACT_GetKTVReleaseDBF();
	                                               eDBFFileInfo = EN_LANGUAGE_SORT;
								u8CurrentMidlistPageIdx=MainMidDepthIndex[u8MidDepth]/UI_KTV_ORDERLIST_NUMBER+1;//ȷ����ǰ��page.
	                                                MApp_ZUI_ACT_GetKTVOpenDBF(0,(U8)u8CurrentMidlistPageIdx,UI_KTV_ORDERLIST_NUMBER);
								u8CurrentLangSortPageIdx = MApp_ZUI_ACT_GetKTVLanguageSortCount();
								u8CurrentMidlistTotalPage = (u8CurrentLangSortPageIdx+UI_KTV_ORDERLIST_NUMBER-1)/UI_KTV_ORDERLIST_NUMBER;
	                                               break;
							default:
								break;
							}
							MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_MAIN_MID_LIST);
							MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_MAIN_MID_PAGE_NUM);
							MApp_ZUI_ACT_SetKTVFocusByCurrentMidDepthIndex();
							return TRUE;
						}
						else if((u8MidDepth ==2)&&(eDBFFileInfo!=EN_SONG_BY_DISK))
						{
							u8MidDepth = 1;
							switch(eDBFFileInfo)
							{
							     case EN_SONG_LIST:
							     {
								MApp_ZUI_API_InvalidateWindow(HWND_KTV_MAIN_MID_TITLE_TEXT);
								MApp_ZUI_ACT_GetKTVReleaseDBF();
								eDBFFileInfo = EN_SINGER_LIST;
								u8CurrentMidlistPageIdx=MainMidDepthIndex[u8MidDepth]/UI_KTV_ORDERLIST_NUMBER+1;//ȷ����ǰ��page.
								MApp_ZUI_ACT_GetKTVOpenDBF(stMidTitleSingSortInfo.u32SingSortId,(U8)u8CurrentMidlistPageIdx,UI_KTV_ORDERLIST_NUMBER);
								u8CurrentSingerlistPageIdx = MApp_ZUI_ACT_GetKTVLanguageSortCount();
								u8CurrentMidlistTotalPage = (u8CurrentSingerlistPageIdx+UI_KTV_ORDERLIST_NUMBER-1)/UI_KTV_ORDERLIST_NUMBER;
								MApp_ZUI_ACT_SetKTVFocusByCurrentMidDepthIndex();
							      }
								break;
							default:
								break;
							}
							MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_MAIN_MID_LIST);
							MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_MAIN_MID_PAGE_NUM);
							return TRUE;
						}
						else if(eDBFFileInfo==EN_SONG_BY_DISK)
						{
						     U16 Len;
						     U16 Len2;
						     U8 TempFilePath[128]={0};
						     U8 TempFilePath2[128]={0};
						     TLONG Handle=0;//1;
						     U16 wStep=0;//UI_KTV_ORDERLIST_NUMBER;

						     if(u8MidDepth >=1)
						    {
						        u8MidDepth--;
								Len = getstrlen((char *)enterFileNme,'\\');
								strncpy((char *)TempFilePath,(const char *)enterFileNme,Len);
								TempFilePath[Len]= '\0';
								Len2 = getstrlen2(TempFilePath,'\\');
								strncpy((char *)TempFilePath2,(const char *)TempFilePath,Len2);
								//TempFilePath2[Len2-1] = '\0';
								TempFilePath2[Len2] = '\0';
								strcpy((char *)enterFileNme,(const char *)TempFilePath2);
						    }

							 MApp_ZUI_ACT_GetKTVReleaseDBF();

						     strcpy((char *)aSearchPath,(const char *)TempFilePath);
						     //U16 wPathLen = strlen((const char *)TempFilePath)*2;
						     U16 wPathLen = __ASCIItoUnicode((U8*)TempFilePath);
						     FMI_GetMediaData((TU8 *)TempFilePath,wPathLen,FMI_MDT_VIDEO,&Handle,wStep,&pRecordSet );
						    //u8CurrentVideoItemsPageIdx = MApp_ZUI_ACT_GetKTVVideoItemsInDiskCount();
						    //if(0 == u8CurrentVideoItemsPageIdx)
						    //   u8CurrentVideoItemsPageIdx =1;
						    //u8CurrentMidlistTotalPage = (u8CurrentVideoItemsPageIdx+UI_KTV_ORDERLIST_NUMBER-1)/UI_KTV_ORDERLIST_NUMBER;

						    MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_MAIN_MID_LIST);
						    //MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_MAIN_MID_PAGE_NUM);
							MApp_ZUI_ACT_SetKTVFocusByCurrentMidDiskDepthIndex();
						}
						else
							return TRUE;
				    }
			    }

				if(MApp_ZUI_API_IsWindowVisible(HWND_KTV_SEL_BANNER))
				{
					MApp_ZUI_API_ShowWindow(HWND_KTV_SEL_BANNER,SW_HIDE);
					MApp_ZUI_API_SetFocus(HWND_KTV_BUTTON_SEL);
					return TRUE;
				}
				else if(MApp_ZUI_API_IsWindowVisible(HWND_KTV_SET_BANNER))
				{
					MApp_ZUI_API_ShowWindow(HWND_KTV_SET_BANNER,SW_HIDE);
					MApp_ZUI_API_SetFocus(HWND_KTV_BUTTON_SET);
					return TRUE;
				}
				else if(MApp_ZUI_API_IsWindowVisible(HWND_KTV_CONTROL_BG))
				{
					if(MApp_ZUI_API_IsWindowVisible(HWND_KTV_ERROR_INFO_PAGE))
						MApp_ZUI_API_ShowWindow(HWND_KTV_ERROR_INFO_PAGE,SW_HIDE);
					MApp_ZUI_API_SetFocus(HWND_KTV_BUTTON_EXIT);
					MApp_ZUI_API_ShowWindow(HWND_KTV_EXIT_BANNER, SW_SHOW);
					return TRUE;
				}
				break;
			//modify by zd 20101206  donot active when get nput key
			case VK_INPUT_SOURCE:
				bPinYinInputMode = FALSE;
				MApp_ZUI_API_ShowWindow(HWND_MAINFRAME, SW_HIDE);
				MApp_ZUI_API_ShowWindow(HWND_KTV_CONTROL_BG, SW_SHOW);
				MApp_ZUI_API_SetFocus(HWND_KTV_BUTTON_EXIT);
				MApp_ZUI_API_ShowWindow(HWND_KTV_EXIT_BANNER, SW_SHOW);
	                     return TRUE;
			case VK_SELECT:
				{
				    hwndCurFocus = MApp_ZUI_API_GetFocus();
					if(MApp_ZUI_API_IsWindowVisible(HWND_KTV_ERROR_INFO_PAGE))
					{
						enKTVErrorInfo = EN_KTV_ERROR_NULL;
						MApp_ZUI_API_ShowWindow(HWND_KTV_ERROR_INFO_PAGE, SW_HIDE);
						if(MApp_ZUI_API_IsWindowVisible(HWND_KTV_SET_BANNER))
						    MApp_ZUI_API_ShowWindow(HWND_KTV_SET_BANNER,SW_HIDE);
						if(MApp_ZUI_API_IsWindowVisible(HWND_KTV_SEL_BANNER))
						    MApp_ZUI_API_ShowWindow(HWND_KTV_SEL_BANNER,SW_HIDE);
						if(MApp_ZUI_API_IsWindowVisible(HWND_KTV_CONTROL_BG))
							MApp_ZUI_API_SetFocus(hwndPrevFocus);
						else
							MApp_ZUI_API_SetFocus(hwndPrevFocus);
					}
					else if(MApp_ZUI_API_IsWindowVisible(HWND_KTV_SET_BANNER))
					{
						if (hwndCurFocus == HWND_KTV_SET_BEST)
						{
							MApp_ZUI_ACT_ExecuteKTVAction(EN_EXE_KTV_SET_BEST);
						}
					}
					else if(MApp_ZUI_API_IsWindowVisible(HWND_KTV_CONTROL_BG)&&(!MApp_ZUI_API_IsWindowVisible(HWND_KTV_SEL_BANNER)))
					{
					   if((!MApp_ZUI_API_IsWindowVisible(HWND_KTV_ERROR_INFO_PAGE))
						 	&&(!MApp_ZUI_API_IsWindowVisible(HWND_KTV_SET_BANNER))
						 	&&(!MApp_ZUI_API_IsWindowVisible(HWND_KTV_SEL_BANNER)))
						    {
								hwndPrevFocus = MApp_ZUI_API_GetFocus();
						    }
						switch(hwndCurFocus)
						{
							case HWND_KTV_BUTTON_ORDER:
								if(!MApp_DMP_RecalculateDriveMappingTable() && !(MApp_ZUI_API_IsWindowVisible(HWND_KTV_ERROR_INFO_PAGE)))
								{
									MApp_ZUI_API_ShowWindow(HWND_KTV_ERROR_INFO_PAGE,SW_SHOW);
									MApp_ZUI_API_SetFocus(HWND_KTV_ERROR_INFO_BUTTON);
									return TRUE;
								}
								else
								{
//									BOOLEAN bFlag = FALSE;
									eDBFFileInfo = EN_SINGER_SORT;
									bUSBHasDateBase = MApp_ZUI_ACT_GetKTVOpenDBF(0,1,0);

									if(!bUSBHasDateBase)
									{
										TLONG Handle=0;//1;
										U16 wStep=0;//UI_KTV_ORDERLIST_NUMBER;
										TU8 aTempPath[128]={0};

// 										MApp_ZUI_ACT_GetKTVReleaseDBF();
										eDBFFileInfo = EN_SONG_BY_DISK;
										strcpy( (char*)aTempPath,(const char *)"\\" );
										strcpy( (char*)aSearchPath,(const char *)"\\" );

										U16 wPathLen = __ASCIItoUnicode((U8*)aTempPath);

										if( 0==FMI_GetMediaData( aTempPath,wPathLen,FMI_MDT_VIDEO,&Handle,wStep,&pRecordSet ) )
										{
											u8MidDepth = 0;
											MApp_ZUI_API_EnableWindow(HWND_KTV_MAIN_LEFT_ITEM0,FALSE);
											MApp_ZUI_API_EnableWindow(HWND_KTV_MAIN_LEFT_ITEM1,FALSE);
											MApp_ZUI_API_EnableWindow(HWND_KTV_MAIN_LEFT_ITEM2,FALSE);
											MApp_ZUI_API_EnableWindow(HWND_KTV_MAIN_LEFT_ITEM3,FALSE);
											MApp_ZUI_API_EnableWindow(HWND_KTV_MAIN_LEFT_ITEM4,FALSE);
											printf( "FMI_GetMediaData() call success!\n" );
											u8CurrentVideoItemsPageIdx = MApp_ZUI_ACT_GetKTVVideoItemsInDiskCount();
											u8CurrentMidlistPageIdx = 1;
											u8CurrentMidlistTotalPage = (u8CurrentVideoItemsPageIdx+UI_KTV_ORDERLIST_NUMBER-1)/UI_KTV_ORDERLIST_NUMBER;
											MApp_ZUI_API_ShowWindow(HWND_KTV_CONTROL_BG,SW_HIDE);
											MApp_ZUI_API_ShowWindow(HWND_KTV_TRANSPARENT_BG,SW_SHOW);
											MApp_ZUI_API_ShowWindow(HWND_KTV_MAIN_BG,SW_SHOW);
											MApp_ZUI_API_ShowWindow(HWND_KTV_MAIN_MID_PINYIN_BANNER,SW_HIDE);
											MApp_ZUI_API_ShowWindow(HWND_KTV_MAIN_MID_PINYIN_BANNER_STR,SW_HIDE);
											MApp_ZUI_API_ShowWindow(HWND_KTV_MAIN_MID_PINYIN_LABLE,SW_HIDE);
											MApp_ZUI_API_ShowWindow(HWND_KTV_MAIN_MID_LIST,SW_HIDE);
											MApp_ZUI_API_ShowWindow(HWND_KTV_MAIN_MID_DISK_LIST,SW_SHOW);
											MApp_ZUI_API_ShowWindow(HWND_KTV_MAIN_MID_SONG_LIST,SW_HIDE);
											MApp_ZUI_API_SetFocus(HWND_KTV_MAIN_LEFT_ITEM5);
											MApp_ZUI_API_InvalidateWindow(HWND_KTV_MAIN_RIGHT_PAGE_NUM);
										}
										else
										{
											enKTVErrorInfo = EN_KTV_ERROR_NO_FILE;
											MApp_ZUI_API_ShowWindow(HWND_KTV_ERROR_INFO_PAGE,SW_SHOW);
											MApp_ZUI_API_SetFocus(HWND_KTV_ERROR_INFO_BUTTON);
										}
  									}
									else
									{
										u8CurrentMidlistPageIdx = 1;
										u8CurrentMidlistTotalPage = 1;
										u8CurrentSingerSortPageIdx = MApp_ZUI_ACT_GetKTVSingerSortCount();
										u8CurrentOrderlistPageIdx = KLM_GetOrderNum();
		                                                    if(0==KLM_GetOrderNum())
		                                                         u8CurrentRightlistTotalPage=1;
		                                                    else
		                                                          u8CurrentRightlistTotalPage  = (u8CurrentOrderlistPageIdx+UI_KTV_ORDERLIST_NUMBER-1)/UI_KTV_ORDERLIST_NUMBER;
										u8CurrentRightlistPageIdx= u8CurrentRightlistTotalPage;
										u8MidDepth = 0;

										MApp_ZUI_API_EnableWindow(HWND_KTV_MAIN_LEFT_ITEM0,TRUE);
										MApp_ZUI_API_EnableWindow(HWND_KTV_MAIN_LEFT_ITEM1,TRUE);
										MApp_ZUI_API_EnableWindow(HWND_KTV_MAIN_LEFT_ITEM2,TRUE);
										MApp_ZUI_API_EnableWindow(HWND_KTV_MAIN_LEFT_ITEM3,TRUE);
										MApp_ZUI_API_EnableWindow(HWND_KTV_MAIN_LEFT_ITEM4,TRUE);

										MApp_ZUI_API_ShowWindow(HWND_KTV_CONTROL_BG,SW_HIDE);
										MApp_ZUI_API_ShowWindow(HWND_KTV_TRANSPARENT_BG,SW_SHOW);
										MApp_ZUI_API_ShowWindow(HWND_KTV_MAIN_BG,SW_SHOW);
										//add by sn del when pinyin search success
										MApp_ZUI_API_ShowWindow(HWND_KTV_MAIN_MID_PINYIN_BANNER,SW_HIDE);
										MApp_ZUI_API_ShowWindow(HWND_KTV_MAIN_MID_PINYIN_BANNER_STR,SW_HIDE);
								               MApp_ZUI_API_ShowWindow(HWND_KTV_MAIN_MID_PINYIN_LABLE,SW_HIDE);
									   //end add////////////////////////////////////////////////////////////
										MApp_ZUI_API_ShowWindow(HWND_KTV_MAIN_MID_DISK_LIST,SW_HIDE);
									   	MApp_ZUI_API_ShowWindow(HWND_KTV_MAIN_MID_SONG_LIST,SW_HIDE);
									       MApp_ZUI_API_SetFocus(HWND_KTV_MAIN_LEFT_ITEM0);
		                                                      MApp_ZUI_API_InvalidateWindow(HWND_KTV_MAIN_RIGHT_PAGE_NUM);

										//add by zd for load jpg 20101215
										MApp_MPlayer_PushAllMPhoto2Playlist();
									}
									return TRUE;
								}
								break;
							case HWND_KTV_BUTTON_SEL:
	                                       {
	                                                 OrderedSongList = KLM_GetOrderNum();
	                                               if(0==KLM_GetOrderNum())
	                                                     u8CurrentSelectedSongListTotalPage = 1;
	                                               else
	                                                     u8CurrentSelectedSongListTotalPage = (OrderedSongList+UI_KTV_SELECTEDSONGLIST_NUMBER-1)/UI_KTV_SELECTEDSONGLIST_NUMBER;
								u8CurrentSelectedSongListPageIdx = 1;
								bEnterSelPage = TRUE;
								MApp_ZUI_API_InvalidateSelectListItem();
	                                               if(0!=KLM_GetOrderNum())
									MApp_ZUI_API_SetFocus(HWND_KTV_SEL_BANNER_ITEM0_TEXT);
								MApp_ZUI_API_InvalidateWindow(HWND_KTV_SEL_BANNER_PAGENUM);
								return TRUE;
							}
								break;
							case HWND_KTV_BUTTON_CUT:
								MApp_ZUI_ACT_ExecuteKTVAction(EN_EXE_KTV_PLAY_NEXT);
								break;
							case HWND_KTV_BUTTON_ORIGACC:
								MApp_ZUI_ACT_ExecuteKTVAction(EN_EXE_KTV_SET_AUDIOTYPE);
								return TRUE;
								break;
							case HWND_KTV_BUTTON_SET:
								MApp_ZUI_API_ShowWindow(HWND_KTV_SET_BANNER, SW_SHOW);
								MApp_ZUI_API_SetFocus(HWND_KTV_SET_ACC_VOLUME);
								return TRUE;
								break;
							case HWND_KTV_BUTTON_EXIT:
								MApp_ZUI_API_ShowWindow(HWND_KTV_EXIT_BANNER, SW_SHOW);
								return TRUE;
								break;
				                     default:
								break;
					    }
					}
					else if(MApp_ZUI_API_IsWindowVisible(HWND_KTV_MAIN_BG))
					{
						if(hwndCurFocus <= HWND_KTV_MAIN_LEFT_ITEM9 && hwndCurFocus >= HWND_KTV_MAIN_LEFT_ITEM0)
							MApp_ActKtv_Main_LeftRightKey(FALSE);
						else if(hwndCurFocus <= HWND_KTV_MAIN_MID_DISK_ITEM9 && hwndCurFocus >= HWND_KTV_MAIN_MID_DISK_ITEM0)
						{
							U8 u8ItemIdx = 0;

							for(u8ItemIdx=0;u8ItemIdx<UI_KTV_ORDERLIST_NUMBER;u8ItemIdx++)
							{
							    if(hwndCurFocus == _hwndListOrderMidDisklistItem[u8ItemIdx])
							    {
							        break;
							    }
							}
							if((!MApp_ZUI_API_IsWindowVisible(HWND_KTV_ERROR_INFO_PAGE))
							 	&&(!MApp_ZUI_API_IsWindowVisible(HWND_KTV_SET_BANNER))
							 	&&(!MApp_ZUI_API_IsWindowVisible(HWND_KTV_SEL_BANNER)))
							    {
									hwndPrevFocus = MApp_ZUI_API_GetFocus();
							    }
							switch(hwndCurFocus)
							{
								case HWND_KTV_MAIN_MID_DISK_ITEM0:
								case HWND_KTV_MAIN_MID_DISK_ITEM1:
								case HWND_KTV_MAIN_MID_DISK_ITEM2:
								case HWND_KTV_MAIN_MID_DISK_ITEM3:
								case HWND_KTV_MAIN_MID_DISK_ITEM4:
								case HWND_KTV_MAIN_MID_DISK_ITEM5:
								case HWND_KTV_MAIN_MID_DISK_ITEM6:
								case HWND_KTV_MAIN_MID_DISK_ITEM7:
								case HWND_KTV_MAIN_MID_DISK_ITEM8:
								case HWND_KTV_MAIN_MID_DISK_ITEM9:
								{
									if(eDBFFileInfo == EN_SONG_BY_DISK)
									{
										TOrderInfo pstOrderSong;
										MEDIA_FILE_INFO MediaFileInfo;
										U16 Len;
										U8 TempFilePath[128]={0};

										TLONG Handle=0;//1;
										U16 wStep=0;//UI_KTV_ORDERLIST_NUMBER;

										MApp_ZUI_ACT_GetKTVVideoItemsInDiskInfo(&MediaFileInfo,(u8CurrentMidlistPageIdx-1)*UI_KTV_ORDERLIST_NUMBER+u8ItemIdx + 1);
										if(0 == MediaFileInfo.u16MediaType)//folder
										{
											char cLastPath[128] = {0};
											u8MidDepth++;
											strcpy(cLastPath,(const char *)aSearchPath);
											strcat((char *)aSearchPath,(const char *)MediaFileInfo.cFileName);
											strcpy((char *)enterFileNme,(const char *)aSearchPath);
											strcat((char *)aSearchPath,(const char *)"\\");
											strcpy((char *)TempFilePath,(const char *)aSearchPath);
											//U16 wPathLen = strlen((const char *)TempFilePath)*2;
											MApp_ZUI_ACT_GetKTVReleaseDBF();

											U16 wPathLen = __ASCIItoUnicode((U8*)TempFilePath);
											FMI_GetMediaData((TU8 *)TempFilePath,wPathLen,FMI_MDT_VIDEO,&Handle,wStep,&pRecordSet );
											u8CurrentVideoItemsPageIdx = MApp_ZUI_ACT_GetKTVVideoItemsInDiskCount();
											if(0 == u8CurrentVideoItemsPageIdx)
											{
												u8MidDepth--;
												memset(TempFilePath,0,sizeof(TempFilePath));
												strcpy((char *)TempFilePath,(const char *)cLastPath);
												memset(aSearchPath,0,sizeof(aSearchPath));
												strcpy((char *)aSearchPath,(const char *)cLastPath);
												//wPathLen = strlen((const char *)TempFilePath)*2;
												wPathLen = __ASCIItoUnicode((U8*)TempFilePath);

												FMI_GetMediaData((TU8 *)TempFilePath,wPathLen,FMI_MDT_VIDEO,&Handle,wStep,&pRecordSet );
												u8CurrentVideoItemsPageIdx = MApp_ZUI_ACT_GetKTVVideoItemsInDiskCount();
//												u8CurrentVideoItemsPageIdx =1;
												enKTVErrorInfo = EN_KTV_ERROR_NO_FILE;
												MApp_ZUI_API_ShowWindow(HWND_KTV_ERROR_INFO_PAGE,SW_SHOW);
												MApp_ZUI_API_SetFocus(HWND_KTV_ERROR_INFO_BUTTON);
											}
											else
											{
												u8CurrentMidlistPageIdx = 1;
												u8CurrentMidlistTotalPage = (u8CurrentVideoItemsPageIdx+UI_KTV_ORDERLIST_NUMBER-1)/UI_KTV_ORDERLIST_NUMBER;
												MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_MAIN_MID_DISK_LIST);
												MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_MAIN_MID_PAGE_NUM);
												MApp_ZUI_API_SetFocus(_hwndListOrderMidDisklistItem[0]);
												MApp_ZUI_ACT_SetKTVCurrentMidDiskDepthIndex();
											}
										}
										else//file
										{
											strcpy((char *)TempFilePath,(const char *)aSearchPath);
											strcat(TempFilePath,MediaFileInfo.cFileName);
											Len = sizeof(pstOrderSong.szFilePath);
											memset(pstOrderSong.szFilePath,0,Len);
											memcpy((char *)pstOrderSong.szFilePath,(const char *)TempFilePath,strlen(TempFilePath));
											Len = sizeof(pstOrderSong.szSongName);
											memset(pstOrderSong.szSongName,0,Len);
											memcpy(pstOrderSong.szSongName,MediaFileInfo.cFileName,strlen(MediaFileInfo.cFileName));
											if(KLM_GetOrderNum()<20)//the number of order song must less than 20
											  {
											    BOOLEAN isAddSuccess = false;
												isAddSuccess = KLM_AddSongInfo(&pstOrderSong);
												if(isAddSuccess)
												{
												  //printf("\n___less than 20 and addsongifo success__%d\n",KLM_GetOrderNum());
												}
											    else
											    {
											      //printf("\n___less than 20 and addsongifo failed__%d\n",KLM_GetOrderNum());
											    }
											  }
											else
											  {
											   // printf("\n___more than 20 and addsongifo failed__\n");
												enKTVErrorInfo = EN_KTV_ERROR_MORE_20_SONGNUM;
												MApp_ZUI_API_ShowWindow(HWND_KTV_ERROR_INFO_PAGE,SW_SHOW);
												MApp_ZUI_API_SetFocus(HWND_KTV_ERROR_INFO_BUTTON);
											  }

											u8CurrentOrderlistPageIdx = KLM_GetOrderNum();
											if(0==KLM_GetOrderNum())
												u8CurrentRightlistTotalPage = 1;
											else
												u8CurrentRightlistTotalPage  = (u8CurrentOrderlistPageIdx+UI_KTV_ORDERLIST_NUMBER-1)/UI_KTV_ORDERLIST_NUMBER;

											u8CurrentRightlistPageIdx = u8CurrentRightlistTotalPage;

											MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_MAIN_MID_DISK_LIST);
											MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_MAIN_RIGHT_LIST);
											MApp_ZUI_API_InvalidateWindow(HWND_KTV_MAIN_RIGHT_PAGE_NUM);
											if(!MApp_MPlayer_IsMoviePlaying()&&!MApp_MPlayer_IsMusicPlaying())
												MApp_ZUI_ACTPlayFile(pstOrderSong);
										}
									}
								}
								return TRUE;
							default:
								break;
							}
						}
						else if(hwndCurFocus <= HWND_KTV_MAIN_MID_SONG_ITEM9 && hwndCurFocus >= HWND_KTV_MAIN_MID_SONG_ITEM0)
						{
							U8 u8ItemIdx = 0;

							for(u8ItemIdx=0;u8ItemIdx<UI_KTV_ORDERLIST_NUMBER;u8ItemIdx++)
							{
							    if(hwndCurFocus == _hwndListOrderMidSonglistItem[u8ItemIdx])
							    {
							        break;
							    }
							}
							if((!MApp_ZUI_API_IsWindowVisible(HWND_KTV_ERROR_INFO_PAGE))
							 	&&(!MApp_ZUI_API_IsWindowVisible(HWND_KTV_SET_BANNER))
							 	&&(!MApp_ZUI_API_IsWindowVisible(HWND_KTV_SEL_BANNER)))
							    {
									hwndPrevFocus = MApp_ZUI_API_GetFocus();
							    }
							switch(hwndCurFocus)
							{
							case HWND_KTV_MAIN_MID_SONG_ITEM0:
							case HWND_KTV_MAIN_MID_SONG_ITEM1:
							case HWND_KTV_MAIN_MID_SONG_ITEM2:
							case HWND_KTV_MAIN_MID_SONG_ITEM3:
							case HWND_KTV_MAIN_MID_SONG_ITEM4:
							case HWND_KTV_MAIN_MID_SONG_ITEM5:
							case HWND_KTV_MAIN_MID_SONG_ITEM6:
							case HWND_KTV_MAIN_MID_SONG_ITEM7:
							case HWND_KTV_MAIN_MID_SONG_ITEM8:
							case HWND_KTV_MAIN_MID_SONG_ITEM9:
							{
								switch(eDBFFileInfo)
								{
									case EN_SONG_LIST:
									case EN_SONG_REFER2_CHARACT:
									case EN_SONG_REFER2_SORT:
                                                            case EN_SONG_REFER2_LANGUAGE:
									case EN_SONG_PINYIN:
									{
										TOrderInfo pstOrderSong;
										SONG_LIST_INFO SongListInfo;
										U16 Len;

										memset( &SongListInfo,0,sizeof(SONG_LIST_INFO) );
										if(eDBFFileInfo == EN_SONG_PINYIN)
										{
											if(0 == u8CurrentLangSortPageIdx)
												return TRUE;
											else
											{
//												u8ItemIdx = u8ItemIdx + ((u8CurrentMidlistPageIdx -1) * UI_KTV_PINYINORDER_NUMBER);
												MApp_ZUI_ACT_GetKTVSongListInfo(&SongListInfo,u8ItemIdx - 1);
											}
										}
										else
										{
//											u8ItemIdx = u8ItemIdx + ((u8CurrentMidlistPageIdx -1) * UI_KTV_ORDERLIST_NUMBER);
											MApp_ZUI_ACT_GetKTVSongListInfo(&SongListInfo,u8ItemIdx + 1);
										}

										Len = sizeof(pstOrderSong.szFilePath);
										memset(pstOrderSong.szFilePath,0,Len);
										memcpy(pstOrderSong.szFilePath,SongListInfo.cSongPath,strlen(SongListInfo.cSongPath));
										Len = sizeof(pstOrderSong.szSongName);
										memset(pstOrderSong.szSongName,0,Len);
										memcpy(pstOrderSong.szSongName,SongListInfo.cSongName,strlen(SongListInfo.cSongName));
										pstOrderSong.nAudioTrack = SongListInfo.u16IsOrgin;
										KTVACT_DBG(printf("\nGetInfo----------\npstOrderSong->szFilePath = %s\n",pstOrderSong.szFilePath););

//										u8CurrentOrderlistPageIdx = KLM_GetOrderNum();

										if(SongListInfo.u32SongNum > 0)
										{
											if(u8CurrentOrderlistPageIdx<20)//the number of order song must less than 20
											  {
											    BOOLEAN isAddSuccess = false;
												isAddSuccess = KLM_AddSongInfo(&pstOrderSong);
												if(isAddSuccess)
												{
												 // printf("\n___less than 20 and addsongifo success__%d\n",KLM_GetOrderNum());
												}
											    else
											    {
											      //printf("\n___less than 20 and addsongifo failed__%d\n",KLM_GetOrderNum());
											    }
											  }
											else
											  {
											   // printf("\n___more than 20 and addsongifo failed__\n");
												enKTVErrorInfo = EN_KTV_ERROR_MORE_20_SONGNUM;
												MApp_ZUI_API_ShowWindow(HWND_KTV_ERROR_INFO_PAGE,SW_SHOW);
												MApp_ZUI_API_SetFocus(HWND_KTV_ERROR_INFO_BUTTON);
											  }
										}
										u8CurrentOrderlistPageIdx = KLM_GetOrderNum();
                                                                   if(0==u8CurrentOrderlistPageIdx)
                                                                         u8CurrentRightlistTotalPage = 1;
                                                                   else
	                                                                   u8CurrentRightlistTotalPage  = (u8CurrentOrderlistPageIdx+UI_KTV_ORDERLIST_NUMBER-1)/UI_KTV_ORDERLIST_NUMBER;

										u8CurrentRightlistPageIdx = u8CurrentRightlistTotalPage;

//										printf("\n--before MApp_ZUI_API_InvalidateAllSuccessors--\n");
//										MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_MAIN_RIGHT_LIST);
//										printf("\n--before MApp_ZUI_API_InvalidateWindow--\n");
//										MApp_ZUI_API_InvalidateWindow(HWND_KTV_MAIN_RIGHT_PAGE_NUM);
//										printf("\n--after MApp_ZUI_API_InvalidateWindow--\n");

										{
											U16 temp;
	                                                                  for(temp=0;temp<UI_KTV_ORDERLIST_NUMBER;temp++)
	                                                                   {
//												MApp_ZUI_API_ShowWindow(_hwndListOrderRightlistItem[temp],SW_SHOW);
												MApp_ZUI_API_InvalidateWindow(_hwndListOrderRightlistItem[temp]);
	                                                                   }
										}

										MApp_ZUI_API_InvalidateWindow(HWND_KTV_MAIN_RIGHT_PAGE_NUM);
									   if(!MApp_MPlayer_IsMoviePlaying()&&!MApp_MPlayer_IsMusicPlaying())
											MApp_ZUI_ACTPlayFile(pstOrderSong);
									}
										break;
								default:
									break;
								}
							}
								return TRUE;
								break;
							default:
								break;
							}
						}
						else if(hwndCurFocus <= HWND_KTV_MAIN_MID_ITEM9 && hwndCurFocus >= HWND_KTV_MAIN_MID_ITEM0)
						{
							U8 u8ItemIdx = 0;

							for(u8ItemIdx=0;u8ItemIdx<UI_KTV_ORDERLIST_NUMBER;u8ItemIdx++)
							{
							    if(hwndCurFocus == _hwndListOrderMidlistItem[u8ItemIdx])
							    {
							        break;
							    }
							}
							if((!MApp_ZUI_API_IsWindowVisible(HWND_KTV_ERROR_INFO_PAGE))
							 	&&(!MApp_ZUI_API_IsWindowVisible(HWND_KTV_SET_BANNER))
							 	&&(!MApp_ZUI_API_IsWindowVisible(HWND_KTV_SEL_BANNER)))
							    {
									hwndPrevFocus = MApp_ZUI_API_GetFocus();
							    }
							switch(hwndCurFocus)
							{
							case HWND_KTV_MAIN_MID_ITEM0:
							case HWND_KTV_MAIN_MID_ITEM1:
							case HWND_KTV_MAIN_MID_ITEM2:
							case HWND_KTV_MAIN_MID_ITEM3:
							case HWND_KTV_MAIN_MID_ITEM4:
							case HWND_KTV_MAIN_MID_ITEM5:
							case HWND_KTV_MAIN_MID_ITEM6:
							case HWND_KTV_MAIN_MID_ITEM7:
							case HWND_KTV_MAIN_MID_ITEM8:
							case HWND_KTV_MAIN_MID_ITEM9:
							{
								switch(eDBFFileInfo)
								{
									case EN_SINGER_SORT:
									{
										if(!pRecordSet)
										{
											enKTVErrorInfo = EN_KTV_ERROR_NO_FILE;
											MApp_ZUI_API_ShowWindow(HWND_KTV_ERROR_INFO_PAGE,SW_SHOW);
											MApp_ZUI_API_SetFocus(HWND_KTV_ERROR_INFO_BUTTON);
										}
										else
										{
	//										SINGER_SORT_INFO stSingSortInfo;
											MApp_ZUI_ACT_GetKTVSingerSortInfo(&stMidTitleSingSortInfo,u8ItemIdx+1);
											eDBFFileInfo = EN_SINGER_LIST;
											MApp_ZUI_ACT_GetKTVReleaseDBF();
											MApp_ZUI_ACT_GetKTVOpenDBF(stMidTitleSingSortInfo.u32SingSortId,(U8)u8CurrentMidlistPageIdx,UI_KTV_ORDERLIST_NUMBER);
											u8MidDepth = 1;

											//���������仯
											u8CurrentSingerlistPageIdx = MApp_ZUI_ACT_GetKTVSingerListCount();
											if(u8CurrentSingerlistPageIdx== 0)
											{
												MApp_ZUI_ACT_GetKTVReleaseDBF();
												eDBFFileInfo = EN_SINGER_SORT;
												MApp_ZUI_ACT_GetKTVOpenDBF(0,1,0);
												u8MidDepth = 0;

 												enKTVErrorInfo = EN_KTV_ERROR_NO_FILE;
												MApp_ZUI_API_ShowWindow(HWND_KTV_ERROR_INFO_PAGE,SW_SHOW);
												MApp_ZUI_API_SetFocus(HWND_KTV_ERROR_INFO_BUTTON);
											}
											else
											{
												u8CurrentMidlistPageIdx = 1;
												u8CurrentMidlistTotalPage = (u8CurrentSingerlistPageIdx - 1)/UI_KTV_ORDERLIST_NUMBER+1;
												MApp_ZUI_API_InvalidateWindow(HWND_KTV_MAIN_MID_TITLE_TEXT);
												MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_MAIN_MID_LIST);
												MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_MAIN_MID_PAGE_NUM);
												MApp_ZUI_API_SetFocus(_hwndListOrderMidlistItem[0]);
												MApp_ZUI_ACT_SetKTVCurrentMidDepthIndex();
											}
										}
									}
										break;
									case EN_SINGER_LIST:
									{
										if(!pRecordSet)
										{
											enKTVErrorInfo = EN_KTV_ERROR_NO_FILE;
											MApp_ZUI_API_ShowWindow(HWND_KTV_ERROR_INFO_PAGE,SW_SHOW);
											MApp_ZUI_API_SetFocus(HWND_KTV_ERROR_INFO_BUTTON);
										}
										else
										{
											u8CurrentMidlistPageIdx = 1;
	//										SINGER_LIST_INFO stSingerListInfo;
//											u8ItemIdx = u8ItemIdx + ((u8CurrentMidlistPageIdx -1) * UI_KTV_ORDERLIST_NUMBER);
											MApp_ZUI_ACT_GetKTVSingerListInfo(&stMidTitleSingerListInfo,u8ItemIdx+1);
											eDBFFileInfo = EN_SONG_LIST;
											MApp_ZUI_ACT_GetKTVReleaseDBF();
											MApp_ZUI_ACT_GetKTVOpenDBF(stMidTitleSingerListInfo.u32SingListId,(U8)u8CurrentMidlistPageIdx,UI_KTV_ORDERLIST_NUMBER);
											u8MidDepth = 2;

											//���������仯
											u8CurrentSonglistPageIdx = MApp_ZUI_ACT_GetKTVSongListCount();
											if(u8CurrentSonglistPageIdx== 0)
											{
												MApp_ZUI_ACT_GetKTVReleaseDBF();
												eDBFFileInfo = EN_SINGER_LIST;
												MApp_ZUI_ACT_GetKTVOpenDBF(stMidTitleSingSortInfo.u32SingSortId,(U8)u8CurrentMidlistPageIdx,UI_KTV_ORDERLIST_NUMBER);
 												u8MidDepth = 1;

 												enKTVErrorInfo = EN_KTV_ERROR_NO_FILE;
												MApp_ZUI_API_ShowWindow(HWND_KTV_ERROR_INFO_PAGE,SW_SHOW);
												MApp_ZUI_API_SetFocus(HWND_KTV_ERROR_INFO_BUTTON);
											}
											else
											{
												u8CurrentMidlistPageIdx = 1;
												u8CurrentMidlistTotalPage = (u8CurrentSonglistPageIdx - 1)/UI_KTV_ORDERLIST_NUMBER+1;
												MApp_ZUI_API_InvalidateWindow(HWND_KTV_MAIN_MID_TITLE_TEXT);
												MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_MAIN_MID_LIST);
												MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_MAIN_MID_PAGE_NUM);
												MApp_ZUI_API_SetFocus(_hwndListOrderMidlistItem[0]);
												MApp_ZUI_ACT_SetKTVCurrentMidDepthIndex();
											}
										}
									}
										break;

									case EN_SONG_LIST:
									{
										TOrderInfo pstOrderSong;
										SONG_LIST_INFO SongListInfo;
										U16 Len;

										memset( &SongListInfo,0,sizeof(SONG_LIST_INFO) );
										if(eDBFFileInfo == EN_SONG_PINYIN)
										{
											if(0 == u8CurrentLangSortPageIdx)
												return TRUE;
											else
											{
//												u8ItemIdx = u8ItemIdx + ((u8CurrentMidlistPageIdx -1) * UI_KTV_PINYINORDER_NUMBER);
												MApp_ZUI_ACT_GetKTVSongListInfo(&SongListInfo,u8ItemIdx - 1);
											}
										}
										else
										{
//											u8ItemIdx = u8ItemIdx + ((u8CurrentMidlistPageIdx -1) * UI_KTV_ORDERLIST_NUMBER);
											MApp_ZUI_ACT_GetKTVSongListInfo(&SongListInfo,u8ItemIdx + 1);
										}

										Len = sizeof(pstOrderSong.szFilePath);
										memset(pstOrderSong.szFilePath,0,Len);
										memcpy(pstOrderSong.szFilePath,SongListInfo.cSongPath,strlen(SongListInfo.cSongPath));
										Len = sizeof(pstOrderSong.szSongName);
										memset(pstOrderSong.szSongName,0,Len);
										memcpy(pstOrderSong.szSongName,SongListInfo.cSongName,strlen(SongListInfo.cSongName));
										KTVACT_DBG(printf("\nGetInfo----------\npstOrderSong->szFilePath = %s\n",pstOrderSong.szFilePath););
										if(SongListInfo.u32SongNum > 0)
										{
											if(KLM_GetOrderNum()<20)//the number of order song must less than 20
											  {
											    BOOLEAN isAddSuccess = false;
												isAddSuccess = KLM_AddSongInfo(&pstOrderSong);
												if(isAddSuccess)
												{
												 // printf("\n___less than 20 and addsongifo success__%d\n",KLM_GetOrderNum());
												}
											    else
											    {
											      //printf("\n___less than 20 and addsongifo failed__%d\n",KLM_GetOrderNum());
											    }
											  }
											else
											  {
											   // printf("\n___more than 20 and addsongifo failed__\n");
												enKTVErrorInfo = EN_KTV_ERROR_MORE_20_SONGNUM;
												MApp_ZUI_API_ShowWindow(HWND_KTV_ERROR_INFO_PAGE,SW_SHOW);
												MApp_ZUI_API_SetFocus(HWND_KTV_ERROR_INFO_BUTTON);
											  }
										}
										u8CurrentOrderlistPageIdx = KLM_GetOrderNum();
                                                                  if(0==KLM_GetOrderNum())
                                                                        u8CurrentRightlistTotalPage = 1;
                                                                  else
	                                                                 u8CurrentRightlistTotalPage  = (u8CurrentOrderlistPageIdx+UI_KTV_ORDERLIST_NUMBER-1)/UI_KTV_ORDERLIST_NUMBER;

										u8CurrentRightlistPageIdx = u8CurrentRightlistTotalPage;

//										printf("\n--before MApp_ZUI_API_InvalidateAllSuccessors--\n");
//										MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_MAIN_RIGHT_LIST);
//										printf("\n--before MApp_ZUI_API_InvalidateWindow--\n");
//										MApp_ZUI_API_InvalidateWindow(HWND_KTV_MAIN_RIGHT_PAGE_NUM);
//										printf("\n--after MApp_ZUI_API_InvalidateWindow--\n");

										{
											U16 temp;
	                                                                  for(temp=0;temp<UI_KTV_ORDERLIST_NUMBER;temp++)
	                                                                  {
												MApp_ZUI_API_ShowWindow(_hwndListOrderRightlistItem[temp],SW_SHOW);
	                                                                   }
										}

										MApp_ZUI_API_InvalidateWindow(HWND_KTV_MAIN_RIGHT_PAGE_NUM);
									       if(!MApp_MPlayer_IsMoviePlaying()&&!MApp_MPlayer_IsMusicPlaying())
											MApp_ZUI_ACTPlayFile(pstOrderSong);
									    }
										break;

                                                          	case EN_CHARACTER_SORT:
                                                                {
										if(!pRecordSet)
										{
											enKTVErrorInfo = EN_KTV_ERROR_NO_FILE;
											MApp_ZUI_API_ShowWindow(HWND_KTV_ERROR_INFO_PAGE,SW_SHOW);
											MApp_ZUI_API_SetFocus(HWND_KTV_ERROR_INFO_BUTTON);
										}
										else
										{
	//										SONG_COUNT_INFO  SongCountInfo;
											MApp_ZUI_ACT_GetKTVSongCountInfo(&stMidTitleSongCountInfo,u8ItemIdx+1);

											eDBFFileInfo = EN_SONG_REFER2_CHARACT;
											MApp_ZUI_ACT_GetKTVReleaseDBF();
											MApp_ZUI_ACT_GetKTVOpenDBF(stMidTitleSongCountInfo.u16SongCount,(U8)u8CurrentMidlistPageIdx,UI_KTV_ORDERLIST_NUMBER);
											u8MidDepth = 1;

											u8CurrentSonglistPageIdx = MApp_ZUI_ACT_GetKTVSongListCount();
											if(u8CurrentSonglistPageIdx == 0)
											{
												MApp_ZUI_ACT_GetKTVReleaseDBF();
												eDBFFileInfo = EN_CHARACTER_SORT;
												MApp_ZUI_ACT_GetKTVOpenDBF(0,1,0);
												u8MidDepth = 0;

												MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_MAIN_MID_LIST);
												enKTVErrorInfo = EN_KTV_ERROR_NO_FILE;
												MApp_ZUI_API_ShowWindow(HWND_KTV_ERROR_INFO_PAGE,SW_SHOW);
												MApp_ZUI_API_SetFocus(HWND_KTV_ERROR_INFO_BUTTON);
											}
											else
											{
											      u8CurrentMidlistPageIdx = 1;
												u8CurrentSongCoutPageIdx = MApp_ZUI_ACT_GetKTVSongCountCount();
            									             u8CurrentMidlistTotalPage = (u8CurrentSongCoutPageIdx+UI_KTV_ORDERLIST_NUMBER-1)/UI_KTV_ORDERLIST_NUMBER;
												MApp_ZUI_API_InvalidateWindow(HWND_KTV_MAIN_MID_TITLE_TEXT);
//												MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_MAIN_MID_LIST);
												MApp_ZUI_API_ShowWindow(HWND_KTV_MAIN_MID_LIST,SW_HIDE);
												MApp_ZUI_API_ShowWindow(HWND_KTV_MAIN_MID_SONG_LIST,SW_SHOW);
												MApp_ZUI_API_SetFocus(_hwndListOrderMidSonglistItem[0]);
												MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_MAIN_MID_PAGE_NUM);
												MApp_ZUI_ACT_SetKTVCurrentMidDepthIndex();
											}

										}
                                	}
                                	break;
                                case EN_SONG_SORT:
                                	{

										if(!pRecordSet)
										{
											enKTVErrorInfo = EN_KTV_ERROR_NO_FILE;
											MApp_ZUI_API_ShowWindow(HWND_KTV_ERROR_INFO_PAGE,SW_SHOW);
											MApp_ZUI_API_SetFocus(HWND_KTV_ERROR_INFO_BUTTON);
										}
										else
										{
//											u8ItemIdx = u8ItemIdx + ((u8CurrentMidlistPageIdx - 1) * UI_KTV_ORDERLIST_NUMBER);
	                                                                  //SONG_SORT_INFO SongSortInfo;
	                                                                 MApp_ZUI_ACT_GetKTVSongSortInfo(&stMidTitleSongSortInfo,u8ItemIdx + 1);

	                                                                 eDBFFileInfo = EN_SONG_REFER2_SORT;
	                                                                 MApp_ZUI_ACT_GetKTVReleaseDBF();
	                                                                 MApp_ZUI_ACT_GetKTVOpenDBF(stMidTitleSongSortInfo.u16SongSortId,(U8)u8CurrentMidlistPageIdx,UI_KTV_ORDERLIST_NUMBER);
	                                                                 u8MidDepth = 1;

	                                                                  u8CurrentSonglistPageIdx = MApp_ZUI_ACT_GetKTVSongListCount();
											if(u8CurrentSonglistPageIdx== 0)
											{
												MApp_ZUI_ACT_GetKTVReleaseDBF();
												eDBFFileInfo = EN_SONG_SORT;
												MApp_ZUI_ACT_GetKTVOpenDBF(0,1,0);
												u8MidDepth = 0;

												MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_MAIN_MID_LIST);
												enKTVErrorInfo = EN_KTV_ERROR_NO_FILE;
												MApp_ZUI_API_ShowWindow(HWND_KTV_ERROR_INFO_PAGE,SW_SHOW);
												MApp_ZUI_API_SetFocus(HWND_KTV_ERROR_INFO_BUTTON);
											}
											else
											{
												u8CurrentMidlistPageIdx = 1;
												u8CurrentSongSortPageIdx = MApp_ZUI_ACT_GetKTVSongSortCount();
            									              u8CurrentMidlistTotalPage = (u8CurrentSongSortPageIdx+UI_KTV_ORDERLIST_NUMBER-1)/UI_KTV_ORDERLIST_NUMBER;
												MApp_ZUI_API_InvalidateWindow(HWND_KTV_MAIN_MID_TITLE_TEXT);
//		                                                                   MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_MAIN_MID_LIST);
		                                                                   MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_MAIN_MID_PAGE_NUM);
												MApp_ZUI_API_ShowWindow(HWND_KTV_MAIN_MID_LIST,SW_HIDE);
												MApp_ZUI_API_ShowWindow(HWND_KTV_MAIN_MID_SONG_LIST,SW_SHOW);
												MApp_ZUI_API_SetFocus(_hwndListOrderMidSonglistItem[0]);
												MApp_ZUI_ACT_SetKTVCurrentMidDepthIndex();
											}
										}
                                	}
                                    break;

                                case EN_LANGUAGE_SORT:
                                    {
										if(!pRecordSet)
										{
											enKTVErrorInfo = EN_KTV_ERROR_NO_FILE;
											MApp_ZUI_API_ShowWindow(HWND_KTV_ERROR_INFO_PAGE,SW_SHOW);
											MApp_ZUI_API_SetFocus(HWND_KTV_ERROR_INFO_BUTTON);
										}
										else
										{
	                                        MApp_ZUI_ACT_GetKTVLanguageSortInfo(&stMidTitleLangSortInfo,u8ItemIdx + 1);

	                                        eDBFFileInfo = EN_SONG_REFER2_LANGUAGE;
	                                        MApp_ZUI_ACT_GetKTVReleaseDBF();
	                                        MApp_ZUI_ACT_GetKTVOpenDBF(stMidTitleLangSortInfo.u16LangId,(U8)u8CurrentMidlistPageIdx,UI_KTV_ORDERLIST_NUMBER);
	                                        u8MidDepth = 1;

	                                        u8CurrentSonglistPageIdx = MApp_ZUI_ACT_GetKTVSongListCount();
											if(u8CurrentSonglistPageIdx== 0)
											{
												MApp_ZUI_ACT_GetKTVReleaseDBF();
												eDBFFileInfo = EN_LANGUAGE_SORT;
												MApp_ZUI_ACT_GetKTVOpenDBF(0,1,0);
												u8MidDepth = 0;

												MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_MAIN_MID_LIST);
												enKTVErrorInfo = EN_KTV_ERROR_NO_FILE;
												MApp_ZUI_API_ShowWindow(HWND_KTV_ERROR_INFO_PAGE,SW_SHOW);
												MApp_ZUI_API_SetFocus(HWND_KTV_ERROR_INFO_BUTTON);
											}
											else
											{
												u8CurrentMidlistPageIdx = 1;
												u8CurrentMidlistTotalPage = (u8CurrentSonglistPageIdx - 1)/UI_KTV_ORDERLIST_NUMBER+1;
												MApp_ZUI_API_InvalidateWindow(HWND_KTV_MAIN_MID_TITLE_TEXT);
//		                                        MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_MAIN_MID_LIST);
		                                        MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_MAIN_MID_PAGE_NUM);
												MApp_ZUI_API_ShowWindow(HWND_KTV_MAIN_MID_LIST,SW_HIDE);
												MApp_ZUI_API_ShowWindow(HWND_KTV_MAIN_MID_SONG_LIST,SW_SHOW);
												MApp_ZUI_API_SetFocus(_hwndListOrderMidSonglistItem[0]);
												MApp_ZUI_ACT_SetKTVCurrentMidDepthIndex();
											}
										}
                                	}
                                    break;

								case EN_SONG_BY_DISK:
									{
										TOrderInfo pstOrderSong;
										MEDIA_FILE_INFO MediaFileInfo;
										U16 Len;
										U8 TempFilePath[128]={0};

										TLONG Handle=0;//1;
										U16 wStep=0;//UI_KTV_ORDERLIST_NUMBER;

										MApp_ZUI_ACT_GetKTVVideoItemsInDiskInfo(&MediaFileInfo,u8ItemIdx + 1);
										if(0 == MediaFileInfo.u16MediaType)
										{
											u8MidDepth++;
											strcat((char *)aSearchPath,(const char *)MediaFileInfo.cFileName);
											strcpy((char *)enterFileNme,(const char *)aSearchPath);
											strcat((char *)aSearchPath,(const char *)"\\");
											strcpy((char *)TempFilePath,(const char *)aSearchPath);
											//U16 wPathLen = strlen((const char *)TempFilePath)*2;
											U16 wPathLen = __ASCIItoUnicode((U8*)TempFilePath);
											FMI_GetMediaData((TU8 *)TempFilePath,wPathLen,FMI_MDT_VIDEO,&Handle,wStep,&pRecordSet );
											u8CurrentVideoItemsPageIdx = MApp_ZUI_ACT_GetKTVVideoItemsInDiskCount();
											if(0 == u8CurrentVideoItemsPageIdx)
											u8CurrentVideoItemsPageIdx =1;
											u8CurrentMidlistTotalPage = (u8CurrentVideoItemsPageIdx+UI_KTV_ORDERLIST_NUMBER-1)/UI_KTV_ORDERLIST_NUMBER;
											MApp_ZUI_API_SetFocus(_hwndListOrderMidlistItem[0]);
										}
										else
										{
											strcpy((char *)TempFilePath,(const char *)aSearchPath);
											strcat(TempFilePath,MediaFileInfo.cFileName);
											Len = sizeof(pstOrderSong.szFilePath);
											memset(pstOrderSong.szFilePath,0,Len);
											memcpy((char *)pstOrderSong.szFilePath,(const char *)TempFilePath,strlen(TempFilePath));
											//printf("\nwzt at songpath =%s",pstOrderSong.szFilePath);
											Len = sizeof(pstOrderSong.szSongName);
											memset(pstOrderSong.szSongName,0,Len);
											memcpy(pstOrderSong.szSongName,MediaFileInfo.cFileName,strlen(MediaFileInfo.cFileName));
											if(KLM_GetOrderNum()<20)//the number of order song must less than 20
											  {
											    BOOLEAN isAddSuccess = false;
												isAddSuccess = KLM_AddSongInfo(&pstOrderSong);
												if(isAddSuccess)
												{
												  //printf("\n___less than 20 and addsongifo success__%d\n",KLM_GetOrderNum());
												}
											    else
											    {
											     // printf("\n___less than 20 and addsongifo failed__%d\n",KLM_GetOrderNum());
											    }
											  }
											else
											  {
											   // printf("\n___more than 20 and addsongifo failed__\n");
												enKTVErrorInfo = EN_KTV_ERROR_MORE_20_SONGNUM;
												MApp_ZUI_API_ShowWindow(HWND_KTV_ERROR_INFO_PAGE,SW_SHOW);
												MApp_ZUI_API_SetFocus(HWND_KTV_ERROR_INFO_BUTTON);
											  }
										}
										u8CurrentOrderlistPageIdx = KLM_GetOrderNum();
										if(0==KLM_GetOrderNum())
											u8CurrentRightlistTotalPage = 1;
										else
											u8CurrentRightlistTotalPage  = (u8CurrentOrderlistPageIdx+UI_KTV_ORDERLIST_NUMBER-1)/UI_KTV_ORDERLIST_NUMBER;

										u8CurrentRightlistPageIdx = u8CurrentRightlistTotalPage;

										MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_MAIN_MID_LIST);
										MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_MAIN_RIGHT_LIST);
										MApp_ZUI_API_InvalidateWindow(HWND_KTV_MAIN_RIGHT_PAGE_NUM);
										if(!MApp_MPlayer_IsMoviePlaying()&&!MApp_MPlayer_IsMusicPlaying())
											MApp_ZUI_ACTPlayFile(pstOrderSong);
									}

									break;
								default:
									break;
								}
							}
								return TRUE;
								break;
							default:
								break;
							}
						}
						else if(hwndCurFocus <= HWND_KTV_MAIN_RIGHT_ITEM9 && hwndCurFocus >= HWND_KTV_MAIN_RIGHT_ITEM0)
						{
							return TRUE;
//							MApp_ZUI_API_SetFocus(HWND_KTV_MAIN_MID_ITEM0);
						}
					}
	                else if(MApp_ZUI_API_IsWindowVisible(HWND_KTV_SEL_BANNER))
	                {
	                	bEnterSelPage = FALSE;
	                    switch(hwndCurFocus)
	                    {
	                            case HWND_SEL_BANNER_ITEM0_BUTTON_1:
	                            case HWND_SEL_BANNER_ITEM1_BUTTON_1:
	                            case HWND_SEL_BANNER_ITEM2_BUTTON_1:
	                            case HWND_SEL_BANNER_ITEM3_BUTTON_1:
	                            case HWND_SEL_BANNER_ITEM4_BUTTON_1:
	                            case HWND_SEL_BANNER_ITEM5_BUTTON_1:
	                                {

	                                    U16 u16ItemIdx = 0;
	                                    TOrderInfo pstOrderInfo;
	                                    BOOLEAN bRet = FALSE;
	                                    for(u16ItemIdx=0;u16ItemIdx<UI_KTV_SELECTEDSONGLIST_NUMBER;u16ItemIdx++)
	                                    {
	                                        if(hwndCurFocus == _hwndListSelectedSongListBotton1Item[u16ItemIdx])
	                                        {
	                                            break;
	                                        }
	                                    }

	                                    if(u8CurrentSelectedSongListPageIdx>1)
	                                        {
	                                            //u8PageIdx = KLM_GetOrderNum()-UI_KTV_SELECTEDSONGLIST_NUMBER*(u8CurrentSelectedSongListPageIdx-1);
	                                            //if(u16ItemIdx<u8PageIdx)
	                                                MApp_ZUI_ACT_GetKTVOrderSongInfo(&pstOrderInfo,u16ItemIdx+(UI_KTV_SELECTEDSONGLIST_NUMBER*(u8CurrentSelectedSongListPageIdx-1)));
												    bRet  = KLM_Priority(u16ItemIdx+(UI_KTV_SELECTEDSONGLIST_NUMBER*(u8CurrentSelectedSongListPageIdx-1)),&pstOrderInfo);
	                                        }
	                                    else
	                                    	{
		                                       MApp_ZUI_ACT_GetKTVOrderSongInfo(&pstOrderInfo,u16ItemIdx);
											   bRet  = KLM_Priority(u16ItemIdx,&pstOrderInfo);
		                                    	}
	                            //KLM_DelSongInfo(&stOrderInfo);//return NULL;

	                            if( bRet )
	                                printf( "KLM_Priority() call success!\n" );
	                            else
	                                printf( "KLM_Priority() call false!\n" );
	                            break;
	                            }

	                        case HWND_SEL_BANNER_ITEM0_BUTTON_2:
	                        case HWND_SEL_BANNER_ITEM1_BUTTON_2:
	                        case HWND_SEL_BANNER_ITEM2_BUTTON_2:
	                        case HWND_SEL_BANNER_ITEM3_BUTTON_2:
	                        case HWND_SEL_BANNER_ITEM4_BUTTON_2:
	                        case HWND_SEL_BANNER_ITEM5_BUTTON_2:
	                        {

	                            U16 u16ItemIdx = 0;
	                            TOrderInfo pstOrderInfo;
								BOOLEAN bRet = FALSE;

	                            for(u16ItemIdx=0;u16ItemIdx<UI_KTV_SELECTEDSONGLIST_NUMBER;u16ItemIdx++)
	                            {
	                                if(hwndCurFocus == _hwndListSelectedSongListBotton2Item[u16ItemIdx])
	                                {
	                                    break;
	                                }
	                            }
	                            if(u8CurrentSelectedSongListPageIdx>1)
	                                {
	                                    MApp_ZUI_ACT_GetKTVOrderSongInfo(&pstOrderInfo,u16ItemIdx+(UI_KTV_SELECTEDSONGLIST_NUMBER*(u8CurrentSelectedSongListPageIdx-1)));
										bRet =  KLM_DelSongInfo(u16ItemIdx+(UI_KTV_SELECTEDSONGLIST_NUMBER*(u8CurrentSelectedSongListPageIdx-1)),&pstOrderInfo);
	                                }
	                            else
	                            	{
	                                    MApp_ZUI_ACT_GetKTVOrderSongInfo(&pstOrderInfo,u16ItemIdx);
										bRet =  KLM_DelSongInfo(u16ItemIdx,&pstOrderInfo);
	                            	}
	                            //KLM_DelSongInfo(&stOrderInfo);//return NULL;

	                            if( bRet )
	                            	{
	                            	bEnterSelPage=FALSE;
									MApp_ZUI_API_InvalidateSelectListItem();
									//printf("\n&&&s=%d,n=%d**\n",u16ItemIdx+1+UI_KTV_SELECTEDSONGLIST_NUMBER*(u8CurrentSelectedSongListPageIdx-1),KLM_GetOrderNum());
									if((u16ItemIdx+UI_KTV_SELECTEDSONGLIST_NUMBER*(u8CurrentSelectedSongListPageIdx-1)==KLM_GetOrderNum())\
									   &&(u16ItemIdx !=0))
										{
										 MApp_ZUI_API_SetFocus(hwndCurFocus-5);
										}
									else
										{
										MApp_ZUI_API_SetFocus(hwndCurFocus);
										}
	                                printf( "KLM_DelSongInfo() call success!\n" );
	                            	}
	                            else
	                            	{
	                                printf( "KLM_DelSongInfo() call false!\n" );
	                            	}
	                            break;

								MApp_ZUI_API_InvalidateWindow(HWND_KTV_SEL_BANNER_PAGENUM);
	                        }

	                        default:
	                            break;
	                    }
	                    MApp_ZUI_API_InvalidateWindow(HWND_KTV_SEL_BANNER);
	                }
				}
				return TRUE;
			case VK_UP:
				if(MApp_ZUI_API_IsWindowVisible(HWND_KTV_MAIN_BG))
				{
					MApp_ActKtv_Main_UpDownKey(FALSE);
					MApp_ZUI_API_InvalidateWindow(HWND_KTV_MAIN_MID_TITLE_TEXT);
				}
				else if(MApp_ZUI_API_IsWindowVisible(HWND_KTV_SET_BANNER))
				{
					MApp_ActKtv_SetBanner_UpDownKey(FALSE);
				}
                else if(MApp_ZUI_API_IsWindowVisible(HWND_KTV_SEL_BANNER))
                {
					MApp_ActKtv_SelectedSongList_UpDownKey(FALSE);
                }
				return TRUE;
			case VK_DOWN:
				if(MApp_ZUI_API_IsWindowVisible(HWND_KTV_MAIN_BG))
				{
					MApp_ActKtv_Main_UpDownKey(TRUE);
					MApp_ZUI_API_InvalidateWindow(HWND_KTV_MAIN_MID_TITLE_TEXT);
				}
				else if(MApp_ZUI_API_IsWindowVisible(HWND_KTV_SET_BANNER))
				{
					MApp_ActKtv_SetBanner_UpDownKey(TRUE);
				}
	                     else if(MApp_ZUI_API_IsWindowVisible(HWND_KTV_SEL_BANNER))
	                    {
                                MApp_ActKtv_SelectedSongList_UpDownKey(TRUE);
	                       }
				return TRUE;
			case   VK_PAGE_UP:
				{
					HWND curFocus = MApp_ZUI_API_GetFocus();
					if(MApp_ZUI_API_IsWindowVisible(HWND_KTV_MAIN_MID_LIST)
						&&(curFocus>89)&&(curFocus<109))
					{
						if(u8CurrentMidlistPageIdx >1)
						u8CurrentMidlistPageIdx -= 1 ;
						else
						u8CurrentMidlistPageIdx = u8CurrentMidlistTotalPage;
						MApp_ZUI_ACT_GetKTVReleaseDBF();
						MApp_ZUI_ACT_GetKTVNextPage((U8)u8CurrentMidlistPageIdx);
						MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_MAIN_MID_LIST);
						MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_MAIN_MID_PAGE_NUM);
						MApp_ZUI_API_SetFocus(HWND_KTV_MAIN_MID_ITEM0);
						return TRUE;
					}
					if(MApp_ZUI_API_IsWindowVisible(HWND_KTV_MAIN_MID_SONG_LIST)
						&&(curFocus>146)&&(curFocus<176))
					{
						if(u8CurrentMidlistPageIdx >1)
						u8CurrentMidlistPageIdx -= 1 ;
						else
						u8CurrentMidlistPageIdx = u8CurrentMidlistTotalPage;
						MApp_ZUI_ACT_GetKTVReleaseDBF();
						MApp_ZUI_ACT_GetKTVNextPage((U8)u8CurrentMidlistPageIdx);
						MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_MAIN_MID_SONG_LIST);
						MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_MAIN_MID_PAGE_NUM);
						MApp_ZUI_API_SetFocus(HWND_KTV_MAIN_MID_SONG_ITEM0);
						return TRUE;
					}
					if(MApp_ZUI_API_IsWindowVisible(HWND_KTV_MAIN_MID_DISK_LIST)
						&&(curFocus>115)&&(curFocus<145))
					{
						if(u8CurrentMidlistPageIdx >1)
						u8CurrentMidlistPageIdx -= 1 ;
						else
						u8CurrentMidlistPageIdx = u8CurrentMidlistTotalPage;
						MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_MAIN_MID_LIST);
						MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_MAIN_MID_PAGE_NUM);
						MApp_ZUI_API_SetFocus(HWND_KTV_MAIN_MID_DISK_ITEM0);
					}
					if(MApp_ZUI_API_IsWindowVisible(HWND_KTV_MAIN_RIGHT_LIST)
						&&(curFocus>184)&&(curFocus<204))
					{
						if( u8CurrentRightlistPageIdx >1)
						u8CurrentRightlistPageIdx -= 1 ;
						else
						u8CurrentRightlistPageIdx = u8CurrentRightlistTotalPage;
						MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_MAIN_RIGHT_LIST);
						MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_MAIN_RIGHT_PAGE_NUM);
						MApp_ZUI_API_SetFocus(HWND_KTV_MAIN_RIGHT_ITEM0);
					}
					if(MApp_ZUI_API_IsWindowVisible(HWND_KTV_SEL_BANNER)
						&&(curFocus>205)&&(curFocus<236))
					{
						if( u8CurrentSelectedSongListPageIdx >1)
						u8CurrentSelectedSongListPageIdx -= 1 ;
						else
						u8CurrentSelectedSongListPageIdx = u8CurrentSelectedSongListTotalPage;
						MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_SEL_BANNER);
						bEnterSelPage = FALSE;
						MApp_ZUI_API_InvalidateSelectListItem();
						if(0!=KLM_GetOrderNum())
						  {
							MApp_ZUI_API_SetFocus(HWND_KTV_SEL_BANNER_ITEM0_TEXT);
						  }
					}

				}
			    return TRUE;
            case VK_PAGE_DOWN:
				{
					HWND curFocus = MApp_ZUI_API_GetFocus();
					if(MApp_ZUI_API_IsWindowVisible(HWND_KTV_MAIN_MID_LIST)
						&&(curFocus>89)&&(curFocus<109))
					{
						if(u8CurrentMidlistPageIdx <u8CurrentMidlistTotalPage)
							u8CurrentMidlistPageIdx += 1 ;
						else
							u8CurrentMidlistPageIdx = 1 ;
						MApp_ZUI_ACT_GetKTVReleaseDBF();
						MApp_ZUI_ACT_GetKTVNextPage((U8)u8CurrentMidlistPageIdx);
						MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_MAIN_MID_LIST);
						MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_MAIN_MID_PAGE_NUM);
						MApp_ZUI_API_SetFocus(HWND_KTV_MAIN_MID_ITEM0);
					}
					if(MApp_ZUI_API_IsWindowVisible(HWND_KTV_MAIN_MID_SONG_LIST)
						&&(curFocus>146)&&(curFocus<176))
					{
						if(u8CurrentMidlistPageIdx <u8CurrentMidlistTotalPage)
							u8CurrentMidlistPageIdx += 1 ;
						else
							u8CurrentMidlistPageIdx = 1 ;
						MApp_ZUI_ACT_GetKTVReleaseDBF();
						MApp_ZUI_ACT_GetKTVNextPage((U8)u8CurrentMidlistPageIdx);
						MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_MAIN_MID_SONG_LIST);
						MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_MAIN_MID_PAGE_NUM);
						MApp_ZUI_API_SetFocus(HWND_KTV_MAIN_MID_SONG_ITEM0);
					}
					if(MApp_ZUI_API_IsWindowVisible(HWND_KTV_MAIN_MID_DISK_LIST)
						&&(curFocus>115)&&(curFocus<145))
					{
						if(u8CurrentMidlistPageIdx <u8CurrentMidlistTotalPage)
						u8CurrentMidlistPageIdx += 1 ;
						else
						u8CurrentMidlistPageIdx = 1 ;
						MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_MAIN_MID_LIST);
						MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_MAIN_MID_PAGE_NUM);
						MApp_ZUI_API_SetFocus(HWND_KTV_MAIN_MID_DISK_ITEM0);
					}
					if(MApp_ZUI_API_IsWindowVisible(HWND_KTV_MAIN_RIGHT_LIST)
						&&(curFocus>184)&&(curFocus<204))
					{
						if( u8CurrentRightlistPageIdx <u8CurrentRightlistTotalPage)
						u8CurrentRightlistPageIdx += 1 ;
						else
						u8CurrentRightlistPageIdx = 1 ;
						MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_MAIN_RIGHT_LIST);
						MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_MAIN_RIGHT_PAGE_NUM);
						MApp_ZUI_API_SetFocus(HWND_KTV_MAIN_RIGHT_ITEM0);
					}
					if(MApp_ZUI_API_IsWindowVisible(HWND_KTV_SEL_BANNER)
						&&(curFocus>205)&&(curFocus<236))
					{
						if( u8CurrentSelectedSongListPageIdx <u8CurrentSelectedSongListTotalPage)
						u8CurrentSelectedSongListPageIdx += 1 ;
						else
						u8CurrentSelectedSongListPageIdx = 1 ;
						MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_SEL_BANNER);
						bEnterSelPage = FALSE;
						MApp_ZUI_API_InvalidateSelectListItem();
						if(0!=KLM_GetOrderNum())
						  {
							MApp_ZUI_API_SetFocus(HWND_KTV_SEL_BANNER_ITEM0_TEXT);
						  }

					}
				}
				return TRUE;
			case VK_LEFT:
				MApp_ActKtv_Main_LeftRightKey(TRUE);
				return TRUE;
			case VK_RIGHT:
				MApp_ActKtv_Main_LeftRightKey(FALSE);
				return TRUE;
		    case VK_NUM_0:
				if(MApp_MPlayer_QueryMusicPlayMode() == E_MPLAYER_MUSIC_NORMAL)
				{
					MApp_MPlayer_MusicChangePlayMode(E_MPLAYER_MUSIC_PAUSE);
				}
				return TRUE;
			case VK_NUM_1:
				{
				    if(MApp_MPlayer_QueryMusicPlayMode() == E_MPLAYER_MUSIC_PAUSE)
					MApp_MPlayer_MusicChangePlayMode(E_MPLAYER_MUSIC_NORMAL);
				}
				return TRUE;
                    case VK_MUTE:
                        {
                            printf("hot key mute\n");
                           MApp_KeyProc_Mute();
                        }
                        return TRUE;
		default:
	        return TRUE;
		}
	}
	else
	{
		switch(key)
		{
			case VK_SELECT:
			{
//				int i;
//				SONG_LIST_INFO SongListInfo;
				if(strlen(szPinYinInputValue) == 0)
					return TRUE;

                           MApp_ZUI_ACT_GetKTVReleaseDBF();

				bPinYinInputMode = FALSE;
				strcat(szPinYinInputValue,InputChar);
				szPinYinInputValue[strlen(szPinYinInputValue)] = 0;
				InputChar[0]=0;
				MApp_ZUI_ACT_GetKTVOpenDBF(0,(U8)u8CurrentMidlistPageIdx,UI_KTV_PINYINORDER_NUMBER);
				u8CurrentLangSortPageIdx = MApp_ZUI_ACT_GetKTVLanguageSortCount();
				u8CurrentMidlistPageIdx = 1;
				if(u8CurrentLangSortPageIdx == 0)
					u8CurrentMidlistTotalPage =1;
				else
					u8CurrentMidlistTotalPage = (u8CurrentLangSortPageIdx+UI_KTV_PINYINORDER_NUMBER-1)/UI_KTV_PINYINORDER_NUMBER;

//				printf("\n---u8CurrentLangSortPageIdx =%d\n",u8CurrentLangSortPageIdx);
//				MApp_ZUI_API_ShowWindow(HWND_KTV_MAIN_MID_LIST,SW_SHOW);
//				MApp_ZUI_API_ShowWindow(HWND_KTV_MAIN_MID_LIST,SW_SHOW);
//				MApp_ZUI_API_ShowWindow(HWND_KTV_MAIN_MID_ITEM0,SW_HIDE);
//				MApp_ZUI_API_ShowWindow(HWND_KTV_MAIN_MID_ITEM1,SW_HIDE);
				MApp_ZUI_API_ShowWindow(HWND_KTV_MAIN_MID_SONG_LIST,SW_SHOW);
				MApp_ZUI_API_ShowWindow(HWND_KTV_MAIN_MID_SONG_ITEM0,SW_HIDE);
				MApp_ZUI_API_ShowWindow(HWND_KTV_MAIN_MID_SONG_ITEM1,SW_HIDE);
				MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_MAIN_MID_PAGE_NUM);
//				if(u8CurrentLangSortPageIdx>0)
					MApp_ZUI_API_SetFocus(HWND_KTV_MAIN_MID_SONG_ITEM2);
			}
			return TRUE;
			case VK_EXIT:
			{
				bPinYinInputMode = FALSE;
				MApp_ZUI_API_SetFocus(HWND_KTV_MAIN_LEFT_ITEM4);
			}
			return TRUE;
			case VK_MUTE:
				{
					MApp_KeyProc_Mute();
				}
				return TRUE;
			case VK_INPUT_SOURCE:
				bPinYinInputMode = FALSE;
				{
					MApp_ZUI_API_ShowWindow(HWND_MAINFRAME, SW_HIDE);
					MApp_ZUI_API_ShowWindow(HWND_KTV_CONTROL_BG, SW_SHOW);
					MApp_ZUI_API_SetFocus(HWND_KTV_BUTTON_EXIT);
					MApp_ZUI_API_ShowWindow(HWND_KTV_EXIT_BANNER, SW_SHOW);
					return TRUE;
				}

//				if(MApp_MPlayer_IsMoviePlaying()||MApp_MPlayer_IsMusicPlaying())
//				{
//	                MApp_MPlayer_Stop();
//	                MApp_MPlayer_StopMusic();
//					if(IsOpenLrc)
//					{
//					MApp_ZUI_ACT_Endlrc();
//					}
//				}
//				MApp_Photo_SlideShow(TRUE);
//				MApp_KTV_SetState(KTVSTATE_GOTO_INPUTSOURCE);
//				return TRUE;
			default:
				break;
		}
	}
		return FALSE;

    return FALSE;
}

void MApp_ZUI_ACT_TerminateKTV(void)
{
   ZUI_MSG( printf("[]term:tenkey\n");)
    //MApp_SaveGenSetting();
}

BOOLEAN MApp_ZUI_ACT_ExecuteKTVAction(U16 act)
{
    switch(act)
    {
        case EN_EXE_CLOSE_CURRENT_OSD:
        case EN_EXE_POWEROFF:
            MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
            return TRUE;
		case EN_EXE_KTV_DEC_BGVOLUME:
		case EN_EXE_KTV_INC_BGVOLUME:
			if(act == EN_EXE_KTV_INC_BGVOLUME)
			{
				if ( stGenSetting.g_SoundSetting.BGVolume < MAX_NUM_OF_KTVBG_VOL_LEVEL )
                                 stGenSetting.g_SoundSetting.BGVolume++;
			}
                    else
                      {
                          if ( stGenSetting.g_SoundSetting.BGVolume > 0 )
                                stGenSetting.g_SoundSetting.BGVolume--;
                        }
			if(act == EN_EXE_KTV_INC_BGVOLUME)
			{
                          msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_BYUSER_MUTEOFF, E_AUDIOMUTESOURCE_ACTIVESOURCE);
                          MApp_UiMenu_MuteWin_Hide();
				_MApp_KTV_SetBGVolume(stGenSetting.g_SoundSetting.BGVolume);
			}
			else
			{
				if(!msAPI_AUD_IsAudioMutedByUser())
					_MApp_KTV_SetBGVolume(stGenSetting.g_SoundSetting.BGVolume);
			}
                    MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_SET_ACC_VOLUME);
			MApp_SaveSoundSetting();
			return TRUE;
		case EN_EXE_KTV_DEC_MICVOLUME:
		case EN_EXE_KTV_INC_MICVOLUME:
			if(act == EN_EXE_KTV_INC_MICVOLUME)
			{
				if ( stGenSetting.g_SoundSetting.KTVMicVolume < MAX_NUM_OF_KTVBG_VOL_LEVEL )
                                stGenSetting.g_SoundSetting.KTVMicVolume++;
			}
                   else
                   {
                         if ( stGenSetting.g_SoundSetting.KTVMicVolume > 0 )
                               stGenSetting.g_SoundSetting.KTVMicVolume--;
                     }
			_MApp_E_KTV_SetMicVolume(stGenSetting.g_SoundSetting.KTVMicVolume);
			MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_SET_MICORPHONE_VOLUME);
			MApp_SaveSoundSetting();
			return TRUE;
		case EN_EXE_KTV_DEC_MIXVOLUME:
		case EN_EXE_KTV_INC_MIXVOLUME:
			if(act == EN_EXE_KTV_INC_MIXVOLUME)
			{
				if ( stGenSetting.g_SoundSetting.MixVolume < MAX_NUM_OF_KTVMIX_VOL_LEVEL )
                    stGenSetting.g_SoundSetting.MixVolume++;
			}
            else
            {
                if ( stGenSetting.g_SoundSetting.MixVolume > 0 )
                    stGenSetting.g_SoundSetting.MixVolume--;
            }

			if(stGenSetting.g_SoundSetting.MixVolume == 0)
				MApi_AUDIO_EnableSurround(FALSE);
			else
				MApi_AUDIO_EnableSurround(TRUE);

			_MApp_E_KTV_SetMixVolume(stGenSetting.g_SoundSetting.MixVolume);
			MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_SET_MIX_VOLUME);
			MApp_SaveSoundSetting();
			return TRUE;
		case EN_EXE_KTV_SET_AUDIOTYPE:
			{
//				if(u8AuidoType == 2)
//				{
//					u8AuidoType = 0;
//				}
//				else
//				{
//					u8AuidoType++;
//				}

//				printf("\n======u8AuidoType = %d ======\n",u8AuidoType);
//				if (u8AuidoType == 0)
//				{
//					//MApi_AUDIO_SetCommAudioInfo(Audio_Comm_infoType_SoundMode, 0, 0);
//				}
//				else if (u8AuidoType == 1)
//				{
//					//MApi_AUDIO_SetCommAudioInfo(Audio_Comm_infoType_SoundMode, 2, 0);
//					MApi_AUDIO_SetMpegInfo(Audio_MPEG_infoType_SoundMode, 1, 0);
//				}
//				else if (u8AuidoType == 2)
//				{
//					//MApi_AUDIO_SetCommAudioInfo(Audio_Comm_infoType_SoundMode, 1, 0);
//					MApi_AUDIO_SetMpegInfo(Audio_MPEG_infoType_SoundMode, 0, 0);
//				}

				bIsOrigal = !bIsOrigal;

				if (u8AuidoType == 1)//left
				{
					if(bIsOrigal)
					{
						MApi_AUDIO_SetMpegInfo(Audio_MPEG_infoType_SoundMode, 0, 0);
					}
					else
					{
//						MApi_AUDIO_SetCommAudioInfo(Audio_Comm_infoType_SoundMode, 0, 0);
						MApi_AUDIO_SetMpegInfo(Audio_MPEG_infoType_SoundMode, 2, 0 );
					}
				}
				else // if (u8AuidoType == 2) //right
				{
					if(bIsOrigal)
					{
						MApi_AUDIO_SetMpegInfo(Audio_MPEG_infoType_SoundMode, 1, 0);
					}
					else
					{
//						MApi_AUDIO_SetCommAudioInfo(Audio_Comm_infoType_SoundMode, 0, 0);
						MApi_AUDIO_SetMpegInfo(Audio_MPEG_infoType_SoundMode, 2, 0 );
					}
				}

				printf("\n-----bIsOrigal = %d\n",bIsOrigal);
				MApp_ZUI_API_ShowWindow(HWND_KTV_MESSAGE_BOX,SW_SHOW);
			}
			return TRUE;
		case EN_EXE_KTV_SET_BEST:
			{
                           msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_BYUSER_MUTEOFF, E_AUDIOMUTESOURCE_ACTIVESOURCE);
                            MApp_UiMenu_MuteWin_Hide();
				stGenSetting.g_SoundSetting.BGVolume = SET_BEST_BGVOLUME;
				stGenSetting.g_SoundSetting.KTVMicVolume = SET_BEST_MICVOLUME;
				stGenSetting.g_SoundSetting.MixVolume = SET_BEST_MIXVOLUME;
				MApp_KTV_SetBGVolume(stGenSetting.g_SoundSetting.BGVolume);
				MApp_KTV_SetMicVolume(stGenSetting.g_SoundSetting.KTVMicVolume);
				MApp_KTV_SetMixVolume(stGenSetting.g_SoundSetting.MixVolume);
				MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_SET_ACC_VOLUME);
				MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_SET_MICORPHONE_VOLUME);
				MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_SET_MIX_VOLUME);
			}
			return TRUE;
		case EN_EXE_KTV_PLAY_NEXT:
		{
			TOrderInfo pstOrderSong;
			//delete playing song

			if(0 == KLM_GetOrderNum())
			{
			     if((!MApp_ZUI_API_IsWindowVisible(HWND_KTV_ERROR_INFO_PAGE))
				 	&&(!MApp_ZUI_API_IsWindowVisible(HWND_KTV_SET_BANNER))
				 	&&(!MApp_ZUI_API_IsWindowVisible(HWND_KTV_SEL_BANNER)))
				    {
						hwndPrevFocus = MApp_ZUI_API_GetFocus();
				    }
				//error   the last file zd 20101217
//				printf("\n------last song------\n");
				enKTVErrorInfo = EN_KTV_ERROR_LAST_SONG;
				MApp_ZUI_ACT_ShowErrorPage();
				MApp_ZUI_API_ShowWindow(HWND_KTV_LRC_SONGNAME,SW_HIDE);
				if(IsOpenLrc)
				{
					MApp_ZUI_ACT_Endlrc();
				}
				return TRUE;
			}
			else
			{
			    if(!MApp_ZUI_API_IsWindowVisible(HWND_KTV_ERROR_INFO_PAGE))
			    {
				    MApp_ZUI_API_ShowWindow(HWND_KTV_MESSAGE_BOX,SW_SHOW);
			    }
				//get next song
//				MApp_ZUI_ACT_DeletePlay();
                          MApp_ZUI_API_ShowWindow(HWND_KTV_LRC_SONGNAME,SW_HIDE);
                           if(IsOpenLrc)
				{
					MApp_ZUI_ACT_Endlrc();
				}
				MApp_ZUI_ACT_GetKTVOrderSongInfo(&pstOrderSong,0);
				MApp_ZUI_ACTPlayFile(pstOrderSong);
			}
		}
			return TRUE;
    }
    return FALSE;
}
static void MApp_ZUI_ACT_GetKTVMidTitleText(U8 *str)
{
	U16 u16ItemIdx = 0;

	for(u16ItemIdx=0;u16ItemIdx<UI_KTV_ORDERLIST_NUMBER;u16ItemIdx++)
	{
	    if(hwndCurFocus == _hwndListOrderMidlistItem[u16ItemIdx])
	    {
	        break;
	    }
	}

	if(u8MidDepth == 1)
	{
		switch(eDBFFileInfo)
		{
			case EN_SINGER_LIST:
				strcpy((char *)str,stMidTitleSingSortInfo.aClassName);
				break;
			case EN_SONG_REFER2_CHARACT:
				strcpy((char *)str,stMidTitleSongCountInfo.cSongCountDesc);
				break;
			case EN_SONG_REFER2_SORT:
				strcpy((char *)str,stMidTitleSongSortInfo.cSongSortName);
				break;
            case EN_SONG_REFER2_LANGUAGE:
				strcpy((char *)str,stMidTitleLangSortInfo.cLangType);
				break;
			default:
				break;
		}
	}
	else if(u8MidDepth == 2)
	{
		switch(eDBFFileInfo)
		{
			case EN_SONG_LIST:
				strcpy((char *)str,stMidTitleSingerListInfo.cSingerName);
				break;
			default:
				break;
		}
	}
}


LPTSTR MApp_ZUI_ACT_GetKTVDynamicText(HWND hwnd)
{
    // Marked it by coverity_304
    U16 u16TempID = Empty;

    switch(hwnd)
    {
    	case HWND_KTV_MAIN_MID_TITLE_TEXT:
		{
			hwndCurFocus = MApp_ZUI_API_GetFocus();
			if(u8MidDepth == 0)
			{
				switch(hwndCurFocus)
				{
					case HWND_KTV_MAIN_LEFT_ITEM0:
                    default:
						u16TempID = en_str_KTV_Left_Item1;
						break;
					case HWND_KTV_MAIN_LEFT_ITEM1:
						u16TempID = en_str_KTV_Left_Item2;
						break;
					case HWND_KTV_MAIN_LEFT_ITEM2:
						u16TempID = en_str_KTV_Left_Item3;
						break;
					case HWND_KTV_MAIN_LEFT_ITEM3:
						u16TempID = en_str_KTV_Left_Item4;
						break;
					case HWND_KTV_MAIN_LEFT_ITEM4:
						u16TempID = en_str_KTV_Left_Item6;
						break;
					case HWND_KTV_MAIN_LEFT_ITEM5:
						u16TempID = en_str_disk;
						break;
					case HWND_KTV_MAIN_LEFT_ITEM6:
						break;
					case HWND_KTV_MAIN_LEFT_ITEM7:
					case HWND_KTV_MAIN_LEFT_ITEM8:
					case HWND_KTV_MAIN_LEFT_ITEM9:
						break;
				}
				switch(eDBFFileInfo)
					{
					case EN_SINGER_SORT:
                        u16TempID = en_str_KTV_Left_Item1;
						break;
					case EN_CHARACTER_SORT:
                        u16TempID = en_str_KTV_Left_Item2;
						break;
					case EN_SONG_SORT:
                        u16TempID = en_str_KTV_Left_Item3;
						break;
					case EN_LANGUAGE_SORT:
					    u16TempID = en_str_KTV_Left_Item4;
					    break;
					case EN_SONG_BY_DISK:
					    u16TempID = en_str_disk;
						break;
					case EN_SONG_PINYIN:
						u16TempID = en_str_KTV_Left_Item6;
					    break;
					default:
						break;
					}
			}
			else
			{
				if(eDBFFileInfo == EN_SONG_PINYIN)
				{
					u16TempID = en_str_KTV_Left_Item6;
					break;
				}
				else if(eDBFFileInfo == EN_SONG_BY_DISK)
				{
					u16TempID = en_str_disk;
					break;
				}
				else
				{
	                U8 *pu8Data = NULL;
	                U8 u8Length;
				// U8 u8strLength;
				MApp_ZUI_ACT_GetKTVMidTitleText(pu8Data);
				u8Length = strlen((const char*)pu8Data);
                          _MApp_DMP_GB2Unicode(pu8Data, (U8 *)CHAR_BUFFER, u8Length+2);
				CHAR_BUFFER[u8Length] = 0x00;
				CHAR_BUFFER[u8Length + 1] = 0x00;
				return CHAR_BUFFER;
				}
			}
		}
			break;
		case HWND_KTV_MESSAGE_BOX_TEXT:
			{
                      hwndCurFocus = MApp_ZUI_API_GetFocus();
			 if(hwndCurFocus == HWND_KTV_BUTTON_CUT)
			 	{
				  u16TempID = en_str_KTV_button3;
			 	}
			 if((hwndCurFocus == HWND_KTV_BUTTON_ORIGACC)&&(bIsOrigal==TRUE))
			 	{
			 	   u16TempID = en_str_KTV_Acc;
			 	}
			 if((hwndCurFocus == HWND_KTV_BUTTON_ORIGACC)&&(bIsOrigal==FALSE))
			 	{
			 	   u16TempID = en_str_KTV_Orig;
			 	}
			 if(hwndCurFocus == HWND_KTV_BUTTON_SEL)
			 	{
			 	   u16TempID = en_str_KTV_noOrder;
			 	}
		    }
			break;

    	case HWND_KTV_MAIN_LEFT_ITEM0_TEXT:
			u16TempID = en_str_KTV_Left_Item1;
			break;
    	case HWND_KTV_MAIN_LEFT_ITEM1_TEXT:
			u16TempID = en_str_KTV_Left_Item2;
			break;
    	case HWND_KTV_MAIN_LEFT_ITEM2_TEXT:
			u16TempID = en_str_KTV_Left_Item3;
			break;
    	case HWND_KTV_MAIN_LEFT_ITEM3_TEXT:
			u16TempID = en_str_KTV_Left_Item4;
			break;
    	case HWND_KTV_MAIN_LEFT_ITEM4_TEXT:
			u16TempID = en_str_KTV_Left_Item6;
			break;
    	case HWND_KTV_MAIN_LEFT_ITEM5_TEXT:
                     u16TempID = en_str_KTV_Left_Item6;
			break;
	case HWND_KTV_MAIN_LEFT_ITEM6_TEXT:
			break;
    	case HWND_KTV_MAIN_LEFT_ITEM7_TEXT:
	   	case HWND_KTV_MAIN_LEFT_ITEM8_TEXT:
    	case HWND_KTV_MAIN_LEFT_ITEM9_TEXT:
			break;

    	case HWND_KTV_MAIN_MID_DISK_ITEM0_TEXT:
    	case HWND_KTV_MAIN_MID_DISK_ITEM1_TEXT:
    	case HWND_KTV_MAIN_MID_DISK_ITEM2_TEXT:
    	case HWND_KTV_MAIN_MID_DISK_ITEM3_TEXT:
    	case HWND_KTV_MAIN_MID_DISK_ITEM4_TEXT:
    	case HWND_KTV_MAIN_MID_DISK_ITEM5_TEXT:
    	case HWND_KTV_MAIN_MID_DISK_ITEM6_TEXT:
    	case HWND_KTV_MAIN_MID_DISK_ITEM7_TEXT:
    	case HWND_KTV_MAIN_MID_DISK_ITEM8_TEXT:
    	case HWND_KTV_MAIN_MID_DISK_ITEM9_TEXT:
		{
			U16 u16ItemIdx = 0;
			for(u16ItemIdx=0;u16ItemIdx<UI_KTV_ORDERLIST_NUMBER;u16ItemIdx++)
			{
			    if(hwnd == _hwndListOrderMidDiskTextListItem[u16ItemIdx])
			    {
			        break;
			    }
			}
	        U8 *pu8Data = NULL;
	        U8 u8Length = 0;

			if(eDBFFileInfo == EN_SONG_BY_DISK)
			{
				MEDIA_FILE_INFO MediaFileInfo;
				u8PageIdx = u8CurrentVideoItemsPageIdx-UI_KTV_ORDERLIST_NUMBER*(u8CurrentMidlistPageIdx-1);

				if (u16ItemIdx < u8PageIdx&& u8PageIdx > 0)
				{
				  MApp_ZUI_ACT_GetKTVVideoItemsInDiskInfo(&MediaFileInfo,u16ItemIdx+UI_KTV_ORDERLIST_NUMBER*(u8CurrentMidlistPageIdx-1)+1);
//				  printf("\n wzt at en_song_by_disk =%s",MediaFileInfo.cFileName);
				  u8Length = strlen(MediaFileInfo.cFileName);
				  pu8Data = (U8 *)MediaFileInfo.cFileName;

				  _MApp_DMP_GB2Unicode(pu8Data, (U8 *)CHAR_BUFFER, u8Length+2);
				  CHAR_BUFFER[u8Length] = 0x00;
				  CHAR_BUFFER[u8Length + 1] = 0x00;
				  return CHAR_BUFFER;
				  }
			  }
			  else
				  return NULL;
    		}
			return NULL;

    	case HWND_KTV_MAIN_MID_ITEM0_TEXT:
    	case HWND_KTV_MAIN_MID_ITEM1_TEXT:
    	case HWND_KTV_MAIN_MID_ITEM2_TEXT:
    	case HWND_KTV_MAIN_MID_ITEM3_TEXT:
    	case HWND_KTV_MAIN_MID_ITEM4_TEXT:
    	case HWND_KTV_MAIN_MID_ITEM5_TEXT:
    	case HWND_KTV_MAIN_MID_ITEM6_TEXT:
    	case HWND_KTV_MAIN_MID_ITEM7_TEXT:
    	case HWND_KTV_MAIN_MID_ITEM8_TEXT:
    	case HWND_KTV_MAIN_MID_ITEM9_TEXT:
		{
			U16 u16ItemIdx = 0;
			for(u16ItemIdx=0;u16ItemIdx<UI_KTV_ORDERLIST_NUMBER;u16ItemIdx++)
			{
			    if(hwnd == _hwndListOrderMidTextListItem[u16ItemIdx])
			    {
//					printf("Get HWND hwnd = %d\n",hwnd);
			        break;
			    }
			}
//			printf("Get Item Value u16ItemIdx = %d\n",u16ItemIdx);

#if 1  // switch eDBFFileInfo
	        U8 *pu8Data = NULL;
	        U8 u8Length = 0;

			switch(eDBFFileInfo)
			{
			case EN_SINGER_SORT:
				{
					SINGER_SORT_INFO SingerSortInfo;

                    u8PageIdx = u8CurrentSingerSortPageIdx-UI_KTV_ORDERLIST_NUMBER*(u8CurrentMidlistPageIdx-1);
					if (u16ItemIdx < u8PageIdx && u8PageIdx > 0)
					{
//						MApp_ZUI_ACT_GetKTVSingerSortInfo(&SingerSortInfo,u16ItemIdx+UI_KTV_ORDERLIST_NUMBER*(u8CurrentMidlistPageIdx-1)+1);
						MApp_ZUI_ACT_GetKTVSingerSortInfo(&SingerSortInfo,u16ItemIdx+1);

						u8Length = strlen(SingerSortInfo.aClassName);
		                pu8Data = (U8 *)SingerSortInfo.aClassName;

	                    _MApp_DMP_GB2Unicode(pu8Data, (U8 *)CHAR_BUFFER, u8Length+2);
						CHAR_BUFFER[u8Length] = 0x00;
						CHAR_BUFFER[u8Length + 1] = 0x00;
						return CHAR_BUFFER;
					}
					else
						return NULL;
				}
				break;
			case EN_SINGER_LIST:
				{
					SINGER_LIST_INFO SingerListInfo;

                    u8PageIdx = u8CurrentSingerlistPageIdx-UI_KTV_ORDERLIST_NUMBER*(u8CurrentMidlistPageIdx-1);
					if (u16ItemIdx < u8PageIdx&& u8PageIdx > 0)
					{
//						MApp_ZUI_ACT_GetKTVSingerListInfo(&SingerListInfo,u16ItemIdx+UI_KTV_ORDERLIST_NUMBER*(u8CurrentMidlistPageIdx-1)+1);
						MApp_ZUI_ACT_GetKTVSingerListInfo(&SingerListInfo,u16ItemIdx+1);

						u8Length = strlen(SingerListInfo.cSingerName);
		                pu8Data = (U8 *)SingerListInfo.cSingerName;

	                    _MApp_DMP_GB2Unicode(pu8Data, (U8 *)CHAR_BUFFER, u8Length+2);
						CHAR_BUFFER[u8Length] = 0x00;
						CHAR_BUFFER[u8Length + 1] = 0x00;
						return CHAR_BUFFER;
					}
					else
						return NULL;
				}
				break;
			case EN_SONG_LIST:
				{
					SONG_LIST_INFO SongListInfo;

                                 u8PageIdx = u8CurrentSonglistPageIdx-UI_KTV_ORDERLIST_NUMBER*(u8CurrentMidlistPageIdx-1);
					if (u16ItemIdx < u8PageIdx&& u8PageIdx > 0)
					{
						memset( &SongListInfo,0,sizeof(SONG_LIST_INFO) );
//						MApp_ZUI_ACT_GetKTVSongListInfo(&SongListInfo,u16ItemIdx+UI_KTV_ORDERLIST_NUMBER*(u8CurrentMidlistPageIdx-1)+1);
						MApp_ZUI_ACT_GetKTVSongListInfo(&SongListInfo,u16ItemIdx+1);

						u8Length = strlen(SongListInfo.cSongName);
		                pu8Data = (U8 *)SongListInfo.cSongName;

	                    _MApp_DMP_GB2Unicode(pu8Data, (U8 *)CHAR_BUFFER, u8Length+2);
						CHAR_BUFFER[u8Length] = 0x00;
						CHAR_BUFFER[u8Length + 1] = 0x00;
						return CHAR_BUFFER;
					}
					else
						return NULL;
				}
				break;
              case EN_CHARACTER_SORT:
                {
					SONG_COUNT_INFO SongCountInfo;
                    u8PageIdx = u8CurrentSongCoutPageIdx-UI_KTV_ORDERLIST_NUMBER*(u8CurrentMidlistPageIdx-1);

					if (u16ItemIdx < u8PageIdx&& u8PageIdx > 0)
					{
//						MApp_ZUI_ACT_GetKTVSongCountInfo(&SongCountInfo,u16ItemIdx+UI_KTV_ORDERLIST_NUMBER*(u8CurrentMidlistPageIdx-1)+1);
						MApp_ZUI_ACT_GetKTVSongCountInfo(&SongCountInfo,u16ItemIdx+1);

						u8Length = strlen(SongCountInfo.cSongCountDesc);
		                pu8Data = (U8 *)SongCountInfo.cSongCountDesc;

	                    _MApp_DMP_GB2Unicode(pu8Data, (U8 *)CHAR_BUFFER, u8Length+2);
						CHAR_BUFFER[u8Length] = 0x00;
						CHAR_BUFFER[u8Length + 1] = 0x00;
						return CHAR_BUFFER;
					}
					else
						return NULL;
				  }
                            break;
				#if 1
				case EN_SONG_PINYIN:
					{
					SONG_LIST_INFO SongListInfo;
					u8PageIdx = u8CurrentLangSortPageIdx-UI_KTV_PINYINORDER_NUMBER*(u8CurrentMidlistPageIdx-1);
					if(u8CurrentLangSortPageIdx == 0 && u16ItemIdx == 2)
					{
						u16TempID = en_str_Usb_Nofile_Text;
						return MApp_ZUI_API_GetString(u16TempID);
					}

//					printf("\nu16ItemIdx = %d\nu8PageIdx=%d\nu8CurrentLangSortPageIdx=%d\n",u16ItemIdx,u8PageIdx,u8CurrentLangSortPageIdx);
					if ((u16ItemIdx - 1) <= u8PageIdx&& u8PageIdx > 0)
					{
						memset( &SongListInfo,0,sizeof(SONG_LIST_INFO) );
//						MApp_ZUI_ACT_GetKTVSongListInfo(&SongListInfo,((u8CurrentMidlistPageIdx-1)*UI_KTV_PINYINORDER_NUMBER+u16ItemIdx-1));
						MApp_ZUI_ACT_GetKTVSongListInfo(&SongListInfo,u16ItemIdx-1);

						u8Length = strlen(SongListInfo.cSongName);
		                pu8Data = (U8 *)SongListInfo.cSongName;
//						printf("****pu8Data = %s****\n",pu8Data);

	                    _MApp_DMP_GB2Unicode(pu8Data, (U8 *)CHAR_BUFFER, u8Length+2);
						CHAR_BUFFER[u8Length] = 0x00;
						CHAR_BUFFER[u8Length + 1] = 0x00;
						return CHAR_BUFFER;
					}
					else
						return NULL;
				}
				break;
				#endif

                    case EN_SONG_REFER2_CHARACT:
                        {

                            SONG_LIST_INFO SongListInfo;
                            u8PageIdx = u8CurrentSonglistPageIdx-UI_KTV_ORDERLIST_NUMBER*(u8CurrentMidlistPageIdx-1);
                            if (u16ItemIdx < u8PageIdx&& u8PageIdx > 0)
                            {
								memset( &SongListInfo,0,sizeof(SONG_LIST_INFO) );
//                                MApp_ZUI_ACT_GetKTVSongListInfo(&SongListInfo,u16ItemIdx+UI_KTV_ORDERLIST_NUMBER*(u8CurrentMidlistPageIdx-1)+1);
                                MApp_ZUI_ACT_GetKTVSongListInfo(&SongListInfo,u16ItemIdx+1);
                                u8Length = strlen(SongListInfo.cSongName);
                                pu8Data = (U8 *)SongListInfo.cSongName;

                                _MApp_DMP_GB2Unicode(pu8Data, (U8 *)CHAR_BUFFER, u8Length+2);
                                CHAR_BUFFER[u8Length] = 0x00;
                                CHAR_BUFFER[u8Length + 1] = 0x00;
                                return CHAR_BUFFER;
                            }
                            else
                                return NULL;
                            }
                              break;

                        case EN_SONG_SORT:
                            {
					SONG_SORT_INFO SongSortInfo;
                                 u8PageIdx = u8CurrentSongSortPageIdx-UI_KTV_ORDERLIST_NUMBER*(u8CurrentMidlistPageIdx-1);
					if (u16ItemIdx < u8PageIdx&& u8PageIdx > 0)
					{
						//MApp_ZUI_ACT_GetKTVSongSortInfo(&SongSortInfo,u16ItemIdx+1);
                                        //if(u8CurrentMidlistPageIdx>1)
                                        //{
                                            //printf("\nwzt u8CurrentMidlistPageIdx=%d\n",u8CurrentMidlistPageIdx);
                                            //u8PageIdx = u8CurrentSongSortPageIdx-UI_KTV_ORDERLIST_NUMBER*(u8CurrentMidlistPageIdx-1);
//                                            printf("nwzt u8PageIdx=%d\n",u8PageIdx);
                                            //if(u16ItemIdx<u8PageIdx)
//                                            MApp_ZUI_ACT_GetKTVSongSortInfo(&SongSortInfo,(u16ItemIdx+UI_KTV_ORDERLIST_NUMBER*(u8CurrentMidlistPageIdx-1)+1));
						MApp_ZUI_ACT_GetKTVSongSortInfo(&SongSortInfo,(u16ItemIdx+1));
                                            //else
                                            //    return NULL;
                                        //}
                                        u8Length = strlen(SongSortInfo.cSongSortName);
		                           pu8Data = (U8 *)SongSortInfo.cSongSortName;

	                                  _MApp_DMP_GB2Unicode(pu8Data, (U8 *)CHAR_BUFFER, u8Length+2);
						CHAR_BUFFER[u8Length] = 0x00;
						CHAR_BUFFER[u8Length + 1] = 0x00;
						return CHAR_BUFFER;
					}
					else
						return NULL;
				  }
                                break;
                        case EN_SONG_REFER2_LANGUAGE:
                        case EN_SONG_REFER2_SORT:
                            {
                            SONG_LIST_INFO SongListInfo;
                            u8PageIdx = u8CurrentSonglistPageIdx-UI_KTV_ORDERLIST_NUMBER*(u8CurrentMidlistPageIdx-1);
                            if (u16ItemIdx < u8PageIdx&& u8PageIdx > 0)
                            {
								memset( &SongListInfo,0,sizeof(SONG_LIST_INFO) );
//                                MApp_ZUI_ACT_GetKTVSongListInfo(&SongListInfo,u16ItemIdx+UI_KTV_ORDERLIST_NUMBER*(u8CurrentMidlistPageIdx-1)+1);
                                MApp_ZUI_ACT_GetKTVSongListInfo(&SongListInfo,u16ItemIdx+1);
                                u8Length = strlen(SongListInfo.cSongName);
                                pu8Data = (U8 *)SongListInfo.cSongName;

                                _MApp_DMP_GB2Unicode(pu8Data, (U8 *)CHAR_BUFFER, u8Length+2);
                                CHAR_BUFFER[u8Length] = 0x00;
                                CHAR_BUFFER[u8Length + 1] = 0x00;
                                return CHAR_BUFFER;
                            }
                            else
                                return NULL;
                            }
                            break;

                            case EN_LANGUAGE_SORT:
                              {
                                  LANG_SORT_INFO LangSortInfo;

                                  u8PageIdx = u8CurrentLangSortPageIdx-UI_KTV_ORDERLIST_NUMBER*(u8CurrentMidlistPageIdx-1);
                                  if (u16ItemIdx < u8PageIdx&& u8PageIdx > 0)
                                  {
//                                      MApp_ZUI_ACT_GetKTVLanguageSortInfo(&LangSortInfo,u16ItemIdx+UI_KTV_ORDERLIST_NUMBER*(u8CurrentMidlistPageIdx-1)+1);
                                      MApp_ZUI_ACT_GetKTVLanguageSortInfo(&LangSortInfo,u16ItemIdx+1);

                                      u8Length = strlen(LangSortInfo.cLangType);
                                      pu8Data = (U8 *)LangSortInfo.cLangType;

                                      _MApp_DMP_GB2Unicode(pu8Data, (U8 *)CHAR_BUFFER, u8Length+2);
                                     CHAR_BUFFER[u8Length] = 0x00;
                                     CHAR_BUFFER[u8Length + 1] = 0x00;
                                      return CHAR_BUFFER;
                                  }
                                  else
                                      return NULL;
                                }
                              break;

                              case EN_SONG_BY_DISK:
                              {
                                  MEDIA_FILE_INFO MediaFileInfo;
                                  u8PageIdx = u8CurrentVideoItemsPageIdx-UI_KTV_ORDERLIST_NUMBER*(u8CurrentMidlistPageIdx-1);
//                                  printf("\n wzt at dynamic text =%d",u8PageIdx);

                                  if (u16ItemIdx < u8PageIdx&& u8PageIdx > 0)
                                  {
                                   //while( !pRecordSet->IsEOF(pRecordSet) )
                                    //{
                                    //printf("\n wzt 1");
                                    //U8 nMediaType = pRecordSet->GetFieldInt_ByFieldName2(pRecordSet,"MEDIATYPE");
                                    //printf("\n wzt 2");
                                    //U8 aFileName[256]={0};//U8 aClassName[41]={0};
                                    //U32 Len = sizeof(aFileName);
                                    //pRecordSet->GetFieldStr_ByFieldName(pRecordSet,"FILENAME",aFileName,Len);
                                    //printf( "\nMediaType=%ld,aFileName=%s\n",nMediaType,aFileName );

                                    //pRecordSet->MoveNext(pRecordSet);
                                    MApp_ZUI_ACT_GetKTVVideoItemsInDiskInfo(&MediaFileInfo,u16ItemIdx+UI_KTV_ORDERLIST_NUMBER*(u8CurrentMidlistPageIdx-1)+1);
//                                    printf("\n wzt at en_song_by_disk =%s",MediaFileInfo.cFileName);
                                    u8Length = strlen(MediaFileInfo.cFileName);
                                    pu8Data = (U8 *)MediaFileInfo.cFileName;

                                    _MApp_DMP_GB2Unicode(pu8Data, (U8 *)CHAR_BUFFER, u8Length+2);
                                    CHAR_BUFFER[u8Length] = 0x00;
                                    CHAR_BUFFER[u8Length + 1] = 0x00;
                                    return CHAR_BUFFER;
                                    //}
                                }
                                else
                                    return NULL;
                                }
                                break;
			default:
				return NULL;
			}
#endif	// end of switch eDBFFileInfo
    	}
			return NULL;

		case HWND_KTV_MAIN_MID_SONG_ITEM0_TEXT1:
		case HWND_KTV_MAIN_MID_SONG_ITEM1_TEXT1:
		case HWND_KTV_MAIN_MID_SONG_ITEM2_TEXT1:
		case HWND_KTV_MAIN_MID_SONG_ITEM3_TEXT1:
		case HWND_KTV_MAIN_MID_SONG_ITEM4_TEXT1:
		case HWND_KTV_MAIN_MID_SONG_ITEM5_TEXT1:
		case HWND_KTV_MAIN_MID_SONG_ITEM6_TEXT1:
		case HWND_KTV_MAIN_MID_SONG_ITEM7_TEXT1:
		case HWND_KTV_MAIN_MID_SONG_ITEM8_TEXT1:
		case HWND_KTV_MAIN_MID_SONG_ITEM9_TEXT1:
		{
			U16 u16ItemIdx = 0;
			for(u16ItemIdx=0;u16ItemIdx<UI_KTV_ORDERLIST_NUMBER;u16ItemIdx++)
			{
				if(hwnd == _hwndListOrderMidSongText1ListItem[u16ItemIdx])
				{
//					printf("Get HWND hwnd = %d\n",hwnd);
					break;
				}
			}
//			printf("Get Item Value u16ItemIdx = %d\n",u16ItemIdx);

#if 1  // switch eDBFFileInfo
			U8 *pu8Data = NULL;
			U8 u8Length = 0;

			switch(eDBFFileInfo)
			{
				case EN_SONG_PINYIN:
				{
					SONG_LIST_INFO SongListInfo;
					u8PageIdx = u8CurrentLangSortPageIdx-UI_KTV_PINYINORDER_NUMBER*(u8CurrentMidlistPageIdx-1);
					if(u8CurrentLangSortPageIdx == 0 && u16ItemIdx == 2)
					{
						u16TempID = en_str_Usb_Nofile_Text;
						return MApp_ZUI_API_GetString(u16TempID);
					}

//					printf("\nu16ItemIdx = %d\nu8PageIdx=%d\nu8CurrentLangSortPageIdx=%d\n",u16ItemIdx,u8PageIdx,u8CurrentLangSortPageIdx);
					if ((u16ItemIdx - 1) <= u8PageIdx&& u8PageIdx > 0)
					{
						memset( &SongListInfo,0,sizeof(SONG_LIST_INFO) );
//						MApp_ZUI_ACT_GetKTVSongListInfo(&SongListInfo,((u8CurrentMidlistPageIdx-1)*UI_KTV_PINYINORDER_NUMBER+u16ItemIdx-1));
						MApp_ZUI_ACT_GetKTVSongListInfo(&SongListInfo,u16ItemIdx-1);

						u8Length = strlen(SongListInfo.cSongName);
						pu8Data = (U8 *)SongListInfo.cSongName;
//						printf("****pu8Data = %s****\n",pu8Data);

						_MApp_DMP_GB2Unicode(pu8Data, (U8 *)CHAR_BUFFER, u8Length+2);
						CHAR_BUFFER[u8Length] = 0x00;
						CHAR_BUFFER[u8Length + 1] = 0x00;
						return CHAR_BUFFER;
					}
					else
						return NULL;
				}
				break;

			case EN_SONG_REFER2_CHARACT:
				{

					SONG_LIST_INFO SongListInfo;
					u8PageIdx = u8CurrentSonglistPageIdx-UI_KTV_ORDERLIST_NUMBER*(u8CurrentMidlistPageIdx-1);
					if (u16ItemIdx < u8PageIdx&& u8PageIdx > 0)
					{
						memset( &SongListInfo,0,sizeof(SONG_LIST_INFO) );
//								  MApp_ZUI_ACT_GetKTVSongListInfo(&SongListInfo,u16ItemIdx+UI_KTV_ORDERLIST_NUMBER*(u8CurrentMidlistPageIdx-1)+1);
						MApp_ZUI_ACT_GetKTVSongListInfo(&SongListInfo,u16ItemIdx+1);
						u8Length = strlen(SongListInfo.cSongName);
						pu8Data = (U8 *)SongListInfo.cSongName;

						_MApp_DMP_GB2Unicode(pu8Data, (U8 *)CHAR_BUFFER, u8Length+2);
						CHAR_BUFFER[u8Length] = 0x00;
						CHAR_BUFFER[u8Length + 1] = 0x00;
						return CHAR_BUFFER;
					}
					else
						return NULL;
					}
					  break;

				case EN_SONG_REFER2_LANGUAGE:
				case EN_SONG_REFER2_SORT:
					{
					SONG_LIST_INFO SongListInfo;
					u8PageIdx = u8CurrentSonglistPageIdx-UI_KTV_ORDERLIST_NUMBER*(u8CurrentMidlistPageIdx-1);
					if (u16ItemIdx < u8PageIdx&& u8PageIdx > 0)
					{
						memset( &SongListInfo,0,sizeof(SONG_LIST_INFO) );
//								  MApp_ZUI_ACT_GetKTVSongListInfo(&SongListInfo,u16ItemIdx+UI_KTV_ORDERLIST_NUMBER*(u8CurrentMidlistPageIdx-1)+1);
						MApp_ZUI_ACT_GetKTVSongListInfo(&SongListInfo,u16ItemIdx+1);
						u8Length = strlen(SongListInfo.cSongName);
						pu8Data = (U8 *)SongListInfo.cSongName;

						_MApp_DMP_GB2Unicode(pu8Data, (U8 *)CHAR_BUFFER, u8Length+2);
						CHAR_BUFFER[u8Length] = 0x00;
						CHAR_BUFFER[u8Length + 1] = 0x00;
						return CHAR_BUFFER;
					}
					else
						return NULL;
					}
					break;

			default:
				return NULL;
			}
#endif	// end of switch eDBFFileInfo
		}
			return NULL;

		case HWND_KTV_MAIN_MID_SONG_ITEM0_TEXT2:
		case HWND_KTV_MAIN_MID_SONG_ITEM1_TEXT2:
		case HWND_KTV_MAIN_MID_SONG_ITEM2_TEXT2:
		case HWND_KTV_MAIN_MID_SONG_ITEM3_TEXT2:
		case HWND_KTV_MAIN_MID_SONG_ITEM4_TEXT2:
		case HWND_KTV_MAIN_MID_SONG_ITEM5_TEXT2:
		case HWND_KTV_MAIN_MID_SONG_ITEM6_TEXT2:
		case HWND_KTV_MAIN_MID_SONG_ITEM7_TEXT2:
		case HWND_KTV_MAIN_MID_SONG_ITEM8_TEXT2:
		case HWND_KTV_MAIN_MID_SONG_ITEM9_TEXT2:
		{
			U16 u16ItemIdx = 0;
			for(u16ItemIdx=0;u16ItemIdx<UI_KTV_ORDERLIST_NUMBER;u16ItemIdx++)
			{
				if(hwnd == _hwndListOrderMidSongText2ListItem[u16ItemIdx])
				{
//					printf("Get HWND hwnd = %d\n",hwnd);
					break;
				}
			}
//			printf("Get Item Value u16ItemIdx = %d\n",u16ItemIdx);

#if 1  // switch eDBFFileInfo
			U8 *pu8Data = NULL;
			U8 u8Length = 0;

			switch(eDBFFileInfo)
			{
				case EN_SONG_PINYIN:
				{

					u8PageIdx = u8CurrentLangSortPageIdx-UI_KTV_PINYINORDER_NUMBER*(u8CurrentMidlistPageIdx-1);
					if(u8CurrentLangSortPageIdx == 0 && u16ItemIdx == 2)
					{
//						u16TempID = en_str_Usb_Nofile_Text;
//						return MApp_ZUI_API_GetString(u16TempID);
						break;
					}

//					printf("\nu16ItemIdx = %d\nu8PageIdx=%d\nu8CurrentLangSortPageIdx=%d\n",u16ItemIdx,u8PageIdx,u8CurrentLangSortPageIdx);
					if ((u16ItemIdx - 1) <= u8PageIdx&& u8PageIdx > 0)
					{
						SONG_LIST_INFO SongListInfo;
						memset( &SongListInfo,0,sizeof(SONG_LIST_INFO) );
//						MApp_ZUI_ACT_GetKTVSongListInfo(&SongListInfo,((u8CurrentMidlistPageIdx-1)*UI_KTV_PINYINORDER_NUMBER+u16ItemIdx-1));
						MApp_ZUI_ACT_GetKTVSongListInfo(&SongListInfo,u16ItemIdx-1);

						u8Length = strlen(SongListInfo.cSingerName);
						pu8Data = (U8 *)SongListInfo.cSingerName;
//						printf("****pu8Data = %s****\n",pu8Data);

						_MApp_DMP_GB2Unicode(pu8Data, (U8 *)CHAR_BUFFER, u8Length+2);
						CHAR_BUFFER[u8Length] = 0x00;
						CHAR_BUFFER[u8Length + 1] = 0x00;
						return CHAR_BUFFER;
					}
					else
						return NULL;
				}
				break;

			case EN_SONG_REFER2_CHARACT:
			case EN_SONG_REFER2_LANGUAGE:
			case EN_SONG_REFER2_SORT:
				{

					SONG_LIST_INFO SongListInfo;
					u8PageIdx = u8CurrentSonglistPageIdx-UI_KTV_ORDERLIST_NUMBER*(u8CurrentMidlistPageIdx-1);
					if (u16ItemIdx < u8PageIdx&& u8PageIdx > 0)
					{
						memset( &SongListInfo,0,sizeof(SONG_LIST_INFO) );
//								  MApp_ZUI_ACT_GetKTVSongListInfo(&SongListInfo,u16ItemIdx+UI_KTV_ORDERLIST_NUMBER*(u8CurrentMidlistPageIdx-1)+1);
						MApp_ZUI_ACT_GetKTVSongListInfo(&SongListInfo,u16ItemIdx+1);
						u8Length = strlen(SongListInfo.cSingerName);
						pu8Data = (U8 *)SongListInfo.cSingerName;

						_MApp_DMP_GB2Unicode(pu8Data, (U8 *)CHAR_BUFFER, u8Length+2);
						CHAR_BUFFER[u8Length] = 0x00;
						CHAR_BUFFER[u8Length + 1] = 0x00;
						return CHAR_BUFFER;
					}
					else
						return NULL;
					}
					  break;
			default:
				return NULL;
			}
#endif	// end of switch eDBFFileInfo
		}
			return NULL;


    	case HWND_KTV_MAIN_RIGHT_ITEM0_TEXT:
		case HWND_KTV_MAIN_RIGHT_ITEM1_TEXT:
		case HWND_KTV_MAIN_RIGHT_ITEM2_TEXT:
		case HWND_KTV_MAIN_RIGHT_ITEM3_TEXT:
		case HWND_KTV_MAIN_RIGHT_ITEM4_TEXT:
		case HWND_KTV_MAIN_RIGHT_ITEM5_TEXT:
		case HWND_KTV_MAIN_RIGHT_ITEM6_TEXT:
		case HWND_KTV_MAIN_RIGHT_ITEM7_TEXT:
		case HWND_KTV_MAIN_RIGHT_ITEM8_TEXT:
		case HWND_KTV_MAIN_RIGHT_ITEM9_TEXT:
#if 1
		{
			U16 u16ItemIdx = 0;

			for(u16ItemIdx=0;u16ItemIdx<UI_KTV_ORDERLIST_NUMBER;u16ItemIdx++)
			{
				if(hwnd == _hwndListOrderRightTextListItem[u16ItemIdx])
				{
					break;
				}
			}

			u8RightPageIdx = u8CurrentOrderlistPageIdx-UI_KTV_ORDERLIST_NUMBER*(u8CurrentRightlistPageIdx-1);
			if(u8RightPageIdx > 0 && u8RightPageIdx > u16ItemIdx)
			{
				TOrderInfo pstOrderInfo;
				U8 *pu8Data = NULL;
				U8 u8Length = 0;

				memset(&pstOrderInfo,0,sizeof(TOrderInfo));

				MApp_ZUI_ACT_GetKTVOrderSongInfo(&pstOrderInfo,u16ItemIdx+(UI_KTV_ORDERLIST_NUMBER*(u8CurrentRightlistPageIdx-1)));

				KTVACT_DBG(printf("\n222222KLM_GetNextOrder2222222\n%s",pstOrderInfo.szFilePath););

				u8Length = strlen(pstOrderInfo.szSongName);
				pu8Data = (U8 *)pstOrderInfo.szSongName;

				_MApp_DMP_GB2Unicode(pu8Data, (U8 *)CHAR_BUFFER, u8Length+2);
				CHAR_BUFFER[u8Length] = 0x00;
				CHAR_BUFFER[u8Length + 1] = 0x00;
				return CHAR_BUFFER;
			}
                    else
                        return NULL;
		}
			return NULL;
#endif

       case HWND_KTV_SEL_BANNER_ITEM0_TEXT:
       case HWND_KTV_SEL_BANNER_ITEM1_TEXT:
       case HWND_KTV_SEL_BANNER_ITEM2_TEXT:
       case HWND_KTV_SEL_BANNER_ITEM3_TEXT:
       case HWND_KTV_SEL_BANNER_ITEM4_TEXT:
       case HWND_KTV_SEL_BANNER_ITEM5_TEXT:
            {
                U16 u16ItemIdx = 0;

                for(u16ItemIdx=0;u16ItemIdx<UI_KTV_SELECTEDSONGLIST_NUMBER;u16ItemIdx++)
                {
                    if(hwnd == _hwndListSelectedSongListItem[u16ItemIdx])
                    {
//                        printf("Get HWND hwnd = %d\n",hwnd);
                        break;
                    }
                }

                if(u16ItemIdx<KLM_GetOrderNum())
                    {
                    U8 *pu8Data = NULL;
                    U8 u8Length = 0;
                    TOrderInfo pstOrderInfo;
                    u8PageIdx = KLM_GetOrderNum()-UI_KTV_SELECTEDSONGLIST_NUMBER*(u8CurrentSelectedSongListPageIdx-1);
                    //MApp_ZUI_ACT_GetKTVOrderSongInfo(&pstOrderInfo,u16ItemIdx);
                    if(u16ItemIdx<u8PageIdx&&u8PageIdx>0)
                        {
                    //        u8PageIdx = KLM_GetOrderNum()-UI_KTV_SELECTEDSONGLIST_NUMBER*(u8CurrentSelectedSongListPageIdx-1);
                    //        if(u16ItemIdx<u8PageIdx)
                                MApp_ZUI_ACT_GetKTVOrderSongInfo(&pstOrderInfo,u16ItemIdx+(UI_KTV_SELECTEDSONGLIST_NUMBER*(u8CurrentSelectedSongListPageIdx-1)));
                     //       else
                     //           return NULL;
                     //   }
                        u8Length = strlen(pstOrderInfo.szSongName);
                        pu8Data = (U8 *)pstOrderInfo.szSongName;

                     _MApp_DMP_GB2Unicode(pu8Data, (U8 *)CHAR_BUFFER, u8Length+2);
                    CHAR_BUFFER[u8Length] = 0x00;
                    CHAR_BUFFER[u8Length + 1] = 0x00;
                     return CHAR_BUFFER;
                        }
                        else
                         return NULL;
                    }
                    else
                        return NULL;
                    //int i=0;
                    //THANDLE Handle = 0;
                    //for( i=0; i<KLM_GetOrderNum(); i++ )
                    //{
                    //    TOrderInfo stOrderInfo;
                    //    memset( &stOrderInfo,0,sizeof(TOrderInfo) );
                    //    printf( "======Handle=%d\n",Handle );
                    //    BOOLEAN bRet = KLM_GetNextOrder(&Handle,&stOrderInfo);
                    //    if( bRet )
                    //    {
                    //        printf( "stOrderInfo.szFilePath=%s\n",stOrderInfo.szFilePath );
                    //        printf( "stOrderInfo.szSongName=%s\n",stOrderInfo.szSongName );
                    //    }
                    //    else
                    //    {
                            //if( TBEHIND_LAST_POSITION==Handle )
                     //           printf( "Query List End,finish!" );
                     //   }
                    //}
                break;
            }

    	case HWND_KTV_LRC_LINE1_BOTTOM:
		case HWND_KTV_LRC_LINE1_UP:
		  {
                U8 *pu8Datalrc = NULL;
	            U8 u8Lengthlrc = 0;
				if(!bFirstShowLrc)
				  {
					pu8Datalrc=( U8 *)LyricLien.szLyric;
					u8Lengthlrc=(U8)strlen((const char *)LyricLien.szLyric);
	            	_MApp_DMP_GB2Unicode(pu8Datalrc, (U8 *)CHAR_BUFFER, u8Lengthlrc+2);
					CHAR_BUFFER[u8Lengthlrc] = 0x00;
					CHAR_BUFFER[u8Lengthlrc+1] = 0x00;
					return CHAR_BUFFER;
				  }
			    else
					return NULL;
		  }
		break;

		case HWND_KTV_LRC_LINE2_BOTTOM:
		case HWND_KTV_LRC_LINE2_UP:
		  {
                   U8 *pu8Datalrc = NULL;
	            U8 u8Lengthlrc = 0;
			if(!bFirstShowLrc)
			{
				pu8Datalrc=( U8 *)LyricLien2.szLyric;
				u8Lengthlrc=(U8)LyricLien2.wLyricLen;
	            	      _MApp_DMP_GB2Unicode(pu8Datalrc, (U8 *)CHAR_BUFFER, u8Lengthlrc+2);
				CHAR_BUFFER[u8Lengthlrc] = 0x00;
				CHAR_BUFFER[u8Lengthlrc+1] = 0x00;
				return CHAR_BUFFER;
					//printf("\n>>>>in the case2 %d=>>>>\n",line2_lrc);
			}
			else
			    return NULL;

		  }
		break;
		case HWND_KTV_LRC_SONGNAME:
		  {
		  	    U8 *pu8Datalrc = NULL;
	            U8 u8Lengthlrc = 0;
				U16 curStringLen = 0;
				//////////
				MApp_ZUI_API_Strcpy(&CHAR_BUFFER[0], MApp_ZUI_API_GetString(en_str_KTV_songname));
                curStringLen = MApp_ZUI_API_Strlen(CHAR_BUFFER);
               // CHAR_BUFFER[curStringLen] = CHAR_SPACE;
				pu8Datalrc=( U8 *)aLabel_TI;
				u8Lengthlrc=(U8)strlen((const char *)aLabel_TI);
				_MApp_DMP_GB2Unicode(pu8Datalrc, (U8 *)&CHAR_BUFFER[curStringLen], curStringLen+u8Lengthlrc+2);
				CHAR_BUFFER[curStringLen+u8Lengthlrc] = 0x00;
				CHAR_BUFFER[curStringLen+u8Lengthlrc+1] = 0x00;
				return CHAR_BUFFER;
		  }
		break;
		case HWND_KTV_LRC_SINGERNAME:
		  {
		     U8 *pu8Datalrc = NULL;
	            U8 u8Lengthlrc = 0;
			U16 curStringLen = 0;
				//////////
			MApp_ZUI_API_Strcpy(&CHAR_BUFFER[0], MApp_ZUI_API_GetString(en_str_KTV_singername));
                    curStringLen = MApp_ZUI_API_Strlen(CHAR_BUFFER);
                   // CHAR_BUFFER[curStringLen] = CHAR_SPACE;
			pu8Datalrc=( U8 *)aLabel_AR;
			u8Lengthlrc=(U8)strlen((const char *)aLabel_AR);
			_MApp_DMP_GB2Unicode(pu8Datalrc, (U8 *)&CHAR_BUFFER[curStringLen], curStringLen+u8Lengthlrc+2);
			CHAR_BUFFER[curStringLen+u8Lengthlrc] = 0x00;
			CHAR_BUFFER[curStringLen+u8Lengthlrc+1] = 0x00;
			return CHAR_BUFFER;
		  }
		break;
		case HWND_KTV_LRC_HIDE:
		  {
                   U8 *pu8DataHide = NULL;
	            U8 u8LengthHide = 0;
			pu8DataHide  = g_u8lrcString;
			u8LengthHide=(U8)strlen((const char *)pu8DataHide);
			//_MApp_DMP_GB2Unicode(pu8DataHide, (U8 *)CHAR_BUFFER, u8LengthHide+2);
               	memcpy(CHAR_BUFFER,pu8DataHide,u8LengthHide+2);
			CHAR_BUFFER[u8LengthHide] = 0x00;
			CHAR_BUFFER[u8LengthHide+1] = 0x00;
			return CHAR_BUFFER; //unicode
		  }
		break;
		case HWND_KTV_MAIN_LEFT_PAGE_NUM_CURRENT:
			return MApp_ZUI_API_GetU16String((U16)(1));
		case HWND_KTV_MAIN_LEFT_PAGE_NUM_TOTAL:
			return MApp_ZUI_API_GetU16String((U16)(1));
		case HWND_KTV_MAIN_MID_PAGE_NUM_CURRENT:
			return MApp_ZUI_API_GetU16String((U16)(u8CurrentMidlistPageIdx));
		case HWND_KTV_MAIN_MID_PAGE_NUM_TOTAL:
			return MApp_ZUI_API_GetU16String((U16)(u8CurrentMidlistTotalPage));
		case HWND_KTV_MAIN_RIGHT_PAGE_NUM_CURRENT:
			return MApp_ZUI_API_GetU16String((U16)(u8CurrentRightlistPageIdx));
		case HWND_KTV_MAIN_RIGHT_PAGE_NUM_TOTAL:
			return MApp_ZUI_API_GetU16String((U16)(u8CurrentRightlistTotalPage));
		case HWND_KTV_SET_ACC_VOLUME_TEXT:
                   return MApp_ZUI_API_GetU16String(stGenSetting.g_SoundSetting.BGVolume);
		case HWND_KTV_SET_MICORPHONE_VOLUME_TEXT:
                   return MApp_ZUI_API_GetU16String(stGenSetting.g_SoundSetting.KTVMicVolume);
		case HWND_KTV_SET_MIX_VOLUME_TEXT:
                     return MApp_ZUI_API_GetU16String(stGenSetting.g_SoundSetting.MixVolume);
              case HWND_KTV_SEL_BANNER_PAGENUM_CURRENT:
                     return MApp_ZUI_API_GetU16String((U16)(u8CurrentSelectedSongListPageIdx));//return MApp_ZUI_API_GetU16String((U16)(u8CurrentSelectedSongListPageIdx));
               case HWND_KTV_SEL_BANNER_PAGENUM_TOTAL:
                    return MApp_ZUI_API_GetU16String((U16)(u8CurrentSelectedSongListTotalPage));//return MApp_ZUI_API_GetU16String((U16)(u8CurrentSelectedSongListTotalPage));
		case HWND_KTV_ERROR_INFO_TEXT:
		{
			switch(enKTVErrorInfo)
			{
				case EN_KTV_ERROR_PLAY_ALL:
					u16TempID = en_str_KTV_Error_PlayAll;
					break;
				case EN_KTV_ERROR_LAST_SONG:
					u16TempID = en_str_KTV_Error_LastSong;
					break;
				case EN_KTV_ERROR_NO_FILE:
					u16TempID = en_str_DMP_No_File_WARNING;
					break;
				case EN_KTV_ERROR_MORE_20_SONGNUM:
					u16TempID = en_str_KTV_Error_MostSong;
					break;
				case EN_KTV_ERROR_UNSUPPORT_FILE:
					u16TempID = en_str_file_error_and_goto_next;
					break;
				case EN_KTV_ERROR_INSERT_USB:
				default:
					u16TempID = en_str_Navigation_Tips_Nodevice;
					break;
			}
		}
		break;
		case HWND_KTV_MAIN_MID_PINYIN_BANNER_STR:
		{
	        U8 *pu8Data = NULL;
	        U8 u8Length = 0;
			u8Length = strlen(szPinYinInputValue);
			pu8Data = (U8 *)szPinYinInputValue;

			_MApp_DMP_GB2Unicode(pu8Data, (U8 *)CHAR_BUFFER, u8Length+2);
			CHAR_BUFFER[u8Length] = 0x00;
		    CHAR_BUFFER[u8Length + 1] = 0x00;
		}
			return CHAR_BUFFER;
		default:
			break;
    }

    if (u16TempID != Empty)
        return MApp_ZUI_API_GetString(u16TempID);



    return NULL; //for empty string
}

S16 MApp_ZUI_ACT_GetKTVDynamicValue(HWND hwnd)
{
    switch(hwnd)
    {
        case HWND_KTV_SET_ACC_BAR_FG:
            return stGenSetting.g_SoundSetting.BGVolume;
        case HWND_KTV_SET_MICORPHONE_BAR_FG:
			return stGenSetting.g_SoundSetting.KTVMicVolume;
        case HWND_KTV_SET_MIX_BAR_FG:
            return stGenSetting.g_SoundSetting.MixVolume;

        default:
            break;
    }
    return 0; //for empty  data
}


U16 MApp_ZUI_ACT_GetKTVDynamicbitmap(HWND hwnd,DRAWSTYLE_TYPE ds_type)
{
	ds_type = ds_type;
	switch(hwnd)
	{
    	case HWND_KTV_MAIN_MID_DISK_ITEM0_ICON:
    	case HWND_KTV_MAIN_MID_DISK_ITEM1_ICON:
    	case HWND_KTV_MAIN_MID_DISK_ITEM2_ICON:
    	case HWND_KTV_MAIN_MID_DISK_ITEM3_ICON:
    	case HWND_KTV_MAIN_MID_DISK_ITEM4_ICON:
    	case HWND_KTV_MAIN_MID_DISK_ITEM5_ICON:
    	case HWND_KTV_MAIN_MID_DISK_ITEM6_ICON:
    	case HWND_KTV_MAIN_MID_DISK_ITEM7_ICON:
    	case HWND_KTV_MAIN_MID_DISK_ITEM8_ICON:
    	case HWND_KTV_MAIN_MID_DISK_ITEM9_ICON:
			{
				U16 u16ItemIdx = 0;
				for(u16ItemIdx=0;u16ItemIdx<UI_KTV_ORDERLIST_NUMBER;u16ItemIdx++)
				{
				    if(hwnd == _hwndListOrderMidDiskIconListItem[u16ItemIdx])
				    {
//						printf("Get HWND hwnd = %d\n",hwnd);
				        break;
				    }
				}
				if(eDBFFileInfo == EN_SONG_BY_DISK)
				{
					MEDIA_FILE_INFO MediaFileInfo;
					u8PageIdx = u8CurrentVideoItemsPageIdx-UI_KTV_ORDERLIST_NUMBER*(u8CurrentMidlistPageIdx-1);

					if (u16ItemIdx < u8PageIdx&& u8PageIdx > 0)
					{
						MApp_ZUI_ACT_GetKTVVideoItemsInDiskInfo(&MediaFileInfo,u16ItemIdx+UI_KTV_ORDERLIST_NUMBER*(u8CurrentMidlistPageIdx-1)+1);
					}
					if(MediaFileInfo.u16MediaType == 0)
						return E_BMP_FOLDER;
					else if(MediaFileInfo.u16MediaType == 1)
						return E_BMP_MUSICICON;
				}
				else
					return 0xFFFF;
			}
			return 0xFFFF;
    	default:
			break;
	}

	return 0xFFFF;
}

void MApp_ZUI_ACT_KTVGetInputChar(VIRTUAL_KEY_CODE eKey,char *str)
{
	unsigned int i = 0;
	char ListChar_2[3]={'A','B','C'};
	char ListChar_3[3]={'D','E','F'};
	char ListChar_4[3]={'G','H','I'};
	char ListChar_5[3]={'J','K','L'};
	char ListChar_6[3]={'M','N','O'};
	char ListChar_7[4]={'P','Q','R','S'};
	char ListChar_8[3]={'T','U','V'};
	char ListChar_9[4]={'W','X','Y','Z'};

	switch(eKey)
	{
		case VK_NUM_2:
		{
			if (str[0] == 0)
				str[0] = ListChar_2[0];
			else
			{
				for(i = 0;i < sizeof(ListChar_2); i ++)
				{
					if (str[0] == ListChar_2[i])
					{
						i++;
						break;
					}
				}
				str[0] = ListChar_2[i % 3];
			}
		}
			break;
		case VK_NUM_3:
			if (str[0] == 0)
				str[0] = ListChar_3[0];
			else
			{
				for(i = 0;i < sizeof(ListChar_3); i ++)
				{
					if (str[0] == ListChar_3[i])
					{
						i++;
						break;
					}
				}
				str[0] = ListChar_3[i % 3];
			}
			break;
		case VK_NUM_4:
			if (str[0] == 0)
				str[0] = ListChar_4[0];
			else
			{
				for(i = 0;i < sizeof(ListChar_4); i ++)
				{
					if (str[0] == ListChar_4[i])
					{
						i++;
						break;
					}
				}
				str[0] = ListChar_4[i % 3];
			}
			break;
		case VK_NUM_5:
			if (str[0] == 0)
				str[0] = ListChar_5[0];
			else
			{
				for(i = 0;i < sizeof(ListChar_5); i ++)
				{
					if (str[0] == ListChar_5[i])
					{
						i++;
						break;
					}
				}
				str[0] = ListChar_5[i % 3];
			}
			break;
		case VK_NUM_6:
			if (str[0] == 0)
				str[0] = ListChar_6[0];
			else
			{
				for(i = 0;i < sizeof(ListChar_6); i ++)
				{
					if (str[0] == ListChar_6[i])
					{
						i++;
						break;
					}
				}
				str[0] = ListChar_6[i % 3];
			}
			break;
		case VK_NUM_7:
			if (str[0] == 0)
				str[0] = ListChar_7[0];
			else
			{
				for(i = 0;i < sizeof(ListChar_7); i ++)
				{
					if (str[0] == ListChar_7[i])
					{
						i++;
						break;
					}
				}
				str[0] = ListChar_7[i % 4];
			}
			break;
		case VK_NUM_8:
			if (str[0] == 0)
				str[0] = ListChar_8[0];
			else
			{
				for(i = 0;i < sizeof(ListChar_8); i ++)
				{
					if (str[0] == ListChar_8[i])
					{
						i++;
						break;
					}
				}
				str[0] = ListChar_8[i % 3];
			}
			break;
		case VK_NUM_9:
			if (str[0] == 0)
				str[0] = ListChar_9[0];
			else
			{
				for(i = 0;i < sizeof(ListChar_9); i ++)
				{
					if (str[0] == ListChar_9[i])
					{
						i++;
						break;
					}
				}
				str[0] = ListChar_9[i % 4];
			}
			break;
		default:
			break;
	}
}

static U32 u32SetFouscTime = 0;
VIRTUAL_KEY_CODE vPreKeyCode = VK_NULL;

S32 MApp_ZUI_ACT_KTVPinyinInputWinProc(HWND hwnd, PMSG msg)
{
    static BOOLEAN _bPinyinBlinkBlack = FALSE;
	U32 u32InputTimer = 0;

    switch(msg->message)
    {
        case MSG_NOTIFY_SETFOCUS:
            {
                //enable blinking
                MApp_ZUI_API_SetTimer(hwnd, 0, 500);
                MApp_ZUI_API_InvalidateWindow(hwnd);
                MApp_ZUI_API_SetTimer(HWND_KTV_MAIN_MID_PINYIN_BANNER_BLANK, 0, 500);
                MApp_ZUI_API_InvalidateWindow(HWND_KTV_MAIN_MID_PINYIN_BANNER_BLANK);
            }
            return 0;

        case MSG_TIMER:
            {
				//blinking
                _bPinyinBlinkBlack = !_bPinyinBlinkBlack;
                MApp_ZUI_API_InvalidateWindow(hwnd);

            }
            break;

        case MSG_NOTIFY_KILLFOCUS:
        case MSG_NOTIFY_HIDE:
            {
                //disable blinking
                MApp_ZUI_API_KillTimer(hwnd, 0);
                MApp_ZUI_API_KillTimer(HWND_KTV_MAIN_MID_PINYIN_BANNER_BLANK,0);
            }
            return 0;

        case MSG_KEYDOWN:
            {

                MApp_ZUI_API_ResetTimer(HWND_KTV_MAIN_MID_PINYIN_BANNER, 0);
		if(msg->wParam >= VK_NUM_2 && msg->wParam <= VK_NUM_9)
		{
			if(vPreKeyCode != msg->wParam)
			{
				_bPinyinBlinkBlack = FALSE;
				strcat(szPinYinInputValue,InputChar);
				szPinYinInputValue[strlen(szPinYinInputValue)] = 0;
				MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_MAIN_MID_PINYIN_BANNER);
				MApp_ZUI_API_InvalidateWindow(HWND_KTV_MAIN_MID_PINYIN_BANNER_STR);
				InputChar[0]=0;
			}

			u32SetFouscTime = msAPI_Timer_GetTime0();
			MApp_ZUI_ACT_KTVGetInputChar((VIRTUAL_KEY_CODE)msg->wParam,InputChar);
			InputChar[1]=0;
			MApp_ZUI_API_InvalidateWindow(HWND_KTV_MAIN_MID_PINYIN_BANNER_CUR_CHA);

			vPreKeyCode = (VIRTUAL_KEY_CODE)msg->wParam;
		  }
                else if (VK_LEFT== msg->wParam || VK_CHANNEL_RETURN == msg->wParam)
                {
                    _bPinyinBlinkBlack = FALSE;
			U8 u8Length = strlen(szPinYinInputValue);
			if(InputChar[0]!=0)
				InputChar[0]=0;
			else
				szPinYinInputValue[u8Length-1]=0;
			MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_MAIN_MID_PINYIN_BANNER);
			MApp_ZUI_API_InvalidateWindow(HWND_KTV_MAIN_MID_PINYIN_BANNER_STR);
                }
                else if (VK_RIGHT== msg->wParam)
                {
                    _bPinyinBlinkBlack = FALSE;
			strcat(szPinYinInputValue,InputChar);
			szPinYinInputValue[strlen(szPinYinInputValue)] = 0;
			MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_MAIN_MID_PINYIN_BANNER);
			MApp_ZUI_API_InvalidateWindow(HWND_KTV_MAIN_MID_PINYIN_BANNER_STR);
			InputChar[0]=0;
                }
//				printf("\n*******szPinYinInputValue=%sInputChar=%s******\n",szPinYinInputValue,InputChar);
		return 0;
            }
            break;

        case MSG_PAINT:
            {

                //get buffer GC for offline drawing...
                PAINT_PARAM * param = (PAINT_PARAM*)msg->wParam;
				RECT rect;

				rect.left = param->rect->left + MApp_ZUI_ACT_GetKTVStringLength(HWND_KTV_MAIN_MID_PINYIN_BANNER_STR,DS_NORMAL);
				rect.top = param->rect->top;
				rect.height= param->rect->height;
				rect.width = param->rect->width;

                //step1:draw word blink
                if (param->bIsFocus)
                {
                    DRAW_TEXT_OUT_DYNAMIC * dyna = (DRAW_TEXT_OUT_DYNAMIC*)_ZUI_MALLOC(sizeof(DRAW_TEXT_OUT_DYNAMIC));
                    LPTSTR str = CHAR_BUFFER;
                    U16 u16TextIndex;
                    u16TextIndex = _MApp_ZUI_API_FindFirstComponentIndex(hwnd, DS_NORMAL, CP_TEXT_OUT);

                    if (dyna)
                    {
                        _MApp_ZUI_API_ConvertTextComponentToDynamic(u16TextIndex, dyna);
                        if (_bPinyinBlinkBlack)
                        {
                            str[0] = CHAR_US;
                        }
                        else
                        {
                            str[0] = CHAR_SPACE;
                        }
                        str[1] = 0;
                        dyna->pString = str;
                        _MApp_ZUI_API_DrawDynamicComponent(CP_TEXT_OUT_DYNAMIC, dyna, &param->dc, &rect);
                        _ZUI_FREE(dyna);
                    }

                }

				u32InputTimer = msAPI_Timer_GetTime0()-u32SetFouscTime;
				if (u32InputTimer > 2000)
                {
                    _bPinyinBlinkBlack = FALSE;
					strcat(szPinYinInputValue,InputChar);
					MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_MAIN_MID_PINYIN_BANNER);
					MApp_ZUI_API_InvalidateWindow(HWND_KTV_MAIN_MID_PINYIN_BANNER_STR);
					InputChar[0]=0;
					u32SetFouscTime = msAPI_Timer_GetTime0();
                }

                //step2: draw text
                {
                    DRAW_TEXT_OUT_DYNAMIC * dyna;
                    U16 u16TextIndex;
                    u16TextIndex = _MApp_ZUI_API_FindFirstComponentIndex(hwnd, (param->bIsFocus)? DS_FOCUS: DS_NORMAL, CP_TEXT_OUT);

                    if (u16TextIndex != 0xFFFF)
                    {
                        if (param->bIsFocus)
                            param->dc.u8ConstantAlpha = MApp_ZUI_API_GetFocusAlpha(hwnd);
                        else
                            param->dc.u8ConstantAlpha = MApp_ZUI_API_GetNormalAlpha(hwnd);

                        dyna = (DRAW_TEXT_OUT_DYNAMIC*)_ZUI_MALLOC(sizeof(DRAW_TEXT_OUT_DYNAMIC));
                        if (dyna)
                        {
                            LPTSTR str = CHAR_BUFFER;
                            _MApp_ZUI_API_ConvertTextComponentToDynamic(u16TextIndex, dyna);
                            str[0] = InputChar[0];//_MApp_ProgramEdit_Rename_GetChar(i);
                            str[1] = 0;
                            dyna->pString = str;
                            _MApp_ZUI_API_DrawDynamicComponent(CP_TEXT_OUT_DYNAMIC, dyna, &param->dc, &rect);
                            _ZUI_FREE(dyna);
                        }
                    }
                }
            }
            return 0;

            default:
                break;

    }

    return DEFAULTWINPROC(hwnd, msg);
}


/////////////////////////////////////////////////////////
#define ZUI_DMP_XKTV   0
#define ZUI_DMP_YKTV  0
#define ZUI_DMP_WIDTH_KTV  630
#define ZUI_DMP_HEIGHT_KTV   70
#define ZUI_COLOR_KTV_GREEN   0x0000FF00
#define ZUI_DMP_XKTVDST  20
#define ZUI_DMP_YKTVDST 10

static void _MAPP_DMP_KTVFb_Create(/*HWND hwnd_bottom,*/HWND hwnd_frame)
{
    GOP_GwinFBAttr fbAttr;
    GRAPHIC_DC *dc = MApp_ZUI_API_GetScreenDC();

    if(_u8KFbId != 0xFF)
    {
       // printf("\ndelet buffer success\n");
        MApi_GOP_GWIN_DeleteFB(_u8KFbId);
    }

     MApi_GOP_GWIN_GetFBInfo(dc->u8FbID, &fbAttr);
    _u8KFbId = MApi_GOP_GWIN_GetFreeFBID();

	if(!MApi_GOP_GWIN_CreateFBbyStaticAddr(_u8KFbId, 0, 0, ZUI_DMP_WIDTH_KTV, ZUI_DMP_HEIGHT_KTV,  fbAttr.fbFmt, SUBTITLE_ADR ))
	{
        //printf("\n _MApp_MediaPlayer_KTV Fail to create buffer %u.\n",_u8KFbId);
        _u8KFbId = 0xFF;
        return;
	}
	else
	{
        //printf("\nCreat buffer success!\n");
	}

  //MApp_ZUI_API_ShowWindow(hwnd_bottom, SW_SHOW);  //del by sn 20101207

   _MApp_ZUI_API_WindowProcOnIdle();

  _MAPP_DMP_KTVFb_DrawArea(hwnd_frame);

  MApp_ZUI_API_GetWindowInitialRect(hwnd_frame,&_stKrcRect);

   _bKrcFlag = TRUE;
   u_u16TargetWidth = 0x00;
   u_u16PreTargetWidth = 0x00;
   _u32KrcTimerCounter = msAPI_Timer_GetTime0();


}

#include "MApp_ZUI_APIstyletables.h"
extern void _MApp_ZUI_API_ConvertTextComponentToDynamic(U16 u16TextOutIndex, DRAW_TEXT_OUT_DYNAMIC * pComp);
extern void _MApp_ZUI_API_ConvertTextComponentToPunctuated(U16 u16TextOutIndex, DRAW_PUNCTUATED_DYNAMIC * pComp);

static void _MAPP_DMP_KTVFb_DrawArea(HWND hWnd)
{
	GRAPHIC_DC Wdc;
    RECT    Wrect;
    U8 WinIdBU;
    //printf("\nDrawing!\n");

    if (_u8KFbId == 0xFF)
    {
        printf("\nNo KTV Lrc buffer");
        return ;
    }

	DRAWSTYLE * _Zui_KTV_TestFrame_DrawStyle = _GUI_WindowsDrawStyleList_Zui_Ktv_[hWnd].pNormalStyle;
	//DRAWSTYLE * _Zui_DMP_TestFrame_DrawStyleT = _GUI_WindowsDrawStyleList_Zui_Dmp[hWnd+2].pNormalStyle;

	WinIdBU = MApi_GOP_GWIN_GetCurrentWinId();
	MApi_GOP_GWIN_Switch2FB(_u8KFbId);

	Wdc.u8FbID = _u8KFbId;
	Wdc.u8ConstantAlpha = 0xFF;


	MApp_ZUI_API_GetWindowInitialRect(hWnd,&Wrect);

	Wrect.left = 0x00;
	Wrect.top = 0x00;
	_MApp_ZUI_API_DrawStyleList(&Wdc, &Wrect, _Zui_KTV_TestFrame_DrawStyle);

	{
  		U16 u16TxtComponentIndex = _MApp_ZUI_API_FindFirstComponentIndex(hWnd+2, DS_NORMAL, CP_TEXT_OUT);
		LPTSTR pStr = MApp_ZUI_ACT_GetDynamicText(hWnd+2);
    	      if (u16TxtComponentIndex != 0xFFFF && pStr)
		{
		  #if 1
		  	{
				//printf("\nu16TxtComponentIndex =%s ,pStr=%s\n",u16TxtComponentIndex,pStr);
				DRAW_TEXT_OUT_DYNAMIC dyna;

				_MApp_ZUI_API_ConvertTextComponentToDynamic(u16TxtComponentIndex, &dyna);
				dyna.pString = pStr;
				dyna.TextColor = MApp_ZUI_ACT_GetDynamicColor(hWnd, DS_NORMAL, dyna.TextColor);
				//printf("\ndyna.TextColor=%lx",dyna.TextColor);
				_MApp_ZUI_API_DrawDynamicComponent(CP_TEXT_OUT_DYNAMIC, &dyna, &Wdc, &Wrect);
		  	}
		 #else
		 	{
				DRAW_PUNCTUATED_DYNAMIC dyna;
				//dyna = (DRAW_PUNCTUATED_DYNAMIC*)_ZUI_MALLOC(sizeof(DRAW_PUNCTUATED_DYNAMIC));
				//if (dyna)
				_MApp_ZUI_API_ConvertTextComponentToPunctuated(u16TxtComponentIndex, &dyna);
				dyna.pString = pStr;
				dyna.max_row = MApp_ZUI_API_GetWindowData(hWnd+2);
				dyna.TextColor = MApp_ZUI_ACT_GetDynamicColor(hWnd, DS_NORMAL, dyna.TextColor);
				_MApp_ZUI_API_DrawDynamicComponent(CP_KTV_PUNCTUATED_DYNAMIC, &dyna, &Wdc, &Wrect);
		 	}
	       #endif
        }
   	}

    MApi_GOP_GWIN_Switch2Gwin(WinIdBU);
}


static  void _MAPP_DMP_KTVFb_CopyRegion(MSAPI_OSDRegion  *src, MSAPI_OSDRegion  *dst)
{
   //intf("\n in the copyregion");
	GOP_GwinFBAttr fbAttr;
	GFX_DrawRect bitbltInfo;
	GFX_BufferInfo srcbuf_bak, dstbuf_bak, srcbuf, dstbuf;

	//MApi_GFX_SetAlpha(TRUE, COEF_ONE, ABL_FROM_ASRC, 0xFF);
       bitbltInfo.srcblk.x = src->x;
	bitbltInfo.srcblk.y = src->y;
	bitbltInfo.srcblk.width = src->width;
	bitbltInfo.srcblk.height = src->height;

	bitbltInfo.dstblk.x = dst->x;
	bitbltInfo.dstblk.y = dst->y;
	bitbltInfo.dstblk.width = dst->width;
	bitbltInfo.dstblk.height = dst->height;

      MApi_GFX_GetBufferInfo(&srcbuf_bak, &dstbuf_bak);
      MApi_GOP_GWIN_GetFBInfo(src->fbID, &fbAttr);
   //printf("\nsrcformat=%d\n",fbAttr.fbFmt);
	if( GFX_FMT_ARGB1555_DST == (fbAttr.fbFmt & 0xff) )
	{
		srcbuf.u32ColorFmt = GFX_FMT_ARGB1555;
		MApi_GFX_SetAlpha_ARGB1555(0xFF); //for alpha channel of ARGB1555 bitblt
	}
	else
		srcbuf.u32ColorFmt = (GFX_Buffer_Format)(fbAttr.fbFmt & 0xff);
	srcbuf.u32Addr = fbAttr.addr;
	srcbuf.u32Pitch = fbAttr.pitch;
	MApi_GFX_SetSrcBufferInfo(&srcbuf, 0);

      MApi_GOP_GWIN_GetFBInfo(dst->fbID, &fbAttr);
   //printf("dstformat=%d\n",fbAttr.fbFmt);
	dstbuf.u32ColorFmt = (GFX_Buffer_Format)(fbAttr.fbFmt & 0xff);
	dstbuf.u32Addr = fbAttr.addr;
	dstbuf.u32Pitch = fbAttr.pitch;
	MApi_GFX_SetDstBufferInfo(&dstbuf, 0);

	if ((src->fbID != 0xFF) && (dst->fbID != 0xFF))
	{
		MApi_GFX_BitBlt(&bitbltInfo, 0);
		//MDrv_GE_BitBlt(&BitbltInfo, &PitBaseInfo);
		//printf("True:  src->fbID %bx / dst->fbID %bx \n ",src->fbID,dst->fbID);
	}
	else
	{
		  printf("ERR:  src->fbID %bx / dst->fbID%bx \n ",src->fbID,dst->fbID);
	}

	MApi_GFX_SetSrcBufferInfo(&srcbuf_bak, 0);
	MApi_GFX_SetDstBufferInfo(&dstbuf_bak, 0);
	//_MApp_KTV_CopyRegion_ClearFB();

   //return 0;

}



static void _MAPP_DMP_KTVFb_Destroy(void)
  {    //intf("\n in the destroy");
       if(_u8KFbId == 0xFF)
        {
            return;
       }
	 else
	  {
	   	 MApi_GOP_GWIN_DeleteFB(_u8KFbId);
	   }
	    _bKrcFlag = FALSE;
          _u8KFbId = 0xFF;

  }

 void _MApp_DMP_KTV_LRC_Handler(HWND hwnd)
{
    if(IsOpenLrc)
    {
       // MApp_ZUI_API_InvalidateAllSuccessors(HWND_KTV_LRC_BG);
		if(enKKLrcStatus == KTV_LRC_LINE1)
		{
			if(bIsFinished)
			{
			   MApp_ZUI_ACT_GetKTVLrc(&LyricLien2);
			   MApp_ZUI_API_ShowWindow(HWND_KTV_LRC_LINE2_BOTTOM,SW_SHOW);
			  // _MAPP_DMP_KTVFb_Destroy();
			   _MAPP_DMP_KTVFb_Create(HWND_KTV_LRC_LINE1);
			}
			MApp_ZUI_ACT_GetKTVLrcSunlength(&LyricLien);

		}
		else
		{
			if(bIsFinished)
			{
			   MApp_ZUI_ACT_GetKTVLrc(&LyricLien);
			   MApp_ZUI_API_ShowWindow(HWND_KTV_LRC_LINE1_BOTTOM,SW_SHOW);
			  // _MAPP_DMP_KTVFb_Destroy();
			   _MAPP_DMP_KTVFb_Create(HWND_KTV_LRC_LINE2);
			 }
			 MApp_ZUI_ACT_GetKTVLrcSunlength(&LyricLien2);
		}
		if((wSungLength > 0)&&bFirstShowLrc)
		{
			MApp_ZUI_API_ShowWindow(HWND_KTV_LRC_SONGNAME,SW_HIDE);
			MApp_ZUI_API_ShowWindow(HWND_KTV_LRC_SINGERNAME,SW_HIDE);
			bFirstShowLrc = FALSE;
			MApp_ZUI_API_ShowWindow(HWND_KTV_LRC_LINE1_BOTTOM,SW_SHOW);
			MApp_ZUI_API_ShowWindow(HWND_KTV_LRC_LINE2_BOTTOM,SW_SHOW);
			_MAPP_DMP_KTVFb_Create(HWND_KTV_LRC_LINE1);
		}
	}

	if(_bKrcFlag)
      {

		   if(enKKLrcStatus == KTV_LRC_LINE1)
		   {
		    	_stKrcRect.width = (MApp_ZUI_ACT_GetKTVStringLength(HWND_KTV_LRC_LINE1_BOTTOM,DS_NORMAL))*2;
		       //printf("\nline1 dwSungLength=%d _stKrcRect.width=%d\n",wSungLength,_stKrcRect.width);
		   }
		   if(enKKLrcStatus == KTV_LRC_LINE2)
		   {
			   	_stKrcRect.width = (MApp_ZUI_ACT_GetKTVStringLength(HWND_KTV_LRC_LINE2_BOTTOM,DS_NORMAL))*2;
			    // printf("\nline2 dwSungLength=%d _stKrcRect.width=%d\n",wSungLength,_stKrcRect.width);
		    }

      		u_u16TargetWidth = wSungLength;

      		if(bIsFinished)
             {
			u_u16TargetWidth = _stKrcRect.width;
			wSungLength =0;
        		_bKrcFlag = FALSE;
				// IsOpenLrc=TRUE;
			if( enKKLrcStatus == KTV_LRC_LINE1)
			{
				 enKKLrcStatus = KTV_LRC_LINE2;
		       }
			else
			{
				enKKLrcStatus = KTV_LRC_LINE1;
		       }
      	      }
      		if((u_u16TargetWidth <= _stKrcRect.width)&&(u_u16TargetWidth != 0x00)&&\
             (u_u16TargetWidth != u_u16PreTargetWidth))
           {
			MSAPI_OSDRegion  src;
			MSAPI_OSDRegion  dst;
			GRAPHIC_DC *dc = MApp_ZUI_API_GetScreenDC();

			_MAPP_DMP_KTVFb_DrawArea(hwnd);

			u_u16PreTargetWidth = u_u16TargetWidth;

			src.fbID=_u8KFbId;
			src.x=0;
			src.y=0;
			src.width=u_u16TargetWidth;
			src.height=_stKrcRect.height;

			dst.fbID=dc->u8FbID;
			dst.x=_stKrcRect.left;
			dst.y=_stKrcRect.top;
			dst.width=u_u16TargetWidth;
			dst.height=_stKrcRect.height;

			msAPI_OSD_SetClipWindow(
			                dst.x, dst.y,
			                dst.x+dst.width-1,
			                dst.y+dst.height-1);
      		       msAPI_OSD_GET_resource();
			_MAPP_DMP_KTVFb_CopyRegion(&src, &dst);
      		       msAPI_OSD_Free_resource();
			//msAPI_Timer_Delayms(50);
           }
  }
}

BOOLEAN MAPP_ZUI_ACT_KTV_PlayBackPhoto(void)
{
    if(MApp_MPlayer_QuerySelectedFileNum(E_MPLAYER_TYPE_PHOTO))
    {
        //MApp_MPlayer_Stop();
        MApp_MPlayer_SetPlayMode(E_MPLAYER_PLAY_SELECTED_FROM_CURRENT);
        MApp_MPlayer_SetCurrentMediaType(E_MPLAYER_TYPE_PHOTO, FALSE);
        if(MApp_MPlayer_QueryPhotoPlayMode() != E_MPLAYER_PHOTO_NORMAL)
        {
            MApp_MPlayer_PhotoChangePlayMode(E_MPLAYER_PHOTO_NORMAL);
        }
        // reset slide show timer(in MPlayer)
        if(MApp_MPlayer_QueryRepeatMode()!=E_MPLAYER_REPEAT_ALL)
        {
            MApp_MPlayer_SetRepeatMode(E_MPLAYER_REPEAT_ALL);
        }

        MApp_MPlayer_SetPhotoSlideShowDelayTime(DEFAULT_PHOTO_SLIDESHOW_DELAY_TIME);

        MApp_MPlayer_Play();

        return TRUE;
    }
    else
    {
        return FALSE;
    }
}
/////////////////////////////////////////////////////////
// Customize Window Procedures
S32 MApp_ZUI_ACT_KTVBackMessage(HWND hwnd, PMSG msg)
{
  //printf("\n@@@in the time\n");
    switch(msg->message)
    {
       case MSG_NOTIFY_SHOW:
            {
			//printf("\n@@@in the paint\n");
			MApp_ZUI_API_InvalidateWindow(hwnd);
			MApp_ZUI_API_SetTimer(hwnd, 0, 1000);
            }
	       break;
        case MSG_TIMER:
            {
			//printf("\n@@@@hide the window\n");
			MApp_ZUI_API_ShowWindow(hwnd,SW_HIDE);
			MApp_ZUI_API_KillTimer(hwnd, 0);

            }
            break;
        default:
            break;
    }
    return DEFAULTWINPROC(hwnd, msg);
}
#endif

#endif

#undef MAPP_ZUI_ACTKTV_C
