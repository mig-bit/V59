#if (defined(USB_HEADPHONE) && defined(CHIP_T3))
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <pthread.h>
#include <sys/soundcard.h>
#include <sys/ioctl.h>
#include "apiAUDIO.h"
#include "MApp_UsbHeadphone.h"
#include "datatype.h"

#define MAPP_USBDOWNLOAD_C

#define DEVICE_NAME "/dev/dsp"
#define SAMPLE_RATE 48000
#define DATA_FORMAT AFMT_S16_NE
#define CHANNEL_NUM 2

static int device_fd = 0;
static MS_BOOL _bEnabled = FALSE;
static pthread_t a_thread;

static MS_BOOL MApp_UsbHeadphoen_WriteData2Device(MS_U8 * pu8Buffer, MS_U32 u32Len)
{
    if (device_fd <= 0)
    {
        printf("MApp_UsbHeadphoen_WriteData2Device - Device is not exist!!\n");
        return FALSE;
    }

    // write data
    write(device_fd, pu8Buffer, u32Len);
    return TRUE;
}

static MS_BOOL MApp_UsbHeadphone_SetSpeed(MS_U32 u32Speed)
{
    int speed;

    if (device_fd <= 0)
    {
        printf("MApp_UsbHeadphone_SetSpeed - Device is not exist!!\n");
        return FALSE;
    }

    speed = u32Speed;
    if (ioctl(device_fd, SNDCTL_DSP_SPEED, &speed) == -1)
    {
       /* Fatal error */
       printf("ioctl failed - SNDCTL_DSP_SPEED\n");
       return FALSE;
    }
    else
    {
        return TRUE;
    }
}

static MS_BOOL MApp_UsbHeadphone_SetChannel(MS_U32 u32Channel)
{
    int channel;

    if (device_fd <= 0)
    {
        printf("MApp_UsbHeadphone_SetChannel - Device is not exist!!\n");
        return FALSE;
    }

    channel = u32Channel;
    if (ioctl(device_fd, SNDCTL_DSP_CHANNELS, &channel) == -1)
    {
       /* Fatal error */
       printf("ioctl failed - SNDCTL_DSP_CHANNELS\n");
       return FALSE;
    }
    else
    {
        return TRUE;
    }
}

static MS_BOOL MApp_UsbHeadphone_SetFormat(MS_U32 u32Format)
{
    int format;

    if (device_fd <= 0)
    {
        printf("MApp_UsbHeadphone_SetFormat - Device is not exist!!\n");
        return FALSE;
    }

    format = u32Format;
    if (ioctl(device_fd, SNDCTL_DSP_SETFMT, &format) == -1)
    {
       /* Fatal error */
       printf("ioctl failed - SNDCTL_DSP_SETFMT\n");
       return FALSE;
    }
    else
    {
        return TRUE;
    }
}
static MS_BOOL MApp_UsbHeadphone_OpenDevice(MS_U8 * pu8DeviceName)
{
    // open device
    if ((device_fd = open((char*)pu8DeviceName, O_WRONLY, 0)) == -1)
    {
       printf("MApp_UsbHeadphone_OpenDevice - open device \"%s\" falied!!\n", pu8DeviceName);
       return FALSE;
    }

    return TRUE;
}

static MS_BOOL MApp_UsbHeadphone_CloseDevice(void)
{
    if (device_fd > 0)
    {
        close(device_fd);
        device_fd = 0;
    }

    return TRUE;
}

static void* MApp_UsbHeadphone_ThreadFunc(void * arg)
{
    MS_U32 addr;
    MS_U32 size;

    UNUSED(arg);

    // polling that is data ready or not, then write the data to device
    while(_bEnabled)
    {
        // The data is ready
        if (MApi_AUDIO_USBPCM_GetFlag())
        {
            // get the data info
            MApi_AUDIO_USBPCM_GetMemInfo(&addr, &size);
            // write to device
            MApp_UsbHeadphoen_WriteData2Device((MS_U8 *)_PA2VA(addr), size);
            // clear the flag
            MApi_AUDIO_USBPCM_SetFlag(0);
        }
    }

    pthread_exit(NULL);
}

void MApp_UsbHeadphone_Enable(MS_BOOL bEnable)
{
    if (bEnable)
    {
        // Already enabled, don't do it again.
        if (_bEnabled == TRUE)
            return;

        _bEnabled = TRUE;

        // open device
        MApp_UsbHeadphone_OpenDevice((MS_U8*)DEVICE_NAME);

        // set format
        MApp_UsbHeadphone_SetFormat(DATA_FORMAT);

        // set channel
        MApp_UsbHeadphone_SetChannel(CHANNEL_NUM); /* 1=mono, 2=stereo */

        // set speed
        MApp_UsbHeadphone_SetSpeed(SAMPLE_RATE);

        // Enable audio driver
        MApi_AUDIO_USBPCM_Enable(TRUE);

        // create thread function to polling and play
        if (pthread_create(&a_thread, NULL, MApp_UsbHeadphone_ThreadFunc, NULL) != 0)
        {
            printf("MApp_UsbHeadphone_Enable - Create thread failed!!\n");
            MApp_UsbHeadphone_CloseDevice();
            return;
        }
    }
    else
    {
        void * thread_result;

        if (_bEnabled == FALSE)
            return;

        _bEnabled = FALSE;

        // Enable audio driver
        MApi_AUDIO_USBPCM_Enable(FALSE);

        MApp_UsbHeadphone_CloseDevice();

        if (pthread_join(a_thread, &thread_result) != 0)
        {
            printf("MApp_UsbHeadphone_Enable - Thread join failed!!\n");
        }
    }
}
#endif  //#if (defined(USB_HEADPHONE) && defined(CHIP_T3))
