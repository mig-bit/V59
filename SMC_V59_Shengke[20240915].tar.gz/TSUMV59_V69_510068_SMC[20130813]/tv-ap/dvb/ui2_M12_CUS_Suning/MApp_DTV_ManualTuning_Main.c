////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#define MAPP_DTV_MANUALTUNING_MAIN_C
#if (ENABLE_DTV)
/******************************************************************************/
/*                 Header Files                                               */
/* ****************************************************************************/
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "Board.h"
#include "datatype.h"
#include "msAPI_Global.h"
#include "apiXC.h"
#include "apiXC_Adc.h"
#include "msAPI_FreqTableDTV.h"
#include "MApp_GlobalSettingSt.h"
#include "MApp_Key.h"
#include "MApp_UiMenuDef.h"
#include "MApp_ZUI_Main.h"
#include "MApp_DTV_ManualTuning_Main.h"
#include "MApp_ChannelChange.h"
#include "MApp_InputSource.h"
#if  NTV_FUNCTION_ENABLE
#include "MApp_Scan.h"
#endif

#ifdef ENABLE_SELECT_NONESEARCH_CH
#include "MApp_TV.h"
#endif

///////////////////////////////////////////////////////////

EN_DTV_MANUALTUNING_STATE enDtvManualTuningState;

#if ENABLE_SBTVD_BRAZIL_APP
extern E_ANTENNA_SOURCE_TYPE enLastWatchAntennaType;
#endif

//////////////////////////////////////////////////////////
EN_RET MApp_DTV_ManualTuning_Main(void)
{
    EN_RET enRetVal = EXIT_NULL;
    MS_TP_SETTING stTempTP;

    switch(enDtvManualTuningState)
    {
        case STATE_DTV_MANUALTUNING_INIT:
            //MApp_ZUI_ACT_StartupOSD(E_OSD_DTV_MANUAL_TUNING);
            MApp_ChannelChange_DisableChannel(TRUE,MAIN_WINDOW);
            #if (ENABLE_PIP)
            if(IsPIPEnable())
            {
                if(stGenSetting.g_stPipSetting.enPipSoundSrc==EN_PIP_SOUND_SRC_SUB)
                {
                    stGenSetting.g_stPipSetting.enPipSoundSrc=EN_PIP_SOUND_SRC_MAIN;
                    MApp_InputSource_PIP_ChangeAudioSource(MAIN_WINDOW);
                }
                UI_SUB_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_NONE;
                MApp_InputSource_ChangeInputSource(SUB_WINDOW);
                stGenSetting.g_stPipSetting.enPipMode = EN_PIP_MODE_OFF;
                UI_SUB_INPUT_SOURCE_TYPE = MApp_InputSource_GetUIInputSourceType(MApp_InputSource_PIP_Get1stCompatibleSrc(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)));
            }
            #endif
    #if ENABLE_SBTVD_BRAZIL_APP
          if(enLastWatchAntennaType!=ANTENNA_DTV_TYPE)
            {
              enLastWatchAntennaType = ANTENNA_DTV_TYPE;
              MApp_InputSource_SwitchSource( UI_INPUT_SOURCE_TYPE , MAIN_WINDOW );
              #ifdef ENABLE_SELECT_NONESEARCH_CH
                u16ChannelReturn_Num2=IVALID_TV_RETURN_NUM;
              #endif
            }
    #else
           MApp_InputSource_ChangeInputSource(MAIN_WINDOW);
    #endif


            enDtvManualTuningState = STATE_DTV_MANUALTUNING_WAIT;

            if( msAPI_DFT_GetTSSetting(stGenSetting.stScanMenuSetting.u8RFChannelNumber, &stTempTP) == TRUE)
                msAPI_Tuner_Tune2RfCh(&stTempTP);

            stGenSetting.stScanMenuSetting.u8PreRFChannelNumber=stGenSetting.stScanMenuSetting.u8RFChannelNumber;

            break;

        case STATE_DTV_MANUALTUNING_WAIT:
            MApp_ZUI_ProcessKey(u8KeyCode);
            {
                BOOLEAN bLockStatus = FALSE;
                static U8 bLockStableCunt = 0;
                if(IsDTVInUse())
                {
                    msAPI_Tuner_CheckLock(&bLockStatus, FALSE);
                 if(bLockStatus != FALSE)
                {
                    if(bLockStableCunt >= 24)
                    {
                        g_CurSignalStrength = msAPI_Tuner_GetSignalQualityPercentage();
                    }
                    else
                    {
                        msAPI_Tuner_GetSignalQualityPercentage();
                        bLockStableCunt++;
                    }

                }
                else
                {
                    g_CurSignalStrength = 0;
                    bLockStableCunt = 0;
                }
                  g_LockStatus = bLockStatus;

                }
            }
            u8KeyCode = KEY_NULL;
            break;

        case STATE_DTV_MANUALTUNING_CLEAN_UP:
            MApp_ZUI_ACT_ShutdownOSD();
#if  NTV_FUNCTION_ENABLE
            if(MApp_Get_ScanGoRegion_Status() == FALSE)
            {
                MApp_ChannelChange_EnableChannel(MAIN_WINDOW);
            }
#else
            MApp_ChannelChange_EnableChannel(MAIN_WINDOW);
#endif
            enDtvManualTuningState = STATE_DTV_MANUALTUNING_INIT;
#if  0//NTV_FUNCTION_ENABLE //wait to do
            if(MApp_Get_ScanGoRegion_Status())
            {
                enRetVal = EXIT_GOTO_NTV_LIST;
                MApp_DTV_Scan_SetSelectFavoriteNetwork(INVALID_NETWORKINDEX);
            }
            else
            {
                enRetVal = EXIT_CLOSE;

            }
#else
            enRetVal = EXIT_CLOSE;
#endif
            break;

        case STATE_DTV_MANUALTUNING_GOTO_STANDBY:
            MApp_ZUI_ACT_ShutdownOSD();
            u8KeyCode = KEY_POWER;
            enRetVal = EXIT_GOTO_STANDBY;
            break;

        case STATE_DTV_MANUALTUNING_GOTO_MAIN_MENU:
            MApp_ZUI_ACT_ShutdownOSD();
            MApp_ChannelChange_EnableChannel(MAIN_WINDOW);
            enDtvManualTuningState = STATE_DTV_MANUALTUNING_INIT;
            enRetVal = EXIT_GOTO_MENU;
            break;

        case STATE_DTV_MANUALTUNING_GOTO_DTV_SCAN:
            enDtvManualTuningState = STATE_DTV_MANUALTUNING_WAIT;
            enRetVal = EXIT_GOTO_DTVSCAN;
            break;

        default:
            enDtvManualTuningState = STATE_DTV_MANUALTUNING_WAIT;
            break;
    }
    return enRetVal;
}
#endif//#if (ENABLE_DTV)
#undef MAPP_DTV_MANUALTUNING_MAIN_C

