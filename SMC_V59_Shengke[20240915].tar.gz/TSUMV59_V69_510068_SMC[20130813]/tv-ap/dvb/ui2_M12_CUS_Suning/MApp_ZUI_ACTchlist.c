////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#define MAPP_ZUI_ACTCHLIST_C
#define _ZUI_INTERNAL_INSIDE_ //NOTE: for ZUI internal


//-------------------------------------------------------------------------------------------------
// Include Files
//-------------------------------------------------------------------------------------------------
#include "Board.h"
#include "datatype.h"
#include "MsCommon.h"
#include "apiXC.h"
#include "apiXC_Adc.h"
#include "MApp_ZUI_Main.h"
#include "MApp_ZUI_APIcommon.h"
#include "MApp_ZUI_APIstrings.h"
#include "MApp_ZUI_APIwindow.h"
#include "ZUI_tables_h.inl"
#include "MApp_ZUI_APIgdi.h"
#include "MApp_ZUI_APIcontrols.h"
#include "MApp_GlobalSettingSt.h"
#include "MApp_ZUI_ACTmainpage.h"
#include "MApp_ZUI_ACTeffect.h"
#include "MApp_ZUI_ACTglobal.h"
#include "OSDcp_String_EnumIndex.h"
#include "OSDcp_Bitmap_EnumIndex.h"
#include "ZUI_exefunc.h"

#include "MApp_ChList_Main.h"
#include "MApp_OSDPage_Main.h"

#include "MApp_SaveData.h"
#include "MApp_UiMenuDef.h"
#include "MApp_ChannelList.h"
#include "msAPI_Memory.h"
#include "msAPI_ChProc.h"
#include "MApp_GlobalFunction.h"

#if (ENABLE_DTV)
#include "mapp_demux.h"
#include "mapp_si.h"
#endif

/////////////////////////////////////////////////////////////////////

static EN_OSDPAGE_STATE _enTargetState;

extern EN_CHLIST_MODE _eChannelListMode;
#if ENABLE_DTV
extern BOOLEAN MApp_CharTable_GetServiceNameToUCS2(MEMBER_SERVICETYPE bServiceType, WORD wPosition, WORD * bChannelName, U8 ControlCodes);
#endif
static void _MApp_ZUI_ACT_Chlist_GetTotalProgCount(U8 u8ServiceType);
#if (ENABLE_PVR)
extern BOOLEAN MApp_ZUI_ACT_PVR_Check_Switch_Channel(MEMBER_SERVICETYPE NewCMType, U16 u16NewPos);
#endif
#if NTV_FUNCTION_ENABLE
static U8 u8TotalNetWorkNum=0;
#endif
//*************************************************************************
//              Defines
//*************************************************************************
#define CHANNEL_LIST_PAGE_NUM          10
#define SIMILAR_LIST_PAGE_NUM          5
#define RECENT_LIST_PAGE_NUM           5
#define CH_LIST_CURRENT_CN_TEXT_COLOR      0x00FF00
#define CH_LIST_CURRENT_CN_TEXT_HL_COLOR   0x0000FF

typedef enum
{
    CHANNEL_LIST_COMMAND_INIT,
    CHANNEL_LIST_COMMAND_UP,
    CHANNEL_LIST_COMMAND_DOWN,
    CHANNEL_LIST_COMMAND_PRVPAGE,
    CHANNEL_LIST_COMMAND_NEXTPAGE,
} EN_CHANNEL_LIST_COMMAND_TYPE;

typedef enum
{
    FAVORITE_LIST_COMMAND_INIT,
    FAVORITE_LIST_COMMAND_UP,
    FAVORITE_LIST_COMMAND_DOWN,
    FAVORITE_LIST_COMMAND_PRVPAGE,
    FAVORITE_LIST_COMMAND_NEXTPAGE,
} EN_FAVORITE_LIST_COMMAND_TYPE;

/********************************************************************************/
/*                    Macro                                                     */
/********************************************************************************/
#define CHANNEL_LIST_DBINFO(y)    //y
#define FAVORITE_LIST_DBINFO(y)   //y

#define RECENT_LIST_DBINFO(y)     //y

/********************************************************************************/
/*                      Local                                                   */
/********************************************************************************/
typedef struct _CHANNEL_LIST_DATA_STRUCT
{
    U8  u8CurrentPage;
    U8  u8ServiceType;
    U16 u16ChCountOfCurPage;  //total channel count of current page
    U16 u16CurCh;
    U16 u16PageListIndex[CHANNEL_LIST_PAGE_NUM];
    U16 u16TotalChCount;  //total channel numer of database

} CHANNEL_LIST_DATA_STRUCT;

static CHANNEL_LIST_DATA_STRUCT * pChListData = NULL;

///////////////////////////////////////////////////////////////////////

static  HWND _ZUI_TBLSEG _ChannelListHwndList[CHANNEL_LIST_PAGE_NUM]=
{
    HWND_CHLIST_ITEM0,
    HWND_CHLIST_ITEM1,
    HWND_CHLIST_ITEM2,
    HWND_CHLIST_ITEM3,
    HWND_CHLIST_ITEM4,
    HWND_CHLIST_ITEM5,
    HWND_CHLIST_ITEM6,
    HWND_CHLIST_ITEM7,
    HWND_CHLIST_ITEM8,
    HWND_CHLIST_ITEM9,
};

static U8 _MApp_ZUI_ACT_ChannelListWindowMapToIndex(HWND hwnd)
{
    U8 i;
    for (i = 0; i < CHANNEL_LIST_PAGE_NUM; i++)
    {
        if (hwnd == _ChannelListHwndList[i] ||
            MApp_ZUI_API_IsSuccessor(_ChannelListHwndList[i], hwnd))
        {
            return i;
        }
    }
    return 0;
}

static HWND _MApp_ZUI_ACT_ChannelListIndexMapToWindow(U8 u8Index)
{
    if (u8Index >= CHANNEL_LIST_PAGE_NUM)
        return HWND_INVALID;
    return _ChannelListHwndList[u8Index];

}

static BOOLEAN _MApp_ZUI_ACT_IsFavMode(void)
{
    return (_eChannelListMode == MODE_CHLIST_RADIO_FAV ||
                _eChannelListMode == MODE_CHLIST_TV_FAV);
}

///////////////////////////////////////////////////////////////////////
// from MApp_ChannelList.c

static void _MApp_ChannelList_Handler (U16 u16ActiveProgOrder, U16 u16ShiftProgIndex, U16 u16TotalSrvCount, U8 u8SrvCommand)
{
    U8 u16SrvPageCurIndex = _MApp_ZUI_ACT_ChannelListWindowMapToIndex(      MApp_ZUI_API_GetFocus());

    switch (u8SrvCommand)
    {
        case CHANNEL_LIST_COMMAND_INIT:
        {
            pChListData->u8CurrentPage = u16ActiveProgOrder / CHANNEL_LIST_PAGE_NUM;
            u16SrvPageCurIndex = u16ActiveProgOrder % CHANNEL_LIST_PAGE_NUM;

            if (u16TotalSrvCount == 0)
            {
                   MApp_ZUI_API_SetFocus(HWND_INVALID);
            }
            else if(IsATVInUse() &&
                msAPI_CHPROC_CM_CountProgram(E_SERVICETYPE_ATV, E_PROGACESS_INCLUDE_VISIBLE_ONLY) ==0)
            {
                  pChListData->u8CurrentPage=0;
                  MApp_ZUI_API_SetFocus(_MApp_ZUI_ACT_ChannelListIndexMapToWindow(0));

            }
            else
            {
                MApp_ZUI_API_SetFocus(
                    _MApp_ZUI_ACT_ChannelListIndexMapToWindow(u16SrvPageCurIndex));
            }

            //u16SrvPagePrvIndex = u16SrvPageCurIndex;
            MApp_ZUI_API_InvalidateAllSuccessors(HWND_CHLIST_LIST_PANE);
            if ( ((u16TotalSrvCount-1) / CHANNEL_LIST_PAGE_NUM) > pChListData->u8CurrentPage )
            {
                pChListData->u16ChCountOfCurPage = CHANNEL_LIST_PAGE_NUM;
            }
            else
            {
                pChListData->u16ChCountOfCurPage = ((u16TotalSrvCount % CHANNEL_LIST_PAGE_NUM) == 0 ? CHANNEL_LIST_PAGE_NUM : (u16TotalSrvCount % CHANNEL_LIST_PAGE_NUM));
            }
        }
        break;

        case CHANNEL_LIST_COMMAND_UP:
        {
            if (u16SrvPageCurIndex >= u16ShiftProgIndex)
            {
                //in the same page movement
                u16SrvPageCurIndex -= u16ShiftProgIndex;
                MApp_ZUI_API_SetFocus(
                    _MApp_ZUI_ACT_ChannelListIndexMapToWindow(u16SrvPageCurIndex));
                return;
            }
            if (pChListData->u8CurrentPage == 0)
            {
                // first page
                _MApp_ZUI_ACT_Chlist_GetTotalProgCount(pChListData->u8ServiceType);
                u16TotalSrvCount = pChListData->u16TotalChCount;
                pChListData->u8CurrentPage= (u16TotalSrvCount - 1) / CHANNEL_LIST_PAGE_NUM;
                pChListData->u16ChCountOfCurPage = ((u16TotalSrvCount % CHANNEL_LIST_PAGE_NUM) == 0 ? CHANNEL_LIST_PAGE_NUM : (u16TotalSrvCount % CHANNEL_LIST_PAGE_NUM));
                MApp_ZUI_API_SetFocus(
                    _MApp_ZUI_ACT_ChannelListIndexMapToWindow(pChListData->u16ChCountOfCurPage - 1));
                if (u16TotalSrvCount > CHANNEL_LIST_PAGE_NUM)
                {
                    MApp_ZUI_API_InvalidateAllSuccessors(HWND_CHLIST_LIST_PANE);
                }
                return;
            }
            // move to prev page
            pChListData->u8CurrentPage--;
            pChListData->u16ChCountOfCurPage = CHANNEL_LIST_PAGE_NUM;
            u16SrvPageCurIndex = (u16SrvPageCurIndex + CHANNEL_LIST_PAGE_NUM - u16ShiftProgIndex) % CHANNEL_LIST_PAGE_NUM;
            MApp_ZUI_API_SetFocus(
                _MApp_ZUI_ACT_ChannelListIndexMapToWindow(u16SrvPageCurIndex));
            MApp_ZUI_API_InvalidateAllSuccessors(HWND_CHLIST_LIST_PANE);
        }
        break;

        case CHANNEL_LIST_COMMAND_DOWN:
        {
            U16 u16PageLastIndex;

            if ((u16SrvPageCurIndex+u16ShiftProgIndex) < pChListData->u16ChCountOfCurPage)
            {
                //in the same page movement
                u16SrvPageCurIndex += u16ShiftProgIndex;
                MApp_ZUI_API_SetFocus(
                    _MApp_ZUI_ACT_ChannelListIndexMapToWindow(u16SrvPageCurIndex));
                return;
            }
            u16PageLastIndex = (pChListData->u8CurrentPage * CHANNEL_LIST_PAGE_NUM) + pChListData->u16ChCountOfCurPage;
            if (u16PageLastIndex == u16TotalSrvCount)
            {
                //move to first page
                _MApp_ZUI_ACT_Chlist_GetTotalProgCount(pChListData->u8ServiceType);
                u16TotalSrvCount = pChListData->u16TotalChCount;
                pChListData->u8CurrentPage = 0;
                pChListData->u16ChCountOfCurPage = (u16TotalSrvCount > CHANNEL_LIST_PAGE_NUM) ? CHANNEL_LIST_PAGE_NUM : u16TotalSrvCount;
                MApp_ZUI_API_SetFocus(
                    _MApp_ZUI_ACT_ChannelListIndexMapToWindow(0));

                if (u16TotalSrvCount > CHANNEL_LIST_PAGE_NUM)
                {
                    MApp_ZUI_API_InvalidateAllSuccessors(HWND_CHLIST_LIST_PANE);
                }
                return;
            }
            //move to next page
            _MApp_ZUI_ACT_Chlist_GetTotalProgCount(pChListData->u8ServiceType);
            u16TotalSrvCount = pChListData->u16TotalChCount;
            pChListData->u8CurrentPage++;
            if ( ((u16TotalSrvCount-1) / CHANNEL_LIST_PAGE_NUM) > pChListData->u8CurrentPage )
            {
                pChListData->u16ChCountOfCurPage = CHANNEL_LIST_PAGE_NUM;
            }
            else
            {
                pChListData->u16ChCountOfCurPage = ((u16TotalSrvCount % CHANNEL_LIST_PAGE_NUM) == 0 ? CHANNEL_LIST_PAGE_NUM : (u16TotalSrvCount % CHANNEL_LIST_PAGE_NUM));
            }
            u16SrvPageCurIndex = (u16SrvPageCurIndex + u16ShiftProgIndex) % CHANNEL_LIST_PAGE_NUM;
            MApp_ZUI_API_SetFocus(
                _MApp_ZUI_ACT_ChannelListIndexMapToWindow(u16SrvPageCurIndex));
            MApp_ZUI_API_InvalidateAllSuccessors(HWND_CHLIST_LIST_PANE);
        }
        break;

        case CHANNEL_LIST_COMMAND_PRVPAGE:
        {
            if (pChListData->u8CurrentPage == 0)
            {
                if (u16SrvPageCurIndex > 0)
                {
                    //focus the first item
                    MApp_ZUI_API_SetFocus(
                        _MApp_ZUI_ACT_ChannelListIndexMapToWindow(0));
                    return;
                }
                else
                {
                    //move to last page last item
                    _MApp_ZUI_ACT_Chlist_GetTotalProgCount(pChListData->u8ServiceType);
                    u16TotalSrvCount = pChListData->u16TotalChCount;
                    pChListData->u8CurrentPage= (u16TotalSrvCount - 1) / CHANNEL_LIST_PAGE_NUM;
                    pChListData->u16ChCountOfCurPage = ((u16TotalSrvCount % CHANNEL_LIST_PAGE_NUM) == 0 ? CHANNEL_LIST_PAGE_NUM : (u16TotalSrvCount % CHANNEL_LIST_PAGE_NUM));
                    u16SrvPageCurIndex = pChListData->u16ChCountOfCurPage - 1;
                    MApp_ZUI_API_SetFocus(
                        _MApp_ZUI_ACT_ChannelListIndexMapToWindow(u16SrvPageCurIndex));
                    if (u16TotalSrvCount > CHANNEL_LIST_PAGE_NUM)
                    {
                        MApp_ZUI_API_InvalidateAllSuccessors(HWND_CHLIST_LIST_PANE);
                    }
                    return;
                }
            }
            pChListData->u8CurrentPage--;
            pChListData->u16ChCountOfCurPage = CHANNEL_LIST_PAGE_NUM;
            MApp_ZUI_API_InvalidateAllSuccessors(HWND_CHLIST_LIST_PANE);
            //ZUI: u8SrvPageBehavior = CHANNEL_LIST_OSDEVENT_REDRAW;
        }
        break;

        case CHANNEL_LIST_COMMAND_NEXTPAGE:
        {
            U8 u8LastPage;
            _MApp_ZUI_ACT_Chlist_GetTotalProgCount(pChListData->u8ServiceType);
            u16TotalSrvCount = pChListData->u16TotalChCount;
            u8LastPage = (u16TotalSrvCount - 1) / CHANNEL_LIST_PAGE_NUM;
            if (u8LastPage == pChListData->u8CurrentPage)
            {
                //the last page
                if (u16SrvPageCurIndex == (pChListData->u16ChCountOfCurPage-1))
                {
                    //the last item, move to first page
                    pChListData->u8CurrentPage = 0;
                    pChListData->u16ChCountOfCurPage = (u16TotalSrvCount > CHANNEL_LIST_PAGE_NUM) ? CHANNEL_LIST_PAGE_NUM : u16TotalSrvCount;
                    MApp_ZUI_API_SetFocus(
                        _MApp_ZUI_ACT_ChannelListIndexMapToWindow(0));
                    if (u16TotalSrvCount > CHANNEL_LIST_PAGE_NUM)
                    {
                        MApp_ZUI_API_InvalidateAllSuccessors(HWND_CHLIST_LIST_PANE);
                    }
                    else
                    {
                    }
                    return;
                }
                else
                {
                    //focus the last item
                    u16SrvPageCurIndex = pChListData->u16ChCountOfCurPage - 1;
                    MApp_ZUI_API_SetFocus(
                        _MApp_ZUI_ACT_ChannelListIndexMapToWindow(u16SrvPageCurIndex));
                    return;
                }
            }
            //move to next page
            pChListData->u8CurrentPage++;
            if (u8LastPage > pChListData->u8CurrentPage)
            {
                pChListData->u16ChCountOfCurPage = CHANNEL_LIST_PAGE_NUM;
            }
            else
            {
                pChListData->u16ChCountOfCurPage = ((u16TotalSrvCount % CHANNEL_LIST_PAGE_NUM) == 0 ? CHANNEL_LIST_PAGE_NUM : (u16TotalSrvCount % CHANNEL_LIST_PAGE_NUM));
            }
            if (u16SrvPageCurIndex >= pChListData->u16ChCountOfCurPage)
            {
                u16SrvPageCurIndex = pChListData->u16ChCountOfCurPage - 1;
            }
            MApp_ZUI_API_SetFocus(_MApp_ZUI_ACT_ChannelListIndexMapToWindow(u16SrvPageCurIndex));
            MApp_ZUI_API_InvalidateAllSuccessors(HWND_CHLIST_LIST_PANE);
        }
        break;
    }
}


static void _MApp_ChannelList_Init(U8 u8ServiceType)
{
    BOOLEAN bVisibleFlag;

    pChListData->u8ServiceType = u8ServiceType;
    CHANNEL_LIST_DBINFO(printf("UI_MApp_ChannelList_Init: u8ServiceType=%bu\n", (U8)u8ServiceType));

    pChListData->u16TotalChCount = msAPI_CHPROC_CM_CountProgram((MEMBER_SERVICETYPE)u8ServiceType, E_PROGACESS_INCLUDE_VISIBLE_ONLY);

    //printf("UI_MApp_ChannelList_Init: u8ServiceType=%bu, count = %u\n", (U8)u8ServiceType, pChListData->u16TotalChCount);

    pChListData->u16CurCh = msAPI_CHPROC_CM_GetCurrentOrdinal((MEMBER_SERVICETYPE)u8ServiceType, E_PROGACESS_INCLUDE_VISIBLE_ONLY);

#if ENABLE_SBTVD_BRAZIL_APP
    if(msAPI_ATV_GetCurrentAntenna() == ANT_AIR)
#endif
    {
        U16 u16CurChTmp;
        u16CurChTmp = msAPI_CHPROC_CM_GetCurrentOrdinal((MEMBER_SERVICETYPE)u8ServiceType, E_PROGACESS_INCLUDE_NOT_VISIBLE_ALSO);
        msAPI_CHPROC_CM_GetAttributeOfOrdinal( (MEMBER_SERVICETYPE)u8ServiceType, u16CurChTmp, &bVisibleFlag, E_SERVICE_ATTR_VISIBLE, E_PROGACESS_INCLUDE_NOT_VISIBLE_ALSO );

//        msAPI_CHPROC_CM_GetAttributeOfOrdinal( (MEMBER_SERVICETYPE)u8ServiceType, pChListData->u16CurCh, &bVisibleFlag, E_SERVICE_ATTR_VISIBLE, E_PROGACESS_INCLUDE_VISIBLE_ONLY );

        if ( !bVisibleFlag )
        {
            pChListData->u16CurCh = 0;
        }

        if ((pChListData->u16TotalChCount > 0) && (pChListData->u16CurCh == INVALID_ORDINAL))
        {
            pChListData->u16CurCh = 0;
        }
        else if (pChListData->u16TotalChCount == 0)
        {
            pChListData->u16CurCh = 0;
        }
    }
    CHANNEL_LIST_DBINFO(printf("pChListData->u16TotalChCount=%u\n", pChListData->u16TotalChCount));
    CHANNEL_LIST_DBINFO(printf("pChListData->u16CurCh=%u\n", pChListData->u16CurCh));
    _MApp_ChannelList_Handler(pChListData->u16CurCh, 0, pChListData->u16TotalChCount, CHANNEL_LIST_COMMAND_INIT);



}

///////////////////////////////////////////////////////////////////////
//for favorite list


static U16 _MApp_FavoriteList_GetOnePagePositionByPageNum(EN_SERVICE_TYPE enType, U16 u16List[], U8 u8WhichPage)
{
    U8 u8Page = 0;
    U16 u16Count = 0, u16FavoriteCount = 0, u16Ptr = 0;
    U16 u16Position = 0, list_i = 0;

    FAVORITE_LIST_DBINFO(printf("_MApp_FavoriteList_GetOnePagePositionByPageNum\n"););
    for (list_i=0; list_i<CHANNEL_LIST_PAGE_NUM; list_i++)
    {
        u16List[list_i] = CHANNEL_LIST_INVALID_PROGINDEX;
    }

    u16FavoriteCount = msAPI_CHPROC_CM_CountFavoriteProgram((MEMBER_SERVICETYPE)enType);
    FAVORITE_LIST_DBINFO(printf("   u16FavoriteCount=%u\n", u16FavoriteCount););
    if (u16FavoriteCount == 0)
    {
        return u16Count;
    }

    list_i = 0;
    u16Position = msAPI_CHPROC_CM_GetFirstFavoriteOrdinal((MEMBER_SERVICETYPE)enType, TRUE);

    do
    {
        if (u8Page == u8WhichPage)
        {
            u16List[list_i] = u16Position;
            FAVORITE_LIST_DBINFO(printf("   u16List[%u]=%u\n", list_i, u16List[list_i]););
            list_i++;
            u16Count++;
            if (list_i >= CHANNEL_LIST_PAGE_NUM)
            {
                // list filled
                break;
            }
            u16Position = msAPI_CHPROC_CM_GetNextFavoriteOrdinal((MEMBER_SERVICETYPE)enType, u16Position, TRUE);
        }
        else
        {
            list_i++;
            if (list_i == CHANNEL_LIST_PAGE_NUM)
            {
                list_i = 0;
                u8Page++;
            }
            u16Position = msAPI_CHPROC_CM_GetNextFavoriteOrdinal((MEMBER_SERVICETYPE)enType, u16Position, TRUE);
        }
        u16Ptr++;
    } while (u16Ptr < u16FavoriteCount);

    return u16Count;
}

static void _MApp_FavoriteList_Handler(U16 u16ActiveProgOrder, U16 u16ShiftProgIndex, U16 u16TotalSrvCount, U8 u8SrvCommand)
{
    U8 u16SrvPageCurIndex = _MApp_ZUI_ACT_ChannelListWindowMapToIndex(      MApp_ZUI_API_GetFocus());

    switch (u8SrvCommand)
    {
        case FAVORITE_LIST_COMMAND_INIT:
        {
            pChListData->u8CurrentPage = u16ActiveProgOrder / CHANNEL_LIST_PAGE_NUM;
            u16SrvPageCurIndex = u16ActiveProgOrder % CHANNEL_LIST_PAGE_NUM;
            if (u16TotalSrvCount == 0)
                MApp_ZUI_API_SetFocus(HWND_INVALID);
            else
                MApp_ZUI_API_SetFocus(
                    _MApp_ZUI_ACT_ChannelListIndexMapToWindow(u16SrvPageCurIndex));
            pChListData->u16ChCountOfCurPage = _MApp_FavoriteList_GetOnePagePositionByPageNum((EN_SERVICE_TYPE)pChListData->u8ServiceType, pChListData->u16PageListIndex, pChListData->u8CurrentPage);
        }
        break;

        case FAVORITE_LIST_COMMAND_UP:
        {
            if (u16SrvPageCurIndex >= u16ShiftProgIndex)
            {
                //in the same page movement
                u16SrvPageCurIndex -= u16ShiftProgIndex;
                MApp_ZUI_API_SetFocus(
                    _MApp_ZUI_ACT_ChannelListIndexMapToWindow(u16SrvPageCurIndex));
                return;
            }
            if (pChListData->u8CurrentPage == 0)
            {
                //first page, move to last page
                pChListData->u8CurrentPage= (u16TotalSrvCount - 1) / CHANNEL_LIST_PAGE_NUM;
                pChListData->u16ChCountOfCurPage = _MApp_FavoriteList_GetOnePagePositionByPageNum((EN_SERVICE_TYPE)pChListData->u8ServiceType, pChListData->u16PageListIndex, pChListData->u8CurrentPage);
                u16SrvPageCurIndex = pChListData->u16ChCountOfCurPage - 1;
                MApp_ZUI_API_SetFocus(
                    _MApp_ZUI_ACT_ChannelListIndexMapToWindow(u16SrvPageCurIndex));
                if (u16TotalSrvCount > CHANNEL_LIST_PAGE_NUM)
                {
                    MApp_ZUI_API_InvalidateAllSuccessors(HWND_CHLIST_LIST_PANE);
                }
                return;
            }
            //move to prev page
            pChListData->u8CurrentPage--;
            pChListData->u16ChCountOfCurPage = _MApp_FavoriteList_GetOnePagePositionByPageNum((EN_SERVICE_TYPE)pChListData->u8ServiceType, pChListData->u16PageListIndex, pChListData->u8CurrentPage);
            u16SrvPageCurIndex = (u16SrvPageCurIndex + CHANNEL_LIST_PAGE_NUM - u16ShiftProgIndex) % CHANNEL_LIST_PAGE_NUM;
            MApp_ZUI_API_SetFocus(
                _MApp_ZUI_ACT_ChannelListIndexMapToWindow(u16SrvPageCurIndex));
            MApp_ZUI_API_InvalidateAllSuccessors(HWND_CHLIST_LIST_PANE);
        }
        break;

        case FAVORITE_LIST_COMMAND_DOWN:
        {
            U16 u16PageLastIndex;
            if ((u16SrvPageCurIndex+u16ShiftProgIndex) < pChListData->u16ChCountOfCurPage)
            {
                //in the same page movement
                u16SrvPageCurIndex += u16ShiftProgIndex;
                MApp_ZUI_API_SetFocus(
                    _MApp_ZUI_ACT_ChannelListIndexMapToWindow(u16SrvPageCurIndex));
                return;
            }
            u16PageLastIndex = (pChListData->u8CurrentPage * CHANNEL_LIST_PAGE_NUM) + pChListData->u16ChCountOfCurPage;
            if (u16PageLastIndex == u16TotalSrvCount)
            {
                //move to first page
                pChListData->u8CurrentPage = 0;
                pChListData->u16ChCountOfCurPage = _MApp_FavoriteList_GetOnePagePositionByPageNum((EN_SERVICE_TYPE)pChListData->u8ServiceType, pChListData->u16PageListIndex, pChListData->u8CurrentPage);
                MApp_ZUI_API_SetFocus(
                    _MApp_ZUI_ACT_ChannelListIndexMapToWindow(0));
                if (u16TotalSrvCount > CHANNEL_LIST_PAGE_NUM)
                {
                    MApp_ZUI_API_InvalidateAllSuccessors(HWND_CHLIST_LIST_PANE);
                }
                return;
            }
            //move to next page
            pChListData->u8CurrentPage++;
            pChListData->u16ChCountOfCurPage = _MApp_FavoriteList_GetOnePagePositionByPageNum((EN_SERVICE_TYPE)pChListData->u8ServiceType, pChListData->u16PageListIndex, pChListData->u8CurrentPage);
            u16SrvPageCurIndex = (u16SrvPageCurIndex + u16ShiftProgIndex) % CHANNEL_LIST_PAGE_NUM;
            MApp_ZUI_API_SetFocus(
                _MApp_ZUI_ACT_ChannelListIndexMapToWindow(u16SrvPageCurIndex));
            MApp_ZUI_API_InvalidateAllSuccessors(HWND_CHLIST_LIST_PANE);
        }
        break;

        case FAVORITE_LIST_COMMAND_PRVPAGE:
        {
            if (pChListData->u8CurrentPage == 0)
            {
                if (u16SrvPageCurIndex > 0)
                {
                    //focus the first item
                    MApp_ZUI_API_SetFocus(
                        _MApp_ZUI_ACT_ChannelListIndexMapToWindow(0));
                    return;
                }
                else
                {
                    //move to last page last item
                    pChListData->u8CurrentPage= (u16TotalSrvCount - 1) / CHANNEL_LIST_PAGE_NUM;
                    pChListData->u16ChCountOfCurPage = _MApp_FavoriteList_GetOnePagePositionByPageNum((EN_SERVICE_TYPE)pChListData->u8ServiceType, pChListData->u16PageListIndex, pChListData->u8CurrentPage);
                    u16SrvPageCurIndex = pChListData->u16ChCountOfCurPage - 1;
                    MApp_ZUI_API_SetFocus(
                        _MApp_ZUI_ACT_ChannelListIndexMapToWindow(u16SrvPageCurIndex));
                    if (u16TotalSrvCount > CHANNEL_LIST_PAGE_NUM)
                    {
                        MApp_ZUI_API_InvalidateAllSuccessors(HWND_CHLIST_LIST_PANE);
                    }
                    return;
                }
            }
            pChListData->u8CurrentPage--;
            pChListData->u16ChCountOfCurPage = CHANNEL_LIST_PAGE_NUM;
            MApp_ZUI_API_InvalidateAllSuccessors(HWND_CHLIST_LIST_PANE);
        }
        break;

        case FAVORITE_LIST_COMMAND_NEXTPAGE:
        {
            U8 u8LastPage = (u16TotalSrvCount - 1) / CHANNEL_LIST_PAGE_NUM;
            if (u8LastPage == pChListData->u8CurrentPage)
            {
                //the last page
                if (u16SrvPageCurIndex == (pChListData->u16ChCountOfCurPage-1))
                {
                    //the last item, move to first page
                    pChListData->u8CurrentPage = 0;
                    pChListData->u16ChCountOfCurPage = _MApp_FavoriteList_GetOnePagePositionByPageNum((EN_SERVICE_TYPE)pChListData->u8ServiceType, pChListData->u16PageListIndex, pChListData->u8CurrentPage);
                    MApp_ZUI_API_SetFocus(
                        _MApp_ZUI_ACT_ChannelListIndexMapToWindow(0));
                    if (u16TotalSrvCount > CHANNEL_LIST_PAGE_NUM)
                    {
                        MApp_ZUI_API_InvalidateAllSuccessors(HWND_CHLIST_LIST_PANE);
                    }
                    else
                    {
                    }
                    return;
                }
                else
                {
                    //focus the last item
                    u16SrvPageCurIndex = pChListData->u16ChCountOfCurPage - 1;
                    MApp_ZUI_API_SetFocus(
                        _MApp_ZUI_ACT_ChannelListIndexMapToWindow(u16SrvPageCurIndex));
                    return;
                }
            }
            //move to next page
            pChListData->u8CurrentPage++;
            pChListData->u16ChCountOfCurPage = _MApp_FavoriteList_GetOnePagePositionByPageNum((EN_SERVICE_TYPE)pChListData->u8ServiceType, pChListData->u16PageListIndex, pChListData->u8CurrentPage);
            if (u16SrvPageCurIndex >= pChListData->u16ChCountOfCurPage)
            {
                u16SrvPageCurIndex = pChListData->u16ChCountOfCurPage - 1;
            }
            MApp_ZUI_API_SetFocus(
                _MApp_ZUI_ACT_ChannelListIndexMapToWindow(u16SrvPageCurIndex));
            MApp_ZUI_API_InvalidateAllSuccessors(HWND_CHLIST_LIST_PANE);
        }
        break;
    }
}

static void _MApp_FavoriteList_Init(U8 u8ServiceType)
{
    U16 u16Index,u16Ordinal;

    BOOLEAN bFind = FALSE;
    pChListData->u8ServiceType = u8ServiceType;
    FAVORITE_LIST_DBINFO(printf("UI_MApp_FavoriteList_Init: u8ServiceType=%bu\n", u8ServiceType));
    pChListData->u16TotalChCount = msAPI_CHPROC_CM_CountFavoriteProgram((MEMBER_SERVICETYPE)pChListData->u8ServiceType);
    pChListData->u16CurCh = msAPI_CHPROC_CM_GetCurrentOrdinal((MEMBER_SERVICETYPE)u8ServiceType, E_PROGACESS_INCLUDE_VISIBLE_ONLY);
    u16Ordinal = msAPI_CHPROC_CM_GetFirstFavoriteOrdinal(E_SERVICETYPE_UNITED_TV, TRUE);
    for( u16Index=0; u16Index < pChListData->u16TotalChCount; u16Index++ )
    {
        if(pChListData->u16CurCh == u16Ordinal)
        {
            pChListData->u16CurCh = u16Index;
            bFind = TRUE;
            break;
        }
        else
        {
            u16Ordinal = msAPI_CHPROC_CM_GetNextFavoriteOrdinal(E_SERVICETYPE_UNITED_TV, u16Ordinal, TRUE);
        }
    }

    if(!bFind)
    {   // when current program not set Favorite program, set focus to position 0 on Favorite List page.
        pChListData->u16CurCh = 0; // reset
    }

    FAVORITE_LIST_DBINFO(printf("pChListData->u16TotalChCount=%u\n", pChListData->u16TotalChCount));
    FAVORITE_LIST_DBINFO(printf("pChListData->u16CurCh=%u\n", pChListData->u16CurCh));

    _MApp_FavoriteList_Handler(pChListData->u16CurCh, 0, pChListData->u16TotalChCount,  FAVORITE_LIST_COMMAND_INIT);
}

///////////////////////////////////////////////////////////////////////

extern BOOLEAN _MApp_ZUI_API_AllocateVarData(void);



void MApp_ZUI_ACT_AppShowChannelList(void)
{
    HWND wnd;
    RECT rect;
    E_OSD_ID osd_id = E_OSD_CHANNEL_LIST;

    g_GUI_WindowList = GetWindowListOfOsdTable(osd_id);
    g_GUI_WinDrawStyleList = GetWindowStyleOfOsdTable(osd_id);
    g_GUI_WindowPositionList = GetWindowPositionOfOsdTable(osd_id);
#if ZUI_ENABLE_ALPHATABLE
    g_GUI_WinAlphaDataList = GetWindowAlphaDataOfOsdTable(osd_id);
#endif
    HWND_MAX = GetWndMaxOfOsdTable(osd_id);
    OSDPAGE_BLENDING_ENABLE = IsBlendingEnabledOfOsdTable(osd_id);
    OSDPAGE_BLENDING_VALUE = GetBlendingValueOfOsdTable(osd_id);

    _enTargetState = STATE_OSDPAGE_CLEAN_UP;

    if (!_MApp_ZUI_API_AllocateVarData())
    {
        ZUI_DBG_FAIL(printf("[ZUI]ALLOC\n"));
        ABORT();
        return;
    }


    //RECT_SET(rect, ((g_IPanel.HStart()+3)&0xFFFC), 1, g_IPanel.Width(), g_IPanel.Height());
    RECT_SET(rect,
        ZUI_CHANNEL_LIST_XSTART, ZUI_CHANNEL_LIST_YSTART,
        ZUI_CHANNEL_LIST_WIDTH, ZUI_CHANNEL_LIST_HEIGHT);

    if (!MApp_ZUI_API_InitGDI(&rect))
    {
        ZUI_DBG_FAIL(printf("[ZUI]GDIINIT\n"));
        ABORT();
        return;
    }

    //////////////////////////////
    // init internal data structre, before ZUI create message...
    _ZUI_FREE(pChListData);
    pChListData = (CHANNEL_LIST_DATA_STRUCT*)_ZUI_MALLOC(
        sizeof(CHANNEL_LIST_DATA_STRUCT));
    if (pChListData == 0)
    {
        ZUI_DBG_FAIL(printf("[ZUI]ACHLIST\n"));
        ABORT();
        return;
    }
    //////////////////////////////

    for (wnd = 0; wnd < HWND_MAX; wnd++)
    {
        //printf("create msg: %lu\n", (U32)wnd);
        MApp_ZUI_API_SendMessage(wnd, MSG_CREATE, 0);
    }

    switch (_eChannelListMode)
    {
        case  MODE_CHLIST_RADIO_FAV:
            _MApp_FavoriteList_Init(SERVICE_TYPE_RADIO);
            break;
        case MODE_CHLIST_TV_FAV:
            #if ENABLE_SBTVD_BRAZIL_APP
            if(msAPI_ATV_GetCurrentAntenna() == ANT_CATV)
                _MApp_FavoriteList_Init(SERVICE_TYPE_ATV);
            else
            #endif
            _MApp_FavoriteList_Init(SERVICE_TYPE_TV);
            break;
        case MODE_CHLIST_RADIO:
            _MApp_ChannelList_Init(SERVICE_TYPE_RADIO);
            break;
        case MODE_CHLIST_TV:
#if ENABLE_SBTVD_BRAZIL_APP
            if(msAPI_ATV_GetCurrentAntenna() == ANT_CATV)
                _MApp_ChannelList_Init(SERVICE_TYPE_ATV);
            else
                _MApp_ChannelList_Init(SERVICE_TYPE_TV);
#else
            _MApp_ChannelList_Init(SERVICE_TYPE_TV);
#endif
            break;
#if  NTV_FUNCTION_ENABLE
            case MODE_NETWORK_CHLIST_TV:
            {
                U8 k;
                u8TotalNetWorkNum = 0;

                for(k=0;k<MAX_NETWOEK_NUMBER;k++)
                {
                    if(msAPI_CM_IS_NorwegianNetwork(k))
                    {
                        u8TotalNetWorkNum++;
                    }
                }
                //printf(">>>>>>>>>>>> xxxxxxx  MODE_NETWORK_CHLIST_TV\n");

                //_MApp_ChannelList_Init(SERVICE_TYPE_TV);

            }
            break;
#endif

    }


    MApp_ZUI_API_ShowWindow(HWND_MAINFRAME, SW_SHOW);
#if(UI_SKIN_SEL!=UI_SKIN_1366X768X565_HAIER_CN) // cus_xm helen modify 20120809
    if(pChListData->u16TotalChCount >CHANNEL_LIST_PAGE_NUM)
    {
        MApp_ZUI_API_ShowWindow(HWND_CHLIST_BOTTOM_HALF_PAGE_UP_BTN, SW_SHOW);
        MApp_ZUI_API_ShowWindow(HWND_CHLIST_BOTTOM_HALF_PAGE_DOWN_BTN, SW_SHOW);
    }
    else
    {
        MApp_ZUI_API_ShowWindow(HWND_CHLIST_BOTTOM_HALF_PAGE_UP_BTN, SW_HIDE);
        MApp_ZUI_API_ShowWindow(HWND_CHLIST_BOTTOM_HALF_PAGE_DOWN_BTN, SW_HIDE);
    }
#endif
    MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_OPEN, E_ZUI_STATE_RUNNING);

}


//////////////////////////////////////////////////////////
// Key Handler

BOOLEAN MApp_ZUI_ACT_ExecuteChannelListAction(U16 act)
{
    if (pChListData == 0)
    {
        ZUI_DBG_FAIL(printf("[ZUI]ECHLIST\n"));
        ABORT();
        return TRUE;
    }

    switch (act)
    {
        case EN_EXE_CLOSE_CURRENT_OSD:
#if 0//NTV_FUNCTION_ENABLE // wait to do
            if (MApp_ZUI_API_IsWindowVisible(HWND_NET_CHLIST_BG_PANE))
            {
                if(msAPI_CM_Get_FavoriteNetwork()==INVALID_NETWORKINDEX)
                {
                    msAPI_CM_Set_FavoriteNetwork(0);
                    msAPI_CM_RestoreLCN();
                    msAPI_CM_ArrangeDataManager(TRUE,FALSE);
                    if(OSD_COUNTRY_SETTING == OSD_COUNTRY_NORWAY && MApp_Get_ScanGoRegion_Status())
                    {
                        MApp_Set_ScanGoRegion_Status(FALSE);
                        if(msAPI_CM_CountProgram(msAPI_CM_GetCurrentServiceType(), E_PROGACESS_INCLUDE_NOT_VISIBLE_ALSO) > 0)
                        {
                            MApp_ChannelChange_EnableChannel();
                        }
                    }
                }
#if 1//20100222 fix region select
                else if(MApp_DTV_Scan_GetSelectFavoriteNetwork() ==INVALID_NETWORKINDEX)
                {
                    MApp_DTV_Scan_SetSelectFavoriteNetwork(msAPI_CM_Get_FavoriteNetwork());
                    msAPI_CM_ArrangeDataManager(TRUE,FALSE);
                    if(OSD_COUNTRY_SETTING == OSD_COUNTRY_NORWAY && MApp_Get_ScanGoRegion_Status())
                    {
                        MApp_Set_ScanGoRegion_Status(FALSE);
                        if(msAPI_CM_CountProgram(msAPI_CM_GetCurrentServiceType(), E_PROGACESS_INCLUDE_NOT_VISIBLE_ALSO) > 0)
                        {
                            MApp_ChannelChange_EnableChannel();
                        }
                    }
                }
#endif
            }
#endif
            MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
            _enTargetState = STATE_OSDPAGE_CLEAN_UP;
            return TRUE;

        case EN_EXE_POWEROFF:
            MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
            _enTargetState = STATE_OSDPAGE_GOTO_STANDBY;
            return TRUE;

        case EN_EXE_CHLIST_UP:
            if (pChListData->u16TotalChCount == 0)
            {
                return TRUE;
            }

            if (_MApp_ZUI_ACT_IsFavMode())
            {
                _MApp_FavoriteList_Handler(0, 1, pChListData->u16TotalChCount,  FAVORITE_LIST_COMMAND_UP);
            }
            else
            {
                _MApp_ChannelList_Handler(0, 1, pChListData->u16TotalChCount,  CHANNEL_LIST_COMMAND_UP);
            }
            return TRUE;

        case EN_EXE_CHLIST_DOWN:
            if (pChListData->u16TotalChCount == 0)
            {
                return TRUE;
            }

            if (_MApp_ZUI_ACT_IsFavMode())
            {

                _MApp_FavoriteList_Handler(0, 1, pChListData->u16TotalChCount,  FAVORITE_LIST_COMMAND_DOWN);
            }
            else
            {
                _MApp_ChannelList_Handler(0, 1, pChListData->u16TotalChCount,  CHANNEL_LIST_COMMAND_DOWN);
            }
            return TRUE;

        case EN_EXE_CHLIST_PAGE_UP:
            if (pChListData->u16TotalChCount == 0)
            {
                return TRUE;
            }

            if (_MApp_ZUI_ACT_IsFavMode())
            {
                _MApp_FavoriteList_Handler(0, CHANNEL_LIST_PAGE_NUM, pChListData->u16TotalChCount,  FAVORITE_LIST_COMMAND_PRVPAGE);
            }
            else
            {
                _MApp_ChannelList_Handler(0, CHANNEL_LIST_PAGE_NUM, pChListData->u16TotalChCount,  CHANNEL_LIST_COMMAND_PRVPAGE);
            }
            return TRUE;

        case EN_EXE_CHLIST_PAGE_DOWN:
            if (pChListData->u16TotalChCount == 0)
            {
                return TRUE;
            }

            if (_MApp_ZUI_ACT_IsFavMode())
            {
                _MApp_FavoriteList_Handler(0, CHANNEL_LIST_PAGE_NUM, pChListData->u16TotalChCount,  FAVORITE_LIST_COMMAND_NEXTPAGE);
            }
            else
            {
                _MApp_ChannelList_Handler(0, CHANNEL_LIST_PAGE_NUM, pChListData->u16TotalChCount,  CHANNEL_LIST_COMMAND_NEXTPAGE);
            }
            return TRUE;

        case EN_EXE_CHLIST_SELECT:
            {
                U16 u16ListOrdinal;
                U8 u16SrvPageCurIndex;

                if (pChListData->u16TotalChCount == 0)
                {
                    return TRUE;
                }
                 u16SrvPageCurIndex = _MApp_ZUI_ACT_ChannelListWindowMapToIndex(      MApp_ZUI_API_GetFocus());
                if (_MApp_ZUI_ACT_IsFavMode())
                {
                    u16ListOrdinal = pChListData->u16PageListIndex[u16SrvPageCurIndex];
                }
                else
                {
                    u16ListOrdinal = pChListData->u8CurrentPage*CHANNEL_LIST_PAGE_NUM + u16SrvPageCurIndex;
                }

                #if ENABLE_PVR
                {
                    MEMBER_SERVICETYPE newCMtype;

                    msAPI_CHPROC_CM_GetAttributeOfOrdinal((MEMBER_SERVICETYPE)pChListData->u8ServiceType, u16ListOrdinal, (BYTE *)&newCMtype, E_SERVICE_ATTR_TYPE, E_PROGACESS_INCLUDE_VISIBLE_ONLY);
                    if(MApp_ZUI_ACT_PVR_Check_Switch_Channel(newCMtype, u16ListOrdinal) == FALSE)
                    {
                        return TRUE;
                    }
                }
                #endif
                msAPI_Scaler_SetBlueScreen(ENABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW); //Mantis 0241544 fixed

                _MApp_ChannelList_ChannelChange(u16ListOrdinal, pChListData->u8ServiceType, FALSE, E_PROGACESS_INCLUDE_VISIBLE_ONLY);

#if ENABLE_SBTVD_BRAZIL_APP
                if(msAPI_ATV_GetCurrentAntenna() == ANT_CATV)
                    pChListData->u16CurCh = msAPI_CHPROC_CM_GetCurrentOrdinal(E_SERVICETYPE_ATV, E_PROGACESS_INCLUDE_VISIBLE_ONLY);
                else
                    pChListData->u16CurCh = msAPI_CHPROC_CM_GetCurrentOrdinal(E_SERVICETYPE_UNITED_TV, E_PROGACESS_INCLUDE_VISIBLE_ONLY);
#else
                pChListData->u16CurCh = msAPI_CHPROC_CM_GetCurrentOrdinal(E_SERVICETYPE_UNITED_TV, E_PROGACESS_INCLUDE_VISIBLE_ONLY);
#endif
                if (_MApp_ZUI_ACT_IsFavMode() == FALSE)
                {
                    MApp_ZUI_API_InvalidateAllSuccessors(HWND_CHLIST_LIST_PANE);
                }
            }
            return TRUE;

        case EN_EXE_GOTO_MAINMENU:
#if 0//NTV_FUNCTION_ENABLE // wait to do
            if (MApp_ZUI_API_IsWindowVisible(HWND_NET_CHLIST_BG_PANE))
            {
                if(msAPI_CM_Get_FavoriteNetwork()==INVALID_NETWORKINDEX)
                {
                    msAPI_CM_Set_FavoriteNetwork(0);
                    msAPI_CM_RestoreLCN();
                    msAPI_CM_ArrangeDataManager(TRUE,FALSE);
                    if(OSD_COUNTRY_SETTING == OSD_COUNTRY_NORWAY && MApp_Get_ScanGoRegion_Status())
                    {
                        MApp_Set_ScanGoRegion_Status(FALSE);
                        if(msAPI_CM_CountProgram(msAPI_CM_GetCurrentServiceType(), E_PROGACESS_INCLUDE_NOT_VISIBLE_ALSO) > 0)
                        {
                            MApp_ChannelChange_EnableChannel();
                        }
                    }
                }
#if 1//20100222 fix region select
                else if(MApp_DTV_Scan_GetSelectFavoriteNetwork() ==INVALID_NETWORKINDEX)
                {
                    MApp_DTV_Scan_SetSelectFavoriteNetwork(msAPI_CM_Get_FavoriteNetwork());
                    msAPI_CM_ArrangeDataManager(TRUE,FALSE);
                    if(OSD_COUNTRY_SETTING == OSD_COUNTRY_NORWAY && MApp_Get_ScanGoRegion_Status())
                    {
                        MApp_Set_ScanGoRegion_Status(FALSE);
                        if(msAPI_CM_CountProgram(msAPI_CM_GetCurrentServiceType(), E_PROGACESS_INCLUDE_NOT_VISIBLE_ALSO) > 0)
                        {
                            MApp_ChannelChange_EnableChannel();
                        }
                    }
                }
#endif
            }
#endif
            MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
            _enTargetState = STATE_OSDPAGE_GOTO_MAIN_MENU;
            return TRUE;
#if 0 //NTV_FUNCTION_ENABLE //wait to do
         case EN_EXE_NETWORK_LIST_SELECT:
            {
                U8 u8FavIdx=0;

                u8FavIdx=_MApp_ZUI_ACT_FavouriteRegionWindowMapToIndex(MApp_ZUI_API_GetFocus());
                msAPI_CM_Set_FavoriteNetwork(ValidNetID[u8FavIdx]);
#if 1//20100222 fix region select
                MApp_DTV_Scan_SetSelectFavoriteNetwork(ValidNetID[u8FavIdx]);
#endif
                MApp_ZUI_ACT_ExecuteChannelListAction(EN_EXE_CLOSE_CURRENT_OSD);
                {
                    msAPI_CM_RestoreLCN();
                    msAPI_CM_ArrangeDataManager(TRUE,FALSE);
                    if(OSD_COUNTRY_SETTING == OSD_COUNTRY_NORWAY && MApp_Get_ScanGoRegion_Status())
                    {
                        MApp_Set_ScanGoRegion_Status(FALSE);
                        if(msAPI_CM_CountProgram(msAPI_CM_GetCurrentServiceType(), E_PROGACESS_INCLUDE_NOT_VISIBLE_ALSO) > 0)
                        {
                            MApp_ChannelChange_EnableChannel();
                        }
                    }
                }
            }
            return TRUE;
         case EN_EXE_NETWORK_LIST_EXIT:
            {
                if(msAPI_CM_Get_FavoriteNetwork()==INVALID_NETWORKINDEX)
                {
                    msAPI_CM_Set_FavoriteNetwork(0);
                    msAPI_CM_RestoreLCN();
                    msAPI_CM_ArrangeDataManager(TRUE,FALSE);
                    if(OSD_COUNTRY_SETTING == OSD_COUNTRY_NORWAY && MApp_Get_ScanGoRegion_Status())
                    {
                        MApp_Set_ScanGoRegion_Status(FALSE);
                        if(msAPI_CM_CountProgram(msAPI_CM_GetCurrentServiceType(), E_PROGACESS_INCLUDE_NOT_VISIBLE_ALSO) > 0)
                        {
                            MApp_ChannelChange_EnableChannel();
                        }
                    }
                }
                else
                {

                }
                MApp_ZUI_ACT_ExecuteChannelListAction(EN_EXE_CLOSE_CURRENT_OSD);

            }
            return TRUE;

            case EN_EXE_NETWORK_CHLIST_UP:
            {

                U8 u8FavIdx=0;
                MApp_ZUI_API_ResetTimer(HWND_CHLIST_LIST_PANE, 0);
                u8FavIdx=_MApp_ZUI_ACT_FavouriteRegionWindowMapToIndex(MApp_ZUI_API_GetFocus());
                if(u8FavIdx == 0)
                {
                    return TRUE;
                }
                else
                {
                    return FALSE;
                }
            }
            case EN_EXE_NETWORK_CHLIST_DOWN:
            {
                U8 u8FavIdx=0;

                MApp_ZUI_API_ResetTimer(HWND_CHLIST_LIST_PANE, 0);

                MApp_ZUI_API_ResetTimer(HWND_CHLIST_LIST_PANE, 0);
                u8FavIdx=_MApp_ZUI_ACT_FavouriteRegionWindowMapToIndex(MApp_ZUI_API_GetFocus());
                if(u8FavIdx == u8TotalNetWorkNum-1)
                {
                   return TRUE;
                }
                else
                {
                   return FALSE;
                }
            }
#endif

    }
    return FALSE;
}


BOOLEAN MApp_ZUI_ACT_HandleChannelListKey(VIRTUAL_KEY_CODE key)
{
    //note: this function will be called in running state

    //reset timer if any key
    MApp_ZUI_API_ResetTimer(HWND_CHLIST_LIST_PANE, 0);

    switch(key)
    {
        case VK_EXIT:
        case VK_CHANNEL_LIST:
        case VK_CHANNEL_FAV_LIST:
            MApp_ZUI_ACT_ExecuteChannelListAction(EN_EXE_CLOSE_CURRENT_OSD);
            return TRUE;
        case VK_POWER:
            MApp_ZUI_ACT_ExecuteChannelListAction(EN_EXE_POWEROFF);
            return TRUE;
/*
        case VK_UP:
            MApp_ZUI_API_SetTimer(HWND_CHLIST_BOTTOM_HALF_UP_ARROW, 0, BUTTONANICLICK_PERIOD);
            MApp_ZUI_API_InvalidateWindow(HWND_CHLIST_BOTTOM_HALF_UP_ARROW);
            break;
        case VK_DOWN:
            MApp_ZUI_API_SetTimer(HWND_CHLIST_BOTTOM_HALF_DOWN_ARROW, 0, BUTTONANICLICK_PERIOD);
            MApp_ZUI_API_InvalidateWindow(HWND_CHLIST_BOTTOM_HALF_DOWN_ARROW);
            break;
            */
        case VK_SELECT:
            MApp_ZUI_API_SetTimer(HWND_CHLIST_BOTTOM_HALF_OK_BTN, 0, BUTTONANICLICK_PERIOD);
            MApp_ZUI_API_InvalidateWindow(HWND_CHLIST_BOTTOM_HALF_OK_BTN);
            break;

        case VK_MENU:
            MApp_ZUI_ACT_ExecuteChannelListAction(EN_EXE_GOTO_MAINMENU);
            return TRUE;

        default:
            break;

    }
    return FALSE;
}

void MApp_ZUI_ACT_TerminateChannelList(void)
{
    ZUI_MSG(printf("[]term:chlist\n");)
    _ZUI_FREE(pChListData);
    MApp_OSDPage_SetState(_enTargetState);
}

LPTSTR MApp_ZUI_ACT_GetChannelListDynamicText(HWND hwnd)
{
    U16 u16TempID = Empty;
    switch(hwnd)
    {
        case HWND_CHLIST_TOP_HALF_BANNER_TITLE:
            if (_eChannelListMode == MODE_CHLIST_RADIO_FAV ||
                _eChannelListMode == MODE_CHLIST_TV_FAV)
                u16TempID = en_str_Fav_ListText;
            else if (_eChannelListMode == MODE_CHLIST_RADIO)
                u16TempID = en_str_Radio_List_Text;
            else //if (_eChannelListMode == MODE_CHLIST_TV)
                u16TempID = en_str_TV_LIST_Text;
            break;

        case HWND_CHLIST_ITEM0_SCRAMBLE:
        case HWND_CHLIST_ITEM1_SCRAMBLE:
        case HWND_CHLIST_ITEM2_SCRAMBLE:
        case HWND_CHLIST_ITEM3_SCRAMBLE:
        case HWND_CHLIST_ITEM4_SCRAMBLE:
        case HWND_CHLIST_ITEM5_SCRAMBLE:
        case HWND_CHLIST_ITEM6_SCRAMBLE:
        case HWND_CHLIST_ITEM7_SCRAMBLE:
        case HWND_CHLIST_ITEM8_SCRAMBLE:
        case HWND_CHLIST_ITEM9_SCRAMBLE:
            {
                U8 u8VisIndex = _MApp_ZUI_ACT_ChannelListWindowMapToIndex(hwnd);
                U16 g_wProgramPosition;

                if (_MApp_ZUI_ACT_IsFavMode())
                {
                    g_wProgramPosition = pChListData->u16PageListIndex[u8VisIndex];
                    if (g_wProgramPosition == CHANNEL_LIST_INVALID_PROGINDEX)
                    {
                        break;
                    }
                }
                else
                {
                    g_wProgramPosition = pChListData->u8CurrentPage*CHANNEL_LIST_PAGE_NUM + u8VisIndex;
                    if (g_wProgramPosition >= pChListData->u16TotalChCount)
                    {
                        break;
                    }
                }
#if ENABLE_DTV
                {
                    LPTSTR str = CHAR_BUFFER;
                    MEMBER_SERVICETYPE bServiceType;
                    BOOLEAN bScramble;

                    msAPI_CHPROC_CM_GetAttributeOfOrdinal((MEMBER_SERVICETYPE)pChListData->u8ServiceType, g_wProgramPosition, ( BYTE *)&bServiceType, E_SERVICE_ATTR_TYPE, E_PROGACESS_INCLUDE_VISIBLE_ONLY);
                    bScramble = msAPI_CM_GetProgramAttribute(bServiceType,g_wProgramPosition, E_ATTRIBUTE_IS_SCRAMBLED);

                    if (bScramble == TRUE)
                    {
                        *str ++ = CHAR_S;
                    }
                    else
                    {
                        *str ++ = CHAR_SPACE;
                    }

                    *str = 0;

                    return CHAR_BUFFER;

                }
#else
                {
                    LPTSTR str = CHAR_BUFFER;
                    *str ++ = CHAR_SPACE;
                    *str = 0;
                    return CHAR_BUFFER;

                }
#endif

            }
            break;


        case HWND_CHLIST_ITEM0_TEXT:
        case HWND_CHLIST_ITEM1_TEXT:
        case HWND_CHLIST_ITEM2_TEXT:
        case HWND_CHLIST_ITEM3_TEXT:
        case HWND_CHLIST_ITEM4_TEXT:
        case HWND_CHLIST_ITEM5_TEXT:
        case HWND_CHLIST_ITEM6_TEXT:
        case HWND_CHLIST_ITEM7_TEXT:
        case HWND_CHLIST_ITEM8_TEXT:
        case HWND_CHLIST_ITEM9_TEXT:
            {
                U8 u8VisIndex = _MApp_ZUI_ACT_ChannelListWindowMapToIndex(hwnd);
                U16 g_wProgramPosition;
                if (_MApp_ZUI_ACT_IsFavMode())
                {
                    g_wProgramPosition = pChListData->u16PageListIndex[u8VisIndex];
                    if (g_wProgramPosition == CHANNEL_LIST_INVALID_PROGINDEX)
                        break;
                }
                else
                {
                    g_wProgramPosition = pChListData->u8CurrentPage*CHANNEL_LIST_PAGE_NUM + u8VisIndex;
                    if (g_wProgramPosition >= pChListData->u16TotalChCount)
                        break;
                     }
                {
                    LPTSTR str = CHAR_BUFFER;
#if ENABLE_DTV
                    if (_eChannelListMode == MODE_CHLIST_RADIO || _eChannelListMode == MODE_CHLIST_RADIO_FAV) //u8ServiceTypeForMenuStr == SERVICE_TYPE_RADIO)
                    {
                        U16 u16Number = msAPI_CM_GetLogicalChannelNumber((MEMBER_SERVICETYPE)SERVICE_TYPE_RADIO,g_wProgramPosition);
#if ENABLE_SBTVD_BRAZIL_APP
                        LOGICAL_CHANNEL_NUMBER LCN;
                        LCN.wLCN = (WORD)u16Number;
                        MApp_UlongToU16String((U32)LCN.stLCN.bPhysicalChannel, str, (S8)MApp_GetNoOfDigit((U32)LCN.stLCN.bPhysicalChannel));
                        str += (MApp_GetNoOfDigit((U32)LCN.stLCN.bPhysicalChannel));
                        *str ++ = CHAR_DOT;
                        MApp_UlongToU16String((U32)LCN.stLCN.bVirtualChannel, str, (S8)MApp_GetNoOfDigit((U32)LCN.stLCN.bVirtualChannel));
#else
                        MApp_ZUI_API_GetU16String(u16Number);//__MApp_UlongToString(u16Number, p_string_buffer, MApp_GetNoOfDigit(u16Number));
#endif
                        str += MApp_ZUI_API_Strlen(str);//u8_idx = __strlen(p_string_buffer);
                        *str++ = CHAR_SPACE; //p_string_buffer[u8_idx++] = CHAR_SPACE;
                        MApp_CharTable_GetServiceNameToUCS2((MEMBER_SERVICETYPE)SERVICE_TYPE_RADIO, g_wProgramPosition, str, KEEP_CONTROL_CODE_NONE);
                        str += MApp_ZUI_API_Strlen(str);
                    }
                    else //if (u8ServiceTypeForMenuStr == SERVICE_TYPE_TV)
#endif
                    {
                        MEMBER_SERVICETYPE bServiceType;
                        U16 u16Number = 0;
                        msAPI_CHPROC_CM_GetAttributeOfOrdinal((MEMBER_SERVICETYPE)pChListData->u8ServiceType, g_wProgramPosition, ( BYTE *)&bServiceType, E_SERVICE_ATTR_TYPE, E_PROGACESS_INCLUDE_VISIBLE_ONLY);
                        msAPI_CHPROC_CM_GetAttributeOfOrdinal((MEMBER_SERVICETYPE)pChListData->u8ServiceType, g_wProgramPosition, (BYTE*)&u16Number, E_SERVICE_ATTR_NUMBER, E_PROGACESS_INCLUDE_VISIBLE_ONLY);
                        //printf("CHANNELLIST_PROGRAMNUMBERNAMETEXT>> msAPI_ATV_GetActiveProgramCount() %bu\n", msAPI_ATV_GetActiveProgramCount());
                        //printf("g_wProgramPosition %u bServiceType %bu u16Number %u\n", g_wProgramPosition, bServiceType, u16Number);

                        if(msAPI_ATV_GetActiveProgramCount()==0 && bServiceType==E_SERVICETYPE_ATV)//Makes channel "0" when no ATV
                            u16Number=0;
#if ENABLE_DTV
                        if (bServiceType == E_SERVICETYPE_DTV)
                        {
#if ENABLE_SBTVD_BRAZIL_APP
                            LOGICAL_CHANNEL_NUMBER LCN;
                            LCN.wLCN = (WORD)u16Number;
                            MApp_UlongToU16String((U32)LCN.stLCN.bPhysicalChannel, str, (S8)MApp_GetNoOfDigit((U32)LCN.stLCN.bPhysicalChannel));
                            str += (MApp_GetNoOfDigit((U32)LCN.stLCN.bPhysicalChannel));
                            *str ++ = CHAR_DOT;
                            MApp_UlongToU16String((U32)LCN.stLCN.bVirtualChannel, str, (S8)MApp_GetNoOfDigit((U32)LCN.stLCN.bVirtualChannel));
#if ENABLE_SBTVD_BRAZIL_CM_APP
                            msAPI_CHPROC_CM_GetOrdinal_SerType_Position_Brazil(g_wProgramPosition,&bServiceType,&g_wProgramPosition);
#endif
#else
                            MApp_ZUI_API_GetU16String(u16Number); //__MApp_UlongToString(u16Number, p_string_buffer, MApp_GetNoOfDigit(u16Number));
#endif
                            str += MApp_ZUI_API_Strlen(str); //u8_idx = __strlen(p_string_buffer);
                            *str++ = CHAR_SPACE; //p_string_buffer[u8_idx++] = CHAR_SPACE;
                            MApp_CharTable_GetServiceNameToUCS2(bServiceType, g_wProgramPosition, str, KEEP_CONTROL_CODE_NONE);
                            str += MApp_ZUI_API_Strlen(str);
                        }
                        else if (bServiceType == E_SERVICETYPE_RADIO)
                        {
#if ENABLE_SBTVD_BRAZIL_APP
                            LOGICAL_CHANNEL_NUMBER LCN;
                            LCN.wLCN = (WORD)u16Number;
                            MApp_UlongToU16String((U32)LCN.stLCN.bPhysicalChannel, str, (S8)MApp_GetNoOfDigit((U32)LCN.stLCN.bPhysicalChannel));
                            str += (MApp_GetNoOfDigit((U32)LCN.stLCN.bPhysicalChannel));
                            *str ++ = CHAR_DOT;
                            MApp_UlongToU16String((U32)LCN.stLCN.bVirtualChannel, str, (S8)MApp_GetNoOfDigit((U32)LCN.stLCN.bVirtualChannel));
#if ENABLE_SBTVD_BRAZIL_CM_APP
                            msAPI_CHPROC_CM_GetOrdinal_SerType_Position_Brazil(g_wProgramPosition,&bServiceType,&g_wProgramPosition);
#endif
#else
                            MApp_ZUI_API_GetU16String(u16Number); //__MApp_UlongToString(u16Number, p_string_buffer, MApp_GetNoOfDigit(u16Number));
#endif
                            str += MApp_ZUI_API_Strlen(str); //u8_idx = __strlen(p_string_buffer);
                            *str++ = CHAR_SPACE; //p_string_buffer[u8_idx++] = CHAR_SPACE;
#if ENABLE_SBTVD_BRAZIL_CM_APP
                            MApp_CharTable_GetServiceNameToUCS2(bServiceType, g_wProgramPosition, str, KEEP_CONTROL_CODE_NONE);
#else
                            MApp_CharTable_GetServiceNameToUCS2(bServiceType, g_wProgramPosition-msAPI_CM_CountProgram(E_SERVICETYPE_DTV, E_PROGACESS_INCLUDE_VISIBLE_ONLY), str, KEEP_CONTROL_CODE_NONE);
#endif
                            str += MApp_ZUI_API_Strlen(str);
                        }
#if NORDIG_FUNC //for Nordig spec v2.0
                        else if (bServiceType == E_SERVICETYPE_DATA)
                        {
                            MApp_ZUI_API_GetU16String(u16Number); //__MApp_UlongToString(u16Number, p_string_buffer, MApp_GetNoOfDigit(u16Number));
                            str += MApp_ZUI_API_Strlen(str); //u8_idx = __strlen(p_string_buffer);
                            *str++ = CHAR_SPACE; //p_string_buffer[u8_idx++] = CHAR_SPACE;
                            MApp_CharTable_GetServiceNameToUCS2(bServiceType, g_wProgramPosition-msAPI_CM_CountProgram(E_SERVICETYPE_DTV, E_PROGACESS_INCLUDE_VISIBLE_ONLY)-msAPI_CM_CountProgram(E_SERVICETYPE_RADIO, E_PROGACESS_INCLUDE_VISIBLE_ONLY), str, KEEP_CONTROL_CODE_NONE);
                            str += MApp_ZUI_API_Strlen(str);
                        }
#endif
                        else
#endif
                        if (bServiceType == E_SERVICETYPE_ATV)
                        {
#if ENABLE_SBTVD_BRAZIL_APP
                            MApp_ZUI_API_GetU16String(u16Number+1);
#else
                            U8 u8Temp[MAX_STATION_NAME];
                            MApp_ZUI_API_GetU16String(u16Number+1); //__MApp_UlongToString(u16Number+1, p_string_buffer, MApp_GetNoOfDigit(u16Number+1)); //channel number start from 1
                            str += MApp_ZUI_API_Strlen(str); //u8_idx = __strlen(p_string_buffer);
                            *str++ = CHAR_SPACE; //p_string_buffer[u8_idx++] = CHAR_SPACE;
                            msAPI_ATV_GetStationName((BYTE)u16Number, u8Temp);
                            #if ENABLE_CUS_UI_SPEC
                            if((u8Temp[0] == 0) && (u8Temp[1] == 0))
                            {
                                U8 i;
                                for(i = 0;i<5; i++)
                                {
                                    u8Temp[i] = '_';
                                }
                                u8Temp[5] = '\0';
                                MApp_U8StringToU16String(u8Temp, str, 5); //for CUS UI SPEC.
                            }
                            else
                            #endif
                            {
                                MApp_U8StringToU16String(u8Temp, str, MAX_STATION_NAME);
                            }
                            str += MApp_ZUI_API_Strlen(str);
#endif
                        }
                    }

                    if ((str-CHAR_BUFFER) > 18)
                    {
                        (CHAR_BUFFER)[18] = 0;
                    }

                    return CHAR_BUFFER;

                }
            }
            break;

        default:
            break;

    }

    if (u16TempID != Empty)
        return MApp_ZUI_API_GetString(u16TempID);
    return 0; //for empty string....
}
#if ENABLE_DTV
static WORD Mapp_ZUI_ACT_Chlist_GetProgramPosition(U8 u8ServiceType, U16 wProgramPosition)
{
    if(u8ServiceType == SERVICE_TYPE_DTV)
    {
        return wProgramPosition;
    }
    else if(u8ServiceType == SERVICE_TYPE_RADIO)
    {
            return  wProgramPosition - msAPI_CM_CountProgram((MEMBER_SERVICETYPE)SERVICE_TYPE_DTV, E_PROGACESS_INCLUDE_VISIBLE_ONLY);
    }
#if NORDIG_FUNC //for Nordig Spec v2.0
    else if(u8ServiceType == SERVICE_TYPE_DATA)
    {
            return  wProgramPosition - msAPI_CM_CountProgram((MEMBER_SERVICETYPE)SERVICE_TYPE_DTV, E_PROGACESS_INCLUDE_VISIBLE_ONLY) - msAPI_CM_CountProgram((MEMBER_SERVICETYPE)SERVICE_TYPE_RADIO, E_PROGACESS_INCLUDE_VISIBLE_ONLY);
    }
#endif
    else
        return 0;
}
#endif
U16 MApp_ZUI_ACT_GetChannelListDynamicBitmap(HWND hwnd, DRAWSTYLE_TYPE ds_type)
{
    #if (ENABLE_CUS_UI_SPEC)
    UNUSED(hwnd);
    UNUSED(ds_type);
    return 0xFFFF; //for empty bitmap....
    #else
    switch(hwnd)
    {
        case HWND_CHLIST_ITEM0_TYPE:
        case HWND_CHLIST_ITEM1_TYPE:
        case HWND_CHLIST_ITEM2_TYPE:
        case HWND_CHLIST_ITEM3_TYPE:
        case HWND_CHLIST_ITEM4_TYPE:
        case HWND_CHLIST_ITEM5_TYPE:
        case HWND_CHLIST_ITEM6_TYPE:
        case HWND_CHLIST_ITEM7_TYPE:
        case HWND_CHLIST_ITEM8_TYPE:
        case HWND_CHLIST_ITEM9_TYPE:
            {
                U8 u8VisIndex = _MApp_ZUI_ACT_ChannelListWindowMapToIndex(hwnd);
                U16 g_wProgramPosition;
                if (_MApp_ZUI_ACT_IsFavMode())
                {
                    g_wProgramPosition = pChListData->u16PageListIndex[u8VisIndex];
                    if (g_wProgramPosition == CHANNEL_LIST_INVALID_PROGINDEX)
                        break;
                }
                else
                {
                    g_wProgramPosition = pChListData->u8CurrentPage*CHANNEL_LIST_PAGE_NUM + u8VisIndex;
                    if (g_wProgramPosition >= pChListData->u16TotalChCount)
                        break;
                }
                {
                    EN_SERVICE_TYPE u8Type;
                    BOOLEAN bSkip;
                    msAPI_CHPROC_CM_GetAttributeOfOrdinal((MEMBER_SERVICETYPE)pChListData->u8ServiceType, g_wProgramPosition, &bSkip, E_SERVICE_ATTR_SKIPPED, E_PROGACESS_INCLUDE_VISIBLE_ONLY);
                    msAPI_CHPROC_CM_GetAttributeOfOrdinal((MEMBER_SERVICETYPE)pChListData->u8ServiceType, g_wProgramPosition, (BYTE *)&u8Type, E_SERVICE_ATTR_TYPE, E_PROGACESS_INCLUDE_VISIBLE_ONLY);
                    if (ds_type == DS_FOCUS && !bSkip)
                    {
                        if (u8Type == SERVICE_TYPE_DTV)
                        {
                            return E_BMP_IDLE_IMG_ICON_DTV_FOCUS;
                        }
                        else if (u8Type == SERVICE_TYPE_RADIO)
                        {
                            return E_BMP_IDLE_IMG_ICON_RADIO_FOCUS;
                        }
#if NORDIG_FUNC //for Nordig spec v2.0
                        else if (u8Type == SERVICE_TYPE_DATA)
                        {
                            return E_BMP_IDLE_IMG_ICON_DATA_FOCUS;
                        }
#endif
                        else if (u8Type == SERVICE_TYPE_ATV)
                        {
#if ENABLE_SBTVD_BRAZIL_APP
                            if(msAPI_ATV_GetCurrentAntenna() == ANT_CATV)
                                return E_BMP_ICON_CATV_F;
                            else
                                return E_BMP_IDLE_IMG_ICON_ATV_FOCUS;
#else
                            return E_BMP_IDLE_IMG_ICON_ATV_FOCUS;
#endif
                        }
                    }
                    else
                    {
                        if (u8Type == SERVICE_TYPE_DTV)
                        {
                            return E_BMP_IDLE_IMG_ICON_DTV_UNFOCUS;
                        }
                        else if (u8Type == SERVICE_TYPE_RADIO)
                        {
                            return E_BMP_IDLE_IMG_ICON_RADIO_UNFOCUS;
                        }
#if NORDIG_FUNC //for Nordig spec v2.0
                        else if (u8Type == SERVICE_TYPE_DATA)
                        {
                            return E_BMP_IDLE_IMG_ICON_DATA_UNFOCUS;
                        }
#endif
                        else if (u8Type == SERVICE_TYPE_ATV)
                        {
#if ENABLE_SBTVD_BRAZIL_APP
                            if(msAPI_ATV_GetCurrentAntenna() == ANT_CATV)
                                return E_BMP_ICON_CATV_N;
                            else
                                return E_BMP_IDLE_IMG_ICON_ATV_UNFOCUS;
#else
                            return E_BMP_IDLE_IMG_ICON_ATV_UNFOCUS;
#endif
                        }
                    }
                }
            }
            break;

        case HWND_CHLIST_ITEM0_LOCK:
        case HWND_CHLIST_ITEM1_LOCK:
        case HWND_CHLIST_ITEM2_LOCK:
        case HWND_CHLIST_ITEM3_LOCK:
        case HWND_CHLIST_ITEM4_LOCK:
        case HWND_CHLIST_ITEM5_LOCK:
        case HWND_CHLIST_ITEM6_LOCK:
        case HWND_CHLIST_ITEM7_LOCK:
        case HWND_CHLIST_ITEM8_LOCK:
        case HWND_CHLIST_ITEM9_LOCK:
            {
                U8 u8VisIndex = _MApp_ZUI_ACT_ChannelListWindowMapToIndex(hwnd);
                U16 g_wProgramPosition;
                if (_MApp_ZUI_ACT_IsFavMode())
                {
                    g_wProgramPosition = pChListData->u16PageListIndex[u8VisIndex];
                    if (g_wProgramPosition == CHANNEL_LIST_INVALID_PROGINDEX)
                        break;
                }
                else
                {
                    g_wProgramPosition = pChListData->u8CurrentPage*CHANNEL_LIST_PAGE_NUM + u8VisIndex;
                    if (g_wProgramPosition >= pChListData->u16TotalChCount)
                        break;
                }
                {
                    BOOLEAN bLock;
                    BOOLEAN bSkip;
                    msAPI_CHPROC_CM_GetAttributeOfOrdinal((MEMBER_SERVICETYPE)pChListData->u8ServiceType, g_wProgramPosition, &bSkip, E_SERVICE_ATTR_SKIPPED, E_PROGACESS_INCLUDE_VISIBLE_ONLY);
                    msAPI_CHPROC_CM_GetAttributeOfOrdinal((MEMBER_SERVICETYPE)pChListData->u8ServiceType, g_wProgramPosition, &bLock, E_SERVICE_ATTR_LOCKED, E_PROGACESS_INCLUDE_VISIBLE_ONLY);
                    if (bLock)
                    {
                        if (ds_type == DS_FOCUS && !bSkip)
                        {
                            return E_BMP_IDLE_IMG_ICON_LOCK_FOCUS;
                        }
                        else
                        {
                            return E_BMP_IDLE_IMG_ICON_LOCK_UNFOCUS;
                        }
                    }

                }
            }
            break;

        case HWND_CHLIST_ITEM0_FAV:
        case HWND_CHLIST_ITEM1_FAV:
        case HWND_CHLIST_ITEM2_FAV:
        case HWND_CHLIST_ITEM3_FAV:
        case HWND_CHLIST_ITEM4_FAV:
        case HWND_CHLIST_ITEM5_FAV:
        case HWND_CHLIST_ITEM6_FAV:
        case HWND_CHLIST_ITEM7_FAV:
        case HWND_CHLIST_ITEM8_FAV:
        case HWND_CHLIST_ITEM9_FAV:
            {
                U8 u8VisIndex = _MApp_ZUI_ACT_ChannelListWindowMapToIndex(hwnd);
                U16 g_wProgramPosition;
                if (_MApp_ZUI_ACT_IsFavMode())
                {
                    g_wProgramPosition = pChListData->u16PageListIndex[u8VisIndex];
                    if (g_wProgramPosition == CHANNEL_LIST_INVALID_PROGINDEX)
                        break;
                }
                else
                {
                    g_wProgramPosition = pChListData->u8CurrentPage*CHANNEL_LIST_PAGE_NUM + u8VisIndex;
                    if (g_wProgramPosition >= pChListData->u16TotalChCount)
                        break;
                }
                {
                    BOOLEAN bFav;
                    BOOLEAN bSkip;
                    msAPI_CHPROC_CM_GetAttributeOfOrdinal((MEMBER_SERVICETYPE)pChListData->u8ServiceType, g_wProgramPosition, &bSkip, E_SERVICE_ATTR_SKIPPED, E_PROGACESS_INCLUDE_VISIBLE_ONLY);
                    msAPI_CHPROC_CM_GetAttributeOfOrdinal((MEMBER_SERVICETYPE)pChListData->u8ServiceType, g_wProgramPosition, &bFav, E_SERVICE_ATTR_FAVORITE, E_PROGACESS_INCLUDE_VISIBLE_ONLY);
                    if (bFav)
                    {
                        if (ds_type == DS_FOCUS && !bSkip)
                        {
                            return E_BMP_IDLE_IMG_ICON_FAVORITE_FOCUS;
                        }
                        else
                        {
                            return E_BMP_IDLE_IMG_ICON_FAVORITE_UNFOCUS;
                        }
                    }

                }
            }
            break;
        case HWND_CHLIST_ITEM0_SCRAMBLE:
        case HWND_CHLIST_ITEM1_SCRAMBLE:
        case HWND_CHLIST_ITEM2_SCRAMBLE:
        case HWND_CHLIST_ITEM3_SCRAMBLE:
        case HWND_CHLIST_ITEM4_SCRAMBLE:
        case HWND_CHLIST_ITEM5_SCRAMBLE:
        case HWND_CHLIST_ITEM6_SCRAMBLE:
        case HWND_CHLIST_ITEM7_SCRAMBLE:
        case HWND_CHLIST_ITEM8_SCRAMBLE:
        case HWND_CHLIST_ITEM9_SCRAMBLE:
            {
                U8 u8VisIndex = _MApp_ZUI_ACT_ChannelListWindowMapToIndex(hwnd);
                U16 g_wProgramPosition;

                if (_MApp_ZUI_ACT_IsFavMode())
                {
                    g_wProgramPosition = pChListData->u16PageListIndex[u8VisIndex];
                    if (g_wProgramPosition == CHANNEL_LIST_INVALID_PROGINDEX)
                    {
                        break;
                    }
                }
                else
                {
                    g_wProgramPosition = pChListData->u8CurrentPage*CHANNEL_LIST_PAGE_NUM + u8VisIndex;
                    if (g_wProgramPosition >= pChListData->u16TotalChCount)
                    {
                        break;
                    }
                }
#if ENABLE_DTV
                {
                    MEMBER_SERVICETYPE bServiceType;
                    BOOLEAN bScramble;
                    U16 u16CurPosition;
                    msAPI_CHPROC_CM_GetAttributeOfOrdinal((MEMBER_SERVICETYPE)pChListData->u8ServiceType, g_wProgramPosition, ( BYTE *)&bServiceType, E_SERVICE_ATTR_TYPE, E_PROGACESS_INCLUDE_VISIBLE_ONLY);
                    u16CurPosition=Mapp_ZUI_ACT_Chlist_GetProgramPosition(bServiceType, g_wProgramPosition );
                    bScramble = msAPI_CM_GetProgramAttribute(bServiceType,u16CurPosition, E_ATTRIBUTE_IS_SCRAMBLED);

                    if (bScramble == TRUE)
                    {
                        if(MApp_ZUI_API_GetFocus()+ 5 == hwnd)
                            return E_BMP_IDLE_IMG_ICON_SSL_FOCUS;
                        else
                            return E_BMP_IDLE_IMG_ICON_SSL_UNFOCUS;
                    }
                    else
                    {
                        return 0xFFFF;//empty bitmap....
                    }


                }
#else
                return 0xFFFF;//empty bitmap....
#endif

            }
            break;
        default:
            break;


    }

    return 0xFFFF; //for empty bitmap....
    #endif
}

OSD_COLOR MApp_ZUI_ACT_GetChannelListDynamicColor(HWND hwnd, DRAWSTYLE_TYPE type, OSD_COLOR colorOriginal)
{
    U16 u16SrvPageCurIndex;
    U16 g_wProgramPosition;
    UNUSED(type);

    u16SrvPageCurIndex = (U16)_MApp_ZUI_ACT_ChannelListWindowMapToIndex(hwnd);
	//SMC jayden.chen mask for Favlist OSD BG color 20130311
	/*
    if(_MApp_ZUI_ACT_IsFavMode())
    {
        return colorOriginal;
    }
    else
    */
    {
        g_wProgramPosition = (U16)(pChListData->u8CurrentPage*CHANNEL_LIST_PAGE_NUM) + u16SrvPageCurIndex;
    }

    if(g_wProgramPosition == pChListData->u16CurCh)
    {
        if(u16SrvPageCurIndex == (U16)_MApp_ZUI_ACT_ChannelListWindowMapToIndex( MApp_ZUI_API_GetFocus())) //is the high light program
            return CH_LIST_CURRENT_CN_TEXT_HL_COLOR;
        else
            return CH_LIST_CURRENT_CN_TEXT_COLOR;
    }

    return colorOriginal;
}
static void _MApp_ZUI_ACT_Chlist_GetTotalProgCount(U8 u8ServiceType)
{
    pChListData->u16TotalChCount = msAPI_CHPROC_CM_CountProgram((MEMBER_SERVICETYPE)u8ServiceType, E_PROGACESS_INCLUDE_VISIBLE_ONLY);
}
#undef MAPP_ZUI_ACTCHLIST_C
