////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#define MAPP_INPUTSOURCE_C

/********************************************************************************/
/*                    Header Files                                              */
/********************************************************************************/
#include <string.h>
#include <stdio.h>
#include "datatype.h"
#include "Board.h"
#include "msAPI_Global.h"
#include "apiXC.h"
#include "apiXC_Sys.h"
#include "drvXC_HDMI_if.h"
#include "apiXC_Hdmi.h"
#include "drvAVD.h"
#include "drvAUDIO.h"
#include "apiXC_Adc.h"

#include "debug.h"

#ifdef SCART_OUT_NEW_METHOD
#include "drvTVEncoder.h"
#endif
#if (ENABLE_CI)
#include "msAPI_CI.h" //**-- Italy CI Certificate --**//
#endif
#include "msAPI_Memory.h"


#include "msAPI_Mode.h"
#include "apiXC_Ace.h"

#include "msAPI_Video.h"
#include "apiXC_PCMonitor.h"
#include "msAPI_Global.h"
#include "apiXC_Dlc.h"
#include "MApp_RestoreToDefault.h"

#if (ENABLE_PWS)
  #include "drvPWS.h"
#endif

#include "msAPI_Timer.h"
#include "msAPI_MIU.h"
#include "msAPI_Tuner.h"

#include "msAPI_VD.h"
#include "msAPI_Tuning.h"
#include "msAPI_audio.h"
#include "msAPI_DrvInit.h"
#include "msAPI_Power.h"
#include "msAPI_ATVSystem.h"

#include "MApp_Init.h"
#include "MApp_MVDMode.h"
#include "MApp_PCMode.h"
#include "MApp_GlobalSettingSt.h"
#include "MApp_GlobalFunction.h"
#include "MApp_Key.h"
#include "MApp_InputSource.h"

#include "MApp_VDMode.h"
#include "MApp_GlobalVar.h"
#include "MApp_ChannelChange.h"
#include "MApp_Scaler.h"
#include "apiXC_Sys.h"

#if (ENABLE_DTV)
#include "mapp_si.h" //**-- Italy CI Certificate --**//
#include "mapp_demux.h"
#endif

#include "MApp_ATVProc.h"
#include "MApp_Audio.h"
#include "GPIO.h"

#include "MApp_MassStorage.h"
#if (ENABLE_TTX)
#include "msAPI_TTX.h"
#include "mapp_ttx.h"
#endif

#include "IF_Demodulator.h"

#include "MApp_UiMenuDef.h"
#include "MApp_BlockSys.h"
#include "MApp_ChannelList.h" //ZUI:

#if (ENABLE_SUBTITLE)
#include "MApp_Subtitle.h" //ZUI:
#endif

#include "MApp_TopStateMachine.h" //ZUI:
#include "MApp_InputSource_Main.h"

#if MCU_AEON_ENABLE
#include "drvCPU.h"
#endif

#include "HdmiSwitch.h"
#if MHEG5_ENABLE
#include "MApp_MHEG5_Main.h"
#endif
#if INPUT_SCART_USE_SV2
extern U8 g_u8IsScartRGB;
#endif

#include "MApp_MultiTasks.h"

#if 1 //def AP_COWORK
#include "MApp_APEngine.h"
#include "msAPI_APEngine.h"
#endif

#include "MApp_ZUI_Main.h"
#include "ZUI_tables_h.inl"
#include "ZUI_exefunc.h"

#if ENABLE_CEC
#include "msAPI_CEC.h"
#endif

#ifdef ENABLE_SELECT_NONESEARCH_CH
#include "MApp_TV.h"
#endif

#if (ENABLE_ATV_VCHIP)
#include "MApp_VChip.h"
#endif

#ifdef SCART_OUT_NEW_METHOD
extern void MDrv_VE_Set_SCART_ADC_BufferOut(void);
extern U8  gScart_1_OutMode;
#if (INPUT_SCART_VIDEO_COUNT >= 2)
extern U8  gScart_2_OutMode;
#endif
#endif

#if ENABLE_DDCCI
#include "drvDDC2BI.h"
#endif

#if (FRONTEND_IF_DEMODE_TYPE == MSTAR_VIF_MSB1210)
extern U8  gMSB1210ATVMode;
#endif

#if ENABLE_SBTVD_BRAZIL_APP
E_ANTENNA_SOURCE_TYPE enLastWatchAntennaType = ANTENNA_DTV_TYPE;
#endif

#if ENABLE_DDCCI
extern U8 MApp_DDC2BI_AlignControl(U8 *pDDCBuffData);
extern U8 MApp_DDC2BI_FactoryAdjustment(U8 *pDDCBuffData);
#endif

#if ENABLE_PVR
#include "MApp_PVR.h"
#endif

#if ENABLE_DMP
#include "MApp_DMP_Main.h"
#endif

#ifdef ENABLE_KTV
extern void MApp_KTV_InitKTVStatus(void);
#endif


#if(ENABLE_DTV)
extern BOOLEAN bDemodPowerOnInit;
#endif
BOOL g_isCVBS2=0;

extern THR_TBL_TYPE code AuSifInitThreshold[];
/********************************************************************************/
/*                   Macro                                                      */
/********************************************************************************/
#define SIGNAL_PATH_DBG(x) //x
#define INPUTSOURCE_DBG(y) //y
#define AIS_DETECT_DUTY 100//150 // ms

#define ATV_SCALER_DNR_BUF_LEN       (((1456UL*3+0x0F) & ~0x0F) * 581UL *2)

#define  SCART_ALWAYS_OUTPUT_ATV     0



code CVBS_OUTPUT_INFO  CVBS1_OUTPUT_Tbl[] =
{  //INPUT SOURCE                        CVBS1 OUTPUT
    {INPUT_SOURCE_TV,           INPUT_SOURCE_TV},
    {INPUT_SOURCE_CVBS,         INPUT_SOURCE_CVBS},
    {INPUT_SOURCE_CVBS2,        INPUT_SOURCE_CVBS2},
    {INPUT_SOURCE_SVIDEO,       INPUT_SOURCE_TV},
    {INPUT_SOURCE_YPBPR,        INPUT_SOURCE_NONE},
    {INPUT_SOURCE_VGA,          INPUT_SOURCE_NONE},
    {INPUT_SOURCE_SCART,        INPUT_SOURCE_TV},
    {INPUT_SOURCE_SCART2,       INPUT_SOURCE_TV},
    {INPUT_SOURCE_NONE,         INPUT_SOURCE_NONE},  //ENDtbl don't modify output source
};

#if (INPUT_SCART_VIDEO_COUNT >= 2)
code CVBS_OUTPUT_INFO  CVBS2_OUTPUT_Tbl[] =
{  //INPUT SOURCE                        CVBS1 OUTPUT
    {INPUT_SOURCE_TV,           INPUT_SOURCE_TV},
    {INPUT_SOURCE_CVBS,         INPUT_SOURCE_CVBS},
    {INPUT_SOURCE_CVBS2,        INPUT_SOURCE_CVBS2},
    {INPUT_SOURCE_SCART,        INPUT_SOURCE_SCART},
    {INPUT_SOURCE_SCART2,       INPUT_SOURCE_SCART2},
    {INPUT_SOURCE_NONE,         INPUT_SOURCE_NONE},  //ENDtbl don't modify output source
};
#endif

INPUT_SOURCE_TYPE_t _MAPP_GET_CVBSOUT_VIDEO_SOURCE( CVBS_OUTPUT_INFO* pCVBStbl, INPUT_SOURCE_TYPE_t u8InputSource )
{
        while(1)
       {
        //if(pCVBStbl->u8InputSource== INPUT_SOURCE_NONE)
        //break;
        if((pCVBStbl->u8InputSource == u8InputSource)||(pCVBStbl->u8InputSource== INPUT_SOURCE_NONE))
        return pCVBStbl->u8CVBSOutVideoSource;
        pCVBStbl++;
        }

     return INPUT_SOURCE_NONE;
}


#if 0
MS_U8 _MAPP_GET_CVBSOUT_AUDIO_SOURCE( CVBS_OUTPUT_INFO* pCVBStbl, INPUT_SOURCE_TYPE_t u8InputSource )
{
        while(1)
       {
            if(pCVBStbl->u8InputSource== INPUT_SOURCE_NONE)
                return 0xFF;  //return no source

            if(pCVBStbl->u8InputSource == u8InputSource)
                return pCVBStbl->u8CVBSOutAudioSource;

            pCVBStbl++;
        }

    return 0xFF;


}

INPUT_SOURCE_TYPE_t MsAPI_GET_CVBSOUT_VIDEO(INPUT_SOURCE_TYPE_t u8InputSource )
{
    return _MAPP_GET_CVBSOUT_VIDEO_SOURCE(CVBS1_OUTPUT_Tbl, u8InputSource);
}


MS_U8 MsAPI_GET_CVBSOUT_AUDIO(INPUT_SOURCE_TYPE_t u8InputSource )
{
    return _MAPP_GET_CVBSOUT_AUDIO_SOURCE(CVBS1_OUTPUT_Tbl, u8InputSource);
}
#endif


/********************************************************************************/
/*                     Local                                                    */
/********************************************************************************/
BOOLEAN TunerInAtvMode=TRUE;

static void _MApp_InputSource_ClearSysInputSourceFlag(SCALER_WIN eWindow)
{
    if(stSystemInfo[eWindow].enInputSourceType < INPUT_SOURCE_NUM)
    {
        EN_SYS_INPUT_SOURCE_TYPE enFlag = EN_SYS_INPUT_SOURCE_TYPE_NONE;
        switch(stSystemInfo[eWindow].enInputSourceType)
        {
            case INPUT_SOURCE_DTV:
                enFlag = EN_SYS_INPUT_SOURCE_TYPE_DTV;
                break;
            case INPUT_SOURCE_TV:
                enFlag = EN_SYS_INPUT_SOURCE_TYPE_ATV;
                break;
            case INPUT_SOURCE_CVBS:
            case INPUT_SOURCE_CVBS2:
            case INPUT_SOURCE_CVBS3:
            case INPUT_SOURCE_CVBS4:
            case INPUT_SOURCE_CVBS5:
            case INPUT_SOURCE_CVBS6:
            case INPUT_SOURCE_CVBS7:
            case INPUT_SOURCE_CVBS8:
                enFlag = EN_SYS_INPUT_SOURCE_TYPE_CVBS;
                break;
            case INPUT_SOURCE_SVIDEO:
            case INPUT_SOURCE_SVIDEO2:
            case INPUT_SOURCE_SVIDEO3:
            case INPUT_SOURCE_SVIDEO4:
                enFlag = EN_SYS_INPUT_SOURCE_TYPE_SVIDEO;
                break;
            case INPUT_SOURCE_YPBPR:
            case INPUT_SOURCE_YPBPR2:
            case INPUT_SOURCE_YPBPR3:
                enFlag = EN_SYS_INPUT_SOURCE_TYPE_YPBPR;
                break;
            case INPUT_SOURCE_SCART:
            case INPUT_SOURCE_SCART2:
                enFlag = EN_SYS_INPUT_SOURCE_TYPE_SCART;
                break;
            case INPUT_SOURCE_HDMI:
            case INPUT_SOURCE_HDMI2:
            case INPUT_SOURCE_HDMI3:
            case INPUT_SOURCE_HDMI4:
                enFlag = EN_SYS_INPUT_SOURCE_TYPE_HDMI;
                break;
            case INPUT_SOURCE_VGA:
                enFlag = EN_SYS_INPUT_SOURCE_TYPE_VGA;
                break;
            case INPUT_SOURCE_STORAGE:
                enFlag = EN_SYS_INPUT_SOURCE_TYPE_STORAGE;
                break;
            default:
                break;
        }
        msAPI_InputSrcType_ClrType(enFlag);
        INPUTSOURCE_DBG(printf("[Clear] _enSysInputSource = 0x%x\n", (U16)msAPI_InputSrcType_GetType()));
    }
}
static void _MApp_InputSource_SetSysInputSourceFlag(SCALER_WIN eWindow)
{
    if(stSystemInfo[eWindow].enInputSourceType < INPUT_SOURCE_NUM)
    {
        EN_SYS_INPUT_SOURCE_TYPE enFlag = EN_SYS_INPUT_SOURCE_TYPE_NONE;
        switch(stSystemInfo[eWindow].enInputSourceType)
        {
            case INPUT_SOURCE_DTV:
                enFlag = EN_SYS_INPUT_SOURCE_TYPE_DTV;
                break;
            case INPUT_SOURCE_TV:
                enFlag = EN_SYS_INPUT_SOURCE_TYPE_ATV;
                break;
            case INPUT_SOURCE_CVBS:
            case INPUT_SOURCE_CVBS2:
            case INPUT_SOURCE_CVBS3:
            case INPUT_SOURCE_CVBS4:
            case INPUT_SOURCE_CVBS5:
            case INPUT_SOURCE_CVBS6:
            case INPUT_SOURCE_CVBS7:
            case INPUT_SOURCE_CVBS8:
                enFlag = EN_SYS_INPUT_SOURCE_TYPE_CVBS;
                break;
            case INPUT_SOURCE_SVIDEO:
            case INPUT_SOURCE_SVIDEO2:
            case INPUT_SOURCE_SVIDEO3:
            case INPUT_SOURCE_SVIDEO4:
                enFlag = EN_SYS_INPUT_SOURCE_TYPE_SVIDEO;
                break;
            case INPUT_SOURCE_YPBPR:
            case INPUT_SOURCE_YPBPR2:
            case INPUT_SOURCE_YPBPR3:
                enFlag = EN_SYS_INPUT_SOURCE_TYPE_YPBPR;
                break;
            case INPUT_SOURCE_SCART:
            case INPUT_SOURCE_SCART2:
                enFlag = EN_SYS_INPUT_SOURCE_TYPE_SCART;
                break;
            case INPUT_SOURCE_HDMI:
            case INPUT_SOURCE_HDMI2:
            case INPUT_SOURCE_HDMI3:
            case INPUT_SOURCE_HDMI4:
                enFlag = EN_SYS_INPUT_SOURCE_TYPE_HDMI;
                break;
            case INPUT_SOURCE_VGA:
                enFlag = EN_SYS_INPUT_SOURCE_TYPE_VGA;
                break;
            case INPUT_SOURCE_STORAGE:
                enFlag = EN_SYS_INPUT_SOURCE_TYPE_STORAGE;
                break;
            default:
                break;
        }
        msAPI_InputSrcType_SetType(enFlag);
        INPUTSOURCE_DBG(printf("[Set] _enSysInputSource = 0x%x\n", (U16)msAPI_InputSrcType_GetType()));
    }
}
/********************************************************************************/
/*                   Functions                                                  */
/********************************************************************************/

void MApp_InputSource_RecordSource(E_UI_INPUT_SOURCE enUiInputSourceType)
{
    UI_PREV_INPUT_SOURCE_TYPE = enUiInputSourceType;
}

E_UI_INPUT_SOURCE MApp_InputSource_GetRecordSource(void)
{
    return UI_PREV_INPUT_SOURCE_TYPE;
}

void MApp_InputSource_RestoreSource(void)
{
    #if ENABLE_SBTVD_BRAZIL_APP
    #if ENABLE_DMP
    // [ISDB] fix exit in DMP, switch to CATV, but previous is ATV
    if((UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_DMP))
    {
        if(UI_PREV_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_ATV && msAPI_ATV_GetCurrentAntenna() == ANT_AIR)
            UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_ANTENNA;
        else
            UI_INPUT_SOURCE_TYPE = UI_PREV_INPUT_SOURCE_TYPE;
    }
    else
    #endif
    #endif
    E_UI_INPUT_SOURCE enUiInputSource;
    enUiInputSource=UI_PREV_INPUT_SOURCE_TYPE;
    MApp_InputSource_RecordSource(UI_INPUT_SOURCE_TYPE);
    UI_INPUT_SOURCE_TYPE = enUiInputSource;


    MApp_InputSource_ChangeInputSource(MAIN_WINDOW);
}


void MApp_InputSource_ChangeVideoSource( INPUT_SOURCE_TYPE_t enInputSourceType )
{
#if ENABLE_TTX
    MApp_TTX_InitVBITeletext();
#endif

    switch ( enInputSourceType )
    {
        case INPUT_SOURCE_TV:
            //BY 20090406 msAPI_VD_AdjustVideoFactor( E_ADJUST_VIDEOMUTE_DURING_LIMITED_TIME, DELAY_FOR_STABLE_TUNER );
            msAPI_AVD_SetVideoSource( E_INPUT_SOURCE_ATV );
            break;

            #if (INPUT_AV_VIDEO_COUNT >= 1)
        case INPUT_SOURCE_CVBS:
            //BY 20090406 msAPI_VD_AdjustVideoFactor( E_ADJUST_VIDEOMUTE_DURING_LIMITED_TIME, DELAY_FOR_STABLE_VIDEO );
            msAPI_AVD_SetVideoSource( E_INPUT_SOURCE_CVBS1 );
            break;
            #endif

            #if (INPUT_AV_VIDEO_COUNT >= 2)
        case INPUT_SOURCE_CVBS2:
            //BY 20090406 msAPI_VD_AdjustVideoFactor( E_ADJUST_VIDEOMUTE_DURING_LIMITED_TIME, DELAY_FOR_STABLE_VIDEO );
            msAPI_AVD_SetVideoSource( E_INPUT_SOURCE_CVBS2 );
            break;
            #endif
            #if (INPUT_AV_VIDEO_COUNT >= 3)
        case INPUT_SOURCE_CVBS3:
            //BY 20090406 msAPI_VD_AdjustVideoFactor( E_ADJUST_VIDEOMUTE_DURING_LIMITED_TIME, DELAY_FOR_STABLE_VIDEO );
            msAPI_AVD_SetVideoSource( E_INPUT_SOURCE_CVBS3 );
            break;
            #endif

            #if (INPUT_SV_VIDEO_COUNT >= 1)
        case INPUT_SOURCE_SVIDEO:
            //BY 20090406 msAPI_VD_AdjustVideoFactor( E_ADJUST_VIDEOMUTE_DURING_LIMITED_TIME, DELAY_FOR_STABLE_VIDEO );
            msAPI_AVD_SetVideoSource( E_INPUT_SOURCE_SVIDEO1 );
            break;
            #endif

            #if (INPUT_SV_VIDEO_COUNT >= 2)
        case INPUT_SOURCE_SVIDEO2:
            #if (INPUT_SCART_USE_SV2 == 0)
            //BY 20090406 msAPI_VD_AdjustVideoFactor( E_ADJUST_VIDEOMUTE_DURING_LIMITED_TIME, DELAY_FOR_STABLE_VIDEO );
            msAPI_AVD_SetVideoSource( E_INPUT_SOURCE_SVIDEO2 );
            break;
            #endif //#if (INPUT_SCART_USE_SV2 == 0)
            #endif

            #if (INPUT_SCART_VIDEO_COUNT >= 1)
        case INPUT_SOURCE_SCART:
            //BY 20090406 msAPI_VD_AdjustVideoFactor( E_ADJUST_VIDEOMUTE_DURING_LIMITED_TIME, DELAY_FOR_STABLE_VIDEO );
            #if (INPUT_SCART_USE_SV2 == 0)
            msAPI_AVD_SetVideoSource( E_INPUT_SOURCE_SCART1 );
            #else
            {
                if(msAPI_AVD_IsScartRGB())
                {
                    g_u8IsScartRGB = TRUE;
                    msAPI_AVD_SetVideoSource(E_INPUT_SOURCE_SCART1);
                }
                else
                {
                    g_u8IsScartRGB = FALSE;
                    switch (stGenSetting.g_SysSetting.fSCARTInputSel)
                    {
                        case EN_SCART_SEL_AV:
                            msAPI_AVD_SetVideoSource(E_INPUT_SOURCE_SCART1);
                            break;
                        case EN_SCART_SEL_SV:
                            msAPI_AVD_SetVideoSource(E_INPUT_SOURCE_SVIDEO2);
                            break;
                        default:
                            return;
                    }
                }
            }
            #endif
            break;
            #endif

      #if (INPUT_SCART_VIDEO_COUNT >= 2)
        case INPUT_SOURCE_SCART2:
            msAPI_AVD_SetVideoSource( E_INPUT_SOURCE_SCART2 );
            break;
      #endif

        default:
            msAPI_AVD_SetVideoSource( E_INPUT_SOURCE_INVALID );
            return;
    }

    if ( enInputSourceType == INPUT_SOURCE_TV )
    {
    	msAPI_AVD_TurnOffAutoAV();
        msAPI_Tuner_ChangeProgram();
    }
    else
    {
        msAPI_AVD_WaitForVideoSyncLock();
#if ENABLE_TTX
        msAPI_TTX_ResetAcquisition();
#endif
        //msAPI_AVD_DetectVideoStandard( OPERATIONMETHOD_MANUALLY );
        msAPI_AVD_StartAutoStandardDetection();
    }

    //msAPI_VD_ClearSyncCheckCounter();
    msAPI_AVD_ClearAspectRatio();
}



//===============================================================================================
//
// All audio path are defined in each board header file !!!
// If you have any questions about it , please call MStar audio engineer
// to give you a hand !!!
//
//===========================================================================

void MApp_InputSource_ChangeAudioSource(INPUT_SOURCE_TYPE_t enInputSourceType)
{
    CAL_TIME_FUNC_START();

    MApi_AUDIO_SetSourceInfo(E_AUDIO_INFO_ADC_IN); // Most case==> ADC in

    CAL_TIME_FUNC_("ChgAuSrc");

    switch(enInputSourceType)
    {
        case INPUT_SOURCE_DTV:
                MApi_AUDIO_SetSourceInfo(E_AUDIO_INFO_DTV_IN);
                msAPI_AUD_AdjustAudioFactor(E_ADJUST_CHANGE_AUDIOSOURCE, E_AUDIOSOURCE_MPEG, 0);
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_MAIN_SPEAKER, AUDIO_SOURCE_DTV, AUDIO_OUTPUT_MAIN_SPEAKER);
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_SPEAKER,      AUDIO_SRC_INPUT,  AUDIO_OUTPUT_MAIN_SPEAKER);
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_LINEOUT,      AUDIO_SOURCE_DTV, AUDIO_OUTPUT_LINEOUT);
                #if ENABLE_CUS_HEADPHONE_SPEC
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_HP, AUDIO_SOURCE_DTV, AUDIO_OUTPUT_HP);
                #endif
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_SPDIF,        AUDIO_SOURCE_DTV, AUDIO_SPDIF_OUTPUT);
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_SIFOUT,       AUDIO_SOURCE_DTV, AUDIO_OUTPUT_SIFOUT);
                MApi_AUDIO_InputSwitch(AUDIO_SOURCE_DTV, E_AUDIO_GROUP_INVALID);
                //MApi_AUDIO_EnableDcRemove(false);
                TunerInAtvMode=FALSE;
                break;

        case INPUT_SOURCE_TV:
                MApi_AUDIO_SetSourceInfo(E_AUDIO_INFO_ATV_IN);
                msAPI_AUD_AdjustAudioFactor(E_ADJUST_CHANGE_AUDIOSOURCE, E_AUDIOSOURCE_ATV, 0);
                //MApi_AUDIO_SIF_SetThreshold(AuSifInitThreshold);
				#if ENABLE_NO_AUDIO_INPUT_AUTO_MUTE
				MApi_AUDIO_SetCommAudioInfo(Audio_Comm_infoType_setNR_Threshold, 0x6E,0X00);//should finetune
                #endif
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_MAIN_SPEAKER, AUDIO_SOURCE_ATV, AUDIO_OUTPUT_MAIN_SPEAKER);
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_SPEAKER,      AUDIO_SRC_INPUT,  AUDIO_OUTPUT_MAIN_SPEAKER);
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_LINEOUT,      AUDIO_SOURCE_ATV, AUDIO_OUTPUT_LINEOUT);
                #if ENABLE_CUS_HEADPHONE_SPEC
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_HP, AUDIO_SOURCE_ATV, AUDIO_OUTPUT_HP);
                #endif
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_SPDIF,        AUDIO_SOURCE_ATV, AUDIO_SPDIF_OUTPUT);
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_SIFOUT,       AUDIO_SOURCE_ATV, AUDIO_OUTPUT_SIFOUT);
                MApi_AUDIO_InputSwitch(AUDIO_SOURCE_ATV, E_AUDIO_GROUP_INVALID);
                //MApi_AUDIO_EnableDcRemove(false);
                TunerInAtvMode=TRUE;
                break;

         case INPUT_SOURCE_CVBS:
                Switch_AV() ;
                msAPI_AUD_AdjustAudioFactor(E_ADJUST_CHANGE_AUDIOSOURCE, E_AUDIOSOURCE_CVBS1, 0);
				#if ENABLE_NO_AUDIO_INPUT_AUTO_MUTE
				MApi_AUDIO_SetCommAudioInfo(Audio_Comm_infoType_setNR_Threshold, 0xAA,0X00);//should finetune
				#endif
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_MAIN_SPEAKER, AUDIO_SOURCE_AV, AUDIO_OUTPUT_MAIN_SPEAKER);
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_SPEAKER,      AUDIO_SRC_INPUT, AUDIO_OUTPUT_MAIN_SPEAKER);
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_LINEOUT,      AUDIO_SOURCE_AV, AUDIO_OUTPUT_LINEOUT);
                #if ENABLE_CUS_HEADPHONE_SPEC
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_HP, AUDIO_SOURCE_AV, AUDIO_OUTPUT_HP);
                #endif
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_SIFOUT,       AUDIO_SOURCE_AV, AUDIO_OUTPUT_SIFOUT);
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_SPDIF,        AUDIO_SOURCE_AV, AUDIO_SPDIF_OUTPUT);
                CAL_TIME_FUNC_("ChgAuSrc");
                MApi_AUDIO_InputSwitch(AUDIO_SOURCE_DTV, E_AUDIO_GROUP_INVALID);
                //MApi_AUDIO_EnableDcRemove(true);
                break;

      #if (INPUT_AV_VIDEO_COUNT >= 2)
         case INPUT_SOURCE_CVBS2:
		 	   
                Switch_AV2() ;
                msAPI_AUD_AdjustAudioFactor(E_ADJUST_CHANGE_AUDIOSOURCE, E_AUDIOSOURCE_CVBS1, 0);
				#if ENABLE_NO_AUDIO_INPUT_AUTO_MUTE
				MApi_AUDIO_SetCommAudioInfo(Audio_Comm_infoType_setNR_Threshold, 0xAA,0X00);//should finetune
				#endif
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_MAIN_SPEAKER, AUDIO_SOURCE_AV2, AUDIO_OUTPUT_MAIN_SPEAKER/*AUDIO_OUTPUT_MAIN_SPEAKER*/);
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_SPEAKER,      AUDIO_SRC_INPUT,  AUDIO_OUTPUT_MAIN_SPEAKER);
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_LINEOUT,      AUDIO_SOURCE_AV2, AUDIO_OUTPUT_LINEOUT/*AUDIO_OUTPUT_LINEOUT*/);
                #if ENABLE_CUS_HEADPHONE_SPEC
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_HP, AUDIO_SOURCE_AV2, AUDIO_OUTPUT_HP);
                #endif
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_SIFOUT,       AUDIO_SOURCE_AV2, AUDIO_OUTPUT_SIFOUT);
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_SPDIF,        AUDIO_SOURCE_AV2, AUDIO_SPDIF_OUTPUT);
                MApi_AUDIO_InputSwitch(AUDIO_SOURCE_DTV, E_AUDIO_GROUP_INVALID);
                
                //MApi_AUDIO_EnableDcRemove(true);
                printf(">>>>>>>>>>>>>>>>INPUT_SOURCE_CVBS2>>>>>>>>>>>>>>>\n");
                break;
      #endif

      #if (INPUT_AV_VIDEO_COUNT >= 3)
        case INPUT_SOURCE_CVBS3:
                msAPI_AUD_AdjustAudioFactor(E_ADJUST_CHANGE_AUDIOSOURCE, E_AUDIOSOURCE_CVBS2, 0);
				#if ENABLE_NO_AUDIO_INPUT_AUTO_MUTE
				MApi_AUDIO_SetCommAudioInfo(Audio_Comm_infoType_setNR_Threshold, 0xAA,0X00);//should finetune
				#endif
                Switch_AV3() ;
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_MAIN_SPEAKER, AUDIO_SOURCE_AV3, AUDIO_OUTPUT_MAIN_SPEAKER);
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_SPEAKER,      AUDIO_SRC_INPUT,  AUDIO_OUTPUT_MAIN_SPEAKER);
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_LINEOUT,      AUDIO_SOURCE_AV3, AUDIO_OUTPUT_LINEOUT);
                #if ENABLE_CUS_HEADPHONE_SPEC
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_HP, AUDIO_SOURCE_AV3, AUDIO_OUTPUT_HP);
                #endif
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_SIFOUT,       AUDIO_SOURCE_AV3, AUDIO_OUTPUT_SIFOUT);
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_SPDIF,        AUDIO_SOURCE_AV3, AUDIO_SPDIF_OUTPUT);
                MApi_AUDIO_InputSwitch(AUDIO_SOURCE_DTV, E_AUDIO_GROUP_INVALID);
                //MApi_AUDIO_EnableDcRemove(true);
                break;
      #endif

      #if (INPUT_SV_VIDEO_COUNT >= 1)
        case INPUT_SOURCE_SVIDEO:
                msAPI_AUD_AdjustAudioFactor(E_ADJUST_CHANGE_AUDIOSOURCE, E_AUDIOSOURCE_SVIDEO1, 0);
				#if ENABLE_NO_AUDIO_INPUT_AUTO_MUTE
				MApi_AUDIO_SetCommAudioInfo(Audio_Comm_infoType_setNR_Threshold, 0xAA,0X00);//should finetune
				#endif
                Switch_SV() ;
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_MAIN_SPEAKER, AUDIO_SOURCE_SV,  AUDIO_OUTPUT_MAIN_SPEAKER);
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_SPEAKER,      AUDIO_SRC_INPUT,  AUDIO_OUTPUT_MAIN_SPEAKER);
                #if SCART_ALWAYS_OUTPUT_ATV
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_LINEOUT,      AUDIO_SOURCE_ATV, AUDIO_OUTPUT_LINEOUT);
                #else
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_LINEOUT,      AUDIO_SOURCE_SV,  AUDIO_OUTPUT_LINEOUT);
                #endif
                #if ENABLE_CUS_HEADPHONE_SPEC
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_HP, AUDIO_SOURCE_SV,  AUDIO_OUTPUT_HP);
                #endif
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_SPDIF,        AUDIO_SOURCE_SV,  AUDIO_SPDIF_OUTPUT);
                MApi_AUDIO_InputSwitch(AUDIO_SOURCE_DTV, E_AUDIO_GROUP_INVALID);
                //MApi_AUDIO_EnableDcRemove(true);
                 break;
      #endif

      #if (INPUT_SV_VIDEO_COUNT >= 2)
        case INPUT_SOURCE_SVIDEO2:
      #if (INPUT_SCART_USE_SV2==0)
                msAPI_AUD_AdjustAudioFactor(E_ADJUST_CHANGE_AUDIOSOURCE, E_AUDIOSOURCE_SVIDEO1, 0);
                Switch_SV2() ;
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_MAIN_SPEAKER, AUDIO_SOURCE_SV2, AUDIO_OUTPUT_MAIN_SPEAKER);
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_SPEAKER,      AUDIO_SRC_INPUT,  AUDIO_OUTPUT_MAIN_SPEAKER);
                #if SCART_ALWAYS_OUTPUT_ATV
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_LINEOUT,      AUDIO_SOURCE_ATV, AUDIO_OUTPUT_LINEOUT);
                #else
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_LINEOUT,      AUDIO_SOURCE_SV2, AUDIO_OUTPUT_LINEOUT);
                #endif
                #if ENABLE_CUS_HEADPHONE_SPEC
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_HP, AUDIO_SOURCE_SV2, AUDIO_OUTPUT_HP);
                #endif
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_SPDIF,        AUDIO_SOURCE_SV2, AUDIO_SPDIF_OUTPUT);
                MApi_AUDIO_InputSwitch(AUDIO_SOURCE_DTV, E_AUDIO_GROUP_INVALID);
                //MApi_AUDIO_EnableDcRemove(true);
                break;
      #endif //#if (INPUT_SCART_USE_SV2==0)
      #endif

      #if (INPUT_SCART_VIDEO_COUNT >= 1)
       case INPUT_SOURCE_SCART:
                msAPI_AUD_AdjustAudioFactor(E_ADJUST_CHANGE_AUDIOSOURCE, E_AUDIOSOURCE_SCART1, 0);
                Switch_SCART() ;
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_MAIN_SPEAKER, AUDIO_SOURCE_SCART, AUDIO_OUTPUT_MAIN_SPEAKER);
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_SPEAKER,      AUDIO_SRC_INPUT,    AUDIO_OUTPUT_MAIN_SPEAKER);
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_LINEOUT,      AUDIO_SOURCE_SCART, AUDIO_OUTPUT_LINEOUT);
                #if ENABLE_CUS_HEADPHONE_SPEC
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_HP, AUDIO_SOURCE_SCART, AUDIO_OUTPUT_HP);
                #endif
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_SPDIF,        AUDIO_SOURCE_SCART, AUDIO_SPDIF_OUTPUT);
                MApi_AUDIO_InputSwitch(AUDIO_SOURCE_DTV, E_AUDIO_GROUP_INVALID);
                //MApi_AUDIO_EnableDcRemove(true);
                break;
      #endif

      #if (INPUT_SCART_VIDEO_COUNT >= 2)
        case INPUT_SOURCE_SCART2:
                msAPI_AUD_AdjustAudioFactor(E_ADJUST_CHANGE_AUDIOSOURCE, E_AUDIOSOURCE_SCART2, 0);
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_MAIN_SPEAKER, AUDIO_SOURCE_SCART2, AUDIO_OUTPUT_MAIN_SPEAKER);
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_SPEAKER,            AUDIO_SRC_INPUT,     AUDIO_OUTPUT_MAIN_SPEAKER);
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_LINEOUT,      AUDIO_SOURCE_SCART2, AUDIO_OUTPUT_LINEOUT);
                #if ENABLE_CUS_HEADPHONE_SPEC
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_HP, AUDIO_SOURCE_SCART2, AUDIO_OUTPUT_HP);
                #endif
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_SPDIF,        AUDIO_SOURCE_SCART2, AUDIO_SPDIF_OUTPUT);
                MApi_AUDIO_InputSwitch(AUDIO_SOURCE_DTV, E_AUDIO_GROUP_INVALID);
                //MApi_AUDIO_EnableDcRemove(true);
                break;
      #endif

      #if (INPUT_YPBPR_VIDEO_COUNT >= 1)
        case INPUT_SOURCE_YPBPR:
                msAPI_AUD_AdjustAudioFactor(E_ADJUST_CHANGE_AUDIOSOURCE, E_AUDIOSOURCE_YPbPr, 0);
				#if ENABLE_NO_AUDIO_INPUT_AUTO_MUTE
				MApi_AUDIO_SetCommAudioInfo(Audio_Comm_infoType_setNR_Threshold, 0xAA,0X00);//should finetune
				#endif
                Switch_YPBPR() ;
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_MAIN_SPEAKER, AUDIO_SOURCE_YPBPR, AUDIO_OUTPUT_MAIN_SPEAKER);
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_SPEAKER,      AUDIO_SRC_INPUT,    AUDIO_OUTPUT_MAIN_SPEAKER);
                #if SCART_ALWAYS_OUTPUT_ATV
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_LINEOUT,      AUDIO_SOURCE_ATV,   AUDIO_OUTPUT_LINEOUT);
                #else
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_LINEOUT,      AUDIO_SOURCE_YPBPR ,AUDIO_OUTPUT_LINEOUT);
                #endif
                #if ENABLE_CUS_HEADPHONE_SPEC
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_HP, AUDIO_SOURCE_YPBPR, AUDIO_OUTPUT_HP);
                #endif
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_SPDIF,        AUDIO_SOURCE_YPBPR , AUDIO_SPDIF_OUTPUT);
                MApi_AUDIO_InputSwitch(AUDIO_SOURCE_DTV, E_AUDIO_GROUP_INVALID);
                //MApi_AUDIO_EnableDcRemove(true);
                break;
      #endif

      #if (INPUT_YPBPR_VIDEO_COUNT >= 2)
        case INPUT_SOURCE_YPBPR2:
                msAPI_AUD_AdjustAudioFactor(E_ADJUST_CHANGE_AUDIOSOURCE, E_AUDIOSOURCE_YPbPr, 0);
				#if ENABLE_NO_AUDIO_INPUT_AUTO_MUTE
				MApi_AUDIO_SetCommAudioInfo(Audio_Comm_infoType_setNR_Threshold, 0xAA,0X00);//should finetune
				#endif
                Switch_YPBPR2() ;
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_MAIN_SPEAKER, AUDIO_SOURCE_YPBPR2, AUDIO_OUTPUT_MAIN_SPEAKER);
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_SPEAKER,      AUDIO_SRC_INPUT,     AUDIO_OUTPUT_MAIN_SPEAKER);
                #if SCART_ALWAYS_OUTPUT_ATV
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_LINEOUT,      AUDIO_SOURCE_ATV,    AUDIO_OUTPUT_LINEOUT);
                #else
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_LINEOUT,      AUDIO_SOURCE_YPBPR2, AUDIO_OUTPUT_LINEOUT);
                #endif
                #if ENABLE_CUS_HEADPHONE_SPEC
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_HP, AUDIO_SOURCE_YPBPR2, AUDIO_OUTPUT_HP);
                #endif
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_SPDIF,        AUDIO_SOURCE_YPBPR2, AUDIO_SPDIF_OUTPUT);
                MApi_AUDIO_InputSwitch(AUDIO_SOURCE_DTV, E_AUDIO_GROUP_INVALID);
                //MApi_AUDIO_EnableDcRemove(true);
                break;
      #endif

        case INPUT_SOURCE_VGA:
                msAPI_AUD_AdjustAudioFactor(E_ADJUST_CHANGE_AUDIOSOURCE, E_AUDIOSOURCE_PC, 0);
                /*
				#if ENABLE_NO_AUDIO_INPUT_AUTO_MUTE
				MApi_AUDIO_SetCommAudioInfo(Audio_Comm_infoType_setNR_Threshold, 0xAA,0X00);//should finetune
				#endif
                Switch_PC() ;
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_MAIN_SPEAKER, AUDIO_SOURCE_PC , AUDIO_OUTPUT_MAIN_SPEAKER);
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_SPEAKER,      AUDIO_SRC_INPUT,  AUDIO_OUTPUT_MAIN_SPEAKER);
                #if SCART_ALWAYS_OUTPUT_ATV
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_LINEOUT,      AUDIO_SOURCE_ATV, AUDIO_OUTPUT_LINEOUT);
                #else
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_LINEOUT,      AUDIO_SOURCE_PC , AUDIO_OUTPUT_LINEOUT);
                #endif
                #if ENABLE_CUS_HEADPHONE_SPEC
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_HP, AUDIO_SOURCE_PC , AUDIO_OUTPUT_HP);
                #endif
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_SPDIF,        AUDIO_SOURCE_PC , AUDIO_SPDIF_OUTPUT);
                MApi_AUDIO_InputSwitch(AUDIO_SOURCE_DTV, E_AUDIO_GROUP_INVALID);
                */
                //MApi_AUDIO_EnableDcRemove(true);
                break;

        case INPUT_SOURCE_HDMI:
         // Switch_DVI() ;   Ken 20080529
     #if(INPUT_HDMI_VIDEO_COUNT>1)
        case INPUT_SOURCE_HDMI2:
     #endif
     #if(INPUT_HDMI_VIDEO_COUNT>2)
       case INPUT_SOURCE_HDMI3:
     #endif
     #if(INPUT_HDMI_VIDEO_COUNT>3)
       case INPUT_SOURCE_HDMI4:
     #endif

                if(g_HdmiPollingStatus.bIsHDMIMode)
                {
                    MApi_AUDIO_SetSourceInfo(E_AUDIO_INFO_HDMI_IN);
					#if ENABLE_NO_AUDIO_INPUT_AUTO_MUTE
					MApi_AUDIO_SetCommAudioInfo(Audio_Comm_infoType_setNR_Threshold, 0xAA,0X00);//should finetune
					#endif
                    msAPI_AUD_AdjustAudioFactor(E_ADJUST_CHANGE_AUDIOSOURCE, E_AUDIOSOURCE_HDMI, 0);
                    MDrv_AUDIO_SetNormalPath(AUDIO_PATH_MAIN_SPEAKER, AUDIO_SOURCE_HDMI, AUDIO_OUTPUT_MAIN_SPEAKER);
                    MDrv_AUDIO_SetNormalPath(AUDIO_PATH_SPEAKER,      AUDIO_SRC_INPUT,   AUDIO_OUTPUT_MAIN_SPEAKER);
                    #if SCART_ALWAYS_OUTPUT_ATV
                    MDrv_AUDIO_SetNormalPath(AUDIO_PATH_LINEOUT,      AUDIO_SOURCE_ATV,  AUDIO_OUTPUT_LINEOUT);
                    #else
                    MDrv_AUDIO_SetNormalPath(AUDIO_PATH_LINEOUT,      AUDIO_SOURCE_HDMI, AUDIO_OUTPUT_LINEOUT);
                    #endif
                    #if ENABLE_CUS_HEADPHONE_SPEC
                    MDrv_AUDIO_SetNormalPath(AUDIO_PATH_HP, AUDIO_SOURCE_HDMI, AUDIO_OUTPUT_HP);
                    #endif
                    MDrv_AUDIO_SetNormalPath(AUDIO_PATH_SPDIF,        AUDIO_SOURCE_HDMI, AUDIO_SPDIF_OUTPUT);
                    MApi_AUDIO_InputSwitch(AUDIO_SOURCE_HDMI, E_AUDIO_GROUP_INVALID);
                    //MApi_AUDIO_EnableDcRemove(false);
                    break;
                }
          // else ==> DVI mode
       case INPUT_SOURCE_DVI:
                printf("\r\n Now is in DVI mode !!! Not HDMI ......");
                //MApi_AUDIO_SetSourceInfo(E_AUDIO_INFO_DTV_IN);
                msAPI_AUD_AdjustAudioFactor(E_ADJUST_CHANGE_AUDIOSOURCE, E_AUDIOSOURCE_DVI, 0);
				#if ENABLE_NO_AUDIO_INPUT_AUTO_MUTE
				MApi_AUDIO_SetCommAudioInfo(Audio_Comm_infoType_setNR_Threshold, 0xAA,0X00);//should finetune
				#endif
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_MAIN_SPEAKER, AUDIO_SOURCE_DVI,   AUDIO_OUTPUT_MAIN_SPEAKER);
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_SPEAKER,      AUDIO_SRC_INPUT,    AUDIO_OUTPUT_MAIN_SPEAKER);
                #if SCART_ALWAYS_OUTPUT_ATV
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_LINEOUT,      AUDIO_SOURCE_ATV,   AUDIO_OUTPUT_LINEOUT);
                #else
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_LINEOUT,      AUDIO_SOURCE_DVI,   AUDIO_OUTPUT_LINEOUT);
                #endif
                #if ENABLE_CUS_HEADPHONE_SPEC
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_HP, AUDIO_SOURCE_DVI,   AUDIO_OUTPUT_HP);
                #endif
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_SPDIF,        AUDIO_SOURCE_DVI,   AUDIO_SPDIF_OUTPUT);
                MApi_AUDIO_InputSwitch(AUDIO_SOURCE_DTV, E_AUDIO_GROUP_INVALID);
                //MApi_AUDIO_EnableDcRemove(true);
                break;

      #if ENABLE_DMP
        case INPUT_SOURCE_STORAGE:
            #ifdef ENABLE_KTV
            if(gbKTVFlag == TRUE)
            {
                MApi_AUDIO_SetSourceInfo(E_AUDIO_INFO_KTV_IN);
                msAPI_AUD_AdjustAudioFactor(E_ADJUST_CHANGE_AUDIOSOURCE, E_AUDIOSOURCE_MPEG, 0);
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_MAIN_SPEAKER, AUDIO_SOURCE_DTV, AUDIO_OUTPUT_MAIN_SPEAKER);
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_SPEAKER,      AUDIO_SRC_INPUT,  AUDIO_OUTPUT_MAIN_SPEAKER);
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_LINEOUT,      AUDIO_SOURCE_KTV, AUDIO_OUTPUT_MAIN_SPEAKER);
                #if ENABLE_CUS_HEADPHONE_SPEC
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_HP, AUDIO_SOURCE_DTV, AUDIO_OUTPUT_HP);
                #endif
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_SPDIF,        AUDIO_SRC_INPUT,  AUDIO_SPDIF_OUTPUT);
                MApi_AUDIO_InputSwitch(AUDIO_SOURCE_DTV, E_AUDIO_GROUP_INVALID);
                //MApi_AUDIO_EnableDcRemove(false);
                //MApi_AUDIO_SetKTVMusicMicMix (TRUE);
            }
            else
            #endif
            {
                MApi_AUDIO_SetSourceInfo(E_AUDIO_INFO_MM_IN);
                msAPI_AUD_AdjustAudioFactor(E_ADJUST_CHANGE_AUDIOSOURCE, E_AUDIOSOURCE_MPEG, 0);
				#if ENABLE_NO_AUDIO_INPUT_AUTO_MUTE
				MApi_AUDIO_SetCommAudioInfo(Audio_Comm_infoType_setNR_Threshold, 0x35,0X00);//should finetune
				#endif

                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_MAIN_SPEAKER, AUDIO_SOURCE_DTV, AUDIO_OUTPUT_MAIN_SPEAKER);
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_SPEAKER,      AUDIO_SRC_INPUT,  AUDIO_OUTPUT_MAIN_SPEAKER);
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_LINEOUT,      AUDIO_SOURCE_DTV, AUDIO_OUTPUT_LINEOUT);
                #if ENABLE_CUS_HEADPHONE_SPEC
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_HP, AUDIO_SOURCE_DTV, AUDIO_OUTPUT_HP);
                #endif
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_SPDIF,        AUDIO_SOURCE_DTV, AUDIO_SPDIF_OUTPUT);
                MApi_AUDIO_InputSwitch(AUDIO_SOURCE_DTV, E_AUDIO_GROUP_INVALID);
                //MApi_AUDIO_EnableDcRemove(false);
                //MApi_AUDIO_SetKTVMusicMicMix (TRUE);
            }
                break;
      #endif //#if ENABLE_DMP

      #ifdef ENABLE_KTV
        case INPUT_SOURCE_KTV:
                MApi_AUDIO_SetSourceInfo(E_AUDIO_INFO_KTV_IN);
                msAPI_AUD_AdjustAudioFactor(E_ADJUST_CHANGE_AUDIOSOURCE, E_AUDIOSOURCE_MPEG, 0);
                //MDrv_AUDIO_SetNormalPath(AUDIO_PATH_MAIN_SPEAKER, AUDIO_SOURCE_KTV, AUDIO_OUTPUT_MAIN_SPEAKER);
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_MAIN_SPEAKER, AUDIO_SOURCE_DTV, AUDIO_OUTPUT_MAIN_SPEAKER);
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_SPEAKER,      AUDIO_SRC_INPUT,  AUDIO_OUTPUT_MAIN_SPEAKER);
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_LINEOUT,      AUDIO_SRC_INPUT, AUDIO_OUTPUT_LINEOUT);
                MDrv_AUDIO_SetNormalPath(AUDIO_PATH_SPDIF,        AUDIO_SRC_INPUT, AUDIO_SPDIF_OUTPUT);
                MApi_AUDIO_InputSwitch(AUDIO_SOURCE_KTV, E_AUDIO_GROUP_INVALID);
                //MApi_AUDIO_EnableDcRemove(true);
                //MApi_AUDIO_SetKTVMusicMicMix (TRUE);
                break;
      #endif //#ifdef ENABLE_KTV

        default:
                return;
    }

    CAL_TIME_FUNC_("ChgAuSrc");

    //if(enInputSourceType==INPUT_SOURCE_STORAGE) //DMP shoud always enable for audio too large sound
    //{
    //    MApi_AUDIO_EnableAutoVolume(ENABLE);

	//#ifdef CUS_AUDIO_DRC_ADJUST

    //	MApi_SND_ProcessEnable(Sound_ENABL_Type_DRC, ENABLE); // DRC		// CUS_XM Sea 20120709:
	//MApi_SND_SetParam1(Sound_SET_PARAM_Drc_Threshold, 0x0e/*0x1a*/, 0); // -8 dBFS		// CUS_XM Sea 20120725: 0X112D34

    //	#endif

    //}
    //else
    {
    #ifdef CUS_AUDIO_AVL_ALWAYS_ON
    MApi_AUDIO_EnableAutoVolume(DEFAULT_AUTO_VOLUME);
    #else
    MApi_AUDIO_EnableAutoVolume((BOOLEAN)stGenSetting.g_SysSetting.fAutoVolume);
    #endif


    #ifdef CUS_AUDIO_DRC_ADJUST

    MApi_SND_ProcessEnable(Sound_ENABL_Type_DRC, ENABLE); // DRC		// CUS_XM Sea 20120709:

    if (stGenSetting.g_SysSetting.fAutoVolume)
    {
	    MApi_SND_SetParam1(Sound_SET_PARAM_Drc_Threshold, 0x1a, 0); // -8 dBFS		// CUS_XM Sea 20120725: 0X112D34
    }
    else
    {
	    MApi_SND_SetParam1(Sound_SET_PARAM_Drc_Threshold, 0x10, 0); // -8 dBFS		// CUS_XM Sea 20120725: 0X112D34
    }

    #endif

    }

    CAL_TIME_FUNC_("ChgAuSrc");






    MApi_AUDIO_SPDIF_SetMode(MSAPI_AUD_SPDIF_PCM);

    CAL_TIME_FUNC_("ChgAuSrc");
#if MAIKT_NTSC_ATV_PRESCALER//minglin1231 
		  printf("msAPI_AVD_GetVideoStandard()333333333===%d\n",msAPI_AVD_GetVideoStandard());
		  printf("mvideo_vd_get_videosystem()44444444===%d\n",mvideo_vd_get_videosystem());
		  //printf("g_ePreVideoSystem55555555555===%d\n",g_ePreVideoSystem);
  //if (IsATVInUse()&&(msAPI_AVD_GetVideoStandard() == E_VIDEOSTANDARD_NTSC_M))
    //if (msAPI_ATV_GetVideoStandardOfProgram(msAPI_ATV_GetCurrentProgramNumber())== E_VIDEOSTANDARD_NTSC_M)
  if(IsATVInUse()&&(msAPI_ATV_GetVideoStandardOfProgram(msAPI_ATV_GetCurrentProgramNumber())== E_VIDEOSTANDARD_NTSC_M))

		  MApi_AUDIO_SetPreScale(AUDIO_PATH_MAIN_SPEAKER,0xfe);
  else	  
    MApp_Audio_AdjustPreScale(m_eAudioSource);
#else
    MApp_Audio_AdjustPreScale(m_eAudioSource);
#endif

    if(IsVgaInUse())
    	{
	//msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE,E_AUDIO_BYSYNC_MUTEON,E_AUDIOMUTESOURCE_ACTIVESOURCE);
	//MUTE_On();
	printf("++++++++++++++++++++IsVgaInUse+++++++++++++++++\n");
	g_isCVBS2=0;
	    MUTE_On();
	    //msAPI_AUD_AdjustAudioFactor(E_ADJUST_VOLUME, 0, 0);
	    //msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_BYUSER_MUTEON, E_AUDIOMUTESOURCE_ACTIVESOURCE);	
		MsOS_DelayTask(100);
    	}
	/*
	else if(IsHDMIInUse)
	{
       msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE,E_AUDIO_BYSYNC_MUTEON,E_AUDIOMUTESOURCE_ACTIVESOURCE);
	}
	*/
	else if(enInputSourceType==INPUT_SOURCE_CVBS2)
		{
		//msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE,E_AUDIO_BYUSER_MUTEON,E_AUDIOMUTESOURCE_ACTIVESOURCE);
		MUTE_On();
		msAPI_AUD_AdjustAudioFactor(E_ADJUST_VOLUME, 0, 0);
		//msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE,E_AUDIO_BYUSER_MUTEON,E_AUDIOMUTESOURCE_ACTIVESOURCE);
		//msAPI_AUD_AdjustAudioFactor(E_ADJUST_VOLUME, stGenSetting.g_SoundSetting.Volume, 0);
		g_isCVBS2=1; 
		printf("++++++++++++++++++++IsCVBS2+++++++++++++++++\n");
		}
	else
		{
	g_isCVBS2=0;
	MUTE_Off();
	msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE,E_AUDIO_BYSYNC_MUTEON,E_AUDIOMUTESOURCE_ACTIVESOURCE);
	msAPI_AUD_AdjustAudioFactor(E_ADJUST_VOLUME, E_AUDIO_BYUSER_MUTEOFF, E_AUDIOMUTESOURCE_ACTIVESOURCE);	
    msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE,E_AUDIO_BYUSER_MUTEOFF,E_AUDIOMUTESOURCE_ACTIVESOURCE);
	msAPI_AUD_AdjustAudioFactor(E_ADJUST_VOLUME, stGenSetting.g_SoundSetting.Volume, 0);
	
	printf("++++++++++++++++++++no_CVBS2_no_vga+++++++++++++++++\n");
		}
    CAL_TIME_FUNC_END();
}
//===============================End of audio source switch Setting=============================================

static void MApp_SwitchInputSrcPin( INPUT_SOURCE_TYPE_t enInputSourceType )
{

    switch ( enInputSourceType )
    {
        case INPUT_SOURCE_VGA:
            #ifdef Switch_PC
            Switch_PC();
            #endif

          #if (HDMI_SWITCH_SELECT != HDMI_SWITCH_NONE)
            #if(INPUT_HDMI_VIDEO_COUNT > 1)
            HDMI_STANDBY_MODE();
            #endif
          #endif // #if (HDMI_SWITCH_SELECT != HDMI_SWITCH_NONE)
            break;


            #if (INPUT_AV_VIDEO_COUNT >= 1)
        case INPUT_SOURCE_CVBS:
            #ifdef Switch_AV
            Switch_AV();
            #endif

          #if (HDMI_SWITCH_SELECT != HDMI_SWITCH_NONE)
            #if(INPUT_HDMI_VIDEO_COUNT > 1)
            HDMI_STANDBY_MODE();
            #endif
          #endif // #if (HDMI_SWITCH_SELECT != HDMI_SWITCH_NONE)
            break;
            #endif


            #if (INPUT_AV_VIDEO_COUNT >= 2)
        case INPUT_SOURCE_CVBS2:
            #ifdef Switch_AV2
            Switch_AV2();
            #endif

          #if (HDMI_SWITCH_SELECT != HDMI_SWITCH_NONE)
            #if(INPUT_HDMI_VIDEO_COUNT > 1)
            HDMI_STANDBY_MODE();
            #endif
          #endif // #if (HDMI_SWITCH_SELECT != HDMI_SWITCH_NONE)
            break;
            #endif


            #if (INPUT_AV_VIDEO_COUNT >= 3)
        case INPUT_SOURCE_CVBS3:
            #ifdef Switch_AV3
            Switch_AV3();
            #endif

          #if (HDMI_SWITCH_SELECT != HDMI_SWITCH_NONE)
            #if(INPUT_HDMI_VIDEO_COUNT > 1)
            HDMI_STANDBY_MODE();
            #endif
          #endif // #if (HDMI_SWITCH_SELECT != HDMI_SWITCH_NONE)
            break;
            #endif


            #if (INPUT_SV_VIDEO_COUNT >= 1)
        case INPUT_SOURCE_SVIDEO:
            #ifdef Switch_SV
            Switch_SV();
            #endif

          #if (HDMI_SWITCH_SELECT != HDMI_SWITCH_NONE)
            #if(INPUT_HDMI_VIDEO_COUNT > 1)
            HDMI_STANDBY_MODE();
            #endif
          #endif // #if (HDMI_SWITCH_SELECT != HDMI_SWITCH_NONE)
            break;
            #endif


            #if (INPUT_SV_VIDEO_COUNT >= 2)
        case INPUT_SOURCE_SVIDEO2:
            #ifdef Switch_SV2
            Switch_SV2();
            #endif

          #if (HDMI_SWITCH_SELECT != HDMI_SWITCH_NONE)
            #if(INPUT_HDMI_VIDEO_COUNT > 1)
            HDMI_STANDBY_MODE();
            #endif
          #endif // #if (HDMI_SWITCH_SELECT != HDMI_SWITCH_NONE)
            break;
            #endif


      #if (INPUT_YPBPR_VIDEO_COUNT >= 1)
        case INPUT_SOURCE_YPBPR:
            #ifdef Switch_YPBPR
            Switch_YPBPR();
            #endif

          #if (HDMI_SWITCH_SELECT != HDMI_SWITCH_NONE)
            #if(INPUT_HDMI_VIDEO_COUNT > 1)
            HDMI_STANDBY_MODE();
            #endif
          #endif // #if (HDMI_SWITCH_SELECT != HDMI_SWITCH_NONE)
            break;
       #endif


            #if (INPUT_YPBPR_VIDEO_COUNT >= 2)
        case INPUT_SOURCE_YPBPR2:
            #ifdef Switch_YPBPR2
            Switch_YPBPR2();
            #endif

          #if (HDMI_SWITCH_SELECT != HDMI_SWITCH_NONE)
            #if(INPUT_HDMI_VIDEO_COUNT > 1)
            HDMI_STANDBY_MODE();
            #endif
          #endif // #if (HDMI_SWITCH_SELECT != HDMI_SWITCH_NONE)
            break;
            #endif


            #if (INPUT_SCART_VIDEO_COUNT >= 1)
        case INPUT_SOURCE_SCART:
            #ifdef Switch_SCART
            Switch_SCART();
            #endif

          #if (HDMI_SWITCH_SELECT != HDMI_SWITCH_NONE)
            #if(INPUT_HDMI_VIDEO_COUNT > 1)
            HDMI_STANDBY_MODE();
            #endif
          #endif // #if (HDMI_SWITCH_SELECT != HDMI_SWITCH_NONE)
            break;
            #endif

            #if (INPUT_SCART_VIDEO_COUNT >= 2)
        case INPUT_SOURCE_SCART2:
            #ifdef Switch_SCART2
            Switch_SCART2();
            #endif

          #if (HDMI_SWITCH_SELECT != HDMI_SWITCH_NONE)
            #if(INPUT_HDMI_VIDEO_COUNT > 1)
            HDMI_STANDBY_MODE();
            #endif
          #endif // #if (HDMI_SWITCH_SELECT != HDMI_SWITCH_NONE)
            break;
            #endif


       #if (INPUT_HDMI_VIDEO_COUNT >= 1)
        case INPUT_SOURCE_HDMI:
            #ifdef Switch_DVI
            Switch_DVI();
            #endif

          #if (HDMI_SWITCH_SELECT != HDMI_SWITCH_NONE)
            Switch_HDMI1();
          #endif // #if (HDMI_SWITCH_SELECT != HDMI_SWITCH_NONE)
            break;
       #endif


       #if (INPUT_HDMI_VIDEO_COUNT >= 2)
        case INPUT_SOURCE_HDMI2:
            #ifdef Switch_DVI2
            Switch_DVI2();
            #endif

          #if (HDMI_SWITCH_SELECT != HDMI_SWITCH_NONE)
            Switch_HDMI2();
          #endif // #if (HDMI_SWITCH_SELECT != HDMI_SWITCH_NONE)
          break;
       #endif


       #if (INPUT_HDMI_VIDEO_COUNT >= 3)
        case INPUT_SOURCE_HDMI3:
            #ifdef Switch_DVI3
            Switch_DVI3();
            #endif

          #if (HDMI_SWITCH_SELECT != HDMI_SWITCH_NONE)
            Switch_HDMI3();
          #endif // #if (HDMI_SWITCH_SELECT != HDMI_SWITCH_NONE)
            break;
       #endif


       #if (INPUT_HDMI_VIDEO_COUNT >= 4)
        case INPUT_SOURCE_HDMI4:
       #ifdef Switch_DVI4
            Switch_DVI4();
            #endif

          #if (HDMI_SWITCH_SELECT != HDMI_SWITCH_NONE)
            Switch_HDMI4();
          #endif // #if (HDMI_SWITCH_SELECT != HDMI_SWITCH_NONE)
            break;
            #endif


		case INPUT_SOURCE_STORAGE:
			USBPowerOn();
			break;


        default:
            #ifdef Switch_DEFAULT
            Switch_DEFAULT();
            #endif

          #if (HDMI_SWITCH_SELECT != HDMI_SWITCH_NONE)
            #if(INPUT_HDMI_VIDEO_COUNT > 1)
            HDMI_STANDBY_MODE();
            #endif
          #endif // #if (HDMI_SWITCH_SELECT != HDMI_SWITCH_NONE)
            break;
    }

}

static void MApp_InputSource_SetInputSource( SCALER_WIN eWindow, MS_SYS_INFO *penMsSysInfo )
{
    MApp_SwitchInputSrcPin( penMsSysInfo->enInputSourceType );

    #if (FRONTEND_IF_DEMODE_TYPE == MSTAR_VIF_MSB1210)
    if (penMsSysInfo->enInputSourceType != INPUT_SOURCE_TV)
        gMSB1210ATVMode = 0;
    #endif
    if (IsATVInUse())
    {
         MDrv_IFDM_Init();//Brian 20101215 move vif_initial in front of vd_mcu_reset to set vif path clock
    }
    if ( IsSrcTypeDigitalVD(penMsSysInfo->enInputSourceType) )
    {
        // BY 20090707 ADC set source should be done before VD change source
        MApp_InputSource_ChangeVideoSource( penMsSysInfo->enInputSourceType );
    }
#if ( (CHIP_FAMILY_TYPE == CHIP_FAMILY_S7LD)    \
   || (CHIP_FAMILY_TYPE == CHIP_FAMILY_S7J)     \
    || (CHIP_FAMILY_TYPE == CHIP_FAMILY_M10)     \
    || (CHIP_FAMILY_TYPE == CHIP_FAMILY_A7)     \
    || (CHIP_FAMILY_TYPE == CHIP_FAMILY_M12) )  //VIF related clk
        //Set 0x0B00[4] = 1 for CVBS out on Component,HDMI,VGA 20100426EL
        if(IsSrcTypeAnalog(penMsSysInfo->enInputSourceType) ||
            IsSrcTypeHDMI(penMsSysInfo->enInputSourceType))
        {
            MDrv_WriteByteMask(0x100B00, 0x10, 0x10);
        }

        //Set 0x0B4C[2] = 0 to select DAC out clock (0: VIF, 1: AV) to fix CVBS out spur issue on AV/SV/SCART 20100618EL
        if(IsSrcTypeDigitalVD(penMsSysInfo->enInputSourceType))
        {
            MDrv_WriteByteMask(0x100B4C, 0x00, 0x04);
        }
    #endif


    #if ENABLE_DMP
    if( IsSrcTypeDTV(SYS_INPUT_SOURCE_TYPE(eWindow))||IsSrcTypeStorage(SYS_INPUT_SOURCE_TYPE(eWindow)) )
    #else
    if( IsSrcTypeDTV(SYS_INPUT_SOURCE_TYPE(eWindow)) )
    #endif
    {
        MApp_VID_VariableInit();

//        msAPI_VID_VOPInit();
        MDrv_MVOP_Init();

        MDrv_MVOP_Enable( TRUE );
//        msAPI_VID_SetVOPClk( ENABLE );
    }
    //exp: In PIP/POP mode, main is TV and switch sub to another source.
    // It should not init DTV "AGAIN"
    else if(IsDTVInUse())
    {
    }
    else
    {

//        msAPI_VID_SetVOPClk( DISABLE );
        //Disable MVOP, if not DTV or Storage
        MDrv_MVOP_Enable( FALSE );
        MDrv_MVOP_Exit();
    }

#if ENABLE_DTV

  #if (CHIP_FAMILY_TYPE == CHIP_FAMILY_S7 || \
       CHIP_FAMILY_TYPE == CHIP_FAMILY_S7LD || \
       CHIP_FAMILY_TYPE == CHIP_FAMILY_S8 || \
       CHIP_FAMILY_TYPE == CHIP_FAMILY_S7L || \
       (CHIP_FAMILY_TYPE == CHIP_FAMILY_J2) || \
       (CHIP_FAMILY_TYPE == CHIP_FAMILY_A1) || \
       (CHIP_FAMILY_TYPE == CHIP_FAMILY_A5) || \
       (CHIP_FAMILY_TYPE == CHIP_FAMILY_A6) || \
       (CHIP_FAMILY_TYPE == CHIP_FAMILY_A7))
    #if ((FRONTEND_DEMOD_TYPE == EMBEDDED_DVBT_DEMOD) || (FRONTEND_DEMOD_TYPE == EMBEDDED_DVBC_DEMOD)\
    || (FRONTEND_SECOND_DEMOD_TYPE == EMBEDDED_DVBT_DEMOD) || (FRONTEND_SECOND_DEMOD_TYPE == EMBEDDED_DVBC_DEMOD))
    if(IsSrcTypeDTV(SYS_INPUT_SOURCE_TYPE(eWindow)))
    {

#if (ENABLE_T_C_COMBO || DVB_T_C_DIFF_DB)//TODO need add DVB-C case
        msAPI_Tuner_SwitchSource((EN_DVB_TYPE)stGenSetting.stScanMenuSetting.u8DVBCTvConnectionType, FALSE);
#endif
        msAPI_Tuner_Initialization(1);

    }
    #endif
  #endif
#endif


  #if ((FRONTEND_IF_DEMODE_TYPE  == MSTAR_INTERN_VIF)||(FRONTEND_DEMOD_TYPE == MSTAR_MSB1210_DEMOD))
    if (IsSrcTypeATV(SYS_INPUT_SOURCE_TYPE(eWindow))
        ||IsSrcTypeAnalog(SYS_INPUT_SOURCE_TYPE(eWindow))
        ||IsSrcTypeHDMI(SYS_INPUT_SOURCE_TYPE(eWindow))
        ||IsSrcTypeAV(SYS_INPUT_SOURCE_TYPE(eWindow))
        ||IsSrcTypeSV(SYS_INPUT_SOURCE_TYPE(eWindow))
       )
        {
       // printf("<<<<<<<<<<<<<<<<<<< MDrv_IFDM_Init\n");
      //  MDrv_IFDM_Init();
        	msAPI_Tuner_SetIF();
    }
    #endif

}

//*************************************************************************
//Function name:    MApp_InputSource_SetSystemmInfo
//Passing parameter:    U8  u8InputSrcType: current input source type
//                        MS_SYS_INFO *penMsSysInfo
//Return parameter:    none
//Description:            get system info. by enInputSourceType
//*************************************************************************

void MApp_InputSource_SetSystemmInfo( E_UI_INPUT_SOURCE enUiInputSourceType, MS_SYS_INFO *penMsSysInfo , E_DATA_INPUT_SOURCE *penDataInpSrcType)
{
    INPUTSOURCE_DBG( printf( "enUiInputSourceType  = %bu\n", ( U8 ) enUiInputSourceType ) );

    switch ( enUiInputSourceType )
    {
    #if ENABLE_DTV
        case UI_INPUT_SOURCE_DTV:
            INPUTSOURCE_DBG( printf("__DTV__ [ch%bu] \r\n", (U8)g_enChType) );
            penMsSysInfo->enInputSourceType = INPUT_SOURCE_DTV;
            *penDataInpSrcType = DATA_INPUT_SOURCE_DTV;
            break;
    #endif

        case UI_INPUT_SOURCE_ATV:
            INPUTSOURCE_DBG( printf("__ATV__ [ch%bu] \r\n", (U8)g_enChType) );
            penMsSysInfo->enInputSourceType = INPUT_SOURCE_TV;
            *penDataInpSrcType = DATA_INPUT_SOURCE_ATV;
            break;

            #if (INPUT_AV_VIDEO_COUNT >= 1)
        case UI_INPUT_SOURCE_AV:
            INPUTSOURCE_DBG( printf("__AV__ \r\n") );
            penMsSysInfo->enInputSourceType = INPUT_SOURCE_CVBS;
            *penDataInpSrcType = DATA_INPUT_SOURCE_AV;
            break;
            #endif

            #if (INPUT_AV_VIDEO_COUNT >= 2)
        case UI_INPUT_SOURCE_AV2:
            INPUTSOURCE_DBG( printf("__AV_2__ \r\n") );
            penMsSysInfo->enInputSourceType = INPUT_SOURCE_CVBS2;
            *penDataInpSrcType = DATA_INPUT_SOURCE_AV2;
            break;
            #endif

            #if (INPUT_AV_VIDEO_COUNT >= 3)
        case UI_INPUT_SOURCE_AV3:
            INPUTSOURCE_DBG( printf("__AV_3__ \r\n") );
            penMsSysInfo->enInputSourceType = INPUT_SOURCE_CVBS3;
            *penDataInpSrcType = DATA_INPUT_SOURCE_AV3;
            break;
            #endif

            #if (INPUT_SV_VIDEO_COUNT >= 1)
        case UI_INPUT_SOURCE_SVIDEO:
            INPUTSOURCE_DBG( printf("__SVIDEO__ \r\n") );
            penMsSysInfo->enInputSourceType = INPUT_SOURCE_SVIDEO;
            *penDataInpSrcType= DATA_INPUT_SOURCE_SVIDEO;
            break;
            #endif

            #if ((INPUT_SCART_USE_SV2 == 0) && (INPUT_SV_VIDEO_COUNT >= 2))
        case UI_INPUT_SOURCE_SVIDEO2:
            INPUTSOURCE_DBG( printf("__SVIDEO_2__ \r\n") );
            penMsSysInfo->enInputSourceType = INPUT_SOURCE_SVIDEO2;
            *penDataInpSrcType = DATA_INPUT_SOURCE_SVIDEO2;
            break;
            #endif

            #if (INPUT_YPBPR_VIDEO_COUNT >= 1)
        case UI_INPUT_SOURCE_COMPONENT:
            INPUTSOURCE_DBG( printf("__YPBPR__ \r\n") );
            penMsSysInfo->enInputSourceType = INPUT_SOURCE_YPBPR;
            *penDataInpSrcType = DATA_INPUT_SOURCE_COMPONENT;
            break;
            #endif

            #if (INPUT_YPBPR_VIDEO_COUNT >= 2)
        case UI_INPUT_SOURCE_COMPONENT2:
            INPUTSOURCE_DBG( printf("__YPBPR_2__ \r\n") );
            penMsSysInfo->enInputSourceType = INPUT_SOURCE_YPBPR2;
            *penDataInpSrcType = DATA_INPUT_SOURCE_COMPONENT2;
            break;
            #endif

        case UI_INPUT_SOURCE_RGB:
            INPUTSOURCE_DBG( printf("__RGB__ \r\n") );
            penMsSysInfo->enInputSourceType = INPUT_SOURCE_VGA;
            *penDataInpSrcType = DATA_INPUT_SOURCE_RGB;
            break;

    #if (INPUT_HDMI_VIDEO_COUNT > 0)
        case UI_INPUT_SOURCE_HDMI:
            INPUTSOURCE_DBG( printf("__HDMI__ \r\n") );
            penMsSysInfo->enInputSourceType = INPUT_SOURCE_HDMI;
            *penDataInpSrcType = DATA_INPUT_SOURCE_HDMI;
            break;
    #endif

    #if (INPUT_HDMI_VIDEO_COUNT >= 2)
        case UI_INPUT_SOURCE_HDMI2:
            INPUTSOURCE_DBG( printf("__HDMI_2__ \r\n") );
            penMsSysInfo->enInputSourceType = INPUT_SOURCE_HDMI2;
            *penDataInpSrcType = DATA_INPUT_SOURCE_HDMI2;
            break;
    #endif

    #if (INPUT_HDMI_VIDEO_COUNT >= 3)
        case UI_INPUT_SOURCE_HDMI3:
            INPUTSOURCE_DBG( printf("__HDMI_3__ \r\n") );
            penMsSysInfo->enInputSourceType = INPUT_SOURCE_HDMI3;
            *penDataInpSrcType = DATA_INPUT_SOURCE_HDMI3;
            break;
    #endif

    #if (INPUT_HDMI_VIDEO_COUNT >= 4)
        case UI_INPUT_SOURCE_HDMI4:
            INPUTSOURCE_DBG( printf("__HDMI_4__ \r\n") );
            penMsSysInfo->enInputSourceType = INPUT_SOURCE_HDMI4;
            *penDataInpSrcType = DATA_INPUT_SOURCE_HDMI4;
            break;
    #endif

            #if (INPUT_SCART_VIDEO_COUNT >= 1)
        case UI_INPUT_SOURCE_SCART:
            INPUTSOURCE_DBG( printf("__SCART__ \r\n") );
            #if ((INPUT_SCART_USE_SV2 == 1) && (INPUT_SV_VIDEO_COUNT >= 2))
            if((!msAPI_AVD_IsScartRGB()) && (stGenSetting.g_SysSetting.fSCARTInputSel == EN_SCART_SEL_SV))
            {
                penMsSysInfo->enInputSourceType = INPUT_SOURCE_SVIDEO2;
                *penDataInpSrcType = DATA_INPUT_SOURCE_SVIDEO2;
            }
            else
            #endif
            {
                penMsSysInfo->enInputSourceType = INPUT_SOURCE_SCART;
                *penDataInpSrcType = DATA_INPUT_SOURCE_SCART;
            }
            break;
            #endif

            #if (INPUT_SCART_VIDEO_COUNT >= 2)
        case UI_INPUT_SOURCE_SCART2:
            INPUTSOURCE_DBG( printf("__SCART_2__ \r\n") );
            penMsSysInfo->enInputSourceType = INPUT_SOURCE_SCART2;
            *penDataInpSrcType = DATA_INPUT_SOURCE_SCART2;
            break;
            #endif

#if ENABLE_DMP
        case UI_INPUT_SOURCE_DMP:
      #if( ENABLE_DMP_SWITCH )
        case UI_INPUT_SOURCE_DMP1:
        case UI_INPUT_SOURCE_DMP2:
      #endif
            INPUTSOURCE_DBG( printf("__DMP__ \r\n") );
            penMsSysInfo->enInputSourceType = INPUT_SOURCE_STORAGE;
            *penDataInpSrcType = DATA_INPUT_SOURCE_STORAGE;
            #ifdef ENABLE_KTV
            gbKTVFlag = FALSE;
            #endif
            break;
#endif

#ifdef ENABLE_BT
        case UI_INPUT_SOURCE_BT:
            INPUTSOURCE_DBG( printf("__BT__ \r\n") );
            penMsSysInfo->enInputSourceType = INPUT_SOURCE_STORAGE;// need modify late
            *penDataInpSrcType = DATA_INPUT_SOURCE_STORAGE;
            break;
#endif

#ifdef ENABLE_KTV
        case UI_INPUT_SOURCE_KTV:
            INPUTSOURCE_DBG( printf("__KTV__ \r\n") );
            penMsSysInfo->enInputSourceType = INPUT_SOURCE_STORAGE;// need modify late
            *penDataInpSrcType = DATA_INPUT_SOURCE_STORAGE;
            gbKTVFlag = TRUE;
            break;
#endif

#ifdef ENABLE_RSS
        case UI_INPUT_SOURCE_RSS:
            INPUTSOURCE_DBG( printf("__RSS__ \r\n") );
            penMsSysInfo->enInputSourceType = INPUT_SOURCE_STORAGE;// need modify late
            *penDataInpSrcType = DATA_INPUT_SOURCE_STORAGE;
            break;
#endif

//#ifdef ENABLE_NETFLIX
//        case UI_INPUT_SOURCE_NETFLIX:
//            INPUTSOURCE_DBG( printf("__NETFLIX__ \r\n") );
//            penMsSysInfo->enInputSourceType = INPUT_SOURCE_STORAGE;// need modify late
//            *penDataInpSrcType = DATA_INPUT_SOURCE_STORAGE;
//            break;
//#endif

#ifdef ENABLE_EXTENSION
        case UI_INPUT_SOURCE_EXTENSION:
            INPUTSOURCE_DBG( printf("__EXTENSION__ \r\n") );
            penMsSysInfo->enInputSourceType = INPUT_SOURCE_STORAGE;// need modify late
            *penDataInpSrcType = DATA_INPUT_SOURCE_STORAGE;
            break;
#endif

#ifdef ENABLE_YOUTUBE
        case UI_INPUT_SOURCE_YOUTUBE:
            INPUTSOURCE_DBG( printf("__YOUTUBE__ \r\n") );
            penMsSysInfo->enInputSourceType = INPUT_SOURCE_STORAGE;// need modify late
            *penDataInpSrcType = DATA_INPUT_SOURCE_STORAGE;
            break;
#endif

#if (ENABLE_GAME)
        case UI_INPUT_SOURCE_GAME:
            INPUTSOURCE_DBG( printf("__GAME__ \r\n") );
            penMsSysInfo->enInputSourceType = INPUT_SOURCE_STORAGE;// need modify late
            *penDataInpSrcType = DATA_INPUT_SOURCE_STORAGE;
            break;
#endif

        case UI_INPUT_SOURCE_NONE:
            INPUTSOURCE_DBG( printf("__NONE__ \r\n") );
            penMsSysInfo->enInputSourceType = INPUT_SOURCE_NONE;
            *penDataInpSrcType = DATA_INPUT_SOURCE_NONE;
            break;

        default:
        #if ENABLE_DTV
            penMsSysInfo->enInputSourceType = INPUT_SOURCE_DTV;
            *penDataInpSrcType = DATA_INPUT_SOURCE_DTV;
        #else
            penMsSysInfo->enInputSourceType = INPUT_SOURCE_TV;
            *penDataInpSrcType = DATA_INPUT_SOURCE_ATV;
        #endif
            INPUTSOURCE_DBG(printf("Error enInputSourceType \r\n"));
            return;
    }

    INPUTSOURCE_DBG( printf( "Result enInputSourceType = %bu\n", ( U8 ) penMsSysInfo->enInputSourceType ) );

#ifdef SCART_OUT_NEW_METHOD
//About the SCART OUT information generate
    MDrv_VE_Check_SCART_OUT_Mute();
#endif

}

//*************************************************************************
//Function name:    MApp_InputSource_InitModeVariables
//Passing parameter:    none
//Return parameter:     none
//Description:      initialize variables for mode changing
//*************************************************************************

static void MApp_InputSource_InitModeVariables( SCALER_WIN eWindow )
{
    // restart timing monitor
    MApi_XC_PCMonitor_Restart(eWindow);

    // input timing flag
    g_u8PcUserModeRamIndex[eWindow] = 0xFF;

#if ENABLE_OFFLINE_SIGNAL_DETECTION
     stAISCtrl.bUICHSourceFlag=1;
     stAISCtrl.bSysTimeDuty=0;
     //stAISCtrl.bAISLock=1;    //When Switch Source ,Lock AIS Polling;
     stAISCtrl.dLockCnt=TIMER_GO;    //    Begin Lock  Counter
     stAISCtrl.bDotimes=0;
     stAISCtrl.bNoSignal=0;
     stAISCtrl.bDetectCnt=0;
#endif

    #if ( ENABLE_DLC )
        #if ENABLE_CUS_DLC
        g_bEnableDLC = ST_PICTURE.bDLCStatus;
        #else
        g_bEnableDLC = FALSE;
        #endif
    #endif

    if(IsSrcTypeHDMI(SYS_INPUT_SOURCE_TYPE(eWindow)) || IsSrcTypeDVI(SYS_INPUT_SOURCE_TYPE(eWindow)))
    {
        MApi_XC_HDMI_Handler_Init();
    }

}
//*************************************************************************
//Function name:    MAPP_InputSource_SwitchHDMI_DVI
//Passing parameter:    HDMI or DVI mode
//Return parameter:     void
//Description:      Do all things about switching mode between HDMI / DVI
//*************************************************************************
void MAPP_InputSource_SwitchHDMI_DVI( U8 Source_Type)
{
     /*
           Now only implement audio channel swithing.
           The video swithing is not be done yet.
     */
    if ( (E_XC_HDMI_Status) Source_Type == E_HDMI_STATUS_DVI)
    {
        MApp_InputSource_ChangeAudioSource(INPUT_SOURCE_DVI);
    }
    else if ( (E_XC_HDMI_Status) Source_Type == E_HDMI_STATUS_HDMI)
    {
        MApp_InputSource_ChangeAudioSource(INPUT_SOURCE_HDMI);
    }

}

#if ( ENABLE_PWS)

static E_PWS_SouceInfo _MAPP_InputSource_Source2PWSSource(INPUT_SOURCE_TYPE_t src )
{
    E_PWS_SouceInfo enTargetSource = _UNKNOWN_;

    if ( IsSrcTypeVga(src) )
    {
        enTargetSource = _RGB_;
    }
    else if ( IsSrcTypeYPbPr(src) )
    {
        enTargetSource = _YPbPr_;
    }
    else if ( IsSrcTypeDTV(src) )
    {
        enTargetSource = _DTV_DVB_; // ATSC???
    }
    else if ( src == INPUT_SOURCE_HDMI)
    {
        enTargetSource = _HDMI1_;
    }
    else if ( src == INPUT_SOURCE_HDMI2)
    {
        enTargetSource = _HDMI2_;
    }
    else if ( src == INPUT_SOURCE_HDMI3)
    {
        enTargetSource = _HDMI3_;
    }
    else if ( src == INPUT_SOURCE_HDMI4)
    {
        enTargetSource = _HDMI4_;
    }
    else if ( IsSrcTypeScart(src) )
    {
        enTargetSource = _SCART_;
    }
    else if ( IsSrcTypeAV(src) )
    {
        enTargetSource = _CVBS_;
    }
    else if ( IsSrcTypeSV(src) )
    {
        enTargetSource = _SV_;
    }
    else if ( IsSrcTypeStorage(src) )
    {
        enTargetSource = _USB_;
    }
    else if ( IsSrcTypeATV(src) )
    {
        enTargetSource = _ATV_VIF_;
    }

    return enTargetSource;
    }
    #endif


void MApp_InputSource_SetVideoOut(SCALER_WIN eWindow,
                                INPUT_SOURCE_TYPE_t u8PreCVBS1OutSource, INPUT_SOURCE_TYPE_t u8NewCVBS1OutSource,
                                INPUT_SOURCE_TYPE_t u8PreCVBS2OutSource, INPUT_SOURCE_TYPE_t u8NewCVBS2OutSource)
{
    XC_MUX_PATH_INFO PathInfo;
    S16 s16PathId;

    // TO DO. need to re-organize, has some problem. Need to check with Kenny

    eWindow = eWindow;
    u8PreCVBS1OutSource=u8PreCVBS1OutSource;
#if 1//(FORCE_ALL_OUTPUT_THROUGH_VE != ENABLE)

    SYS_CVBS1_OUT_SOURCE_TYPE(eWindow) = u8NewCVBS1OutSource;

    if((u8NewCVBS1OutSource != INPUT_SOURCE_NONE))// && (u8NewCVBS1OutSource != u8PreCVBS1OutSource))
    {
        PathInfo.Path_Type = PATH_TYPE_SYNCHRONOUS;
        PathInfo.src = u8NewCVBS1OutSource;
        PathInfo.dest = OUTPUT_CVBS1;

    #if(ENABLE_DTV)
        if (IsSrcTypeDTV(u8NewCVBS1OutSource))
        {
            PathInfo.path_thread = MApp_DTV_Handler;
        }
        else
    #endif
        if (IsSrcTypeDigitalVD(u8NewCVBS1OutSource))
    {
            PathInfo.path_thread = MApp_ATV_Handler;
    }
    #if(ENABLE_DMP)
        else if(IsSrcTypeStorage(u8NewCVBS1OutSource))
    {
            PathInfo.path_thread = MApp_Storage_Handler;
    }
    #endif

        PathInfo.SyncEventHandler = MApp_Scaler_CVBS1OutSyncEventHandler;
        PathInfo.DestOnOff_Event_Handler = MApp_Scaler_CVBS1OutOnOffEventHandler;
        PathInfo.dest_periodic_handler = NULL;

        s16PathId = MApi_XC_Mux_CreatePath(&PathInfo, sizeof(XC_MUX_PATH_INFO) );

        if (s16PathId == -1)
    {
            SIGNAL_PATH_DBG(printf(" Create CVBS1 path fail src = %d  dest = %d \n",PathInfo.src ,PathInfo.dest ));
    }
        else
    {
            MApi_XC_Mux_EnablePath( (U16)s16PathId );
            SIGNAL_PATH_DBG(printf(" Create CVBS1 path success src = %d  dest = %d \n",PathInfo.src ,PathInfo.dest ));
    }
    }

  #if (INPUT_SCART_VIDEO_COUNT >= 2)

    SYS_CVBS2_OUT_SOURCE_TYPE(eWindow) = u8NewCVBS2OutSource;

    // Create CVBS out path2
    if((u8NewCVBS2OutSource != INPUT_SOURCE_NONE)&&(u8NewCVBS2OutSource != u8PreCVBS2OutSource))
    {
        PathInfo.Path_Type = PATH_TYPE_SYNCHRONOUS;
        PathInfo.src = u8NewCVBS2OutSource;
        PathInfo.dest = OUTPUT_CVBS2;

      #if(ENABLE_DTV)
        if (IsSrcTypeDTV(u8NewCVBS2OutSource))
        {
            PathInfo.path_thread = MApp_DTV_Handler;
    }
        else
      #endif
        if (IsSrcTypeDigitalVD(u8NewCVBS2OutSource))
    {
            PathInfo.path_thread = MApp_ATV_Handler;
    }
        else if(IsSrcTypeStorage(u8NewCVBS2OutSource))
    {
            PathInfo.path_thread = MApp_Storage_Handler;
    }
        PathInfo.SyncEventHandler = MApp_Scaler_CVBS2OutSyncEventHandler;
        PathInfo.DestOnOff_Event_Handler = MApp_Scaler_CVBS2OutOnOffEventHandler;
        PathInfo.dest_periodic_handler = NULL;

        s16PathId = MApi_XC_Mux_CreatePath(&PathInfo, sizeof(XC_MUX_PATH_INFO) );

        if (s16PathId == -1)
    {
            SIGNAL_PATH_DBG(printf(" Create CVBS2 path fail src = %d  dest = %d \n",PathInfo.src ,PathInfo.dest ));
    }
        else
    {
            MApi_XC_Mux_EnablePath( (U16)s16PathId );
            SIGNAL_PATH_DBG(printf(" Create CVBS2 path success src = %d  dest = %d \n",PathInfo.src ,PathInfo.dest ));
    }
    }
  #else
    u8PreCVBS2OutSource = u8PreCVBS2OutSource;
    u8NewCVBS2OutSource = u8NewCVBS2OutSource;
  #endif // #if (INPUT_SCART_VIDEO_COUNT >= 2)

#else // #if(FORCE_ALL_OUTPUT_THROUGH_VE != ENABLE)

    u8NewCVBS1OutSource = u8NewCVBS1OutSource;
    u8PreCVBS1OutSource = u8PreCVBS1OutSource;

    // Create CVBS out path
    if (IsSrcTypeATV(SYS_INPUT_SOURCE_TYPE(eWindow))
      ||IsSrcTypeAV(SYS_INPUT_SOURCE_TYPE(eWindow))
    #if (ENABLE_VE)
      ||IsSrcTypeDTV(SYS_INPUT_SOURCE_TYPE(eWindow))
     #if ENABLE_MM_VE_OUTPUT
      ||IsSrcTypeStorage(SYS_INPUT_SOURCE_TYPE(eWindow))
     #endif
    #endif //#if (ENABLE_VE)
        )
    {
        PathInfo.Path_Type = PATH_TYPE_SYNCHRONOUS;
        PathInfo.src = SYS_INPUT_SOURCE_TYPE(eWindow);
        PathInfo.dest = OUTPUT_CVBS1;

      #if(ENABLE_DTV)
        if (IsSrcTypeDTV(stSystemInfo[eWindow].enInputSourceType))
        {
            PathInfo.path_thread = MApp_DTV_Handler;
    }
        else
      #endif
        if (IsSrcTypeDigitalVD(stSystemInfo[eWindow].enInputSourceType))
    {
            PathInfo.path_thread = MApp_ATV_Handler;
    }
    #if(ENABLE_DMP)
        else if(IsSrcTypeStorage(SYS_INPUT_SOURCE_TYPE(eWindow)))
    {
            PathInfo.path_thread = MApp_Storage_Handler;
    }
    #endif

        PathInfo.SyncEventHandler = MApp_Scaler_CVBS1OutSyncEventHandler;
        PathInfo.DestOnOff_Event_Handler = MApp_Scaler_CVBS1OutOnOffEventHandler;
        PathInfo.dest_periodic_handler = NULL;

        s16PathId = MApi_XC_Mux_CreatePath(&PathInfo, sizeof(XC_MUX_PATH_INFO) );

        if (s16PathId == -1)
        {
            SIGNAL_PATH_DBG(printf(" Create CVBS1 path fail src = %d  dest = %d \n",PathInfo.src ,PathInfo.dest ));
        }
        else
        {
            SIGNAL_PATH_DBG(printf(" Create CVBS1 path success src = %d  dest = %d \n",PathInfo.src ,PathInfo.dest ));
            MApi_XC_Mux_EnablePath( (U16)s16PathId );
}
    }


  #if (INPUT_SCART_VIDEO_COUNT >= 2)
    // Create CVBS out path2
    if (IsSrcTypeATV(SYS_INPUT_SOURCE_TYPE(eWindow))
      ||IsSrcTypeAV(SYS_INPUT_SOURCE_TYPE(eWindow))
      ||IsSrcTypeScart(SYS_INPUT_SOURCE_TYPE(eWindow))
    #if (ENABLE_VE)
      ||IsSrcTypeDTV(SYS_INPUT_SOURCE_TYPE(eWindow))
     #if ENABLE_MM_VE_OUTPUT
      ||IsSrcTypeStorage(SYS_INPUT_SOURCE_TYPE(eWindow))
#endif
    #endif //#if (ENABLE_VE)
        )
    {
        PathInfo.Path_Type = PATH_TYPE_SYNCHRONOUS;
        PathInfo.src = SYS_INPUT_SOURCE_TYPE(eWindow);
        PathInfo.dest = OUTPUT_CVBS2;

      #if(ENABLE_DTV)
        if (IsSrcTypeDTV(stSystemInfo[eWindow].enInputSourceType))
        {
            PathInfo.path_thread = MApp_DTV_Handler;
        }
        else
#endif
        if (IsSrcTypeDigitalVD(stSystemInfo[eWindow].enInputSourceType))
        {
            PathInfo.path_thread = MApp_ATV_Handler;
        }
        else if(IsSrcTypeStorage(SYS_INPUT_SOURCE_TYPE(eWindow)))
        {
            PathInfo.path_thread = MApp_Storage_Handler;
        }

        PathInfo.SyncEventHandler = MApp_Scaler_CVBS2OutSyncEventHandler;
        PathInfo.DestOnOff_Event_Handler = MApp_Scaler_CVBS2OutOnOffEventHandler;
        PathInfo.dest_periodic_handler = NULL;

        s16PathId = MApi_XC_Mux_CreatePath(&PathInfo, sizeof(XC_MUX_PATH_INFO) );

        if (s16PathId == -1)
        {
            SIGNAL_PATH_DBG(printf(" Create CVBS2 path fail src = %d  dest = %d \n",PathInfo.src ,PathInfo.dest ));
        }
        else
        {
            SIGNAL_PATH_DBG(printf(" Create CVBS2 path success src = %d  dest = %d \n",PathInfo.src ,PathInfo.dest ));
            MApi_XC_Mux_EnablePath( (U16)s16PathId );
        }
    }
  #endif // #if (INPUT_SCART_VIDEO_COUNT >= 2)
#endif //(ALL_SOURCE_OUTPUT_THROUGH_VE != ENABLE)

}

//*************************************************************************
//Function name:    MApp_InputSource_SwitchSource
//Passing parameter:    U8 u8InputSrc: input source type
//Return parameter:     none
//Description:      change input source
//*************************************************************************
extern EN_VD_SIGNALTYPE g_ePreVideoSystem;
extern BOOL g_bPreInit_SkipChangeAudioSrc;
#if ENABLE_SZ_BLUESCREEN_FUNCTION
extern BOOLEAN bIsNeedBlueScreen;
#endif

void MApp_InputSource_SwitchSource( E_UI_INPUT_SOURCE enUiInputSourceType,SCALER_WIN eWindow )
{
    XC_MUX_PATH_INFO PathInfo;
    S16 s16PathId;

    INPUT_SOURCE_TYPE_t u8PreCVBS1OutSource = INPUT_SOURCE_NONE;
    INPUT_SOURCE_TYPE_t u8NewCVBS1OutSource = INPUT_SOURCE_NONE;

    INPUT_SOURCE_TYPE_t u8PreCVBS2OutSource = INPUT_SOURCE_NONE;
    INPUT_SOURCE_TYPE_t u8NewCVBS2OutSource = INPUT_SOURCE_NONE;

    // For CEC usage - sending routing change or active source when switching source
#if ENABLE_CEC
    INPUT_SOURCE_TYPE_t pre_srctype = INPUT_SOURCE_NONE, cur_srctype = INPUT_SOURCE_NONE;
#endif
#if ENABLE_DTV
#if ENABLE_CI
    //for internal DEMOD init
    EN_INTERNAL_DEMOD_MODE ePreDemodMode = msAPI_Tuner_GetDemodMode();
#endif
#endif

    CAL_TIME_FUNC_START();

    INPUTSOURCE_DBG( printf( "=============== eWin = %d ============== \r\n", ( U8 ) eWindow ) );
    INPUTSOURCE_DBG( printf( "Enter enUiInputSourceType = %d \r\n", ( U8 ) enUiInputSourceType ) );
    #if SMC_VGA_SLEEP_COUNT_DOWN_DIPLAY_EN //SMC jayden.chen add for VGA Sleep Counter Display 20130308
    	MApp_Sleep_ReleaseSleepTimer();
    #endif

    //printf("ChangeSrc(%u), %lu\n", enUiInputSourceType, MsOS_GetSystemTime());

    // Enable black screen
    //<<SMC add
    if(enUiInputSourceType>=UI_INPUT_SOURCE_DMP)
    {
        msAPI_Scaler_SetBlueScreen_Origin( ENABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, eWindow);
		msAPI_Timer_Delayms(100);
    }
    else
    //>>>>>>>>>>
    {
        #if ENABLE_SZ_BLUESCREEN_FUNCTION
        if((enUiInputSourceType < UI_INPUT_SOURCE_DMP)&&IsStorageInUse())
        {
            bIsNeedBlueScreen = TRUE;
        }
        #endif
        msAPI_Scaler_SetBlueScreen( ENABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, eWindow);
    }

    if(enUiInputSourceType == UI_INPUT_SOURCE_ATV)
    {
        msAPI_Scaler_SetScreenMute(E_SCREEN_MUTE_TEMPORARY, ENABLE, 2000, eWindow);
    }

#if (MirrorEnable)
    if(IsSrcTypeStorage(SYS_INPUT_SOURCE_TYPE(eWindow))||IsSrcTypeDTV(SYS_INPUT_SOURCE_TYPE(eWindow)))
    {
        //Leaving storage source, so switch to XC mirror
        MDrv_MVOP_SetVOPMirrorMode(DISABLE, E_VOPMIRROR_HORIZONTALL);
        MDrv_MVOP_SetVOPMirrorMode(DISABLE, E_VOPMIRROR_VERTICAL);
        MApi_XC_EnableMirrorMode(TRUE);
    }
#endif

#if (ENABLE_PIP)
    if(!IsPIPSupported())
    {
        if (eWindow == SUB_WINDOW)
        {
            ASSERT("No Sub Window while DISABLE PIP");
        }
    }
#endif

#if (NO_SIGNAL_AUTO_SHUTDOWN==1)
    benableNoSiganlSleepCheck = FALSE;
#endif

    /////////////////////////////////////////
    //Destroy path which destination is eWindow
    /////////////////////////////////////////

    //printf("==>Delete Main Path, SRC =%u, Dest=%u\n",SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW),OUTPUT_SCALER_MAIN_WINDOW);

    if(MApi_XC_Mux_DeletePath(SYS_INPUT_SOURCE_TYPE(eWindow), (eWindow==SUB_WINDOW)?OUTPUT_SCALER_SUB_WINDOW:OUTPUT_SCALER_MAIN_WINDOW)==-1)
    {
        SIGNAL_PATH_DBG(printf("\r\n Delete path fail src =%d \r\n", SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW) ));
    }
    else
    {
        SIGNAL_PATH_DBG(printf("\r\n Delete path success src =%d dst=%d \r\n",
                    SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW), OUTPUT_SCALER_MAIN_WINDOW ));
    }


    // Please NOTE: SYS_INPUT_SOURCE_TYPE is equal to previous input source
    // before MApp_InputSource_SetSystemmInfo called. Clear VE here.
    // This part should be finetuned by APP level when PIP involved.

    #if (FORCE_ALL_OUTPUT_THROUGH_VE != ENABLE)
        u8PreCVBS1OutSource = _MAPP_GET_CVBSOUT_VIDEO_SOURCE(CVBS1_OUTPUT_Tbl, SYS_INPUT_SOURCE_TYPE(eWindow));
    #if (INPUT_SCART_VIDEO_COUNT >= 2)
        u8PreCVBS2OutSource = _MAPP_GET_CVBSOUT_VIDEO_SOURCE(CVBS2_OUTPUT_Tbl, SYS_INPUT_SOURCE_TYPE(eWindow));
    #endif
    #endif

    #if (ENABLE_CUS_DBC && ENABLE_CUS_9WINDOWS_DETECT)
    MApi_XC_Sys_SetVideoPattern9WindowsFlag(FALSE);
    #endif


// Power off (power saving, must after path created)
#if (ENABLE_PWS)
/*****************************************************************************
Power saving do IP power on/off, so the code flow related to IP power on/off
can't be arbitraraily change, like the ADC table (MApi_XC_Mux_CreatePath)
******************************************************************************/
  #if ( (CHIP_FAMILY_TYPE == CHIP_FAMILY_S7LD)      \
     || (CHIP_FAMILY_TYPE == CHIP_FAMILY_S7J)       \
     || (CHIP_FAMILY_TYPE == CHIP_FAMILY_M10)       \
     || (CHIP_FAMILY_TYPE == CHIP_FAMILY_M12)       \
      )

        MDrv_PWS_HandleSource(PWS_DEL_SOURCE,_MAPP_InputSource_Source2PWSSource( SYS_INPUT_SOURCE_TYPE(eWindow) ),PWS_FULL);

        if(IsSrcTypeATV(stSystemInfo[eWindow].enInputSourceType) ||
           IsSrcTypeAV(stSystemInfo[eWindow].enInputSourceType) ||
           IsSrcTypeSV(stSystemInfo[eWindow].enInputSourceType) ||
           IsSrcTypeScart(stSystemInfo[eWindow].enInputSourceType))
        {
            MDrv_PWS_HandleSource(PWS_DEL_SOURCE,_CVBSOi_,PWS_FULL);
        }
   #endif
#endif


#if ENABLE_TTX
    if(eWindow != SUB_WINDOW)
    {
        if (MApp_TTX_IsTeletextOn() == TRUE)
        {
            MApp_TTX_TeletextCommand(TTX_TV);
        }

        msAPI_TTX_VBIAcquireEnable(FALSE);

        msAPI_TTX_Stop();
    }
#endif  // ENABLE_TTX
#if ((ENABLE_SBTVD_BRAZIL_APP) && (BRAZIL_CC))
    if ((IsDTVInUse() && stGenSetting.g_SysSetting.enDTVCaptionType != DTV_CAPTION_OFF)
      ||(IsATVInUse() && stGenSetting.g_SysSetting.enATVCaptionType != ATV_CAPTION_TYPE_OFF))
    {
        if(MApp_CC_GetInfo(CC_SELECTOR_STATUS_CODE) == STATE_CAPTION_PARSER)
        {
            MApp_CC_StopParser();
            MApp_Dmx_PES_Stop();
        }
    }
#endif
#if (ATSC_CC == ATV_CC)
     if ((IsATVInUse()||IsAVInUse()) && stGenSetting.g_SysSetting.enATVCaptionType != ATV_CAPTION_TYPE_OFF)
     {
            if ( MApp_CC_GetInfo(CC_SELECTOR_STATUS_CODE) == STATE_CAPTION_PARSER)
            {
                  MApp_CC_StopParser();
                  MApp_Set_CCState(FALSE);
            }
    }
#endif

      CAL_TIME_FUNC_("ChgSrc");

      // digital IP
#if ENABLE_DTV
    if (IsSrcTypeDTV(SYS_INPUT_SOURCE_TYPE(eWindow)))
    {
    // exit DTV
    #if ENABLE_CI
        if (msAPI_CI_CardDetect())
        {
            //**-- Italy CI Certificate Start --**//
            MEMBER_SERVICETYPE bServiceType;
            WORD wCurrentPosition;

            bServiceType = msAPI_CM_GetCurrentServiceType();
            wCurrentPosition = msAPI_CM_GetCurrentPosition(bServiceType);

            msAPI_CI_SendEmptyPmt(msAPI_CM_GetService_ID(bServiceType, wCurrentPosition), MApp_SI_Get_PSISIVersion(E_VER_PMT));
        }

    //**-- Italy CI Certificate End --**//
    #endif

    #if MHEG5_ENABLE
        if(msAPI_MHEG5_GetBinStatus() == TRUE)
        {
        // Disable Aeon for Non-DTV Mode
        #if (MHEG5_WITH_OSD)
            //if ( msAPI_MHEG5_checkGoBackMHEG5())
            {
                MApi_MHEG5_Disable(EN_MHEG5_DM_DISABLE_AND_WAIT);
            }
        #endif

        #if defined(MIPS_CHAKRA) || defined(__AEONR2__)
            msAPI_AEON_Disable();
        #else
            msAPI_BEON_Disable();
        #endif
        }
    #endif
        //msAPI_VID_Command(MSAPI_VID_STOP);
        MApp_Dmx_CloseAllFilters();
        MApi_DMX_Exit();
        msAPI_Demodulator_Exit();

    }
    else
#endif
    //if (IsSrcTypeATV(SYS_INPUT_SOURCE_TYPE(eWindow)))
    {
        if (IsSrcTypeDigitalVD(SYS_INPUT_SOURCE_TYPE(eWindow)))
        {

            if (IsSrcTypeATV(SYS_INPUT_SOURCE_TYPE(eWindow)))
            {
                #if((FRONTEND_IF_DEMODE_TYPE == MSTAR_VIF)||(FRONTEND_IF_DEMODE_TYPE == MSTAR_INTERN_VIF))

              #if ( (CHIP_FAMILY_TYPE == CHIP_FAMILY_S7LD)  \
                 || (CHIP_FAMILY_TYPE == CHIP_FAMILY_S7J)   \
                 || (CHIP_FAMILY_TYPE == CHIP_FAMILY_A7)   \
                 || (CHIP_FAMILY_TYPE == CHIP_FAMILY_M12)   \
                 || (CHIP_FAMILY_TYPE == CHIP_FAMILY_A7) )
                        if(enUiInputSourceType == UI_INPUT_SOURCE_DTV) //Be disable VIF clock only on DTV(dest.) for CVBS out ATV issue 20100426EL
                    #endif
                        {
                            MDrv_VIF_SetClock(DISABLE); //At ATV,change to another , close VIF
                        }

                #endif
            }

            MDrv_AVD_SetInput(E_INPUT_SOURCE_INVALID,(U8)SCART_FB_NONE);
            msAPI_AVD_Exit();
        }

        #if ENABLE_DTV
        MApi_DMX_Exit();
        #endif

    }

    //////////////////////////////////////////////
    // Mapping UI source to driver supported source
    //////////////////////////////////////////////
    CAL_TIME_FUNC_("ChgSrc");

  #if ENABLE_CEC
    if( eWindow == MAIN_WINDOW )
    {
        pre_srctype = stSystemInfo[MAIN_WINDOW].enInputSourceType;
    }
  #endif

    //Clear previous input source flag
    _MApp_InputSource_ClearSysInputSourceFlag(eWindow);
    MApp_InputSource_SetSystemmInfo( enUiInputSourceType, &stSystemInfo[eWindow] , &g_enDataInputSourceType[eWindow]);
    _MApp_InputSource_SetSysInputSourceFlag(eWindow);

    u8NewCVBS1OutSource = _MAPP_GET_CVBSOUT_VIDEO_SOURCE(CVBS1_OUTPUT_Tbl, SYS_INPUT_SOURCE_TYPE(eWindow));

    #if (INPUT_SCART_VIDEO_COUNT >= 2)
    u8NewCVBS2OutSource = _MAPP_GET_CVBSOUT_VIDEO_SOURCE(CVBS2_OUTPUT_Tbl, SYS_INPUT_SOURCE_TYPE(eWindow));
    #endif

    #if (ENABLE_PIP)
    if(IsPIPSupported())
    #endif
    {
        //used for main / sub window swap
        if(enUiInputSourceType == UI_INPUT_SOURCE_NONE)
        {
            //Close sub window
            if(eWindow == SUB_WINDOW)
            {
                MApi_XC_DisableSubWindow();
            }
            #if 0//TV_FREQ_SHIFT_CLOCK
            g_bChangeChannelAtTVsource = FALSE;
            #endif
            return;
        }
    }

    g_ePreVideoSystem = SIG_NONE;


#if (!((FORCE_ALL_OUTPUT_THROUGH_VE == ENABLE) && (ENABLE_OP2_TO_VE == ENABLE)))

    if ( (u8PreCVBS1OutSource!= INPUT_SOURCE_NONE))//&&(u8PreCVBS1OutSource != u8NewCVBS1OutSource))
    {
        if(MApi_XC_Mux_DeletePath(u8PreCVBS1OutSource,OUTPUT_CVBS1)==-1)
        {
            SIGNAL_PATH_DBG(printf(" delete CVBS1 path fail src = %d  dest = %d \r\n",u8PreCVBS1OutSource ,OUTPUT_CVBS1));
        }
        else
        {
            SIGNAL_PATH_DBG(printf(" delete CVBS1 path success src = %d  dest = %d \r\n",u8PreCVBS1OutSource ,OUTPUT_CVBS1));
        }
        msAPI_Scaler_SetCVBSMute(ENABLE,  E_VE_MUTE_GEN,SYS_INPUT_SOURCE_TYPE(eWindow),OUTPUT_CVBS1);
    }
    #if (INPUT_SCART_VIDEO_COUNT >= 2)
    if((u8PreCVBS2OutSource != u8NewCVBS2OutSource)&&(u8PreCVBS2OutSource!= INPUT_SOURCE_NONE))
    {
        if(MApi_XC_Mux_DeletePath(u8PreCVBS2OutSource,OUTPUT_CVBS2)==-1)
        {
            SIGNAL_PATH_DBG(printf(" delete CVBS2 path fail src = %d  dest = %d \r\n",u8PreCVBS2OutSource ,OUTPUT_CVBS2));
        }
        else
        {
             SIGNAL_PATH_DBG(printf(" delete CVBS2 path success src = %d  dest = %d \r\n",u8PreCVBS2OutSource ,OUTPUT_CVBS2));
        }
        msAPI_Scaler_SetCVBSMute(ENABLE,  E_VE_MUTE_GEN,SYS_INPUT_SOURCE_TYPE(eWindow),OUTPUT_CVBS2);
    }
    #endif

    // Turn off VE first in switch source, turn it on at next necessary places
    msAPI_VE_Exit();
#endif //ALL_SOURCE_OUTPUT_THROUGH_VE

    if(IsSrcTypeAnalog(SYS_INPUT_SOURCE_TYPE(eWindow)) || IsSrcTypeHDMI(SYS_INPUT_SOURCE_TYPE(eWindow)) || IsSrcTypeDVI(SYS_INPUT_SOURCE_TYPE(eWindow)))
    {
        MApp_InputSource_InitModeVariables(eWindow); // initialize mode variables
    }

    if (enUiInputSourceType == UI_INPUT_SOURCE_DTV)
    {
        MDrv_IFDM_SetIF(IF_DIGITAL_MODE);
    }

  #if ENABLE_CEC
    if( eWindow == MAIN_WINDOW )
    {
        cur_srctype = stSystemInfo[MAIN_WINDOW].enInputSourceType;
    }
  #endif

    switch(ST_VIDEO.eAspectRatio) // we should Reset _u8EnableOverScan when switch source. or it will used by mistake when switch source.
    {
        case EN_AspectRatio_JustScan:
         #if VGA_HDMI_YUV_POINT_TO_POINT
        case EN_AspectRatio_point_to_point:
          #endif
                  MApp_Scaler_EnableOverScan(FALSE);
            break;
        case EN_AspectRatio_Zoom1:
        case EN_AspectRatio_Zoom2:
        case EN_AspectRatio_Panorama:
            //MApp_Picture_ResetZoomFactor(ST_VIDEO.eAspectRatio);
        default:
            MApp_Scaler_EnableOverScan(ENABLE);
            break;
    }
    if( eWindow == MAIN_WINDOW )
    {
        stSystemInfo[MAIN_WINDOW].enAspectRatio = MApp_Scaler_GetAspectRatio( ST_VIDEO.eAspectRatio );
    }

    //////////////////////////////////////////////
    // Create Path
    // InputSource -> Scaler Main/Sub Window
    //////////////////////////////////////////////

  #if(ENABLE_DTV)
    if(IsSrcTypeDTV(stSystemInfo[eWindow].enInputSourceType))
    {
        PathInfo.path_thread = MApp_DTV_Handler;
    }
    else
  #endif
    if(IsSrcTypeAnalog(stSystemInfo[eWindow].enInputSourceType) || IsSrcTypeHDMI(stSystemInfo[eWindow].enInputSourceType))
    {
        if ( eWindow == MAIN_WINDOW )
        {
            PathInfo.path_thread = MApp_PC_MainWin_Handler;
        }
        #if (ENABLE_PIP)
        else
        {
            PathInfo.path_thread = MApp_PC_SubWin_Handler;
        }
        #endif
    }
  #if ENABLE_DMP
    else if (IsStorageInUse())
    {
        PathInfo.path_thread = MApp_Storage_Handler;
    }
  #endif
    else // ATV
    {
        PathInfo.path_thread = MApp_ATV_Handler;
    }

    PathInfo.Path_Type = PATH_TYPE_SYNCHRONOUS;
    PathInfo.src = SYS_INPUT_SOURCE_TYPE(eWindow);
    //MApi_XC_SetDbgLevel(XC_DBGLEVEL_SETWINDOW|XC_DGBLEVEL_CROPCALC);

    if ( eWindow == MAIN_WINDOW )
    {
        PathInfo.dest = OUTPUT_SCALER_MAIN_WINDOW;
        if(IsSrcTypeStorage(SYS_INPUT_SOURCE_TYPE(eWindow)))
        {
            //Since MM has its own flow for below event, so skip loading handler here
            PathInfo.SyncEventHandler = NULL;
            PathInfo.DestOnOff_Event_Handler = NULL;
        }
        else
        {
            PathInfo.SyncEventHandler = MApp_Scaler_MainWindowSyncEventHandler;
            PathInfo.DestOnOff_Event_Handler = MApp_Scaler_MainWindowOnOffEventHandler;
        }
        PathInfo.dest_periodic_handler = MApp_Scaler_MainWindowPeriodicHandler;
    }
    #if (ENABLE_PIP)
    else
    {
        PathInfo.dest = OUTPUT_SCALER_SUB_WINDOW;
        if(IsSrcTypeStorage(SYS_INPUT_SOURCE_TYPE(eWindow)))
        {
            //Since MM has its own flow for below event, so skip loading handler here
            PathInfo.SyncEventHandler = NULL;
            PathInfo.DestOnOff_Event_Handler = NULL;
        }
        else
        {
            PathInfo.SyncEventHandler = MApp_Scaler_SubWindowSyncEventHandler;
            PathInfo.DestOnOff_Event_Handler = MApp_Scaler_SubWindowOnOffEventHandler;
        }
        PathInfo.dest_periodic_handler = MApp_Scaler_SubWindowPeriodicHandler;
    }
    #endif

/*****************************************************************************
Power saving do IP power on/off, so the code flow related to IP power on/off
can't be arbitraraily change, like the ADC table (MApi_XC_Mux_CreatePath)
******************************************************************************/

 #if ( ENABLE_PWS)
        MDrv_PWS_HandleSource(PWS_ADD_SOURCE,_MAPP_InputSource_Source2PWSSource( stSystemInfo[eWindow].enInputSourceType ),PWS_FULL);
        if(IsSrcTypeATV(stSystemInfo[eWindow].enInputSourceType) ||
           IsSrcTypeAV(stSystemInfo[eWindow].enInputSourceType) ||
           IsSrcTypeSV(stSystemInfo[eWindow].enInputSourceType) ||
           IsSrcTypeScart(stSystemInfo[eWindow].enInputSourceType))
        {
            MDrv_PWS_HandleSource(PWS_ADD_SOURCE,_CVBSOi_,PWS_FULL);
        }

 #endif


/*****************************************************************************
Power saving do IP power on/off, so the code flow related to IP power on/off
can't be arbitraraily change, like the ADC table (MApi_XC_Mux_CreatePath)
******************************************************************************/
    CAL_TIME_FUNC_("ChgSrc");

    s16PathId = MApi_XC_Mux_CreatePath( &PathInfo, sizeof(XC_MUX_PATH_INFO) );
    CAL_TIME_FUNC_("ChgSrc");

    if (s16PathId == -1)
    {
        SIGNAL_PATH_DBG(printf(" Create path fail src = %d  dest = %d, your structure has wrong size with library \n",PathInfo.src ,PathInfo.dest ));
    }
    else
    {
        SIGNAL_PATH_DBG(printf("\r\n create path success src = %d dest = %d ",PathInfo.src ,PathInfo.dest  ));
        MApi_XC_Mux_EnablePath( (U16)s16PathId );
    }


    MApp_InputSource_SetVideoOut(eWindow,
                                 u8PreCVBS1OutSource, u8NewCVBS1OutSource,
                                 u8PreCVBS2OutSource, u8NewCVBS2OutSource);


    //////////////////////////////////////////////
    // Set Video Scale
    //////////////////////////////////////////////

    MApp_Scaler_Setting_SetVDScale( ST_VIDEO.eAspectRatio, eWindow );

    if(IsSrcTypeAnalog(SYS_INPUT_SOURCE_TYPE(eWindow)) || IsSrcTypeHDMI(SYS_INPUT_SOURCE_TYPE(eWindow)) || IsSrcTypeDVI(SYS_INPUT_SOURCE_TYPE(eWindow)))
    {
        MApp_PCMode_Reset(eWindow);
    }

  #if ENABLE_DTV
    if ( IsSrcTypeDTV( SYS_INPUT_SOURCE_TYPE(eWindow) ) )
    {
        //msAPI_Tuner_Initialization();
        //power on tuner and set tri-state on
        if(bDemodPowerOnInit == TRUE)
            msAPI_Tuner_PowerOnOff( ENABLE );
        msAPI_Tuner_InintCurrentTPSetting();

        //MDrv_IFDM_CVBSOff();
    }
    else if (!IsDTVInUse())
    {
      #if MHEG5_ENABLE
        if(msAPI_MHEG5_GetBinStatus() == TRUE)
        {
            // Disable Aeon for Non-DTV Mode
          #if (MHEG5_WITH_OSD)
            //if ( msAPI_MHEG5_checkGoBackMHEG5())
            {
                MApi_MHEG5_Disable(EN_MHEG5_DM_DISABLE_AND_WAIT);
            }
          #endif
          #if defined(MIPS_CHAKRA) || defined(__AEONR2__)
            msAPI_AEON_Disable();
          #else
            msAPI_BEON_Disable();
          #endif
        }
      #endif
        //power off tuner and tri-state off
        if(bDemodPowerOnInit == TRUE)
            msAPI_Tuner_PowerOnOff( DISABLE );
        //TU_RESET_N_On();
    }
  #endif

    CAL_TIME_FUNC_("ChgSrc");

    if (IsATVInUse()||IsAVInUse()||IsSVInUse())
    {
        MDrv_AVD_Set3dComb( ENABLE );
    }
    else
    {
        MDrv_AVD_Set3dComb( DISABLE );
    }

#if (ENABLE_ATV_VCHIP)
    /* init V-Chip while switching to AV or SV
    TV and DTV will init in enable channel each time */

    if ( IsSrcTypeAV( SYS_INPUT_SOURCE_TYPE(eWindow) ) || IsSrcTypeSV( SYS_INPUT_SOURCE_TYPE(eWindow) )
#ifndef DISABLE_COMPONENT_VBI
          || IsSrcTypeYPbPr(SYS_INPUT_SOURCE_TYPE(eWindow))
#endif
       )
    {
        MApp_VChip_Init();
        fVChipPassWordEntered= FALSE;
    }
#endif

  #if ( (EEPROM_DB_STORAGE!=EEPROM_SAVE_ALL) && (!DB_IN_NAND) )
    while (FALSE==MDrv_FLASH_CheckWriteDone());
  #endif
  CAL_TIME_FUNC_("ChgSrc");

  #if (ENABLE_PIP)
    if( (IsPIPEnable()==FALSE) || UI_IS_AUDIO_SOURCE_IN(eWindow) )
  #endif
    {
        if( g_bPreInit_SkipChangeAudioSrc == FALSE )
        {
            MApp_InputSource_ChangeAudioSource( SYS_INPUT_SOURCE_TYPE(eWindow));
        }
    }

    CAL_TIME_FUNC_("ChgSrc");

#if ENABLE_CUS_BLOCK_SYS
    MApp_BlockSys_Monitor(MAIN_WINDOW,BLOCKSYS_CHECK_AV,TRUE); //only check block audio and video
#else
    MApp_CheckBlockProgramme();
#endif

  #if ENABLE_CEC
    MApp_CEC_SetMyPhyAddr(pre_srctype, cur_srctype);
    msAPI_CEC_RoutingControl_SourceChange(pre_srctype, cur_srctype);
  #endif

#if 0//move after PWS Handle Source
    msAPI_Scaler_SetSourceType( stSystemInfo[eWindow].enInputSourceType , eWindow);
#endif

/*****************************************************************************
Power saving do IP power on/off, so the code flow related to IP power on/off
can't be arbitraraily change, like the ADC table (MApi_XC_Mux_CreatePath)
******************************************************************************/
#if 0
 #if ( ENABLE_PWS)
    MDrv_PWS_HandleSource(PWS_ADD_SOURCE,_MAPP_InputSource_Source2PWSSource( stSystemInfo[eWindow].enInputSourceType ),PWS_FULL);

	if(IsSrcTypeATV(stSystemInfo[eWindow].enInputSourceType) ||
       IsSrcTypeAV(stSystemInfo[eWindow].enInputSourceType) ||
       IsSrcTypeSV(stSystemInfo[eWindow].enInputSourceType) ||
       IsSrcTypeScart(stSystemInfo[eWindow].enInputSourceType))
    {
		MDrv_PWS_HandleSource(PWS_ADD_SOURCE,_CVBSOi_,PWS_FULL);
    }

    #endif
 #endif
    CAL_TIME_FUNC_("ChgSrc");

    MApp_InputSource_SetInputSource( eWindow, &stSystemInfo[eWindow] );

    CAL_TIME_FUNC_("ChgSrc");


    /***************************************************
power saving do IP power on/off, it causes Scaler IP state machine unstable if not resetting it.
so it has to be called before Scaler set source type.
let Scaler set source type to do the resetting job
****************************************************/
    msAPI_Scaler_SetSourceType( stSystemInfo[eWindow].enInputSourceType , eWindow);
    CAL_TIME_FUNC_("ChgSrc");


  #ifdef SCALER_DNR_BUF_UC_ADR
    if (( IsSrcTypeHDMI(stSystemInfo[eWindow].enInputSourceType) ) || ( IsSrcTypeYPbPr(stSystemInfo[eWindow].enInputSourceType) ))
    {
        MApi_XC_SetFrameBufferAddress(((SCALER_DNR_BUF_MEMORY_TYPE & MIU1) ? (SCALER_DNR_BUF_UC_ADR | MIU_INTERVAL) : (SCALER_DNR_BUF_UC_ADR)), SCALER_DNR_BUF_UC_LEN, eWindow);
    }
    else
  #endif
    {
        MApi_XC_SetFrameBufferAddress(((SCALER_DNR_BUF_MEMORY_TYPE & MIU1) ? (SCALER_DNR_BUF_ADR | MIU_INTERVAL) : (SCALER_DNR_BUF_ADR)), SCALER_DNR_BUF_LEN, eWindow);
    }

    MApi_XC_EnableFrameBufferLess(DISABLE);

#if RFBL_Test_EN // for RFBL mode test
    if(MApi_XC_IsRequestFrameBufferLessMode()&& !MApi_XC_IsCurrentFrameBufferLessMode())
        MApi_XC_EnableRequest_FrameBufferLess(ENABLE);
#endif

  #if ENABLE_DDCCI
    MDrv_DDC2BI_Set_StandardCallBack(MApp_DDC2BI_AlignControl);
    MDrv_DDC2BI_Set_CustomerCallBack(MApp_DDC2BI_FactoryAdjustment);
  #endif

  #if ENABLE_TTX
  if(eWindow != SUB_WINDOW)
  {
    //g_NeedReloadTTXFont = TRUE;    // Force TTX to reload font

    if ( IsDTVInUse() )
    {
        msAPI_TTX_OnOffVBISlicer( DISABLE );
        msAPI_TTX_SetTTXFid(DMX_DMXID_NULL);
        msAPI_TTX_SetSource( TTX_SOURCE_DTV );
        msAPI_TTX_Run();
    }
    else if ( IsDigitalSourceInUse() )
    {
        //msAPI_TTX_DecCreate();
        msAPI_TTX_OnOffVBISlicer( ENABLE );
        msAPI_TTX_SetSource( TTX_SOURCE_ANALOG );
        msAPI_TTX_VBIAcquireEnable(TRUE);
        msAPI_TTX_Run();
    }
    else
    {
        // in other sources, we don't need to turn on backgound TTX packets receving
        msAPI_TTX_OnOffVBISlicer( DISABLE );
    }

    MApp_TTX_Reflesh();
  }
  #endif  // ENABLE_TTX



  #if ENABLE_DMP
    //if ( gCurrentBinID != BIN_ID_CODE_AEON_FONT )
    {
        if (IsSrcTypeStorage(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)))
        {
            #ifdef ENABLE_KTV
            if(gbKTVFlag == TRUE)
                MApp_KTV_InitKTVStatus();
            else
            #endif
            MApp_DMP_InitDMPStat();
            // here we restroe the UI_INPUT_SOURCE_TYPE because the dmp should not be an inputsource
            //UI_INPUT_SOURCE_TYPE = MApp_InputSource_GetRecordSource();
            msAPI_Aeon_ReInitial( BIN_ID_CODE_VDPLAYER );
        }
    }
  #endif //MM_AEON_ENABLE

  #if ENABLE_DBC
    MApi_XC_DLC_SetOnOff(ENABLE, MAIN_WINDOW);
    MApi_XC_Sys_DLC_DBC_OnOff(stGenSetting.g_SysSetting.fDCR);
  #endif

    #if (ENABLE_PIP)
    if(IsPIPEnable())
    {
        if(eWindow == SUB_WINDOW && enUiInputSourceType != UI_INPUT_SOURCE_NONE)
        {
            MS_WINDOW_TYPE stWinRect;
            if(MApp_InputSource_PIP_GetSubWinRect(&stWinRect))
            {
                //printf("Sub win rect = (%d, %d) w = %d, h = %d\n", stWinRect.x, stWinRect.y, stWinRect.width, stWinRect.height);
                MApi_XC_EnableSubWindow(&stWinRect);
            }
            else
            {
                printf("Failed to enable sub window!\n");
            }
        }
    }
    #endif

    CAL_TIME_FUNC_("ChgSrc");

  // digital IP
  #if ENABLE_DTV
    if (IsSrcTypeDTV(SYS_INPUT_SOURCE_TYPE(eWindow)))
    {
        // enter DTV
        // DMX int begin

#ifndef MSOS_TYPE_LINUX

        BININFO   DMXBinInfo;
        BOOLEAN   bResult;
        MS_U32    u32DMXBinAddr, u32DMXTmp;

        DMXBinInfo.B_ID = BIN_ID_CODE_DEMUX;
        MDrv_Sys_Get_BinInfo(&DMXBinInfo, &bResult);
        if (bResult != PASS)
        {
            MS_DEBUG_MSG(printf( "could not find Demux binary on flash.\n"));
        }

        u32DMXTmp = (MS_U32)msAPI_Memory_Allocate((U16)(DMXBinInfo.B_Len+128),(EN_BUFFER_ID)NULL);
        if (u32DMXTmp == NULL)
        {
            ASSERT(u32DMXTmp);
            return;
        }
        u32DMXBinAddr = MemAlign(u32DMXTmp,256UL); // address must align by chip ex: t2 64 align, t3 128 align, t8 256 align
        msAPI_MIU_Copy(DMXBinInfo.B_FAddr, MS_VA2PA(u32DMXBinAddr), MemAlign(DMXBinInfo.B_Len,8UL), MIU_FLASH2SDRAM);
		MApi_DMX_SetFW(MS_VA2PA(u32DMXBinAddr), DMXBinInfo.B_Len);
        MApi_DMX_SetHK(TRUE);

        MApi_DMX_Init();
        msAPI_Memory_Free((void *)u32DMXTmp, (EN_BUFFER_ID)NULL);
#else
        MApi_DMX_SetHK(TRUE);

        MApi_DMX_Init();
#endif

    CAL_TIME_FUNC_("ChgSrc");

#if (ENABLE_DTV_EPG)
    #if( (MEMORY_MAP == MMAP_64MB) )
        MApp_Epg_Init();
    #endif
#endif

    CAL_TIME_FUNC_("ChgSrc");

#if VQ_ENABLE
		DMX_TSPParam tspparam;
		tspparam.phyFWAddr = MS_VA2PA(u32DMXBinAddr);
		tspparam.u32FWSize = DMXBinInfo.B_Len;
		tspparam.phyVQAddr = TSP_VQ_BUFFER_AVAILABLE;
		tspparam.u32VQSize = TSP_VQ_BUFFER_LEN;
		MApi_DMX_TSPInit(&tspparam);
#endif


#if MHEG5_ENABLE
#if ((OBA2 == 1) && (MHEG5_IN_HK == ENABLE))
        MApi_DMX_SetOwner(0,31,TRUE);
#else
        MApi_DMX_SetOwner(16,31,TRUE);
#endif
#else
        MApi_DMX_SetOwner(0,31,TRUE);
#endif
#if (ENABLE_CI)
#if (!TS_SERIAL_OUTPUT_IF_CI_REMOVED)
        msAPI_Tuner_Serial_Control(TRUE);
#if (ENABLE_CI_PLUS)
        msAPI_Tuner_SetByPassMode(TRUE, FALSE);
#else
        if( msAPI_CI_CardDetect() )
        {
            msAPI_Tuner_SetByPassMode( FALSE, FALSE );
        }
        else
        {
            msAPI_Tuner_SetByPassMode( TRUE, FALSE );
        }
#endif
#else
        msAPI_Tuner_Serial_Control(FALSE);
#endif
		//for internal DEMOD init
        if ((ePreDemodMode != msAPI_Tuner_GetDemodMode()) && msAPI_CI_CardDetect())
        {
            msAPI_CI_ReInitial();
        }
        // DMX int end
#else
        msAPI_Tuner_Serial_Control(FALSE);
#endif

  #if MHEG5_ENABLE
        msAPI_MHEG5_Bean_Init();
  #endif
        msAPI_Timer_Delayms(1);//add 1ms delay for demux inital to avoid info ui bug
    }
  #endif


// Init VE to a display state to show out the "NO Signal" symbol and reconfig CVBS mux path
#if((FORCE_ALL_OUTPUT_THROUGH_VE == ENABLE) && (ENABLE_OP2_TO_VE == ENABLE))
    msAPI_Scaler_SetCVBSMute(DISABLE, E_VE_MUTE_GEN, SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW), OUTPUT_CVBS1);
    #if (INPUT_SCART_VIDEO_COUNT >= 2)
    msAPI_Scaler_SetCVBSMute(DISABLE, E_VE_MUTE_GEN, SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW), OUTPUT_CVBS2);
    #endif
#endif //(ALL_SOURCE_OUTPUT_THROUGH_VE == ENABLE)

#if 0
   if(IsSrcTypeAnalog(SYS_INPUT_SOURCE_TYPE(eWindow)) ||IsSrcTypeSV(SYS_INPUT_SOURCE_TYPE(eWindow))/*||IsSrcTypeHDMI(SYS_INPUT_SOURCE_TYPE(eWindow))*/)  //Component, HDMI, and VGA
    {
        U8 u8DestOnOffPara = ENABLE;
        //printf("^^^20100421EL  Trigger CVBS out handler now~~~~~~~\n");
        MApi_XC_Mux_TriggerDestOnOffEvent(INPUT_SOURCE_TV,&u8DestOnOffPara);
    }
#endif
    #if 0//TV_FREQ_SHIFT_CLOCK
    if(IsAnyTVSourceInUse() == FALSE)
    {
        g_bChangeChannelAtTVsource = FALSE;
    }
    #endif

    #if ENABLE_CUS_BLOCK_SYS
    if(IsStorageInUse())
    {
        msAPI_Scaler_SetScreenMuteStatus(MAIN_WINDOW, (E_SCREEN_MUTE_STATUS)(msAPI_Scaler_GetScreenMute(MAIN_WINDOW) & ~E_SCREEN_MUTE_RATING));
        msAPI_Scaler_SetScreenMuteStatus(MAIN_WINDOW, (E_SCREEN_MUTE_STATUS)(msAPI_Scaler_GetScreenMute(MAIN_WINDOW) & ~E_SCREEN_MUTE_BLOCK));
        msAPI_Scaler_SetScreenMuteStatus(MAIN_WINDOW, (E_SCREEN_MUTE_STATUS)(msAPI_Scaler_GetScreenMute(MAIN_WINDOW) & ~E_SCREEN_MUTE_INPUT));
        msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_BYBLOCK_MUTEOFF, E_AUDIOMUTESOURCE_ACTIVESOURCE);
    }
	msAPI_Scaler_SetScreenMuteStatus(MAIN_WINDOW, (E_SCREEN_MUTE_STATUS)(msAPI_Scaler_GetScreenMute(MAIN_WINDOW) & ~E_SCREEN_MUTE_BLOCK));
    #endif

    g_u16PasswordCheckSource = 0xffff;
	
//<< smc.truth add for reduce NR 20130513
    MDrv_WriteRegBit(0x112d84, 1, BIT1);
    MDrv_WriteRegBit(0x112dae, 0, BIT1);
//>>
#ifdef ENABLE_SANYO_WB_JPG
	if(bSanyoWbJpgDisplayed && enUiInputSourceType != UI_INPUT_SOURCE_DMP)
	{
		bSanyoWbJpgDisplayed = FALSE;
	}
#endif

    CAL_TIME_FUNC_END();
}


//ZUI: moved from UiMenuFunc
void MApp_InputSource_ChangeInputSource(SCALER_WIN eWindow)
{
    //add for the caller: _MApp_ZUI_ACT_FactoryMenu_ChangeDataInputSource(E_DATA_INPUT_SOURCE)
    E_UI_INPUT_SOURCE source_type;
#if ENABLE_CUS_BURNING_MODE
    if(stGenSetting.g_FactorySetting.fBuringMode)
    {
        g_bDisableBurninMode = TRUE;
        MApi_XC_SetFrameColor(0x00000000UL);    //Set Black
    }
#endif
    //from void MApp_UiMenuFunc_ChangeInputSource(void)

    if(eWindow==MAIN_WINDOW)
    {
        source_type = UI_INPUT_SOURCE_TYPE;
    }
    #if (ENABLE_PIP)
    else if (eWindow==SUB_WINDOW)
    {
        source_type = UI_SUB_INPUT_SOURCE_TYPE;
    }
    #endif
    else
    {
        printf("invalid window#!\n");
        return;
    }

#if ENABLE_TTX
    if (MApp_TTX_IsTeletextOn() == TRUE)
    {
        MApp_TTX_TeletextCommand(TTX_TV);
    }
#endif


#if ENABLE_SBTVD_BRAZIL_APP
    if (IsSrcTypeDTV(SYS_INPUT_SOURCE_TYPE(eWindow))&&(source_type!=UI_INPUT_SOURCE_DTV))
    {
        dmSetLastWatchedOrdinal();
        enLastWatchAntennaType = ANTENNA_DTV_TYPE;
        MApp_ChannelChange_DisableChannel(TRUE, eWindow);
        MApp_Dmx_CloseAllFilters();
       // msAPI_Tuner_ChangeProgram();
    }
    else if ( IsSrcTypeATV(SYS_INPUT_SOURCE_TYPE(eWindow))&&(source_type!=UI_INPUT_SOURCE_ATV)&& ANT_AIR == msAPI_ATV_GetCurrentAntenna())
    {
        dmSetLastWatchedOrdinal();
        enLastWatchAntennaType = ANTENNA_ATV_TYPE;
        MApp_ChannelChange_DisableChannel(TRUE, eWindow);
    }
    else if ( IsSrcTypeATV(SYS_INPUT_SOURCE_TYPE(eWindow))&&(source_type!=UI_INPUT_SOURCE_ATV)&& ANT_CATV == msAPI_ATV_GetCurrentAntenna())
    {
        dmSetLastWatchedOrdinal();
        MApp_ChannelChange_DisableChannel(TRUE, eWindow);
    }
    else
    {
    MApp_ChannelChange_DisableAV(eWindow);
    }

    #if (ENABLE_SW_CH_FREEZE_SCREEN)
	if(stGenSetting.g_SysSetting.u8SwitchMode == ATV_SWITCH_CH_FREEZE_SCREEN)
		msAPI_Scaler_SetFreezeScreen(DISABLE, 0, eWindow);
	#endif

    if (source_type == UI_INPUT_SOURCE_ANTENNA)
    {
        msAPI_ATV_SetCurrentAntenna(ANT_AIR);
        msAPI_ATV_LoadCurrentProgramNumber();
        if (enLastWatchAntennaType == ANTENNA_DTV_TYPE)
        {
            UI_INPUT_SOURCE_TYPE=UI_INPUT_SOURCE_DTV;
            MApp_InputSource_SwitchSource(UI_INPUT_SOURCE_DTV, eWindow);
         #ifdef ENABLE_SELECT_NONESEARCH_CH
            u16ChannelReturn_Num2=IVALID_TV_RETURN_NUM;
         #endif
        }
        else
        {
            UI_INPUT_SOURCE_TYPE=UI_INPUT_SOURCE_ATV;
            MApp_InputSource_SwitchSource(UI_INPUT_SOURCE_ATV, eWindow);
        }
        stGenSetting.stScanMenuSetting.u8Antenna =1;
    }
    else if (source_type == UI_INPUT_SOURCE_CABLE)
    {
        msAPI_ATV_SetCurrentAntenna(ANT_CATV);
        msAPI_ATV_LoadCurrentProgramNumber();
        MApp_InputSource_SwitchSource( UI_INPUT_SOURCE_ATV, eWindow );
        stGenSetting.stScanMenuSetting.u8Antenna =0;
      #ifdef ENABLE_SELECT_NONESEARCH_CH
        u16ChannelReturn_Num2=IVALID_TV_RETURN_NUM;
      #endif
    }
    else
    {
        MApp_InputSource_SwitchSource( source_type, eWindow);
    }

#else
#ifdef AP_COWORK
    if ( MApp_APEngine_CheckAPStatus()>>1 )
    {
        if((source_type != UI_INPUT_SOURCE_ATV) && (source_type != UI_INPUT_SOURCE_DTV))
        {
          #if (OBA2 && defined(GADGET))
            if(MApp_APEngine_IsGadgetActived())
            {//
                printf("Gadget need not exit when change inputsource\n");
            }
            else
          #endif
            {
                msAPI_APEngine_TransmitKey(KEY_EXIT);
                MApp_APEngine_Exit();
            }
        }
    }
#endif

#if ENABLE_DTV
    if ( IsSrcTypeDTV(SYS_INPUT_SOURCE_TYPE(eWindow))
        &&(source_type!=UI_INPUT_SOURCE_DTV)
#if DVB_C_ENABLE
        &&(source_type!=UI_INPUT_SOURCE_CADTV)
#endif
        )
    {
        dmSetLastWatchedOrdinal();
#if MHEG5_ENABLE
        MApi_MHEG5_Disable(EN_MHEG5_DM_DISABLE_AND_WAIT);
#endif
        MApp_ChannelChange_DisableChannel(TRUE, eWindow);

    #if (ENABLE_UPDATE_MULTIPLEX_VIA_NIT)
        MApp_SI_Free_NetworkChangeInfo();
    #endif
        MApp_Dmx_CloseAllFilters();
       // msAPI_Tuner_ChangeProgram();
    }
    else
#endif
    if ( IsSrcTypeATV(SYS_INPUT_SOURCE_TYPE(eWindow))&&(source_type!=UI_INPUT_SOURCE_ATV) )
    {
        dmSetLastWatchedOrdinal();
        MApp_ChannelChange_DisableChannel(TRUE, eWindow);
    }
    else
    {
        MApp_ChannelChange_DisableAV(eWindow);
    }
#if ENABLE_3D_PROCESS
    //msAPI_Scaler_SetBlueScreen may fail for 3D project, since eScreenMute is not right now
    MApi_XC_GenerateBlackVideo(TRUE, MAIN_WINDOW);
    if((eWindow == MAIN_WINDOW) && (g_HdmiInput3DFormat != E_XC_3D_INPUT_MODE_NONE))
    {
        g_HdmiInput3DFormat = E_XC_3D_INPUT_MODE_NONE;
        g_HdmiInput3DFormatStatus = E_XC_3D_INPUT_MODE_NONE;
        MApp_Scaler_SetVideo3DMode(E_USER_3D_MODE_OFF);
        if ((source_type == UI_INPUT_SOURCE_DMP)
	   #if( ENABLE_DMP_SWITCH )
            ||(UI_INPUT_SOURCE_DMP1 == source_type)
            ||(UI_INPUT_SOURCE_DMP2 == source_type)
         #endif
          )
        {
            msAPI_Scaler_SetBlueScreen(DISABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
        }
    }
    #if (ENABLE_CUS_3D_SOURCE_MEMORY == DISABLE)
    if((source_type != UI_INPUT_SOURCE_HDMI)
        #if (INPUT_HDMI_VIDEO_COUNT > 1)
        && (source_type != UI_INPUT_SOURCE_HDMI2)
        #endif
        #if (INPUT_HDMI_VIDEO_COUNT > 2)
        && (source_type != UI_INPUT_SOURCE_HDMI3)
        #endif
        #if (INPUT_HDMI_VIDEO_COUNT > 3)
        && (source_type != UI_INPUT_SOURCE_HDMI4)
        #endif
        )
    {
        printf("Change Src and Close 3D Type \n");/*Creass.liu at 2012-06-28*/
        ST_3D_TYPE = EN_3D_BYPASS;
        stGenSetting.g_SysSetting.en3DDetectMode = EN_3D_DETECT_MANUAL;
    }
    else
    {
        stGenSetting.g_SysSetting.en3DDetectMode = EN_3D_DETECT_AUTO;
    }
    #else
    MApp_Scaler_Close3DFunction();
    #endif
#endif

    #if (ENABLE_SW_CH_FREEZE_SCREEN)
	if(stGenSetting.g_SysSetting.u8SwitchMode == ATV_SWITCH_CH_FREEZE_SCREEN)
		msAPI_Scaler_SetFreezeScreen(DISABLE, 0, eWindow);
	#endif

    MApp_InputSource_SwitchSource( source_type, eWindow);

#endif // #if ENABLE_SBTVD_BRAZIL_APP


    if (IsSrcTypeDTV(SYS_INPUT_SOURCE_TYPE(eWindow)) || IsSrcTypeATV(SYS_INPUT_SOURCE_TYPE(eWindow)))
    {
        MApp_ChannelChange_EnableChannel(eWindow);
        #if ENABLE_SW_CH_FREEZE_SCREEN
        msApi_VD_Reset_ChannelChangeStatus();
        #endif
    }
    //exp: In PIP/POP mode, main is TV and switch sub to another source.
    // It should not Enable channel "AGAIN"
    else if (IsAnyTVSourceInUse())
    {
    }
    else
    {
        MApp_ChannelChange_EnableAV();
    }
}

////////////////////////////////////////////////////////
//moved from MApp_UiMenu2.c
#if (INPUT_SCART_VIDEO_COUNT > 0)
void MApp_InputSource_ScartIOMonitor(void)
{
#if (INPUT_SCART_VIDEO_COUNT >= 1)
    if (msAPI_GPIO_IsSourceJustConnected(INPUT_SOURCE_SCART) == TRUE)
    {
        if ((SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW) != INPUT_SOURCE_SCART) && (msAPI_Timer_DiffTimeFromNow(u32ScartSwitchDuration) > 1200) &&(IsScartChange()))
        {
            #if (MHEG5_ENABLE)
            if(msAPI_MHEG5_IsRunning() == TRUE)
            {
                msAPI_MHEG5_Key_Transmit( KEY_INFO, 0 );//force exit Mheg5
                bExitMheg5AsScartInserted = TRUE;
            }
            else
            #endif
            {
                #if ENABLE_SUBTITLE
                if (MApp_Subtitle_Get_SubtitleOSDState())
                {
                    MApp_Subtitle_Force_Exit();
                }
                else
                #endif
                {
                    #if ENABLE_TTX
                    if (MApp_TTX_IsTeletextOn() == TRUE)
                    {
                        MApp_TTX_TeletextCommand(TTX_TV);
                    }
                    #endif
                }
            }

            #if (ENABLE_PIP)
            if( IsPIPEnable()
                && !MApp_InputSource_PIP_IsSrcCompatible(xcTargetScartSource, SYS_INPUT_SOURCE_TYPE(SUB_WINDOW)))
            {
                //Close subwindow and set compatible source type to sub win
                if(stGenSetting.g_stPipSetting.enPipSoundSrc==EN_PIP_SOUND_SRC_SUB)
                {
                    stGenSetting.g_stPipSetting.enPipSoundSrc=EN_PIP_SOUND_SRC_MAIN;
                    MApp_InputSource_PIP_ChangeAudioSource(MAIN_WINDOW);
                }
                UI_SUB_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_NONE;
                MApp_InputSource_ChangeInputSource(SUB_WINDOW);
                stGenSetting.g_stPipSetting.enPipMode = EN_PIP_MODE_OFF;
                UI_SUB_INPUT_SOURCE_TYPE = MApp_InputSource_GetUIInputSourceType(MApp_InputSource_PIP_Get1stCompatibleSrc(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)));
            }
            #endif

            UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_SCART;
            MApp_InputSource_ChangeInputSource(MAIN_WINDOW);
            MApp_TopStateMachine_SetTopState(STATE_TOP_DIGITALINPUTS);

            MApp_ChannelChange_VariableInit();
            u32ScartSwitchDuration = msAPI_Timer_GetTime0();
            ResetScartChange();

            if (MApp_ZUI_GetActiveOSD()!=E_OSD_EMPTY) //ZUI:
            {
                MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_CLOSE_CURRENT_OSD);
            }
            if (stGenSetting.fRunInstallationGuide == FALSE )
            {
                MApp_ZUI_ACT_StartupOSD(E_OSD_CHANNEL_INFO);
                MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_SHOW_SOURCE_BANNER);
            }

            return;
        }
    }
#endif

#if (INPUT_SCART_VIDEO_COUNT >= 2)
    if (msAPI_GPIO_IsSourceJustConnected(INPUT_SOURCE_SCART2) == TRUE)
    {
        if ((SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW) != INPUT_SOURCE_SCART2) && (msAPI_Timer_DiffTimeFromNow(u32ScartSwitchDuration) > 1200)&&(IsScartChange()))
        {
            #if (MHEG5_ENABLE)
            if(msAPI_MHEG5_IsRunning() == TRUE)
            {
                msAPI_MHEG5_Key_Transmit( KEY_INFO, 0 );//force exit Mheg5
                bExitMheg5AsScartInserted = TRUE;
            }
            else
            #endif
            #if (ENABLE_SUBTITLE)
            if (MApp_Subtitle_Get_SubtitleOSDState())
            {
                MApp_Subtitle_Exit();
            }
            else
            #endif
            {
                #if ENABLE_TTX
                if (MApp_TTX_IsTeletextOn() == TRUE)
                {
                    MApp_TTX_TeletextCommand(TTX_TV);
                }
                #endif

                //ZUI_TODO: MApp_UiMenu_ExecuteKeyEvent(MIA_EXIT);
                MApp_TopStateMachine_SetTopState(STATE_TOP_ANALOG_SHOW_BANNER);
            }

            #if (ENABLE_PIP)
            if( IsPIPEnable()
                && !MApp_InputSource_PIP_IsSrcCompatible(INPUT_SOURCE_SCART, SYS_INPUT_SOURCE_TYPE(SUB_WINDOW)))
            {
                //Close subwindow and set compatible source type to sub win
                if(stGenSetting.g_stPipSetting.enPipSoundSrc==EN_PIP_SOUND_SRC_SUB)
                {
                    stGenSetting.g_stPipSetting.enPipSoundSrc=EN_PIP_SOUND_SRC_MAIN;
                    MApp_InputSource_PIP_ChangeAudioSource(MAIN_WINDOW);
                }
                UI_SUB_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_NONE;
                MApp_InputSource_ChangeInputSource(SUB_WINDOW);
                stGenSetting.g_stPipSetting.enPipMode = EN_PIP_MODE_OFF;
                UI_SUB_INPUT_SOURCE_TYPE = MApp_InputSource_GetUIInputSourceType(MApp_InputSource_PIP_Get1stCompatibleSrc(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)));
            }
            #endif

            UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_ATV;
            MApp_InputSource_ChangeInputSource(MAIN_WINDOW);
            MApp_TopStateMachine_SetTopState(STATE_TOP_DIGITALINPUTS);

            MApp_ChannelChange_VariableInit();
            u32ScartSwitchDuration = msAPI_Timer_GetTime0();
            ResetScartChange();

            if( MApp_ZUI_GetActiveOSD() != E_OSD_EMPTY ) //ZUI:
            {
                MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_CLOSE_CURRENT_OSD);
            }

            if( stGenSetting.fRunInstallationGuide == FALSE )
            {
                MApp_ZUI_ACT_StartupOSD(E_OSD_CHANNEL_INFO);
                MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_SHOW_SOURCE_BANNER);
            }

            return;
        }
    }
#endif

#if (INPUT_SCART_VIDEO_COUNT >= 1)
    if (msAPI_GPIO_IsSourceJustDisConnected(INPUT_SOURCE_SCART) == TRUE)
    {
        if ((SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)  == INPUT_SOURCE_SCART) && (msAPI_Timer_DiffTimeFromNow(u32ScartSwitchDuration) > 1200)&&(IsScartChange()))
        {
            //ZUI_TODO: MApp_UiMenu_ExecuteKeyEvent(MIA_EXIT);
            #if (ENABLE_PIP)
            if(IsPIPEnable()
                && !MApp_InputSource_PIP_IsSrcCompatible(INPUT_SOURCE_TV, SYS_INPUT_SOURCE_TYPE(SUB_WINDOW)))
            {
                //Close subwindow and set compatible source type to sub win
                if(stGenSetting.g_stPipSetting.enPipSoundSrc==EN_PIP_SOUND_SRC_SUB)
                {
                    stGenSetting.g_stPipSetting.enPipSoundSrc=EN_PIP_SOUND_SRC_MAIN;
                    MApp_InputSource_PIP_ChangeAudioSource(MAIN_WINDOW);
                }
                UI_SUB_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_NONE;
                MApp_InputSource_ChangeInputSource(SUB_WINDOW);
                stGenSetting.g_stPipSetting.enPipMode = EN_PIP_MODE_OFF;
                UI_SUB_INPUT_SOURCE_TYPE = MApp_InputSource_GetUIInputSourceType(MApp_InputSource_PIP_Get1stCompatibleSrc(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)));
            }
            #endif

            UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_ATV;
            MApp_InputSource_ChangeInputSource(MAIN_WINDOW);
            MApp_ChannelChange_VariableInit();
            MApp_TopStateMachine_SetTopState(STATE_TOP_CHANNELCHANGE);
            u32ScartSwitchDuration = msAPI_Timer_GetTime0();
            ResetScartChange();

            if (MApp_ZUI_GetActiveOSD()!=E_OSD_EMPTY) //ZUI:
            {
                MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_CLOSE_CURRENT_OSD);
            }
            if (stGenSetting.fRunInstallationGuide == FALSE )
            {
                MApp_ZUI_ACT_StartupOSD(E_OSD_CHANNEL_INFO);
                MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_SHOW_BRIEF_CH_INFO);
            }

            return;
        }
    }
#endif

#if (INPUT_SCART_VIDEO_COUNT >= 2)
    if (msAPI_GPIO_IsSourceJustDisConnected(INPUT_SOURCE_SCART2) == TRUE)
    {
        if ((SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)  == INPUT_SOURCE_SCART) && (msAPI_Timer_DiffTimeFromNow(u32ScartSwitchDuration) > 1200)&&(IsScartChange()))
        {
            //ZUI_TODO: MApp_UiMenu_ExecuteKeyEvent(MIA_EXIT);
            #if (ENABLE_PIP)
            if(IsPIPEnable()
                && !MApp_InputSource_PIP_IsSrcCompatible(INPUT_SOURCE_TV, SYS_INPUT_SOURCE_TYPE(SUB_WINDOW)))
            {
                //Close subwindow and set compatible source type to sub win
                if(stGenSetting.g_stPipSetting.enPipSoundSrc==EN_PIP_SOUND_SRC_SUB)
                {
                    stGenSetting.g_stPipSetting.enPipSoundSrc=EN_PIP_SOUND_SRC_MAIN;
                    MApp_InputSource_PIP_ChangeAudioSource(MAIN_WINDOW);
                }
                UI_SUB_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_NONE;
                MApp_InputSource_ChangeInputSource(SUB_WINDOW);
                stGenSetting.g_stPipSetting.enPipMode = EN_PIP_MODE_OFF;
                UI_SUB_INPUT_SOURCE_TYPE = MApp_InputSource_GetUIInputSourceType(MApp_InputSource_PIP_Get1stCompatibleSrc(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)));
            }
            #endif

            UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_ATV;
            MApp_InputSource_ChangeInputSource(MAIN_WINDOW);
            MApp_ChannelChange_VariableInit();
            MApp_TopStateMachine_SetTopState(STATE_TOP_CHANNELCHANGE);
            u32ScartSwitchDuration = msAPI_Timer_GetTime0();
            ResetScartChange();

            if (MApp_ZUI_GetActiveOSD()!=E_OSD_EMPTY) //ZUI:
            {
                MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_CLOSE_CURRENT_OSD);
            }
            if (stGenSetting.fRunInstallationGuide == FALSE )
            {
                MApp_ZUI_ACT_StartupOSD(E_OSD_CHANNEL_INFO);
                MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_SHOW_BRIEF_CH_INFO);
            }

            return;
        }
    }
#endif
}
#endif

#if ENABLE_OFFLINE_SIGNAL_DETECTION
#define    AIS_Debug(x)    x
typedef struct _SOURCE_SRC2LEVEL_STRUCT
{
    E_UI_INPUT_SOURCE source;
    U8 level;
} SOURCE_SRC2LEVEL_STRUCT;


static SOURCE_SRC2LEVEL_STRUCT code  _Source_Levels[] =
{
    {
        UI_INPUT_SOURCE_DTV,            // VIDEO - DTV Tuner
        6
    },
    {
        UI_INPUT_SOURCE_ATV,             // VIDEO - TV Tuner
        7
    },

#if (INPUT_SCART_VIDEO_COUNT >= 1)
    {
        UI_INPUT_SOURCE_SCART,
        18
    },
#endif
#if (INPUT_SCART_VIDEO_COUNT >= 2)
    {
        UI_INPUT_SOURCE_SCART2,
        17
    },
#endif
#if (INPUT_YPBPR_VIDEO_COUNT>=1)
    {
        UI_INPUT_SOURCE_COMPONENT,      // VIDEO - YPbPr
        26
    },
#endif
#if (INPUT_YPBPR_VIDEO_COUNT >= 2)
    {
        UI_INPUT_SOURCE_COMPONENT2,
        25
    },
#endif
    {
        UI_INPUT_SOURCE_RGB,            // PC - VGA
        19
    },
#if (INPUT_HDMI_VIDEO_COUNT >= 1)
    {
        UI_INPUT_SOURCE_HDMI,           // HDMI
        30
    },
#endif
#if (INPUT_HDMI_VIDEO_COUNT >= 2)
    {
        UI_INPUT_SOURCE_HDMI2,
        29
    },
#endif
#if (INPUT_HDMI_VIDEO_COUNT >= 3)
    {
        UI_INPUT_SOURCE_HDMI3,
        28
    },
#endif
#if (INPUT_HDMI_VIDEO_COUNT >= 4)
    {
        UI_INPUT_SOURCE_HDMI4,
        27
    },
#endif
#if (INPUT_AV_VIDEO_COUNT >= 1)
    {
        UI_INPUT_SOURCE_AV,             // VIDEO - CVBS
        24
    },
#endif
#if (INPUT_AV_VIDEO_COUNT >= 2)
    {
        UI_INPUT_SOURCE_AV2,
        23
    },
#endif
#if (INPUT_AV_VIDEO_COUNT >= 3)
    {
        UI_INPUT_SOURCE_AV3,
        22
    },
#endif
#if (INPUT_SV_VIDEO_COUNT >= 1)
    {
        UI_INPUT_SOURCE_SVIDEO,
        21
    },
#endif
#if ((INPUT_SCART_USE_SV2 == 0) && (INPUT_SV_VIDEO_COUNT >= 2))
    {
        UI_INPUT_SOURCE_SVIDEO2,
        20
    },
#endif

#ifdef ENABLE_DMP
    {
        UI_INPUT_SOURCE_DMP,
        16
    },
  #if( ENABLE_DMP_SWITCH )
    {
        UI_INPUT_SOURCE_DMP1,
        31
    },
    {
        UI_INPUT_SOURCE_DMP2,
        32
    },
  #endif
#endif //#ifdef ENABLE_DMP

#ifdef ENABLE_RSS
    {
        UI_INPUT_SOURCE_RSS,
        14
    },
#endif

#ifdef ENABLE_BT
    {
        UI_INPUT_SOURCE_BT,
        13
    },
#endif

#ifdef ENABLE_YOUTUBE
    {
        UI_INPUT_SOURCE_YOUTUBE,
        12
    },
#endif

    {
        UI_INPUT_SOURCE_GYM,
        11
    },
    {
        UI_INPUT_SOURCE_KTV,
        10
    },

    {
        UI_INPUT_SOURCE_PLUG_IN,
        9
    },
};
static U8 MApp_InputSourceIdMapToLevel(E_UI_INPUT_SOURCE id)
{
    U8 i;
    for (i = 0; i < COUNTOF(_Source_Levels); i++)
    {
        if (id == _Source_Levels[i].source)
        {
            return _Source_Levels[i].level;
        }
    }
    return  0;
}

void MApp_AISDebug(U8 bSrcCnt)
{
    if((bSrcCnt == UI_INPUT_SOURCE_ATV) ||(bSrcCnt == UI_INPUT_SOURCE_DTV))
        AIS_Debug(printf("*TV*"));
#if (INPUT_YPBPR_VIDEO_COUNT>=1)
    else if(bSrcCnt ==UI_INPUT_SOURCE_COMPONENT)
        AIS_Debug(printf("*YUV 1*"));
#endif
#if (INPUT_YPBPR_VIDEO_COUNT >= 2)
    else if(bSrcCnt ==UI_INPUT_SOURCE_COMPONENT2)
        AIS_Debug(printf("*YUV 2*"));
#endif
    else if(bSrcCnt ==UI_INPUT_SOURCE_RGB)
        AIS_Debug(printf("*RGB*"));
#if (INPUT_HDMI_VIDEO_COUNT >= 1)
    else if(bSrcCnt ==UI_INPUT_SOURCE_HDMI)
        AIS_Debug(printf("*HDMI-1*"));
#endif
#if (INPUT_HDMI_VIDEO_COUNT >= 2)
    else if(bSrcCnt ==UI_INPUT_SOURCE_HDMI2)
        AIS_Debug(printf("*HDMI-2*"));
#endif
#if (INPUT_HDMI_VIDEO_COUNT >= 3)
    else if(bSrcCnt ==UI_INPUT_SOURCE_HDMI3)
        AIS_Debug(printf("*HDMI-3*"));
#endif
#if (INPUT_AV_VIDEO_COUNT >= 1)
    else if(bSrcCnt ==UI_INPUT_SOURCE_AV)
        AIS_Debug(printf("*AV-1*"));
#endif
#if (INPUT_AV_VIDEO_COUNT >= 2)
    else if(bSrcCnt ==UI_INPUT_SOURCE_AV2)
        AIS_Debug(printf("*AV-2*"));
#endif
#if (INPUT_SV_VIDEO_COUNT >= 1)
    else if(bSrcCnt ==UI_INPUT_SOURCE_SVIDEO)
        AIS_Debug(printf("*SVideo-0*"));
#endif
#if ENABLE_DMP
    else if(bSrcCnt ==UI_INPUT_SOURCE_DMP)
        AIS_Debug(printf("*USB*"));
#if( ENABLE_DMP_SWITCH )
    else if(bSrcCnt ==UI_INPUT_SOURCE_DMP1)
        AIS_Debug(printf("*USB1*"));
    else if(bSrcCnt ==UI_INPUT_SOURCE_DMP2)
        AIS_Debug(printf("*USB2*"));
#endif
#endif
    else
    {
        AIS_Debug(printf("unknow: %u", bSrcCnt));
    }
}

void MApp_AISResultReset(void)
{
    U8 i;
    for(i=0;i<AIS_DOS_TIMES;i++)
    {
        stAISCtrl.strResult[i]=0;
    }
    stAISCtrl.bDotimes=0;
}

U8 MApp_AISGetAverage(void)
{
    U8 i,value;

    value=0;
    for(i=0;i<AIS_DOS_TIMES;i++)
    {
        value +=stAISCtrl.strResult[i];
    }
    AIS_Debug(printf("AVG:%u\n",value));

    if(value>(AIS_DOS_TIMES/2))
        return 1;
    else
        return 0;
}

void MApp_OffLineInit(void)
{
    U8 i;

    stAISCtrl.bUICHSourceFlag=1;
    stAISCtrl.bAISSrcPush=0xff;
    stAISCtrl.bSrcCnt=UI_INPUT_SOURCE_ATV;
    stAISCtrl.bSysTimeDuty=0;
    //stAISCtrl.bAISLock=1;
    stAISCtrl.dLockCnt=TIMER_STOP;
    stAISCtrl.bDotimes=0;
    stAISCtrl.bNoSignal=0;
    stAISCtrl.bDetectCnt=0;
    stAISCtrl.bDetectStart=0;
    MApp_AISResultReset();

    AIS_Debug(printf("OffLineIntial:\n"));
    for(i=0;i<UI_INPUT_SOURCE_NUM;i++)
    {
        AIS_Debug(printf("i=%u,",i));
        stAISSrcList[i].bChangeFlag=0;
        stAISSrcList[i].bUISourceID=i;
        stAISSrcList[i].bLevel=MApp_InputSourceIdMapToLevel((E_UI_INPUT_SOURCE)i);

        if((i==UI_INPUT_SOURCE_ATV)
     #if (INPUT_AV_VIDEO_COUNT >= 1)
         ||(i==UI_INPUT_SOURCE_AV)
     #endif
     #if (INPUT_AV_VIDEO_COUNT >= 2)
         ||(i==UI_INPUT_SOURCE_AV2)
          #endif
     #if (INPUT_YPBPR_VIDEO_COUNT>=1)
         ||(i==UI_INPUT_SOURCE_COMPONENT)
     #endif
         ||(i==UI_INPUT_SOURCE_RGB)
          )
        {
            stAISSrcList[i].bHaveSignal=1;
        }
        else
        {
            stAISSrcList[i].bHaveSignal=0;
        }
    }

    MApi_XC_OffLineInit();
    //MApi_XC_SetOffLineDetection(1);
    AIS_Debug(printf("\n"));
}


//get next available InputSourceType and convert it to SourceNum,
//and then query sc lib
INPUT_SOURCE_TYPE_t MApp_GetAISNextSetSource(void)
{
    BOOLEAN bFlag=1;
    MS_SYS_INFO tmpSystemInfo;
    E_DATA_INPUT_SOURCE enTempDataInpSrc;
    tmpSystemInfo.enInputSourceType = INPUT_SOURCE_NONE;
    AIS_Debug(printf("current SOURCE_TYPE = %u\n", UI_INPUT_SOURCE_TYPE));
    do
    {
        if(stAISCtrl.bSrcCnt>=UI_INPUT_SOURCE_NUM-1)    //Last Source
            stAISCtrl.bSrcCnt= UI_INPUT_SOURCE_ATV;

        // Only do offline detection for below valid Input Source.
        // If you want to add more input, please add it here and the function:MApi_XC_MUX_MapInputSourceToVDYMuxPORT
        if(((UI_INPUT_SOURCE_RGB == stAISCtrl.bSrcCnt)
#if (INPUT_AV_VIDEO_COUNT >= 1)
            || (UI_INPUT_SOURCE_AV == stAISCtrl.bSrcCnt)
#endif
#if (INPUT_AV_VIDEO_COUNT >= 2)
            || (UI_INPUT_SOURCE_AV2 == stAISCtrl.bSrcCnt)
#endif
#if 0//(INPUT_HDMI_VIDEO_COUNT >= 1)
            || (UI_INPUT_SOURCE_HDMI == stAISCtrl.bSrcCnt)
#endif
#if 0//(INPUT_HDMI_VIDEO_COUNT >= 2)
            || (UI_INPUT_SOURCE_HDMI2 == stAISCtrl.bSrcCnt)
#endif
#if 0//(INPUT_HDMI_VIDEO_COUNT >= 3)
            || (UI_INPUT_SOURCE_HDMI3 == stAISCtrl.bSrcCnt)
#endif
#if (INPUT_YPBPR_VIDEO_COUNT >= 1)
            || (UI_INPUT_SOURCE_COMPONENT == stAISCtrl.bSrcCnt)
#endif
#if (INPUT_YPBPR_VIDEO_COUNT >= 2)
            || (UI_INPUT_SOURCE_COMPONENT2 == stAISCtrl.bSrcCnt)
#endif
#if (INPUT_SV_VIDEO_COUNT >= 1)
            || (UI_INPUT_SOURCE_SVIDEO == stAISCtrl.bSrcCnt)
#endif
#if 0//def ENABLE_DMP//cancel detect usb source
            || (UI_INPUT_SOURCE_DMP == stAISCtrl.bSrcCnt)
#endif
            )
            && (UI_INPUT_SOURCE_TYPE != stAISCtrl.bSrcCnt))
        {
            bFlag=0;
        }
        else
        {
            stAISCtrl.bSrcCnt++;
        }

    }while(bFlag);

    MApp_InputSource_SetSystemmInfo( stAISCtrl.bSrcCnt, &tmpSystemInfo , &enTempDataInpSrc );

    AIS_Debug(printf("now process UI type: "));
    AIS_Debug(MApp_AISDebug(stAISCtrl.bSrcCnt));
    AIS_Debug(printf("\n"));
    AIS_Debug(printf("Map to InputSourceType: %u\n", tmpSystemInfo.enInputSourceType));

    return tmpSystemInfo.enInputSourceType;
}

void MApp_SetDetectChannel(void)
{
    INPUT_SOURCE_TYPE_t u8InputSourceType = INPUT_SOURCE_NONE;

    u8InputSourceType = MApp_GetAISNextSetSource();
    stAISCtrl.bDetectCnt++;

    if(INPUT_SOURCE_NONE != u8InputSourceType)
    {
        MApi_XC_SetOffLineDetection(u8InputSourceType);
        MApp_AISResultReset();
    }
    else
    {
        MApp_AISResultReset();
    }
    stAISCtrl.bSysTimeDuty= msAPI_Timer_GetTime0();
    //AIS_Debug(printf("get time:%lx\n",stAISCtrl.bSysTimeDuty));
}

void MApp_SetSrcListFlag(BOOLEAN bHaveSignal,U8 bSrcCnt)
{
    if(bHaveSignal)    //Have signal
    {
        AIS_Debug(printf(":Signal:%u,CHFlag:%u\n",stAISSrcList[bSrcCnt].bHaveSignal,stAISSrcList[bSrcCnt].bChangeFlag));

    if(stAISSrcList[bSrcCnt].bHaveSignal)    //No Change:Still have Signal
    {
        stAISSrcList[bSrcCnt].bChangeFlag=0;
    }
    else                                            //Signal Change:Plug in
    {
        AIS_Debug(printf("[Signal Plug in]\n",bSrcCnt));
        stAISSrcList[bSrcCnt].bChangeFlag=1;
        stAISSrcList[bSrcCnt].bHaveSignal=1;
        return;
    }
    }
    else    //No signal
    {
        AIS_Debug(printf(":Signal:%u,CHFlag:%u\n",stAISSrcList[bSrcCnt].bHaveSignal,stAISSrcList[bSrcCnt].bChangeFlag));
        if(stAISSrcList[bSrcCnt].bHaveSignal)    //    Signal Change:Plug out
        {
            AIS_Debug(printf("[Signal Plug Out]\n",bSrcCnt));
            stAISSrcList[bSrcCnt].bChangeFlag=1;
            stAISSrcList[bSrcCnt].bHaveSignal=0;
            return;
        }
        else                                            //No Change :Still no signal
        {
            stAISSrcList[bSrcCnt].bChangeFlag=0;
        }
    }

    AIS_Debug(printf("\r\n"));

    return;
}


void MApp_GetOffLineStatus(void)
{
    U8 bHaveSignal = 0;
    MS_SYS_INFO tmpSystemInfo;
    E_DATA_INPUT_SOURCE enTempDataInpSrc;

    MApp_InputSource_SetSystemmInfo( stAISCtrl.bSrcCnt, &tmpSystemInfo , &enTempDataInpSrc);

    bHaveSignal = MApi_XC_GetOffLineDetection(tmpSystemInfo.enInputSourceType);

    stAISCtrl.strResult[stAISCtrl.bDotimes++]=bHaveSignal;
    AIS_Debug(MApp_AISDebug(stAISCtrl.bSrcCnt));
    AIS_Debug(printf("times:%u,Signal:%u\n", stAISCtrl.bDotimes, bHaveSignal));
    if(stAISCtrl.bDotimes <AIS_DOS_TIMES)
    {
        return;
    }
    else
    {
        bHaveSignal = MApp_AISGetAverage();
    }

    //MApp_AISDebug(stAISCtrl.bSrcCnt);
    MApp_SetSrcListFlag(bHaveSignal,stAISCtrl.bSrcCnt);
    AIS_Debug(printf("-----------bHaveSignal:%u\r\n",bHaveSignal));
    return;
}

U8 MApp_GetStsChangeSrc(void)
{
    U8 i;

    for(i=0;i<UI_INPUT_SOURCE_NUM;i++)
    {
        if(stAISSrcList[i].bChangeFlag)
        {
            stAISSrcList[i].bChangeFlag=0;
            return i;
        }
    }

    return 0xff;
}
U8 MApp_GetShowTopChangeSrc(void)
{
    U8 i;
    U8 level=0;
    U8 SrcID=0xFF;
    for(i=0;i<UI_INPUT_SOURCE_NUM;i++)
    {
        if(stAISSrcList[i].bChangeFlag&&stAISSrcList[i].bHaveSignal)
        {
            AIS_Debug(printf("-SrcID=%d-bLevel=%d-\n",i,stAISSrcList[i].bLevel));//
            if(stAISSrcList[i].bLevel>=level)
            {
                level=stAISSrcList[i].bLevel;
                SrcID=i;
            }
        }
    }
    if(SrcID!=0xFF)
    {
       stAISSrcList[SrcID].bChangeFlag=0;
       AIS_Debug(printf("-End SrcID=%d-bLevel=%d-\n",SrcID,stAISSrcList[SrcID].bLevel));//
    }
    return SrcID;
}

U8 MApp_GetAISReturnSrcID(void)
{
    U8 i,SrcID=0xff;
    AIS_Debug(printf("Get Have Signal Channel:"));
    for(i=0;i<UI_INPUT_SOURCE_NUM;i++)
    {
       //AIS_Debug(printf("---i=%bu---\n",i));
        if(stAISSrcList[i].bHaveSignal)
        {
            if((i==UI_INPUT_SOURCE_ATV) /*||(i==UI_INPUT_SOURCE_DTV)*/
      #if ENABLE_DMP
		 ||(i==UI_INPUT_SOURCE_DMP)
	       #if( ENABLE_DMP_SWITCH )
                 ||(i==UI_INPUT_SOURCE_DMP1)
                 ||(i==UI_INPUT_SOURCE_DMP2)
               #endif
	#endif
		    )
                continue;
            else
            {
                SrcID=i;
                break;
            }

        }
    }
    if(SrcID == 0xff)
        SrcID=UI_INPUT_SOURCE_ATV;
    AIS_Debug(printf("SrcID:%d\n",SrcID));

    return SrcID;

}

void    MApp_AISMonitor(void)
{
    U8 bValue=0xff;
    BOOLEAN bChange_Flag=FALSE;
    U8 bDetectNum=4;
    stGenSetting.g_SysSetting.bAIS=AIS_DISPLAY;//AIS_SWITCH;//AIS_DISPLAY;
    if(stGenSetting.g_SysSetting.bAIS==AIS_OFF/*||(!MApp_IsNormalMode())*/)
        return;
    if(msAPI_Tuner_IsTuningProcessorBusy())
    {
        //printf(" AIS: Scan return\n");
        return;
    }
    if((UI_INPUT_SOURCE_TYPE==UI_INPUT_SOURCE_COMPONENT)
        ||(UI_INPUT_SOURCE_TYPE==UI_INPUT_SOURCE_AV)
#if (INPUT_AV_VIDEO_COUNT >= 2)
        ||(UI_INPUT_SOURCE_TYPE==UI_INPUT_SOURCE_AV2)
#endif
        ||(UI_INPUT_SOURCE_TYPE==UI_INPUT_SOURCE_RGB)
        )
    {
        bDetectNum=3;
    }
    else
    {
        bDetectNum=4;
    }
    if(stAISCtrl.dLockCnt==TIMER_STOP)
   {
    }
    else if(stAISCtrl.dLockCnt>2500)
    {
        stAISCtrl.dLockCnt=TIMER_STOP;
    }
    else
    {
        stAISCtrl.dLockCnt++;
        return;
    }

    if(0 == stAISCtrl.bSysTimeDuty)
    {
        MApp_SetDetectChannel();
    }

    if ( msAPI_Timer_DiffTimeFromNow( stAISCtrl.bSysTimeDuty ) > AIS_DETECT_DUTY )
    {
        //AIS_Debug(printf("get time2:%lx\n",msAPI_Timer_GetTime0()));
        MApp_GetOffLineStatus();
        if(stAISCtrl.bDotimes<AIS_DOS_TIMES)
        {
            stAISCtrl.bSysTimeDuty= msAPI_Timer_GetTime0();
            return;
        }
        else
        {
            stAISCtrl.bSrcCnt++;
            stAISCtrl.bSysTimeDuty=0;
        }

        /*
            Here, draw menu and some other AP behavior according to stAISSrcList[bValue].bHaveSignal
        */
        if(stAISCtrl.bDetectCnt>=bDetectNum)
        {
           stAISCtrl.bDetectCnt=0;
           stAISCtrl.bDetectStart=TRUE;
           bChange_Flag=TRUE;
        }
        else
        {
           bChange_Flag=FALSE;
        }
        switch(stGenSetting.g_SysSetting.bAIS)
        {
           default:
           case AIS_OFF:
            break;
           case AIS_DISPLAY:
            if(!stAISCtrl.bDetectStart)
            {
                break;
            }
            if(bChange_Flag)
            {
                bChange_Flag=FALSE;
                bValue= MApp_GetShowTopChangeSrc();
                AIS_Debug(printf("-Detect Display Source=%d--\n",bValue));//
            }
            else
            {
                break;
            }
               //  bValue=MApp_GetStatusChangeSrc();        //Clear Signal Change Flag...
            if((bValue<UI_INPUT_SOURCE_NUM) &&(bValue!=UI_INPUT_SOURCE_TYPE) )    //Valid Source
            {
                if(MApp_IsSrcHasSignal(MAIN_WINDOW))
                {
                    stAISSrcList[UI_INPUT_SOURCE_TYPE].bHaveSignal=1;
                    AIS_Debug(printf("-AIS_DISPLAY:current source has signal no change--\n"));//
                }
                else
                    stAISSrcList[UI_INPUT_SOURCE_TYPE].bHaveSignal=0;

                if(stAISSrcList[bValue].bHaveSignal)// Plug in
                {
                    stAISCtrl.bAISSrcPush=bValue;
                    //Draw UI Message,Wait "Yes/No"
                    if (IsAnyTVSourceInUse())
                    {
                        MApp_TopStateMachine_SetTopState(STATE_TOP_DIGITALINPUTS);
                    }
                    else
                    {
                        MApp_TopStateMachine_SetTopState(STATE_TOP_DIGITALINPUTS);
                    }
                    MApp_ZUI_ACT_StartupOSD(E_OSD_MESSAGE_BOX);
                    MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_SHOW_CEC_DEVICE_MSGBOX);

                    AIS_Debug(printf("-show  source display change--\n"));
                }
            }
            break;
            case AIS_SWITCH:
            if(!stAISCtrl.bDetectStart)
            {
                break;
            }
            if(bChange_Flag)
            {
                bChange_Flag=FALSE;
                bValue= MApp_GetShowTopChangeSrc();
                AIS_Debug(printf("-Detect change Source=%d--\n",bValue));//
            }
            else
            {
                break;
            }
            if((bValue<UI_INPUT_SOURCE_NUM)&&(bValue!=UI_INPUT_SOURCE_TYPE))//    Valid Source
            {
                if(stAISSrcList[bValue].bHaveSignal)// Plug in
                {
                    if(MApp_IsSrcHasSignal(MAIN_WINDOW))
                    {
                        stAISSrcList[UI_INPUT_SOURCE_TYPE].bHaveSignal=1;
                        AIS_Debug(printf("-AIS_SWITCH:current source has signal no change-\n"));//
                    }
                    else
                        stAISSrcList[UI_INPUT_SOURCE_TYPE].bHaveSignal=0;

                stAISCtrl.bAISSrcPush=bValue;

                UI_INPUT_SOURCE_TYPE=(E_UI_INPUT_SOURCE)bValue;
                MApp_InputSource_RecordSource(UI_INPUT_SOURCE_TYPE);
                MApp_InputSource_ChangeInputSource(MAIN_WINDOW);
                MApp_ChannelChange_VariableInit();
                MApp_TopStateMachine_SetTopState(STATE_TOP_ANALOG_SHOW_BANNER);//(STATE_TOP_ANALOG_SHOW_BANNER);
                stAISCtrl.bUICHSourceFlag=0;
                AIS_Debug(printf("-AIS_SWITCH:change to source=%d--\n",UI_INPUT_SOURCE_TYPE));
                }
            }
            break;
        }

        //---MainDisplay Nosigal Return Fuction Begin---
        if(stAISCtrl.bUICHSourceFlag ||(UI_INPUT_SOURCE_ATV ==UI_INPUT_SOURCE_TYPE))
        {
            AIS_Debug(printf("-Don't detect signal-\n"));
            return;
        }
        AIS_Debug(printf("---AIS_Nosiganl=%d----\n",stAISCtrl.bNoSignal));

        if(stAISCtrl.bNoSignal)
        {
            AIS_Debug(printf("-MainDisplay NoSignal--\n"));

            stAISSrcList[UI_INPUT_SOURCE_TYPE].bHaveSignal=0;
            //AIS_Debug(printf("-------AIS Return Signal in Source--------\n"));
            bValue=MApp_GetAISReturnSrcID();
            AIS_Debug(printf("---Get Source id:%d----\n",bValue));
            if(UI_INPUT_SOURCE_TYPE != bValue)
            {
                UI_INPUT_SOURCE_TYPE=(E_UI_INPUT_SOURCE)bValue;
                MApp_InputSource_RecordSource(UI_INPUT_SOURCE_TYPE);
                MApp_InputSource_ChangeInputSource(MAIN_WINDOW);
                MApp_ChannelChange_VariableInit();
                MApp_TopStateMachine_SetTopState(STATE_TOP_ANALOG_SHOW_BANNER);
                stAISCtrl.bUICHSourceFlag=0;
                AIS_Debug(printf("-Auto:change to source=%d--\n",UI_INPUT_SOURCE_TYPE));
            }
        }
    //---MainDisplay Nosigal Return Fuction end---

    }
}
#endif

#if (ENABLE_PIP)
#define PIP_INPUT_SOURCE_NUM 8
static U8 _u8PipTable[PIP_INPUT_SOURCE_NUM][PIP_INPUT_SOURCE_NUM] =
{
/*              DTV, ATV, CVBS, SCART, SV, COMPONENT, VGA, HDMI */
/* DTV */       {0, 0, 0, 0, 0, 1, 1, 1,},
/* ATV */       {0, 0, 0, 0, 0, 1, 1, 1,},
/* CVBS */      {0, 0, 0, 0, 0, 1, 1, 1,},
/* SCART */     {0, 0, 0, 0, 0, 0, 0, 1,},
/* SV */        {0, 0, 0, 0, 0, 0, 0, 1,},
/* COMPONENT */ {1, 1, 1, 0, 0, 0, 0, 1,},
/* VGA */       {1, 1, 1, 0, 0, 0, 0, 1,},
/* HDMI */      {1, 1, 1, 1, 1, 1, 1, 0,},
};
E_UI_INPUT_SOURCE MApp_InputSource_GetUIInputSourceType(INPUT_SOURCE_TYPE_t stInputSrc)
{
    switch(stInputSrc)
    {
        case INPUT_SOURCE_VGA:
            return UI_INPUT_SOURCE_RGB;
        case INPUT_SOURCE_TV:
            return UI_INPUT_SOURCE_ATV;
        case INPUT_SOURCE_CVBS:
#if (INPUT_AV_VIDEO_COUNT >= 1)
            return UI_INPUT_SOURCE_AV;
#endif
            break;
        case INPUT_SOURCE_CVBS2:
#if (INPUT_AV_VIDEO_COUNT >= 2)
            return UI_INPUT_SOURCE_AV2;
#endif
            break;
        case INPUT_SOURCE_CVBS3:
#if (INPUT_AV_VIDEO_COUNT >= 3)
            return UI_INPUT_SOURCE_AV3;
#endif
            break;
        case INPUT_SOURCE_SVIDEO:
#if (INPUT_SV_VIDEO_COUNT >= 1)
            return UI_INPUT_SOURCE_SVIDEO;
#endif
            break;
        case INPUT_SOURCE_SVIDEO2:
#if (INPUT_SV_VIDEO_COUNT >= 2)
            return UI_INPUT_SOURCE_SVIDEO2;
#endif
            break;
        case INPUT_SOURCE_YPBPR:
#if (INPUT_YPBPR_VIDEO_COUNT>=1)
            return UI_INPUT_SOURCE_COMPONENT;
#endif
            break;
        case INPUT_SOURCE_YPBPR2:
#if (INPUT_YPBPR_VIDEO_COUNT>=2)
            return UI_INPUT_SOURCE_COMPONENT2;
#endif
            break;
        case INPUT_SOURCE_SCART:
#if (INPUT_SCART_VIDEO_COUNT >= 1)
            return UI_INPUT_SOURCE_SCART;
#endif
            break;
        case INPUT_SOURCE_SCART2:
#if (INPUT_SCART_VIDEO_COUNT >= 2)
            return UI_INPUT_SOURCE_SCART2;
#endif
            break;
        case INPUT_SOURCE_HDMI:
#if (INPUT_HDMI_VIDEO_COUNT >= 1)
            return UI_INPUT_SOURCE_HDMI;
#endif
            break;
        case INPUT_SOURCE_HDMI2:
#if (INPUT_HDMI_VIDEO_COUNT >= 2)
            return UI_INPUT_SOURCE_HDMI2;
#endif
            break;
        case INPUT_SOURCE_HDMI3:
#if (INPUT_HDMI_VIDEO_COUNT >= 3)
            return UI_INPUT_SOURCE_HDMI3;
#endif
            break;
        case INPUT_SOURCE_HDMI4:
#if (INPUT_HDMI_VIDEO_COUNT >= 4)
            return UI_INPUT_SOURCE_HDMI4;
#endif
            break;
        case INPUT_SOURCE_DTV:
            return UI_INPUT_SOURCE_DTV;
      #if ENABLE_DMP
        case INPUT_SOURCE_STORAGE:
            return UI_INPUT_SOURCE_DMP;
      #endif
        default:
            break;
    }
    return UI_INPUT_SOURCE_NONE;
}
#endif
INPUT_SOURCE_TYPE_t MApp_InputSource_GetInputSourceType(E_UI_INPUT_SOURCE stInputSrc)
{
    switch(stInputSrc)
    {
        case UI_INPUT_SOURCE_DTV:
            return INPUT_SOURCE_DTV;
        case UI_INPUT_SOURCE_ATV:
            return INPUT_SOURCE_TV;
#if (INPUT_AV_VIDEO_COUNT >= 1)
        case UI_INPUT_SOURCE_AV:
            return INPUT_SOURCE_CVBS;
#endif
            break;
#if (INPUT_AV_VIDEO_COUNT >= 2)
        case UI_INPUT_SOURCE_AV2:
            return INPUT_SOURCE_CVBS2;
#endif
#if (INPUT_AV_VIDEO_COUNT >= 3)
        case UI_INPUT_SOURCE_AV3:
            return INPUT_SOURCE_CVBS3;
#endif
#if (INPUT_SV_VIDEO_COUNT >= 1)
        case UI_INPUT_SOURCE_SVIDEO:
            return INPUT_SOURCE_SVIDEO;
#endif
#if (INPUT_SV_VIDEO_COUNT >= 2)
        case UI_INPUT_SOURCE_SVIDEO2:
            return INPUT_SOURCE_SVIDEO2;
#endif
#if (INPUT_YPBPR_VIDEO_COUNT>=1)
        case UI_INPUT_SOURCE_COMPONENT:
            return INPUT_SOURCE_YPBPR;
#endif
#if (INPUT_YPBPR_VIDEO_COUNT>=2)
        case UI_INPUT_SOURCE_COMPONENT2:
            return INPUT_SOURCE_YPBPR2;
#endif
#if (INPUT_SCART_VIDEO_COUNT >= 1)
        case UI_INPUT_SOURCE_SCART:
            return INPUT_SOURCE_SCART;
#endif
#if (INPUT_SCART_VIDEO_COUNT >= 2)
        case UI_INPUT_SOURCE_SCART2:
            return INPUT_SOURCE_SCART2;
#endif
#if (INPUT_HDMI_VIDEO_COUNT >= 1)
        case UI_INPUT_SOURCE_HDMI:
            return INPUT_SOURCE_HDMI;
#endif
#if (INPUT_HDMI_VIDEO_COUNT >= 2)
        case UI_INPUT_SOURCE_HDMI2:
            return INPUT_SOURCE_HDMI2;
#endif
#if (INPUT_HDMI_VIDEO_COUNT >= 3)
        case UI_INPUT_SOURCE_HDMI3:
            return INPUT_SOURCE_HDMI3;
#endif
#if (INPUT_HDMI_VIDEO_COUNT >= 4)
        case UI_INPUT_SOURCE_HDMI4:
            return INPUT_SOURCE_HDMI4;
#endif
        case UI_INPUT_SOURCE_RGB:
            return INPUT_SOURCE_VGA;
      #if ENABLE_DMP
        case UI_INPUT_SOURCE_DMP:
            return INPUT_SOURCE_STORAGE;
       #if( ENABLE_DMP_SWITCH )
         case UI_INPUT_SOURCE_DMP1:
            return INPUT_SOURCE_STORAGE;
         case UI_INPUT_SOURCE_DMP2:
            return INPUT_SOURCE_STORAGE;
       #endif
      #endif
        default:
            break;
    }
    return INPUT_SOURCE_NONE;
}

#if (ENABLE_PIP)
void MApp_InputSource_PIP_Swap(void)
{
    E_UI_INPUT_SOURCE preMainUIInputSrc = UI_INPUT_SOURCE_TYPE;
    E_UI_INPUT_SOURCE preSubUIInputSrc = UI_SUB_INPUT_SOURCE_TYPE;

    if(!IsPIPSupported())
    {
        printf("MApp_InputSource_PIP_Swap: This chip do not support PIP!\n");
        return;
    }
    if(stGenSetting.g_stPipSetting.enSubInputSourceType == UI_INPUT_SOURCE_NONE)
    {
        printf("[SWAP] Please check UI input source = NONE!\n");
        return;
    }
    // 1. empty main & sub window
    UI_SUB_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_NONE;
    MApp_InputSource_ChangeInputSource(SUB_WINDOW);
    UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_NONE;
    MApp_InputSource_ChangeInputSource(MAIN_WINDOW);
    // 2. create sub window with prev. main input source
    UI_INPUT_SOURCE_TYPE = preSubUIInputSrc;
    MApp_InputSource_ChangeInputSource(MAIN_WINDOW);
    // 3. switch main -> sub
    UI_SUB_INPUT_SOURCE_TYPE = preMainUIInputSrc;
    MApp_InputSource_ChangeInputSource(SUB_WINDOW);
}
static U8 _MApp_InputSource_PIP_GetCompatibleNum(INPUT_SOURCE_TYPE_t enSrc)
{
    U8 u8Value = 0xFF;

    switch(enSrc)
    {
        case INPUT_SOURCE_VGA:
            u8Value = 6;
            break;
        case INPUT_SOURCE_TV:
            u8Value = 1;
            break;
        case INPUT_SOURCE_CVBS:
        case INPUT_SOURCE_CVBS2:
        case INPUT_SOURCE_CVBS3:
        case INPUT_SOURCE_CVBS4:
        case INPUT_SOURCE_CVBS5:
        case INPUT_SOURCE_CVBS6:
        case INPUT_SOURCE_CVBS7:
        case INPUT_SOURCE_CVBS8:
            u8Value = 2;
            break;
        case INPUT_SOURCE_SVIDEO:
        case INPUT_SOURCE_SVIDEO2:
        case INPUT_SOURCE_SVIDEO3:
        case INPUT_SOURCE_SVIDEO4:
            u8Value = 4;
            break;
        case INPUT_SOURCE_YPBPR:
        case INPUT_SOURCE_YPBPR2:
        case INPUT_SOURCE_YPBPR3:
            u8Value = 5;
            break;
        case INPUT_SOURCE_SCART:
        case INPUT_SOURCE_SCART2:
            u8Value = 3;
            break;
        case INPUT_SOURCE_HDMI:
        case INPUT_SOURCE_HDMI2:
        case INPUT_SOURCE_HDMI3:
        case INPUT_SOURCE_HDMI4:
            u8Value = 7;
            break;
        case INPUT_SOURCE_DTV:
            u8Value = 0;
            break;
        default:
            break;
    }
    return u8Value;
}
BOOLEAN MApp_InputSource_PIP_IsSrcCompatible(INPUT_SOURCE_TYPE_t enSrcMain, INPUT_SOURCE_TYPE_t enSrcSub)
{
    U8 u8Main = _MApp_InputSource_PIP_GetCompatibleNum(enSrcMain);
    U8 u8Sub = _MApp_InputSource_PIP_GetCompatibleNum(enSrcSub);

    if(u8Main >= PIP_INPUT_SOURCE_NUM || u8Sub >= PIP_INPUT_SOURCE_NUM)
    {
        return FALSE;
    }

    return (BOOLEAN)_u8PipTable[u8Main][u8Sub];
}
INPUT_SOURCE_TYPE_t MApp_InputSource_PIP_Get1stCompatibleSrc(INPUT_SOURCE_TYPE_t enSrc)
{
    U8 u8Num = _MApp_InputSource_PIP_GetCompatibleNum(enSrc);
    U8 i = 0;

    for(i = 0; i < PIP_INPUT_SOURCE_NUM; i++)
    {
        if(_u8PipTable[u8Num][i] != 0)
        {
            //Found!
            break;
        }
    }

    switch(i)
    {
        case 0:
            return INPUT_SOURCE_DTV;
        case 1:
            return INPUT_SOURCE_TV;
        case 2:
            return INPUT_SOURCE_CVBS;
        case 3:
            return INPUT_SOURCE_SCART;
        case 4:
            return INPUT_SOURCE_SVIDEO;
        case 5:
            return INPUT_SOURCE_YPBPR;
        case 6:
            return INPUT_SOURCE_VGA;
        case 7:
            return INPUT_SOURCE_HDMI;
        default:
            printf("Not found! Compatible list error\n");
            break;
    }

    return INPUT_SOURCE_NONE;
}
BOOLEAN MApp_InputSource_PIP_GetSubWinRect(MS_WINDOW_TYPE *stWinRect)
{
    if(IsPIPEnable())
    {
        U8 u8TempPIP_Offset = 3;
        //First calculate the large sub window width and height
        U16 u16TempPIP_Width = (PANEL_WIDTH - SCREEN_SAVER_FRAME_WIDTH)/2 - u8TempPIP_Offset;
        U16 u16TempPIP_Height = u16TempPIP_Width*PANEL_HEIGHT/PANEL_WIDTH;

        stWinRect->x = 0;
        stWinRect->y = 0;
        stWinRect->width = PANEL_WIDTH;
        stWinRect->height = PANEL_HEIGHT;
        if(stGenSetting.g_stPipSetting.enPipMode == EN_PIP_MODE_PIP)
        {
            switch(stGenSetting.g_stPipSetting.enPipSize)
            {
                default:
                case EN_PIP_SIZE_LARGE: //125%
                       stWinRect->width = u16TempPIP_Width;
                       stWinRect->height = u16TempPIP_Height;
                       break;
                case EN_PIP_SIZE_MEDIUM: //100%
                       stWinRect->width = u16TempPIP_Width/5*4;
                       stWinRect->height = stWinRect->width*PANEL_HEIGHT/PANEL_WIDTH;
                       break;
                case EN_PIP_SIZE_SMALL: //75%
                       stWinRect->width = u16TempPIP_Width/5*3;
                       stWinRect->height = stWinRect->width*PANEL_HEIGHT/PANEL_WIDTH;
                       break;
            }
            switch(stGenSetting.g_stPipSetting.enPipPosition)
            {
                default:
                case EN_PIP_POSITION_LEFT_TOP:
                    stWinRect->x = 0;
                    stWinRect->y = 0;
                    break;
                case EN_PIP_POSITION_RIGHT_TOP:
                    stWinRect->x = (PANEL_WIDTH - stWinRect->width);
                    stWinRect->y = 0;
                    break;
                case EN_PIP_POSITION_LEFT_BOTTOM:
                    stWinRect->x = 0;
                    stWinRect->y = (PANEL_HEIGHT - stWinRect->height);
                    break;
                case EN_PIP_POSITION_RIGHT_BOTTOM:
                    stWinRect->x = (PANEL_WIDTH - stWinRect->width);
                    stWinRect->y = (PANEL_HEIGHT - stWinRect->height);
                    break;
            }
            return TRUE;
        }
        else if(stGenSetting.g_stPipSetting.enPipMode == EN_PIP_MODE_POP_FULL)
        {
            stWinRect->width = PANEL_WIDTH/2;
            stWinRect->height = PANEL_HEIGHT;
            stWinRect->x = PANEL_WIDTH/2;
            stWinRect->y = 0;
            return TRUE;
        }
        else if(stGenSetting.g_stPipSetting.enPipMode == EN_PIP_MODE_POP)
        {
            stWinRect->width = PANEL_WIDTH/2;
            stWinRect->height = (PANEL_WIDTH/2) * PANEL_HEIGHT / PANEL_WIDTH;
            stWinRect->y = PANEL_HEIGHT/2-stWinRect->height/2;
            stWinRect->x = PANEL_WIDTH/2;
            return TRUE;
        }
    }
    return FALSE;
}

void MApp_InputSource_PIP_ChangeAudioSource( SCALER_WIN eWindow )
{
    if(UI_IS_AUDIO_SOURCE_IN(eWindow))
    {
        msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_BYSYNC_MUTEON, E_AUDIOMUTESOURCE_ACTIVESOURCE);
        MApp_InputSource_ChangeAudioSource( stSystemInfo[eWindow].enInputSourceType );
        if(IsSrcTypeDTV(SYS_INPUT_SOURCE_TYPE(eWindow)) || IsSrcTypeATV(SYS_INPUT_SOURCE_TYPE(eWindow)))
        {
             MApp_ChannelChange_PIP_ChangeAudioSource2TV (eWindow);
        }
        else if( IsSrcTypeHDMI(SYS_INPUT_SOURCE_TYPE(eWindow)))
        {
            MAPP_PCMode_PIP_ChangeAudioSource2HDMI(eWindow);
        }
        msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_BYSYNC_MUTEOFF, E_AUDIOMUTESOURCE_ACTIVESOURCE);
    }
}
#endif

#if (ENABLE_CUS_UI_SPEC && ENABLE_SZ_BLUESCREEN_FUNCTION)
BOOLEAN MApp_InputSource_ResetAspectRatio(void)
{
    //signal-in source change to no-signal source,set zoom mode to 16:9
    if((IsStorageInUse() == FALSE) && MApp_IsSrcHasSignal(MAIN_WINDOW) && (stGenSetting.g_SysSetting.bIsBluescreenOn == ENABLE))
    {
    /*
      if((ST_VIDEO.eAspectRatio == EN_AspectRatio_4X3)
          || (ST_VIDEO.eAspectRatio == EN_AspectRatio_14X9)
          || (ST_VIDEO.eAspectRatio == EN_AspectRatio_Original)
          || (ST_VIDEO.eAspectRatio == EN_AspectRatio_JustScan))
          */
	if(ST_VIDEO.eAspectRatio != EN_AspectRatio_16X9)
      {
          EN_MENU_AspectRatio eAspectRatioTemp;
          printf("\r\n Set zoom mode to 16:9 before change source. \n");/*Creass.liu at 2012-08-02*/
          eAspectRatioTemp = ST_VIDEO.eAspectRatio;
          ST_VIDEO.eAspectRatio = EN_AspectRatio_16X9;
          MApp_Scaler_Setting_SetVDScale( ST_VIDEO.eAspectRatio, MAIN_WINDOW );
          ST_VIDEO.eAspectRatio = eAspectRatioTemp;
      }
    }
    return TRUE;
}
#endif




////////////////////////////////////////////////////////////////////////////////
#undef MAPP_INPUTSOURCE_C

