////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#define MAPP_INIT_C

//------------------------------------------------------------------------------
//                            Header Files
//------------------------------------------------------------------------------
#include <string.h>
#include <stdio.h>
#include "util_checkversion.h"
#include "Board.h"
#include "datatype.h"
#include "debug.h"
#include "MsTypes.h"
#include "drvBDMA.h"

#if DEBUG_USE_UART_COMMAND
#include "drvAeonUART.h"
#endif

// Common Definition
#include "datatype.h"

#include "MsIRQ.h"
#include "MsOS.h"

#include "apiGOP.h"
#include "apiXC.h"
#include "apiXC_Adc.h"
#include "apiXC_Sys.h"
#include "apiXC_ModeParse.h"
#include "apiXC_Cus.h"
#include "apiAUDIO.h"
#include "apiCEC.h"
#include "apiPNL.h"
#include "Panel.h"

//#include "BD_MST031B_10AL0_11523.h"

#ifdef SCART_OUT_NEW_METHOD
#include "drvTVEncoder.h"
#endif

#include "drvPM.h"
#include "drvGPIO.h"
#include "apiXC_Ace.h"
#include "msAPI_Power.h"
#include "msAPI_Memory.h"
#include "msAPI_MIU.h"
#include "msAPI_DrvInit.h"
#include "msAPI_Video.h"
#include "msAPI_IR.h"
#include "msAPI_Ram.h"
#include "apiGOP.h"
#include "msAPI_OSD.h"
#include "msAPI_Tuner.h"
#include "msAPI_Timer.h"
#include "apiXC_Dlc.h"
#include "msAPI_OCP.h"
#include "msAPI_DTVSystem.h"
#include "msAPI_ATVSystem.h"
#include "msAPI_ChProc.h"
#include "msAPI_Flash.h"
#include "msAPI_audio.h"
#include "msAPI_Font.h"

#include "msAPI_MSDCtrl.h"
#include "msAPI_FCtrl.h"
#include "msAPI_FSEnv.h"
#include "msAPI_DCC.h"
#include "msAPI_FS_SysInfo.h"

#if (VECTOR_FONT_ENABLE) && (COPRO_MVF_ENABLE)
#include "msAPI_CPU.h"
#endif

#include "drvSYS.h"
#include "MApp_Font.h"
#include "MApp_RestoreToDefault.h"
#include "MApp_MultiTasks.h"
#include "MApp_Font.h"
#include "MApp_GlobalVar.h"
#include"MApp_GlobalSettingSt.h"
#include "MApp_GlobalFunction.h"
#include "MApp_Key.h"
#include "MApp_IR.h"
#include "MApp_Bitmap.h"
#include "MApp_Init.h"
#include "MApp_SignalMonitor.h"
#include "MApp_InputSource.h"

#include "MApp_PCMode.h"
#include "MApp_Audio.h"
#include "MApp_Logo.h"

#if (ENABLE_SUBTITLE)
#include "MApp_Subtitle.h"
#endif

#include "MApp_Scaler.h"
#include "MApp_SaveData.h"
#include "MApp_MVDMode.h"
#include "MApp_DataBase.h"
#include "MApp_UiEpg.h"

#if (ENABLE_DTV)
#include "mapp_demux.h"
#include "mapp_si.h"
#endif

#if (ENABLE_DTV_EPG)
#include "mapp_epgdb_public.h"
#include "mapp_eit.h"
#endif

#include "MApp_Scan.h"
#include "MApp_UiMenuDef.h"
#include "MApp_Sleep.h"
#include "OSDcp_readbin.h"
#include "OSDcp_loadfont.h"
#include "MApp_EpgTimer.h"
#include "MApp_ChannelChange.h"
#include "MApp_VDMode.h"
#include "MApp_ATVProc.h"
#include "MApp_BlockSys.h"
#include "MApp_ZUI_Main.h"
#include "MApp_LoadFontInit.h"
#if DISPLAY_LOGO
#include "MApp_Logo.h"
#endif
#include "MApp_UiMediaPlayer_Define.h"
#if ENABLE_OD
#include "Pnl_OdTable.h"
#endif

#if ((BRAZIL_CC )|| (ATSC_CC == ATV_CC))
#include "msAPI_vbi.h"
#include "mapp_closedcaption.h"
#endif

#if ENABLE_DMP
#include "mapp_mplayer.h"
#endif

#if ENABLE_OAD
#include "imginfo.h"
#include "MApp_OAD.h"
#endif //ENABLE_OAD

#if ENABLE_CI
#include "msAPI_CI.h"
#include "MApp_CIMMI.h"
#endif

#include "GPIO.h"

#if (HDMI_SWITCH_SELECT != HDMI_SWITCH_NONE)
#include "HdmiSwitch.h"
#endif // #if (HDMI_SWITCH_SELECT != HDMI_SWITCH_NONE)

#if ENABLE_PVR
#include "MApp_UiPvr.h"
#include "msAPI_PVRFileSystem.h"
    #if (ENABLE_PVR_AESDMA)
        #ifdef PVR_UTOPIA
        #include "drvAESDMA.h"
        #endif
    #endif
#endif
#include "msAPI_Global.h"

#if (ENABLE_TTX)
#include "msAPI_TTX.h"
#include "mapp_ttx.h"
#endif

#if(ENABLE_DTV)
#include "MApp_SI_Parse.h"
#endif
#if (ENABLE_UPDATE_MULTIPLEX_VIA_NIT)
#include "MApp_TV.h"
#endif
#include "mapp_photo_display.h"

#ifndef GOP_TEST_CODE
#define GOP_TEST_CODE       0
#endif

#if MHEG5_ENABLE
#include "msAPI_MHEG5.h"
#endif

#if(ENABLE_6M30_3D_PROCESS)
#include "drvUrsa6M30.h"
#endif
#ifdef ENABLE_SELECT_NONESEARCH_CH
#include "MApp_TV.h"
#endif
#if ( ENABLE_CEC || ENABLE_SW_CEC_WAKEUP)
#include "msAPI_CEC.h"
#endif
#include "msAPI_Tuning.h"
#if ENABLE_JPEGPNG_OSD
#include "msAPI_OCP_A.h"
#endif
#include "MApp_TV.h"

#include "MApp_Standby.h"

#if BOE_ACPOWERON_AUTO_UPGRADE
extern int BOE_usb_check(void);
#endif


//#include "MApp_Customer_Info.h"
extern unsigned char code CID_Buf[];
extern unsigned char code IP_Cntrol_Mapping_1[8];
extern unsigned char code IP_Cntrol_Mapping_2[8];
extern unsigned char code IP_Cntrol_Mapping_3[8];
extern unsigned char code IP_Cntrol_Mapping_4[8];

unsigned char Customer_info[49];
#define DEBUG_CUSTOMER_INFO_ENABLE 0
#if ENABLE_CI
#define CI_INIT_DETECT_COUNT  3
#endif

#if ENABLE_AUTOTEST
extern BOOLEAN g_bAutobuildDebug;
#endif

#define MK_U32(B0, B1, B2, B3) ((((U32)(B3))<<24) |(((U32)(B2))<<16)|(((U32)(B1))<<8)|((U32)(B0)))
//------------------------------------------------------------------------------
//                               Debug
//------------------------------------------------------------------------------
#define INIT_DBINFO(x)  //x
#define PWR_DBG(y)      //y
#define BREAK_DEBUG(deay_ms)    {\
                                    U32 u32TimeBefore;\
                                    u32TimeBefore = msAPI_Timer_GetTime0();\
                                    printf("%d\n",u32TimeBefore);\
                                    while(1)\
                                    {\
                                        if ((msAPI_Timer_GetTime0() - u32TimeBefore > deay_ms))\
                                            break;\
                                        msAPI_Timer_ResetWDT();\
                                    }\
                                }

/********************************************************************************/
/*                                Static                                        */
/********************************************************************************/
extern U32 u32ProtectOffTimer;
#if (ENABLE_DTV)
extern U16             u16ReminderSrv;
extern U8               u8ReminderPcn;
#if ENABLE_EPGTIMER_RECORDER_TURNOFFPANEL
extern BOOLEAN     g_bTimerTypeRecord;
#endif
#endif
#if(ENABLE_POWERON_VIDEO)
extern void msAPI_Pan_Task(void);
#endif
U8  u8Switch2Scart;
U8  u8IsAutoSleep_Skip_Logo;
U32 gSystemStartTimeForRemider;
U32 gSystemStartTimeForRecorder;
S32 volatile gS32OffsetTime;
#if(ENABLE_DTV)
BOOLEAN bDemodPowerOnInit = FALSE;
static void _MApp_DTVInit(void);
#endif
extern BOOLEAN MApp_UiMenuFunc_CheckInputLock(void);
extern BOOLEAN MApp_UiMenuFunc_CheckInputLockAudioVideo(void);
extern void MApp_MuteAvByLock(U8 u8ScreenMute, BOOLEAN bMuteEnable);

#if CUS_SMC_ENABLE_HOTEL_MODE
#include <MApp_RestoreToDefault.h>
#include <MApp_XC_PQ.h>
#include <MApp_GlobalSettingSt_Common.h>
#include <MApp_GlobalSettingSt.h>
//#include <MApp_ZUI_ACTfactorymenu.h>
extern void _MApp_HotelMode_Load_InputSourceChange(void);
#endif

/********************************************************************************/
/*                               Functions                                      */
/********************************************************************************/
void MApp_Init_CustomerInfo(void)
{
    unsigned char * pu8Temp;
    U8 i,u8Data;
    U8 u8ASCII_Mapping[16] = {'0','1','2','3','4','5','6','7','8','9','A',
        'B','C','D','E','F'};

#if (DEBUG_CUSTOMER_INFO_ENABLE)
        printf("****** Customer_info:Before ******");
        for (i=0;i<48;i++)
        {
            if (i%8 ==0)
                printf("\n");
            printf("0x%bx,",Customer_info[i]);

        }

        printf("\n abcdef => 0x%bx,0x%bx,0x%bx,0x%bx,0x%bx,0x%bx,",'a','b','c','d','e','f');
        printf("\n ABCDEF => 0x%bx,0x%bx,0x%bx,0x%bx,0x%bx,0x%bx,",'A','B','C','D','E','F');
        printf("\n\n");
#endif

    pu8Temp = &CID_Buf[6];//(Byte6,7: Customer ID)(Byte8,9: Model ID)(Byte1011: Chip ID)

    //<1>.To Prepare the Customer-ID + Model-ID + Chip-ID
          for (i=0;i<3;i++)
          { //Get hight byte
            u8Data = ((*(pu8Temp+1))>> 4);
            Customer_info[0+i*4] = u8ASCII_Mapping[u8Data];
            u8Data = (*(pu8Temp+1) & 0x0F);
            Customer_info[1+i*4] =  u8ASCII_Mapping[u8Data];
            //Get Low byte
            u8Data = ((*(pu8Temp))>>4) ;
            Customer_info[2+i*4] = u8ASCII_Mapping[u8Data];
            u8Data = (*(pu8Temp) & 0x0F);
            Customer_info[3+i*4] = u8ASCII_Mapping[u8Data];
            pu8Temp +=2;
          }
          for (i=0;i<4;i++)
            Customer_info[12+i] = 0x30;

    //<2>.To prepare the Customer IP
          pu8Temp = &IP_Cntrol_Mapping_1[0];
          memcpy(&Customer_info[16], pu8Temp, 8);
          pu8Temp = &IP_Cntrol_Mapping_2[0];
          memcpy(&Customer_info[16+8], pu8Temp, 8);
          pu8Temp = &IP_Cntrol_Mapping_3[0];
          memcpy(&Customer_info[16+16], pu8Temp, 8);
          pu8Temp = &IP_Cntrol_Mapping_4[0];
          memcpy(&Customer_info[16+24], pu8Temp, 8);

#if (DEBUG_CUSTOMER_INFO_ENABLE)
        printf("****** Customer_info ******");
        for (i=0;i<48;i++)
        {
            if (i%8 ==0)
                printf("\n");
            printf("0x%bx,",Customer_info[i]);

        }
#endif
        Customer_info[48] = 0;  //Important, string end symbol
}

void MApp_Preparation(void)
{
    MApp_Key_Initial_Status();
}

static void MApp_Init_UIVariable(void)
{
    EN_OSD_COUNTRY_SETTING eCountry;

    CAL_TIME_FUNC_START();

  #if (ENABLE_DTV)
    #if ENABLE_SBTVD_BRAZIL_APP
     eCountry = (EN_OSD_COUNTRY_SETTING)E_BRAZIL,                       ///< Brazil
   #else
    eCountry = (EN_OSD_COUNTRY_SETTING)msAPI_CM_GetCountry();
   #endif
  #else
    #if (ENABLE_DTMB_CHINA_APP || ENABLE_ATV_CHINA_APP || ENABLE_DVBC_PLUS_DTMB_CHINA_APP)
    eCountry = OSD_COUNTRY_CHINA;
    #else
    eCountry = OSD_COUNTRY_UK;
    #endif
  #endif

    MApp_SetOSDCountrySetting(eCountry, FALSE);

  #if EAR_PHONE_POLLING
    PreEarphoneState = EAR_PHONE_NULL;
  #endif
    u32InfoOSD_Duration = 5000L;

    u32MonitorOsdTimer = 0;

    bNextEvent = FALSE;

    g_u16PasswordCheckSource = 0xffff;
  #if (MHEG5_ENABLE)
    enCheckMHEGLoadingStatus = EN_MHEG5_MONITOR;
  #endif

    g_bGotoCUSMenu = 0;       //add hdx 20120605
 	g_bSscEnable = FALSE;
	g_bFactoryResetMode=TRUE;//CUS_XM gary 20120616 modify by factory reset
	g_bFactoryLanguageBack=LANGUAGE_ENGLISH;//CUS_XM gary 20120616 modify by factory language

   #if ENABLE_CUS_UPDATE_SCAN
    g_bGotoUpdateScan = FALSE;
   #endif

   #if ENABLE_CUS_KEY_DASH
    g_bPressDashKey = FALSE;
    u8MaxDigiKeyNum = 3;
   #endif
    g_bCancelAutoscanByUser = FALSE;
    g_u8PreditFocusATVProgramNumber = msAPI_ATV_GetCurrentProgramNumber();
    #if ENABLE_CUS_RS232_FUNC
    g_u8USBPortAttachmentFlag = 0x00;
    #endif
    #if ENABLE_CUS_BURNING_MODE
    g_bIsOpenTestPattern = FALSE;
    g_bDisableBurninMode = FALSE;
    #endif
    #if 0//TV_FREQ_SHIFT_CLOCK
    g_bChangeChannelAtTVsource = FALSE;
    #endif

    enIndicateTimerSource = TS_TYPE_NONE;
    memset(&stLMGenSetting.stMB, 0, sizeof(L_MENU_VIDEO_B_VAR));
    memset(&stLMGenSetting.stMFactory_Adjust, 0, sizeof(L_MENU_FACTORY_ADJUST_VAR));

    CAL_TIME_FUNC_("UIVar");

  #if ENABLE_DTV
    SET_OSD_MENU_LANGUAGE(GET_OSD_MENU_LANGUAGE());
  #if (OBA2)
    MApp_ZUI_ACT_SetEnvLanguage(GET_OSD_MENU_LANGUAGE());
  #endif
  #endif
  	if(stGenSetting.g_SysSetting.bPanelVcom==0)
			stGenSetting.g_SysSetting.bPanelVcom=DEF_VCOM_VALUE;
	#if PANEL_TYPE==_1024x600_
	msAPI_Ajust_Vcom_value();
	#endif
    //SET_VCOM_VAULE(220);
    CAL_TIME_FUNC_("UIVar");

    CAL_TIME_FUNC_END();
}
extern U32 volatile gSystemTimeCount;

static void MApp_Init_TimeSetting(void)
{
    ST_TIME _stTime;
    U32 u32PMSystemTime = 0;

    if(bfirstACBoot == TRUE)//--------------AC Power On
    {
        u32PMSystemTime = msAPI_Timer_GetSystemTime();
        stGenSetting.g_Time.NVRAM_g_u8TimeInfo_Flag = 0;
	gFactoryTotaltimeback1=stGenSetting.g_FactorySetting.gFactoryTotaltime;
	gFactoryTotaltime=gFactoryTotaltimeback1;
    }
    else//----------------------------------DC Power On
    {
        u32PMSystemTime = msAPI_Timer_GetRTCSystemTime(); //restore system time from RTC
        g_u8TimeInfo_Flag = stGenSetting.g_Time.NVRAM_g_u8TimeInfo_Flag;
		//gary add for ac on time

	 	gFactoryTotaltimeback=stGenSetting.g_FactorySetting.gFactoryTotaltimeback;
		gFactoryTotaltimeback1=stGenSetting.g_FactorySetting.gFactoryTotaltime;
		gFactoryTotaltime=gFactoryTotaltimeback1+(u32PMSystemTime -gFactoryTotaltimeback)/1000;
		//printf("gFactoryTotaltimeback===%d\n",gFactoryTotaltimeback);
		//printf("u32PMSystemTime===%d\n",u32PMSystemTime);
		//printf("gFactoryTotaltime===%d\n",gFactoryTotaltime);
    }

    gFactoryBLTBackLITtime = stGenSetting.g_FactorySetting.gFactoryBackLITtimeback;

    msAPI_Timer_Load_OffsetTime(); // must after EEPROM or FLASH init

    gSystemTimeCount=u32PMSystemTime;
    gSystemTimeCount_TCON = 0;

    /* init offset time */
    stLMGenSetting.stMD.enD4_SleepTimer = STATE_SLEEP_TOTAL;

#if ENABLE_CUS_AUTO_SLEEP_MODE
    MApp_NoSignal_SetAutoSleep(TRUE);
    if( stGenSetting.g_Time.cAutoSleepFlag != EN_Time_AutoOff_Off)
    {
        MApp_Sleep_SetAutoOn_OffTime(ENABLE);
    }
    else
    {
        MApp_Sleep_SetAutoOn_OffTime(DISABLE);
    }
#else
    MApp_NoSignal_SetAutoSleep((BOOLEAN)stGenSetting.g_Time.cAutoSleepFlag);
#endif
    MApp_Sleep_ReleaseSleepTimer();
    #if ENABLE_POWER_SAVING_DPMS
    u8VGANoSignalSleepCheck = UNKNOW;
    #endif

    u32ProtectOffTimer = 0;

    MApp_SetOnTimer((MENU_OnTimer)stGenSetting.g_Time.cOnTimerFlag);

    if(stGenSetting.g_Time.cOnTimerFlag != EN_Time_OnTimer_Off)
    {
        MApp_ConvertSeconds2StTime(MApp_GetLocalSystemTime(),&_stTime);
        _stTime.u8Hour = (U8)stGenSetting.g_Time.u16OnTimer_Info_Hour;
        _stTime.u8Min = (U8)stGenSetting.g_Time.u16OnTimer_Info_Min;
        _stTime.u8Sec = (U8)stGenSetting.g_Time.u16OnTimer_Info_Sec;
        //MApp_SetLocalWakeUpTime(MApp_ConvertStTime2Seconds(&_stTime));
    }
    //once mode on need reset flag
    if(stGenSetting.g_Time.cOffTimerFlag == EN_Time_OffTimer_Once)
    {
        stGenSetting.g_Time.cOffTimerFlag = EN_Time_OffTimer_Off;
    }

    MApp_Sleep_SetOffTime(TRUE); //set timer

    stGenSetting.g_Time.wTimeDataCS = MApp_CalCheckSum((BYTE *)&(stGenSetting.g_Time), SIZE_TIME_DATA );
}

static void MApp_Init_PrintDataBaseMsg(void)
{
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    INIT_DBINFO(printf("DRAM_GEN_DB_START = 0x%08lX\n", DRAM_GEN_DB_START(((DATABASE_START_MEMORY_TYPE & MIU1) ? (DATABASE_START_ADR | MIU_INTERVAL) : (DATABASE_START_ADR)))));
    INIT_DBINFO(printf("DRAM_64K_DB_START = 0x%08lX\n", DRAM_64K_DB_START(((DATABASE_START_MEMORY_TYPE & MIU1) ? (DATABASE_START_ADR | MIU_INTERVAL) : (DATABASE_START_ADR)))));

    /* database usage status */
    INIT_DBINFO(printf("General Usage :    start   size\n"));
    INIT_DBINFO(printf("BOOTLOADER         0x%04X  0x%04X\n", (U16)RM_BOOTLOADER_ADDR, (U16)RM_SIZE_BOOTLOADER));
    INIT_DBINFO(printf("HDCP_KEY           0x%04X  0x%04X\n", (U16)RM_HDCP_KEY_ADDR, (U16)RM_SIZE_HDCP_KEY));

  #if ( ENABLE_DVB_TAIWAN_APP || ENABLE_SBTVD_BRAZIL_APP || (TV_SYSTEM == TV_NTSC) )
    INIT_DBINFO(printf("CATV_LAST_START    0x%04X  0x%04X\n", (U16)RM_CATV_LAST_START_ADR, (U16)RM_SIZE_CATV_LAST_DATA));
  #endif
    INIT_DBINFO(printf("ATV_LAST_START     0x%04X  0x%04X\n", (U16)RM_ATV_LAST_START_ADR, (U16)RM_SIZE_ATV_LAST_DATA));

    INIT_DBINFO(printf("GEN_SETTING        0x%04X  0x%04X\n", (U16)RM_GENSET_START_ADR, (U16)RM_SIZE_GENSET));

    INIT_DBINFO(printf("RM_GEN_USAGE               0x%04X\n", (U16)RM_GEN_USAGE));


    INIT_DBINFO(printf("ADC_SETTING        0x%04X  0x%04X\n", (U16)RM_ADC_SETTING_ADDRESS(0), (U16)RM_ADC_SETTING_SIZE));

    INIT_DBINFO(printf("ADC_SETTING        0x%04X  0x%04X\n", (U16)RM_VIDEO_DATA_ADDRESS(0), (U16)RM_VIDEO_DATA_SIZE));

    INIT_DBINFO(printf("WB_DATA            0x%04X  0x%04X\n", (U16)RM_WHITEBALANCE_DATA_ADDRESS(0), (U16)RM_WHITEBALANCE_DATA_SIZE));

    INIT_DBINFO(printf("SUBCOLOR_DATA      0x%04X  0x%04X\n", (U16)RM_SUBCOLOR_DATA_ADDRESS(0), (U16)RM_SUBCOLOR_DATA_SIZE));

#if (ENABLE_DTV_EPG)
    INIT_DBINFO(printf("TIMER_MANUAL_EVENT 0x%04X  0x%04X\n", (U16)RM_TIMER_MANUAL_EVENT_START_ADR, (U16)RM_SIZE_MANUAL_TIMER_EVENT));
    INIT_DBINFO(printf("TIMER_CHECKSUM     0x%04X  0x%04X\n", (U16)RM_TIMER_CHECKSUM_START_ADR, (U16)RM_SIZE_TIMER_CHECKSUM));
#endif
    INIT_DBINFO(printf("TV_COMMON_DATA     0x%04X  0x%04X\n", (U16)RM_TV_COMMON_DATA_START_ADR, (U16)RM_SIZE_TV_COMMON_DATA));

    INIT_DBINFO(printf("ATV_CHSET          0x%04X  0x%04X\n", (U16)RM_ATV_CHSET_START_ADDR, (U16)RM_ATV_CHSET_SIZE));

    INIT_DBINFO(printf("OVERSCAN_DATA      0x%04X  0x%04X\n", (U16)RM_OVERSCAN_DATA_START_ADR, (U16)RM_SIZE_OVERSCAN_DATA));
    INIT_DBINFO(printf("MODE_SETTING       0x%04X  0x%04X\n", (U16)RM_MODE_SETTING_START_ADR, (U16)RM_SIZE_MODE_SETTING));

  #if (ENABLE_DTV)
    INIT_DBINFO(printf("DTV_CHSET          0x%04X  0x%04X\n", (U16)RM_DTV_CHSET_START_ADDR, (U16)RM_DTV_CHSET_SIZE));
    INIT_DBINFO(printf("sizeof(DTV_CHANNEL_INFO) = 0x%04X\n", (U16)sizeof(DTV_CHANNEL_INFO)));
  #endif
    INIT_DBINFO(printf("=> RM_64K_USAGE =          0x%04X\n", (U32)RM_64K_USAGE));

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
}

BOOLEAN MApp_Init_CheckOnTimeSetting(void)
{
    ST_TIME _stTime;
    DAYOFWEEK _Today = SUN;

   MApp_ConvertSeconds2StTime(MApp_GetLocalSystemTime(),&_stTime);
   //printf("stGenSetting.g_Time.u16OnTimer_Info_Hour=%d\n",stGenSetting.g_Time.u16OnTimer_Info_Hour);
   //printf("stGenSetting.g_Time.u16OnTimer_Info_Min=%d\n",stGenSetting.g_Time.u16OnTimer_Info_Min);

   //printf("_stTime.u8Hour=%d\n", _stTime.u8Hour);
   //printf("_stTime.u8Min=%d\n", _stTime.u8Min);
   _Today = (DAYOFWEEK)MApp_GetDayOfWeek(_stTime.u16Year, _stTime.u8Month, _stTime.u8Day);
   if( _stTime.u8Hour != (U8)stGenSetting.g_Time.u16OnTimer_Info_Hour ||
        _stTime.u8Min != (U8)stGenSetting.g_Time.u16OnTimer_Info_Min)
        return FALSE;

    switch(stGenSetting.g_Time.cOnTimerFlag)
    {
        default :
        case EN_Time_OnTimer_Off:
        return FALSE;

        case EN_Time_OnTimer_Once:
        case EN_Time_OnTimer_Everyday:
            return TRUE;

        case EN_Time_OnTimer_Mon2Fri:
            switch(_Today)
            {
                case SUN:
                case SAT:
        return FALSE;
                default:
                    return TRUE;
            }
            break;

        case EN_Time_OnTimer_Mon2Sat:
            switch(_Today)
            {
                case SUN:
        return FALSE;
                default:
                    return TRUE;
            }
            break;

        case EN_Time_OnTimer_Sat2Sun:
            switch(_Today)
            {
                case MON:
                case TUE:
                case WED:
                case THU:
                case FRI:
        return FALSE;
                default:
                    return TRUE;
            }
            break;

        case EN_Time_OnTimer_Sun:
            switch(_Today)
            {
                case SUN:
                    return TRUE;
                default:
        return FALSE;
    }
            break;
    }
}

static void MApp_Init_CheckOnTimer(void)
{
#if ENABLE_DTV_EPG //ENABLE_DTV
#if ENABLE_PVR
    EN_EPG_TIMER_ACT_TYPE actType = MApp_EpgTimer_GetTimerActType();

    if( actType == EN_EPGTIMER_ACT_REMINDER ||
        actType == EN_EPGTIMER_ACT_RECORDER_START)
    {
        if(stGenSetting.g_Time.cOnTimerFlag == EN_Time_OnTimer_Once)
        {
            stGenSetting.g_Time.cOnTimerFlag = EN_Time_OnTimer_Off;
        }
        MApp_Sleep_SetAutoOn_OffTime(DISABLE);
        INIT_DBINFO(printf("WakeUpByEPG!!!\n"));
        return;
    }
#endif
#endif
    if(MApp_Init_CheckOnTimeSetting() == TRUE)
    {
      //  printf("xue trace MApp_Init_CheckOnTimeSetting\n ");
        INIT_DBINFO(printf("WakeUpByOnTimer!!!\n"));
        //reset on timer when on timer mode is once
        if(stGenSetting.g_Time.cOnTimerFlag == EN_Time_OnTimer_Once)
        {
            stGenSetting.g_Time.cOnTimerFlag = EN_Time_OnTimer_Off;
            MApp_SetOnTimer((MENU_OnTimer)stGenSetting.g_Time.cOnTimerFlag);
            gWakeupSystemTime = 0xFFFFFFFF;
        }

        // on timer
        switch(stGenSetting.g_Time.cOnTimerSourceFlag)
        {
            case EN_Time_OnTimer_Source_MEMORY:
                printf("---OnTimer Source Last Memory!---\n");
                break;
            case EN_Time_OnTimer_Source_ATV:
                UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_ATV;
                msAPI_CHPROC_CM_SetCurrentOrdinal(E_SERVICETYPE_ATV, stGenSetting.g_Time.cOnTimerChannel, E_PROGACESS_INCLUDE_VISIBLE_ONLY);
                break;
        #if (ENABLE_DTV)
            case EN_Time_OnTimer_Source_DTV:
                UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_DTV;
                msAPI_CHPROC_CM_SetCurrentOrdinal(E_SERVICETYPE_DTV, stGenSetting.g_Time.cOnTimerChannel, E_PROGACESS_INCLUDE_VISIBLE_ONLY);
                break;
            case EN_Time_OnTimer_Source_RADIO:
                UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_DTV;
                msAPI_CHPROC_CM_SetCurrentOrdinal(E_SERVICETYPE_RADIO, stGenSetting.g_Time.cOnTimerChannel, E_PROGACESS_INCLUDE_VISIBLE_ONLY);
                break;

            #if NORDIG_FUNC //for Nordig Spec v2.0
            case EN_Time_OnTimer_Source_DATA:
                UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_DTV;
                msAPI_CHPROC_CM_SetCurrentOrdinal(E_SERVICETYPE_DATA, stGenSetting.g_Time.cOnTimerChannel, E_PROGACESS_INCLUDE_VISIBLE_ONLY);
                break;
            #endif
      #endif
            #if (INPUT_SCART_VIDEO_COUNT >= 1)
            case EN_Time_OnTimer_Source_SCART:
                UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_SCART;
                break;
            #endif

            #if (INPUT_SCART_VIDEO_COUNT >= 2)
            case EN_Time_OnTimer_Source_SCART2:
                UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_SCART2;
                break;
            #endif

            #if (INPUT_YPBPR_VIDEO_COUNT>=1)
            case EN_Time_OnTimer_Source_COMPONENT:
                UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_COMPONENT;
                break;
            #endif

            #if (INPUT_YPBPR_VIDEO_COUNT >= 2)
            case EN_Time_OnTimer_Source_COMPONENT2:
                UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_COMPONENT2;
                break;
            #endif

            case EN_Time_OnTimer_Source_RGB:
                UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_RGB;
                break;

            #if (INPUT_HDMI_VIDEO_COUNT >= 1)
            case EN_Time_OnTimer_Source_HDMI:
                UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_HDMI;
                break;
            #endif

            #if (INPUT_HDMI_VIDEO_COUNT >= 2)
            case EN_Time_OnTimer_Source_HDMI2:
                UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_HDMI2;
                break;
            #endif

            #if (INPUT_HDMI_VIDEO_COUNT >= 3)
            case EN_Time_OnTimer_Source_HDMI3:
                UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_HDMI3;
                break;
            #endif

            #if (INPUT_HDMI_VIDEO_COUNT >= 4)
            case EN_Time_OnTimer_Source_HDMI4:
                UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_HDMI4;
                break;
            #endif

            #if (INPUT_AV_VIDEO_COUNT >= 1)
            case EN_Time_OnTimer_Source_AV:
                UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_AV;
                break;
            #endif

            #if (INPUT_AV_VIDEO_COUNT >= 2)
            case EN_Time_OnTimer_Source_AV2:
                UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_AV2;
                break;
            #endif

            #if (INPUT_AV_VIDEO_COUNT >= 3)
            case EN_Time_OnTimer_Source_AV3:
                UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_AV3;
                break;
            #endif

            #if (INPUT_SV_VIDEO_COUNT >= 1)
            case EN_Time_OnTimer_Source_SVIDEO:
                UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_SVIDEO;
                break;
            #endif

            #if ((INPUT_SCART_USE_SV2 == 0) && (INPUT_SV_VIDEO_COUNT >= 2))
            case EN_Time_OnTimer_Source_SVIDEO2:
                UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_SVIDEO2;
                break;
            #endif

            #if ENABLE_DMP
            #if( ENABLE_DMP_SWITCH )
            case EN_Time_OnTimer_Source_MPLAYER1:
                UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_DMP1;
                break;
#if ENABLE_USB2_SOURCE	
            case EN_Time_OnTimer_Source_MPLAYER2:
                UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_DMP2;
                break;
#endif
            #else
            case EN_Time_OnTimer_Source_MPLAYER:
                UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_DMP;
                break;
            #endif
            #endif

            default:
                break;
        }

    #if !ENABLE_CUS_UI_SPEC
        stGenSetting.g_SoundSetting.Volume = stGenSetting.g_Time.cOnTimerVolume;
        MApp_SaveSoundSetting();
    #endif
        MApp_SaveSysSetting();

        if( stGenSetting.g_Time.cAutoSleepFlag != EN_Time_AutoOff_Off)
        {
            MApp_Sleep_SetAutoOn_OffTime(ENABLE);
        }
        else
        {
            MApp_Sleep_SetAutoOn_OffTime(DISABLE);
        }
    }
  #if (ENABLE_DTV)
    else if(msAPI_Power_IswakeupsourceRTC())
    {
        if(MApp_EpgTimer_CheckOnTimeReminder())
        {
        MEMBER_SERVICETYPE srvType = E_SERVICETYPE_INVALID;
        U16 srvPos = INVALID_SERVICE_ID;
        UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_DTV;
        msAPI_CM_GetServiceTypeAndPositionWithPCN(u8ReminderPcn, u16ReminderSrv, &srvType, &srvPos);
        msAPI_CM_SetCurrentServiceType(srvType);
        msAPI_CM_SetCurrentPosition(srvType, srvPos);
     }
    }
  #endif
}

#if ENABLE_CI
static void MApp_Init_CI(void)
{
    msAPI_CI_SetPMTBufAddr(_PA2VA((CI_PMT_BUFFER_MEMORY_TYPE & MIU1) ? (CI_PMT_BUFFER_ADR | MIU_INTERVAL) : (CI_PMT_BUFFER_ADR)));
    msAPI_CI_SetMMIBufAddr(_PA2VA((MMI_TEXTSTRING_MEMORY_TYPE & MIU1) ? (MMI_TEXTSTRING_ADR | MIU_INTERVAL) : (MMI_TEXTSTRING_ADR)));
#if (ENABLE_CI_PLUS)
    msAPI_CI_Initial( TRUE );   // TRUE: CI+ Supported
#else
    msAPI_CI_Initial( FALSE );  // FALSE: CI VI Only
#endif
    msAPI_CI_InstallCallback_CI_Event(MApp_CI_Event_Cb);
#if (ENABLE_CI_PLUS)
    /* Set up CI+ Credentials Setting.
       If using default CI+ Test Keys, please keep marking line.
       If using outside (from Flash) CI+ Production Keys, please unmark this line.
    */
    //msAPI_CI_CC_SetCredentialsType(TRUE, TRUE);
    /*
    if customer use it's own credentiel ci+ key,may open this fucntion,otherwise make this fucntion
    */
   // msAPI_CI_CC_SetDescryptKeyForEncryptedCredentials( gu8aAesXcbcKey, gu8aAesCbcKey, gu8aAesCbcIV );
#endif
    /* For CI/CI+ Debuging. */
    //msAPI_CI_SetDebugLevel(EN_CI_FUNCTION_DEFAULT, 1);
    //msAPI_CI_SetDebugLevel(EN_CI_FUNCTION_CC, 1);
}
#endif

extern void UART_Clear(void);

#if ENABLE_SW_CEC_WAKEUP
#define PM_WKUPST_ADDR0      0x104E //store the wakeup flag0
#define PM_WKUPST_ADDR1      0x104F //store the wakeup flag1
#define PM_CECPORT_ADDR1     0x1052 //store the CEC port

U8 MDrv_PM_WKP_CECPort(void)
{
    U8 Cec_Port;
    U16 u16PmAddr = PM_CECPORT_ADDR1;

    Cec_Port = MDrv_PM_RegRead(u16PmAddr);
    if(0x10 == Cec_Port)
    {
        Cec_Port = 1;
    }
    else
    if(0x20 == Cec_Port)
    {
        Cec_Port = 2;
    }
    else
    if(0x30 == Cec_Port)
    {
        Cec_Port = 3;
    }
    else
    {
        Cec_Port = 0;
    }
    //printf("Cec_Port = %bx, addr = %lu \n",Cec_Port,u16PmAddr);

    return Cec_Port;
}

void MApp_PMGetCECWakeUpPort(void)
{
    U8 u8HdmiCEC_Port, u8PowerOnMode=0;

    /*if(!stGenSetting.g_SysSetting.g_enHDMICEC)
    {
        return;
    }*/

    INIT_DBINFO(printf("u8PowerOnMode = %bu\n", u8PowerOnMode);)
    if(u8PowerOnMode == M_POWER_ON_BY_HDMI_CEC)
    {
        u8HdmiCEC_Port = MDrv_PM_WKP_CECPort();
        if(u8HdmiCEC_Port > 3 || u8HdmiCEC_Port < 1)
        {
            INIT_DBINFO(printf("u8HdmiCEC_Port = %bu, out of range\n", u8HdmiCEC_Port);)
            return;
        }

        INIT_DBINFO(printf("PM CEC Get WakeUp Port:%bu\n", u8HdmiCEC_Port);)
        UI_INPUT_SOURCE_TYPE = (E_UI_INPUT_SOURCE)(UI_INPUT_SOURCE_HDMI + (U8)(u8HdmiCEC_Port - 1));
#if (INPUT_HDMI_VIDEO_COUNT >= 3)
        if(UI_INPUT_SOURCE_TYPE > UI_INPUT_SOURCE_HDMI3)
            UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_ATV;
#endif
    }
}
#endif


#ifdef MSOS_TYPE_LINUX //OBA2

#include "drvMMIO.h"
#include <unistd.h>

U32 MApp_SystemGetTypeMem_adr(U8 type)
{
    unsigned long start_address,length,aligned,miu;
    MAdp_SYS_GetMemoryInfoByEnum(type, &start_address, &length, &aligned,&miu);
    return (U32)start_address;
}

U32 MApp_SystemGetTypeMem_length(U8 type)
{
    unsigned long start_address,length,aligned,miu;
    MAdp_SYS_GetMemoryInfoByEnum(type, &start_address, &length, &aligned,&miu);

    return (U32)length;
}

U32 MApp_SystemGetTypeMem_aligned(U8 type)
{
    unsigned long start_address,length,aligned,miu;
    MAdp_SYS_GetMemoryInfoByEnum(type, &start_address, &length, &aligned,&miu);

    return aligned;
}


U32 MApp_SystemGetTypeMem_miu(U8 type)
{
    unsigned long start_address,length,aligned,miu;
    MAdp_SYS_GetMemoryInfoByEnum(type, &start_address, &length, &aligned,&miu);
    return miu;
}

#endif

void MApp_setupMemory(void)
{
    // Initialize XC DNR Address
  #ifdef SCALER_DNR_BUF_UC_ADR
    if (( IsSrcTypeVga(stSystemInfo[MAIN_WINDOW].enInputSourceType) )||( IsSrcTypeHDMI(stSystemInfo[MAIN_WINDOW].enInputSourceType) ) || ( IsSrcTypeYPbPr(stSystemInfo[MAIN_WINDOW].enInputSourceType)))
    {
        MApi_XC_SetFrameBufferAddress(((SCALER_DNR_BUF_MEMORY_TYPE & MIU1) ? (SCALER_DNR_BUF_UC_ADR | MIU_INTERVAL) : (SCALER_DNR_BUF_UC_ADR)), SCALER_DNR_BUF_UC_LEN, MAIN_WINDOW);
    }
    else
  #endif
    {
        MApi_XC_SetFrameBufferAddress(((SCALER_DNR_BUF_MEMORY_TYPE & MIU1) ? (SCALER_DNR_BUF_ADR | MIU_INTERVAL) : (SCALER_DNR_BUF_ADR)), SCALER_DNR_BUF_LEN, MAIN_WINDOW);
    }
}

#if ENABLE_SHOW_PHASE_FACTORY
void MApp_ReadDDRPhase(void)
 {
      //read miu0 DQS0 and DQS1 for factory show
      g_u16Miu0_Dqs0 = MDrv_Read2Byte(0x103390);
      g_u16Miu0_Dqs1 =MDrv_Read2Byte(0x103392);
      MS_DEBUG_MSG(printf("g_u16Miu0_Dqs0~~~~~________-0x=%x\n",g_u16Miu0_Dqs0));
      MS_DEBUG_MSG(printf("g_u16Miu0_Dqs1~~~~~_________0x=%x\n",g_u16Miu0_Dqs1));
  #if(ENABLE_MIU_1)
      //read miu1 DQS0 and DQS1 for factory show
      g_u16Miu1_Dqs0 = MDrv_Read2Byte(0x10051C);
      g_u16Miu1_Dqs1 =MDrv_Read2Byte(0x10051E);
      MS_DEBUG_MSG(printf("g_u16Miu1_Dqs0~~~~~=%bx\n",g_u16Miu1_Dqs0));
      MS_DEBUG_MSG(printf("g_u16Miu1_Dqs1~~~~~=%bx\n",g_u16Miu1_Dqs0));
   #endif
  }
#endif
#if ENABLE_SMC_USB_AUTO_UPDATE

#include "mw_usbdownload.h"
#include "MApp_USBDownload.h"
#include "drvISR.h"

void MApp_UsbDownload_Process(void)
{
    extern void msAPI_BLoader_Reboot(void);
    extern U8 MDrv_USBGetPortEnableStatus(void);
    extern void MApp_ZUI_SwUpdate_ProgressBar(U8 percent);
	extern BOOLEAN bLedFlickering ;
    //extern void msAPI_BLoader_Reboot(void);
    U8 u8PortEnStatus = 0;
    
    printf("\n");
    printf("********************************\n");
    printf("\n");
    printf("SMC Update Software!\n");
    printf("\n");
    printf("********************************\n");
    printf("\n");
    u8PortEnStatus = MDrv_USBGetPortEnableStatus();
	{
	    U8 i = 0;
	    BOOLEAN blnIsConnect = MDrv_UsbDeviceConnect();
	    for(i = 0; i < 10; i++)
	    {
	        //printf("[%d]blnIsConnect = %d\n", i, blnIsConnect);
	        if (blnIsConnect)
	        {
	            break;
	        }
	        else
	        {
	            msAPI_Timer_Delayms(80);
	            blnIsConnect = MDrv_UsbDeviceConnect();
	        }
	    }
	    if (!blnIsConnect)
	    {
	        return;
	    }
    }

       #if 1//(USB_DOWNLOAD_PORT==USB1_PORT)
        if((u8PortEnStatus & BIT0) == BIT0)
        {
            MApp_UsbDownload_Init(BIT0, MApp_ZUI_SwUpdate_ProgressBar);
        }
       #else
        if((u8PortEnStatus & BIT1) == BIT1)
        {
            MApp_UsbDownload_Init(BIT1, MApp_ZUI_SwUpdate_ProgressBar);
        }
       #endif
        else
        {
            printf("Error> Unknown USB port\n");
            return;
        }
            if(MW_UsbDownload_Search())
            {
                 bLedFlickering = 1;
  			   // MApp_Power_SetPowerMode();
				MDrv_Write2Byte(PM_SLEEP_POWERON_FLAG, MAKEWORD(POWERON_FLAG2, POWERON_FLAG1));
               if (MW_UsbDownload_Start())
               {
                  bLedFlickering = 0;
               }
            }
}
#endif

void MApp_image_mirror(U8 b_mirror)
{
    //printf("\r\n Mirror function (%d)\n", b_mirror);

    if ( !IsSrcTypeStorage(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)) )
    {
        // Video
        MApi_XC_EnableMirrorMode(b_mirror);

        // GOP
        MApi_GOP_GWIN_SetHMirror(b_mirror);
        MApi_GOP_GWIN_SetVMirror(b_mirror);
    }
#if (DISPLAY_LOGO == DISABLE)
    /* If system enable DISABLE_LOGO, MApp_Scaler_SetWindow will be involved when logo shown. */
    MApp_Scaler_SetWindow(NULL, NULL, NULL, stSystemInfo[MAIN_WINDOW].enAspectRatio, SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW), MAIN_WINDOW);
#endif
}

#if (CHIP_FAMILY_TYPE==CHIP_FAMILY_M10)
extern void MDrv_BW_LoadDefaultTable(void);
#endif

BOOL g_bPreInit_SkipChangeAudioSrc = FALSE;
extern void MApp_UartPort_Conect(void);

void MApp_PreInit(void)
{

  #if ((ENABLE_DMP) && (ENABLE_POWERON_MUSIC))
    BOOL bEnablePowerOnMusic = FALSE;
  #endif
#if( DISPLAY_LOGO )
    BOOL bEnablePowerOnLogo = TRUE;
#endif

#if(ENABLE_DTV)
    bDemodPowerOnInit = FALSE;
#endif

    BOOL bAlreadyCall_MApi_PNL_En = FALSE;
    BOOL bAlreadyCall_SetBacklight = FALSE;

	g_bInitFinished = FALSE;


    CAL_TIME_FUNC_START();

    g_bPreInit_SkipChangeAudioSrc = FALSE;

    printf("====> Time: %s\n", __TIME__);


   
    //init OCP var  20091124EL
    _bOCPFromMem = FALSE;
	
#if(ENABLE_MULTI_PANELS==1)//fanjian0822
	bMulti_panel=FALSE; 
	bMulti_panel_count=0;
#endif

#if (ENABLE_BOOTTIME)
    gU32BootTotalStepTime = msAPI_Timer_GetTime0();
#endif

#if (ENABLE_6M30_3D_PROCESS)  //
    MDrv_Ursa_USB_Update_SetChipType(SWUpdateForHK);
  #if ENABLE_6M30_OSD_PROTECT
    MDrv_Ursa_6M30_InitOSDWin();
  #endif
#endif
    bfirstACBoot = FALSE;
    stSystemInfo[MAIN_WINDOW].enInputSourceType = INPUT_SOURCE_NONE;

#if ENABLE_3D_PROCESS
    g_HdmiInput3DFormat = E_XC_3D_INPUT_MODE_NONE;
    g_HdmiInput3DFormatStatus = E_XC_3D_INPUT_MODE_NONE;
#endif

  #if (ENABLE_PIP)
    if(IsPIPSupported())
    {
        stSystemInfo[SUB_WINDOW].enInputSourceType = INPUT_SOURCE_NONE;
    }
  #endif

    #if BOE_FACTORY_CHANNEL
    stGenSetting.g_SysSetting.uFactoryChannelFlag2=TRUE;
    #endif
     
	#if BOE_ACPOERON_BURINGMODE
      stGenSetting.g_FactorySetting.fBuringMode = ENABLE;
	#endif
   //stGenSetting.g_SysSetting.gId693Cnt=0;
   stGenSetting.g_SysSetting.gId693FailCnt=0;
    msAPI_PowerSetting_Init();

    msAPI_MIU_GetMiuSpeed();

    /* initialize all device drivers */
    msAPI_ChipInit(); // 0 ms
    MApp_Init_FlashVariable();

    /* To set Vendor ID to the Mailbox register */
    MApp_Init_CustomerInfo(); // 0 ms

    // MDrv_Sys_Set_CIDInfo(&CID_Buf[6]); // 0 ms

    MApi_PNL_SetInverter(DISABLE); // 0 ms

    /*
     *   Init Scaler, LVDS...etc, "Call It FIRST!" before using any (panel)
     *   PNL related function,
    */

  #if (ENABLE_BOOTTIME)
    gU32BootStepTime = msAPI_Timer_GetTime0();
  #endif

  #if ENABLE_SHOW_PHASE_FACTORY
    MApp_ReadDDRPhase();
  #endif

    msAPI_DrvInitStep1();


  #if (ENABLE_BOOTTIME)
    gU32TmpTime = msAPI_Timer_DiffTimeFromNow(gU32BootStepTime);
    printf("[boot step time]msAPI_DrvInitStep1 = %ld\n", gU32TmpTime);
  #endif

    // work around code, currently if the VBI address (From start to end) is beyond 0xFFFF, there'll be problem
    // Temp solution, makes VBI start to end is in same U16 area (0 ~ 0xFFFF)
    msAPI_Interrupt_Init(); // 0 ms

  #if (ENABLE_BOOTTIME)
    gU32BootStepTime = msAPI_Timer_GetTime0();
  #endif

  #if (VECTOR_FONT_ENABLE) && (COPRO_MVF_ENABLE)
    msAPI_COPRO_Init(BIN_ID_CODE_AEON_MVF,((AEON_MEM_MEMORY_TYPE & MIU1) ? (AEON_MEM_ADR | MIU_INTERVAL) : (AEON_MEM_ADR)),AEON_MEM_LEN);
  #endif

    MApp_LoadFontInit();


  #if (ENABLE_BOOTTIME)
    gU32TmpTime = msAPI_Timer_DiffTimeFromNow(gU32BootStepTime);
    printf("[boot step time]MApp_LoadFontInit = %ld\n", gU32TmpTime);
  #endif

  #if (ENABLE_BOOTTIME)
    gU32BootStepTime = msAPI_Timer_GetTime0();
  #endif


#if !ENABLE_MULTI_PANELS
    msAPI_DrvInitStep2();
    CAL_TIME_FUNC_("PreInit");
#endif


    USBPowerOn();


  #if (ENABLE_BOOTTIME)
    gU32TmpTime = msAPI_Timer_DiffTimeFromNow(gU32BootStepTime);
    printf("[boot step time]msAPI_DrvInitStep2 = %ld\n", gU32TmpTime);
  #endif

    Tcon_Printf(3);
    MDrv_SYS_Init();
    //MApi_Mod_Calibration_Setting(0, 0);//test ...it must be called before g_IPanel.Enable


    //Disable Output CLK
#if !ENABLE_MULTI_PANELS
    MApi_PNL_En(ENABLE); // 0 ms
    bAlreadyCall_MApi_PNL_En = TRUE;
#endif

    Tcon_Printf(4);

    //Set GOP Stop to wait VSync
    MApi_GOP_GWIN_SetForceWrite(ENABLE); // 0 ms
   
    //MUTE_On(); // 0 ms 
    msAPI_PowerON_EXEC(); // 0 ms

  #if (ENABLE_BOOTTIME)
    gU32BootStepTime = msAPI_Timer_GetTime0();
  #endif

#if (GENSETTING_STORE_USE_NEW_METHOD)
    msAPI_Flash_WriteProtect_SetBPStatus();
#else
    msAPI_Flash_WriteProtect(ENABLE);
#endif

  #if (ENABLE_BOOTTIME)
    gU32TmpTime = msAPI_Timer_DiffTimeFromNow(gU32BootStepTime);
    printf("[boot step time]msAPI_Flash_WriteProtect = %ld\n", gU32TmpTime);
  #endif

  #if ((BRAZIL_CC )|| (ATSC_CC == ATV_CC))
    MApp_LoadFont_CC_Init();
  #endif

  #if ENABLE_DCC
    msAPI_DCC_EnableDCC();
  #endif

  #if ENABLE_DDCCI
    msAPI_DDC2BI_Init(); // 0 ms
  #endif


    /* initialize 8K bytes memory pool */
    msAPI_Memory_Init(); // 0 ms

    /*initialize the OCP address then prepare the bitmap binary*/
    msAPI_OCP_Init(); // 0 ms

  #if (ENABLE_BOOTTIME)
    gU32BootStepTime = msAPI_Timer_GetTime0();
  #endif

  #if ENABLE_SZ_FACTORY_OVER_SCAN_FUNCTION
    g_OverScan.osOffsetX      = 0;
    g_OverScan.osOffsetY      = 0;
    g_OverScan.osOffsetWidth  = 0;
    g_OverScan.osOffsetHeight = 0;
  #endif

    msAPI_OCP_PrepareBitmapBinary();


  #if (ENABLE_BOOTTIME)
    gU32TmpTime = msAPI_Timer_DiffTimeFromNow(gU32BootStepTime);
    printf("[boot step time]msAPI_OCP_PrepareBitmapBinary = %ld\n", gU32TmpTime);
  #endif

  #if (ENABLE_BOOTTIME)
    gU32BootStepTime = msAPI_Timer_GetTime0();
  #endif

  #if (ENABLE_BOOTTIME)
    gU32BootStepTime = msAPI_Timer_GetTime0();
  #endif

    msAPI_OCP_LoadBitmap(Osdcp_bmpHandle);

  #if (ENABLE_BOOTTIME)
    gU32TmpTime = msAPI_Timer_DiffTimeFromNow(gU32BootStepTime);
    printf("[boot step time]msAPI_OCP_LoadBitmap = %ld\n", gU32TmpTime);
  #endif
#if (ENABLE_JPEGPNG_OSD)
        msAPI_OCP_JpegPngSetOutBufInfo(TRUE);
        msAPI_OCP_JpegPng_StLoadInit(&Osdcp_JpegPngHandle[0], MAX_STATICLOAD_JPEGPNG, BIN_ID_OSDCP_JPEG, JPP_LOADST_MAX, CAPE_BUFFER_ADR, CAPE_BUFFER_LEN);
        msAPI_OCP_JpegPng_StLoad(JPP_JPGFLG);
#endif

    msAPI_OCP_PrepareStringBinary();

  #if (ENABLE_BOOTTIME)
    gU32TmpTime = msAPI_Timer_DiffTimeFromNow(gU32BootStepTime);
    printf("[boot step time]msAPI_OCP_PrepareStringBinary = %ld\n", gU32TmpTime);
  #endif

    /* initialize ir key value */
    u8KeyCode = KEY_NULL;

    /* initialize channel move index*/
    g_u16ChannelOrinigalIndex = -1;

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Start of Load & Check general setting and database
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /* database usage status */
    MApp_Init_PrintDataBaseMsg(); // 0 ms
    /* EEPROM usage check */
#if (EEPROM_DB_STORAGE!=EEPROM_SAVE_NONE)
  #if (EEPROM_DB_STORAGE==EEPROM_SAVE_ALL)
    if ( ((U32)RM_GEN_USAGE + (U32)RM_64K_USAGE + RM_EEPROM_ID_SIZE) > ((U32)RM_MAX_ADDRESS + 1) )
  #elif (EEPROM_DB_STORAGE==EEPROM_SAVE_WITHOUT_CH_DB)
    if ( ((U32)RM_GEN_USAGE + RM_EEPROM_ID_SIZE) > ((U32)RM_MAX_ADDRESS + 1) )
  #endif
    {
        int i;
        for(i=0;i<20;i++)
        {
            printf("\n\nWarning!       RM_GEN_USAGE + RM_64K_USAGE Overflow: %lu + %lu\n\n", (U32)RM_GEN_USAGE, (U32)RM_64K_USAGE);
        }
    }
#endif // #if (EEPROM_DB_STORAGE!=EEPROM_SAVE_NONE)


    /* EEPROM restore or init global setting */
#if (EEPROM_DB_STORAGE!=EEPROM_SAVE_NONE)
  #if (ENABLE_BOOTTIME)
    gU32BootStepTime = msAPI_Timer_GetTime0();
  #endif

    CAL_TIME_FUNC_("PreInit");

    MApp_CheckEEPROM();

    CAL_TIME_FUNC_("PreInit");

  #if (ENABLE_BOOTTIME)
    gU32TmpTime = msAPI_Timer_DiffTimeFromNow(gU32BootStepTime);
    printf("[boot step time]MApp_CheckEEPROM = %ld\n", gU32TmpTime);
  #endif
#endif // #if (EEPROM_DB_STORAGE!=EEPROM_SAVE_NONE)


    /* Flash restore or init global setting */
#if (EEPROM_DB_STORAGE != EEPROM_SAVE_ALL)
  #if (ENABLE_BOOTTIME)
    gU32BootStepTime = msAPI_Timer_GetTime0();
  #endif

    MApp_CheckFlash();
#ifdef ENABLE_CUS_POWERON_CHECK_WB_ADC
    MApp_CheckWhiteBalanceSetting();
    MApp_CheckADCSetting();
#endif
    CAL_TIME_FUNC_("PreInit");

  #if (ENABLE_BOOTTIME)
    gU32TmpTime = msAPI_Timer_DiffTimeFromNow(gU32BootStepTime);
    printf("[boot step time]MApp_CheckFlash = %ld\n", gU32TmpTime);
  #endif
#endif // #if (EEPROM_DB_STORAGE != EEPROM_SAVE_ALL)

#if ENABLE_MULTI_PANELS
    msAPI_DrvInitStep2();
    MApi_PNL_En(ENABLE); 
    MApi_SC_ForceFreerun(TRUE);
    MApi_SC_SetFreerunVFreq(VFREQ_60HZ);
	//MApi_XC_SetPanelTiming(&stTimingInfo, eWindow);
    bAlreadyCall_MApi_PNL_En = TRUE;
#endif
   msAPI_Ajust_Vcom_value();
    MApp_UartPort_Conect();

#if (ENABLE_FACTORY_PANEL_SEL)
    devPanel_GetPanelType();
#endif

#if BOE_ACPOWERON_AUTO_UPGRADE

	if (EN_POWER_AC_BOOT == stPowerGenSetting.g_ucACorDCon)
	{
		BOE_usb_check();
	}
#endif
//<<SMC jayden.chen  add auto usb update when AC power on 20130927
#if ENABLE_SMC_USB_AUTO_UPDATE
if(stPowerGenSetting.g_ucACorDCon == EN_POWER_AC_BOOT)
	MApp_UsbDownload_Process();
#endif

// CUS_XM Xue 20120803:
//stGenSetting.g_FactorySetting.isPCSelfAdjusted=FALSE;
// ------------------------------------------------------------
// Check DC or AC on to decide right now should boot or sleep
// ------------------------------------------------------------


  #if (ENABLE_FACTORY_POWER_ON_MODE)

    if ( stPowerGenSetting.g_ucACorDCon == EN_POWER_AC_BOOT )
    {
        bfirstACBoot = TRUE;
 //       msAPI_Timer_SetSystemTime(946771163); //946771163 = 2010-01-01 00:00 AM  (TIME ZONE = 0+)
	 msAPI_Timer_SetSystemTime(631152000);    //CUS SMC INDIA 2000-01-01 00:00
        // MApp_LoadGenSetting();
        printf(" g_u8DCOnOff = %s \r\n", (stGenSetting.g_FactorySetting.g_u8DCOnOff)?("ON"):("OFF"));

        if ((stGenSetting.g_FactorySetting.u8PowerOnMode == POWERON_MODE_ON) || (stGenSetting.g_FactorySetting.fBuringMode == TRUE))		// CUS_XM Sea 20120718: burn in Ϊon�ϵ��Զ�����
        {
            printf("POWERON_MODE_ON >>\n");
        }
        else if(stGenSetting.g_FactorySetting.u8PowerOnMode == POWERON_MODE_OFF)
        {
            printf("POWERON_MODE_OFF >>\n");
            printf("should go to standby!!!!!\n");
            msAPI_Power_PowerDown_EXEC();
        }
        else if(stGenSetting.g_FactorySetting.u8PowerOnMode == POWERON_MODE_SAVE)
        {
            printf("POWERON_MODE_SAVE >>\n");
            if(stGenSetting.g_FactorySetting.g_u8DCOnOff == EN_POWER_DC_OFF)
            {
                printf("should go to standby!!!!!\n");
                msAPI_Power_PowerDown_EXEC();
            }
        }
        LED_RED_ON();
        LED_GREEN_OFF();

    }
    else if ( stPowerGenSetting.g_ucACorDCon == EN_POWER_DC_BOOT )
    {
        bfirstACBoot = FALSE;
        printf(">>>EN_POWER_DC_BOOT\n");
        LED_RED_ON();
        LED_GREEN_OFF();
    }

    if(stGenSetting.g_FactorySetting.g_u8DCOnOff != EN_POWER_DC_ON)
    {
        //printf("Save g_u8DCOnOff to ON\n");

        stGenSetting.g_FactorySetting.g_u8DCOnOff = EN_POWER_DC_ON;

        MApp_SaveFactorySetting();

#if (EEPROM_DB_STORAGE == EEPROM_SAVE_NONE)
      #if GENSETTING_STORE_USE_NEW_METHOD
         msAPI_Flash_EraseGensettingBank();
      #else
        if (g_u16QuickGenSettingIdx == (QUICK_DB_GENST_NUM - 1))
       {
           msAPI_MIU_QuickGenSettingErase(QUICK_DB_GENSETTING_BANK, TRUE);
           msAPI_MIU_QuickGenSettingErase(QUICK_DB_GENSETTING_BANK+1, FALSE);
           g_u16QuickGenSettingIdx = 0;
       }
  #endif
        MApp_DB_SaveGenSetting();
#endif
    }
  #endif

#if  MIG_USE_MD5_ENCRYPT
 int My_cmpstr(unsigned char *arg1,unsigned char *arg2)
 {
       while(*arg1==*arg2)
       {

             if(*arg1=='\0')
             {

                return 0;
			 }

           arg1++;

		   arg2++; 
	   }

      return  *arg1 - *arg2;
  }
  
//
// ------------------------------------------------------------
//
  unsigned char u8ftempbuf[16]={0x00};
  //U16 u16flshlenth = 0;
   MD5_CTX md5;
   MD5Init(&md5);		 
   int i,k;
   unsigned char encrypt[] ="admin";//21232f297a57a5a743894a0e4a801fc3
   unsigned char decrypt[16];	 
   MD5Update(&md5,encrypt,strlen((char *)encrypt));
   MD5Final(&md5,decrypt);		  
   printf("����ǰ:%s\n after encryption:",encrypt);
   for(i=0;i<16;i++)
   {
	printf("%02x\n",decrypt[i]);
   }
    /*
	if (MDrv_FLASH_Write( 0x3f0000  , 16, (U8 *) (void*)decrypt )!=FALSE)
	{
        printf("Write succse!\n");
	}
	*/
    if(MDrv_FLASH_Read(  0x400000 , 64, (U8 *) (void*)u8ftempbuf )!=FALSE)
    {
    
	for(k=0;k<64;k++)
    {
	printf("%02x\n", u8ftempbuf[k]);
    }

	}
	if(My_cmpstr(decrypt,u8ftempbuf)==0)
	{
        printf("SECRT SUCCES\n");
	}
    else
    {
       //SHOW_VIDEO_ERR(x)
       //OSD_NO_SI
       printf("\nSECRT FAIL\n");
	   

	}
	#endif
    // if cold boot and want to enter UI menu screen page, there is no default data for it, need to initialize here ///
    MApp_DB_LoadModeSetting(MAIN_WINDOW, 0); // 0 ms


  #if (ENABLE_PIP)
    if(IsPIPSupported())
    {
        MApp_DB_LoadModeSetting(SUB_WINDOW, 0); // 0 ms
    }
  #endif

    if(g_PcadcModeSetting[MAIN_WINDOW].u16HorizontalStart == 0 || g_PcadcModeSetting[MAIN_WINDOW].u16VerticalStart == 0)
    {
        MApp_DB_LoadDefaultTable(MAIN_WINDOW, 0); // 0 ms

      #if (ENABLE_PIP)
        if(IsPIPSupported())
        {
            MApp_DB_LoadDefaultTable(SUB_WINDOW, 0); // 0 ms
        }
      #endif
    }

    if (MApp_DataBase_VersionCheck() == FALSE) // 0 ms
    {
        INIT_DBINFO(printf("Version Check Fail => Restore to Default!!!\n"));
        printf("Version Check Fail => Restore to Default!!!\n");
        MApp_InitGenSetting();
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // End of Load & Check general setting and database
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    // Should be put after loading DB

    SYS_SCREEN_SAVER_TYPE(MAIN_WINDOW) = EN_SCREENSAVER_NULL;

  #if (ENABLE_PIP)
    if(IsPIPSupported())
    {

        SYS_SCREEN_SAVER_TYPE(SUB_WINDOW) = EN_SCREENSAVER_NULL;
    }
  #endif

#if ENABLE_SSC
    msAPI_MIU_SetSsc(  stGenSetting.g_SSCSetting.MIUSscSpanKHzx10,
                        stGenSetting.g_SSCSetting.MIUSscStepPercentagex100,
                        stGenSetting.g_SSCSetting.SscMIUEnable );

  #if (ENABLE_LVDSTORGB_CONVERTER == ENABLE)
    g_IPanel.SetSSC( SSC_SPAN_PERIOD, SSC_STEP_PERCENT, DISABLE );
  #else
    g_IPanel.SetSSC( stGenSetting.g_SSCSetting.LVDSSscSpanKHzx10,
                        stGenSetting.g_SSCSetting.LVDSSscStepPercentagex100,
                        stGenSetting.g_SSCSetting.SscLVDSEnale);
  #endif
#endif // #if ENABLE_SSC


    /* initial teletext */
#if ENABLE_TTX
  #if (ENABLE_BOOTTIME)
    gU32BootStepTime = msAPI_Timer_GetTime0();
  #endif

    msAPI_TTX_InitSystem();

  #if (ENABLE_BOOTTIME)
    gU32TmpTime = msAPI_Timer_DiffTimeFromNow(gU32BootStepTime);
    printf("[boot step time]msAPI_TTX_InitSystem = %ld\n", gU32TmpTime);
  #endif
#endif  // #if ENABLE_TTX


#if (MirrorEnable== ENABLE)
    MApp_image_mirror(MirrorEnable);
#endif

#if ENABLE_TCON
    MApi_TCON_PNL_POWER_ENABLE();
#endif


  #if ENABLE_DMP
    if((UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_DMP)
      #if( ENABLE_DMP_SWITCH )
       ||(UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_DMP1)
       ||(UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_DMP2)
      #endif
	)
    {
        if(UI_PREV_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_DMP)
        {
        #if(ENABLE_DTV == FALSE)
            UI_PREV_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_ATV;
        #else
            UI_PREV_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_DTV;
        #endif
        }

      #if (ENABLE_DMP_POWERON==FALSE)
        UI_INPUT_SOURCE_TYPE = UI_PREV_INPUT_SOURCE_TYPE;
     #endif
    }
#endif // #if ENABLE_DMP


#if  (ENABLE_DMP_POWERON==FALSE)
    UI_PREV_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_TYPE;
#endif

  #if (ENABLE_DTV == FALSE)
    if( UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_DTV)
        UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_AV;
  #endif

    g_enChType = (EN_CH_TYPE)UI_INPUT_SOURCE_TYPE;
    // Set flag initial value
    fEnableSignalMonitor      = FALSE;    // Enable signal
    bEnableAC3Check         = FALSE;    // for check scramble(ac3 not exist.)
    u8PollingStereo         = 0;
    g_bRealTimeMonitorOnly = FALSE;
    #if (INPUT_SCART_VIDEO_COUNT >= 1)
    u32ScartSwitchDuration = 0;
    #endif
    g_bIsImageFrozen = FALSE;


    /* init HDMI Switch */
#if (HDMI_SWITCH_SELECT != HDMI_SWITCH_NONE)
  #if(INPUT_HDMI_VIDEO_COUNT > 0)
    HDMI_SWITCH_INIT();
  #endif
#endif // #if (HDMI_SWITCH_SELECT != HDMI_SWITCH_NONE)

    /* init audio */
    //msAPI_AUD_I2S_Amp_Reset(); // 0 ms,move down !

  #if (ENABLE_BOOTTIME)
    gU32BootStepTime = msAPI_Timer_GetTime0();
  #endif

    MApp_ATVProc_Initialize();
  #if ENABLE_CUS_BLOCK_SYS
    msAPI_ATV_ClearAllLockedCHCheckPwdFlag();
  #endif

  #if (ENABLE_BOOTTIME)
    gU32TmpTime = msAPI_Timer_DiffTimeFromNow(gU32BootStepTime);
    printf("[boot step time]MApp_ATVProc_Initialize = %ld\n", gU32TmpTime);
  #endif


    CAL_TIME_FUNC_("PreInit");
  
#if CUS_SMC_ENABLE_HOTEL_MODE
	  if(stGenSetting.g_FactorySetting.HotelMenuHotelModeOperationEnable == ENABLE)
	  {
		  stGenSetting.g_SysSetting.Language=stGenSetting.g_FactorySetting.HotelMenuLanguage;
		  stGenSetting.g_SoundSetting.Volume = stGenSetting.g_FactorySetting.HotelMenuVolumeDefault;
	  }
	  //SMC jayden.chen
	  g_u8HotelVolMax = stGenSetting.g_FactorySetting.HotelMenuMaxVolumeSetting;
#endif

    msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_PERMANENT_MUTEON, E_AUDIOMUTESOURCE_ACTIVESOURCE);
    msAPI_AUD_AdjustAudioFactor(E_ADJUST_VOLUME, stGenSetting.g_SoundSetting.Volume, 0);
    //Audio_Amplifier_ON();

    /* Set the sound mode */
    MApp_Audio_AdjustSoundMode();

    /* Set the surround mode */
#if (ENABLE_CUS_SURROUND_FOLLOW_SNDMODE == DISABLE)
    MApp_Aud_SetSurroundMode(stGenSetting.g_SoundSetting.SurroundSoundMode);
#else
    MApp_Aud_SetSurroundMode(stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].SurroundSoundMode);
#endif
    MApp_Aud_Banlace_Init();
#if (ENABLE_CUS_UI_SPEC == FALSE)
    MApp_Aud_EQ_Init();
#endif

    //�������������ת
    //MDrv_WriteWordRegBit(0x112D7A, ENABLE, BIT8);
    //>>
    
 /* init audio after Audio switch*/             //
    msAPI_AUD_I2S_Amp_Reset(); // 0 ms
  //////////////////////////////////////////////////////////

  CAL_TIME_FUNC_("PreInit");
#if (MS_BOARD_TYPE_SEL == BD_CUS_715G_5740)
  PANEL_3D_ENABLE_OFF();
#endif
#if (DISPLAY_LOGO) //Thomas 20120402 for logo & audio sync
  #if((ENABLE_MPLAYER_CAPTURE_LOGO) || ENABLE_CUS_UI_SPEC)
    printf("--------->Power on Logo is [%bu] \n",stGenSetting.g_SysSetting.UsrLogo);
    u8IsAutoSleep_Skip_Logo = !stGenSetting.g_SysSetting.UsrLogo;
  #endif
    if (u8IsAutoSleep_Skip_Logo == FALSE)
    {
        if (MApp_Logo_Load())
        {
            bEnablePowerOnLogo = TRUE;

        }
        else
        {
            bEnablePowerOnLogo = FALSE;
        }
        msAPI_AEON_Disable();
    }
#endif // #if (DISPLAY_LOGO)

#if ENABLE_POWERON_MUSIC
Audio_Amplifier_ON();
#endif

#if ((ENABLE_DMP) && (ENABLE_POWERON_MUSIC))
    printf("-->Power on Music is [%bu] \n",stGenSetting.g_SysSetting.UsrPowerOnMusic);
    if(stGenSetting.g_SysSetting.UsrPowerOnMusic)
    {
        bEnablePowerOnMusic = TRUE;
        MApp_PowerOnMusic_Init();
    }
#endif // #if ((ENABLE_DMP) && (ENABLE_POWERON_MUSIC))


#if (DISPLAY_LOGO)
     printf("---->bEnablePowerOnLogo=%d\n",bEnablePowerOnLogo);
    if( bEnablePowerOnLogo )
    {
        printf("---->start  show  LOGO\n");
        g_bPreInit_SkipChangeAudioSrc = TRUE;
        MApp_Logo_Display(TRUE);
		

        g_bPreInit_SkipChangeAudioSrc = FALSE;
    }
#endif

    // First time set backlight
    MApi_PNL_SetBackLight(BACKLITE_INIT_SETTING);
    
    bAlreadyCall_SetBacklight = TRUE;
    gFactoryBLTBackLITtimeback1 = msAPI_Timer_GetTime0();

#if ((ENABLE_DMP) && (ENABLE_POWERON_MUSIC))
    if( bEnablePowerOnMusic )
    {
        MApp_PowerOnMusic_Polling(16);
    }
#endif // #if ((ENABLE_DMP) && (ENABLE_POWERON_MUSIC))

    MW_AUD_SetSoundMute(SOUND_MUTE_SCART, E_MUTE_ON); // mute AV-OUT

    // Init  CEC
  #if (ENABLE_CEC)
      msAPI_CEC_Init();
  #endif

#if ((ENABLE_DMP) && (ENABLE_POWERON_MUSIC))
    if( bEnablePowerOnMusic )
    {
        MApp_PowerOnMusic_Polling(2);
    }
#endif // #if ((ENABLE_DMP) && (ENABLE_POWERON_MUSIC))

    CAL_TIME_FUNC_("PreInit");

#if (ENABLE_DTV==0)
    #if ((ENABLE_DMP) && (ENABLE_POWERON_MUSIC))  //fix bug:poweron music lag when ATV has channel data  /*Creass.liu at 2012-07-18*/
    if(stGenSetting.g_SysSetting.UsrPowerOnMusic == FALSE)
    #endif
    {
        msAPI_Tuner_Init();
    }
#endif
#if (ENABLE_DTV)
  #if (ENABLE_BOOTTIME)
    gU32BootStepTime = msAPI_Timer_GetTime0();
  #endif

  #if (ENABLE_T_C_COMBO || DVB_T_C_DIFF_DB)//TODO need add DVB-C case
    msAPI_Tuner_SwitchSource((EN_DVB_TYPE)stGenSetting.stScanMenuSetting.u8DVBCTvConnectionType, FALSE);
    MApp_DVBType_SetPrevType((EN_DVB_TYPE)stGenSetting.stScanMenuSetting.u8DVBCTvConnectionType);
  #endif

    msAPI_Tuner_Initialization(1);
    msAPI_Tuner_InitExternDemod();

  #if (ENABLE_BOOTTIME)
    gU32TmpTime = msAPI_Timer_DiffTimeFromNow(gU32BootStepTime);
    printf("[boot step time]msAPI_Tuner_Initialization = %ld\n", gU32TmpTime);
  #endif

  #if (ENABLE_BOOTTIME)
    gU32BootStepTime = msAPI_Timer_GetTime0();
  #endif

  #if ENABLE_CI
    /* CI_Init: Detect CICAM and then Switch TS Interface to Serial/Parallel Mode. */
    //msAPI_CI_EnablePerformanceMonitor(msAPI_Timer_DiffTimeFromNow(gU32BootTime));
    MApp_Init_CI(); // It's important to INIT CI LIB HERE irrespective of which the input source is!

    // Speed up CI.
    if (FALSE == msAPI_CI_CardDetect())
    {
        U8 i;

        for (i = 0; i < CI_INIT_DETECT_COUNT; i++)
        {
            if (msAPI_CI_Polling())
            {
                break;
            }
        }
    }

    if (!msAPI_CI_CardDetect())
    {
      #if (ENABLE_BOOTTIME)
        gU32BootStepTime = msAPI_Timer_GetTime0();
      #endif
      #if ENABLE_CI_PLUS
        #if (!TS_SERIAL_OUTPUT_IF_CI_REMOVED)
        msAPI_Tuner_Serial_Control(TRUE);
        msAPI_Tuner_SetByPassMode(TRUE, FALSE);
        #else
        msAPI_Tuner_Serial_Control(FALSE);
        #endif
      #else
        msAPI_Tuner_Serial_Control(FALSE);
      #endif
    }
    else
    {
      #if ENABLE_CI_PLUS
        #if (!TS_SERIAL_OUTPUT_IF_CI_REMOVED)
        msAPI_Tuner_Serial_Control(TRUE);
        msAPI_Tuner_SetByPassMode(TRUE, FALSE);
        #else
        msAPI_Tuner_Serial_Control(FALSE);
        #endif
      #else
        MApp_CI_Switch_TS(FALSE);
      #endif
    }
  #else
      #if ENABLE_CI_PLUS
      #if (!TS_SERIAL_OUTPUT_IF_CI_REMOVED)
          msAPI_Tuner_Serial_Control(TRUE);
      #else
          msAPI_Tuner_Serial_Control(FALSE);
      #endif
      #else
        msAPI_Tuner_Serial_Control(FALSE);
      #endif
  #endif // #if ENABLE_CI

    bDemodPowerOnInit = TRUE;

  #if (ENABLE_BOOTTIME)
        gU32TmpTime = msAPI_Timer_DiffTimeFromNow(gU32BootStepTime);
        printf("[boot step time]msAPI_Tuner_Serial_Control = %ld\n", gU32TmpTime);
  #endif
#endif // #if (ENABLE_DTV)

    CAL_TIME_FUNC_("PreInit");

#if ((ENABLE_DMP) && (ENABLE_POWERON_MUSIC))
    if( bEnablePowerOnMusic )
    {
        MApp_PowerOnMusic_Polling(2);
    }
#endif // #if ((ENABLE_DMP) && (ENABLE_POWERON_MUSIC))

    MApp_Init_TimeSetting();    // 0 ms
    MApp_Init_CheckOnTimer();   // 0 ms
    msAPI_AUD_AdjustAudioFactor(E_ADJUST_VOLUME, stGenSetting.g_SoundSetting.Volume, 0);

  //////////////////////////////////////////////////////////

  #if ENABLE_OFFLINE_SIGNAL_DETECTION
    MApp_OffLineInit();
  #endif

  #if (INPUT_SCART_VIDEO_COUNT >= 1)
    //Scart plug-in, enable to switch to scart
    if (u8Switch2Scart == 1)
    {
        UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_SCART;
    }

    u8Switch2Scart = 0;
  #endif

  #if ENABLE_SW_CEC_WAKEUP
    MApp_PMGetCECWakeUpPort();
  #endif
#if (INPUT_SCART_VIDEO_COUNT > 0)
#if (INPUT_SCART_VIDEO_COUNT >= 1)
    if(UI_INPUT_SOURCE_TYPE != UI_INPUT_SOURCE_SCART)
    {
        if (msAPI_GPIO_IsSourceJustConnected(INPUT_SOURCE_SCART) == TRUE)
        {
            UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_SCART;
            ResetScartChange();
        }
    }
#endif
#if (INPUT_SCART_VIDEO_COUNT >= 2)
    if(UI_INPUT_SOURCE_TYPE != UI_INPUT_SOURCE_SCART)
    {
        if (msAPI_GPIO_IsSourceJustConnected(INPUT_SOURCE_SCART2) == TRUE)
        {
            UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_SCART;
            ResetScartChange();
        }
    }
#endif
#endif

  #if (ENABLE_BOOTTIME)
    gU32BootStepTime = msAPI_Timer_GetTime0();
  #endif

    MApp_Init_UIVariable();

  #if (ENABLE_BOOTTIME)
    gU32TmpTime = msAPI_Timer_DiffTimeFromNow(gU32BootStepTime);
    printf("[boot step time]MApp_Init_UIVariable = %ld\n", gU32TmpTime);
  #endif

    //bIsInsideDTVManualScanMenu = FALSE;


  CAL_TIME_FUNC_("PreInit");

    //Set GOP Start to wait VSync
    MApi_GOP_GWIN_SetForceWrite(DISABLE); // 0 ms

  #if ENABLE_OAD
    MApp_OAD_Init(); // 0 ms

    /* Initial OAD Flag */
    bFoundOAD = FALSE;
    bNitFoundInvalidOAD=FALSE;
  #endif //ENABLE_OAD

    enFrotEndLockStatus = FRONTEND_UNKNOWN;
    enMVDVideoStatus = MVD_UNKNOWN_VIDEO;
    g_bPCSignalMonitor = FALSE;
    g_u8PCSignalMonitorCounter = 0;
	#ifdef ENABLE_CUS_AUTO_SCAN_HOTKEY
    g_u8FacIRGotoScanMonitorCounter = 0;
	#endif

    MApp_Scan_State_Init(); // 0 ms
    MApp_DataInitVariable(); // 0 ms
    MApp_SignalMonitor_Init(); // 0 ms
    MApp_ChannelChange_VariableInit(); // 0 ms

    // 5V Antenna Monitor
    AdjustAntenna5VMonitor((EN_MENU_5V_AntennaPower)stGenSetting.g_SysSetting.f5VAntennaPower); // 0 ms

    UART_Clear(); // 0 ms

    CAL_TIME_FUNC_("PreInit");

    MApp_ZUI_Init(); // 0 ms

    CAL_TIME_FUNC_("PreInit");

#if ((ENABLE_DMP) && (ENABLE_POWERON_MUSIC))
    if( bEnablePowerOnMusic )
    {
        MApp_PowerOnMusic_WaitStop();
    }
#endif

    CAL_TIME_FUNC_("PreInit");

#if (DISPLAY_LOGO)
    if (u8IsAutoSleep_Skip_Logo == TRUE)
    {
        u8IsAutoSleep_Skip_Logo = FALSE;
    }
    else
    {
        if( bEnablePowerOnLogo )
        {
            MApp_PowerOnLogo_WaitStop(3000);//show logo 3s for CUS spec.

            MApp_Logo_Display(FALSE);
        }
    }
#endif // #if (DISPLAY_LOGO)

  CAL_TIME_FUNC_("PreInit");


  #if (ENABLE_DTV)
    _MApp_DTVInit();
  #else
  #if ((ENABLE_DMP) && (ENABLE_POWERON_MUSIC))  //fix bug:poweron music lag when ATV has channel data  /*Creass.liu at 2012-07-18*/
     if(stGenSetting.g_SysSetting.UsrPowerOnMusic)
     {
         msAPI_Tuner_Init();
     }
  #endif
  #endif
  CAL_TIME_FUNC_("PreInit");

#if (CHIP_FAMILY_TYPE==CHIP_FAMILY_M10)
    if ((enMiuDDR_Speed == DDR1_400MHz)||((enMiuDDR_Speed == DDR2_800MHz)&&(MEMORY_MAP == MMAP_32MB)))
        MDrv_BW_LoadDefaultTable();
#endif

#if ENABLE_EPGTIMER_RECORDER_TURNOFFPANEL
    if(g_bTimerTypeRecord)
    {
        msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_INTERNAL_3_MUTEON, E_AUDIOMUTESOURCE_ACTIVESOURCE);
        MApi_PNL_SetBackLight(DISABLE);
        bAlreadyCall_SetBacklight = FALSE;
    }
 #endif

  #if (ENABLE_BOOTTIME)
    gU32BootStepTime = msAPI_Timer_GetTime0();
  #endif

  #if ( ENABLE_DIP_PWS)
    {
        MS_SYS_INFO pSysInfo;
        E_DATA_INPUT_SOURCE pDataInputSource;
        E_PWS_DIGITALIP_API_SouceInfo ePWSInputSource;

        MApp_Load_Input_Source_Setting();

        MApp_InputSource_SetSystemmInfo( UI_INPUT_SOURCE_TYPE, &pSysInfo , &pDataInputSource);
        //printf("###EDDIE:pSysInfo->enInputSourceType=0x%x \n",pSysInfo.enInputSourceType);
        ePWSInputSource=msAPI_SysInputSource2PWSInputSource(pSysInfo.enInputSourceType);
        MApi_DigitalIP_PWS_Init(ePWSInputSource);
    }
  #endif

    #if(ENABLE_POWERON_VIDEO)
    msAPI_Pan_Task();
    #endif
//=============================================================================================
//add for hotel mode's input source change @chuxu 2012-08-17
	#if CUS_SMC_ENABLE_HOTEL_MODE
	    if(stGenSetting.g_FactorySetting.HotelMenuHotelModeOperationEnable == ENABLE)
		{
		   _MApp_HotelMode_Load_InputSourceChange();
		}
	#endif
//===============================================================================================
	MApp_InputSource_SwitchSource(UI_INPUT_SOURCE_TYPE, MAIN_WINDOW);
    CAL_TIME_FUNC_("PreInit");

  #if (ENABLE_BOOTTIME)
    gU32TmpTime = msAPI_Timer_DiffTimeFromNow(gU32BootStepTime);
    printf("[boot step time]MApp_InputSource_SwitchSource 1 = %ld\n", gU32TmpTime);
  #endif


#if (ENABLE_PIP)
    if(IsPIPSupported())
    {
        MApi_XC_SetBorderFormat( stGenSetting.g_stPipSetting.u8BorderWidth, stGenSetting.g_stPipSetting.u8BorderWidth<<4, stGenSetting.g_stPipSetting.u8BorderWidth, stGenSetting.g_stPipSetting.u8BorderWidth<<4, 0xFC, SUB_WINDOW );
        if((stGenSetting.g_stPipSetting.enPipMode==EN_PIP_MODE_PIP) &&
            stGenSetting.g_stPipSetting.bBolderEnable)
        {
            MApi_XC_EnableBorder(stGenSetting.g_stPipSetting.bBolderEnable, SUB_WINDOW);
        }
    }

    if(IsPIPEnable())
    {
        if(stGenSetting.g_stPipSetting.enSubInputSourceType == UI_INPUT_SOURCE_NONE)
        {
            stGenSetting.g_stPipSetting.enPipMode = EN_PIP_MODE_OFF;
            stGenSetting.g_stPipSetting.enSubInputSourceType = MApp_InputSource_GetUIInputSourceType(MApp_InputSource_PIP_Get1stCompatibleSrc(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)));
        }
        else if(!MApp_InputSource_PIP_IsSrcCompatible(MApp_InputSource_GetInputSourceType(UI_INPUT_SOURCE_TYPE), MApp_InputSource_GetInputSourceType(stGenSetting.g_stPipSetting.enSubInputSourceType)))
        {
            //If sub src is not compatible with main src, find the first compatible src for sub window.
            stGenSetting.g_stPipSetting.enSubInputSourceType = MApp_InputSource_GetUIInputSourceType(MApp_InputSource_PIP_Get1stCompatibleSrc(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)));
        }

      #if (ENABLE_BOOTTIME)
        gU32BootStepTime = msAPI_Timer_GetTime0();
      #endif

        MApp_InputSource_SwitchSource(stGenSetting.g_stPipSetting.enSubInputSourceType, SUB_WINDOW);

      #if (ENABLE_BOOTTIME)
        gU32TmpTime = msAPI_Timer_DiffTimeFromNow(gU32BootStepTime);
        printf("[boot step time]MApp_InputSource_SwitchSource 2 = %ld\n", gU32TmpTime);
      #endif
    }
    else if(!IsPIPSupported())
#endif // #if (ENABLE_PIP)
    {
        stSystemInfo[SUB_WINDOW].enInputSourceType = INPUT_SOURCE_NONE;
    }

  #if (ENABLE_BOOTTIME)
    gU32BootStepTime = msAPI_Timer_GetTime0();
  #endif

  #if (INPUT_SCART_VIDEO_COUNT >= 1)
    msAPI_GPIO_IsSourceJustConnected(INPUT_SOURCE_SCART);
    msAPI_GPIO_IsSourceJustDisConnected(INPUT_SOURCE_SCART);
  #endif

  #if (INPUT_SCART_VIDEO_COUNT >= 2)
    msAPI_GPIO_IsSourceJustConnected(INPUT_SOURCE_SCART2);
    msAPI_GPIO_IsSourceJustDisConnected(INPUT_SOURCE_SCART2);
  #endif

  #if (ENABLE_BOOTTIME)
    gU32TmpTime = msAPI_Timer_DiffTimeFromNow(gU32BootStepTime);
    printf("[boot step time]msAPI_GPIO_IsSourceJustConnected 2 = %ld\n", gU32TmpTime);
  #endif


  #ifdef SCART_OUT_NEW_METHOD
    MDrv_VE_Init_SCART_OUT_MODE();
  #endif

  #if ( ENABLE_CUS_DBC)
    MApi_XC_Sys_DBCInit();
  #endif

  #if ( ENABLE_DLC)
  #if ENABLE_CUS_DLC
    g_bEnableDLC = ST_PICTURE.bDLCStatus;
  #endif
  #endif

    switch(ST_VIDEO.eAspectRatio)
    {
        case EN_AspectRatio_JustScan:
         #if VGA_HDMI_YUV_POINT_TO_POINT
        case EN_AspectRatio_point_to_point:
          #endif
            MApp_Scaler_EnableOverScan(DISABLE);
            break;

        case EN_AspectRatio_Zoom1:
        case EN_AspectRatio_Zoom2:
            MApp_Scaler_ResetZoomFactor(ST_VIDEO.eAspectRatio);
            MApp_Scaler_EnableOverScan(ENABLE);
            break;

        default:
            MApp_Scaler_EnableOverScan(ENABLE);
            break;
    }

    MApi_AUDIO_SPDIF_HWEN(TRUE);
    u8HDMIchkflag = 0;

    msAPI_FS_Init();

  #if (ENABLE_DTV_EPG)
    stEpgTimerParam.stEpgTimer.enTimerType = EN_EPGUI_TIMER_REMINDER;
  #endif

  #if ENABLE_PVR
    msAPI_PVRFS_SetMemory(((BULK_FILE_SYSTEM_MEMORY_TYPE & MIU1) ? (BULK_FILE_SYSTEM_ADR | MIU_INTERVAL) : (BULK_FILE_SYSTEM_ADR)),BULK_FILE_SYSTEM_LEN);
    msAPI_PVRFS_SetDiskDriveIndex(0);
    msAPI_PVRFS_SetDeviceIndex(0);
    MApp_UiPvr_Init();
  #endif


#if ENABLE_OD
  #if (ENABLE_BOOTTIME)
    gU32BootStepTime = msAPI_Timer_GetTime0();
  #endif

    MDrv_OD_Init( OD_MSB_START_ADDR ,OD_MSB_LIMIT_ADDR,OD_LSB_START_ADDR,OD_LSB_LIMIT_ADDR , tOverDrive);
    MDrv_OverDriverSwitch( TRUE );

  #if (ENABLE_BOOTTIME)
    gU32TmpTime = msAPI_Timer_DiffTimeFromNow(gU32BootStepTime);
    printf("[boot step time]ENABLE_OD = %ld\n", gU32TmpTime);
  #endif
#endif // #if ENABLE_OD


  #if ((UI_SKIN_SEL ==  UI_SKIN_1366X768X565) \
        ||(UI_SKIN_SEL ==  UI_SKIN_1366X768X565_SMC_India) \
        ||(UI_SKIN_SEL ==  UI_SKIN_1366X768X4444) \
        ||(UI_SKIN_SEL ==  UI_SKIN_1366X768X565) \
        ||(UI_SKIN_SEL ==  UI_SKIN_1366X768X8888)\
        ||(UI_SKIN_SEL==UI_SKIN_1366X768X565_HAIER_CN))
#if (CHIP_FAMILY_TYPE==CHIP_FAMILY_M10) || (CHIP_FAMILY_TYPE==CHIP_FAMILY_M12)
    if(g_IPanel.Width() >= 960 && g_IPanel.Height() >= 540)
#else
    if(g_IPanel.Width() >= 1366 && g_IPanel.Height() >= 768)
#endif
    {
        MApi_GOP_GWIN_SwitchGOP(E_GOP_OSD);

        #if (CHIP_FAMILY_TYPE==CHIP_FAMILY_M10) || (CHIP_FAMILY_TYPE==CHIP_FAMILY_M12)
        MApi_GOP_GWIN_Set_STRETCHWIN(E_GOP_OSD, E_GOP_DST_OP0,0, 0, 960, 540);
        MApi_GOP_GWIN_Set_HSCALE(TRUE,960,PANEL_WIDTH);
        MApi_GOP_GWIN_Set_VSCALE(TRUE, 540, PANEL_HEIGHT);
        #else
        MApi_GOP_GWIN_Set_STRETCHWIN(E_GOP_OSD, E_GOP_DST_OP0,0, 0, ZUI_ALIGNED_VALUE(1366,8), 768);
        MApi_GOP_GWIN_Set_HSCALE(TRUE,ZUI_ALIGNED_VALUE(1366,8),PANEL_WIDTH);
        MApi_GOP_GWIN_Set_VSCALE(TRUE, 768, PANEL_HEIGHT);
        #endif

        MApi_GOP_GWIN_Set_HStretchMode(E_GOP_HSTRCH_6TAPE_LINEAR);
        MApi_GOP_GWIN_Set_TranspColorStretchMode(E_GOP_TRANSPCOLOR_STRCH_DUPLICATE);
    }
    else
    {
       //Unsupported resolution
       printf("[Unsupported Resolution: %d x %d\n]",g_IPanel.Width(),g_IPanel.Height());
    }
  #endif

  #if DEBUG_USE_UART_COMMAND
    uart_interrupt_enable(FALSE);
  #endif

  #if ((BRAZIL_CC )|| (ATSC_CC == ATV_CC))
    msAPI_VBI_Init();
    MApp_CC_ResetExistInfo();
    MApp_CC_SetPeriodTime(0);     //0:check only once   x: check always
    PT_PreInit_PrintfTime("msAPI_VBI_Init();-- %ld\n");
#endif


  #if MHEG5_ENABLE
    msAPI_MHEG5_SetBaseYear(DEFAULT_YEAR);
  #endif


#ifdef OPEN_VERSION_DBG
 #if (OPEN_VERSION_DBG==ENABLE)
  #if (ENABLE_BOOTTIME)
    gU32BootStepTime = msAPI_Timer_GetTime0();
  #endif

    MApp_AllVersion_Init();
    MApp_CountMax();
    MApp_CheckAllVersion();

  #if (ENABLE_BOOTTIME)
    gU32TmpTime = msAPI_Timer_DiffTimeFromNow(gU32BootStepTime);
    printf("[boot step time]OPEN_VERSION_DBG = %ld\n", gU32TmpTime);
  #endif
 #endif // #if (OPEN_VERSION_DBG==ENABLE)
#endif // #ifdef OPEN_VERSION_DBG


    // Should be called behind Database part
    MApp_setupMemory();

  #if (VECTOR_FONT_ENABLE) && (COPRO_MVF_ENABLE)
    msAPI_Font_MVF_WaitForGenerateBitmaps();
  #endif

    MApp_ADC_HW_SaveGainOffset();

    #if (ENABLE_BOOTTIME)
    gU32TmpTime = msAPI_Timer_DiffTimeFromNow(gU32BootTotalStepTime);
    printf("[boot step time]Major function Total Time = %ld\n", gU32TmpTime);
    stGenSetting.g_SysSetting.fEnableOsdAnimation = EN_OSD_EFFECT_ROTATION_ONLY;
    stGenSetting.g_SysSetting.SystemSettingCS = MApp_CalCheckSum((BYTE *)&(stGenSetting.g_SysSetting), SIZE_SYS_SETTING );
    #endif

#if ENABLE_PVR
    #if (ENABLE_PVR_AESDMA)
        #ifdef PVR_UTOPIA
        MDrv_AESDMA_Init(0, 0, 1);
        #endif
    #endif
#endif
    Tcon_Printf(5);
    CAL_TIME_FUNC_END();

    MApp_MuteAvByLock(E_SCREEN_MUTE_INPUT, MApp_UiMenuFunc_CheckInputLockAudioVideo());
    MApp_SetMenuLanguage(stGenSetting.g_SysSetting.Language);
    //Panel_VCOM_PWM_SET(180);
   //MDrv_PWM_DutyCycle(1,180);
/////////////////////////////////////////////////////////////////////////////////////////////////////////
//add for hotel menu AQ/PQ restore : if off and turn off power, initial AQ and PQ setting, if on and turn off power,  save AQ and PQ setting @chuxu 2012-08-07
    #if 0//CUS_SMC_ENABLE_HOTEL_MODE
    if(stGenSetting.g_FactorySetting.HotelMenuHotelModeOperationEnable == ENABLE)
    {
        if(stGenSetting.g_FactorySetting.HotelMenuAQPQRestoreEnable == ENABLE)
        {
            //can restore AQ and PQ setting
        }
        else if(stGenSetting.g_FactorySetting.HotelMenuAQPQRestoreEnable == DISABLE)
        {
            //don't  restore AQ and PQ setting = AQ and PQ setting initialize
            //add for reset audio
            MApp_DataBase_RestoreDefaultAudio();

            //add for reset video
            MApp_DataBase_RestoreDefaultVideo(DATA_INPUT_SOURCE_TYPE(MAIN_WINDOW));
            MApp_DataBase_PictureResetWhiteBalance(DATA_INPUT_SOURCE_TYPE(MAIN_WINDOW));
            MApp_Picture_Setting_SetColor(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW), MAIN_WINDOW);  //MApp_PicSetVideo(SYS_INPUT_SOURCE_TYPE, &ST_VIDEO );
            MApp_Scaler_Setting_SetVDScale(ST_VIDEO.eAspectRatio, MAIN_WINDOW);
        }
    }
    else if(stGenSetting.g_FactorySetting.HotelMenuHotelModeOperationEnable == DISABLE)
    {
        //don't execute any action
    }
    #endif
/////////////////////////////////////////////////////////////////////////////////////////////////////////

    g_bInitFinished = TRUE;
#if BOE_USB_UPGRADE_FACTROY//minglin1206	
  MDrv_USBSetPortAutoSwitchStatus(FALSE);	
#endif
}

#if(ENABLE_DTV)
static void _MApp_DTVInit(void)
{
    MS_SI_INIT_PARAMETER sSIParameter;
#if ENABLE_OAD
    MS_DMX_NOTIFY sDmxNotify;
#endif
 #if (ENABLE_DTV_EPG)
    DTV_CM_INIT_PARAMETER sDTVNotify;
//  #if (ENABLE_SBTVD_BRAZIL_APP==0)
    MS_EIT_INIT_PARAMETER sEITInitParameter;
//  #endif
 #endif // #if (ENABLE_DTV_EPG)

    CAL_TIME_FUNC_START();

    /*Clear EPG Timer before loading DataBase*/
  #if ENABLE_DTV_EPG //(ENABLE_DTV)
    MApp_EpgTimer_InitTimerSettings(FALSE);
  #endif

 #if (ENABLE_DTV_EPG)
//  #if (ENABLE_SBTVD_BRAZIL_APP==0)
    memset(&sEITInitParameter,0,sizeof(MS_EIT_INIT_PARAMETER));
//  #endif
 #endif // #if (ENABLE_DTV_EPG)
    memset(&sSIParameter,0,sizeof(MS_SI_INIT_PARAMETER));

    sSIParameter.u8MaxServiceOneMux=MAX_VC_PER_PHYSICAL;
    sSIParameter.u32SIBufferStartAddress = _PA2VA(((SI_MONITOR_DB_MEMORY_TYPE & MIU1) ? (SI_MONITOR_DB_ADR | MIU_INTERVAL) : (SI_MONITOR_DB_ADR)));
    sSIParameter.u32SIBufferSize = SI_MONITOR_DB_LEN;
    sSIParameter.u32SINameBufferAddress = _PA2VA(((SRV_NAME_BUF_MEMORY_TYPE & MIU1) ? (SRV_NAME_BUF_ADR | MIU_INTERVAL) : (SRV_NAME_BUF_ADR)));


    //printf("(SI_MAX_VC_PER_PHYSICAL*SI_MAX_SERVICE_NAME) %x %x\n",(SI_MAX_VC_PER_PHYSICAL*SI_MAX_SERVICE_NAME)
    //    ,SRV_NAME_BUF_LEN);
    if((SI_MAX_VC_PER_PHYSICAL*SI_MAX_SERVICE_NAME)>SRV_NAME_BUF_LEN)
    {
        int i;
        for(i=0;i<100;i++)ASSERT(0);
    }

#if(ENABLE_SBTVD_BRAZIL_APP)
    sSIParameter.u32NITScanTimeOut=4000;
#else
    sSIParameter.u32NITScanTimeOut=30000;
#endif


  #if (ENABLE_SBTVD_BRAZIL_APP == 0)
    sSIParameter.eSI_Type=SI_PARSER_DVB;
  #else
    sSIParameter.eSI_Type=SI_PARSER_ISDB_ABNT;
  #endif

    sSIParameter.bSkipUnsupportService = FALSE;

#if 1
    sSIParameter.enProgUpdateType=EN_SI_UPDATE_TYPE_SDT_PAT_COMBO;
    sSIParameter.bEnablePATCRCcheck=TRUE;
#endif

  #if (ENABLE_DTV_EPG)
   sSIParameter.bEnableEPG = TRUE;
  #endif

//  #if (ENABLE_SBTVD_BRAZIL_APP == 0)
    sSIParameter.pfNotify_PMT = MApp_SI_Parse_PMT;
//  #endif

  #if 1//ENABLE_TS_FILEIN
    sSIParameter.pfNotify_FileIn_PMT = MApp_SI_FileIn_Parse_PMT;
  #endif

  #if ENABLE_OAD
    sDmxNotify.pfNotify_OAD_Init=MApp_OAD_Init;
    MApp_Dmx_Init_OAD(&sDmxNotify);
    sSIParameter.pfNotify_NIT = MApp_SI_Parse_NIT;
  #endif
  #if ENABLE_CI
    sSIParameter.pfNotify_SDT = MApp_SI_Parse_SDT;
  #endif

    CAL_TIME_FUNC_("DtvInit");

    MApp_SI_Init(&sSIParameter);

    CAL_TIME_FUNC_("DtvInit");

#if ENABLE_SAVE_MULTILINGUAL_SERVICE_NAME
	MApp_SI_SetSaveMultiLingualServiceNameNumber(MAX_MULTI_LINGUAL_SERVICE_NAME);
#endif
    /* init epg database */
#if (ENABLE_DTV_EPG)
// #if (ENABLE_SBTVD_BRAZIL_APP==0)
    sEITInitParameter.u32PF_BufferAddress =_PA2VA(EIT_PF_STRING_BUF_ADR);
    sEITInitParameter.pfNotify_EIT_Cur_PF=MApp_SI_Parse_EIT;
  #if SUPPORT_PVR_CRID
    if(EVENTDB_SDRAM_LEN>=0x0000840000)
    {
        sEITInitParameter.bEnablePVR_CRID=TRUE;
    }
  #endif
  #if ENABLE_SCHE_EXT
    sEITInitParameter.bEnableScheduleExtendEvent=TRUE;
  #endif
    MApp_EIT_Init(&sEITInitParameter);
// #endif // #if (ENABLE_SBTVD_BRAZIL_APP==0)

    CAL_TIME_FUNC_("DtvInit");

    memset(&sDTVNotify,0,sizeof(sDTVNotify));
    sDTVNotify.pfNotify_CM_MoveProgram=MApp_Epg_MoveSrvBuffer;
    sDTVNotify.pfNotify_CM_SwapProgram=MApp_Epg_SwapProgram;
    sDTVNotify.pfNotify_SrvPriorityHandler=MApp_Epg_SrvPriorityHandler;
    sDTVNotify.pfNotify_CM_RemoveProgram=MApp_Epg_RemoveProgram;
    msAPI_CM_Init(&sDTVNotify);

    MApp_EIT_All_Sche_ResetFilter();

    {
        U32 u32EventDbMIUAddrGap = ( (EVENTDB_SDRAM_MEMORY_TYPE&MIU1) ? MIU_INTERVAL : 0x0000000 );
        U32 u32EventDbAddr       = EVENTDB_SDRAM_ADR + u32EventDbMIUAddrGap;
        U32 u32ExtDbMIUAddrGap;//   = ( (EPGEXTDB_SDRAM_MEMORY_TYPE&MIU1) ? MIU_INTERVAL : 0x0000000 );
        U32 u32ExtDbAddr;//         = EPGEXTDB_SDRAM_ADR + u32ExtDbMIUAddrGap;
#if ENABLE_SCHE_EXT
        u32ExtDbMIUAddrGap   = ( (EPGEXTDB_SDRAM_MEMORY_TYPE&MIU1) ? MIU_INTERVAL : 0x0000000 );
        u32ExtDbAddr         = EPGEXTDB_SDRAM_ADR + u32ExtDbMIUAddrGap;
#else
        u32ExtDbMIUAddrGap=u32ExtDbAddr=0;
#endif
  #if SUPPORT_PVR_CRID
        if(EVENTDB_SDRAM_LEN>=0x0000840000)
        {
            MAPP_EPG_SetFunctionFlag(eEN_PVR_CRID);
        }
  #endif

  #if ENABLE_SCHE_EXT
        MAPP_EPG_SetFunctionFlag(eEN_SCHE_EXT);
  #endif

  #ifdef SUPPORT_FRANCE_H264_BY_1DDR//T4 1DDR H264 project has only 3800KB Event DB buffer, event number need reduce to 11200(Original is 16000)
        {
           MW_EN_EPG_DB_PARAM_CONFIG config;
           config.u32MaxNumOfEventInEPGDB = 11200;
           config.u32MaxNumOfEventInSrv = 512;
           MApp_EPGDB_ParamConfig(&config);
        }
  #endif

        CAL_TIME_FUNC_("DtvInit");

        MApp_EPGDB_Setup(MAX_DTVPROGRAM, _PA2VA(u32EventDbAddr), EVENTDB_SDRAM_LEN, _PA2VA(u32ExtDbAddr), EPGEXTDB_SDRAM_LEN);
        CAL_TIME_FUNC_("DtvInit");

        MApp_Epg_Init();
        CAL_TIME_FUNC_("DtvInit");
    }
#endif //#if (ENABLE_DTV_EPG)

#if (ENABLE_UPDATE_MULTIPLEX_VIA_NIT)
    if(IsDTVInUse() && (OSD_COUNTRY_SETTING == OSD_COUNTRY_NORWAY || OSD_COUNTRY_SETTING == OSD_COUNTRY_NEWZEALAND))
    {
#if (LOSS_SIGNAL_ALTERNATIVE_ENABLE)
    MApp_TV_SetCheckAlternativeFlag(TRUE);
#endif
        MApp_SI_SetCheckFreqChange(TRUE);
    }
#endif

    CAL_TIME_FUNC_END();

}
#endif // #if(ENABLE_DTV)

void MApp_Init_FlashVariable(void)
{
	g_bGenSettingStoreUseNewMethod 		= GENSETTING_STORE_USE_NEW_METHOD;
	g_bOpenGenstStoreDBG 					= 0;//Open DBG Message
	g_ENABLE_DVBT_1000_LCN 				= 0;
	g_DB_IN_NAND 							= DB_IN_NAND;
	g_SYSTEM_BANK_SIZE 					= SYSTEM_BANK_SIZE;
    g_FLASH_SIZE                        = FLASH_SIZE;
	g_QUICK_DB_GENSETTING_BANK 			= QUICK_DB_GENSETTING_BANK;
	g_u8EEPROM_DB_STORAGE 				= EEPROM_DB_STORAGE;
	//g_EEPROM_SAVE_ALL						= EEPROM_SAVE_ALL;
	g_u32DataBaseAddr 						= DRAM_GEN_DB_START(((DATABASE_START_MEMORY_TYPE & MIU1) ? (DATABASE_START_ADR | MIU_INTERVAL) : (DATABASE_START_ADR)));
	g_RM_GENSET_START_ADR 				= RM_GENSET_START_ADR;
	g_QUICK_DB_GENST_NUM 				= QUICK_DB_GENST_NUM;
	g_RM_GEN_USAGE 						= RM_GEN_USAGE;
	g_BUF_ID_FLASH 						= BUF_ID_FLASH;
	g_QUICK_DB_GENST_INVALID_IDX 		= QUICK_DB_GENST_INVALID_IDX;
	g_QUICK_DB_GENST_GOOD 				= QUICK_DB_GENST_GOOD;
	g_QUICK_DB_GENST_OBSOLETE 			= QUICK_DB_GENST_OBSOLETE;
	g_MEMCOPYTYPE 						= MIU_FLASH2SDRAM;
	g_RM_SIZE_GENSET 						= RM_SIZE_GENSET;
	g_QUICK_DB_GENST_SIZE 				= QUICK_DB_GENST_SIZE;
	g_QUICK_DB_GENST_MASK 				= QUICK_DB_GENST_MASK;
	g_QUICK_DB_GENST_READY 				= QUICK_DB_GENST_READY;
	g_QUICK_DB_GENST_UPDATE 				= QUICK_DB_GENST_UPDATE;
	g_QUICK_DB_GENST_MODIFIED 			= QUICK_DB_GENST_MODIFIED;
	g_QUICK_DB_GENST_ERASE_DONE 		= QUICK_DB_GENST_ERASE_DONE;
	g_QUICK_DB_GENST_ERASE_IN_PROGRESS 	= QUICK_DB_GENST_ERASE_IN_PROGRESS;
}

#undef MAPP_INIT_C

