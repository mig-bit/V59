////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MAPP_INSTALL_MAIN_H
#define _MAPP_INSTALL_MAIN_H

#include "datatype.h"
#include "MApp_Exit.h"

#ifdef MAPP_INSTALL_MAIN_C
#define INTERFACE
#else
#define INTERFACE extern
#endif

typedef enum
{
    STATE_INSTALL_INIT,
    STATE_INSTALL_WAIT,
    STATE_INSTALL_EPGTIMER_WAIT,
    STATE_INSTALL_CLEAN_UP,
    STATE_INSTALL_GOTO_STANDBY,
    STATE_INSTALL_GOTO_SCAN,
    STATE_INSTALL_GOTO_EPG,
    STATE_INSTALL_GOTO_CHANNELCHANGE,   // To chagne TV<->RADIO when banner is displayed.
} EN_INSTALL_STATE;

INTERFACE EN_RET MApp_InstallGuide_Main(void);

#undef INTERFACE

#endif  // _MAPP_INSTALL_MAIN_H

