///////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// ("MStar Confidential Information") by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
///////////////////////////////////////////////////////////////////////////////

#ifndef _MAPP_BITMAP_H
#define _MAPP_BITMAP_H

#include "datatype.h"
#include "msAPI_OSD.h"

#ifdef MAPP_LOADBITMAP_C
#define INTERFACE
#else
#define INTERFACE extern
#endif

//------------------------------------------------------------------------------
// Defines
//------------------------------------------------------------------------------
#define LOCK_BMP_WIDTH              0x40
#define LOCK_BMP_HEIGHT             0X40
#define LOCK_BMP_TOTAL_BYTE         (LOCK_BMP_WIDTH * LOCK_BMP_HEIGHT * 2)

#define LOCK_SMALL_BMP_WIDTH        0x18
#define LOCK_SMALL_BMP_HEIGHT       0X18
#define LOCK_SMALL_BMP_TOTAL_BYTE   (LOCK_SMALL_BMP_WIDTH * LOCK_SMALL_BMP_HEIGHT * 2)

//Input bitmap
#define PICTURE_BMP_WIDTH           0x40
#define PICTURE_BMP_HEIGHT          0x40
#define PICTURE_BMP_TOTAL_BYTE      (PICTURE_BMP_WIDTH * PICTURE_BMP_HEIGHT * 2)

//Mute bitmap
#define MUTE_BMP_WIDTH          0x20
#define MUTE_BMP_HEIGHT         0x20
#define MUTE_BMP_TOTAL_BYTE     (MUTE_BMP_WIDTH * MUTE_BMP_HEIGHT * 2)

//Clock bitmap

#define CLOCK_BMP_WIDTH         0x20
#define CLOCK_BMP_HEIGHT        0x20
#define CLOCK_BMP_TOTAL_BYTE    (CLOCK_BMP_WIDTH * CLOCK_BMP_HEIGHT * 2)

// Volume Bitmap
#define VOLUME_BMP_WIDTH        40
#define VOLUME_BMP_HEIGHT       40
#define VOLUME_BMP_TOTAL_BYTE   (VOLUME_BMP_WIDTH * VOLUME_BMP_HEIGHT * 2)


#undef INTERFACE
#endif /*~MAPP_BITMAP_H*/

