////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MAPP_ZUI_ACTUPGRADE_H
#define _MAPP_ZUI_ACTUPGRADE_H

#ifdef __cplusplus
extern "C" {
#endif  /* __cplusplus */

#include "MApp_ZUI_APIgdi.h"
#include "MApp_ZUI_APIcommon.h"


#ifdef MAPP_ZUI_ACTUPGRADE_C
#define INTERFACE
#else
#define INTERFACE extern
#endif

typedef enum
{
    DISPPLAY_MSG_UPDATE_DONE,
    DISPPLAY_MSG_UPDATE_ERROR,
    DISPPLAY_MSG_UNPACK_DONE,
    DISPPLAY_MSG_UNPACK_ERROR,
    DISPPLAY_MSG_NUM,
}DISPLAY_MSG_TYPE;

typedef enum
{
    // chakra to daemon
    UPGRADE_CMD_START = 0x00,                        // chakra to daemon. Notify daemon start to update.
    UPGRADE_CMD_CANCEL = 0x01,                       // chakra to daemon. Notify daemon doesn��t do update.
    UPGRADE_CMD_SET_MSG_DISPLAY_TIME = 0x02,    // chakra to daemon. Set the the interval before reboot when the event is happened.
    // 0x03~0x1F is reserved for other cmd.

    // daemon to chakra
    UPGRADE_CMD_REQUEST = 0x20,               // daemon to chakra. Notify chakra the daemon pid and request to do update.
    UPGRADE_CMD_UPDATE_DONE = 0x21,    // daemon to chakra. Update is done.
    UPGRADE_CMD_UPDATE_ERROR = 0x22, // daemon to chakra. Update is failed.
    UPGRADE_CMD_UNPACK_DONE = 0x23,    // daemon to chakra. Unpack image done.
    UPGRADE_CMD_UNPACK_ERROR = 0x24, // daemon to chakra. Unpack image failed.
} UPGRADE_CMD;

typedef enum
{
    UPGRADE_STATE_REQ,
    UPGRADE_STATE_START,
    UPGRADE_STATE_DONE,
    UPGRADE_STATE_FAIL,
    UPGRADE_STATE_UNPACK_DONE,
    UPGRADE_STATE_UNPACK_ERROR,
}UPGRADE_STATE;


/////////////////////////////////////////
// Cutomize Window Procedures...
//INTERFACE S32 MApp_ZUI_ACT_AudioVolumeWinProc(HWND, PMSG);

//#define AUDIOVOLUME_WINPROC MApp_ZUI_ACT_AudioVolumeWinProc

/////////////////////////////////////////
// Event Handlers....
INTERFACE void MApp_ZUI_ACT_AppShowUpgrade(void);
INTERFACE void MApp_ZUI_ACT_TerminateUpgrade(void);
INTERFACE BOOLEAN MApp_ZUI_ACT_HandleUpgradeKey(VIRTUAL_KEY_CODE key);
INTERFACE BOOLEAN MApp_ZUI_ACT_ExecuteUpgradeAction(U16 act);
INTERFACE LPTSTR MApp_ZUI_ACT_GetUpgradeDynamicText(HWND hwnd);
INTERFACE EN_RET MApp_Upgrade_Main(void);


#undef INTERFACE

#ifdef __cplusplus
}
#endif  /* __cplusplus */

#endif /* _MAPP_ZUI_ACTAUDIOVOLUME_H */

