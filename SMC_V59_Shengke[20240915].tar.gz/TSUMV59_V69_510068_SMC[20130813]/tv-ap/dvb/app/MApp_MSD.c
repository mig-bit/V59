////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#define MAPP_MSD_C

#include "datatype.h"
#include "sysinfo.h"
#include <string.h>
#include "msAPI_FCtrl.h"
#include "msAPI_MSDCtrl.h"
#include "msAPI_MIU.h"
#include "msAPI_Memory.h"


#include "MApp_Exit.h"


#define MSDAP_DBG(x) x

//static U8 code _CO_DUMMY=0; //to avoid linking error

typedef enum
{
    STATE_MSD_INIT,
    STATE_MSD_LOADING,
    STATE_MSD_EXIT,
} EN_MSD_STATE;


//static EN_MSD_STATE enMSDState = STATE_MSD_INIT;

#if 0//ENABLE_DREC
BOOLEAN MApp_MSD_StartDevice(S8 deviceIndex)
{

     EN_MSD_STATUS status=msAPI_MSDCtrl_GetDeviceStatus(deviceIndex);

    //printf("deviceStatus=%bu for deviceIndex=%bu\n",(U8)status,(U8)deviceIndex);

    if(status==MSD_STATUS_INSERTED)

    {

        return msAPI_FCtrl_ActiveDevice(deviceIndex);

    }

    else if(status==MSD_STATUS_IDLE)

    {

        return TRUE;

    }

    else

    {

        return FALSE;

    }


}

#endif

#undef MAPP_MSD_C

