///////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// ("MStar Confidential Information") by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
///////////////////////////////////////////////////////////////////////////////

#ifndef _MAPP_CHANNEL_CHANGE_H
#define _MAPP_CHANNEL_CHANGE_H

#include "apiVDEC.h"
#include "MApp_Exit.h"
#include "msAPI_Global.h"
#include "msAPI_MW_GlobalSt.h"
#include "MApp_GlobalSettingSt.h"
#include "apiAUDIO.h"

//extern U32 u32ChannelChangeStartingTime;


#if MHEG5_ENABLE
#include "msAPI_MHEG5.h"
#endif
#if (ENABLE_DTV_EPG)
#include "mapp_eit.h"
#endif
typedef enum
{
    STATE_CHANNELCHANGE_INIT,
    STATE_CHANNELCHANGE_SHOWINFO,
    STATE_CHANNELCHANGE_WAITKEY,
    STATE_CHANNELCHANGE_DISPLAY,
    STATE_CHANNELCHANGE_MSGBOX_FADING,
    STATE_CHANNELCHANGE_EXIT,
} EN_CHANNELCHANGE_STATE;

typedef enum
{
    TYPE_TV,
    TYPE_ATV,
    TYPE_DTV,
    TYPE_ANALOG,
    TYPE_PC,
    TYPE_YPBPR,
    TYPE_AV,
} EN_INPUT_TYPE;

typedef enum
{
    STATE_DETECT_SIGNAL_INPROGRESS_NOSIGNAL,
    STATE_DETECT_SIGNAL_INPROGRESS_UNSUPPORT_MODE,
    STATE_DETECT_SIGNAL_NOSIGNAL,
    STATE_DETECT_SIGNAL_OK,
    STATE_DETECT_SIGNAL_PC_UNSUPPORT_MODE,
    STATE_DETECT_SIGNAL_ERROR,
} EN_DETECT_SIGNAL_STATE;

typedef enum
{
    TYPE_CHANNEL_CHANGE_SER_ID,
    TYPE_TUNE_STREAM_SER_ID,
    TYPE_CHANNEL_CHANGE_SER_ID_QUIETLY,
    TYPE_CHANNEL_CHANGE_LCN,
    TYPE_TUNE_STREAM_LCN,
    TYPE_CHANNEL_CHANGE_LCN_QUIETLY,
    TYPE_CHANNEL_CHANGE_SER_ID_NDT,             // ndt
    TYPE_CHANNEL_CHANGE_SER_ID_QUIETLY_NDT,     // ndt
    TYPE_CHANNEL_CHANGE_LCN_NDT,                // ndt
    TYPE_CHANNEL_CHANGE_LCN_QUIETLY_NDT,        // ndt
} EN_MHEG_5_TUNE_TYPE;

typedef enum
{
    PVR_DEMUX_CHANGE_INPUTSOURCE,
    PVR_DEMUX_CHANGE_CH_PLUS, //change RF by KEY_CH_PLUS
    PVR_DEMUX_CHANGE_CH_MINUS,
    PVR_DEMUX_CHANGE_CH_CHANGE, //change RF by channel list

}EN_PVR_DEMUX_CHANGE_TYPE;

#ifdef MAPP_CHANNEL_CHANGE_C
#define INTERFACE
#else
#define INTERFACE extern
#endif


#define CHANNEL_CHANGE_KEY_REPEAT_DELAY 1200//300 //ms
INTERFACE void MApp_ChannelChange_VariableInit( void );
INTERFACE EN_DETECT_SIGNAL_STATE MApp_ChannelChange_DetectSignalStatus(E_UI_INPUT_SOURCE input_type);
INTERFACE void MApp_ChannelChange_DisableAV(SCALER_WIN eWindow);
INTERFACE void MApp_ChannelChange_EnableAV(void);
INTERFACE void MApp_ChannelChange_DisableChannel(BOOLEAN u8IfStopDsmcc, SCALER_WIN eWindow/*U8 u8ChanBufIdx*/);
INTERFACE void MApp_ChannelChange_EnableChannel(SCALER_WIN eWindow);
INTERFACE void MApp_ChannelChange_PIP_ChangeAudioSource2TV(SCALER_WIN eWindow);
INTERFACE void MApp_ChannelChange_CheckBlockChannelPW(void);
INTERFACE EN_RET MApp_ChannelChange(void);
INTERFACE EN_RET MApp_ChannelChange_ShowAnalogBanner ( void );
#if ENABLE_DTV
INTERFACE BOOLEAN MApp_ChannelChange_ChangeSpeciChannel( U16 u16InputValue, U16 wOriginalNetwork_ID, U16 wTransportStream_ID, EN_MHEG_5_TUNE_TYPE bType, BOOLEAN bCheckTsID );
#endif
INTERFACE void MApp_ChannelPosition_Restore(void);
#if MHEG5_ENABLE
INTERFACE EN_RET MApp_ChannelChange_GoBackDataMode(void);
#endif
INTERFACE void MApp_ChannelChange_ShowEventInfoBanner(void);
//INTERFACE void MApp_ChannelChange_DrawChannelBannerInfo(BOOLEAN checkMVDMode);
INTERFACE void MApp_ChannelChange_SearchDefaultAudioLang(void);
INTERFACE void MApp_ChannelChange_CheckForceMode(void);
INTERFACE void MApp_ChannelChange_SearchBroadcastMixAudio(void);


INTERFACE MEMBER_SERVICETYPE g_eCurrentUserServiceType;

#if MHEG5_ENABLE
INTERFACE U16  g_u16Current_AudioPID;
INTERFACE U16  g_u16Current_VideoPID;
INTERFACE U16  g_u16Current_AudioType;
INTERFACE VDEC_CodecType g_eCurrent_VideoType;
INTERFACE U16 g_u16CurrentServiceID;
INTERFACE WORD g_wCurrentTS_ID,g_wCurrent_ONID;
INTERFACE WORD g_wCurrentTVUserServicePosition,g_wCurrentRadioUserServicePosition;
INTERFACE MEMBER_SERVICETYPE g_eCurrentRealServiceType;
INTERFACE WORD g_wCurrentTVRealServicePosition,g_wCurrentRadioRealServicePosition;
#if NORDIG_FUNC //for Nordig Spec v2.0
INTERFACE WORD g_wCurrentDataUserServicePosition,g_wCurrentDataRealServicePosition;
#endif
INTERFACE BOOLEAN g_bMHEG5Service;
#endif

#if ENABLE_PVR
INTERFACE U16  g_u16Current_PCRPID;
INTERFACE U16  g_u16Current_PVR_VideoPID;
INTERFACE U16  g_u16Current_PVR_AudioPID;
INTERFACE U16  g_u16Current_AudioDescriptorPID;
INTERFACE AUDIOSTREAM_TYPE  g_enCurrent_AudioDescriptorType;
INTERFACE U16  g_wCurrent_AudioType;
//INTERFACE BOOLEAN bPvrRecChChange;  // check to allow CH change in  PVR recording mode
//INTERFACE U8 u8PvrCHChangeKey;
INTERFACE VDEC_CodecType g_eCurrent_PVR_VideoType;
INTERFACE void MApp_ChannelChange_Set_Audio_Decoder_System(WORD wAudType);
#endif

INTERFACE U8 u8AudLangCodeIdx;
INTERFACE U8 u8AudLangSelectedIdx;

#if ( ENABLE_DVB_TAIWAN_APP || ENABLE_SBTVD_BRAZIL_APP)
INTERFACE BOOLEAN g_bIsProgramAutoColorSystem;
#endif

#if (ENABLE_MADMONITOR)
INTERFACE U16  u16AudioPID;
INTERFACE U16  u16AudioType;
#endif
#undef INTERFACE
#endif
