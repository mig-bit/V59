////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MAPP_ZUI_ACTMENUFUNC_H
#define _MAPP_ZUI_ACTMENUFUNC_H

#ifdef __cplusplus
extern "C" {
#endif  /* __cplusplus */

#ifdef MAPP_ZUI_ACTMENUFUNC_C
#define INTERFACE
#else
#define INTERFACE extern
#endif

/////////////////////////////////////////
// Event Handlers....
INTERFACE BOOLEAN MApp_ZUI_ACT_ExecuteMenuItemAction(U16 act);
INTERFACE LPTSTR MApp_ZUI_ACT_GetMenuItemDynamicText(HWND hwnd);

INTERFACE S16 MApp_ZUI_ACT_GetMainMenuDynamicValue(HWND hwnd);
INTERFACE GUI_ENUM_DYNAMIC_LIST_STATE MApp_ZUI_ACT_QueryMainMenuItemStatus(HWND hwnd);
INTERFACE U16 _MApp_ZUI_ACT_GetLanguageStringID(EN_LANGUAGE lang, BOOLEAN bDefaultEnglish);
INTERFACE U16 _MApp_ZUI_ACT_GetCountryStringID(EN_OSD_COUNTRY_SETTING country);
#if (ENABLE_CUS_UI_SPEC == FALSE) /*Creass.liu at 2012-06-27*/
INTERFACE U16 _MApp_ZUI_ACT_GetTimeZoneStringID(EN_MENU_TIMEZONE timezone);
#endif
INTERFACE U16 _MApp_ZUI_ACT_GetBalanceValue(void);
INTERFACE U16 _MApp_ZUI_ACT_GetPictureModeStringID(void);
#if(UI_SKIN_SEL==UI_SKIN_1366X768X565_HAIER_CN) // cus_xm helen add 20120809
INTERFACE U16 _MApp_ZUI_ACT_GetREPEATStringID(void);
#endif
//CUS_XM:xue add remove compiler warnings 2012-7-10
INTERFACE U16 _MApp_ZUI_ACT_GetAudioModeStringID(void);
#if 1
INTERFACE BOOLEAN MApp_UiMenuFunc_AdjustInputLockTV(void);
INTERFACE BOOLEAN MApp_UiMenuFunc_AdjustInputLockAV1(void);
INTERFACE BOOLEAN MApp_UiMenuFunc_AdjustInputLockAV2(void);
INTERFACE BOOLEAN MApp_UiMenuFunc_AdjustInputLockYPbPr1(void);
INTERFACE BOOLEAN MApp_UiMenuFunc_AdjustInputLockYPbPr2(void);
INTERFACE BOOLEAN MApp_UiMenuFunc_AdjustInputLockHDMI1(void);
INTERFACE BOOLEAN MApp_UiMenuFunc_AdjustInputLockHDMI2(void);
INTERFACE BOOLEAN MApp_UiMenuFunc_AdjustInputLockHDMI3(void);
INTERFACE BOOLEAN MApp_UiMenuFunc_AdjustInputLockHDMI4(void);
INTERFACE BOOLEAN MApp_UiMenuFunc_AdjustInputLockPC(void);
INTERFACE BOOLEAN MApp_UiMenuFunc_CheckInputLock(void);
INTERFACE BOOLEAN MApp_UiMenuFunc_CheckInputLockAudioVideo(void);
#endif


#if (ENABLE_ATV_VCHIP)
INTERFACE HWND _MApp_ZUI_ACT_VchipIdMapToWindow(U8 u8Index);
#endif

#if (OBA2 && EN_BABAO_COMMUNICATE)
INTERFACE BOOLEAN MApp_ZUI_ACT_TurnOnOff_Babao(BOOLEAN on);
#endif

#if (OBA2)
INTERFACE BOOLEAN MApp_ZUI_ACT_SetEnvLanguage(EN_LANGUAGE elanguage);
#endif

//#define MAPP_SET_PANEL_VOCM_VAULE(x)    Panel_VCOM_PWM_SET(x);

#if (ENABLE_UI_3D_PROCESS)
void  MApp_ZUI_ACT_SetEnv3DOutputMode(E_UI_3D_UI_MODE eDirectType);
#endif
INTERFACE void MApp_ST_VIDEO_SetDMPUserDate(void);

#undef INTERFACE

#ifdef __cplusplus
}
#endif  /* __cplusplus */

#endif /* _MAPP_ZUI_ACTMENUFUNC_H */

