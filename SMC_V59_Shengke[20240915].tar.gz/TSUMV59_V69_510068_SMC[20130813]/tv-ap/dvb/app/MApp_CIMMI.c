////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#define MAPP_CIMMI_C

/********************************************************************************/
/*                            Header Files                                      */
/********************************************************************************/
#include <string.h>
#include <stdio.h>

#include "debug.h"

#include "sysinfo.h"
#include "msAPI_Global.h"
#include "msAPI_Flash.h"

#include "MApp_UiMenuDef.h"
#include "MApp_Subtitle.h"
#if MHEG5_ENABLE
#include "MApp_MHEG5_Main.h"
#endif
#include "MApp_Main.h"
#include "MApp_AnalogInputs.h"
#include "MApp_CIMMI.h"
#include "MApp_CIMMI_Private.h"
#include "MApp_TopStateMachine.h"
#include "MApp_ZUI_Main.h"
#include "ZUI_tables_h.inl"
#include "ZUI_exefunc.h"
#include "msAPI_MIU.h"
#include "msAPI_Timer.h"
#include "MApp_ChannelChange.h"
#include "MApp_ZUI_ACTeffect.h"
#include "MApp_SaveData.h"
#if ENABLE_PVR
#include "MApp_PVR.h"
#endif
#if (ENABLE_DTV)
/********************************************************************************/
/*                                 Macro                                        */
/********************************************************************************/
#define CIMMI_DEG_EN    0

#if CIMMI_DEG_EN
#define CIMMI_DBG(x)    x
#else
#define CIMMI_DBG(x)
#endif

#if ENABLE_CI
/******************************************************************************/
/*                                 External                                   */
/******************************************************************************/
#if MHEG5_ENABLE
    extern EN_MHEG5_STATE enMHEG5State;
#endif

//ZUI_TODO: extern void MApp_UiMenu_DrawMuteWin(void);
extern WORD CI_Cur_ServiceID;
extern WORD CI_PMT_ServiceID;
extern unsigned char g_activeMMI;
#if ENABLE_AUTOTEST
extern BOOLEAN g_bAutobuildDebug;
#endif
/********************************************************************************/
/*                                 Local                                        */
/********************************************************************************/

//static U8 bCleanOsdBeforeMmi=1;
static U8 u8CardDetectCnt = 0;
static U8 u8CI_Channel_change = FALSE;
static U8 u8CI_Event = 0x00;

/******************************************************************************/
/// DumpBuffer
/// Dump input buffer
/******************************************************************************/
#if 0
void DumpMMIBuffer(U8 *pBuf, U16 nBufSize)
{
    U16 i;
    CIMMI_DBG(printf("-------- pBuf:0x%08LX, Size:%04u--------------\n", (U32)pBuf, nBufSize));
    for(i=0; i<nBufSize; i++)
    {
        CIMMI_DBG(printf(" %02bX", *(pBuf+i)));
        if((i&0xF)==0xF)
        {
            CIMMI_DBG(putchar('\n'));
        }
    }
    CIMMI_DBG(putchar('\n'));
    for(i=0; i<20; i++)
    {
        CIMMI_DBG(putchar('\n'));
    }
    CIMMI_DBG(putchar('\n'));
}
#endif

BOOLEAN MMI_PrepareActiveMMI( void )
{
#if (MHEG5_ENABLE )
    if ( enMHEG5State == STATE_MHEG5_WAIT )
        return TRUE;
#endif

    if ( MApp_TopStateMachine_GetTopState()!=STATE_TOP_MENU //&& //ZUI: (enMenuFlowState != FS_MAIN_MENU)
         //ZUI_TODO: && (enMenuFlowState != FS_FACTORY_MENU)
         //(CI_Cur_ServiceID == CI_PMT_ServiceID)
       )
    {
        /*/ZUI_TODO:
        enUiMainMenuState = STATE_UIMENU_INIT;

        if ( enMenuMode == MENU_MODE )*/
        {
            if ( IsAnyTVSourceInUse() )
            {
                MApp_TopStateMachine_SetTopState(STATE_TOP_DIGITALINPUTS);
                //ZUI_TODO: enMenuMode = IDLE_MODE;
            }
            else
            {
                MApp_TopStateMachine_SetTopState(STATE_TOP_DIGITALINPUTS);
                //ZUI_TODO: enMenuMode = ANALOGINPUTS_MODE;
            }
        }
        /*/ZUI_TODO: else if ( enMenuMode == ANALOGINPUTS_MODE )
        {
            MApp_TopStateMachine_SetTopState(STATE_TOP_ANALOGINPUTS);
        }
        else
        */
        {
            MApp_TopStateMachine_SetTopState(STATE_TOP_DIGITALINPUTS);
        }

        return TRUE;
    }
    else
    {
        return FALSE;
    }
}

//////////////////////////////////////////////////////////
//2008/3/10: refine CI/MMI flow to independent MMI state...
//#include ".\..\..\..\Kernel\S3P\Driver\CI\include\drvCI_MMI.h"
EN_CIMMI_STATE enCIEvtState = STATE_CIMMI_EVENT_HANDLE;
EN_CIMMI_STATE enCIMMIState = STATE_CIMMI_INIT;

void MApp_CIMMI_ProcessUserInput(void)
{
#if ENABLE_CI_PLUS
    /* For item 24 of CI+ DTVL Certification, user can't change channel through P+/P-, EPG List, and etc. */
    if (TRUE == msAPI_CI_CU_GetState())
    {
        u8KeyCode = KEY_NULL;
    }
#endif
    switch ( u8KeyCode )
    {
        case KEY_CHANNEL_PLUS:
        case KEY_CHANNEL_MINUS:
#if ENABLE_HOTEL_MODE_FUNCTION
            if (HOTEL_INPUTMODE_FIX_IS_ON && (HOTEL_INPUTMODE_IS_TUNER == false))
            {
                u8KeyCode = KEY_NULL;
                break;
            }
#endif // ENABLE_HOTEL_MODE_FUNCTION

            if( IsSrcTypeDTV(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)) )
            {
                U16 u16TotalProNum;

                #if NORDIG_FUNC //for Nordig Spec v2.0
                u16TotalProNum = msAPI_CM_CountProgram(E_SERVICETYPE_DTV, E_PROGACESS_INCLUDE_VISIBLE_ONLY)
                                            + msAPI_CM_CountProgram(E_SERVICETYPE_RADIO, E_PROGACESS_INCLUDE_VISIBLE_ONLY)
                                            + msAPI_CM_CountProgram(E_SERVICETYPE_DATA, E_PROGACESS_INCLUDE_VISIBLE_ONLY);
                #else
                u16TotalProNum = msAPI_CM_CountProgram(E_SERVICETYPE_DTV, E_PROGACESS_INCLUDE_VISIBLE_ONLY)
                                            + msAPI_CM_CountProgram(E_SERVICETYPE_RADIO, E_PROGACESS_INCLUDE_VISIBLE_ONLY);
                #endif

                if(u16TotalProNum)
                {
                    enCIEvtState = STATE_CIMMI_CLEAN_UP;
                    u8CI_Channel_change=TRUE;
                }
                else
                {
                    enCIEvtState = STATE_CIMMI_CLEAN_UP;
                    u8KeyCode = KEY_NULL;
                }
            }
            else
            {
                    enCIEvtState = STATE_CIMMI_CLEAN_UP;
                    u8CI_Channel_change=TRUE;
            }

#if 0   // clean current MMI event; Move to Mapp_Tv.c
            if( (CI_EVENT_MMI_CLOSEMMI == u8CI_Event)||(CI_EVENT_MMI_MENU == u8CI_Event)
                ||(CI_EVENT_MMI_ENQ== u8CI_Event)||(CI_EVENT_MMI_LIST== u8CI_Event))
            {
                msAPI_CI_MMIDoneEvent(CIEvt);
            }
#endif
            msAPI_CI_MMIClose();//Send Close_CIMMI to CAM

            break;

        default:
            MApp_ZUI_ProcessKey(u8KeyCode);
            u8KeyCode = KEY_NULL;
            break;
    }
}

EN_RET MApp_CIMMI_Main(void)
{
    u8CI_Event = msAPI_CI_MMICheckEvent();
    EN_RET enRetVal = EXIT_NULL;

    //printf("MApp_CIMMI_Main %d %d\n", enCIEvtState, u8CI_Event);

    if(!msAPI_CI_CardDetect())
    {
        msAPI_CI_MMIDoneEvent(u8CI_Event);
        enCIEvtState = STATE_CIMMI_CLEAN_UP;
    }

    switch(enCIEvtState)
    {
        //Dispatch CI events
        case STATE_CIMMI_EVENT_HANDLE:
            switch(u8CI_Event)
            {
                //Draw CI MMI MSG box
                case CI_EVENT_MMI_ENQ:
                case CI_EVENT_MMI_MENU:
                case CI_EVENT_MMI_LIST:
                    enCIEvtState = enCIMMIState;
                    break;

                //If ZUI is running=> process key
                //If ZUI is not running => exit STATE_TOP_MMI in TopStateMachine
                case CI_EVENT_NONE:
                    if(MApp_ZUI_GetActiveOSD()!=E_OSD_CIMMI)
                        enRetVal = EXIT_CLOSE;
                    else
                    {
                        MApp_CIMMI_ProcessUserInput();
                    }
                    break;

                 //No need ZUI, process the CI events
                default:
                    enCIEvtState = STATE_CIMMI_WAIT;
                    break;
            }
            break;

        //Init ZUI
        case STATE_CIMMI_INIT:
            //_prev_type = EN_CIMMI_TYPE_NONE;

            MApp_ZUI_ACT_StartupOSD(E_OSD_CIMMI);
            if( msAPI_CI_GetCardState()==EN_NO_MODULE )
                MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_SHOW_CI_NO_MODULE_MSGBOX);
            else
                MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_SHOW_CI_LOAD_INFO_MSGBOX);

            enCIMMIState = STATE_CIMMI_INIT;
            break;

        //Wait ZUI MSG Box
        case STATE_CIMMI_MESSAGE_BOX:
            //note: don't polling CI status when message is shown...
            MApp_CIMMI_ProcessUserInput();
            break;

        //Process CI events
        case STATE_CIMMI_WAIT:
            {
                switch(u8CI_Event)
                {
                    case CI_EVENT_MMI_ENQ:
                    case CI_EVENT_MMI_MENU:
                    case CI_EVENT_MMI_LIST:
                        {
                            enCIMMIState = STATE_CIMMI_WAIT;
                            if (FALSE == MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_REPAINT_CIMMI_PAGE))
                            {
                                msAPI_CI_MMIDoneEvent(u8CI_Event);
                                enCIEvtState = STATE_CIMMI_CLEAN_UP;
                            }
                        }
                        break;
                    case CI_EVENT_MMI_CLOSEMMI:
                        msAPI_CI_MMIDoneEvent(u8CI_Event);
                        enCIEvtState = STATE_CIMMI_CLEAN_UP;
                    case CI_EVENT_NONE:
                        MApp_CIMMI_ProcessUserInput();
                        break;

                    default:
                        msAPI_CI_MMIDoneEvent(u8CI_Event);
                        enCIEvtState = STATE_CIMMI_EVENT_HANDLE;
                        break;
                }
            }

            break;

        //Clean ZUI
        case STATE_CIMMI_CLEAN_UP:
            if(MApp_ZUI_GetActiveOSD()==E_OSD_CIMMI)
            {
                if( u8CI_Channel_change)
                {
                    MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_PAGE_FADE_OUT, E_ZUI_STATE_TERMINATE);
                    u8CI_Channel_change=FALSE;
#if 0
                    msAPI_CI_MMIDoneEvent(u8CI_Event);  //if the previous state is not STATE_CIMMI_WAIT; Clean MMI event
#else
                    if( (CI_EVENT_MMI_CLOSEMMI == u8CI_Event)||(CI_EVENT_MMI_MENU == u8CI_Event)
                                    ||(CI_EVENT_MMI_ENQ== u8CI_Event)||(CI_EVENT_MMI_LIST== u8CI_Event))
                    {
                        msAPI_CI_MMIDoneEvent(u8CI_Event);
                    }
#endif
                }
                else
                {
                    MApp_ZUI_ACT_ShutdownOSD();
                }
            }

            enCIEvtState = STATE_CIMMI_EVENT_HANDLE;
            enCIMMIState = STATE_CIMMI_INIT;
            enRetVal = EXIT_CLOSE;
            break;

        case STATE_CIMMI_GOTO_STANDBY:
            MApp_ZUI_ACT_ShutdownOSD();
            u8KeyCode = KEY_POWER;
            enRetVal = EXIT_GOTO_STANDBY;
            break;

        default:
            enCIEvtState = STATE_CIMMI_EVENT_HANDLE;
            break;
    }
    return enRetVal;
}

//2008/3/11: refine CI/MMI interfaces...
// NOTE: use fake data for simulation...
//     0=init
//     1=enq
//            <=  wait for user enq
//     2=menu
//            <=  wait for user select
//     3=title
//            <=  timeout, goto 0

BOOLEAN MMI_ParseInformaton(CIMMI_INFO * pInfo) //[out] pInfo for current displaying infomation.
{
    MMI_INFO *pMMI = msAPI_CI_MMIGetData();
    U16 u16Len = 0, u16TmpLen = 0;
    U8 i, *pBuf = NULL;
    U8 u8Event = msAPI_CI_MMICheckEvent();

    if (NULL == pMMI)
        return TRUE;

    memset(pInfo, 0, sizeof(CIMMI_INFO));

    //Use pMMI->enType to switch, not u8Event
    //CI lib only stores the last MMI event's MMI data
    //only the last MMI event's pMMI->enType is valid, others are EN_MMI_TYPE_NONE
    switch (pMMI->enType)
    {
        case EN_MMI_TYPE_ENQ:
            CIMMI_DBG(printf("ENQ\n"));
            pInfo->enType = EN_CIMMI_TYPE_ENQ;
            pInfo->content.enq_data.bBlindAns = pMMI->content.enq.bBlindAns;
            pInfo->content.enq_data.u8AnsLen = pMMI->content.enq.u8AnsLen;
            memcpy(pInfo->aTitleContent,pMMI->content.enq.pu8Enq,pMMI->content.enq.u8EnqLen);
            pInfo->aTitleContent[pMMI->content.enq.u8EnqLen] = '\0';
            msAPI_CI_RemoveControlByte(pInfo->aTitleContent,pMMI->content.enq.u8EnqLen + 1);
            CIMMI_DBG(printf("ENQ Str %s\n",pInfo->aTitleContent));
            break;
        case EN_MMI_TYPE_MENU:
            CIMMI_DBG(printf("MENU\n"));
            pInfo->enType = EN_CIMMI_TYPE_MENU;
            if (pMMI->content.menu.u16TitleLen)
            {
                //memcpy(pInfo->aTitleContent,pMMI->content.menu.pu8Title,pMMI->content.menu.u8TitleLen);
                //We should follow SI character table, to translate various character.
                U8 u8TmpLen;
                u8TmpLen = MApp_SI_GetString(pInfo->aTitleContent, pMMI->content.menu.u16TitleLen, pMMI->content.menu.pu8Title, pMMI->content.menu.u16TitleLen, pMMI->content.menu.pu8Title[0]);

                pInfo->aTitleContent[u8TmpLen] = '\0';
                //msAPI_CI_RemoveControlByte(pInfo->aTitleContent,pMMI->content.menu.u8TitleLen + 1);
                CIMMI_DBG(printf("Title: %s\n",pInfo->aTitleContent));
            }
            if (pMMI->content.menu.u16SubtitleLen)
            {
                //memcpy(pInfo->content.menu_data.au8Subtitle, pMMI->content.menu.pu8Subtitle,pMMI->content.menu.u8SubtitleLen);
                //We should follow SI character table, to translate various character.
                U8 u8TmpLen;
                u8TmpLen = MApp_SI_GetString(pInfo->content.menu_data.au8Subtitle, pMMI->content.menu.u16SubtitleLen, pMMI->content.menu.pu8Subtitle, pMMI->content.menu.u16SubtitleLen, pMMI->content.menu.pu8Subtitle[0]);
                pInfo->content.menu_data.au8Subtitle[u8TmpLen] = '\0';
                //msAPI_CI_RemoveControlByte(pInfo->content.menu_data.au8Subtitle,++pMMI->content.menu.u8SubtitleLen);
                CIMMI_DBG(printf("Subtitle: %s\n",pInfo->content.menu_data.au8Subtitle));
            }
            if (pMMI->content.menu.u16BottomLen)
            {
                //memcpy(pInfo->content.menu_data.au8Bottom, pMMI->content.menu.pu8Bottom, pMMI->content.menu.u8BottomLen);
                //We should follow SI character table, to translate various character.
                U8 u8TmpLen;
                u8TmpLen = MApp_SI_GetString(pInfo->content.menu_data.au8Bottom, pMMI->content.menu.u16BottomLen, pMMI->content.menu.pu8Bottom, pMMI->content.menu.u16BottomLen, pMMI->content.menu.pu8Bottom[0]);
                pInfo->content.menu_data.au8Bottom[u8TmpLen] = '\0';
                //msAPI_CI_RemoveControlByte(pInfo->content.menu_data.au8Bottom,++pMMI->content.menu.u8BottomLen);
                CIMMI_DBG(printf("Bottom: %s\n",pInfo->content.menu_data.au8Bottom));
            }
            pBuf = pInfo->content.menu_data.aStringContent;
            for (i = 0; i < pMMI->content.menu.u8Choice_nb; i++)
            {
                U16 u16StringLen;

                if (i == pMMI->content.menu.u8Choice_nb - 1)
                    u16StringLen =  pMMI->content.menu.pStringEnd - pMMI->content.menu.pString[i];
                else
                    u16StringLen = pMMI->content.menu.pString[i+1] - pMMI->content.menu.pString[i];

                //memcpy(&pBuf[u16Len],pMMI->content.menu.pString[i],u16StringLen);
                //We should follow SI character table, to translate various character.
                U8 u8TmpLen;
                u8TmpLen = MApp_SI_GetString(&pBuf[u16Len], u16StringLen, pMMI->content.menu.pString[i], u16StringLen, pMMI->content.menu.pString[i][0]);
                pBuf[u16Len+u8TmpLen] = '\0';

                u16TmpLen = u8TmpLen+1;
                pInfo->content.menu_data.pString[i] = &pBuf[u16Len];
                {
                    U16 j;
                    for(j = 0; j < u16StringLen; j++)
                    {
                        CIMMI_DBG(printf("%c",pInfo->content.menu_data.pString[i][j]));
                    }
                    CIMMI_DBG(printf("\n"));
                }
                u16Len += u16TmpLen;
            }
            pInfo->content.menu_data.ListCnt = pMMI->content.menu.u8Choice_nb; //adam test
            break;
        case EN_MMI_TYPE_LIST:
            CIMMI_DBG(printf("LIST\n"));
            pInfo->enType = EN_CIMMI_TYPE_LIST;
            if (pMMI->content.list.u16TitleLen)
            {
                //memcpy(pInfo->aTitleContent,pMMI->content.list.pu8Title,pMMI->content.list.u8TitleLen);
                //We should follow SI character table, to translate various character.
                U8 u8TmpLen;
                u8TmpLen = MApp_SI_GetString(pInfo->aTitleContent, pMMI->content.list.u16TitleLen, pMMI->content.list.pu8Title, pMMI->content.list.u16TitleLen, pMMI->content.list.pu8Title[0]);
                pInfo->aTitleContent[u8TmpLen] = '\0';
                //msAPI_CI_RemoveControlByte(pInfo->aTitleContent,pMMI->content.list.u8TitleLen + 1);
            }

            if (pMMI->content.list.u16SubtitleLen)
            {
                //memcpy(pInfo->content.list_data.au8Subtitle, pMMI->content.list.pu8Subtitle,pMMI->content.list.u8SubtitleLen);
                //We should follow SI character table, to translate various character.
                U8 u8TmpLen;
                u8TmpLen = MApp_SI_GetString(pInfo->content.list_data.au8Subtitle, pMMI->content.list.u16SubtitleLen, pMMI->content.list.pu8Subtitle, pMMI->content.list.u16SubtitleLen, pMMI->content.list.pu8Subtitle[0]);
                pInfo->content.list_data.au8Subtitle[u8TmpLen] = '\0';
                //msAPI_CI_RemoveControlByte(pInfo->content.list_data.au8Subtitle,++pMMI->content.list.u8SubtitleLen);
                CIMMI_DBG(printf("Subtitle %s\n",pInfo->content.list_data.au8Subtitle));
            }

            if (pMMI->content.list.u16BottomLen)
            {
                //memcpy(pInfo->content.list_data.au8Bottom, pMMI->content.list.pu8Bottom, pMMI->content.list.u8BottomLen);
                //We should follow SI character table, to translate various character.
                U8 u8TmpLen;
                u8TmpLen = MApp_SI_GetString(pInfo->content.list_data.au8Bottom, pMMI->content.list.u16BottomLen, pMMI->content.list.pu8Bottom, pMMI->content.list.u16BottomLen, pMMI->content.list.pu8Bottom[0]);
                pInfo->content.list_data.au8Bottom[u8TmpLen] = '\0';
                //msAPI_CI_RemoveControlByte(pInfo->content.list_data.au8Bottom,++pMMI->content.list.u8BottomLen);
                CIMMI_DBG(printf("Bottom %s\n",pInfo->content.list_data.au8Bottom));
            }
            pBuf = pInfo->content.list_data.aStringContent;

         if((pMMI->content.list.pStringEnd - pMMI->content.list.pString[0]) < MAX_CIMMI_TEXT_SIZE)
            {
            for (i = 0; i < pMMI->content.list.u8Choice_nb; i++)
            {
                U16 u16StringLen;

                if (i == pMMI->content.list.u8Choice_nb - 1)
                    u16StringLen =  pMMI->content.list.pStringEnd - pMMI->content.list.pString[i];
                else
                    u16StringLen = pMMI->content.list.pString[i+1] - pMMI->content.list.pString[i];

                //memcpy(&pBuf[u16Len],pMMI->content.menu.pString[i],u16StringLen);
                //We should follow SI character table, to translate various character.
                U8 u8TmpLen;
                u8TmpLen = MApp_SI_GetString(&pBuf[u16Len], u16StringLen, pMMI->content.list.pString[i], u16StringLen, pMMI->content.list.pString[i][0]);
                pBuf[u16Len+u8TmpLen] = '\0';

                u16TmpLen = u8TmpLen+1;
                pInfo->content.list_data.pString[i] = &pBuf[u16Len];
                {
                    U16 j;
                    for(j = 0; j < u16StringLen; j++)
                    {
                        CIMMI_DBG(printf("%c",pInfo->content.list_data.pString[i][j]));
                    }
                    CIMMI_DBG(printf("\n"));
                }
                u16Len += u16TmpLen;
            }
            pInfo->content.list_data.ListCnt = pMMI->content.list.u8Choice_nb; //adam test
         }
         else
         {
             printf("[file:%s][line:%d]CIMMI content is too large, skip!!!\n", __FILE__, __LINE__);
          pInfo->content.list_data.ListCnt = 0; //adam test
         }

            break;
        default:
            break;
    }
    msAPI_CI_MMIDoneEvent(u8Event);
    msAPI_CI_MMIFreeData(pMMI);

    #if ENABLE_AUTOTEST
    if(g_bAutobuildDebug)
    {
        printf("CI Information display finish\n");
    }
    #endif

    return TRUE;
}

BOOLEAN MMI_SelectItem(S8 s8ItemIndex) //[in] s8ItemIndex for menu item index, -1 for back to prev menu
{
    //printf("[]select=%bd\n", s8ItemIndex);
    msAPI_CI_MMIAnswerMenu(s8ItemIndex+1);
    return TRUE;
}

BOOLEAN MMI_BackENQ( void )
{
    msAPI_CI_MMICancelEnq();
    return TRUE;
}
BOOLEAN MMI_InputENQ(U8 * pu8Code) //[in] pu8Code for user input PIN code, NULL for cancel
{
    //U8 u8Code[MAX_ENQ_LENGTH+1];
    //printf("[]enq=%u\n", u16Code);

    if(pu8Code == NULL) // User press exit
    {
        msAPI_CI_MMIAnswerEnq(NULL,0);
        MMI_SelectItem(-1);
    }
    else
    {
        /*
        sprintf(&u8Code[0],"%bu",(((U8)(u16Code >> 12))&0xF));
        sprintf(&u8Code[1],"%bu",(((U8)(u16Code >> 8))&0xF));
        sprintf(&u8Code[2],"%bu",(((U8)(u16Code >> 4))&0xF));
        sprintf(&u8Code[3],"%bu",(((U8)(u16Code >> 0))&0xF));
        */
        //sprintf(u8Code,"%04x", u16Code);
        //printf("Code: %s\n",pu8Code);
        msAPI_CI_MMIAnswerEnq(pu8Code,(U8)strlen((char*)pu8Code));
    }
    return TRUE;
}

void MMI_MessageHandle(void)
{
    // Marked it by coverity_0315
    //unsigned char   bCleanFlag = FALSE;
    E_CIMSG_TYPE CIMsgType = msAPI_CI_GetCIMessageType();

    if(
#if ENABLE_PVR
		(MApp_PVR_IsPlaybacking() || MApp_PVR_IsRecording())||MApp_TopStateMachine_GetTopState() == STATE_TOP_PVR||
#endif
	    (MApp_ZUI_GetActiveOSD() == E_OSD_DTV_MANUAL_TUNING) || (STATE_TOP_DTV_SCAN == MApp_TopStateMachine_GetTopState())||(STATE_TOP_ATV_SCAN == MApp_TopStateMachine_GetTopState())
	   )
    {
        return;
    }

    if ( CIMsgType != EN_CIMSG_NONE )
    {
        if(EN_CIMSG_DETECTED == CIMsgType)
        {
            u8CardDetectCnt ++;
            if(u8CardDetectCnt > 1)
            {
                MApp_ZUI_ACT_StartupOSD(E_OSD_CIMMI);
                u8CardDetectCnt = 0;
            }
            else
                return;
        }
        else
            MApp_ZUI_ACT_StartupOSD(E_OSD_CIMMI);
    }
    switch ( CIMsgType )
    {
        case EN_CIMSG_REMOVED:
        case EN_CIMSG_DETECTED:
        case EN_CIMSG_INVALID:
            if (CIMsgType == EN_CIMSG_REMOVED)
            {
                MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_SHOW_CI_REMOVED_MSGBOX);
            }
            else if(CIMsgType == EN_CIMSG_DETECTED)
            {
                MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_SHOW_CI_DETECTED_MSGBOX);
            }

            //MMI_DBG( printf( "Draw Message Type:%bu\n", CIMsgType) );

            //if (MApp_TTX_IsTeletextOn())
                //MApp_TTX_TeletextCommand(TTX_TV);

        #if (MHEG5_ENABLE && CIPLUS_MHEG)
            if (msAPI_CI_GetCIMessageType() == EN_CIMSG_REMOVED && msAPI_IsCIMHEGRun() == E_MHEG_CI_RUNNING)
            {
                MApp_MHEG5_Force_Exit();
                enCheckMHEGLoadingStatus = EN_MHEG5_MONITOR;
            }
        #endif
            msAPI_CI_SetCIMessageType(EN_CIMSG_NONE);
            break;

        case EN_CIMSG_NOMODULE:
        case EN_CIMSG_TRYAGAIN:
            if (CIMsgType == EN_CIMSG_NOMODULE)
            {
                MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_SHOW_CI_NO_MODULE_MSGBOX);
            }
            else if(CIMsgType==EN_CIMSG_TRYAGAIN)
            {
                MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_SHOW_CI_TRY_AGAIN_MSGBOX);
            }

            msAPI_CI_SetCIMessageType(EN_CIMSG_NONE);
            break;

        //case EN_CIMSG_LOADINFO:
            //MMI_DBG( printf( "Draw Message Type:%bu\n", CIMsgType) );
            //MMI_DrawBitmapMessage( CIMsgType );
            //msAPI_CI_SetCIMessageType(EN_CIMSG_LOAD_NONE);
            //break;

        //case EN_CIMSG_LOAD_NONE:
       //    msAPI_CI_SetCIMessageType(EN_CIMSG_TRYAGAIN);

       //     break;
        default:
        case EN_CIMSG_NONE:
            break;
    }
}

BOOL MApp_CI_Date_SendDateTime(void)
{
    U32 u32CurrentSysime = MApp_GetLocalSystemTime();
    U8 au8CurrentUTCTime[5] = { 0x00 };
    MApp_Seconds2MJDUTC(u32CurrentSysime, au8CurrentUTCTime);

#if (!ENABLE_CI_PLUS)
    return msAPI_CI_DT_SendUTC(au8CurrentUTCTime);
#else
    static U16 u16HostInitUTCTime = 0xACCF;    // valid from 1980/01/01(0xAC, 0xCF).
    U16 u16UTCTime = 0;
    U16 u16CachedUTCTime = 0;
    ST_TIME CI_DT_Time;

    u16UTCTime = ((U16)au8CurrentUTCTime[0] << 8) | (U16)au8CurrentUTCTime[1];
    u16CachedUTCTime = ((U16)(stGenSetting.g_CIKeySetting.u8SystemMJDUTC[0]) << 8) | (U16)(stGenSetting.g_CIKeySetting.u8SystemMJDUTC[1]);

    //Fake time for testing key: 2009/12/19 00:00:00
    static U8 u8FakeUTC[5] = { 0xD7, 0x90, 0x00, 0x00, 0x00 };

    // Fake time for production key: 2010/12/31 00:00:00
    if(msAPI_CI_CC_GetCredentialsType())
    {
        u8FakeUTC[0] = 0xD9;
        u8FakeUTC[1] = 0x09;
    }

    //If current system time <= valid time.
    if(u16UTCTime <= u16HostInitUTCTime)
    {
        //If cached time <= valid time, use fake time.
        if(u16CachedUTCTime <= u16HostInitUTCTime)
        {
            MApp_ConvertSeconds2StTime(MApp_MJDUTC2Seconds(u8FakeUTC), &CI_DT_Time);
            //printf("Fake Time=>DATE : %d/%d/%d \n", CI_DT_Time.u16Year, CI_DT_Time.u8Month, CI_DT_Time.u8Day);

            return msAPI_CI_DT_SendUTC(u8FakeUTC);
        }
        //Else, use cached time.
        else
        {
            MApp_ConvertSeconds2StTime(MApp_MJDUTC2Seconds(stGenSetting.g_CIKeySetting.u8SystemMJDUTC), &CI_DT_Time);
            //printf("Cached Time=>DATE : %d/%d/%d \n", CI_DT_Time.u16Year, CI_DT_Time.u8Month, CI_DT_Time.u8Day);

            return msAPI_CI_DT_SendUTC(stGenSetting.g_CIKeySetting.u8SystemMJDUTC);
        }
    }
    //Otherwise, use system time.
    else
    {
        MApp_ConvertSeconds2StTime(MApp_MJDUTC2Seconds(au8CurrentUTCTime), &CI_DT_Time);
        printf("System Time=>DATE : %d/%d/%d \n", CI_DT_Time.u16Year, CI_DT_Time.u8Month, CI_DT_Time.u8Day);

        if (u16UTCTime != u16CachedUTCTime)
        {
            printf("Update Cached Date\n");
            memcpy(stGenSetting.g_CIKeySetting.u8SystemMJDUTC, au8CurrentUTCTime, 5);
        }

        return msAPI_CI_DT_SendUTC(au8CurrentUTCTime);
    }
#endif
}

#if ENABLE_CI_PLUS
void MApp_CI_HSS_Active_Cb( BOOL bActive )
{
#if (!TS_SERIAL_OUTPUT_IF_CI_REMOVED)
    BOOLEAN bPVRMode = FALSE;
#if ENABLE_PVR
    if ((MApp_PVR_IsPlaybacking() || MApp_PVR_IsRecording()))
    {
        bPVRMode = TRUE;
    }
#endif
    if (msAPI_CI_CardDetect())
    {
        if (FALSE == bActive)
        {
            /* Pass-Through Mode */
            msAPI_Tuner_SetByPassMode(FALSE, bPVRMode);
        }
        else
        {
            /* By-Pass Mode */
            msAPI_Tuner_SetByPassMode(TRUE, bPVRMode);
        }
    }
#else
    if (msAPI_CI_CardDetect())
    {
        if (FALSE == bActive)
        {
            /* Pass-Through Mode */
            msAPI_Tuner_Serial_Control(TRUE);
        }
        else
        {
            /* By-Pass Mode */
            msAPI_Tuner_Serial_Control(FALSE);
        }
    }
#endif
}
#endif  // #if ENABLE_CI_PLUS

#if 0//(ENABLE_DTV)
void MApp_CI_PMT_Parse(U8 *pu8Section)
{
    // Neotion NP4 transcode issue
    #define CIINFO_LENGTH 10
    U8 manufacturer[CIINFO_LENGTH];
    U8 product[CIINFO_LENGTH];
    U8 Info1[CIINFO_LENGTH];


    // Neotion NP4 transcode issue
    // Don't send PMT if it is neotion and content is clear.
    u32ChkTry2ChgMpeg2Time = msAPI_Timer_GetTime0();
    msAPI_CI_GetCIS( manufacturer, CIINFO_LENGTH, product, CIINFO_LENGTH, Info1, CIINFO_LENGTH );
    if(msAPI_CI_GetCardType()               == EN_SMARTCARD_TYPE_NEOTNT &&
       strcmp((char*)manufacturer,"NEOTION")== 0                        &&
       strcmp((char*)product,"NP4")         == 0)
    {
        if(MApp_SI_CheckCurProgScramble() == TRUE)
        {
            //printf("Send PMT\n");
            msAPI_CI_NotifyPMTUpdate(pu8Section,(3 + TSGetBitsFromU16(&pu8Section[1], 0, 0x0FFF)));
        }
    }
    else
    {
        msAPI_CI_NotifyPMTUpdate(pu8Section,(3 + TSGetBitsFromU16(&pu8Section[1], 0, 0x0FFF)));
    }

}
#endif

void MApp_CI_Event_Cb(EN_CI_EVENT etype)
{
    switch(etype)
    {
#if (MHEG5_ENABLE && CIPLUS_MHEG && ENABLE_CI_PLUS)
        case CI_EVENT_APPMMI:    // Wake MHEG5 engine up.
            {
                U32 u32Len = 0;
                U8 *pu8AppMmi = NULL;

                if (msAPI_MHEG5_GetBinStatus() == FALSE)
                {
                    msAPI_MHEG5_Bean_Init();
                }

                // if broadcast mheg is running, insert CI+ will make broadcast mheg leave and run CIMHEG
                if ((msAPI_IsCIMHEGRun() == E_MHEG_CI_OFF) && (msAPI_MHEG5_checkGoBackMHEG5()==true || MApp_MHEG5_CheckGoMHEG5Process()==TRUE))
                {
                    MApi_MHEG5_Disable(EN_MHEG5_DM_DISABLE_AND_WAIT);
                    //msAPI_Timer_Delayms(500);
                }

                enCheckMHEGLoadingStatus = EN_MHEG5_MONITOR;

                pu8AppMmi = msAPI_CI_AppMmiGetBufPtr();
                if(pu8AppMmi != NULL)
                {
                    // allocate buffer for CIMHEG
                    msAPI_MHEG5_AllocateCIMHEGBuffer();

                    u32Len = (U32)pu8AppMmi[0] << 24 |
                        (U32)pu8AppMmi[1] << 16 |
                        (U32)pu8AppMmi[2] << 8 |
                        (U32)pu8AppMmi[3];

                    if (u32Len)
                    {
                        U32 u32BufferAddr = msAPI_MHEG5_GetDLAFBAddress();

                    #ifdef GOP_GWIN_RB2_ADR
                        if (GOP_GWIN_RB2_MEMORY_TYPE & MIU1)
                        {
                            if (MMI_TEXTSTRING_MEMORY_TYPE & MIU1)  // 1 -> 1
                            {
                                msAPI_MIU_Copy((MMI_TEXTSTRING_ADR | MIU_INTERVAL)+0x800, u32BufferAddr, u32Len+4, MIU_SDRAM12SDRAM1);
                            }
                            else    // 0 -> 1
                            {
                                msAPI_MIU_Copy(MMI_TEXTSTRING_ADR+0x800, u32BufferAddr, u32Len+4, MIU_SDRAM02SDRAM1);
                            }
                        }
                        else
                    #endif
                        {
                            if (MMI_TEXTSTRING_MEMORY_TYPE & MIU1)  // 1->0
                            {
                                msAPI_MIU_Copy((MMI_TEXTSTRING_ADR | MIU_INTERVAL)+0x800, u32BufferAddr, u32Len+4, MIU_SDRAM12SDRAM0);
                            }
                            else    // 0->0
                            {
                                msAPI_MIU_Copy(MMI_TEXTSTRING_ADR+0x800, u32BufferAddr, u32Len+4, MIU_SDRAM02SDRAM0);
                            }
                        }

                    #if 0
                        // fEnableSignalMonior will be false when 1st setup (after "Factory Reset")
                        if (u32DSMCC_Start_Timer == 0 && fEnableSignalMonitor == false)
                        {
                            u32DSMCC_Start_Timer = msAPI_Timer_GetTime0();
                        }
                    #endif

                        // wake mheg5 engine up
                        msAPI_MHEG5_SetCIMHEGRun(E_MHEG_CI_TRIGGER);

                    #if CIMHEG_DBG
                        printf("CI+ Request Start ....\n");
                    #endif
                    }
                }
            }
            break;

        case CI_EVENT_APPMMI_FILE:
        case CI_EVENT_APPMMI_DATA:
            {
            #if CIMHEG_DBG
                printf("file ready...\n");
            #endif
                msAPI_MHEG5_SendCIMHEGFileReady();
            }
            break;

        case CI_EVENT_APPMMI_FILE_INQUIRE_OK:
           // msAPI_MHEG5_SendCIMHEGFileExistence(TRUE); //Compile error,check later
            break;

        case CI_EVENT_APPMMI_FILE_INQUIRE_NG:
            //msAPI_MHEG5_SendCIMHEGFileExistence(FALSE);//Compile error,check later
            break;

        case CI_EVENT_APPMMI_NG:
        #if 0
            msAPI_MHEG5_SendCIMHEGFileReady();  // tell data is ready to make engine exit the busy waiting
            msAPI_MHEG5_CIMHEGNG();             // tell cimheg data is NG
            MApp_MHEG5_Force_Exit();            // force exit mheg to do cleaning in housekeeping
        #else
           // msAPI_MHEG5_SendCIMHEGFileNG();//Compile error,check later
        #endif
            break;

        case CI_EVENT_APPMMI_REQ_ABORT:
            {
                if (msAPI_IsCIMHEGRun() == E_MHEG_CI_RUNNING)
                {
                    MApp_MHEG5_Force_Exit();
                    enCheckMHEGLoadingStatus = EN_MHEG5_MONITOR;
                }
            }
            break;

        case CI_EVENT_DT_ENQ:
            MApp_CI_Date_SendDateTime();
            break;

        case CI_EVENT_HC_TUNE:
            {
                U16 u16NetworkID         = 0;
                U16 u16OriginalNetworkID = 0;
                U16 u16TransportStreamID = 0;
                U16 u16ServiceID         = 0;
                if (FALSE == msAPI_CI_HC_GetTuneInfo(&u16NetworkID, &u16OriginalNetworkID, &u16TransportStreamID, &u16ServiceID))
                {
                    MS_DEBUG_MSG(printf( "[%s:%d][Warning!] Fails to get CI HC Tune info!\n", __FILE__, __LINE__ ));
                }
                else
                {
                    if (TRUE != MApp_ChannelChange_ChangeSpeciChannel(u16ServiceID, u16OriginalNetworkID, u16TransportStreamID, TYPE_CHANNEL_CHANGE_SER_ID, TRUE))
                    {
                        MS_DEBUG_MSG(printf( "[%s:%d][Warning!] CI HC Tune NG!\n", __FILE__, __LINE__ ));
                    }
                }
            }
            break;

        case CI_EVENT_HSS:
            MApp_CI_HSS_Active_Cb(msAPI_CI_HSS_Get());
            break;

        case CI_EVENT_CC_CREDENTIALS_LOAD:
            {
                U8 u8aTempBuf[2] = { 0x00 };
                U16 u16CredentialsLength = 0;

                msAPI_Flash_Read( 0x7F0000 + 12, 2, u8aTempBuf );
                u16CredentialsLength = (U16)u8aTempBuf[0] << 8 | (U16)u8aTempBuf[1];

                msAPI_Flash_Read( 0x7F0000 + 12, (U32)u16CredentialsLength, msAPI_CI_CC_GetCredentialsBufferAddr() );
            }
            break;

        case CI_EVENT_CC_KEY_SAVE:
            msAPI_CI_CC_SaveKeyToFlash(stGenSetting.g_CIKeySetting.stKeySetting);
            stGenSetting.g_CIKeySetting.CIKeyCS = 0;
            break;

        case CI_EVENT_CC_KEY_LOAD:
            msAPI_CI_CC_LoadKeyFromFlash(stGenSetting.g_CIKeySetting.stKeySetting);
            break;

        case CI_EVENT_CC_URI:
        {
            U8 u8URI_RCT = 0, u8URI_EMI = 0, u8URI_APS = 0, u8URI_ICT = 0, u8URI_RL = 0;
            static BOOLEAN bMuteEnable = FALSE;

            msAPI_CI_CC_GetURI(&u8URI_RCT, &u8URI_EMI, &u8URI_APS, &u8URI_ICT, &u8URI_RL);
            //printf("RCT|EMI|APS|ICT|RL\n");
            //printf("%02bX|%02bX|%02bX|%02bX|%02bX\n", u8URI_RCT, u8URI_EMI, u8URI_APS, u8URI_ICT, u8URI_RL);
            if (msAPI_CI_CardDetect() && (EN_CI_VERSION_CI_PLUS == msAPI_CI_CC_CAM_Mode()))
            {
                MEMBER_SERVICETYPE bServiceType;
                U16 u16ProgramPosition;

                /* Macrovision. */
                u16ProgramPosition = msAPI_CM_GetCurrentPosition(msAPI_CM_GetCurrentServiceType());
                bServiceType = msAPI_CM_GetCurrentServiceType();
                if (msAPI_CM_GetProgramAttribute(bServiceType, u16ProgramPosition, E_ATTRIBUTE_IS_SCRAMBLED))
                {
                    if ( 0x00 != u8URI_EMI)
                    {
                        /* non Copy Freely */
                        //printf("[CI+] Blocking....");
                        if ( TRUE != bMuteEnable )
                        {
                            msAPI_Scaler_SetCVBSMute(ENABLE, E_VE_MUTE_CI_PLUS, SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW), OUTPUT_CVBS1);
                            msAPI_Scaler_SetCVBSMute(ENABLE, E_VE_MUTE_CI_PLUS, SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW), OUTPUT_CVBS2);
                            msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_CI_MUTEON, E_AUDIOMUTESOURCE_ACTIVESOURCE);
                            bMuteEnable = TRUE;
                        }
                    }
                    else
                    {
                        /* Copy Freely */
                        //printf("[CI+] None Blocking....");
                        if ( TRUE == bMuteEnable )
                        {
                            msAPI_Scaler_SetCVBSMute(DISABLE, E_VE_MUTE_CI_PLUS, SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW), OUTPUT_CVBS1);
                            msAPI_Scaler_SetCVBSMute(DISABLE, E_VE_MUTE_CI_PLUS, SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW), OUTPUT_CVBS2);
                            msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_CI_MUTEOFF, E_AUDIOMUTESOURCE_ACTIVESOURCE);
                            bMuteEnable = FALSE;
                        }
                    }
                }
                else
                {
                    //printf("[CI+] None Blocking....");
                    if ( TRUE == bMuteEnable )
                    {
                        msAPI_Scaler_SetCVBSMute(DISABLE, E_VE_MUTE_CI_PLUS, SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW), OUTPUT_CVBS1);
                        msAPI_Scaler_SetCVBSMute(DISABLE, E_VE_MUTE_CI_PLUS, SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW), OUTPUT_CVBS2);
                        msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_CI_MUTEOFF, E_AUDIOMUTESOURCE_ACTIVESOURCE);
                        bMuteEnable = FALSE;
                    }
                }
            }

            /* SPDIF - SCMS */
            if ((0x00 == u8URI_RCT && 0x00 == u8URI_EMI) || (0x01 == u8URI_RCT && 0x00 == u8URI_EMI))
            {
                /* Freely Copy */
                msAPI_AUD_SPDIF_SetSCMS(1, 0);
            }
            else if (0x00 == u8URI_RCT && 0x01 == u8URI_EMI)
            {
                /* No More Copy */
                msAPI_AUD_SPDIF_SetSCMS(0, 1);
            }
            else if (0x00 == u8URI_RCT && 0x02 == u8URI_EMI)
            {
                /* Once Copy */ /* FIXME_Alec: Because we don't implement CI+ PVR, we don't support Copy Once. */
                //msAPI_AUD_SPDIF_SetSCMS(0, 0);
                msAPI_AUD_SPDIF_SetSCMS(0, 1);
            }
            else if (0x00 == u8URI_RCT && 0x03 == u8URI_EMI)
            {
                /* Never Copy */
                msAPI_AUD_SPDIF_SetSCMS(0, 1);
            }
            else
            {
                MS_DEBUG_MSG(printf("[Warning!] Abnormal URI!\n"));
            }
        }
        break;
#endif

        case CI_EVENT_CAM_DETECT:
        case CI_EVENT_CAM_RESET:
#if ENABLE_CI_PLUS
#if MHEG5_ENABLE
#if CIPLUS_MHEG  // reset MHEG5
            if (msAPI_IsCIMHEGRun() == E_MHEG_CI_RUNNING)
            {
                MApp_MHEG5_Force_Exit();
                enCheckMHEGLoadingStatus = EN_MHEG5_MONITOR;
            }
#endif
#endif
#endif
            break;

        default:
            MS_DEBUG_MSG(printf( "[%s:%d][Warning!] Unknow CI event !!!\n", __FILE__, __LINE__ ));
            break;
    }
}
#endif // (ENABLE_DTV)

#endif  //ENABLE_CI
#undef MAPP_CIMMI_C

