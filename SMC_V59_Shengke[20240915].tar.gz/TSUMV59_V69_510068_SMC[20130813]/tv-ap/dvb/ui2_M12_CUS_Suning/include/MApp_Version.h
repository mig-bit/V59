////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//
/// @file: MApp_Version.h
/// @brief description: This file manages the released sowtware version names.
/// @author: Mstar Semi.
//
////////////////////////////////////////////////////////////////////////////////


#define _CODE_MAIN_VERSION_     "MSTAR.DVBT.CHAKRA2.V00.T01"
#define _CODE_SW_VERSION_       0x0001
#define _CODE_OFFICIAL_VERSION_ "CHAKRA2 v0.01"

//cus_xm gary  20120611 add for factory menu Customer Information

#define _CODE_MAIN_Brand_     		"Pioneer"
#define _CODE_MAIN_SW_VERSION_     "V0.01"
#define _CODE_MODENAME_    		 "LED-42M600"
#define _CODE_SCALER_ 				"MST6931XP"
#define _CODE_PANELTYPE_ 			"TPT420H2-HVD01"


#define _CODE_DATE_             __DATE__  // ANSI format(month dd yyyy)
#define _CODE_DATE2_            __DATE2__ // Short format(mm/dd/yy)
#define _CODE_TIME_             __TIME__


