////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#define MAPP_INPUTSOURCE_MAIN_C

/******************************************************************************/
/*                 Header Files                                               */
/* ****************************************************************************/
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "Board.h"
#include "datatype.h"
#include "MsCommon.h"

#include "apiXC.h"
#include "apiXC_Adc.h"
#include "MApp_GlobalSettingSt.h"

#include "MApp_Exit.h"
#include "MApp_Key.h"
#include "MApp_UiMenuDef.h"
#include "MApp_ZUI_Main.h"
#include "ZUI_tables_h.inl"
#include "MApp_OSDPage_Main.h"
#include "MApp_InputSource_Main.h"

///////////////////////////////////////////////////////////

EN_INPUTSOURCE_STATE enInputSourceState;

//////////////////////////////////////////////////////////
void MApp_InputSource_SetStateFromUSB(void)
{
   enInputSourceState = STATE_INPUTSOURCE_INIT ;
}

EN_RET MApp_InputSource_Main(void)
{
    EN_RET enRetVal =EXIT_NULL;

    switch(enInputSourceState)
    {
        case STATE_INPUTSOURCE_INIT:
            MApp_ZUI_ACT_StartupOSD(E_OSD_INPUT_SOURCE);
            enInputSourceState = STATE_INPUTSOURCE_WAIT;
            break;

        case STATE_INPUTSOURCE_WAIT:
            MApp_ZUI_ProcessKey(u8KeyCode);
            u8KeyCode = KEY_NULL;
            break;

        case STATE_INPUTSOURCE_CLEAN_UP:
            MApp_ZUI_ACT_ShutdownOSD();
            enInputSourceState = STATE_INPUTSOURCE_INIT;
            enRetVal = EXIT_CLOSE;
            break;

        case STATE_INPUTSOURCE_GOTO_STANDBY:
            MApp_ZUI_ACT_ShutdownOSD();
            u8KeyCode = KEY_POWER;
            enRetVal = EXIT_GOTO_STANDBY;
            break;

        case STATE_INPUTSOURCE_GOTO_OSDPAGE:
            MApp_ZUI_ACT_ShutdownOSD();
            enInputSourceState = STATE_INPUTSOURCE_INIT;
            enRetVal = EXIT_GOTO_OSDPAGE;
            break;

        case STATE_INPUTSOURCE_GOTO_MAIN_MENU:
            MApp_ZUI_ACT_ShutdownOSD();
            enInputSourceState = STATE_INPUTSOURCE_INIT;
            enRetVal = EXIT_GOTO_MENU;
            break;

#if ENABLE_DMP
        case STATE_INPUTSOURCE_GOTO_DMP:
            MApp_ZUI_ACT_ShutdownOSD();
            enInputSourceState = STATE_INPUTSOURCE_INIT;
            enRetVal = EXIT_GOTO_DMP;
            break;
#endif

        case STATE_INPUTSOURCE_GOTO_CH_INFO:
            MApp_ZUI_ACT_ShutdownOSD();
            enInputSourceState = STATE_INPUTSOURCE_INIT;
            enRetVal = EXIT_GOTO_INFO;
            break;

#ifdef ENABLE_BT
        case STATE_INPUTSOURCE_GOTO_BT:
            MApp_ZUI_ACT_ShutdownOSD();
            enInputSourceState = STATE_INPUTSOURCE_INIT;
            enRetVal =EXIT_GOTO_BT;
            break;
#endif

#ifdef ENABLE_KTV
        case STATE_INPUTSOURCE_GOTO_KTV:
            MApp_ZUI_ACT_ShutdownOSD();
            enInputSourceState = STATE_INPUTSOURCE_INIT;
            enRetVal =EXIT_GOTO_KTV;
            break;
#endif

#ifdef ENABLE_YOUTUBE
    case STATE_INPUTSOURCE_GOTO_YOUTUBE:
        MApp_ZUI_ACT_ShutdownOSD();
        enInputSourceState = STATE_INPUTSOURCE_INIT;
        enRetVal =EXIT_GOTO_YOUTUBE;
        break;
#endif

#ifdef ENABLE_RSS
    case STATE_INPUTSOURCE_GOTO_RSS:
        MApp_ZUI_ACT_ShutdownOSD();
        enInputSourceState = STATE_INPUTSOURCE_INIT;
        enRetVal =EXIT_GOTO_RSS;
        break;
#endif

//#ifdef ENABLE_NETFLIX
//    case STATE_INPUTSOURCE_GOTO_NETFLIX:
//        MApp_ZUI_ACT_ShutdownOSD();
//        enInputSourceState = STATE_INPUTSOURCE_INIT;
//        enRetVal = EXIT_GOTO_NETFLIX;
//        break;
//#endif

#if (ENABLE_GAME)
    case STATE_INPUTSOURCE_GOTO_GAME:
        {
            extern EN_GAME_STATE enGameState;
            MApp_ZUI_ACT_ShutdownOSD();
            enInputSourceState = STATE_INPUTSOURCE_INIT;
            enGameState=STATE_GAME_INIT;
            enRetVal =EXIT_GOTO_GAME;
        }
        break;
#endif

#ifdef ENABLE_EXTENSION
    case STATE_INPUTSOURCE_GOTO_EXTENSION:
        {
        MApp_ZUI_ACT_ShutdownOSD();
        enInputSourceState = STATE_INPUTSOURCE_INIT;
        enRetVal =EXIT_GOTO_EXTENSION;
        }
        break;
#endif

    default:
        enInputSourceState = STATE_INPUTSOURCE_WAIT;
        break;
    }
    return enRetVal;
}

#undef MAPP_INPUTSOURCE_MAIN_C

