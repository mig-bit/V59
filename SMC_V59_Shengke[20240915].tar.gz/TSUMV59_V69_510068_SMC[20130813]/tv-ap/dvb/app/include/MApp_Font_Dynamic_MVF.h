////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef MAPP_FONT_DYNAMIC_MVF_H
#define MAPP_FONT_DYNAMIC_MVF_H

#define MS_DYNAMIC_FONTSIZE             88
#define MS_DYNAMIC_FONTOUTPUTSIZE       108

#ifdef MAPP_FONT_DYNAMIC_MVF_C
#define INTERFACE
#else
#define INTERFACE extern
#endif

INTERFACE void msAPI_MVF_LoadFont(void);
INTERFACE void Dyx_MVF_LoadFont(U16 *pU16);

#undef INTERFACE
#endif


