////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////
#ifdef ENABLE_BT

#if (ENABLE_THUNDER_DOWNLOAD)

#ifndef _MAPP_THUNDER_MAIN_H
#define _MAPP_THUNDER_MAIN_H

#include "datatype.h"
#include "MApp_Exit.h"
#include "MApp_ZUI_APIcommon.h"

#define MApp_BT_Main            MApp_Thunder_Main
#define MApp_BT_Main_Exit       MApp_Thunder_Main_Exit

#ifdef MAPP_THUNDER_MAIN_C
#define INTERFACE
#else
#define INTERFACE extern
#endif

typedef enum
{
    STATE_THUNDER_INIT,
    STATE_THUNDER_WAIT,
    STATE_THUNDER_CLEAN_UP,
    STATE_THUNDER_GOTO_STANDBY,
    STATE_THUNDER_GOTO_MENU,
    STATE_THUNDER_GOTO_INPUTSOURCE,
    STATE_THUNDER_RETURN_FROM_MENU,
} EN_THUNDER_STATE;

typedef enum
{
    E_THUNDER_FLAG_NONE                     = 0,
    E_THUNDER_FLAG_INITED                   = BIT0,
    E_THUNDER_FLAG_LINK0PHOTO_MODE          = BIT1,
    E_THUNDER_FLAG_LINK1PHOTO_MODE          = BIT2,
    E_THUNDER_FLAG_FILE_DOWNLOADING         = BIT3,
} enumThunderFlags;


//INTERFACE EN_Thunder_SEARCH_STATE enThunderSearchState;
INTERFACE EN_THUNDER_STATE enThunderState;

INTERFACE EN_RET MApp_Thunder_Main(void);
INTERFACE enumThunderFlags MApp_Thunder_GetThunderFlags(void);
INTERFACE void MApp_Thunder_SetLink0Flags(BOOLEAN bEnable);
INTERFACE void MApp_Thunder_SetLink1Flags(BOOLEAN bEnable);
INTERFACE void MApp_Thunder_Main_Exit(void);

#undef INTERFACE

#endif//#ifndef _MAPP_THUNDER_MAIN_H

#endif//#if (ENABLE_THUNDER_DOWNLOAD)
#endif//#ifdef ENABLE_BT

