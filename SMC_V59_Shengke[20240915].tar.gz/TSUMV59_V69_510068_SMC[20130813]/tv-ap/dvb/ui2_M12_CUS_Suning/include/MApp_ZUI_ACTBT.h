////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MAPP_ZUI_ACTBT_H
#define _MAPP_ZUI_ACTBT_H

#include "MApp_BT_config.h"

#if (ENABLE_THUNDER_DOWNLOAD)
#include "MApp_ZUI_ACTThunder.h"

#else

#ifdef __cplusplus
extern "C" {
#endif  /* __cplusplus */

#include "MApp_ZUI_APIgdi.h"

#ifdef MAPP_ZUI_ACTBT_C
#define INTERFACE
#else
#define INTERFACE extern
#endif


/////////////////////////////////////////
// Event Handlers....
INTERFACE S32 MApp_ZUI_ACT_BTTopWinProc(HWND hwnd, PMSG msg);
INTERFACE S32 MApp_ZUI_ACT_BTLinkPhotoWinProc(HWND hwnd, PMSG msg);
INTERFACE S32 MApp_ZUI_ACT_BTDescriptionWinProc(HWND hWnd, PMSG pMsg);
INTERFACE void MApp_ZUI_ACT_AppShowBT(void);
INTERFACE BOOLEAN MApp_ZUI_ACT_HandleBTKey(VIRTUAL_KEY_CODE key);
INTERFACE BOOLEAN MApp_ZUI_ACT_ExecuteBTAction(U16 act);
INTERFACE LPTSTR MApp_ZUI_ACT_GetBTDynamicText(HWND hwnd);
INTERFACE U16 MApp_ZUI_ACT_GetBTDynamicBitmap(HWND hwnd, DRAWSTYLE_TYPE ds_type);
INTERFACE void MApp_ZUI_ACT_TerminateBT(void);
INTERFACE void MApp_UiBT_ClearFocusHwnd(void);
INTERFACE void MApp_ZUI_ACT_AppShowBTSearchResult(void);
INTERFACE void MApp_ZUI_ACT_AppShowDownLoadListResult(HWND hwnd);
INTERFACE void MApp_ZUI_ACT_AppShowToporNewListResult(HWND hwnd);
INTERFACE void MApp_ZUI_ACT_AppShowToporNewListDescription(HWND hwnd);
INTERFACE U16 *MApp_GetSearchStingName(void);
INTERFACE BOOLEAN MApp_ZUI_ACT_BT_SystemErrorCheck(void);
INTERFACE void MApp_ZUI_ACT_AppShowBTSystemError(void);
INTERFACE void MApp_ZUI_ACT_AppShowBTSystemErrorReturn(void);
INTERFACE void MApp_BT_ClearTopOrNewListPhotoBG(U8 u8Item);

#undef INTERFACE

#ifdef __cplusplus
}
#endif  /* __cplusplus */

#endif // #if (ENABLE_THUNDER_DOWNLOAD)

#endif /* _MAPP_ZUI_ACTBT_H */

