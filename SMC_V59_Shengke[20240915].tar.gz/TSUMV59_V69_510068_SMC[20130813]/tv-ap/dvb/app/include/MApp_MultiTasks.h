////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef MAPP_MULTITASKS_H
#define MAPP_MULTITASKS_H


#ifdef MAPP_MULTITASKS_C
#define INTERFACE
#else
#define INTERFACE extern
#endif

typedef enum
{
    EN_5V_AntennaPower_Off,
    EN_5V_AntennaPower_On,
    EN_5V_AntennaPower_Num
} EN_MENU_5V_AntennaPower;

#define DELAY_FOR_REMOVE_SCREENMUTE         20      // for screen mute


INTERFACE void EarPhone_OFF(void);
INTERFACE void EarPhone_ON(void);

INTERFACE bool MApp_MHEG_MultiTasks(void);  // for S4, S4L...
INTERFACE void MApp_MultiTasks(void);
INTERFACE void MApp_Time_Tasks(void);
INTERFACE void MApp_PreProcessUserInput(void);
INTERFACE void MApp_ScreenMuteMonitor(SCALER_WIN eWindow);
INTERFACE void MApp_SDT_ResetRunningStatus(void);

INTERFACE void USB_update_set(bool flag);
INTERFACE void Update_DBUS_init(void);

////////////////////////////////////////////
// Input Source Handler
////////////////////////////////////////////
#if(ENABLE_DTV)
INTERFACE void MApp_DTV_Handler(INPUT_SOURCE_TYPE_t src, BOOLEAN bRealTimeMonitorOnly);
#if ENABLE_SDT_OTHER_MONITOR
INTERFACE void MApp_Update_User_Service(void);
#endif
#endif

INTERFACE void MApp_ATV_Handler(INPUT_SOURCE_TYPE_t src, BOOLEAN bRealTimeMonitorOnly);

//#if ENABLE_DMP
INTERFACE void MApp_Storage_Handler(INPUT_SOURCE_TYPE_t src, BOOLEAN bRealTimeMonitorOnly);
//#endif



#if (ENABLE_MVDMONITOR)
static void MVD_Monitor();
#endif

// 070523_SK 5V Antenna Monitor
INTERFACE void EnableAntenna5VMonitor(BOOLEAN bAntenna5VMonitorOnOff);
INTERFACE void AdjustAntenna5VMonitor(EN_MENU_5V_AntennaPower en5VAntennaOnOff);
INTERFACE BOOLEAN g_bRealTimeMonitorOnly;
#if ENABLE_CI
INTERFACE void MApp_CI_Switch_TS(BOOLEAN bZarLinkReset);
INTERFACE void MApp_CI_Enable_Process(BOOLEAN bEnable);
#endif
INTERFACE void MApp_Set_MonitorParental(BOOLEAN bEnable);
INTERFACE BOOLEAN MApp_Get_MonitorParental(void);
INTERFACE BOOLEAN MApp_Get_ParentalBlock_state(void);
INTERFACE void MApp_Set_ParentalBlock_state(BOOLEAN bEnable);
#if (ENABLE_DTV)
INTERFACE BOOLEAN MApp_GetAutoSystemTimeFlag(void);
#endif
INTERFACE void MApp_SingleListen_ScreenMute_Check(void);
INTERFACE void MApp_Single_Listen_CountDown_Monitor(void);
INTERFACE void MApp_SingleListen_ScreenMute_Clear(void);

#if ENABLE_CUS_BURNING_MODE
INTERFACE void MApp_MultiTasks_AdjustBurningMode(BOOLEAN bEnable);
#endif

#undef INTERFACE
#endif
