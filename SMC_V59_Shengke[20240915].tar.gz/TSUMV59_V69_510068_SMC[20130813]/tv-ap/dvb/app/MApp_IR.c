////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#define MAPP_IR_C

#include <stdio.h>
#include <string.h>
#include "Board.h"
#include "datatype.h"
#include "MsCommon.h"
#include "MsIRQ.h"
#include "MsOS.h"
#include "SysInit.h"

#include "apiXC.h"
#include "apiXC_Adc.h"
#include "MApp_GlobalSettingSt.h"
#include "msAPI_Global.h"
#include "MApp_GlobalFunction.h"

#include "msAPI_ATVSystem.h"
#include "msAPI_DTVSystem.h"
#include "msAPI_IR.h"
#include "msAPI_Timer.h"
#include "msAPI_Power.h"
#include "drvUartDebug.h"

//#if (DEBUG_SYS_INFO_REPORT && MHEG5_ENABLE)
#if (MHEG5_ENABLE)
#include "msAPI_MHEG5.h"
#endif

#include "MApp_GlobalVar.h"
#include "MApp_Key.h"
#include "MApp_IR.h"
#include "MApp_DataBase.h"
#include "MApp_Sleep.h"
#include "MApp_SaveData.h"
#include "MApp_ATVProc.h"
#include "MApp_ZUI_Main.h"
#include "ZUI_tables_h.inl"
#include "ZUI_exefunc.h"
#include "MApp_UiMenuDef.h" //ZUI: #include "MApp_UiMenu.h"
#include "MApp_Main.h"

#if MHEG5_ENABLE
#include "MApp_ChannelChange.h"
#endif

//CEC
#if ENABLE_CEC
#include "msAPI_CEC.h"
#endif

//MHL
#if (ENABLE_MHL == ENABLE)
#include "msAPI_MHL.h"
#endif

#include "mstar_debug.h"
#include "msIR.h"
#include "GPIO.h"
#include "MApp_TopStateMachine.h"

#include "msAPI_Tuning.h"
#include "mapp_videoplayer.h"
#include "MApp_RestoreToDefault.h"
#include "MApp_ZUI_ACTmenufunc.h"
#include "MApp_BlockSys.h"

#include "cusFactoryIR.h"

#include "MApp_ZUI_ACTdmp.h"

#ifndef SCAN_TEST_MODE_ENABLE
#define SCAN_TEST_MODE_ENABLE 0
#endif

#if CUS_SMC_ENABLE_HOTEL_MODE
#include <MApp_ZUI_ACTmainpage.h>
static U32 _u32LaunchKeys_rclock_hotelmode;
static U32 _u32LaunchKeys_osd_lock_hotelmode;
#include <MApp_ZUI_ACTglobal.h>
#include <MApp_ZUI_APIcommon.h>
#include <MApp_ZUI_ACTfactorymenu.h>
//static U16 u16MenuKeyCounter = 0;
//extern BOOLEAN MApp_ZUI_ACT_HandleGlobalKey(VIRTUAL_KEY_CODE key);
#endif
#include "MApp_Menu_Main.h"
//==============================================================================
/*                                 Macro                                        */
//==============================================================================
#define CUSTOM_CODE 0xAB
#define KEY_DEBUG(y)            y //minglin1205
#define DEBUG_OBAMA_KEY 0

//==============================================================================
/*                                 Local                                        */
//==============================================================================
static void MApp_ParseKey(void);
static void MApp_CheckKeyStatus(void);
static void MApp_SetKeyRepeatState(U8 u8KeyData);

static KEYSTAT stKeyStatus;

#define OSD_REPEAT_MASK     (BIT1|BIT0)
#define OSD_REPEAT_DISABLE  (0x00)
#define OSD_REPEAT_H_ENABLE (BIT0)
#define OSD_REPEAT_V_ENABLE (BIT1)
#define OSD_REPEAT_ENABLE   (BIT1|BIT0)

static U8 u8KeyRepeatState = OSD_REPEAT_ENABLE;
static U8 u8HwDebugFlag = 0;

#if (IR_MODE_SEL == IR_TYPE_FULLDECODE_MODE)
extern U8 u8IRTimerBlockstatus;
#endif

extern BOOL g_isCVBS2;
#if (FRONTEND_IF_DEMODE_TYPE == MSTAR_VIF_MSB1210) // GEM_SYNC_0815
#define MSTAR_VIF_MSB1210_DEBUG_MODE      0
#define GEMINI_KEY_NONE                   0
#define GEMINI_KEY_WAIT_1                 1
#define GEMINI_KEY_WAIT_2                 2
#define GEMINI_KEY_WAIT_3                 3
#define GEMINI_GET_KEY_1                  1
#define GEMINI_GET_KEY_2                  2

U8 gGemini_KeyState            =0;
U8 gGemini_FactoryMode_Enable  =0;
U8 gGemini_GetKey              =0;
U8 gGemini_KeyValue            =0;
extern U8 gVifTop;

#if (FRONTEND_IF_DEMODE_TYPE == MSTAR_VIF)
extern void msVifTopAdjust(void);
#endif

#if (FRONTEND_IF_DEMODE_TYPE == MSTAR_VIF_MSB1210)
extern BOOL msVifTopAdjust(BYTE ucVifTop);
#endif

extern U8 MApp_ProcessUserInput_MSVIF_Debug(U8 keycode);
#endif // #if (FRONTEND_IF_DEMODE_TYPE == MSTAR_VIF_MSB1210)

extern void MApp_SingleListen_ScreenMute_Check(void);


static ST_MBIR mbir;

#if ENABLE_AUTOTEST
extern BOOLEAN g_bAutobuildDebug;
#endif

#if (ENABLE_MSTV_UART_DEBUG && ENABLE_MMS)
extern U8 g_DisableIr;
#endif

BOOLEAN   MenuKeyState = 1;

BOOLEAN MApp_isKeypadSourceKeyCanSelect(void)
{
    /*/ZUI_TODO:
    if((g_u8MenuPageIndex == MENU_SETUP_A1_Scan_CheckMenu)||
        (g_u8MenuPageIndex == MENU_SETUP_A1_Scan_ConfirmMsg_SkipATV)||
        (g_u8MenuPageIndex == MENU_SETUP_A1_Scan_ConfirmMsg_SkipDTV)||
        (g_u8MenuPageIndex == MENU_CHANNEL_DTV_ManualScan)||
        (g_u8MenuPageIndex == MENU_OPTION_FACTORY_RESET)||  //Restore to default
        (g_u8MenuPageIndex == MENU_TIME_D1_Clock)|| // Cur timer's close option
        (g_u8MenuPageIndex == MENU_TIME_D2_OffTimer)||// off timer 's close option
        (g_u8MenuPageIndex == MENU_TIME_D3_OnTimer)// on timer 's close option
        )
            return TRUE;
    else
            return FALSE;
    */
    return FALSE;
}

/******************************************************************************/
/*                             Functions                                      */
/******************************************************************************/

#ifdef SUPPORT_IR_CUS_FACTORY
BOOLEAN Mapp_CheckFactoryKey(U8 RCkey)
{
    if(IsStorageInUse())
    {
        switch(RCkey)
        {
            case IR_CUS_FACTORY_KEY_TEST:
            case IR_CUS_FACTORY_KEY_RST:
            case IR_CUS_FACTORY_KEY_FAC:
            case IR_CUS_FACTORY_KEY_CSM:
            case IR_CUS_FACTORY_KEY_PATTERN:
            case IR_CUS_FACTORY_KEY_NUM_0:
            case IR_CUS_FACTORY_KEY_NUM_1:
            case IR_CUS_FACTORY_KEY_NUM_2:
            case IR_CUS_FACTORY_KEY_NUM_3:
            case IR_CUS_FACTORY_KEY_NUM_4:
            case IR_CUS_FACTORY_KEY_NUM_5:
            case IR_CUS_FACTORY_KEY_NUM_6:
            case IR_CUS_FACTORY_KEY_NUM_7:
            case IR_CUS_FACTORY_KEY_NUM_8:
            case IR_CUS_FACTORY_KEY_NUM_9:
            case IR_CUS_FACTORY_KEY_AIRCABLE:
            case IR_CUS_FACTORY_KEY_PRE_CH:
            case IR_CUS_FACTORY_KEY_VOL_MAX:
            case IR_CUS_FACTORY_KEY_VOL_BUZZ:
            case IR_CUS_FACTORY_KEY_CTC:
            case IR_CUS_FACTORY_KEY_MENU:
            case IR_CUS_FACTORY_KEY_CH_ADD:
            case IR_CUS_FACTORY_KEY_CH_SUB:
            case IR_CUS_FACTORY_KEY_BURNIN:
            case IR_CUS_FACTORY_KEY_CH_SCAN:
            case IR_CUS_FACTORY_KEY_VOL_LEFT:
            case IR_CUS_FACTORY_KEY_VOL_RIGHT:
            case IR_CUS_FACTORY_KEY_DOWN:
            case IR_CUS_FACTORY_KEY_UP:
            case IR_CUS_FACTORY_KEY_ENTER:
            case IR_CUS_FACTORY_KEY_CCTT:
            case IR_CUS_FACTORY_KEY_MUTE:
            case IR_CUS_FACTORY_KEY_LOG_LED:
            case IR_CUS_FACTORY_KEY_PIC:
            case IR_CUS_FACTORY_KEY_AUDIO:
            case IR_CUS_FACTORY_KEY_2D3D:
            case IR_CUS_FACTORY_KEY_ARC:
            case IR_CUS_FACTORY_KEY_CI_ADD:
            case IR_CUS_FACTORY_KEY_VIRG_IN:
            case IR_CUS_FACTORY_KEY_REGIN:
            case IR_CUS_FACTORY_KEY_CLONE:
            case IR_CUS_FACTORY_KEY_CLK:
            case IR_CUS_FACTORY_KEY_DCR:
            case IR_CUS_FACTORY_KEY_ADC:
            case IR_CUS_FACTORY_KEY_BLK:
            case IR_CUS_FACTORY_KEY_WP:
            case IR_CUS_FACTORY_KEY_LIGHT_SENSOR:
            case IR_CUS_FACTORY_KEY_RJ45:
            case IR_CUS_FACTORY_KEY_RS232:
            case IR_CUS_FACTORY_KEY_NULL_KEY:
                stKeyStatus.keydata=IRKEY_DUMY;
                return FALSE;
            default:
                break;
        }

    }
	switch(RCkey)
	{
		case IR_CUS_FACTORY_KEY_NUM_0:
            stKeyStatus.keydata=IRKEY_NUM_0;
            return FALSE;
            break;
		case IR_CUS_FACTORY_KEY_NUM_1:
            stKeyStatus.keydata=IRKEY_NUM_1;
            return FALSE;
            break;
		case IR_CUS_FACTORY_KEY_NUM_2:
            stKeyStatus.keydata=IRKEY_NUM_2;
            return FALSE;
            break;
		case IR_CUS_FACTORY_KEY_NUM_3:
            stKeyStatus.keydata=IRKEY_NUM_3;
            return FALSE;
            break;
		case IR_CUS_FACTORY_KEY_NUM_4:
            stKeyStatus.keydata=IRKEY_NUM_4;
            return FALSE;
            break;
		case IR_CUS_FACTORY_KEY_NUM_5:
            stKeyStatus.keydata=IRKEY_NUM_5;
            return FALSE;
            break;
		case IR_CUS_FACTORY_KEY_NUM_6:
            stKeyStatus.keydata=IRKEY_NUM_6;
            return FALSE;
            break;
		case IR_CUS_FACTORY_KEY_NUM_7:
            stKeyStatus.keydata=IRKEY_NUM_7;
            return FALSE;
            break;
		case IR_CUS_FACTORY_KEY_NUM_8:
            stKeyStatus.keydata=IRKEY_NUM_8;
            return FALSE;
            break;
		case IR_CUS_FACTORY_KEY_NUM_9:
            stKeyStatus.keydata=IRKEY_NUM_9;
            return FALSE;
            break;
		case IR_CUS_FACTORY_KEY_MENU:
            stKeyStatus.keydata=IRKEY_MENU;
            return FALSE;
            break;
		case IR_CUS_FACTORY_KEY_CH_ADD:
            stKeyStatus.keydata=IRKEY_CHANNEL_PLUS;
            return FALSE;
            break;
		case IR_CUS_FACTORY_KEY_CH_SUB:
            stKeyStatus.keydata=IRKEY_CHANNEL_MINUS;
            return FALSE;
            break;
		case IR_CUS_FACTORY_KEY_UP:
            stKeyStatus.keydata=IRKEY_UP;
            return FALSE;
            break;
		case IR_CUS_FACTORY_KEY_DOWN:
            stKeyStatus.keydata=IRKEY_DOWN;
            return FALSE;
            break;
		case IR_CUS_FACTORY_KEY_ENTER:
            stKeyStatus.keydata=IRKEY_SELECT;
            return FALSE;
            break;
		case IR_CUS_FACTORY_KEY_MUTE:
            stKeyStatus.keydata=IRKEY_MUTE;
            return FALSE;
            break;
		//case IR_CUS_FACTORY_KEY_PIC: stKeyStatus.keydata=IRKEY_PICTURE;return FALSE;break;
		//case IR_CUS_FACTORY_KEY_AUDIO: stKeyStatus.keydata=IRKEY_AUDIO;return FALSE;break;
		case IR_CUS_FACTORY_KEY_CVBS:
            stKeyStatus.keydata=IRKEY_AV;
            return FALSE;
            break;
		case IR_CUS_FACTORY_KEY_YPBPRSCART:
            stKeyStatus.keydata=IRKEY_COMPONENT;
            return FALSE;
            break;
		case IR_CUS_FACTORY_KEY_HDMI:
            stKeyStatus.keydata=IRKEY_HDMI;
            return FALSE;
            break;
		case IR_CUS_FACTORY_KEY_VGA:
            stKeyStatus.keydata=IRKEY_PC;
            return FALSE;
            break;
		case IR_CUS_FACTORY_KEY_CCTT:
            stKeyStatus.keydata=IRKEY_CC;
            return FALSE;
            break;
		 case IR_CUS_FACTORY_KEY_USB:
            stKeyStatus.keydata=IRKEY_DMP;
            return FALSE;
            break;

		default:
			return TRUE;
	}
}
#endif

static void MApp_IR_Custome_IRkeyFilter(void)
{
#if ENABLE_INPUT_LOCK
    if ( MApp_UiMenuFunc_CheckInputLock())
    {
        switch(u8KeyCode)
        {
            case KEY_CHANNEL_PLUS:
            case KEY_CHANNEL_MINUS:
            case KEY_CHANNEL_RETURN:
                if(IsAnyTVSourceInUse() && (g_u16PasswordCheckSource & INPUT_BLOCK_TV))
                {
                    u8KeyCode = KEY_NULL;
                }
                break;
            case KEY_EPG:
            case KEY_VOLUME_PLUS:
            case KEY_VOLUME_MINUS:
            case KEY_CHANNEL_LIST:
            case KEY_CHANNEL_FAV_LIST:
            //case KEY_INFO:  //cus_xm:zb modify at 2012-7-21
            case KEY_CC:
            case KEY_PICTURE:
            case KEY_AUDIO:
            case KEY_ZOOM:
                if(MApp_UiMenuFunc_CheckInputLockAudioVideo())
                {
                    u8KeyCode = KEY_NULL;
                }
                break;
            default:
                break;
        }

    }
#endif
}


extern BOOLEAN MApp_SleepCountWinShow(void);
static void MApp_ParseKey(void)
{
	//static U8 videosource=0;
	//static U8 pcsource=0;
	static U32  WaitTime=0;
	static U8 key=0;
#if ENABLE_AUTOTEST
    if(g_bAutobuildDebug)
    {
        return;
    }
#endif

#if (ENABLE_MSTV_UART_DEBUG && ENABLE_MMS)
    if (g_DisableIr)
    {
        return;
    }
#endif

#if (ENABLE_CUS_BURNING_MODE)
	if (stGenSetting.g_FactorySetting.fBuringMode && !MApp_IsSrcHasSignal(MAIN_WINDOW))
	{
		if ((stKeyStatus.keydata == IRKEY_POWER)&&(stKeyStatus.keytype==0))
		{
			u8KeyCode = KEY_POWER;
			return;
		}
		else if(MApp_ZUI_GetActiveOSD() != E_OSD_FACTORY_MENU)
		{
			u8KeyCode = KEY_NULL;
			return;
		}
	}
#endif

    MWDBGprintf(MWDBG_KEYINPUT, MWDBGLVL_STATUS_B, "IR:%02dh\n", (int)stKeyStatus.keydata);

    if(stKeyStatus.keydata != 0xff)
    {
        if(stKeyStatus.keytype == KEY_TYPE_KEYPAD)
        {
            KEY_DEBUG(printf("IR-keydata[%x],--Keypad! \n",stKeyStatus.keydata));
        }
        else
        {
                printf("IR-keydata[%x],--IR! \n",stKeyStatus.keydata);
			//u16MenuKeyCounter = 0;
            WaitTime=msAPI_Timer_GetSystemTime();
			
			    if(stKeyStatus.keydata!=key)
				{
				printf("!!!!!!IR-keydata[%x],--IR! \n",stKeyStatus.keydata);
				stKeyStatus.KeydataCnt++;
				//if((msAPI_Timer_GetSystemTime() - WaitTime) >= 100UL)
				if(stKeyStatus.KeydataCnt>1)
					{
				key=stKeyStatus.keydata;
				stKeyStatus.KeydataCnt=0;
				printf("!!!!!!aaaaaIR-keydata[%x],--IR! \n",stKeyStatus.keydata);
					}
				  else
				  	stKeyStatus.keydata=KEY_NULL;
				}
			    else//if((stKeyStatus.keydata==key)&&(stKeyStatus.KeydataCnt==0))
				{
                //if((msAPI_Timer_GetSystemTime() - WaitTime) >= 1000ul)
                stKeyStatus.KeydataCnt++;
				if(stKeyStatus.KeydataCnt>1)
                {
              	key=stKeyStatus.keydata;
				stKeyStatus.KeydataCnt=0;
				}
				else
					stKeyStatus.keydata=KEY_NULL;

				printf("!!!!!!444IR-keydata[%x],--IR! \n",stKeyStatus.keydata);
			   }
			     if((stKeyStatus.KeydataCnt==1)&&((msAPI_Timer_GetSystemTime() - WaitTime) >= 1000ul))
                {
					
									key=stKeyStatus.keydata;
									stKeyStatus.KeydataCnt=0;

							printf("!!!!!!333IR-keydata[%x],--IR! \n",stKeyStatus.keydata);
				}
             
		   
        }
    }
//========================================================================
//add for hotel menu's local key lock @zhihe 2012-08-21 @chuxu modify 2012-08-23
#ifdef ENABLE_BUTTON_LOCK
	#if CUS_SMC_ENABLE_HOTEL_MODE
		if(stGenSetting.g_FactorySetting.HotelMenuHotelModeOperationEnable == ENABLE)
			{
				//if local keypad is unlocked, button key menu 5sec, to lock local keypad
				if((stGenSetting.g_SysSetting.g_enKeyPadLock == EN_E5_KeyLock_Off)&&(stKeyStatus.keytype == KEY_TYPE_KEYPAD))
					{   if(stKeyStatus.keyrepeat==1)
					    {
							if(stGenSetting.g_FactorySetting.HotelMenuMenuKeyPressFlag==0XFF)
								{
								   // stGenSetting.g_FactorySetting.HotelMenuMenuKeyPressTime++;
								   if(stGenSetting.g_FactorySetting.HotelMenuMenuKeyPressTime>=25)
								   {
								     stGenSetting.g_SysSetting.g_enKeyPadLock = EN_E5_KeyLock_On;
									 stGenSetting.g_FactorySetting.HotelMenuMenuKeyPressFlag=0;
									 stGenSetting.g_FactorySetting.HotelMenuMenuKeyPressTime=0;
									 MenuKeyState = 1;

                                     MApp_ZUI_ACT_ShutdownOSD();//close current main menu osd
									 u8KeyCode = KEY_BUTTON_LOCK_HOTEL_MODE;
									 u8KeyRepeatState = OSD_REPEAT_DISABLE;
									 return;
								   }
								   if(MenuKeyState == 0)//can not open main menu state
								   	{
										 u8KeyCode = KEY_BUTTON_UNLOCK_HOTEL_MODE;
										 u8KeyRepeatState = OSD_REPEAT_DISABLE;
										 return;
								   	}
								}
					    }
						else if(stKeyStatus.keyrepeat==0)
							 {
									 stGenSetting.g_FactorySetting.HotelMenuMenuKeyPressFlag=0;
									 stGenSetting.g_FactorySetting.HotelMenuMenuKeyPressTime=0;
									 MenuKeyState = 1;
							 }
						else if(stGenSetting.g_FactorySetting.HotelMenuMenuKeyPressFlag==0X0)
							{
									 stGenSetting.g_FactorySetting.HotelMenuMenuKeyPressFlag=0;
									 stGenSetting.g_FactorySetting.HotelMenuMenuKeyPressTime=0;
									 MenuKeyState = 1;
							}
					}
				//if local keypad is locked, button key menu 5sec, to unlock local keypad
				else if((stGenSetting.g_SysSetting.g_enKeyPadLock == EN_E5_KeyLock_On) && (stKeyStatus.keytype == KEY_TYPE_KEYPAD))
					{   if(stKeyStatus.keyrepeat==1)
					    {
							if(stGenSetting.g_FactorySetting.HotelMenuMenuKeyPressFlag==0XFF)
								{
								   //stGenSetting.g_FactorySetting.HotelMenuMenuKeyPressTime++;
								   if(stGenSetting.g_FactorySetting.HotelMenuMenuKeyPressTime>=25)
								   {
								     stGenSetting.g_SysSetting.g_enKeyPadLock = EN_E5_KeyLock_Off;
									 stGenSetting.g_FactorySetting.HotelMenuMenuKeyPressFlag=0;
									 stGenSetting.g_FactorySetting.HotelMenuMenuKeyPressTime=0;
									 MenuKeyState = 0;//can not open main menu state

									 u8KeyCode = KEY_BUTTON_UNLOCK_HOTEL_MODE;
									 u8KeyRepeatState = OSD_REPEAT_DISABLE;
									 return;
								   }
								}

								u8KeyCode = KEY_BUTTON_LOCK_HOTEL_MODE;
								u8KeyRepeatState = OSD_REPEAT_DISABLE;
								return;
					    }
			            else if(stKeyStatus.keyrepeat==0)
					     	 {
					     	   		 stGenSetting.g_FactorySetting.HotelMenuMenuKeyPressFlag=0;
									 stGenSetting.g_FactorySetting.HotelMenuMenuKeyPressTime=0;

									 if(stKeyStatus.keydata == IRKEY_POWER)//button power key, off DC
										{
											u8KeyCode = KEY_POWER;
											return;
										}

									 u8KeyCode = KEY_BUTTON_LOCK_HOTEL_MODE;
									 u8KeyRepeatState = OSD_REPEAT_DISABLE;
									 return;
					     	 }
						else if(stGenSetting.g_FactorySetting.HotelMenuMenuKeyPressFlag==0X0)
							{
							      	 stGenSetting.g_FactorySetting.HotelMenuMenuKeyPressFlag=0;
									 stGenSetting.g_FactorySetting.HotelMenuMenuKeyPressTime=0;
							}
					}
			}
		else if(stGenSetting.g_FactorySetting.HotelMenuHotelModeOperationEnable == DISABLE)
			{
				if((stGenSetting.g_SysSetting.g_enKeyPadLock == EN_E5_KeyLock_On)
			#if (IR_TYPE_SEL == CUS_IR_TYPE)
					   &&(stKeyStatus.keydata == IRKEY_BUTTON_LOCK)
		  	#endif
					   && (stKeyStatus.keytype == KEY_TYPE_KEYPAD))
				{
					u8KeyCode = KEY_BUTTON_LOCK;
					stKeyStatus.keydata = IRKEY_DUMY;
					MApp_SetKeyRepeatState(u8KeyCode);
					return;
				}
			}
	#else
			{
				if((stGenSetting.g_SysSetting.g_enKeyPadLock == EN_E5_KeyLock_On)
		   #if (IR_TYPE_SEL == CUS_IR_TYPE)
					   &&(stKeyStatus.keydata == IRKEY_BUTTON_LOCK)
		   #endif
					   && (stKeyStatus.keytype == KEY_TYPE_KEYPAD))
			   {
				   u8KeyCode = KEY_BUTTON_LOCK;
				   stKeyStatus.keydata = IRKEY_DUMY;
				   MApp_SetKeyRepeatState(u8KeyCode);
				   return;
			   }
			}
	#endif
#endif
//========================================================================
//add for hotel menu source key lock @chuxu 2012-08-10
#if CUS_SMC_ENABLE_HOTEL_MODE
	if(stGenSetting.g_FactorySetting.HotelMenuHotelModeOperationEnable == ENABLE)
	{
		//if((stGenSetting.g_FactorySetting.HotelMenuSourceKeyLockEnable == ENABLE)
			  // && (stKeyStatus.keytype == KEY_TYPE_IR))
		if(stGenSetting.g_FactorySetting.HotelMenuSourceKeyLockEnable == ENABLE)
   		{
			if((stKeyStatus.keydata == IRKEY_TV)           ||
				(stKeyStatus.keydata == IRKEY_AV)          ||
				(stKeyStatus.keydata == IRKEY_HDMI)        ||
				(stKeyStatus.keydata == IRKEY_INPUT_SOURCE)||
				(stKeyStatus.keydata == IRKEY_DMP)         ||
				(stKeyStatus.keydata == IRKEY_TV_INPUT)    ||
				(stKeyStatus.keydata == IRKEY_DTV)         ||
				(stKeyStatus.keydata == IRKEY_PC))
			{
				u8KeyCode = KEY_SOURCE_KEY_LOCK;
				u8KeyRepeatState = OSD_REPEAT_DISABLE;
				return;
			}
		}
	}
#endif
//===========================================================================
#ifdef SUPPORT_IR_CUS_FACTORY
	KEY_DEBUG(printf("*GetCUSFactoryRCReceivedStatus()=%b\n",GetCUSFactoryRCReceivedStatus()));
	if (GetCUSFactoryRCReceivedStatus() == TRUE && Mapp_CheckFactoryKey(stKeyStatus.keydata) && (stKeyStatus.keytype == KEY_TYPE_IR))
	{
		if (GetCUSFactoryRCEnableStatus() == TRUE)
        {
            HandleCUSFactoryRCKey(stKeyStatus.keydata);
        }

		u8KeyCode = KEY_NULL;
	}
	else
#endif
	{
     printf("====>stKeyStatus.keydata=0x%x\n",stKeyStatus.keydata);

	 
#ifndef HISENSE_6I78 //for Hisense use msAPI_IsMBIREnabled
        switch(stKeyStatus.keydata)
        {
        case IRKEY_POWER:               u8KeyCode = KEY_POWER;              break;
        case IRKEY_UP:
            if(stKeyStatus.keytype == KEY_TYPE_KEYPAD)
            {
	            if((MApp_ZUI_GetActiveOSD() == E_OSD_MAIN_MENU)
	                ||(MApp_ZUI_GetActiveOSD() == E_OSD_INPUT_SOURCE)
	                ||(MApp_ZUI_GetActiveOSD() == E_OSD_FACTORY_MENU)
	                )
                {
                    u8KeyCode = KEY_UP;
                }
                else
                {
                    u8KeyCode = KEY_CHANNEL_PLUS;
                }
            }
            else
            {
                if((MApp_ZUI_GetActiveOSD() == E_OSD_DMP)&&(MApp_DMP_GetDmpUiState() == DMP_UI_STATE_MEDIA_SELECT))
				{
                   u8KeyCode = KEY_NULL;
				}
				else
            	u8KeyCode = KEY_UP;
            }
                break;
        case IRKEY_DOWN:
            if(stKeyStatus.keytype == KEY_TYPE_KEYPAD)
            {
	            if((MApp_ZUI_GetActiveOSD() == E_OSD_MAIN_MENU)
	                ||(MApp_ZUI_GetActiveOSD() == E_OSD_INPUT_SOURCE)
	                ||(MApp_ZUI_GetActiveOSD() == E_OSD_FACTORY_MENU)
	                )
                {
                    u8KeyCode = KEY_DOWN;
                }
                else
                {
                    u8KeyCode = KEY_CHANNEL_MINUS;
                }
            }
            else
            {
                if((MApp_ZUI_GetActiveOSD() == E_OSD_DMP)&&(MApp_DMP_GetDmpUiState() == DMP_UI_STATE_MEDIA_SELECT))
				{
                   u8KeyCode = KEY_NULL;
				}
				else
            	u8KeyCode = KEY_DOWN;
            }

                break;
        case IRKEY_RIGHT:
            if(stKeyStatus.keytype == KEY_TYPE_KEYPAD)
            {
	            if((MApp_ZUI_GetActiveOSD() == E_OSD_MAIN_MENU)
	                ||(MApp_ZUI_GetActiveOSD() == E_OSD_INPUT_SOURCE)
	                ||(MApp_ZUI_GetActiveOSD() == E_OSD_FACTORY_MENU)
	                //||(MApp_ZUI_GetActiveOSD() == E_OSD_DMP)
	                ||(MApp_DMP_GetDmpUiState() == DMP_UI_STATE_DRIVE_SELECT)
	                ||(MApp_DMP_GetDmpUiState() == DMP_UI_STATE_FILE_SELECT)
	                )
                {
                    u8KeyCode = KEY_RIGHT;
                }
				else if((MApp_ZUI_GetActiveOSD() == E_OSD_DMP)&&(MApp_DMP_GetDmpUiState() == DMP_UI_STATE_MEDIA_SELECT))
				{
                   u8KeyCode = KEY_DOWN;
				}
                else
                {
                    u8KeyCode = KEY_RIGHT;//KEY_VOLUME_PLUS;
                }
            }
            else
            {
             if((MApp_ZUI_GetActiveOSD() == E_OSD_DMP)&&(MApp_DMP_GetDmpUiState() == DMP_UI_STATE_MEDIA_SELECT))
				{
                   u8KeyCode = KEY_DOWN;
				}
			   else
                u8KeyCode = KEY_RIGHT;
            }

            break;
        case IRKEY_LEFT:
            if(stKeyStatus.keytype == KEY_TYPE_KEYPAD)
            {
	            if((MApp_ZUI_GetActiveOSD() == E_OSD_MAIN_MENU)
	                ||(MApp_ZUI_GetActiveOSD() == E_OSD_INPUT_SOURCE)
	                ||(MApp_ZUI_GetActiveOSD() == E_OSD_FACTORY_MENU)
	                //||(MApp_ZUI_GetActiveOSD() == E_OSD_DMP)
	                ||(MApp_DMP_GetDmpUiState() == DMP_UI_STATE_DRIVE_SELECT)
	                ||(MApp_DMP_GetDmpUiState() == DMP_UI_STATE_FILE_SELECT)
	                )
	            {
	            	u8KeyCode = KEY_LEFT;
	            }
				else if((MApp_ZUI_GetActiveOSD() == E_OSD_DMP)&&(MApp_DMP_GetDmpUiState() == DMP_UI_STATE_MEDIA_SELECT))
				{
                   u8KeyCode = KEY_UP;
				}
                else
                {
                	u8KeyCode = KEY_LEFT;//KEY_VOLUME_MINUS;
                }
            }
            else
            {
                if((MApp_ZUI_GetActiveOSD() == E_OSD_DMP)&&(MApp_DMP_GetDmpUiState() == DMP_UI_STATE_MEDIA_SELECT))
				{
                   u8KeyCode = KEY_UP;
				}
			   else
            	u8KeyCode = KEY_LEFT;
            }

            break;
        case IRKEY_SELECT:
			if(MApp_MPlayer_QueryCurrentMediaType()==E_MPLAYER_TYPE_MOVIE)
			{
			    if((MApp_MPlayer_QueryMoviePlayMode()>=E_MPLAYER_MOVIE_FF_2X)&&(MApp_MPlayer_QueryMoviePlayMode()<=E_MPLAYER_MOVIE_SF_32X))
				{
                 u8KeyCode = KEY_PLAY;
			    }
				else
				u8KeyCode = KEY_SELECT;	
			}
			else
            u8KeyCode = KEY_SELECT;
            break;

        case IRKEY_CHANNEL_PLUS:
          #if(IR_CHANNEL_USE_AS_UPDOWN==1)
         //   if((enMenuFlowState != FS_WAIT_MENU)||(g_u8MenuPageIndex==MENU_INPUT_SOURCE))
	  //   if((MApp_TopStateMachine_GetTopState()==STATE_TOP_MENU)	)
		  if(( MApp_TopStateMachine_GetTopState() != STATE_TOP_MENU) &&
		  	( MApp_TopStateMachine_GetTopState() != STATE_TOP_DMP)&&
		  	( MApp_TopStateMachine_GetTopState() != STATE_TOP_INPUTSOURCE) )

          #else
            if ((stKeyStatus.keytype != KEY_TYPE_KEYPAD) ) //ZUI_TODO: &&
        #endif
                u8KeyCode = KEY_CHANNEL_PLUS;
            else
                u8KeyCode = KEY_UP;
            break;

        case IRKEY_CHANNEL_MINUS:
          #if(IR_CHANNEL_USE_AS_UPDOWN==1)
            //if((enMenuFlowState != FS_WAIT_MENU)||(g_u8MenuPageIndex==MENU_INPUT_SOURCE))
     //       if((MApp_TopStateMachine_GetTopState()==STATE_TOP_MENU)	)
     		 if(( MApp_TopStateMachine_GetTopState() != STATE_TOP_MENU) &&
		  	( MApp_TopStateMachine_GetTopState() != STATE_TOP_DMP)&&
		  	( MApp_TopStateMachine_GetTopState() != STATE_TOP_INPUTSOURCE) )
        #else
            if ((stKeyStatus.keytype != KEY_TYPE_KEYPAD) )//ZUI_TODO: &&
          #endif
                u8KeyCode = KEY_CHANNEL_MINUS;
            else
                u8KeyCode = KEY_DOWN;
            break;
		case IRKEY_DMP:
			u8KeyCode = KEY_DMP;
			break;
        case IRKEY_VOLUME_PLUS:
            // special case : when in input select mode, the KEYPAD LEFT/RIGHT is interpreted as VolUP/VolDOWN
          #if(IR_VOLUME_USE_AS_LEFTRIGHT==1)
           /*helen  if ( (enMenuFlowState != FS_WAIT_MENU) && ((g_u8MenuPageIndex==MENU_INPUT_SOURCE) ||(g_u8MenuPageIndex==MENU_CHANNEL_RETURN_LIST) || (g_u8MenuPageIndex==MENU_FAVORITE_LIST) ) )

		  u8KeyCode = KEY_VOLUME_PLUS;
            else*/ 
      
            if(((( MApp_TopStateMachine_GetTopState() != STATE_TOP_MENU) &&
		  	( MApp_TopStateMachine_GetTopState() != STATE_TOP_DMP)&&
		  	(MApp_DMP_GetDmpUiState() != DMP_UI_STATE_DRIVE_SELECT)&&
		  	(MApp_DMP_GetDmpUiState() != DMP_UI_STATE_FILE_SELECT)&&
		  	(MApp_DMP_GetDmpUiState() != DMP_UI_STATE_MEDIA_SELECT)&&
		  	( MApp_TopStateMachine_GetTopState() != STATE_TOP_INPUTSOURCE))&&(!IsAnalogSourceInUse())&&(g_isCVBS2==0)&&(MApp_ZUI_GetActiveOSD() != E_OSD_MAIN_MENU))||((IsDigitalSourceInUse()||IsHDMIInUse())&&(MApp_ZUI_GetActiveOSD() != E_OSD_MAIN_MENU))||(IsStorageInUse() && MApp_MPlayer_IsMediaFileInPlaying() && MApp_ZUI_ACT_GetCurrentMediaPlayingFlag()&&(!MApp_ZUI_API_IsWindowVisible(HWND_DMP_PLAYBACK_INFO_PANE))&&(MApp_ZUI_GetActiveOSD() != E_OSD_MAIN_MENU))) 	//if( enMenuFlowState != FS_WAIT_MENU))
                u8KeyCode = KEY_VOLUME_PLUS;
		    else if((MApp_ZUI_GetActiveOSD() == E_OSD_DMP)&&(MApp_DMP_GetDmpUiState() == DMP_UI_STATE_MEDIA_SELECT))
				u8KeyCode =  KEY_UP;
            else
                u8KeyCode =  KEY_RIGHT;
          #else
            if ((stKeyStatus.keytype == KEY_TYPE_KEYPAD) )//ZUI_TODO: &&
                u8KeyCode = KEY_VOLUME_PLUS;
            else if((stKeyStatus.keytype == KEY_TYPE_KEYPAD) )//ZUI_TODO: &&
                u8KeyCode = KEY_SELECT;
            else if((stKeyStatus.keytype == KEY_TYPE_KEYPAD) )//ZUI_TODO: &&
                u8KeyCode = KEY_RIGHT;
            else if((UI_INPUT_SOURCE_TYPE != UI_INPUT_SOURCE_RGB)||(UI_INPUT_SOURCE_TYPE != UI_INPUT_SOURCE_AV2))
                u8KeyCode = KEY_VOLUME_PLUS;
          #endif
            break;

        case IRKEY_VOLUME_MINUS:
          #if(IR_VOLUME_USE_AS_LEFTRIGHT==1)
		  if(((( MApp_TopStateMachine_GetTopState() != STATE_TOP_MENU) &&
		  	( MApp_TopStateMachine_GetTopState() != STATE_TOP_DMP) &&
		  	(MApp_DMP_GetDmpUiState() != DMP_UI_STATE_DRIVE_SELECT)&&
		  	(MApp_DMP_GetDmpUiState() != DMP_UI_STATE_FILE_SELECT)&&
		  	(MApp_DMP_GetDmpUiState() != DMP_UI_STATE_MEDIA_SELECT)&&
		  	( MApp_TopStateMachine_GetTopState() != STATE_TOP_INPUTSOURCE))&&(!IsAnalogSourceInUse())&&(g_isCVBS2==0)&&(MApp_ZUI_GetActiveOSD() != E_OSD_MAIN_MENU))||((IsDigitalSourceInUse()||IsHDMIInUse())&&(MApp_ZUI_GetActiveOSD() != E_OSD_MAIN_MENU))||(IsStorageInUse() && MApp_MPlayer_IsMediaFileInPlaying() && MApp_ZUI_ACT_GetCurrentMediaPlayingFlag()&&(!MApp_ZUI_API_IsWindowVisible(HWND_DMP_PLAYBACK_INFO_PANE))&&(MApp_ZUI_GetActiveOSD() != E_OSD_MAIN_MENU)))
		  	u8KeyCode = KEY_VOLUME_MINUS;
		  else if((MApp_ZUI_GetActiveOSD() == E_OSD_DMP)&&(MApp_DMP_GetDmpUiState() == DMP_UI_STATE_MEDIA_SELECT))
				u8KeyCode =  KEY_DOWN;
		  	
		  else
                	u8KeyCode = KEY_LEFT;
          #else
            if ((stKeyStatus.keytype == KEY_TYPE_KEYPAD) )//ZUI_TODO: &&
                u8KeyCode = KEY_VOLUME_MINUS;
            else if((stKeyStatus.keytype == KEY_TYPE_KEYPAD) )//ZUI_TODO: &&
                u8KeyCode = KEY_SELECT;
            else if((stKeyStatus.keytype == KEY_TYPE_KEYPAD) )//ZUI_TODO: &&
                u8KeyCode = KEY_LEFT;
            else if(((UI_INPUT_SOURCE_TYPE != UI_INPUT_SOURCE_RGB)||(UI_INPUT_SOURCE_TYPE != UI_INPUT_SOURCE_AV2))&&(MApp_ZUI_GetActiveOSD() != E_OSD_MAIN_MENU))
      
                u8KeyCode = KEY_VOLUME_MINUS;
          #endif
            break;

        case IRKEY_MENU:
            u8KeyCode = KEY_MENU;
            break;
			
	#if IR_TYPE_SEL==IR_TYPE_HAIER_TOSHIBA
		case IRKEY_LOCK:
		  #if 1
            u8KeyCode = KEY_LOCK;
		  #else
		   if(MApp_ZUI_GetActiveOSD()!=E_OSD_DMP && MApp_ZUI_GetActiveOSD()!=E_OSD_INPUT_SOURCE)
			  MApp_ZUI_ACT_ShutdownOSD();
            u8KeyCode = KEY_MENU;
			_enReturnMenuItem = STATE_RETURN_LOCK_PAGE;
		  #endif
			break;
	#endif
	
        case IRKEY_INPUT_SOURCE:
		/*
            if(stKeyStatus.keytype==KEY_TYPE_KEYPAD)
            {
                if(MApp_isKeypadSourceKeyCanSelect() == TRUE)
                    u8KeyCode = KEY_SELECT;
                
            }
			else 
			*/
			if((MApp_ZUI_GetActiveOSD() == E_OSD_MAIN_MENU)
	                ||(MApp_ZUI_GetActiveOSD() == E_OSD_INPUT_SOURCE)
	                ||(MApp_ZUI_GetActiveOSD() == E_OSD_FACTORY_MENU)
	                )
	             u8KeyCode = KEY_DOWN;   
	             else   
				u8KeyCode = KEY_AV;
			//u8KeyCode = KEY_AV;
			#if 0
			printf("Test--> IRKEY_INPUT_SOURCE  key \n");
			if((MApp_ZUI_GetActiveOSD() == E_OSD_MAIN_MENU)
	                ||(MApp_ZUI_GetActiveOSD() == E_OSD_INPUT_SOURCE)
	                ||(MApp_ZUI_GetActiveOSD() == E_OSD_FACTORY_MENU)
				)
				 u8KeyCode = KEY_DOWN;
            else
          
                u8KeyCode = KEY_INPUT_SOURCE;
			#endif
            break;

            case IRKEY_NUM_0:            	u8KeyCode = KEY_0;                  break;
            case IRKEY_NUM_1:               u8KeyCode = KEY_1;                  break;
            case IRKEY_NUM_2:               u8KeyCode = KEY_2;                  break;
            case IRKEY_NUM_3:               u8KeyCode = KEY_3;                  break;
            case IRKEY_NUM_4:               u8KeyCode = KEY_4;                  break;
            case IRKEY_NUM_5:               u8KeyCode = KEY_5;                  break;
            case IRKEY_NUM_6:               u8KeyCode = KEY_6;                  break;

    #if (!SCAN_TEST_MODE_ENABLE)
        case IRKEY_NUM_7:               u8KeyCode = KEY_7;                  break;
        case IRKEY_NUM_8:               u8KeyCode = KEY_8;                  break;
        case IRKEY_NUM_9:               u8KeyCode = KEY_9;                  break;
    #else
            case IRKEY_NUM_7:
                u8KeyCode = KEY_7;
                AutoScanTest.u8State= TEST_MODE_ATV_SCAN_STATE_DISABLE;
                AutoScanTest.u16VerifyCount=0;
                printf("Test--> Test Mode ATV Scan = Disable\n");
                break;
            case IRKEY_NUM_8:
                u8KeyCode = KEY_8;
                AutoScanTest.u8State= TEST_MODE_ATV_SCAN_STATE_SAVE_DATA;
                AutoScanTest.u16VerifyCount=0;
                printf("Test--> Test Mode ATV Scan = SAVE_DATA\n");
                break;
            case IRKEY_NUM_9:
                u8KeyCode = KEY_9;
                AutoScanTest.u8State= TEST_MODE_ATV_SCAN_STATE_VERIFY;
                AutoScanTest.u16VerifyCount=0;
                AutoScanTest.u16Total_Lost_Channel=0;
                AutoScanTest.u16Total_Ghost_Channel=0;
                switch (AutoScanTest.u16VerifyCountInput)
                {
                    case 1://30 min
                        AutoScanTest.u16VerifyCountInput=10;//60 min
                        printf("Test--> VerifyCountInput = 10, (30 minutes) \n");
                        break;
                    case 10://30 min
                        AutoScanTest.u16VerifyCountInput=20;//60 min
                        printf("Test--> VerifyCountInput = 20, (60 minutes) \n");
                        break;
                    case 20:
                        AutoScanTest.u16VerifyCountInput=50;//300 min = 5 hours
                        printf("Test--> VerifyCountInput = 50, (5 hours) \n");
                        break;
                    case 50://5 hours
                        AutoScanTest.u16VerifyCountInput=100;//10hours
                        printf("Test--> VerifyCountInput = 100, (10 hours) \n");
                        break;
                    case 100://10 hours
                        AutoScanTest.u16VerifyCountInput=10000;//1000hours = 41 days
                        printf("Test--> VerifyCountInput = 10000, (41 days) \n");
                        break;
                    default://10 hours
                        AutoScanTest.u16VerifyCountInput=1;
                        printf("Test--> VerifyCountInput = 1, (3~ minutes) \n");
                        break;
                }

                printf("Test--> Test Mode ATV Scan = Verify \n");
                break;
    #endif // #if (SCAN_TEST_MODE_ENABLE==1)


      #if (ENABLE_DMP == DISABLE)
        case IRKEY_TV_RADIO:            u8KeyCode = KEY_TV_RADIO;           break;
        #endif

        case IRKEY_EXIT:                u8KeyCode = KEY_EXIT;               break;

    #if (ENABLE_DTV_EPG)
        case IRKEY_EPG:                 u8KeyCode = KEY_EPG;                break;
    #else
        case IRKEY_EPG:                 u8KeyCode = KEY_NULL;               break;
    #endif //#if (ENABLE_DTV_EPG)

        case IRKEY_CHANNEL_RETURN:
            u8KeyCode = KEY_CHANNEL_RETURN;
            break;
		case IRKEY_RETURN:
			if(MApp_ZUI_GetActiveOSD() == E_OSD_MAIN_MENU)
			u8KeyCode = KEY_MENU;
			else if(IsStorageInUse() && MApp_DMP_GetDmpUiState()==DMP_UI_STATE_FILE_SELECT)
			u8KeyCode = KEY_BACK;
			else
			u8KeyCode = KEY_EXIT;//KEY_BACK;//KEY_CHANNEL_RETURN;
			break;
        case IRKEY_BACK:                u8KeyCode = KEY_BACK;               break;

            case IRKEY_CHANNEL_FAV_LIST:    u8KeyCode = KEY_CHANNEL_FAV_LIST;   break;
            case IRKEY_MUTE:
                #if ENABLE_CUS_UI_SPEC
                if(MApp_ZUI_GetActiveOSD() == E_OSD_INSTALL_GUIDE)
                {
                    u8KeyCode = KEY_NULL;
                }
                else
                #endif
                {
                    u8KeyCode = KEY_MUTE;
                }
                break;
            case IRKEY_FREEZE:              u8KeyCode = KEY_FREEZE;             break;
            case IRKEY_INFO:                u8KeyCode = KEY_INFO;               break;
		#if(CUS_OSD_STYLE==CUS_OSD_EBONY_ONEUX_LIKE)//cus_xm 20120818 gary disable smart audio &picture hotkey
		case IRKEY_AUDIO:               u8KeyCode = KEY_NULL;              break;
		 #else
            case IRKEY_AUDIO:             u8KeyCode = KEY_AUDIO;              break;
		#endif
		case IRKEY_PICTURE:           u8KeyCode = KEY_PICTURE;              break;

            case IRKEY_MTS:
                #if ENABLE_3D_PROCESS
                    u8KeyCode = KEY_3D_SETTING;
                #else
                    u8KeyCode = KEY_MTS;
                #endif
                break;
            case IRKEY_ZOOM:                u8KeyCode = KEY_ZOOM;               break;

        #if ENABLE_SBTVD_BRAZIL_APP
            case IRKEY_SUBTITLE:            u8KeyCode = KEY_DASH;               break;
        #else
            case IRKEY_SUBTITLE:            u8KeyCode = KEY_SUBTITLE;
                            #if(IR_TYPE_SEL==IR_TYPE_SMC_2010)
				if(IsStorageInUse())
        			{
           			    u8KeyCode = KEY_NULL;
        			}
			        #endif
				break;
        #endif

            case IRKEY_UPDATE:              u8KeyCode = KEY_UPDATE;             break;        // add UPDATE key
            case IRKEY_TTX_MODE:            u8KeyCode = KEY_TTX_MODE;           break;
            case IRKEY_MIX:                 u8KeyCode = KEY_MIX;                break;

        #if ENABLE_SBTVD_BRAZIL_APP
            case IRKEY_TTX:                 u8KeyCode = KEY_NULL;                break;
        #else
            case IRKEY_TTX:                 u8KeyCode = KEY_TTX;

          #if((IR_TYPE_SEL==IR_TYPE_SMC_2010)||(IR_TYPE_SEL==IR_TYPE_BOE))//minglin1205
                     if (IsStorageInUse())
                     {
                         if (MApp_MPlayer_IsMediaFileInPlaying() && MApp_ZUI_ACT_GetCurrentMediaPlayingFlag())
                        {
                            u8KeyCode = KEY_PAUSE;
                        }
                        else
                        {
                            u8KeyCode = KEY_PLAY;
                        }
                        break;
                     }
                    #endif

                    break;
        #endif

            case IRKEY_SIZE:                u8KeyCode = KEY_SIZE;               break;
            case IRKEY_HOLD:                u8KeyCode = KEY_HOLD;
		#if((IR_TYPE_SEL == IR_TYPE_SMC_2010)||(IR_TYPE_SEL == IR_TYPE_BOE))//minglin1205
				if(IsStorageInUse())
        	 		{
           			   u8KeyCode = KEY_STOP;
        		      	}
                     #endif
		        break;
            case IRKEY_INDEX:               u8KeyCode = KEY_INDEX;              break;
		#if ENABLE_TTX // cus_xm helen add 20120813
			 case IRKEY_CLOCK:               u8KeyCode = KEY_CLOCK;              break;
		#endif
            case IRKEY_CHANNEL_LIST:        u8KeyCode = KEY_CHANNEL_LIST;       break;
            case IRKEY_SLEEP:               u8KeyCode = KEY_SLEEP;              break;
            case IRKEY_DASH:                u8KeyCode = KEY_DASH;               break;

            //Because some IR key codes are defined un-correctly, so we have to change key mapping below.
            case IRKEY_BACKWARD:            u8KeyCode = KEY_REWIND;            break;
            case IRKEY_FORWARD:             u8KeyCode = KEY_FF;                break;

          #if (ENABLE_DMP)
            case IRKEY_PAGE_UP:             u8KeyCode = KEY_PAGE_UP;             break;
          #endif

            case IRKEY_PAGE_DOWN:           u8KeyCode = KEY_PAGE_DOWN;           break;
            case IRKEY_PREVIOUS:            u8KeyCode = KEY_PREVIOUS;            break;
            case IRKEY_NEXT:                u8KeyCode = KEY_NEXT;                break;
            case IRKEY_CC:                  u8KeyCode = KEY_CC;                  break;
		#if (IR_TYPE_SEL == IR_TYPE_HAIER_NEC)
	     case IRKEY_REPEAT:                  u8KeyCode = KEY_REPEAT;                  break;// CUS xm helen add for haier
       #endif
        case IRKEY_ADJUST:                  u8KeyCode = KEY_ADJUST;             break;
        case IRKEY_KEY_DISABLE_KEYPAD:      u8KeyCode = KEY_DISABLE_KEYPAD;     break;
        case IRKEY_REVEAL:                  u8KeyCode = KEY_REVEAL;             break;

        #if ENABLE_DMP || ENABLE_PVR
            case IRKEY_RECORD:                  u8KeyCode = KEY_RECORD;           break;
            case IRKEY_STOP:                    u8KeyCode = KEY_STOP;             break;
        #else
            //CEC
        #endif

        #if (MCU_AEON_ENABLE|ENABLE_CEC)
          #if ENABLE_DMP
            #if ((IR_TYPE_SEL == IR_TYPE_SMC_XIN_2012)||(IR_TYPE_SEL == IR_TYPE_FOX_SHARP) || (IR_TYPE_SEL == IR_TYPE_FOX_NEC) || (IR_TYPE_SEL == IR_TYPE_HAIER_TOSHIBA))
            case IRKEY_PLAY:
                if (IsStorageInUse() && MApp_MPlayer_IsMediaFileInPlaying() && MApp_ZUI_ACT_GetCurrentMediaPlayingFlag())
                {
                    u8KeyCode = KEY_PAUSE;
                }
                else
                {
                    u8KeyCode = KEY_PLAY;
                }
                break;
            #else
            case IRKEY_PLAY:                     u8KeyCode = KEY_PLAY;               break;
            #endif
            case IRKEY_PAUSE:                    u8KeyCode = KEY_PAUSE;              break;
          #endif
        #endif

            case IRKEY_SUBPAGE:                 u8KeyCode = KEY_SUBPAGE;            break;

        case IRKEY_RED:
            u8KeyCode = KEY_RED;
        #if ((IR_TYPE_SEL==IR_TYPE_SMC_2010) || (IR_TYPE_SEL == IR_TYPE_FOX_SHARP) || (IR_TYPE_SEL == IR_TYPE_FOX_NEC))
            if(IsStorageInUse())
            {
                if(MApp_MPlayer_IsMediaFileInPlaying() && (MApp_DMP_GetDmpFlag()& DMP_FLAG_MEDIA_FILE_PLAYING))
                {
                    u8KeyCode = KEY_REWIND;
                }
            }
            else
        #endif
        #if 0//(CUS_IR_TYPE==IR_TYPE_HAIER_TOSHIBA)
            if(MApp_TopStateMachine_GetTopState() == STATE_TOP_DMP || MApp_TopStateMachine_GetTopState() == STATE_TOP_DIGITALINPUTS)
                u8KeyCode = KEY_LOCK;//u8KeyCode = KEY_REWIND;
            else
        #endif
                u8KeyCode = KEY_RED;
            break;
        case IRKEY_GREEN:
            u8KeyCode = KEY_GREEN;
        #if(IR_TYPE_SEL==IR_TYPE_SMC_2010)
            if(IsStorageInUse())
            {
                if(MApp_MPlayer_IsMediaFileInPlaying() && (MApp_DMP_GetDmpFlag()& DMP_FLAG_MEDIA_FILE_PLAYING))
                    u8KeyCode = KEY_FF;
            }
            else
        #endif
        #if 0//(CUS_IR_TYPE==IR_TYPE_HAIER_TOSHIBA)
            if(MApp_TopStateMachine_GetTopState() == STATE_TOP_DMP)
                u8KeyCode = KEY_FF;
            else
        #endif
                u8KeyCode = KEY_GREEN;
			break;
        case IRKEY_YELLOW:
            u8KeyCode =  KEY_YELLOW;
        #if(IR_TYPE_SEL==IR_TYPE_SMC_2010)
            if(IsStorageInUse())
            {
                if(MApp_MPlayer_IsMediaFileInPlaying() && (MApp_DMP_GetDmpFlag()& DMP_FLAG_MEDIA_FILE_PLAYING))
                    u8KeyCode = KEY_PREVIOUS;
            }
            else
        #endif
        #if 0//(CUS_IR_TYPE==IR_TYPE_HAIER_TOSHIBA)
            if(MApp_TopStateMachine_GetTopState() == STATE_TOP_DMP)
                u8KeyCode = KEY_PREVIOUS;
            else
        #endif
                u8KeyCode =  KEY_YELLOW;
        #if ((IR_TYPE_SEL == IR_TYPE_FOX_SHARP) || (IR_TYPE_SEL == IR_TYPE_FOX_NEC))
            if(IsStorageInUse())
            {
                if(MApp_MPlayer_IsMediaFileInPlaying() && (MApp_DMP_GetDmpFlag()& DMP_FLAG_MEDIA_FILE_PLAYING))
                    u8KeyCode = KEY_FF;
            }
        #endif
			break;
        case IRKEY_BLUE:
            u8KeyCode = KEY_BLUE;
        #if(IR_TYPE_SEL==IR_TYPE_SMC_2010)
            if(IsStorageInUse())
            {
                if(MApp_MPlayer_IsMediaFileInPlaying() && (MApp_DMP_GetDmpFlag()& DMP_FLAG_MEDIA_FILE_PLAYING))
                    u8KeyCode = KEY_NEXT;
            }
            else
        #endif
        #if 0//(CUS_IR_TYPE==IR_TYPE_HAIER_TOSHIBA)
            if(MApp_TopStateMachine_GetTopState() == STATE_TOP_DMP)
                u8KeyCode = KEY_NEXT;
            else
        #endif
                u8KeyCode = KEY_BLUE;
            break;
        case IRKEY_RED2:                u8KeyCode = KEY_RED;                break;
        case IRKEY_GREEN2:              u8KeyCode = KEY_GREEN;              break;

        case IRKEY_TV_INPUT:            u8KeyCode = KEY_TV_INPUT;           break;
        case IRKEY_DTV:                     u8KeyCode = KEY_DTV;                 break;
        case IRKEY_TV:                      u8KeyCode = KEY_TV;                    break;
        case IRKEY_PC:
			 #if 0//CUS_XM:xue modify switch source 2012-6-2
			{
				//if(IsHDMIInUse())
								if(UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_RGB)
					u8KeyCode = KEY_HDMI;
				else if(UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_HDMI)

					u8KeyCode = KEY_HDMI;
				else
					u8KeyCode = KEY_PC;
			}
			 #endif

			 u8KeyCode = KEY_PC;
			break;
        case IRKEY_COMPONENT:               u8KeyCode = KEY_COMPONENT;             break;
        case IRKEY_SV:                      u8KeyCode = KEY_SV;     		break;

        case IRKEY_HDMI:
#if 1 	// CUS_XM Xue 20120727: modify XF112PIOCNMS0-791 bug

			if(UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_RGB)
				u8KeyCode = KEY_HDMI;
            #if 0//(INPUT_HDMI_VIDEO_COUNT >=2)
			else if(UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_HDMI2)
				u8KeyCode =KEY_PC;
            #endif
			else
				u8KeyCode = KEY_HDMI;

			if(IsStorageInUse())
				u8KeyCode = KEY_HDMI;
#endif
			#if 0
        if(IsStorageInUse())
        {
        u8KeyCode = KEY_HDMI;
        pcsource=2;
        videosource=0;
         break;
        }
			//CUS_XM:xue modify switch source 2012-6-2
			{
				//if(UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_AV)
				if(pcsource==0)
					{
					u8KeyCode = KEY_PC;
					pcsource++;
					videosource=0;
					}
				else if(pcsource==1)
					{
					u8KeyCode = KEY_HDMI;
					pcsource++;
					videosource=0;
					}
				else if(pcsource==2)
					{
					u8KeyCode = KEY_HDMI;
					pcsource=0;
					videosource=0;
					}
				else
					{
					u8KeyCode = KEY_PC;
					pcsource=0;
					videosource=0;
					}
			}
#endif
		break;

        case IRKEY_AV:
		// CUS_XM Xue 20120727: modfiy XF112PIOCNMS0-792 bug
			//if(UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_AV)
			//	u8KeyCode = KEY_COMPONENT;
			//else
				if((MApp_ZUI_GetActiveOSD() == E_OSD_MAIN_MENU)
	                ||(MApp_ZUI_GetActiveOSD() == E_OSD_INPUT_SOURCE)
	                ||(MApp_ZUI_GetActiveOSD() == E_OSD_FACTORY_MENU)
	                )
	             u8KeyCode = KEY_DOWN;   
	             else   
				u8KeyCode = KEY_AV;
             printf("---KEY_AV!---\n");
			//if(IsStorageInUse())
			//	u8KeyCode = KEY_AV;

			#if 0
			//CUS_XM:xue modify switch source 2012-6-2
			{
            if(IsStorageInUse())
            {
            u8KeyCode = KEY_AV;
            pcsource=0;
            videosource=1;
             break;
            }
				//if(UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_AV)
				if(videosource==0)
					{
					u8KeyCode = KEY_AV;
					pcsource=0;
					videosource++;
					}
				else if(videosource==1)
					{
					u8KeyCode = KEY_AV;
					videosource++;
					pcsource=0;
					}
				else if(videosource==2)
					{
					u8KeyCode = KEY_COMPONENT;
					videosource++;
					pcsource=0;
					}
				else if(videosource==3)
					{
					u8KeyCode = KEY_COMPONENT;
					videosource=0;
					pcsource=0;
					}
				else
					{
					videosource=0;
					u8KeyCode = KEY_AV;
					pcsource=0;
					}
			}
			#endif
			break;
      #endif
    	//case IRKEY_MINU:		u8KeyCode = KEY_DOT;         	break;

#if KEYPAD_TYPE_SEL == KEYPAD_TYPE_IR
        case IRKEY_KEYPAD_POWER:
            u8KeyCode = KEY_POWER;
            stKeyStatus.keytype = KEY_TYPE_KEYPAD;
            break;
        case IRKEY_KEYPAD_MENU:
            u8KeyCode = KEY_MENU;
            stKeyStatus.keytype = KEY_TYPE_KEYPAD;
            break;
        case IRKEY_KEYPAD_UP:
            if((MApp_ZUI_GetActiveOSD() == E_OSD_MAIN_MENU)
                ||(MApp_ZUI_GetActiveOSD() == E_OSD_INPUT_SOURCE)
                ||(MApp_ZUI_GetActiveOSD() == E_OSD_FACTORY_MENU)
                )
            {
                u8KeyCode = KEY_UP;
            }
            else
            {
                u8KeyCode = KEY_CHANNEL_PLUS;
            }
            stKeyStatus.keytype = KEY_TYPE_KEYPAD;
            break;
        case IRKEY_KEYPAD_DOWN:
            if((MApp_ZUI_GetActiveOSD() == E_OSD_MAIN_MENU)
                ||(MApp_ZUI_GetActiveOSD() == E_OSD_INPUT_SOURCE)
                ||(MApp_ZUI_GetActiveOSD() == E_OSD_FACTORY_MENU)
                )
            {
                u8KeyCode = KEY_DOWN;
            }
            else
            {
                u8KeyCode = KEY_CHANNEL_MINUS;
            }
            stKeyStatus.keytype = KEY_TYPE_KEYPAD;
            break;
        case IRKEY_KEYPAD_RIGHT:
            if((MApp_ZUI_GetActiveOSD() == E_OSD_MAIN_MENU)
                ||(MApp_ZUI_GetActiveOSD() == E_OSD_FACTORY_MENU)
                )
            {
                u8KeyCode = KEY_RIGHT;
            }
            else if(MApp_ZUI_GetActiveOSD() == E_OSD_INPUT_SOURCE)
            {
                u8KeyCode = KEY_SELECT;
            }
            else
            {
                u8KeyCode = KEY_VOLUME_PLUS;
            }
            stKeyStatus.keytype = KEY_TYPE_KEYPAD;
            break;
        case IRKEY_KEYPAD_LEFT:
            if((MApp_ZUI_GetActiveOSD() == E_OSD_MAIN_MENU)
                ||(MApp_ZUI_GetActiveOSD() == E_OSD_FACTORY_MENU)
                )
            {
                u8KeyCode = KEY_LEFT;
            }
            else if(MApp_ZUI_GetActiveOSD() == E_OSD_INPUT_SOURCE)
            {
                u8KeyCode = KEY_SELECT;
            }
            else
            {
                u8KeyCode = KEY_VOLUME_MINUS;
            }
            stKeyStatus.keytype = KEY_TYPE_KEYPAD;
            break;
        case IRKEY_KEYPAD_INPUT_SOURCE:
            if(MApp_ZUI_GetActiveOSD() == E_OSD_MAIN_MENU)
            {
                u8KeyCode = KEY_SELECT;
            }
            else
            {
                u8KeyCode = KEY_INPUT_SOURCE;
            }
            stKeyStatus.keytype = KEY_TYPE_KEYPAD;
            break;
#endif


            default:      
            if(u8KeyCode != KEY_CHANNEL_MINUS && u8KeyCode != KEY_CHANNEL_PLUS)
               u8KeyCode = KEY_NULL;              
			break;
        }

    }
//========================================================================
//add for hotel mode @chuxu 2012-08-15
#if CUS_SMC_ENABLE_HOTEL_MODE
    if(stGenSetting.g_FactorySetting.HotelMenuHotelModeOperationEnable == ENABLE && MApp_ZUI_GetActiveOSD()!=E_OSD_FACTORY_MENU)
    {
		//add for hotel mode's remote control lock @chuxu 2012-08-15
		if((stGenSetting.g_FactorySetting.HotelMenuRometeControlLockEnable == ENABLE)&&(stKeyStatus.keytype == KEY_TYPE_IR))
        {
        	if(u8KeyCode == KEY_MENU)
    		{
    			_u32LaunchKeys_rclock_hotelmode = 0;
    		}
        	else if (KEY_0 <= u8KeyCode && u8KeyCode <= KEY_9)
    		{
    			_u32LaunchKeys_rclock_hotelmode = (_u32LaunchKeys_rclock_hotelmode<<4)|(u8KeyCode-KEY_0);
    		}
        	else if(u8KeyCode == KEY_CHANNEL_RETURN)
    		{
    			switch (_u32LaunchKeys_rclock_hotelmode)
    				{
    					case 0x100108:
    						//stGenSetting.g_FactorySetting.HotelMenuRometeControlLockEnable = DISABLE;
    						_u32LaunchKeys_rclock_hotelmode=0;
    						g_bGotoCUSMenu = 3;
    						u8KeyCode = KEY_GOTO_HOTEL_MODE;//goto hotel menu
    						break;
    					default:
    						_u32LaunchKeys_rclock_hotelmode=0;
    						break;
    				}
    		}

        	if(stGenSetting.g_FactorySetting.HotelMenuRometeControlLockEnable == DISABLE)
    		{
    			return;
    		}
        	else if((stGenSetting.g_FactorySetting.HotelMenuRometeControlLockEnable == ENABLE)&&(stKeyStatus.keytype == KEY_TYPE_IR))
    		{
    		  if((MApp_ZUI_GetActiveOSD()==E_OSD_MAIN_MENU || MApp_ZUI_GetActiveOSD()==E_OSD_MESSAGE_BOX \
			  	|| MApp_ZUI_API_GetFocus()==HWND_DMP_HOTEL_PASSWD_PANEL_OPTION || MApp_ZUI_API_GetFocus()==HWND_DMP_HOTEL_PASSWD_WRONG) \
			  	&& u8KeyCode>=KEY_0 && u8KeyCode<=KEY_9)
			  	;
			  else if(MApp_ZUI_API_IsSuccessor(HWND_MENU_LOCK_MAINSUBPAGE,MApp_ZUI_API_GetFocus()) \
			  	     && u8KeyCode>=KEY_MENU && u8KeyCode<=KEY_RIGHT)
			  	;
			  else if(stKeyStatus.keydata==IRKEY_POWER  || stKeyStatus.keydata==IRKEY_EXIT)
			  	;
			  #if(IR_TYPE_SEL == IR_TYPE_HAIER_TOSHIBA) //<<SMC jayden.chen add if 20130813
			  else if(stKeyStatus.keydata==IRKEY_LOCK)
			  	;
			  #endif
			  else
			  	{
    			u8KeyCode = KEY_REMOTE_CONTROL_LOCK;
    			u8KeyRepeatState = OSD_REPEAT_DISABLE;
    			return;
			  	}
    		}
        }
		//add for hotel mode's osd display lock @chuxu 2012-08-15
        if(stGenSetting.g_FactorySetting.HotelMenuOSDDisplayEnable == DISABLE)
        {
            if(u8KeyCode == KEY_MENU)
            {
                _u32LaunchKeys_osd_lock_hotelmode = 0;
            }
            else if (KEY_0 <= u8KeyCode && u8KeyCode <= KEY_9)
            {
                _u32LaunchKeys_osd_lock_hotelmode = (_u32LaunchKeys_osd_lock_hotelmode<<4)|(u8KeyCode-KEY_0);
            }
            else if(u8KeyCode == KEY_CHANNEL_RETURN)
            {
                u8KeyCode = KEY_NULL;
                switch (_u32LaunchKeys_osd_lock_hotelmode)
                {
                    case 0x100108:
                        stGenSetting.g_FactorySetting.HotelMenuOSDDisplayEnable = ENABLE;
                        _u32LaunchKeys_osd_lock_hotelmode=0;
                        g_bGotoCUSMenu = 3;
                        u8KeyCode = KEY_GOTO_HOTEL_MODE;//goto hotel menu
                        break;
                    default:
                        _u32LaunchKeys_osd_lock_hotelmode=0;
                        break;
                }
            }

            if(stGenSetting.g_FactorySetting.HotelMenuOSDDisplayEnable == ENABLE)
            {
                return;
            }
            else if(stGenSetting.g_FactorySetting.HotelMenuOSDDisplayEnable == DISABLE)
            {
                if(u8KeyCode == KEY_MENU)
                {
                    //u8KeyCode = KEY_OSD_DISPLAY_LOCK;
                    //u8KeyRepeatState = OSD_REPEAT_DISABLE;
                    ;//return;
                }
				else if(u8KeyCode == KEY_LEFT || u8KeyCode == KEY_RIGHT || u8KeyCode == KEY_UP \
					|| u8KeyCode == KEY_DOWN || u8KeyCode == KEY_SELECT)
					{
					 if(MApp_ZUI_GetActiveOSD()==E_OSD_MAIN_MENU)
					 	{
						 u8KeyCode = KEY_NULL;
                         return;
					 	}
				    }
            }
        }
    }
#endif
//========================================================================

    if(MApp_SleepCountWinShow())
    {
        if(u8KeyCode == KEY_SLEEP)
        {
            printf("---Sleep Count,KEY_SLEEP Change To KEY_NULL!---\n");
            u8KeyCode = KEY_NULL;
        }
    }

  #if (ENABLE_CHCHANGETIME)
    if (u8KeyCode != KEY_NULL)
    {
        printf("[ch change time]start\n", u8KeyCode);
        gU32ChChangeTime = msAPI_Timer_GetTime0();
        gbKeyPress = TRUE;
    }
  #endif
  #if (ENABLE_SOURCECHANGETIME)
    if (u8KeyCode != KEY_NULL)
    {
        printf("[source change time]start\n", u8KeyCode);
        gU32SourceChangeTime= msAPI_Timer_GetTime0();
    }
  #endif


  #if (ENABLE_SWITCH_CHANNEL_TIME)
    if( (IsATVInUse()) && (u8KeyCode==KEY_CHANNEL_PLUS || u8KeyCode==KEY_CHANNEL_MINUS) )
    {
        if(u8KeyCode == KEY_CHANNEL_PLUS)
            printf("Press KEY_CHANNEL_PLUS\n");

        if(u8KeyCode == KEY_CHANNEL_MINUS)
            printf("Press KEY_CHANNEL_MINUS\n");

        if(u8KeyCode == KEY_CHANNEL_RETURN)
            printf("Press KEY_CHANNEL_RETURN\n");

        SwitchChannelTimeSetBegin();
    }
  #endif
    #if ENABLE_CUS_BLOCK_SYS
    if((u8KeyCode == KEY_SELECT) && (MApp_ZUI_GetActiveOSD() ==E_OSD_SCREEN_SAVER) &&
        ((SYS_SCREEN_SAVER_TYPE(MAIN_WINDOW) == EN_SCREENSAVER_LOCKED_PROGRAM)
        || (SYS_SCREEN_SAVER_TYPE(MAIN_WINDOW) == EN_SCREENSAVER_BLOCKRATING)))
    {
        u8KeyCode = KEY_NULL;
        MApp_ZUI_ACT_ShutdownOSD();
        MApp_BlockSys_ResetMsgbox2ScreenSaverTimer();
        MApp_ZUI_ACT_StartupOSD(E_OSD_MESSAGE_BOX);
        MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_SHOW_PASSWORD_INPUT_MSGBOX);
    }
    #endif

    MApp_SingleListen_ScreenMute_Check();

    MApp_IR_Custome_IRkeyFilter();

    MApp_SetKeyRepeatState(u8KeyCode);
}

/******************************************************************************/
static void MApp_SetKeyRepeatState(U8 u8KeyData)
{
    if ( u8KeyData == KEY_UP             ||
         u8KeyData == KEY_DOWN           ||
         u8KeyData == KEY_LEFT           ||
         u8KeyData == KEY_RIGHT          ||
         u8KeyData == KEY_VOLUME_PLUS    ||
         u8KeyData == KEY_VOLUME_MINUS   ||
         u8KeyData == KEY_CHANNEL_PLUS   ||
         u8KeyData == KEY_CHANNEL_MINUS ||
         u8KeyData == KEY_INPUT_SOURCE)
    {
        u8KeyRepeatState = OSD_REPEAT_ENABLE;
    }
    else
    {
        u8KeyRepeatState = OSD_REPEAT_DISABLE;
    }
}

#define System_Stable_Testing   0

#if System_Stable_Testing
#define KEY_TIMEOUT_1MS  (1000LU)
U8 Test_Key = 0;
U32 Test_Time = 0;
extern void MDrv_Power_ResetAndPowerUp();
#endif
/*
#if ENABLE_MSTV_UART_DEBUG

static BOOLEAN MApp_IsLocalkeyEnabled(U8 u8LocalKey)
{
    U8 u8key;

    u8key = u8LocalKey; // Reserved for  future use.

    if(stGenSetting.g_SysSetting.g_enKeyLock == EN_E5_KeyLock_On) // KeyLock in TvLink-Tuner & Child Lock in User Menu
    {
        if(MApp_TopStateMachine_GetTopState() == STATE_TOP_DIGITALINPUTS)
        {
            //ZUI: MApp_UiMenu_Show_Warning_Message_Dialog(MENU_KEY_LOCK_MSG);
            MApp_ZUI_ACT_StartupOSD(E_OSD_MESSAGE_BOX);
            MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_SHOW_KEY_LOCK_MSGBOX);

        }
        return FALSE;
    }
    return TRUE;
}
#endif // #if ENABLE_MSTV_UART_DEBUG
*/
static void MApp_CheckKeyStatus(void)
{
    U8 key;
    U8 KeyRepeatStatus;
    static U8 KeyCnt=0;
	static U32 u32KeydownTime = 0;
		static BOOL bIsPressed = FALSE;
		static U8 u8PrePressedKey = KEY_NULL;
		static U8 key2=KEY_NULL;

    if(!msAPI_IsMBIREnabled())//for OBAMA
    {
    
        if( msAPI_GetIRKey(&key, &KeyRepeatStatus) == MSRET_OK )
        {
           if((key!=KEY_NULL)&&(key2!=key))
		   	  bIsPressed=TRUE;
		   if((key!=KEY_NULL)&&(key2==key)&&(DIFFERENCE(u32KeydownTime, msAPI_Timer_GetTime0()) > 5000UL))
		   	{
           KEY_DEBUG( printf(" 1254 IR key = 0x%02bx, Repeat = %bu \n", key, KeyRepeatStatus) );
             bIsPressed=TRUE;
		   }
          if((bIsPressed == TRUE)&&(DIFFERENCE(u32KeydownTime, msAPI_Timer_GetTime0()) > 3000UL))
          	{
            stKeyStatus.keytype = KEY_TYPE_IR;
            stKeyStatus.keydown = TRUE;
            stKeyStatus.keydata = key;
            stKeyStatus.keyrepeat = KeyRepeatStatus;
			bIsPressed=FALSE;
			KeyCnt=1;
			key2=key;
            KEY_DEBUG( printf(" 1254 IR key = 0x%02bx, Repeat = %bu \n", key, KeyRepeatStatus) );
          	}
        }
        else if( msAPI_GetKeyPad(&key, &KeyRepeatStatus)== MSRET_OK )
        {
            stKeyStatus.keytype = KEY_TYPE_KEYPAD;
            stKeyStatus.keydown = TRUE;
            stKeyStatus.keydata = key;
            stKeyStatus.keyrepeat = KeyRepeatStatus;
            printf(" 1262 Keypad key = 0x%02bx, Repeat = %bu \n", key, KeyRepeatStatus);


			#if ENABLE_KEYPAD_FIVEKEY		
            if((key==IRKEY_RIGHT||key==IRKEY_LEFT||key==IRKEY_UP||key==IRKEY_DOWN ||key == IRKEY_POWER))	
				{
               switch(key)
               	{
	           #if ENABLE_KEYPAD_FIVEKEY		
                         case IRKEY_POWER:
                             if(MApp_ZUI_GetActiveOSD() ==E_OSD_MAIN_MENU)
					{
                                     stKeyStatus.keytype = KEY_TYPE_IR;
                                     stKeyStatus.keydata=IRKEY_SELECT;
                 			}
				 else if(IsStorageInUseMain() &&(MApp_ZUI_API_GetFocus()>=0x3C)&&(MApp_ZUI_API_GetFocus()<=0x7E)
			 	  &&(MApp_ZUI_GetActiveOSD()!= E_OSD_INPUT_SOURCE))
				 	{
                                     stKeyStatus.keytype = KEY_TYPE_IR;
                                     stKeyStatus.keydata=IRKEY_SELECT;
				 }
				//else if(IsStorageInUseMain() &&(MApp_DMP_GetDmpUiState(DMP_UI_STATE_FILE_SELECT)||MApp_DMP_GetDmpUiState(DMP_UI_STATE_MEDIA_SELECT)))//(MApp_MPlayer_QueryCurrentMediaType()==E_MPLAYER_TYPE_MUSIC)
				else if(IsStorageInUse()&&(( MApp_DMP_GetDmpUiState() == DMP_UI_STATE_MEDIA_SELECT)||( MApp_DMP_GetDmpUiState() == DMP_UI_STATE_FILE_SELECT)||( MApp_DMP_GetDmpUiState() == DMP_UI_STATE_DRIVE_SELECT)))
					{
                                                                                                      stKeyStatus.keytype = KEY_TYPE_IR;
                                     stKeyStatus.keydata=IRKEY_SELECT;
				}
				/*
				else if(IsStorageInUseMain()&&(MApp_DMP_GetDmpUiState()==DMP_UI_STATE_FILE_SELECT)&&((MApp_ZUI_API_GetFocus()>=0x3C)&&(MApp_ZUI_API_GetFocus()<=0x7E))&&((MApp_MPlayer_QueryCurrentMediaType()==E_MPLAYER_TYPE_MUSIC)||(MApp_MPlayer_QueryCurrentMediaType()==E_MPLAYER_TYPE_MOVIE) \
				||(MApp_MPlayer_QueryCurrentMediaType()==E_MPLAYER_TYPE_TEXT)))
				{
                                     stKeyStatus.keytype = KEY_TYPE_IR;
                                     stKeyStatus.keydata=IRKEY_PLAY;
				}
				*/
				      else
				      	{
                                     stKeyStatus.keydata = key;
					}
			 break;
	           #endif			
                   case  IRKEY_RIGHT:
                 	#if ENABLE_KEYPAD_FIVEKEY
                                if(IsATVInUse()&&((MApp_ZUI_GetActiveOSD()== E_OSD_CHANNEL_INFO)))
                                  {
                                       stKeyStatus.keytype = KEY_TYPE_IR;
                                       stKeyStatus.keydata=IRKEY_CHANNEL_PLUS;
                                  }
                                else if(MApp_ZUI_GetActiveOSD() ==E_OSD_INPUT_SOURCE)
                                  {
                                       stKeyStatus.keytype = KEY_TYPE_IR;
                                       stKeyStatus.keydata=IRKEY_SELECT;
                                  }
					else if(MApp_ZUI_GetActiveOSD() ==E_OSD_MAIN_MENU)
					{
                                     stKeyStatus.keytype = KEY_TYPE_IR;
                                     stKeyStatus.keydata=IRKEY_UP;
                 			}			
                                else if((IsStorageInUseMain() &&(MApp_ZUI_API_GetFocus()==0xA7||MApp_ZUI_API_GetFocus()== 0xFFFF))||MApp_ZUI_GetActiveOSD()==E_OSD_EMPTY||MApp_ZUI_GetActiveOSD()== E_OSD_AUDIO_VOLUME
					||MApp_ZUI_GetActiveOSD()== E_OSD_SCREEN_SAVER)
			               stKeyStatus.keydata=IRKEY_VOLUME_PLUS ;
					else if(MApp_MPlayer_IsMediaFileInPlaying() &&
                ((MApp_DMP_GetDmpFlag() & DMP_FLAG_MEDIA_FILE_PLAYING)
                /*|| (MApp_DMP_GetDmpFlag() & E_FLAG_THUMBNAIL_PLAYING)*/)&&(MApp_MPlayer_QueryCurrentMediaType()!=E_MPLAYER_TYPE_TEXT))
						{
                                           stKeyStatus.keydata=IRKEY_NEXT;
					}
				else if(MApp_DMP_GetDmpUiState() == DMP_UI_STATE_DRIVE_SELECT)
					{
                                     stKeyStatus.keytype = KEY_TYPE_IR;
                                     stKeyStatus.keydata=IRKEY_RIGHT;
                 			}	
                                else
			               stKeyStatus.keydata = key;
                 		#else
				if((IsStorageInUseMain() &&(MApp_ZUI_API_GetFocus()==0xA7||MApp_ZUI_API_GetFocus()== 0xFFFF))||MApp_ZUI_GetActiveOSD()==E_OSD_EMPTY||MApp_ZUI_GetActiveOSD()== E_OSD_AUDIO_VOLUME
					||MApp_ZUI_GetActiveOSD()== E_OSD_CHANNEL_INFO||MApp_ZUI_GetActiveOSD()== E_OSD_SCREEN_SAVER)
					{
			               stKeyStatus.keydata=IRKEY_VOLUME_PLUS ;
						   printf("====>>>>IRKEY_VOLUME_PLUS");
					}
			       else
                                      stKeyStatus.keydata = key;
                 		#endif
				break;
		  case  IRKEY_LEFT:
                 		#if ENABLE_KEYPAD_FIVEKEY
                                if(IsATVInUse()&&((MApp_ZUI_GetActiveOSD()== E_OSD_CHANNEL_INFO)||(MApp_ZUI_GetActiveOSD()== E_OSD_SCREEN_SAVER)||(MApp_ZUI_GetActiveOSD()==E_OSD_EMPTY)))
                                        {
                 	                       stKeyStatus.keytype = KEY_TYPE_IR;
                 			       stKeyStatus.keydata=IRKEY_CHANNEL_MINUS;
                 			}
                                else if(MApp_ZUI_GetActiveOSD() ==E_OSD_INPUT_SOURCE)
                                        {
                 	                       stKeyStatus.keytype = KEY_TYPE_IR;
                 			       stKeyStatus.keydata=IRKEY_SELECT;
                 			}
					else if(MApp_ZUI_GetActiveOSD() ==E_OSD_MAIN_MENU)
					{
                                     stKeyStatus.keytype = KEY_TYPE_IR;
                                     stKeyStatus.keydata=IRKEY_DOWN;
                 			}					
                                else if((IsStorageInUseMain() &&(MApp_ZUI_API_GetFocus()==0xA7||MApp_ZUI_API_GetFocus()== 0xFFFF))||MApp_ZUI_GetActiveOSD()==E_OSD_EMPTY||MApp_ZUI_GetActiveOSD()== E_OSD_AUDIO_VOLUME
					||MApp_ZUI_GetActiveOSD()== E_OSD_SCREEN_SAVER)		//xdl Changed  for Key 20100524
			                stKeyStatus.keydata=IRKEY_VOLUME_MINUS;
										else if(MApp_MPlayer_IsMediaFileInPlaying() &&
                ((MApp_DMP_GetDmpFlag() & DMP_FLAG_MEDIA_FILE_PLAYING)
                /*|| (MApp_DMP_GetDmpFlag() & E_FLAG_THUMBNAIL_PLAYING)*/)&&(MApp_MPlayer_QueryCurrentMediaType()!=E_MPLAYER_TYPE_TEXT))
						{
                                           stKeyStatus.keydata=IRKEY_PREVIOUS;
					}
					else if(MApp_DMP_GetDmpUiState() == DMP_UI_STATE_DRIVE_SELECT)
					{
                                     stKeyStatus.keytype = KEY_TYPE_IR;
                                     stKeyStatus.keydata=IRKEY_LEFT;
                 			}	
			       else
			                stKeyStatus.keydata=key;
                 		#else
				if((IsStorageInUseMain() &&(MApp_ZUI_API_GetFocus()==0xA7||MApp_ZUI_API_GetFocus()== 0xFFFF))||MApp_ZUI_GetActiveOSD()==E_OSD_EMPTY||MApp_ZUI_GetActiveOSD()== E_OSD_AUDIO_VOLUME
					||MApp_ZUI_GetActiveOSD()== E_OSD_CHANNEL_INFO||MApp_ZUI_GetActiveOSD()== E_OSD_SCREEN_SAVER)		//xdl Changed  for Key 20100524
					{
			                stKeyStatus.keydata=IRKEY_VOLUME_MINUS;
							printf("====>>>>IRKEY_VOLUME_MINUS");
					}
			       else
			                stKeyStatus.keydata=key;
                 		#endif
				break;
		  case  IRKEY_UP:
		  	if(IsStorageInUseMain() &&(MApp_ZUI_GetActiveOSD()!= E_OSD_INPUT_SOURCE))	//xdl Changed  for Key 20100524
		  		{
		  		   if(MApp_ZUI_API_GetFocus()== 0xFFFF)
					MApp_ZUI_SetActiveOSD(0x12);
				    stKeyStatus.keydata=IRKEY_SELECT;
		  		}
			else  
				#if (ENABLE_INPUT_LOCK)
				if(MApp_ZUI_GetActiveOSD()==E_OSD_EMPTY\
				    ||MApp_ZUI_GetActiveOSD()== E_OSD_AUDIO_VOLUME\
				    ||MApp_ZUI_GetActiveOSD()== E_OSD_CHANNEL_INFO\
				    ||MApp_ZUI_GetActiveOSD()== E_OSD_SCREEN_SAVER\
				    ||(MApp_ZUI_ACT_ExecuteMessageBoxAction(EN_EXE_QUERY_IS_PASSWORD_INPUT_MSG_BOX)&&MApp_UiMenuFunc_CheckInputLock())\
				   )	
				#else
				if(MApp_ZUI_GetActiveOSD()==E_OSD_EMPTY\
				    ||MApp_ZUI_GetActiveOSD()== E_OSD_AUDIO_VOLUME\
				    ||MApp_ZUI_GetActiveOSD()== E_OSD_CHANNEL_INFO\
				    ||MApp_ZUI_GetActiveOSD()== E_OSD_SCREEN_SAVER)
				#endif
				{
			     stKeyStatus.keytype = KEY_TYPE_IR;
				 if(MApp_ZUI_GetActiveOSD()== E_OSD_INPUT_SOURCE)//added by CHENJIE FOR INPUTLOCK OPEN SOURCE OSD KEYPAD CAN'T CHOOSE 20130711
				 stKeyStatus.keydata=IRKEY_UP;
				 else
				 stKeyStatus.keydata=IRKEY_CHANNEL_PLUS;
				}
			else
			    stKeyStatus.keydata=key;
          				break;
         		  case  IRKEY_DOWN:
		  	if(IsStorageInUseMain() &&(MApp_ZUI_GetActiveOSD()==E_OSD_DMP||MApp_ZUI_GetActiveOSD()==E_OSD_EMPTY||MApp_ZUI_GetActiveOSD()== E_OSD_AUDIO_VOLUME||MApp_ZUI_API_GetFocus()== 0xFFFF)&&(MApp_ZUI_GetActiveOSD()!= E_OSD_INPUT_SOURCE))
		  		{
		  		if(MApp_ZUI_API_GetFocus()== 0xFFFF)
					MApp_ZUI_SetActiveOSD(0x12);
				    stKeyStatus.keydata=IRKEY_EXIT;	
		  		}
			else
				#if(ENABLE_INPUT_LOCK)
				if(MApp_ZUI_GetActiveOSD()==E_OSD_EMPTY\
			        ||MApp_ZUI_GetActiveOSD()== E_OSD_AUDIO_VOLUME\
					||MApp_ZUI_GetActiveOSD()== E_OSD_CHANNEL_INFO\
					||MApp_ZUI_GetActiveOSD()== E_OSD_SCREEN_SAVER\
					||(MApp_ZUI_ACT_ExecuteMessageBoxAction(EN_EXE_QUERY_IS_PASSWORD_INPUT_MSG_BOX)&&MApp_UiMenuFunc_CheckInputLock())\
				   )	
				#else
				if(MApp_ZUI_GetActiveOSD()==E_OSD_EMPTY\
			             ||MApp_ZUI_GetActiveOSD()== E_OSD_AUDIO_VOLUME\
					||MApp_ZUI_GetActiveOSD()== E_OSD_CHANNEL_INFO\
					||MApp_ZUI_GetActiveOSD()== E_OSD_SCREEN_SAVER)
				#endif
				{
                 stKeyStatus.keytype = KEY_TYPE_IR;
				 if(MApp_ZUI_GetActiveOSD()== E_OSD_INPUT_SOURCE)//added by CHENJIE FOR INPUTLOCK OPEN SOURCE OSD KEYPAD CAN'T CHOOSE 20130711
	             stKeyStatus.keydata=IRKEY_DOWN;
				 else
	             stKeyStatus.keydata=IRKEY_CHANNEL_MINUS;
				}
			else
			    stKeyStatus.keydata=key;
			break;
		 default:
		 	 stKeyStatus.keydata=key;
			 break;
            	}
            	}
			#endif//*endif ENABLE_KEYPAD_FIVEKEY
        }
        /*
        else if (enMenuFlowState == FS_WAIT_MENU
            && msAPI_Timer_DiffTimeFromNow(u32IRTimer) > 8000)
        {
            stKeyStatus.keytype = KEY_TYPE_IR;
            stKeyStatus.keydown = TRUE;
            stKeyStatus.keydata = 0x52;
            stKeyStatus.keyrepeat = 0;

            printf("keydata = 0x52\n");

            u32IRTimer = msAPI_Timer_GetTime0();
        }
       */

 //This condition will affect remote control lock. When rc lock,  KEY_TYPE_KEYPAD images KEY_TYPE_IR occasionally  @helen 2012-08-20
 #if 0
       /* This chicking is used to auto bench testing */
#if ENABLE_MSTV_UART_DEBUG
        else if ( msAPI_GetKeyPad(&key, &KeyRepeatStatus)== MSRET_OK && MApp_IsLocalkeyEnabled(key))
        {
            /* The UART simulates the IR key, so we set keytyps as IR key type*/
            stKeyStatus.keytype = KEY_TYPE_IR;
            stKeyStatus.keydown = TRUE;
            stKeyStatus.keydata = key;
            stKeyStatus.keyrepeat = KeyRepeatStatus;
			KEY_DEBUG(printf(" 1288 Keypad key = 0x%02bx, Repeat = %bu \n", key, KeyRepeatStatus));
        }
#endif
#endif
        else
        {
        #if (IR_MODE_SEL == IR_TYPE_FULLDECODE_MODE)
            if (u8IRTimerBlockstatus == 0xff)
            {
                stKeyStatus.keydown = FALSE;
                stKeyStatus.keydata = KEY_NULL;
            }
            else
        #endif
            {
                stKeyStatus.keydown = FALSE;
                stKeyStatus.keydata = KEY_NULL;
                stKeyStatus.keyrepeat = FALSE;
            }
        }
    }
    else
    {
    printf("TTT Keypad key value = 0x%02x, KeyRepeatStatus = %u \n", key, KeyRepeatStatus);
        if ( msAPI_GetKeyPad(&key, &KeyRepeatStatus)== MSRET_OK )
        {
            stKeyStatus.keytype = KEY_TYPE_KEYPAD;
            stKeyStatus.keydown = TRUE;
            stKeyStatus.keydata = key;
            stKeyStatus.keyrepeat = KeyRepeatStatus;
            //printf(" Keypad key value = 0x%02x, KeyRepeatStatus = %u \n", key, KeyRepeatStatus);
        }
        else if(mbir.empty)
        {
            stKeyStatus.keydown   = FALSE;
            stKeyStatus.keydata   = KEY_NULL;
            stKeyStatus.keyrepeat = FALSE;
        }
        else
        {
            stKeyStatus.keytype=KEY_TYPE_IR;
            stKeyStatus.keydown=TRUE;
            stKeyStatus.keydata=(U8)mbir.keydata;
            stKeyStatus.keyrepeat=mbir.repeat;
            mbir.empty=TRUE;
        }
    }

#if System_Stable_Testing
    if (Test_Key != 0)
    {
        stKeyStatus.keytype = KEY_TYPE_IR;
        stKeyStatus.keydown = TRUE;
        stKeyStatus.keyrepeat = 0;
		//KEY_DEBUG(printf(" 1340 Keypad key = 0x%02bx, Repeat = %bu \n", key, KeyRepeatStatus));
    }
#endif
}

#define System_Script_Testing   0


#if System_Script_Testing
U8 u8KeyScriptOn=0;

U8 code u8ScriptKeys[] =
{
    KEY_CHANNEL_PLUS,KEY_CHANNEL_PLUS,0x81,KEY_EXIT, 0x83,
    KEY_CHANNEL_MINUS,KEY_CHANNEL_MINUS,0x81,KEY_EXIT, 0x83,

    #if 0
    // rotate OSD
    KEY_MENU, KEY_RIGHT, KEY_RIGHT,
    //  scan channel
    KEY_SELECT, KEY_DOWN, KEY_DOWN, KEY_SELECT, KEY_DOWN, KEY_GREEN, 0x85,
    // adjust volume
    KEY_VOLUME_PLUS, KEY_VOLUME_PLUS, KEY_VOLUME_PLUS, 0x83,
    // change channel,
    KEY_SELECT, KEY_UP, KEY_SELECT, 0x84,
    // change to PC
    KEY_INPUT_SOURCE, KEY_UP, KEY_SELECT, 0x83,
    // mute
    KEY_MUTE,
    #endif
};

U16 u16ScriptIndex = 0;
U32 u32WaitTime = 0;
#endif // #if System_Script_Testing


#if (CHIP_FAMILY_TYPE == CHIP_FAMILY_M10) || (CHIP_FAMILY_TYPE == CHIP_FAMILY_M12)
BOOLEAN MDrv_Power_CheckPowerOnKey(void)
{
    U8 key;
    U8 KeyRepeatStatus;
    KEYSTAT tmpKeyStatus;
  
	 
    if ( msAPI_GetIRKey(&key, &KeyRepeatStatus) == MSRET_OK )
    {
       
        tmpKeyStatus.keytype = KEY_TYPE_IR;
        tmpKeyStatus.keydown = TRUE;
        tmpKeyStatus.keydata = key;
        tmpKeyStatus.keyrepeat = KeyRepeatStatus;
        KEY_DEBUG( printf(" IR key value = 0x%02bx, KeyRepeatStatus = %bu \n", key, KeyRepeatStatus) );
    }
    else if ( msAPI_GetKeyPad(&key, &KeyRepeatStatus)== MSRET_OK )
    {
        tmpKeyStatus.keytype = KEY_TYPE_KEYPAD;
        tmpKeyStatus.keydown = TRUE;
        tmpKeyStatus.keydata = key;
        tmpKeyStatus.keyrepeat = KeyRepeatStatus;
        KEY_DEBUG(printf(" Keypad key value = 0x%02bx, KeyRepeatStatus = %bu \n", key, KeyRepeatStatus));
    }

    if ( tmpKeyStatus.keydown )
    {
        MApp_ParseKey();

        if ( tmpKeyStatus.keydata == IRKEY_POWER )
            return TRUE;
    }

    return FALSE;
}
#endif // #if (CHIP_FAMILY_TYPE == CHIP_FAMILY_M10) || (CHIP_FAMILY_TYPE == CHIP_FAMILY_M12)


/******************************************************************************/
#define PRESS_RELEASE_TIMEOUT 150 // ms
extern void MApp_DMP_SetMediaKey (U8 u8Key);
extern BOOLEAN MApp_DMP_IsMediaType(void);

void MApp_ProcessUserInput(void)
{
  #if (ENABLE_MHL == ENABLE)
    static U32 u32KeydownTime = 0;
    static BOOL bIsPressed = FALSE;
    static U8 u8PrePressedKey = KEY_NULL;
  #endif

    MApp_CheckKeyStatus();

#if (IR_ENABLE_UART_INPUT)
    if ( !stKeyStatus.keydown )
    {
        if (kbhit())
        {
            stKeyStatus.keydata = getchar();
            stKeyStatus.keydown = 1;
            if ( stKeyStatus.keydata == 0 )
            {
                stKeyStatus.keydown = 0;
            }

            stKeyStatus.RepeatEnable = 0;
            stKeyStatus.keyrepeat = 0;
        }
    }
#endif

    if ( stKeyStatus.keydown )
    {
        MApp_ParseKey();

        if(u8KeyCode != KEY_NULL && MApp_DMP_IsMediaType())
        MApp_DMP_SetMediaKey(u8KeyCode);

	#if (ENABLE_ARABIC_OSD)
		if ( !msAPI_OSD_GetDivxSubtitleMode() )
		{
			switch ( MApp_GetMenuLanguage() )
			{
          #if (ENABLE_ARABIC_TEST_UI)
            case LANGUAGE_SPANISH:
          #endif
			case LANGUAGE_ARABIC:
			case LANGUAGE_PARSI:
			case LANGUAGE_KURDISH:
			case LANGUAGE_HEBREW:
				if ( u8KeyCode == KEY_LEFT )
				{
					u8KeyCode = KEY_RIGHT;
				}
				else if ( u8KeyCode == KEY_RIGHT )
				{
					u8KeyCode = KEY_LEFT;
				}
				break;
			default:
				break;
			}
		}
    #endif // #if (ENABLE_ARABIC_OSD)

    //MHL
  #if (ENABLE_MHL == ENABLE)
    if ((UI_INPUT_SOURCE_TYPE == HDMI_PORT_FOR_MHL) \
     && msAPI_MHL_IsCbusConnected() \
     && (MApp_TopStateMachine_GetTopState() == STATE_TOP_DIGITALINPUTS)\
       )
    {
        if (msAPI_MHL_IRKeyProcess(u8KeyCode, FALSE))
        {
            //printf("0x%x Key Pressed\r\n", u8KeyCode);
            u8PrePressedKey = u8KeyCode;
            u8KeyCode = KEY_NULL;
            u32KeydownTime = msAPI_Timer_GetTime0();
            bIsPressed = TRUE;
            return;
        }
        else
        {
            //printf("MHL IR key False\r\n");
        }
    }
  #endif


    #if(ENABLE_CEC)
     if( (UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_HDMI)
    #if (INPUT_HDMI_VIDEO_COUNT >= 2)
         || (UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_HDMI2)
    #if (INPUT_HDMI_VIDEO_COUNT >= 3)
         || (UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_HDMI3)
    #endif
    #endif
      )
     {
            if(msAPI_CEC_IrdaKeyProcess(u8KeyCode))
            {
                return;
            }
     }
    #endif // #if(ENABLE_CEC)


    #if (FRONTEND_IF_DEMODE_TYPE == MSTAR_VIF_MSB1210)
        #if (MSTAR_VIF_MSB1210_DEBUG_MODE==1)
            if (MApp_ProcessUserInput_MSVIF_Debug(u8KeyCode)==1)
            return;
        #endif
    #endif

        #if System_Script_Testing
        if ( u8KeyCode == KEY_GREEN )
        {
            if(u8KeyScriptOn)
                u8KeyScriptOn=0;
            else
                u8KeyScriptOn=1;
        }
    #endif // #if System_Script_Testing

#if MHEG5_ENABLE
        if ( u8KeyCode == KEY_POWER )
            MApp_ChannelPosition_Restore();
#endif

   #if MCU_AEON_ENABLE
        // TODO, For debug only, remove it later!
        if ( u8KeyCode == KEY_UARTDEBUGPORT )
        {
            u8KeyCode = KEY_NULL;
        }

        #if (MHEG5_ENABLE && DEBUG_SYS_INFO_REPORT)
        // Query System Inormation
        else if(u8KeyCode == KEY_INFO)
            msAPI_System_StatusReport();
        #endif

    #endif // #if MCU_AEON_ENABLE

#if (ENABLE_CUS_AUTO_SLEEP_MODE == DISABLE)
        MApp_Sleep_SetAutoOn_OffTime(DISABLE);
#endif

        // Enter Serial Debug Mode through IR Command 8033
        switch ( u8HwDebugFlag )
        {
            case 1:
                if ( u8KeyCode == KEY_0 )
                {
                    u8HwDebugFlag++;
                }
                else
                {
                    u8HwDebugFlag=0;
                }
                break;

            case 2:
                if (u8KeyCode == KEY_3)
                {
                    u8HwDebugFlag++;
                }
                else
                {
                    u8HwDebugFlag=0;
                }
                break;

            case 3:
                if (u8KeyCode == KEY_4)
                {
                }
              #if (ENABLE_DMP)
                else if (u8KeyCode == KEY_9)
                {
                    MApp_VDPlayer_UartSwitch(E_UART_SWITCH_TO_HK);
                    u8HwDebugFlag=0;
                }
                else if (u8KeyCode == KEY_0)
                {
                    MApp_VDPlayer_UartSwitch(E_UART_SWITCH_TO_COPROCESSOR);
                    u8HwDebugFlag=0;
                }
                else if (u8KeyCode == KEY_3)
                {
                    MApp_VDPlayer_UartSwitch(E_UART_SWITCH_TO_VDEC);
                    u8HwDebugFlag=0;
                }
              #endif
                else
                {
                    u8HwDebugFlag=0;
                }
                break;

            case 0:
                if (u8KeyCode == KEY_8)
                {
                    u8HwDebugFlag++;
                }
                else
                {
                    u8HwDebugFlag=0;
                }
                break;

            default :
                u8HwDebugFlag=0;
                break;
        }

        // End Enter Serial Debug Mode through IR Command 8033
      #if (IR_MODE_SEL == IR_TYPE_SWDECODE_NEC_MODE)
        if(msIsNECKeyRepeat())
      #endif

        if ( stKeyStatus.keyrepeat )
        {
            switch ( u8KeyRepeatState )
            {
            case OSD_REPEAT_DISABLE:
				//u8KeyCode = KEY_NULL;
				//break;
				//add for hotel menu remote control lock: run msgbox @chuxu 2012-08-13
			#if CUS_SMC_ENABLE_HOTEL_MODE
				if(stGenSetting.g_FactorySetting.HotelMenuHotelModeOperationEnable == ENABLE)
				{
					if((stGenSetting.g_FactorySetting.HotelMenuRometeControlLockEnable == ENABLE)&&(stKeyStatus.keytype == KEY_TYPE_IR))
						{
							break;
						}
					else if(stGenSetting.g_FactorySetting.HotelMenuOSDDisplayEnable== ENABLE)
						{
							break;
						}
				}
				else
					{
						u8KeyCode = KEY_NULL;
						break;
					}
			#else
				u8KeyCode = KEY_NULL;
				break;
			#endif

            case OSD_REPEAT_H_ENABLE:
                if (u8KeyCode == KEY_UP || u8KeyCode == KEY_DOWN)
                {
                     u8KeyCode = KEY_NULL;
                }
                break;

            case OSD_REPEAT_V_ENABLE:
                if ( u8KeyCode == KEY_LEFT || u8KeyCode == KEY_RIGHT)
                {
                     u8KeyCode = KEY_NULL;
                }
                break;
            }
        }


        //Rex.Wang Test
      #if (SLOW_IR_SPEED_FOR_MM_NOCLOCKING)
        u8KeyCode = SlowDownIRSpeed(u8KeyCode, stKeyStatus.keyrepeat, stKeyStatus.keydown);
        #endif

#if (NO_SIGNAL_AUTO_SHUTDOWN==1)

        u32NoSignal_MonitorStartTime = msAPI_Timer_GetTime0();
        u32MonitorOsdTimer = msAPI_Timer_GetTime0();
#endif
        if (stKeyStatus.KeyFilterPower)
        {
            stKeyStatus.KeyFilterPower = FALSE;
            #if (CHIP_FAMILY_TYPE==CHIP_FAMILY_M10) || (CHIP_FAMILY_TYPE==CHIP_FAMILY_M12)
            msIR_ProcessUserKey(TRUE);
            #endif
          #if 0  //cause fisrt press power key has be filter
            if (((u8KeyCode == KEY_POWER) || (u8KeyCode == DSC_KEY_PWROFF)))
            {
                u8KeyCode = KEY_NULL;
            }
          #endif
        }
    }
  #if (ENABLE_MHL == ENABLE)
    else if ((UI_INPUT_SOURCE_TYPE == HDMI_PORT_FOR_MHL) && msAPI_MHL_IsCbusConnected())
    {
        if ((bIsPressed == TRUE)&&(DIFFERENCE(u32KeydownTime, msAPI_Timer_GetTime0()) > PRESS_RELEASE_TIMEOUT))
        {
            if (msAPI_MHL_IRKeyProcess(u8PrePressedKey, TRUE))
            {
                //printf("0x%x Key Released\r\n", u8PrePressedKey);
                u8PrePressedKey = KEY_NULL;
                u8KeyCode = KEY_NULL;
                bIsPressed = FALSE;
                return;
            }
            else
            {
                //printf("MHL IR key False\r\n");
            }
        }
    }
  #endif

  else
  {
  	//printf("\N FOR TEST RELEASE KEY \n");
 // 	u16MenuKeyCounter = 0;
  }


    #if System_Script_Testing
    if(u8KeyScriptOn)
    {
        if (u16ScriptIndex < sizeof(u8ScriptKeys) / sizeof(u8ScriptKeys[0]))
        {
            if (u8ScriptKeys[u16ScriptIndex] & 0x80)
            {
                if (msAPI_Timer_DiffTime( msAPI_Timer_GetTime0(), u32WaitTime ) >
                    (u8ScriptKeys[u16ScriptIndex] & 0x7F) * 1000LU)
                {
                    u16ScriptIndex++;
                }
                u8KeyCode = KEY_NULL;
            }
            else
            {
                if (msAPI_Timer_DiffTime( msAPI_Timer_GetTime0(), u32WaitTime ) > 200LU)
                {
                    u32WaitTime = u32MonitorOsdTimer = msAPI_Timer_GetTime0();
                    u8KeyCode = u8ScriptKeys[u16ScriptIndex++];
                }

                else
                {
                    u8KeyCode = KEY_NULL;
                }
            }
        }
        else
        {
            u16ScriptIndex=0;
        }
    }
    #endif

    /* simple key leaner */
#define STUDY_BEGIN_KEY        KEY_NULL//KEY_INDEX
#define STUDY_SEND_KEY        KEY_HOLD

    if (STUDY_BEGIN_KEY != KEY_NULL && STUDY_SEND_KEY != KEY_NULL)
    {
#define SK_STATE_NONE  0
#define SK_STATE_LEARN 1
#define SK_STATE_SEND  2
#define SK_STATE_DELAY 3

        static U32 WaitTime;
        static U8 Keys[16];
        static U8 NumberOfKeys = 0;
        static U8 CurrentKeyIndex = 0;
        static U8 state = SK_STATE_NONE;
        static U8 u8LastKey = KEY_NULL;

        switch (state)
        {
        default:
        case SK_STATE_NONE:
            if (u8KeyCode == STUDY_BEGIN_KEY)    // begin of study
            {
                NumberOfKeys = 0;
                state = SK_STATE_LEARN;
                u8KeyCode = KEY_NULL;
//                printf("+\n");
            }
            else if (u8KeyCode == STUDY_SEND_KEY)// start to send keys
            {
                if (NumberOfKeys)
                {
                    CurrentKeyIndex = 0;
                    state = SK_STATE_SEND;
                    u8KeyCode = KEY_NULL;
//                    printf(">\n");
                }
            }
            break;

        case SK_STATE_LEARN:
            if (u8KeyCode == KEY_NULL)
                break;
            if (u8LastKey == STUDY_SEND_KEY)        // escape key
            {
                u8LastKey = KEY_NULL;

                // delay time
                if (u8KeyCode >= KEY_0 && u8KeyCode <= KEY_9)
                    u8KeyCode = 0x81 - KEY_0 + u8KeyCode;
            }
            else if (u8KeyCode == STUDY_SEND_KEY)    // escape
            {
                u8LastKey = u8KeyCode;
                u8KeyCode = KEY_NULL;
                break;
            }
            else if (u8KeyCode == STUDY_BEGIN_KEY)    // end of study
            {
                state = SK_STATE_NONE;
                u8KeyCode = KEY_NULL;
//                printf("-%d\n", (int)NumberOfKeys);
                break;
            }
            if (NumberOfKeys >= (sizeof(Keys) / sizeof(Keys[0])))
                break;
            Keys[NumberOfKeys++] = u8KeyCode;
//            printf("%x\n", (int)u8KeyCode);

            if (u8KeyCode >= 0x80)
                u8KeyCode = KEY_NULL;
            break;

        case SK_STATE_SEND:
        case SK_STATE_DELAY:
            if (u8KeyCode == STUDY_SEND_KEY)        // stop send
            {
                state = SK_STATE_NONE;
                u8KeyCode = KEY_NULL;
//                printf("<\n");
            }
            else
            {
                u32MonitorOsdTimer = msAPI_Timer_GetTime0();
                if (CurrentKeyIndex >= NumberOfKeys)
                    CurrentKeyIndex = 0;
                u8KeyCode = Keys[CurrentKeyIndex];
                if (u8KeyCode >= 0x80 /* && u8KeyCode <= 0x80 + 10 */)    // commented out for bank overflow
                {
                    if (state == SK_STATE_SEND)
                    {
                        state = SK_STATE_DELAY;
                        WaitTime = msAPI_Timer_GetSystemTime();
                    }
                    else if ((msAPI_Timer_GetSystemTime() - WaitTime) >= (U32)(u8KeyCode & 0x7F))
                    {
                        state = SK_STATE_SEND;
                        CurrentKeyIndex++;
                    }
                    u8KeyCode = KEY_NULL;
                    break;
                }
                CurrentKeyIndex++;
            }
            break;
        }
    }

}

/******************************************************************************/
void MApp_Key_Initial_Status(void)
{
    stKeyStatus.KeyFilterPower = TRUE;
#if (CHIP_FAMILY_TYPE==CHIP_FAMILY_M10) || (CHIP_FAMILY_TYPE==CHIP_FAMILY_M12)
   if (msAPI_Power_QueryPowerOnMode()== EN_POWER_AC_BOOT)
   {
      msIR_ProcessUserKey(TRUE);
   }
   else
   {
      msIR_ProcessUserKey(FALSE);
   }
#endif
    msAPI_ClearIRFIFO();

#ifdef SUPPORT_IR_CUS_FACTORY
    CUSFactoryRCKeyInit();
#endif

}

/******************************************************************************/
BOOLEAN MApp_GetCurrentKeyType(void)
{
    return stKeyStatus.keytype;
}

BOOLEAN MApp_KeyIsReapeatStatus(void)
{
    //printf("stKeyStatus.keyrepeat %bu\n", stKeyStatus.keyrepeat);
    if ((stKeyStatus.keyrepeat == TRUE )&&(stKeyStatus.keydata != KEY_NULL))
    {
        return TRUE;
    }

    return FALSE;
}

void MApp_GetMBIR(ST_MBIR* pMBIR)
{
    memcpy(pMBIR,&mbir,sizeof(ST_MBIR));

}

void MApp_FillMBIR(U8 keycode, U8 repeat)
{
    mbir.empty=FALSE;
    mbir.keydata=keycode;
    mbir.repeat=repeat;
}

void MApp_ClearMBIR(void)
{
    mbir.empty=TRUE;
    mbir.keydata=0xFFFF;
    mbir.repeat=FALSE;
}

void MApp_SetMBIRFlag(U8 val)
{
    mbir.flag=val;
}

U8 MApp_GetMBIRFlag(void)
{
    return mbir.flag;
}

#if (FRONTEND_IF_DEMODE_TYPE == MSTAR_VIF_MSB1210)
#if (MSTAR_VIF_MSB1210_DEBUG_MODE==1)

U8 MApp_ProcessUserInput_MSVIF_Debug(U8 keycode)
{
#if 0 //Debug
    printf("--Key = 0x%bx (gGemini_KeyState = 0x%bx)\n",keycode,gGemini_KeyState);
    printf("--gGemini_FactoryMode_Enable = 0x%bx (gGemini_KeyValue = 0x%bx)\n"
        ,gGemini_FactoryMode_Enable,gGemini_KeyValue);
#endif

    switch (keycode)
    {
        case KEY_1:
                if (gGemini_KeyState == GEMINI_KEY_WAIT_1)
            {
                    gGemini_KeyState = GEMINI_KEY_WAIT_2;
            }
                else
                {
                    gGemini_KeyState = GEMINI_KEY_NONE;
                }
        break;

        case KEY_2:
                if (gGemini_KeyState == GEMINI_KEY_WAIT_2)
            {
                    gGemini_KeyState = GEMINI_KEY_WAIT_3;
            }
                else
                {
                    gGemini_KeyState = GEMINI_KEY_NONE;
                }
        break;

        case KEY_3:
                if (gGemini_KeyState == GEMINI_KEY_WAIT_3)
                {
                    gGemini_KeyState = GEMINI_KEY_NONE;
                    gGemini_FactoryMode_Enable=1;
                    gGemini_GetKey = GEMINI_GET_KEY_1;
                    gGemini_KeyValue=0XFF;
                    printf("---> MSVIF Debug Enable...\n");
                }
                else
                {
                    gGemini_KeyState = GEMINI_KEY_NONE;
                }
        break;

        case KEY_RED:
                if (gGemini_FactoryMode_Enable ==1)
                {
                    gGemini_KeyState = GEMINI_KEY_NONE;
                    gGemini_FactoryMode_Enable = 0;
                    printf("---> MSVIF Debug Disable...\n");
                    break;
            }
            else
                {
                    if (gGemini_KeyState == GEMINI_KEY_NONE)
                        gGemini_KeyState = GEMINI_KEY_WAIT_1;
                    else
                    {
                        gGemini_KeyState = GEMINI_KEY_NONE;
                    }
                }
        break;

        default:
        break;
    }

    if (gGemini_FactoryMode_Enable == 1)
    {
        //To support Gemini Key Factory Mode from 1 to 15
           if ((keycode >= KEY_0) &&(keycode <= KEY_9) )
           {
            if (gGemini_GetKey == GEMINI_GET_KEY_1)
               {
                gGemini_KeyValue = keycode & 0x0F;
                gGemini_GetKey = GEMINI_GET_KEY_2;
            }
            else
            {
                gGemini_KeyValue = (gGemini_KeyValue *10) + (keycode & 0x0F);
                gGemini_GetKey = GEMINI_GET_KEY_1;
            }
       }

         if (keycode == KEY_SELECT)
         {
            printf("---> MSVIF Get Key = (0x%bx)\n",gGemini_KeyValue);
            if (gGemini_KeyValue <= 15)
            {
                gVifTop = gGemini_KeyValue;
                printf("---> MSVIF Call msVifTopAdjust(0x%bx)\n",gGemini_KeyValue);
                msVifTopAdjust(gVifTop);
            }

            gGemini_GetKey = GEMINI_GET_KEY_1;
            gGemini_KeyValue = 0XFF;
         }
    }

    if ((gGemini_FactoryMode_Enable == 1)||(gGemini_KeyState != GEMINI_KEY_NONE))
    {
         if (((keycode >= KEY_0) &&(keycode <= KEY_9) )
             ||(keycode == IRKEY_RED)||(keycode == KEY_SELECT))
            return (1);
    }

    return (0);
}

#endif // #if (MSTAR_VIF_MSB1210_DEBUG_MODE==1)
#endif // #if (FRONTEND_IF_DEMODE_TYPE == MSTAR_VIF_MSB1210)





#undef MAPP_IR_C

