////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (MStar Confidential Information!�L) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef __API_CHPROC_H__
#define __API_CHPROC_H__

#include "MApp_GlobalSettingSt.h"
#include "msAPI_DTVSystem.h"
#include "msAPI_Tuner.h"
#include "debug.h"
//------------------------------------------------------------------------------
// Public attributes.
//------------------------------------------------------------------------------
#define INVALID_ORDINAL                 0xFFFF
#define INVALID_ATV_PROGRAM_NUMBER      0xFF

typedef enum
{
    E_SERVICE_ATTR_TYPE             = 0x70,
    E_SERVICE_ATTR_NUMBER           = 0x71,
    E_SERVICE_ATTR_NAME             = 0x72,
    E_SERVICE_ATTR_SKIPPED          = 0x73,
    E_SERVICE_ATTR_FAVORITE         = 0x74,
    E_SERVICE_ATTR_LOCKED           = 0x75,
    E_SERVICE_ATTR_VISIBLE          = 0x76,
    E_SERVICE_ATTR_NUMERIC          = 0x77
} SERVICE_ATTRIBUTE_MEMBER;

//------------------------------------------------------------------------------
// Public functions.
//------------------------------------------------------------------------------

WORD msAPI_CHPROC_CM_GetCurrentOrdinal(MEMBER_SERVICETYPE bServiceType, E_MEMBER_PROGRAM_ACCESSIBLE_BOUNDARY eBoundary);
BOOLEAN msAPI_CHPROC_CM_SetCurrentOrdinal(MEMBER_SERVICETYPE bServiceType, WORD wOrdinal,  E_MEMBER_PROGRAM_ACCESSIBLE_BOUNDARY eBoundary);
WORD msAPI_CHPROC_CM_CountProgram(MEMBER_SERVICETYPE bServiceType, E_MEMBER_PROGRAM_ACCESSIBLE_BOUNDARY eBoundary);
WORD msAPI_CHPROC_CM_CountFavoriteProgram(MEMBER_SERVICETYPE bServiceType);
WORD msAPI_CHPROC_CM_GetFirstFavoriteOrdinal(MEMBER_SERVICETYPE bServiceType, BOOLEAN bIncludeSkipped);
WORD msAPI_CHPROC_CM_GetNextFavoriteOrdinal(MEMBER_SERVICETYPE bServiceType, WORD wBaseOrdinal, BOOLEAN bIncludeSkipped);
//WORD msAPI_CHPROC_CM_GetSimilarOrdinals(MEMBER_SERVICETYPE bServiceType, WORD wPressedNumber, WORD * pwOrdinal, BYTE cSizeOfBuffer);
WORD msAPI_CHPROC_CM_GetMatchedOrdinals(MEMBER_SERVICETYPE bServiceType, WORD wPressedNumber);
BOOLEAN msAPI_CHPROC_CM_GetAttributeOfOrdinal(MEMBER_SERVICETYPE bServiceType, WORD wOrdinal, BYTE * pcBuffer, SERVICE_ATTRIBUTE_MEMBER eAttributeMember, E_MEMBER_PROGRAM_ACCESSIBLE_BOUNDARY eBoundary);
BOOLEAN msAPI_CHPROC_CM_SetMove2CurrentOrdinal(MEMBER_SERVICETYPE bServiceType, WORD wOrdinal, E_MEMBER_PROGRAM_ACCESSIBLE_BOUNDARY eBoundary);
#if ENABLE_SBTVD_BRAZIL_CM_APP
void msAPI_CHPROC_CM_InitOridial(void);
WORD msAPI_CHPROC_CM_GetNextOrdinal(MEMBER_SERVICETYPE bServiceType, WORD wBaseOrdinal, BOOLEAN bIncludeSkipped);
WORD msAPI_CHPROC_CM_GetPrevOrdinal(MEMBER_SERVICETYPE bServiceType, WORD wBaseOrdinal, BOOLEAN bIncludeSkipped);
WORD msAPI_CHPROC_CM_GetOrdinal_Brazil(MEMBER_SERVICETYPE bServiceType,WORD wPosition);
BOOLEAN msAPI_CHPROC_CM_GetOrdinal_SerType_Position_Brazil(WORD wOridinal,MEMBER_SERVICETYPE * pbServiceType,WORD * pwPosition);
MEMBER_SERVICETYPE msAPI_CHPROC_CM_GetServiceTypeByLCN_Brazil(WORD wPosition,WORD * wOridinal);
#endif
#endif // __API_CHPROC_H__

