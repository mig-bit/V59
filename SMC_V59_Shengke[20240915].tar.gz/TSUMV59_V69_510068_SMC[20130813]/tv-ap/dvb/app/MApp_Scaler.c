////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#define MAPP_SCALER_C

/******************************************************************************/
// [SC_PATCH_03]
// Date: 20090112
// Descriptions: fix right boundary green line problem due to CTI will refer to
// green points outside right boundary of capture range.
//
/******************************************************************************/
/*             Header Files                                                   */
/* ****************************************************************************/
#include <string.h>
#include "debug.h"
#include "datatype.h"
#include "Board.h"
#include "msAPI_Global.h"
#include "apiXC.h"
#include "drvXC_HDMI_if.h"
#include "apiXC_Sys.h"
#include "apiPNL.h"
#include "Panel.h"
#include "apiXC_Hdmi.h"
#include "apiXC_Adc.h"
#include "apiXC_ModeParse.h"
#include "apiXC_Cus.h"
#if ENABLE_MFC
#include "drvMFC.h"
#endif
#include "drvPWM.h"

#include "msAPI_Mode.h"
#include "drvGPIO.h"
#include "apiXC_Ace.h"
#include "apiXC_Auto.h"
#include "apiXC_PCMonitor.h"
#include "MApp_GlobalSettingSt.h"

#ifdef ATSC_SYSTEM
#include "MApp_DataBase_A.h"
#else
#include "MApp_DataBase.h"
#endif

#include "MApp_PCMode.h"
#include "MApp_GlobalVar.h"
#include "MApp_Scaler.h"
#include "MApp_XC_Sys.h"
#include "MApp_XC_PQ.h"
#include "MApp_MVDMode.h"
#include "MApp_SaveData.h"
#include "MApp_GlobalFunction.h"
#include "MApp_TopStateMachine.h"
#include "MApp_InputSource.h"
#include"MApp_ZUI_Main.h"
#include "mapp_videoplayer.h"

#include "msAPI_Video.h"
#include "msAPI_Timer.h"
#include "msAPI_VD.h"
#include "msAPI_Tuning.h"
#include "msAPI_MIU.h"

#include "apiXC_Dlc.h"

#include "drvCPU.h"
#include "drvPQ.h"
#include "drvGlobal.h"
#include "color_reg.h"
#include "sysinfo.h"
#include "apiGOP.h"

#include "ZUI_tables_h.inl"

#if MHEG5_ENABLE
#include "MApp_MHEG5_Main.h"
#endif

#if ENABLE_DMP
#include "mapp_mplayer.h"
#endif

#if (ENABLE_ATV_VCHIP)
#include "MApp_VChip.h"
#endif
#include "MApp_ZUI_ACTmenufunc.h"

/******************************************************************************/
/*                     Definition                                             */
/* ****************************************************************************/

#define NEWCROPMSG(x)   //x
#define MSG(x)          //x
#define MSG_MOVIE(x)            //x
#define MENU_3D_DBG(x)          x

#define VERIFY_SCALER_FPGA  0

#if ENABLE_ZOOM_AVOUT_NOTMUTE
extern BOOLEAN bIsAspectMute;
#endif
#if ENABLE_SZ_BLUESCREEN_FUNCTION
	extern BOOL ATV_SEARCH_STATE;
#endif

//******************************************************************************
//          Structures
//******************************************************************************

typedef struct
{
    U16 u16H_CapStart;          ///< Capture window H start
    U16 u16V_CapStart;          ///< Capture window V start

    U8 u8HCrop_Left;    // H Crop Left
    U8 u8HCrop_Right;    // H crop Right
    U8 u8VCrop_Up;      // V Crop Up
    U8 u8VCrop_Down;      // V Crop Down
} MS_VIDEO_Window_Info;

typedef enum
{
    E_YPbPr480i_60,         // 0
    E_YPbPr480p_60,        // 1
    E_YPbPr576i_50,         // 2
    E_YPbPr576p_50,        // 3
    E_YPbPr720p_60,        // 4
    E_YPbPr720p_50,        // 5
    E_YPbPr1080i_60,       // 6
    E_YPbPr1080i_50,       // 7
    E_YPbPr1080p_60,      // 8
    E_YPbPr1080p_50,      // 9
    E_YPbPr1080p_30,      // 10
    E_YPbPr1080p_24,      // 11
    E_YPbPr1470p_50,      // 12
    E_YPbPr1470p_60,      // 13
    E_YPbPr2205p_24,      // 14
    E_YPbPr1080p_25,      // 15
    E_YPbPr720p_25,       // 16
    E_YPbPr720p_30,       // 17
    #if (SUPPORT_EURO_HDTV)
     E_YPbPr1080i_25,      // 18
     #endif
    E_YPbPr_MAX,   // 19
}MAX_YPbPr_Resolution_Info;

typedef enum
{
    E_HDMI480i_60,         // 0
    E_HDMI480p_60,        // 1
    E_HDMI576i_50,         // 2
    E_HDMI576p_50,        // 3
    E_HDMI720p_60,        // 4
    E_HDMI720p_50,        // 5
    E_HDMI1080i_60,       // 6
    E_HDMI1080i_50,       // 7
    E_HDMI1080p_60,      // 8
    E_HDMI1080p_50,      // 9
    E_HDMI1080p_30,      // 10
    E_HDMI1080p_24,      // 11

    E_HDMI1440x480i_60,      // 12
    E_HDMI1440x480p_60,     // 13
    E_HDMI1440x576i_50,     // 14
    E_HDMI1440x576p_50,     // 15

    E_HDMI_MAX,           // 16

}MAX_HDMI_Resolution_Info;

typedef enum
{
    E_AR_DEFAULT = 0,  // 0
    E_AR_16x9,              // 1
    E_AR_4x3,                // 2
    E_AR_AUTO,             // 3
    E_AR_Panorama,     // 4
    E_AR_JustScan,       // 5
    E_AR_Zoom2,          // 6
    E_AR_Zoom1,          // 7

    E_AR_MAX,
}MAX_AspectRatio_Info;

//------------------------------------------------------------------------------
// ARC
//------------------------------------------------------------------------------
#define ARC_14X19_OVS_UP                62
#define ARC_14X19_OVS_DOWN              62

#define ARC_CINEMA_OVS_H                100
#define ARC_CINEMA_OVS_V                100

//------------------------------------------------------------------------------
// Over Scan
//------------------------------------------------------------------------------
#define OVERSCAN_DEFAULT_H              30 // 1.0%
#define OVERSCAN_DEFAULT_V              35 // 1.0%


//------------------------------------------------------------------------------
// VD Timing Window (Table)
//------------------------------------------------------------------------------

U8 SV_OffsetH[] =
{
    0x10,   //NTSC
   0x12,// 0x0E,   //PAL
    0x00,   //SECAM
    0x0D,   //NTSC-443/PAL-60
    0x12,   //PAL-M
    0x12    //PAL-NC
};

U8 SV_OffsetV[] =
{
    0x82,   //NTSC
    0x82,   //PAL
    0x0,    //SECAM
    0x82,   //NTSC-443/PAL-60
    0x83,   //PAL-M
    0x82    //PAL-NC
};


MS_VIDEO_Window_Info CVBS_WinInfo[][E_AR_MAX] =
{
    {  //NTSC, 0
        {MSVD_HSTART_NTSC, MSVD_VSTART_NTSC,   52, 52, 36, 36},  // Default
        {MSVD_HSTART_NTSC, MSVD_VSTART_NTSC,   52, 52, 36, 36},  // 16:9
        {MSVD_HSTART_NTSC, MSVD_VSTART_NTSC,   52, 52, 36, 36},  // 4:3
        {MSVD_HSTART_NTSC, MSVD_VSTART_NTSC,   52, 52, 36, 36},  // Auto
        {MSVD_HSTART_NTSC, MSVD_VSTART_NTSC,   52, 52, 36, 36},  // Panorama
        {MSVD_HSTART_NTSC, MSVD_VSTART_NTSC,   52, 52, 36, 36},  // Just Scan
        {MSVD_HSTART_NTSC, MSVD_VSTART_NTSC,   52, 52, 36, 36},  // Zoom2
        {MSVD_HSTART_NTSC, MSVD_VSTART_NTSC,   52, 52, 36, 36},  // Zoom1
    },
    {  //PAL, 1
        {MSVD_HSTART_PAL, MSVD_VSTART_PAL,   56, 56, 38, 38},  // Default
        {MSVD_HSTART_PAL, MSVD_VSTART_PAL,   56, 56, 38, 38},  // 16:9
        {MSVD_HSTART_PAL, MSVD_VSTART_PAL,   56, 56, 38, 38},  // 4:3
        {MSVD_HSTART_PAL, MSVD_VSTART_PAL,   56, 56, 38, 38},  // Auto
        {MSVD_HSTART_PAL, MSVD_VSTART_PAL,   56, 56, 38, 38},  // Panorama
        {MSVD_HSTART_PAL, MSVD_VSTART_PAL,   56, 56, 38, 38},  // Just Scan
        {MSVD_HSTART_PAL, MSVD_VSTART_PAL,   56, 56, 38, 38},  // Zoom2
        {MSVD_HSTART_PAL, MSVD_VSTART_PAL,   56, 56, 38, 38},  // Zoom1
    },
    {  //SECAM, 2
        {MSVD_HSTART_SECAM, MSVD_VSTART_SECAM,   56, 56, 36, 36},  // Default
        {MSVD_HSTART_SECAM, MSVD_VSTART_SECAM,   56, 56, 36, 36},  // 16:9
        {MSVD_HSTART_SECAM, MSVD_VSTART_SECAM,   56, 56, 36, 36},  // 4:3
        {MSVD_HSTART_SECAM, MSVD_VSTART_SECAM,   56, 56, 36, 36},  // Auto
        {MSVD_HSTART_SECAM, MSVD_VSTART_SECAM,   56, 56, 36, 36},  // Panorama
        {MSVD_HSTART_SECAM, MSVD_VSTART_SECAM,   56, 56, 36, 36},  // Just Scan
        {MSVD_HSTART_SECAM, MSVD_VSTART_SECAM,   56, 56, 36, 36},  // Zoom2
        {MSVD_HSTART_SECAM, MSVD_VSTART_SECAM,   56, 56, 36, 36},  // Zoom1
    },
    {  //NTSC-443/PAL-60, 3
        {MSVD_HSTART_NTSC_443, MSVD_VSTART_NTSC_443,   50, 50, 36, 36},  // Default
        {MSVD_HSTART_NTSC_443, MSVD_VSTART_NTSC_443,   50, 50, 36, 36},  // 16:9
        {MSVD_HSTART_NTSC_443, MSVD_VSTART_NTSC_443,   50, 50, 36, 36},  // 4:3
        {MSVD_HSTART_NTSC_443, MSVD_VSTART_NTSC_443,   50, 50, 36, 36},  // Auto
        {MSVD_HSTART_NTSC_443, MSVD_VSTART_NTSC_443,   50, 50, 36, 36},  // Panorama
        {MSVD_HSTART_NTSC_443, MSVD_VSTART_NTSC_443,   50, 50, 36, 36},  // Just Scan
        {MSVD_HSTART_NTSC_443, MSVD_VSTART_NTSC_443,   50, 50, 36, 36},  // Zoom2
        {MSVD_HSTART_NTSC_443, MSVD_VSTART_NTSC_443,   50, 50, 36, 36},  // Zoom1
    },
    {  //PAL-M, 4
        {MSVD_HSTART_PAL_M, MSVD_VSTART_PAL_M,   54, 54, 36, 36},  // Default
        {MSVD_HSTART_PAL_M, MSVD_VSTART_PAL_M,   54, 54, 36, 36},  // 16:9
        {MSVD_HSTART_PAL_M, MSVD_VSTART_PAL_M,   54, 54, 36, 36},  // 4:3
        {MSVD_HSTART_PAL_M, MSVD_VSTART_PAL_M,   54, 54, 36, 36},  // Auto
        {MSVD_HSTART_PAL_M, MSVD_VSTART_PAL_M,   54, 54, 36, 36},  // Panorama
        {MSVD_HSTART_PAL_M, MSVD_VSTART_PAL_M,   54, 54, 36, 36},  // Just Scan
        {MSVD_HSTART_PAL_M, MSVD_VSTART_PAL_M,   54, 54, 36, 36},  // Zoom2
        {MSVD_HSTART_PAL_M, MSVD_VSTART_PAL_M,   54, 54, 36, 36},  // Zoom1
    },
    {  //PAL-NC, 5
        {MSVD_HSTART_PAL_NC, MSVD_VSTART_PAL_NC,   58, 58, 36, 36},  // Default
        {MSVD_HSTART_PAL_NC, MSVD_VSTART_PAL_NC,   58, 58, 36, 36},  // 16:9
        {MSVD_HSTART_PAL_NC, MSVD_VSTART_PAL_NC,   58, 58, 36, 36},  // 4:3
        {MSVD_HSTART_PAL_NC, MSVD_VSTART_PAL_NC,   58, 58, 36, 36},  // Auto
        {MSVD_HSTART_PAL_NC, MSVD_VSTART_PAL_NC,   58, 58, 36, 36},  // Panorama
        {MSVD_HSTART_PAL_NC, MSVD_VSTART_PAL_NC,   58, 58, 36, 36},  // Just Scan
        {MSVD_HSTART_PAL_NC, MSVD_VSTART_PAL_NC,   58, 58, 36, 36},  // Zoom2
        {MSVD_HSTART_PAL_NC, MSVD_VSTART_PAL_NC,   58, 58, 36, 36},  // Zoom1
    },
};

//  720x 480
#define MSVD_YPbPr_HSTART_480i60  0x74
#define MSVD_YPbPr_VSTART_480i60  0x1c
#define MSVD_YPbPr_HSTART_480p60  0x74
#define MSVD_YPbPr_VSTART_480p60  0x1C
//  720x 576
#define MSVD_YPbPr_HSTART_576i50  0x8A
#define MSVD_YPbPr_VSTART_576i50  0x20
#define MSVD_YPbPr_HSTART_576p50  0x89
#define MSVD_YPbPr_VSTART_576p50  0x25
// 1280x 720
#define MSVD_YPbPr_HSTART_720p60  0x101//0xff//0xf2 // 0x102
#define MSVD_YPbPr_VSTART_720p60  0x10 //0x13//0x18 // 0x22
#define MSVD_YPbPr_HSTART_720p50  0x113//0xFC//0xf4
#define MSVD_YPbPr_VSTART_720p50  0x10//0x1C
#define MSVD_YPbPr_HSTART_720p25  0xC1//0xf4
#define MSVD_YPbPr_VSTART_720p25  0x05//0x1C
#define MSVD_YPbPr_HSTART_720p30  0xC2//0xf2 // 0x102
#define MSVD_YPbPr_VSTART_720p30  0x05//0x18 // 0x22
// 1920x1080, interlace
#define MSVD_YPbPr_HSTART_1080i60  0xbd
#define MSVD_YPbPr_VSTART_1080i60  0x17
#define MSVD_YPbPr_HSTART_1080i50  0xbd//0x9C
#define MSVD_YPbPr_VSTART_1080i50  0x17//0x2C
#if (SUPPORT_EURO_HDTV)
#define MSVD_YPbPr_HSTART_108oi25  0x138//0x9C
#define MSVD_YPbPr_VSTART_108oi25  0x9b//0x2C
#endif
// 1920x1080, progressive
#define MSVD_YPbPr_HSTART_1080p60  0xBE
#define MSVD_YPbPr_VSTART_1080p60  0x20
#define MSVD_YPbPr_HSTART_1080p50  0xBC
#define MSVD_YPbPr_VSTART_1080p50  0x20
#define MSVD_YPbPr_HSTART_1080p30  0xBC
#define MSVD_YPbPr_VSTART_1080p30  0x20
#define MSVD_YPbPr_HSTART_1080p24  0xBA
#define MSVD_YPbPr_VSTART_1080p24  0x21
#define MSVD_YPbPr_HSTART_1080p25  0xBB
#define MSVD_YPbPr_VSTART_1080p25 0x21

//1280X1470 50hz, progressive
#define MSVD_YPbPr_HSTART_1470p50  0xFF
#define MSVD_YPbPr_VSTART_1470p50  0x2D

//1280X1470 60hz, progressive
#define MSVD_YPbPr_HSTART_1470p60  0xFF
#define MSVD_YPbPr_VSTART_1470p60  0x2D

//1920X2205 24p, progressive
#define MSVD_YPbPr_HSTART_2205p24  0xFF
#define MSVD_YPbPr_VSTART_2205p24  0x2D


MS_VIDEO_Window_Info YPbPr_WinInfo[E_YPbPr_MAX][E_AR_MAX] =
{
    {  //480i_60, 0
        {MSVD_YPbPr_HSTART_480i60, MSVD_YPbPr_VSTART_480i60, 50, 50, 20, 20},  // Default
        {MSVD_YPbPr_HSTART_480i60, MSVD_YPbPr_VSTART_480i60, 50, 50, 20, 20},  // 16:9
        {MSVD_YPbPr_HSTART_480i60, MSVD_YPbPr_VSTART_480i60, 50, 50, 20, 20},  // 4:3
        {MSVD_YPbPr_HSTART_480i60, MSVD_YPbPr_VSTART_480i60, 50, 50, 20, 20},  // Auto
        {MSVD_YPbPr_HSTART_480i60, MSVD_YPbPr_VSTART_480i60, 50, 50, 20, 20},  // Panorama
        {MSVD_YPbPr_HSTART_480i60, MSVD_YPbPr_VSTART_480i60, 50, 50, 20, 20},  // Just Scan
        {MSVD_YPbPr_HSTART_480i60, MSVD_YPbPr_VSTART_480i60, 50, 50, 20, 20},  // Zoom2
        {MSVD_YPbPr_HSTART_480i60, MSVD_YPbPr_VSTART_480i60, 50, 50, 20, 20},  // Zoom1
    },
    {  //480p_60, 1
        {MSVD_YPbPr_HSTART_480p60, MSVD_YPbPr_VSTART_480p60, 50, 50, 20, 20},  // Default
        {MSVD_YPbPr_HSTART_480p60, MSVD_YPbPr_VSTART_480p60, 50, 50, 20, 20},  // 16:9
        {MSVD_YPbPr_HSTART_480p60, MSVD_YPbPr_VSTART_480p60, 50, 50, 20, 20},  // 4:3
        {MSVD_YPbPr_HSTART_480p60, MSVD_YPbPr_VSTART_480p60, 50, 50, 20, 20},  // Auto
        {MSVD_YPbPr_HSTART_480p60, MSVD_YPbPr_VSTART_480p60, 50, 50, 20, 20},  // Panorama
        {MSVD_YPbPr_HSTART_480p60, MSVD_YPbPr_VSTART_480p60, 50, 50, 20, 20},  // Just Scan
        {MSVD_YPbPr_HSTART_480p60, MSVD_YPbPr_VSTART_480p60, 50, 50, 20, 20},  // Zoom2
        {MSVD_YPbPr_HSTART_480p60, MSVD_YPbPr_VSTART_480p60, 50, 50, 20, 20},  // Zoom1
    },
    {  //576i_50, 2
        {MSVD_YPbPr_HSTART_576i50, MSVD_YPbPr_VSTART_576i50, 56, 56, 30, 30},  // Default
        {MSVD_YPbPr_HSTART_576i50, MSVD_YPbPr_VSTART_576i50, 56, 56, 30, 30},  // 16:9
        {MSVD_YPbPr_HSTART_576i50, MSVD_YPbPr_VSTART_576i50, 56, 56, 30, 30},  // 4:3
        {MSVD_YPbPr_HSTART_576i50, MSVD_YPbPr_VSTART_576i50, 56, 56, 30, 30},  // Auto
        {MSVD_YPbPr_HSTART_576i50, MSVD_YPbPr_VSTART_576i50, 56, 56, 30, 30},  // Panorama
        {MSVD_YPbPr_HSTART_576i50, MSVD_YPbPr_VSTART_576i50, 56, 56, 30, 30},  // Just Scan
        {MSVD_YPbPr_HSTART_576i50, MSVD_YPbPr_VSTART_576i50, 56, 56, 30, 30},  // Zoom2
        {MSVD_YPbPr_HSTART_576i50, MSVD_YPbPr_VSTART_576i50, 56, 56, 30, 30},  // Zoom1
    },
    {  //576p_50, 3
        {MSVD_YPbPr_HSTART_576p50, MSVD_YPbPr_VSTART_576p50, 48, 48, 30, 30},  // Default
        {MSVD_YPbPr_HSTART_576p50, MSVD_YPbPr_VSTART_576p50, 48, 48, 30, 30},  // 16:9
        {MSVD_YPbPr_HSTART_576p50, MSVD_YPbPr_VSTART_576p50, 48, 48, 30, 30},  // 4:3
        {MSVD_YPbPr_HSTART_576p50, MSVD_YPbPr_VSTART_576p50, 48, 48, 30, 30},  // Auto
        {MSVD_YPbPr_HSTART_576p50, MSVD_YPbPr_VSTART_576p50, 48, 48, 30, 30},  // Panorama
        {MSVD_YPbPr_HSTART_576p50, MSVD_YPbPr_VSTART_576p50, 48, 48, 30, 30},  // Just Scan
        {MSVD_YPbPr_HSTART_576p50, MSVD_YPbPr_VSTART_576p50, 48, 48, 30, 30},  // Zoom2
        {MSVD_YPbPr_HSTART_576p50, MSVD_YPbPr_VSTART_576p50, 48, 48, 30, 30},  // Zoom1
    },
    {  //720p_60, 4
        {MSVD_YPbPr_HSTART_720p60, MSVD_YPbPr_VSTART_720p60, 21, 21, 25, 25},  // Default
        {MSVD_YPbPr_HSTART_720p60, MSVD_YPbPr_VSTART_720p60, 21, 21, 25, 25},  // 16:9
        {MSVD_YPbPr_HSTART_720p60, MSVD_YPbPr_VSTART_720p60, 21, 21, 25, 25},  // 4:3
        {MSVD_YPbPr_HSTART_720p60, MSVD_YPbPr_VSTART_720p60, 21, 21, 25, 25},  // Auto
        {MSVD_YPbPr_HSTART_720p60, MSVD_YPbPr_VSTART_720p60, 21, 21, 25, 25},  // Panorama
        {MSVD_YPbPr_HSTART_720p60, MSVD_YPbPr_VSTART_720p60, 21, 21, 25, 25},  // Just Scan
        {MSVD_YPbPr_HSTART_720p60, MSVD_YPbPr_VSTART_720p60, 21, 21, 25, 25},  // Zoom2
        {MSVD_YPbPr_HSTART_720p60, MSVD_YPbPr_VSTART_720p60, 21, 21, 25, 25},  // Zoom1
    },
    {  //720p_50, 5
        {MSVD_YPbPr_HSTART_720p50, MSVD_YPbPr_VSTART_720p50, 21, 21, 25, 25},  // Default
        {MSVD_YPbPr_HSTART_720p50, MSVD_YPbPr_VSTART_720p50, 21, 21, 25, 25},  // 16:9
        {MSVD_YPbPr_HSTART_720p50, MSVD_YPbPr_VSTART_720p50, 21, 21, 25, 25},  // 4:3
        {MSVD_YPbPr_HSTART_720p50, MSVD_YPbPr_VSTART_720p50, 21, 21, 25, 25},  // Auto
        {MSVD_YPbPr_HSTART_720p50, MSVD_YPbPr_VSTART_720p50, 21, 21, 25, 25},  // Panorama
        {MSVD_YPbPr_HSTART_720p50, MSVD_YPbPr_VSTART_720p50, 21, 21, 25, 25},  // Just Scan
        {MSVD_YPbPr_HSTART_720p50, MSVD_YPbPr_VSTART_720p50, 21, 21, 25, 25},  // Zoom2
        {MSVD_YPbPr_HSTART_720p50, MSVD_YPbPr_VSTART_720p50, 21, 21, 25, 25},  // Zoom1
    },
    {  //1080i_60, 6
        {MSVD_YPbPr_HSTART_1080i60, MSVD_YPbPr_VSTART_1080i60, 17, 17, 23, 23},  // Default
        {MSVD_YPbPr_HSTART_1080i60, MSVD_YPbPr_VSTART_1080i60, 17, 17, 23, 23},  // 16:9
        {MSVD_YPbPr_HSTART_1080i60, MSVD_YPbPr_VSTART_1080i60, 17, 17, 23, 23},  // 4:3
        {MSVD_YPbPr_HSTART_1080i60, MSVD_YPbPr_VSTART_1080i60, 17, 17, 23, 23},  // Auto
        {MSVD_YPbPr_HSTART_1080i60, MSVD_YPbPr_VSTART_1080i60, 17, 17, 23, 23},  // Panorama
        {MSVD_YPbPr_HSTART_1080i60, MSVD_YPbPr_VSTART_1080i60, 0, 0, 0, 0},  // Just Scan
        {MSVD_YPbPr_HSTART_1080i60, MSVD_YPbPr_VSTART_1080i60, 30, 30, 23, 23},  // Zoom2
        {MSVD_YPbPr_HSTART_1080i60, MSVD_YPbPr_VSTART_1080i60, 30, 30, 23, 23},  // Zoom1
    },
    {  //1080i_50, 7
        {MSVD_YPbPr_HSTART_1080i50, MSVD_YPbPr_VSTART_1080i50, 17, 17, 23, 23},  // Default
        {MSVD_YPbPr_HSTART_1080i50, MSVD_YPbPr_VSTART_1080i50, 17, 17, 23, 23},  // 16:9
        {MSVD_YPbPr_HSTART_1080i50, MSVD_YPbPr_VSTART_1080i50, 17, 17, 23, 23},  // 4:3
        {MSVD_YPbPr_HSTART_1080i50, MSVD_YPbPr_VSTART_1080i50, 17, 17, 23, 23},  // Auto
        {MSVD_YPbPr_HSTART_1080i50, MSVD_YPbPr_VSTART_1080i50, 17, 17, 23, 23},  // Panorama
        {MSVD_YPbPr_HSTART_1080i50, MSVD_YPbPr_VSTART_1080i50, 0, 0, 0, 0},  // Just Scan
        {MSVD_YPbPr_HSTART_1080i50, MSVD_YPbPr_VSTART_1080i50, 30, 30, 30, 30},  // Zoom2
        {MSVD_YPbPr_HSTART_1080i50, MSVD_YPbPr_VSTART_1080i50, 30, 30, 30, 30},  // Zoom1
    },
    {  //1080p_60, 8
        {MSVD_YPbPr_HSTART_1080p60, MSVD_YPbPr_VSTART_1080p60, 10, 10, 10, 10},  // Default
        {MSVD_YPbPr_HSTART_1080p60, MSVD_YPbPr_VSTART_1080p60, 10, 10, 10, 10},  // 16:9
        {MSVD_YPbPr_HSTART_1080p60, MSVD_YPbPr_VSTART_1080p60, 10, 10, 10, 10},  // 4:3
        {MSVD_YPbPr_HSTART_1080p60, MSVD_YPbPr_VSTART_1080p60, 10, 10, 10, 10},  // Auto
        {MSVD_YPbPr_HSTART_1080p60, MSVD_YPbPr_VSTART_1080p60, 10, 10, 10, 10},  // Panorama
        {MSVD_YPbPr_HSTART_1080p60, MSVD_YPbPr_VSTART_1080p60, 0, 0, 0, 0},  // Just Scan
        {MSVD_YPbPr_HSTART_1080p60, MSVD_YPbPr_VSTART_1080p60, 10, 10, 10, 10},  // Zoom2
        {MSVD_YPbPr_HSTART_1080p60, MSVD_YPbPr_VSTART_1080p60, 10, 10, 10, 10},  // Zoom1
    },
    {  //1080p_50, 9
        {MSVD_YPbPr_HSTART_1080p50, MSVD_YPbPr_VSTART_1080p50, 10, 10, 10, 10},  // Default
        {MSVD_YPbPr_HSTART_1080p50, MSVD_YPbPr_VSTART_1080p50, 10, 10, 10, 10},  // 16:9
        {MSVD_YPbPr_HSTART_1080p50, MSVD_YPbPr_VSTART_1080p50, 10, 10, 10, 10},  // 4:3
        {MSVD_YPbPr_HSTART_1080p50, MSVD_YPbPr_VSTART_1080p50, 10, 10,10,10},  // Auto
        {MSVD_YPbPr_HSTART_1080p50, MSVD_YPbPr_VSTART_1080p50, 10, 10, 10, 10},  // Panorama
        {MSVD_YPbPr_HSTART_1080p50, MSVD_YPbPr_VSTART_1080p50, 0, 0, 0, 0},  // Just Scan
        {MSVD_YPbPr_HSTART_1080p50, MSVD_YPbPr_VSTART_1080p50, 10, 10, 10, 10},  // Zoom2
        {MSVD_YPbPr_HSTART_1080p50, MSVD_YPbPr_VSTART_1080p50, 10, 10, 10, 10},  // Zoom1
    },
    {  //1080p_30, 10
        {MSVD_YPbPr_HSTART_1080p30, MSVD_YPbPr_VSTART_1080p30, 17, 17, 23, 23},  // Default
        {MSVD_YPbPr_HSTART_1080p30, MSVD_YPbPr_VSTART_1080p30, 17, 17, 23, 23},  // 16:9
        {MSVD_YPbPr_HSTART_1080p30, MSVD_YPbPr_VSTART_1080p30, 17, 17, 23, 23},  // 4:3
        {MSVD_YPbPr_HSTART_1080p30, MSVD_YPbPr_VSTART_1080p30, 17, 17, 23, 23},  // Auto
        {MSVD_YPbPr_HSTART_1080p30, MSVD_YPbPr_VSTART_1080p30, 17, 17, 23, 23},  // Panorama
        {MSVD_YPbPr_HSTART_1080p30, MSVD_YPbPr_VSTART_1080p30, 0, 0, 0, 0},  // Just Scan
        {MSVD_YPbPr_HSTART_1080p30, MSVD_YPbPr_VSTART_1080p30, 17, 17, 23, 23},  // Zoom2
        {MSVD_YPbPr_HSTART_1080p30, MSVD_YPbPr_VSTART_1080p30, 17, 17, 23, 23},  // Zoom1
    },
    {  //1080p_24, 11
        {MSVD_YPbPr_HSTART_1080p24, MSVD_YPbPr_VSTART_1080p24, 17, 17, 23, 23},  // Default
        {MSVD_YPbPr_HSTART_1080p24, MSVD_YPbPr_VSTART_1080p24, 17, 17, 23, 23},  // 16:9
        {MSVD_YPbPr_HSTART_1080p24, MSVD_YPbPr_VSTART_1080p24, 17, 17, 23, 23},  // 4:3
        {MSVD_YPbPr_HSTART_1080p24, MSVD_YPbPr_VSTART_1080p24, 17, 17, 23, 23},  // Auto
        {MSVD_YPbPr_HSTART_1080p24, MSVD_YPbPr_VSTART_1080p24, 17, 17, 23, 23},  // Panorama
        {MSVD_YPbPr_HSTART_1080p24, MSVD_YPbPr_VSTART_1080p24, 0, 0, 0, 0},  // Just Scan
        {MSVD_YPbPr_HSTART_1080p24, MSVD_YPbPr_VSTART_1080p24, 17, 17, 23, 23},  // Zoom2
        {MSVD_YPbPr_HSTART_1080p24, MSVD_YPbPr_VSTART_1080p24, 17, 17, 23, 23},  // Zoom1
    },
    {  //1470p_50, 12
        {MSVD_YPbPr_HSTART_1470p50, MSVD_YPbPr_VSTART_1470p50, 17, 17, 23, 23},  // Default
        {MSVD_YPbPr_HSTART_1470p50, MSVD_YPbPr_VSTART_1470p50, 17, 17, 23, 23},  // 16:9
        {MSVD_YPbPr_HSTART_1470p50, MSVD_YPbPr_VSTART_1470p50, 17, 17, 23, 23},  // 4:3
        {MSVD_YPbPr_HSTART_1470p50, MSVD_YPbPr_VSTART_1470p50, 17, 17, 23, 23},  // Auto
        {MSVD_YPbPr_HSTART_1470p50, MSVD_YPbPr_VSTART_1470p50, 17, 17, 23, 23},  // Panorama
        {MSVD_YPbPr_HSTART_1470p50, MSVD_YPbPr_VSTART_1470p50, 17, 17, 23, 23},  // Just Scan
        {MSVD_YPbPr_HSTART_1470p50, MSVD_YPbPr_VSTART_1470p50, 17, 17, 23, 23},  // Zoom2
        {MSVD_YPbPr_HSTART_1470p50, MSVD_YPbPr_VSTART_1470p50, 17, 17, 23, 23},  // Zoom1
    },
    {  //1470p_60, 13
        {MSVD_YPbPr_HSTART_1470p60, MSVD_YPbPr_VSTART_1470p60, 17, 17, 23, 23},  // Default
        {MSVD_YPbPr_HSTART_1470p60, MSVD_YPbPr_VSTART_1470p60, 17, 17, 23, 23},  // 16:9
        {MSVD_YPbPr_HSTART_1470p60, MSVD_YPbPr_VSTART_1470p60, 17, 17, 23, 23},  // 4:3
        {MSVD_YPbPr_HSTART_1470p60, MSVD_YPbPr_VSTART_1470p60, 17, 17, 23, 23},  // Auto
        {MSVD_YPbPr_HSTART_1470p60, MSVD_YPbPr_VSTART_1470p60, 17, 17, 23, 23},  // Panorama
        {MSVD_YPbPr_HSTART_1470p60, MSVD_YPbPr_VSTART_1470p60, 17, 17, 23, 23},  // Just Scan
        {MSVD_YPbPr_HSTART_1470p60, MSVD_YPbPr_VSTART_1470p60, 17, 17, 23, 23},  // Zoom2
        {MSVD_YPbPr_HSTART_1470p60, MSVD_YPbPr_VSTART_1470p60, 17, 17, 23, 23},  // Zoom1
    },
    {  //2205p_24, 14
        {MSVD_YPbPr_HSTART_2205p24, MSVD_YPbPr_VSTART_2205p24, 17, 17, 23, 23},  // Default
        {MSVD_YPbPr_HSTART_2205p24, MSVD_YPbPr_VSTART_2205p24, 17, 17, 23, 23},  // 16:9
        {MSVD_YPbPr_HSTART_2205p24, MSVD_YPbPr_VSTART_2205p24, 17, 17, 23, 23},  // 4:3
        {MSVD_YPbPr_HSTART_2205p24, MSVD_YPbPr_VSTART_2205p24, 17, 17, 23, 23},  // Auto
        {MSVD_YPbPr_HSTART_2205p24, MSVD_YPbPr_VSTART_2205p24, 17, 17, 23, 23},  // Panorama
        {MSVD_YPbPr_HSTART_2205p24, MSVD_YPbPr_VSTART_2205p24, 17, 17, 23, 23},  // Just Scan
        {MSVD_YPbPr_HSTART_2205p24, MSVD_YPbPr_VSTART_2205p24, 17, 17, 23, 23},  // Zoom2
        {MSVD_YPbPr_HSTART_2205p24, MSVD_YPbPr_VSTART_2205p24, 17, 17, 23, 23},  // Zoom1
    },
    {  //1080p_25, 15
        {MSVD_YPbPr_HSTART_1080p25, MSVD_YPbPr_VSTART_1080p25, 17, 17, 23, 23},  // Default
        {MSVD_YPbPr_HSTART_1080p25, MSVD_YPbPr_VSTART_1080p25, 17, 17, 23, 23},  // 16:9
        {MSVD_YPbPr_HSTART_1080p25, MSVD_YPbPr_VSTART_1080p25, 17, 17, 23, 23},  // 4:3
        {MSVD_YPbPr_HSTART_1080p25, MSVD_YPbPr_VSTART_1080p25, 17, 17, 23, 23},  // Auto
        {MSVD_YPbPr_HSTART_1080p25, MSVD_YPbPr_VSTART_1080p25, 17, 17, 23, 23},  // Panorama
        {MSVD_YPbPr_HSTART_1080p25, MSVD_YPbPr_VSTART_1080p25, 0, 0, 0, 0},  // Just Scan
        {MSVD_YPbPr_HSTART_1080p25, MSVD_YPbPr_VSTART_1080p25, 17, 17, 23, 23},  // Zoom2
        {MSVD_YPbPr_HSTART_1080p25, MSVD_YPbPr_VSTART_1080p25, 17, 17, 23, 23},  // Zoom1
    },
    {  //720p_25, 16
        {MSVD_YPbPr_HSTART_720p25, MSVD_YPbPr_VSTART_720p25, 21, 21, 25, 25},  // Default
        {MSVD_YPbPr_HSTART_720p25, MSVD_YPbPr_VSTART_720p25, 21, 21, 25, 25},  // 16:9
        {MSVD_YPbPr_HSTART_720p25, MSVD_YPbPr_VSTART_720p25, 21, 21, 25, 25},  // 4:3
        {MSVD_YPbPr_HSTART_720p25, MSVD_YPbPr_VSTART_720p25, 21, 21, 25, 25},  // Auto
        {MSVD_YPbPr_HSTART_720p25, MSVD_YPbPr_VSTART_720p25, 21, 21, 25, 25},  // Panorama
        {MSVD_YPbPr_HSTART_720p25, MSVD_YPbPr_VSTART_720p25, 21, 21, 25, 25},  // Just Scan
        {MSVD_YPbPr_HSTART_720p25, MSVD_YPbPr_VSTART_720p25, 21, 21, 25, 25},  // Zoom2
        {MSVD_YPbPr_HSTART_720p25, MSVD_YPbPr_VSTART_720p25, 21, 21, 25, 25},  // Zoom1
    },
    {  //720p_30, 17
        {MSVD_YPbPr_HSTART_720p30, MSVD_YPbPr_VSTART_720p30, 21, 21, 25, 25},  // Default
        {MSVD_YPbPr_HSTART_720p30, MSVD_YPbPr_VSTART_720p30, 21, 21, 25, 25},  // 16:9
        {MSVD_YPbPr_HSTART_720p30, MSVD_YPbPr_VSTART_720p30, 21, 21, 25, 25},  // 4:3
        {MSVD_YPbPr_HSTART_720p30, MSVD_YPbPr_VSTART_720p30, 21, 21, 25, 25},  // Auto
        {MSVD_YPbPr_HSTART_720p30, MSVD_YPbPr_VSTART_720p30, 21, 21, 25, 25},  // Panorama
        {MSVD_YPbPr_HSTART_720p30, MSVD_YPbPr_VSTART_720p30, 21, 21, 25, 25},  // Just Scan
        {MSVD_YPbPr_HSTART_720p30, MSVD_YPbPr_VSTART_720p30, 21, 21, 25, 25},  // Zoom2
        {MSVD_YPbPr_HSTART_720p30, MSVD_YPbPr_VSTART_720p30, 21, 21, 25, 25},  // Zoom1
    },
    #if (SUPPORT_EURO_HDTV)
    {  //1080i_25, 18
        {MSVD_YPbPr_HSTART_108oi25, MSVD_YPbPr_VSTART_108oi25, 17, 17, 23, 23},  // Default
        {MSVD_YPbPr_HSTART_108oi25, MSVD_YPbPr_VSTART_108oi25, 17, 17, 23, 23},  // 16:9
        {MSVD_YPbPr_HSTART_108oi25, MSVD_YPbPr_VSTART_108oi25, 17, 17, 23, 23},  // 4:3
        {MSVD_YPbPr_HSTART_108oi25, MSVD_YPbPr_VSTART_108oi25, 17, 17, 23, 23},  // Auto
        {MSVD_YPbPr_HSTART_108oi25, MSVD_YPbPr_VSTART_108oi25, 17, 17, 23, 23},  // Panorama
        {MSVD_YPbPr_HSTART_108oi25, MSVD_YPbPr_VSTART_108oi25, 0, 0, 0, 0},  // Just Scan
        {MSVD_YPbPr_HSTART_108oi25, MSVD_YPbPr_VSTART_108oi25, 17, 17, 23, 23},  // Zoom2
        {MSVD_YPbPr_HSTART_108oi25, MSVD_YPbPr_VSTART_108oi25, 17, 17, 23, 23},  // Zoom1
    },
    #endif
};

//  720x 480
#define MSVD_HDMI_HSTART_480i60  0x51//0x8A
#define MSVD_HDMI_VSTART_480i60  0x25
#define MSVD_HDMI_HSTART_480p60  0x51//0x88
#define MSVD_HDMI_VSTART_480p60  0x25
//  720x 576
#define MSVD_HDMI_HSTART_576i50  0x4D//0x86
#define MSVD_HDMI_VSTART_576i50  0x22
#define MSVD_HDMI_HSTART_576p50  0x56//0x8F
#define MSVD_HDMI_VSTART_576p50  0x2C
// 1280x 720
#define MSVD_HDMI_HSTART_720p60  0x13B//0x174
#define MSVD_HDMI_VSTART_720p60  0x1A
#define MSVD_HDMI_HSTART_720p50  0x289//0x2C2
#define MSVD_HDMI_VSTART_720p50  0x1C
// 1920x1080, interlace
#define MSVD_HDMI_HSTART_1080i60  0xE3//0x11C
#define MSVD_HDMI_VSTART_1080i60  0x24
#define MSVD_HDMI_HSTART_1080i50  0x29F//0x2D8
#define MSVD_HDMI_VSTART_1080i50  0x24
// 1920x1080, progressive
#define MSVD_HDMI_HSTART_1080p60  0xDE//0x117
#define MSVD_HDMI_VSTART_1080p60  0x20
#define MSVD_HDMI_HSTART_1080p50  0x296//0x2CF
#define MSVD_HDMI_VSTART_1080p50  0x25
#define MSVD_HDMI_HSTART_1080p30  0x83//0xBC
#define MSVD_HDMI_VSTART_1080p30  0x20
#define MSVD_HDMI_HSTART_1080p24  0x83//0xBC
#define MSVD_HDMI_VSTART_1080p24  0x21
// 1440x480
#define MSVD_HDMI_HSTART_1440x480i60  0xD9//0x112
#define MSVD_HDMI_VSTART_1440x480i60  0x28
#define MSVD_HDMI_HSTART_1440x480p60  0xD9//0x112
#define MSVD_HDMI_VSTART_1440x480p60  0x28
// 1440x576
#define MSVD_HDMI_HSTART_1440x576i50  0xE7//0x120
#define MSVD_HDMI_VSTART_1440x576i50  0x32
#define MSVD_HDMI_HSTART_1440x576p50  0xE7//0x120
#define MSVD_HDMI_VSTART_1440x576p50  0x32

MS_VIDEO_Window_Info HDMI_WinInfo[E_HDMI_MAX][E_AR_MAX] =
{
    {  //480i_60, 0
        {MSVD_HDMI_HSTART_480i60, MSVD_HDMI_VSTART_480i60, 46, 46, 40, 40},  // Default
        {MSVD_HDMI_HSTART_480i60, MSVD_HDMI_VSTART_480i60, 46, 46, 40, 40},  // 16:9
        {MSVD_HDMI_HSTART_480i60, MSVD_HDMI_VSTART_480i60, 46, 46, 40, 40},  // 4:3
        {MSVD_HDMI_HSTART_480i60, MSVD_HDMI_VSTART_480i60, 46, 46, 40, 40},  // Auto
        {MSVD_HDMI_HSTART_480i60, MSVD_HDMI_VSTART_480i60, 46, 46, 40, 40},  // Panorama
        {MSVD_HDMI_HSTART_480i60, MSVD_HDMI_VSTART_480i60, 46, 46, 40, 40},  // Just Scan
        {MSVD_HDMI_HSTART_480i60, MSVD_HDMI_VSTART_480i60, 46, 46, 40, 40},  // Zoom2
        {MSVD_HDMI_HSTART_480i60, MSVD_HDMI_VSTART_480i60, 46, 46, 40, 40},  // Zoom1
    },
    {  //480p_60, 1
        {MSVD_HDMI_HSTART_480p60, MSVD_HDMI_VSTART_480p60, 46, 46, 40, 40},  // Default
        {MSVD_HDMI_HSTART_480p60, MSVD_HDMI_VSTART_480p60, 46, 46, 40, 40},  // 16:9
        {MSVD_HDMI_HSTART_480p60, MSVD_HDMI_VSTART_480p60, 46, 46, 40, 40},  // 4:3
        {MSVD_HDMI_HSTART_480p60, MSVD_HDMI_VSTART_480p60, 46, 46, 40, 40},  // Auto
        {MSVD_HDMI_HSTART_480p60, MSVD_HDMI_VSTART_480p60, 46, 46, 40, 40},  // Panorama
        {MSVD_HDMI_HSTART_480p60, MSVD_HDMI_VSTART_480p60, 46, 46, 40, 40},  // Just Scan
        {MSVD_HDMI_HSTART_480p60, MSVD_HDMI_VSTART_480p60, 46, 46, 40, 40},  // Zoom2
        {MSVD_HDMI_HSTART_480p60, MSVD_HDMI_VSTART_480p60, 46, 46, 40, 40},  // Zoom1
    },
    {  //576i_50, 2
        {MSVD_HDMI_HSTART_576i50, MSVD_HDMI_VSTART_576i50, 46, 46, 40, 40},  // Default
        {MSVD_HDMI_HSTART_576i50, MSVD_HDMI_VSTART_576i50, 46, 46, 40, 40},  // 16:9
        {MSVD_HDMI_HSTART_576i50, MSVD_HDMI_VSTART_576i50, 46, 46, 40, 40},  // 4:3
        {MSVD_HDMI_HSTART_576i50, MSVD_HDMI_VSTART_576i50, 46, 46, 40, 40},  // Auto
        {MSVD_HDMI_HSTART_576i50, MSVD_HDMI_VSTART_576i50, 46, 46, 40, 40},  // Panorama
        {MSVD_HDMI_HSTART_576i50, MSVD_HDMI_VSTART_576i50, 46, 46, 40, 40},  // Just Scan
        {MSVD_HDMI_HSTART_576i50, MSVD_HDMI_VSTART_576i50, 46, 46, 40, 40},  // Zoom2
        {MSVD_HDMI_HSTART_576i50, MSVD_HDMI_VSTART_576i50, 46, 46, 40, 40},  // Zoom1
    },
    {  //576p_50, 3
        {MSVD_HDMI_HSTART_576p50, MSVD_HDMI_VSTART_576p50, 50, 50, 20, 20},  // Default
        {MSVD_HDMI_HSTART_576p50, MSVD_HDMI_VSTART_576p50, 50, 50, 20, 20},  // 16:9
        {MSVD_HDMI_HSTART_576p50, MSVD_HDMI_VSTART_576p50, 50, 50, 20, 20},  // 4:3
        {MSVD_HDMI_HSTART_576p50, MSVD_HDMI_VSTART_576p50, 50, 20, 20, 20},  // Auto
        {MSVD_HDMI_HSTART_576p50, MSVD_HDMI_VSTART_576p50, 50, 50, 20, 20},  // Panorama
        {MSVD_HDMI_HSTART_576p50, MSVD_HDMI_VSTART_576p50, 50, 50, 20, 20},  // Just Scan
        {MSVD_HDMI_HSTART_576p50, MSVD_HDMI_VSTART_576p50, 50, 50, 20, 20},  // Zoom2
        {MSVD_HDMI_HSTART_576p50, MSVD_HDMI_VSTART_576p50, 50, 50, 20, 20},  // Zoom1
    },
    {  //720p_60, 4
        {MSVD_HDMI_HSTART_720p60, MSVD_HDMI_VSTART_720p60, 17, 17, 25, 25},  // Default
        {MSVD_HDMI_HSTART_720p60, MSVD_HDMI_VSTART_720p60, 17, 17, 25, 25},  // 16:9
        {MSVD_HDMI_HSTART_720p60, MSVD_HDMI_VSTART_720p60, 17, 17, 25, 25},  // 4:3
        {MSVD_HDMI_HSTART_720p60, MSVD_HDMI_VSTART_720p60, 17, 17, 25, 25},  // Auto
        {MSVD_HDMI_HSTART_720p60, MSVD_HDMI_VSTART_720p60, 17, 17, 25, 25},  // Panorama
        {MSVD_HDMI_HSTART_720p60, MSVD_HDMI_VSTART_720p60, 0, 0, 0, 0},  // Just Scan
        {MSVD_HDMI_HSTART_720p60, MSVD_HDMI_VSTART_720p60, 17, 17, 25, 25},  // Zoom2
        {MSVD_HDMI_HSTART_720p60, MSVD_HDMI_VSTART_720p60, 17, 17, 25, 25},  // Zoom1
    },
    {  //720p_50, 5
        {MSVD_HDMI_HSTART_720p50, MSVD_HDMI_VSTART_720p50, 17, 17, 25, 25},  // Default
        {MSVD_HDMI_HSTART_720p50, MSVD_HDMI_VSTART_720p50, 17, 17, 25, 25},  // 16:9
        {MSVD_HDMI_HSTART_720p50, MSVD_HDMI_VSTART_720p50, 17, 17, 25, 25},  // 4:3
        {MSVD_HDMI_HSTART_720p50, MSVD_HDMI_VSTART_720p50, 17, 17, 25, 25},  // Auto
        {MSVD_HDMI_HSTART_720p50, MSVD_HDMI_VSTART_720p50, 17, 17, 25, 25},  // Panorama
        {MSVD_HDMI_HSTART_720p50, MSVD_HDMI_VSTART_720p50, 0, 0, 0, 0},  // Just Scan
        {MSVD_HDMI_HSTART_720p50, MSVD_HDMI_VSTART_720p50, 17, 17, 25, 25},  // Zoom2
        {MSVD_HDMI_HSTART_720p50, MSVD_HDMI_VSTART_720p50, 17, 17, 25, 25},  // Zoom1
    },
    {  //1080i_60, 6
        {MSVD_HDMI_HSTART_1080i60, MSVD_HDMI_VSTART_1080i60, 17, 17, 20, 20},  // Default
        {MSVD_HDMI_HSTART_1080i60, MSVD_HDMI_VSTART_1080i60, 17, 17, 20, 20},  // 16:9
        {MSVD_HDMI_HSTART_1080i60, MSVD_HDMI_VSTART_1080i60, 17, 17, 20, 20},  // 4:3
        {MSVD_HDMI_HSTART_1080i60, MSVD_HDMI_VSTART_1080i60, 17, 17, 20, 20},  // Auto
        {MSVD_HDMI_HSTART_1080i60, MSVD_HDMI_VSTART_1080i60, 17, 17, 20, 20},  // Panorama
        {MSVD_HDMI_HSTART_1080i60, MSVD_HDMI_VSTART_1080i60, 0, 0, 0, 0},  // Just Scan
        {MSVD_HDMI_HSTART_1080i60, MSVD_HDMI_VSTART_1080i60, 17, 17, 20, 20},  // Zoom2
        {MSVD_HDMI_HSTART_1080i60, MSVD_HDMI_VSTART_1080i60, 17, 17, 20, 20},  // Zoom1
    },
    {  //1080i_50, 7
        {MSVD_HDMI_HSTART_1080i50, MSVD_HDMI_VSTART_1080i50, 17, 17, 20, 20},  // Default
        {MSVD_HDMI_HSTART_1080i50, MSVD_HDMI_VSTART_1080i50, 17, 17, 20, 20},  // 16:9
        {MSVD_HDMI_HSTART_1080i50, MSVD_HDMI_VSTART_1080i50, 17, 17, 20, 20},  // 4:3
        {MSVD_HDMI_HSTART_1080i50, MSVD_HDMI_VSTART_1080i50, 17, 17, 20, 20},  // Auto
        {MSVD_HDMI_HSTART_1080i50, MSVD_HDMI_VSTART_1080i50, 17, 17, 20, 20},  // Panorama
        {MSVD_HDMI_HSTART_1080i50, MSVD_HDMI_VSTART_1080i50, 0, 0, 0, 0},  // Just Scan
        {MSVD_HDMI_HSTART_1080i50, MSVD_HDMI_VSTART_1080i50, 17, 17, 20, 20},  // Zoom2
        {MSVD_HDMI_HSTART_1080i50, MSVD_HDMI_VSTART_1080i50, 17, 17, 20, 20},  // Zoom1
    },
    {  //1080p_60, 8
        {MSVD_HDMI_HSTART_1080p60, MSVD_HDMI_VSTART_1080p60, 0, 0, 0, 0},  // Default
        {MSVD_HDMI_HSTART_1080p60, MSVD_HDMI_VSTART_1080p60, 0, 0, 0, 0},  // 16:9
        {MSVD_HDMI_HSTART_1080p60, MSVD_HDMI_VSTART_1080p60, 0, 0, 0, 0},  // 4:3
        {MSVD_HDMI_HSTART_1080p60, MSVD_HDMI_VSTART_1080p60, 0, 0, 0, 0},  // Auto
        {MSVD_HDMI_HSTART_1080p60, MSVD_HDMI_VSTART_1080p60, 0, 0, 0, 0},  // Panorama
        {MSVD_HDMI_HSTART_1080p60, MSVD_HDMI_VSTART_1080p60, 0, 0, 0, 0},  // Just Scan
        {MSVD_HDMI_HSTART_1080p60, MSVD_HDMI_VSTART_1080p60, 0, 0, 0, 0},  // Zoom2
        {MSVD_HDMI_HSTART_1080p60, MSVD_HDMI_VSTART_1080p60, 0, 0, 0, 0},  // Zoom1
    },
    {  //1080p_50, 9
        {MSVD_HDMI_HSTART_1080p50, MSVD_HDMI_VSTART_1080p50, 0, 0, 0, 0},  // Default
        {MSVD_HDMI_HSTART_1080p50, MSVD_HDMI_VSTART_1080p50, 0, 0, 0, 0},  // 16:9
        {MSVD_HDMI_HSTART_1080p50, MSVD_HDMI_VSTART_1080p50, 0, 0, 0, 0},  // 4:3
        {MSVD_HDMI_HSTART_1080p50, MSVD_HDMI_VSTART_1080p50, 0, 0, 0, 0},  // Auto
        {MSVD_HDMI_HSTART_1080p50, MSVD_HDMI_VSTART_1080p50, 0, 0, 0, 0},  // Panorama
        {MSVD_HDMI_HSTART_1080p50, MSVD_HDMI_VSTART_1080p50, 0, 0, 0, 0},  // Just Scan
        {MSVD_HDMI_HSTART_1080p50, MSVD_HDMI_VSTART_1080p50, 0, 0, 0, 0},  // Zoom2
        {MSVD_HDMI_HSTART_1080p50, MSVD_HDMI_VSTART_1080p50, 0, 0, 0, 0},  // Zoom1
    },
    {  //1080p_30, 10
        {MSVD_HDMI_HSTART_1080p30, MSVD_HDMI_VSTART_1080p30, 17, 17, 22, 22},  // Default
        {MSVD_HDMI_HSTART_1080p30, MSVD_HDMI_VSTART_1080p30, 17, 17, 22, 22},  // 16:9
        {MSVD_HDMI_HSTART_1080p30, MSVD_HDMI_VSTART_1080p30, 17, 17, 22, 22},  // 4:3
        {MSVD_HDMI_HSTART_1080p30, MSVD_HDMI_VSTART_1080p30, 17, 17, 22, 22},  // Auto
        {MSVD_HDMI_HSTART_1080p30, MSVD_HDMI_VSTART_1080p30, 17, 17, 22, 22},  // Panorama
        {MSVD_HDMI_HSTART_1080p30, MSVD_HDMI_VSTART_1080p30, 0, 0, 0, 0},  // Just Scan
        {MSVD_HDMI_HSTART_1080p30, MSVD_HDMI_VSTART_1080p30, 17, 17, 22, 22},  // Zoom2
        {MSVD_HDMI_HSTART_1080p30, MSVD_HDMI_VSTART_1080p30, 17, 17, 22, 22},  // Zoom1
    },
    {  //1080p_24, 11
        {MSVD_HDMI_HSTART_1080p24, MSVD_HDMI_VSTART_1080p24, 17, 17, 22, 22},  // Default
        {MSVD_HDMI_HSTART_1080p24, MSVD_HDMI_VSTART_1080p24, 17, 17, 22, 22},  // 16:9
        {MSVD_HDMI_HSTART_1080p24, MSVD_HDMI_VSTART_1080p24, 17, 17, 22, 22},  // 4:3
        {MSVD_HDMI_HSTART_1080p24, MSVD_HDMI_VSTART_1080p24, 17, 17, 22, 22},  // Auto
        {MSVD_HDMI_HSTART_1080p24, MSVD_HDMI_VSTART_1080p24, 17, 17, 22, 22},  // Panorama
        {MSVD_HDMI_HSTART_1080p24, MSVD_HDMI_VSTART_1080p24, 0, 0, 0, 0},  // Just Scan
        {MSVD_HDMI_HSTART_1080p24, MSVD_HDMI_VSTART_1080p24, 17, 17, 22, 22},  // Zoom2
        {MSVD_HDMI_HSTART_1080p24, MSVD_HDMI_VSTART_1080p24, 17, 17, 22, 22},  // Zoom1
    },
    {  //1440x480i, 12
        {MSVD_HDMI_HSTART_1440x480i60, MSVD_HDMI_VSTART_1440x480i60, 50, 50, 20, 20},  // Default
        {MSVD_HDMI_HSTART_1440x480i60, MSVD_HDMI_VSTART_1440x480i60, 50, 50, 20, 20},  // 16:9
        {MSVD_HDMI_HSTART_1440x480i60, MSVD_HDMI_VSTART_1440x480i60, 50, 50, 20, 20},  // 4:3
        {MSVD_HDMI_HSTART_1440x480i60, MSVD_HDMI_VSTART_1440x480i60, 50, 50, 20, 20},  // Auto
        {MSVD_HDMI_HSTART_1440x480i60, MSVD_HDMI_VSTART_1440x480i60, 50, 50, 20, 20},  // Panorama
        {MSVD_HDMI_HSTART_1440x480i60, MSVD_HDMI_VSTART_1440x480i60, 0, 0, 0, 0},  // Just Scan
        {MSVD_HDMI_HSTART_1440x480i60, MSVD_HDMI_VSTART_1440x480i60, 50, 50, 20, 20},  // Zoom2
        {MSVD_HDMI_HSTART_1440x480i60, MSVD_HDMI_VSTART_1440x480i60, 50, 50, 20, 20},  // Zoom1
    },
    {  //1440x480p, 13
        {MSVD_HDMI_HSTART_1440x480p60, MSVD_HDMI_VSTART_1440x480p60, 50, 50, 20, 20},  // Default
        {MSVD_HDMI_HSTART_1440x480p60, MSVD_HDMI_VSTART_1440x480p60, 50, 50, 20, 20},  // 16:9
        {MSVD_HDMI_HSTART_1440x480p60, MSVD_HDMI_VSTART_1440x480p60, 50, 50, 20, 20},  // 4:3
        {MSVD_HDMI_HSTART_1440x480p60, MSVD_HDMI_VSTART_1440x480p60, 50, 50, 20, 20},  // Auto
        {MSVD_HDMI_HSTART_1440x480p60, MSVD_HDMI_VSTART_1440x480p60, 50, 50, 20, 20},  // Panorama
        {MSVD_HDMI_HSTART_1440x480p60, MSVD_HDMI_VSTART_1440x480p60, 0, 0, 0, 0},  // Just Scan
        {MSVD_HDMI_HSTART_1440x480p60, MSVD_HDMI_VSTART_1440x480p60, 50, 50, 20, 20},  // Zoom2
        {MSVD_HDMI_HSTART_1440x480p60, MSVD_HDMI_VSTART_1440x480p60, 50, 50, 20, 20},  // Zoom1
    },
    {  //1440x576i, 14
        {MSVD_HDMI_HSTART_1440x576i50, MSVD_HDMI_VSTART_1440x576i50, 50, 50, 20, 20},  // Default
        {MSVD_HDMI_HSTART_1440x576i50, MSVD_HDMI_VSTART_1440x576i50, 50, 50, 20, 20},  // 16:9
        {MSVD_HDMI_HSTART_1440x576i50, MSVD_HDMI_VSTART_1440x576i50, 50, 50, 20, 20},  // 4:3
        {MSVD_HDMI_HSTART_1440x576i50, MSVD_HDMI_VSTART_1440x576i50, 50, 50, 20, 20},  // Auto
        {MSVD_HDMI_HSTART_1440x576i50, MSVD_HDMI_VSTART_1440x576i50, 50, 50, 20, 20},  // Panorama
        {MSVD_HDMI_HSTART_1440x576i50, MSVD_HDMI_VSTART_1440x576i50, 0, 0, 0, 0},  // Just Scan
        {MSVD_HDMI_HSTART_1440x576i50, MSVD_HDMI_VSTART_1440x576i50, 50, 50, 20, 20},  // Zoom2
        {MSVD_HDMI_HSTART_1440x576i50, MSVD_HDMI_VSTART_1440x576i50, 50, 50, 20, 20},  // Zoom1
    },
    {  //1440x576p, 15
        {MSVD_HDMI_HSTART_1440x576p50, MSVD_HDMI_VSTART_1440x576p50, 50, 50, 20, 20},  // Default
        {MSVD_HDMI_HSTART_1440x576p50, MSVD_HDMI_VSTART_1440x576p50, 50, 50, 20, 20},  // 16:9
        {MSVD_HDMI_HSTART_1440x576p50, MSVD_HDMI_VSTART_1440x576p50, 50, 50, 20, 20},  // 4:3
        {MSVD_HDMI_HSTART_1440x576p50, MSVD_HDMI_VSTART_1440x576p50, 50, 50, 20, 20},  // Auto
        {MSVD_HDMI_HSTART_1440x576p50, MSVD_HDMI_VSTART_1440x576p50, 50, 50, 20, 20},  // Panorama
        {MSVD_HDMI_HSTART_1440x576p50, MSVD_HDMI_VSTART_1440x576p50, 0, 0, 0, 0},  // Just Scan
        {MSVD_HDMI_HSTART_1440x576p50, MSVD_HDMI_VSTART_1440x576p50, 50, 50, 20, 20},  // Zoom2
        {MSVD_HDMI_HSTART_1440x576p50, MSVD_HDMI_VSTART_1440x576p50, 50, 50, 20, 20},  // Zoom1
    },
};

//********************************************************************************
//                     Local
//********************************************************************************

// zoom numerator of left/right/up/down & zoom denumerator
#define ZOOM_NUMERATOR_LEFTMAX      200
#define ZOOM_NUMERATOR_RIGHTMAX     200
#define ZOOM_NUMERATOR_UPMAX        200
#define ZOOM_NUMERATOR_DOWNMAX      200
#define ZOOM_DENUMERATOR            1000

static S16 _s16ZoomLeft;
static S16 _s16ZoomRight;
static S16 _s16ZoomUp;
static S16 _s16ZoomDown;

static BOOLEAN _u8EnableOverScan;
static U8 _u8H_OverScanRatio;
static U8 _u8V_OverScanRatio;

static U8 _u8H_CropRatio_Left;
static U8 _u8H_CropRatio_Right;
static U8 _u8V_CropRatio_Up;
static U8 _u8V_CropRatio_Down;

static BOOLEAN _bEnNonLinearScaling[PIP_WINDOWS];             // Daten FixMe, MAX_WINDOW will be removed and can be obtained from MApi_XC_GetInfo()
static BOOLEAN _bEnHDMI_RefineHVStart = FALSE;

static U8 _MApp_Scaler_Resolution_Remapping(XC_SETWIN_INFO *pstXC_SetWin_Info, SCALER_WIN eWindow );
static U8 _MApp_Scaler_Aspect_Ratio_Remapping(EN_ASPECT_RATIO_TYPE enVideoScreen);

static XC_SETWIN_INFO stXC_SetWin_Info[PIP_WINDOWS];
static MS_VIDEO_Window_Info_EXT st_VidWin_Info;

// DTV
static U16 _u16OverscanDtvDefaultH = 10;
static U16 _u16OverscanDtvDefaultV = 10;
static U16 _u16OverscanDtv480iH = 35;
static U16 _u16OverscanDtv480iV = 28;
static U16 _u16OverscanDtv480pH = 34;
static U16 _u16OverscanDtv480pV = 34;
static U16 _u16OverscanDtv576iH = 32;
static U16 _u16OverscanDtv576iV = 23;
static U16 _u16OverscanDtv576pH = 20;
static U16 _u16OverscanDtv576pV = 20;
static U16 _u16OverscanDtv720pH = 34;
static U16 _u16OverscanDtv720pV = 34;
static U16 _u16OverscanDtv1080iH = 31;
static U16 _u16OverscanDtv1080iV = 30;
static U16 _u16OverscanDtv1080pH = 33;
static U16 _u16OverscanDtv1080pV = 33;
#if ENABLE_3D_PROCESS
static BOOLEAN _bManualDetectTiming = FALSE;
#endif

#if ENABLE_AUTOTEST
extern BOOLEAN g_bAutobuildDebug;
#endif
BOOLEAN m_bFLG_PREVIEW = FALSE;

#if (MEMORY_MAP <= MMAP_32MB)
BOOLEAN m_bFLG_MMSD = FALSE;
#endif

/********************************************************************************/
/*              Functions                                           */
/* ******************************************************************************/
#if ENABLE_BACKLIGHT_PWM_SYNC_WITH_FRAMERATE
void SetPWMto2PanelVFreq(U8 ratio)
{
    MS_U32 OutputVFreqX100 = MApi_XC_GetOutputVFreqX100();
    MS_U32 u32PWM_PERIOD;

    u32PWM_PERIOD = (long)(12000000 * 100)/(OutputVFreqX100 * ratio*PWM0_DIV);

    MDrv_PWM_Period(E_PWM_CH0, u32PWM_PERIOD);
    MDrv_PWM_DutyCycle(E_PWM_CH0, 50);
    printf("\n wz@ OutputVFreqX100=%d\n", OutputVFreqX100);
    printf("\n wz@ u32PWM_PERIOD=%d\n", u32PWM_PERIOD);
    printf("\n wz@ u32PWM_PERIOD=0x%x\n", u32PWM_PERIOD);
}
#endif

U8 MApp_Scaler_FactoryAdjBrightness(U8 u8Brightness, U8 u8SubBrightness)
{
    U16 u16TempBrightness;
    u16TempBrightness = (U16)u8Brightness * u8SubBrightness / SUB_BRIGHTNESS_BYPASS;
    u16TempBrightness = MIN(u16TempBrightness, 255);
    return (U8)u16TempBrightness;
}

U8 MApp_Scaler_FactoryContrast(U8 u8Contrast, U8 u8SubContrast)
{
    U16 u16TempContrast;
    u16TempContrast = (U16)u8Contrast * u8SubContrast / SUB_CONTRAST_BYPASS;

#if (FRONTEND_IF_DEMODE_TYPE == MSTAR_VIF)
    u16TempContrast+=50;
#endif

    u16TempContrast = MIN(u16TempContrast, 255);
    return (U8)u16TempContrast;
}

void MApp_Scaler_SetTiming(INPUT_SOURCE_TYPE_t enInputSourceType, SCALER_WIN eWindow)
{
    XC_SetTiming_Info stTimingInfo;
    MS_U16 u16InputHFreq;
    MVOP_Timing stMVOPTiming;

    stTimingInfo.bFastFrameLock = FALSE;

    if( IsSrcTypeAnalog(enInputSourceType) || IsSrcTypeHDMI(enInputSourceType))
    {
        stTimingInfo.u16InputVTotal = MApi_XC_PCMonitor_Get_Vtotal(eWindow);
        stTimingInfo.bInterlace     = MApi_XC_PCMonitor_GetSyncStatus(eWindow) & XC_MD_INTERLACE_BIT ? TRUE : FALSE;
        stTimingInfo.u16InputVFreq  = MApi_XC_PCMonitor_Get_VFreqx10(eWindow);
        stTimingInfo.bMVOPSrc       = 0;
    }
    else if( IsSrcTypeATV(enInputSourceType) || IsSrcTypeDigitalVD(enInputSourceType) )
    {
        EN_VD_SIGNALTYPE enVideoSystem = mvideo_vd_get_videosystem();

        if(enVideoSystem == SIG_NONE)
        {
        #if ( TV_SYSTEM == TV_NTSC )
            enVideoSystem = SIG_NTSC;
        #elif ( TV_SYSTEM == TV_PAL || TV_SYSTEM == TV_CHINA)
            enVideoSystem = SIG_PAL;
        #else
            enVideoSystem = SIG_PAL;
        #endif
        }

        u16InputHFreq = MApi_XC_CalculateHFreqx10(msAPI_Scaler_VD_GetHPeriod(eWindow, enInputSourceType, GET_SYNC_VIRTUAL));
        stTimingInfo.u16InputVTotal = msAPI_Scaler_VD_GetVTotal(eWindow, enInputSourceType, GET_SYNC_VIRTUAL, u16InputHFreq);
        stTimingInfo.bInterlace     = TRUE;
        stTimingInfo.u16InputVFreq  = MApi_XC_CalculateVFreqx10(u16InputHFreq, stTimingInfo.u16InputVTotal)*2;
        stTimingInfo.bMVOPSrc       = FALSE;

        if(msAPI_AVD_GetForceVideoStandardFlag())
        {
            MSG(printf("Force Video Standard!\n");)
            if(stTimingInfo.u16InputVTotal > 566)
            {
                MSG(printf("signal in fact is PAL!\n");)
                enVideoSystem = SIG_PAL;
            }
            else
            {
                MSG(printf("signal in fact is NTSC!\n");)
                enVideoSystem = SIG_NTSC;
            }
        }

        switch ( enVideoSystem )
        {
            case SIG_NTSC:
            case SIG_NTSC_443:
            case SIG_PAL_M:
                if((stTimingInfo.u16InputVFreq > 610) || (stTimingInfo.u16InputVFreq < 590))
                {
                    stTimingInfo.u16InputVFreq = 600;
                }
                break;

            default:
            case SIG_PAL:
            case SIG_SECAM:
            case SIG_PAL_NC:
                if((stTimingInfo.u16InputVFreq > 510) || (stTimingInfo.u16InputVFreq < 490) )
                {
                    stTimingInfo.u16InputVFreq = 500;
                }
                break;
        }
    }
    else
    {
        MDrv_MVOP_GetOutputTiming(&stMVOPTiming);

        stTimingInfo.u16InputVTotal = stMVOPTiming.u16V_TotalCount;
        stTimingInfo.bInterlace     = stMVOPTiming.bInterlace;
        if(stTimingInfo.bInterlace)
        {
            stTimingInfo.u16InputVFreq = (U16)((stMVOPTiming.u16ExpFrameRate * 2 + 50) / 100);
        }
        else
        {
            stTimingInfo.u16InputVFreq = (U16)((stMVOPTiming.u16ExpFrameRate + 50) / 100);
        }

        stTimingInfo.bMVOPSrc = TRUE;
    }

MApi_SC_ForceFreerun(TRUE);
MApi_SC_SetFreerunVFreq(VFREQ_60HZ);

//DAC output need special SET computation.
//We disable scaler SET temporarily here. need refine if we merge SET of XC into PNL
    {
        MApi_XC_SetPanelTiming(&stTimingInfo, eWindow);
    }
#if ENABLE_BACKLIGHT_PWM_SYNC_WITH_FRAMERATE
        SetPWMto2PanelVFreq(RATIO_OF_BACKLIGHT_FREQ_OVER_FRAMERATE);
#endif

}

//*************************************************************************
//Function name:    MApp_Scaler_Setting_SetVDScale
//Passing parameter:    none
//Return parameter:     none
//Description:      Set video scale
//*************************************************************************
void MApp_Scaler_Setting_SetVDScale (EN_MENU_AspectRatio eAspect, SCALER_WIN eWindow)
{
    EN_ASPECT_RATIO_TYPE enVideoScreen;

    static EN_MENU_AspectRatio ePreARC = EN_AspectRatio_Num;

    if( eAspect == ePreARC)
    {
        MSG(printf("AspectRatio pass \r\n"));
      #if ENABLE_ZOOM_AVOUT_NOTMUTE
       if(bIsAspectMute)
        bIsAspectMute = FALSE;
      #endif
        return;
    }
    else
    {
        ePreARC = eAspect;
    }
	//SMC jayden.chen add for show blackScreen when adjust picture aspect ratio 20130311
	//����Ϊ������ʱ���л�����ģʽ˲������
	{
		extern BOOLEAN bIsSrcChangeScreen;
		//printf("bIsSrcChangeScreen1 = %d \r\n",bIsSrcChangeScreen);
		bIsSrcChangeScreen = TRUE;
    }
    switch(eWindow)
    {
    case MAIN_WINDOW:
        if((!(stSystemInfo[MAIN_WINDOW].u8PanelPowerStatus & PANEL_POWER_BLUESCREEN))
            #if (MHEG5_ENABLE)
            || msAPI_MHEG5_IsRunning()
            #endif
            )
        {
            enVideoScreen = MApp_Scaler_GetAspectRatio(eAspect);
            stSystemInfo[MAIN_WINDOW].enAspectRatio = enVideoScreen;

            if(MApp_IsSrcHasSignal(MAIN_WINDOW)
                #if (MHEG5_ENABLE)
                || msAPI_MHEG5_IsRunning()
                #endif
                )
            {
                #if (CHANGE_AR_WITHOUT_BLUESCREEN == DISABLE)
                msAPI_Scaler_SetBlueScreen(ENABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
                #endif


                #if (MHEG5_ENABLE)
                    if(msAPI_MHEG5_IsRunning())
                    {
                        if  (msAPI_Picture_isAFDEnable(stSystemInfo[MAIN_WINDOW].enAspectRatio) &&
                            msAPI_Picture_isCurrentAFDVaild(MApi_VDEC_GetActiveFormat()))
                        {
                            MApp_MHEG5_SetGraphARCInfo(SENDARC_AFD_FOR_GE,stSystemInfo[MAIN_WINDOW].enAspectRatio);
                            MApp_MHEG5_SetGraphARCInfo(SENDARC_AFD,stSystemInfo[MAIN_WINDOW].enAspectRatio);
                            msAPI_MHEG5_VID_SendUserArcEvent();
                        }
                        else
                        {
                            MApp_MHEG5_SetGraphARCInfo(SENDARC_ARC_CHANGE,stSystemInfo[MAIN_WINDOW].enAspectRatio);
                        }
                    }
                #endif

                MS_DEBUG_MSG(printf("[%s]: SetT&W------------------------------\n", __FUNCTION__));
              #if ENABLE_FBL_ASPECT_RATIO_BY_MVOP
                if( MApi_XC_IsCurrentFrameBufferLessMode() &&
                    (IsSrcTypeStorage(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)) || IsSrcTypeDTV(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW))) )
                {
                    MApp_Scaler_SetFBLTimingForAspectRatio(enVideoScreen);
                }
                else
              #endif
                {
                    MApp_Scaler_SetWindow(NULL, NULL, NULL,
                                           enVideoScreen, SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW), MAIN_WINDOW);

                    MApp_Picture_Setting_SetColor(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW), MAIN_WINDOW);
                #if (CHANGE_AR_WITHOUT_BLUESCREEN == DISABLE)
                    MApp_Scaler_SetTiming(SYS_INPUT_SOURCE_TYPE(eWindow), eWindow);
                    msAPI_Scaler_SetBlueScreen(DISABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
                #endif
                }
            }
        }
        break;
#if (ENABLE_PIP)
    case SUB_WINDOW:
        if(IsPIPSupported())
        {
            if(!(stSystemInfo[SUB_WINDOW].u8PanelPowerStatus & PANEL_POWER_BLUESCREEN))
            {
                enVideoScreen = MApp_Scaler_GetAspectRatio(eAspect);
                stSystemInfo[SUB_WINDOW].enAspectRatio = enVideoScreen;

                if(MApp_IsSrcHasSignal(SUB_WINDOW))
                {
                    msAPI_Scaler_SetBlueScreen(ENABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, SUB_WINDOW);
                    printf("[%s]: Set sub window T&W------------------------------\n", __FUNCTION__);
                    printf("sub window position x:%u y:%u width:%u hight:%u",stSubWindowPosition.x,stSubWindowPosition.y,stSubWindowPosition.width,stSubWindowPosition.height);
                    MApp_Scaler_SetWindow(NULL, NULL, &stSubWindowPosition,
                                               enVideoScreen, SYS_INPUT_SOURCE_TYPE(SUB_WINDOW), SUB_WINDOW);
                    MApp_Picture_Setting_SetColor(SYS_INPUT_SOURCE_TYPE(SUB_WINDOW), SUB_WINDOW);
                    MApp_Scaler_SetTiming(SYS_INPUT_SOURCE_TYPE(eWindow), eWindow);
                    msAPI_Scaler_SetBlueScreen(DISABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, SUB_WINDOW);
                }
            }
        }
        break;
#endif
    default:
        MS_DEBUG_MSG(printf("invalid window number!\n"));
        break;
    }
   #if ENABLE_ZOOM_AVOUT_NOTMUTE
    if(bIsAspectMute)
     bIsAspectMute = FALSE;
   #endif

   //SMC jayden.chen add for show blackScreen when adjust picture aspect ratio 20130311
   //����Ϊ������ʱ���л�����ģʽ˲������
   {
	   extern BOOLEAN bIsSrcChangeScreen;
	   //printf("bIsSrcChangeScreen2 = %d \r\n",bIsSrcChangeScreen);
	   bIsSrcChangeScreen = FALSE;
   }
}

#if ENABLE_CUS_HDMI_MODE
void MApp_Scaler_Setting_ForceSetVDScale (EN_MENU_AspectRatio eAspect, SCALER_WIN eWindow)
{
    EN_ASPECT_RATIO_TYPE enVideoScreen;

    switch(eWindow)
    {
    case MAIN_WINDOW:
        if((!(stSystemInfo[MAIN_WINDOW].u8PanelPowerStatus & PANEL_POWER_BLUESCREEN))
            #if (MHEG5_ENABLE)
            || msAPI_MHEG5_IsRunning()
            #endif
            )
        {
            enVideoScreen = MApp_Scaler_GetAspectRatio(eAspect);
            stSystemInfo[MAIN_WINDOW].enAspectRatio = enVideoScreen;

            if(MApp_IsSrcHasSignal(MAIN_WINDOW)
                #if (MHEG5_ENABLE)
                || msAPI_MHEG5_IsRunning()
                #endif
                )
            {
                #if (CHANGE_AR_WITHOUT_BLUESCREEN == DISABLE)
                msAPI_Scaler_SetBlueScreen(ENABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
                #endif


                #if (MHEG5_ENABLE)
                    if(msAPI_MHEG5_IsRunning())
                    {
                        if  (msAPI_Picture_isAFDEnable(stSystemInfo[MAIN_WINDOW].enAspectRatio) &&
                            msAPI_Picture_isCurrentAFDVaild(MApi_VDEC_GetActiveFormat()))
                        {
                            MApp_MHEG5_SetGraphARCInfo(SENDARC_AFD_FOR_GE,stSystemInfo[MAIN_WINDOW].enAspectRatio);
                            MApp_MHEG5_SetGraphARCInfo(SENDARC_AFD,stSystemInfo[MAIN_WINDOW].enAspectRatio);
                            msAPI_MHEG5_VID_SendUserArcEvent();
                        }
                        else
                        {
                            MApp_MHEG5_SetGraphARCInfo(SENDARC_ARC_CHANGE,stSystemInfo[MAIN_WINDOW].enAspectRatio);
                        }
                    }
                #endif

                MS_DEBUG_MSG(printf("[%s]: SetT&W------------------------------\n", __FUNCTION__));
              #if ENABLE_FBL_ASPECT_RATIO_BY_MVOP
                if( MApi_XC_IsCurrentFrameBufferLessMode() &&
                    (IsSrcTypeStorage(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)) || IsSrcTypeDTV(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW))) )
                {
                    MApp_Scaler_SetFBLTimingForAspectRatio(enVideoScreen);
                }
                else
              #endif
                {
                    MApp_Scaler_SetWindow(NULL, NULL, NULL,
                                           enVideoScreen, SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW), MAIN_WINDOW);

                    MApp_Picture_Setting_SetColor(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW), MAIN_WINDOW);
                #if (CHANGE_AR_WITHOUT_BLUESCREEN == DISABLE)
                    MApp_Scaler_SetTiming(SYS_INPUT_SOURCE_TYPE(eWindow), eWindow);
                    msAPI_Scaler_SetBlueScreen(DISABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
                #endif
                }
            }
        }
        break;
#if (ENABLE_PIP)
    case SUB_WINDOW:
        if(IsPIPSupported())
        {
            if(!(stSystemInfo[SUB_WINDOW].u8PanelPowerStatus & PANEL_POWER_BLUESCREEN))
            {
                enVideoScreen = MApp_Scaler_GetAspectRatio(eAspect);
                stSystemInfo[SUB_WINDOW].enAspectRatio = enVideoScreen;

                if(MApp_IsSrcHasSignal(SUB_WINDOW))
                {
                    msAPI_Scaler_SetBlueScreen(ENABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, SUB_WINDOW);
                    printf("[%s]: Set sub window T&W------------------------------\n", __FUNCTION__);
                    printf("sub window position x:%u y:%u width:%u hight:%u",stSubWindowPosition.x,stSubWindowPosition.y,stSubWindowPosition.width,stSubWindowPosition.height);
                    MApp_Scaler_SetWindow(NULL, NULL, &stSubWindowPosition,
                                               enVideoScreen, SYS_INPUT_SOURCE_TYPE(SUB_WINDOW), SUB_WINDOW);
                    MApp_Picture_Setting_SetColor(SYS_INPUT_SOURCE_TYPE(SUB_WINDOW), SUB_WINDOW);
                    MApp_Scaler_SetTiming(SYS_INPUT_SOURCE_TYPE(eWindow), eWindow);
                    msAPI_Scaler_SetBlueScreen(DISABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, SUB_WINDOW);
                }
            }
        }
        break;
#endif
    default:
        MS_DEBUG_MSG(printf("invalid window number!\n"));
        break;
    }
}
#endif

#if ( ENABLE_OD )
extern void MDrv_FrontOverDriver(void);  ///jaly test od here
extern void MDrv_BackOverDriver(void);  //jaly test Od here
#endif

static void _MApp_Scaler_CheckHDMode(void)
{
    U16 u16H_CapSize=0, u16V_CapSize=0;

    if( IsSrcTypeDigitalVD(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)) )
    {
        MApi_XC_Sys_SetSrcIsHD( FALSE, MAIN_WINDOW );
    }
    else
    {
#if (INPUT_HDMI_VIDEO_COUNT > 0)
        if(IsSrcTypeHDMI(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)))
        {
            u16H_CapSize = MApp_PCMode_Get_HResolution(MAIN_WINDOW,FALSE);
            u16V_CapSize = MApp_PCMode_Get_VResolution(MAIN_WINDOW,FALSE);
        }
        else
#endif
        if(IsSrcTypeVga(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)) || IsSrcTypeYPbPr(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)))
        {
            u16H_CapSize = MApp_PCMode_Get_HResolution( MAIN_WINDOW, TRUE); // standard display width
            u16V_CapSize = MApp_PCMode_Get_VResolution( MAIN_WINDOW, TRUE); // standard display height
        }
        else if( IsSrcTypeDTV(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)) )
        {
            u16H_CapSize = MDrv_MVOP_GetHSize();
            u16V_CapSize = MDrv_MVOP_GetVSize();
        }

        // Setup HD flag
        if(u16H_CapSize >= 1280 && u16V_CapSize >= 720)
        {
            MApi_XC_Sys_SetSrcIsHD( TRUE, MAIN_WINDOW );
            #if ( ENABLE_OD )
            MDrv_FrontOverDriver();
            #endif
        }
        else
        {
            MApi_XC_Sys_SetSrcIsHD( FALSE, MAIN_WINDOW );

            #if ( ENABLE_OD )
            MDrv_BackOverDriver();
            #endif
        }
    }
}

void MApp_Scaler_Setting_HDMI_PAR(void)
{
    if( ST_VIDEO.eAspectRatio == EN_AspectRatio_Original )
    {
            EN_ASPECT_RATIO_TYPE enVideoScreen;

            enVideoScreen = MApp_Scaler_GetAspectRatio(ST_VIDEO.eAspectRatio);

            if( enVideoScreen != stSystemInfo[MAIN_WINDOW].enAspectRatio )
            {
                //printf("Set by program hdmi Par chankged! %bu\n");
                stSystemInfo[MAIN_WINDOW].enAspectRatio = enVideoScreen;

                 MS_DEBUG_MSG(printf("[%s]: SetT&W------------------------------\n", __FUNCTION__));
                 MApp_Scaler_SetWindow(NULL, NULL, NULL,
                                           enVideoScreen, SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW), MAIN_WINDOW);
             }
    }
}


/******************************************************************************/
///Setup input and output window information including aspect ratio, scaling.(analog part)
///@param enPortType \b IN
///- input Port (RGB or YPbPr) only could be use
///@param pstModesetting \b IN
///- pointer to mode settings
///@param u8CurrentSyncStatus \b IN
///- current mode index
///@return
///- pointer to current window information
/******************************************************************************/
static void _MApp_Scaler_ProgAnalogWin ( INPUT_SOURCE_TYPE_t enInputSourceType,
                                         MS_PCADC_MODESETTING_TYPE *pstModesetting,
                                         U8 u8AspectRatio,
                                         U8 u8CurrentSyncStatus,
                                         XC_SETWIN_INFO *pstXC_SetWin_Info,
                                         SCALER_WIN eWindow)
{
    U8 u8Resolution;
    PQ_WIN enPQWin;

    pstXC_SetWin_Info->bHDuplicate    = FALSE;
    pstXC_SetWin_Info->u16InputVTotal = MApi_XC_PCMonitor_Get_Vtotal(eWindow);

    if(IsSrcTypeYPbPr(enInputSourceType) && (g_PcadcModeSetting[eWindow].u8ModeIndex == MD_720x480_60I_P))
    {
        // this is patch for DVD 480i -> Sherwood -> component output -> OSD unsupport mode
        pstXC_SetWin_Info->bInterlace = TRUE;
    }
    else
    {
        pstXC_SetWin_Info->bInterlace = u8CurrentSyncStatus & XC_MD_INTERLACE_BIT ? TRUE : FALSE;
    }

    pstXC_SetWin_Info->u16InputVFreq  = MApi_XC_PCMonitor_Get_VFreqx10(eWindow);


#if (INPUT_HDMI_VIDEO_COUNT > 0)
    if(IsSrcTypeHDMI(enInputSourceType))
    {
        // DVI or HDMI
        if (MApi_XC_GetHdmiSyncMode() == HDMI_SYNC_DE)
        {
            MApi_XC_GetDEWindow(&(pstXC_SetWin_Info->stCapWin), eWindow);

            if(pstXC_SetWin_Info->bInterlace
            &&(pstXC_SetWin_Info->stCapWin.height>1080)
            &&(pstXC_SetWin_Info->stCapWin.height<1100)
            )
            {
                pstXC_SetWin_Info->stCapWin.height=1080;
            }
            u8Resolution = _MApp_Scaler_Resolution_Remapping(pstXC_SetWin_Info, eWindow);

            if( (g_HdmiPollingStatus.bIsHDMIMode == FALSE))     // DVI mode
            {
                // Use DE information
            }
            else if (_bEnHDMI_RefineHVStart)
            {                                                   // HDMI mode
                pstXC_SetWin_Info->stCapWin.x = HDMI_WinInfo[u8Resolution][u8AspectRatio].u16H_CapStart;
                pstXC_SetWin_Info->stCapWin.y = HDMI_WinInfo[u8Resolution][u8AspectRatio].u16V_CapStart;
            }
        }
        else
        {
            // The capture window is uncontrollable in HDMI HV DE-Bypass mode. So Capture start will assigned by driver itself.
            // Here we just assign a value to capture start
            pstXC_SetWin_Info->stCapWin.x = pstXC_SetWin_Info->stCapWin.y = 8;
            pstXC_SetWin_Info->stCapWin.width = MApp_PCMode_Get_HResolution( eWindow ,FALSE); // standard display width
            pstXC_SetWin_Info->stCapWin.height = MApp_PCMode_Get_VResolution( eWindow ,FALSE); // standard display height
        }
    }
    else
#endif
    {
        // VGA or YPbPr
        pstXC_SetWin_Info->stCapWin.x      = pstModesetting->u16DefaultHStart* 2 -pstModesetting->u16HorizontalStart;
        pstXC_SetWin_Info->stCapWin.y      = pstModesetting->u16VerticalStart;

        pstXC_SetWin_Info->stCapWin.width  = MApp_PCMode_Get_HResolution( eWindow ,TRUE); // standard display width
        pstXC_SetWin_Info->stCapWin.height = MApp_PCMode_Get_VResolution( eWindow ,TRUE); // standard display height

        u8Resolution = _MApp_Scaler_Resolution_Remapping(pstXC_SetWin_Info, eWindow);

            if(IsSrcTypeYPbPr(enInputSourceType))
            {
                if(g_PcadcModeSetting[eWindow].u8ModeIndex == MD_720x480_60I ||
                   g_PcadcModeSetting[eWindow].u8ModeIndex == MD_720x480_60P ||
                   g_PcadcModeSetting[eWindow].u8ModeIndex == MD_720x576_50I ||
                   g_PcadcModeSetting[eWindow].u8ModeIndex == MD_720x576_50P ||
                   g_PcadcModeSetting[eWindow].u8ModeIndex == MD_720x480_60I_P)
                {
                    pstXC_SetWin_Info->stCapWin.x <<= 1; // for better quality
                    pstXC_SetWin_Info->stCapWin.width <<= 1;
                    pstXC_SetWin_Info->bHDuplicate = TRUE;
                }

                pstXC_SetWin_Info->stCapWin.x = YPbPr_WinInfo[u8Resolution][u8AspectRatio].u16H_CapStart;
                pstXC_SetWin_Info->stCapWin.y = YPbPr_WinInfo[u8Resolution][u8AspectRatio].u16V_CapStart;
            }

        // these 2 settings only for VGA/YPbPr
        // must be mode table user data because everytime called set window such as change Aspect Ratio
        // these values will be set again to ADC
        // UI can change VGA Htotal and Phase, so must pass UI setting
        pstXC_SetWin_Info->u16DefaultHtotal = g_PcadcModeSetting[eWindow].u16HorizontalTotal;
        pstXC_SetWin_Info->u8DefaultPhase   = g_PcadcModeSetting[eWindow].u16Phase;
    }

    _u8H_OverScanRatio = OVERSCAN_DEFAULT_H;
    _u8V_OverScanRatio = OVERSCAN_DEFAULT_V;

    switch(eWindow)
    {
    default:
    case MAIN_WINDOW:
        enPQWin = PQ_MAIN_WINDOW;
        break;
    case SUB_WINDOW:
        enPQWin = PQ_SUB_WINDOW;
        break;
    }

    if(IsSrcTypeHDMI(enInputSourceType))
    {
        MS_PQ_Hdmi_Info stPQHDMI_Info;

        stPQHDMI_Info.bIsHDMI = g_HdmiPollingStatus.bIsHDMIMode;
        switch(g_HdmiPollingStatus.u8ColorFormat)
        {
        default:
        case MS_HDMI_COLOR_RGB:
            stPQHDMI_Info.enColorFmt = PQ_HDMI_COLOR_RGB;
            break;

        case MS_HDMI_COLOR_YUV_422:
            stPQHDMI_Info.enColorFmt = PQ_HDMI_COLOR_YUV_422;
            break;

        case MS_HDMI_COLOR_YUV_444:
            stPQHDMI_Info.enColorFmt = PQ_HDMI_COLOR_YUV_444;
            break;
        }

        MDrv_PQ_SetHDMIInfo(enPQWin, &stPQHDMI_Info);
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////
    // VGA, DVI
}

static void _MApp_Scaler_ProgDigitalWin (INPUT_SOURCE_TYPE_t enInputSourceType, EN_VD_SIGNALTYPE enVideoSystem,
                                            U8 u8AspectRatio, XC_SETWIN_INFO *pstXC_SetWin_Info, SCALER_WIN eWindow)
{
    U16 u16InputHFreq;
    PQ_WIN enPQWin;
    MS_PQ_Vd_Info stPQVDInfo;
    EN_VD_SIGNALTYPE enBackupVideoSystem;
#if(PQ_ENABLE_VD_SAMPLING)
    MS_PQ_VD_Sampling_Info stVDSamplingInfo;
#endif

    switch(eWindow)
    {
    default:
    case MAIN_WINDOW:
        enPQWin = PQ_MAIN_WINDOW;
        break;
    case SUB_WINDOW:
        enPQWin = PQ_SUB_WINDOW;
        break;
    }

    switch(msAPI_AVD_GetVideoStandard())
    {
    case E_VIDEOSTANDARD_NTSC_M:
        stPQVDInfo.enVideoStandard = E_PQ_VIDEOSTANDARD_NTSC_M;
        break;

    case E_VIDEOSTANDARD_PAL_BGHI:
        stPQVDInfo.enVideoStandard = E_PQ_VIDEOSTANDARD_PAL_BGHI;
        break;

    case E_VIDEOSTANDARD_SECAM:
        stPQVDInfo.enVideoStandard = E_PQ_VIDEOSTANDARD_SECAM;
        break;

    case E_VIDEOSTANDARD_NTSC_44:
        stPQVDInfo.enVideoStandard = E_PQ_VIDEOSTANDARD_NTSC_44;
        break;

    case E_VIDEOSTANDARD_PAL_M:
        stPQVDInfo.enVideoStandard = E_PQ_VIDEOSTANDARD_PAL_M;
        break;

    case E_VIDEOSTANDARD_PAL_N:
        stPQVDInfo.enVideoStandard = E_PQ_VIDEOSTANDARD_PAL_N;
        break;

    case E_VIDEOSTANDARD_PAL_60:
        stPQVDInfo.enVideoStandard = E_PQ_VIDEOSTANDARD_PAL_60;
        break;

    default:
        ASSERT(0);
        stPQVDInfo.enVideoStandard = E_PQ_VIDEOSTANDARD_PAL_BGHI;
        break;
    }

    switch(msAPI_AVD_GetScart1SrcType())
    {
    case E_SCART_SRC_TYPE_RGB:
        stPQVDInfo.bIsSCART_RGB = TRUE;
        break;
    case E_SCART_SRC_TYPE_CVBS:
    default:
        stPQVDInfo.bIsSCART_RGB = FALSE;
        break;
    }

#if (FRONTEND_IF_DEMODE_TYPE == MSTAR_VIF)
    stPQVDInfo.bIsVIFIN = TRUE;
#else
    stPQVDInfo.bIsVIFIN = FALSE;
#endif

    MDrv_PQ_Set_VDInfo(enPQWin, &stPQVDInfo);

    if ( enVideoSystem == SIG_NONE )
    {
        enVideoSystem = SIG_PAL;
    }

    enBackupVideoSystem = enVideoSystem;

    #ifdef __EXTVD
    if(IsUseExtVDPort((INPUT_PORT_TYPE_t)enInputSourceType))
    {
        msAPI_AVD_GetCaptureWindow(&(pstXC_SetWin_Info->stCapWin), enVideoSystem, TRUE);
    }
    else
    #endif
    {
    #if(PQ_ENABLE_VD_SAMPLING)
        memset(&stVDSamplingInfo, 0, sizeof(MS_PQ_VD_Sampling_Info));
        MDrv_PQ_Get_VDSampling_Info(PQ_MAIN_WINDOW, PQ_INPUT_SOURCE_CVBS, stPQVDInfo.enVideoStandard, &stVDSamplingInfo);
        msAPI_AVD_GetCaptureWindowByPQ(&(pstXC_SetWin_Info->stCapWin), enVideoSystem, &stVDSamplingInfo);
    #else
        msAPI_AVD_GetCaptureWindow(&(pstXC_SetWin_Info->stCapWin), enVideoSystem, FALSE);
    #endif
    }

    // Capture height should be set to 920 when no signal.
    if (IsSrcTypeATV(enInputSourceType) && !MDrv_AVD_IsSyncLocked())
    {
        if(MApp_IsSrcHasSignal(MAIN_WINDOW)==FALSE)
        {
            #if ( TV_SYSTEM == TV_NTSC )
                    pstXC_SetWin_Info->stCapWin.height = 432;  //480 * 0.9 (V sync is unstable now, so setting capture height as standard * .9 (overscan 10%) )
            #elif ( TV_SYSTEM == TV_PAL || TV_SYSTEM == TV_CHINA)
                    pstXC_SetWin_Info->stCapWin.height = 518;
            #else
                    pstXC_SetWin_Info->stCapWin.height = 432;
            #endif
        }
    }

#if(!ENABLE_DTV)
#if ( TV_SYSTEM == TV_PAL || TV_SYSTEM == TV_CHINA)
    // for cut off some garbage on screen bottom while channel auto scan
    if ( IsSrcTypeATV(enInputSourceType) && msAPI_Tuner_IsTuningProcessorBusy() == TRUE &&MApp_ZUI_GetActiveOSD() == E_OSD_AUTO_TUNING)
    {
        pstXC_SetWin_Info->stCapWin.height = 510;
    }
#endif
#endif
    pstXC_SetWin_Info->bHDuplicate    = FALSE;     // not set in this path

    u16InputHFreq = MApi_XC_CalculateHFreqx10(msAPI_Scaler_VD_GetHPeriod(eWindow, enInputSourceType, GET_SYNC_VIRTUAL));

    pstXC_SetWin_Info->u16InputVTotal = msAPI_Scaler_VD_GetVTotal(eWindow, enInputSourceType, GET_SYNC_VIRTUAL, u16InputHFreq);
    pstXC_SetWin_Info->bInterlace     = TRUE;
    pstXC_SetWin_Info->u16InputVFreq  = MApi_XC_CalculateVFreqx10(u16InputHFreq, pstXC_SetWin_Info->u16InputVTotal)*2;

    if(msAPI_AVD_GetForceVideoStandardFlag())
    {
        MSG(printf("Force Video Standard!\n");)
        if(pstXC_SetWin_Info->u16InputVTotal > 566)
        {
            MSG(printf("signal in fact is PAL!\n");)
            enVideoSystem = SIG_PAL;
            pstXC_SetWin_Info->stCapWin.height = 576;
        }
        else
        {
            MSG(printf("signal in fact is NTSC!\n");)
            enVideoSystem = SIG_NTSC;
            pstXC_SetWin_Info->stCapWin.height = 480;
        }
    }

    switch ( enVideoSystem )
    {
        case SIG_NTSC:
        case SIG_NTSC_443:
        case SIG_PAL_M:
            if ( (pstXC_SetWin_Info->u16InputVFreq > 610) || (pstXC_SetWin_Info->u16InputVFreq < 590) )
            {
                pstXC_SetWin_Info->u16InputVFreq = 600;
            }
            break;

        default:
        case SIG_PAL:
        case SIG_SECAM:
        case SIG_PAL_NC:
            if ( (pstXC_SetWin_Info->u16InputVFreq > 510) || (pstXC_SetWin_Info->u16InputVFreq < 490) )
            {
                pstXC_SetWin_Info->u16InputVFreq = 500;
            }
            break;
    }

    enVideoSystem = enBackupVideoSystem;

    // refine H/V capture start
    //MSG(printf("video system %d, aspect ratio %d\n", enVideoSystem, enVideoSystem));
#if(PQ_ENABLE_VD_SAMPLING)
    if(stVDSamplingInfo.eType == PQ_VD_SAMPLING_ON)
    {
        pstXC_SetWin_Info->stCapWin.x = stVDSamplingInfo.u16Hstart;
        pstXC_SetWin_Info->stCapWin.y = stVDSamplingInfo.u16Vstart;
    }
    else
#endif
    {
    pstXC_SetWin_Info->stCapWin.x = CVBS_WinInfo[enVideoSystem][u8AspectRatio].u16H_CapStart;
    pstXC_SetWin_Info->stCapWin.y = CVBS_WinInfo[enVideoSystem][u8AspectRatio].u16V_CapStart;
    }


    if (IsSrcTypeSV(enInputSourceType))
    {
        pstXC_SetWin_Info->stCapWin.x += SV_OffsetH[enVideoSystem];

        if(SV_OffsetV[enVideoSystem] & 0x80)
            pstXC_SetWin_Info->stCapWin.y -= SV_OffsetV[enVideoSystem] & 0x3F;
        else
            pstXC_SetWin_Info->stCapWin.y += SV_OffsetV[enVideoSystem] & 0x3F;
    }

    _u8H_OverScanRatio = OVERSCAN_DEFAULT_H;
    _u8V_OverScanRatio = OVERSCAN_DEFAULT_V;

    switch(eWindow)
    {
        default:
        case MAIN_WINDOW:
            enPQWin = PQ_MAIN_WINDOW;
            break;
        case SUB_WINDOW:
            enPQWin = PQ_SUB_WINDOW;
            break;
    }

    switch(msAPI_AVD_GetVideoStandard())
    {
        case E_VIDEOSTANDARD_NTSC_M:
            stPQVDInfo.enVideoStandard = E_PQ_VIDEOSTANDARD_NTSC_M;
            break;

        case E_VIDEOSTANDARD_PAL_BGHI:
            stPQVDInfo.enVideoStandard = E_PQ_VIDEOSTANDARD_PAL_BGHI;
            break;

        case E_VIDEOSTANDARD_SECAM:
            stPQVDInfo.enVideoStandard = E_PQ_VIDEOSTANDARD_SECAM;
            break;

        case E_VIDEOSTANDARD_NTSC_44:
            stPQVDInfo.enVideoStandard = E_PQ_VIDEOSTANDARD_NTSC_44;
            break;

        case E_VIDEOSTANDARD_PAL_M:
            stPQVDInfo.enVideoStandard = E_PQ_VIDEOSTANDARD_PAL_M;
            break;

        case E_VIDEOSTANDARD_PAL_N:
            stPQVDInfo.enVideoStandard = E_PQ_VIDEOSTANDARD_PAL_N;
            break;

        case E_VIDEOSTANDARD_PAL_60:
            stPQVDInfo.enVideoStandard = E_PQ_VIDEOSTANDARD_PAL_60;
            break;

        default:
            ASSERT(0);
            stPQVDInfo.enVideoStandard = E_PQ_VIDEOSTANDARD_PAL_BGHI;
            break;
    }

    switch(msAPI_AVD_GetScart1SrcType())
    {
        case E_SCART_SRC_TYPE_RGB:
            stPQVDInfo.bIsSCART_RGB = TRUE;
            break;
        case E_SCART_SRC_TYPE_CVBS:
        default:
            stPQVDInfo.bIsSCART_RGB = FALSE;
            break;
    }

    if (IsSrcTypeScart(enInputSourceType))
    {
        if( stPQVDInfo.bIsSCART_RGB == TRUE)
            pstXC_SetWin_Info->stCapWin.x -= 52;//pach for scart RGB
    }

#if (FRONTEND_IF_DEMODE_TYPE == MSTAR_VIF)
    stPQVDInfo.bIsVIFIN = TRUE;
#else
    stPQVDInfo.bIsVIFIN = FALSE;
#endif

    MDrv_PQ_Set_VDInfo(enPQWin, &stPQVDInfo);
}

/******************************************************************************/
///Setup input and output window information including aspect ratio, scaling.(MVD part)
///@param u8ModeIndex of DTV \b IN
///@param ptiming \b IN
///-pointer to VOP Timing information
/******************************************************************************/
static void _MApp_Scaler_ProgMVDWin(SCALER_WIN eWindow, INPUT_SOURCE_TYPE_t enInputSourceType,
                                    MVOP_Timing *ptiming, XC_SETWIN_INFO *pstXC_SetWin_Info)
{
    PQ_WIN enPQWin;
    MS_PQ_Dtv_Info stPQDTVInfo;
    MS_PQ_MuliMedia_Info stPQMMInfo;

    pstXC_SetWin_Info->stCapWin.x = MDrv_MVOP_GetHStart();
    pstXC_SetWin_Info->stCapWin.y = MDrv_MVOP_GetVStart();
    pstXC_SetWin_Info->stCapWin.width = ptiming->u16Width;
    pstXC_SetWin_Info->stCapWin.height = ptiming->u16Height;

    pstXC_SetWin_Info->bHDuplicate    = ptiming->bHDuplicate;
    pstXC_SetWin_Info->u16InputVTotal = ptiming->u16V_TotalCount;
    pstXC_SetWin_Info->bInterlace     = ptiming->bInterlace;

    if(pstXC_SetWin_Info->bInterlace)
    {
        pstXC_SetWin_Info->u16InputVFreq = (U16)((ptiming->u16ExpFrameRate * 2 + 50) / 100);
    }
    else
    {
        pstXC_SetWin_Info->u16InputVFreq = (U16)((ptiming->u16ExpFrameRate + 50) / 100);
    }

    _u8H_OverScanRatio = _u16OverscanDtvDefaultH;
    _u8V_OverScanRatio = _u16OverscanDtvDefaultV;


    switch(eWindow)
    {
    default:
    case MAIN_WINDOW:
        enPQWin = PQ_MAIN_WINDOW;
        break;
    case SUB_WINDOW:
        enPQWin = PQ_SUB_WINDOW;
        break;
    }

    if(IsSrcTypeDTV(enInputSourceType))
    {
    #if MHEG5_ENABLE
        if(msAPI_MHEG5_IsIFrameExist())
        {
            stPQDTVInfo.eType = E_PQ_DTV_IFRAME;
        }
        else
    #endif
        if(g_eCodecType == E_VDEC_CODEC_TYPE_H264)
            stPQDTVInfo.eType = E_PQ_DTV_H264;
        else
             stPQDTVInfo.eType = E_PQ_DTV_MPEG2;

        MDrv_PQ_Set_DTVInfo(enPQWin, &stPQDTVInfo);
    }

    if(IsSrcTypeStorage(enInputSourceType) || IsSrcTypeJpeg(enInputSourceType))
    {
    #if ENABLE_DMP
        if(E_MPLAYER_TYPE_MOVIE == MApp_MPlayer_QueryCurrentMediaType())
        {
            stPQMMInfo.eType = E_PQ_MULTIMEDIA_MOVIE;
        }
        else if(E_MPLAYER_TYPE_PHOTO == MApp_MPlayer_QueryCurrentMediaType())
        {
            stPQMMInfo.eType = E_PQ_MULTIMEDIA_PHOTO;
        }
        else
        {
            ASSERT(0);
        }
    #else
        stPQMMInfo.eType = E_PQ_MULTIMEDIA_MOVIE;
    #endif
        MDrv_PQ_Set_MultiMediaInfo(enPQWin, &stPQMMInfo);
    }
}

static void _MApp_Scaler_CropCodecSrcWin( VDEC_DispInfo *stVidStatus, XC_SETWIN_INFO *pstXC_SetWin_Info)
{
    MVOP_Handle stHdl = {E_MVOP_MODULE_MAIN};
    MVOP_DrvMirror enMirror = E_VOPMIRROR_NONE;

    MDrv_MVOP_GetCommand(&stHdl, E_MVOP_CMD_GET_MIRROR_MODE, &enMirror, sizeof(MVOP_DrvMirror));

    // this is from MVD additional information and it is MVD's crop window
    if((enMirror == E_VOPMIRROR_HVBOTH) || (enMirror == E_VOPMIRROR_HORIZONTALL))
    {
        pstXC_SetWin_Info->stCapWin.x += stVidStatus->u16CropRight;
        // [SC_PATCH_03] BEGIN
        if (stVidStatus->u16CropLeft)
        {
            pstXC_SetWin_Info->stCapWin.width -= 2;          // MM -> CTI off otherwise right-side garbage, T3 will remove
        }
        // [SC_PATCH_03] END
    }
    else
    {
        pstXC_SetWin_Info->stCapWin.x += stVidStatus->u16CropLeft;
        // [SC_PATCH_03] BEGIN
        if (stVidStatus->u16CropRight)
        {
            pstXC_SetWin_Info->stCapWin.width -= 2;          // MM -> CTI off otherwise right-side garbage, T3 will remove
        }
        // [SC_PATCH_03] END
    }

    if((enMirror == E_VOPMIRROR_HVBOTH)  || (enMirror == E_VOPMIRROR_VERTICAL))
    {
        //H264 FW does not make MVOP transport crop_bottom to Scaler
        if (E_VDPLAYER_VIDEO_H264 != g_enVDPlayerVideoType)
        {
            pstXC_SetWin_Info->stCapWin.y += stVidStatus->u16CropBottom;
        }
    }
    else
    {
        pstXC_SetWin_Info->stCapWin.y += stVidStatus->u16CropTop;
    }

    pstXC_SetWin_Info->stCapWin.width -= (stVidStatus->u16CropLeft + stVidStatus->u16CropRight);
    pstXC_SetWin_Info->stCapWin.height -= (stVidStatus->u16CropTop + stVidStatus->u16CropBottom);

    MSG(printf("codec crop left=%u, top=%u, right=%u, bottom=%u\n",
                    stVidStatus->u16CropLeft, stVidStatus->u16CropTop,
                    stVidStatus->u16CropRight, stVidStatus->u16CropBottom));
}

void MApp_Scaler_EnableHDMI_RefineHVStart(BOOLEAN bEnable)
{
    _bEnHDMI_RefineHVStart = bEnable;
}

//********************************************************************************************
// Program capture win/crop win/display window
//   parameter:
//     pDisplayWindow  - The display window before adjust it .i.e: adjust aspect ratio to it.
//     eWindow             - Display window id, i.e Main_WINDOW or SUB_WINDOW
//********************************************************************************************
static void _MApp_XC_check_crop_win( XC_SETWIN_INFO *pstXC_SetWin_Info )
{
    if (pstXC_SetWin_Info->stCropWin.width > pstXC_SetWin_Info->stCapWin.width)
    {
        ASSERT(0);
        pstXC_SetWin_Info->stCropWin.width = pstXC_SetWin_Info->stCapWin.width;
    }

    if (pstXC_SetWin_Info->stCropWin.height > pstXC_SetWin_Info->stCapWin.height)
    {
        ASSERT(0);
        pstXC_SetWin_Info->stCropWin.height = pstXC_SetWin_Info->stCapWin.height;
    }

    if (pstXC_SetWin_Info->stCropWin.x > pstXC_SetWin_Info->stCapWin.width - pstXC_SetWin_Info->stCropWin.width)
    {
        ASSERT(0);
        pstXC_SetWin_Info->stCropWin.x = pstXC_SetWin_Info->stCapWin.width - pstXC_SetWin_Info->stCropWin.width;
    }
    if (pstXC_SetWin_Info->stCropWin.y > pstXC_SetWin_Info->stCapWin.height - pstXC_SetWin_Info->stCropWin.height)
    {
        ASSERT(0);
        pstXC_SetWin_Info->stCropWin.y = pstXC_SetWin_Info->stCapWin.height - pstXC_SetWin_Info->stCropWin.height;
    }
}

#if ENABLE_FBL_ASPECT_RATIO_BY_MVOP

void MApp_Scaler_AdjustDisplayContent(MS_WINDOW_TYPE *ptWin, U16 u16X, U16 u16Y, U16 u16Width, U16 u16Height)
{
    if(NULL == ptWin)
    {
        printf("Invalid Pointer!\n");
        return;
    }

    if(u16X >= ptWin->width || u16Y >= ptWin->height
       || u16Width > ptWin->width || u16Height > ptWin->height
       || u16X + u16Width > ptWin->width || u16Y + u16Height > ptWin->height)
    {
        printf("May have invalid input parameters!\n");
    }

    if(u16X < ptWin->width)
    {
        ptWin->x = u16X;
    }

    if(u16Y < ptWin->height)
    {
        ptWin->y = u16Y;
    }

    if(u16Width < ptWin->width)
    {
        if(ptWin->x + u16Width <= ptWin->width)
        {
            ptWin->width = u16Width;
        }
        else
        {
            ptWin->width -= ptWin->x;
        }
    }

    if(u16Height < ptWin->height)
    {
        if(ptWin->y + u16Height <= ptWin->height)
        {
            ptWin->height = u16Height;
        }
        else
        {
            ptWin->height -= ptWin->y;
        }
    }
}


U16 MApp_Scaler_GetMVOPMinVDE_ForFixVtotal(U8 u8Interlace, U16 u16FrameRate, U16 u16PanelVotal, U16 u16PanelHeight)
{
    MS_BOOL b50HZOutput = (!u8Interlace && (u16FrameRate > 49500) && (u16FrameRate <= 50000))
                        || (u8Interlace && (u16FrameRate > 24500) && (u16FrameRate <= 25000));
    U16 u16MVOPMinVBlank = 0;
    U16 u16MinVDE = 0;

    if(u8Interlace)
    {
        u16MVOPMinVBlank = 35;
    }
    else
    {
        u16MVOPMinVBlank = 20;
    }

    if(b50HZOutput)
    {
        u16MinVDE = (u16MVOPMinVBlank * 5 * u16PanelHeight) / (6 * u16PanelVotal - 5 * u16PanelHeight) + 1;
    }
    else
    {
        u16MinVDE = (u16MVOPMinVBlank * u16PanelHeight) / (u16PanelVotal - u16PanelHeight) + 1;
    }

    return u16MinVDE;
}

void MApp_Scaler_SetFixVtotal(U8 u8Interlace, U16 u16FrameRate, U16 u16VDE)
{
    if(MApi_XC_IsCurrentFrameBufferLessMode())
    {
        MS_U16 TargetVtt = 0;

        MSG(printf("Panel_Vtotal=%u,Panel_Vde=%u\n", g_IPanel.VTotal(), devPanel_HEIGHT());)
        MSG(printf("u8Interlace=%u,u16FrameRate=%u,u16VDE=%u\n", u8Interlace, u16FrameRate, u16VDE);)

        if(u16VDE >= MApp_Scaler_GetMVOPMinVDE_ForFixVtotal(u8Interlace, u16FrameRate, g_IPanel.VTotal(), devPanel_HEIGHT()))
        {
            if((!u8Interlace && (u16FrameRate > 49500) && (u16FrameRate <= 50000))
                || (u8Interlace && (u16FrameRate > 24500) && (u16FrameRate <= 25000)))
            {
                TargetVtt = g_IPanel.VTotal() * 6 / 5 * u16VDE / devPanel_HEIGHT();
                MSG(printf("change vtt in aeonmm TargetVtt = %u\n", TargetVtt);)
            }
            else
            {
                TargetVtt = g_IPanel.VTotal() * u16VDE / devPanel_HEIGHT();
            }
            // Force Mvop adjust its timing when FBL
            MSG(printf("TargetVtt:%u\n",TargetVtt);)
            if(MDrv_MVOP_SetFixVtt(TargetVtt) == FALSE)
            {
                printf("-------Attention! Fix VTotal Feature is not Enabled!-------\n");
            }
        }
        else
        {
            printf("-------Attention! we can not support such display method since mvop vblank is too small!-------\n");
        }
    }
    else
    {
        printf("-------Attention! FB doesn't support this feature!-------\n");
    }
}

void MApp_Scaler_Adjust_AspectRatio_FBL(EN_ASPECT_RATIO_TYPE enVideoScreen, MS_WINDOW_TYPE *ptSrcWin)
{
    U32 u32MVOP_Black_Width = 0;
    U32 u32MVOP_Black_Height = 0;
    U16 u16Temp = 0;
    U16 x0 = 0, y0 = 0,x1 = 0, y1 = 0;
    U16 u16TempUp = 0;
    U16 u16TempDown = 0;

    if(NULL == ptSrcWin)
    {
        printf("Invalid Pointer:ptSrcWin\n");
        return;
    }

    if(!MApi_XC_IsCurrentFrameBufferLessMode())
    {
        MSG(printf("this function only support for FBL!\n");)
        return;
    }

    MSG(printf("enVideoScreen=%u\n\n", enVideoScreen);)

    g_u16HorOffset = 0;
    g_u16VerOffset = 0;
    g_bApplyMVOPCrop = FALSE;
    ptSrcWin->width = gstVidStatus.u16HorSize;
    ptSrcWin->height = gstVidStatus.u16VerSize;

    switch(enVideoScreen)
    {
    case VIDEOSCREEN_PROGRAM_16X9:
        u16Temp = (U32)devPanel_HEIGHT() * 16 / 9;
        if(u16Temp <= devPanel_WIDTH())
        {
            g_u16HorOffset = (float)(devPanel_WIDTH() - u16Temp) / ((float)u16Temp / gstVidStatus.u16HorSize) / 2;
        }
        else
        {
            u16Temp = (U32)devPanel_WIDTH() * 9 / 16;
            g_u16VerOffset = (float)(devPanel_HEIGHT() - u16Temp) / ((float)u16Temp / gstVidStatus.u16VerSize) / 2;
        }
        break;
    case VIDEOSCREEN_PROGRAM_4X3:
#if 0
      #if 0
        MSG(printf("should not enter VIDEOSCREEN_PROGRAM_4X3!\n");)
        u16Temp = (U32)devPanel_HEIGHT() * 4 / 3;
        if(u16Temp <= devPanel_WIDTH())
        {
            g_u16HorOffset = (float)(devPanel_WIDTH() - u16Temp) / ((float)u16Temp / gstVidStatus.u16HorSize) / 2;
        }
        else
        {
            u16Temp = (U32)devPanel_WIDTH() * 3 / 4;
            g_u16VerOffset = (float)(devPanel_HEIGHT() - u16Temp) / ((float)u16Temp / gstVidStatus.u16VerSize) / 2;
        }
      #else
        MApp_VDPlayer_GetMVOPBlackSize((U32)gstVidStatus.u16HorSize, (U32)gstVidStatus.u16VerSize, &u32MVOP_Black_Width, &u32MVOP_Black_Height);
        MSG(printf("w=%u, h=%u,  black_W=%lu, black_H=%lu \n",gstVidStatus.u16HorSize, gstVidStatus.u16VerSize, u32MVOP_Black_Width, u32MVOP_Black_Height);)
        g_u16HorOffset = u32MVOP_Black_Width;
        g_u16VerOffset = u32MVOP_Black_Height;
      #endif
#endif
        break;

    case VIDEOSCREEN_ZOOM1:
        MApp_Scaler_ResetZoomFactor(EN_AspectRatio_Zoom1);
        ptSrcWin->x = 0;
        ptSrcWin->y = 0;
        ptSrcWin->width = gstVidStatus.u16HorSize - gstVidStatus.u16CropLeft - gstVidStatus.u16CropRight;
        ptSrcWin->height = gstVidStatus.u16VerSize - gstVidStatus.u16CropTop - gstVidStatus.u16CropBottom;
        x0 = (U16)((U32)ptSrcWin->width * _s16ZoomLeft / ZOOM_DENUMERATOR);
        y0 = (U16)((U32)ptSrcWin->height * _s16ZoomUp / ZOOM_DENUMERATOR);
        x1 = (U16)((U32)ptSrcWin->width * _s16ZoomRight / ZOOM_DENUMERATOR);
        y1 = (U16)((U32)ptSrcWin->height * _s16ZoomDown / ZOOM_DENUMERATOR);
        MApp_Scaler_AdjustDisplayContent(ptSrcWin, x0, y0, ptSrcWin->width - (x0 + x1), ptSrcWin->height - (y0 + y1));
        gstVidStatus.u16HorSize = ptSrcWin->width;
        gstVidStatus.u16VerSize = ptSrcWin->height;
        g_u16HorOffset = 0;
        g_u16VerOffset = 0;
        g_bApplyMVOPCrop = TRUE;
        break;
    case VIDEOSCREEN_ZOOM2:
        MApp_Scaler_ResetZoomFactor(EN_AspectRatio_Zoom2);
        ptSrcWin->x = 0;
        ptSrcWin->y = 0;
        ptSrcWin->width = gstVidStatus.u16HorSize - gstVidStatus.u16CropLeft - gstVidStatus.u16CropRight;
        ptSrcWin->height = gstVidStatus.u16VerSize - gstVidStatus.u16CropTop - gstVidStatus.u16CropBottom;
        x0 = (U16)((U32)ptSrcWin->width * _s16ZoomLeft / ZOOM_DENUMERATOR);
        y0 = (U16)((U32)ptSrcWin->height * _s16ZoomUp / ZOOM_DENUMERATOR);
        x1 = (U16)((U32)ptSrcWin->width * _s16ZoomRight / ZOOM_DENUMERATOR);
        y1 = (U16)((U32)ptSrcWin->height * _s16ZoomDown / ZOOM_DENUMERATOR);
        MApp_Scaler_AdjustDisplayContent(ptSrcWin, x0, y0, ptSrcWin->width - (x0 + x1), ptSrcWin->height - (y0 + y1));
        gstVidStatus.u16HorSize = ptSrcWin->width;
        gstVidStatus.u16VerSize = ptSrcWin->height;
        g_u16HorOffset = 0;
        g_u16VerOffset = 0;
        g_bApplyMVOPCrop = TRUE;
        break;
    case VIDEOSCREEN_PROGRAM: // Set Capture/Crop/Display window by function directly
        ptSrcWin->x = 0;
        ptSrcWin->y = 0;
        ptSrcWin->width = gstVidStatus.u16HorSize - gstVidStatus.u16CropLeft - gstVidStatus.u16CropRight;
        ptSrcWin->height = gstVidStatus.u16VerSize - gstVidStatus.u16CropTop - gstVidStatus.u16CropBottom;
        x0 = (U16)((U32)ptSrcWin->width * _s16ZoomLeft / ZOOM_DENUMERATOR);
        y0 = (U16)((U32)ptSrcWin->height * _s16ZoomUp / ZOOM_DENUMERATOR);
        x1 = (U16)((U32)ptSrcWin->width * _s16ZoomRight / ZOOM_DENUMERATOR);
        y1 = (U16)((U32)ptSrcWin->height * _s16ZoomDown / ZOOM_DENUMERATOR);
        MApp_Scaler_AdjustDisplayContent(ptSrcWin, x0, y0, ptSrcWin->width - (x0 + x1), ptSrcWin->height - (y0 + y1));
        gstVidStatus.u16HorSize = ptSrcWin->width;
        gstVidStatus.u16VerSize = ptSrcWin->height;
        g_u16HorOffset = 0;
        g_u16VerOffset = 0;
        g_bApplyMVOPCrop = TRUE;
        break;
    case VIDEOSCREEN_CINEMA:
        ptSrcWin->x = 0;
        ptSrcWin->y = 0;
        ptSrcWin->width = gstVidStatus.u16HorSize - gstVidStatus.u16CropLeft - gstVidStatus.u16CropRight;
        ptSrcWin->height = gstVidStatus.u16VerSize - gstVidStatus.u16CropTop - gstVidStatus.u16CropBottom;
        MApp_Scaler_AdjustDisplayContent(ptSrcWin, ((U32)ptSrcWin->width * ARC_CINEMA_OVS_H) / 1000, ((U32)ptSrcWin->height * ARC_CINEMA_OVS_V) / 1000,
                                         ptSrcWin->width - 2 * ((U32)ptSrcWin->width * ARC_CINEMA_OVS_H) / 1000,
                                         ptSrcWin->height - 2 * ((U32)ptSrcWin->height * ARC_CINEMA_OVS_V) / 1000);
        gstVidStatus.u16HorSize = ptSrcWin->width;
        gstVidStatus.u16VerSize = ptSrcWin->height;
        g_u16HorOffset = 0;
        g_u16VerOffset = 0;
        g_bApplyMVOPCrop = TRUE;
        break;
    case VIDEOSCREEN_14by9:
        ptSrcWin->x = 0;
        ptSrcWin->y = 0;
        ptSrcWin->width = gstVidStatus.u16HorSize - gstVidStatus.u16CropLeft - gstVidStatus.u16CropRight;
        ptSrcWin->height = gstVidStatus.u16VerSize - gstVidStatus.u16CropTop - gstVidStatus.u16CropBottom;
        u16TempUp = ((U32)ptSrcWin->height * ARC_14X19_OVS_UP + 500) / 1000;
        u16TempDown = ((U32)ptSrcWin->height * ARC_14X19_OVS_DOWN + 500) / 1000;
        MApp_Scaler_AdjustDisplayContent(ptSrcWin, 0, u16TempUp, ptSrcWin->width, ptSrcWin->height - (u16TempUp + u16TempDown));

        gstVidStatus.u16HorSize = ptSrcWin->width;
        gstVidStatus.u16VerSize = ptSrcWin->height;

        u16Temp = (U32)devPanel_HEIGHT() * 14 / 9;
        if (u16Temp <= devPanel_WIDTH()) // H:V >= 14:9
        {
            g_u16HorOffset = (float)(devPanel_WIDTH() - u16Temp) / ((float)u16Temp / gstVidStatus.u16HorSize) / 2;
        }
        else // H:V <= 4:3
        {
            u16Temp = (U32)devPanel_WIDTH() * 9 / 14;
            g_u16VerOffset = (float)(devPanel_HEIGHT() - u16Temp) / ((float)u16Temp / gstVidStatus.u16VerSize) / 2;
        }
        g_bApplyMVOPCrop = TRUE;
        break;
    case VIDEOSCREEN_16by9_SUBTITLE:
        ptSrcWin->x = 0;
        ptSrcWin->y = 0;
        ptSrcWin->width = gstVidStatus.u16HorSize - gstVidStatus.u16CropLeft - gstVidStatus.u16CropRight;
        ptSrcWin->height = gstVidStatus.u16VerSize - gstVidStatus.u16CropTop - gstVidStatus.u16CropBottom;
        MApp_Scaler_AdjustDisplayContent(ptSrcWin, 0, ptSrcWin->height * 1 / 8, ptSrcWin->width, ptSrcWin->height * 6 / 8);
        gstVidStatus.u16HorSize = ptSrcWin->width;
        gstVidStatus.u16VerSize = ptSrcWin->height;

        u16Temp = (U32)devPanel_HEIGHT() * 32 / 21; // 640x420 => 1097x720 Display
        if (u16Temp <= devPanel_WIDTH()) // H:V >= 32:21
        {
            g_u16HorOffset = (float)(devPanel_WIDTH() - u16Temp) / ((float)u16Temp / gstVidStatus.u16HorSize) / 2;
        }
        else // H:V <= 32:21
        {
            u16Temp = (U32)devPanel_WIDTH() * 21 / 32;
            g_u16VerOffset = (float)(devPanel_HEIGHT() - u16Temp) / ((float)u16Temp / gstVidStatus.u16VerSize) / 2;
        }
        g_bApplyMVOPCrop = TRUE;
        break;
    case VIDEOSCREEN_PANORAMA:
        _bEnNonLinearScaling[MAIN_WINDOW] = TRUE;
        break;
    case VIDEOSCREEN_NORMAL:
#if 0
      #if 0
        if ((g_IPanel.AspectRatio()==E_PNL_ASPECT_RATIO_WIDE))
        {
            MSG(printf("should not enter into VIDEOSCREEN_NORMAL\n");)
            u16Temp = (U32)devPanel_HEIGHT() * 4 / 3;
            if(u16Temp <= devPanel_WIDTH())
            {
                g_u16HorOffset = (float)(devPanel_WIDTH() - u16Temp) / ((float)u16Temp / gstVidStatus.u16HorSize) / 2;
            }
            else
            {
                u16Temp = (U32)devPanel_WIDTH() * 3 / 4;
                g_u16VerOffset = (float)(devPanel_HEIGHT() - u16Temp) / ((float)u16Temp / gstVidStatus.u16VerSize) / 2;
            }
        }
        else
        {
            u16Temp = (U32)devPanel_HEIGHT() * 16 / 9;
            if(u16Temp <= devPanel_WIDTH())
            {
                g_u16HorOffset = (float)(devPanel_WIDTH() - u16Temp) / ((float)u16Temp / gstVidStatus.u16HorSize) / 2;
            }
            else
            {
                u16Temp = (U32)devPanel_WIDTH() * 9 / 16;
                g_u16VerOffset = (float)(devPanel_HEIGHT() - u16Temp) / ((float)u16Temp / gstVidStatus.u16VerSize) / 2;
            }
        }
      #else
        MApp_VDPlayer_GetMVOPBlackSize((U32)gstVidStatus.u16HorSize, (U32)gstVidStatus.u16VerSize, &u32MVOP_Black_Width, &u32MVOP_Black_Height);
        MSG(printf("w=%u, h=%u,  black_W=%lu, black_H=%lu \n",gstVidStatus.u16HorSize, gstVidStatus.u16VerSize, u32MVOP_Black_Width, u32MVOP_Black_Height);)
        g_u16HorOffset = u32MVOP_Black_Width;
        g_u16VerOffset = u32MVOP_Black_Height;
      #endif
#endif
        break;

    case VIDEOSCREEN_LETTERBOX:
        u16Temp = (U32)devPanel_WIDTH() * 9 / 16;
        g_u16VerOffset = (float)(devPanel_HEIGHT() - u16Temp) / ((float)u16Temp / gstVidStatus.u16VerSize) / 2;
        break;
    case VIDEOSCREEN_WSS_16by9:
        ptSrcWin->x = 0;
        ptSrcWin->y = 0;
        ptSrcWin->width = gstVidStatus.u16HorSize - gstVidStatus.u16CropLeft - gstVidStatus.u16CropRight;
        ptSrcWin->height = gstVidStatus.u16VerSize - gstVidStatus.u16CropTop - gstVidStatus.u16CropBottom;
        MApp_Scaler_AdjustDisplayContent(ptSrcWin, 0, ptSrcWin->height * 1 / 8, ptSrcWin->width, ptSrcWin->height * 6 / 8);
        gstVidStatus.u16HorSize = ptSrcWin->width;
        gstVidStatus.u16VerSize = ptSrcWin->height;
        g_bApplyMVOPCrop = TRUE;
        break;

#if defined(ENABLE_MEDIAPLAYER) || (DISPLAY_LOGO)
    case VIDEOSCREEN_ORIGIN:
        if((gstVidStatus.u16HorSize <= devPanel_WIDTH())
           && (gstVidStatus.u16VerSize <= devPanel_HEIGHT()))
        {
            MSG(printf("Display Original!\n");)
            g_u16HorOffset = (devPanel_WIDTH() - gstVidStatus.u16HorSize) / 2;
            g_u16VerOffset = (devPanel_HEIGHT() - gstVidStatus.u16VerSize) / 2;
        }
        else
        {
            //for FBL set MVOP for maintain video ratio
            MApp_VDPlayer_GetMVOPBlackSize((U32)gstVidStatus.u16HorSize, (U32)gstVidStatus.u16VerSize, &u32MVOP_Black_Width, &u32MVOP_Black_Height);
            MSG(printf("\n w=%u, h=%u,  black_W=%lu, black_H=%lu \n",gstVidStatus.u16HorSize, gstVidStatus.u16VerSize, u32MVOP_Black_Width, u32MVOP_Black_Height);)
            g_u16HorOffset = u32MVOP_Black_Width;
            g_u16VerOffset = u32MVOP_Black_Height;
        }
        break;
#endif

    case VIDEOSCREEN_FULL:
    default:
        MApp_VDPlayer_GetMVOPBlackSize((U32)gstVidStatus.u16HorSize, (U32)gstVidStatus.u16VerSize, &u32MVOP_Black_Width, &u32MVOP_Black_Height);
        MSG(printf("w=%u, h=%u,  black_W=%lu, black_H=%lu \n",gstVidStatus.u16HorSize, gstVidStatus.u16VerSize, u32MVOP_Black_Width, u32MVOP_Black_Height);)
        g_u16HorOffset = u32MVOP_Black_Width;
        g_u16VerOffset = u32MVOP_Black_Height;
        break;
    }
    ptSrcWin->width = (ptSrcWin->width >> 3) << 3; // 8 bytes align
    ptSrcWin->height = (ptSrcWin->height>> 1) << 1; // even
    gstVidStatus.u16HorSize = ptSrcWin->width;
    gstVidStatus.u16VerSize = ptSrcWin->height;
}

void MApp_Scaler_SetFBLTimingForAspectRatio(EN_ASPECT_RATIO_TYPE enVideoScreen)
{
    MS_WINDOW_TYPE tSrcWin;
    U16 u16VDE = 0;
    MVOP_VidStat stMvopVidSt;

    if(!MApi_XC_IsCurrentFrameBufferLessMode())
    {
        MSG(printf("this function only support for FBL!\n");)
        return;
    }

    if(enMVOPVideoType == MVOP_MJPEG)
    {
        //no FBL case
        printf("No FBL for MJPEG yet!\n");
        return;
    }

    msAPI_Scaler_SetBlueScreen(ENABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
    memset(&tSrcWin, 0, sizeof(tSrcWin));
    memset(&stMvopVidSt, 0, sizeof(MVOP_VidStat));

    if(IsSrcTypeStorage(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)))
    {
        // load video information
        gstVidStatus.u32FrameRate = _MApp_VDPlayer_GetShareMemData(E_SHAREMEM_FRAME_RATE);
        gstVidStatus.u8Interlace = _MApp_VDPlayer_GetShareMemData(E_SHAREMEM_INTERLACE);
        gstVidStatus.u16HorSize =  _MApp_VDPlayer_GetShareMemData(E_SHAREMEM_WIDTH);
        gstVidStatus.u16VerSize = _MApp_VDPlayer_GetShareMemData(E_SHAREMEM_HEIGHT);
        gstVidStatus.u16CropRight = _MApp_VDPlayer_GetShareMemData(E_SHAREMEM_VIDEO_CROP_RIGHT);
        gstVidStatus.u16CropLeft = _MApp_VDPlayer_GetShareMemData(E_SHAREMEM_VIDEO_CROP_LEFT);
        gstVidStatus.u16CropBottom = _MApp_VDPlayer_GetShareMemData(E_SHAREMEM_VIDEO_CROP_BOTTOM);
        gstVidStatus.u16CropTop = _MApp_VDPlayer_GetShareMemData(E_SHAREMEM_VIDEO_CROP_TOP);
    }

    MSG(printf("width=%u, height=%u, framerate=%u, Interlace=%u\n", gstVidStatus.u16HorSize, gstVidStatus.u16VerSize, gstVidStatus.u32FrameRate, gstVidStatus.u8Interlace);)
    MSG(printf("cropleft=%u, cropright=%u, croptop=%u, cropbottom=%u\n", gstVidStatus.u16CropLeft, gstVidStatus.u16CropRight, gstVidStatus.u16CropTop, gstVidStatus.u16CropBottom);)

    MApp_Scaler_Adjust_AspectRatio_FBL(enVideoScreen, &tSrcWin);

    if((gstVidStatus.u32FrameRate > 24500) && (gstVidStatus.u32FrameRate <= 25000))
    {
        //gstVidStatus.u32FrameRate = 25000;
    }
    else if((gstVidStatus.u32FrameRate > 49500) && (gstVidStatus.u32FrameRate <= 50000))
    {
        gstVidStatus.u32FrameRate = gstVidStatus.u32FrameRate / 2; //25
    }
    else if((gstVidStatus.u32FrameRate > 23500) && (gstVidStatus.u32FrameRate <= 24000) )
    {
        gstVidStatus.u32FrameRate = (U32)gstVidStatus.u32FrameRate * 5 / 4; //30
    }
    else if((gstVidStatus.u32FrameRate > 29500) && (gstVidStatus.u32FrameRate <= 30000))
    {
        //~30
    }
    else
    {
        gstVidStatus.u32FrameRate = 30000;
    }

    if (gstVidStatus.u8Interlace == FALSE)   // progressive
    {
        gstVidStatus.u32FrameRate *= 2;
    }

    MDrv_MVOP_Init();
    stMvopVidSt.u16HorSize   = gstVidStatus.u16HorSize;
    stMvopVidSt.u16VerSize   = gstVidStatus.u16VerSize;
    stMvopVidSt.u16FrameRate = gstVidStatus.u32FrameRate;
    stMvopVidSt.u8AspectRate = gstVidStatus.u8AspectRate;
    stMvopVidSt.u8Interlace  = gstVidStatus.u8Interlace;
    stMvopVidSt.u16HorOffset = g_u16HorOffset;
    stMvopVidSt.u16VerOffset = g_u16VerOffset;
    u16VDE = gstVidStatus.u16VerSize - (gstVidStatus.u16CropTop + gstVidStatus.u16CropBottom) + 2 * g_u16VerOffset;
    MApp_Scaler_SetFixVtotal(stMvopVidSt.u8Interlace, stMvopVidSt.u16FrameRate, u16VDE);
    MDrv_MVOP_SetOutputCfg(&stMvopVidSt, FALSE);

    MDrv_MVOP_Enable(FALSE);

    switch (enMVOPVideoType)
    {
        case MVOP_MPEG4:
        case MVOP_MPG:
            if(g_bApplyMVOPCrop)
            {
                MVOP_InputCfg dc_param;
                memset(&dc_param, 0, sizeof(MVOP_InputCfg));
                dc_param.u16CropWidth = tSrcWin.width;
                dc_param.u16CropHeight = tSrcWin.height;
                dc_param.u16CropX = tSrcWin.x;
                dc_param.u16CropY = tSrcWin.y;
                dc_param.enVideoType = MVOP_MPG;
              #if (VIDEO_FIRMWARE_CODE >= VIDEO_FIRMWARE_CODE_HD)
                dc_param.u16StripSize = 1920;
              #else
                dc_param.u16StripSize = 720;
              #endif
                MDrv_MVOP_SetInputCfg(MVOP_INPUT_CLIP, &dc_param);
            }
            else
            {
                MDrv_MVOP_SetInputCfg(MVOP_INPUT_MVD, NULL);
            }
            break;

        case MVOP_H264:
            if(g_bApplyMVOPCrop)
            {
                MVOP_InputCfg dc_param;
                memset(&dc_param, 0, sizeof(MVOP_InputCfg));
                dc_param.u16CropWidth = tSrcWin.width;
                dc_param.u16CropHeight = tSrcWin.height;
                dc_param.u16CropX = tSrcWin.x;
                dc_param.u16CropY = tSrcWin.y;
                dc_param.enVideoType = MVOP_H264;
                if(IsSrcTypeStorage(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)))
                {
                    dc_param.u16StripSize = _MApp_VDPlayer_GetShareMemData(E_SHAREMEM_WIDTH);
                }
                else if(IsSrcTypeDTV(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)))
                {
                    dc_param.u16StripSize = g_u16StripSize;
                }
                else
                {
                    printf("this input source type is not supported\n");
                }
                MDrv_MVOP_SetInputCfg(MVOP_INPUT_CLIP, &dc_param);
            }
            else
            {
                MDrv_MVOP_SetInputCfg(MVOP_INPUT_H264, NULL);
            }
            break;

        case MVOP_RM:
            if(g_bApplyMVOPCrop)
            {
                MVOP_InputCfg dc_param;
                memset(&dc_param, 0, sizeof(MVOP_InputCfg));
                dc_param.u16CropWidth = tSrcWin.width;
                dc_param.u16CropHeight = tSrcWin.height;
                dc_param.u16CropX = tSrcWin.x;
                dc_param.u16CropY = tSrcWin.y;
                dc_param.enVideoType = MVOP_RM;
                if(IsSrcTypeStorage(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)))
                {
                    dc_param.u16StripSize = _MApp_VDPlayer_GetShareMemData(E_SHAREMEM_WIDTH);
                }
                else if(IsSrcTypeDTV(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)))
                {
                    dc_param.u16StripSize = g_u16StripSize;
                }
                else
                {
                    printf("this input source type is not supported\n");
                }
                MDrv_MVOP_SetInputCfg(MVOP_INPUT_CLIP, &dc_param);
            }
            else
            {
                MDrv_MVOP_SetInputCfg(MVOP_INPUT_RVD, NULL);
            }
            break;
        default:
            break;
    }

    MApp_Scaler_EnableOverScan(FALSE);
    MDrv_MVOP_Enable(TRUE);
    MApp_Scaler_SetWindow(NULL, NULL, NULL, stSystemInfo[MAIN_WINDOW].enAspectRatio, SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW), MAIN_WINDOW);

    MApp_Picture_Setting_SetColor(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW), MAIN_WINDOW);
    MApp_Scaler_SetTiming(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW), MAIN_WINDOW);
    msAPI_Scaler_SetBlueScreen(DISABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
}

#endif // #if ENABLE_FBL_ASPECT_RATIO_BY_MVOP

static PQ_INPUT_SOURCE_TYPE SystemInputSrcToPQInputSrc(INPUT_SOURCE_TYPE_t enInputSourceType)
{
    PQ_INPUT_SOURCE_TYPE enPQSourceType = PQ_INPUT_SOURCE_HDMI;

    if(IsSrcTypeVga(enInputSourceType))
    {
        enPQSourceType = PQ_INPUT_SOURCE_VGA; // VGA
    }
    else if(IsSrcTypeATV(enInputSourceType))
    {
        enPQSourceType = PQ_INPUT_SOURCE_TV; // TV
    }
    else if(IsSrcTypeDTV(enInputSourceType))
    {
        enPQSourceType = PQ_INPUT_SOURCE_DTV; //DTV
    }
    else if(IsSrcTypeAV(enInputSourceType))
    {
        enPQSourceType = PQ_INPUT_SOURCE_CVBS; // AV
    }
    else if(IsSrcTypeScart(enInputSourceType))
    {
        enPQSourceType = PQ_INPUT_SOURCE_SCART; // SCART
    }
    else if(IsSrcTypeSV(enInputSourceType))
    {
        enPQSourceType = PQ_INPUT_SOURCE_SVIDEO; // SV
    }
    else if(IsSrcTypeHDMI(enInputSourceType))
    {
        enPQSourceType = PQ_INPUT_SOURCE_HDMI; // HDMI
    }
    else if(IsSrcTypeYPbPr(enInputSourceType))
    {
        enPQSourceType = PQ_INPUT_SOURCE_YPBPR; // COMP
    }
    else if(IsSrcTypeJpeg(enInputSourceType))
    {
        enPQSourceType = PQ_INPUT_SOURCE_JPEG; // JPEG
    }
    else if(IsSrcTypeStorage(enInputSourceType))
    {
        enPQSourceType = PQ_INPUT_SOURCE_STORAGE; // Storage
    }
    else if(enInputSourceType == INPUT_SOURCE_KTV)
    {
        enPQSourceType = PQ_INPUT_SOURCE_KTV; // KTV
    }
    else
    {
        MS_ASSERT(0);
    }

    return enPQSourceType;
}

//********************************************************************************************
// Program capture win/crop win/display window
//   parameter:
//     ptSrcWin  - pointer to src window (not including timing hstart/vstart)
//                 NULL to use default value
//     ptCropWin - pointer to crop window
//                 NULL to use default value
//     ptDstWin  - pointer to dst window (not including timing hstart/vstart)
//                 NULL to use default value
//     enVideoScreen - aspect ratio code
//********************************************************************************************
void MApp_Scaler_SetWindow(MS_WINDOW_TYPE *ptSrcWin,                                // start from (0,0)
                                            MS_WINDOW_TYPE *ptCropWin,              // start from (0,0)
                                            MS_WINDOW_TYPE *ptDstWin,               // start from (0,0)
                                            EN_ASPECT_RATIO_TYPE enVideoScreen,
                                            INPUT_SOURCE_TYPE_t enInputSourceType,
                                            SCALER_WIN eWindow)
{
    U16 u16AlignX=0, u16AlignY=0;
    SRC_RATIO_INFO tSrcRatioInfo;
    U8 u8AspectRatio;
    MVOP_Timing stMVOPTiming;
    PQ_WIN  enPQWin;
    XC_DLC_CAPTURE_Range stDLC_CapRange;
    E_XC_3D_INPUT_MODE e3DInput = E_XC_3D_INPUT_MODE_NONE;
    E_XC_3D_OUTPUT_MODE e3DOutput = E_XC_3D_OUTPUT_MODE_NONE;
    BOOL bIsFBLMode = MApi_XC_IsCurrentFrameBufferLessMode();
    BOOL bIsRFBLMode = FALSE;

    CAL_TIME_FUNC_START();


    MSG(printf("MApp_Scaler_SetWindow(win=%u)\n", (U16)eWindow));
    MSG(printf(" enInputSourceType=%u\n", (U16)enInputSourceType));
    MSG(printf(" enAspectRatio=%u\n", (U16)enVideoScreen));

#if ENABLE_3D_PROCESS
    e3DInput = MApi_XC_Get_3D_Input_Mode(eWindow);
    e3DOutput = MApi_XC_Get_3D_Output_Mode();
#else
    e3DOutput = e3DOutput; //Dumy code to prevent compile warning
    e3DInput = e3DInput;
#endif
    memset(&stXC_SetWin_Info[eWindow], 0, sizeof(XC_SETWIN_INFO));
    memset(&stDLC_CapRange, 0, sizeof(XC_DLC_CAPTURE_Range));

    stXC_SetWin_Info[eWindow].enInputSourceType = enInputSourceType;

    switch(ST_VIDEO.eAspectRatio)
    {
        case EN_AspectRatio_JustScan:
        #if VGA_HDMI_YUV_POINT_TO_POINT
        case EN_AspectRatio_point_to_point:
        #endif
            MApp_Scaler_EnableOverScan(DISABLE);
            break;

        case EN_AspectRatio_Zoom1:
        case EN_AspectRatio_Zoom2:
            MApp_Scaler_ResetZoomFactor(ST_VIDEO.eAspectRatio);
            MApp_Scaler_EnableOverScan(ENABLE);
            break;

        default:
            MApp_Scaler_EnableOverScan(ENABLE);
            break;
    }

    #if ENABLE_3D_PROCESS /*Creass.liu at 2012-08-02*/
    if(IsHDMIInUse())
    {
        if(g_HdmiPollingStatus.bIsHDMIMode == FALSE)
        {
            if(ST_VGA_3D_TYPE != EN_3D_BYPASS)
            {
                MApp_Scaler_EnableOverScan(DISABLE);
            }
        }
        else
        {
            if(stGenSetting.g_SysSetting.en3DDetectMode != EN_3D_DETECT_AUTO)
            {
                if(ST_3D_TYPE != EN_3D_BYPASS)
                {
                    MApp_Scaler_EnableOverScan(DISABLE);
                }
            }
            else
            {
                if(MApi_XC_Get_3D_Output_Mode() != E_XC_3D_OUTPUT_MODE_NONE )
                {
                    MApp_Scaler_EnableOverScan(DISABLE);
                }
            }
        }
    }
#if(ENABLE_DMP)
    else if( IsSrcTypeStorage(enInputSourceType) && (ST_3D_TYPE != EN_3D_BYPASS)) // MM and not preview
    {
        if( MApp_MPlayer_IsMoviePlaying() )
        {
            MApp_Scaler_EnableOverScan(DISABLE);
        }
    }
#endif
    #endif

#if MHEG5_ENABLE
    if(IsDTVInUse() && msAPI_MHEG5_IsRunning()
#if (ENABLE_DTV_EPG)
       && (STATE_TOP_EPG != MApp_TopStateMachine_GetTopState())
#endif
       )
    {
        MDrv_MVOP_GetOutputTiming(&stMVOPTiming);

        _MApp_Scaler_ProgMVDWin(eWindow, enInputSourceType, &stMVOPTiming, &stXC_SetWin_Info[eWindow]);

        _MApp_Scaler_CropCodecSrcWin(&gstVidStatus, &stXC_SetWin_Info[eWindow]);

        // In MHEG's concept, the capture win is start from (0,0), so convert to (0,0) first before MHEG calculated it's own parameters
        stXC_SetWin_Info[eWindow].stCapWin.x = 0;
        stXC_SetWin_Info[eWindow].stCapWin.y = 0;

        if(msAPI_MHEG5_VID_SetWindowInfo(&stXC_SetWin_Info[MAIN_WINDOW],eWindow))
        {
            // ok
        }
        else
        {
            printf("MApp_Scaler_SetWindow  msAPI_MHEG5_VID_SetWindowInfo == FALSE\n");
            return;
        }

        // XC capture win start from "capture start", not from 0
        stXC_SetWin_Info[eWindow].stCapWin.x += MDrv_MVOP_GetHStart();
        stXC_SetWin_Info[eWindow].stCapWin.y += MDrv_MVOP_GetVStart();
    #if VERIFY_SCALER_FPGA //non-scaling function
        stXC_SetWin_Info[eWindow].stDispWin.height = stXC_SetWin_Info[eWindow].stCropWin.height = stXC_SetWin_Info[eWindow].stCapWin.height;
        stXC_SetWin_Info[eWindow].stDispWin.width= stXC_SetWin_Info[eWindow].stCropWin.width = stXC_SetWin_Info[eWindow].stCapWin.width;
        stXC_SetWin_Info[eWindow].stDispWin.x = stXC_SetWin_Info[eWindow].stDispWin.y = 0;
    #endif
    }
    else
#endif // #if MHEG5_ENABLE
    {
        u8AspectRatio = _MApp_Scaler_Aspect_Ratio_Remapping(enVideoScreen);

        if( IsSrcTypeAnalog(enInputSourceType) || IsSrcTypeHDMI(enInputSourceType))
        {
            _MApp_Scaler_ProgAnalogWin(enInputSourceType, &g_PcadcModeSetting[eWindow], u8AspectRatio,
                                        MApi_XC_PCMonitor_GetSyncStatus(eWindow), &stXC_SetWin_Info[eWindow], eWindow);

            u16AlignX = ANALOG_CROP_ALIGN_X;
            u16AlignY = ANALOG_CROP_ALIGN_Y;
        }
        else if( IsSrcTypeATV(enInputSourceType) )
        {
            _MApp_Scaler_ProgDigitalWin( enInputSourceType, mvideo_vd_get_videosystem(), u8AspectRatio,
                                         &stXC_SetWin_Info[eWindow], eWindow );

            u16AlignX = DIGITAL_CROP_ALIGN_X;
            u16AlignY = DIGITAL_CROP_ALIGN_Y;
        }
        else if( IsSrcTypeDigitalVD(enInputSourceType) )
        {
            _MApp_Scaler_ProgDigitalWin( enInputSourceType, mvideo_vd_get_videosystem(), u8AspectRatio,
                                         &stXC_SetWin_Info[eWindow], eWindow );

            u16AlignX = DIGITAL_CROP_ALIGN_X;
            u16AlignY = DIGITAL_CROP_ALIGN_Y;
        }
        else if( IsSrcTypeDTV(enInputSourceType) )
        {
            MDrv_MVOP_GetOutputTiming(&stMVOPTiming);
            _MApp_Scaler_ProgMVDWin(eWindow, enInputSourceType, &stMVOPTiming, &stXC_SetWin_Info[eWindow]);
            _MApp_Scaler_CropCodecSrcWin(&gstVidStatus, &stXC_SetWin_Info[eWindow]);

            u16AlignX = DTV_CROP_ALIGN_X;
            u16AlignY = DTV_CROP_ALIGN_Y;
        }
    #if ((ENABLE_DMP) || (DISPLAY_LOGO))
        else
        {
            MDrv_MVOP_GetOutputTiming(&stMVOPTiming);

            _MApp_Scaler_ProgMVDWin(eWindow, enInputSourceType, &stMVOPTiming, &stXC_SetWin_Info[eWindow]);

            _MApp_Scaler_CropCodecSrcWin(&gstVidStatus, &stXC_SetWin_Info[eWindow]);

            u16AlignX = MEDIA_CROP_ALIGN_X;
            u16AlignY = MEDIA_CROP_ALIGN_Y;
        }
    #endif // #if ((ENABLE_DMP) || (DISPLAY_LOGO))



        MSG(printf(" %s timing \n", (stXC_SetWin_Info[eWindow].bInterlace)?("Interlace"):("Progress")));

        //printf("Start(%d, %d) Size(%d, %d)\n", g_SrcInfo.u16H_CapStart,g_SrcInfo.u16V_CapStart,
        //g_SrcInfo.u16H_CapSize,g_SrcInfo.u16V_CapSize);


        if (ptSrcWin)
        {
            // XC concept: capture window never start from (0,0) because it's base is input signal
            memcpy(&stXC_SetWin_Info[eWindow].stCapWin, ptSrcWin, sizeof(MS_WINDOW_TYPE));
            ASSERT(stXC_SetWin_Info[eWindow].stCapWin.x != 0);
            ASSERT(stXC_SetWin_Info[eWindow].stCapWin.y != 0);
        }
        MSG(printf("src0: x,y,w,h=%u,%u,%u,%u\n", stXC_SetWin_Info[eWindow].stCapWin.x, stXC_SetWin_Info[eWindow].stCapWin.y, stXC_SetWin_Info[eWindow].stCapWin.width, stXC_SetWin_Info[eWindow].stCapWin.height));

        // PIP/POP: In PIP/POP mode, we need set window size before signal stable.
        // Width and height of capture window set to zero will cause pre-scale crash.
        // Therefore we correct invalid value on there.
        if( (stXC_SetWin_Info[eWindow].stCapWin.width==0) || (stXC_SetWin_Info[eWindow].stCapWin.height==0) )
        {
            stXC_SetWin_Info[eWindow].stCapWin.width = 10;
            stXC_SetWin_Info[eWindow].stCapWin.height = 10;
        }

        if (ptDstWin)
        {
            //printf(" Has DstWin!\n");
            // XC concept: disp window must start from (0,0) because it's base is display and which is aligned to UI, all start from (0,0)
            memcpy(&stXC_SetWin_Info[eWindow].stDispWin, ptDstWin, sizeof(MS_WINDOW_TYPE));
        }
        else
        {
            //printf(" No DstWin => Panel~\n");
            stXC_SetWin_Info[eWindow].stDispWin.x = 0;
            stXC_SetWin_Info[eWindow].stDispWin.y = 0;
            stXC_SetWin_Info[eWindow].stDispWin.width = g_IPanel.Width();
            stXC_SetWin_Info[eWindow].stDispWin.height = g_IPanel.Height();

            #if ENABLE_CUS_PTP_MODE
            if(IsHDMIInUse())
            {
                U8 u8Resolution;
                u8Resolution = _MApp_Scaler_Resolution_Remapping(stXC_SetWin_Info, eWindow);
                if((g_HdmiPollingStatus.bIsHDMIMode == TRUE)&&(u8Resolution<E_HDMI_MAX)
                    && (ST_VIDEO.eAspectRatio == EN_AspectRatio_point_to_point)
                #if ENABLE_3D_PROCESS
                    &&(MApi_XC_Get_3D_Output_Mode() == E_XC_3D_OUTPUT_MODE_NONE)//Not run when 3D on.
                #endif
                    )
                {
                    if(g_IPanel.Width() > stXC_SetWin_Info[eWindow].stCapWin.width)
                    {
                        stXC_SetWin_Info[eWindow].stDispWin.x = (g_IPanel.Width()-stXC_SetWin_Info[eWindow].stCapWin.width)/2;
                        stXC_SetWin_Info[eWindow].stDispWin.width = stXC_SetWin_Info[eWindow].stCapWin.width;
                    }

                    if(g_IPanel.Height() > (stXC_SetWin_Info[eWindow].stCapWin.height))
                    {
                        stXC_SetWin_Info[eWindow].stDispWin.y = (g_IPanel.Height()-stXC_SetWin_Info[eWindow].stCapWin.height)/2;
                        stXC_SetWin_Info[eWindow].stDispWin.height = (stXC_SetWin_Info[eWindow].stCapWin.height);
                    }
                }
            }

            #endif
        }
        MSG(printf("dst0 : x,y,w,h=%u,%u,%u,%u\n", stXC_SetWin_Info[eWindow].stDispWin.x, stXC_SetWin_Info[eWindow].stDispWin.y,
                                                   stXC_SetWin_Info[eWindow].stDispWin.width, stXC_SetWin_Info[eWindow].stDispWin.height));

        // Pre-Check PQ setting
        {
            PQ_WIN ePQWin = (eWindow==MAIN_WINDOW)?PQ_MAIN_WINDOW:PQ_SUB_WINDOW;
            PQ_INPUT_SOURCE_TYPE pqInputSrc = SystemInputSrcToPQInputSrc(enInputSourceType);
            MS_PQ_Mode_Info stPQModeInfo;

            stPQModeInfo.bFBL               = bIsFBLMode;
            stPQModeInfo.bInterlace         = stXC_SetWin_Info[eWindow].bInterlace;
            stPQModeInfo.u16input_hsize     = stXC_SetWin_Info[eWindow].stCapWin.width;
            stPQModeInfo.u16input_vsize     = stXC_SetWin_Info[eWindow].stCapWin.height;
            stPQModeInfo.u16input_vfreq     = stXC_SetWin_Info[eWindow].u16InputVFreq;
            stPQModeInfo.u16input_vtotal    = stXC_SetWin_Info[eWindow].u16InputVTotal;
            stPQModeInfo.u16ouput_vfreq     = stXC_SetWin_Info[eWindow].u16InputVFreq;
            stPQModeInfo.u16display_hsize   = stXC_SetWin_Info[eWindow].stDispWin.width;
            stPQModeInfo.u16display_vsize   = stXC_SetWin_Info[eWindow].stDispWin.height;

            MDrv_PQ_Set_ModeInfo( ePQWin,  pqInputSrc, &stPQModeInfo );
            MDrv_PQ_DesideSrcType( ePQWin, pqInputSrc );
            if( eWindow == MAIN_WINDOW )
            {
                if( bIsFBLMode == FALSE )
                {
                    MDrv_PQ_Get_RFBL_Info(ePQWin);
                    bIsRFBLMode = MApi_XC_IsCurrentRequest_FrameBufferLessMode();
                }
            }
        }

    #if 0//( (MirrorEnable == DISABLE) && (ENABLE_3D_PROCESS == DISABLE) )
        if ((enMiuDDR_Speed == DDR1_400MHz)||((enMiuDDR_Speed == DDR2_800MHz)&&(MEMORY_MAP == MMAP_32MB)))
        {
            if (  (!stXC_SetWin_Info[eWindow].bInterlace)
               && (stXC_SetWin_Info[eWindow].stCapWin.width == 1920)
               && (stXC_SetWin_Info[eWindow].u16InputVFreq > 350)
               )
            {
                MApp_Scaler_Adjust_OverscanRatio_RFBL(enInputSourceType, &stXC_SetWin_Info[eWindow]);
            }
        }
    #endif


        tSrcRatioInfo.u16VideoWidth = stXC_SetWin_Info[eWindow].stCapWin.width;
        tSrcRatioInfo.u16VideoHeight = stXC_SetWin_Info[eWindow].stCapWin.height;
        tSrcRatioInfo.u8AspectRate = gstVidStatus.u8AspectRate;
        tSrcRatioInfo.u8AFD = gstVidStatus.u8AFD;
        tSrcRatioInfo.u32SarWidth = gstVidStatus.u16SarWidth;
        tSrcRatioInfo.u32SarHeight = gstVidStatus.u16SarHeight;


        if ( bIsFBLMode || bIsRFBLMode )
            ptCropWin = NULL;

        if (ptCropWin)
        {
            // XC concept: crop window must start from (0,0) because it's base is frame buffer window
            memcpy(&stXC_SetWin_Info[eWindow].stCropWin, ptCropWin, sizeof(MS_WINDOW_TYPE));
            ASSERT(stXC_SetWin_Info[eWindow].stCropWin.x == 0);
            ASSERT(stXC_SetWin_Info[eWindow].stCropWin.y == 0);
        }
        else
        {
            stXC_SetWin_Info[eWindow].stCropWin.x = 0;
            stXC_SetWin_Info[eWindow].stCropWin.y = 0;
            stXC_SetWin_Info[eWindow].stCropWin.width = stXC_SetWin_Info[eWindow].stCapWin.width;
            stXC_SetWin_Info[eWindow].stCropWin.height= stXC_SetWin_Info[eWindow].stCapWin.height;
        }

        MSG(printf("crop0: x,y,w,h=%u,%u,%u,%u\n", stXC_SetWin_Info[eWindow].stCropWin.x, stXC_SetWin_Info[eWindow].stCropWin.y,
                                                   stXC_SetWin_Info[eWindow].stCropWin.width, stXC_SetWin_Info[eWindow].stCropWin.height));



        //patch:  [Evora_Boxer]issue 943_DNK:Lite 463: 720x576 and 704x576 should be the same size and position
        if( IsSrcTypeDTV(enInputSourceType) )
        {
            if((stXC_SetWin_Info[eWindow].stCapWin.width == 704))
            {
                stXC_SetWin_Info[eWindow].stDispWin.x += (g_IPanel.Width()- (stXC_SetWin_Info[eWindow].stCapWin.width * g_IPanel.Width())/720)/2;
                stXC_SetWin_Info[eWindow].stDispWin.width = (stXC_SetWin_Info[eWindow].stCapWin.width * g_IPanel.Width())/720;
                printf("DisWin x=%x, width=%x\n",stXC_SetWin_Info[eWindow].stDispWin.x, stXC_SetWin_Info[eWindow].stDispWin.width);
            }
        }

        MSG(printf("src1: x,y,w,h=%u,%u,%u,%u\n", stXC_SetWin_Info[eWindow].stCapWin.x, stXC_SetWin_Info[eWindow].stCapWin.y,
                                                  stXC_SetWin_Info[eWindow].stCapWin.width, stXC_SetWin_Info[eWindow].stCapWin.height));

        MSG(printf("crop1: x,y,w,h=%u,%u,%u,%u\n", stXC_SetWin_Info[eWindow].stCropWin.x, stXC_SetWin_Info[eWindow].stCropWin.y,
                                                   stXC_SetWin_Info[eWindow].stCropWin.width, stXC_SetWin_Info[eWindow].stCropWin.height));

        MSG(printf("dst1 : x,y,w,h=%u,%u,%u,%u\n", stXC_SetWin_Info[eWindow].stDispWin.x, stXC_SetWin_Info[eWindow].stDispWin.y,
                                                   stXC_SetWin_Info[eWindow].stDispWin.width, stXC_SetWin_Info[eWindow].stDispWin.height));


        // tCropWin should keep to non-cropped size for MApp_Scaler_Adjust_AspectRatio()
        // because indirect caller _msAPI_Picture_AdjustWidth_CutByHeight() need to
        // original video size
    #if(ENABLE_DMP)
        if( IsSrcTypeStorage(enInputSourceType)  && (e3DInput == E_XC_3D_INPUT_MODE_NONE)) // MM and not preview
        {
            if( MApp_MPlayer_IsMoviePlaying() )
            {
                if( MApp_MPlayer_QueryZoomScale() != E_MPLAYER_ZOOM_1 )
                {
                    // Use the videoplayer's dst window
                    enVideoScreen = VIDEOSCREEN_MM_CAL_BY_VIDEOPLAYER;
                    MS_DEBUG_MSG(printf("MApp_Scaler_SetWindow: Force Aspect Ratio to FULL\n"));
                }
            }
            else // Preview or play photo
            {
                enVideoScreen = VIDEOSCREEN_MM_CAL_BY_VIDEOPLAYER;
            }
        }
    #endif

        // [Set display window 1]    keep the display window before processing it.
        // [Set display window 2.1] processing the display window...
    #if(ENABLE_PIP)
        if((eWindow==MAIN_WINDOW) && (stGenSetting.g_stPipSetting.enPipMode!=EN_PIP_MODE_POP_FULL) && (stGenSetting.g_stPipSetting.enPipMode!=EN_PIP_MODE_POP) )
    #endif
        {
          #if ENABLE_FBL_ASPECT_RATIO_BY_MVOP
            if((!MApi_XC_IsCurrentFrameBufferLessMode()) || (enVideoScreen == VIDEOSCREEN_NORMAL) || (!IsSrcTypeStorage(enInputSourceType) && !IsSrcTypeDTV(enInputSourceType)))
          #endif
            {
                MApp_Scaler_Adjust_AspectRatio(stXC_SetWin_Info, enVideoScreen, &stXC_SetWin_Info[eWindow].stCropWin, &stXC_SetWin_Info[eWindow].stDispWin, &tSrcRatioInfo);  // adjust CropWin according to aspect ratio

                MSG(printf("crop2: x,y,w,h=%u,%u,%u,%u\n", stXC_SetWin_Info[eWindow].stCropWin.x, stXC_SetWin_Info[eWindow].stCropWin.y, stXC_SetWin_Info[eWindow].stCropWin.width, stXC_SetWin_Info[eWindow].stCropWin.height));
                MSG(printf("dst2 : x,y,w,h=%u,%u,%u,%u\n", stXC_SetWin_Info[eWindow].stDispWin.x, stXC_SetWin_Info[eWindow].stDispWin.y, stXC_SetWin_Info[eWindow].stDispWin.width, stXC_SetWin_Info[eWindow].stDispWin.height));
            }
        }

      #if 0//(  (MEMORY_MAP <= MMAP_32MB) && (MirrorEnable==DISABLE) && (ENABLE_3D_PROCESS==DISABLE) )
        if (!(!stXC_SetWin_Info[eWindow].bInterlace
            && (stXC_SetWin_Info[eWindow].stCapWin.width ==1920)
            &&(stXC_SetWin_Info[eWindow].u16InputVFreq>350))
            )
        {
            MApp_Scaler_Adjust_OverscanRatio(enInputSourceType, &stXC_SetWin_Info[eWindow]);    // adjust CropWin according to overscan ratio
        }
      #else
        // [Set display window 2.2] proceesing the dispaly window..
        MApp_Scaler_Adjust_OverscanRatio(enInputSourceType, &stXC_SetWin_Info[eWindow]);           // adjust CropWin according to overscan ratio
      #endif

        MSG(printf("crop3: x,y,w,h=%u,%u,%u,%u\n", stXC_SetWin_Info[eWindow].stCropWin.x, stXC_SetWin_Info[eWindow].stCropWin.y, stXC_SetWin_Info[eWindow].stCropWin.width, stXC_SetWin_Info[eWindow].stCropWin.height));

        MApp_Scaler_AlignWindow(&stXC_SetWin_Info[eWindow].stCropWin, u16AlignX, u16AlignY);
        MSG(printf("crop4: x,y,w,h=%u,%u,%u,%u\n", stXC_SetWin_Info[eWindow].stCropWin.x, stXC_SetWin_Info[eWindow].stCropWin.y, stXC_SetWin_Info[eWindow].stCropWin.width, stXC_SetWin_Info[eWindow].stCropWin.height));

        //if( MApi_XC_IsCurrentFrameBufferLessMode() )
        if( bIsFBLMode || bIsRFBLMode )
        {
            //memcpy(&stXC_SetWin_Info[eWindow].stCapWin, &stXC_SetWin_Info[eWindow].stCropWin, sizeof(MS_WINDOW_TYPE));
            stXC_SetWin_Info[eWindow].stCapWin.x += stXC_SetWin_Info[eWindow].stCropWin.x;
            stXC_SetWin_Info[eWindow].stCapWin.y += stXC_SetWin_Info[eWindow].stCropWin.y;
            stXC_SetWin_Info[eWindow].stCapWin.height = stXC_SetWin_Info[eWindow].stCropWin.height;
            stXC_SetWin_Info[eWindow].stCapWin.width  = stXC_SetWin_Info[eWindow].stCropWin.width;
            stXC_SetWin_Info[eWindow].stCropWin.x = 0;
            stXC_SetWin_Info[eWindow].stCropWin.y = 0;

            MSG(printf("FBL force Cap=Crop: x,y,w,h=%u,%u,%u,%u\n", stXC_SetWin_Info[eWindow].stCapWin.x, stXC_SetWin_Info[eWindow].stCapWin.y, stXC_SetWin_Info[eWindow].stCapWin.width, stXC_SetWin_Info[eWindow].stCapWin.height));
        }

    #if 0// RFBL_Test_EN
        if ( (MApi_XC_IsRequestFrameBufferLessMode() && MApi_XC_IsCurrentRequest_FrameBufferLessMode())
          && (!MApi_XC_IsCurrentFrameBufferLessMode()) )
        {
            printf("====No Crop==\n");

            stXC_SetWin_Info[eWindow].stCropWin.x = 0;
            stXC_SetWin_Info[eWindow].stCropWin.y = 0;
            stXC_SetWin_Info[eWindow].stCropWin.width = stXC_SetWin_Info[eWindow].stCapWin.width;
            stXC_SetWin_Info[eWindow].stCropWin.height= stXC_SetWin_Info[eWindow].stCapWin.height;
        }
    #endif // #if RFBL_Test_EN


    #if (VERIFY_SCALER_FPGA || _TEST_VGA_) //non-scaling function
        stXC_SetWin_Info[eWindow].stDispWin.height = stXC_SetWin_Info[eWindow].stCropWin.height = stXC_SetWin_Info[eWindow].stCapWin.height;
        stXC_SetWin_Info[eWindow].stDispWin.width= stXC_SetWin_Info[eWindow].stCropWin.width = stXC_SetWin_Info[eWindow].stCapWin.width;
        stXC_SetWin_Info[eWindow].stDispWin.x = stXC_SetWin_Info[eWindow].stDispWin.y = 0;
    #endif

        // Force control pre-scaling ...
        // 1. Reset pre-scaling falg
        stXC_SetWin_Info[eWindow].bPreHCusScaling = FALSE;
        stXC_SetWin_Info[eWindow].bPreVCusScaling = FALSE;

        // 2. Over write pre-scaling flag by case
    #if(ENABLE_DMP)
    #if 0 //because of bw problem, don't prescaling to fix point. use black screen between AR change
        if( IsSrcTypeStorage(enInputSourceType)  && (e3DInput == E_XC_3D_INPUT_MODE_NONE)) // MM and not preview
        {
            if( MApp_MPlayer_IsMoviePlaying() )
            {
                if( !MApi_XC_IsCurrentFrameBufferLessMode() ) // Use memory
                {
                    // Force don't use pre-scaling for keep memory data unchanged when change aspect ratio...
                    stXC_SetWin_Info[eWindow].bPreHCusScaling = TRUE;
                    stXC_SetWin_Info[eWindow].u16PreHCusScalingSrc = stXC_SetWin_Info[eWindow].stCapWin.width;
                    if( stXC_SetWin_Info[eWindow].u16PreHCusScalingSrc > g_IPanel.Width() )
                        stXC_SetWin_Info[eWindow].u16PreHCusScalingDst = g_IPanel.Width();
                    else
                        stXC_SetWin_Info[eWindow].u16PreHCusScalingDst = stXC_SetWin_Info[eWindow].u16PreHCusScalingSrc;
                    //printf("Force don't use H pre-scaling: HAfterPreScaling=%u\n", stXC_SetWin_Info[eWindow].u16PreHCusScalingDst);

                    stXC_SetWin_Info[eWindow].bPreVCusScaling = TRUE;
                    stXC_SetWin_Info[eWindow].u16PreVCusScalingSrc = stXC_SetWin_Info[eWindow].stCapWin.height;
                    if( stXC_SetWin_Info[eWindow].u16PreVCusScalingSrc > g_IPanel.Height() )
                        stXC_SetWin_Info[eWindow].u16PreVCusScalingDst = g_IPanel.Height();
                    else
                        stXC_SetWin_Info[eWindow].u16PreVCusScalingDst = stXC_SetWin_Info[eWindow].u16PreVCusScalingSrc;
                    //printf("Force don't use V pre-scaling: VAfterPreScaling=%u\n", stXC_SetWin_Info[eWindow].u16PreVCusScalingDst);
                }
            }
        }
        else
    #endif
    #endif
        {
        #if (CHANGE_AR_WITHOUT_BLUESCREEN == ENABLE)
            if(e3DInput == E_XC_3D_INPUT_MODE_NONE)
            {
            stXC_SetWin_Info[eWindow].bPreHCusScaling = TRUE;
            stXC_SetWin_Info[eWindow].u16PreHCusScalingSrc = stXC_SetWin_Info[eWindow].stCapWin.width;
            stXC_SetWin_Info[eWindow].u16PreHCusScalingDst = stXC_SetWin_Info[eWindow].stDispWin.width;
            }
        #endif
        }

    #if (DYNSCALING == 0)
        stXC_SetWin_Info[eWindow].bHCusScaling = stXC_SetWin_Info[eWindow].bVCusScaling = FALSE;
    #endif

  #if ((ENABLE_1080I_SCALE||ENABLE_3D_PROCESS)&&(MEMORY_MAP <= MMAP_32MB))
        if (( IsSrcTypeAnalog(enInputSourceType) || IsSrcTypeHDMI(enInputSourceType))
             &&(stXC_SetWin_Info[eWindow].stCapWin.width > 1280))    //need use 3 frame mode when mirror
            {
            if (stXC_SetWin_Info[eWindow].bInterlace)
             {
                MSG(printf("need 1080I scale down when 32M\n"));

                stXC_SetWin_Info[eWindow].bPreHCusScaling = TRUE;
                stXC_SetWin_Info[eWindow].u16PreHCusScalingSrc = stXC_SetWin_Info[eWindow].stCapWin.width;
                stXC_SetWin_Info[eWindow].u16PreHCusScalingDst = 1280;
              }
        #if ENABLE_3D_PROCESS
            else
            {
                MSG(printf("need 3D scale down when 32M\n"));
                stXC_SetWin_Info[eWindow].bPreHCusScaling = TRUE;
                stXC_SetWin_Info[eWindow].u16PreHCusScalingSrc = stXC_SetWin_Info[eWindow].stCapWin.width;
                stXC_SetWin_Info[eWindow].u16PreHCusScalingDst = 1280;
            }
        #endif
        }
    #endif

    #if (MirrorEnable)
        if (  (!stXC_SetWin_Info[eWindow].bInterlace)
           && (stXC_SetWin_Info[eWindow].stCapWin.width > 1280)     //need use 3 frame mode when mirror
           )
        {
            MSG(printf("need use 3 frame mode when mirror\n"));
           /*if ((enMiuDDR_Speed == DDR1_400MHz)) //32MB DDR1
           {
              stXC_SetWin_Info[eWindow].bPreHCusScaling = TRUE;
              stXC_SetWin_Info[eWindow].u16PreHCusScalingSrc = stXC_SetWin_Info[eWindow].stCapWin.width;
              stXC_SetWin_Info[eWindow].u16PreHCusScalingDst = 1280;
           }
           else*/
           {
           #if (ENABLE_3D_PROCESS&&(MEMORY_MAP == MMAP_64MB))
              if( stXC_SetWin_Info[eWindow].u16InputVFreq<245)
              {
                 stXC_SetWin_Info[eWindow].bPreHCusScaling = TRUE;
                 stXC_SetWin_Info[eWindow].u16PreHCusScalingSrc = stXC_SetWin_Info[eWindow].stCapWin.width;
                 stXC_SetWin_Info[eWindow].u16PreHCusScalingDst = 960;
              }
           #endif
           }
        }
    #endif


    #if (ENABLE_TCON)
        if (g_PNL_TypeSel == TCON_PNL_WXGA_BOE_HV320WXC)
        {   // BOE_HV320WXC panel has 2-bit dummy pixel
            MSG(printf("BOE_HV320WXC_03 : x = %u, w = %u, \n", stXC_SetWin_Info[eWindow].stDispWin.x, stXC_SetWin_Info[eWindow].stDispWin.width));
            stXC_SetWin_Info[eWindow].stDispWin.x += 0;
            stXC_SetWin_Info[eWindow].stDispWin.width -= 2;
            MSG(printf("BOE_HV320WXC_04 : x = %u, w = %u, \n", stXC_SetWin_Info[eWindow].stDispWin.x, stXC_SetWin_Info[eWindow].stDispWin.width));
        }
    #endif


    #if (ENABLE_MIU_1 == 0) //need to check , IS_HVD_CODEC(msAPI_VID_GetCodecType() is valid or not
        // For reduce bandwidth ...
        //Block some small window like MM preview or DTV channel edit window enter below patch
        //and also need prevent customer scaling when enter 3D mode, like half side by side
        if (stXC_SetWin_Info[eWindow].stCapWin.width >= 1900 && stXC_SetWin_Info[eWindow].stDispWin.width > (g_IPanel.Width()+1)/2)
        {
            if ((IsSrcTypeStorage(enInputSourceType) && (!MApi_XC_IsCurrentFrameBufferLessMode()) && (MEMORY_MAP>MMAP_64MB)))
            {
                //printf("*** => Cap:W,H=%d,%d\n",stXC_SetWin_Info[eWindow].stCapWin.width,stXC_SetWin_Info[eWindow].stCapWin.height);
		  if(e3DInput == E_XC_3D_INPUT_MODE_NONE)
                {
                    printf("--MM HD scale down to 960----\n");
                    stXC_SetWin_Info[eWindow].bPreHCusScaling = TRUE;
                    stXC_SetWin_Info[eWindow].u16PreHCusScalingDst = 960-4;//480;//960;       ///<pre H customized scaling dst width
                    stXC_SetWin_Info[eWindow].u16PreHCusScalingSrc = stXC_SetWin_Info[eWindow].stCapWin.width;
                }

                if ( IsSrcTypeStorage(enInputSourceType) && (!MApi_XC_IsCurrentFrameBufferLessMode()) && (MEMORY_MAP>MMAP_64MB) )
                {
                    if(e3DInput == E_XC_3D_INPUT_MODE_NONE)
                    {
                        stXC_SetWin_Info[eWindow].u16PreHCusScalingDst = 988;
                    }
                    else if(e3DInput == E_XC_3D_INPUT_NORMAL_2D)
                    {
                        stXC_SetWin_Info[eWindow].bPreHCusScaling = TRUE;
                        stXC_SetWin_Info[eWindow].u16PreHCusScalingSrc = stXC_SetWin_Info[eWindow].stCapWin.width;
                        stXC_SetWin_Info[eWindow].u16PreHCusScalingDst = 640;      ///<pre H customized scaling dst width
                    }
                }
            }
        }
    #endif
        if (stXC_SetWin_Info[eWindow].stCapWin.width >= 1900 && stXC_SetWin_Info[eWindow].stDispWin.width > (g_IPanel.Width()+1)/2)
        {
            if (IsSrcTypeDTV(enInputSourceType) && IS_HVD_CODEC(msAPI_VID_GetCodecType()))
            {
           #if (ENABLE_3D_PROCESS&&(MEMORY_MAP == MMAP_64MB))
		   //if(e3DInput == E_XC_3D_INPUT_MODE_NONE)
                {
                    printf("--DTV/MM HD scale down to 960----\n");
                    stXC_SetWin_Info[eWindow].bPreHCusScaling = TRUE;
                    stXC_SetWin_Info[eWindow].u16PreHCusScalingDst = 960-4;       ///<pre H customized scaling dst width
                    stXC_SetWin_Info[eWindow].u16PreHCusScalingSrc = stXC_SetWin_Info[eWindow].stCapWin.width;
                }
	    #endif
            }
        }
        // For reduce bandwidth ...
        //Block some small window like MM preview or DTV channel edit window enter below patch
        //and also need prevent customer scaling when enter 3D mode, like half side by side
#if 1//( ENABLE_MM_HD_FB&& (MEMORY_MAP==MMAP_64MB))

        if ((stXC_SetWin_Info[eWindow].stCapWin.width >= 1200) && (stXC_SetWin_Info[eWindow].stDispWin.width > (g_IPanel.Width()+1)/2))
        {
            if (IsSrcTypeStorage(enInputSourceType) && (!MApi_XC_IsCurrentFrameBufferLessMode()))
            {
                //printf("*** => Cap:W,H=%d,%d\n",stXC_SetWin_Info[eWindow].stCapWin.width,stXC_SetWin_Info[eWindow].stCapWin.height);
                printf("--MM HD scale down to 960--[Memory >= 6M]\n");
                stXC_SetWin_Info[eWindow].bPreHCusScaling = TRUE;
                stXC_SetWin_Info[eWindow].u16PreHCusScalingDst = 800;//480;//960-4;       ///<pre H customized scaling dst width
                stXC_SetWin_Info[eWindow].u16PreHCusScalingSrc = stXC_SetWin_Info[eWindow].stCapWin.width;
            }
        }
#endif
/*
      if ((stXC_SetWin_Info[eWindow].stCapWin.width == 800) && (stXC_SetWin_Info[eWindow].stDispWin.width > (g_IPanel.Width()+1)/2))
        {
            if (IsSrcTypeStorage(enInputSourceType) && (!MApi_XC_IsCurrentFrameBufferLessMode()))
            {
                //printf("*** => Cap:W,H=%d,%d\n",stXC_SetWin_Info[eWindow].stCapWin.width,stXC_SetWin_Info[eWindow].stCapWin.height);
                printf("--MM HD scale down to 960--[Memory >= 6M]\n");
                stXC_SetWin_Info[eWindow].bPreHCusScaling = TRUE;
                stXC_SetWin_Info[eWindow].u16PreHCusScalingDst = 240;//480-4;//480;//640;//960-4;       ///<pre H customized scaling dst width
                stXC_SetWin_Info[eWindow].u16PreHCusScalingSrc = stXC_SetWin_Info[eWindow].stCapWin.width;
            }
        }
        */
    }

#if (MEMORY_MAP <= MMAP_32MB)
    if ( (IsSrcTypeStorage(enInputSourceType)) && (m_bFLG_PREVIEW) )
    {
        #define MOVIE_PREVIEW_WIDTH_32MB        (MOVIE_PREVIEW_WIDTH/2)
        #define MOVIE_PREVIEW_HEIGHT_32MB       (MOVIE_PREVIEW_HEIGHT)

        stXC_SetWin_Info[eWindow].bPreHCusScaling = TRUE;
        stXC_SetWin_Info[eWindow].u16PreHCusScalingSrc = stXC_SetWin_Info[eWindow].stCapWin.width;
        stXC_SetWin_Info[eWindow].u16PreHCusScalingDst = MOVIE_PREVIEW_WIDTH_32MB;

        stXC_SetWin_Info[eWindow].bPreVCusScaling = TRUE;
        stXC_SetWin_Info[eWindow].u16PreVCusScalingSrc = stXC_SetWin_Info[eWindow].stCapWin.height;
        stXC_SetWin_Info[eWindow].u16PreVCusScalingDst = MOVIE_PREVIEW_HEIGHT_32MB;

        /*
        //Notes: Recommend NOT do Post customer scaling to avoid crop cause garbage
        //and here we do not need below post customer scaling too, so remove it.
        stXC_SetWin_Info[eWindow].bHCusScaling = TRUE;
        stXC_SetWin_Info[eWindow].u16HCusScalingSrc = MOVIE_PREVIEW_WIDTH_32MB;
                stXC_SetWin_Info[eWindow].u16HCusScalingDst = stXC_SetWin_Info[eWindow].stDispWin.width;
        stXC_SetWin_Info[eWindow].bVCusScaling = TRUE;
        stXC_SetWin_Info[eWindow].u16VCusScalingSrc = MOVIE_PREVIEW_HEIGHT_32MB;
        stXC_SetWin_Info[eWindow].u16VCusScalingDst = stXC_SetWin_Info[eWindow].stDispWin.height;
        */
    }
#endif // #if (MEMORY_MAP<= MMAP_32MB)


#if ENABLE_3D_LAP_PATCH
    if(IsSrcTypeDigitalVD(enInputSourceType)) // Patch for M10 3D in ATV/AV/SV/etc
    {
        if(E_XC_3D_OUTPUT_LINE_ALTERNATIVE == e3DOutput)
        {
            if((E_XC_3D_INPUT_SIDE_BY_SIDE_HALF == e3DInput)||(E_XC_3D_INPUT_SIDE_BY_SIDE_HALF_INTERLACE == e3DInput))
            {
                stXC_SetWin_Info[eWindow].bVCusScaling = TRUE;
                stXC_SetWin_Info[eWindow].u16VCusScalingSrc = stXC_SetWin_Info[eWindow].stCapWin.height-2;//remove 2 line to avoid garbage
                stXC_SetWin_Info[eWindow].u16VCusScalingDst = stXC_SetWin_Info[eWindow].stDispWin.height/2;
                }
            else if((E_XC_3D_INPUT_TOP_BOTTOM == e3DInput)||(E_XC_3D_INPUT_LINE_ALTERNATIVE == e3DInput))
            {
                stXC_SetWin_Info[eWindow].bVCusScaling = TRUE;
                stXC_SetWin_Info[eWindow].u16VCusScalingSrc = stXC_SetWin_Info[eWindow].stCapWin.height/2-2;//remove 2 line to avoid garbage
                stXC_SetWin_Info[eWindow].u16VCusScalingDst = stXC_SetWin_Info[eWindow].stDispWin.height/2;
            }
        }
    }
#endif //#if ENABLE_3D_LAP_PATCH

#if 1//(VGA_POINT_TO_POINT)  	
   if ((IsVgaInUse()||IsHDMIInUse())&&(ST_VIDEO.eAspectRatio == EN_AspectRatio_point_to_point))
   {
   if((stXC_SetWin_Info[eWindow].stCapWin.width >=1358 && stXC_SetWin_Info[eWindow].stCapWin.width <=1370) \
   	&& (stXC_SetWin_Info[eWindow].stCapWin.height>=760 && stXC_SetWin_Info[eWindow].stCapWin.height<=775))
   	{
     stXC_SetWin_Info[eWindow].stDispWin.height = stXC_SetWin_Info[eWindow].stCropWin.height = stXC_SetWin_Info[eWindow].stCapWin.height;
     stXC_SetWin_Info[eWindow].stDispWin.width= stXC_SetWin_Info[eWindow].stCropWin.width = stXC_SetWin_Info[eWindow].stCapWin.width;
     stXC_SetWin_Info[eWindow].stDispWin.x = (g_IPanel.Width()-stXC_SetWin_Info[eWindow].stCapWin.width)/2;
     stXC_SetWin_Info[eWindow].stDispWin.y = ( g_IPanel.Height()-stXC_SetWin_Info[eWindow].stCapWin.height)/2;
   	}
   }
   
   else if ((IsVgaInUse()||IsHDMIInUse())&&(ST_VIDEO.eAspectRatio == EN_AspectRatio_16X9)
       //&&(stXC_SetWin_Info[eWindow].stCapWin.width >=1358)
       //&&(stXC_SetWin_Info[eWindow].stCapWin.height>=760)
       )
   {
   if((stXC_SetWin_Info[eWindow].stCapWin.width >=1358 && stXC_SetWin_Info[eWindow].stCapWin.width <=1370) \
	&& (stXC_SetWin_Info[eWindow].stCapWin.height>=760 && stXC_SetWin_Info[eWindow].stCapWin.height<=775))
   	{
     stXC_SetWin_Info[eWindow].stDispWin.height = stXC_SetWin_Info[eWindow].stCropWin.height = stXC_SetWin_Info[eWindow].stCapWin.height;
     stXC_SetWin_Info[eWindow].stDispWin.width= stXC_SetWin_Info[eWindow].stCropWin.width = stXC_SetWin_Info[eWindow].stCapWin.width;
     stXC_SetWin_Info[eWindow].stDispWin.x = (g_IPanel.Width()-stXC_SetWin_Info[eWindow].stCapWin.width)/2;
     stXC_SetWin_Info[eWindow].stDispWin.y = ( g_IPanel.Height()-stXC_SetWin_Info[eWindow].stCapWin.height)/2;
   	}
   }
#endif

#if(ENABLE_DMP & DYNSCALING)
        if( IsSrcTypeStorage(enInputSourceType) ) // MM
        {
            printf("@@Set MApp_VDPlayer_SetVirtualBox\n");
            MApp_VDPlayer_SetVirtualBox(&stXC_SetWin_Info[eWindow], ptSrcWin, ptDstWin);
        }
#endif

        if(stXC_SetWin_Info[eWindow].bInterlace)
        {
            if(stXC_SetWin_Info[eWindow].stCapWin.height%2)
            {
                stXC_SetWin_Info[eWindow].stCapWin.height -= 1;
            }
        }

    _MApp_XC_check_crop_win( &stXC_SetWin_Info[eWindow] );

    if(msAPI_AVD_IsScartRGB() && IsScartInUse())//For customer set Scart RGB sync on green clamp delay
    {
        MApi_XC_ADC_ScartRGB_SOG_ClampDelay(0x280,0xC0);
    }

    if(stXC_SetWin_Info[eWindow].u16PreHCusScalingDst > stXC_SetWin_Info[eWindow].u16PreHCusScalingSrc)
    {
        stXC_SetWin_Info[eWindow].bPreHCusScaling = FALSE;
        printf("Customer H PreScaling setting error %u->%u: change to auto prescaling\n",
                stXC_SetWin_Info[eWindow].u16PreHCusScalingSrc, stXC_SetWin_Info[eWindow].u16PreHCusScalingDst);
    }

    if(stXC_SetWin_Info[eWindow].u16PreVCusScalingDst > stXC_SetWin_Info[eWindow].u16PreVCusScalingSrc)
    {
        stXC_SetWin_Info[eWindow].bPreVCusScaling = FALSE;
        printf("Customer V PreScaling setting error %u->%u: change to auto prescaling\n",
                stXC_SetWin_Info[eWindow].u16PreVCusScalingSrc, stXC_SetWin_Info[eWindow].u16PreVCusScalingDst);
    }

    MSG(printf("Cus Pre H scaling Ena=%u, from %d to %d\n",stXC_SetWin_Info[eWindow].bPreHCusScaling,
                stXC_SetWin_Info[eWindow].u16PreHCusScalingSrc, stXC_SetWin_Info[eWindow].u16PreHCusScalingDst));
    MSG(printf("Cus Pre V scaling Ena=%u, from %d to %d\n",stXC_SetWin_Info[eWindow].bPreVCusScaling,
                stXC_SetWin_Info[eWindow].u16PreVCusScalingSrc, stXC_SetWin_Info[eWindow].u16PreVCusScalingDst));
    MSG(printf("Cus Post H scaling Ena=%u, from %d to %d\n",stXC_SetWin_Info[eWindow].bHCusScaling,
                stXC_SetWin_Info[eWindow].u16HCusScalingSrc, stXC_SetWin_Info[eWindow].u16HCusScalingDst));
    MSG(printf("Cus Post V scaling Ena=%u, from %d to %d\n",stXC_SetWin_Info[eWindow].bVCusScaling,
                stXC_SetWin_Info[eWindow].u16VCusScalingSrc, stXC_SetWin_Info[eWindow].u16VCusScalingDst));

#if ENABLE_3D_PROCESS
    if((IsStorageInUse()) && (MApp_MPlayer_IsMoviePlaying()) &&
       (E_MPLAYER_MOVIE_PAUSE==MApp_MPlayer_QueryMoviePlayMode()))
    {
        //Patch for MM pause video and enable 3D
        MApi_XC_DisableInputSource(FALSE, eWindow);
        MApi_XC_set_FD_Mask(FALSE);
    }
#endif


    if (MApi_XC_SetWindow(&stXC_SetWin_Info[eWindow], sizeof(XC_SETWIN_INFO), eWindow) == FALSE)
    {
        printf("MApi_XC_SetWindow failed because of InitData wrong, please update header file and compile again\n");
    }

#if ENABLE_3D_PROCESS
    if((IsStorageInUse()) && (MApp_MPlayer_IsMoviePlaying()) &&
       (E_MPLAYER_MOVIE_PAUSE==MApp_MPlayer_QueryMoviePlayMode()))
    {
        //Patch for MM pause video and enable 3D
        MApi_XC_WaitInputVSync(4, 100, MAIN_WINDOW);//For M10, maximum is 4 filed support, so wait 4 vsync here
        MApi_XC_set_FD_Mask(TRUE);
        MApi_XC_DisableInputSource(TRUE, eWindow);
    }
    #endif

    // for Dynamic change DLC capture range
    {
        MS_WINDOW_TYPE stDstWin;
        MS_U16 u16DE_Start = MApi_XC_R2BYTEMSK(REG_SC_BK10_04_L,0x7FF);;
        MApi_XC_GetDispWinFromReg(&stDstWin, MAIN_WINDOW);
        stDLC_CapRange.wHStart = stDstWin.x - u16DE_Start+1;
        stDLC_CapRange.wHEnd = stDLC_CapRange.wHStart+stDstWin.width;
        //DLC capture height range need to set (display windows height * 6/8) .
        stDLC_CapRange.wVStart = stDstWin.height/8;
        stDLC_CapRange.wVEnd = stDLC_CapRange.wVStart*7;
        MApi_XC_DLC_SetCaptureRange(&stDLC_CapRange);
    }


    if (IsYPbPrInUse()&&stXC_SetWin_Info[eWindow].stCapWin.height <= 580 )// Set SOG bandwidth for SD timing
    {
        MApi_XC_ADC_Set_SOGBW(0x1F);
    }
    else
    {
        MApi_XC_ADC_Set_SOGBW(0x00);
    }

    //TODO: For Backward compatibility
    if (IsYPbPrInUse() )//For customer set default adc phase
    {
        MApi_XC_ADC_SetPhaseEx(MApi_XC_GetCustomAdcPhase(g_PcadcModeSetting[eWindow].u8ModeIndex));
    }
    else if ( IsVgaInUse() )
    {
        MApi_XC_ADC_SetPhaseEx(g_PcadcModeSetting[eWindow].u16Phase);
    }

    // non-linear scaling control
    if (_bEnNonLinearScaling[eWindow] && (stXC_SetWin_Info[eWindow].stDispWin.width != g_IPanel.Width()) )
    {
        //ASSERT(0); printf("display window width != panel width and cannot do non-linear scaling\n");

        _bEnNonLinearScaling[eWindow] = FALSE;
    }

    switch(eWindow)
    {
        default:
        case MAIN_WINDOW:
            enPQWin = PQ_MAIN_WINDOW;
            break;

        case SUB_WINDOW:
            enPQWin = PQ_SUB_WINDOW;
            break;
    }

    MDrv_PQ_SetNonLinearScaling(enPQWin, 0, _bEnNonLinearScaling[eWindow]);

    if(_bEnNonLinearScaling[eWindow])
    {
        //If we set a bad Linear scaling setting, then the display will turn bad
        //and we now correct it, it may cause garbage flash out, so must done this in blue screen case
        if(MApi_XC_Check_HNonLinearScaling() == FALSE)
        {
            //If beyond the max offset, then disable non-linear scaling
            _bEnNonLinearScaling[eWindow] = FALSE;
            MDrv_PQ_SetNonLinearScaling(enPQWin, 0, _bEnNonLinearScaling[eWindow]);
        }
    }
#if (ENABLE_3D_PROCESS && (ENABLE_6M30_3D_PROCESS == FALSE))
#if MirrorEnable
    // swap LR for 3D PR and mirror panel
    {
        EN_3D_LR_MODE enLRMODE;
        #if ENABLE_CUS_3D_SOURCE_MEMORY
        if(IsHDMIInUse() && (g_HdmiPollingStatus.bIsHDMIMode == FALSE)) //dvi
        {
            enLRMODE = ST_VGA_3D_LRMODE;
        }
        else
        #endif
        {
            enLRMODE = ST_3D_LRMODE;
        }

        if(enLRMODE == EN_3D_LR_L)
        {
            if(IsDigitalSourceInUse() == FALSE)
            {
                MApi_XC_Set_3D_LR_Frame_Exchg(MAIN_WINDOW);
            }
        }
    }
#endif
#endif

#if (MWE_FUNCTION)
    MApi_XC_ACE_MWESetDispWin(stXC_SetWin_Info[eWindow].stDispWin.x, stXC_SetWin_Info[eWindow].stDispWin.y, stXC_SetWin_Info[eWindow].stDispWin.width, stXC_SetWin_Info[eWindow].stDispWin.height);
#endif

    CAL_TIME_FUNC_END();
}

//********************************************************************************************
// Get saved display window
//   parameter:
//          eWin: MAIN_WINDOW/SUB_WINDOW
//********************************************************************************************
void MApp_Scaler_ResetZoomFactor(EN_MENU_AspectRatio enAspectratio)
{
    S16 s16Left,s16Rigth,s16Up,s16Down;

    s16Left = 0;
    s16Rigth = 0;
    s16Up = 0;
    s16Down = 0;

    switch(enAspectratio)
    {
        case EN_AspectRatio_Zoom1:
            #if ENABLE_CUS_UI_SPEC
            s16Left = 0;
            s16Rigth = 0;
            s16Up = 30;
            s16Down = 30;
            #else
            s16Left = 50;
            s16Rigth = 50;
            s16Up = 60;
            s16Down = 60;
            #endif
            break;

        case EN_AspectRatio_Zoom2:
            #if ENABLE_CUS_UI_SPEC
            s16Left = 0;
            s16Rigth = 0;
            s16Up = 50;
            s16Down = 50;
            #else
            s16Left = 100;
            s16Rigth = 100;
            s16Up = 120;
            s16Down = 120;
            #endif
            break;

        case EN_AspectRatio_Panorama:
            s16Left = 20;
            s16Rigth = 20;
            s16Up = 30;
            s16Down = 30;
            break;

        default:
            break;
    }

    _s16ZoomLeft = s16Left;
    _s16ZoomRight = s16Rigth;
    _s16ZoomUp = s16Up;
    _s16ZoomDown = s16Down;
}

//////////////////////////////////////////////////////////////////
// increment/decrement left zoom factor
// for horizontal shift video, this factor should be independently
// set
// parameter:
//    s16Hfator: increment/decrement count,
//               unit: ZOOM_NUMERATOR/ZOOM_DENUMERATOR
// return:
//    TRUE if really increment/decrement
//    FALSE otherwise
//////////////////////////////////////////////////////////////////
BOOLEAN MApp_Scaler_IncLeftZoomfactor(S16 s16ZoomFator)
{
    if (s16ZoomFator > 0)
    {
        if (_s16ZoomLeft + s16ZoomFator < ZOOM_NUMERATOR_LEFTMAX)
        {
            _s16ZoomLeft += s16ZoomFator;
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
    else
    {
        if (_s16ZoomLeft + s16ZoomFator > 0)
        {
            _s16ZoomLeft += s16ZoomFator;
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
}

//////////////////////////////////////////////////////////////////
// increment/decrement right zoom factor
// for horizontal shift video, this factor should be independently
// set
// parameter:
//    s16Hfator: increment/decrement count,
//               unit: ZOOM_NUMERATOR/ZOOM_DENUMERATOR
// return:
//    TRUE if really increment/decrement
//    FALSE otherwise
//////////////////////////////////////////////////////////////////
BOOLEAN MApp_Scaler_IncRightZoomfactor(S16 s16ZoomFator)
{
    if (s16ZoomFator > 0)
    {
        if (_s16ZoomRight+ s16ZoomFator < ZOOM_NUMERATOR_RIGHTMAX)
        {
            _s16ZoomRight += s16ZoomFator;
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
    else
    {
        if (_s16ZoomRight + s16ZoomFator > 0)
        {
            _s16ZoomRight += s16ZoomFator;
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
}

//////////////////////////////////////////////////////////////////
// increment/decrement up zoom factor
// for vertical shift video, this factor should be independently
// set
// parameter:
//    s16Hfator: increment/decrement count,
//               unit: ZOOM_NUMERATOR/ZOOM_DENUMERATOR
// return:
//    TRUE if really increment/decrement
//    FALSE otherwise
//////////////////////////////////////////////////////////////////
BOOLEAN MApp_Scaler_IncUpZoomfactor(S16 s16ZoomFator)
{
    if (s16ZoomFator > 0)
    {
        if (_s16ZoomUp + s16ZoomFator < ZOOM_NUMERATOR_UPMAX)
        {
            _s16ZoomUp += s16ZoomFator;
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
    else
    {
        if (_s16ZoomUp + s16ZoomFator > 0)
        {
            _s16ZoomUp += s16ZoomFator;
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
}

//////////////////////////////////////////////////////////////////
// increment/decrement down zoom factor
// for vertical shift video, this factor should be independently
// set
// parameter:
//    s16Hfator: increment/decrement count,
//               unit: ZOOM_NUMERATOR/ZOOM_DENUMERATOR
// return:
//    TRUE if really increment/decrement
//    FALSE otherwise
//////////////////////////////////////////////////////////////////
BOOLEAN MApp_Scaler_IncDownZoomfactor(S16 s16ZoomFator)
{
    if (s16ZoomFator > 0)
    {
        if (_s16ZoomDown+ s16ZoomFator < ZOOM_NUMERATOR_DOWNMAX)
        {
            _s16ZoomDown += s16ZoomFator;
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
    else
    {
        if (_s16ZoomDown + s16ZoomFator > 0)
        {
            _s16ZoomDown += s16ZoomFator;
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
}

//////////////////////////////////////////////////////////////////
// calculate cropwin by zoom factor
// parameter:
//    pstCropWin [IN/OUT]: cropping window
//////////////////////////////////////////////////////////////////

static void _MApp_Scaler_ZoomCropWin(MS_WINDOW_TYPE *pstCropWin)
{
    U16 x0, y0,x1, y1;

    x0 = (U16)((U32)pstCropWin->width * _s16ZoomLeft / ZOOM_DENUMERATOR);
    y0 = (U16)((U32)pstCropWin->height * _s16ZoomUp / ZOOM_DENUMERATOR);
    x1 = (U16)((U32)pstCropWin->width * _s16ZoomRight / ZOOM_DENUMERATOR);
    y1 = (U16)((U32)pstCropWin->height * _s16ZoomDown / ZOOM_DENUMERATOR);

    x0 &= ~0x1;
    y0 &= ~0x1;
    x1 &= ~0x1;
    y1 &= ~0x1;

    pstCropWin->x += x0;
    pstCropWin->y += y0;
    pstCropWin->x &= ~0x1;
    pstCropWin->y &= ~0x1;

    pstCropWin->width = pstCropWin->width - (x0 + x1);
    pstCropWin->height = pstCropWin->height - (y0 + y1);
}


EN_ASPECT_RATIO_TYPE MApp_Scaler_GetAspectRatio(EN_MENU_AspectRatio eAspect)
{
    EN_ASPECT_RATIO_TYPE eResult;

    _MApp_Scaler_CheckHDMode();
    #if ENABLE_3D_PROCESS
    #if ENABLE_CUS_UI_SPEC
    if(eAspect != EN_AspectRatio_16X9)
    {
        if(IsSrcTypeHDMI(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)))
        {
            if(g_HdmiPollingStatus.bIsHDMIMode == FALSE)
            {
                if(ST_VGA_3D_TYPE != EN_3D_BYPASS)
                {
                    eAspect = EN_AspectRatio_16X9;
                }
            }
            else
            {
                if(stGenSetting.g_SysSetting.en3DDetectMode != EN_3D_DETECT_AUTO)
                {
                    if(ST_3D_TYPE != EN_3D_BYPASS)
                    {
                        eAspect = EN_AspectRatio_16X9;
                    }
                }
                else
                {
                    if(MApi_XC_Get_3D_Output_Mode() != E_XC_3D_OUTPUT_MODE_NONE )
                    {
                        eAspect = EN_AspectRatio_16X9;
                    }
                }
            }
        }
        else
        {
            if(ST_3D_TYPE != EN_3D_BYPASS)
            {
                eAspect = EN_AspectRatio_16X9;
            }

        }
    }
    #endif
    #endif

    switch (eAspect)
    {
        case EN_AspectRatio_JustScan:
            if ( MApi_XC_Sys_IsSrcHD(MAIN_WINDOW) &&
            (IsSrcTypeDTV(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)) ||
            IsSrcTypeHDMI(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)) ||
            IsSrcTypeYPbPr(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW))) )
            {
                eResult = VIDEOSCREEN_JUSTSCAN;
                break;
            }
            else
            {
                // same as Oringal
            }

        case EN_AspectRatio_Original:
        default:
            if( SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW) == INPUT_SOURCE_DTV )
            {
                eResult = VIDEOSCREEN_PROGRAM;
            }
            else if( IsSrcTypeStorage(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW) ))
            {
                 eResult= VIDEOSCREEN_MM_KEEP_RATIO_AND_SCALE; // H and V scale to fit panel
            }
            else if ( IsSrcTypeYPbPr(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW))
                   || IsSrcTypeHDMI(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)) )
            {
                if( MApp_PCMode_IsAspectRatioWide(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)) == TRUE )
                    eResult = VIDEOSCREEN_FULL;
                else
                    eResult = VIDEOSCREEN_NORMAL;
            }
            else if( IsSrcTypeDigitalVD(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)))
            { // ATV, SCART, AV
                U8 u8WSSARCType;
                //WSS information only for wide panel
                if (!(g_IPanel.AspectRatio()==E_PNL_ASPECT_RATIO_WIDE))
                {
                    eResult = VIDEOSCREEN_NORMAL;
                }
                else
                {
                    u8WSSARCType = msAPI_AVD_GetAspectRatioCode();

                    switch(u8WSSARCType)
                    {
                    case ARC4x3_FULL:
                        eResult  =   VIDEOSCREEN_NORMAL;
                        break;

                    case ARC14x9_LETTERBOX_CENTER:
                    case ARC14x9_FULL_CENTER:
                        eResult = VIDEOSCREEN_WSS_14by9_LETTERBOX_CENTER;
                        break;
                    case ARC14x9_LETTERBOX_TOP:
                        eResult = VIDEOSCREEN_WSS_14by9_LETTERBOX_TOP;
                        break;
                    case ARC16x9_LETTERBOX_CENTER:
                    case ARC_ABOVE16x9_LETTERBOX_CENTER:
                        eResult = VIDEOSCREEN_WSS_16by9_LETTERBOX_CENTER;
                        break;
                    case ARC16x9_LETTERBOX_TOP:
                        eResult = VIDEOSCREEN_WSS_16by9_LETTERBOX_TOP;
                        break;

                    case ARC16x9_ANAMORPHIC:
                        eResult = VIDEOSCREEN_FULL;
                        break;

                    case ARC_INVALID:
                        eResult = VIDEOSCREEN_FULL;
                        break;
                    default:
                        eResult = VIDEOSCREEN_NORMAL;
                        break;
                    }
                }
            }
            else //PC
            {
                eResult = VIDEOSCREEN_NORMAL;
            }
            break;
        case EN_AspectRatio_4X3:
             if( IsSrcTypeStorage(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW) ))
            {
                eResult= VIDEOSCREEN_MM_4_3; // H and V scale to fit panel
            }
            else
            {
            if ((g_IPanel.AspectRatio()==E_PNL_ASPECT_RATIO_WIDE))
                eResult = VIDEOSCREEN_NORMAL;
            else
                eResult = VIDEOSCREEN_FULL;
            }
            break;

        case EN_AspectRatio_16X9:
            if( IsSrcTypeStorage(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW) ))
            {
                eResult= VIDEOSCREEN_MM_16_9; // H and V scale to fit panel
            }
            else
            {
            if ((g_IPanel.AspectRatio()==E_PNL_ASPECT_RATIO_WIDE))
                eResult = VIDEOSCREEN_FULL;
            else
                eResult = VIDEOSCREEN_NORMAL;
            }
            break;

        case EN_AspectRatio_14X9:
            eResult = VIDEOSCREEN_14by9;
            break;

        case EN_AspectRatio_Zoom1:
            eResult = VIDEOSCREEN_ZOOM1;
            break;

        case EN_AspectRatio_Zoom2:
            eResult = VIDEOSCREEN_ZOOM2;
            break;
        case EN_AspectRatio_Panorama:
            eResult = VIDEOSCREEN_PANORAMA;
            break;


    #if  VGA_HDMI_YUV_POINT_TO_POINT
        case EN_AspectRatio_point_to_point:
          #if 0//(MEMORY_MAP <= MMAP_32MB)
            if(MDrv_PQ_Get_HDMIPTPMode())
            {
                eResult = VIDEOSCREEN_POINT_TO_POINT;
            }
            else
          #endif
#if 1//BOE_ENBALE_P2P_1360_HDMI//minglin1031
				  // printf("stXC_SetWin_Info[MAIN_WINDOW].stCropWin.width22222222222222=%d\n",stXC_SetWin_Info[MAIN_WINDOW].stCropWin.width);
				  if((stXC_SetWin_Info[MAIN_WINDOW].stCropWin.width==1360)
					  ||((MApp_PCMode_Get_HResolution(MAIN_WINDOW,TRUE)== 1360)
					  &&(MApp_PCMode_Get_VResolution(MAIN_WINDOW,TRUE) == 768)))//�ж�����			
				  { 
					  eResult = VIDEOSCREEN_POINT_TO_POINT;
				  }
				  else
				  {
					  eResult = VIDEOSCREEN_FULL;
					  ST_VIDEO.eAspectRatio = EN_AspectRatio_16X9;
				  }
				  break;
#else
            if(MApi_XC_IsCurrentFrameBufferLessMode()||MApi_XC_IsCurrentRequest_FrameBufferLessMode())
            {
               eResult = VIDEOSCREEN_FULL;
               ST_VIDEO.eAspectRatio = EN_AspectRatio_16X9;
            }
            else
            {
               eResult = VIDEOSCREEN_POINT_TO_POINT;
            }
            break;
#endif
    #endif

    }

    return eResult;
}

static U8 _MApp_Scaler_Resolution_Remapping(XC_SETWIN_INFO *pstXC_SetWin_Info, SCALER_WIN eWindow )
{
    U16 u16HSize, u16VSize, u16InputVFreq;
    U8 u8_Resolution=E_YPbPr480i_60;

    if(IsSrcTypeYPbPr(SYS_INPUT_SOURCE_TYPE(eWindow)))
    {
        u16HSize = MApp_PCMode_Get_HResolution(eWindow,TRUE);
        u16VSize = MApp_PCMode_Get_VResolution(eWindow,TRUE);
    }
    else
    {
        u16HSize = pstXC_SetWin_Info->stCapWin.width;
        u16VSize = pstXC_SetWin_Info->stCapWin.height;
    }
    u16InputVFreq = pstXC_SetWin_Info->u16InputVFreq;

    MSG(printf("_MApp_Scaler_Resolution_Remapping \r\n"));
    MSG(printf(" -> Mode H Size = %d \r\n", u16HSize));
    MSG(printf(" -> Mode V Size = %d \r\n", u16VSize));
    MSG(printf(" -> Mode V Freq = %d \r\n", u16InputVFreq));

    if(IsSrcTypeYPbPr(SYS_INPUT_SOURCE_TYPE(eWindow)))
    {
        switch(g_PcadcModeSetting[eWindow].u8ModeIndex)
        {
            case MD_720x480_60I:
                u8_Resolution = E_YPbPr480i_60;
                MSG(printf(" [YPbPr 480i] \r\n"));
                break;

            case MD_720x480_60P:
                u8_Resolution = E_YPbPr480p_60;
                MSG(printf(" [YPbPr 480p] \r\n"));
                break;

            case MD_720x576_50I:
                u8_Resolution = E_YPbPr576i_50;
                MSG(printf(" [YPbPr 576i] \r\n"));
                break;

            case MD_720x576_50P:
                u8_Resolution = E_YPbPr576p_50;
                MSG(printf(" [YPbPr 576p] \r\n"));
                break;

            case MD_1280x720_60P:
                u8_Resolution = E_YPbPr720p_60;
                MSG(printf(" [YPbPr 720p@60] \r\n"));
                break;

            case MD_1280x720_50P:
                u8_Resolution = E_YPbPr720p_50;
                MSG(printf(" [YPbPr 720p@50] \r\n"));
                break;

            case MD_1280x720_25P:
                u8_Resolution = E_YPbPr720p_25;
                MSG(printf(" [YPbPr 720p@25] \r\n"));
                break;

            case MD_1280x720_30P:
                u8_Resolution = E_YPbPr720p_30;
                MSG(printf(" [YPbPr 720p@30] \r\n"));
                break;

            case MD_1920x1080_60I:
                u8_Resolution = E_YPbPr1080i_60;
                MSG(printf(" [YPbPr 1080i@60] \r\n"));
                break;

            case MD_1920x1080_50I:
                u8_Resolution = E_YPbPr1080i_50;
                MSG(printf(" [YPbPr 1080i@50] \r\n"));
                break;

            case MD_1920x1080_60P:
                u8_Resolution = E_YPbPr1080p_60;
                MSG(printf(" [YPbPr 1080p@60] \r\n"));
                break;

            case MD_1920x1080_50P:
                u8_Resolution = E_YPbPr1080p_50;
                MSG(printf(" [YPbPr 1080p@50] \r\n"));
                break;

            case MD_1920x1080_30P:
                u8_Resolution = E_YPbPr1080p_30;
                MSG(printf(" [YPbPr 1080p@30] \r\n"));
                break;

            case MD_1920x1080_24P:
                u8_Resolution = E_YPbPr1080p_24;
                MSG(printf(" [YPbPr 1080p@24] \r\n"));
                break;

            case MD_1280X1470_50P:
                u8_Resolution = E_YPbPr1470p_50;
                break;

            case MD_1280X1470_60P:
                u8_Resolution = E_YPbPr1470p_60;
                break;

            case MD_1920X2205_24P:
                u8_Resolution = E_YPbPr2205p_24;
                break;

             case MD_1920x1080_25P:
                u8_Resolution = E_YPbPr1080p_25;
                MSG(printf(" [YPbPr 1080p@25] \r\n"));
                break;

           #if (SUPPORT_EURO_HDTV)
            case  MD_1920x1080_50I_EURO:
                u8_Resolution = E_YPbPr1080i_25;
                MSG(printf(" [YPbPr 1080i@25] \r\n"));
                break;

           #endif
            default:
                u8_Resolution = E_YPbPr480i_60;
                MSG(printf(" [YPbPr 480i_60] \r\n"));
                break;
        }
    }
    else if(IsSrcTypeHDMI(SYS_INPUT_SOURCE_TYPE(eWindow)))
    {
        if((u16HSize>=710 && u16HSize<=730) && (u16VSize>=470 && u16VSize<=490))
        {// 720
            if(pstXC_SetWin_Info->bInterlace)
            {// 480i
               u8_Resolution = E_HDMI480i_60;
                MSG(printf(" [HDMI 480i@60] \r\n"));
            }
            else
            {// 480p
               u8_Resolution = E_HDMI480p_60;
                MSG(printf(" [HDMI 480i@60] \r\n"));
            }
        }
        else if((u16HSize>=710 && u16HSize<=730) && (u16VSize>=566 && u16VSize<=586))
        {// 720
            if(pstXC_SetWin_Info->bInterlace)
            {// 576i
               u8_Resolution = E_HDMI576i_50;
                MSG(printf(" [HDMI 576i@50] \r\n"));
            }
            else
            {// 576p
               u8_Resolution = E_HDMI576p_50;
                MSG(printf(" [HDMI 576p@50] \r\n"));
            }
        }
        else if((u16HSize>=1430 && u16HSize<=1450) && (u16VSize>=470 && u16VSize<=490))
        {// 720
            if(pstXC_SetWin_Info->bInterlace)
            {// 480i
               u8_Resolution = E_HDMI1440x480i_60;
                MSG(printf(" [HDMI 1440x480i@60] \r\n"));
            }
            else
            {// 480p
               u8_Resolution = E_HDMI1440x480p_60;
                MSG(printf(" [HDMI 1440x480p@60] \r\n"));
            }
        }
        else if((u16HSize>=1430 && u16HSize<=1450) && (u16VSize>=566 && u16VSize<=586))
        {// 720
            if(pstXC_SetWin_Info->bInterlace)
            {// 576i
               u8_Resolution = E_HDMI1440x576i_50;
                MSG(printf(" [HDMI 1440x576i@50] \r\n"));
            }
            else
            {// 576p
               u8_Resolution = E_HDMI1440x576p_50;
                MSG(printf(" [HDMI 1440x576p@50] \r\n"));
            }
        }
        else if((u16HSize>=1270 && u16HSize<=1290) && (u16VSize>=710 && u16VSize<=730))
        {// 1280
            // 720P
            if( u16InputVFreq > 550 )
            {
               u8_Resolution = E_HDMI720p_60;
                MSG(printf(" [HDMI 720p@60] \r\n"));
            }
            else
            {
                u8_Resolution = E_HDMI720p_50;
                MSG(printf(" [HDMI 720p@50] \r\n"));
            }
        }
        else if((u16HSize>=1910 && u16HSize<=1930) && (u16VSize>=1070 && u16VSize<=1090))
        {// 1920
            if (pstXC_SetWin_Info->bInterlace)
            {//1080i
                if( u16InputVFreq > 550 )
                {
                   u8_Resolution = E_HDMI1080i_60;
                    MSG(printf(" [HDMI 1080i@60] \r\n"));
                }
                else
                {
                    u8_Resolution = E_HDMI1080i_50;
                    MSG(printf(" [HDMI 1080i@50] \r\n"));
                }
            }
            else
            {
                if( u16InputVFreq > 550 )
                {// 1080P (60)
                   u8_Resolution = E_HDMI1080p_60;
                    MSG(printf(" [HDMI 1080p@60] \r\n"));
                }
                else if( u16InputVFreq > 450 )
                {// 1080P (50)
                   u8_Resolution = E_HDMI1080p_50;
                    MSG(printf(" [HDMI 1080p@50] \r\n"));
                }
                else if( u16InputVFreq > 275 )
                {// 1080P (30)
                   u8_Resolution = E_HDMI1080p_30;
                    MSG(printf(" [HDMI 1080p@30] \r\n"));
                }
                else if( u16InputVFreq > 200 )
                {// 1080P (24P)
                   u8_Resolution = E_HDMI1080p_24;
                    MSG(printf(" [HDMI 1080p@24] \r\n"));
                }
            }
        }
        else
        {
         u8_Resolution = E_HDMI_MAX;
            MSG(printf(" [HDMI Unknown mode] \r\n"));
            //  no suitable value given.
            //__ASSERT( 0 );
        }
    }

//    MSG(printf("\r\n _MApp_Scaler_Resolution_Remapping -> u8_Resolution = %d\n",u8_Resolution));

    return u8_Resolution;
}

static U8 _MApp_Scaler_Aspect_Ratio_Remapping(EN_ASPECT_RATIO_TYPE enVideoScreen)
{
    U8 u8_AR_NUM;

    MSG(printf(" Scaler_Aspect_Ratio_Remapping :"));

    switch(enVideoScreen)
    {
        case VIDEOSCREEN_FULL:
            u8_AR_NUM = E_AR_16x9;
            MSG(printf(" [E_AR_16x9] \r\n"));
            break;

        case VIDEOSCREEN_NORMAL:
            u8_AR_NUM = E_AR_4x3;
            MSG(printf(" [E_AR_4x3] \r\n"));
            break;

//        case VIDEOSCREEN_FULL:
//            u8_AR_NUM = E_AR_AUTO;
//            MSG(printf(" [E_AR_AUTO] \r\n"));
//            break;

        case VIDEOSCREEN_PANORAMA:
            u8_AR_NUM = E_AR_Panorama;
            MSG(printf(" [E_AR_Panorama] \r\n"));
            break;

        case VIDEOSCREEN_JUSTSCAN:
            u8_AR_NUM = E_AR_JustScan;
            MSG(printf(" [E_AR_JustScan] \r\n"));
            break;

        case VIDEOSCREEN_ZOOM2:
            u8_AR_NUM = E_AR_Zoom2;
            MSG(printf(" [E_AR_Zoom2] \r\n"));
            break;

        case VIDEOSCREEN_ZOOM1:
            u8_AR_NUM = E_AR_Zoom1;
            MSG(printf(" [E_AR_Zoom1] \r\n"));
            break;

        default:
            u8_AR_NUM = E_AR_AUTO;
            MSG(printf(" [E_AR_AUTO] \r\n"));
            break;

    }

//    MSG(printf("Scaler aspect ratio remap: %u -> %u \n", enVideoScreen, u8_AR_NUM));

    return u8_AR_NUM;

}

void MApp_Scaler_EnableOverScan(BOOLEAN bEnable)
{
    _u8EnableOverScan = bEnable;
}

/// Get current window settings: includes Capture window, Display window
/// and Crop window
void MApp_Scaler_GetWinInfo(XC_SETWIN_INFO* pWindowInfo, SCALER_WIN eWindow)
{
    memcpy((void*)pWindowInfo, (void*)&stXC_SetWin_Info[eWindow],sizeof(XC_SETWIN_INFO));
}


void MApp_Scaler_GetVidWinInfo(MS_VIDEO_Window_Info_EXT *pstWindow_info, SCALER_WIN eWindow)
{
    st_VidWin_Info.stCapWin = stXC_SetWin_Info[eWindow].stCapWin;
    memcpy((void*)pstWindow_info, (void*)&st_VidWin_Info,sizeof(MS_VIDEO_Window_Info_EXT));
}


void MApp_Scaler_SetVidWinInfo(INPUT_SOURCE_TYPE_t enInputSrcType,MS_VIDEO_Window_Info_EXT *pstWindow_info, SCALER_WIN eWindow)
{
    U16 u16HSize, u16VSize;
    U8 u8_AspectRatio;
    U8 u8_Resolution;

    u16HSize = stXC_SetWin_Info[eWindow].stCapWin.width;
    u16VSize = stXC_SetWin_Info[eWindow].stCapWin.height;

    u8_AspectRatio = _MApp_Scaler_Aspect_Ratio_Remapping(stSystemInfo[MAIN_WINDOW].enAspectRatio);

    if( IsSrcTypeYPbPr(enInputSrcType) || IsSrcTypeHDMI(enInputSrcType) )
        u8_Resolution = _MApp_Scaler_Resolution_Remapping( &stXC_SetWin_Info[eWindow], MAIN_WINDOW);
    else
        u8_Resolution = 0;

    printf("Before SetWindow cap H[%d] V[%d], crop: H[%d]-V[%d] L[%d] R[%d] U[%d] D[%d]\n" ,
            st_VidWin_Info.stCapWin.x, st_VidWin_Info.stCapWin.y,
            st_VidWin_Info.u8H_OverScanRatio, st_VidWin_Info.u8V_OverScanRatio,
            _u8H_CropRatio_Left, _u8H_CropRatio_Right,
            _u8V_CropRatio_Up, _u8V_CropRatio_Down);

    st_VidWin_Info.u8H_OverScanRatio = pstWindow_info->u8H_OverScanRatio;
    st_VidWin_Info.u8V_OverScanRatio = pstWindow_info->u8V_OverScanRatio;
    st_VidWin_Info.u8HCrop_Left = pstWindow_info->u8HCrop_Left;
    st_VidWin_Info.u8HCrop_Right = pstWindow_info->u8HCrop_Right;
    st_VidWin_Info.u8VCrop_Up = pstWindow_info->u8VCrop_Up;
    st_VidWin_Info.u8VCrop_Down = pstWindow_info->u8VCrop_Down;
    st_VidWin_Info.stCapWin = pstWindow_info->stCapWin;

    if(IsSrcTypeDTV(enInputSrcType) ||
      (IsSrcTypeStorage(enInputSrcType) && !IsSrcTypeJpeg(enInputSrcType))) // storage type except JPEG
    {
        MSG(printf("not hdmi or dvi\n!!"));

        if(u16HSize <= 750 && u16VSize <= 500)
        {
           if(stXC_SetWin_Info[eWindow].bInterlace)
           {// 480i
                _u16OverscanDtv480iH = st_VidWin_Info.u8H_OverScanRatio;
                _u16OverscanDtv480iV = st_VidWin_Info.u8V_OverScanRatio;
           }
           else
           {// 480p
                _u16OverscanDtv480pH = st_VidWin_Info.u8H_OverScanRatio;
                _u16OverscanDtv480pV = st_VidWin_Info.u8V_OverScanRatio;
           }
        }
        else if(u16HSize <= 750 && u16VSize <= 600)
        {
            if (stXC_SetWin_Info[eWindow].bInterlace)
            {// 576i
                _u16OverscanDtv576iH = st_VidWin_Info.u8H_OverScanRatio;
                _u16OverscanDtv576iV = st_VidWin_Info.u8V_OverScanRatio;
            }
            else
            {// 576p
                _u16OverscanDtv576pH = st_VidWin_Info.u8H_OverScanRatio;
                _u16OverscanDtv576pV = st_VidWin_Info.u8V_OverScanRatio;
            }
        }
        else if(u16HSize <= 1300 && u16VSize <= 750)
        {   //720P
            _u16OverscanDtv720pH = st_VidWin_Info.u8H_OverScanRatio;
            _u16OverscanDtv720pV = st_VidWin_Info.u8V_OverScanRatio;
        }
        else if(u16HSize <= 1950 && u16VSize <= 1200)
        {
            if (stXC_SetWin_Info[eWindow].bInterlace)
            {//1080i
                _u16OverscanDtv1080iH = st_VidWin_Info.u8H_OverScanRatio;
                _u16OverscanDtv1080iV = st_VidWin_Info.u8V_OverScanRatio;
            }
            else
            {// 1080P
                _u16OverscanDtv1080pH = st_VidWin_Info.u8H_OverScanRatio;
                _u16OverscanDtv1080pV = st_VidWin_Info.u8V_OverScanRatio;
            }
        }
        _u8H_OverScanRatio = st_VidWin_Info.u8H_OverScanRatio;
        _u8V_OverScanRatio = st_VidWin_Info.u8V_OverScanRatio;
     }
    else if(IsSrcTypeYPbPr(enInputSrcType))
    {
        YPbPr_WinInfo[u8_Resolution][u8_AspectRatio].u8HCrop_Left = st_VidWin_Info.u8HCrop_Left;
        YPbPr_WinInfo[u8_Resolution][u8_AspectRatio].u8HCrop_Right = st_VidWin_Info.u8HCrop_Right;
        YPbPr_WinInfo[u8_Resolution][u8_AspectRatio].u8VCrop_Up = st_VidWin_Info.u8VCrop_Up;
        YPbPr_WinInfo[u8_Resolution][u8_AspectRatio].u8VCrop_Down = st_VidWin_Info.u8VCrop_Down;

        _u8H_CropRatio_Left = st_VidWin_Info.u8HCrop_Left;
        _u8H_CropRatio_Right = st_VidWin_Info.u8HCrop_Right;
        _u8V_CropRatio_Up = st_VidWin_Info.u8VCrop_Up;
        _u8V_CropRatio_Down = st_VidWin_Info.u8VCrop_Down;
    }
    else if(IsSrcTypeDigitalVD(enInputSrcType))
    {
        //pstVideoWinInfo = &CVBS_WinInfo[mvideo_vd_get_videosystem()][u8_AspectRatio];

        CVBS_WinInfo[mvideo_vd_get_videosystem()][u8_AspectRatio].u8HCrop_Left = st_VidWin_Info.u8HCrop_Left;
        CVBS_WinInfo[mvideo_vd_get_videosystem()][u8_AspectRatio].u8HCrop_Right = st_VidWin_Info.u8HCrop_Right;
        CVBS_WinInfo[mvideo_vd_get_videosystem()][u8_AspectRatio].u8VCrop_Up = st_VidWin_Info.u8VCrop_Up;
        CVBS_WinInfo[mvideo_vd_get_videosystem()][u8_AspectRatio].u8VCrop_Down = st_VidWin_Info.u8VCrop_Down;

        _u8H_CropRatio_Left = st_VidWin_Info.u8HCrop_Left;
        _u8H_CropRatio_Right = st_VidWin_Info.u8HCrop_Right;
        _u8V_CropRatio_Up = st_VidWin_Info.u8VCrop_Up;
        _u8V_CropRatio_Down = st_VidWin_Info.u8VCrop_Down;
    }
#if (INPUT_HDMI_VIDEO_COUNT>0)
    //else if(IsSrcTypeHDMI(enInputSrcType) && (g_HdmiPollingStatus.bIsHDMIMode == TRUE))
    else if(IsSrcTypeHDMI(enInputSrcType))
    {  // make sure this is HDMI mode, not DVI mode
        HDMI_WinInfo[u8_Resolution][u8_AspectRatio].u8HCrop_Left = st_VidWin_Info.u8HCrop_Left;
        HDMI_WinInfo[u8_Resolution][u8_AspectRatio].u8HCrop_Right = st_VidWin_Info.u8HCrop_Right;
        HDMI_WinInfo[u8_Resolution][u8_AspectRatio].u8VCrop_Up = st_VidWin_Info.u8VCrop_Up;
        HDMI_WinInfo[u8_Resolution][u8_AspectRatio].u8VCrop_Down = st_VidWin_Info.u8VCrop_Down;

        _u8H_CropRatio_Left = st_VidWin_Info.u8HCrop_Left;
        _u8H_CropRatio_Right = st_VidWin_Info.u8HCrop_Right;
        _u8V_CropRatio_Up = st_VidWin_Info.u8VCrop_Up;
        _u8V_CropRatio_Down = st_VidWin_Info.u8VCrop_Down;
    }
#endif
    else
    {
        _u8H_CropRatio_Left = 0;
        _u8H_CropRatio_Right = 0;
        _u8V_CropRatio_Up = 0;
        _u8V_CropRatio_Down = 0;
    }

    printf("After SetWindow cap H[%d] V[%d], crop: H[%d]-V[%d] L[%d] R[%d] U[%d] D[%d]\n"
    ,st_VidWin_Info.stCapWin.x,st_VidWin_Info.stCapWin.y
        ,st_VidWin_Info.u8H_OverScanRatio,st_VidWin_Info.u8V_OverScanRatio
            ,_u8H_CropRatio_Left,_u8H_CropRatio_Right
                ,_u8V_CropRatio_Up,_u8V_CropRatio_Down );
}

//-----------------------------------------------------------------------------
// Get Over Scan Ratio from table
//-----------------------------------------------------------------------------
void MApp_Scaler_GetOverScan(INPUT_SOURCE_TYPE_t enInputSrcType, XC_SETWIN_INFO *pstXC_SetWin_Info)
{
    U16 u16HSize, u16VSize;
    U8 u8_AspectRatio;
    U8 u8_Resolution;
    //MS_VIDEO_Window_Info *pstVideoWinInfo;

    u16HSize = pstXC_SetWin_Info->stCapWin.width;
    u16VSize = pstXC_SetWin_Info->stCapWin.height;

    u8_AspectRatio = _MApp_Scaler_Aspect_Ratio_Remapping(stSystemInfo[MAIN_WINDOW].enAspectRatio);

    if( IsSrcTypeYPbPr(enInputSrcType) || IsSrcTypeHDMI(enInputSrcType) )
        u8_Resolution = _MApp_Scaler_Resolution_Remapping( pstXC_SetWin_Info, MAIN_WINDOW );
    else
        u8_Resolution = 0;

    //clear static value
    _u8H_CropRatio_Left = st_VidWin_Info.u8HCrop_Left = 0;
    _u8H_CropRatio_Right = st_VidWin_Info.u8HCrop_Right = 0;
    _u8V_CropRatio_Up = st_VidWin_Info.u8VCrop_Up = 0;
    _u8V_CropRatio_Down = st_VidWin_Info.u8VCrop_Down = 0;
    _u8H_OverScanRatio = st_VidWin_Info.u8H_OverScanRatio = 0;
    _u8V_OverScanRatio = st_VidWin_Info.u8V_OverScanRatio = 0;

    //printf("Vidoe AR = %bx,%bx,Res = %bx\n",stSystemInfo.enAspectRatio,u8_AspectRatio,u8_Resolution);

    if(IsSrcTypeDTV(enInputSrcType) ||
      (IsSrcTypeStorage(enInputSrcType) && !IsSrcTypeJpeg(enInputSrcType))) // storage type except JPEG
    {
        MSG(printf("not hdmi or dvi\n!!"));
        if(u16HSize <= 750 && u16VSize <= 500)
        {
           if(pstXC_SetWin_Info->bInterlace)
           {// 480i
                _u8H_OverScanRatio = _u16OverscanDtv480iH;
                _u8V_OverScanRatio = _u16OverscanDtv480iV;
           }
           else
           {// 480p
                _u8H_OverScanRatio = _u16OverscanDtv480pH;
                _u8V_OverScanRatio = _u16OverscanDtv480pV;
           }
        }
        else if(u16HSize <= 750 && u16VSize <= 600)
        {
            if (pstXC_SetWin_Info->bInterlace)
            {// 576i
                _u8H_OverScanRatio = _u16OverscanDtv576iH;
                _u8V_OverScanRatio = _u16OverscanDtv576iV;
            }
            else
            {// 576p
                _u8H_OverScanRatio = _u16OverscanDtv576pH;
                _u8V_OverScanRatio = _u16OverscanDtv576pV;
            }
        }
        else if(u16HSize <= 1300 && u16VSize <= 750)
        {   //720P
            _u8H_OverScanRatio = _u16OverscanDtv720pH;
            _u8V_OverScanRatio = _u16OverscanDtv720pV;
        }
        else if(u16HSize <= 1950 && u16VSize <= 1200)
        {
            if (pstXC_SetWin_Info->bInterlace)
            {//1080i
                _u8H_OverScanRatio = _u16OverscanDtv1080iH;
                _u8V_OverScanRatio = _u16OverscanDtv1080iV;
            }
            else
            {// 1080P
                _u8H_OverScanRatio = _u16OverscanDtv1080pH;
                _u8V_OverScanRatio = _u16OverscanDtv1080pV;
            }
        }

        st_VidWin_Info.u8H_OverScanRatio =  _u8H_OverScanRatio;
        st_VidWin_Info.u8V_OverScanRatio =  _u8V_OverScanRatio;

     }
    else if(IsSrcTypeYPbPr(enInputSrcType))
    {
        _u8H_CropRatio_Left = YPbPr_WinInfo[u8_Resolution][u8_AspectRatio].u8HCrop_Left;
        _u8H_CropRatio_Right = YPbPr_WinInfo[u8_Resolution][u8_AspectRatio].u8HCrop_Right;
        _u8V_CropRatio_Up = YPbPr_WinInfo[u8_Resolution][u8_AspectRatio].u8VCrop_Up;
        _u8V_CropRatio_Down = YPbPr_WinInfo[u8_Resolution][u8_AspectRatio].u8VCrop_Down;
    }
    else if(IsSrcTypeDigitalVD(enInputSrcType))
    {
        //pstVideoWinInfo = &CVBS_WinInfo[mvideo_vd_get_videosystem()][u8_AspectRatio];

        _u8H_CropRatio_Left = CVBS_WinInfo[mvideo_vd_get_videosystem()][u8_AspectRatio].u8HCrop_Left;
        _u8H_CropRatio_Right = CVBS_WinInfo[mvideo_vd_get_videosystem()][u8_AspectRatio].u8HCrop_Right;
        _u8V_CropRatio_Up = CVBS_WinInfo[mvideo_vd_get_videosystem()][u8_AspectRatio].u8VCrop_Up;
        _u8V_CropRatio_Down = CVBS_WinInfo[mvideo_vd_get_videosystem()][u8_AspectRatio].u8VCrop_Down;
    }
#if (INPUT_HDMI_VIDEO_COUNT>0)
   else if(IsSrcTypeHDMI(enInputSrcType) && (g_HdmiPollingStatus.bIsHDMIMode == TRUE)&&(u8_Resolution<E_HDMI_MAX))
    //else if(IsSrcTypeHDMI(enInputSrcType))
    {  // make sure this is HDMI mode, not DVI mode

       #if ENABLE_CUS_HDMI_MODE
        if((stGenSetting.g_SysSetting.bIsHDMIVideoMode == FALSE) && (MApp_Scaler_CheckHDMIModeAvailable() == TRUE))
        {
            printf("\r\n HDMI video timming and HDMI MODE off! \n");
            _u8H_CropRatio_Left = 0;
            _u8H_CropRatio_Right = 0;
            _u8V_CropRatio_Up = 0;
            _u8V_CropRatio_Down = 0;
        }
        else
       #endif
        {
            _u8H_CropRatio_Left = HDMI_WinInfo[u8_Resolution][u8_AspectRatio].u8HCrop_Left;
            _u8H_CropRatio_Right = HDMI_WinInfo[u8_Resolution][u8_AspectRatio].u8HCrop_Right;
            _u8V_CropRatio_Up = HDMI_WinInfo[u8_Resolution][u8_AspectRatio].u8VCrop_Up;
            _u8V_CropRatio_Down = HDMI_WinInfo[u8_Resolution][u8_AspectRatio].u8VCrop_Down;
        }


        /*printf("HDMI src type [%bu][%bu]\n\n===========",u8_Resolution, u8_AspectRatio);
        printf("HDMI src type !==========\n\nCropRatio Hstart, Vstart, left, right, up, down = 0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x\n",
               HDMI_WinInfo[u8_Resolution][u8_AspectRatio].u16H_CapStart,
               HDMI_WinInfo[u8_Resolution][u8_AspectRatio].u16V_CapStart,
               HDMI_WinInfo[u8_Resolution][u8_AspectRatio].u8HCrop_Left,
               HDMI_WinInfo[u8_Resolution][u8_AspectRatio].u8HCrop_Right,
               HDMI_WinInfo[u8_Resolution][u8_AspectRatio].u8VCrop_Up,
               HDMI_WinInfo[u8_Resolution][u8_AspectRatio].u8VCrop_Down
               );*/

    }
#endif
    else
    {
        _u8H_CropRatio_Left = 0;
        _u8H_CropRatio_Right = 0;
        _u8V_CropRatio_Up = 0;
        _u8V_CropRatio_Down = 0;
    }

    st_VidWin_Info.u8H_OverScanRatio = _u8H_OverScanRatio;
    st_VidWin_Info.u8V_OverScanRatio = _u8V_OverScanRatio;
    st_VidWin_Info.u8HCrop_Left = _u8H_CropRatio_Left;
    st_VidWin_Info.u8HCrop_Right = _u8H_CropRatio_Right;
    st_VidWin_Info.u8VCrop_Up = _u8V_CropRatio_Up;
    st_VidWin_Info.u8VCrop_Down = _u8V_CropRatio_Down;

}

//-----------------------------------------------------------------------------
static void _MApp_Scaler_CalculateOverScan(INPUT_SOURCE_TYPE_t enInputSrcType, MS_WINDOW_TYPE *pstCropWin)
{
    U32 u32Temp, u32Temp2;
    if(IsSrcTypeDTV(enInputSrcType))
    {
        if (_u8H_OverScanRatio) // Horizontal
        {
            u32Temp = ((U32)pstCropWin->width * (U32)_u8H_OverScanRatio + 500 )/OVERSCAN_RATIO;
            pstCropWin->x += (U16) u32Temp;
            pstCropWin->width = pstCropWin->width - (U16)u32Temp*2;
        }

        if (_u8V_OverScanRatio) // Vertical
        {
            u32Temp = ((U32)pstCropWin->height * (U32)_u8V_OverScanRatio + 500 )/OVERSCAN_RATIO;
            pstCropWin->y += (U16) u32Temp;
            pstCropWin->height = pstCropWin->height - (U16)u32Temp*2;
        }
        //printf("OVS H=%bx,V=%bx\n",_u8H_OverScanRatio,_u8V_OverScanRatio);
    }
    else
    {
        MSG(printf("OVS L=%u, R=%u\n", _u8H_CropRatio_Left, _u8H_CropRatio_Right));
        MSG(printf("OVS U=%bx,D=%bx\n",_u8V_CropRatio_Up, _u8V_CropRatio_Down));

        // Horizontal
        u32Temp = u32Temp2 = 0;
        if (_u8H_CropRatio_Left)
            u32Temp = ((U32)pstCropWin->width * (U32)_u8H_CropRatio_Left + 500 )/OVERSCAN_RATIO;

        if (_u8H_CropRatio_Right)
            u32Temp2 = ((U32)pstCropWin->width * (U32)_u8H_CropRatio_Right + 500 )/OVERSCAN_RATIO;

        pstCropWin->x += (U16) u32Temp;
        pstCropWin->width -= (U16)(u32Temp + u32Temp2);

        // Vertical
        u32Temp = u32Temp2 = 0;
        if (_u8V_CropRatio_Up)
            u32Temp = ((U32)pstCropWin->height * (U32)_u8V_CropRatio_Up + 500 )/OVERSCAN_RATIO;

        if (_u8V_CropRatio_Down)
            u32Temp2 = ((U32)pstCropWin->height * (U32)_u8V_CropRatio_Down + 500 )/OVERSCAN_RATIO;

        pstCropWin->y += (U16) u32Temp;
        pstCropWin->height -= (U16)(u32Temp + u32Temp2);
    }

  #if (ENABLE_SZ_FACTORY_OVER_SCAN_FUNCTION)
    MApp_LoadOverScanData();

    MSG(printf("0-pstCropWin{%d, %d, %d, %d}\n", pstCropWin->x, pstCropWin->y, pstCropWin->width, pstCropWin->height));
    MSG(printf("g_OverScan{%d, %d, %d, %d}\n", g_OverScan.osOffsetX, g_OverScan.osOffsetY, g_OverScan.osOffsetWidth, g_OverScan.osOffsetHeight));

    if(((S16)(pstCropWin->x) + g_OverScan.osOffsetX) <= 0)
        pstCropWin->x = 0;
    else
        pstCropWin->x += g_OverScan.osOffsetX;

    if(((S16)(pstCropWin->y) + g_OverScan.osOffsetY) <= 0)
       pstCropWin->y = 0;
    else
       pstCropWin->y += g_OverScan.osOffsetY;

    if(((S16)(pstCropWin->width) + g_OverScan.osOffsetWidth) <= 0)
        pstCropWin->width= 0;
    else
        pstCropWin->width+= g_OverScan.osOffsetWidth;

    if(((S16)(pstCropWin->height) + g_OverScan.osOffsetHeight) <= 0)
        pstCropWin->height= 0;
    else
        pstCropWin->height+= g_OverScan.osOffsetHeight;

    MSG(printf("1-pstCropWin{%d, %d, %d, %d}\n", pstCropWin->x, pstCropWin->y, pstCropWin->width, pstCropWin->height));
#endif

}

void MApp_Scaler_CalculateAspectRatio(XC_SETWIN_INFO *pstXC_SetWin_Info,
                                       EN_ASPECT_RATIO_TYPE enVideoScreen,
                                       MS_WINDOW_TYPE *pstCropWin,
                                       MS_WINDOW_TYPE *pstDstWin)
{
    U16 u16Temp;

    //restore according to my setting history
    MDrv_PQ_Set_PointToPoint(pstXC_SetWin_Info, FALSE,  PQ_MAIN_WINDOW);

    if ( enVideoScreen != VIDEOSCREEN_PANORAMA)
    {
        _bEnNonLinearScaling[MAIN_WINDOW] = FALSE;
    }

    switch( enVideoScreen )
    {
        case VIDEOSCREEN_PROGRAM_16X9:
            break;
        case VIDEOSCREEN_PROGRAM_4X3:
        {
            u16Temp = (U32)pstDstWin->height * 4 / 3;
            if (u16Temp <= pstDstWin->width) // H:V >= 4:3
            {
                pstDstWin->x += (pstDstWin->width - u16Temp) / 2;
                pstDstWin->width = u16Temp;
            }
            else // H:V <= 4:3
            {
                u16Temp = (U32)pstDstWin->width * 3 / 4;
                pstDstWin->y += (pstDstWin->height - u16Temp) / 2;
                pstDstWin->height = u16Temp;
            }
        }
            break;

        case VIDEOSCREEN_FULL:
            //printf("VIDEOSCREEN_FULL\n");
            pstDstWin->x = 0;
            pstDstWin->y = 0;
            pstDstWin->width = g_IPanel.Width();
            pstDstWin->height = g_IPanel.Height();
        default:
            break;

        case VIDEOSCREEN_ZOOM1:
            MApp_Scaler_ResetZoomFactor(EN_AspectRatio_Zoom1);
            _MApp_Scaler_ZoomCropWin(pstCropWin);
            break;
        case VIDEOSCREEN_ZOOM2:
            MApp_Scaler_ResetZoomFactor(EN_AspectRatio_Zoom2);
            _MApp_Scaler_ZoomCropWin(pstCropWin);
            break;
        case VIDEOSCREEN_PROGRAM: // Set Capture/Crop/Display window by function directly
            _MApp_Scaler_ZoomCropWin(pstCropWin);
            break;

        case VIDEOSCREEN_CINEMA:
            u16Temp =( ( U32 ) pstCropWin->height * ARC_CINEMA_OVS_V) / 1000;

            pstCropWin->y += u16Temp;
            pstCropWin->height = ( pstCropWin->height - 2 * u16Temp );

            u16Temp = (( U32 ) pstCropWin->width * ARC_CINEMA_OVS_H) / 1000;//
            pstCropWin->x += u16Temp;
            pstCropWin->width = ( pstCropWin->width - 2 * u16Temp );
            break;

        case VIDEOSCREEN_14by9:
            u16Temp = ((U32) pstCropWin->height * ARC_14X19_OVS_UP + 500) / 1000;
            pstCropWin->y += u16Temp;

            u16Temp += ((U32) pstCropWin->height * ARC_14X19_OVS_DOWN + 500) / 1000;
            pstCropWin->height -= (u16Temp);

            u16Temp = (U32)pstDstWin->height * 14 / 9;
            if (u16Temp <= pstDstWin->width) // H:V >= 14:9
            {
                pstDstWin->x += (pstDstWin->width - u16Temp) / 2;
                pstDstWin->width = u16Temp;
                pstDstWin->width = (pstDstWin->width + 1) & ~1;
            }
            else // H:V <= 4:3
            {
                u16Temp = (U32)pstDstWin->width * 9 / 14;
                pstDstWin->y += (pstDstWin->height - u16Temp) / 2;
                pstDstWin->height = u16Temp;
            }
            break;

        case VIDEOSCREEN_16by9_SUBTITLE: // �W?��1/8�A�i?�A�U?�O�d���r��
            pstCropWin->y += pstCropWin->height * 1 / 8;
            pstCropWin->height = pstCropWin->height * 7 / 8; // * 420 / 480;

            u16Temp = (U32)pstDstWin->height * 32 / 21; // 640x420 => 1097x720 Display
            if (u16Temp <= pstDstWin->width) // H:V >= 32:21
            {
                pstDstWin->x += (pstDstWin->width - u16Temp) / 2;
                pstDstWin->width = u16Temp;
            }
            else // H:V <= 32:21
            {
                u16Temp = (U32)pstDstWin->width * 21 / 32;
                pstDstWin->y += (pstDstWin->height - u16Temp) / 2;
                pstDstWin->height = u16Temp;
            }
            break;

        case VIDEOSCREEN_PANORAMA:
            _bEnNonLinearScaling[MAIN_WINDOW] = TRUE;
            break;

        case VIDEOSCREEN_NORMAL:
#if 0// this is sample code for PointtoPoint.
            if(MDrv_PQ_Check_PointToPoint_Condition(pstXC_SetWin_Info, PQ_MAIN_WINDOW))
            {
                MDrv_PQ_Set_PointToPoint(pstXC_SetWin_Info, TRUE, pstCropWin, pstDstWin, PQ_MAIN_WINDOW);
            }
            else
#endif
            if ((g_IPanel.AspectRatio()==E_PNL_ASPECT_RATIO_WIDE))
            {
                u16Temp = (U32)pstDstWin->height * 4 / 3;
                if (u16Temp <= pstDstWin->width) // H:V >= 4:3
                {
                    pstDstWin->x += (pstDstWin->width - u16Temp) / 2;
                    pstDstWin->width = u16Temp;
                }
                else // H:V <= 4:3
                {
                    u16Temp = (U32)pstDstWin->width * 3 / 4;
                    pstDstWin->y += (pstDstWin->height - u16Temp) / 2;
                    pstDstWin->height = u16Temp;
                }
            }
            else
            {
                u16Temp = (U32)pstDstWin->width * 9 / 16;
                if(u16Temp <= pstDstWin->width) // H:V <= 16:9
                {
                    pstDstWin->y += (pstDstWin->height - u16Temp)/2;
                    pstDstWin->height = u16Temp;
                }
                else// H:V > 16:9
                {
                    u16Temp = (U32) pstDstWin->width * 16/ 9;
                    pstDstWin->x += (pstDstWin->width - u16Temp)/2;
                    pstDstWin->width = u16Temp;
                }
            }
            break;

        case VIDEOSCREEN_LETTERBOX: // �W�U�d�¡A16:9 Display
            u16Temp = (U32)pstDstWin->width * 9 / 16;
            pstDstWin->y += (pstDstWin->height - u16Temp) / 2;
            pstDstWin->height = u16Temp;
            break;

        case VIDEOSCREEN_WSS_16by9:// first cut 1/8 size of top and bottom and then expand to full screen
            pstCropWin->y += pstCropWin->height * 1 / 8;
            pstCropWin->height = pstCropWin->height * 6 / 8;
            break;

    #if  (DISPLAY_LOGO)
        case VIDEOSCREEN_ORIGIN:
            break;
    #endif

        case VIDEOSCREEN_MM_CAL_BY_VIDEOPLAYER:    // Keep source H/V ratio and scale to fit panel
            MSG_MOVIE(printf("\nVIDEOSCREEN_MM_CAL_BY_VIDEOPLAYER"));
            // Direct use videoplayer's dst window
            break;

        case VIDEOSCREEN_MM_KEEP_RATIO_AND_SCALE:    // Keep source H/V ratio and scale to fit panel
            MSG_MOVIE(printf("\nVIDEOSCREEN_MM_KEEP_RATIO_AND_SCALE"));
            // Direct use videoplayer's dst window
            break;

        case VIDEOSCREEN_MM_FULL:    // H and V scale to fit panel
            MSG_MOVIE(printf("VIDEOSCREEN_MM_FULL\n"));
            pstDstWin->x = 0;
            pstDstWin->y = 0;
            pstDstWin->width = g_IPanel.Width();
            pstDstWin->height = g_IPanel.Height();
            break;

        case VIDEOSCREEN_MM_1_1:     // Bypass scale
            MSG_MOVIE(printf("VIDEOSCREEN_MM_1_1\n"));
            pstDstWin->width = pstCropWin->width;
            if( pstDstWin->width > g_IPanel.Width() )
                pstDstWin->width = g_IPanel.Width();
            pstDstWin->height = pstCropWin->height;
            if( pstDstWin->height > g_IPanel.Height() )
                pstDstWin->height = g_IPanel.Height();
            pstDstWin->x = (g_IPanel.Width()-pstDstWin->width)/2;
            pstDstWin->y = (g_IPanel.Height()-pstDstWin->height)/2;
            break;

        case VIDEOSCREEN_MM_16_9:    // Display window: H:V=16:9
            MSG_MOVIE(printf("VIDEOSCREEN_MM_16_9\n"));
            if( g_IPanel.AspectRatio() == E_PNL_ASPECT_RATIO_WIDE )
            {
                pstDstWin->x = 0;
                pstDstWin->y = 0;
                pstDstWin->width = g_IPanel.Width();
                pstDstWin->height = g_IPanel.Height();
            }
            else
            {
                if( g_IPanel.Width()*9 > g_IPanel.Height()*16 )
                {
                    pstDstWin->height = g_IPanel.Height();
                    pstDstWin->y = 0;
                    pstDstWin->width = g_IPanel.Height()*16/9;
                    pstDstWin->x = (g_IPanel.Width()-pstDstWin->width)/2;
                }
                else
                {
                    pstDstWin->width = g_IPanel.Width();
                    pstDstWin->x = 0;
                    pstDstWin->height = g_IPanel.Width()*9/16;
                    pstDstWin->y = (g_IPanel.Height()-pstDstWin->height)/2;
                }
            }
            break;

        case VIDEOSCREEN_MM_4_3:     // Display window: H:V=4:3
            MSG_MOVIE(printf("VIDEOSCREEN_MM_4_3\n"));
            if( g_IPanel.Width()*3 > g_IPanel.Height()*4 )
            {
                pstDstWin->height = g_IPanel.Height();
                pstDstWin->y = 0;
                pstDstWin->width = g_IPanel.Height()*4/3;
                pstDstWin->x = (g_IPanel.Width()-pstDstWin->width)/2;
            }
            else
            {
                pstDstWin->width = g_IPanel.Width();
                pstDstWin->x = 0;
                pstDstWin->height = g_IPanel.Width()*3/4;
                pstDstWin->y = (g_IPanel.Height()-pstDstWin->height)/2;
            }
            break;

        case VIDEOSCREEN_MM_ZOOM1:   // TO BE defined
            MSG_MOVIE(printf("VIDEOSCREEN_MM_ZOOM1 - todo\n"));
            break;

        case VIDEOSCREEN_MM_ZOOM2:   // TO BE defined
            MSG_MOVIE(printf("VIDEOSCREEN_MM_ZOOM2 - todo\n"));
            break;
        case VIDEOSCREEN_POINT_TO_POINT:
       #if 1
            if(MDrv_PQ_Check_PointToPoint_Condition(pstXC_SetWin_Info, PQ_MAIN_WINDOW))
            {
                MDrv_PQ_Set_PointToPoint(pstXC_SetWin_Info, TRUE, PQ_MAIN_WINDOW);
            }
      #else
           if((pstCropWin->width <= PANEL_WIDTH) && (pstCropWin->height <= PANEL_HEIGHT))
           {
               pstDstWin->x = (PANEL_WIDTH - pstCropWin->width)/2;
               pstDstWin->width = pstCropWin->width;
               pstDstWin->y = (PANEL_HEIGHT - pstCropWin->height)/2;
               pstDstWin->height = pstCropWin->height;
           }
      #endif
            break;
    }

}

void MApp_Scaler_Adjust_OverscanRatio_RFBL(INPUT_SOURCE_TYPE_t enInputSourceType,
                                        XC_SETWIN_INFO *pstXC_SetWin_Info)
{
    if (_u8EnableOverScan)
    {
        #if ENABLE_CUS_HDMI_MODE
        if(IsHDMIInUse() && (stGenSetting.g_SysSetting.bIsHDMIVideoMode == FALSE) && (MApp_Scaler_CheckHDMIModeAvailable() == TRUE))
        {
            // do nothing
        }
        else
        #endif
        {
            MApp_Scaler_GetOverScan(enInputSourceType, pstXC_SetWin_Info);
            _MApp_Scaler_CalculateOverScan(enInputSourceType,&(pstXC_SetWin_Info->stCapWin));
        }
    }
}
void MApp_Scaler_Adjust_OverscanRatio(INPUT_SOURCE_TYPE_t enInputSourceType,
                                   XC_SETWIN_INFO *pstXC_SetWin_Info)
{
    if (_u8EnableOverScan && (!MDrv_PQ_Get_PointToPoint(PQ_MAIN_WINDOW)))
    {
        #if ENABLE_CUS_HDMI_MODE
        if(IsHDMIInUse() && (stGenSetting.g_SysSetting.bIsHDMIVideoMode == FALSE) && (MApp_Scaler_CheckHDMIModeAvailable() == TRUE))
        {
            // do nothing
        }
        else
        #endif
        {
            MApp_Scaler_GetOverScan(enInputSourceType, pstXC_SetWin_Info);
            _MApp_Scaler_CalculateOverScan(enInputSourceType,&(pstXC_SetWin_Info->stCropWin));
        }
    }

#if ENABLE_3D_PROCESS
        MApp_Scaler_Adjust_3D_CropWin(&(pstXC_SetWin_Info->stCropWin));
#endif

}

void MApp_Scaler_Adjust_AspectRatio(XC_SETWIN_INFO *pstXC_SetWin_Info,
                                                EN_ASPECT_RATIO_TYPE enVideoScreen,
                                                MS_WINDOW_TYPE *pstCropWin,
                                                MS_WINDOW_TYPE *pstDstWin,
                                                SRC_RATIO_INFO *pstSrcRatioInfo)
{
    NEWCROPMSG(printf("Adjust_AspectRatio:%bx,(CropWin:%u,%u,%u,%u)\n",
                       enVideoScreen,pstCropWin->x,pstCropWin->y,pstCropWin->width,pstCropWin->height));

    if( MApi_XC_IsCurrentFrameBufferLessMode() )
    {
        //FBL mode can not do overscan and cropping.
        MApp_Scaler_EnableOverScan(FALSE);

        if( IsStorageInUse() )
        {
            switch( enVideoScreen )
            {
                case VIDEOSCREEN_MM_4_3:
                    // Do nothing
                    break;

                default:
                    enVideoScreen = VIDEOSCREEN_FULL;
                    NEWCROPMSG(printf("Force enVideoScreen = VIDEOSCREEN_FULL\n"));
                    break;
            }
        }
	 else if(IsDTVInUse())
         {
            switch( enVideoScreen )
            {
                case VIDEOSCREEN_NORMAL:
                case VIDEOSCREEN_FULL:
                    // Do nothing
                    break;

                default:
                    enVideoScreen = VIDEOSCREEN_FULL;
                    ST_VIDEO.eAspectRatio = EN_AspectRatio_16X9;
                    (printf("Force enVideoScreen = VIDEOSCREEN_FULL\n"));
                    break;
            }
        }
        else if ( IsVgaInUse()
              #if (INPUT_HDMI_VIDEO_COUNT > 0)
               || ( IsHDMIInUse()&& !g_HdmiPollingStatus.bIsHDMIMode )
              #endif
                )
        {
            switch( enVideoScreen )
            {
                case VIDEOSCREEN_NORMAL:
                case VIDEOSCREEN_FULL:
                    // Do nothing
                    break;

                case VIDEOSCREEN_POINT_TO_POINT:
                  #if (MEMORY_MAP <= MMAP_32MB)
		    #if 0//VGA_HDMI_YUV_POINT_TO_POINT
                    if (MDrv_PQ_Get_HDMIPTPMode())
                    {
                        enVideoScreen = VIDEOSCREEN_POINT_TO_POINT;
                    }
                    else
                  #endif
                  #endif
                    {
                        enVideoScreen = VIDEOSCREEN_FULL;
                        ST_VIDEO.eAspectRatio = EN_AspectRatio_16X9;
                    }
                    break;

                default:
                    enVideoScreen = VIDEOSCREEN_FULL;
                    ST_VIDEO.eAspectRatio = EN_AspectRatio_16X9;
                    break;
            }
        }
        else
        {
            if( enVideoScreen != VIDEOSCREEN_NORMAL )
            {
                enVideoScreen = VIDEOSCREEN_FULL;
            }
        }
    }

    if( MApi_XC_IsCurrentRequest_FrameBufferLessMode())
    {
        //FBL mode can not do overscan and cropping.
        MApp_Scaler_EnableOverScan(FALSE);

 #if (INPUT_HDMI_VIDEO_COUNT > 0)
      if (IsHDMIInUse()&& (g_HdmiPollingStatus.bIsHDMIMode==TRUE))
      {
            switch( enVideoScreen )
            {
                case VIDEOSCREEN_NORMAL:
                case VIDEOSCREEN_FULL:
                    // Do nothing
                    break;

                case VIDEOSCREEN_POINT_TO_POINT:
                  #if (MEMORY_MAP <= MMAP_32MB)
		    #if 0//VGA_HDMI_YUV_POINT_TO_POINT
                    if (MDrv_PQ_Get_HDMIPTPMode())
                    {
                        enVideoScreen = VIDEOSCREEN_POINT_TO_POINT;
                        printf("Force enVideoScreen = VIDEOSCREEN_POINT_TO_POINT\n");
                    }
                    else
                  #endif
                  #endif
                    {
                        enVideoScreen = VIDEOSCREEN_FULL;
                        ST_VIDEO.eAspectRatio = EN_AspectRatio_16X9;
                        printf("Force enVideoScreen = EN_AspectRatio_16X9\n");
                    }
                    break;

                default:
                    enVideoScreen = VIDEOSCREEN_FULL;
                    ST_VIDEO.eAspectRatio = EN_AspectRatio_16X9;
                    printf("Force enVideoScreen = VIDEOSCREEN_FULL\n");
                    break;
            }
     }
#endif
    }

    if( IsSrcTypeDTV(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)) &&
        (enVideoScreen == VIDEOSCREEN_PROGRAM           ||
          enVideoScreen == VIDEOSCREEN_PROGRAM_4X3    ||
            enVideoScreen == VIDEOSCREEN_PROGRAM_16X9   ||
            enVideoScreen == VIDEOSCREEN_PROGRAM_14X9)
       )
    {
        // Scene Aspec Ratio
    #if (MHEG5_ENABLE)
        if(msAPI_MHEG5_IsRunning())
        {
            if(msAPI_MHEG5_CalcSceneAspectRatio(pstDstWin))
            {
                NEWCROPMSG(printf("    |1.GetARC:SCENE!\n"));
            }
            else if( msAPI_MHEG5_IsIFrameExist() || !g_MHEG5Video.bHaveVideo)// || (!msAPI_MHEG5_VID_IsFullScreen()))
            {
                MS_WINDOW_TYPE tmpWin;
                MApp_Scaler_CalculateAspectRatio(pstXC_SetWin_Info, enVideoScreen,&tmpWin,pstDstWin);

                NEWCROPMSG(printf("    |1.GetARC:IFRAME or No Video or non-Full screen\n"));
            }
            else
            {
                NEWCROPMSG(printf("    | 1.GetARC:AFD!\n"));
                msAPI_Picture_CalculateAFDWindow(pstXC_SetWin_Info,enVideoScreen,pstCropWin,pstDstWin, pstSrcRatioInfo);
            }
        }
        else
    #endif
        {

            NEWCROPMSG(printf("    | 1.GetARC:AFD!\n"));
            msAPI_Picture_CalculateAFDWindow(pstXC_SetWin_Info,enVideoScreen,pstCropWin,pstDstWin, pstSrcRatioInfo);
        }
    }
    else
    {   // UI ARC
#if(ENABLE_USERARC_WITH_AFD == ENABLE)
        MS_WINDOW_TYPE tmpDstWin;
        tmpDstWin = *pstDstWin;
        msAPI_Picture_CalculateAFDWindow(pstXC_SetWin_Info, enVideoScreen,pstCropWin,&tmpDstWin,pstSrcRatioInfo);

#endif
        MApp_Scaler_CalculateAspectRatio(pstXC_SetWin_Info, enVideoScreen,pstCropWin,pstDstWin);
    }
}

void MApp_Scaler_AlignWindow(MS_WINDOW_TYPE *pWindow, U16 u16AlignX, U16 u16AlignY)
{
    U16 u16temp;
    u16temp = ((pWindow->x + u16AlignX-1) & (~(u16AlignX-1))) - pWindow->x;
    pWindow->x += u16temp;
    pWindow->width -= (u16temp*2);

    u16temp = ((pWindow->y + u16AlignY-1) & (~(u16AlignY-1))) - pWindow->y;
    pWindow->y += u16temp;
    pWindow->height -= (u16temp*2);
}

///////////////////////////////////////////////////////////
/// Scaler MainWin Handler
///////////////////////////////////////////////////////////

/*
    Parameter 'Src' comes from PathSyncEvent.
    Setup scaler main window when sync event happen.
*/
void MApp_Scaler_MainWindowSyncEventHandler(INPUT_SOURCE_TYPE_t src, void* para)
{
    UNUSED(src); UNUSED(para);

    //printf("SyncEventHandler()\n");
    CAL_TIME_FUNC_START();

    stSystemInfo[MAIN_WINDOW].enAspectRatio = MApp_Scaler_GetAspectRatio(ST_VIDEO.eAspectRatio);

    // panelTiming is determined by main input source
#if ENABLE_MFC
    if (g_PNL_TypeSel >= MFC_DEFAULT)
    {
        MDrv_URSA_SetVFreq(60*100, DISABLE);
    }
#endif

#if (ENABLE_BOOTTIME)
    gU32TmpTime = msAPI_Timer_DiffTimeFromNow(gU32BootTime);
    printf("[boot time]MApp_Scaler_MainWindowSyncEventHandler = %ld\n", gU32TmpTime);
#endif


#if (ENABLE_PIP)
    if(IsPIPEnable())
    {
        MS_WINDOW_TYPE stPOPMainWin;

        if(stGenSetting.g_stPipSetting.enPipMode == EN_PIP_MODE_POP_FULL)
        {
            stPOPMainWin.x = 0;
            stPOPMainWin.y = 0;
            stPOPMainWin.width = PANEL_WIDTH/2;
            stPOPMainWin.height = PANEL_HEIGHT;

            MApp_Scaler_SetWindow(
                NULL,
                NULL,
                &stPOPMainWin,
                stSystemInfo[MAIN_WINDOW].enAspectRatio,
                SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW),
                MAIN_WINDOW);
        }
        else if(stGenSetting.g_stPipSetting.enPipMode == EN_PIP_MODE_POP)
        {
            stPOPMainWin.width = PANEL_WIDTH/2;
            stPOPMainWin.height = stPOPMainWin.width * PANEL_HEIGHT / PANEL_WIDTH;
            stPOPMainWin.x = 0;
            stPOPMainWin.y = PANEL_HEIGHT/2-stPOPMainWin.height/2;

            MApp_Scaler_SetWindow(NULL, NULL,
                &stPOPMainWin,
                stSystemInfo[MAIN_WINDOW].enAspectRatio,
                SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW),
                MAIN_WINDOW);
        }
        else
        {
            MApp_Scaler_SetWindow(NULL, NULL, NULL,
                stSystemInfo[MAIN_WINDOW].enAspectRatio,
                src,
                MAIN_WINDOW);
        }
    }
    else
#endif
    {
        MApp_Scaler_SetWindow(NULL, NULL, NULL,
            stSystemInfo[MAIN_WINDOW].enAspectRatio,
                              src, MAIN_WINDOW);
    }
    //MApi_XC_SetDbgLevel(XC_DBGLEVEL_SETTIMING);

    MApp_Scaler_SetTiming(src, MAIN_WINDOW);

    MApi_XC_Mux_OnOffPeriodicHandler(src, ENABLE);

    CAL_TIME_FUNC_END();
}

/*
    Put jobs which need to do when destination on/off event happen
 */
#if ENABLE_SW_CH_FREEZE_SCREEN
extern BOOLEAN bVideoStandardChanged;
#endif
void MApp_Scaler_MainWindowOnOffEventHandler(INPUT_SOURCE_TYPE_t src, void* para)
{
    U8 u8Enable = *((U8*)para);

//    printf("%s, %d\n", __FILE__, __LINE__);

    //printf("OnOffEventHandler(en=%u)\n", u8Enable);
    CAL_TIME_FUNC_START();


    // Turn on Main window
    if ( u8Enable )
    {
        MApi_XC_Sys_PQ_ReduceBW_ForOSD(MAIN_WINDOW, MApi_GOP_GWIN_IsEnabled());
        MApp_Picture_Setting_SetColor(src, MAIN_WINDOW);
    }
    else
    {
        MApi_XC_Mux_OnOffPeriodicHandler(src, DISABLE);
    }

#if (XC_BRINGUP)
    //MApi_XC_W2BYTEMSK(REG_SC_BK02_48_L, 0x00, 0x8000); // for CVBS/ATV/SVIDEO, and need to modify in PQ
    //MApi_XC_W2BYTE(REG_SC_BK10_50_L, 0x0000); // for CVBS/ATV/SVIDEO, and need to modify in PQ
    //MApi_XC_W2BYTE(REG_SC_BK23_0B_L, 0x0000); // disable PQ SRAM first
#endif

#if (ENABLE_ATV_VCHIP)
     if ((MApp_VChip_GetCurVChipBlockStatus()) && (u8Enable == 1))
        ;
     else
#endif
     {
        MS_U16 u16UnMuteTime = DEFAULT_SCREEN_UNMUTE_TIME;

        // For DTV HD FBL mode, need to wait FPLL done
        if (IsDTVInUse() && MApi_XC_IsCurrentFrameBufferLessMode())
        {
            u16UnMuteTime = u16UnMuteTime * 2;
        }

        #if 0//TV_FREQ_SHIFT_CLOCK
        if(IsATVInUse() && u8Enable && msAPI_Tuner_Patch_IsTVShiftVDClk())
        {
            //u16UnMuteTime = u16UnMuteTime+800;
            #if(ENABLE_SW_CH_FREEZE_SCREEN)
            if((msAPI_Scaler_GetScreenMute(MAIN_WINDOW) & E_SCREEN_MUTE_CHANNEL)&&(bVideoStandardChanged == FALSE))
            {
                msAPI_Scaler_SetFreezeScreen(ENABLE, 500, MAIN_WINDOW);
            }
            else
            #endif
            {
                msAPI_Scaler_SetScreenMute(E_SCREEN_MUTE_TEMPORARY, ENABLE, 500, MAIN_WINDOW);
            }
        }
        #endif
        #ifdef ENABLE_CUS_AUTO_AUDIO_SYSTEM_DETECT
        if(msAPI_ATV_IsRealtimeAudioDetectionEnabled(msAPI_ATV_GetCurrentProgramNumber()))
        {
            //u16UnMuteTime = u16UnMuteTime+800;
            #if(ENABLE_SW_CH_FREEZE_SCREEN)
            if((msAPI_Scaler_GetScreenMute(MAIN_WINDOW) & E_SCREEN_MUTE_CHANNEL)&&(bVideoStandardChanged == FALSE))
            {
                msAPI_Scaler_SetFreezeScreen(ENABLE, 700, MAIN_WINDOW);
            }
            else
            #endif
            {
                msAPI_Scaler_SetScreenMute(E_SCREEN_MUTE_TEMPORARY, ENABLE, 700, MAIN_WINDOW);
            }
        }
        #endif

        #if ENABLE_CUS_BLOCK_SYS
        if(MApp_UiMenuFunc_CheckInputLockAudioVideo() == TRUE)
        {
            msAPI_Scaler_SetBlueScreen( ENABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
        }
        else
        #endif
        {
#if ENABLE_SZ_BLUESCREEN_FUNCTION
		if(stGenSetting.g_SysSetting.bIsBluescreenOn && !ATV_SEARCH_STATE && IsATVInUse() && (!IsVDHasSignal()))
            msAPI_Scaler_SetBlueScreen( ENABLE, E_XC_FREE_RUN_COLOR_BLACK, u16UnMuteTime, MAIN_WINDOW);
		else
#endif
            msAPI_Scaler_SetBlueScreen( !u8Enable , E_XC_FREE_RUN_COLOR_BLACK, u16UnMuteTime, MAIN_WINDOW);
        }
    #if ENABLE_CUS_BURNING_MODE
        g_bDisableBurninMode = FALSE;
    #endif
    }

    CAL_TIME_FUNC_END();
}

/*
    Put jobs which need to do when periodic handler executed
 */
void MApp_Scaler_MainWindowPeriodicHandler(INPUT_SOURCE_TYPE_t src, BOOLEAN bRealTimeMonitorOnly)
{
    UNUSED(src);

    MApi_XC_Sys_Periodic_Handler(MAIN_WINDOW, bRealTimeMonitorOnly);
}

///////////////////////////////////////////////////////////
/// Scaler SubWin Handler
///////////////////////////////////////////////////////////

/*
    Setup scaler sub window when sync event happen.
 */
#if (ENABLE_PIP)
void MApp_Scaler_SubWindowSyncEventHandler(INPUT_SOURCE_TYPE_t src, void* para)
{
    UNUSED(src); UNUSED(para);

    if(!IsPIPSupported())
    {
        printf("MApp_Scaler_SubWindowSyncEventHandler: This chip do not support PIP!\n");
        return;
    }

    stSystemInfo[SUB_WINDOW].enAspectRatio = MApp_Scaler_GetAspectRatio(ST_VIDEO.eAspectRatio);

    if(IsPIPEnable())
    {
        MS_WINDOW_TYPE stWinRect;
        MApp_InputSource_PIP_GetSubWinRect(&stWinRect);
        MApp_Scaler_SetWindow(
            NULL,
            NULL,
            &stWinRect,
            stSystemInfo[SUB_WINDOW].enAspectRatio,
            SYS_INPUT_SOURCE_TYPE(SUB_WINDOW),
            SUB_WINDOW);
    }
    else
    {
        MApp_Scaler_SetWindow(NULL, NULL, NULL, stSystemInfo[SUB_WINDOW].enAspectRatio, src, SUB_WINDOW);
    }

    MApi_XC_Mux_OnOffPeriodicHandler(src, ENABLE);
}

/*
    Put jobs which need to do when destination on/off event happen
 */
void MApp_Scaler_SubWindowOnOffEventHandler(INPUT_SOURCE_TYPE_t src, void* para)
{
    U8 u8Enable = *((U8*)para);

    // Turn on Sub window
    if ( u8Enable )
    {
        MApi_XC_Sys_PQ_ReduceBW_ForOSD(SUB_WINDOW, MApi_GOP_GWIN_IsEnabled());
        MApp_Picture_Setting_SetColor(src, SUB_WINDOW);
    }
    else
    {
        MApi_XC_Mux_OnOffPeriodicHandler(src, DISABLE);
    }

    msAPI_Scaler_SetBlueScreen( !u8Enable , E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, SUB_WINDOW);
}


/*
    Put jobs which need to do when periodic handler executed
 */
void MApp_Scaler_SubWindowPeriodicHandler(INPUT_SOURCE_TYPE_t src, BOOLEAN bRealTimeMonitorOnly)
{
    UNUSED(src);

    MApi_XC_Sys_Periodic_Handler(SUB_WINDOW, bRealTimeMonitorOnly);
}

#endif
///////////////////////////////////////////////////////////
/// CVBS out Handler
///////////////////////////////////////////////////////////
/*
    Setup CVBS out when sync event happen.
 */
void MApp_Scaler_CVBS1OutSyncEventHandler(INPUT_SOURCE_TYPE_t src, void* para)
{
    UNUSED(para);
    UNUSED(src); // temp

    // Only DTV need to set.
    if ( src == INPUT_SOURCE_DTV || src == INPUT_SOURCE_STORAGE)
    {
        msAPI_Scaler_SetVE(src,OUTPUT_CVBS1);
    }
}

void MApp_Scaler_CVBS2OutSyncEventHandler(INPUT_SOURCE_TYPE_t src, void* para)
{
    UNUSED(para);
    UNUSED(src); // temp

    // Only DTV need to set.
    if ( src == INPUT_SOURCE_DTV || src == INPUT_SOURCE_STORAGE )
    {
        msAPI_Scaler_SetVE(src,OUTPUT_CVBS2);
    }
}


/*
    Put jobs which need to do when destination on/off event happen
 */
void MApp_Scaler_CVBS1OutOnOffEventHandler(INPUT_SOURCE_TYPE_t src, void* para)
{
    UNUSED(para);
    UNUSED(src);

    //CVBS out control move to screen mute function
    //U8 u8Enable = *((U8*)para);

    //msAPI_Scaler_SetCVBSMute(!u8Enable, E_VE_MUTE_GEN, src,OUTPUT_CVBS1);
}

/*
    Put jobs which need to do when destination on/off event happen
 */
void MApp_Scaler_CVBS2OutOnOffEventHandler(INPUT_SOURCE_TYPE_t src, void* para)
{
    UNUSED(para);
    UNUSED(src);

    //CVBS out control move to screen mute function
    //U8 u8Enable = *((U8*)para);

    //msAPI_Scaler_SetCVBSMute(!u8Enable, E_VE_MUTE_GEN, src,OUTPUT_CVBS2);
}

#ifdef DVBT_MMBOX
void MApp_Scaler_SetDacOutputMode(E_DAC_OUTPUT_TIMING_TYPE eTiming)
{
    msAPI_Scaler_ChangePanelType(eTiming);
    MApp_Scaler_SetWindow(NULL, NULL, NULL, stSystemInfo[MAIN_WINDOW].enAspectRatio, SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW), MAIN_WINDOW);
    msAPI_Scaler_SetDacOutputMode(eTiming);
}
#endif

#if(PATCH_FOR_V_RANGE)
void MApp_Scaler_SetCustomerWindow(MS_WINDOW_TYPE *ptSrcWin, MS_WINDOW_TYPE *ptCropWin, MS_WINDOW_TYPE *ptDstWin, SCALER_WIN eWindow)
{
    XC_SETWIN_INFO stSetWinInfo;

    MApp_Scaler_GetWinInfo(&stSetWinInfo, eWindow);

    if(ptSrcWin)
        stSetWinInfo.stCapWin = *ptSrcWin;

    if(ptCropWin)
        stSetWinInfo.stCropWin = *ptCropWin;

    if(ptDstWin)
        stSetWinInfo.stDispWin = *ptDstWin;

     MApp_Scaler_SetWindow(
                        ptSrcWin,
                        ptCropWin,
                        ptDstWin,
                        stSystemInfo[MAIN_WINDOW].enAspectRatio,
                        SYS_INPUT_SOURCE_TYPE(eWindow),
                        eWindow);
}
#endif

#if ENABLE_3D_PROCESS
void MApp_Scaler_Adjust_3D_CropWin(MS_WINDOW_TYPE *pstCropWin)
{
    if(MApi_XC_Get_3D_Input_Mode(MAIN_WINDOW) == E_XC_3D_INPUT_SIDE_BY_SIDE_HALF
       ||MApi_XC_Get_3D_Input_Mode(MAIN_WINDOW) == E_XC_3D_INPUT_SIDE_BY_SIDE_HALF_INTERLACE)
    {
        pstCropWin->x/=2;
    }
    else if(MApi_XC_Get_3D_Input_Mode(MAIN_WINDOW) == E_XC_3D_INPUT_TOP_BOTTOM
      ||MApi_XC_Get_3D_Input_Mode(MAIN_WINDOW) == E_XC_3D_INPUT_FRAME_PACKING
      ||MApi_XC_Get_3D_Input_Mode(MAIN_WINDOW) == E_XC_3D_INPUT_LINE_ALTERNATIVE)
    {
        pstCropWin->y/=2;
    }
}

void MApp_Scaler_EnableManualDetectTiming(BOOLEAN bEnable)
{
    _bManualDetectTiming = bEnable;
}

BOOLEAN MApp_Scaler_IsManualDetectTiming(void)
{
    return _bManualDetectTiming;
}

E_XC_3D_INPUT_MODE MAPP_Scaler_MapUI3DModeToXC3DMode(EN_3D_TYPE eInputUI3DType)
{
    E_XC_3D_INPUT_MODE eInput3DMode;

    if(eInputUI3DType == EN_3D_FRAME_PARKING)
    {
        eInput3DMode = E_XC_3D_INPUT_FRAME_PACKING;
    }
    else if(eInputUI3DType == EN_3D_SIDE_BY_SIDE)
    {
        if(gstVidStatus.u8Interlace)
            eInput3DMode = E_XC_3D_INPUT_SIDE_BY_SIDE_HALF_INTERLACE;
        else
            eInput3DMode = E_XC_3D_INPUT_SIDE_BY_SIDE_HALF;
    }
    else if(eInputUI3DType == EN_3D_TOP_BOTTOM)
    {
        eInput3DMode = E_XC_3D_INPUT_TOP_BOTTOM;
    }
    else if(eInputUI3DType == EN_3D_LINE_BY_LINE)
    {
        eInput3DMode = E_XC_3D_INPUT_LINE_ALTERNATIVE;
    }
    else if(eInputUI3DType == EN_3D_BYPASS)
    {
        eInput3DMode = E_XC_3D_INPUT_MODE_NONE;
    }
    else if(eInputUI3DType == EN_3D_NORMAL_2D)
    {
        eInput3DMode = E_XC_3D_INPUT_NORMAL_2D;
    }
    else if(eInputUI3DType == EN_3D_FRAME_ALTERNATIVE)
    {
        eInput3DMode = E_XC_3D_INPUT_FRAME_ALTERNATIVE;
    }
    else if(eInputUI3DType == EN_3D_3D_TO_2D)
    {
        eInput3DMode = E_XC_3D_INPUT_SIDE_BY_SIDE_HALF;
    }
    else
    {
        eInput3DMode = E_XC_3D_INPUT_MODE_NONE;
    }
    return eInput3DMode;
}

BOOL MAPP_Scaler_MapUIDetectMode(EN_3D_DETECT_MODE eDetect3DMode)
{
    BOOL bAutoDetect = FALSE;

    if(eDetect3DMode == EN_3D_DETECT_AUTO)
    {
        bAutoDetect = TRUE;
    }
    else
    {
        bAutoDetect = FALSE;
    }
    return bAutoDetect;
}

U16 MAPP_Scaler_Map3DFormatTo3DUserMode(E_XC_3D_INPUT_MODE eInput3DFormat)
{
    U16 u16User3DMode = E_USER_3D_MODE_OFF;
#if ENABLE_6M30_3D_PROCESS
    if(eInput3DFormat == E_XC_3D_INPUT_FRAME_PACKING)
    {
        u16User3DMode = E_USER_3D_MODE_FRAME_PACKING_2_FRAME_ALTERNATIVE;
    }
    else if(eInput3DFormat == E_XC_3D_INPUT_SIDE_BY_SIDE_HALF)
    {
        u16User3DMode = E_USER_3D_MODE_OFF;
    }
    else if(eInput3DFormat == E_XC_3D_INPUT_SIDE_BY_SIDE_HALF_INTERLACE)
    {
        u16User3DMode = E_USER_3D_MODE_OFF;
    }
    else if(eInput3DFormat == E_XC_3D_INPUT_TOP_BOTTOM)
    {
        u16User3DMode = E_USER_3D_MODE_OFF;
    }
    else if(eInput3DFormat == E_XC_3D_INPUT_LINE_ALTERNATIVE)
    {
        u16User3DMode = E_USER_3D_MODE_OFF;
    }
    else if(eInput3DFormat == E_XC_3D_INPUT_NORMAL_2D)
    {
        u16User3DMode = E_USER_3D_MODE_OFF;
    }
    else
    {
        u16User3DMode = E_USER_3D_MODE_OFF;
    }
#else
{
    EN_3D_TYPE en3DType;
	#if ENABLE_CUS_3D_SOURCE_MEMORY
    if(IsHDMIInUse() && (g_HdmiPollingStatus.bIsHDMIMode == FALSE)) //dvi
    {
        en3DType = ST_VGA_3D_TYPE;
    }
    else
	#endif
    {
        en3DType = ST_3D_TYPE;
    }

    if((EN_3D_3D_TO_2D==en3DType) && (stGenSetting.g_SysSetting.en3DDetectMode != EN_3D_DETECT_AUTO))
    {
        #if ENABLE_CUS_UI_SPEC
        if(IsHDMIInUse() && g_HdmiPollingStatus.bIsHDMIMode)
        {
            if((g_HdmiInput3DFormatStatus == E_XC_3D_INPUT_SIDE_BY_SIDE_HALF)
                || (g_HdmiInput3DFormatStatus == E_XC_3D_INPUT_TOP_BOTTOM)
                || (g_HdmiInput3DFormatStatus == E_XC_3D_INPUT_FRAME_PACKING)
                || (g_HdmiInput3DFormatStatus == E_XC_3D_INPUT_LINE_ALTERNATIVE))
            {
                //patch for HDMI 3D to 2D /*Creass.liu at 2012-08-01*/
                eInput3DFormat = g_HdmiInput3DFormatStatus;
            }
        }
        #endif

        switch(eInput3DFormat)
        {
             case  E_XC_3D_INPUT_FRAME_PACKING:
                 u16User3DMode = E_USER_3D_MODE_FRAME_PACKING_2_FRAME_L;
		    break;
             case  E_XC_3D_INPUT_FRAME_ALTERNATIVE:
                 u16User3DMode = E_USER_3D_MODE_FRAME_ALTERNATIVE_2_FRAME_L;
		    break;
             case  E_XC_3D_INPUT_SIDE_BY_SIDE_HALF:
                 u16User3DMode = E_USER_3D_MODE_SIDE_BY_SIDE_HALF_2_FRAME_L;
		    break;
             case  E_XC_3D_INPUT_TOP_BOTTOM:
                 u16User3DMode = E_USER_3D_MODE_TOP_BOTTOM_2_FRAME_L;
		    break;
             case  E_XC_3D_INPUT_LINE_ALTERNATIVE:
                 u16User3DMode = E_USER_3D_MODE_LINE_ALTERNATIVE_2_FRAME_L;
		    break;
		default:
                 u16User3DMode = E_USER_3D_MODE_OFF;
		    break;
        }
    }
    else
    {
        switch(eInput3DFormat)
        {
            case E_XC_3D_INPUT_FRAME_PACKING:
                en3DType = EN_3D_FRAME_PARKING;   //For HDMI Auto Detect Sync UI
                u16User3DMode = E_USER_3D_MODE_FRAME_PACKING_2_LINE_ALTERNATIVE;
            break;
            case E_XC_3D_INPUT_FRAME_ALTERNATIVE:
                en3DType = EN_3D_FRAME_ALTERNATIVE;   //For HDMI Auto Detect Sync UI
                u16User3DMode = E_USER_3D_MODE_FRAME_ALTERNATIVE_2_LINE_ALTERNATIVE;
            break;
            case E_XC_3D_INPUT_SIDE_BY_SIDE_HALF_INTERLACE:
                en3DType = EN_3D_SIDE_BY_SIDE;    //For HDMI Auto Detect Sync UI
                u16User3DMode = E_USER_3D_MODE_SIDE_BY_SIDE_HALF_2_LINE_ALTERNATIVE;
            break;
            case E_XC_3D_INPUT_SIDE_BY_SIDE_HALF:
                en3DType = EN_3D_SIDE_BY_SIDE;    //For HDMI Auto Detect Sync UI
                u16User3DMode = E_USER_3D_MODE_SIDE_BY_SIDE_HALF_2_LINE_ALTERNATIVE;
            break;
            case E_XC_3D_INPUT_TOP_BOTTOM:
                en3DType = EN_3D_TOP_BOTTOM;
                u16User3DMode = E_USER_3D_MODE_TOP_BOTTOM_2_LINE_ALTERNATIVE;
            break;
            case E_XC_3D_INPUT_LINE_ALTERNATIVE:
                u16User3DMode = E_USER_3D_MODE_LINE_ALTERNATIVE_2_LINE_ALTERNATIVE;
            break;
            case E_XC_3D_INPUT_NORMAL_2D:
                u16User3DMode = E_USER_3D_MODE_NORMAL_2D_2_LINE_ALTERNATIVE;
            break;
            default:
            u16User3DMode = E_USER_3D_MODE_OFF;
            break;
        }

        if(IsHDMIInUse() && (g_HdmiPollingStatus.bIsHDMIMode == FALSE)) //dvi
        {
            //ST_VGA_3D_TYPE = en3DType;
        }
        else if(IsStorageInUse())
        {
        }
        else
        {
            ST_3D_TYPE = en3DType;
        }
    }
}
#endif
    return u16User3DMode;
}

void MApp_Scaler_Set3DScene_CUS(void)
{
    #ifdef HW_2DTO3D_SUPPORT
    MS_XC_3D_HW2DTO3D_PARA stHw2Dto3DPara;
    memset(&stHw2Dto3DPara, 0, sizeof(MS_XC_3D_HW2DTO3D_PARA));
    MApi_XC_Get_3D_HW2DTo3D_Parameters(&stHw2Dto3DPara);

    // 0x0f ~0xEF
    stHw2Dto3DPara.u16Offset = ST_3D_3DScene * 22 + 0x0f;

    if(ST_3D_3DScene >9)
    {
    stHw2Dto3DPara.u16Offset = 0xEF;
    }
    MApi_XC_Set_3D_HW2DTo3D_Parameters(stHw2Dto3DPara);
    #endif
}

#if ENABLE_3D_LAP_PATCH
extern BOOLEAN MApp_VDPlayer_GetDisplayPathInfo(U8 *u8VideoType, U16 *u16Width, U16 *u16Height,
               U16 *u16DisplayX, U16 *u16DisplayY, U16 *u16DisplayWidth, U16 *u16DisplayHeight, U32 *u32BuffAddr, U8 *u8TSStream);
extern void _MApp_VDPlayer_SetupDisplayPath(U8 u8VideoType, U16 u16Width, U16 u16Height,
               U16 u16DisplayX, U16 u16DisplayY, U16 u16DisplayWidth, U16 u16DisplayHeight, U32 u32BuffAddr, U8 u8TSStream);
#define MAX_MVOP_HDUPLICATE_SIZE 704 //mvop driver will skip duplicate if >= this value
#endif //#if ENABLE_3D_LAP_PATCH
extern BOOLEAN g_bForceMVOPHDuplicate;
BOOLEAN MApp_Scaler_SetVideo3DMode(U16 u16_Video3Dmode)
{
    MENU_3D_DBG(printf("u16_Video3Dmode<<0x%x>>\n", u16_Video3Dmode);)
    g_bForceMVOPHDuplicate = FALSE;//Remove patch for small video on TP/SBS->LAP
    MApi_XC_Set_3D_HShift(0); //Default set shift to 0 to avoid Non-2d->3d case use this shift to adjust 3D quality
    switch(u16_Video3Dmode)
    {
        case E_USER_3D_MODE_80:
        {
            MENU_3D_DBG(printf("******************************Usage Note******************************\n");)
            MENU_3D_DBG(printf("[0x00]3D:Close 3D\n");)

            MENU_3D_DBG(printf("[0x01]3D: Begin 3D. FRAME_PACKING ===> LINE_ALTERNATIVE\n");)
            MENU_3D_DBG(printf("[0x02]3D: Begin 3D. SIDE_BY_SIDE_HALF ===> LINE_ALTERNATIVE\n");)
            MENU_3D_DBG(printf("[0x03]3D: Begin 3D. Vertical LINE_ALTERNATIVE to Vertical LINE_ALTERNATIVE\n");)
            MENU_3D_DBG(printf("[0x04]3D: Begin 3D. LINE_ALTERNATIVE ===> LINE_ALTERNATIVE\n");)
            MENU_3D_DBG(printf("[0x05]3D: Begin 3D. SIDE_BY_SIDE_HALF_INTERLACE ===> LINE_ALTERNATIVE\n");)

            MENU_3D_DBG(printf("[0x11]3D: Begin 3D. LINE_ALTERNATIVE ====> TOP_BOTTOM\n");)
            MENU_3D_DBG(printf("[0x12]3D: Begin 3D. TOP_BOTTOM ====> TOP_BOTTOM\n");)
            MENU_3D_DBG(printf("[0x13]3D: Begin 3D. FRAME_ALTERNATIVE ====> TOP_BOTTOM\n");)
            MENU_3D_DBG(printf("[0x14]3D: Begin 3D. SIDE_BY_SIDE_HALF ====> SIDE_BY_SIDE_HALF\n");)
            MENU_3D_DBG(printf("[0x15]3D: Begin 3D. FRAME_PACKING ====> FRAME_ALTERNATIVE\n");)
            MENU_3D_DBG(printf("*********************************************************************\n");)
        }
            break;
        case E_USER_3D_MODE_OFF:
        case E_USER_3D_MODE_FRAME_PACKING_2_LINE_ALTERNATIVE:
        case E_USER_3D_MODE_SIDE_BY_SIDE_HALF_2_LINE_ALTERNATIVE:
        case E_USER_3D_MODE_SIDE_BY_SIDE_HALF_INTERLACE_2_LINE_ALTERNATIVE:
        case E_USER_3D_MODE_VERTICAL_LINE_ALTERNATIVE_2_VERTICAL_LINE_ALTERNATIVE:
        case E_USER_3D_MODE_LINE_ALTERNATIVE_2_LINE_ALTERNATIVE:
        case E_USER_3D_MODE_TOP_BOTTOM_2_LINE_ALTERNATIVE:
        case E_USER_3D_MODE_FRAME_ALTERNATIVE_2_LINE_ALTERNATIVE:

        case E_USER_3D_MODE_FRAME_PACKING_2_TOP_BOTTOM:
        case E_USER_3D_MODE_TOP_BOTTOM_2_TOP_BOTTOM:
        case E_USER_3D_MODE_FRAME_ALTERNATIVE_2_TOP_BOTTOM:

        case E_USER_3D_MODE_LINE_ALTERNATIVE_2_SIDE_BY_SIDE_HALF: //special case
        case E_USER_3D_MODE_SIDE_BY_SIDE_HALF_2_SIDE_BY_SIDE_HALF:
        case E_USER_3D_MODE_FRAME_PACKING_2_SIDE_BY_SIDE_HALF:
        case E_USER_3D_MODE_TOP_BOTTOM_2_SIDE_BY_SIDE_HALF:

        case E_USER_3D_MODE_FRAME_PACKING_2_FRAME_ALTERNATIVE_NOFRC:
        case E_USER_3D_MODE_SIDE_BY_SIDE_HALF_2_FRAME_ALTERNATIVE_NOFRC:
        case E_USER_3D_MODE_SIDE_BY_SIDE_HALF_INTERLACE_2_FRAME_ALTERNATIVE_NOFRC:
        case E_USER_3D_MODE_LINE_ALTERNATIVE_2_FRAME_ALTERNATIVE_NOFRC:
        case E_USER_3D_MODE_TOP_BOTTOM_2_FRAME_ALTERNATIVE_NOFRC:

        case E_USER_3D_MODE_FRAME_PACKING_2_FRAME_ALTERNATIVE:
        case E_USER_3D_MODE_TOP_BOTTOM_2_FRAME_ALTERNATIVE:
        case E_USER_3D_MODE_SIDE_BY_SIDE_HALF_2_FRAME_ALTERNATIVE:
        case E_USER_3D_MODE_LINE_ALTERNATIVE_2_FRAME_ALTERNATIVE:

        case E_USER_3D_MODE_FRAME_PACKING_2_FRAME_L:
        case E_USER_3D_MODE_SIDE_BY_SIDE_HALF_2_FRAME_L:
        case E_USER_3D_MODE_TOP_BOTTOM_2_FRAME_L:
        case E_USER_3D_MODE_LINE_ALTERNATIVE_2_FRAME_L:
        case E_USER_3D_MODE_FRAME_ALTERNATIVE_2_FRAME_L:

        case E_USER_3D_MODE_NORMAL_2D_2_LINE_ALTERNATIVE:
        case E_USER_3D_MODE_NORMAL_2D_2_FRAME_ALTERNATIVE_NOFRC:
        {
            if(MApp_Scaler_IsManualDetectTiming())
            {
               // MApp_InputSource_ChangeInputSource(MAIN_WINDOW);
                MApp_Scaler_EnableManualDetectTiming(FALSE);
            }
            else
            {
                if(u16_Video3Dmode != E_USER_3D_MODE_OFF)
                {
                    return FALSE;
                }
            }
            //MApp_Scaler_EnableOverScan(DISABLE);

//            MApp_ZUI_API_Enable3DTwinMode(TRUE);

            #if (MS_BOARD_TYPE_SEL == BD_CUS_715G_5740)
            if((E_USER_3D_MODE_OFF==u16_Video3Dmode)
                || (E_USER_3D_MODE_FRAME_PACKING_2_FRAME_L==u16_Video3Dmode)
                || (E_USER_3D_MODE_SIDE_BY_SIDE_HALF_2_FRAME_L==u16_Video3Dmode)
                || (E_USER_3D_MODE_TOP_BOTTOM_2_FRAME_L==u16_Video3Dmode)
                || (E_USER_3D_MODE_LINE_ALTERNATIVE_2_FRAME_L==u16_Video3Dmode)
                || (E_USER_3D_MODE_FRAME_ALTERNATIVE_2_FRAME_L==u16_Video3Dmode))

            {
                //3d off or 3D to 2D
                PANEL_3D_ENABLE_OFF();
            }
            else
            {
                PANEL_3D_ENABLE_ON();
            }
            #endif
            if(E_USER_3D_MODE_OFF==u16_Video3Dmode)
            {
                //MApp_ZUI_API_Enable3DTwinMode(FALSE);
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_MODE_NONE, E_XC_3D_OUTPUT_MODE_NONE, E_XC_3D_PANEL_NONE, MAIN_WINDOW);
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_MODE_NONE, E_XC_3D_OUTPUT_MODE_NONE, E_XC_3D_PANEL_NONE, SUB_WINDOW);
                MENU_3D_DBG(printf("\n\n=================================================\n");)
                MENU_3D_DBG(printf("3D:Close 3D\n");)
                MENU_3D_DBG(printf("=================================================\n");)
                MApp_Scaler_EnableOverScan(ENABLE);

            }
            else if(E_USER_3D_MODE_FRAME_PACKING_2_LINE_ALTERNATIVE==u16_Video3Dmode)
            {
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_FRAME_PACKING, E_XC_3D_OUTPUT_LINE_ALTERNATIVE, E_XC_3D_PANEL_PELLICLE, MAIN_WINDOW);
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_MODE_NONE, E_XC_3D_OUTPUT_LINE_ALTERNATIVE, E_XC_3D_PANEL_PELLICLE, SUB_WINDOW);
                MENU_3D_DBG(printf("\n\n=================================================\n");)
                MENU_3D_DBG(printf("3D: Begin 3D. FRAME_PACKING ===> LINE_ALTERNATIVE\n");)
                MENU_3D_DBG(printf("=================================================\n");)
            }
            else if(E_USER_3D_MODE_FRAME_ALTERNATIVE_2_LINE_ALTERNATIVE==u16_Video3Dmode)
            {
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_FRAME_ALTERNATIVE, E_XC_3D_OUTPUT_LINE_ALTERNATIVE, E_XC_3D_PANEL_PELLICLE, MAIN_WINDOW);
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_MODE_NONE, E_XC_3D_OUTPUT_LINE_ALTERNATIVE, E_XC_3D_PANEL_PELLICLE, SUB_WINDOW);
                MENU_3D_DBG(printf("\n\n=================================================\n");)
                MENU_3D_DBG(printf("3D: Begin 3D. FRAME_ALTERNATIVE ===> LINE_ALTERNATIVE\n");)
                MENU_3D_DBG(printf("=================================================\n");)
            }
            else if(E_USER_3D_MODE_SIDE_BY_SIDE_HALF_2_LINE_ALTERNATIVE==u16_Video3Dmode)
            {
                g_bForceMVOPHDuplicate = TRUE;//Enable patch for small video on TP/SBS->LAP
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_SIDE_BY_SIDE_HALF, E_XC_3D_OUTPUT_LINE_ALTERNATIVE, E_XC_3D_PANEL_PELLICLE, MAIN_WINDOW);
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_MODE_NONE, E_XC_3D_OUTPUT_LINE_ALTERNATIVE, E_XC_3D_PANEL_PELLICLE, SUB_WINDOW);
                MENU_3D_DBG(printf("\n\n=================================================\n");)
                MENU_3D_DBG(printf("3D: Begin 3D. SIDE_BY_SIDE_HALF ===> LINE_ALTERNATIVE\n");)
                MENU_3D_DBG(printf("=================================================\n");)
            }
            else if(E_USER_3D_MODE_SIDE_BY_SIDE_HALF_INTERLACE_2_LINE_ALTERNATIVE==u16_Video3Dmode)
            {
                g_bForceMVOPHDuplicate = TRUE;//Enable patch for small video on TP/SBS->LAP
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_SIDE_BY_SIDE_HALF_INTERLACE, E_XC_3D_OUTPUT_LINE_ALTERNATIVE, E_XC_3D_PANEL_PELLICLE, MAIN_WINDOW);
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_MODE_NONE, E_XC_3D_OUTPUT_LINE_ALTERNATIVE, E_XC_3D_PANEL_PELLICLE, SUB_WINDOW);
                MENU_3D_DBG(printf("\n\n=================================================\n");)
                MENU_3D_DBG(printf("3D: Begin 3D. SIDE_BY_SIDE_HALF_INTERLACE ===> LINE_ALTERNATIVE\n");)
                MENU_3D_DBG(printf("=================================================\n");)
            }
            else if(E_USER_3D_MODE_VERTICAL_LINE_ALTERNATIVE_2_VERTICAL_LINE_ALTERNATIVE==u16_Video3Dmode)
            {
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_MODE_NONE, E_XC_3D_OUTPUT_MODE_NONE, E_XC_3D_PANEL_PELLICLE, MAIN_WINDOW);
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_MODE_NONE, E_XC_3D_OUTPUT_MODE_NONE, E_XC_3D_PANEL_PELLICLE, SUB_WINDOW);
                MENU_3D_DBG(printf("\n\n=================================================\n");)
                MENU_3D_DBG(printf("3D: Begin 3D. ByPassMode\n");)
                MENU_3D_DBG(printf("=================================================\n");)
            }
            else if(E_USER_3D_MODE_LINE_ALTERNATIVE_2_LINE_ALTERNATIVE==u16_Video3Dmode)
            {
                g_bForceMVOPHDuplicate = TRUE;//Enable patch for small video on TP/SBS->LAP
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_LINE_ALTERNATIVE, E_XC_3D_OUTPUT_LINE_ALTERNATIVE, E_XC_3D_PANEL_PELLICLE, MAIN_WINDOW);
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_MODE_NONE, E_XC_3D_OUTPUT_LINE_ALTERNATIVE, E_XC_3D_PANEL_PELLICLE, SUB_WINDOW);
                MENU_3D_DBG(printf("\n\n=================================================\n");)
                MENU_3D_DBG(printf("3D: Begin 3D. LINE_ALTERNATIVE ===> LINE_ALTERNATIVE\n");)
                MENU_3D_DBG(printf("=================================================\n");)
            }
            else if(E_USER_3D_MODE_TOP_BOTTOM_2_LINE_ALTERNATIVE==u16_Video3Dmode)
            {
                g_bForceMVOPHDuplicate = TRUE;//Enable patch for small video on TP/SBS->LAP
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_TOP_BOTTOM, E_XC_3D_OUTPUT_LINE_ALTERNATIVE, E_XC_3D_PANEL_SHUTTER, MAIN_WINDOW);
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_TOP_BOTTOM, E_XC_3D_OUTPUT_LINE_ALTERNATIVE, E_XC_3D_PANEL_SHUTTER, SUB_WINDOW);
                MENU_3D_DBG(printf("3D:Begin 3D. TOP_BOTTOM ====> LINE_ALTERNATIVE\n");)
            }
            else if(E_USER_3D_MODE_NORMAL_2D_2_LINE_ALTERNATIVE==u16_Video3Dmode)
            {
                //MApi_XC_Set_3D_HShift(16);
                #if ENABLE_CUS_3D_SOURCE_MEMORY
                if(IsHDMIInUse() && (g_HdmiPollingStatus.bIsHDMIMode == FALSE)) //dvi
                {
                    MApi_XC_Set_3D_HShift(ST_VGA_3DScene*2);
                }
                else
                #endif
                {
                    MApi_XC_Set_3D_HShift(ST_3D_3DScene*2);
                }

                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_NORMAL_2D, E_XC_3D_OUTPUT_LINE_ALTERNATIVE, E_XC_3D_PANEL_PELLICLE, MAIN_WINDOW);
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_MODE_NONE, E_XC_3D_OUTPUT_LINE_ALTERNATIVE, E_XC_3D_PANEL_PELLICLE, SUB_WINDOW);
                MENU_3D_DBG(printf("3D: Begin 3D. NORMAL_2D ===> LINE_ALTERNATIVE\n");)
            #if MirrorEnable
                // swap LR for 3D PR and mirror panel
                {
                    EN_3D_LR_MODE enLRMODE;
                    #if ENABLE_CUS_3D_SOURCE_MEMORY
                    if(IsHDMIInUse() && (g_HdmiPollingStatus.bIsHDMIMode == FALSE)) //dvi
                    {
                        enLRMODE = ST_VGA_3D_LRMODE;
                    }
                    else
                    #endif
                    {
                        enLRMODE = ST_3D_LRMODE;
                    }

                    if(enLRMODE == EN_3D_LR_L)
                    {
                        if(IsDigitalSourceInUse())
                        {
                            MApi_XC_Set_3D_LR_Frame_Exchg(MAIN_WINDOW);
                        }
                    }
                }
            #endif

            }

            else  if(E_USER_3D_MODE_FRAME_PACKING_2_FRAME_ALTERNATIVE_NOFRC==u16_Video3Dmode)
            {
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_FRAME_PACKING, E_XC_3D_OUTPUT_FRAME_ALTERNATIVE_NOFRC, E_XC_3D_PANEL_PELLICLE, MAIN_WINDOW);
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_MODE_NONE, E_XC_3D_OUTPUT_FRAME_ALTERNATIVE_NOFRC, E_XC_3D_PANEL_PELLICLE, SUB_WINDOW);
                MENU_3D_DBG(printf("3D:Begin 3D. FRAME_PACKING ====> FRAME_ALTERNATIVE_NOFRC\n");)
            }
            else  if(E_USER_3D_MODE_TOP_BOTTOM_2_FRAME_ALTERNATIVE_NOFRC==u16_Video3Dmode)
            {
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_TOP_BOTTOM, E_XC_3D_OUTPUT_FRAME_ALTERNATIVE_NOFRC, E_XC_3D_PANEL_PELLICLE, MAIN_WINDOW);
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_MODE_NONE, E_XC_3D_OUTPUT_FRAME_ALTERNATIVE_NOFRC, E_XC_3D_PANEL_PELLICLE, SUB_WINDOW);
                MENU_3D_DBG(printf("3D:Begin 3D. TOP_BOTTOM ====> FRAME_ALTERNATIVE_NOFRC\n");)
            }
            else  if(E_USER_3D_MODE_SIDE_BY_SIDE_HALF_2_FRAME_ALTERNATIVE_NOFRC==u16_Video3Dmode)
            {
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_SIDE_BY_SIDE_HALF, E_XC_3D_OUTPUT_FRAME_ALTERNATIVE_NOFRC, E_XC_3D_PANEL_PELLICLE, MAIN_WINDOW);
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_MODE_NONE, E_XC_3D_OUTPUT_FRAME_ALTERNATIVE_NOFRC, E_XC_3D_PANEL_PELLICLE, SUB_WINDOW);
                MENU_3D_DBG(printf("3D:Begin 3D. SIDE_BY_SIDE_HALF ====> FRAME_ALTERNATIVE_NOFRC\n");)
            }
            else if(E_USER_3D_MODE_SIDE_BY_SIDE_HALF_INTERLACE_2_FRAME_ALTERNATIVE_NOFRC==u16_Video3Dmode)
            {
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_SIDE_BY_SIDE_HALF_INTERLACE, E_XC_3D_OUTPUT_FRAME_ALTERNATIVE_NOFRC, E_XC_3D_PANEL_PELLICLE, MAIN_WINDOW);
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_MODE_NONE, E_XC_3D_OUTPUT_FRAME_ALTERNATIVE_NOFRC, E_XC_3D_PANEL_PELLICLE, SUB_WINDOW);
                MENU_3D_DBG(printf("3D:Begin 3D. SIDE_BY_SIDE_HALF_INTERLACE ====> FRAME_ALTERNATIVE_NOFRC\n");)
            }
            else  if(E_USER_3D_MODE_LINE_ALTERNATIVE_2_FRAME_ALTERNATIVE_NOFRC==u16_Video3Dmode)
            {
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_LINE_ALTERNATIVE, E_XC_3D_OUTPUT_FRAME_ALTERNATIVE_NOFRC, E_XC_3D_PANEL_PELLICLE, MAIN_WINDOW);
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_MODE_NONE, E_XC_3D_OUTPUT_FRAME_ALTERNATIVE_NOFRC, E_XC_3D_PANEL_PELLICLE, SUB_WINDOW);
                MENU_3D_DBG(printf("3D:Begin 3D. LINE_ALTERNATIVE ====> FRAME_ALTERNATIVE_NOFRC\n");)
            }
            else if(E_USER_3D_MODE_NORMAL_2D_2_FRAME_ALTERNATIVE_NOFRC==u16_Video3Dmode)
            {
                MApi_XC_Set_3D_HShift(16);

                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_NORMAL_2D, E_XC_3D_OUTPUT_FRAME_ALTERNATIVE_NOFRC, E_XC_3D_PANEL_PELLICLE, MAIN_WINDOW);
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_MODE_NONE, E_XC_3D_OUTPUT_FRAME_ALTERNATIVE_NOFRC, E_XC_3D_PANEL_PELLICLE, SUB_WINDOW);
                MENU_3D_DBG(printf("3D: Begin 3D. NORMAL_2D ===> FRAME_ALTERNATIVE\n");)
            }

            else  if(E_USER_3D_MODE_FRAME_PACKING_2_FRAME_ALTERNATIVE==u16_Video3Dmode)
            {
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_FRAME_PACKING, E_XC_3D_OUTPUT_FRAME_ALTERNATIVE, E_XC_3D_PANEL_PELLICLE, MAIN_WINDOW);
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_MODE_NONE, E_XC_3D_OUTPUT_FRAME_ALTERNATIVE, E_XC_3D_PANEL_PELLICLE, SUB_WINDOW);
                MENU_3D_DBG(printf("3D:Begin 3D. FRAME_PACKING ====> FRAME_ALTERNATIVE\n");)
            }
            else  if(E_USER_3D_MODE_TOP_BOTTOM_2_FRAME_ALTERNATIVE==u16_Video3Dmode)
            {
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_TOP_BOTTOM, E_XC_3D_OUTPUT_FRAME_ALTERNATIVE, E_XC_3D_PANEL_PELLICLE, MAIN_WINDOW);
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_MODE_NONE, E_XC_3D_OUTPUT_FRAME_ALTERNATIVE, E_XC_3D_PANEL_PELLICLE, SUB_WINDOW);
                MENU_3D_DBG(printf("3D:Begin 3D. TOP_BOTTOM ====> FRAME_ALTERNATIVE\n");)
            }
            else  if(E_USER_3D_MODE_SIDE_BY_SIDE_HALF_2_FRAME_ALTERNATIVE==u16_Video3Dmode)
            {
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_SIDE_BY_SIDE_HALF, E_XC_3D_OUTPUT_FRAME_ALTERNATIVE, E_XC_3D_PANEL_PELLICLE, MAIN_WINDOW);
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_MODE_NONE, E_XC_3D_OUTPUT_FRAME_ALTERNATIVE, E_XC_3D_PANEL_PELLICLE, SUB_WINDOW);
                MENU_3D_DBG(printf("3D:Begin 3D. SIDE_BY_SIDE_HALF ====> FRAME_ALTERNATIVE\n");)
            }
            else  if(E_USER_3D_MODE_LINE_ALTERNATIVE_2_FRAME_ALTERNATIVE==u16_Video3Dmode)
            {
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_LINE_ALTERNATIVE, E_XC_3D_OUTPUT_FRAME_ALTERNATIVE, E_XC_3D_PANEL_PELLICLE, MAIN_WINDOW);
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_MODE_NONE, E_XC_3D_OUTPUT_FRAME_ALTERNATIVE, E_XC_3D_PANEL_PELLICLE, SUB_WINDOW);
                MENU_3D_DBG(printf("3D:Begin 3D. LINE_ALTERNATIVE ====> FRAME_ALTERNATIVE\n");)
            }

            else  if(E_USER_3D_MODE_FRAME_PACKING_2_FRAME_L==u16_Video3Dmode)
            {
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_FRAME_PACKING, E_XC_3D_OUTPUT_FRAME_L, E_XC_3D_PANEL_PELLICLE, MAIN_WINDOW);
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_MODE_NONE, E_XC_3D_OUTPUT_FRAME_L, E_XC_3D_PANEL_PELLICLE, SUB_WINDOW);
                MENU_3D_DBG(printf("3D:Begin 3D. FRAME_PACKING ====> FRAME_L\n");)
            }
            else  if(E_USER_3D_MODE_SIDE_BY_SIDE_HALF_2_FRAME_L==u16_Video3Dmode)
            {
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_SIDE_BY_SIDE_HALF, E_XC_3D_OUTPUT_FRAME_L, E_XC_3D_PANEL_PELLICLE, MAIN_WINDOW);
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_MODE_NONE, E_XC_3D_OUTPUT_FRAME_L, E_XC_3D_PANEL_PELLICLE, SUB_WINDOW);
                MENU_3D_DBG(printf("3D:Begin 3D. SIDE_BY_SIDE_HALF ====> FRAME_L\n");)
            }
            else  if(E_USER_3D_MODE_TOP_BOTTOM_2_FRAME_L==u16_Video3Dmode)
            {
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_TOP_BOTTOM, E_XC_3D_OUTPUT_FRAME_L, E_XC_3D_PANEL_PELLICLE, MAIN_WINDOW);
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_MODE_NONE, E_XC_3D_OUTPUT_FRAME_L, E_XC_3D_PANEL_PELLICLE, SUB_WINDOW);
                MENU_3D_DBG(printf("3D:Begin 3D. TOP_BOTTOM ====> FRAME_L\n");)
            }
            else  if(E_USER_3D_MODE_LINE_ALTERNATIVE_2_FRAME_L==u16_Video3Dmode)
            {
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_LINE_ALTERNATIVE, E_XC_3D_OUTPUT_FRAME_L, E_XC_3D_PANEL_PELLICLE, MAIN_WINDOW);
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_MODE_NONE, E_XC_3D_OUTPUT_FRAME_L, E_XC_3D_PANEL_PELLICLE, SUB_WINDOW);
                MENU_3D_DBG(printf("3D:Begin 3D. LINE_ALTERNATIVE ====> FRAME_L\n");)
            }
            else  if(E_USER_3D_MODE_FRAME_ALTERNATIVE_2_FRAME_L==u16_Video3Dmode)
            {
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_FRAME_ALTERNATIVE, E_XC_3D_OUTPUT_FRAME_L, E_XC_3D_PANEL_PELLICLE, MAIN_WINDOW);
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_MODE_NONE, E_XC_3D_OUTPUT_FRAME_L, E_XC_3D_PANEL_PELLICLE, SUB_WINDOW);
                MENU_3D_DBG(printf("3D:Begin 3D. FRAME_ALTERNATIVE ====> FRAME_L\n");)
            }

            else if(E_USER_3D_MODE_FRAME_PACKING_2_TOP_BOTTOM==u16_Video3Dmode)
            {
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_FRAME_PACKING, E_XC_3D_OUTPUT_TOP_BOTTOM, E_XC_3D_PANEL_SHUTTER, MAIN_WINDOW);
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_FRAME_PACKING, E_XC_3D_OUTPUT_TOP_BOTTOM, E_XC_3D_PANEL_SHUTTER, SUB_WINDOW);
                //MAPI_XC_Set_3D_MainSub_FirstMode(FALSE);
                //MApi_XC_SetFrameBufferAddress(((SCALER_DNR_BUF_MEMORY_TYPE & MIU1) ? (SCALER_DNR_BUF_ADR | MIU_INTERVAL) : (SCALER_DNR_BUF_ADR)), SCALER_DNR_BUF_LEN, SUB_WINDOW);
                MENU_3D_DBG(printf("3D:Begin 3D. FRAME_PACKING ====> TOP_BOTTOM\n");)
            }
            else if(E_USER_3D_MODE_TOP_BOTTOM_2_TOP_BOTTOM==u16_Video3Dmode)
            {
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_TOP_BOTTOM, E_XC_3D_OUTPUT_TOP_BOTTOM, E_XC_3D_PANEL_PELLICLE, MAIN_WINDOW);
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_TOP_BOTTOM, E_XC_3D_OUTPUT_TOP_BOTTOM, E_XC_3D_PANEL_PELLICLE, SUB_WINDOW);
                //MApi_XC_SetFrameBufferAddress(((SCALER_DNR_BUF_MEMORY_TYPE & MIU1) ? (SCALER_DNR_BUF_ADR | MIU_INTERVAL) : (SCALER_DNR_BUF_ADR)), SCALER_DNR_BUF_LEN, SUB_WINDOW);
                MENU_3D_DBG(printf("3D:Begin 3D. TOP_BOTTOM ====> TOP_BOTTOM\n");)
            }
            else  if(E_USER_3D_MODE_FRAME_ALTERNATIVE_2_TOP_BOTTOM==u16_Video3Dmode)
            {
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_FRAME_ALTERNATIVE, E_XC_3D_OUTPUT_TOP_BOTTOM, E_XC_3D_PANEL_PELLICLE, MAIN_WINDOW);
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_FRAME_ALTERNATIVE, E_XC_3D_OUTPUT_TOP_BOTTOM, E_XC_3D_PANEL_PELLICLE, SUB_WINDOW);
                MENU_3D_DBG(printf("3D:Begin 3D. FRAME_ALTERNATIVE ====> TOP_BOTTOM\n");)
            }

            else  if(E_USER_3D_MODE_SIDE_BY_SIDE_HALF_2_SIDE_BY_SIDE_HALF==u16_Video3Dmode)
            {
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_SIDE_BY_SIDE_HALF, E_XC_3D_OUTPUT_SIDE_BY_SIDE_HALF, E_XC_3D_PANEL_PELLICLE, MAIN_WINDOW);
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_SIDE_BY_SIDE_HALF, E_XC_3D_OUTPUT_SIDE_BY_SIDE_HALF, E_XC_3D_PANEL_PELLICLE, SUB_WINDOW);
                MENU_3D_DBG(printf("3D:Begin 3D. SIDE_BY_SIDE_HALF ====> SIDE_BY_SIDE_HALF\n");)
            }
            else if(E_USER_3D_MODE_FRAME_PACKING_2_SIDE_BY_SIDE_HALF==u16_Video3Dmode)
            {
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_FRAME_PACKING, E_XC_3D_OUTPUT_SIDE_BY_SIDE_HALF, E_XC_3D_PANEL_SHUTTER, MAIN_WINDOW);
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_FRAME_PACKING, E_XC_3D_OUTPUT_SIDE_BY_SIDE_HALF, E_XC_3D_PANEL_SHUTTER, SUB_WINDOW);
                //MAPI_XC_Set_3D_MainSub_FirstMode(FALSE);
                //MApi_XC_SetFrameBufferAddress(((SCALER_DNR_BUF_MEMORY_TYPE & MIU1) ? (SCALER_DNR_BUF_ADR | MIU_INTERVAL) : (SCALER_DNR_BUF_ADR)), SCALER_DNR_BUF_LEN, SUB_WINDOW);
                MENU_3D_DBG(printf("3D:Begin 3D. FRAME_PACKING ====> Side_By_Side\n");)
            }
            else if(E_USER_3D_MODE_LINE_ALTERNATIVE_2_SIDE_BY_SIDE_HALF==u16_Video3Dmode)
            {
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_LINE_ALTERNATIVE, E_XC_3D_OUTPUT_SIDE_BY_SIDE_HALF, E_XC_3D_PANEL_PELLICLE, MAIN_WINDOW);
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_MODE_NONE, E_XC_3D_OUTPUT_SIDE_BY_SIDE_HALF, E_XC_3D_PANEL_PELLICLE, SUB_WINDOW);
                MENU_3D_DBG(printf("\n\n=================================================\n");)
                MENU_3D_DBG(printf("3D: Begin 3D. LINE_ALTERNATIVE ===> SIDE_BY_SIDE_HALF\n");)
                MENU_3D_DBG(printf("=================================================\n");)
            }
            else if(E_USER_3D_MODE_TOP_BOTTOM_2_SIDE_BY_SIDE_HALF==u16_Video3Dmode)
            {
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_TOP_BOTTOM, E_XC_3D_OUTPUT_SIDE_BY_SIDE_HALF, E_XC_3D_PANEL_PELLICLE, MAIN_WINDOW);
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_MODE_NONE, E_XC_3D_OUTPUT_SIDE_BY_SIDE_HALF, E_XC_3D_PANEL_PELLICLE, SUB_WINDOW);
                MENU_3D_DBG(printf("\n\n=================================================\n");)
                MENU_3D_DBG(printf("3D: Begin 3D. TOP_BOTTOM ===> SIDE_BY_SIDE_HALF\n");)
                MENU_3D_DBG(printf("=================================================\n");)
            }

#if ENABLE_3D_LAP_PATCH
            if(MApp_MPlayer_IsMoviePlaying() && g_bForceMVOPHDuplicate)
            {
                U8 u8VideoType, u8TSStream;
                U16 u16Width, u16Height, u16DisplayX, u16DisplayY, u16DisplayWidth, u16DisplayHeight;
                U32 u32BuffAddr;
                if(gstVidStatus.u16HorSize >= MAX_MVOP_HDUPLICATE_SIZE)
                {
                    g_bForceMVOPHDuplicate = FALSE;  //mvop driver will skip duplicate if >= MAX_MVOP_HDUPLICATE_SIZE
                    MApp_Scaler_SetWindow(
                        NULL,
                        NULL,
                        NULL,
                        stSystemInfo[MAIN_WINDOW].enAspectRatio,
                        SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW),
                        MAIN_WINDOW);
                }
                else if(MApp_VDPlayer_GetDisplayPathInfo(&u8VideoType, &u16Width, &u16Height, &u16DisplayX, &u16DisplayY, &u16DisplayWidth, &u16DisplayHeight, &u32BuffAddr, &u8TSStream))
                {
                    _MApp_VDPlayer_SetupDisplayPath(u8VideoType, u8TSStream, u16Width, u16Height, u16DisplayX, u16DisplayY, u16DisplayWidth, u16DisplayHeight, u32BuffAddr);
                }
                MApp_Picture_Setting_SetColor(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW), MAIN_WINDOW);
            }
            else
#endif //#if ENABLE_3D_LAP_PATCH
            if(MApp_IsSrcHasSignal(MAIN_WINDOW))
            {
                #if ENABLE_CUS_UI_SPEC /*Creass.liu at 2012-08-01*/
                //remaping zoom mode to 16:9 when 3D mode on
                stSystemInfo[MAIN_WINDOW].enAspectRatio = MApp_Scaler_GetAspectRatio(ST_VIDEO.eAspectRatio);
                #endif

                MApp_Scaler_SetWindow(
                    NULL,
                    NULL,
                    NULL,
                    stSystemInfo[MAIN_WINDOW].enAspectRatio,
                    SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW),
                    MAIN_WINDOW);
                MApp_Picture_Setting_SetColor(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW), MAIN_WINDOW);
                /*if(E_USER_3D_MODE_VERTICAL_LINE_ALTERNATIVE_2_VERTICAL_LINE_ALTERNATIVE==u16_Video3Dmode)
                MApi_XC_ACE_3DClonePQMap(TRUE);
                else
                MApi_XC_ACE_3DClonePQMap(FALSE);
                */
                //MDrv_PQ_3DCloneforPIP(TRUE); //move to MApp_Picture_Setting_SetColor() /*Creass.liu at 2012-08-01*/
                msAPI_Scaler_SetBlueScreen(DISABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
                MApp_Scaler_SetTiming(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW), MAIN_WINDOW);
            }
        }
        break;

        default:
            break;
    }

    #if ENABLE_CUS_3D_SOURCE_MEMORY
    MApp_Scaler_Set3DScene_CUS();
    #endif

    return FALSE;
}

BOOLEAN MApp_Scaler_Set_3DMode(U16 u16_Video3Dmode)
{
    MENU_3D_DBG(printf("u16_Video3Dmode<<0x%x>>\n", u16_Video3Dmode);)
    MApi_XC_Set_3D_HShift(0); //Default set shift to 0 to avoid Non-2d->3d case use this shift to adjust 3D quality
    switch(u16_Video3Dmode)
    {
        case E_USER_3D_MODE_80:
        {
            MENU_3D_DBG(printf("******************************Usage Note******************************\n");)
            MENU_3D_DBG(printf("[0x00]3D:Close 3D\n");)

            MENU_3D_DBG(printf("[0x01]3D: Begin 3D. FRAME_PACKING ===> LINE_ALTERNATIVE\n");)
            MENU_3D_DBG(printf("[0x02]3D: Begin 3D. SIDE_BY_SIDE_HALF ===> LINE_ALTERNATIVE\n");)
            MENU_3D_DBG(printf("[0x03]3D: Begin 3D. Vertical LINE_ALTERNATIVE to Vertical LINE_ALTERNATIVE\n");)
            MENU_3D_DBG(printf("[0x04]3D: Begin 3D. LINE_ALTERNATIVE ===> LINE_ALTERNATIVE\n");)
            MENU_3D_DBG(printf("[0x05]3D: Begin 3D. SIDE_BY_SIDE_HALF_INTERLACE ===> LINE_ALTERNATIVE\n");)

            MENU_3D_DBG(printf("[0x11]3D: Begin 3D. LINE_ALTERNATIVE ====> TOP_BOTTOM\n");)
            MENU_3D_DBG(printf("[0x12]3D: Begin 3D. TOP_BOTTOM ====> TOP_BOTTOM\n");)
            MENU_3D_DBG(printf("[0x13]3D: Begin 3D. FRAME_ALTERNATIVE ====> TOP_BOTTOM\n");)
            MENU_3D_DBG(printf("[0x14]3D: Begin 3D. SIDE_BY_SIDE_HALF ====> SIDE_BY_SIDE_HALF\n");)
            MENU_3D_DBG(printf("[0x15]3D: Begin 3D. FRAME_PACKING ====> FRAME_ALTERNATIVE\n");)
            MENU_3D_DBG(printf("*********************************************************************\n");)
        }
            break;
        case E_USER_3D_MODE_OFF:
        case E_USER_3D_MODE_FRAME_PACKING_2_LINE_ALTERNATIVE:
        case E_USER_3D_MODE_SIDE_BY_SIDE_HALF_2_LINE_ALTERNATIVE:
        case E_USER_3D_MODE_SIDE_BY_SIDE_HALF_INTERLACE_2_LINE_ALTERNATIVE:
        case E_USER_3D_MODE_VERTICAL_LINE_ALTERNATIVE_2_VERTICAL_LINE_ALTERNATIVE:
        case E_USER_3D_MODE_LINE_ALTERNATIVE_2_LINE_ALTERNATIVE:
        case E_USER_3D_MODE_TOP_BOTTOM_2_LINE_ALTERNATIVE:
        case E_USER_3D_MODE_FRAME_ALTERNATIVE_2_LINE_ALTERNATIVE:

        case E_USER_3D_MODE_FRAME_PACKING_2_TOP_BOTTOM:
        case E_USER_3D_MODE_TOP_BOTTOM_2_TOP_BOTTOM:
        case E_USER_3D_MODE_FRAME_ALTERNATIVE_2_TOP_BOTTOM:

        case E_USER_3D_MODE_LINE_ALTERNATIVE_2_SIDE_BY_SIDE_HALF: //special case
        case E_USER_3D_MODE_SIDE_BY_SIDE_HALF_2_SIDE_BY_SIDE_HALF:
        case E_USER_3D_MODE_FRAME_PACKING_2_SIDE_BY_SIDE_HALF:
        case E_USER_3D_MODE_TOP_BOTTOM_2_SIDE_BY_SIDE_HALF:

        case E_USER_3D_MODE_FRAME_PACKING_2_FRAME_ALTERNATIVE_NOFRC:
        case E_USER_3D_MODE_SIDE_BY_SIDE_HALF_2_FRAME_ALTERNATIVE_NOFRC:
        case E_USER_3D_MODE_SIDE_BY_SIDE_HALF_INTERLACE_2_FRAME_ALTERNATIVE_NOFRC:
        case E_USER_3D_MODE_LINE_ALTERNATIVE_2_FRAME_ALTERNATIVE_NOFRC:
        case E_USER_3D_MODE_TOP_BOTTOM_2_FRAME_ALTERNATIVE_NOFRC:

        case E_USER_3D_MODE_FRAME_PACKING_2_FRAME_ALTERNATIVE:
        case E_USER_3D_MODE_TOP_BOTTOM_2_FRAME_ALTERNATIVE:
        case E_USER_3D_MODE_SIDE_BY_SIDE_HALF_2_FRAME_ALTERNATIVE:
        case E_USER_3D_MODE_LINE_ALTERNATIVE_2_FRAME_ALTERNATIVE:

        case E_USER_3D_MODE_FRAME_PACKING_2_FRAME_L:
        case E_USER_3D_MODE_SIDE_BY_SIDE_HALF_2_FRAME_L:
        case E_USER_3D_MODE_TOP_BOTTOM_2_FRAME_L:
        case E_USER_3D_MODE_LINE_ALTERNATIVE_2_FRAME_L:
        case E_USER_3D_MODE_FRAME_ALTERNATIVE_2_FRAME_L:

        case E_USER_3D_MODE_NORMAL_2D_2_LINE_ALTERNATIVE:
        case E_USER_3D_MODE_NORMAL_2D_2_FRAME_ALTERNATIVE_NOFRC:
        {
            if(MApp_Scaler_IsManualDetectTiming())
            {
               // MApp_InputSource_ChangeInputSource(MAIN_WINDOW);
                MApp_Scaler_EnableManualDetectTiming(FALSE);
            }
            //MApp_Scaler_EnableOverScan(DISABLE);

//            MApp_ZUI_API_Enable3DTwinMode(TRUE);

            #if (MS_BOARD_TYPE_SEL == BD_CUS_715G_5740)
            if((E_USER_3D_MODE_OFF==u16_Video3Dmode)
                || (E_USER_3D_MODE_FRAME_PACKING_2_FRAME_L==u16_Video3Dmode)
                || (E_USER_3D_MODE_SIDE_BY_SIDE_HALF_2_FRAME_L==u16_Video3Dmode)
                || (E_USER_3D_MODE_TOP_BOTTOM_2_FRAME_L==u16_Video3Dmode)
                || (E_USER_3D_MODE_LINE_ALTERNATIVE_2_FRAME_L==u16_Video3Dmode)
                || (E_USER_3D_MODE_FRAME_ALTERNATIVE_2_FRAME_L==u16_Video3Dmode))

            {
                //3d off or 3D to 2D
                PANEL_3D_ENABLE_OFF();
            }
            else
            {
                PANEL_3D_ENABLE_ON();
            }
            #endif

            if(E_USER_3D_MODE_OFF==u16_Video3Dmode)
            {
                //MApp_ZUI_API_Enable3DTwinMode(FALSE);
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_MODE_NONE, E_XC_3D_OUTPUT_MODE_NONE, E_XC_3D_PANEL_NONE, MAIN_WINDOW);
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_MODE_NONE, E_XC_3D_OUTPUT_MODE_NONE, E_XC_3D_PANEL_NONE, SUB_WINDOW);
                MENU_3D_DBG(printf("\n\n=================================================\n");)
                MENU_3D_DBG(printf("3D:Close 3D\n");)
                MENU_3D_DBG(printf("=================================================\n");)
                MApp_Scaler_EnableOverScan(ENABLE);

            }
            else if(E_USER_3D_MODE_FRAME_PACKING_2_LINE_ALTERNATIVE==u16_Video3Dmode)
            {
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_FRAME_PACKING, E_XC_3D_OUTPUT_LINE_ALTERNATIVE, E_XC_3D_PANEL_PELLICLE, MAIN_WINDOW);
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_MODE_NONE, E_XC_3D_OUTPUT_LINE_ALTERNATIVE, E_XC_3D_PANEL_PELLICLE, SUB_WINDOW);
                MENU_3D_DBG(printf("\n\n=================================================\n");)
                MENU_3D_DBG(printf("3D: Begin 3D. FRAME_PACKING ===> LINE_ALTERNATIVE\n");)
                MENU_3D_DBG(printf("=================================================\n");)
            }
            else if(E_USER_3D_MODE_FRAME_ALTERNATIVE_2_LINE_ALTERNATIVE==u16_Video3Dmode)
            {
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_FRAME_ALTERNATIVE, E_XC_3D_OUTPUT_LINE_ALTERNATIVE, E_XC_3D_PANEL_PELLICLE, MAIN_WINDOW);
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_MODE_NONE, E_XC_3D_OUTPUT_LINE_ALTERNATIVE, E_XC_3D_PANEL_PELLICLE, SUB_WINDOW);
                MENU_3D_DBG(printf("\n\n=================================================\n");)
                MENU_3D_DBG(printf("3D: Begin 3D. FRAME_ALTERNATIVE ===> LINE_ALTERNATIVE\n");)
                MENU_3D_DBG(printf("=================================================\n");)
            }
            else if(E_USER_3D_MODE_SIDE_BY_SIDE_HALF_2_LINE_ALTERNATIVE==u16_Video3Dmode)
            {
                g_bForceMVOPHDuplicate = TRUE;//Enable patch for small video on TP/SBS->LAP
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_SIDE_BY_SIDE_HALF, E_XC_3D_OUTPUT_LINE_ALTERNATIVE, E_XC_3D_PANEL_PELLICLE, MAIN_WINDOW);
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_MODE_NONE, E_XC_3D_OUTPUT_LINE_ALTERNATIVE, E_XC_3D_PANEL_PELLICLE, SUB_WINDOW);
                MENU_3D_DBG(printf("\n\n=================================================\n");)
                MENU_3D_DBG(printf("3D: Begin 3D. SIDE_BY_SIDE_HALF ===> LINE_ALTERNATIVE\n");)
                MENU_3D_DBG(printf("=================================================\n");)
            }
            else if(E_USER_3D_MODE_SIDE_BY_SIDE_HALF_INTERLACE_2_LINE_ALTERNATIVE==u16_Video3Dmode)
            {
                g_bForceMVOPHDuplicate = TRUE;//Enable patch for small video on TP/SBS->LAP
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_SIDE_BY_SIDE_HALF_INTERLACE, E_XC_3D_OUTPUT_LINE_ALTERNATIVE, E_XC_3D_PANEL_PELLICLE, MAIN_WINDOW);
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_MODE_NONE, E_XC_3D_OUTPUT_LINE_ALTERNATIVE, E_XC_3D_PANEL_PELLICLE, SUB_WINDOW);
                MENU_3D_DBG(printf("\n\n=================================================\n");)
                MENU_3D_DBG(printf("3D: Begin 3D. SIDE_BY_SIDE_HALF_INTERLACE ===> LINE_ALTERNATIVE\n");)
                MENU_3D_DBG(printf("=================================================\n");)
            }
            else if(E_USER_3D_MODE_VERTICAL_LINE_ALTERNATIVE_2_VERTICAL_LINE_ALTERNATIVE==u16_Video3Dmode)
            {
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_MODE_NONE, E_XC_3D_OUTPUT_MODE_NONE, E_XC_3D_PANEL_PELLICLE, MAIN_WINDOW);
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_MODE_NONE, E_XC_3D_OUTPUT_MODE_NONE, E_XC_3D_PANEL_PELLICLE, SUB_WINDOW);
                MENU_3D_DBG(printf("\n\n=================================================\n");)
                MENU_3D_DBG(printf("3D: Begin 3D. ByPassMode\n");)
                MENU_3D_DBG(printf("=================================================\n");)
            }
            else if(E_USER_3D_MODE_LINE_ALTERNATIVE_2_LINE_ALTERNATIVE==u16_Video3Dmode)
            {
                g_bForceMVOPHDuplicate = TRUE;//Enable patch for small video on TP/SBS->LAP
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_LINE_ALTERNATIVE, E_XC_3D_OUTPUT_LINE_ALTERNATIVE, E_XC_3D_PANEL_PELLICLE, MAIN_WINDOW);
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_MODE_NONE, E_XC_3D_OUTPUT_LINE_ALTERNATIVE, E_XC_3D_PANEL_PELLICLE, SUB_WINDOW);
                MENU_3D_DBG(printf("\n\n=================================================\n");)
                MENU_3D_DBG(printf("3D: Begin 3D. LINE_ALTERNATIVE ===> LINE_ALTERNATIVE\n");)
                MENU_3D_DBG(printf("=================================================\n");)
            }
            else if(E_USER_3D_MODE_TOP_BOTTOM_2_LINE_ALTERNATIVE==u16_Video3Dmode)
            {
                g_bForceMVOPHDuplicate = TRUE;//Enable patch for small video on TP/SBS->LAP
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_TOP_BOTTOM, E_XC_3D_OUTPUT_LINE_ALTERNATIVE, E_XC_3D_PANEL_SHUTTER, MAIN_WINDOW);
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_TOP_BOTTOM, E_XC_3D_OUTPUT_LINE_ALTERNATIVE, E_XC_3D_PANEL_SHUTTER, SUB_WINDOW);
                MENU_3D_DBG(printf("3D:Begin 3D. TOP_BOTTOM ====> LINE_ALTERNATIVE\n");)
            }
            else if(E_USER_3D_MODE_NORMAL_2D_2_LINE_ALTERNATIVE==u16_Video3Dmode)
            {
                MApi_XC_Set_3D_HShift(16);

                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_NORMAL_2D, E_XC_3D_OUTPUT_LINE_ALTERNATIVE, E_XC_3D_PANEL_PELLICLE, MAIN_WINDOW);
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_MODE_NONE, E_XC_3D_OUTPUT_LINE_ALTERNATIVE, E_XC_3D_PANEL_PELLICLE, SUB_WINDOW);
                MENU_3D_DBG(printf("3D: Begin 3D. NORMAL_2D ===> LINE_ALTERNATIVE\n");)
            }

            else  if(E_USER_3D_MODE_FRAME_PACKING_2_FRAME_ALTERNATIVE_NOFRC==u16_Video3Dmode)
            {
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_FRAME_PACKING, E_XC_3D_OUTPUT_FRAME_ALTERNATIVE_NOFRC, E_XC_3D_PANEL_PELLICLE, MAIN_WINDOW);
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_MODE_NONE, E_XC_3D_OUTPUT_FRAME_ALTERNATIVE_NOFRC, E_XC_3D_PANEL_PELLICLE, SUB_WINDOW);
                MENU_3D_DBG(printf("3D:Begin 3D. FRAME_PACKING ====> FRAME_ALTERNATIVE_NOFRC\n");)
            }
            else  if(E_USER_3D_MODE_TOP_BOTTOM_2_FRAME_ALTERNATIVE_NOFRC==u16_Video3Dmode)
            {
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_TOP_BOTTOM, E_XC_3D_OUTPUT_FRAME_ALTERNATIVE_NOFRC, E_XC_3D_PANEL_PELLICLE, MAIN_WINDOW);
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_MODE_NONE, E_XC_3D_OUTPUT_FRAME_ALTERNATIVE_NOFRC, E_XC_3D_PANEL_PELLICLE, SUB_WINDOW);
                MENU_3D_DBG(printf("3D:Begin 3D. TOP_BOTTOM ====> FRAME_ALTERNATIVE_NOFRC\n");)
            }
            else  if(E_USER_3D_MODE_SIDE_BY_SIDE_HALF_2_FRAME_ALTERNATIVE_NOFRC==u16_Video3Dmode)
            {
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_SIDE_BY_SIDE_HALF, E_XC_3D_OUTPUT_FRAME_ALTERNATIVE_NOFRC, E_XC_3D_PANEL_PELLICLE, MAIN_WINDOW);
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_MODE_NONE, E_XC_3D_OUTPUT_FRAME_ALTERNATIVE_NOFRC, E_XC_3D_PANEL_PELLICLE, SUB_WINDOW);
                MENU_3D_DBG(printf("3D:Begin 3D. SIDE_BY_SIDE_HALF ====> FRAME_ALTERNATIVE_NOFRC\n");)
            }
            else if(E_USER_3D_MODE_SIDE_BY_SIDE_HALF_INTERLACE_2_FRAME_ALTERNATIVE_NOFRC==u16_Video3Dmode)
            {
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_SIDE_BY_SIDE_HALF_INTERLACE, E_XC_3D_OUTPUT_FRAME_ALTERNATIVE_NOFRC, E_XC_3D_PANEL_PELLICLE, MAIN_WINDOW);
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_MODE_NONE, E_XC_3D_OUTPUT_FRAME_ALTERNATIVE_NOFRC, E_XC_3D_PANEL_PELLICLE, SUB_WINDOW);
                MENU_3D_DBG(printf("3D:Begin 3D. SIDE_BY_SIDE_HALF_INTERLACE ====> FRAME_ALTERNATIVE_NOFRC\n");)
            }
            else  if(E_USER_3D_MODE_LINE_ALTERNATIVE_2_FRAME_ALTERNATIVE_NOFRC==u16_Video3Dmode)
            {
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_LINE_ALTERNATIVE, E_XC_3D_OUTPUT_FRAME_ALTERNATIVE_NOFRC, E_XC_3D_PANEL_PELLICLE, MAIN_WINDOW);
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_MODE_NONE, E_XC_3D_OUTPUT_FRAME_ALTERNATIVE_NOFRC, E_XC_3D_PANEL_PELLICLE, SUB_WINDOW);
                MENU_3D_DBG(printf("3D:Begin 3D. LINE_ALTERNATIVE ====> FRAME_ALTERNATIVE_NOFRC\n");)
            }
            else if(E_USER_3D_MODE_NORMAL_2D_2_FRAME_ALTERNATIVE_NOFRC==u16_Video3Dmode)
            {
                MApi_XC_Set_3D_HShift(16);

                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_NORMAL_2D, E_XC_3D_OUTPUT_FRAME_ALTERNATIVE_NOFRC, E_XC_3D_PANEL_PELLICLE, MAIN_WINDOW);
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_MODE_NONE, E_XC_3D_OUTPUT_FRAME_ALTERNATIVE_NOFRC, E_XC_3D_PANEL_PELLICLE, SUB_WINDOW);
                MENU_3D_DBG(printf("3D: Begin 3D. NORMAL_2D ===> FRAME_ALTERNATIVE\n");)
            }

            else  if(E_USER_3D_MODE_FRAME_PACKING_2_FRAME_ALTERNATIVE==u16_Video3Dmode)
            {
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_FRAME_PACKING, E_XC_3D_OUTPUT_FRAME_ALTERNATIVE, E_XC_3D_PANEL_PELLICLE, MAIN_WINDOW);
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_MODE_NONE, E_XC_3D_OUTPUT_FRAME_ALTERNATIVE, E_XC_3D_PANEL_PELLICLE, SUB_WINDOW);
                MENU_3D_DBG(printf("3D:Begin 3D. FRAME_PACKING ====> FRAME_ALTERNATIVE\n");)
            }
            else  if(E_USER_3D_MODE_TOP_BOTTOM_2_FRAME_ALTERNATIVE==u16_Video3Dmode)
            {
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_TOP_BOTTOM, E_XC_3D_OUTPUT_FRAME_ALTERNATIVE, E_XC_3D_PANEL_PELLICLE, MAIN_WINDOW);
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_MODE_NONE, E_XC_3D_OUTPUT_FRAME_ALTERNATIVE, E_XC_3D_PANEL_PELLICLE, SUB_WINDOW);
                MENU_3D_DBG(printf("3D:Begin 3D. TOP_BOTTOM ====> FRAME_ALTERNATIVE\n");)
            }
            else  if(E_USER_3D_MODE_SIDE_BY_SIDE_HALF_2_FRAME_ALTERNATIVE==u16_Video3Dmode)
            {
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_SIDE_BY_SIDE_HALF, E_XC_3D_OUTPUT_FRAME_ALTERNATIVE, E_XC_3D_PANEL_PELLICLE, MAIN_WINDOW);
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_MODE_NONE, E_XC_3D_OUTPUT_FRAME_ALTERNATIVE, E_XC_3D_PANEL_PELLICLE, SUB_WINDOW);
                MENU_3D_DBG(printf("3D:Begin 3D. SIDE_BY_SIDE_HALF ====> FRAME_ALTERNATIVE\n");)
            }
            else  if(E_USER_3D_MODE_LINE_ALTERNATIVE_2_FRAME_ALTERNATIVE==u16_Video3Dmode)
            {
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_LINE_ALTERNATIVE, E_XC_3D_OUTPUT_FRAME_ALTERNATIVE, E_XC_3D_PANEL_PELLICLE, MAIN_WINDOW);
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_MODE_NONE, E_XC_3D_OUTPUT_FRAME_ALTERNATIVE, E_XC_3D_PANEL_PELLICLE, SUB_WINDOW);
                MENU_3D_DBG(printf("3D:Begin 3D. LINE_ALTERNATIVE ====> FRAME_ALTERNATIVE\n");)
            }

            else  if(E_USER_3D_MODE_FRAME_PACKING_2_FRAME_L==u16_Video3Dmode)
            {
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_FRAME_PACKING, E_XC_3D_OUTPUT_FRAME_L, E_XC_3D_PANEL_PELLICLE, MAIN_WINDOW);
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_MODE_NONE, E_XC_3D_OUTPUT_FRAME_L, E_XC_3D_PANEL_PELLICLE, SUB_WINDOW);
                MENU_3D_DBG(printf("3D:Begin 3D. FRAME_PACKING ====> FRAME_L\n");)
            }
            else  if(E_USER_3D_MODE_SIDE_BY_SIDE_HALF_2_FRAME_L==u16_Video3Dmode)
            {
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_SIDE_BY_SIDE_HALF, E_XC_3D_OUTPUT_FRAME_L, E_XC_3D_PANEL_PELLICLE, MAIN_WINDOW);
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_MODE_NONE, E_XC_3D_OUTPUT_FRAME_L, E_XC_3D_PANEL_PELLICLE, SUB_WINDOW);
                MENU_3D_DBG(printf("3D:Begin 3D. SIDE_BY_SIDE_HALF ====> FRAME_L\n");)
            }
            else  if(E_USER_3D_MODE_TOP_BOTTOM_2_FRAME_L==u16_Video3Dmode)
            {
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_TOP_BOTTOM, E_XC_3D_OUTPUT_FRAME_L, E_XC_3D_PANEL_PELLICLE, MAIN_WINDOW);
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_MODE_NONE, E_XC_3D_OUTPUT_FRAME_L, E_XC_3D_PANEL_PELLICLE, SUB_WINDOW);
                MENU_3D_DBG(printf("3D:Begin 3D. TOP_BOTTOM ====> FRAME_L\n");)
            }
            else  if(E_USER_3D_MODE_LINE_ALTERNATIVE_2_FRAME_L==u16_Video3Dmode)
            {
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_LINE_ALTERNATIVE, E_XC_3D_OUTPUT_FRAME_L, E_XC_3D_PANEL_PELLICLE, MAIN_WINDOW);
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_MODE_NONE, E_XC_3D_OUTPUT_FRAME_L, E_XC_3D_PANEL_PELLICLE, SUB_WINDOW);
                MENU_3D_DBG(printf("3D:Begin 3D. LINE_ALTERNATIVE ====> FRAME_L\n");)
            }
            else  if(E_USER_3D_MODE_FRAME_ALTERNATIVE_2_FRAME_L==u16_Video3Dmode)
            {
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_FRAME_ALTERNATIVE, E_XC_3D_OUTPUT_FRAME_L, E_XC_3D_PANEL_PELLICLE, MAIN_WINDOW);
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_MODE_NONE, E_XC_3D_OUTPUT_FRAME_L, E_XC_3D_PANEL_PELLICLE, SUB_WINDOW);
                MENU_3D_DBG(printf("3D:Begin 3D. FRAME_ALTERNATIVE ====> FRAME_L\n");)
            }

            else if(E_USER_3D_MODE_FRAME_PACKING_2_TOP_BOTTOM==u16_Video3Dmode)
            {
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_FRAME_PACKING, E_XC_3D_OUTPUT_TOP_BOTTOM, E_XC_3D_PANEL_SHUTTER, MAIN_WINDOW);
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_FRAME_PACKING, E_XC_3D_OUTPUT_TOP_BOTTOM, E_XC_3D_PANEL_SHUTTER, SUB_WINDOW);
                //MAPI_XC_Set_3D_MainSub_FirstMode(FALSE);
                //MApi_XC_SetFrameBufferAddress(((SCALER_DNR_BUF_MEMORY_TYPE & MIU1) ? (SCALER_DNR_BUF_ADR | MIU_INTERVAL) : (SCALER_DNR_BUF_ADR)), SCALER_DNR_BUF_LEN, SUB_WINDOW);
                MENU_3D_DBG(printf("3D:Begin 3D. FRAME_PACKING ====> TOP_BOTTOM\n");)
            }
            else if(E_USER_3D_MODE_TOP_BOTTOM_2_TOP_BOTTOM==u16_Video3Dmode)
            {
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_TOP_BOTTOM, E_XC_3D_OUTPUT_TOP_BOTTOM, E_XC_3D_PANEL_PELLICLE, MAIN_WINDOW);
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_TOP_BOTTOM, E_XC_3D_OUTPUT_TOP_BOTTOM, E_XC_3D_PANEL_PELLICLE, SUB_WINDOW);
                //MApi_XC_SetFrameBufferAddress(((SCALER_DNR_BUF_MEMORY_TYPE & MIU1) ? (SCALER_DNR_BUF_ADR | MIU_INTERVAL) : (SCALER_DNR_BUF_ADR)), SCALER_DNR_BUF_LEN, SUB_WINDOW);
                MENU_3D_DBG(printf("3D:Begin 3D. TOP_BOTTOM ====> TOP_BOTTOM\n");)
            }
            else  if(E_USER_3D_MODE_FRAME_ALTERNATIVE_2_TOP_BOTTOM==u16_Video3Dmode)
            {
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_FRAME_ALTERNATIVE, E_XC_3D_OUTPUT_TOP_BOTTOM, E_XC_3D_PANEL_PELLICLE, MAIN_WINDOW);
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_FRAME_ALTERNATIVE, E_XC_3D_OUTPUT_TOP_BOTTOM, E_XC_3D_PANEL_PELLICLE, SUB_WINDOW);
                MENU_3D_DBG(printf("3D:Begin 3D. FRAME_ALTERNATIVE ====> TOP_BOTTOM\n");)
            }

            else  if(E_USER_3D_MODE_SIDE_BY_SIDE_HALF_2_SIDE_BY_SIDE_HALF==u16_Video3Dmode)
            {
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_SIDE_BY_SIDE_HALF, E_XC_3D_OUTPUT_SIDE_BY_SIDE_HALF, E_XC_3D_PANEL_PELLICLE, MAIN_WINDOW);
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_SIDE_BY_SIDE_HALF, E_XC_3D_OUTPUT_SIDE_BY_SIDE_HALF, E_XC_3D_PANEL_PELLICLE, SUB_WINDOW);
                MENU_3D_DBG(printf("3D:Begin 3D. SIDE_BY_SIDE_HALF ====> SIDE_BY_SIDE_HALF\n");)
            }
            else if(E_USER_3D_MODE_FRAME_PACKING_2_SIDE_BY_SIDE_HALF==u16_Video3Dmode)
            {
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_FRAME_PACKING, E_XC_3D_OUTPUT_SIDE_BY_SIDE_HALF, E_XC_3D_PANEL_SHUTTER, MAIN_WINDOW);
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_FRAME_PACKING, E_XC_3D_OUTPUT_SIDE_BY_SIDE_HALF, E_XC_3D_PANEL_SHUTTER, SUB_WINDOW);
                //MAPI_XC_Set_3D_MainSub_FirstMode(FALSE);
                //MApi_XC_SetFrameBufferAddress(((SCALER_DNR_BUF_MEMORY_TYPE & MIU1) ? (SCALER_DNR_BUF_ADR | MIU_INTERVAL) : (SCALER_DNR_BUF_ADR)), SCALER_DNR_BUF_LEN, SUB_WINDOW);
                MENU_3D_DBG(printf("3D:Begin 3D. FRAME_PACKING ====> Side_By_Side\n");)
            }
            else if(E_USER_3D_MODE_LINE_ALTERNATIVE_2_SIDE_BY_SIDE_HALF==u16_Video3Dmode)
            {
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_LINE_ALTERNATIVE, E_XC_3D_OUTPUT_SIDE_BY_SIDE_HALF, E_XC_3D_PANEL_PELLICLE, MAIN_WINDOW);
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_MODE_NONE, E_XC_3D_OUTPUT_SIDE_BY_SIDE_HALF, E_XC_3D_PANEL_PELLICLE, SUB_WINDOW);
                MENU_3D_DBG(printf("\n\n=================================================\n");)
                MENU_3D_DBG(printf("3D: Begin 3D. LINE_ALTERNATIVE ===> SIDE_BY_SIDE_HALF\n");)
                MENU_3D_DBG(printf("=================================================\n");)
            }
            else if(E_USER_3D_MODE_TOP_BOTTOM_2_SIDE_BY_SIDE_HALF==u16_Video3Dmode)
            {
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_TOP_BOTTOM, E_XC_3D_OUTPUT_SIDE_BY_SIDE_HALF, E_XC_3D_PANEL_PELLICLE, MAIN_WINDOW);
                MApi_XC_Set_3D_Mode(E_XC_3D_INPUT_MODE_NONE, E_XC_3D_OUTPUT_SIDE_BY_SIDE_HALF, E_XC_3D_PANEL_PELLICLE, SUB_WINDOW);
                MENU_3D_DBG(printf("\n\n=================================================\n");)
                MENU_3D_DBG(printf("3D: Begin 3D. TOP_BOTTOM ===> SIDE_BY_SIDE_HALF\n");)
                MENU_3D_DBG(printf("=================================================\n");)
            }
            break;

        default:
            break;
    }
  }
    return FALSE;
}

void MApp_Scaler_Close3DFunction(void )
{
    #if (ENABLE_CUS_3D_SOURCE_MEMORY == DISABLE)
    E_XC_3D_INPUT_MODE eInput3DMode;
    #endif

    if(ST_3D_TYPE !=EN_3D_BYPASS)
    {
        g_HdmiInput3DFormat = E_XC_3D_INPUT_MODE_NONE;
        g_HdmiInput3DFormatStatus = E_XC_3D_INPUT_MODE_NONE;

        printf(" -->Close 3D Type \n");/*Creass.liu at 2012-06-28*/
    #if (ENABLE_CUS_3D_SOURCE_MEMORY == DISABLE)
        ST_3D_TYPE=EN_3D_BYPASS;
        ST_3D_LRMODE=EN_3D_LR_L;
    #endif
    #if (ENABLE_6M30_3D_PROCESS)
        MDrv_Ursa_6M30_3D_MODE(ST_3D_TYPE);
    #endif
    #if ENABLE_CUS_3D_SOURCE_MEMORY
        MApp_Scaler_EnableManualDetectTiming(TRUE);
        msAPI_Scaler_SetBlueScreen(ENABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
        MApp_Scaler_SetVideo3DMode(E_USER_3D_MODE_OFF);
    #else
        eInput3DMode = MAPP_Scaler_MapUI3DModeToXC3DMode(ST_3D_TYPE);
        MApp_Scaler_EnableManualDetectTiming(TRUE);
        msAPI_Scaler_SetBlueScreen(ENABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
        MApp_Scaler_SetVideo3DMode(MAPP_Scaler_Map3DFormatTo3DUserMode(eInput3DMode));
    #endif

    #if ENABLE_UI_3D_PROCESS
        MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_CLOSE_CURRENT_OSD);
        stGenSetting.g_SysSetting.en3DUIMODE = E_UI_3D_UI_MODE_NUM;
    #else
        msAPI_Scaler_SetBlueScreen(DISABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
    #endif

    }
}

#endif


#if 0//VGA_HDMI_YUV_POINT_TO_POINT
BOOLEAN MApp_CheckHDMI_PCTiming_FBL(void)
{
    U8 u8Resolution=0;
    XC_SETWIN_INFO XC_SetWin_Info ;

    memset(&XC_SetWin_Info, 0, sizeof(XC_SETWIN_INFO));

  #if (INPUT_HDMI_VIDEO_COUNT > 0)
    if(IsSrcTypeHDMI(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)))
    {
        // DVI or HDMI
        MApi_XC_GetDEWindow(&(XC_SetWin_Info.stCapWin), MAIN_WINDOW);

        u8Resolution = _MApp_Scaler_Resolution_Remapping(&XC_SetWin_Info, MAIN_WINDOW);

        if ((u8Resolution==E_HDMI_MAX)&&(!XC_SetWin_Info.bInterlace)
            &&(!_MApp_CheckBWOK(XC_SetWin_Info.stCapWin.width,
                                XC_SetWin_Info.stCapWin.height,
                                MApi_XC_PCMonitor_Get_VFreqx10(MAIN_WINDOW))))
        {
            (printf(" use FBL \r\n"));
            return TRUE;
        }
     }
  #endif

    return FALSE;
}
#endif

#if ENABLE_CUS_HDMI_MODE
BOOLEAN MApp_Scaler_CheckHDMIModeAvailable(void)
{
    U16 u16H, u16V;
    //480p,576p,720p,1080p is OK!
    if(IsHDMIInUse())
    {
        if (MApp_IsSrcHasSignal(MAIN_WINDOW) == FALSE)
        {
            return FALSE;
        }

        if (MApi_XC_PCMonitor_GetSyncStatus(MAIN_WINDOW) & XC_MD_INTERLACE_BIT)
        {
            return FALSE;
        }

        u16V = MApp_PCMode_Get_VResolution(MAIN_WINDOW,FALSE);
        u16H = MApp_PCMode_Get_HResolution(MAIN_WINDOW,FALSE);
        if((u16V==0)||(u16H==0))
        {
            return FALSE;
        }

        if ((u16H >= 710 && u16H <= 1540) && (u16V >= 470 && u16V <= 490))
        {
            //printf("\r\nHDMI 480p");
            u16V = 480;
        }
        else if ((u16H>=710 && u16H<=1540)&&(u16V > 566 && u16V < 586))
        {
            //printf("\r\nHDMI 576P");
            u16V = 576;
        }
        // 1280x720
        else if((u16V > 710 && u16V < 730) && (u16H> 1270 && u16H < 1290))
        {
            //printf("\r\nHDMI 720p");
            u16V = 720;
        }
        // 1920x1080
        else if((u16V > 1070 && u16V < 1090) && (u16H > 1910 && u16H < 1930))
        {
            //printf("\r\nHDMI 1080p");
            u16V = 1080;
        }
        else
        {
            return FALSE;
        }

        return TRUE;

    }
    else
    {
        return FALSE;
    }
}

#endif

#if ENABLE_CUS_UI_SPEC
BOOLEAN MApp_Scaler_CheckDBC_DLCAvailable(void)
{
    if(IsVgaInUse()
        #if ENABLE_CUS_HDMI_MODE
        || (IsHDMIInUse() && (stGenSetting.g_SysSetting.bIsHDMIVideoMode == FALSE) && (MApp_Scaler_CheckHDMIModeAvailable() == TRUE))
        #endif
        #if VGA_HDMI_YUV_POINT_TO_POINT
        || (IsHDMIInUse()&&MDrv_PQ_Check_PointToPoint_Mode() && (ST_VIDEO.eAspectRatio == EN_AspectRatio_point_to_point))
        #endif
        || (IsHDMIInUse()&&(g_HdmiPollingStatus.bIsHDMIMode == TRUE) && (ST_VIDEO.eAspectRatio == EN_AspectRatio_point_to_point))
        || (IsHDMIInUse() && (g_HdmiPollingStatus.bIsHDMIMode == FALSE ))
        )
    {
        return FALSE;
    }
    else
    {
        return TRUE;
    }
}
#endif



/******************************************************************************/
//SMC jayden.chen add for set free run display window size when no singal 20130311
/******************************************************************************/
#define BK_REG_L_SMC( x, y )  ((x) | (((y) << 1)))
#define BK_REG_H_SMC( x, y )  (((x) | (((y) << 1))) + 1)

#define L_BK_VOP_SMC(x)         BK_REG_L_SMC(BK_SCALER_BASE,x)
#define H_BK_VOP_SMC(x)         BK_REG_H_SMC(BK_SCALER_BASE,x)

void MDrv_Scaler_SetFreeRunWindow ( void )
{

    U8 u8Bank;
    PanelType *pPanelType = MApi_XC_GetPanelSpec(g_PNL_TypeSel);
    u8Bank = MDrv_ReadByte(0x102F00);
    MDrv_WriteByte(0x102F00, 0x10);
    MDrv_Write2Byte(L_BK_VOP_SMC(0x08), pPanelType->m_wPanelHStart); // Image H start
    MDrv_Write2Byte(L_BK_VOP_SMC(0x09), pPanelType->m_wPanelHStart + devPanel_WIDTH() - 1); // Image H end
    MDrv_Write2Byte(L_BK_VOP_SMC(0x0A), 0);// Image V end
    MDrv_Write2Byte(L_BK_VOP_SMC(0x0B), devPanel_HEIGHT() - 1);// DE V end

    MDrv_WriteByte(0x102F00, u8Bank);
    
    if (g_bIsImageFrozen)
    {
       g_bIsImageFrozen = FALSE;
       MApi_XC_FreezeImg(g_bIsImageFrozen, MAIN_WINDOW);
    }

}
//------------------------------------------------------------





////////////////////////////////////////////////////////////////////////////////
#undef MAPP_SCALER_C

