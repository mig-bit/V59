////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

//-------------------------------------------------------------------------------------------------
// File Name:
//        MApp_Subtitle.h
// Description:
//        This file declares the functions that response to the user requests. The functionalities of these functions are
//          1. initialize subtitle decoder - this one gives the decoder a chance to initialize internal variables
//          2. set PID - this one tells the decoder which PID will contains subtitle data
//          3. get PID - this one returns PID currently used by subtitle decoder
//          4. set page/ancillary id - this one tells the decoder which subtitle service is desired
//          5. get page/ancillary id - this one returns page/ancillary id currently used by subtitle decoder
//          6. get decoder state - this one returns the current state of subtitle decoder
//          7. start/stop decoder - these two start/stop subtitle decoder. All set functions can only issued when decoder
//              is in stop state.
//          8. deinitialize subtitle decoder - this one gives the decoder a chance to return resource to system
// Note:
//        MStar Semi.
//-------------------------------------------------------------------------------------------------

#ifndef MAPP_JPEG_H
#define MAPP_JPEG_H

//-------------------------------------------------------------------------------------------------
// Standard include files:
//-------------------------------------------------------------------------------------------------
#include "datatype.h"
#include "MApp_Exit.h"
#include "MApp_Key.h"




#ifdef MAPP_JPEG_C
#define INTERFACE
#else
#define INTERFACE extern
#endif

//-------------------------------------------------------------------------------------------------
// Project include files:
//-------------------------------------------------------------------------------------------------

//-------------------------------------------------------------------------------------------------
// Defines
//-------------------------------------------------------------------------------------------------
typedef enum
{
    JPEG_RETURN_DECODING = 0,
    JPEG_RETURN_SUCCESS,
    JPEG_RETURN_ERR_FILE,
    JPEG_RETURN_ERR_DECODE,
    JPEG_RETURN_ERR_NO_THUMBNAIL,
    JPEG_RETURN_ERR_NOT_JPEG,
    JPEG_RETURN_ERR_NO_EXIF,
    JPEG_RETURN_INIT,
} JPEG_RETURN_STATUS;

typedef enum
{
    JPEG_CMD_DECODE_SD,
    JPEG_CMD_DECODE_HD,
    JPEG_CMD_PLAY,
    JPEG_CMD_STOP,
} JPEG_PLAY_COMMAND;


//-------------------------------------------------------------------------------------------------
// Macros
//-------------------------------------------------------------------------------------------------

//-------------------------------------------------------------------------------------------------
// Type and Structure Declaration
//-------------------------------------------------------------------------------------------------

//-------------------------------------------------------------------------------------------------
// Extern Global Variabls
//-------------------------------------------------------------------------------------------------


//-------------------------------------------------------------------------------------------------
// Extern Functions
///-------------------------------------------------------------------------------------------------
INTERFACE void MApp_Jpeg_SetupDisplayInfo(U16 u16OutputX, U16 u16OutputY, U16 u16OutputWidth, U16 u16OutputHeight, U32 u32DecodeAddr, U16 u16LineSize);
INTERFACE void MApp_Jpeg_EnableThumbnail(U8 bEnableThumb);
INTERFACE JPEG_RETURN_STATUS MApp_JPEG_GetExifInfo(FileEntry* pFileEntry, JPEG_EXIF_INFO *pExifInfo);
INTERFACE JPEG_DECODE_STATUS MApp_Jpeg_Decode (FileEntry* pFileEntry, U16 dataOffset,U16 dataSize, JPEG_PLAY_COMMAND enCommand);

#undef INTERFACE

#endif // _MAPP_SUBTITLE_H

