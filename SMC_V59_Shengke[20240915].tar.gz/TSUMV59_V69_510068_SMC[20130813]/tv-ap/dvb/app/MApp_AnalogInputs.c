////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#define _MAPP_ANALOGINPUTS_C

//------------------------------------------------------------------------------
//                            Header Files
//------------------------------------------------------------------------------
#include <string.h>
#include <stdio.h>

#include "MsCommon.h"
#include "MApp_Main.h"
#include "MApp_Exit.h"
#include "MApp_GlobalVar.h"
#include "MApp_GlobalSettingSt.h"
#include "MApp_GlobalFunction.h"
#include "MApp_Key.h"
#include "MApp_IR.h"
#include "MApp_Audio.h"
#include "MApp_MultiTasks.h"

#include "MApp_DataBase.h"
#include "MApp_Scan.h"
#include "MApp_Font.h"
#include "MApp_InputSource.h"
#include "MApp_PCMode.h"
#include "MApp_VDMode.h"
#include "MApp_AnalogInputs.h"
#include "MApp_TV.h"
#include "MApp_ChannelChange.h"
#include "MApp_Bitmap.h"
#include "apiXC_Ace.h"
#include "MApp_Sleep.h"
#include "MApp_Scaler.h"
#include "MApp_UiMenuDef.h"
#include "MApp_ZUI_Main.h"
#include "ZUI_tables_h.inl"
#include "ZUI_exefunc.h"
#include "MApp_BlockSys.h"
#include "MApp_SaveData.h"
#include "MApp_ATVProc.h"
#include "MApp_ChannelList.h"

#include "msAPI_OSD.h"
#include "apiGOP.h"
#include "msAPI_Timer.h"
#include "msAPI_Mode.h"

#include "apiXC_Sys.h"
#include "apiXC_PCMonitor.h"

#include "msAPI_DTVSystem.h"
#include "msAPI_DrvInit.h"
#include "msAPI_audio.h"
#include "msAPI_Tuning.h"
#include "msAPI_ChProc.h"
#if ENABLE_TTX
#include "msAPI_TTX.h"
#include "mapp_ttx.h"
#endif

#include "MApp_TopStateMachine.h"
#include "GPIO.h"
#include "drvpower_if.h"
#include "msAPI_FreqTableATV.h"

#include "msIR.h"

#if ENABLE_DMP
#include "mapp_mplayer.h"
#include "MApp_UiMediaPlayer.h"
#endif


#if ENABLE_CI
#include "MApp_CIMMI.h"
#include "msAPI_CI.h"
#endif

#if ENABLE_SBTVD_BRAZIL_APP
#include "mapp_closedcaption.h"
#endif

#if (((ENABLE_SBTVD_BRAZIL_APP)&&(BRAZIL_CC))||(ATSC_CC == ATV_CC))
#include "mapp_closedcaption.h"
#endif
#include "MApp_ZUI_ACTcoexistWin.h"

#if (ENABLE_ATV_VCHIP)
#include "MApp_VChip.h"
#include "MApp_ZUI_ACTmsgbox.h"
#endif

#include "MApp_ZUI_ACTmenufunc.h"
#include "MApp_ZUI_ACTmainpage.h"
#if ENABLE_DTV_EPG //ENABLE_DTV
    extern void MApp_ZUI_EpgTimerCountDown(void);
    extern BOOLEAN MApp_TV_ProcessEpgCountDownKey(U8 key);
#endif

//------------------------------------------------------------------------------
//                                Local
//------------------------------------------------------------------------------
#define ANALOGINPUTS_DBINFO(y)   //y

#define TV_MODE_WINDOW_MONITOR_PERIOD 2000 //ms
#define TV_MODE_WINDOW_MONITOR_PERIOD_NOSINGAL 50 //ms

#define DELAY_4SEC  10

//static EN_RET enAnalogInputsRetVal;
//static EN_ANALOGINPUTS_STATE enAnalogInputsState = STATE_ANALOGINPUTS_INIT;
static U32 u32AnalogInputsModeWinTimer[PIP_WINDOWS];
#if (ATSC_CC == ATV_CC)
static BOOLEAN DigitalCCState=FALSE;
#endif

#if ENABLE_TTX
//static U_INT8 SubtitlePageIndex;
#endif
extern EN_RET enTVRetVal;
extern EN_TV_STATE enTVState;
BOOLEAN MApp_Analog_NoSignal_ExcludeATV()
{
     return ( ( ( IsVgaInUse() || IsYPbPrInUse() || (IsHDMIInUse()) ) && MApi_XC_PCMonitor_SyncLoss(MAIN_WINDOW) )
               || ((IsAVInUse()||(IsSVInUse())||(IsScartInUse()))&&(!MApp_VD_IsSyncLock())));
}

//------------------------------------------------------------------------------
// Function name:    MApp_AnalogInputs_FunctionNotAvailableCheck
// Passing parameter:    none
// Return parameter:    none
// Description:      If function not available, draw a warning message dialog then return true
//------------------------------------------------------------------------------
BOOLEAN MApp_AnalogInputs_FunctionNotAvailableCheck()
{
    if ( MApp_Analog_NoSignal_ExcludeATV() )
    {
        //ZUI: #if SHOW_NOT_AVAILABLE_WARNING_MESSAGE
        //ZUI: MApp_UiMenu_Show_Warning_Message_Dialog(MENU_FUNCTION_NOT_AVAILABLE_MSG);
        MApp_ZUI_ACT_StartupOSD(E_OSD_MESSAGE_BOX);
        MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_SHOW_FUNC_NOT_AVAIL_MSGBOX);
        //ZUI: #endif
       return TRUE;
    }
    return FALSE;
}

/********************************************************************************/
/*                   Functions                      */
/********************************************************************************/
//*************************************************************************
//Function name:    MApp_AnalogInputs_DeleteWin
//Passing parameter:    none
//Return parameter:    none
//Description:      Delete idle mode OSD window
//*************************************************************************
void MApp_AnalogInputs_DeleteWin(void)
{
    /*/ZUI:
    if (enCurTVWin != DISP_WIN_NONEOSD &&
        enCurTVWin != DISP_WIN_MUTE) //2007/10/25: fix mute blinking in AV mode
    {
        MApp_UiMenu_HideShortcut();
        MApp_UiMenu2_HideOSDGwin(GWIN_MAIN_MENU);
        enCurTVWin = DISP_WIN_NONEOSD;
    }
    */
}

//*************************************************************************
//Function name:    MApp_AnalogInputs_MonitorWindows
//Passing parameter:    none
//Return parameter:    none
//Description:      Monitor idle mode OSD window
//*************************************************************************
void MApp_AnalogInputs_MonitorWindows(SCALER_WIN eWindow)
{
    static U8 su8NoSignalDisplayCNT[PIP_WINDOWS] = {DELAY_4SEC, DELAY_4SEC};
    static U8 u8HdmiNosignalCounter = 0;
    MApp_NoSignalSleep_Monitor();

    // monitor all windows in idle mode
    if (msAPI_Timer_DiffTimeFromNow(u32AnalogInputsModeWinTimer[eWindow]) > TV_MODE_WINDOW_MONITOR_PERIOD_NOSINGAL) //unit = ms
    {
        if(IsSrcTypeAnalog(SYS_INPUT_SOURCE_TYPE(eWindow)) || IsSrcTypeHDMI(SYS_INPUT_SOURCE_TYPE(eWindow)))   //PC & YPBPR
        {
#if (INPUT_HDMI_VIDEO_COUNT > 0)
            if((IsSrcTypeHDMI(SYS_INPUT_SOURCE_TYPE(eWindow)) && (MApp_PCMode_GetCurrentState(eWindow) == E_PCMODE_UNSTABLE)))
            {
                u32AnalogInputsModeWinTimer[eWindow] = msAPI_Timer_GetTime0();
                return;
            }
#endif
            if(MApi_XC_PCMonitor_SyncLoss(eWindow) || (MApp_PCMode_GetCurrentState(eWindow) == E_PCMODE_STABLE_UN_SUPPORT_MODE))
            { // no sync
                if(!su8NoSignalDisplayCNT[eWindow])
                {
                    if(MApp_PCMode_GetCurrentState(eWindow) == E_PCMODE_STABLE_UN_SUPPORT_MODE) //un-support mode
                    {
                        ANALOGINPUTS_DBINFO(printf("IDLE_WIN>> un-support mode \n"));
                        enTVState = STATE_TV_INIT;
                        //enAnalogInputsRetVal = EXIT_GOTO_MENU;
                        #if ENABLE_CUS_BLOCK_SYS
                        if(MApp_UiMenuFunc_CheckInputLockAudioVideo())
                        {
                            SYS_SCREEN_SAVER_TYPE(eWindow) = EN_SCREENSAVER_BLOCKRATING;
                        }
                        else
                        #endif
                        {
                            SYS_SCREEN_SAVER_TYPE(eWindow) = EN_SCREENSAVER_UNSUPPORT_MODE;
                        }

                        //ZUI: MApp_UiMenu_ExecuteKeyEvent(MIA_UNSUPPORTED_MODE_MSG_BOX);
                        //ZUI: enUiMainMenuState = STATE_UIMENU_CLEAN_UP;
                    }
                    else
                    {
                    #if ENABLE_OFFLINE_SIGNAL_DETECTION
                        //printf("no signal  pc/ypbpr");
                        stAISCtrl.bNoSignal=1;
                        if((UI_INPUT_SOURCE_RGB == UI_INPUT_SOURCE_TYPE)
                      #if (INPUT_YPBPR_VIDEO_COUNT>=1)
                        || (UI_INPUT_SOURCE_COMPONENT== UI_INPUT_SOURCE_TYPE)
                      #endif
                        )
                        {
                            if(stGenSetting.g_SysSetting.bAIS!=AIS_OFF)
                            {
                                stAISSrcList[UI_INPUT_SOURCE_TYPE].bHaveSignal=0;
                            }
                        }
                    #endif
                        ANALOGINPUTS_DBINFO(printf("IDLE_WIN>> no sync\n"));
                        enTVState = STATE_TV_INIT;
                        //enAnalogInputsRetVal = EXIT_GOTO_MENU;
                        if(IsSrcTypeAnalog(SYS_INPUT_SOURCE_TYPE(eWindow))||IsSrcTypeHDMI(SYS_INPUT_SOURCE_TYPE(eWindow)))
                        {
                            if(MApi_XC_PCMonitor_GetCurrentState(MAIN_WINDOW) == E_XC_PCMONITOR_STABLE_NOSYNC)
                            {
                                #if ENABLE_CUS_BLOCK_SYS
                                if(MApp_UiMenuFunc_CheckInputLockAudioVideo())
                                {
                                    SYS_SCREEN_SAVER_TYPE(eWindow) = EN_SCREENSAVER_BLOCKRATING;
                                }
                                else
                                #endif
                                {
                                    SYS_SCREEN_SAVER_TYPE(eWindow) = EN_SCREENSAVER_NOSYNC;
                                }
                            }
                        }
                        //ZUI: MApp_UiMenu_ExecuteKeyEvent(MIA_NO_SYNC_MSG_BOX);
                        //ZUI: enUiMainMenuState = STATE_UIMENU_CLEAN_UP;
                    }

                    if (MApp_ZUI_GetActiveOSD() == E_OSD_SCREEN_SAVER)
                    {
                        MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_REPAINT_ALL);
                    }
                    else if (MApp_ZUI_GetActiveOSD() == E_OSD_EMPTY)
                    {
                           if ((SYS_SCREEN_SAVER_TYPE(eWindow) == EN_SCREENSAVER_UNSUPPORT_MODE)
                              ||(MApi_XC_PCMonitor_GetCurrentState(MAIN_WINDOW) == E_XC_PCMONITOR_STABLE_NOSYNC))
                           {
                                if (IsSrcTypeHDMI(SYS_INPUT_SOURCE_TYPE(eWindow)))
                                {
                                    ++u8HdmiNosignalCounter ;
                                    if (u8HdmiNosignalCounter >= 2)
                                    {
                                        u8HdmiNosignalCounter = 0;
                                        #if ENABLE_CUS_BLOCK_SYS
                                        if(MApp_UiMenuFunc_CheckInputLockAudioVideo())
                                        {
                                            MApp_BlockSys_ResetMsgbox2ScreenSaverTimer();
                                            MApp_ZUI_ACT_StartupOSD(E_OSD_MESSAGE_BOX);
                                            MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_SHOW_PASSWORD_INPUT_MSGBOX);
                                        }
                                        else
                                        #endif
                                        {
                                            MApp_ZUI_ACT_StartupOSD(E_OSD_SCREEN_SAVER);
                                        }
                                    }
                                }
                                else
                                {
                                    #if ENABLE_CUS_BLOCK_SYS
                                    if(MApp_UiMenuFunc_CheckInputLockAudioVideo())
                                    {
                                        MApp_BlockSys_ResetMsgbox2ScreenSaverTimer();
                                        MApp_ZUI_ACT_StartupOSD(E_OSD_MESSAGE_BOX);
                                        MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_SHOW_PASSWORD_INPUT_MSGBOX);
                                    }
                                    else
                                    #endif
                                    {
                                        MApp_ZUI_ACT_StartupOSD(E_OSD_SCREEN_SAVER);
                                    }
                                }
                           }
                    }

                    #if ENABLE_CUS_BLOCK_SYS
                    MApp_BlockSys_Monitor(MAIN_WINDOW,BLOCKSYS_CHECK_OSD,FALSE);
                    #endif
                }
                else
                {
                    if(su8NoSignalDisplayCNT[eWindow]>0)
                    su8NoSignalDisplayCNT[eWindow]--;
                }
            }
            else
            {
            #if ENABLE_OFFLINE_SIGNAL_DETECTION
                //printf("Signal in pc/ypbpr");
                stAISCtrl.bNoSignal=0;
            #endif
            #if ENABLE_CUS_BLOCK_SYS
                MApp_BlockSys_Monitor(MAIN_WINDOW,(BLOCKSYS_CHECK_AV|BLOCKSYS_CHECK_OSD),FALSE);
            #endif
                su8NoSignalDisplayCNT[eWindow] = DELAY_4SEC;
            }
        }
        else //if(IsDigitalSourceInUse())
        {    //Todo PIP: deal with SUB_WINDOW aspect

            if(!MApp_VD_IsSyncLock())
            {   // no sync
                if(!su8NoSignalDisplayCNT[eWindow])
                {
                #if ENABLE_OFFLINE_SIGNAL_DETECTION
                    //printf("Analog VD no signal");
                    stAISCtrl.bNoSignal=1;
                    if((UI_INPUT_SOURCE_AV== UI_INPUT_SOURCE_TYPE)
                  #if (INPUT_AV_VIDEO_COUNT >= 2)
                    || (UI_INPUT_SOURCE_AV2== UI_INPUT_SOURCE_TYPE)
                  #endif
                    )
                    {
                        if(stGenSetting.g_SysSetting.bAIS!=AIS_OFF)
                        {
                            stAISSrcList[UI_INPUT_SOURCE_TYPE].bHaveSignal=0;
                        }
                    }
                #endif

                #if (ATSC_CC == ATV_CC)
                if (MApp_CC_GetInfo(CC_SELECTOR_STATUS_CODE) == STATE_CAPTION_PARSER)
                {
                    MApp_CC_StopParser();
                    MApp_Set_CCState(FALSE);
                }
                #endif

                    ANALOGINPUTS_DBINFO(printf("IDLE_WIN>> VD no sync\n"));
                    enTVState = STATE_TV_INIT;
                    //enAnalogInputsRetVal = EXIT_GOTO_MENU;
                    if(IsSrcTypeDigitalVD(SYS_INPUT_SOURCE_TYPE(eWindow)))
                    {
                        #if ENABLE_CUS_BLOCK_SYS
                        if(MApp_UiMenuFunc_CheckInputLockAudioVideo())
                        {
                            SYS_SCREEN_SAVER_TYPE(eWindow) = EN_SCREENSAVER_BLOCKRATING;
                        }
                        else
                        #endif
                        {
                            SYS_SCREEN_SAVER_TYPE(eWindow) = EN_SCREENSAVER_NOSYNC_VD;
                        }
                    }
                    if( (SYS_SCREEN_SAVER_TYPE(eWindow) == EN_SCREENSAVER_NOSIGNAL) \
                        || (SYS_SCREEN_SAVER_TYPE(eWindow) == EN_SCREENSAVER_NOSYNC) \
                        || (SYS_SCREEN_SAVER_TYPE(eWindow) == EN_SCREENSAVER_NOSYNC_VD))
                    {
                        //  power saving TO DO : wait for API from ken.chang
                    }
                    //ZUI: MApp_UiMenu_ExecuteKeyEvent(MIA_NO_SYNC_MSG_BOX);
                    //ZUI: enUiMainMenuState = STATE_UIMENU_CLEAN_UP;
                    //Todo PIP: need to know main or sub window is un-locked
                    //  and how to pass this msg to screen saver?
                    #if (ENABLE_ATV_VCHIP)
                    if (E_OSD_MESSAGE_BOX == MApp_ZUI_GetActiveOSD() && (EN_MSGBOX_MODE_PASSWORD_INPUT == MApp_ZUI_ACT_GetMessageBoxMode()))
                    {
                        MApp_ZUI_ACT_ShutdownOSD();
                    }
                    #endif

                    if (MApp_ZUI_GetActiveOSD() == E_OSD_SCREEN_SAVER)
                    {
                        MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_REPAINT_ALL);
                    }
                    else if (MApp_ZUI_GetActiveOSD() == E_OSD_EMPTY)
                    {
                        #if ENABLE_CUS_BLOCK_SYS
                        if(MApp_UiMenuFunc_CheckInputLockAudioVideo())
                        {
                            MApp_BlockSys_ResetMsgbox2ScreenSaverTimer();
                            MApp_ZUI_ACT_StartupOSD(E_OSD_MESSAGE_BOX);
                            MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_SHOW_PASSWORD_INPUT_MSGBOX);
                        }
                        else
                        #endif
                        {
                            MApp_ZUI_ACT_StartupOSD(E_OSD_SCREEN_SAVER);
                        }
                    }
                    #if ENABLE_CUS_BLOCK_SYS
                    MApp_BlockSys_Monitor(MAIN_WINDOW,BLOCKSYS_CHECK_OSD,FALSE);
                    #endif
                }
                else
                {
                    if(su8NoSignalDisplayCNT[eWindow]>0)
                        su8NoSignalDisplayCNT[eWindow]--;
                }
            }
            else
            { // others
              #if ENABLE_OFFLINE_SIGNAL_DETECTION
                //printf("Signal in VD");
                stAISCtrl.bNoSignal=0;
              #endif

              #if ENABLE_CUS_BLOCK_SYS
                MApp_BlockSys_Monitor(MAIN_WINDOW,(BLOCKSYS_CHECK_AV|BLOCKSYS_CHECK_OSD),FALSE);
              #endif

                ANALOGINPUTS_DBINFO(printf("IDLE>> other\n"));

                #if (ENABLE_ATV_VCHIP)
                if (E_OSD_EMPTY == MApp_ZUI_GetActiveOSD())
                {
                     if (MApp_VChip_GetCurVChipBlockStatus())
                    {
                          // parental blocked
                          MApp_ZUI_ACT_StartupOSD(E_OSD_MESSAGE_BOX);
                          MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_SHOW_PASSWORD_INPUT_MSGBOX);
                    }
                }

                if (E_OSD_MESSAGE_BOX == MApp_ZUI_GetActiveOSD() && EN_MSGBOX_MODE_PASSWORD_INPUT == MApp_ZUI_ACT_GetMessageBoxMode())
                {
                    if (MApp_VChip_GetCurVChipBlockStatus())
                    {
                        if (MApp_VChip_GetRatingUpdateStatus())
                        {
                            MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_REPAINT_ALL);
                        }
                    }
                    else
                    {
                        MApp_ZUI_ACT_ShutdownOSD();
                    }
                }
                #endif

               #if (ATSC_CC == ATV_CC)
                if((enTVState == STATE_TV_WAIT)&& (IsSrcTypeAV(SYS_INPUT_SOURCE_TYPE(eWindow)) && stGenSetting.g_SysSetting.enATVCaptionType != ATV_CAPTION_TYPE_OFF))
                {
                    if ((MApp_ZUI_GetActiveOSD() == E_OSD_EMPTY)
                        &&MApp_UiMenu_GetCoexistWin_State()
                        && MApp_IsSrcHasSignal(eWindow))
                    {
                        enTVState = STATE_TV_INIT;
                        enTVRetVal = EXIT_GOTO_CLOSEDCAPTION;
                        MApp_Set_CCState(TRUE);
                    }
                }

                if  ( IsSrcTypeAV(SYS_INPUT_SOURCE_TYPE(eWindow))
                  && stGenSetting.g_SysSetting.enATVCaptionType != ATV_CAPTION_TYPE_OFF
                  && (SYS_SCREEN_SAVER_TYPE(eWindow)==EN_SCREENSAVER_NULL)
                  && MApp_IsSrcHasSignal(eWindow)
                  &&(MApp_ZUI_GetActiveOSD()==E_OSD_EMPTY)&&MApp_UiMenu_GetCoexistWin_State())
                {
                     if (MApp_CC_GetInfo(CC_SELECTOR_STATUS_CODE) != STATE_CAPTION_PARSER)
                    {
                          U32 u32Err;

                          u32Err = MApp_CC_CtrlParser(CC_SELECTOR_MODE, CC_MODE_ATV);
                          u32Err = MApp_CC_CtrlParser(CC_SELECTOR_SERVICE, (EN_CLOSEDCAPTION_SERVICE)stGenSetting.g_SysSetting.enATVCaptionType);
                          u32Err = MApp_CC_CtrlParser(CC_SELECTOR_RESET_TO_DEFAULT, ENABLE);
                          if(devPanel_HEIGHT()>780)
                         {
                              u32Err = MApp_CC_CtrlParser(CC_SELECTOR_AXIS_XPOS, CC_AXIS_XPOS);        // horizontal offset
                              u32Err = MApp_CC_CtrlParser(CC_SELECTOR_AXIS_YPOS, CC_AXIS_YPOS);        // vertical offset
                          }
                          else
                         {
                               u32Err = MApp_CC_CtrlParser(CC_SELECTOR_AXIS_XPOS, SD_CC_AXIS_XPOS);        // horizontal offset brz 090826
                               u32Err = MApp_CC_CtrlParser(CC_SELECTOR_AXIS_YPOS, SD_CC_AXIS_YPOS);        // vertical offset
                          }
                          u32Err = MApp_CC_StartParser();
                    }
                }
                #endif // #if (ATSC_CC == ATV_CC)

#if  ENABLE_SBTVD_BRAZIL_APP
#if (BRAZIL_CC)
                if(MApp_VD_IsSyncLock())
                {
                        if ((enTVState == STATE_TV_WAIT)&&(MApp_ZUI_GetActiveOSD() ==E_OSD_EMPTY)&&(IsAVInUse() || IsSVInUse()) && stGenSetting.g_SysSetting.enATVCaptionType != ATV_CAPTION_TYPE_OFF)
                        {
                                enTVState = STATE_TV_INIT;
                                enTVRetVal = EXIT_GOTO_CLOSEDCAPTION;
                        }
                        if ((IsAVInUse() || IsSVInUse())
                        && stGenSetting.g_SysSetting.enATVCaptionType != ATV_CAPTION_TYPE_OFF
                        && MApp_ZUI_GetActiveOSD() ==E_OSD_EMPTY
                        &&(SYS_SCREEN_SAVER_TYPE(eWindow)==EN_SCREENSAVER_NULL))
                        {
                            if(MApp_CC_GetInfo(CC_SELECTOR_STATUS_CODE) != STATE_CAPTION_PARSER)
                            {
                                U32 u32Err;
                                u32Err = MApp_CC_CtrlParser(CC_SELECTOR_MODE, CC_MODE_ATV);
                                u32Err = MApp_CC_CtrlParser(CC_SELECTOR_SERVICE, (EN_CLOSEDCAPTION_SERVICE)stGenSetting.g_SysSetting.enATVCaptionType);
                                u32Err = MApp_CC_CtrlParser(CC_SELECTOR_RESET_TO_DEFAULT, ENABLE);
                                u32Err = MApp_CC_CtrlParser(CC_SELECTOR_608_SCROLL_STEP, ENABLE);
                                u32Err = MApp_CC_CtrlParser(CC_SELECTOR_608_TIMEOUT_TEXT, 16000);
            #ifdef HER_BRAZIL
                                u32Err = MApp_CC_CtrlParser(CC_SELECTOR_AXIS_XPOS, 0xA4);        // horizontal offset
                                u32Err = MApp_CC_CtrlParser(CC_SELECTOR_AXIS_YPOS, 0x74);        // vertical offset
            #endif
                                u32Err = MApp_CC_StartParser();
                            }
                        }
                }
                else
                {
                    if (MApp_CC_GetInfo(CC_SELECTOR_STATUS_CODE) == STATE_CAPTION_PARSER)
                    {
                        MApp_CC_StopParser();
                        MApp_Dmx_PES_Stop();
                    }
                }
#endif
#endif

                /*/ZUI:
                if(enCurTVWin != DISP_WIN_NONEOSD)
                {
                    MApp_AnalogInputs_DeleteWin();
                }*/
                su8NoSignalDisplayCNT[eWindow] = DELAY_4SEC;
                }
            }
        u32AnalogInputsModeWinTimer[eWindow] = msAPI_Timer_GetTime0();
    }
}

//*************************************************************************
//Function name:    MApp_AnalogInputs_Init
//Passing parameter:    none
//Return parameter:    none
//Description:      Initialize all state before entering idle mode
//*************************************************************************
void MApp_AnalogInputs_Init(SCALER_WIN eWindow)
{

    u32AnalogInputsModeWinTimer[eWindow] = msAPI_Timer_GetTime0();
    u16IdleInputValue = msAPI_ATV_GetCurrentProgramNumber()+1;
}

void MApp_AnalogInputs_Force2MonitorWindows(SCALER_WIN eWindow)
{
    u32AnalogInputsModeWinTimer[eWindow] -= TV_MODE_WINDOW_MONITOR_PERIOD;
}

void MApp_AnalogInputs_ResetTimer(SCALER_WIN eWindow)
{
    u32AnalogInputsModeWinTimer[eWindow] = msAPI_Timer_GetTime0();
}
#if (ATSC_CC == ATV_CC)
void MApp_Set_CCState(BOOLEAN bEnable)
{
    DigitalCCState = bEnable;
}
BOOLEAN MApp_Get_CCState(void)
{
    return DigitalCCState;
}
#endif
#undef _MAPP_ANALOGINPUTS_C

