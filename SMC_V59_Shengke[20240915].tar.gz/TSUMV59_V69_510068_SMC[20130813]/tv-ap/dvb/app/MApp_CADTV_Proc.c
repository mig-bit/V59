////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////
#define MAPP_CADTVPROC_C

#include "Board.h"
#include "MApp_CADTV_Proc.h"
#include "msAPI_Global.h"
#include "drvAUDIO.h"

static U32 _u32CadtvManualTuningFrequency = DEFAULT_DVBC_FREQUENCY;
static U16 _u16CadtvManualTuningSymbo = DEFAULT_DVBC_SYMBOL_RATE;
static EN_CAB_CONSTEL_TYPE _enCadtvManualTuningQamType= CAB_QAM16;
static U16 _u16CadtvNetworkTuningNetworkID = DEFAULT_DVBC_NID;
void MApp_CATV_RestoreManutuning_settingDefault(void)
{
   _u32CadtvManualTuningFrequency = DEFAULT_DVBC_FREQUENCY;
 _u16CadtvManualTuningSymbo = DEFAULT_DVBC_SYMBOL_RATE;
 _enCadtvManualTuningQamType= CAB_QAM16;
 _u16CadtvNetworkTuningNetworkID = DEFAULT_DVBC_NID;
 }


BOOL MApp_CadtvManualTuning_IncreaseFrequency(void)
{
    if( _u32CadtvManualTuningFrequency+500 <= MAX_DVBC_FREQUENCY )
        _u32CadtvManualTuningFrequency = _u32CadtvManualTuningFrequency+500;
    else
        _u32CadtvManualTuningFrequency = MIN_DVBC_FREQUENCY;
    return TRUE;
}

BOOL MApp_CadtvManualTuning_DecreaseFrequency(void)
{
    if( _u32CadtvManualTuningFrequency-500 >= MIN_DVBC_FREQUENCY )
        _u32CadtvManualTuningFrequency = _u32CadtvManualTuningFrequency-500;
    else
        _u32CadtvManualTuningFrequency = MAX_DVBC_FREQUENCY;
    return TRUE;
}

U32 MApp_CadtvManualTuning_GetFrequency(void)
{
    return _u32CadtvManualTuningFrequency;
}

BOOL MApp_CadtvManualTuning_SetFrequency(U32 u32freq)
{
    if(u32freq <= MAX_DVBC_FREQUENCY && u32freq >= MIN_DVBC_FREQUENCY)
    {
        _u32CadtvManualTuningFrequency = u32freq;
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}


BOOL MApp_CadtvManualTuning_IncreaseSymbol(void)
{
    if( _u16CadtvManualTuningSymbo+1 <= MAX_DVBC_SYMBOL_RATE)
    {
        _u16CadtvManualTuningSymbo = _u16CadtvManualTuningSymbo+1;
    }
    else
    {
        _u16CadtvManualTuningSymbo = MIN_DVBC_SYMBOL_RATE;
    }
    return TRUE;
}

BOOL MApp_CadtvManualTuning_DecreaseSymbol(void)
{
    if(_u16CadtvManualTuningSymbo-1 > MIN_DVBC_SYMBOL_RATE)
    {
        _u16CadtvManualTuningSymbo = _u16CadtvManualTuningSymbo-1;
    }
    else
    {
        _u16CadtvManualTuningSymbo = MAX_DVBC_SYMBOL_RATE;
    }
    return TRUE;
}

U16 MApp_CadtvManualTuning_GetSymbol(void)
{
    return _u16CadtvManualTuningSymbo;
}

BOOL MApp_CadtvManualTuning_SetSymbol(U16 u16Sym)
{
    if(u16Sym <= MAX_DVBC_SYMBOL_RATE && u16Sym >= MIN_DVBC_SYMBOL_RATE)
    {
         _u16CadtvManualTuningSymbo = u16Sym;
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}

BOOL MApp_CadtvManualTuning_IncreaseQamType(void)
{
    switch( _enCadtvManualTuningQamType )
    {
        case CAB_QAM16:
            _enCadtvManualTuningQamType = CAB_QAM32;
            break;
        case CAB_QAM32:
            _enCadtvManualTuningQamType = CAB_QAM64;
            break;
        case CAB_QAM64:
            _enCadtvManualTuningQamType = CAB_QAM128;
            break;

        case CAB_QAM128:
            _enCadtvManualTuningQamType = CAB_QAM256;
            break;
        case CAB_QAM256:
        default:
            _enCadtvManualTuningQamType = CAB_QAM16;
            break;
    }
    return TRUE;
}

BOOL MApp_CadtvManualTuning_DecreaseQamType(void)
{
    switch( _enCadtvManualTuningQamType )
    {
        case CAB_QAM16:
        default:
            _enCadtvManualTuningQamType = CAB_QAM256;
            break;
        case CAB_QAM32:
            _enCadtvManualTuningQamType = CAB_QAM16;
            break;
        case CAB_QAM64:
            _enCadtvManualTuningQamType = CAB_QAM32;
            break;

        case CAB_QAM128:
            _enCadtvManualTuningQamType = CAB_QAM64;
            break;
        case CAB_QAM256:
            _enCadtvManualTuningQamType = CAB_QAM128;
            break;
    }
    return TRUE;
}

EN_CAB_CONSTEL_TYPE MApp_CadtvManualTuning_GetQamType(void)
{
    return _enCadtvManualTuningQamType;
}

BOOL MApp_CadtvManualTuning_SetQamType(EN_CAB_CONSTEL_TYPE eQAM)
{
    if(eQAM <= CAB_QAM256)
    {
        _enCadtvManualTuningQamType = eQAM;
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}

U16 MApp_CadtvManualTuning_GetNID(void)
{
    return _u16CadtvNetworkTuningNetworkID;
}

BOOL MApp_CadtvManualTuning_SetNID(U16 u16NID)
{
    _u16CadtvNetworkTuningNetworkID = u16NID;
    return TRUE;
}
#undef MAPP_CADTVPROC_C

