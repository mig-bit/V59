////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#define MAPP_ZUI_CTL_AUTOCLOSE_C
#define _ZUI_INTERNAL_INSIDE_ //NOTE: for ZUI internal


//-------------------------------------------------------------------------------------------------
// Include Files
//-------------------------------------------------------------------------------------------------
#include "stdlib.h"
#include "stdio.h"
#include "datatype.h"
#include "MApp_ZUI_Main.h"
#include "MApp_ZUI_APIcommon.h"
#include "MApp_ZUI_APIwindow.h"
#include "MApp_ZUI_APItables.h"
#include "MApp_ZUI_APIcontrols.h"
#include "MApp_ZUI_ACTglobal.h"
#include "ZUI_exefunc.h"
#include "MApp_ZUI_ACTchannelinfo.h"
#include "MApp_ZUI_ACTcoexistWin.h"
#include "MApp_GlobalSettingSt.h"
#include "MApp_ZUI_ACTmsgbox.h"
#include "MApp_TopStateMachine.h"
///////////////////////////////////////////////////////////////////////////////
///  global  MApp_ZUI_CTL_AutoCloseWinProc
///  Window Proc for "auto close" control,
///     register a timer when being created.
//      And if timer event notified, then execute EN_EXE_CLOSE_CURRENT_OSD
///
///  @param [in]       hWnd HWND     window handle
///  @param [in]       pMsg PMSG     message type
///
///  @return S32 message execute result
///
///  @author MStarSemi @date 2007/1/25
///////////////////////////////////////////////////////////////////////////////
extern BOOL Mapp_ZUI_ACT_Hotkey_IsFreeze(void);
#if ENABLE_PLAYBACK_INFO_AUTO_CLOSE
extern BOOLEAN MApp_ZUI_ACT_ExecuteDmpAction(U16 act);   //truth.xu add 20101204
#endif

S32 MApp_ZUI_CTL_AutoCloseWinProc(HWND hWnd, PMSG pMsg)
{
    U32 timeout_ms;
    switch(pMsg->message)
    {
        case MSG_CREATE:
            if((stGenSetting.g_SysSetting.OsdDuration == EN_OSD_TIME_ALWAYS) && (MApp_ZUI_GetActiveOSD() == E_OSD_MAIN_MENU))
                break;

            if(( hWnd == HWND_MENU_MASK_BACKGROUND ) && (MApp_ZUI_GetActiveOSD() == E_OSD_MAIN_MENU))
            {
                #if ENABLE_CUS_OSD_TIMEOUT
                timeout_ms =stGenSetting.g_SysSetting.OsdDuration*10000;
                #else
                timeout_ms =stGenSetting.g_SysSetting.OsdDuration*5000;
                #endif
            }
            #if ENABLE_CUS_OSD_TIMEOUT
            else if(( hWnd == HWND_MENU_PICTURE_ADJUST_SUBMENU ) && (MApp_ZUI_GetActiveOSD() == E_OSD_MAIN_MENU))
            {
                timeout_ms =stGenSetting.g_SysSetting.OsdDuration*10000;
            }
            #endif
            else
            {
                timeout_ms = MApp_ZUI_API_GetWindowData(hWnd);
            }
            if (timeout_ms > 0)
            {
                //setting AP timeout, auto close
                MApp_ZUI_API_SetTimer(hWnd, 0, timeout_ms);
            }
            break;

        case MSG_TIMER:
            {
                if((MApp_ZUI_GetActiveOSD()==E_OSD_MESSAGE_BOX)&&(IsVgaInUse()))
                {
               
                    MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_CLOSE_CURRENT_OSD);					
                    if(MApp_ZUI_ACT_GetMessageBoxMode() == EN_MSGBOX_MODE_AUTO_ADJUSTING)
                    {
			MApp_ZUI_ACT_StartupOSD(E_OSD_CHANNEL_INFO);
					// CUS_XM Xue 20120803: XF112PIOCNMS0-661 
			MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_SHOW_SOURCE_BANNER);
                    }
                }
				#ifdef ENABLE_SRC_MENU_AUTOCLOSE_AND_SWITCH_SOURCE
                else if(MApp_ZUI_GetActiveOSD() == E_OSD_INPUT_SOURCE)
                {
                    extern BOOLEAN MApp_ZUI_ACT_ExecuteInputSourceAction(U16 act);
                    MApp_ZUI_ACT_ExecuteInputSourceAction(EN_EXE_SWITCH_SRC_AND_CLOSE_OSD);
                }
				#endif
                else if ((MApp_TopStateMachine_GetTopState() != STATE_TOP_ATV_SCAN)
                      #if ENABLE_DTV
                        && (MApp_TopStateMachine_GetTopState() != STATE_TOP_DTV_SCAN)
                      #endif
                      )
                {
                    //if the time is up, kill the timer and then close AP!
                    //maybe timeout on common dialog...MApp_ZUI_API_KillTimer(hwnd, 0);
                     #if ENABLE_PLAYBACK_INFO_AUTO_CLOSE
                     if(hWnd==HWND_DMP_PLAYBACK_INFO_PANE)
                    	{
                    	  if(MApp_ZUI_API_IsWindowVisible(HWND_DMP_PLAYBACK_INFO_PANE))
                    	  MApp_ZUI_ACT_ExecuteDmpAction(EN_EXE_DMP_PLAYBACK_INFO_CLOSE);
                    	}
                     else
                    #endif                  
				    if(Mapp_ZUI_ACT_Hotkey_IsFreeze())
						MApp_ZUI_API_ResetTimer(hWnd, 0);
					else
						
                    MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_CLOSE_CURRENT_OSD);
                }
            }
            break;

        default:
            //
            break;
    }

    return DEFAULTWINPROC(hWnd, pMsg);
}

#undef MAPP_ZUI_CTL_AUTOCLOSE_C
