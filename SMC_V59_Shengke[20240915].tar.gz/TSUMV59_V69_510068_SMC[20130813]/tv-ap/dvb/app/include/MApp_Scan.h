////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef MAPP_SCAN_H
#define MAPP_SCAN_H

#include "datatype.h"
#include "msAPI_Global.h"

#include "msAPI_Tuner.h"
#include "msAPI_DTVSystem.h"

#include "MApp_Exit.h"


//------------------------------------------------------------------------------
// Defines
//------------------------------------------------------------------------------

// debug for scan
#define ENABLE_SCAN_CM_DEBUG            0 //for CM debugging

//------------------------------------------------------------------------------
// Enums
//------------------------------------------------------------------------------
typedef enum
{
    STATE_SCAN_INIT,
    STATE_SCAN_NEXT_CHANNEL,
    STATE_SCAN_SEARCH_RF_CHANNEL,
    STATE_SCAN_GET_PROGRAMS,
    STATE_SCAN_SAVE_PROGRAMS,
    STATE_SCAN_PAUSE,
    STATE_SCAN_END,
    STATE_SCAN_GOTO_STANDBY,
    STATE_SCAN_EXIT_MAIN_MENU,
    STATE_SCAN_INTERRUPT,
#if (ENABLE_UPDATE_MULTIPLEX_VIA_NIT)
    STATE_SCAN_WAIT,
#endif
} EN_SCAN_STATE;

#if DVB_C_ENABLE
typedef enum
{
    QUICK_INSTALL_STATE_INIT = 0,
    QUICK_INSTALL_STATE_SCAN_TABLE,
    QUICK_INSTALL_STATE_UPDATE_CHLIST,
    QUICK_INSTALL_STATE_REMOVE_MISSING_MUX,
    QUICK_INSTALL_STATE_END,
}DVBC_QUICK_INSTALL_CHLIST_STATE;
#endif



typedef enum
{
    STATE_DVB_SCAN_INIT,
    STATE_DVB_SCAN_INIT_DEMODE,
    STATE_DVB_SCAN_CHECK_LOCK,
} EN_DVB_SCAN_STATE;

typedef enum
{
    FTA,
    ALL,
    SCAN_SRV_TYPE_NUM
} EN_SCAN_SRV_TYPE;

#if (ENABLE_UPDATE_MULTIPLEX_VIA_NIT)
typedef enum
{
    LOSS_SIGNAL_INIT,
    LOSS_SIGNAL_CONFIRM_MSG,
    LOSS_SIGNAL_RETUNE,
    LOSS_SIGNAL_NO_RETUNE,
    LOSS_SIGNAL_RETURN_TO_NOSIGNAL,
    LOSS_SIGNAL_RETURN_ORIGINAL_RF
}EN_LOSS_SIGNAL_STATE;
#endif

//------------------------------------------------------------------------------
// Function prototypes
//------------------------------------------------------------------------------
#ifdef MAPP_SCAN_A_C
#define INTERFACE
#else
#define INTERFACE extern
#endif

INTERFACE void MApp_Scan_State_Init(void);
INTERFACE EN_RET MApp_DTV_Scan( void );
#if (ENABLE_UPDATE_MULTIPLEX_VIA_NIT)
INTERFACE void MApp_DTV_Scan_Retune_Confirm_Yes(void);
INTERFACE void MApp_DTV_Scan_Retune_Confirm_No(void);
INTERFACE void MApp_DTV_Scan_NetworkChange_Cornfim_OK(void);
INTERFACE EN_LOSS_SIGNAL_STATE MApp_DTV_Scan_GetLossSignalState(void);
INTERFACE void MApp_DTV_Scan_SetLossSignalState(EN_LOSS_SIGNAL_STATE enState);
INTERFACE void MApp_DTV_Scan_Set_LossSignalFlag(BOOLEAN bLossSignal);
INTERFACE EN_RET MApp_DTV_Scan_Update_Mux( void );
INTERFACE void MApp_DTV_Scan_Set_UpdateMethod(BOOLEAN bAddMux, BOOLEAN bRemoveMux ,BOOLEAN bCellRemove, BOOLEAN bFreqChange);
INTERFACE void MApp_DTV_Scan_Update_Mux_State_Init( void );
#endif
INTERFACE BOOLEAN MApp_DTV_Scan_Init(void);
INTERFACE void MApp_DTV_Scan_End(BOOLEAN bSkipDupSrvRemove);
INTERFACE BOOLEAN MApp_DVB_Scan( MS_TP_SETTING *pstTPSetting, BOOLEAN *ScanResult);

#if DVB_C_ENABLE
INTERFACE EN_DVB_TYPE MApp_DVBType_GetCurrentType(void);
INTERFACE void MApp_DVBType_SetCurrentType(U8 SelectDVBType);

INTERFACE EN_DVB_TYPE MApp_DVBType_GetPrevType(void);
INTERFACE void MApp_DVBType_SetPrevType(EN_DVB_TYPE SelectDVBType);
#endif

//ZUI:
INTERFACE void MApp_Scan_SetScanState(EN_SCAN_STATE state);
INTERFACE void MApp_DTV_ExitScanPauseState(void);
INTERFACE void MApp_DTV_ExitScanPause2End(void);
INTERFACE void MApp_DTV_ExitScanPause2Menu(void);

#if DVB_C_ENABLE
INTERFACE BOOLEAN MApp_Scan_DVBC_QuickInstall_GetProcessedFlag(void);
INTERFACE BOOLEAN MApp_Scan_DVBC_QuickInstall_ChList(void);
#endif
#if NTV_FUNCTION_ENABLE
INTERFACE void MApp_DTV_Scan_SetSelectFavoriteNetwork(U8 cNetworkIndex);
INTERFACE U8 MApp_DTV_Scan_GetSelectFavoriteNetwork(void);
INTERFACE void MApp_Set_ScanGoRegion_Status(BOOLEAN bStatus);
INTERFACE BOOLEAN MApp_Get_ScanGoRegion_Status(void);
#endif

#undef INTERFACE

#endif

