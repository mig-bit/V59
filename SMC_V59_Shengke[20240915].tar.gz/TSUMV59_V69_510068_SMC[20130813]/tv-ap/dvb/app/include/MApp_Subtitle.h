////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//
/// @file MApp_Subtitle.h
/// @brief API for Subtitle Display
/// @author MStar Semiconductor, Inc.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef MAPP_SUBTITLE_H
#define MAPP_SUBTITLE_H

//-------------------------------------------------------------------------------------------------
// Defines
//-------------------------------------------------------------------------------------------------
#define SIZE_OF_PMT_NODE            8
#if (CHIP_FAMILY_TYPE==CHIP_FAMILY_M10) || (CHIP_FAMILY_TYPE == CHIP_FAMILY_M12)
#define SUBTITLE_WITH_OSD           FALSE
#else
#define SUBTITLE_WITH_OSD           TRUE
#endif
#define SUBTITLE_REDUCE_GWIN        TRUE
#define MAX_SUBTITLE_OPTIONS        10
#define SUBTITLE_PMT_MONITOR_PERIOD 1500
#define SUBTITLE_TIMEOUT_THRESHOLD  15000 //UNIT:mSec,(15 Sec) DTG : 10 ~ 15 Sec

//-------------------------------------------------------------------------------------------------
// Standard include files:
//-------------------------------------------------------------------------------------------------
#include "datatype.h"

#include "msAPI_Subtitle.h"
#include "msAPI_MIU.h"
#if (MHEG5_ENABLE)
#include "msAPI_MHEG5.h"
#endif

#if (ENABLE_TTX)
#include "mapp_ttx.h"
#endif
#include "MApp_Exit.h"
#include "MApp_VDMode.h"
#include "MApp_SignalMonitor.h"
#include "MApp_Key.h"
#include "MApp_GlobalSettingSt.h"
#include "mapp_si.h"

#ifdef MAPP_SUBTITLE_C
#define INTERFACE
#else
#define INTERFACE extern
#endif

typedef enum
{
    SBTL_SERVICE_NOT_FOUND = 0,
    SBTL_SERVICE_FOUND,
    SBTL_SERVICE_TTX_FOUND
} RET_SBTL_SERVICE_SEARCH;

//-------------------------------------------------------------------------------------------------
// Defines
//-------------------------------------------------------------------------------------------------
#define MAX_SUBTITLE_SERVICE_NUM       20
//#define MAX_TTX_SUBTITLE_SERVICE_NUM    6
//-------------------------------------------------------------------------------------------------
// Macros
//-------------------------------------------------------------------------------------------------

//-------------------------------------------------------------------------------------------------
// Type and Structure Declaration
//-------------------------------------------------------------------------------------------------
typedef enum
{
    SBTL_GET_PES_STATE_FAIL = 0,
    SBTL_GET_PES_STATE_TOBECONTINUED,
    SBTL_GET_PES_STATE_FINISH,
    SBTL_GET_PES_STATE_WAITING
} GET_PES_STATE;

typedef enum _SUBTITLING_TYPE
{
    SUBTITLING_TYPE_TELETEXT       = 0x01,
    SUBTITLING_TYPE_TELETEXT_HOH   = 0x02,
    SUBTITLING_TYPE_NORMAL_NO      = 0x10,
    SUBTITLING_TYPE_NORMAL_4X3     = 0x11,
    SUBTITLING_TYPE_NORMAL_16X9    = 0x12,
    SUBTITLING_TYPE_NORMAL_221X100 = 0x13,
    SUBTITLING_TYPE_NORMAL_HD      = 0x14,
    SUBTITLING_TYPE_HH_NO          = 0x20,
    SUBTITLING_TYPE_HH_4X3         = 0x21,
    SUBTITLING_TYPE_HH_16X9        = 0x22,
    SUBTITLING_TYPE_HH_221X100     = 0x23,
    SUBTITLING_TYPE_HH_HD          = 0x24,
} SUBTITLING_TYPE;

typedef enum
{
    STATE_SUBTITLE_INIT = 0,
    STATE_SUBTITLE_DECODING
} EN_SUBTITLE_STATE;

typedef struct
{
    U16 u16PID;
    U8  StringCodes[4];
    SUBTITLING_TYPE  u8SubtitleType;
    U16 u16Composition_Page_id;
    U16 u16Ancillary_Page_id;
} DVB_SUBTITLE_SERVICE;
/*
typedef struct
{
    U8  StringCodes[4];
    U8  u8Magazine;
    U8  u8Page;
} TTX_SUBTITLE_SERVICES;
*/
typedef struct
{
    char StringCodes[4];
    U8  u8Magazine;
    U8  u8Page;
    U16 u16PID;
    SUBTITLING_TYPE  u8SubtitleType;
} SUBTITLE_MENU;

#if (ENABLE_SUBTITLE)
//-------------------------------------------------------------------------------------------------
// Extern Global Variabls
//-------------------------------------------------------------------------------------------------
INTERFACE U8 u8SubtitleIdx;
INTERFACE U8 *pu8ElementaryPID;
INTERFACE U8 SubtitleSamePIDCnt;
INTERFACE U8 u8SubtitleMenuNum;
INTERFACE U8 *pu8SubtitleDescriptor;
INTERFACE U8 u8DVBSubtitleServiceNum;
INTERFACE BOOLEAN bEnableSubtitleTimeoutMonitor;
INTERFACE U32 u32SubtitleTimeOut;

INTERFACE SUBTITLE_MENU SubtitleMenu[MAX_SUBTITLE_SERVICE_NUM];
INTERFACE DVB_SUBTITLE_SERVICE DVBSubtitleServices[MAX_SUBTITLE_SERVICE_NUM];

//-------------------------------------------------------------------------------------------------
// Extern Functions
///-------------------------------------------------------------------------------------------------
INTERFACE U8 MApp_Subtitle_Get_SubtitleOSDState(void);
INTERFACE U16 MApp_Subitle_GetCurPID(void);
INTERFACE void MApp_Subtitle_Disable(void);
INTERFACE BOOLEAN MApp_Subtitle_ParsePMT(void);
INTERFACE void MApp_Subtitle_GetPid(U16 *pu16_pid);
INTERFACE void MApp_Subtitle_Clear_ServiceData(BOOLEAN bUpdate);
INTERFACE void MApp_Subtitle_Force_Exit(void);
INTERFACE void MApp_Subtitle_Exit_ForAutoScart(void);
INTERFACE void MApp_Subtitle_OrgnizeServiceTbl(void);
INTERFACE void MApp_Subtitle_PID_Monitor(void);
INTERFACE void MApp_Subtitle_SetInvalidPID(void);
INTERFACE BOOLEAN MApp_Subtitle_IsRunning(void);
INTERFACE void MApp_Subtitle_PID_Updated(void);
INTERFACE void MApp_Subtitle_TimeOut_Clear(void);
INTERFACE BOOLEAN MApp_Subtitle_Initial(void);
INTERFACE BOOLEAN MApp_Subtitle_SetPid(U16 u16_pid);
INTERFACE BOOLEAN MApp_Subtitle_Select_Language(U8 SubtitleLang);
INTERFACE U8 MApp_TTX_Subtitle_ParsePMT(MS_TELETEXT_INFO *pTTXInfo, U16 pid, U8 u8NumOfTTX, BOOLEAN *bGotInitPage);
INTERFACE BOOLEAN MApp_TTX_Subtitle_GetData(U8 SubtitleIndex, U8 *Magazine, U8 *Page, U16 *u16Pid);
INTERFACE BOOLEAN MApp_TTX_Subtitle_GetDefaultLang(EN_LANGUAGE lang, U8 *Magazine, U8 *Page, U16 *u16Pid);
//INTERFACE BOOLEAN MApp_Subtitle_SetPageId(U16 u16_component_page_id, U16 u16_ancillary_page_id);
//INTERFACE BOOLEAN MApp_Subtitle_IS_HoH(SUBTITLING_TYPE u8type);
INTERFACE EN_RET MApp_Subtitle_Main(void);
INTERFACE void MApp_Subtitle_OrgnizeServiceTbl(void);
INTERFACE void MApp_Subtitle_Switch2OP(void);
INTERFACE void MApp_Subtitle_Switch2IP(void);

INTERFACE void MApp_Subtitle_Exit(void);
INTERFACE void MApp_Subtitle_SetValidIndex(U8 type, U8* lang, U32 *pu32Validndex);
INTERFACE U8 MApp_Subtitle_ReArrange(U32 u32ValidIndex, U8 u8CurIdx);
INTERFACE void MApp_Subtitle_Open_Filter(U16 u16PID);
INTERFACE BOOLEAN MApp_Subtitle_IsTTXSubtitle(U8 SubtitleLang);
#if (CHIP_FAMILY_TYPE == CHIP_FAMILY_M12)
INTERFACE void MApp_Subtitle_SetShowStatus(BOOLEAN bShowStatus);
INTERFACE EN_SUBTITLE_STATE MApp_Subtitle_GetStatus(void);
#endif
#else //ENABLE_SUBTITLE==0
#define MApp_Subtitle_PID_Updated()
#define MApp_Subtitle_Open_Filter(x)
#endif
#undef INTERFACE
#endif // _MAPP_SUBTITLE_H
