////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (MStar Confidential Information) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#define MAPP_GLOBAL_FUNCTION_C

//------------------------------------------------------------------------------
// Includes
//------------------------------------------------------------------------------

#include <string.h>
#include <math.h>
#include "datatype.h"
#include "sysinfo.h"
#include "MsTypes.h"
#include "drvBDMA.h"
#include "drvCPU.h"
#include "debug.h"

// Common Definition
#include "apiXC.h"
#include "apiXC_Adc.h"

#include "msAPI_Timer.h"
#include "msAPI_Power.h"
#include "msAPI_Memory.h"
#include "msAPI_Video.h"
#include "msAPI_DTVSystem.h"
#include "msAPI_FreqTableCommon.h"
#include "msAPI_DrvInit.h"
#include "msAPI_VD.h"

#include "MApp_PCMode.h"
#if ENABLE_TTX
#include "msAPI_TTX.h"
#include "mapp_ttx.h"
#endif
#include "MApp_GlobalVar.h"
#include "MApp_GlobalFunction.h"
#include "MApp_RestoreToDefault.h"
#include "MApp_VDMode.h"
#include "MApp_SaveData.h"

#if (ENABLE_DTV)
#include "mapp_si.h"
#endif

#include "MApp_ATVProc.h"
#include "MApp_MVDMode.h"
#if (MHEG5_ENABLE)
#include "msAPI_MHEG5.h"
#include "MApp_MHEG5_Main.h"
#endif
#if ENABLE_DLC
#include "apiXC_Dlc.h"
#endif
#include "MApp_UiMenuDef.h" //ZUI:
#if(ENABLE_DTV)
#include "mapp_si.h"
#endif
#if ENABLE_CI
#include "msAPI_CI.h"
#endif
#if ENABLE_CEC
#include "msAPI_CEC.h"
#endif

/***************************************************************************************/
#define    GET_3BYTE( cp )    ( ( ( (U32)(*cp) )<< 16 ) | ( ( (U32)(*(cp+1)) ) <<  8 ) | ( ( (U32)(*(cp+2)) ) ) )
#if ENABLE_AUTOTEST
extern BOOLEAN g_bAutobuildDebug;
#endif
extern U16 OSD_L;
extern U16 Audio_L;
extern U16 Subtitle_L;

/* ??C�?*/
code U8 SolarCal[12] =
{
    31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31
};

/* ??C뤧ֿn, ??P?? */
code U16 SolarDays[28] =
{
    0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334, 365, 396, 0, 31, 60, 91, 121, 152, 182, 213, 244, 274, 305, 335, 366, 397
};

static EN_OSD_COUNTRY_SETTING m_eOSDCountrySetting;
#if (!ENABLE_DTV)
typedef struct _TimeZone2Country
{
    EN_MENU_TIMEZONE eTimeZone;
    EN_OSD_COUNTRY_SETTING eCountry;
} TimeZone2Country;
static code TimeZone2Country stTimeZone2Country[]=
{
    {TIMEZONE_CANARY,       OSD_COUNTRY_SPAIN},
    {TIMEZONE_LISBON,       OSD_COUNTRY_PORTUGAL},
    {TIMEZONE_LONDON,       OSD_COUNTRY_UK},
    {TIMEZONE_RABAT,        OSD_COUNTRY_MOROCCO},
    {TIMEZONE_AMSTERDAM,    OSD_COUNTRY_NETHERLANDS},
    {TIMEZONE_BEOGRAD,      OSD_COUNTRY_SERBIA},
    {TIMEZONE_BERLIN,       OSD_COUNTRY_GERMANY},
    {TIMEZONE_BRUSSELS,     OSD_COUNTRY_BELGIUM},
    {TIMEZONE_BUDAPEST,     OSD_COUNTRY_HUNGARY},
    {TIMEZONE_COPENHAGEN,   OSD_COUNTRY_DENMARK},
    {TIMEZONE_LIUBLJANA,    OSD_COUNTRY_SLOVENIA},
    {TIMEZONE_LUXEMBOURG,   OSD_COUNTRY_LUXEMBOURG},
    {TIMEZONE_MADRID,       OSD_COUNTRY_SPAIN},
    {TIMEZONE_OSLO,         OSD_COUNTRY_NORWAY},
    {TIMEZONE_PARIS,        OSD_COUNTRY_FRANCE},
    {TIMEZONE_PRAGUE,       OSD_COUNTRY_CZECH},
    {TIMEZONE_BRATISLAVA,   OSD_COUNTRY_SLOVAKIA},
    {TIMEZONE_BERN,         OSD_COUNTRY_SWITZERLAND},
    {TIMEZONE_ROME,         OSD_COUNTRY_ITALY},
    {TIMEZONE_STOCKHOLM,    OSD_COUNTRY_SWEDEN},
    {TIMEZONE_WARSAW,       OSD_COUNTRY_POLAND},
    {TIMEZONE_VIENNA,       OSD_COUNTRY_AUSTRIA},
    {TIMEZONE_ZAGREB,       OSD_COUNTRY_CROATIA},
    {TIMEZONE_TUNIS,        OSD_COUNTRY_TUNIS},
    {TIMEZONE_ALGIERS,      OSD_COUNTRY_ALGERIA},
    {TIMEZONE_ATHENS,       OSD_COUNTRY_GREECE},
    {TIMEZONE_BUCURESTI,    OSD_COUNTRY_RUMANIA},
    {TIMEZONE_HELSINKI,     OSD_COUNTRY_FINLAND},
    {TIMEZONE_SOFIA,        OSD_COUNTRY_BULGARIA},
    {TIMEZONE_CAIRO,        OSD_COUNTRY_EGYPT},
    {TIMEZONE_CAPE_TOWN,    OSD_COUNTRY_SOUTH_AFRICA},
    {TIMEZONE_JERUSSLEM,    OSD_COUNTRY_ISRAEL},
    {TIMEZONE_MOSCOW,       OSD_COUNTRY_RUSSIA},
    {TIMEZONE_TEHERAN,      OSD_COUNTRY_IRAN},
    {TIMEZONE_ABU_DHABI,    OSD_COUNTRY_UNITED_ARAB_EMIRATES},
    {TIMEZONE_BEIJING,      OSD_COUNTRY_CHINA},
    {TIMEZONE_ESTONIA,      OSD_COUNTRY_ESTONIA},
    {TIMEZONE_TURKEY,      OSD_COUNTRY_TURKEY},
    {TIMEZONE_WA,           OSD_COUNTRY_AUSTRALIA},
    {TIMEZONE_SA,           OSD_COUNTRY_AUSTRALIA},
    {TIMEZONE_NT,           OSD_COUNTRY_AUSTRALIA},
    {TIMEZONE_NSW,          OSD_COUNTRY_AUSTRALIA},
    {TIMEZONE_VIC,          OSD_COUNTRY_AUSTRALIA},
    {TIMEZONE_QLD,          OSD_COUNTRY_AUSTRALIA},
    {TIMEZONE_TAS,          OSD_COUNTRY_AUSTRALIA},

#if ENABLE_SBTVD_BRAZIL_APP
    {TIMEZONE_AM_WEST,      OSD_COUNTRY_BRAZIL},
    {TIMEZONE_ACRE,         OSD_COUNTRY_BRAZIL},
    {TIMEZONE_M_GROSSO,     OSD_COUNTRY_BRAZIL},
    {TIMEZONE_NORTH,        OSD_COUNTRY_BRAZIL},
    {TIMEZONE_BRASILIA,     OSD_COUNTRY_BRAZIL},
    {TIMEZONE_NORTHEAST,    OSD_COUNTRY_BRAZIL},
    {TIMEZONE_F_NORONHA,    OSD_COUNTRY_BRAZIL},
#endif
};
#endif
//*******************************************************************************
//             Functions
//******************************************************************************
#if ENABLE_DTV
static void MApp_SetSICountry(EN_OSD_COUNTRY_SETTING eOSDCountrySetting);
static void MApp_SetSILanguage(EN_LANGUAGE eLanguage);
#if 1//(!ENABLE_SBTVD_BRAZIL_APP)
static EN_MENU_TIMEZONE MApp_GetTimeZoneBySITimeZone(EN_SI_TIMEZONE eTimeZone);
#endif
#else
static EN_MENU_TIMEZONE MApp_GetTimeZoneByCountry(EN_OSD_COUNTRY_SETTING eCountry);
#endif

#if ( ENABLE_ARABIC_OSD || ENABLE_THAI_OSD )
extern void msAPI_OSD_SetOSDLanguage(EN_OSDAPI_LANGUAGE eLanguage);
#endif

//*************************************************************************
//Function name:    MApp_GetNoOfDigit
//Passing parameter:    U32 u32Data: Value need to be calculated
//Return parameter:     U8: number of digit
//Description:      Calculate the digit number of u32Data
//*************************************************************************
U8 MApp_GetNoOfDigit ( U32 u32Data )
{
    U8 u8NoOfDigit;

    u8NoOfDigit = 0;
    do
    {
        u32Data /= 10;
        u8NoOfDigit++;
    }
    while ( u32Data != 0 );

    return u8NoOfDigit;
}
//*************************************************************************
//Function name:    MApp_UlongToU16String
//Passing parameter:    U32 ulValue: Value need to be transfered into string
//              U16* bArrOutput: Transfered string pointer
//              S8 NoOfDigit: The number of digits need to transfer
// Return parameter:    none
//Description:      Transfer numer to u16string
//*************************************************************************
//#if (KEEP_UNUSED_FUNC == 1)
void MApp_UlongToU16String ( U32 ulValue, U16 *pArrOutput, S8 NoOfDigit )
{
    pArrOutput[NoOfDigit] = 0;
    NoOfDigit -= 1;

    if(ulValue==0)
    	{
        pArrOutput[NoOfDigit] = ( ulValue % 10 ) + 0x30;
        ulValue /= 10;
        NoOfDigit--;
    	}
	
    while ( ulValue )
    {
        pArrOutput[NoOfDigit--] = ( ulValue % 10 ) + 0x30;
        ulValue /= 10;
    }
    while ( NoOfDigit >= 0 )
    {
        pArrOutput[NoOfDigit] = ' ';
        NoOfDigit--;
    }
}
//#endif

//*************************************************************************
//Function name:    MApp_UlongToU8String
//Passing parameter:    U32 ulValue: Value need to be transfered into string
//              U16* bArrOutput: Transfered string pointer
//              S8 NoOfDigit: The number of digits need to transfer
// Return parameter:    none
//Description:      Transfer numer to u8string
//*************************************************************************
void MApp_UlongToU8String ( U32 ulValue, U8 *pArrOutput, S8 NoOfDigit )
{
    pArrOutput[NoOfDigit] = 0;
    NoOfDigit -= 1;

    while ( ulValue )
    {
        pArrOutput[NoOfDigit--] = ( ulValue % 10 ) + 0x30;
        ulValue /= 10;
    }
    while ( NoOfDigit >= 0 )
    {
        pArrOutput[NoOfDigit] = '0';
        NoOfDigit--;
    }
}

//*************************************************************************
//Function name:    MApp_GetNoOfHexDigit
//Passing parameter:    U32 u32Data: Value need to be calculated
//Return parameter:     U8: number of digit
//Description:      Calculate the digit number of u32Data
//*************************************************************************
U8 MApp_GetNoOfHexDigit ( U32 u32Data )
{
    U8 u8NoOfDigit;

    u8NoOfDigit = 0;
    do
    {
        u32Data /= 0x10;
        u8NoOfDigit++;
    }
    while ( u32Data != 0 );

    return u8NoOfDigit;
}
//*************************************************************************
//Function name:    MApp_HexUlongToU16String
//Passing parameter:    U32 ulValue: Value need to be transfered into string
//              U16* bArrOutput: Transfered string pointer
//              S8 NoOfDigit: The number of digits need to transfer
// Return parameter:    none
//Description:      Transfer numer to u16string
//*************************************************************************
//#if (KEEP_UNUSED_FUNC == 1)
void MApp_HexUlongToU16String ( U32 ulValue, U16 *pArrOutput, S8 NoOfDigit )
{
    U8 u8NumValue = 0;

    pArrOutput[NoOfDigit] = 0;
    NoOfDigit -= 1;

    while ( ulValue )
    {
        u8NumValue = ulValue % 0x10;
        if(u8NumValue <= 9)
            pArrOutput[NoOfDigit] = u8NumValue + 0x30;
        else
            pArrOutput[NoOfDigit] = (u8NumValue-0x0A) + 'A';
        NoOfDigit--;
        ulValue /= 0x10;
    }
    while ( NoOfDigit >= 0 )
    {
        pArrOutput[NoOfDigit] = '0';
        NoOfDigit--;
    }
}
//#endif

void MApp_HexUlongToU8String ( U32 ulValue, U8 *pArrOutput, S8 NoOfDigit )
{
    U8 u8NumValue = 0;

    pArrOutput[NoOfDigit] = 0;
    NoOfDigit -= 1;

    while ( ulValue )
    {
        u8NumValue = ulValue % 0x10;
        if(u8NumValue <= 9)
            pArrOutput[NoOfDigit] = u8NumValue + 0x30;
        else
            pArrOutput[NoOfDigit] = (u8NumValue-0x0A) + 'A';
        NoOfDigit--;
        ulValue /= 0x10;
    }
    while ( NoOfDigit >= 0 )
    {
        pArrOutput[NoOfDigit] = '0';
        NoOfDigit--;
    }
}


//*************************************************************************
//Function name:    MApp_U8StringToU16String
//Passing parameter:    U8 *pu8Str: string pointer to be transfered
//              U16 *pu16Str: transfered string pointer
//              U8 u8Strlen: the number of characters to be transfered
// Return parameter:    none
//Description:      Transfer u8string to u16string
//*************************************************************************
void MApp_U8StringToU16String ( U8 *pu8Str, U16 *pu16Str, U8 u8Strlen )
{
    U8 u8Index;

    for ( u8Index = 0; u8Index < u8Strlen; u8Index++ )
    {
        pu16Str[u8Index] = pu8Str[u8Index];
    }
    pu16Str[u8Index] = 0;
}

U32 MApp_U8StringToUlong(U8* InputStr, U8 len)
{
    U32 ulValue = 0;
    U8 strIdx = 0;

    if(len<=1)
        return ulValue;

    for(strIdx=0; strIdx<len; strIdx++)
    {
        ulValue *= 10;
        ulValue += InputStr[strIdx] - '0';
    }

    return ulValue;
}

//*************************************************************************
//Function name:    MApp_GetLeap
//Passing parameter:    U16 year :  current solar year
//Return parameter:     U8: Leap year or not
//Description:      Decide leap year
//*************************************************************************
U8 MApp_GetLeap ( U16 u16year )
{
    if ( u16year % 400 == 0 )
    {
        return 1;
    }
    else if ( u16year % 100 == 0 )
    {
        return 0;
    }
    else if ( u16year % 4 == 0 )
    {
        return 1;
    }

    return 0;
}

// Get day of week
U8 MApp_GetDayOfWeek(U16 u16Year, U8 u8Month, U8 u8Day)
{
    U8 i;
    U16 u16days = 0;
    U32 u32sum;

    for(i = 1; i<=(u8Month - 1); i++)
    {
        u16days+=SolarCal[i - 1];
    }

    if(MApp_GetLeap( u16Year )&&u8Month>2)
        u16days+=1;

    u16days+=u8Day;

    u32sum = u16Year -1 + ((u16Year - 1)/4) - ((u16Year - 1)/100) + ((u16Year - 1)/400) + u16days;

    return (U8) (u32sum%7);
}

//*************************************************************************
//Function name:    MApp_GetDaysOfThisYear
//Passing parameter:    U16 u16Year : specific year
//Return parameter:     U16: number of days
//Description:      Get number of days of the specific year
//*************************************************************************
static U16 MApp_GetDaysOfThisYear ( U16 u16Year )
{
    return MApp_GetLeap( u16Year ) ? 366 : 365;
}
//*************************************************************************
//Function name:    MApp_GetDaysOfThisMonth
//Passing parameter:    U16 u16Year : specific year
//              U8 u8Month : specific month (1 ~ 12)
//Return parameter:     U8: number of days
//Description:      Get number of days of the specific month
//*************************************************************************
U8 MApp_GetDaysOfThisMonth ( U16 u16Year, U8 u8Month )
{
    if ( u8Month >= 1 && u8Month <= 12 )
    {
        return ( ( MApp_GetLeap( u16Year ) && u8Month == 2 ) ? 29 : SolarCal[u8Month - 1] );
    }
    else
    {
        return 0;
    }
}
//*************************************************************************
//Function name:    MApp_SetToDefaultSystemTime
//Passing parameter:    ST_TIME *pstTime : pointer of date structure
//Return parameter:     none
//Description:      set to default date
//*************************************************************************
/* the base time starts from DEFAULT_YEAR/DEFAULT_MONTH/DEFAULT_DAY DEFAULT_HOUR:DEFAULT_MIN:DEFAULT_SEC*/
void MApp_SetToDefaultSystemTime ( ST_TIME *pstTime )
{
    pstTime->u16Year = DEFAULT_YEAR;
    pstTime->u8Month = DEFAULT_MONTH;
    pstTime->u8Day = DEFAULT_DAY;
    pstTime->u8Hour = DEFAULT_HOUR;
    pstTime->u8Min = DEFAULT_MIN;
    pstTime->u8Sec = DEFAULT_SEC;
}
/*****************************************************************************/
/* please refer to EN300 468 Annex C */
#if 0
void MApp_MJDUTC2Date(U8 *pau8TDTData, ST_TIME *pstTime)
{
    U8 YY,MM,K;
    U16 u16MJD;

    u16MJD = pau8TDTData[0] << 8 | pau8TDTData[1];
    if(u16MJD > DEFAULT_MJD)
    {
    YY = (U8) ((u16MJD - 15078.2) / 365.25);
    MM = (U8) ((u16MJD - 14956.1 - (YY * 365.25)) / 30.6001);
    K = ((MM == 14) || (MM == 15)) ? 1 : 0;

    pstTime->u16Year = (U16) (1900 + YY + K);
    pstTime->u8Month = (U8) (MM - 1 - (K * 12));
    pstTime->u8Day = (U8) (u16MJD - 14956 - (U16) (YY * 365.25) - (U16) (MM * 30.6001));
    pstTime->u8Hour = BCD2Dec(pau8TDTData[2]);
    pstTime->u8Min = BCD2Dec(pau8TDTData[3]);
    pstTime->u8Sec = BCD2Dec(pau8TDTData[4]);
    }
    else
    {
    /* set to default date */
    MApp_SetToDefaultSystemTime(pstTime);
    }
}
U32 MApp_MJDUTC2Seconds ( U8 *pau8TDTData )
{
    U8 YY, MM, K;
    U16 u16MJD;
    U32 u32TotalSeconds;

    u32TotalSeconds = 0;
    u16MJD = pau8TDTData[0] << 8 | pau8TDTData[1];
    if ( u16MJD > DEFAULT_MJD )
    {
        YY = ( U8 ) ( ( u16MJD - 15078.2 ) / 365.25 );
        MM = ( U8 ) ( ( u16MJD - 14956.1 - ( YY * 365.25 ) ) / 30.6001 );
        K = ( ( MM == 14 ) || ( MM == 15 ) ) ? 1 : 0;

        stDate.u16Year = ( U16 ) ( 1900 + YY + K );
        stDate.u8Month = ( U8 ) ( MM - 1 - ( K * 12 ) );
        stDate.u8Day = ( U8 ) ( u16MJD - 14956 - ( U16 ) ( YY * 365.25 ) - ( U16 ) ( MM * 30.6001 ) );
        stDate.u8Hour = BCD2Dec( pau8TDTData[2] );
        stDate.u8Min = BCD2Dec( pau8TDTData[3] );
        stDate.u8Sec = BCD2Dec( pau8TDTData[4] );

        /* sec */
        u32TotalSeconds += stDate.u8Sec;

        /* min */
        u32TotalSeconds += stDate.u8Min * SECONDS_PER_MIN;

        /* hour */
        u32TotalSeconds += stDate.u8Hour * SECONDS_PER_HOUR;

        /* day */
        u32TotalSeconds += ( stDate.u8Day - 1 ) * SECONDS_PER_DAY;

        /* month */
        u32TotalSeconds += SolarDays[MApp_GetLeap( stDate.u16Year ) * 14 + stDate.u8Month - 1] * SECONDS_PER_DAY;

        /* year */
        while ( stDate.u16Year > DEFAULT_YEAR )
        {
            stDate.u16Year--;
            u32TotalSeconds += MApp_GetDaysOfThisYear( stDate.u16Year ) * SECONDS_PER_DAY;
        }
    }

    return u32TotalSeconds;
}
#endif
//*************************************************************************
//Function name:    MApp_ConvertStTime2Seconds
//Passing parameter:    ST_TIME *pstTime :  date got from TDT
//Return parameter:     U32 u32TotalSeconds : total secounds
//Description:      calculate total seconds which starts from the default date
//*************************************************************************
/* the base time starts from DEFAULT_YEAR/DEFAULT_MONTH/DEFAULT_DAY DEFAULT_HOUR:DEFAULT_MIN:DEFAULT_SEC*/
U32 MApp_ConvertStTime2Seconds ( ST_TIME *pstTime )
{
    U32 u32TotalSeconds;
    U16 u16YearCalc;

    u32TotalSeconds = 0;

    /* sec */
    u32TotalSeconds += pstTime->u8Sec;

    /* min */
    u32TotalSeconds += pstTime->u8Min * SECONDS_PER_MIN;

    /* hour */
    u32TotalSeconds += pstTime->u8Hour * SECONDS_PER_HOUR;

    /* day */
    u32TotalSeconds += ( pstTime->u8Day - 1 ) * SECONDS_PER_DAY;

    /* month */
    u32TotalSeconds += SolarDays[MApp_GetLeap( pstTime->u16Year ) * 14 + pstTime->u8Month - 1] * SECONDS_PER_DAY;

    /* year */
    u16YearCalc = pstTime->u16Year;
    while(u16YearCalc > DEFAULT_YEAR)
    {
        u16YearCalc--;
        u32TotalSeconds += MApp_GetDaysOfThisYear( u16YearCalc ) * SECONDS_PER_DAY;
    }

    return u32TotalSeconds;
}
//*************************************************************************
//Function name:    MApp_ConvertSeconds2StTime
//Passing parameter:    U32 u32SystemTime : system time + offset time
//              ST_TIME *pstTime : local date
//Return parameter:     none
//Description:      Calculate local date
//*************************************************************************
/* the base time starts from DEFAULT_YEAR/DEFAULT_MONTH/DEFAULT_DAY DEFAULT_HOUR:DEFAULT_MIN:DEFAULT_SEC*/
void MApp_ConvertSeconds2StTime ( U32 u32SystemTime, ST_TIME *pstTime )
{
    U16 u16TotalDays, u16Days;

    /* set to base date */
    MApp_SetToDefaultSystemTime( pstTime );

    /* u32SystemTime = total accumulative seconds from base date */
    if(u32SystemTime > 0)
    {
        /* sec */
        pstTime->u8Sec = u32SystemTime % SECONDS_PER_MIN;
        u32SystemTime -= pstTime->u8Sec;

        /* min */
        pstTime->u8Min = ( u32SystemTime / SECONDS_PER_MIN ) % MINS_PER_HOUR;
        u32SystemTime -= pstTime->u8Min * SECONDS_PER_MIN;

        /* hour */
        pstTime->u8Hour = ( u32SystemTime / SECONDS_PER_HOUR ) % HOURS_PER_DAY;
        u32SystemTime -= pstTime->u8Hour * SECONDS_PER_HOUR;

        /* days */
        u16TotalDays = u32SystemTime / SECONDS_PER_DAY;

        /* year */
        u16Days = MApp_GetDaysOfThisYear( pstTime->u16Year );
        while ( u16TotalDays >= u16Days )
        {
            u16TotalDays -= u16Days;
            pstTime->u16Year++;
            u16Days = MApp_GetDaysOfThisYear( pstTime->u16Year );
        }

        /* month */
        u16Days = MApp_GetDaysOfThisMonth( pstTime->u16Year, pstTime->u8Month );
        while ( u16TotalDays >= u16Days )
        {
            u16TotalDays -= u16Days;
            pstTime->u8Month++;
            u16Days = MApp_GetDaysOfThisMonth( pstTime->u16Year, pstTime->u8Month );
        }

        /* day */
        pstTime->u8Day += ( U8 ) u16TotalDays;
    }
}

//*************************************************************************
//Function name:    MApp_GetTimeZoneOffset
//Passing parameter:    Time Zone
//Return parameter:     offset time    in seconds
//Description:      Calculate Time Zone offset time in seconds
//*************************************************************************
S32 MApp_GetTimeZoneOffset ( U8 u8TimeZone )
{
    S32 s32TempTime = 0;
    s32TempTime = (u8TimeZone - (S32)EN_Clock_TimeZone_24) * SECONDS_PER_HALF_HOUR;
    return s32TempTime;
}

U8 MApp_CalSummerTimeOffset(U8 *L_MJDUTC)
{
#if 1
        L_MJDUTC=L_MJDUTC;
        return 0;
#else
    U32            MJD;
    U8            WD;    // Day of week from Monday (=1) to Sunday (=7)
    U8            First_DST_Transition;    // Before = 0, After = 1;
    U8            Second_DST_Transition;    // Before = 0, After = 1;
    U8            summer_time_offset;

    if ( IS_DTG_COUNTRY(OSD_COUNTRY_SETTING) )//disable for DTG test
        return 0;
    First_DST_Transition = 0;    // Before = 0, After = 1;
    Second_DST_Transition = 0;    // Before = 0, After = 1;



    MJD = GET_3BYTE(L_MJDUTC);
    WD = ((MJD+2)%7) + 1;

    // First DST Transition
    if(stDate.u8Month >= 4)
    {
        First_DST_Transition = 1;
    }
    else if( (stDate.u8Month==3) &&
            (((stDate.u8Day==26)&&(WD==1))            || ((stDate.u8Day==27)&&(WD>=1)&&(WD<=2)) ||
             ((stDate.u8Day==28)&&(WD>=1)&&(WD<=3)) || ((stDate.u8Day==29)&&(WD>=1)&&(WD<=4)) ||
             ((stDate.u8Day==30)&&(WD>=1)&&(WD<=5)) || ((stDate.u8Day==31)&&(WD>=1)&&(WD<=6))) )
    {
        First_DST_Transition = 1;
    }
    else if( (stDate.u8Month==3) &&
            (((stDate.u8Day>=25)&&(stDate.u8Day<=31)) && (WD==7) && (stDate.u8Hour!=0)) )
    {
        First_DST_Transition = 1;
    }

    // Second DST Transition
    if(stDate.u8Month >= 11)
    {
        Second_DST_Transition= 1;
    }
    else if( (stDate.u8Month==10) &&
            (((stDate.u8Day==26)&&(WD==1))            || ((stDate.u8Day==27)&&(WD>=1)&&(WD<=2)) ||
             ((stDate.u8Day==28)&&(WD>=1)&&(WD<=3)) || ((stDate.u8Day==29)&&(WD>=1)&&(WD<=4)) ||
             ((stDate.u8Day==30)&&(WD>=1)&&(WD<=5)) || ((stDate.u8Day==31)&&(WD>=1)&&(WD<=6))) )
    {
        Second_DST_Transition = 1;
    }
    else if( (stDate.u8Month==10) &&
            (((stDate.u8Day>=25)&&(stDate.u8Day<=31)) && (WD==7) && (stDate.u8Hour!=0)) )
    {
        Second_DST_Transition = 1;
    }

    // Summer Time Setting
    if((First_DST_Transition == 1) && (Second_DST_Transition == 0))
    {
        //dbgprint("^y^ Summer~ ^^");
        summer_time_offset = 1;    // 1 Hour
    }
    else
    {
        //dbgprint("^y^ Winter~ ^^");
        summer_time_offset = 0;
    }
    return summer_time_offset;
#endif
}

void MApp_CalDefaultTimeOffest(void)
{
#if ENABLE_DTV
    U8 au8UTCTime[5];
#endif
    U8 summerTimeOffset =0;
    S32 s32TempTime = 0;


    msAPI_Timer_SetOffsetTime(0);
    msAPI_Timer_SetTimeOfChange(0);
    msAPI_Timer_SetNextTimeOffset(0);
#if ENABLE_DTV
    MApp_SI_Get_UTCTime(au8UTCTime);
    summerTimeOffset = MApp_CalSummerTimeOffset(au8UTCTime);
#endif
    s32TempTime = MApp_GetTimeZoneOffset(stGenSetting.g_Time.en_Clock_TimeZone);
    s32TempTime += summerTimeOffset*SECONDS_PER_HOUR;
    msAPI_Timer_SetOffsetTime(s32TempTime);
}
//*************************************************************************
//Function name:        MApp_GetLocalSystemTime
//Passing parameter:    None
//Return parameter:     Local system time in seconds
//Description:          Calculate local system time in seconds
//*************************************************************************
U32 MApp_GetLocalSystemTime (void)
{
    return (msAPI_Timer_GetSystemTime()+ msAPI_Timer_GetOffsetTime());
}
//*************************************************************************
//Function name:        MApp_SetLocalSystemTime
//Passing parameter:    Local system time in seconds
//Return parameter:     System time w/o time zone, day light saving offset
//Description:          Calculate local system time in seconds
//*************************************************************************
void MApp_SetLocalSystemTime (U32 u32LocalSystemTime)
{
    msAPI_Timer_SetSystemTime(u32LocalSystemTime -  msAPI_Timer_GetOffsetTime());
}
//*************************************************************************
//Function name:        MApp_GetLocalWakeUpTime
//Passing parameter:    None
//Return parameter:     Local WakeUp time in seconds
//Description:          Calculate local WakeUp time in seconds
//*************************************************************************
U32 MApp_GetLocalWakeUpTime (void)
{
    return (msAPI_Timer_GetWakeupTime()+ msAPI_Timer_GetOffsetTime());
}
//*************************************************************************
//Function name:        MApp_SetLocalWakeUpTime
//Passing parameter:    Local WakeUp time in seconds
//Return parameter:     WakeUp time w/o time zone, day light saving offset
//Description:          Calculate local WakeUp time in seconds
//*************************************************************************
void MApp_SetLocalWakeUpTime (U32 u32LocalWakeUpTime)
{
    //C51
    msAPI_Timer_SetWakeupTime(u32LocalWakeUpTime - msAPI_Timer_GetOffsetTime());
    //RTC
    msAPI_Timer_SetRTCWakeUpTime(u32LocalWakeUpTime - msAPI_Timer_GetOffsetTime());
}

//*************************************************************************
//Function name:    MApp_IsSrcHasSignal
//Passing parameter: eWindow - MAIN_WINDOW, SUB_WINDOW
//Return parameter:
//Description:
//*************************************************************************
BOOLEAN MApp_IsSrcHasSignal(SCALER_WIN eWindow)
{
    if( IsSrcTypeAnalog(SYS_INPUT_SOURCE_TYPE(eWindow)) || IsSrcTypeHDMI(SYS_INPUT_SOURCE_TYPE(eWindow)) || IsSrcTypeDVI(SYS_INPUT_SOURCE_TYPE(eWindow)))
    {
        if(MApp_PCMode_GetCurrentState(eWindow) != E_PCMODE_STABLE_SUPPORT_MODE) //(g_bInputTimingChange || (g_bUnsupportMode)|| MApp_IsSyncLossFlag())
        {
            #if ENABLE_DLC
            MApi_XC_DLC_CGC_Reset();
            #if ENABLE_DBC
                MApi_XC_DLC_DBC_Reset();
            #endif
            #endif
            return FALSE;
        }
    }
    else if (IsSrcTypeDTV(SYS_INPUT_SOURCE_TYPE(eWindow)))
    {
        VDEC_DispInfo vidStatus;
        if(msAPI_VID_GetVidInfo(&vidStatus))
        {
            return TRUE;
        }
        else
        {
            #if ENABLE_DLC
            MApi_XC_DLC_CGC_Reset();
            #if ENABLE_DBC
                MApi_XC_DLC_DBC_Reset();
            #endif
            #endif
            return FALSE;
        }
    }
#if ENABLE_DMP
    else if (IsSrcTypeStorage(SYS_INPUT_SOURCE_TYPE(eWindow)))
    {
    }
#endif
    else // Digital port
    {

        if( FALSE == MApp_VD_IsSyncLock() )
        {
            #if ENABLE_DLC
            MApi_XC_DLC_CGC_Reset();
            #if ENABLE_DBC
                MApi_XC_DLC_DBC_Reset();
            #endif
            #endif
            return FALSE;
        }
    }
    return TRUE;
}


/*=========================================================================
    FUNCTION    : MApp_ResetTimeLog()
                  MApp_UpdateTimeLog()
    DESCRIPTION : Reset/Update/Dump Channel Change Time Log
=========================================================================*/
/*ZUI_TODO:
void MApp_ResetTimeLog(void)
{
    g_TimeLog.tl_numLogs = 0;
    return;
}

void MApp_UpdateTimeLog(U8 u8TimeLogIndex)
{
    U8 i=0;
    int    nLogs = g_TimeLog.tl_numLogs;

    if (nLogs < 16)
    {
        g_TimeLog.tl_index[nLogs] = u8TimeLogIndex;
        g_TimeLog.tl_time [nLogs] = msAPI_Timer_GetTime0();
        g_TimeLog.tl_numLogs++;
    }
    return;
}

void MApp_DumpTimeLog(void)
{
#if 0    // disable code because of bank size overflow, don't delete
    U8     i, nLogs = g_TimeLog.tl_numLogs;
    U32    firstTicks, prevTicks;

    if (nLogs > 0)
    {
        firstTicks = g_TimeLog.tl_time[0];
        prevTicks  = g_TimeLog.tl_time[0];
        printf("  Num, Index  ,timeStamp,  Delta1,  Delta2\n");
        for (i = 0; i < nLogs; i++)
        {
            printf("  %bu,  %bu,  %9.3f, %6.3f, %6.3f\n", i,
                        g_TimeLog.tl_index[i],
                        (g_TimeLog.tl_time[i]             )/1000.0,
                        (g_TimeLog.tl_time[i] - prevTicks )/1000.0,
                        (g_TimeLog.tl_time[i] - firstTicks)/1000.0);
            prevTicks = g_TimeLog.tl_time[i];
        }
    }
    else
    {
        printf("No Time Log Present\n");
    }
#endif

    return;
}
*/

U32 MApp_UTC2Seconds(U8 *pau8TDTData)
{
    U32 u32TotalSeconds = 0;

    _stDate.u8Hour = BCD2Dec(pau8TDTData[0]);
    _stDate.u8Min  = BCD2Dec(pau8TDTData[1]);
    _stDate.u8Sec  = BCD2Dec(pau8TDTData[2]);

    //printf("\n %bu %bu %bu\n",pau8TDTData[0],pau8TDTData[1],pau8TDTData[2]);
    /* sec */
    u32TotalSeconds += _stDate.u8Sec;

    /* min */
    u32TotalSeconds += _stDate.u8Min * SECONDS_PER_MIN;

    /* hour */
    u32TotalSeconds += _stDate.u8Hour * SECONDS_PER_HOUR;

    return u32TotalSeconds;
}

#if 1    // disable code because of bank size overflow, don't delete
void MApp_Seconds2UTC ( U32 u32TotalSeconds, U8 *pau8TDTData )
{
    ST_TIME stDateTmp;

    memset(&stDateTmp, 0x00, sizeof(ST_TIME));
    memset(pau8TDTData, 0x00, 3);

    /* sec */
    stDateTmp.u8Sec  = u32TotalSeconds % SECONDS_PER_MIN;
    u32TotalSeconds -= stDateTmp.u8Sec;

    /* min */
    stDateTmp.u8Min  = ( u32TotalSeconds / SECONDS_PER_MIN ) % MINS_PER_HOUR;
    u32TotalSeconds -= stDateTmp.u8Min * SECONDS_PER_MIN;

    /* hour */
    stDateTmp.u8Hour = u32TotalSeconds / SECONDS_PER_HOUR ;

    pau8TDTData[0] = DEC2BCD(stDateTmp.u8Hour);
    pau8TDTData[1] = DEC2BCD(stDateTmp.u8Min);
    pau8TDTData[2] = DEC2BCD(stDateTmp.u8Sec);
}
#endif

#if 0
U32 MApp_MJD2Sec(U8 *pu8MJD)
{
    U8 YY,MM,K;
    U16 u16MJD;
    U32 u32TotalSeconds;

    u32TotalSeconds = 0;
    u16MJD = pu8MJD[0] << 8 | pu8MJD[1];

    // 2000/1/1 ~ 2100/1/1
    if ((u16MJD > DEFAULT_MJD) && (u16MJD < (DEFAULT_MJD+36500)))
    {
        YY = (U8) ((u16MJD - 15078.2) / 365.25);
        MM = (U8) ((u16MJD - 14956.1 - (YY * 365.25)) / 30.6001);
        K = ((MM == 14) || (MM == 15)) ? 1 : 0;

        stDate.u16Year = (U16) (1900 + YY + K);
        stDate.u8Month = (U8) (MM - 1 - (K * 12));
        stDate.u8Day = (U8) (u16MJD - 14956 - (U16) (YY * 365.25) - (U16) (MM * 30.6001));

        /* day */
        u32TotalSeconds += (stDate.u8Day - 1) * SECONDS_PER_DAY;

        /* month */
        u32TotalSeconds += SolarDays[MApp_GetLeap(stDate.u16Year) * 14 + stDate.u8Month - 1] * SECONDS_PER_DAY;

        /* year */
        while(stDate.u16Year > DEFAULT_YEAR)
        {
            stDate.u16Year--;
            u32TotalSeconds += MApp_GetDaysOfThisYear(stDate.u16Year) * SECONDS_PER_DAY;
        }
    }

    return u32TotalSeconds;
}
#endif

U32 MApp_MJDUTC2Seconds(U8 *pau8TDTData)
{
    U8 YY,MM,K;
    U16 u16MJD;
    U32 u32TotalSeconds;

    u32TotalSeconds = 0;
    u16MJD = pau8TDTData[0] << 8 | pau8TDTData[1];
    if(u16MJD > DEFAULT_MJD)
    {
        YY = (U8) ((u16MJD - 15078.2) / 365.25);
        MM = (U8) ((u16MJD - 14956.1 - (U16)(YY * 365.25)) / 30.6001);
        K = ((MM == 14) || (MM == 15)) ? 1 : 0;

        _stDate.u16Year = (U16) (1900 + YY + K);
        _stDate.u8Month = (U8) (MM - 1 - (K * 12));
        _stDate.u8Day = (U8) (u16MJD - 14956 - (U16) (YY * 365.25) - (U16) (MM * 30.6001));
        _stDate.u8Hour = BCD2Dec(pau8TDTData[2]);
        _stDate.u8Min = BCD2Dec(pau8TDTData[3]);
        _stDate.u8Sec = BCD2Dec(pau8TDTData[4]);

        /* sec */
        u32TotalSeconds += _stDate.u8Sec;

        /* min */
        u32TotalSeconds += _stDate.u8Min * SECONDS_PER_MIN;

        /* hour */
        u32TotalSeconds += _stDate.u8Hour * SECONDS_PER_HOUR;

        /* day */
        u32TotalSeconds += (_stDate.u8Day - 1) * SECONDS_PER_DAY;

        /* month */
        u32TotalSeconds += SolarDays[MApp_GetLeap(_stDate.u16Year) * 14 + _stDate.u8Month - 1] * SECONDS_PER_DAY;

        /* year */
        while(_stDate.u16Year > DEFAULT_YEAR)
        {
            _stDate.u16Year--;
            u32TotalSeconds += MApp_GetDaysOfThisYear(_stDate.u16Year) * SECONDS_PER_DAY;
        }
    }

    return u32TotalSeconds;
}

//Notice: the output array pau8TDTData size should be 5.
void MApp_Seconds2MJDUTC ( U32 u32TotalSeconds, U8 *pau8TDTData )
{
    //Array should be allocated outside.
    if(!pau8TDTData)
        return;

    ST_TIME stTime;
    MApp_ConvertSeconds2StTime(u32TotalSeconds, &stTime);

    // In leap years, -1 for Jan, Feb, else 0
    double L = ceil(((double)stTime.u8Month - 14.0) / 12.0);
    double p1 = (double)stTime.u8Day - 32075.0 + floor(1461.0 * ((double)stTime.u16Year + 4800.0 + L) / 4.0);

    double p2 =  floor(367.0 * ((double)stTime.u8Month - 2.0 - L * 12.0) / 12.0);
    double p3 = 3.0 *  floor(floor(((double)stTime.u16Year + 4900.0 + L) / 100.0) / 4.0);

    double julian = p1 + p2 - p3 - 0.5;
    U16 mjd = (U16)(julian - 2400000.5);

    pau8TDTData[0] = HIGHBYTE(mjd);
    pau8TDTData[1] = LOWBYTE(mjd);
    pau8TDTData[2] = DEC2BCD(stTime.u8Hour);
    pau8TDTData[3] = DEC2BCD(stTime.u8Min);
    pau8TDTData[4] = DEC2BCD(stTime.u8Sec);
}

void MApp_SetClockTimezoneByTimezone(EN_MENU_TIMEZONE eTimezone)
{
#if ENABLE_SBTVD_BRAZIL_APP
        if(eTimezone<=TIMEZONE_GMT_Minus5_END)
        {
            stGenSetting.g_Time.en_Clock_TimeZone=EN_Clock_TimeZone_20;
        }
        else if(eTimezone>=TIMEZONE_GMT_Minus4_START && eTimezone<=TIMEZONE_GMT_Minus4_END)
        {
            stGenSetting.g_Time.en_Clock_TimeZone=EN_Clock_TimeZone_22;
        }
        else if(eTimezone>=TIMEZONE_GMT_Minus3_START && eTimezone<=TIMEZONE_GMT_Minus3_END)
        {
            stGenSetting.g_Time.en_Clock_TimeZone=EN_Clock_TimeZone_24;
        }
        else if(eTimezone>=TIMEZONE_GMT_Minus2_START && eTimezone<=TIMEZONE_GMT_Minus2_END)
        {
            stGenSetting.g_Time.en_Clock_TimeZone=EN_Clock_TimeZone_26;
        }
        else
        {
            stGenSetting.g_Time.en_Clock_TimeZone=EN_Clock_TimeZone_24;
        }
#else
        if((eTimezone<=TIMEZONE_GMT_0_END))
        {
            stGenSetting.g_Time.en_Clock_TimeZone=EN_Clock_TimeZone_24;
        }
        else if(eTimezone>=TIMEZONE_GMT_1_START && eTimezone<=TIMEZONE_GMT_1_END)
        {
            stGenSetting.g_Time.en_Clock_TimeZone=EN_Clock_TimeZone_26;
        }
        else if(eTimezone>=TIMEZONE_GMT_2_START && eTimezone<=TIMEZONE_GMT_2_END)
        {
            stGenSetting.g_Time.en_Clock_TimeZone=EN_Clock_TimeZone_28;
        }
        else if(eTimezone>=TIMEZONE_GMT_3_START && eTimezone<=TIMEZONE_GMT_3_END)
        {
            stGenSetting.g_Time.en_Clock_TimeZone=EN_Clock_TimeZone_30;
        }
        else if(eTimezone>=TIMEZONE_GMT_8_START && eTimezone<=TIMEZONE_GMT_8_END)
        {
            stGenSetting.g_Time.en_Clock_TimeZone=EN_Clock_TimeZone_40;
        }
        else if(eTimezone>=TIMEZONE_GMT_9Point5_START && eTimezone<=TIMEZONE_GMT_9Point5_END)
        {
            stGenSetting.g_Time.en_Clock_TimeZone=EN_Clock_TimeZone_43;
        }
        else if(eTimezone>=TIMEZONE_GMT_10_START && eTimezone<=TIMEZONE_GMT_10_END)
        {
            stGenSetting.g_Time.en_Clock_TimeZone=EN_Clock_TimeZone_44;
        }
        else if(eTimezone>=TIMEZONE_GMT_12_START && eTimezone<=TIMEZONE_GMT_12_END)
        {
            stGenSetting.g_Time.en_Clock_TimeZone=EN_Clock_TimeZone_48;
        }
	else if(eTimezone == TIMEZONE_AZORES)
	{
            stGenSetting.g_Time.en_Clock_TimeZone=EN_Clock_TimeZone_22;
	}
#endif
}
void MApp_SetTimezoneOfCurrentCountry(U8 u8Country)
{
    U8 u8TimeZone;
    switch(u8Country)
    {
        case OSD_COUNTRY_AUSTRIA:
            u8TimeZone = TIMEZONE_VIENNA;
            break;
        case OSD_COUNTRY_BELGIUM:
            u8TimeZone = TIMEZONE_BRUSSELS;
            break;
        case OSD_COUNTRY_BULGARIA:
            u8TimeZone = TIMEZONE_SOFIA;
            break;
        case OSD_COUNTRY_CROATIA:
            u8TimeZone = TIMEZONE_ZAGREB;
            break;
        case OSD_COUNTRY_CZECH:
            u8TimeZone = TIMEZONE_PRAGUE;
            break;
        case OSD_COUNTRY_DENMARK:
            u8TimeZone = TIMEZONE_COPENHAGEN;
            break;
        case OSD_COUNTRY_FINLAND:
            u8TimeZone = TIMEZONE_HELSINKI;
            break;
        case OSD_COUNTRY_FRANCE:
            u8TimeZone = TIMEZONE_PARIS;
            break;
        case OSD_COUNTRY_GERMANY:
            u8TimeZone = TIMEZONE_BERLIN;
            break;
        case OSD_COUNTRY_GREECE:
            u8TimeZone = TIMEZONE_ATHENS;
            break;
        case OSD_COUNTRY_HUNGARY:
            u8TimeZone = TIMEZONE_BUDAPEST;
            break;
        case OSD_COUNTRY_ITALY:
            u8TimeZone = TIMEZONE_ROME;
            break;
        case OSD_COUNTRY_LUXEMBOURG:
            u8TimeZone = TIMEZONE_LUXEMBOURG;
            break;
        case OSD_COUNTRY_NETHERLANDS:
            u8TimeZone = TIMEZONE_AMSTERDAM;
            break;
        case OSD_COUNTRY_NORWAY:
            u8TimeZone = TIMEZONE_OSLO;
            break;
        case OSD_COUNTRY_POLAND:
            u8TimeZone = TIMEZONE_WARSAW;
            break;
        case OSD_COUNTRY_PORTUGAL:
            u8TimeZone = TIMEZONE_LISBON;
            break;
        case OSD_COUNTRY_RUMANIA:
            u8TimeZone = TIMEZONE_BUCURESTI;
            break;
        case OSD_COUNTRY_RUSSIA:
            u8TimeZone = TIMEZONE_MOSCOW;
            break;
        case OSD_COUNTRY_SERBIA:
            u8TimeZone = TIMEZONE_BEOGRAD;
            break;
        case OSD_COUNTRY_SLOVENIA:
            u8TimeZone = TIMEZONE_LIUBLJANA;
            break;
        case OSD_COUNTRY_SPAIN    :
            u8TimeZone = TIMEZONE_CANARY;
            break;
        case OSD_COUNTRY_SWEDEN:
            u8TimeZone = TIMEZONE_STOCKHOLM;
            break;
        case OSD_COUNTRY_SWITZERLAND:
            u8TimeZone = TIMEZONE_BERN;
            break;
        case OSD_COUNTRY_UK:
            u8TimeZone = TIMEZONE_LONDON;
            break;
        case OSD_COUNTRY_NEWZEALAND:
            u8TimeZone = TIMEZONE_NZST;
            break;
        case OSD_COUNTRY_MOROCCO:
            u8TimeZone = TIMEZONE_RABAT;
            break;
        case OSD_COUNTRY_TUNIS:
            u8TimeZone = TIMEZONE_TUNIS;
            break;
        case OSD_COUNTRY_ALGERIA:
            u8TimeZone = TIMEZONE_ALGIERS;
            break;
        case OSD_COUNTRY_EGYPT:
            u8TimeZone = TIMEZONE_CAIRO;
            break;
        case OSD_COUNTRY_SOUTH_AFRICA:
            u8TimeZone = TIMEZONE_CAPE_TOWN;
            break;
        case OSD_COUNTRY_ISRAEL:
            u8TimeZone = TIMEZONE_JERUSSLEM;
            break;
        case OSD_COUNTRY_IRAN:
            u8TimeZone = TIMEZONE_TEHERAN;
            break;
        case OSD_COUNTRY_UNITED_ARAB_EMIRATES:
            u8TimeZone = TIMEZONE_ABU_DHABI;
            break;
        case OSD_COUNTRY_SLOVAKIA:
            u8TimeZone = TIMEZONE_BRATISLAVA;
            break;
        case OSD_COUNTRY_ESTONIA:
            u8TimeZone = TIMEZONE_ESTONIA;
            break;
	 case OSD_COUNTRY_TURKEY:
            u8TimeZone = TIMEZONE_TURKEY;
            break;
        default:
            u8TimeZone = TIMEZONE_LONDON;
            break;
    }

    if( u8TimeZone<=TIMEZONE_GMT_0_END)
        stGenSetting.g_Time.en_Clock_TimeZone=EN_Clock_TimeZone_24;
    else if(u8TimeZone>=TIMEZONE_GMT_1_START && u8TimeZone<=TIMEZONE_GMT_1_END)
        stGenSetting.g_Time.en_Clock_TimeZone=EN_Clock_TimeZone_26;
    else if(u8TimeZone>=TIMEZONE_GMT_2_START && u8TimeZone<=TIMEZONE_GMT_2_END)
        stGenSetting.g_Time.en_Clock_TimeZone=EN_Clock_TimeZone_28;
    else if(u8TimeZone>=TIMEZONE_GMT_3_START && u8TimeZone<=TIMEZONE_GMT_3_END)
        stGenSetting.g_Time.en_Clock_TimeZone=EN_Clock_TimeZone_30;
    else if(u8TimeZone>=TIMEZONE_GMT_3Point5_START && u8TimeZone<=TIMEZONE_GMT_3Point5_END)
        stGenSetting.g_Time.en_Clock_TimeZone=EN_Clock_TimeZone_31;
    else if(u8TimeZone>=TIMEZONE_GMT_4_START && u8TimeZone<=TIMEZONE_GMT_4_END)
        stGenSetting.g_Time.en_Clock_TimeZone=EN_Clock_TimeZone_32;
    else if(u8TimeZone>=TIMEZONE_GMT_12_START && u8TimeZone<=TIMEZONE_GMT_12_END)
        stGenSetting.g_Time.en_Clock_TimeZone=EN_Clock_TimeZone_48;
    else if(u8TimeZone>=TIMEZONE_GMT_Minus1_START && u8TimeZone<=TIMEZONE_GMT_Minus1_END)
        stGenSetting.g_Time.en_Clock_TimeZone=EN_Clock_TimeZone_22;
#if 0 //ENABLE_DTV
        MApp_SI_Set_TimeZone((U8)stGenSetting.g_Time.en_Clock_TimeZone);
#endif
}
EN_OSD_COUNTRY_SETTING MApp_GetOSDCountrySetting(void)
{
#ifdef ROM_FILE
    m_eOSDCountrySetting = OSD_COUNTRY_UK;
    return m_eOSDCountrySetting;
#else
    return m_eOSDCountrySetting;
#endif
}
void MApp_SetSubtAndAudioByCountry(EN_OSD_COUNTRY_SETTING eOSDCountrySetting)
{
    switch(eOSDCountrySetting)
    {
        case OSD_COUNTRY_AUSTRALIA:
         {
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage = LANGUAGE_ENGLISH;
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage_2= LANGUAGE_ENGLISH;
            stGenSetting.g_SoundSetting.enSoundAudioLan1 = LANGUAGE_ENGLISH;
            stGenSetting.g_SoundSetting.enSoundAudioLan2 = LANGUAGE_ENGLISH;
        }
        break;
        case OSD_COUNTRY_AUSTRIA:
         {
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage = LANGUAGE_GERMAN;
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage_2= LANGUAGE_ENGLISH;
            stGenSetting.g_SoundSetting.enSoundAudioLan1 = LANGUAGE_GERMAN;
            stGenSetting.g_SoundSetting.enSoundAudioLan2 = LANGUAGE_ENGLISH;
        }
        break;
        case OSD_COUNTRY_BELGIUM:
         {
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage = LANGUAGE_GERMAN;
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage_2= LANGUAGE_FRENCH;
            stGenSetting.g_SoundSetting.enSoundAudioLan1 = LANGUAGE_GERMAN;
            stGenSetting.g_SoundSetting.enSoundAudioLan2 = LANGUAGE_FRENCH;
        }
        break;
        case OSD_COUNTRY_BULGARIA:
         {
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage = LANGUAGE_BULGARIAN;
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage_2= LANGUAGE_ENGLISH;
            stGenSetting.g_SoundSetting.enSoundAudioLan1 = LANGUAGE_BULGARIAN;
            stGenSetting.g_SoundSetting.enSoundAudioLan2 = LANGUAGE_ENGLISH;
        }
        break;
        case OSD_COUNTRY_CROATIA:
         {
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage = LANGUAGE_CROATIAN;
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage_2= LANGUAGE_ENGLISH;
            stGenSetting.g_SoundSetting.enSoundAudioLan1 = LANGUAGE_CROATIAN;
            stGenSetting.g_SoundSetting.enSoundAudioLan2 = LANGUAGE_ENGLISH;
        }
        break;
        case OSD_COUNTRY_CZECH:
         {
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage = LANGUAGE_CZECH;
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage_2= LANGUAGE_ENGLISH;
            stGenSetting.g_SoundSetting.enSoundAudioLan1 = LANGUAGE_CZECH;
            stGenSetting.g_SoundSetting.enSoundAudioLan2 = LANGUAGE_ENGLISH;
        }
        break;
        case OSD_COUNTRY_DENMARK:
         {
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage = LANGUAGE_DANISH;
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage_2= LANGUAGE_ENGLISH;
            stGenSetting.g_SoundSetting.enSoundAudioLan1 = LANGUAGE_DANISH;
            stGenSetting.g_SoundSetting.enSoundAudioLan2 = LANGUAGE_ENGLISH;
        }
        break;
        case OSD_COUNTRY_FINLAND:
         {
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage = LANGUAGE_FINNISH;
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage_2= LANGUAGE_SWEDISH;
            stGenSetting.g_SoundSetting.enSoundAudioLan1 = LANGUAGE_FINNISH;
            stGenSetting.g_SoundSetting.enSoundAudioLan2 = LANGUAGE_SWEDISH;
        }
        break;
        case OSD_COUNTRY_FRANCE:
         {
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage = LANGUAGE_FRENCH;
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage_2= LANGUAGE_ENGLISH;
            stGenSetting.g_SoundSetting.enSoundAudioLan1 = LANGUAGE_FRENCH;
            stGenSetting.g_SoundSetting.enSoundAudioLan2 = LANGUAGE_ENGLISH;
        }
        break;
        case OSD_COUNTRY_GERMANY:
         {
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage = LANGUAGE_GERMAN;
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage_2= LANGUAGE_ENGLISH;
            stGenSetting.g_SoundSetting.enSoundAudioLan1 = LANGUAGE_GERMAN;
            stGenSetting.g_SoundSetting.enSoundAudioLan2 = LANGUAGE_ENGLISH;
        }
        break;
        case OSD_COUNTRY_GREECE:
         {
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage = LANGUAGE_GREEK;
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage_2= LANGUAGE_ENGLISH;
            stGenSetting.g_SoundSetting.enSoundAudioLan1 = LANGUAGE_GREEK;
            stGenSetting.g_SoundSetting.enSoundAudioLan2 = LANGUAGE_ENGLISH;
        }
        break;
        case OSD_COUNTRY_HUNGARY:
         {
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage = LANGUAGE_HUNGARIAN;
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage_2= LANGUAGE_ENGLISH;
            stGenSetting.g_SoundSetting.enSoundAudioLan1 = LANGUAGE_HUNGARIAN;
            stGenSetting.g_SoundSetting.enSoundAudioLan2 = LANGUAGE_ENGLISH;
        }
        break;
        case OSD_COUNTRY_ITALY:
         {
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage = LANGUAGE_ITALIAN;
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage_2= LANGUAGE_ENGLISH;
            stGenSetting.g_SoundSetting.enSoundAudioLan1 = LANGUAGE_ITALIAN;
            stGenSetting.g_SoundSetting.enSoundAudioLan2 = LANGUAGE_ENGLISH;
        }
        break;
        case OSD_COUNTRY_LUXEMBOURG:
         {
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage = LANGUAGE_GERMAN;
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage_2= LANGUAGE_FRENCH;
            stGenSetting.g_SoundSetting.enSoundAudioLan1 = LANGUAGE_GERMAN;
            stGenSetting.g_SoundSetting.enSoundAudioLan2 = LANGUAGE_FRENCH;
        }
        break;
        case OSD_COUNTRY_NETHERLANDS:
         {
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage = LANGUAGE_DUTCH;
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage_2= LANGUAGE_ENGLISH;
            stGenSetting.g_SoundSetting.enSoundAudioLan1 = LANGUAGE_DUTCH;
            stGenSetting.g_SoundSetting.enSoundAudioLan2 = LANGUAGE_ENGLISH;
        }
        break;
        case OSD_COUNTRY_NORWAY:
         {
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage = LANGUAGE_NORWEGIAN;
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage_2= LANGUAGE_ENGLISH;
            stGenSetting.g_SoundSetting.enSoundAudioLan1 = LANGUAGE_NORWEGIAN;
            stGenSetting.g_SoundSetting.enSoundAudioLan2 = LANGUAGE_ENGLISH;
        }
        break;
        case OSD_COUNTRY_POLAND:
         {
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage = LANGUAGE_POLISH;
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage_2= LANGUAGE_ENGLISH;
            stGenSetting.g_SoundSetting.enSoundAudioLan1 = LANGUAGE_POLISH;
            stGenSetting.g_SoundSetting.enSoundAudioLan2 = LANGUAGE_ENGLISH;
        }
        break;
        case OSD_COUNTRY_PORTUGAL:
         {
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage = LANGUAGE_PORTUGUESE;
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage_2= LANGUAGE_ENGLISH;
            stGenSetting.g_SoundSetting.enSoundAudioLan1 = LANGUAGE_PORTUGUESE;
            stGenSetting.g_SoundSetting.enSoundAudioLan2 = LANGUAGE_ENGLISH;
        }
        break;
        case OSD_COUNTRY_RUMANIA:
         {
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage = LANGUAGE_ROMANIAN;
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage_2= LANGUAGE_ENGLISH;
            stGenSetting.g_SoundSetting.enSoundAudioLan1 = LANGUAGE_ROMANIAN;
            stGenSetting.g_SoundSetting.enSoundAudioLan2 = LANGUAGE_ENGLISH;
        }
        break;
        case OSD_COUNTRY_RUSSIA:
         {
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage = LANGUAGE_RUSSIAN;
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage_2= LANGUAGE_ENGLISH;
            stGenSetting.g_SoundSetting.enSoundAudioLan1 = LANGUAGE_RUSSIAN;
            stGenSetting.g_SoundSetting.enSoundAudioLan2 = LANGUAGE_ENGLISH;
        }
        break;
        case OSD_COUNTRY_SERBIA:
         {
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage = LANGUAGE_SERBIAN;
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage_2= LANGUAGE_ENGLISH;
            stGenSetting.g_SoundSetting.enSoundAudioLan1 = LANGUAGE_SERBIAN;
            stGenSetting.g_SoundSetting.enSoundAudioLan2 = LANGUAGE_ENGLISH;
        }
        break;
        case OSD_COUNTRY_SLOVENIA:
         {
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage = LANGUAGE_SLOVENIAN;
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage_2= LANGUAGE_ENGLISH;
            stGenSetting.g_SoundSetting.enSoundAudioLan1 = LANGUAGE_SLOVENIAN;
            stGenSetting.g_SoundSetting.enSoundAudioLan2 = LANGUAGE_ENGLISH;
        }
        break;
        case OSD_COUNTRY_SPAIN:
         {
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage = LANGUAGE_SPANISH;
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage_2= LANGUAGE_ENGLISH;
            stGenSetting.g_SoundSetting.enSoundAudioLan1 = LANGUAGE_SPANISH;
            stGenSetting.g_SoundSetting.enSoundAudioLan2 = LANGUAGE_ENGLISH;
        }
        break;
        case OSD_COUNTRY_SWEDEN:
        {
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage = LANGUAGE_SWEDISH;
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage_2= LANGUAGE_ENGLISH;
            stGenSetting.g_SysSetting.fEnableSubTitle = TRUE;
            stGenSetting.g_SoundSetting.enSoundAudioLan1 = LANGUAGE_SWEDISH;
            stGenSetting.g_SoundSetting.enSoundAudioLan2 = LANGUAGE_ENGLISH;
        }
        break;
        case OSD_COUNTRY_SWITZERLAND:
        {
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage = LANGUAGE_FRENCH;
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage_2= LANGUAGE_GERMAN;
            stGenSetting.g_SoundSetting.enSoundAudioLan1 = LANGUAGE_FRENCH;
            stGenSetting.g_SoundSetting.enSoundAudioLan2 = LANGUAGE_GERMAN;
        }
        break;
        case OSD_COUNTRY_UK:
        {
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage = LANGUAGE_ENGLISH;
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage_2= LANGUAGE_ENGLISH;
            stGenSetting.g_SoundSetting.enSoundAudioLan1 = LANGUAGE_ENGLISH;
            stGenSetting.g_SoundSetting.enSoundAudioLan2 = LANGUAGE_ENGLISH;
        }
        break;
        case OSD_COUNTRY_NEWZEALAND:
        {
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage = LANGUAGE_ENGLISH;
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage_2= LANGUAGE_ENGLISH;
            stGenSetting.g_SoundSetting.enSoundAudioLan1 = LANGUAGE_ENGLISH;
            stGenSetting.g_SoundSetting.enSoundAudioLan2 = LANGUAGE_ENGLISH;
        }
        break;
        case OSD_COUNTRY_MOROCCO:
        {
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage = LANGUAGE_ARABIC;
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage_2= LANGUAGE_ARABIC;
            stGenSetting.g_SoundSetting.enSoundAudioLan1 = LANGUAGE_ARABIC;
            stGenSetting.g_SoundSetting.enSoundAudioLan2 = LANGUAGE_ARABIC;
        }
        break;
        case OSD_COUNTRY_TUNIS:
        {
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage = LANGUAGE_ARABIC;
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage_2= LANGUAGE_ARABIC;
            stGenSetting.g_SoundSetting.enSoundAudioLan1 = LANGUAGE_ARABIC;
            stGenSetting.g_SoundSetting.enSoundAudioLan2 = LANGUAGE_ARABIC;
        }
        break;
        case OSD_COUNTRY_ALGERIA:
        {
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage = LANGUAGE_ARABIC;
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage_2= LANGUAGE_ARABIC;
            stGenSetting.g_SoundSetting.enSoundAudioLan1 = LANGUAGE_ARABIC;
            stGenSetting.g_SoundSetting.enSoundAudioLan2 = LANGUAGE_ARABIC;
        }
        break;
        case OSD_COUNTRY_EGYPT:
        {
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage = LANGUAGE_ARABIC;
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage_2= LANGUAGE_ARABIC;
            stGenSetting.g_SoundSetting.enSoundAudioLan1 = LANGUAGE_ARABIC;
            stGenSetting.g_SoundSetting.enSoundAudioLan2 = LANGUAGE_ARABIC;
        }
        break;
        case OSD_COUNTRY_SOUTH_AFRICA:
        {
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage = LANGUAGE_ENGLISH;
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage_2= LANGUAGE_ENGLISH;
            stGenSetting.g_SoundSetting.enSoundAudioLan1 = LANGUAGE_ENGLISH;
            stGenSetting.g_SoundSetting.enSoundAudioLan2 = LANGUAGE_ENGLISH;
        }
        break;
        case OSD_COUNTRY_ISRAEL:
        {
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage = LANGUAGE_HEBREW;
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage_2= LANGUAGE_HEBREW;
            stGenSetting.g_SoundSetting.enSoundAudioLan1 = LANGUAGE_HEBREW;
            stGenSetting.g_SoundSetting.enSoundAudioLan2 = LANGUAGE_HEBREW;
        }
        break;
        case OSD_COUNTRY_IRAN:
        {
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage = LANGUAGE_PARSI;
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage_2= LANGUAGE_PARSI;
            stGenSetting.g_SoundSetting.enSoundAudioLan1 = LANGUAGE_PARSI;
            stGenSetting.g_SoundSetting.enSoundAudioLan2 = LANGUAGE_PARSI;
        }
        break;
        case OSD_COUNTRY_UNITED_ARAB_EMIRATES:
        {
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage = LANGUAGE_ARABIC;
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage_2= LANGUAGE_ARABIC;
            stGenSetting.g_SoundSetting.enSoundAudioLan1 = LANGUAGE_ARABIC;
            stGenSetting.g_SoundSetting.enSoundAudioLan2 = LANGUAGE_ARABIC;
        }
        break;
        case OSD_COUNTRY_SLOVAKIA:
        {
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage = LANGUAGE_SLOVAK;
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage_2= LANGUAGE_ENGLISH;
            stGenSetting.g_SoundSetting.enSoundAudioLan1 = LANGUAGE_SLOVAK;
            stGenSetting.g_SoundSetting.enSoundAudioLan2 = LANGUAGE_ENGLISH;
        }
        break;
        case OSD_COUNTRY_IRELAND:
        {
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage = LANGUAGE_ENGLISH;
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage_2= LANGUAGE_IRISH;
            stGenSetting.g_SoundSetting.enSoundAudioLan1 = LANGUAGE_ENGLISH;
            stGenSetting.g_SoundSetting.enSoundAudioLan2 = LANGUAGE_IRISH;
        }
        break;
        default:
        {
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage = LANGUAGE_ENGLISH;
            stGenSetting.g_SysSetting.SubtitleDefaultLanguage_2= LANGUAGE_ENGLISH;
            stGenSetting.g_SoundSetting.enSoundAudioLan1 = LANGUAGE_ENGLISH;
            stGenSetting.g_SoundSetting.enSoundAudioLan2 = LANGUAGE_ENGLISH;
        }
        break;

    }
}
//@@-- changed it for can not show the clock for some stream, should set time zone and clock for SI.
#if (ENABLE_SBTVD_BRAZIL_APP)
static void _MApp_SetOSDCountrySetting_SBTVD(EN_OSD_COUNTRY_SETTING eOSDCountrySetting, BOOLEAN bSave)
{
#if (ENABLE_DTV)
    if(bSave)
    {
        msAPI_CM_SetCountry((MEMBER_COUNTRY) eOSDCountrySetting);
        stGenSetting.g_Time.enTimeZone = MApp_GetTimeZoneBySITimeZone(msAPI_SI_GetTimeZoneByCountry(MApp_GetSICountry(OSD_COUNTRY_SETTING)));
    }
#endif

    m_eOSDCountrySetting = eOSDCountrySetting;
    fEnableLCN = FALSE;

#if ENABLE_DTV
    MApp_SI_SetTimeZone(MApp_GetSITimeZone(stGenSetting.g_Time.enTimeZone));
    MApp_SI_SetClockTimeZone(MApp_GetSIClockTimeZone(stGenSetting.g_Time.en_Clock_TimeZone));
#endif

#if defined(MIPS_CHAKRA) || defined(__AEONR2__)
    msAPI_AEON_Disable();
#else
    msAPI_BEON_Disable();
#endif

}
#else
static void _MApp_SetOSDCountrySetting(EN_OSD_COUNTRY_SETTING eOSDCountrySetting, BOOLEAN bSave)
{
    m_eOSDCountrySetting = eOSDCountrySetting;
    if(bSave)//
    {
        #if ENABLE_DTV
        msAPI_CM_SetCountry((MEMBER_COUNTRY) eOSDCountrySetting);
        stGenSetting.g_Time.enTimeZone = MApp_GetTimeZoneBySITimeZone(msAPI_SI_GetTimeZoneByCountry(MApp_GetSICountry(OSD_COUNTRY_SETTING)));
        #else
        stGenSetting.g_Time.enTimeZone = MApp_GetTimeZoneByCountry(OSD_COUNTRY_SETTING);
        #endif
        MApp_SetClockTimezoneByTimezone(stGenSetting.g_Time.enTimeZone);
        if( OSD_COUNTRY_SETTING == OSD_COUNTRY_FRANCE)
        {
             stGenSetting.stScanMenuSetting.u8LSystem=TRUE;
        }
        else
        {
             stGenSetting.stScanMenuSetting.u8LSystem=FALSE;
        }
        MApp_SetSubtAndAudioByCountry(eOSDCountrySetting);
  #if ENABLE_DTV
        if(IS_NORDIC_COUNTRY(OSD_COUNTRY_SETTING))
        {
            stGenSetting.g_SysSetting.fEnableSubTitle = 1;
            stGenSetting.g_SysSetting.fEnableTTXSubTitle = 1;
        }
        else
  #endif
        {
            stGenSetting.g_SysSetting.fEnableSubTitle = 0;
            stGenSetting.g_SysSetting.fEnableTTXSubTitle = 0;
        }
        MApp_SaveSysSetting();
        MApp_SaveSoundSetting();
        MApp_SaveTimeData();
    }
    #if ENABLE_TTX
    MApp_TTX_SetCountry((MEMBER_COUNTRY) eOSDCountrySetting);
    #endif
    #if ENABLE_DTV
    MApp_SI_SetTimeZone(MApp_GetSITimeZone(stGenSetting.g_Time.enTimeZone));
    MApp_SI_SetClockTimeZone(MApp_GetSIClockTimeZone(stGenSetting.g_Time.en_Clock_TimeZone));
    stGenSetting.g_Time.en_ClockMode = EN_ClockMode_Auto;
    #endif
  #if ENABLE_DTV
    if ( IS_COUNTRY_SUPPORT_LCN(OSD_COUNTRY_SETTING) )
    {
        fEnableLCN = TRUE;
    }
    else
  #endif
    {
        fEnableLCN = FALSE;
    }

  #if ENABLE_DTV
    if( OSD_COUNTRY_SETTING == OSD_COUNTRY_NORWAY)
    {
       // msAPI_DFT_SetBandwidth(stGenSetting.stScanMenuSetting.u8BandWidth);
    }
    //MApp_SI_ResetNetwork();
#endif
}
#endif

#if ENABLE_DTV
static EN_MENU_TIMEZONE MApp_GetTimeZoneBySITimeZone(EN_SI_TIMEZONE eTimeZone)
{
    switch(eTimeZone)
    {
        case SI_TIMEZONE_CANARY:    return TIMEZONE_CANARY;
        case SI_TIMEZONE_LISBON:    return TIMEZONE_LISBON;
        case SI_TIMEZONE_LONDON:    return TIMEZONE_LONDON;
        case SI_TIMEZONE_RABAT:     return TIMEZONE_RABAT;
        case SI_TIMEZONE_AMSTERDAM:    return TIMEZONE_AMSTERDAM;
        case SI_TIMEZONE_BEOGRAD:    return TIMEZONE_BEOGRAD;
        case SI_TIMEZONE_BERLIN:    return TIMEZONE_BERLIN;
        case SI_TIMEZONE_BRUSSELS:    return TIMEZONE_BRUSSELS;
        case SI_TIMEZONE_BUDAPEST:    return TIMEZONE_BUDAPEST;
        case SI_TIMEZONE_COPENHAGEN:    return TIMEZONE_COPENHAGEN;
        case SI_TIMEZONE_LIUBLJANA:    return TIMEZONE_LIUBLJANA;
        case SI_TIMEZONE_LUXEMBOURG:    return TIMEZONE_LUXEMBOURG;
        case SI_TIMEZONE_MADRID:    return TIMEZONE_MADRID;
        case SI_TIMEZONE_OSLO:    return TIMEZONE_OSLO;
        case SI_TIMEZONE_PARIS:    return TIMEZONE_PARIS;
        case SI_TIMEZONE_PRAGUE:    return TIMEZONE_PRAGUE;
        case SI_TIMEZONE_BRATISLAVA:return TIMEZONE_BRATISLAVA;
        case SI_TIMEZONE_BERN:       return TIMEZONE_BERN;
        case SI_TIMEZONE_ROME:    return TIMEZONE_ROME;
        case SI_TIMEZONE_STOCKHOLM:    return TIMEZONE_STOCKHOLM;
        case SI_TIMEZONE_WARSAW:    return TIMEZONE_WARSAW;
        case SI_TIMEZONE_VIENNA:    return TIMEZONE_VIENNA;
        case SI_TIMEZONE_ZAGREB:    return TIMEZONE_ZAGREB;
        case SI_TIMEZONE_TUNIS:    return TIMEZONE_TUNIS;
        case SI_TIMEZONE_ALGIERS:    return TIMEZONE_ALGIERS;
        case SI_TIMEZONE_ATHENS:    return TIMEZONE_ATHENS;
        case SI_TIMEZONE_BUCURESTI:    return TIMEZONE_BUCURESTI;
        case SI_TIMEZONE_HELSINKI:    return TIMEZONE_HELSINKI;
        case SI_TIMEZONE_SOFIA:    return TIMEZONE_SOFIA;
        case SI_TIMEZONE_CAIRO:    return TIMEZONE_CAIRO;
        case SI_TIMEZONE_CAPE_TOWN:    return TIMEZONE_CAPE_TOWN;
        case SI_TIMEZONE_ESTONIA:      return TIMEZONE_ESTONIA;
	 case SI_TIMEZONE_TURKEY:      return TIMEZONE_TURKEY;
        case SI_TIMEZONE_JERUSSLEM:    return TIMEZONE_JERUSSLEM;
        case SI_TIMEZONE_MOSCOW:    return TIMEZONE_MOSCOW;
        case SI_TIMEZONE_TEHERAN:    return TIMEZONE_TEHERAN;
        case SI_TIMEZONE_ABU_DHABI:    return TIMEZONE_ABU_DHABI;
        case SI_TIMEZONE_BEIJING:    return TIMEZONE_BEIJING;
        case SI_TIMEZONE_WA:    return TIMEZONE_WA;
        case SI_TIMEZONE_SA:    return TIMEZONE_SA;
        case SI_TIMEZONE_NT:    return TIMEZONE_NT;
        case SI_TIMEZONE_NSW:    return TIMEZONE_NSW;
        case SI_TIMEZONE_VIC:    return TIMEZONE_VIC;
        case SI_TIMEZONE_QLD:    return TIMEZONE_QLD;
        case SI_TIMEZONE_TAS:    return TIMEZONE_TAS;
        case SI_TIMEZONE_NZST:    return TIMEZONE_NZST;
#if ENABLE_SBTVD_BRAZIL_APP
        case SI_TIMEZONE_AM_WEST:    return TIMEZONE_AM_WEST;
        case SI_TIMEZONE_ACRE:    return TIMEZONE_ACRE;
        case SI_TIMEZONE_M_GROSSO:    return TIMEZONE_M_GROSSO;
        case SI_TIMEZONE_NORTH:    return TIMEZONE_NORTH;
        case SI_TIMEZONE_BRASILIA:    return TIMEZONE_BRASILIA;
        case SI_TIMEZONE_NORTHEAST:    return TIMEZONE_NORTHEAST;
        case SI_TIMEZONE_F_NORONHA:    return TIMEZONE_F_NORONHA;
#endif
        case SI_TIMEZONE_AZORES:    return TIMEZONE_AZORES;
        //case SI_TIMEZONE_DUBLIN:    return TIMEZONE_DUBLIN;
        case SI_TIMEZONE_NUM:    return TIMEZONE_NUM;
        default:
        ASSERT(0);
        return TIMEZONE_LONDON;
    }
}

#else
static EN_MENU_TIMEZONE MApp_GetTimeZoneByCountry(EN_OSD_COUNTRY_SETTING eCountry)
{
    U8 u8Loop;

    //printf("Total = %bu\n",sizeof(stTimeZone2Country)/sizeof(TimeZone2Country));
    for(u8Loop = 0; u8Loop < sizeof(stTimeZone2Country)/sizeof(TimeZone2Country); u8Loop++)
    {
        if(stTimeZone2Country[u8Loop].eCountry == eCountry)
            return stTimeZone2Country[u8Loop].eTimeZone;
    }
    return TIMEZONE_LONDON; // Unknow timezone, return UK.
}
#endif

#if ENABLE_DTV
EN_SI_COUNTRY_SETTING MApp_GetSICountry(EN_OSD_COUNTRY_SETTING eOSDCountrySetting)
{
    EN_SI_COUNTRY_SETTING eSICountry=SI_COUNTRY_UK;
    switch(eOSDCountrySetting)
    {
        case OSD_COUNTRY_AUSTRALIA:       eSICountry = SI_COUNTRY_AUSTRALIA; break;
        case OSD_COUNTRY_AUSTRIA:            eSICountry= SI_COUNTRY_AUSTRIA; break;
        case OSD_COUNTRY_BELGIUM:            eSICountry= SI_COUNTRY_BELGIUM; break;
        case OSD_COUNTRY_BULGARIA:        eSICountry= SI_COUNTRY_BULGARIA; break;
        case OSD_COUNTRY_CROATIA:            eSICountry= SI_COUNTRY_CROATIA; break;
        case OSD_COUNTRY_CZECH:            eSICountry= SI_COUNTRY_CZECH; break;
        case OSD_COUNTRY_DENMARK:            eSICountry= SI_COUNTRY_DENMARK; break;
        case OSD_COUNTRY_FINLAND:            eSICountry= SI_COUNTRY_FINLAND; break;
        case OSD_COUNTRY_FRANCE:            eSICountry= SI_COUNTRY_FRANCE; break;
        case OSD_COUNTRY_GERMANY:            eSICountry= SI_COUNTRY_GERMANY; break;
        case OSD_COUNTRY_GREECE:            eSICountry= SI_COUNTRY_GREECE; break;
        case OSD_COUNTRY_HUNGARY:            eSICountry= SI_COUNTRY_HUNGARY; break;
        case OSD_COUNTRY_ITALY:        eSICountry= SI_COUNTRY_ITALY; break;
	 case OSD_COUNTRY_IRELAND:			eSICountry= SI_COUNTRY_IRELAND; break;
        case OSD_COUNTRY_LUXEMBOURG:        eSICountry= SI_COUNTRY_LUXEMBOURG; break;
        case OSD_COUNTRY_NETHERLANDS:        eSICountry= SI_COUNTRY_NETHERLANDS; break;
        case OSD_COUNTRY_NORWAY:            eSICountry= SI_COUNTRY_NORWAY; break;
        case OSD_COUNTRY_POLAND:            eSICountry= SI_COUNTRY_POLAND; break;
        case OSD_COUNTRY_PORTUGAL:        eSICountry= SI_COUNTRY_PORTUGAL; break;
        case OSD_COUNTRY_RUMANIA:            eSICountry= SI_COUNTRY_RUMANIA; break;
        case OSD_COUNTRY_RUSSIA:            eSICountry= SI_COUNTRY_RUSSIA; break;
        case OSD_COUNTRY_SERBIA:            eSICountry= SI_COUNTRY_SERBIA; break;
        case OSD_COUNTRY_SLOVENIA:        eSICountry= SI_COUNTRY_SLOVENIA; break;
        case OSD_COUNTRY_SPAIN:            eSICountry= SI_COUNTRY_SPAIN; break;
        case OSD_COUNTRY_SWEDEN:            eSICountry= SI_COUNTRY_SWEDEN; break;
        case OSD_COUNTRY_SWITZERLAND:        eSICountry= SI_COUNTRY_SWITZERLAND; break;
        case OSD_COUNTRY_UK:             eSICountry = SI_COUNTRY_UK; break;
        case OSD_COUNTRY_NEWZEALAND:             eSICountry = SI_COUNTRY_NEWZEALAND; break;
        case OSD_COUNTRY_CHINA:           eSICountry= SI_COUNTRY_CHINA; break;
        case OSD_COUNTRY_MOROCCO:            eSICountry = SI_COUNTRY_MOROCCO; break;
        case OSD_COUNTRY_TUNIS:              eSICountry = SI_COUNTRY_TUNIS; break;
        case OSD_COUNTRY_ALGERIA:            eSICountry = SI_COUNTRY_ALGERIA; break;
        case OSD_COUNTRY_EGYPT:              eSICountry = SI_COUNTRY_EGYPT; break;
        case OSD_COUNTRY_SOUTH_AFRICA:       eSICountry = SI_COUNTRY_SOUTH_AFRICA; break;
        case OSD_COUNTRY_ISRAEL:             eSICountry = SI_COUNTRY_ISRAEL; break;
        case OSD_COUNTRY_IRAN:               eSICountry = SI_COUNTRY_IRAN; break;
        case OSD_COUNTRY_UNITED_ARAB_EMIRATES:   eSICountry = SI_COUNTRY_UNITED_ARAB_EMIRATES; break;
        case OSD_COUNTRY_SLOVAKIA:            	eSICountry= SI_COUNTRY_SLOVAKIA; 			break;
        #if (ENABLE_DVB_TAIWAN_APP)
        case OSD_COUNTRY_TAIWAN:          eSICountry= SI_COUNTRY_TAIWAN; break;
        #endif
        #if (ENABLE_SBTVD_BRAZIL_APP)
        case OSD_COUNTRY_BRAZIL:          eSICountry= SI_COUNTRY_BRAZIL; break;
        #endif
        case OSD_COUNTRY_ESTONIA:           eSICountry = SI_COUNTRY_ESTONIA; break;
	 case OSD_COUNTRY_TURKEY:           eSICountry = SI_COUNTRY_TURKEY; break;

        default:
        ASSERT(0);
        break;
    }
    return eSICountry;
}
#endif

void MApp_SetOSDCountrySetting(EN_OSD_COUNTRY_SETTING eOSDCountrySetting, BOOLEAN bSave)
{
  #if (ENABLE_SBTVD_BRAZIL_APP)
    _MApp_SetOSDCountrySetting_SBTVD(eOSDCountrySetting, bSave);
  #else
    _MApp_SetOSDCountrySetting(eOSDCountrySetting, bSave);
  #endif

  #if(ENABLE_DTV)
    MApp_SetSICountry(eOSDCountrySetting);
    #if (ENABLE_CI && ENABLE_CI_PLUS)
    {
        EN_SI_COUNTRY_SETTING eCountryCodeId;
        U8 u8aCountryCode[MAX_ISO639CODE_LENGTH] = { 0 };

        eCountryCodeId = MApp_GetSICountry(eOSDCountrySetting);
        if (TRUE == msAPI_SI_GetISO3166CountryCodeFromIndex(eCountryCodeId, u8aCountryCode))
        {
            msAPI_CI_HLC_SetCountry(u8aCountryCode);
	 }
    }
    #endif
  #endif
}

EN_LANGUAGE MApp_GetMenuLanguage(void)
{
    if (stGenSetting.g_SysSetting.Language > LANGUAGE_MENU_MAX)
    {
        MS_DEBUG_MSG(printf("Get Lang Overflow: %u\n", (U16)stGenSetting.g_SysSetting.Language));
        stGenSetting.g_SysSetting.Language = DEFAULT_MENU_LANG;
#if ( ENABLE_ARABIC_OSD || ENABLE_THAI_OSD )
		msAPI_OSD_SetOSDLanguage((EN_OSDAPI_LANGUAGE)DEFAULT_MENU_LANG);
#endif
    }

    return stGenSetting.g_SysSetting.Language;
}

EN_LANGUAGE MApp_GetMenuLanguage_DTG(void)
{
    if (stGenSetting.g_SysSetting.Language > LANGUAGE_MENU_MAX)
    {
        MS_DEBUG_MSG(printf("Get Lang Overflow: %u\n", (U16)stGenSetting.g_SysSetting.Language));
        stGenSetting.g_SysSetting.Language = DEFAULT_MENU_LANG;
#if ( ENABLE_ARABIC_OSD || ENABLE_THAI_OSD )
		msAPI_OSD_SetOSDLanguage((EN_OSDAPI_LANGUAGE)DEFAULT_MENU_LANG);
#endif
    }
    return stGenSetting.g_SysSetting.Language;
}

EN_MENU_TIMEZONE MApp_GetTimeZone_DTG(void)
{
    if (stGenSetting.g_Time.enTimeZone >= TIMEZONE_NUM)
    {
        MS_DEBUG_MSG(printf("Get Lang Overflow: %u\n", (U16)stGenSetting.g_Time.enTimeZone));
        #if  ENABLE_SBTVD_BRAZIL_APP
            stGenSetting.g_Time.enTimeZone = TIMEZONE_GMT_Minus3_START;
        #else
            stGenSetting.g_Time.enTimeZone = TIMEZONE_GMT_0_START;
        #endif
    }
    return stGenSetting.g_Time.enTimeZone;
}

EN_LANGUAGE MApp_GetAudioLangMenuLanguage_DTG(void)
{
    if(!stGenSetting.g_SoundSetting.Primary_Flag)
    {
        if(OSD_COUNTRY_SETTING == E_NEWZEALAND)
        {
            if (stGenSetting.g_SoundSetting.enSoundAudioLan1 > LANGUAGE_AUDIO_MAX_NZ)
            {
                MS_DEBUG_MSG(printf("Get Lang Overflow: %u\n", (U8)stGenSetting.g_SoundSetting.enSoundAudioLan1));
                stGenSetting.g_SoundSetting.enSoundAudioLan1 = DEFAULT_MENU_LANG;
            }
        }
        else
        {
            if (stGenSetting.g_SoundSetting.enSoundAudioLan1 > LANGUAGE_AUDIO_MAX_EU)
            {
                MS_DEBUG_MSG(printf("Get Lang Overflow: %u\n", (U8)stGenSetting.g_SoundSetting.enSoundAudioLan1));
                stGenSetting.g_SoundSetting.enSoundAudioLan1 = DEFAULT_MENU_LANG;
            }
        }
        return (EN_LANGUAGE)stGenSetting.g_SoundSetting.enSoundAudioLan1;
    }
    else
    {
        if(OSD_COUNTRY_SETTING == E_NEWZEALAND)
        {
            if (stGenSetting.g_SoundSetting.enSoundAudioLan2 > LANGUAGE_AUDIO_MAX_NZ)
            {
                MS_DEBUG_MSG(printf("Get Lang Overflow: %u\n", (U8)stGenSetting.g_SoundSetting.enSoundAudioLan2));
                stGenSetting.g_SoundSetting.enSoundAudioLan2 = DEFAULT_MENU_LANG;
            }
        }
        else
        {
            if (stGenSetting.g_SoundSetting.enSoundAudioLan2 > LANGUAGE_AUDIO_MAX_EU)
            {
                MS_DEBUG_MSG(printf("Get Lang Overflow: %u\n", (U8)stGenSetting.g_SoundSetting.enSoundAudioLan2));
                stGenSetting.g_SoundSetting.enSoundAudioLan2 = DEFAULT_MENU_LANG;
            }
        }
        return (EN_LANGUAGE)stGenSetting.g_SoundSetting.enSoundAudioLan2;
    }
}

EN_LANGUAGE MApp_GetSubLangMenuLanguage_DTG(void)
{
    if(!stGenSetting.g_SysSetting.fSUBLANG_FLAG)
    {
        if(OSD_COUNTRY_SETTING == E_NEWZEALAND)
        {
            if (stGenSetting.g_SysSetting.SubtitleDefaultLanguage > LANGUAGE_SUBTITLE_MAX_NZ)
            {
                MS_DEBUG_MSG(printf("Get Lang Overflow: %u\n", (U8)stGenSetting.g_SysSetting.SubtitleDefaultLanguage));
                stGenSetting.g_SysSetting.SubtitleDefaultLanguage = DEFAULT_SUB_LANG;
            }
        }
        else
        {
            if (stGenSetting.g_SysSetting.SubtitleDefaultLanguage > LANGUAGE_SUBTITLE_MAX_EU)
            {
                MS_DEBUG_MSG(printf("Get Lang Overflow: %u\n", (U8)stGenSetting.g_SysSetting.SubtitleDefaultLanguage));
                stGenSetting.g_SysSetting.SubtitleDefaultLanguage = DEFAULT_SUB_LANG;
            }
        }
        return stGenSetting.g_SysSetting.SubtitleDefaultLanguage;
    }
    else
    {
        if(OSD_COUNTRY_SETTING == E_NEWZEALAND)
        {
            if (stGenSetting.g_SysSetting.SubtitleDefaultLanguage_2 > LANGUAGE_SUBTITLE_MAX_NZ)
            {
                MS_DEBUG_MSG(printf("Get Lang Overflow: %u\n", (U8)stGenSetting.g_SysSetting.SubtitleDefaultLanguage_2));
                stGenSetting.g_SysSetting.SubtitleDefaultLanguage_2 = DEFAULT_SUB_LANG;
            }
        }
        else
        {
            if (stGenSetting.g_SysSetting.SubtitleDefaultLanguage_2 > LANGUAGE_SUBTITLE_MAX_EU)
            {
                MS_DEBUG_MSG(printf("Get Lang Overflow: %u\n", (U8)stGenSetting.g_SysSetting.SubtitleDefaultLanguage_2));
                stGenSetting.g_SysSetting.SubtitleDefaultLanguage_2 = DEFAULT_SUB_LANG;
            }
        }
        return stGenSetting.g_SysSetting.SubtitleDefaultLanguage_2;
    }
}


#if ENABLE_TTX // helen add for TTX
TT_Charset_Group MApp_GetTTXLang(void)
{
    return stGenSetting.g_SysSetting.TTX_Language ;
}

#endif


void MApp_SetMenuLanguage(EN_LANGUAGE eLanguage)
{
    if (eLanguage > LANGUAGE_MENU_MAX)
    {
        MS_DEBUG_MSG(printf("Set Lang Overflow: %u\n", (U16)eLanguage));
        eLanguage = DEFAULT_MENU_LANG;
    }

    stGenSetting.g_SysSetting.Language = eLanguage;

#if ( ENABLE_ARABIC_OSD || ENABLE_THAI_OSD )
  #if (ENABLE_ARABIC_TEST_UI)
    if ( eLanguage == LANGUAGE_SPANISH )
    {
        msAPI_OSD_SetOSDLanguage(LANGUAGE_OSD_ARABIC);
    }
    else
  #endif
    {
    	if(LANGUAGE_ARABIC == eLanguage)
        {
            msAPI_OSD_SetOSDLanguage(LANGUAGE_OSD_ARABIC);
        }
        else
        {
            msAPI_OSD_SetOSDLanguage((EN_OSDAPI_LANGUAGE)eLanguage);
        }
    }
#endif

  #if ENABLE_AUTOTEST
    if(g_bAutobuildDebug)
    {
        if(OSD_L != stGenSetting.g_SysSetting.Language)
        {
            printf("71_OSD_Change_Language\n");
        }
        OSD_L = stGenSetting.g_SysSetting.Language;
    }
  #endif

  #if ENABLE_DTV
    MApp_SetSILanguage(eLanguage);
    #if (ENABLE_CI && ENABLE_CI_PLUS)
    {
        EN_SI_LANGUAGE eLangCodeId;
        U8 u8aLangCode[MAX_ISO639CODE_LENGTH] = { 0 };

        eLangCodeId = MApp_GetSILanguage(eLanguage);
        if (TRUE == msAPI_SI_GetISOLangCodeFromIndex(eLangCodeId, u8aLangCode))
            msAPI_CI_HLC_SetLanguage(u8aLangCode);
    }
    #endif

    #if ENABLE_TTX
    MApp_TTX_NotifyPMTTTXInfoChanged();
    #endif
  #endif


#if ENABLE_CEC
    msAPI_SystemInfo_SetMenuLanguage(stGenSetting.g_SysSetting.Language);
#endif
}

void MApp_SetTimeZone(EN_MENU_TIMEZONE eTimezone)
{
#if ENABLE_SBTVD_BRAZIL_APP
    if (eTimezone > TIMEZONE_GMT_Minus2_END)
    {
        printf("Set Lang Overflow: %u\n", (U16)eTimezone);
        eTimezone = TIMEZONE_GMT_Minus3_START;
    }

    stGenSetting.g_Time.enTimeZone = eTimezone;
    if(MENU_TIMEZONE<=TIMEZONE_GMT_Minus5_END)
    {
        stGenSetting.g_Time.en_Clock_TimeZone=EN_Clock_TimeZone_20;
    }
    else if(MENU_TIMEZONE>=TIMEZONE_GMT_Minus4_START && MENU_TIMEZONE<=TIMEZONE_GMT_Minus4_END)
    {
        stGenSetting.g_Time.en_Clock_TimeZone=EN_Clock_TimeZone_22;
    }
    else if(MENU_TIMEZONE>=TIMEZONE_GMT_Minus3_START && MENU_TIMEZONE<=TIMEZONE_GMT_Minus3_END)
    {
        stGenSetting.g_Time.en_Clock_TimeZone=EN_Clock_TimeZone_24;
    }
    else if(MENU_TIMEZONE>=TIMEZONE_GMT_Minus2_START && MENU_TIMEZONE<=TIMEZONE_GMT_Minus2_END)
    {
        stGenSetting.g_Time.en_Clock_TimeZone=EN_Clock_TimeZone_26;
    }
    else
    {
        stGenSetting.g_Time.en_Clock_TimeZone=EN_Clock_TimeZone_24;
    }
#else
    if (eTimezone >= TIMEZONE_NUM)
    {
        MS_DEBUG_MSG(printf("Set Lang Overflow: %u\n", (U16)eTimezone));
        eTimezone = TIMEZONE_GMT_0_START;
    }
    stGenSetting.g_Time.enTimeZone = eTimezone;
    if((MENU_TIMEZONE<=TIMEZONE_GMT_0_END))
    {
        stGenSetting.g_Time.en_Clock_TimeZone=EN_Clock_TimeZone_24;
    }
    else if(MENU_TIMEZONE>=TIMEZONE_GMT_1_START && MENU_TIMEZONE<=TIMEZONE_GMT_1_END)
    {
        stGenSetting.g_Time.en_Clock_TimeZone=EN_Clock_TimeZone_26;
    }
    else if(MENU_TIMEZONE>=TIMEZONE_GMT_2_START && MENU_TIMEZONE<=TIMEZONE_GMT_2_END)
    {
        stGenSetting.g_Time.en_Clock_TimeZone=EN_Clock_TimeZone_28;
    }
    else if(MENU_TIMEZONE>=TIMEZONE_GMT_3_START && MENU_TIMEZONE<=TIMEZONE_GMT_3_END)
    {
        stGenSetting.g_Time.en_Clock_TimeZone=EN_Clock_TimeZone_30;
    }
    else if(MENU_TIMEZONE>=TIMEZONE_GMT_3Point5_START && MENU_TIMEZONE<=TIMEZONE_GMT_3Point5_END)
    {
        stGenSetting.g_Time.en_Clock_TimeZone=EN_Clock_TimeZone_31;
    }
    else if(MENU_TIMEZONE>=TIMEZONE_GMT_4_START && MENU_TIMEZONE<=TIMEZONE_GMT_4_END)
    {
        stGenSetting.g_Time.en_Clock_TimeZone=EN_Clock_TimeZone_32;
    }
    else if(MENU_TIMEZONE>=TIMEZONE_GMT_8_START && MENU_TIMEZONE<=TIMEZONE_GMT_8_END)
    {
        stGenSetting.g_Time.en_Clock_TimeZone=EN_Clock_TimeZone_40;
    }
    else if(MENU_TIMEZONE>=TIMEZONE_GMT_9Point5_START && MENU_TIMEZONE<=TIMEZONE_GMT_9Point5_END)
    {
        stGenSetting.g_Time.en_Clock_TimeZone=EN_Clock_TimeZone_43;
    }
    else if(MENU_TIMEZONE>=TIMEZONE_GMT_10_START && MENU_TIMEZONE<=TIMEZONE_GMT_10_END)
    {
        stGenSetting.g_Time.en_Clock_TimeZone=EN_Clock_TimeZone_44;
    }
    else if(MENU_TIMEZONE>=TIMEZONE_GMT_12_START && MENU_TIMEZONE<=TIMEZONE_GMT_12_END)
    {
        stGenSetting.g_Time.en_Clock_TimeZone=EN_Clock_TimeZone_48;
    }
	else if(MENU_TIMEZONE == TIMEZONE_AZORES)
	{
        stGenSetting.g_Time.en_Clock_TimeZone=EN_Clock_TimeZone_22;
	}
#endif
}

void MApp_SetAudioLangMenuLanguage(EN_LANGUAGE eLanguage)
{
    if(OSD_COUNTRY_SETTING == E_NEWZEALAND)
    {
        if (eLanguage > LANGUAGE_AUDIO_MAX_NZ)
        {
            MS_DEBUG_MSG(printf("Set Lang Overflow: %u\n", (U8)eLanguage));
            eLanguage = DEFAULT_MENU_LANG;
        }
    }
    else
    {
        if (eLanguage > LANGUAGE_AUDIO_MAX_EU)
        {
            MS_DEBUG_MSG(printf("Set Lang Overflow: %u\n", (U8)eLanguage));
            eLanguage = DEFAULT_MENU_LANG;
        }
    }
    if(!stGenSetting.g_SoundSetting.Primary_Flag)
    {
        stGenSetting.g_SoundSetting.enSoundAudioLan1 = eLanguage;
    }
    else
    {
        stGenSetting.g_SoundSetting.enSoundAudioLan2 = eLanguage;
    }
    #if ENABLE_AUTOTEST
    if(g_bAutobuildDebug)
    {
        if(Audio_L != stGenSetting.g_SoundSetting.enSoundAudioLan1)
        {
            printf("71_Audio_Change_Language\n");
        }
        Audio_L = stGenSetting.g_SoundSetting.enSoundAudioLan1;
    }
    #endif
}

void MApp_SetSubLangMenuLanguage(EN_LANGUAGE eLanguage)
{
    if(OSD_COUNTRY_SETTING == E_NEWZEALAND)
    {
        if (eLanguage > LANGUAGE_SUBTITLE_MAX_NZ)
        {
            MS_DEBUG_MSG(printf("Set Lang Overflow: %u\n", (U8)eLanguage));
            eLanguage = DEFAULT_MENU_LANG;
        }
    }
    else
    {
        if (eLanguage > LANGUAGE_SUBTITLE_MAX_EU)
        {
            MS_DEBUG_MSG(printf("Set Lang Overflow: %u\n", (U8)eLanguage));
            eLanguage = DEFAULT_MENU_LANG;
        }
    }
    if(!stGenSetting.g_SysSetting.fSUBLANG_FLAG)
    {
        stGenSetting.g_SysSetting.SubtitleDefaultLanguage = eLanguage;
    }
    else
    {
        stGenSetting.g_SysSetting.SubtitleDefaultLanguage_2 = eLanguage;
    }
    #if ENABLE_AUTOTEST
    if(g_bAutobuildDebug)
    {
        if(Audio_L != stGenSetting.g_SoundSetting.enSoundAudioLan1)
        {
            printf("71_Subtitle_Change_Language\n");
        }
        Audio_L = stGenSetting.g_SoundSetting.enSoundAudioLan1;
    }
    #endif
}
#if ENABLE_TTX // helen add for TTX
void MApp_SetTTXLang(TT_Charset_Group eLanguage)
{
    stGenSetting.g_SysSetting.TTX_Language = eLanguage;
	msAPI_TTX_SetLanguageGroup(stGenSetting.g_SysSetting.TTX_Language);
}

#endif


BOOLEAN MApp_CmpMenuLanguage(EN_LANGUAGE eLanguage)
{
#if 1 // (MS_BOARD_TYPE_SEL == BD_P_001A)
    U8 u8UnSelect = FALSE;
    switch (eLanguage)
    {
        //case LANGUAGE_CZECH:
        //case LANGUAGE_DANISH:
        //case LANGUAGE_GERMAN:
        //case LANGUAGE_ENGLISH:
        //case LANGUAGE_SPANISH:
        //case LANGUAGE_GREEK:
        //case LANGUAGE_FRENCH:
        //case LANGUAGE_CROATIAN:
        //case LANGUAGE_ITALIAN:
        //case LANGUAGE_HUNGARIAN:
        //case LANGUAGE_DUTCH:
        //case LANGUAGE_NORWEGIAN:
        //case LANGUAGE_POLISH:
        //case LANGUAGE_PORTUGUESE:
        //case LANGUAGE_RUSSIAN:
        //case LANGUAGE_ROMANIAN:
        case LANGUAGE_SLOVENIAN:
        //case LANGUAGE_SERBIAN:
        //case LANGUAGE_FINNISH:
        //case LANGUAGE_SWEDISH:
        //case LANGUAGE_BULGARIAN:
    #if (!OBA2)
		#if (ENABLE_DTMB_CHINA_APP || ENABLE_ATV_CHINA_APP || ENABLE_DVBC_PLUS_DTMB_CHINA_APP||CHINESE_SIMP_FONT_ENABLE ||CHINESE_BIG5_FONT_ENABLE)
        case LANGUAGE_CHINESE:
		#endif
    #endif
        case LANGUAGE_GAELIC:
        case LANGUAGE_WELSH:
            u8UnSelect = TRUE;
        default:
            break;
    }
    return u8UnSelect;
#else
    eLanguage = eLanguage;
    return FALSE;
#endif
}

void MApp_SetOnTimer(MENU_OnTimer eOnTimerDate)
{
    msAPI_Power_SetOnTimer(eOnTimerDate);
}

MENU_OnTimer MApp_GetOnTimer(void)
{
    return msAPI_Power_GetOnTimer();
}

void MApp_SetDayOfWeek(DAYOFWEEK eDayOfWeek)
{
    msAPI_Power_SetDayOfWeek(eDayOfWeek);
}

/*/ZUI: unused:
U8 MApp_ASCII2INT(U8 buf)
{

    U8 value;

    if((buf>=0x30) && (buf <=0x39 )) // 0~9
    {
        value=buf-0x30;
    }
    else if((buf >=0x41) && (buf <=0x46))    // A~F
    {
        value=buf-0x37;
    }
    else if((buf >=0x61) && (buf <=0x66))    // a~f
    {
        value=buf-0x57;
    }
    else
        value=0x00;

    return value;
}
*/

void MApp_AddDay2StTime ( U16 u16DaysToAdd, ST_TIME *pstTime )
{
    U16 u16DaysInYear;
    U16 u16Days;

    //Year
    u16Days = MApp_GetDaysOfThisYear(pstTime->u16Year);
    u16DaysInYear = SolarDays[MApp_GetLeap( pstTime->u16Year ) * 14 + pstTime->u8Month - 1]+ pstTime->u8Day;

    if(u16DaysToAdd > (u16Days - u16DaysInYear))  //leap year
    {
        u16DaysToAdd -= (u16Days - u16DaysInYear + 1);
        pstTime->u16Year++;

        //Advancing Year
        while(u16DaysToAdd > (u16Days = MApp_GetDaysOfThisYear(pstTime->u16Year)))
        {
            u16DaysToAdd -= u16Days;
            pstTime->u16Year++;
        }
    }
    else
    {
        u16DaysToAdd += u16DaysInYear - 1;
    }

    pstTime->u8Month = 1;
    pstTime->u8Day= 1;

    //Advancing Month
    while(u16DaysToAdd > (u16Days = MApp_GetDaysOfThisMonth(pstTime->u16Year, pstTime->u8Month)))
    {
        u16DaysToAdd -= u16Days;
        pstTime->u8Month++;
    }
    pstTime->u8Day += u16DaysToAdd;
}

#if ENABLE_DTV
BOOLEAN MApp_UiMenuFunc_IsSystemClockSet(void)
{
    return ((g_u8TimeInfo_Flag & UI_TIME_MINUTE_SET) || MApp_SI_IsAutoClockValid());
}

static void MApp_SetSICountry(EN_OSD_COUNTRY_SETTING eOSDCountrySetting)
{
    EN_SI_COUNTRY_SETTING eSICountry = SI_COUNTRY_UK;
    switch(eOSDCountrySetting)
    {
        case OSD_COUNTRY_AUSTRALIA:         eSICountry = SI_COUNTRY_AUSTRALIA; break;
        case OSD_COUNTRY_AUSTRIA:           eSICountry = SI_COUNTRY_AUSTRIA; break;
        case OSD_COUNTRY_BELGIUM:           eSICountry = SI_COUNTRY_BELGIUM; break;
        case OSD_COUNTRY_BULGARIA:          eSICountry = SI_COUNTRY_BULGARIA; break;
        case OSD_COUNTRY_CROATIA:           eSICountry = SI_COUNTRY_CROATIA; break;
        case OSD_COUNTRY_CZECH:             eSICountry = SI_COUNTRY_CZECH; break;
        case OSD_COUNTRY_DENMARK:           eSICountry = SI_COUNTRY_DENMARK; break;
        case OSD_COUNTRY_FINLAND:           eSICountry = SI_COUNTRY_FINLAND; break;
        case OSD_COUNTRY_FRANCE:            eSICountry = SI_COUNTRY_FRANCE; break;
        case OSD_COUNTRY_GERMANY:           eSICountry = SI_COUNTRY_GERMANY; break;
        case OSD_COUNTRY_GREECE:            eSICountry = SI_COUNTRY_GREECE; break;
        case OSD_COUNTRY_HUNGARY:            eSICountry = SI_COUNTRY_HUNGARY; break;
        case OSD_COUNTRY_ITALY:             eSICountry = SI_COUNTRY_ITALY; break;
		case OSD_COUNTRY_IRELAND:			eSICountry = SI_COUNTRY_IRELAND; break;
        case OSD_COUNTRY_LUXEMBOURG:        eSICountry = SI_COUNTRY_LUXEMBOURG; break;
        case OSD_COUNTRY_NETHERLANDS:       eSICountry = SI_COUNTRY_NETHERLANDS; break;
        case OSD_COUNTRY_NORWAY:            eSICountry = SI_COUNTRY_NORWAY; break;
        case OSD_COUNTRY_POLAND:            eSICountry = SI_COUNTRY_POLAND; break;
        case OSD_COUNTRY_PORTUGAL:          eSICountry = SI_COUNTRY_PORTUGAL; break;
        case OSD_COUNTRY_RUMANIA:           eSICountry = SI_COUNTRY_RUMANIA; break;
        case OSD_COUNTRY_RUSSIA:           eSICountry = SI_COUNTRY_RUSSIA; break;
        case OSD_COUNTRY_SERBIA:            eSICountry = SI_COUNTRY_SERBIA; break;
        case OSD_COUNTRY_SLOVENIA:          eSICountry = SI_COUNTRY_SLOVENIA; break;
        case OSD_COUNTRY_SPAIN:             eSICountry = SI_COUNTRY_SPAIN; break;
        case OSD_COUNTRY_SWEDEN:            eSICountry = SI_COUNTRY_SWEDEN; break;
        case OSD_COUNTRY_SWITZERLAND:       eSICountry = SI_COUNTRY_SWITZERLAND; break;
        case OSD_COUNTRY_UK:                eSICountry = SI_COUNTRY_UK; break;
        case OSD_COUNTRY_NEWZEALAND:        eSICountry = SI_COUNTRY_NEWZEALAND; break;
        case OSD_COUNTRY_CHINA:             eSICountry = SI_COUNTRY_CHINA; break;
        case OSD_COUNTRY_MOROCCO:            eSICountry = SI_COUNTRY_MOROCCO; break;
        case OSD_COUNTRY_TUNIS:              eSICountry = SI_COUNTRY_TUNIS; break;
        case OSD_COUNTRY_ALGERIA:            eSICountry = SI_COUNTRY_ALGERIA; break;
        case OSD_COUNTRY_EGYPT:              eSICountry = SI_COUNTRY_EGYPT; break;
        case OSD_COUNTRY_SOUTH_AFRICA:       eSICountry = SI_COUNTRY_SOUTH_AFRICA; break;
        case OSD_COUNTRY_ISRAEL:             eSICountry = SI_COUNTRY_ISRAEL; break;
        case OSD_COUNTRY_IRAN:               eSICountry = SI_COUNTRY_IRAN; break;
        case OSD_COUNTRY_UNITED_ARAB_EMIRATES:   eSICountry = SI_COUNTRY_UNITED_ARAB_EMIRATES; break;
        case OSD_COUNTRY_SLOVAKIA:   			eSICountry = SI_COUNTRY_SLOVAKIA; 				break;
      #if (ENABLE_DVB_TAIWAN_APP)
        case OSD_COUNTRY_TAIWAN:            eSICountry = SI_COUNTRY_TAIWAN; break;
      #endif
      #if (ENABLE_SBTVD_BRAZIL_APP)
        case OSD_COUNTRY_BRAZIL:            eSICountry = SI_COUNTRY_BRAZIL; break;
      #endif
        case OSD_COUNTRY_ESTONIA:           eSICountry = SI_COUNTRY_ESTONIA; break;
	 case OSD_COUNTRY_TURKEY:           eSICountry = SI_COUNTRY_TURKEY; break;

        default:
            ASSERT(0);
        break;
    }

    MApp_SI_SetDefaultCountry(eSICountry);
}



static void MApp_SetSILanguage(EN_LANGUAGE eLanguage)
{
    EN_SI_LANGUAGE eSILanguage = SI_LANGUAGE_ENGLISH;
    switch(eLanguage)
    {
        case LANGUAGE_CZECH:                eSILanguage = SI_LANGUAGE_CZECH; break;
        case LANGUAGE_DANISH:               eSILanguage = SI_LANGUAGE_DANISH; break;
        case LANGUAGE_GERMAN:               eSILanguage = SI_LANGUAGE_GERMAN; break;
        case LANGUAGE_ENGLISH:              eSILanguage = SI_LANGUAGE_ENGLISH; break;
        case LANGUAGE_SPANISH:              eSILanguage = SI_LANGUAGE_SPANISH; break;
        case LANGUAGE_GREEK:                eSILanguage = SI_LANGUAGE_GREEK; break;
        case LANGUAGE_FRENCH:               eSILanguage = SI_LANGUAGE_FRENCH; break;
        case LANGUAGE_CROATIAN:             eSILanguage = SI_LANGUAGE_CROATIAN; break;
        case LANGUAGE_ITALIAN:              eSILanguage = SI_LANGUAGE_ITALIAN; break;
        case LANGUAGE_HUNGARIAN:            eSILanguage = SI_LANGUAGE_HUNGARIAN; break;
        case LANGUAGE_DUTCH:                eSILanguage = SI_LANGUAGE_DUTCH; break;
        case LANGUAGE_NORWEGIAN:            eSILanguage = SI_LANGUAGE_NORWEGIAN; break;
        case LANGUAGE_POLISH:               eSILanguage = SI_LANGUAGE_POLISH; break;
        case LANGUAGE_PORTUGUESE:           eSILanguage = SI_LANGUAGE_PORTUGUESE; break;
        case LANGUAGE_RUSSIAN:              eSILanguage = SI_LANGUAGE_RUSSIAN; break;
        case LANGUAGE_ROMANIAN:             eSILanguage = SI_LANGUAGE_ROMANIAN; break;
        case LANGUAGE_SLOVENIAN:            eSILanguage = SI_LANGUAGE_SLOVENIAN; break;
        case LANGUAGE_SERBIAN:              eSILanguage = SI_LANGUAGE_SERBIAN; break;
        case LANGUAGE_FINNISH:              eSILanguage = SI_LANGUAGE_FINNISH; break;
        case LANGUAGE_SWEDISH:              eSILanguage = SI_LANGUAGE_SWEDISH; break;
        case LANGUAGE_BULGARIAN:            eSILanguage = SI_LANGUAGE_BULGARIAN; break;
        case LANGUAGE_SLOVAK:               eSILanguage = SI_LANGUAGE_SLOVAK; break;
#if (ENABLE_DTMB_CHINA_APP || ENABLE_ATV_CHINA_APP || ENABLE_DVBC_PLUS_DTMB_CHINA_APP||CHINESE_SIMP_FONT_ENABLE ||CHINESE_BIG5_FONT_ENABLE)
        case LANGUAGE_CHINESE:              eSILanguage = SI_LANGUAGE_CHINESE; break;
#endif
        case LANGUAGE_GAELIC:               eSILanguage = SI_LANGUAGE_GAELIC; break;
        case LANGUAGE_WELSH:                eSILanguage = SI_LANGUAGE_WELSH; break;
        case LANGUAGE_IRISH:                eSILanguage = SI_LANGUAGE_IRISH; break;
        case LANGUAGE_TURKISH:              eSILanguage = SI_LANGUAGE_TURKISH; break;
        case LANGUAGE_NETHERLANDS:          eSILanguage = SI_LANGUAGE_NETHERLANDS; break;
        case LANGUAGE_ARABIC:               eSILanguage = SI_LANGUAGE_ARABIC; break;
        case LANGUAGE_HEBREW:               eSILanguage = SI_LANGUAGE_HEBREW; break;
        case LANGUAGE_KOREAN:               eSILanguage = SI_LANGUAGE_KOREAN; break;
        case LANGUAGE_JAPAN:                eSILanguage = SI_LANGUAGE_JAPAN; break;
        case LANGUAGE_HINDI:                eSILanguage = SI_LANGUAGE_HINDI; break;
        case LANGUAGE_MANDARIN:             eSILanguage = SI_LANGUAGE_MANDARIN; break;
        case LANGUAGE_CANTONESE:            eSILanguage = SI_LANGUAGE_CANTONESE; break;
        case LANGUAGE_MAORI:                eSILanguage = SI_LANGUAGE_MAORI; break;

        default:
            ASSERT(0);
        break;
    }

    MApp_SI_SetDefaultLanguage(eSILanguage);
}

EN_SI_TIMEZONE MApp_GetSITimeZone(EN_MENU_TIMEZONE eTimeZone)
{
    switch(eTimeZone)
    {
        case TIMEZONE_CANARY:               return SI_TIMEZONE_CANARY;
        case TIMEZONE_LISBON:               return SI_TIMEZONE_LISBON;
        case TIMEZONE_LONDON:               return SI_TIMEZONE_LONDON;
        case TIMEZONE_RABAT:                return SI_TIMEZONE_RABAT;
        case TIMEZONE_AMSTERDAM:            return SI_TIMEZONE_AMSTERDAM;
        case TIMEZONE_BEOGRAD:              return SI_TIMEZONE_BEOGRAD;
        case TIMEZONE_BERLIN:               return SI_TIMEZONE_BERLIN;
        case TIMEZONE_BRUSSELS:             return SI_TIMEZONE_BRUSSELS;
        case TIMEZONE_BUDAPEST:             return SI_TIMEZONE_BUDAPEST;
        case TIMEZONE_COPENHAGEN:           return SI_TIMEZONE_COPENHAGEN;
        case TIMEZONE_LIUBLJANA:            return SI_TIMEZONE_LIUBLJANA;
        case TIMEZONE_LUXEMBOURG:           return SI_TIMEZONE_LUXEMBOURG;
        case TIMEZONE_MADRID:               return SI_TIMEZONE_MADRID;
        case TIMEZONE_OSLO:                 return SI_TIMEZONE_OSLO;
        case TIMEZONE_PARIS:                return SI_TIMEZONE_PARIS;
        case TIMEZONE_PRAGUE:               return SI_TIMEZONE_PRAGUE;
        case TIMEZONE_BRATISLAVA:           return SI_TIMEZONE_BRATISLAVA;
        case TIMEZONE_BERN:                 return SI_TIMEZONE_BERN;
        case TIMEZONE_ROME:                 return SI_TIMEZONE_ROME;
        case TIMEZONE_STOCKHOLM:            return SI_TIMEZONE_STOCKHOLM;
        case TIMEZONE_WARSAW:               return SI_TIMEZONE_WARSAW;
        case TIMEZONE_VIENNA:               return SI_TIMEZONE_VIENNA;
        case TIMEZONE_ZAGREB:               return SI_TIMEZONE_ZAGREB;
        case TIMEZONE_TUNIS:                return SI_TIMEZONE_TUNIS;
        case TIMEZONE_ALGIERS:              return SI_TIMEZONE_ALGIERS;
        case TIMEZONE_ATHENS:               return SI_TIMEZONE_ATHENS;
        case TIMEZONE_BUCURESTI:            return SI_TIMEZONE_BUCURESTI;
        case TIMEZONE_HELSINKI:             return SI_TIMEZONE_HELSINKI;
        case TIMEZONE_SOFIA:                return SI_TIMEZONE_SOFIA;
        case TIMEZONE_CAIRO:                return SI_TIMEZONE_CAIRO;
        case TIMEZONE_CAPE_TOWN:            return SI_TIMEZONE_CAPE_TOWN;
        case TIMEZONE_ESTONIA:              return SI_TIMEZONE_ESTONIA;
	 case TIMEZONE_TURKEY:              return SI_TIMEZONE_TURKEY;
        case TIMEZONE_JERUSSLEM:            return SI_TIMEZONE_JERUSSLEM;
        case TIMEZONE_MOSCOW:               return SI_TIMEZONE_MOSCOW;
        case TIMEZONE_TEHERAN:              return SI_TIMEZONE_TEHERAN;
        case TIMEZONE_ABU_DHABI:            return SI_TIMEZONE_ABU_DHABI;
        case TIMEZONE_BEIJING:              return SI_TIMEZONE_BEIJING;
        case TIMEZONE_WA:                   return SI_TIMEZONE_WA;
        case TIMEZONE_SA:                   return SI_TIMEZONE_SA;
        case TIMEZONE_NT:                   return SI_TIMEZONE_NT;
        case TIMEZONE_NSW:                  return SI_TIMEZONE_NSW;
        case TIMEZONE_VIC:                  return SI_TIMEZONE_VIC;
        case TIMEZONE_QLD:                  return SI_TIMEZONE_QLD;
        case TIMEZONE_TAS:                  return SI_TIMEZONE_TAS;
        case TIMEZONE_NZST:                 return SI_TIMEZONE_NZST;

      #if ENABLE_SBTVD_BRAZIL_APP
        case TIMEZONE_AM_WEST:              return SI_TIMEZONE_AM_WEST;
        case TIMEZONE_ACRE:                 return SI_TIMEZONE_ACRE;
        case TIMEZONE_M_GROSSO:             return SI_TIMEZONE_M_GROSSO;
        case TIMEZONE_NORTH:                return SI_TIMEZONE_NORTH;
        case TIMEZONE_BRASILIA:             return SI_TIMEZONE_BRASILIA;
        case TIMEZONE_NORTHEAST:            return SI_TIMEZONE_NORTHEAST;
        case TIMEZONE_F_NORONHA:            return SI_TIMEZONE_F_NORONHA;
      #endif
	    case TIMEZONE_AZORES: 		   		return SI_TIMEZONE_AZORES;
        //case TIMEZONE_DUBLIN:            	return SI_TIMEZONE_DUBLIN;
        case TIMEZONE_NUM:                  return SI_TIMEZONE_NUM;

        default:
            ASSERT(0);
        return SI_TIMEZONE_LONDON;
    }
}

EN_SI_Clock_TimeZone MApp_GetSIClockTimeZone(EN_MENU_Clock_TimeZone eClockTimeZone)
{
    switch(eClockTimeZone)
    {
        case EN_Clock_TimeZone_0:           return EN_SI_Clock_TimeZone_0;
        case EN_Clock_TimeZone_1:           return EN_SI_Clock_TimeZone_1;
        case EN_Clock_TimeZone_2:           return EN_SI_Clock_TimeZone_2;
        case EN_Clock_TimeZone_3:           return EN_SI_Clock_TimeZone_3;
        case EN_Clock_TimeZone_4:           return EN_SI_Clock_TimeZone_4;
        case EN_Clock_TimeZone_5:           return EN_SI_Clock_TimeZone_5;
        case EN_Clock_TimeZone_6:           return EN_SI_Clock_TimeZone_6;
        case EN_Clock_TimeZone_7:           return EN_SI_Clock_TimeZone_7;
        case EN_Clock_TimeZone_8:           return EN_SI_Clock_TimeZone_8;
        case EN_Clock_TimeZone_9:           return EN_SI_Clock_TimeZone_9;
        case EN_Clock_TimeZone_10:          return EN_SI_Clock_TimeZone_10;
        case EN_Clock_TimeZone_11:          return EN_SI_Clock_TimeZone_11;
        case EN_Clock_TimeZone_12:          return EN_SI_Clock_TimeZone_12;
        case EN_Clock_TimeZone_13:          return EN_SI_Clock_TimeZone_13;
        case EN_Clock_TimeZone_14:          return EN_SI_Clock_TimeZone_14;
        case EN_Clock_TimeZone_15:          return EN_SI_Clock_TimeZone_15;
        case EN_Clock_TimeZone_16:          return EN_SI_Clock_TimeZone_16;
        case EN_Clock_TimeZone_17:          return EN_SI_Clock_TimeZone_17;
        case EN_Clock_TimeZone_18:          return EN_SI_Clock_TimeZone_18;
        case EN_Clock_TimeZone_19:          return EN_SI_Clock_TimeZone_19;
        case EN_Clock_TimeZone_20:          return EN_SI_Clock_TimeZone_20;
        case EN_Clock_TimeZone_21:          return EN_SI_Clock_TimeZone_21;
        case EN_Clock_TimeZone_22:          return EN_SI_Clock_TimeZone_22;
        case EN_Clock_TimeZone_23:          return EN_SI_Clock_TimeZone_23;
        case EN_Clock_TimeZone_24:          return EN_SI_Clock_TimeZone_24;
        case EN_Clock_TimeZone_25:          return EN_SI_Clock_TimeZone_25;
        case EN_Clock_TimeZone_26:          return EN_SI_Clock_TimeZone_26;
        case EN_Clock_TimeZone_27:          return EN_SI_Clock_TimeZone_27;
        case EN_Clock_TimeZone_28:          return EN_SI_Clock_TimeZone_28;
        case EN_Clock_TimeZone_29:          return EN_SI_Clock_TimeZone_29;
        case EN_Clock_TimeZone_30:          return EN_SI_Clock_TimeZone_30;
        case EN_Clock_TimeZone_31:          return EN_SI_Clock_TimeZone_31;
        case EN_Clock_TimeZone_32:          return EN_SI_Clock_TimeZone_32;
        case EN_Clock_TimeZone_33:          return EN_SI_Clock_TimeZone_33;
        case EN_Clock_TimeZone_34:          return EN_SI_Clock_TimeZone_34;
        case EN_Clock_TimeZone_35:          return EN_SI_Clock_TimeZone_35;
        case EN_Clock_TimeZone_36:          return EN_SI_Clock_TimeZone_36;
        case EN_Clock_TimeZone_37:          return EN_SI_Clock_TimeZone_37;
        case EN_Clock_TimeZone_38:          return EN_SI_Clock_TimeZone_38;
        case EN_Clock_TimeZone_39:          return EN_SI_Clock_TimeZone_39;
        case EN_Clock_TimeZone_40:          return EN_SI_Clock_TimeZone_40;
        case EN_Clock_TimeZone_41:          return EN_SI_Clock_TimeZone_41;
        case EN_Clock_TimeZone_42:          return EN_SI_Clock_TimeZone_42;
        case EN_Clock_TimeZone_43:          return EN_SI_Clock_TimeZone_43;
        case EN_Clock_TimeZone_44:          return EN_SI_Clock_TimeZone_44;
        case EN_Clock_TimeZone_45:          return EN_SI_Clock_TimeZone_45;
        case EN_Clock_TimeZone_46:          return EN_SI_Clock_TimeZone_46;
        case EN_Clock_TimeZone_47:          return EN_SI_Clock_TimeZone_47;
        case EN_Clock_TimeZone_48:          return EN_SI_Clock_TimeZone_48;
        case EN_Clock_TimeZone_Num:         return EN_SI_Clock_TimeZone_Num;

        default:
            ASSERT(0);
        return EN_SI_Clock_TimeZone_24;
    }
}



EN_SI_LANGUAGE MApp_GetSILanguage(EN_LANGUAGE eLanguage)
{
    switch(eLanguage)
    {
        case LANGUAGE_CZECH:                return SI_LANGUAGE_CZECH;
        case LANGUAGE_DANISH:               return SI_LANGUAGE_DANISH;
        case LANGUAGE_GERMAN:               return SI_LANGUAGE_GERMAN;
        case LANGUAGE_ENGLISH:              return SI_LANGUAGE_ENGLISH;
        case LANGUAGE_SPANISH:              return SI_LANGUAGE_SPANISH;
        case LANGUAGE_GREEK:                return SI_LANGUAGE_GREEK;
        case LANGUAGE_FRENCH:               return SI_LANGUAGE_FRENCH;
        case LANGUAGE_CROATIAN:             return SI_LANGUAGE_CROATIAN;
        case LANGUAGE_ITALIAN:              return SI_LANGUAGE_ITALIAN;
        case LANGUAGE_HUNGARIAN:            return SI_LANGUAGE_HUNGARIAN;
        case LANGUAGE_DUTCH:                return SI_LANGUAGE_DUTCH;
        case LANGUAGE_NORWEGIAN:            return SI_LANGUAGE_NORWEGIAN;
        case LANGUAGE_POLISH:               return SI_LANGUAGE_POLISH;
        case LANGUAGE_PORTUGUESE:           return SI_LANGUAGE_PORTUGUESE;
        case LANGUAGE_RUSSIAN:              return SI_LANGUAGE_RUSSIAN;
        case LANGUAGE_ROMANIAN:             return SI_LANGUAGE_ROMANIAN;
        case LANGUAGE_SLOVENIAN:            return SI_LANGUAGE_SLOVENIAN;
        case LANGUAGE_SERBIAN:              return SI_LANGUAGE_SERBIAN;
        case LANGUAGE_FINNISH:              return SI_LANGUAGE_FINNISH;
        case LANGUAGE_SWEDISH:              return SI_LANGUAGE_SWEDISH;
        case LANGUAGE_BULGARIAN:            return SI_LANGUAGE_BULGARIAN;
        case LANGUAGE_SLOVAK:               return SI_LANGUAGE_SLOVAK;
#if (ENABLE_DTMB_CHINA_APP || ENABLE_ATV_CHINA_APP || ENABLE_DVBC_PLUS_DTMB_CHINA_APP||CHINESE_SIMP_FONT_ENABLE ||CHINESE_BIG5_FONT_ENABLE)
        case LANGUAGE_CHINESE:              return SI_LANGUAGE_CHINESE;
#endif
        case LANGUAGE_GAELIC:               return SI_LANGUAGE_GAELIC;
        case LANGUAGE_WELSH:                return SI_LANGUAGE_WELSH;
        case LANGUAGE_IRISH:                return SI_LANGUAGE_IRISH;
        case LANGUAGE_TURKISH:              return SI_LANGUAGE_TURKISH;
        case LANGUAGE_NETHERLANDS:          return SI_LANGUAGE_NETHERLANDS;
        case LANGUAGE_ARABIC:               return SI_LANGUAGE_ARABIC;
        case LANGUAGE_HEBREW:               return SI_LANGUAGE_HEBREW;
        case LANGUAGE_KOREAN:               return SI_LANGUAGE_KOREAN;
        case LANGUAGE_JAPAN:                return SI_LANGUAGE_JAPAN;
        case LANGUAGE_HINDI:                return SI_LANGUAGE_HINDI;
        case LANGUAGE_MANDARIN:             return SI_LANGUAGE_MANDARIN;
        case LANGUAGE_CANTONESE:            return SI_LANGUAGE_CANTONESE;
        case LANGUAGE_MAORI:                return SI_LANGUAGE_MAORI;
        case LANGUAGE_UND:                  return SI_LANGUAGE_UND;
        case LANGUAGE_QAA:                  return SI_LANGUAGE_QAA;
        case LANGUAGE_UNKNOWN:              return SI_LANGUAGE_UNKNOWN;

        default:
            ASSERT(0);
        return SI_LANGUAGE_UNKNOWN;
    }
}
EN_LANGUAGE MApp_GetLanguageBySILanguage(EN_SI_LANGUAGE eLanguage)
{
    switch(eLanguage)
    {
        case SI_LANGUAGE_CZECH:             return LANGUAGE_CZECH;
        case SI_LANGUAGE_DANISH:            return LANGUAGE_DANISH;
        case SI_LANGUAGE_GERMAN:            return LANGUAGE_GERMAN;
        case SI_LANGUAGE_ENGLISH:           return LANGUAGE_ENGLISH;
        case SI_LANGUAGE_SPANISH:           return LANGUAGE_SPANISH;
        case SI_LANGUAGE_GREEK:             return LANGUAGE_GREEK;
        case SI_LANGUAGE_FRENCH:            return LANGUAGE_FRENCH;
        case SI_LANGUAGE_CROATIAN:          return LANGUAGE_CROATIAN;
        case SI_LANGUAGE_ITALIAN:           return LANGUAGE_ITALIAN;
        case SI_LANGUAGE_HUNGARIAN:         return LANGUAGE_HUNGARIAN;
        case SI_LANGUAGE_DUTCH:             return LANGUAGE_DUTCH;
        case SI_LANGUAGE_NORWEGIAN:         return LANGUAGE_NORWEGIAN;
        case SI_LANGUAGE_POLISH:            return LANGUAGE_POLISH;
        case SI_LANGUAGE_PORTUGUESE:        return LANGUAGE_PORTUGUESE;
        case SI_LANGUAGE_RUSSIAN:           return LANGUAGE_RUSSIAN;
        case SI_LANGUAGE_ROMANIAN:          return LANGUAGE_ROMANIAN;
        case SI_LANGUAGE_SLOVENIAN:         return LANGUAGE_SLOVENIAN;
        case SI_LANGUAGE_SERBIAN:           return LANGUAGE_SERBIAN;
        case SI_LANGUAGE_FINNISH:           return LANGUAGE_FINNISH;
        case SI_LANGUAGE_SWEDISH:           return LANGUAGE_SWEDISH;
        case SI_LANGUAGE_BULGARIAN:         return LANGUAGE_BULGARIAN;
        case SI_LANGUAGE_SLOVAK:            return LANGUAGE_SLOVAK;
#if (ENABLE_DTMB_CHINA_APP || ENABLE_ATV_CHINA_APP || ENABLE_DVBC_PLUS_DTMB_CHINA_APP||CHINESE_SIMP_FONT_ENABLE ||CHINESE_BIG5_FONT_ENABLE)
        case SI_LANGUAGE_CHINESE:           return LANGUAGE_CHINESE;
#endif
        case SI_LANGUAGE_GAELIC:            return LANGUAGE_GAELIC;
        case SI_LANGUAGE_WELSH:             return LANGUAGE_WELSH;
        case SI_LANGUAGE_IRISH:             return LANGUAGE_IRISH;
        case SI_LANGUAGE_TURKISH:           return LANGUAGE_TURKISH;
        case SI_LANGUAGE_NETHERLANDS:       return LANGUAGE_NETHERLANDS;
        case SI_LANGUAGE_ARABIC:            return LANGUAGE_ARABIC;
        case SI_LANGUAGE_HEBREW:            return LANGUAGE_HEBREW;
        case SI_LANGUAGE_KOREAN:            return LANGUAGE_KOREAN;
        case SI_LANGUAGE_JAPAN:             return LANGUAGE_JAPAN;
        case SI_LANGUAGE_HINDI:             return LANGUAGE_HINDI;
        case SI_LANGUAGE_MANDARIN:          return LANGUAGE_MANDARIN;
        case SI_LANGUAGE_CANTONESE:         return LANGUAGE_CANTONESE;
        case SI_LANGUAGE_MAORI:             return LANGUAGE_MAORI;
        case SI_LANGUAGE_UND:               return LANGUAGE_UND;
        case SI_LANGUAGE_QAA:               return LANGUAGE_QAA;
        case SI_LANGUAGE_UNKNOWN:           return LANGUAGE_UNKNOWN;
        case SI_LANGUAGE_NONE:              return LANGUAGE_UNKNOWN;

        default:
            ASSERT(0);
        return LANGUAGE_UNKNOWN;
    }
}
#endif

#if (ENABLE_NONLINEAR_CURVE)
#if (ENABLE_SOUND_NONLINEAR_CURVE_TEN)
P_MS_USER_NONLINEAR_CURVE_TEN MApp_GetNonLinearCurveTen(EN_MS_NONLINEAR_CURVE eNonLinearCurveIndex)
{
    P_MS_USER_NONLINEAR_CURVE_TEN pNonLinearCurve = NULL;

    switch(eNonLinearCurveIndex)
    {
#if(ENABLE_SOUND_NONLINEAR_CURVE)
        case NONLINEAR_CURVE_VOLUME:
#if ENABLE_DTV
            if(IsDTVInUse())
                pNonLinearCurve = &(stGenSetting.g_NonLinearCurveSetting.DTVSoundCurve);
            else
#endif
            if(IsATVInUse())
                pNonLinearCurve = &(stGenSetting.g_NonLinearCurveSetting.ATVSoundCurve);
	  #if 1
			  else if(IsSVInUse())
				  pNonLinearCurve = &(stGenSetting.g_NonLinearCurveSetting.SVSoundCurve);
			  else if(IsYPbPrInUse())
				  pNonLinearCurve = &(stGenSetting.g_NonLinearCurveSetting.YPbPrSoundCurve);
			  else if(IsHDMIInUse())
				  pNonLinearCurve = &(stGenSetting.g_NonLinearCurveSetting.HDMISoundCurve);
			  else if(IsVgaInUse())
				  pNonLinearCurve = &(stGenSetting.g_NonLinearCurveSetting.PCSoundCurve);
     #endif
            else if(IsStorageInUse())
                pNonLinearCurve = &(stGenSetting.g_NonLinearCurveSetting.StorageSoundCurve);
            else
                pNonLinearCurve = &(stGenSetting.g_NonLinearCurveSetting.AVSoundCurve);
            break;
#endif
            default:
            break;
    }

    return pNonLinearCurve;
}
#endif
U8 MApp_NonLinearCalculate(P_MS_USER_NONLINEAR_CURVE pNonLinearCurve, U8 AdjustValue)
{
    //dual direction
    BYTE rValue,ucY0,ucY1,ucX0,ucX1,ucIntercept;
    WORD wDistanceOfY, wDistanceOfX;

    //if (AdjustValue < stNonLinearCurve.u8OSD_25)
    if (AdjustValue < 25)
    {
          ucY0 = pNonLinearCurve->u8OSD_0;
          ucY1 = pNonLinearCurve->u8OSD_25;
          ucX0 = 0;
          ucX1 = 25;
    }
    //else if (AdjustValue < stNonLinearCurve.u8OSD_50)
    else if (AdjustValue < 50)
    {
          ucY0 = pNonLinearCurve->u8OSD_25;
          ucY1 = pNonLinearCurve->u8OSD_50;
          ucX0 = 25;
          ucX1 = 50;
    }
    //else if (AdjustValue < stNonLinearCurve.u8OSD_75)
    else if (AdjustValue < 75)
    {
          ucY0 = pNonLinearCurve->u8OSD_50;
          ucY1 = pNonLinearCurve->u8OSD_75;
          ucX0 = 50;
          ucX1 = 75;
    }
    else
    {
          ucY0 = pNonLinearCurve->u8OSD_75;
          ucY1 = pNonLinearCurve->u8OSD_100;
          ucX0 = 75;
          ucX1 = 100;
    }

    if (ucY1 > ucY0)
    {
        wDistanceOfY = ucY1 - ucY0;
        wDistanceOfX = ucX1 - ucX0;
        ucIntercept  = ucY0;
        AdjustValue  = AdjustValue - ucX0;
    }
    else
    {
        wDistanceOfY = ucY0 - ucY1;
        wDistanceOfX = ucX1 - ucX0;
        ucIntercept  = ucY1;
        AdjustValue  = ucX1 - AdjustValue;
    }

 // printf("wDistanceOfY %u\n", wDistanceOfY);
 // printf("wDistanceOfX %u\n", wDistanceOfX);
 // printf("ucIntercept %bu\n", ucIntercept);
 // printf("AdjustValue %bu\n", AdjustValue);

    rValue = ((WORD)wDistanceOfY*AdjustValue/(wDistanceOfX)) + ucIntercept;
    return rValue;
}

P_MS_USER_NONLINEAR_CURVE MApp_GetNonLinearCurve(EN_MS_NONLINEAR_CURVE eNonLinearCurveIndex)
{
    P_MS_USER_NONLINEAR_CURVE pNonLinearCurve = NULL;

    switch(eNonLinearCurveIndex)
    {
#if(!BOE_VOLUME_CURVE)
#if(ENABLE_SOUND_NONLINEAR_CURVE)
        case NONLINEAR_CURVE_VOLUME:
#if (!ENABLE_SOUND_NONLINEAR_CURVE_TEN)
#if ENABLE_DTV
            if(IsDTVInUse())
                pNonLinearCurve = &(stGenSetting.g_NonLinearCurveSetting.DTVSoundCurve);
            else
#endif
            if(IsATVInUse())
                pNonLinearCurve = &(stGenSetting.g_NonLinearCurveSetting.ATVSoundCurve);
            else if(IsStorageInUse())
                pNonLinearCurve = &(stGenSetting.g_NonLinearCurveSetting.StorageSoundCurve);
            else
                pNonLinearCurve = &(stGenSetting.g_NonLinearCurveSetting.AVSoundCurve);
#endif
            break;
#endif
#endif
#if(ENABLE_PICTURE_NONLINEAR_CURVE)
        case NONLINEAR_CURVE_CONTRAST:
#if ENABLE_DTV
            if(IsDTVInUse())
                pNonLinearCurve = &(stGenSetting.g_NonLinearCurveSetting.DTVPictureCurve[NONLINEAR_CURVE_CONTRAST]);
            else
#endif
            if(IsATVInUse())
                pNonLinearCurve = &(stGenSetting.g_NonLinearCurveSetting.ATVPictureCurve[NONLINEAR_CURVE_CONTRAST]);
            else if(IsAVInUse())
                pNonLinearCurve = &(stGenSetting.g_NonLinearCurveSetting.AVPictureCurve[NONLINEAR_CURVE_CONTRAST]);
            else if(IsSVInUse())
                pNonLinearCurve = &(stGenSetting.g_NonLinearCurveSetting.SVPictureCurve[NONLINEAR_CURVE_CONTRAST]);
            else if(IsYPbPrInUse())
                pNonLinearCurve = &(stGenSetting.g_NonLinearCurveSetting.YPbPrPictureCurve[NONLINEAR_CURVE_CONTRAST]);
            else if(IsHDMIInUse())
                pNonLinearCurve = &(stGenSetting.g_NonLinearCurveSetting.HDMIPictureCurve[NONLINEAR_CURVE_CONTRAST]);
            else if(IsVgaInUse())
                pNonLinearCurve = &(stGenSetting.g_NonLinearCurveSetting.PCPictureCurve[NONLINEAR_CURVE_CONTRAST]);
            else if(IsStorageInUse())
                pNonLinearCurve = &(stGenSetting.g_NonLinearCurveSetting.StoragePictureCurve[NONLINEAR_CURVE_CONTRAST]);
            else
                pNonLinearCurve = &(stGenSetting.g_NonLinearCurveSetting.AVPictureCurve[NONLINEAR_CURVE_CONTRAST]);

            break;
        case NONLINEAR_CURVE_BRIGHTNESS:
#if ENABLE_DTV
            if(IsDTVInUse())
                pNonLinearCurve = &(stGenSetting.g_NonLinearCurveSetting.DTVPictureCurve[NONLINEAR_CURVE_BRIGHTNESS]);
            else
#endif
            if(IsATVInUse())
                pNonLinearCurve = &(stGenSetting.g_NonLinearCurveSetting.ATVPictureCurve[NONLINEAR_CURVE_BRIGHTNESS]);
            else if(IsAVInUse())
                pNonLinearCurve = &(stGenSetting.g_NonLinearCurveSetting.AVPictureCurve[NONLINEAR_CURVE_BRIGHTNESS]);
            else if(IsSVInUse())
                pNonLinearCurve = &(stGenSetting.g_NonLinearCurveSetting.SVPictureCurve[NONLINEAR_CURVE_BRIGHTNESS]);
            else if(IsYPbPrInUse())
                pNonLinearCurve = &(stGenSetting.g_NonLinearCurveSetting.YPbPrPictureCurve[NONLINEAR_CURVE_BRIGHTNESS]);
            else if(IsHDMIInUse())
                pNonLinearCurve = &(stGenSetting.g_NonLinearCurveSetting.HDMIPictureCurve[NONLINEAR_CURVE_BRIGHTNESS]);
            else if(IsVgaInUse())
                pNonLinearCurve = &(stGenSetting.g_NonLinearCurveSetting.PCPictureCurve[NONLINEAR_CURVE_BRIGHTNESS]);
            else if(IsStorageInUse())
                pNonLinearCurve = &(stGenSetting.g_NonLinearCurveSetting.StoragePictureCurve[NONLINEAR_CURVE_BRIGHTNESS]);
            else
               pNonLinearCurve = &(stGenSetting.g_NonLinearCurveSetting.AVPictureCurve[NONLINEAR_CURVE_BRIGHTNESS]);

            break;
        case NONLINEAR_CURVE_SATURATION:
#if ENABLE_DTV
            if(IsDTVInUse())
                pNonLinearCurve = &(stGenSetting.g_NonLinearCurveSetting.DTVPictureCurve[NONLINEAR_CURVE_SATURATION]);
            else
#endif
            if(IsATVInUse())
                pNonLinearCurve = &(stGenSetting.g_NonLinearCurveSetting.ATVPictureCurve[NONLINEAR_CURVE_SATURATION]);
            else if(IsAVInUse())
                pNonLinearCurve = &(stGenSetting.g_NonLinearCurveSetting.AVPictureCurve[NONLINEAR_CURVE_SATURATION]);
            else if(IsSVInUse())
                pNonLinearCurve = &(stGenSetting.g_NonLinearCurveSetting.SVPictureCurve[NONLINEAR_CURVE_SATURATION]);
            else if(IsYPbPrInUse())
                pNonLinearCurve = &(stGenSetting.g_NonLinearCurveSetting.YPbPrPictureCurve[NONLINEAR_CURVE_SATURATION]);
            else if(IsHDMIInUse())
                pNonLinearCurve = &(stGenSetting.g_NonLinearCurveSetting.HDMIPictureCurve[NONLINEAR_CURVE_SATURATION]);
            else if(IsVgaInUse())
                pNonLinearCurve = &(stGenSetting.g_NonLinearCurveSetting.PCPictureCurve[NONLINEAR_CURVE_SATURATION]);
            else if(IsStorageInUse())
                pNonLinearCurve = &(stGenSetting.g_NonLinearCurveSetting.StoragePictureCurve[NONLINEAR_CURVE_SATURATION]);
            else
                pNonLinearCurve = &(stGenSetting.g_NonLinearCurveSetting.AVPictureCurve[NONLINEAR_CURVE_SATURATION]);
            break;
        case NONLINEAR_CURVE_SHARPNESS:
#if ENABLE_DTV
            if(IsDTVInUse())
                pNonLinearCurve = &(stGenSetting.g_NonLinearCurveSetting.DTVPictureCurve[NONLINEAR_CURVE_SHARPNESS]);
            else
#endif
            if(IsATVInUse())
                pNonLinearCurve = &(stGenSetting.g_NonLinearCurveSetting.ATVPictureCurve[NONLINEAR_CURVE_SHARPNESS]);
            else if(IsAVInUse())
                pNonLinearCurve = &(stGenSetting.g_NonLinearCurveSetting.AVPictureCurve[NONLINEAR_CURVE_SHARPNESS]);
            else if(IsSVInUse())
                pNonLinearCurve = &(stGenSetting.g_NonLinearCurveSetting.SVPictureCurve[NONLINEAR_CURVE_SHARPNESS]);
            else if(IsYPbPrInUse())
                pNonLinearCurve = &(stGenSetting.g_NonLinearCurveSetting.YPbPrPictureCurve[NONLINEAR_CURVE_SHARPNESS]);
            else if(IsHDMIInUse())
                pNonLinearCurve = &(stGenSetting.g_NonLinearCurveSetting.HDMIPictureCurve[NONLINEAR_CURVE_SHARPNESS]);
            else if(IsVgaInUse())
                pNonLinearCurve = &(stGenSetting.g_NonLinearCurveSetting.PCPictureCurve[NONLINEAR_CURVE_SHARPNESS]);
            else if(IsStorageInUse())
                pNonLinearCurve = &(stGenSetting.g_NonLinearCurveSetting.StoragePictureCurve[NONLINEAR_CURVE_SHARPNESS]);
            else
                pNonLinearCurve = &(stGenSetting.g_NonLinearCurveSetting.AVPictureCurve[NONLINEAR_CURVE_SHARPNESS]);
            break;
        case NONLINEAR_CURVE_HUE:
#if ENABLE_DTV
            if(IsDTVInUse())
                pNonLinearCurve = &(stGenSetting.g_NonLinearCurveSetting.DTVPictureCurve[NONLINEAR_CURVE_HUE]);
            else
#endif
            if(IsATVInUse())
                pNonLinearCurve = &(stGenSetting.g_NonLinearCurveSetting.ATVPictureCurve[NONLINEAR_CURVE_HUE]);
            else if(IsAVInUse())
                pNonLinearCurve = &(stGenSetting.g_NonLinearCurveSetting.AVPictureCurve[NONLINEAR_CURVE_HUE]);
            else if(IsSVInUse())
                pNonLinearCurve = &(stGenSetting.g_NonLinearCurveSetting.SVPictureCurve[NONLINEAR_CURVE_HUE]);
            else if(IsYPbPrInUse())
                pNonLinearCurve = &(stGenSetting.g_NonLinearCurveSetting.YPbPrPictureCurve[NONLINEAR_CURVE_HUE]);
            else if(IsHDMIInUse())
                pNonLinearCurve = &(stGenSetting.g_NonLinearCurveSetting.HDMIPictureCurve[NONLINEAR_CURVE_HUE]);
            else if(IsVgaInUse())
                pNonLinearCurve = &(stGenSetting.g_NonLinearCurveSetting.PCPictureCurve[NONLINEAR_CURVE_HUE]);
            else if(IsStorageInUse())
                pNonLinearCurve = &(stGenSetting.g_NonLinearCurveSetting.StoragePictureCurve[NONLINEAR_CURVE_HUE]);
            else
              pNonLinearCurve = &(stGenSetting.g_NonLinearCurveSetting.AVPictureCurve[NONLINEAR_CURVE_HUE]);
            break;
#endif
    }

    return pNonLinearCurve;
}
#if (BOE_VOLUME_CURVE)
U8 MApp_NonLinearVOLCalculate(P_MS_USER_NONLINEAR_VOLCURVE pNonLinearVOLCurve, U8 AdjustValue)
{
	//dual direction
	BYTE rValue,ucY0,ucY1,ucX0,ucX1,ucIntercept;
	WORD wDistanceOfY, wDistanceOfX;

	if (AdjustValue < 1)
	{
		  ucY0 = pNonLinearVOLCurve->u8OSD_0;
		  ucY1 = pNonLinearVOLCurve->u8OSD_1;
		  ucX0 = 0;
		  ucX1 = 1;
	}
	else if (AdjustValue < 10)
	{
		  ucY0 = pNonLinearVOLCurve->u8OSD_1;
		  ucY1 = pNonLinearVOLCurve->u8OSD_10;
		  ucX0 = 1;
		  ucX1 = 10;
	}
	else if (AdjustValue < 20)
	{
		  ucY0 = pNonLinearVOLCurve->u8OSD_10;
		  ucY1 = pNonLinearVOLCurve->u8OSD_20;
		  ucX0 = 10;
		  ucX1 = 20;
	}
	else if (AdjustValue < 30)
	{
		  ucY0 = pNonLinearVOLCurve->u8OSD_20;
		  ucY1 = pNonLinearVOLCurve->u8OSD_30;
		  ucX0 = 20;
		  ucX1 = 30;
	}
	else if (AdjustValue < 40)
	{
		  ucY0 = pNonLinearVOLCurve->u8OSD_30;
		  ucY1 = pNonLinearVOLCurve->u8OSD_40;
		  ucX0 = 30;
		  ucX1 = 40;
	}
		else if (AdjustValue < 50)
	{
		  ucY0 = pNonLinearVOLCurve->u8OSD_40;
		  ucY1 = pNonLinearVOLCurve->u8OSD_50;
		  ucX0 = 40;
		  ucX1 = 50;
	}
	else if (AdjustValue < 60)
	{
		  ucY0 = pNonLinearVOLCurve->u8OSD_50;
		  ucY1 = pNonLinearVOLCurve->u8OSD_60;
		  ucX0 = 50;
		  ucX1 = 60;
	}
	else if (AdjustValue < 70)
	{
		  ucY0 = pNonLinearVOLCurve->u8OSD_60;
		  ucY1 = pNonLinearVOLCurve->u8OSD_70;
		  ucX0 = 60;
		  ucX1 = 70;
	}
	else if (AdjustValue < 80)
	{
		  ucY0 = pNonLinearVOLCurve->u8OSD_70;
		  ucY1 = pNonLinearVOLCurve->u8OSD_80;
		  ucX0 = 70;
		  ucX1 = 80;
	}
	else if (AdjustValue < 90)
	{
		  ucY0 = pNonLinearVOLCurve->u8OSD_80;
		  ucY1 = pNonLinearVOLCurve->u8OSD_90;
		  ucX0 = 80;
		  ucX1 = 90;
	}
	else
	{
		  ucY0 = pNonLinearVOLCurve->u8OSD_90;
		  ucY1 = pNonLinearVOLCurve->u8OSD_100;
		  ucX0 = 90;
		  ucX1 = 100;
	}

	if (ucY1 > ucY0)
	{
		wDistanceOfY = ucY1 - ucY0;
		wDistanceOfX = ucX1 - ucX0;
		ucIntercept  = ucY0;
		AdjustValue  = AdjustValue - ucX0;
	}
	else
	{
		wDistanceOfY = ucY0 - ucY1;
		wDistanceOfX = ucX1 - ucX0;
		ucIntercept  = ucY1;
		AdjustValue  = ucX1 - AdjustValue;
	}

	rValue = ((WORD)wDistanceOfY*AdjustValue/(wDistanceOfX)) + ucIntercept;
	return rValue;
}
P_MS_USER_NONLINEAR_VOLCURVE MApp_GetNonLinearVOLCurve(EN_MS_NONLINEAR_VOLCURVE eNonLinearVOLCurveIndex)
{
	P_MS_USER_NONLINEAR_VOLCURVE pNonLinearVOLCurve = NULL;

	switch(eNonLinearVOLCurveIndex)
	{
		case NONLINEAR_VOLCURVE_VOLUME:
#if ENABLE_DTV
			if(IsDTVInUse())
				pNonLinearVOLCurve = &(stGenSetting.g_NonLinearVOLCurveSetting.DTVSoundCurve);
			else
#endif
			if(IsATVInUse())
				pNonLinearVOLCurve = &(stGenSetting.g_NonLinearVOLCurveSetting.ATVSoundCurve);
			else if(IsStorageInUse())
				pNonLinearVOLCurve = &(stGenSetting.g_NonLinearVOLCurveSetting.StorageSoundCurve);
			else if(IsAVInUse())
				pNonLinearVOLCurve = &(stGenSetting.g_NonLinearVOLCurveSetting.AVSoundCurve);
			else if(IsYPbPrInUse())
				pNonLinearVOLCurve = &(stGenSetting.g_NonLinearVOLCurveSetting.YPbPrSoundCurve);
			else if(IsHDMIInUse())
				pNonLinearVOLCurve = &(stGenSetting.g_NonLinearVOLCurveSetting.HDMISoundCurve);
			else if(IsVgaInUse())
				pNonLinearVOLCurve = &(stGenSetting.g_NonLinearVOLCurveSetting.VGASoundCurve);
			break;
	}

	return pNonLinearVOLCurve;
}
#endif

#endif

#undef MAPP_GLOBAL_FUNCTION_C
