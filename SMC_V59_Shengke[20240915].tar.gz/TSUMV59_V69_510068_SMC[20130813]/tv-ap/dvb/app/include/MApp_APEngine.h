////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MApp_APENGINE_H_
#define _MApp_APENGINE_H_

#include "datatype.h"
#include "MApp_Exit.h"

#undef INTERFACE
#ifdef _MAPP_APENGINE_C_
#define INTERFACE
#else
#define INTERFACE extern
#endif


#define BIN_ID_GAME     0x00FF

typedef enum
{
    NULL_HANDLE = 0,
    NONE_HANDLE,        //for AP witn its own key handle
    GAME_HANDLE,        //for GAME runs in MM
    FULL_HANDLE,        //for general AP

} EN_APENGINE_HANDLER;

#define DBG_APSTATE(x) //x
typedef enum
{
//add new states " LISTEN" , and "WITH OSD"
    STATE_APENGINE_LISTEN = 0,  // 0
#ifdef AP_COWORK
#if AP_WITH_OSD || AP_WITH_TTX
    STATE_APENGINE_WITH_OSD,    // 1
#endif
#endif
    STATE_APENGINE_INIT,            // 2
    STATE_APENGINE_WAIT,           // 3
    STATE_APENGINE_EXIT,            // 4
    STATE_APENGINE_NONE,            // 5
} EN_APENGINE_STATE;

//a new identifier to check OSD
#ifdef AP_COWORK
#if AP_WITH_OSD || AP_WITH_TTX
INTERFACE BOOLEAN g_bGoBack_AP;
INTERFACE BOOLEAN g_bPassTV;
INTERFACE BOOLEAN g_bHideAP;
#endif
#endif

INTERFACE BOOLEAN MApp_APEngine_Start(void);
INTERFACE BOOLEAN MApp_APEngine_Resume(void);
INTERFACE BOOLEAN MApp_APEngine_RegisterByID(U16, EN_APENGINE_HANDLER, U32, U32);
INTERFACE BOOLEAN MApp_APEngine_RegisterBIN(U16, EN_APENGINE_HANDLER, U32 u32AppBinaryAddr, U32 u32Len, U32, U32);
#if OBA2
INTERFACE BOOLEAN MApp_APEngine_RegisterByName(char* AP_Name);
#if (OBA2 && defined(GADGET))
INTERFACE void MApp_APEngine_Debug(void);
INTERFACE BOOLEAN MApp_APEngine_IsGadgetActived(void);
INTERFACE BOOLEAN MApp_APEngine_ActivateGadget(void);
#endif
#endif
INTERFACE void MApp_APEngine_ClearRetVal(void);
INTERFACE U16 MApp_APEngine_GetnowBIN(void);
INTERFACE U8 MApp_APEngine_CheckAPStatus(void);
INTERFACE void MApp_APEngine_HideGWIN(void);
INTERFACE void MApp_APEngine_RestoreGWIN(void);

#ifdef AP_COWORK
INTERFACE void MApp_APEngine_SetAPCowork(BOOLEAN);
#if AP_WITH_OSD
INTERFACE void MApp_APEngine_SetGoback(void);
#endif
#endif

INTERFACE BOOLEAN MApp_APEngine_KeyBypass(void);
INTERFACE BOOLEAN MApp_APEngine_Init(void);
INTERFACE void MApp_APEngine_Process(void);
INTERFACE void MApp_APEngine_Exit(void);
INTERFACE EN_RET MApp_APEngine_CheckRetVal(void);
INTERFACE void MApp_APEngine_ProcessKey(U8);

#ifdef ENABLE_LOAD_APP_FROM_USB
INTERFACE BOOLEAN LoadAppbyFileNameFromUSB(U8 *fn);
#endif

#ifdef MSOS_TYPE_LINUX
bool MApp_DM_Wrapped_Init(void);
#endif

#undef INTERFACE

#endif //_MApp_APENGINE_H_
