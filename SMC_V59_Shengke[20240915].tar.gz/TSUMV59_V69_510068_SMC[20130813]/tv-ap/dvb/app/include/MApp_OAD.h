////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////
#ifndef _MAPP_OAD_H_
#define _MAPP_OAD_H_

#include "datatype.h"
#include "msAPI_demux.h"
#include "MApp_Exit.h"
#include "msAPI_MW_GlobalSt.h"

#ifdef _MAPP_OAD_C_
#define INTERFACE
#else
#define INTERFACE extern
#endif

#define OAD_TEST 0

typedef enum
{
    EN_OAD_MONITOR_STATE_DSI_INIT,
    EN_OAD_MONITOR_STATE_DSI_RECEIVING,
    EN_OAD_MONITOR_STATE_DSI_SIGNAL,
    EN_OAD_MONITOR_STATE_NIT_DSI_SIGNAL,
    EN_OAD_MONITOR_STATE_UNT_INIT,
    EN_OAD_MONITOR_STATE_UNT_RECEIVING,
    EN_OAD_MONITOR_STATE_UNT_SIGNAL,
    EN_OAD_MONITOR_STATE_UNT_WAIT_SCHEDULE,
    EN_OAD_MONITOR_STATE_NIT_SIGNAL,
    EN_OAD_MONITOR_STATE_PMT_DBID_RECEINING,
    EN_OAD_MONITOR_STATE_PMT_SID_RECEINING,
    EN_OAD_MONITOR_STATE_STOP,
    EN_OAD_MONITOR_STATE_NONE,
} EN_OAD_MONITOR_STATE;

typedef enum
{
    EN_OAD_DOWNLOAD_STATE_FLASH_ERASEINIT,
    EN_OAD_DOWNLOAD_STATE_FLASH_ERASING,
    EN_OAD_DOWNLOAD_STATE_DII_INIT,
    EN_OAD_DOWNLOAD_STATE_DII_RECEIVING,
    EN_OAD_DOWNLOAD_STATE_DDB_INIT,
    EN_OAD_DOWNLOAD_STATE_DDB_RECEIVING,
    EN_OAD_DOWNLOAD_STATE_DDB_COMPLETED,
    EN_OAD_DOWNLOAD_STATE_WAIT,
    EN_OAD_DOWNLOAD_STATE_STOP,
    EN_OAD_DOWNLOAD_STATE_NONE,
} EN_OAD_DOWNLOAD_STATE;

typedef enum
{
    EN_OAD_APP_STATE_INIT,
    EN_OAD_APP_STATE_WAIT_USER,
    EN_OAD_APP_STATE_YES,
    EN_OAD_APP_STATE_NO,
    EN_OAD_APP_STATE_DOWNLOADING,
    EN_OAD_APP_STATE_SCAN,
    EN_OAD_APP_STATE_STOP,
    EN_OAD_APP_STATE_UPGRADING,
    EN_OAD_APP_STATE_EXIT,
} EN_OAD_APP_STATE;

typedef enum
{
    STATE_OAD_SCAN_INIT,
    STATE_OAD_SCAN_NEXT_CHANNEL,
    STATE_OAD_SCAN_SEARCH_RF_CHANNEL,
    STATE_OAD_SCAN_PATPMT_MONITOR,
    STATE_OAD_SCAN_WAIT_PATPMT_MONITOR,
    STATE_OAD_SCAN_WAIT_DSI_CHECK_VERSION,
    STATE_OAD_SCAN_EXIT,
    STATE_OAD_SCAN_END,
} EN_OAD_SCAN_STATE;

#define DMX_BUF_SIZE_MONITOR    0x4000
#define DMX_BUF_SIZE_DOWNLOAD   0x4000*4

#if (!OBA2)
struct DEMUXBUF
{
    //U8 au8MonitorSection[MSAPI_DMX_SECTION_4K];
    //U8 au8DownloadSection[MSAPI_DMX_SECTION_4K];
    U8 monitor[DMX_BUF_SIZE_MONITOR];
    U8 download[DMX_BUF_SIZE_DOWNLOAD] ;
}  __attribute__ ((aligned (32)));
#endif

typedef enum
{
    EN_OAD_EEPROM_MONITOR,
    EN_OAD_EEPROM_OTHER,
} EN_OAD_EEPROM_STATE;

INTERFACE void MApp_OAD_Init( void ) ;
INTERFACE void MApp_OAD_SetInfo(void) ;
INTERFACE void MApp_OAD_GetInfo(EN_OAD_EEPROM_STATE state) ;
INTERFACE BOOLEAN MApp_OAD_VersonCheck(U16 type,U8 *pPrivateData) ;
INTERFACE void MApp_OAD_SetPmtSignal( WORD wPid, WORD wBDid,BYTE *pSelector,U8 selectorType );
INTERFACE void MApp_OAD_SetNitSignal( WORD wTSId, WORD wONId, WORD wServiceId, BYTE *pSelector ) ;
INTERFACE void MApp_OAD_Monitor( void );
INTERFACE void MApp_OAD_Download( void );
#if OAD_TEST
INTERFACE void MApp_OAD_AppTest( void );
#endif
INTERFACE EN_RET MApp_OAD_AppMain( void );
INTERFACE  EN_OAD_MONITOR_STATE MApp_OAD_GetMonitorState( void );
INTERFACE  void MApp_OAD_SetMonitorState( EN_OAD_MONITOR_STATE state );
INTERFACE  EN_OAD_DOWNLOAD_STATE MApp_OAD_GetDownloadState( void );
INTERFACE  void MApp_OAD_SetDownloadState( EN_OAD_DOWNLOAD_STATE state );
INTERFACE  EN_OAD_APP_STATE MApp_OAD_GetAppState( void );
INTERFACE  void MApp_OAD_SetAppState( EN_OAD_APP_STATE state );
INTERFACE BOOLEAN MApp_OAD_IsDownloadAvailable(void) ;
INTERFACE BOOLEAN MApp_OAD_IsAutoScanEnable(void);
INTERFACE void MApp_Set_OAD_AutoScanStatus(BOOLEAN bEnable);
INTERFACE EN_OAD_SCAN_STATE MApp_OAD_GetScanState( void );
INTERFACE void MApp_OAD_SetScanState( EN_OAD_SCAN_STATE state );
INTERFACE BOOLEAN MApp_OAD_IsDownloadCompleted(void) ;
INTERFACE BOOLEAN MApp_OAD_IsDownloading(void) ;
INTERFACE BOOLEAN MApp_OAD_IsUntSchedule(void) ;
INTERFACE BOOLEAN MApp_OAD_IsUserSelectOn(void);
INTERFACE void MApp_OAD_StartDownload(void) ;
INTERFACE void MApp_OAD_StopDownload(void) ;
INTERFACE void MApp_OAD_GetVersion(U32 *tvVER,U32 *tsVER);
INTERFACE void MApp_OAD_GetService(U16 *netID,U16 *tsID,U16 *serviceID,MEMBER_SERVICETYPE *type,WORD *position) ;
INTERFACE U8 MApp_OAD_GetProgress(void) ;
INTERFACE U32 MApp_OAD_GetScheduleStart(void) ;
INTERFACE U32 MApp_OAD_GetScheduleEnd(void) ;
INTERFACE WORD MApp_OAD_GetServiceLcn(void) ;
#if (BLOADER)
EN_OAD_SCAN_STATE MApp_OAD_Scan( U8* percentage );
#else
INTERFACE EN_RET MApp_OAD_Scan( U8* percentage );
#endif
#if (BLOADER)
INTERFACE void MApp_OAD_GetInfo_BL(U16* u16PID, U32* u32Freq, U8* u8BandWidth);
#endif

#undef INTERFACE
#endif //_MAPP_OAD_H_

