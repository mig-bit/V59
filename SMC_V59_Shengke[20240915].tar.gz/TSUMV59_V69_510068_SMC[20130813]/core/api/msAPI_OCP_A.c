////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2008 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (MStar Confidential Information!�L) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#define MSAPI_OCP_A_C

#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

#include "datatype.h"
#include "msAPI_OCP_A.h"
#include "msAPI_OSD_A.h"
#include "msAPI_Memory.h"
#include "msAPI_Timer.h"

#include "debug.h"
#include "msAPI_MIU.h"
#include "ms_decompress.h"

#include "sysinfo.h"
#include "msAPI_OCP.h"
#include "MApp_InputSource.h"
#include "MApp_Logo.h"
#include "mapp_videoplayer.h"

#include "msAPI_CPU.h"
#include "MApp_SaveData.h"
#define OCP_A_DBG(x)  //x
#define OCP_A_DBG_DY(x)// x

BOOLEAN bUseFlashSize=FALSE;
//*******************Jpeg&Png
#if ENABLE_JPEGPNG_OSD
static void LoadU16(U32 pSpiAddr, U16 *pU16)
{
    MDrv_FLASH_Read(pSpiAddr, sizeof(U16), (U8 *)pU16);
    *pU16 = BE2ME16(*pU16);
}

static void LoadU32(U32 pSpiAddr, U32 *pU32)
{
    MDrv_FLASH_Read(pSpiAddr, sizeof(U32), (U8 *)pU32);
    *pU32 = BE2ME32(*pU32);
}

/**************************Static Load JpegPng****************************************************************/
//  Target buffer: use fixed buffer, cannot conflict with other app in all system
//  Input buffer: flash jpegpng packet
//  Used for JpegPng packet load
/**************************Static Load JpegPng****************************************************************/
static MSAPI_JPEGPNGHANDLE* g_pSLJPHandle;
static U8 g_u8MaxSLJPHandleNum;
static U32 g_u32LastSLJPDramBufAddr;
static U32 g_u32SLJPMaxDramBufAddr;
static U8 g_u8MaxSLJPJpegPngNum;
static U8 g_u8JPPLoadStMax;
static U32 g_u32SLJPDramStartPos;
static U32 g_u32SLJPDramStartLen;

BOOLEAN msAPI_OCP_JpegPng_StLoadInit(MSAPI_JPEGPNGHANDLE* pJpegPngHandle, U8 u8TotalHandleNum, U16 u16JpegPngPacketBinID, U8 u8JPPLoadStMax, U32 u32PreDecodeBufAddr, U32 u32PreDecodeBufSize)
{
    BININFO BinInfo;
    BOOLEAN bResult;
    U8 u8Index;
    U16 u16JpegPngNum;
    U32 u32Osdcp_JpegPng_Addr = 0;
    U32 u32FlashImgAddr, u32FlashImgSize;

    // Init global variables
    g_pSLJPHandle = pJpegPngHandle;
    g_u8MaxSLJPHandleNum = u8TotalHandleNum;
    g_u32LastSLJPDramBufAddr = u32PreDecodeBufAddr;
    g_u32SLJPMaxDramBufAddr = g_u32LastSLJPDramBufAddr + u32PreDecodeBufSize;
    g_u8JPPLoadStMax = u8JPPLoadStMax;
    //g_u8CurSLJPIdx = 0;

    OCP_A_DBG(puts("\n Static LoadJpegPng Init start >>>"));
    BinInfo.B_ID = u16JpegPngPacketBinID;
    msAPI_MIU_Get_BinInfo(&BinInfo, &bResult);
    if ( bResult == PASS )
    {
        u32Osdcp_JpegPng_Addr = BinInfo.B_FAddr;
    }
    else
    {
        puts("\n Static LoadJpegPng Init: Not found JpegPngPaket bin!!!");
        return FALSE;
    }
    // Init decoder for decode jpeg/png to dram buf
    // Get the total num of photo in BIN_ID_OSDCP_JPEG bin
    LoadU16(u32Osdcp_JpegPng_Addr + INFO_SIZE, &u16JpegPngNum);
    OCP_A_DBG(printf("\n u16JpegPngNum = %ld", u16JpegPngNum));
    if(u16JpegPngNum > g_u8MaxSLJPHandleNum)
    {
        puts("\n Static LoadJpegPng Init: pJpegPngHandle Overflow!!!");
        return FALSE;
    }
    g_u8MaxSLJPJpegPngNum = u16JpegPngNum;
    // Move to point the img data buf, Size0.Size1...Data0.Data1
    u32Osdcp_JpegPng_Addr += (INFO_SIZE + sizeof(u16JpegPngNum));
    u32FlashImgAddr = u32Osdcp_JpegPng_Addr + u16JpegPngNum*sizeof(U32);
    for(u8Index = 0; u8Index < u16JpegPngNum; u8Index++)
    {
        g_pSLJPHandle[u8Index].bInitFlg = FALSE;
        OCP_A_DBG(printf("\n----- Index = %ld------", u8Index));
        LoadU32(u32Osdcp_JpegPng_Addr + u8Index*sizeof(U32), &u32FlashImgSize);
        OCP_A_DBG(printf("\n u32FlashImgAddr = 0x%x, u32FlashImgSize = 0x%x", u32FlashImgAddr, u32FlashImgSize));
        // format the handle
        g_pSLJPHandle[u8Index].bFlashBinFlg = TRUE;
        g_pSLJPHandle[u8Index].u32FlashImgAddr = u32FlashImgAddr;  //img addr
        g_pSLJPHandle[u8Index].u32FlashImgSize = u32FlashImgSize;  //img size
        g_pSLJPHandle[u8Index].u32BuffAddr = 0x0000;       //target buf
        g_pSLJPHandle[u8Index].bJpegFlg=TRUE;
        // Prepare the handle data for next photo decode
        u32FlashImgAddr += u32FlashImgSize;
        OCP_A_DBG(printf("\n-----------------------", u8Index));
    }
    OCP_A_DBG(puts("\n Static LoadJpegPng Init end <<<<"));

    return TRUE;
}

BOOLEAN msAPI_OCP_JpegPng_StLoad(U8 u8JPPLoadSt)
{
    U8 u8Index;
    U32 u32DramBufAddr = g_u32LastSLJPDramBufAddr;
    OCP_A_DBG(puts("\n Static LoadJpegPng  start >>>"));

    if(u8JPPLoadSt >= g_u8JPPLoadStMax)
    {
        puts("\n Static LoadJpegPng: u8JPPLoadSt Overflow!!!");
        return FALSE;
    }

   // if(gbBinLoad==FALSE)
    {
        OCP_A_DBG(printf("load co-processor code\n"));
      #if defined(MIPS_CHAKRA) || defined(MSOS_TYPE_LINUX) || defined(__AEONR2__)
        msAPI_COPRO_Init(BIN_ID_CODE_VDPLAYER,((AEON_MEM_MEMORY_TYPE & MIU1) ? (AEON_MM_MEM_ADR | MIU_INTERVAL) : (AEON_MM_MEM_ADR)),AEON_MM_MEM_LEN);
      #else
        msAPI_COPRO_Init(BIN_ID_CODE_VDPLAYER,((BEON_MEM_MEMORY_TYPE & MIU1) ? (BEON_MEM_ADR | MIU_INTERVAL) : ( BEON_MEM_ADR)),BEON_MEM_LEN);
      #endif

      // gbBinLoad=TRUE;
       msAPI_Timer_Delayms(70);
    }

    //msAPI_Timer_Delayms(200);
    // Init decoder for decode jpeg/png to dram buf
    for(u8Index = 0; u8Index < g_u8MaxSLJPJpegPngNum; u8Index++)
    {
        OCP_A_DBG(printf("\n----- Index = %ld------", u8Index));

        if(g_pSLJPHandle[u8Index].bInitFlg)
        {
           continue;
        }
        // Start decode to buf which used for jpeg&png decoded data, format the handle
        g_pSLJPHandle[u8Index].u32BuffAddr = u32DramBufAddr;       //target buf

        {
            if(MApp_PhotoOSD_DecodeToBuf(&g_pSLJPHandle[u8Index]) == FALSE)
            {
                if(g_pSLJPHandle[u8Index].bJpegFlg)
                    puts("\n Static LoadJpegPng: jpeg decode fail!!!");
                else
                    puts("\n Static LoadJpegPng: png decode fail!!!");
                return FALSE;
            }
        }

      //  TIME_DBG(printf("Decode time: index = %ld, size = %ld, %Lu ms\n", u8Index, g_pSLJPHandle[u8Index].u32BuffSize, msAPI_Timer_DiffTimeFromNow(StartTime)));
        g_pSLJPHandle[u8Index].bInitFlg = TRUE;
        // Prepare the handle data for next photo decode
        u32DramBufAddr = u32DramBufAddr + g_pSLJPHandle[u8Index].u32BuffSize;
        u32DramBufAddr = GE_ALIGNED_VALUE(u32DramBufAddr, 8);
        g_u32LastSLJPDramBufAddr = u32DramBufAddr;
        OCP_A_DBG(printf("\n, u32BuffSize = 0x%x", g_pSLJPHandle[u8Index].u32BuffSize));
        OCP_A_DBG(printf("\n-----------------------", u8Index));
    }

    if(u32DramBufAddr > g_u32SLJPMaxDramBufAddr)
    {
        printf("\n Static LoadJpegPng: JpegBufAddr = 0x%lx, Overflow > 0x%lx\n", u32DramBufAddr, g_u32SLJPMaxDramBufAddr);
        return FALSE;
    }
    else
    {
        g_u32LastSLJPDramBufAddr = u32DramBufAddr;
    }

    OCP_A_DBG(puts("\n Static LoadJpegPng end <<<<"));
    return TRUE;
}

void msAPI_OCP_JpegPngSetOutBufInfo(BOOLEAN bOSDBuf)
{
    UNUSED(bOSDBuf);
    g_u32SLJPDramStartPos = (U32)CAPE_BUFFER_ADR;
    g_u32SLJPDramStartLen = (U32)CAPE_BUFFER_LEN;
}

U32 msAPI_OCP_JpegPngGetOutBufPos(void)
{
    return g_u32SLJPDramStartPos;
}

U32 msAPI_OCP_JpegPngGetOutBufLen(void)
{
    return g_u32SLJPDramStartLen;
}
#endif

#undef  MSAPI_OCP_A_C
