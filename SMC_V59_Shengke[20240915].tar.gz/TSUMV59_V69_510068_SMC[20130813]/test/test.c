#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <string.h>

#define PROG_NAME "cutter"
#define NEW_CHUNK_HEADER_FILE "./secure/new_chunk.bin"

void printUsage()
{
    //return;
    printf("Please use:\n");
    printf("\r\t%s [file to cut] [file size to cut] [file to save]\n", PROG_NAME);
    printf("\n\r\texample: %s MERGE.bin AP_C.bin chunk_header.bin\n", PROG_NAME);
    printf("\n\n");
}

/*
 * dump chunk from MERGE.bin
 */


int func1(char *merge)
{
    unsigned long idx=0;
    int ch=0;
    FILE *fp1=NULL, *fp2=NULL;
    fp1 = fopen(merge, "rb");
    fp2 = fopen(NEW_CHUNK_HEADER_FILE, "wb");
    if((fp1!=NULL) && (fp2!=NULL))
    {
        for(idx=0; idx<0x60000; idx++)
        {
            if((ch=fgetc(fp1)) == EOF)
            {
                goto ERR_RET;
            }
        }
        for(idx=0; idx<0x400; idx++)
        {
            if((ch=fgetc(fp1)) == EOF)
            {
                goto ERR_RET;
            }
            if(fputc(ch, fp2) == EOF)
            {
                goto ERR_RET;
            }
        }
        fclose(fp1);
        fclose(fp2);
    }
    else
    {
ERR_RET:
        if(fp1!=NULL)
            fclose(fp1);
        if(fp2!=NULL)
            fclose(fp2);
        return -1;
    }
    
    return 0;
}

/*
 * save chunk back to MERGE.bin
 */
int func3(char *merge)
{
    unsigned long idx=0;
    int ch=0;
    FILE *fp1=NULL, *fp2=NULL;
    fp1 = fopen(NEW_CHUNK_HEADER_FILE, "rb");
    fp2 = fopen(merge, "r+");
    if((fp1!=NULL) && (fp2!=NULL))
    {
        if(fseek(fp2, 0x60000, SEEK_SET))
        {
            goto ERR_RET;
        }
        for(idx=0; idx<0x400; idx++)
        {
            if((ch=fgetc(fp1)) == EOF)
            {
                goto ERR_RET;
            }
            if(fputc(ch, fp2) == EOF)
            {
                goto ERR_RET;
            }
        }
        fclose(fp1);
        fclose(fp2);
    }
    else
    {
ERR_RET:
        if(fp1!=NULL)
            fclose(fp1);
        if(fp2!=NULL)
            fclose(fp2);
        return -1;
    }
    
    return 0;
}

int func2(char *file_need_auth)
{
    char cmd[256];
    memset(cmd, 0, sizeof(cmd));
    sprintf(cmd, "./secure/cryptest.exe na_sign ./secure/t_private_loader ./secure/t_public_loader %s secure/t_signature_loader 1 > /dev/null", file_need_auth);
    system(cmd);
    //secure/cryptest.exe na_sign secure/t_private_loader secure/t_public_loader $(APC_BIN) secure/t_signature_loader 1 > /dev/null
    sprintf(cmd, "./secure/SecureInfoBinGen.exe %s secure/t_public_loader secure/t_signature_loader", NEW_CHUNK_HEADER_FILE);
    system(cmd);
    //secure/SecureInfoBinGen.exe $(ROOT)/boot/sboot/out/chunk_header.bin secure/t_public_loader secure/t_signature_loader
    return 0;
}

int main(int argc, char **argv)
{
    struct stat s_fstat;
    FILE *fp1=NULL, *fp2=NULL;
    unsigned long idx=0;
    int ch=0;
    if(argc!=4)
    {
        printUsage();
        return -1;
    }
    fp1 = fopen(argv[1], "rb");
    fp2 = fopen(argv[3], "wb");
    if((fp1!=NULL) && (fp2!=NULL))
    {
        memset(&s_fstat, 0, sizeof(s_fstat));
        if(lstat(argv[2], &s_fstat))
        {
            printUsage();
            return -1;
        }
        //printf("st_size: 0x%lx\n", s_fstat.st_size);
        if(fseek(fp1, 0x60400, SEEK_SET))
        {
            printf("at %d\n", __LINE__);
            goto ERR_RET;
        }
        for(idx=0; idx<s_fstat.st_size; idx++)
        {
            if((ch=fgetc(fp1)) == EOF)
            {
                printf("%s\n", argv[1]);
                printf("idx: %ld, at %d\n", idx, __LINE__);
                goto ERR_RET;
            }
            if(fputc(ch, fp2) == EOF)
            {
                printf("at %d\n", __LINE__);
                goto ERR_RET;
            }
        }
        fclose(fp1);
        fclose(fp2);
        if(!func1(argv[1]))
        {
            func2(argv[3]);
            if(func3(argv[1]))
            {
                printf("failed\n");
                goto ERR_RET;
            }
            printf("done\n");
        }
        else
        {
            printf("at %d\n", __LINE__);
        }
    }
    else
    {
ERR_RET:
        if(fp1!=NULL)
            fclose(fp1);
        if(fp2!=NULL)
            fclose(fp2);
        printUsage();
        return -1;
    }
	return 0;
}

