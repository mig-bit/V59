////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (MStar Confidential Information) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////


/********************************************************************************/
/*                      Header Files                                            */
/********************************************************************************/
#include "MsCommon.h"
#include "hwreg.h"
#include "MApp_Key.h"
#include "drvpower_if.h"

#define MAPP_SLEEP_C

#include "MApp_TV.h"
#include "MApp_GlobalVar.h"
#include "MApp_PCMode.h"
#include "apiXC_PCMonitor.h"

#include "MApp_Sleep.h"
#include "msAPI_Timer.h"
#include "msAPI_Power.h"
#if (NO_SIGNAL_AUTO_SHUTDOWN==1)
#include "MApp_SignalMonitor.h"
#include "MApp_VDMode.h"
#endif
#include "MApp_UiMenuDef.h"
#include "MApp_SaveData.h"

#include "MApp_GlobalFunction.h"
#include "MApp_GlobalSettingSt.h"
#if (ENABLE_TTX)
#include "mapp_ttx.h"
#endif
#include "MApp_ZUI_Main.h"
#include "ZUI_tables_h.inl"
#include "ZUI_exefunc.h"
#include "MApp_TopStateMachine.h"
#if ENABLE_DMP
#include "mapp_mplayer.h"
#include "MApp_UiMediaPlayer.h"
#endif
#include "MApp_ZUI_ACTcoexistWin.h"
#if (ENABLE_UPDATE_MULTIPLEX_VIA_NIT)
#include "MApp_Scan.h"
#endif

#if ENABLE_OAD
#include "MApp_OAD.h"
#endif

#include "msAPI_DrvInit.h"

#include "MApp_Menu_Main.h"
#include "MApp_InputSource_Main.h"
#include "MApp_ZUI_ACTdmp.h"


#define DEBUG_SLEEP(x)  //x

#if (CHIP_FAMILY_TYPE!=CHIP_FAMILY_M10) && (CHIP_FAMILY_TYPE!=CHIP_FAMILY_M12)
#define RTC_DISABLE_VALUE 0xFFFFFFFF
#endif

/*static EN_SLEEP_TIME_STATE enSleepTimeState = STATE_SLEEP_OFF;*/
static U8   u8SiganlStatusCheck_Count = 0;
static BOOLEAN benableNoSignalAutoSleep=0;//default disable
static BOOLEAN bIsCountWinShow = FALSE;

U32 u32ProtectOffTimer;
U32 u32OffTimeFreeze = 0;
BOOLEAN bSkipCountdown = TRUE;

#if DTV_COUNT_DOWN_TIMER_PATCH
U8 u8DTVCountDownTimer = 0xFF;
#endif


static U8 const code au8SleepTimeCoef[STATE_SLEEP_TOTAL]= {0,1,2,3,4,5,6,9,12/*,18,24*/};
extern void MApp_ZUI_ACTcoexistWin_Init(void);

//extern U16 g_u16ElapsedTimeSecond;
extern DWORD MApp_GetEpgManualTimerStartDate(void);

extern BOOLEAN msAPI_Tuner_IsTuningProcessorBusy(void);

void MApp_Sleep_SetTime()
{
    switch(++enSleepTimeState)
    {
        case STATE_SLEEP_TOTAL:
        case STATE_SLEEP_OFF:
                enSleepTimeState = STATE_SLEEP_OFF;
                benableSleepTimer=FALSE;
                u32SleepTimeDur=0;
                break;

        default:
                benableSleepTimer=TRUE;
                u32SleepTimeDur=(U32)SLEEP_TIMER_TIMEBASE*(U32)au8SleepTimeCoef[enSleepTimeState];
                u32SleepTimer=msAPI_Timer_GetTime0();
                break;
    }
}

/*
BOOLEAN _MApp_Sleep_TurnOff_OtherOSD(BOOLEAN bPass)
{
    BOOLEAN bret = TRUE;

    #if ENABLE_TTX
        if(MApp_TTX_TeletextCommand(TTX_TV) != E_RESULT_FAILURE)//turn TTX OFF if need be
        {
            ;// the TTX will be turn off by MApp_TTX_TeletextCommand(TTX_TV)
        }
        else
    #endif
        if(0)// turn Subtitle OFF if need be
        {
            u8KeyCode = KEY_COUNTDOWN_EXIT_TT_SUBTITLE;
        }
        else if(0)// turn MHEG5 OFF if need be
        {
            ;
        }
        else if(0)// turn C.C OFF if need be
        {
            ;
        }
        else if(MApp_ZUI_GetActiveOSD() != E_OSD_EMPTY && MApp_ZUI_GetActiveOSD() != E_OSD_MESSAGE_BOX)// Other OSD On
        {
            if (MApp_ZUI_GetActiveOSD() == E_OSD_SCREEN_SAVER && (bPass || bSkipCountdown == FALSE))
            {
                MApp_ZUI_ACT_ShutdownOSD();
                SYS_SCREEN_SAVER_TYPE(MAIN_WINDOW) = EN_SCREENSAVER_NULL;
            }
            else
            if( MApp_ZUI_GetState() == E_ZUI_STATE_STANDBY
                || MApp_ZUI_GetState() == E_ZUI_STATE_RUNNING)
            {
                u8KeyCode = KEY_EXIT;
            }
        }
        else
            bret = FALSE;

        return bret;

}
*/

extern EN_MENU_STATE enMainMenuState;
extern EN_INPUTSOURCE_STATE enInputSourceState;
extern BOOLEAN bPlayingStateEnableOSD;
void  MApp_Sleep_Monitor(void)
{
    if(benableSleepTimer)
    {
        U32 u32SleepTimerDiff = msAPI_Timer_DiffTimeFromNow(u32SleepTimer);

        if(u32SleepTimerDiff>=u32SleepTimeDur)
        {
            if ((u32SleepTimerDiff-u32SleepTimeDur) < 60*1000 && (u32SleepTimerDiff-u32SleepTimeDur) > 0)
            {
       #if 0
                if( MApp_ZUI_GetActiveOSD() == E_OSD_ATV_MANUAL_TUNING
                    || MApp_ZUI_GetActiveOSD() == E_OSD_AUTO_TUNING
                    #if ENABLE_DTV
                    || MApp_ZUI_GetActiveOSD() == E_OSD_DTV_MANUAL_TUNING
                    #endif
                   )
       #else
		   if(IsATVInUse() && (MApp_ZUI_GetActiveOSD() == E_OSD_MAIN_MENU) && msAPI_Tuner_IsTuningProcessorBusy())
	   #endif
                {
                    u32SleepTimer += 1000;
                    return;
                }

                if(bIsCountWinShow == FALSE)    //if((u8CoexistWinType != COWIN_ID_COUNT_DOWN_WIN))
                {
                    enIndicateTimerSource = TS_TYPE_SLEEPTIMER;
                    if(IsStorageInUse())
                    {
                        if((bPlayingStateEnableOSD)/*&&(MApp_ZUI_GetActiveOSD() == E_OSD_DMP)*/)
                        {
                            MApp_ZUI_ACT_DmpShowCountDownWin();
                            bIsCountWinShow=TRUE;    //u8CoexistWinType = COWIN_ID_COUNT_DOWN_WIN;
                            bPlayingStateEnableOSD = FALSE;
                        }
                        else
                        {
                            if(MApp_ZUI_GetActiveOSD() != E_OSD_DMP)
                            {
                                MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_CLOSE_CURRENT_OSD);
                            }
                            else
                            {
                                bPlayingStateEnableOSD = TRUE;
                            }
                        }
                    }
                    else
                    {
                    	#if 1
		                if(MApp_ZUI_GetActiveOSD() == E_OSD_MAIN_MENU ||MApp_ZUI_GetActiveOSD() == E_OSD_INPUT_SOURCE)
                        {
                            enMainMenuState = STATE_MENU_CLEAN_UP;
                            enInputSourceState = STATE_INPUTSOURCE_CLEAN_UP;
                        }
                        else
                        {
                            if (MApp_ZUI_GetActiveOSD() != E_OSD_MESSAGE_BOX ||
		                    ((MApp_ZUI_GetActiveOSD() == E_OSD_MESSAGE_BOX) && (MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_QUERY_IS_POWER_OFF_COUNTDOWN_MSG_BOX) == FALSE)))
                            {
                                MApp_ZUI_ACT_ShutdownOSD();
                            }
                            bIsCountWinShow=TRUE;    //u8CoexistWinType = COWIN_ID_COUNT_DOWN_WIN;
                            MApp_ZUI_ACT_StartupOSD(E_OSD_MESSAGE_BOX);
                            DEBUG_SLEEP(printf("\n EN_EXE_SHOW_POWER_OFF_COUNTDOWN_MSG_BOX\n"));
                            MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_SHOW_POWER_OFF_COUNTDOWN_MSG_BOX);
                        }
			            #else
                        MApp_UiMenu_CountDownWin_Create();
			            #endif
                    }
                }
                else if(u8KeyCode != KEY_NULL)
                {
                    if(IsStorageInUse())
                    {
                        bIsCountWinShow=FALSE;    //u8CoexistWinType = COWIN_ID_NONE;
                        MApp_ZUI_ACT_DmpHideCountDownWin();
                    }
                    else
                    {
                    	#if 1
				        DEBUG_SLEEP(printf("\n MApp_ZUI_ACT_ShutdownOSD \n"));
				        bIsCountWinShow=FALSE;    //u8CoexistWinType = COWIN_ID_NONE;
				        MApp_ZUI_ACT_ShutdownOSD();
			            #else
                        MApp_ZUI_ACTcoexist_Delete();
                        MApp_ZUI_ACTcoexistWin_Init();
			            #endif
                    }
                    if(msAPI_AUD_IsAudioMutedByUser()) //redraw MUTE icon after close CountDown OSD
                        MApp_UiMenu_MuteWin_Show();
                    MApp_Sleep_ReleaseSleepTimer();
                    enSleepTimeState = STATE_SLEEP_OFF;
		            stLMGenSetting.stMD.enD4_SleepTimer = STATE_SLEEP_OFF;
                    if(u8KeyCode != KEY_POWER)
                    {
                        u8KeyCode = KEY_NULL;
                    }
                    enIndicateTimerSource = TS_TYPE_NONE;
                }
                else if(bIsCountWinShow)    //else if(u8CoexistWinType == COWIN_ID_COUNT_DOWN_WIN)
                {
                    if(IsStorageInUse())
                    {
                        MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_COUNTDOWN_PANEL);
                    }
                    else
                    {
                    	#if 1
				        DEBUG_SLEEP(printf("MApp_ZUI_API_InvalidateAllSuccessors  HWND_MSGBOX_COUNTDOWN here \n"));
                     	MApp_ZUI_API_InvalidateAllSuccessors(HWND_MSGBOX_COUNTDOWN);
			            #else
                        MApp_UiMenu_CountDownWin_Draw();
			            #endif
                    }
                }
                return;
            }
            else if ((u32SleepTimerDiff-u32SleepTimeDur) >= 60*1000)
            {
                u8KeyCode  = KEY_POWER;
                enIndicateTimerSource = TS_TYPE_NONE;
                return;
            }
        }
    }

    if(benableAutoOn_OffTimer)
    {
        U32 u32TimeAutooff;
        u32TimeAutooff = TIME_AUTO_OFF_AFTER_AUTO_ON;
        #if ENABLE_CUS_AUTO_SLEEP_MODE
        if(stGenSetting.g_Time.cAutoSleepFlag == EN_Time_AutoOff_On_1Hour)
        {
            u32TimeAutooff = 3600000;
        }
        else if(stGenSetting.g_Time.cAutoSleepFlag == EN_Time_AutoOff_On_2Hours)
        {
            u32TimeAutooff = 7200000;
        }
        else if(stGenSetting.g_Time.cAutoSleepFlag == EN_Time_AutoOff_On_5Hours)
        {
            u32TimeAutooff = 18000000;
        }
        #endif
        if (msAPI_Timer_DiffTime((u32AutoOnTime+u32TimeAutooff),msAPI_Timer_GetTime0()) == 0) //unit = ms
        {
            u8KeyCode = KEY_POWER;
            return;
        }
    }

    if (!(g_u8TimeInfo_Flag & UI_TIME_MINUTE_SET))
        return;

    if(benableOffTimer == STATE_SLEEP_OFFTIMER_TRANSIT)
    {
        U32 u32LocalOneDayTime = MApp_GetLocalSystemTime() % ONEDAY_TIME;

        if (u32LocalOneDayTime > u32OffTimeDur)
        {
            MApp_Sleep_SetOffTime(TRUE);
        }
        return;
    }
    else if(
        ((benableOffTimer == STATE_SLEEP_OFFTIMER_ON) && (MApp_OffTime_IsOffTimeInDayOfWeek() == TRUE))  //Off timer is this time & this day
    #if DTV_COUNT_DOWN_TIMER_PATCH
        || ((benableOffTimer == STATE_SLEEP_OFFTIMER_ON) && (u8DTVCountDownTimer != 0xFF))
    #endif
        )
    {
        U32 u32LocalOneDayTime;
        U32 u32OffTimerDiff;

        u32LocalOneDayTime = MApp_GetLocalSystemTime()% ONEDAY_TIME;

        if((u32OffTimeDur+u32OffTimeFreeze)< u32LocalOneDayTime) //the time already pass
        {
        #if DTV_COUNT_DOWN_TIMER_PATCH
            if(u8DTVCountDownTimer != 0xFF)
                ;
            else
        #endif
            return;
        }

        u32OffTimerDiff = msAPI_Timer_DiffTime(u32OffTimeDur+u32OffTimeFreeze, u32LocalOneDayTime);

    #if DTV_COUNT_DOWN_TIMER_PATCH
        if(u8DTVCountDownTimer == 0 && bSkipCountdown == FALSE)
        {
            u8KeyCode  = KEY_POWER;
            enIndicateTimerSource = TS_TYPE_NONE;
            return;
        }
        else
    #endif
        if(
            (u32OffTimerDiff <= 60 && u32OffTimerDiff >0 && (bSkipCountdown == FALSE))
        #if DTV_COUNT_DOWN_TIMER_PATCH
            || ((u8DTVCountDownTimer != 0xFF ) && (bSkipCountdown == FALSE))
        #endif
            )
        {
     #if 0
            if( MApp_ZUI_GetActiveOSD() == E_OSD_ATV_MANUAL_TUNING
                || MApp_ZUI_GetActiveOSD() == E_OSD_AUTO_TUNING
                #if ENABLE_DTV
                || MApp_ZUI_GetActiveOSD() == E_OSD_DTV_MANUAL_TUNING
                #endif
               )
     #else
	      if(IsATVInUse() && (MApp_ZUI_GetActiveOSD() == E_OSD_MAIN_MENU) && msAPI_Tuner_IsTuningProcessorBusy())
	 #endif
            {
                u32OffTimeFreeze++;
                if(u32OffTimerDiff < 62)
                    u32OffTimeFreeze++;
                return;
            }

        #if DTV_COUNT_DOWN_TIMER_PATCH
            if(u8DTVCountDownTimer == 0xFF)
            {
                u8DTVCountDownTimer = u32OffTimerDiff;
            }
        #endif

        #if 1//(ENABLE_CUS_UI_SPEC == DISABLE)
            if(bIsCountWinShow==FALSE)   //if((u8CoexistWinType != COWIN_ID_COUNT_DOWN_WIN))
            {
                enIndicateTimerSource = TS_TYPE_OFFTIMER;
                if(IsStorageInUse())
                {
                    if((bPlayingStateEnableOSD)/*&&(MApp_ZUI_GetActiveOSD() == E_OSD_DMP)*/)
                    {
                        MApp_ZUI_ACT_DmpShowCountDownWin();
                        bIsCountWinShow=TRUE;    //u8CoexistWinType = COWIN_ID_COUNT_DOWN_WIN;
                        bPlayingStateEnableOSD = FALSE;
                    }
                    else
                    {
                        if(MApp_ZUI_GetActiveOSD() != E_OSD_DMP)
                        {
                            MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_CLOSE_CURRENT_OSD);
                        }
                        else
                        {
                            bPlayingStateEnableOSD = TRUE;
                        }
                    }
                }
                else
                {
                	#if 1
	                if(MApp_ZUI_GetActiveOSD() == E_OSD_MAIN_MENU ||MApp_ZUI_GetActiveOSD() == E_OSD_INPUT_SOURCE)
                    {
                        enMainMenuState = STATE_MENU_CLEAN_UP;
                        enInputSourceState = STATE_INPUTSOURCE_CLEAN_UP;
                    }
                    else
                    {
                        if (MApp_ZUI_GetActiveOSD() != E_OSD_MESSAGE_BOX ||
	                    ((MApp_ZUI_GetActiveOSD() == E_OSD_MESSAGE_BOX) && (MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_QUERY_IS_POWER_OFF_COUNTDOWN_MSG_BOX) == FALSE)))
                        {
                            MApp_ZUI_ACT_ShutdownOSD();
                        }
                        bIsCountWinShow=TRUE;    //u8CoexistWinType = COWIN_ID_COUNT_DOWN_WIN;
                        MApp_ZUI_ACT_StartupOSD(E_OSD_MESSAGE_BOX);
                        DEBUG_SLEEP(printf("\n EN_EXE_SHOW_POWER_OFF_COUNTDOWN_MSG_BOX\n"));
                        MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_SHOW_POWER_OFF_COUNTDOWN_MSG_BOX);
                    }
		            #else
                    MApp_UiMenu_CountDownWin_Create();
		            #endif
                }
            }
            else if(u8KeyCode != KEY_NULL)
            {
                if(IsStorageInUse())
                {
                    bIsCountWinShow=FALSE;    //u8CoexistWinType = COWIN_ID_NONE;
                    MApp_ZUI_ACT_DmpHideCountDownWin();
                }
                else
                {
                	#if 1
			        DEBUG_SLEEP(printf("\n MApp_ZUI_ACT_ShutdownOSD \n"));
			        bIsCountWinShow=FALSE;    //u8CoexistWinType = COWIN_ID_NONE;
			        MApp_ZUI_ACT_ShutdownOSD();
		            #else
                    MApp_ZUI_ACTcoexist_Delete();
                    MApp_ZUI_ACTcoexistWin_Init();
		            #endif
                }
                if(msAPI_AUD_IsAudioMutedByUser()) //redraw MUTE icon after close CountDown OSD
                {
                   MApp_UiMenu_MuteWin_Show();
                }

                bSkipCountdown = TRUE;
                u32OffTimeFreeze = 0;
                if(u8KeyCode != KEY_POWER)
                {
                    u8KeyCode = KEY_NULL;
                }
                enIndicateTimerSource = TS_TYPE_NONE;

                if(stGenSetting.g_Time.cOffTimerFlag == EN_Time_OffTimer_Once)
                {
                    stGenSetting.g_Time.cOffTimerFlag = EN_Time_OffTimer_Off;
                    #if ENABLE_CUS_UI_SPEC
                    MApp_ZUI_API_InvalidateWindow(HWND_MENU_TIME_SET_OFFTIME);
                    #else
                    MApp_ZUI_API_InvalidateWindow(HWND_MENU_TIME_SET_OFFTIME_OPTION);
                    #endif
                }

            #if DTV_COUNT_DOWN_TIMER_PATCH
                u8DTVCountDownTimer = 0xFF;
            #endif

                //do not out off countdown  while is not sleep off time
                //u8KeyCode = KEY_NULL;
                //return;

            }
            else if(bIsCountWinShow)    //else if(u8CoexistWinType == COWIN_ID_COUNT_DOWN_WIN)
            {
                if(IsStorageInUse())
                {
                    MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_COUNTDOWN_PANEL);
                }
                else
                {
                	#if 1
			        DEBUG_SLEEP(printf("MApp_ZUI_API_InvalidateAllSuccessors  HWND_MSGBOX_COUNTDOWN here \n"));
                 	MApp_ZUI_API_InvalidateAllSuccessors(HWND_MSGBOX_COUNTDOWN);
		            #else
                    MApp_UiMenu_CountDownWin_Draw();
		            #endif
                }
            }
           #endif
            return;
        }
    #if (!DTV_COUNT_DOWN_TIMER_PATCH)
        else if(u32OffTimerDiff== 0 && bSkipCountdown == FALSE)
        {
            u8KeyCode  = KEY_POWER;
            enIndicateTimerSource = TS_TYPE_NONE;
            return;
        }
    #endif
        else if(u32OffTimerDiff > 60)
        {
            bSkipCountdown = FALSE;
        }
    }
}

BOOLEAN MApp_SleepCountWinShow(void)
{
    return bIsCountWinShow;
}

void MApp_NoSignalSleep_Monitor()
{
#if (NO_SIGNAL_AUTO_SHUTDOWN==1)
//CUS_XM:xue add for burnin open no sleep 2012-7-9
		if(stGenSetting.g_FactorySetting.fBuringMode)
			return;
			//benableNoSignalAutoSleep=0;

#if ENABLE_POWER_SAVING_DPMS
if ( ((++u8SiganlStatusCheck_Count)>50) && (IsVgaInUse() || (benableNoSignalAutoSleep==TRUE)))
#else
if ( ((++u8SiganlStatusCheck_Count)>50)&& (benableSleepTimer==FALSE) && (benableNoSignalAutoSleep==TRUE))
#endif
    {
        DEBUG_SLEEP(printf("\n>>>>>>>>MApp_NoSignalSleep_Monitor\n"));
        DEBUG_SLEEP(printf("   :benableNoSignalAutoSleep = %d\n",benableNoSignalAutoSleep));


        if (IsDTVInUse())
        {
            DEBUG_SLEEP(printf("----->MApp_GetSignalStatus() = %d\n",MApp_GetSignalStatus()));
            if (( MApp_GetSignalStatus()==SIGNAL_UNLOCK )||(MApp_GetSignalStatus()==SIGNAL_UNKNOWN))
            {
               DEBUG_SLEEP(printf(">>>>> MApp_GetSignalStatus()==SIGNAL_UNLOCK\n"));
                if (FALSE==benableNoSiganlSleepCheck)
                {
                    u32NoSignal_MonitorStartTime = msAPI_Timer_GetTime0();
                    u32No_Signal_SleepTimeDur = (U32)NO_SIGNAL_SLEEP_TIMER;
                    benableNoSiganlSleepCheck = TRUE;
                     DEBUG_SLEEP(printf("   :u32NoSignal_MonitorStartTime = %ld\n",u32NoSignal_MonitorStartTime));
                     DEBUG_SLEEP(printf("   :u32No_Signal_SleepTimeDur = %ld\n",u32No_Signal_SleepTimeDur));
                     DEBUG_SLEEP(printf("   :benableNoSiganlSleepCheck = %d\n",benableNoSiganlSleepCheck));
                }

            }
            else
            {
                DEBUG_SLEEP(printf(">>>>> MApp_GetSignalStatus()==SIGNAL_LOCK\n"));
                if (benableNoSiganlSleepCheck==TRUE)
                {
                    benableNoSiganlSleepCheck = FALSE;
                    //bSleepTimerCountDown = FALSE;
                }
            }
        }
        #if ENABLE_POWER_SAVING_DPMS
        else if(IsVgaInUse())
        {
            if(MApi_XC_PCMonitor_SyncLoss(MAIN_WINDOW))
            {
                if((u8VGANoSignalSleepCheck == UNKNOW)||(u8VGANoSignalSleepCheck == FALSE)
                    || (benableNoSiganlSleepCheck==FALSE) )
                {
                    u32NoSignal_MonitorStartTime = msAPI_Timer_GetTime0();
                    u32No_Signal_SleepTimeDur = (U32)NO_SIGNAL_VGA_SLEEP_TIMER;
                    benableNoSiganlSleepCheck = TRUE;
                    u8VGANoSignalSleepCheck =  TRUE;
					bIsCountWinShow = FALSE;
                }
            }
            #if (ENABLE_PIP)
            else if(IsPIPEnable())
            {
                if(MApi_XC_PCMonitor_SyncLoss(SUB_WINDOW))
                {
                    if((u8VGANoSignalSleepCheck == UNKNOW)||(u8VGANoSignalSleepCheck == FALSE)
                        || (benableNoSiganlSleepCheck==FALSE) )
                    {
                        u32NoSignal_MonitorStartTime = msAPI_Timer_GetTime0();
                        u32No_Signal_SleepTimeDur = (U32)NO_SIGNAL_VGA_SLEEP_TIMER;
                        benableNoSiganlSleepCheck = TRUE;
                        u8VGANoSignalSleepCheck =  TRUE;
                    }
                    else
                    {
                        if (benableNoSiganlSleepCheck==TRUE)
                        {
                            benableNoSiganlSleepCheck = FALSE;
                            u8VGANoSignalSleepCheck = FALSE;
                        }
                    }
                }
            }
            #endif
            else
            {
                if (benableNoSiganlSleepCheck==TRUE)
                {
                    benableNoSiganlSleepCheck = FALSE;
                    u8VGANoSignalSleepCheck = FALSE;
					bIsCountWinShow = FALSE;
					MApp_ZUI_ACT_ShutdownOSD();
                }
            }
        }
        #endif
        else if(IsAnalogSourceInUse())
        {
            if(MApi_XC_PCMonitor_SyncLoss(MAIN_WINDOW))
            {
                if (FALSE==benableNoSiganlSleepCheck)
                {
                    u32NoSignal_MonitorStartTime = msAPI_Timer_GetTime0();
                    u32No_Signal_SleepTimeDur = (U32)NO_SIGNAL_SLEEP_TIMER;
                    benableNoSiganlSleepCheck = TRUE;
					bIsCountWinShow = FALSE;
                }
            }
            #if (ENABLE_PIP)
            else if(IsPIPEnable())
            {
                if(MApi_XC_PCMonitor_SyncLoss(SUB_WINDOW))
                {
                    if (FALSE==benableNoSiganlSleepCheck)
                    {
                        u32NoSignal_MonitorStartTime = msAPI_Timer_GetTime0();
                        u32No_Signal_SleepTimeDur = (U32)NO_SIGNAL_SLEEP_TIMER;
                        benableNoSiganlSleepCheck = TRUE;
                    }
                }
                else
                {
                    if (benableNoSiganlSleepCheck==TRUE)
                    {
                        benableNoSiganlSleepCheck = FALSE;
                    }
                }
            }
            #endif
            else
            {
                if (benableNoSiganlSleepCheck==TRUE)
                {
                    benableNoSiganlSleepCheck = FALSE;
					bIsCountWinShow = FALSE;
					MApp_ZUI_ACT_ShutdownOSD();
                }
            }
        }
        else
        {
            if(MApp_VD_IsSyncLock()==FALSE)
            {
                if (FALSE==benableNoSiganlSleepCheck)
                {
                    u32NoSignal_MonitorStartTime = msAPI_Timer_GetTime0();
                    u32No_Signal_SleepTimeDur = (U32)NO_SIGNAL_SLEEP_TIMER;
                    benableNoSiganlSleepCheck = TRUE;
					bIsCountWinShow = FALSE;
                }
            }
            else
            {
                if (benableNoSiganlSleepCheck == TRUE)
                {
                    benableNoSiganlSleepCheck = FALSE;
					bIsCountWinShow = FALSE;
					MApp_ZUI_ACT_ShutdownOSD();
                }
            }
        }

        if (benableNoSiganlSleepCheck == TRUE)
        {

            U32 u32SleepTimerDiff = msAPI_Timer_DiffTimeFromNow(u32NoSignal_MonitorStartTime);
            DEBUG_SLEEP(printf("Enter >>>>>>> if (benableNoSiganlSleepCheck == TRUE) \n"));
            DEBUG_SLEEP(printf(" : u32SleepTimerDiff = %ld\n",u32SleepTimerDiff));
#if 1
			if((!IsVgaInUse() && u32SleepTimerDiff >= u32No_Signal_SleepTimeDur) || (IsVgaInUse() && u32SleepTimerDiff >= (u32No_Signal_SleepTimeDur-30000)))
			{
	#if 0
					if( MApp_ZUI_GetActiveOSD() == E_OSD_ATV_MANUAL_TUNING
						|| MApp_ZUI_GetActiveOSD() == E_OSD_AUTO_TUNING
            #if ENABLE_DTV
						|| MApp_ZUI_GetActiveOSD() == E_OSD_DTV_MANUAL_TUNING
            #endif
					   )
	#else
	        if(IsATVInUse() && (MApp_ZUI_GetActiveOSD() == E_OSD_MAIN_MENU) && msAPI_Tuner_IsTuningProcessorBusy())
	#endif
					{
						u32NoSignal_MonitorStartTime = msAPI_Timer_GetTime0()+1000;
						return;
					}

					if(bIsCountWinShow == FALSE)
					{
						enIndicateTimerSource = TS_TYPE_AUTOSLEEPTIMER;
						if(0)//IsStorageInUse())
						{
							if((bPlayingStateEnableOSD)/*&&(MApp_ZUI_GetActiveOSD() == E_OSD_DMP)*/)
							{
								MApp_ZUI_ACT_DmpShowCountDownWin();
								bIsCountWinShow=TRUE;	 //u8CoexistWinType = COWIN_ID_COUNT_DOWN_WIN;
								bPlayingStateEnableOSD = FALSE;
							}
							else
							{
								if(MApp_ZUI_GetActiveOSD() != E_OSD_DMP)
								{
									MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_CLOSE_CURRENT_OSD);
								}
								else
								{
									bPlayingStateEnableOSD = TRUE;
								}
							}
						}
						else
						{
						if(MApp_ZUI_GetActiveOSD() == E_OSD_MAIN_MENU ||MApp_ZUI_GetActiveOSD() == E_OSD_INPUT_SOURCE)
						{
							enMainMenuState = STATE_MENU_CLEAN_UP;
							enInputSourceState = STATE_INPUTSOURCE_CLEAN_UP;
						}
						else
						{
							if (MApp_ZUI_GetActiveOSD() != E_OSD_MESSAGE_BOX ||
							((MApp_ZUI_GetActiveOSD() == E_OSD_MESSAGE_BOX) && (MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_QUERY_IS_POWER_OFF_COUNTDOWN_MSG_BOX) == FALSE)))
							{
								MApp_ZUI_ACT_ShutdownOSD();
							}
                            bIsCountWinShow=TRUE; 
							MApp_ZUI_ACT_StartupOSD(E_OSD_MESSAGE_BOX);
							DEBUG_SLEEP(printf("\n EN_EXE_SHOW_POWER_OFF_COUNTDOWN_MSG_BOX\n"));
							MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_SHOW_POWER_OFF_COUNTDOWN_MSG_BOX);
						}
						}
					}
					else if(u8KeyCode != KEY_NULL)
					{
						if(IsStorageInUse())
						{
							bIsCountWinShow=FALSE;	  //u8CoexistWinType = COWIN_ID_NONE;
							MApp_ZUI_ACT_DmpHideCountDownWin();
						}
						else
						{
	#if 1
							DEBUG_SLEEP(printf("\n MApp_ZUI_ACT_ShutdownOSD \n"));
							bIsCountWinShow=FALSE;	  //u8CoexistWinType = COWIN_ID_NONE;
							MApp_ZUI_ACT_ShutdownOSD();
	#else
							MApp_ZUI_ACTcoexist_Delete();
							MApp_ZUI_ACTcoexistWin_Init();
	#endif
						}
						if(msAPI_AUD_IsAudioMutedByUser()) //redraw MUTE icon after close CountDown OSD
							MApp_UiMenu_MuteWin_Show();
						if(u8KeyCode != KEY_POWER)
						{
							u8KeyCode = KEY_NULL;
						}
						u32NoSignal_MonitorStartTime = msAPI_Timer_GetTime0();
						benableNoSiganlSleepCheck=FALSE;
						if(IsVgaInUse())
						u32No_Signal_SleepTimeDur = (U32)NO_SIGNAL_VGA_SLEEP_TIMER;
						else
						u32No_Signal_SleepTimeDur = (U32)NO_SIGNAL_SLEEP_TIMER;
						enIndicateTimerSource = TS_TYPE_NONE;
					}
					else if(bIsCountWinShow)	//else if(u8CoexistWinType == COWIN_ID_COUNT_DOWN_WIN)
					{
						if(IsStorageInUse())
						{
							MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_COUNTDOWN_PANEL);
						}
						else
						{
		#if 1
							DEBUG_SLEEP(printf("MApp_ZUI_API_InvalidateAllSuccessors  HWND_MSGBOX_COUNTDOWN here \n"));
							MApp_ZUI_API_InvalidateAllSuccessors(HWND_MSGBOX_COUNTDOWN);
		#else
							MApp_UiMenu_CountDownWin_Draw();
		#endif
						}
					}
				if ((!IsVgaInUse() && ((u32SleepTimerDiff - u32No_Signal_SleepTimeDur)>=60*1000)) || (IsVgaInUse() && (u32SleepTimerDiff >= u32No_Signal_SleepTimeDur)))
				{
					u8KeyCode  = KEY_POWER;
					enIndicateTimerSource = TS_TYPE_NONE;

        #if ENABLE_POWER_SAVING_DPMS
					if (IsVgaInUse())
					{
						g_bVGANoSignalPowerDown = TRUE;
						stPowerGenSetting.wPM_WakeUpDevice |= PM_WAKEUP_BY_VGA;
					}
					else if(IsHDMIInUse())
					stPowerGenSetting.wPM_WakeUpDevice |= PM_WAKEUP_BY_DVI; 
        #endif
					
					return;
				}
			}
				
#else
            if ( u32SleepTimerDiff >= u32No_Signal_SleepTimeDur )//60*10000)
            {
                DEBUG_SLEEP(printf("\n<<<<<<<<<<<<POWER OFF>>>>>>>>>>\n"));
                u8KeyCode = KEY_POWER;

#if ENABLE_POWER_SAVING_DPMS
                if (IsVgaInUse())
                    stPowerGenSetting.wPM_WakeUpDevice |= PM_WAKEUP_BY_VGA;
#endif
                if(IsHDMIInUse())
                    stPowerGenSetting.wPM_WakeUpDevice |= PM_WAKEUP_BY_DVI;
            }
#endif

        }

        u8SiganlStatusCheck_Count = 0;
    }
#endif // #if (NO_SIGNAL_AUTO_SHUTDOWN==1)
}

void MApp_Sleep_ReleaseSleepTimer()
{

#if (NO_SIGNAL_AUTO_SHUTDOWN==1)
    benableNoSiganlSleepCheck = FALSE;
#endif
    enSleepTimeState = STATE_SLEEP_OFF;
    benableSleepTimer=FALSE;
}

U32 MApp_Sleep_DisplayCountDownTimer()
{
    if(enIndicateTimerSource == TS_TYPE_SLEEPTIMER)
    {
        U32 u32SleepTimerDiff = msAPI_Timer_DiffTime(u32SleepTimer+u32SleepTimeDur, msAPI_Timer_GetTime0());
        return (60-(u32SleepTimerDiff/1000));
    }
    else if(enIndicateTimerSource  == TS_TYPE_OFFTIMER )
    {
    #if DTV_COUNT_DOWN_TIMER_PATCH
        return u8DTVCountDownTimer;
    #else
        U32 u32LocalOneDayTime = MApp_GetLocalSystemTime()%ONEDAY_TIME;
        U32 u32OffTimerDiff = msAPI_Timer_DiffTime(u32OffTimeDur+u32OffTimeFreeze, u32LocalOneDayTime);
        return u32OffTimerDiff;
    #endif
    }
    else if(enIndicateTimerSource  == TS_TYPE_AUTOSLEEPTIMER ) //smc.chy 2010/04/23
    {
        if(IsVgaInUse())
        {
		U32 u32AutoSleepTimerDiff = msAPI_Timer_DiffTime(u32NoSignal_MonitorStartTime+u32No_Signal_SleepTimeDur, msAPI_Timer_GetTime0());
		return ((u32AutoSleepTimerDiff/1000));
		}
		else
		{
        U32 u32AutoSleepTimerDiff = msAPI_Timer_DiffTime(u32NoSignal_MonitorStartTime+u32No_Signal_SleepTimeDur, msAPI_Timer_GetTime0());
        return (60-(u32AutoSleepTimerDiff/1000));
		}
    }
    return 0;
}

EN_SLEEP_TIME_STATE MApp_Sleep_GetCurrentSleepState()
{
    return enSleepTimeState;
}

void MApp_Sleep_SetCurrentSleepTime(U8 CurrentSleepTime)
{
    enSleepTimeState =(EN_SLEEP_TIME_STATE)(CurrentSleepTime -1);
    MApp_Sleep_SetTime();
}

U32 MApp_Sleep_GetSleepTimeRemainTime(void)
{
    U32 TimeRemain;
    U32 tmpTime;
    tmpTime = msAPI_Timer_GetTime0();

    if (tmpTime >= u32SleepTimer+u32SleepTimeDur)
        TimeRemain = 1;
    else
        TimeRemain=msAPI_Timer_DiffTime(u32SleepTimer+u32SleepTimeDur,tmpTime);

    if((TimeRemain%MINUTE_TO_MS)==0)
    {
        return (TimeRemain/MINUTE_TO_MS);
    }
    else
    {
        return (TimeRemain/MINUTE_TO_MS)+1;
    }
}

void MApp_Time_SetOnTime(void)
{
    ST_TIME _stTime;
    U32 u32WakeUpTime = 0;

    if (stGenSetting.g_Time.cOnTimerFlag == EN_Time_OnTimer_Off)
    {
        gWakeupSystemTime = RTC_DISABLE_VALUE;
    }
    else
    {
        MApp_ConvertSeconds2StTime(MApp_GetLocalSystemTime(),&_stTime);

        _stTime.u8Hour = (U8)stGenSetting.g_Time.u16OnTimer_Info_Hour;
        _stTime.u8Min = (U8)stGenSetting.g_Time.u16OnTimer_Info_Min;
        _stTime.u8Sec = (U8)stGenSetting.g_Time.u16OnTimer_Info_Sec;

        u32WakeUpTime = MApp_ConvertStTime2Seconds(&_stTime);

        MApp_SetLocalWakeUpTime(u32WakeUpTime);
    }
    //*******************************************************
}

U32 MApp_OnTime_GetNextWakeUpTime(void)
{
    ST_TIME _stTime;
    DAYOFWEEK _Today = SUN;
    U32 _u32NextDay = 0;
    U32 OnTime;

    if(stGenSetting.g_Time.cOnTimerFlag == EN_Time_OnTimer_Off)
    {
        return 0;
    }
    else
    {
        MApp_ConvertSeconds2StTime(MApp_GetLocalSystemTime(),&_stTime);

        _Today = (DAYOFWEEK)MApp_GetDayOfWeek(_stTime.u16Year, _stTime.u8Month, _stTime.u8Day);
        _stTime.u8Hour = (U8)stGenSetting.g_Time.u16OnTimer_Info_Hour;
        _stTime.u8Min = (U8)stGenSetting.g_Time.u16OnTimer_Info_Min;
        _stTime.u8Sec = (U8)stGenSetting.g_Time.u16OnTimer_Info_Sec;
        OnTime = MApp_ConvertStTime2Seconds(&_stTime);

        if(OnTime < MApp_GetLocalSystemTime()) //the time pass, find next day
        {
            switch(stGenSetting.g_Time.cOnTimerFlag)
            {
                default :
                case EN_Time_OnTimer_Off:
                    return 0;

                case EN_Time_OnTimer_Once:
                case EN_Time_OnTimer_Everyday:
                    _u32NextDay = SECONDS_PER_DAY;
                    break;

                case EN_Time_OnTimer_Mon2Fri:
                    switch(_Today)
                    {
                        case FRI:
                            _u32NextDay += SECONDS_PER_DAY*3; break;
                        case SAT:
                            _u32NextDay += SECONDS_PER_DAY*2; break;
                        default:
                            _u32NextDay += SECONDS_PER_DAY; break;
                    }
                    break;

                case EN_Time_OnTimer_Mon2Sat:
                    switch(_Today)
                    {
                        case SAT:
                            _u32NextDay += SECONDS_PER_DAY*2; break;
                        default:
                            _u32NextDay += SECONDS_PER_DAY; break;
                    }
                    break;

                case EN_Time_OnTimer_Sat2Sun:
                    switch(_Today)
                    {
                        case SUN: _u32NextDay += SECONDS_PER_DAY*6; break;
                        case MON: _u32NextDay += SECONDS_PER_DAY*5; break;
                        case TUE: _u32NextDay += SECONDS_PER_DAY*4; break;
                        case WED: _u32NextDay += SECONDS_PER_DAY*3; break;
                        case THU: _u32NextDay += SECONDS_PER_DAY*2; break;
                        case FRI:
                        case SAT:
                                  _u32NextDay += SECONDS_PER_DAY; break;
                        default: break;
                    }
                    break;

                case EN_Time_OnTimer_Sun:
                    switch(_Today)
                    {
                        case SUN: _u32NextDay += SECONDS_PER_DAY*7; break;
                        case MON: _u32NextDay += SECONDS_PER_DAY*6; break;
                        case TUE: _u32NextDay += SECONDS_PER_DAY*5; break;
                        case WED: _u32NextDay += SECONDS_PER_DAY*4; break;
                        case THU: _u32NextDay += SECONDS_PER_DAY*3; break;
                        case FRI: _u32NextDay += SECONDS_PER_DAY*2; break;
                        case SAT: _u32NextDay += SECONDS_PER_DAY;   break;
                        default: break;
                    }
                    break;
            }
        }
        else
        {
            switch(stGenSetting.g_Time.cOnTimerFlag)
            {
                default :
                case EN_Time_OnTimer_Off:
                    return 0;

                case EN_Time_OnTimer_Once:
                case EN_Time_OnTimer_Everyday:
                    _u32NextDay = 0;
                    break;

                case EN_Time_OnTimer_Mon2Fri:
                    switch(_Today)
                    {
                        case SAT:   _u32NextDay += SECONDS_PER_DAY*2; break;
                        case SUN:   _u32NextDay += SECONDS_PER_DAY; break;
                        default:
                            break;
                    }
                    break;

                case EN_Time_OnTimer_Mon2Sat:
                        if(_Today == SUN)
                            _u32NextDay += SECONDS_PER_DAY;
                        break;

                case EN_Time_OnTimer_Sat2Sun:
                        switch(_Today)
                        {
                            case MON:   _u32NextDay += SECONDS_PER_DAY*5; break;
                            case TUE:   _u32NextDay += SECONDS_PER_DAY*4; break;
                            case WED:   _u32NextDay += SECONDS_PER_DAY*3; break;
                            case THU:   _u32NextDay += SECONDS_PER_DAY*2; break;
                            case FRI:   _u32NextDay += SECONDS_PER_DAY; break;

                            default:
                                break;
                        }
                        break;

                case EN_Time_OnTimer_Sun:
                        switch(_Today)
                        {
                            case MON:   _u32NextDay += SECONDS_PER_DAY*6; break;
                            case TUE:   _u32NextDay += SECONDS_PER_DAY*5; break;
                            case WED:   _u32NextDay += SECONDS_PER_DAY*4; break;
                            case THU:   _u32NextDay += SECONDS_PER_DAY*3; break;
                            case FRI:   _u32NextDay += SECONDS_PER_DAY*2; break;
                            case SAT:   _u32NextDay += SECONDS_PER_DAY; break;
                            default:
                                        break;
                        }
                        break;
            }
        }
        return (OnTime+_u32NextDay);
    }
}

//************************************************************
// patameter : bEnable
//             0: disable timer
//             1: set timer by stGenSetting.g_Time
//************************************************************
void MApp_Sleep_SetOffTime(BOOLEAN bEnable)
{
    U8 u8Hour, u8Min,u8Sec;
    if(bEnable == FALSE)
    {
        benableOffTimer = STATE_SLEEP_OFFTIMER_OFF;
        return;
    }

    if (stGenSetting.g_Time.cOffTimerFlag == EN_Time_OffTimer_Off)
    {
        benableOffTimer = STATE_SLEEP_OFFTIMER_OFF;
    }
    else
    {
        benableOffTimer = STATE_SLEEP_OFFTIMER_ON;
    }

    u8Hour = stGenSetting.g_Time.u16OffTimer_Info_Hour;
    u8Min = stGenSetting.g_Time.u16OffTimer_Info_Min;
    u8Sec = stGenSetting.g_Time.u16OffTimer_Info_Sec;
    if((u8Hour == 0)&&(u8Min == 0))
    {
        u32OffTimeDur = ONEDAY_TIME - 1;;
    }
    else
    {
        u32OffTimeDur = ((U32)u8Hour*60 + u8Min) * MINUTE_TO_S + u8Sec;
    }

    bSkipCountdown = FALSE;
}

void MApp_Sleep_TransitOffTime(void)
{

    if(stGenSetting.g_Time.cOffTimerFlag == EN_Time_OffTimer_Once)
    {
        stGenSetting.g_Time.cOffTimerFlag = EN_Time_OffTimer_Off;
        benableOffTimer= STATE_SLEEP_OFFTIMER_OFF;
    }
    else
    {
        benableOffTimer = STATE_SLEEP_OFFTIMER_TRANSIT;
    }
}

void MApp_Sleep_SetAutoOn_OffTime(BOOLEAN bEnable)
{
    if(bEnable)
    {
        benableAutoOn_OffTimer = TRUE;
        u32AutoOnTime =msAPI_Timer_GetTime0();
    }
    else
    {
        benableAutoOn_OffTimer = FALSE;
    }
}


void MApp_NoSignal_SetAutoSleep(BOOLEAN benable)
{
    benableNoSignalAutoSleep = benable;
}

U8 MApp_GetSleepIndexTime(EN_SLEEP_TIME_STATE SleepIndex)
{
    return au8SleepTimeCoef[SleepIndex] * 10;
}

EN_SLEEP_TIME_STATE MApp_GetCurSleepTime(BOOLEAN bDecInc)
{
    EN_SLEEP_TIME_STATE i;
    U8 TimeRemain;

    if(MApp_Sleep_GetCurrentSleepState() != STATE_SLEEP_OFF)
    {
        TimeRemain = MApp_Sleep_GetSleepTimeRemainTime();

        for(i = STATE_SLEEP_OFF; i < STATE_SLEEP_TOTAL; i++)
        {
            if(TimeRemain <= (au8SleepTimeCoef[i] * 10))
            {
                if((TimeRemain < (au8SleepTimeCoef[i] * 10)) && (i>0) && bDecInc)
                    i--;

                return (i);
            }
        }
    }
    else
        return STATE_SLEEP_OFF;

    return STATE_SLEEP_120MIN;

}

#if 0 //non-used
void MApp_Timer_SetElapsedTimer(void)
{
    //printf("g_u16ElapsedTimeSecond %u\n", g_u16ElapsedTimeSecond );
    // TODO:
}
#endif

BOOLEAN MApp_OffTime_IsOffTimeInDayOfWeek(void)
{
    ST_TIME _stTime;
    DAYOFWEEK eDayOfWeek;

    MApp_ConvertSeconds2StTime(MApp_GetLocalSystemTime(),&_stTime);
    eDayOfWeek = (DAYOFWEEK)MApp_GetDayOfWeek(_stTime.u16Year, _stTime.u8Month, _stTime.u8Day);

    switch( stGenSetting.g_Time.cOffTimerFlag)
    {
        case EN_Time_OffTimer_Once:
        case EN_Time_OffTimer_Everyday:
        return TRUE;
        case EN_Time_OffTimer_Mon2Fri:
            if(eDayOfWeek > SUN && eDayOfWeek <= FRI)
        return TRUE;
        break;
        case EN_Time_OffTimer_Mon2Sat:
            if(eDayOfWeek > MON && eDayOfWeek <= SAT)
        return TRUE;
        break;
        case EN_Time_OffTimer_Sat2Sun:
            if( eDayOfWeek == SAT || eDayOfWeek == SUN )
        return TRUE;
         break;
        case EN_Time_OffTimer_Sun:
            if( eDayOfWeek == SUN )
        return TRUE;
         break;
        default:
        return FALSE;
    }
    return FALSE;
}

void MApp_Sleep_SendKeyOffTimeDayOfWeek(void)
{
    ST_TIME _stTime;
    DAYOFWEEK eDayOfWeek;

    MApp_ConvertSeconds2StTime(MApp_GetLocalSystemTime(),&_stTime);
    eDayOfWeek = (DAYOFWEEK)MApp_GetDayOfWeek(_stTime.u16Year, _stTime.u8Month, _stTime.u8Day);

    switch( stGenSetting.g_Time.cOffTimerFlag)
    {
    case EN_Time_OffTimer_Once:
        MApp_Sleep_SetOffTime(FALSE);
        stGenSetting.g_Time.cOffTimerFlag = EN_Time_OffTimer_Off;
        benableOffTimer = STATE_SLEEP_OFFTIMER_OFF;
        u32OffTimeDur = 0xffffffff;
        u8KeyCode = KEY_POWER;
        break;

    case EN_Time_OffTimer_Everyday:
        u32OffTimeDur = 0xffffffff;
        u8KeyCode = KEY_POWER;
        break;

    case EN_Time_OffTimer_Mon2Fri:
        if(eDayOfWeek > SUN && eDayOfWeek <= FRI)
        {
            u32OffTimeDur = 0xffffffff;
            u8KeyCode = KEY_POWER;
        }
        break;

    case EN_Time_OffTimer_Mon2Sat:
        if(eDayOfWeek > MON && eDayOfWeek <= SAT)
        {
            u32OffTimeDur = 0xffffffff;
            u8KeyCode = KEY_POWER;
        }
        break;

    case EN_Time_OffTimer_Sat2Sun:
        if( eDayOfWeek == SAT || eDayOfWeek == SUN )
        {
            u32OffTimeDur = 0xffffffff;
            u8KeyCode = KEY_POWER;
        }
        break;

    case EN_Time_OffTimer_Sun:
        if( eDayOfWeek == SUN )
        {
            u32OffTimeDur = 0xffffffff;
            u8KeyCode = KEY_POWER;
        }
        break;

    default:
        break;
    }
}

#if ((ENABLE_DTV_EPG) && (OBA2!=1) && (ENABLE_OAD))
static int MApp_TimeCompare(const void *a,const void *b)
{
    if (*(U32*)a<*(U32*)b)
    {
        return -1;
    }
    else if (*(U32*)a==*(U32*)b)
    {
        return 0 ;
    }
    else
    {
        return 1 ;
    }
}
#endif

void MApp_InitRtcWakeUpTimer(void)
{
#if ((ENABLE_DTV_EPG) && (OBA2!=1) && (ENABLE_OAD))//ENABLE_DTV

    #define ARRAYSIZE 3

    U32 RTCtimer,timeArray[ARRAYSIZE],j;

    timeArray[0] = MApp_GetEpgManualTimerStartDate();
    timeArray[1] = MApp_OnTime_GetNextWakeUpTime();
    timeArray[2] = MApp_OAD_GetScheduleStart() ;

    qsort(timeArray,ARRAYSIZE,4,MApp_TimeCompare) ;

    RTCtimer = 0 ;

    for (j=0;j<ARRAYSIZE;j++)
    {
       if (timeArray[j]>0)
       {
          RTCtimer = timeArray[j] ;
          break ;
       }
    }

    if(RTCtimer > 0)
    {
        MApp_SetLocalWakeUpTime(RTCtimer);
        msAPI_Timer_EnableRTCWakeUp(TRUE);
    }
    else
    {
        MApp_SetLocalWakeUpTime(RTC_DISABLE_VALUE);
        msAPI_Timer_EnableRTCWakeUp(FALSE);
    }

#else
    U32 RTCtimer = MApp_OnTime_GetNextWakeUpTime();
    if(RTCtimer > 0)
    {
        MApp_SetLocalWakeUpTime(RTCtimer);
        msAPI_Timer_EnableRTCWakeUp(TRUE);
    }
    else
    {
        MApp_SetLocalWakeUpTime(RTC_DISABLE_VALUE);
        msAPI_Timer_EnableRTCWakeUp(FALSE);
    }
#endif
}


void MApp_Time_Tasks_Set_RTC_NextWakeUpTime(void)
{
    ST_TIME _stTime;
    DAYOFWEEK _Today = SUN;
    U32 _u32NextDay = 0;
    BOOLEAN _bEnableWakeUp = TRUE;

    if (stGenSetting.g_Time.cOnTimerFlag != EN_Time_OnTimer_Off)
    {
        MApp_ConvertSeconds2StTime(MApp_GetLocalSystemTime(),&_stTime);

        _Today = (DAYOFWEEK)MApp_GetDayOfWeek(_stTime.u16Year, _stTime.u8Month, _stTime.u8Day);
        _stTime.u8Hour = (U8)stGenSetting.g_Time.u16OnTimer_Info_Hour;
        _stTime.u8Min = (U8)stGenSetting.g_Time.u16OnTimer_Info_Min;
        _stTime.u8Sec = (U8)stGenSetting.g_Time.u16OnTimer_Info_Sec;

        if (MApp_GetLocalWakeUpTime() < MApp_GetLocalSystemTime())
        {
            switch(stGenSetting.g_Time.cOnTimerFlag)
            {
                default :
                case EN_Time_OnTimer_Off:
                        _bEnableWakeUp = FALSE;
                        break;

                case EN_Time_OnTimer_Once:
                case EN_Time_OnTimer_Everyday:
                        _u32NextDay = SECONDS_PER_DAY;
                        break;

                case EN_Time_OnTimer_Mon2Fri:
                        switch(_Today)
                        {
                            case FRI: _u32NextDay += SECONDS_PER_DAY;
                            case SAT: _u32NextDay += SECONDS_PER_DAY;
                            default:
                                      _u32NextDay += SECONDS_PER_DAY;
                                    break;
                        }
                        break;

                case EN_Time_OnTimer_Mon2Sat:
                        switch(_Today)
                        {
                            case SAT: _u32NextDay += SECONDS_PER_DAY;
                            default:
                                      _u32NextDay += SECONDS_PER_DAY;
                                    break;
                        }
                        break;

                case EN_Time_OnTimer_Sat2Sun:
                        switch(_Today)
                        {
                            case SUN: _u32NextDay += SECONDS_PER_DAY;
                            case MON: _u32NextDay += SECONDS_PER_DAY;
                            case TUE: _u32NextDay += SECONDS_PER_DAY;
                            case WED: _u32NextDay += SECONDS_PER_DAY;
                            case THU: _u32NextDay += SECONDS_PER_DAY;
                            case FRI:
                            case SAT:
                                      _u32NextDay += SECONDS_PER_DAY;
                            default:
                                    break;
                        }
                        break;

                case EN_Time_OnTimer_Sun:
                        switch(_Today)
                        {
                            case SUN: _u32NextDay += SECONDS_PER_DAY;
                            case MON: _u32NextDay += SECONDS_PER_DAY;
                            case TUE: _u32NextDay += SECONDS_PER_DAY;
                            case WED: _u32NextDay += SECONDS_PER_DAY;
                            case THU: _u32NextDay += SECONDS_PER_DAY;
                            case FRI: _u32NextDay += SECONDS_PER_DAY;
                            case SAT: _u32NextDay += SECONDS_PER_DAY;
                            default:
                                    break;
                        }
                        break;
            }
            if (_u32NextDay != 0 )
            {
                MApp_SetLocalWakeUpTime(MApp_ConvertStTime2Seconds(&_stTime)+_u32NextDay);
                msAPI_Timer_EnableRTCWakeUp(_bEnableWakeUp);
            }
        }

        if (MApp_GetLocalWakeUpTime() > MApp_GetLocalSystemTime())
        {
            _u32NextDay = 0;

            switch(stGenSetting.g_Time.cOnTimerFlag)
            {
                default :
                case EN_Time_OnTimer_Off:
                        _bEnableWakeUp = FALSE;
                        break;

                case EN_Time_OnTimer_Once:
                        break;

                case EN_Time_OnTimer_Everyday:
                        break;

                case EN_Time_OnTimer_Mon2Fri:
                        switch(_Today)
                        {
                            case SAT:   _u32NextDay += SECONDS_PER_DAY;
                            case SUN:   _u32NextDay += SECONDS_PER_DAY;
                            default:
                                        break;
                        }
                        break;

                case EN_Time_OnTimer_Mon2Sat:
                        if (_Today == SUN)
                        {
                            _u32NextDay += SECONDS_PER_DAY;
                        }
                        break;

                case EN_Time_OnTimer_Sat2Sun:
                        switch(_Today)
                        {
                            case MON:   _u32NextDay += SECONDS_PER_DAY;
                            case TUE:   _u32NextDay += SECONDS_PER_DAY;
                            case WED:   _u32NextDay += SECONDS_PER_DAY;
                            case THU:   _u32NextDay += SECONDS_PER_DAY;
                            case FRI:   _u32NextDay += SECONDS_PER_DAY;
                            default:
                                        break;
                        }
                        break;

                case EN_Time_OnTimer_Sun:
                        switch(_Today)
                        {
                            case MON:   _u32NextDay += SECONDS_PER_DAY;
                            case TUE:   _u32NextDay += SECONDS_PER_DAY;
                            case WED:   _u32NextDay += SECONDS_PER_DAY;
                            case THU:   _u32NextDay += SECONDS_PER_DAY;
                            case FRI:   _u32NextDay += SECONDS_PER_DAY;
                            case SAT:   _u32NextDay += SECONDS_PER_DAY;
                            default:
                                        break;
                        }
                        break;
            }

            if (_u32NextDay != 0 )
            {
                MApp_SetLocalWakeUpTime(MApp_ConvertStTime2Seconds(&_stTime)+_u32NextDay);
                msAPI_Timer_EnableRTCWakeUp(_bEnableWakeUp);
            }
        }
    }
}


void MApp_SleepSetWinShow(void)
{
 bIsCountWinShow = FALSE;
}
#undef MAPP_SLEEP_C

