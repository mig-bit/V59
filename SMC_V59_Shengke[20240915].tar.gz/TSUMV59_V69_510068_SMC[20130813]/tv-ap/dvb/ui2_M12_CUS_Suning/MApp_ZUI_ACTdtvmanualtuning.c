////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#define MAPP_ZUI_ACTDTVMANUALTUNING_C
#define _ZUI_INTERNAL_INSIDE_ //NOTE: for ZUI internal
#if ENABLE_DTV

//-------------------------------------------------------------------------------------------------
// Include Files
//-------------------------------------------------------------------------------------------------
#include <stdio.h>
#include <string.h>
#include "Board.h"
#include "datatype.h"
#include "MsCommon.h"
#include "apiXC.h"
#include "apiXC_Adc.h"
#include "MApp_GlobalSettingSt.h"

#include "MApp_ZUI_Main.h"
#include "MApp_ZUI_APIcommon.h"
#include "MApp_ZUI_APIstrings.h"
#include "MApp_ZUI_APIwindow.h"
#include "ZUI_tables_h.inl"
#include "MApp_ZUI_APIgdi.h"
#include "MApp_ZUI_APIcontrols.h"
#include "MApp_ZUI_APIdraw.h"
#include "MApp_ZUI_ACTeffect.h"
#include "MApp_ZUI_ACTglobal.h"
#include "OSDcp_String_EnumIndex.h"
#include "OSDcp_Bitmap_EnumIndex.h"
#include "ZUI_exefunc.h"
#include "MApp_SignalMonitor.h"
#include "MApp_DTV_ManualTuning_Main.h"
#include "MApp_SaveData.h"
#include "msAPI_FreqTableDTV.h"
#include "msAPI_Timer.h"
#include "mapp_demux.h"
#include "MApp_ChannelChange.h"
#include "MApp_TopStateMachine.h"
#include "MApp_Menu_Main.h"
#include "MApp_TV.h"
#include "MApp_InputSource.h"

/////////////////////////////////////////////////////////////////////

#if ENABLE_SBTVD_BRAZIL_APP
extern E_ANTENNA_SOURCE_TYPE enLastWatchAntennaType;
#endif
extern EN_DTV_MANUALTUNING_STATE enDtvManualTuningState;
extern U8                u8RFCh;
static EN_DTV_MANUALTUNING_STATE _enTargetDtvManualTuningState;

extern BOOLEAN MApp_CharTable_GetServiceNameToUCS2(MEMBER_SERVICETYPE bServiceType, WORD wPosition, WORD * bChannelName, U8 ControlCodes);


//*************************************************************************
//              Defines
//*************************************************************************
typedef enum
{
    DTV_MANUAL_TUNING_COMMAND_INIT,
    DTV_MANUAL_TUNING_COMMAND_UP,
    DTV_MANUAL_TUNING_COMMAND_DOWN,
} EN_DTV_MANUAL_TUNING_COMMAND_TYPE;

typedef struct _MENU_KEY2BTN_STRUCT
{
    VIRTUAL_KEY_CODE key;
    HWND hwnd;
} MENU_KEY2BTN_STRUCT;

/********************************************************************************/
/*                    Macro                                                     */
/********************************************************************************/
#define DTV_MANUAL_TUNING_DBINFO(y)    //y

extern BOOLEAN _MApp_ZUI_API_AllocateVarData(void);

/********************************************************************************/
/*                      Local                                                   */
/********************************************************************************/
#define MANUAL_SCAN_MONITOR_DURATION 1000

S32 MApp_ZUI_ACT_DtvManualTuningWinProc(HWND hwnd, PMSG msg)
{
    switch(msg->message)
    {
        case MSG_CREATE:
            {
                MApp_ZUI_API_SetTimer(HWND_DTUNE_SCAN_RESULT_NO_SIGNAL_BTN, 0, MANUAL_SCAN_MONITOR_DURATION);
                MApp_ZUI_API_SetTimer(HWND_DTUNE_SIGNAL_BG, 1, MANUAL_SCAN_MONITOR_DURATION);
            }
            break;

        case MSG_TIMER:
            {
                switch(msg->wParam)
                {
                    case 0:
                        MApp_ZUI_API_ShowWindow(HWND_DTUNE_SCAN_RESULT_TXT, SW_HIDE);
                        MApp_ZUI_API_ShowWindow(HWND_DTUNE_SCAN_RESULT_SEARCHING_TXT, SW_HIDE);
                        MApp_ZUI_API_ShowWindow(HWND_DTUNE_SCAN_ENTERKEY_REMIND_TXT, SW_HIDE);
                        if(g_LockStatus == FALSE)
                        {
                            MApp_ZUI_API_ShowWindow(hwnd, SW_SHOW);
                        }
                        else
                        {
                            MApp_ZUI_API_ShowWindow(hwnd, SW_HIDE);
                            MApp_ZUI_API_ShowWindow(HWND_DTUNE_SCAN_ENTERKEY_REMIND_TXT, SW_SHOW);
                        }
                        break;
                    case 1:
                        MApp_ZUI_API_InvalidateWindow(hwnd);
                        break;
                    default:
                        MApp_ZUI_API_InvalidateWindow(hwnd);
                        break;
                }
            }
            break;

        default:
            break;

    }
    return DEFAULTWINPROC(hwnd, msg);

}

static void _MApp_ZUI_ACT_ChangeChannel(void)
{
    MS_TP_SETTING stTempTP;

    if(IsDTVInUse())
    {
        //disable current channel & talbe monitor
        MApp_ChannelChange_DisableChannel(TRUE, MAIN_WINDOW);
        MApp_Dmx_DisableTableMonitor();
        MApp_Dmx_CloseAllFilters();

        // change FN
        if( msAPI_DFT_GetTSSetting(stGenSetting.stScanMenuSetting.u8RFChannelNumber, &stTempTP) == TRUE)
            msAPI_Tuner_Tune2RfCh(&stTempTP);
    }
}

BOOLEAN MApp_ZUI_ACT_ExecuteDtvManualTuningAction(U16 act)
{
    switch(act)
    {
        case EN_EXE_POWEROFF:
            MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
            _enTargetDtvManualTuningState = STATE_DTV_MANUALTUNING_GOTO_STANDBY;
            return TRUE;


        case EN_EXE_CLOSE_CURRENT_OSD:
        case EN_EXE_GOTO_MAINMENU:
            MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);

            if(act == EN_EXE_CLOSE_CURRENT_OSD)
            {
                _enTargetDtvManualTuningState = STATE_DTV_MANUALTUNING_CLEAN_UP;
            }
            else
            {
                _enTargetDtvManualTuningState = STATE_DTV_MANUALTUNING_GOTO_MAIN_MENU;
            }

            stGenSetting.stScanMenuSetting.u8PreRFChannelNumber = stGenSetting.stScanMenuSetting.u8RFChannelNumber;

            return TRUE;

        case EN_EXE_GET_PREV_CHANNEL:
            stGenSetting.stScanMenuSetting.u8RFChannelNumber = msAPI_DFT_GetPrevPhysicalChannelNumber(stGenSetting.stScanMenuSetting.u8RFChannelNumber);
            if( INVALID_PHYSICAL_CHANNEL_NUMBER == stGenSetting.stScanMenuSetting.u8RFChannelNumber )
            {
               stGenSetting.stScanMenuSetting.u8RFChannelNumber = MAX_PHYSICAL_CHANNEL_NUMBER;
            }
			#ifndef HISENSE_OSD_STYLE
            _MApp_ZUI_ACT_ChangeChannel();
			#endif
            MApp_ZUI_API_InvalidateWindow(HWND_DTUNE_MANUAL_SCAN_CHANNEL_NAME_TXT);
            MApp_ZUI_API_InvalidateWindow(HWND_DTUNE_MANUAL_SCAN_UFH_TXT);
            MApp_ZUI_API_ShowWindow(HWND_DTUNE_SCAN_RESULT_TXT, SW_HIDE);
            MApp_ZUI_API_SetTimer(HWND_DTUNE_SCAN_RESULT_NO_SIGNAL_BTN, 0, MANUAL_SCAN_MONITOR_DURATION);
            return TRUE;
        case EN_EXE_GET_NEXT_CHANNEL:
            stGenSetting.stScanMenuSetting.u8RFChannelNumber = msAPI_DFT_GetNextPhysicalChannelNumber(stGenSetting.stScanMenuSetting.u8RFChannelNumber);
            if( INVALID_PHYSICAL_CHANNEL_NUMBER == stGenSetting.stScanMenuSetting.u8RFChannelNumber )
            {
                stGenSetting.stScanMenuSetting.u8RFChannelNumber = msAPI_DFT_GetFirstPhysicalChannelNumber();
            }
			#ifndef HISENSE_OSD_STYLE
            _MApp_ZUI_ACT_ChangeChannel();
			#endif

            MApp_ZUI_API_InvalidateWindow(HWND_DTUNE_MANUAL_SCAN_CHANNEL_NAME_TXT);
            MApp_ZUI_API_InvalidateWindow(HWND_DTUNE_MANUAL_SCAN_UFH_TXT);
            MApp_ZUI_API_ShowWindow(HWND_DTUNE_SCAN_RESULT_TXT, SW_HIDE);
            MApp_ZUI_API_SetTimer(HWND_DTUNE_SCAN_RESULT_NO_SIGNAL_BTN, 0, MANUAL_SCAN_MONITOR_DURATION);
            return TRUE;
        case EN_EXE_MANUAL_SCAN_CHANGE_RF:
            enDtvManualTuningState = STATE_DTV_MANUALTUNING_GOTO_DTV_SCAN;
            u16ScanDtvChNum = 0;
            u16ScanRadioChNum = 0;
            #if NORDIG_FUNC //for Nordig Spec v2.0
            u16ScanDataChNum = 0;
            #endif

            stGenSetting.stScanMenuSetting.u8ScanType=SCAN_TYPE_MANUAL;
            MApp_ZUI_API_KillTimer(HWND_DTUNE_SCAN_RESULT_NO_SIGNAL_BTN, 0);
            MApp_ZUI_API_KillTimer(HWND_DTUNE_BG_PANE, 0);
            MApp_ZUI_API_ShowWindow(HWND_DTUNE_SCAN_RESULT_NO_SIGNAL_BTN, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_DTUNE_SCAN_RESULT_DTV_TXT, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_DTUNE_SCAN_RESULT_RADIO_TXT, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_DTUNE_SCAN_RESULT_DATA_TXT, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_DTUNE_SCAN_ENTERKEY_REMIND_TXT, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_DTUNE_SCAN_RESULT_SEARCHING_TXT, SW_SHOW);
            return TRUE;
        case EN_EXE_DTV_MANUAL_SCAN_END:
#if NORDIG_FUNC //for Nordig Spec v2.0
            if((!u16ScanDtvChNum)&&(!u16ScanRadioChNum)&&(!u16ScanDataChNum))
#else
            if((!u16ScanDtvChNum)&&(!u16ScanRadioChNum))
#endif
            {
                MApp_ZUI_API_SetTimer(HWND_DTUNE_SCAN_RESULT_NO_SIGNAL_BTN, 0, MANUAL_SCAN_MONITOR_DURATION);
            }
            MApp_ZUI_API_SetTimer(HWND_DTUNE_BG_PANE, 0, DTV_MANUAL_SCAN_END_TIME_OUT_MS);
            MApp_ZUI_API_ShowWindow(HWND_DTUNE_SCAN_RESULT_SEARCHING_TXT, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_DTUNE_SCAN_ENTERKEY_REMIND_TXT, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_DTUNE_SCAN_RESULT_TXT, SW_SHOW);
#if !NORDIG_FUNC //for Nordig Spec v2.0
            MApp_ZUI_API_ShowWindow(HWND_DTUNE_SCAN_RESULT_DATA_TXT, SW_HIDE);
#endif
            return TRUE;


    case EN_EXE_MANUAL_SCAN_NUMBERKEY_0:
    case EN_EXE_MANUAL_SCAN_NUMBERKEY_1:
    case EN_EXE_MANUAL_SCAN_NUMBERKEY_2:
    case EN_EXE_MANUAL_SCAN_NUMBERKEY_3:
    case EN_EXE_MANUAL_SCAN_NUMBERKEY_4:
    case EN_EXE_MANUAL_SCAN_NUMBERKEY_5:
    case EN_EXE_MANUAL_SCAN_NUMBERKEY_6:
    case EN_EXE_MANUAL_SCAN_NUMBERKEY_7:
    case EN_EXE_MANUAL_SCAN_NUMBERKEY_8:
    case EN_EXE_MANUAL_SCAN_NUMBERKEY_9:
        {
            BOOLEAN eRes;
            MS_TP_SETTING stTPSetting;
            MApp_ChannelChange_DisableChannel(TRUE, MAIN_WINDOW);
            MApp_Dmx_DisableTableMonitor();

            u16ScanDtvChNum = 0;
            u16ScanRadioChNum = 0;
#if NORDIG_FUNC //for Nordig Spec v2.0
            u16ScanDataChNum = 0;
#endif
            u16IdleInputValue = u16IdleInputValue * 10 + (act - EN_EXE_MANUAL_SCAN_NUMBERKEY_0);
            u8IdleDigitCount++;
            if (u8IdleDigitCount >= 2)
            {

                eRes = msAPI_DFT_GetTSSetting((U8)u16IdleInputValue, &stTPSetting);
                if ( eRes != TRUE )
                {
                    msAPI_Timer_Delayms(500);
                    u8IdleDigitCount = 0;
                }
                else
                {
                    stGenSetting.stScanMenuSetting.u8RFChannelNumber = u16IdleInputValue;
                }
                _MApp_ZUI_ACT_ChangeChannel();
                u16IdleInputValue = 0;
                u8IdleDigitCount = 0;
            }
        }
        MApp_ZUI_API_InvalidateWindow(HWND_DTUNE_MANUAL_SCAN_CHANNEL_NAME_TXT);
        MApp_ZUI_API_InvalidateWindow(HWND_DTUNE_MANUAL_SCAN_UFH_TXT);
        MApp_ZUI_API_ShowWindow(HWND_DTUNE_SCAN_RESULT_TXT, SW_HIDE);
        MApp_ZUI_API_SetTimer(HWND_DTUNE_SCAN_RESULT_NO_SIGNAL_BTN, 0, MANUAL_SCAN_MONITOR_DURATION);
        return TRUE;

    }
    return FALSE;
}

void MApp_ZUI_ACT_TerminateDtvManualTuning(void)
{
    ZUI_MSG(printf("[]term:dtv manual tuning\n"));
    enDtvManualTuningState = _enTargetDtvManualTuningState;
}

BOOLEAN MApp_ZUI_ACT_HandleDtvManualTuningKey(VIRTUAL_KEY_CODE key)
{
    //reset timer if any key
    MApp_ZUI_API_ResetTimer(HWND_DTUNE_BG_PANE, 0);

    switch(key)
    {
        case VK_EXIT:
            MApp_ZUI_ACT_ExecuteDtvManualTuningAction(EN_EXE_CLOSE_CURRENT_OSD);
            return TRUE;
        case VK_POWER:
            MApp_ZUI_ACT_ExecuteDtvManualTuningAction(EN_EXE_POWEROFF);
            return TRUE;
        case VK_MENU:
            MApp_ZUI_ACT_ExecuteDtvManualTuningAction(EN_EXE_GOTO_MAINMENU);
            _enReturnMenuItem = STATE_RETURN_DTV_MANUAL_TUNING;
            return TRUE;

        default:
            break;

    }
    return FALSE;
}

LPTSTR MApp_ZUI_ACT_GetDtvManualTuningDynamicText(HWND hwnd)
{
    // Marked it by coverity_297
    //U16 u16TempID = Empty;
    switch(hwnd)
    {
        case HWND_DTUNE_MANUAL_SCAN_UFH_TXT:
            {
                LPTSTR str = CHAR_BUFFER;
                U8 u8Index;

                u8Index = 0;
                if(((21 <= stGenSetting.stScanMenuSetting.u8RFChannelNumber )&& (stGenSetting.stScanMenuSetting.u8RFChannelNumber <= 69 )&&(MApp_TopStateMachine_GetTopState() != STATE_TOP_DTV_SCAN))
                    ||((21 <= u8RFCh)&&(u8RFCh <= 69)&&(MApp_TopStateMachine_GetTopState() == STATE_TOP_DTV_SCAN)))
                {
                    str[u8Index++] = CHAR_U;
                    str[u8Index++] = CHAR_H;
                    str[u8Index++] = CHAR_F;
                }
                else
                {
                    str[u8Index++] = CHAR_V;
                    str[u8Index++] = CHAR_H;
                    str[u8Index++] = CHAR_F;
                }
                str[u8Index++] = CHAR_SPACE;
                str[u8Index++] = CHAR_SPACE;
                str[u8Index++] = CHAR_C;
                str[u8Index++] = CHAR_H;
                str[u8Index] = 0;
                return CHAR_BUFFER;
            }
            break;

        case HWND_DTUNE_MANUAL_SCAN_CHANNEL_NAME_TXT:
            {
                U8 RFChannelName[4];
                LPTSTR str = CHAR_BUFFER;
                U8 u8Index;
                //U8 u8NoOfDigit;
                u8Index = 0;
                str[u8Index] = 0;
                if (u8IdleDigitCount == 0)
                {
                    if(TRUE == msAPI_DFT_GetPhysicalChannelName((stGenSetting.stScanMenuSetting.u8RFChannelNumber),RFChannelName,4))
                    {
                        str[u8Index++] = (U16)RFChannelName[0];
                        str[u8Index++] = (U16)RFChannelName[1];
                        str[u8Index++] = (U16)RFChannelName[2];
                        str[u8Index++] = (U16)RFChannelName[3];
                        str[u8Index++] = 0;
                    }

                }
                else if (u8IdleDigitCount == 1)
                {
                    MApp_ZUI_API_GetU16String(u16IdleInputValue);
                    CHAR_BUFFER[1] = CHAR_MINUS;
                    CHAR_BUFFER[2] = 0;
                }
                else if (u8IdleDigitCount == 2)
                {
                    return MApp_ZUI_API_GetU16String(stGenSetting.stScanMenuSetting.u8RFChannelNumber);

                }
                else
                {
                    CHAR_BUFFER[0] = 0;
                }
                return CHAR_BUFFER;
            }
            break;

        case HWND_DTUNE_SCAN_RESULT_DTV_NUMBER_TXT:
            return MApp_ZUI_API_GetU16String(u16ScanDtvChNum);

        case HWND_DTUNE_SCAN_RESULT_RADIO_NUMBER_TXT:
            return MApp_ZUI_API_GetU16String(u16ScanRadioChNum);

#if NORDIG_FUNC //for Nordig Spec v2.0
        case HWND_DTUNE_SCAN_RESULT_DATA_NUMBER_TXT:
            return MApp_ZUI_API_GetU16String(u16ScanDataChNum);
#endif

    }

    //if (u16TempID != Empty)
    //    return MApp_ZUI_API_GetString(u16TempID);
    return 0; //for empty string....
}

S16 MApp_ZUI_ACT_GetDtvManualTuningDynamicValue(HWND hwnd)
{
    switch(hwnd)
    {
        case HWND_DTUNE_SIGNAL_BAR:
            return g_CurSignalStrength;
    }

    return 0; //for empty  data
}

void MApp_ZUI_ACT_AppShowDtvManualTuning(void)
{
    HWND wnd;
    RECT rect;
    E_OSD_ID osd_id = E_OSD_DTV_MANUAL_TUNING;

    g_GUI_WindowList = GetWindowListOfOsdTable(osd_id);
    g_GUI_WinDrawStyleList = GetWindowStyleOfOsdTable(osd_id);
    g_GUI_WindowPositionList = GetWindowPositionOfOsdTable(osd_id);
#if ZUI_ENABLE_ALPHATABLE
    g_GUI_WinAlphaDataList = GetWindowAlphaDataOfOsdTable(osd_id);
#endif
    HWND_MAX = GetWndMaxOfOsdTable(osd_id);
    OSDPAGE_BLENDING_ENABLE = IsBlendingEnabledOfOsdTable(osd_id);
    OSDPAGE_BLENDING_VALUE = GetBlendingValueOfOsdTable(osd_id);

    if( msAPI_CM_GetPhysicalChannelNumber(msAPI_CM_GetCurrentServiceType(), msAPI_CM_GetCurrentPosition(msAPI_CM_GetCurrentServiceType())) != INVALID_PHYSICAL_CHANNEL_NUMBER )
        stGenSetting.stScanMenuSetting.u8RFChannelNumber = msAPI_CM_GetPhysicalChannelNumber(msAPI_CM_GetCurrentServiceType(), msAPI_CM_GetCurrentPosition(msAPI_CM_GetCurrentServiceType()));
    else
        stGenSetting.stScanMenuSetting.u8RFChannelNumber = msAPI_DFT_GetFirstPhysicalChannelNumber();

    if (!_MApp_ZUI_API_AllocateVarData())
    {
        ZUI_DBG_FAIL(printf("[ZUI]ALLOC\n"));
        ABORT();
        return;
    }

    RECT_SET(rect,
        ZUI_DTV_MANUAL_TUNING_XSTART, ZUI_DTV_MANUAL_TUNING_YSTART,
        ZUI_DTV_MANUAL_TUNING_WIDTH, ZUI_DTV_MANUAL_TUNING_HEIGHT);

    if (!MApp_ZUI_API_InitGDI(&rect))
    {
        ZUI_DBG_FAIL(printf("[ZUI]GDIINIT\n"));
        ABORT();
        return;
    }
    if ( UI_INPUT_SOURCE_TYPE != UI_INPUT_SOURCE_DTV
    #if ENABLE_T_C_COMBO
        || UI_PREV_INPUT_SOURCE_TYPE != UI_INPUT_SOURCE_DTV
    #endif
    )
    {
        msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_PERMANENT_MUTEON, E_AUDIOMUTESOURCE_ACTIVESOURCE);
        UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_DTV;
    #if ENABLE_SBTVD_BRAZIL_APP
        enLastWatchAntennaType = ANTENNA_DTV_TYPE;
       MApp_InputSource_SwitchSource( UI_INPUT_SOURCE_TYPE , MAIN_WINDOW );
    #else
        MApp_InputSource_ChangeInputSource(MAIN_WINDOW);
    #endif

        MApp_SaveSysSetting();
        msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_PERMANENT_MUTEOFF, E_AUDIOMUTESOURCE_ACTIVESOURCE);

    }
    for (wnd = 0; wnd < HWND_MAX; wnd++)
    {
        MApp_ZUI_API_SendMessage(wnd, MSG_CREATE, 0);
    }


    MApp_ZUI_API_ShowWindow(HWND_MAINFRAME, SW_SHOW);
    MApp_ZUI_API_ShowWindow(HWND_DTUNE_SCAN_RESULT_NO_SIGNAL_BTN, SW_HIDE);
    MApp_ZUI_API_ShowWindow(HWND_DTUNE_SCAN_RESULT_SEARCHING_TXT, SW_HIDE);
    MApp_ZUI_API_ShowWindow(HWND_DTUNE_SCAN_ENTERKEY_REMIND_TXT, SW_HIDE);
    MApp_ZUI_API_ShowWindow(HWND_DTUNE_SCAN_RESULT_DTV_TXT, SW_HIDE);
    MApp_ZUI_API_ShowWindow(HWND_DTUNE_SCAN_RESULT_RADIO_TXT, SW_HIDE);
    MApp_ZUI_API_ShowWindow(HWND_DTUNE_SCAN_RESULT_DATA_TXT, SW_HIDE);

    MApp_ZUI_API_SetFocus(HWND_DTUNE_MANUAL_SCAN_BAR);

}
#endif//#if ENABLE_DTV
#undef MAPP_ZUI_ACTDTVMANUALTUNING_C
