////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#define MAPP_OSDPAGE_MAIN_C

/******************************************************************************/
/*                 Header Files                                               */
/* ****************************************************************************/
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#include "datatype.h"

#include "MApp_Exit.h"
#include "MApp_Key.h"
#include "MApp_UiMenuDef.h"
#include "MApp_ZUI_Main.h"
#include "ZUI_tables_h.inl"
#include "MApp_OSDPage_Main.h"
#include "MApp_ZUI_ACTfactorymenu.h"

///////////////////////////////////////////////////////////
static E_OSD_ID enOSDPage;
static EN_OSDPAGE_STATE enOSDPageState;

//////////////////////////////////////////////////////////

EN_RET MApp_OSDPage_Main(void)
{
    EN_RET enRetVal = EXIT_NULL;
    switch(enOSDPageState)
    {
        case STATE_OSDPAGE_INIT:
            MApp_ZUI_ACT_StartupOSD(enOSDPage);
            enOSDPageState = STATE_OSDPAGE_WAIT;
            break;

        case STATE_OSDPAGE_WAIT:
            MApp_ZUI_ProcessKey(u8KeyCode);
			MApp_ZUI_FactoryAutoRun();
            u8KeyCode = KEY_NULL;
            break;

        case STATE_OSDPAGE_CHANGE_PAGE:
            MApp_ZUI_ACT_ShutdownOSD();
            enOSDPageState = STATE_OSDPAGE_INIT;
            break;

        case STATE_OSDPAGE_CLEAN_UP:
            MApp_ZUI_ACT_ShutdownOSD();
            enOSDPageState = STATE_OSDPAGE_INIT;
            enRetVal = EXIT_CLOSE;
            break;
#if ENABLE_DMP
        case STATE_OSDPAGE_GOTO_DMP:
            MApp_ZUI_ACT_ShutdownOSD();
            enOSDPageState = STATE_OSDPAGE_INIT;
            enRetVal = EXIT_GOTO_DMP;
            break;
#endif
#ifdef ENABLE_BT
        case STATE_OSDPAGE_GOTO_BT:
            MApp_ZUI_ACT_ShutdownOSD();
            enOSDPageState = STATE_OSDPAGE_INIT;
            enRetVal =EXIT_GOTO_BT;
            break;
#endif
#ifdef ENABLE_KTV
        case STATE_OSDPAGE_GOTO_KTV:
            MApp_ZUI_ACT_ShutdownOSD();
            enOSDPageState = STATE_OSDPAGE_INIT;
            enRetVal =EXIT_GOTO_KTV;
            break;
#endif
        case STATE_OSDPAGE_GOTO_MAIN_MENU:
            MApp_ZUI_ACT_ShutdownOSD();
            enOSDPageState = STATE_OSDPAGE_INIT;
            enRetVal = EXIT_GOTO_MENU;
            break;

        case STATE_OSDPAGE_GOTO_INPUT_SOURCE:
            MApp_ZUI_ACT_ShutdownOSD();
            enOSDPageState = STATE_OSDPAGE_INIT;
            enRetVal = EXIT_GOTO_INPUTSOURCE;
            break;

        case STATE_OSDPAGE_GOTO_STANDBY:
            MApp_ZUI_ACT_ShutdownOSD();
            u8KeyCode = KEY_POWER;
            enRetVal = EXIT_GOTO_STANDBY;
            break;

        case STATE_OSDPAGE_EXIT:  //do nothing, just exit OSD state
            enOSDPageState = STATE_OSDPAGE_INIT;
            enRetVal = EXIT_CLOSE;
            break; // Added by coverity_0617
       #if BOE_USB_UPGRADE_FACTROY//minglin1206     
       case STATE_OSDPAGE_GOTO_UPDATE_MENU:
         
            MApp_ZUI_ACT_ShutdownOSD();
            enOSDPageState = STATE_OSDPAGE_INIT;
            //enRetVal = EXIT_GOTO_MENU;
            enRetVal =EXIT_GOTO_UPDATE;
            
            break;
		#endif	
        default:
            enOSDPageState = STATE_OSDPAGE_WAIT;
            break;
    }
    return enRetVal;
}

void MApp_OSDPage_SetOSDPage(E_OSD_ID id)
{
    enOSDPage = id;
}

void MApp_OSDPage_SetState(EN_OSDPAGE_STATE enState)
{
    enOSDPageState = enState;
}

#undef MAPP_OSDPAGE_MAIN_C

