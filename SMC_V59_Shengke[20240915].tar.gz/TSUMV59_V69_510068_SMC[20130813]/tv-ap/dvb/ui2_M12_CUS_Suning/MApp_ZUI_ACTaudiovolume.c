////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#define MAPP_ZUI_ACTAUDIOVOLUME_C
#define _ZUI_INTERNAL_INSIDE_ //NOTE: for ZUI internal


//-------------------------------------------------------------------------------------------------
// Include Files
//-------------------------------------------------------------------------------------------------
#include "Board.h"
#include "datatype.h"
#include "MsCommon.h"
#include "apiXC.h"
#include "apiXC_Adc.h"
#include "MApp_GlobalSettingSt.h"
#include "MApp_ZUI_Main.h"
#include "MApp_ZUI_APIcommon.h"
#include "MApp_ZUI_APIstrings.h"
#include "MApp_ZUI_APIgdi.h"
#include "MApp_ZUI_APIwindow.h"
#include "ZUI_tables_h.inl"
#include "MApp_ZUI_APIcontrols.h"
#include "MApp_ZUI_ACTeffect.h"
#include "MApp_ZUI_ACTglobal.h"
#include "OSDcp_String_EnumIndex.h"
#include "ZUI_exefunc.h"

#include "MApp_ZUI_ACTaudiovolume.h"
#include "MApp_UiMenuDef.h"
#include "MApp_Audio.h"
#include "MApp_GlobalSettingSt.h"
#include "msAPI_audio.h"
#include "MApp_SaveData.h"
#include "drvGPIO.h"

//#include "ZUI_bitmap_EnumIndex.h"
#include "OSDcp_Bitmap_EnumIndex.h"
#include "MApp_TopStateMachine.h"
/////////////////////////////////////////////////////////////////////

extern BOOLEAN _MApp_ZUI_API_AllocateVarData(void);


void MApp_ZUI_ACT_AppShowAudioVolume(void)
{
    HWND wnd;
    RECT rect;
    E_OSD_ID osd_id = E_OSD_AUDIO_VOLUME;

    g_GUI_WindowList = GetWindowListOfOsdTable(osd_id);
    g_GUI_WinDrawStyleList = GetWindowStyleOfOsdTable(osd_id);
    g_GUI_WindowPositionList = GetWindowPositionOfOsdTable(osd_id);
#if ZUI_ENABLE_ALPHATABLE
    g_GUI_WinAlphaDataList = GetWindowAlphaDataOfOsdTable(osd_id);
#endif
    HWND_MAX = GetWndMaxOfOsdTable(osd_id);
    OSDPAGE_BLENDING_ENABLE = IsBlendingEnabledOfOsdTable(osd_id);
    OSDPAGE_BLENDING_VALUE = GetBlendingValueOfOsdTable(osd_id);

    if (!_MApp_ZUI_API_AllocateVarData())
    {
        ZUI_DBG_FAIL(printf("[ZUI]ALLOC\n"));
        ABORT();
        return;
    }

    RECT_SET(rect,
        ZUI_AUDIO_VOLUME_XSTART, ZUI_AUDIO_VOLUME_YSTART,
        ZUI_AUDIO_VOLUME_WIDTH, ZUI_AUDIO_VOLUME_HEIGHT);

    if (!MApp_ZUI_API_InitGDI(&rect))
    {
        ZUI_DBG_FAIL(printf("[ZUI]GDIINIT\n"));
        ABORT();
        return;
    }

    for (wnd = 0; wnd < HWND_MAX; wnd++)
    {
        //printf("create msg: %lu\n", (U32)wnd);
        MApp_ZUI_API_SendMessage(wnd, MSG_CREATE, 0);
    }

    MApp_ZUI_API_ShowWindow(HWND_MAINFRAME, SW_SHOW);
    //MApp_ZUI_API_ShowWindow(HWND_VOLUME_MUTE_TEXT, SW_HIDE);
    //MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_PAGE_SHOWUP, E_ZUI_STATE_RUNNING);

}


//////////////////////////////////////////////////////////
// Key Handler

BOOLEAN MApp_ZUI_ACT_HandleAudioVolumeKey(VIRTUAL_KEY_CODE key)
{
    //note: don't do anything here! keys will be handled in state machines
    //      moved to MApp_TV_ProcessAudioVolumeKey()
    UNUSED(key);
    ZUI_DBG_FAIL(printf("[ZUI]IDLEKEY\n"));
    //ABORT();
    return FALSE;
}

void MApp_ZUI_ACT_TerminateAudioVolume(void)
{
    ZUI_MSG(printf("[]term:volume\n"));
    //enAudioVolumeState = _enTargetAudioVolumeState;
}
//cus_xm:xue add for FRC volume MAX value 2012-6-13
void Mapp_AdjustVolumeMax(void)
{
	 printf("handle factory RC VolumeMax Key");
	// MApp_ZUI_ACT_ShutdownOSD();
	 stGenSetting.g_SoundSetting.Volume=100;
	//MApp_ZUI_ACT_ExecuteAudioVolumeAction(EN_EXE_INC_AUDIO_VOLUME);
	  msAPI_AUD_AdjustAudioFactor(E_ADJUST_VOLUME, stGenSetting.g_SoundSetting.Volume, 0);
}
void Mapp_AdjustVolumeHalt(void)
{
	printf("handle factory RC VolumeMax Key");
	//MApp_ZUI_ACT_ShutdownOSD();
	stGenSetting.g_SoundSetting.Volume=50;
	msAPI_AUD_AdjustAudioFactor(E_ADJUST_VOLUME, stGenSetting.g_SoundSetting.Volume, 0);

}

extern void MApp_UiMenu_MuteWin_Hide(void);

BOOLEAN MApp_ZUI_ACT_ExecuteAudioVolumeAction(U16 act)
{

    switch(act)
    {

        case EN_EXE_CLOSE_CURRENT_OSD:
            MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
            return TRUE;
        case EN_EXE_POWEROFF://cus_xm:zb add at 2012-7-14
       	MApp_ZUI_ACT_ExecuteEffectSettingAction(EN_EXE_POWEROFF);
        	return FALSE;

        case EN_EXE_RESET_AUTO_CLOSE_TIMER:
            //reset timer if any key
            MApp_ZUI_API_ResetTimer(HWND_VOLUME_CONFIG_PANE, 0);
            return FALSE;
/*
        case EN_EXE_MUTE_AUDIO_VOLUME:
            {
                BOOLEAN bIsAudioMuted;

                bIsAudioMuted = msAPI_AUD_IsAudioMutedByUser();

                if (bIsAudioMuted == FALSE)
                {
                    msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_BYUSER_MUTEON, E_AUDIOMUTESOURCE_ACTIVESOURCE);
                    MApp_ZUI_API_ShowWindow(HWND_VOLUME_CONFIG_PANE, SW_HIDE);
                    MApp_ZUI_API_ShowWindow(HWND_VOLUME_MUTE_PANE, SW_SHOW);

                }
                else
                {
                    msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_BYUSER_MUTEOFF, E_AUDIOMUTESOURCE_ACTIVESOURCE);
                    MApp_ZUI_API_ShowWindow(HWND_VOLUME_CONFIG_PANE, SW_SHOW);
                    MApp_ZUI_API_ShowWindow(HWND_VOLUME_MUTE_PANE, SW_HIDE);
                    MApp_ZUI_API_SetFocus(HWND_VOLUME_CONFIG_BAR);

                }
            }
            return TRUE;
*/
        case EN_EXE_DEC_AUDIO_VOLUME:
        case EN_EXE_INC_AUDIO_VOLUME:

           if(act == EN_EXE_INC_AUDIO_VOLUME)
            {
				/*
				if ( stGenSetting.g_SoundSetting.Volume < MAX_NUM_OF_VOL_LEVEL )
		            {
		                stGenSetting.g_SoundSetting.Volume++;
		                msAPI_AUD_AdjustAudioFactor(E_ADJUST_VOLUME, stGenSetting.g_SoundSetting.Volume, 0);
		                MApp_ZUI_API_InvalidateAllSuccessors(HWND_VOLUME_CONFIG_PANE);
		            }
				*/
				//================================================================================
				//add for hotel menu max volume setting @chuxu 2012-08-07 @ modify 2012-08-20
			#if CUS_SMC_ENABLE_HOTEL_MODE
                if (stGenSetting.g_FactorySetting.HotelMenuHotelModeOperationEnable == ENABLE)
                {
                	//printf("\r\ng_u8HotelVolMax = %d",g_u8HotelVolMax);
                	//SMC jayden.chen 111111111111111
                    if ( stGenSetting.g_SoundSetting.Volume < g_u8HotelVolMax )//stGenSetting.g_FactorySetting.HotelMenuMaxVolumeSetting)
                    {
                        stGenSetting.g_SoundSetting.Volume++;
                        msAPI_AUD_AdjustAudioFactor(E_ADJUST_VOLUME, stGenSetting.g_SoundSetting.Volume, 0);
                        MApp_ZUI_API_InvalidateAllSuccessors(HWND_VOLUME_CONFIG_PANE);
                    }
                }
				else
					if ( stGenSetting.g_SoundSetting.Volume < MAX_NUM_OF_VOL_LEVEL )
                    {
                        stGenSetting.g_SoundSetting.Volume++;
                        msAPI_AUD_AdjustAudioFactor(E_ADJUST_VOLUME, stGenSetting.g_SoundSetting.Volume, 0);
                        MApp_ZUI_API_InvalidateAllSuccessors(HWND_VOLUME_CONFIG_PANE);
                    }
			#else
                {
                    if ( stGenSetting.g_SoundSetting.Volume < MAX_NUM_OF_VOL_LEVEL )
                    {
                        stGenSetting.g_SoundSetting.Volume++;
                        msAPI_AUD_AdjustAudioFactor(E_ADJUST_VOLUME, stGenSetting.g_SoundSetting.Volume, 0);
                        MApp_ZUI_API_InvalidateAllSuccessors(HWND_VOLUME_CONFIG_PANE);
                    }
                }
			#endif
				//================================================================================
				// CUS_XM Xue 20120727:
				MApp_UiMenu_MuteWin_Hide();
				msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_BYUSER_MUTEOFF, E_AUDIOMUTESOURCE_ACTIVESOURCE);
				msAPI_AUD_AdjustAudioFactor(E_ADJUST_VOLUME, stGenSetting.g_SoundSetting.Volume, 0);

            }
            else
            {
             // CUS_XM Xue 20120720: if mute on volume dec  unlock mute status
                    if(msAPI_AUD_IsAudioMutedByUser())
				MW_AUD_SetSoundMute(SOUND_MUTE_ALL,E_MUTE_ON);

                if ( stGenSetting.g_SoundSetting.Volume > 0 )
                {

                    stGenSetting.g_SoundSetting.Volume--;
                    msAPI_AUD_AdjustAudioFactor(E_ADJUST_VOLUME, stGenSetting.g_SoundSetting.Volume, 0);
                   MApp_ZUI_API_InvalidateAllSuccessors(HWND_VOLUME_CONFIG_PANE);
                }
            }
					// CUS_XM Xue 20120728: unuse
		//MApp_ZUI_API_InvalidateAllSuccessors(HWND_VOLUME_CONFIG_PANE);
            //msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_BYUSER_MUTEOFF, E_AUDIOMUTESOURCE_ACTIVESOURCE);
         //   msAPI_AUD_AdjustAudioFactor(E_ADJUST_VOLUME, stGenSetting.g_SoundSetting.Volume, 0);

            #if 0 //EAR_PHONE_POLLING		// CUS_XM Sea 20120619:
            if (PreEarphoneState != EAR_PHONE_NULL)
            {
                if(stGenSetting.g_SoundSetting.Volume>0)
                {
                    EarPhone_ON();
                }
                else
                {
                    EarPhone_OFF();
                }
            }
            #endif
			
#if !ENABLE_NO_AUDIO_INPUT_AUTO_MUTE
            if(stGenSetting.g_SoundSetting.Volume>0)
            {

                MUTE_Off();
               // MApp_ZUI_API_ShowWindow(HWND_VOLUME_CONFIG_PANE, SW_SHOW);
               // MApp_ZUI_API_ShowWindow(HWND_VOLUME_MUTE_PANE, SW_HIDE);
               // MApp_ZUI_API_SetFocus(HWND_VOLUME_CONFIG_BAR);

            }
            else
            {

#if !(AUDIO_EN_CONTROL_DISABLE) // CUS_XM Sea 20120615

                MUTE_On();
#endif

               // MApp_ZUI_API_ShowWindow(HWND_VOLUME_CONFIG_PANE, SW_HIDE);
               // MApp_ZUI_API_ShowWindow(HWND_VOLUME_MUTE_PANE, SW_SHOW);
            }
#endif
            return TRUE;


    }
    return FALSE;
}

LPTSTR MApp_ZUI_ACT_GetAudioVolumeDynamicText(HWND hwnd)
{
    // Marked it by coverity_296
    //U16 u16TempID = Empty;
    switch(hwnd)
    {
        //case HWND_VOLUME_CONFIG_TEXT:
        case HWND_VOLUME_CONFIG_VALUE:
			//add for hotel menu max volume setting @chuxu 2012-08-07 @ modify 2012-08-20
			#if 0//CUS_SMC_ENABLE_HOTEL_MODE
			    if(stGenSetting.g_FactorySetting.HotelMenuHotelModeOperationEnable == ENABLE)//OSD display factual value bar
                {
					return (MApp_ZUI_API_GetU16String((MAX_NUM_OF_VOL_LEVEL*stGenSetting.g_SoundSetting.Volume)/stGenSetting.g_FactorySetting.HotelMenuMaxVolumeSetting));
				}
				else
					return MApp_ZUI_API_GetU16String(stGenSetting.g_SoundSetting.Volume);
			#else
				{
            		return MApp_ZUI_API_GetU16String(stGenSetting.g_SoundSetting.Volume);
				}
			#endif
    }

    //if (u16TempID != Empty)
    //    return MApp_ZUI_API_GetString(u16TempID);
    return 0; //for empty string....
}



S16 MApp_ZUI_ACT_GetAudioVolumeDynamicValue(HWND hwnd)
{
    switch(hwnd)
    {
        case HWND_VOLUME_CONFIG_SLIDER_BAR:
/*
#if (0)  // EAR_PHONE_POLLING
	     if(GetEarphoneState()==EAR_PHONE_INSERTED)//hj add for earphone 2010-06-03
	     {
	            return stGenSetting.g_SoundSetting.EarPhoneVolume;
	     }
	     else
	     {
	            return stGenSetting.g_SoundSetting.Volume;
	     }
#else
            return stGenSetting.g_SoundSetting.Volume;
#endif
*/
	//add for hotel menu max volume setting @chuxu 2012-08-07 @ modify 2012-08-20
	#if 0//CUS_SMC_ENABLE_HOTEL_MODE
        if(stGenSetting.g_FactorySetting.HotelMenuHotelModeOperationEnable == ENABLE)//OSD display virtual value bar
        {
            return ((MAX_NUM_OF_VOL_LEVEL*stGenSetting.g_SoundSetting.Volume)/stGenSetting.g_FactorySetting.HotelMenuMaxVolumeSetting);
        }
		else
			return stGenSetting.g_SoundSetting.Volume;
	#else
        {
            return stGenSetting.g_SoundSetting.Volume;
        }
	#endif

    }

    return 0; //for empty  data
}

/////////////////////////////////////////////////////////
// Customize Window Procedures
/*
S32 MApp_ZUI_ACT_AudioVolumeWinProc(HWND hwnd, PMSG msg)
{
    switch(msg->message)
    {
        case MSG_CREATE:
            {
                //setting AP timeout, auto close
                MApp_ZUI_API_SetTimer(hwnd, 0, HOT_MENU_TIME_OUT_3SEC);
            }
            break;

        case MSG_TIMER:
            {
                //if the time is up, kill the timer and then close AP!
                MApp_ZUI_API_KillTimer(hwnd, 0);
                MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_CLOSE_CURRENT_OSD);
            }
            break;


    }

    return DEFAULTWINPROC(hwnd, msg);
}
*/

#undef MAPP_ZUI_ACTAUDIOVOLUME_C
