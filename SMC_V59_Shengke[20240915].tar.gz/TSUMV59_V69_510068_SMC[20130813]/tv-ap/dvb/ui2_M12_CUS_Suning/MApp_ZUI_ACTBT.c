////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////
#define MAPP_ZUI_ACTBT_C
#define _ZUI_INTERNAL_INSIDE_ //NOTE: for ZUI internal
//-------------------------------------------------------------------------------------------------
// Include Files
//-------------------------------------------------------------------------------------------------
#include "MsCommon.h"
#ifdef ENABLE_BT
#include "MApp_BT_config.h"

#if (ENABLE_THUNDER_DOWNLOAD)
#include "MApp_ZUI_ACTThunder.c"

#else
#include "MApp_ZUI_Main.h"
#include "MApp_ZUI_APIcommon.h"
#include "MApp_ZUI_APIstrings.h"
#include "MApp_ZUI_APIwindow.h"
#include "ZUI_tables_h.inl"
#include "MApp_ZUI_APIgdi.h"
#include "MApp_ZUI_APIcontrols.h"
#include "MApp_ZUI_ACTmainpage.h"
#include "MApp_ZUI_ACTeffect.h"
#include "MApp_ZUI_ACTglobal.h"
#include "OSDcp_String_EnumIndex.h"
#include "OSDcp_Bitmap_EnumIndex.h"
#include "ZUI_exefunc.h"
#include "msAPI_Memory.h"
#include "drvUSB.h"
#include "msAPI_MSDCtrl.h"
#include "apiGOP.h"
#include "MApp_ZUI_APIChineseIME.h"
#include "MApp_BT_Main.h"
#include "MApp_BT.h"
#include "MApp_ZUI_ACTBT.h"
#include "MApp_UiMenuDef.h"
#include "MApp_RestoreToDefault.h"
#include "mapp_gb2unicode.h"
#include "mapp_videoplayer.h"
#include "GPIO.h"
#include "FSUtil.h"
#include "IOUtil.h"
#include <stdio.h>
#include <string.h>

#include "MApp_ZUI_APIcomponent.h"
#include "MApp_ZUI_APItables.h"
#include "MApp_ZUI_APIdraw.h"
#include "MApp_ZUI_APIalphatables.h"

extern void _MApp_ZUI_API_DefaultOnPaint(HWND hWnd, PAINT_PARAM * param, BOOLEAN bDrawText);
extern U16 _MApp_ZUI_API_FindFirstComponentIndex(HWND hWnd, DRAWSTYLE_TYPE type, DRAWCOMPONENT comp);
extern void _MApp_ZUI_API_ConvertTextComponentToPunctuated(U16 u16TextOutIndex, DRAW_PUNCTUATED_DYNAMIC * pComp);

#define ZUIBT_DBG(x)   x

#define BT_INIT_BMP_FLASH_COUNT   1

_BT_IME enBT_IME;
U8 u8SearchListPage = 0;
static U8 _u8BtInitCount = 0;

/////////////////////////////////////////////////////////////////////
static EN_BT_STATE _enTargetBTState;
static HWND m_hwndFocus = HWND_INVALID;
static EN_BT_PAGE_TYPE _enBtPageType = TYPE_BT_DOWNLOAD_LIST;
static U8 u8BTSetting_maxnum = 0xFF;
static U8 u8BTSetting_Servername_Inputcount = 0;
static U8 u8_Array_BTKeyboard_Symbol[4][47] =
{
    {"  0   1    2    3    4    5    6    7   8    9"},
    {".    /    -    _    %    @    ?    $    :    ~"},
    {",    !    ;    #    ^    *    (    )    [    ]"},
    {"{    }    <    >    =    +    &    '    `    "},
};
static  HWND _ZUI_TBLSEG _DownloadPageItemHwndList[NUM_OF_TORRENT_FILES_PER_PAGE]=
{
    HWND_BT_DOWNLOAD_DOWNLOAD_ITEM0,
    HWND_BT_DOWNLOAD_DOWNLOAD_ITEM1,
    HWND_BT_DOWNLOAD_DOWNLOAD_ITEM2,
    HWND_BT_DOWNLOAD_DOWNLOAD_ITEM3,
    HWND_BT_DOWNLOAD_DOWNLOAD_ITEM4,
};
static  HWND _ZUI_TBLSEG _DownloadPageItemFileNameHwndList[NUM_OF_TORRENT_FILES_PER_PAGE]=
{
    HWND_BT_DOWNLOAD_DOWNLOAD_ITEM0_FILE_NAME,
    HWND_BT_DOWNLOAD_DOWNLOAD_ITEM1_FILE_NAME,
    HWND_BT_DOWNLOAD_DOWNLOAD_ITEM2_FILE_NAME,
    HWND_BT_DOWNLOAD_DOWNLOAD_ITEM3_FILE_NAME,
    HWND_BT_DOWNLOAD_DOWNLOAD_ITEM4_FILE_NAME,
};
static  HWND _ZUI_TBLSEG _DownloadPageItemFileStateHwndList[NUM_OF_TORRENT_FILES_PER_PAGE]=
{
    HWND_BT_DOWNLOAD_DOWNLOAD_ITEM0_STATE,
    HWND_BT_DOWNLOAD_DOWNLOAD_ITEM1_STATE,
    HWND_BT_DOWNLOAD_DOWNLOAD_ITEM2_STATE,
    HWND_BT_DOWNLOAD_DOWNLOAD_ITEM3_STATE,
    HWND_BT_DOWNLOAD_DOWNLOAD_ITEM4_STATE,
};
static  HWND _ZUI_TBLSEG _DownloadPageItemFileSizeHwndList[NUM_OF_TORRENT_FILES_PER_PAGE]=
{
    HWND_BT_DOWNLOAD_DOWNLOAD_ITEM0_FILE_SIZE,
    HWND_BT_DOWNLOAD_DOWNLOAD_ITEM1_FILE_SIZE,
    HWND_BT_DOWNLOAD_DOWNLOAD_ITEM2_FILE_SIZE,
    HWND_BT_DOWNLOAD_DOWNLOAD_ITEM3_FILE_SIZE,
    HWND_BT_DOWNLOAD_DOWNLOAD_ITEM4_FILE_SIZE,
};
static  HWND _ZUI_TBLSEG _DownloadPageItemFilePercentHwndList[NUM_OF_TORRENT_FILES_PER_PAGE]=
{
    HWND_BT_DOWNLOAD_DOWNLOAD_ITEM0_FILE_PERCENT,
    HWND_BT_DOWNLOAD_DOWNLOAD_ITEM1_FILE_PERCENT,
    HWND_BT_DOWNLOAD_DOWNLOAD_ITEM2_FILE_PERCENT,
    HWND_BT_DOWNLOAD_DOWNLOAD_ITEM3_FILE_PERCENT,
    HWND_BT_DOWNLOAD_DOWNLOAD_ITEM4_FILE_PERCENT,
};
static  HWND _ZUI_TBLSEG _DownloadPageItemDownloadSpeedHwndList[NUM_OF_TORRENT_FILES_PER_PAGE]=
{
    HWND_BT_DOWNLOAD_DOWNLOAD_ITEM0_DOWNLOAD_SPEED,
    HWND_BT_DOWNLOAD_DOWNLOAD_ITEM1_DOWNLOAD_SPEED,
    HWND_BT_DOWNLOAD_DOWNLOAD_ITEM2_DOWNLOAD_SPEED,
    HWND_BT_DOWNLOAD_DOWNLOAD_ITEM3_DOWNLOAD_SPEED,
    HWND_BT_DOWNLOAD_DOWNLOAD_ITEM4_DOWNLOAD_SPEED,
};
static  HWND _ZUI_TBLSEG _DownloadPageItemTimeLeftHwndList[NUM_OF_TORRENT_FILES_PER_PAGE]=
{
    HWND_BT_DOWNLOAD_DOWNLOAD_ITEM0_TIME_LEFT,
    HWND_BT_DOWNLOAD_DOWNLOAD_ITEM1_TIME_LEFT,
    HWND_BT_DOWNLOAD_DOWNLOAD_ITEM2_TIME_LEFT,
    HWND_BT_DOWNLOAD_DOWNLOAD_ITEM3_TIME_LEFT,
    HWND_BT_DOWNLOAD_DOWNLOAD_ITEM4_TIME_LEFT,
};
static  HWND _ZUI_TBLSEG _IME_PAGE_HwndList[NUM_OF_IME_CHARS_PER_PAGE]=
{
    HWND_BT_DOWNLOAD_TORRENT_SEARCH_IME_ITEM1,
    HWND_BT_DOWNLOAD_TORRENT_SEARCH_IME_ITEM2,
    HWND_BT_DOWNLOAD_TORRENT_SEARCH_IME_ITEM3,
    HWND_BT_DOWNLOAD_TORRENT_SEARCH_IME_ITEM4,
    HWND_BT_DOWNLOAD_TORRENT_SEARCH_IME_ITEM5,
    HWND_BT_DOWNLOAD_TORRENT_SEARCH_IME_ITEM6,
    HWND_BT_DOWNLOAD_TORRENT_SEARCH_IME_ITEM7,
    HWND_BT_DOWNLOAD_TORRENT_SEARCH_IME_ITEM8,
};
static  HWND _ZUI_TBLSEG hwnd2key[][2] =
{
    { HWND_BT_DOWNLOAD_SOFTWARE_KEY_0, '0'},
    { HWND_BT_DOWNLOAD_SOFTWARE_KEY_1, '1'},
    { HWND_BT_DOWNLOAD_SOFTWARE_KEY_2, '2'},
    { HWND_BT_DOWNLOAD_SOFTWARE_KEY_3, '3'},
    { HWND_BT_DOWNLOAD_SOFTWARE_KEY_4, '4'},
    { HWND_BT_DOWNLOAD_SOFTWARE_KEY_5, '5'},
    { HWND_BT_DOWNLOAD_SOFTWARE_KEY_6, '6'},
    { HWND_BT_DOWNLOAD_SOFTWARE_KEY_7, '7'},
    { HWND_BT_DOWNLOAD_SOFTWARE_KEY_8, '8'},
    { HWND_BT_DOWNLOAD_SOFTWARE_KEY_9, '9'},
    { HWND_BT_DOWNLOAD_SOFTWARE_KEY_A, 'a'},
    { HWND_BT_DOWNLOAD_SOFTWARE_KEY_B, 'b'},
    { HWND_BT_DOWNLOAD_SOFTWARE_KEY_C, 'c'},
    { HWND_BT_DOWNLOAD_SOFTWARE_KEY_D, 'd'},
    { HWND_BT_DOWNLOAD_SOFTWARE_KEY_E, 'e'},
    { HWND_BT_DOWNLOAD_SOFTWARE_KEY_F, 'f'},
    { HWND_BT_DOWNLOAD_SOFTWARE_KEY_G, 'g'},
    { HWND_BT_DOWNLOAD_SOFTWARE_KEY_H, 'h'},
    { HWND_BT_DOWNLOAD_SOFTWARE_KEY_I, 'i'},
    { HWND_BT_DOWNLOAD_SOFTWARE_KEY_J, 'j'},
    { HWND_BT_DOWNLOAD_SOFTWARE_KEY_K, 'k'},
    { HWND_BT_DOWNLOAD_SOFTWARE_KEY_L, 'l'},
    { HWND_BT_DOWNLOAD_SOFTWARE_KEY_M, 'm'},
    { HWND_BT_DOWNLOAD_SOFTWARE_KEY_N, 'n'},
    { HWND_BT_DOWNLOAD_SOFTWARE_KEY_O, 'o'},
    { HWND_BT_DOWNLOAD_SOFTWARE_KEY_P, 'p'},
    { HWND_BT_DOWNLOAD_SOFTWARE_KEY_Q, 'q'},
    { HWND_BT_DOWNLOAD_SOFTWARE_KEY_R, 'r'},
    { HWND_BT_DOWNLOAD_SOFTWARE_KEY_S, 's'},
    { HWND_BT_DOWNLOAD_SOFTWARE_KEY_T, 't'},
    { HWND_BT_DOWNLOAD_SOFTWARE_KEY_U, 'u'},
    { HWND_BT_DOWNLOAD_SOFTWARE_KEY_V, 'v'},
    { HWND_BT_DOWNLOAD_SOFTWARE_KEY_W, 'w'},
    { HWND_BT_DOWNLOAD_SOFTWARE_KEY_X, 'x'},
    { HWND_BT_DOWNLOAD_SOFTWARE_KEY_Y, 'y'},
    { HWND_BT_DOWNLOAD_SOFTWARE_KEY_Z, 'z'},
    { HWND_BT_DOWNLOAD_SOFTWARE_KEY_BLANK, ' '},
    { HWND_BT_DOWNLOAD_SOFTWARE_KEY_BACKSPACE, 0x08},
    { HWND_BT_DOWNLOAD_SOFTWARE_KEY_SYMBOL, 0x07},
};
static  HWND _ZUI_TBLSEG _MainLink0PageItemPhotoHwndList[NUM_OF_MAINLINK0_PHOTO_PER_PAGE]=
{
    HWND_BT_DOWNLOAD_MAINLINK0_ITEM0_PHOTO,
    HWND_BT_DOWNLOAD_MAINLINK0_ITEM1_PHOTO,
    HWND_BT_DOWNLOAD_MAINLINK0_ITEM2_PHOTO,
    HWND_BT_DOWNLOAD_MAINLINK0_ITEM3_PHOTO,
    HWND_BT_DOWNLOAD_MAINLINK0_ITEM4_PHOTO,
    HWND_BT_DOWNLOAD_MAINLINK0_ITEM5_PHOTO,
};
static  HWND _ZUI_TBLSEG _MainLink0PageItemNameHwndList[NUM_OF_MAINLINK0_PHOTO_PER_PAGE]=
{
    HWND_BT_DOWNLOAD_MAINLINK0_ITEM0_NAME,
    HWND_BT_DOWNLOAD_MAINLINK0_ITEM1_NAME,
    HWND_BT_DOWNLOAD_MAINLINK0_ITEM2_NAME,
    HWND_BT_DOWNLOAD_MAINLINK0_ITEM3_NAME,
    HWND_BT_DOWNLOAD_MAINLINK0_ITEM4_NAME,
    HWND_BT_DOWNLOAD_MAINLINK0_ITEM5_NAME,
};
static  HWND _ZUI_TBLSEG _MainLink1PageItemPhotoHwndList[NUM_OF_MAINLINK1_PHOTO_PER_PAGE]=
{
    HWND_BT_DOWNLOAD_MAINLINK1_ITEM0_PHOTO,
    HWND_BT_DOWNLOAD_MAINLINK1_ITEM1_PHOTO,
    HWND_BT_DOWNLOAD_MAINLINK1_ITEM2_PHOTO,
    HWND_BT_DOWNLOAD_MAINLINK1_ITEM3_PHOTO,
    HWND_BT_DOWNLOAD_MAINLINK1_ITEM4_PHOTO,
    HWND_BT_DOWNLOAD_MAINLINK1_ITEM5_PHOTO,
};
static  HWND _ZUI_TBLSEG _MainLink1PageItemNameHwndList[NUM_OF_MAINLINK1_PHOTO_PER_PAGE]=
{
    HWND_BT_DOWNLOAD_MAINLINK1_ITEM0_NAME,
    HWND_BT_DOWNLOAD_MAINLINK1_ITEM1_NAME,
    HWND_BT_DOWNLOAD_MAINLINK1_ITEM2_NAME,
    HWND_BT_DOWNLOAD_MAINLINK1_ITEM3_NAME,
    HWND_BT_DOWNLOAD_MAINLINK1_ITEM4_NAME,
    HWND_BT_DOWNLOAD_MAINLINK1_ITEM5_NAME,
};
static  HWND _ZUI_TBLSEG _SearchListPageItemHwndList[NUM_OF_TORRENT_FILES_PER_PAGE]=
{
    HWND_BT_DOWNLOAD_SEARCHING_LIST_ITEM1,
    HWND_BT_DOWNLOAD_SEARCHING_LIST_ITEM2,
    HWND_BT_DOWNLOAD_SEARCHING_LIST_ITEM3,
    HWND_BT_DOWNLOAD_SEARCHING_LIST_ITEM4,
    HWND_BT_DOWNLOAD_SEARCHING_LIST_ITEM5,
};
static  HWND _ZUI_TBLSEG _SearchListPageItemFileNameHwndList[NUM_OF_TORRENT_FILES_PER_PAGE]=
{
    HWND_BT_DOWNLOAD_SEARCHING_LIST_ITEM1_FILE_NAME,
    HWND_BT_DOWNLOAD_SEARCHING_LIST_ITEM2_FILE_NAME,
    HWND_BT_DOWNLOAD_SEARCHING_LIST_ITEM3_FILE_NAME,
    HWND_BT_DOWNLOAD_SEARCHING_LIST_ITEM4_FILE_NAME,
    HWND_BT_DOWNLOAD_SEARCHING_LIST_ITEM5_FILE_NAME,
};
static  HWND _ZUI_TBLSEG _SearchListPageItemFileSizeHwndList[NUM_OF_TORRENT_FILES_PER_PAGE]=
{
    HWND_BT_DOWNLOAD_SEARCHING_LIST_ITEM1_FILE_SIZE,
    HWND_BT_DOWNLOAD_SEARCHING_LIST_ITEM2_FILE_SIZE,
    HWND_BT_DOWNLOAD_SEARCHING_LIST_ITEM3_FILE_SIZE,
    HWND_BT_DOWNLOAD_SEARCHING_LIST_ITEM4_FILE_SIZE,
    HWND_BT_DOWNLOAD_SEARCHING_LIST_ITEM5_FILE_SIZE,
};
static  HWND _ZUI_TBLSEG _SearchListPageItemFileTypeHwndList[NUM_OF_TORRENT_FILES_PER_PAGE]=
{
    HWND_BT_DOWNLOAD_SEARCHING_LIST_ITEM1_FILE_TYPE,
    HWND_BT_DOWNLOAD_SEARCHING_LIST_ITEM2_FILE_TYPE,
    HWND_BT_DOWNLOAD_SEARCHING_LIST_ITEM3_FILE_TYPE,
    HWND_BT_DOWNLOAD_SEARCHING_LIST_ITEM4_FILE_TYPE,
    HWND_BT_DOWNLOAD_SEARCHING_LIST_ITEM5_FILE_TYPE,
};
extern BOOLEAN _MApp_ZUI_API_AllocateVarData(void);
//==============================================================
//local function
static BOOLEAN _MApp_BT_GotoMenuState(void)
{
    if(enBTState == STATE_BT_WAIT ||
        enBTState == STATE_BT_INIT ||
        enBTState == STATE_BT_SEARCH_WAIT)
    {
        enBTState = STATE_BT_GOTO_MENU;
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}
static BOOLEAN _MApp_BT_GotoInputSourceState(void)
{
    if(enBTState == STATE_BT_WAIT ||
        enBTState == STATE_BT_INIT ||
        enBTState == STATE_BT_SEARCH_WAIT )
    {
        enBTState = STATE_BT_GOTO_INPUTSOURCE;
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}
static BOOLEAN _MApp_BT_GotoBTSearchWaitState(void)
{
    if(enBTState == STATE_BT_WAIT ||
        enBTState == STATE_BT_INIT )
    {
        enBTState = STATE_BT_SEARCH_WAIT;
        u32MonitorBTSearchTimer  = msAPI_Timer_GetTime0();
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}
static BOOLEAN _MApp_BT_GotoBTSearchWaitStateExit(void)
{
    enBTState = STATE_BT_WAIT;
    return TRUE;
}
static void _MApp_BT_ShowDefaultPage(void)
{
    MApp_ZUI_API_ShowWindow(HWND_MAINFRAME, SW_SHOW);
    MApp_ZUI_API_ShowWindow(HWND_BT_DOWNLOAD_BG, SW_HIDE);
    MApp_ZUI_API_ShowWindow(HWND_BT_DOWNLOAD_MAIN_PAGE, SW_HIDE);
    MApp_ZUI_API_ShowWindow(HWND_BT_DOWNLOAD_DOWNLOAD_LIST, SW_HIDE);
    MApp_ZUI_API_SetTimer(HWND_BT_SYSTEM_INFO, 0, 500);
}
static void BT_ASCII2Unicode(U8 *pu8String)
{
    U8 len=0;
    U8 i=0;
    for(i=0;i<255;i++)
    {
        if(pu8String[i]==0)
        {
            len=i;
            break;
        }
    }
    for(i=0;i<len;i++)
    {
        ((U16*)pu8String)[len-1-i]=pu8String[len-1-i];
    }
    if(len>0)
    {
        ((U16*)pu8String)[len]=0;
    }
}


static void MApp_BT_MappingToUnicode(U8 *pu8Str, U16 *pu16Str, U16 srcByteLen, U16 dstWideCharLen)
{
    U8 u8Char, u8Offset;
    U16 i, j=0, u16Char;

    if ((pu8Str == 0) || (srcByteLen == 0) || (pu16Str == 0) || (dstWideCharLen <= 1)) return;

    for(i=0; i<srcByteLen && j<dstWideCharLen-1; i+=u8Offset)
    {
        u8Char = pu8Str[i];
        if(u8Char < 0xA0)
        {
            u16Char = u8Char;
            u8Offset = 1;

        }
        else
        {
            u16Char = ReadU16BE(pu8Str+i);
            //u16Char = MApp_Transfer2Unicode(u16Char);
            u16Char = MApp_GB2Unicode(u16Char);

            if(u16Char == INVALID_UNICODE)
            {
                u16Char = 0x003F;
            }

            u8Offset = 2;
        }
        pu16Str[j] = u16Char;

        // convert control code
        if ( pu16Str[j]>=0x80 && pu16Str[j]<=0x9F )
        {
            pu16Str[j] = (0xE000 | pu16Str[j]);
        }

        j++;
    }

    // NULL termination character
    pu16Str[j] = 0;

}

static void MApp_BT_HexToUnicode(U8 *pu8Str, U16 *pu16Str, U16 srcByteLen, U16 dstWideCharLen)
{
    U8 u8Char, u8Offset = 0;
    U16 i, j=0, n, m, u16Char;

    U16 as16Bais[4]={4096,256,16,1};

    if ((pu8Str == 0) || (srcByteLen == 0) || (pu16Str == 0) || (dstWideCharLen <= 1)) return;

    for(i=0; i<srcByteLen && j<dstWideCharLen-1; i+=u8Offset)
    {
        u8Char = pu8Str[i];
        if(0x25 == u8Char )  /* % */
        {
            u16Char = 0;
            for(n=0; n<4; n++)
            {
                m = i+ n +1; // +1: "%" -> next
                if((pu8Str[m]>=0x41)&&(pu8Str[m]<=0x46))    /* A~F */
                {
                    u16Char+=((U16)(pu8Str[m]-0x41+10))*as16Bais[n];
                }
                else if((pu8Str[m]>=0x61)&&(pu8Str[m]<=0x66))    /* a~f */
                {
                    u16Char+=((U16)(pu8Str[m]-0x61+10))*as16Bais[n];
                }
                else if((pu8Str[m]>=0x30)&&(pu8Str[m]<=0x39))    /* 0~9 */
                {
                    u16Char+=((U16)(pu8Str[m]-0x30))*as16Bais[n];
                }
                else    /* Unexpected condition */
                {
                    //DBG_ASSERT(0);
                }
            }

            u8Offset = 5;
        }
        else
        {
            u16Char = (U16)(u8Char);
            u8Offset = 1;
        }

        pu16Str[j] = u16Char;

        // convert control code
        if ( pu16Str[j]>=0x80 && pu16Str[j]<=0x9F )
        {
            pu16Str[j] = (0xE000 | pu16Str[j]);
        }

        j++;
    }

    // NULL termination character
    pu16Str[j] = 0;

}


static void _MApp_BT_SetPageType(HWND hwnd)
{
    switch(hwnd)
    {
        case HWND_BT_DOWNLOAD_TORRENT_SEARCH_TITLE:
            _enBtPageType = TYPE_BT_TORRENT_SEARCH;
            MApp_BT_SetLink0PhotoFlags(FALSE);
            MApp_ZUI_API_KillTimer(HWND_BT_DOWNLOAD_DOWNLOAD_LIST_TITLE, 0);
            MApp_ZUI_API_KillTimer(HWND_BT_DOWNLOAD_MAINLINK0_TITLE, 0);
            break;
        case HWND_BT_DOWNLOAD_MAINLINK0_TITLE:
            _enBtPageType = TYPE_BT_TOP_10;
            MApp_BT_SetLink0PhotoFlags(TRUE);
            MApp_BT_SetLink1PhotoFlags(FALSE);
            MApp_ZUI_API_KillTimer(HWND_BT_DOWNLOAD_MAINLINK1_TITLE, 0);
            MApp_BT_GetTopListOrNewList(TRUE);
            MApp_ZUI_API_SetTimer(HWND_BT_DOWNLOAD_MAINLINK0_TITLE, 0, 200);
            break;
        case HWND_BT_DOWNLOAD_MAINLINK1_TITLE:
            _enBtPageType = TYPE_BT_NEW_10;
            MApp_BT_SetLink0PhotoFlags(FALSE);
            MApp_BT_SetLink1PhotoFlags(TRUE);
            MApp_ZUI_API_KillTimer(HWND_BT_DOWNLOAD_DOWNLOAD_LIST_TITLE, 0);
            MApp_ZUI_API_KillTimer(HWND_BT_DOWNLOAD_MAINLINK0_TITLE, 0);
            MApp_BT_GetTopListOrNewList(FALSE);
            MApp_ZUI_API_SetTimer(HWND_BT_DOWNLOAD_MAINLINK1_TITLE, 0, 200);
            break;
        case HWND_BT_DOWNLOAD_DOWNLOAD_LIST_TITLE:
            _enBtPageType = TYPE_BT_DOWNLOAD_LIST;
            MApp_BT_SetLink1PhotoFlags(FALSE);
            MApp_ZUI_API_KillTimer(HWND_BT_DOWNLOAD_MAINLINK1_TITLE, 0);
            MApp_ZUI_API_SetTimer(HWND_BT_DOWNLOAD_DOWNLOAD_LIST_TITLE, 0, 200);
            break;
        case HWND_BT_DOWNLOAD_SETUP_TITLE:
            _enBtPageType = TYPE_BT_SETUP;
            MApp_ZUI_API_KillTimer(HWND_BT_DOWNLOAD_DOWNLOAD_LIST_TITLE, 0);
            break;
        default:
            _enBtPageType = TYPE_BT_INVALID;
            break;
    }
}

static EN_BT_PAGE_TYPE _MApp_BT_GetPageType(void)
{
    return _enBtPageType;
}

static void MApp_BT_IME_Init(void)
{
    enBT_IME.bInputOK = FALSE;
    enBT_IME.bIsCAPs = FALSE;
    enBT_IME.bIsEnglish = TRUE;//FALSE;
    enBT_IME.uIME_State = STATE_IME_NULL;
    enBT_IME.u16SpellCounter = 0;
    enBT_IME.u16SpellStar = 0;
}
//=============================================================
// global function
S32 MApp_ZUI_ACT_BTTopWinProc(HWND hwnd, PMSG msg)
{
    static  HWND _ZUI_TBLSEG title2page[5][2] =
    {
        { HWND_BT_DOWNLOAD_TORRENT_SEARCH_TITLE, HWND_BT_DOWNLOAD_TORRENT_SEARCH},
        { HWND_BT_DOWNLOAD_MAINLINK0_TITLE, HWND_BT_DOWNLOAD_MAINLINK0},
        { HWND_BT_DOWNLOAD_MAINLINK1_TITLE, HWND_BT_DOWNLOAD_MAINLINK1},
        { HWND_BT_DOWNLOAD_DOWNLOAD_LIST_TITLE, HWND_BT_DOWNLOAD_DOWNLOAD_LIST},
        { HWND_BT_DOWNLOAD_SETUP_TITLE, HWND_BT_DOWNLOAD_SETUP}
    };
    static U8 u8CurrentPage = 0xFF;
    //printf("topicon_winproc\n");
    switch(msg->message)
    {
        case MSG_CREATE:
            u8CurrentPage = 0xFF;
            break;
        case MSG_KEYDOWN:
            {
                U8 i;
                //note: here assume HWND_BT_DOWNLOAD_TORRENT_SEARCH to HWND_BT_DOWNLOAD_SETUP continuously placed...
                hwnd = MApp_ZUI_API_GetFocus();
                if (msg->wParam == VK_RIGHT)
                {
                    MApp_ZUI_API_SetFocus((hwnd==HWND_BT_DOWNLOAD_SETUP_TITLE)? HWND_BT_DOWNLOAD_TORRENT_SEARCH_TITLE: hwnd+1);
                }
                else if (msg->wParam == VK_LEFT)
                {
                    MApp_ZUI_API_SetFocus((hwnd==HWND_BT_DOWNLOAD_TORRENT_SEARCH_TITLE)? HWND_BT_DOWNLOAD_SETUP_TITLE: hwnd-1);
                }

                else if (msg->wParam == VK_DOWN)
                {
                    if(hwnd==HWND_BT_DOWNLOAD_DOWNLOAD_LIST)
                    {
                        MApp_ZUI_API_SetTimer(HWND_BT_DOWNLOAD_DOWNLOAD_LIST, 0, 500);
                        MApp_ZUI_API_KillTimer(HWND_BT_DOWNLOAD_DOWNLOAD_LIST_TITLE, 0);
                    }
                }

        //_MApp_BT_SetPageType(HWND_BT_DOWNLOAD_MAX);//set a invalid value
                if (msg->wParam == VK_RIGHT || msg->wParam == VK_LEFT)
                {
                    for (i = 0; i < COUNTOF(title2page); i++)
                    {
                        if (MApp_ZUI_API_GetFocus()== title2page[i][0])
                        {
                            _MApp_BT_SetPageType(title2page[i][0]);
                            if (MApp_ZUI_API_IsWindowVisible(title2page[i][1]))
                            {
                                //note: if page and list is already visible, do not show it again
                                //   otherwise, all page items will be shown...
                            }
                            else
                            {
                                MApp_ZUI_API_ShowWindow(title2page[i][1], SW_SHOW);
                                if(title2page[i][0] == HWND_BT_DOWNLOAD_TORRENT_SEARCH_TITLE)
                                {
                                    MApp_ZUI_API_ShowWindow(HWND_BT_DOWNLOAD_SOFTWARE_KEYBOARD, SW_SHOW);
                                }
                                else
                                {
                                    MApp_ZUI_API_ShowWindow(HWND_BT_DOWNLOAD_SOFTWARE_KEYBOARD, SW_HIDE);
                                }
                            }
                            u8CurrentPage = i;
                        }
                        else
                            MApp_ZUI_API_ShowWindow(title2page[i][1], SW_HIDE);
                    }
                    return 0; //stop doing default winproc
                }
            }
            break;
        case MSG_TIMER:
            {
                HWND FocusHwnd = MApp_ZUI_API_GetFocus();

                printf("TM HW:[%d]\n", FocusHwnd);

                if(FocusHwnd == HWND_BT_SYSTEM_INIT)
                {
                    if(MApp_BT_GetSystemInitState() == STATE_SYSTEM_INIT_NONE)
                    {
                        MApp_BT_SetSystemInitState(STATE_SYSTEM_INIT_LOAD_BIN);
                    }
                    else if(MApp_BT_GetSystemInitState() == STATE_SYSTEM_INIT_OK)
                    {
                        MApp_ZUI_API_ShowWindow(HWND_BT_SYSTEM_INIT, SW_HIDE);
                        MApp_ZUI_API_RestoreFocusCheckpoint();
                        break;
                    }

                    _u8BtInitCount++;
                    if(_u8BtInitCount>=BT_INIT_BMP_FLASH_COUNT*2)
                        _u8BtInitCount = 0;

                    MApp_ZUI_API_InvalidateAllSuccessors(HWND_BT_SYSTEM_INIT_BMP);

                    break;
                }

                if(MApp_ZUI_ACT_BT_SystemErrorCheck())
                {
                    MApp_ZUI_ACT_AppShowBTSystemError();
                    break;
                }

                switch( FocusHwnd )
                {
                    case HWND_BT_DOWNLOAD_SEARCHING_INFO_PAGE:
                        MApp_ZUI_ACT_AppShowBTSearchResult();
                        break;

                    case HWND_BT_DOWNLOAD_DOWNLOAD_LIST_TITLE:
                    case HWND_BT_DOWNLOAD_DOWNLOAD_ITEM0:
                    case HWND_BT_DOWNLOAD_DOWNLOAD_ITEM1:
                    case HWND_BT_DOWNLOAD_DOWNLOAD_ITEM2:
                    case HWND_BT_DOWNLOAD_DOWNLOAD_ITEM3:
                    case HWND_BT_DOWNLOAD_DOWNLOAD_ITEM4:
                        MApp_ZUI_ACT_AppShowDownLoadListResult(FocusHwnd);
                        break;

                    case HWND_BT_DOWNLOAD_MAINLINK0_TITLE:
                    case HWND_BT_DOWNLOAD_MAINLINK1_TITLE:
                        MApp_ZUI_ACT_AppShowToporNewListResult(FocusHwnd);
                        break;

                    case HWND_BT_DOWNLOAD_MAINLINK0_ITEM0_NAME:
                    case HWND_BT_DOWNLOAD_MAINLINK0_ITEM1_NAME:
                    case HWND_BT_DOWNLOAD_MAINLINK0_ITEM2_NAME:
                    case HWND_BT_DOWNLOAD_MAINLINK0_ITEM3_NAME:
                    case HWND_BT_DOWNLOAD_MAINLINK0_ITEM4_NAME:
                    case HWND_BT_DOWNLOAD_MAINLINK0_ITEM5_NAME:
                    case HWND_BT_DOWNLOAD_MAINLINK1_ITEM0_NAME:
                    case HWND_BT_DOWNLOAD_MAINLINK1_ITEM1_NAME:
                    case HWND_BT_DOWNLOAD_MAINLINK1_ITEM2_NAME:
                    case HWND_BT_DOWNLOAD_MAINLINK1_ITEM3_NAME:
                    case HWND_BT_DOWNLOAD_MAINLINK1_ITEM4_NAME:
                    case HWND_BT_DOWNLOAD_MAINLINK1_ITEM5_NAME:
                        MApp_ZUI_ACT_AppShowToporNewListDescription(FocusHwnd);
                        break;

                    default:
                        break;
                }
            }
            break;
        default:
            break;
    }
    return DEFAULTWINPROC(hwnd, msg);
}

S32 MApp_ZUI_ACT_BTLinkPhotoWinProc(HWND hwnd, PMSG msg)
{
    switch(msg->message)
    {
        case MSG_PAINT:
        {
            switch(hwnd)
            {
                case HWND_BT_DOWNLOAD_MAINLINK0_ITEM0_PHOTO:
                case HWND_BT_DOWNLOAD_MAINLINK0_ITEM1_PHOTO:
                case HWND_BT_DOWNLOAD_MAINLINK0_ITEM2_PHOTO:
                case HWND_BT_DOWNLOAD_MAINLINK0_ITEM3_PHOTO:
                case HWND_BT_DOWNLOAD_MAINLINK0_ITEM4_PHOTO:
                case HWND_BT_DOWNLOAD_MAINLINK0_ITEM5_PHOTO:
                    {
                        U8 u8ItemIdx;
                        for(u8ItemIdx=0;u8ItemIdx<NUM_OF_MAINLINK0_PHOTO_PER_PAGE;u8ItemIdx++)
                        {
                            if(hwnd == _MainLink0PageItemPhotoHwndList[u8ItemIdx])
                            {
                                break;
                            }
                        }
                        if(u8ItemIdx < NUM_OF_MAINLINK0_PHOTO_PER_PAGE)
                        {
                            MApp_BT_SetMainLink0PhotoShow(u8ItemIdx,TRUE);
                        }
                    }
                    break;
                case HWND_BT_DOWNLOAD_MAINLINK1_ITEM0_PHOTO:
                case HWND_BT_DOWNLOAD_MAINLINK1_ITEM1_PHOTO:
                case HWND_BT_DOWNLOAD_MAINLINK1_ITEM2_PHOTO:
                case HWND_BT_DOWNLOAD_MAINLINK1_ITEM3_PHOTO:
                case HWND_BT_DOWNLOAD_MAINLINK1_ITEM4_PHOTO:
                case HWND_BT_DOWNLOAD_MAINLINK1_ITEM5_PHOTO:
                    {
                        U8 u8ItemIdx;
                        for(u8ItemIdx=0;u8ItemIdx<NUM_OF_MAINLINK1_PHOTO_PER_PAGE;u8ItemIdx++)
                        {
                            if(hwnd == _MainLink1PageItemPhotoHwndList[u8ItemIdx])
                            {
                                break;
                            }
                        }
                        if(u8ItemIdx < NUM_OF_MAINLINK1_PHOTO_PER_PAGE)
                        {
                            MApp_BT_SetMainLink1PhotoShow(u8ItemIdx,TRUE);
                        }
                    }
                    break;
                default:
                    break;
            }
        }
        break;
        default:
            break;
    }
    return DEFAULTWINPROC(hwnd, msg);
}

S32 MApp_ZUI_ACT_BTDescriptionWinProc(HWND hWnd, PMSG pMsg)
{
    switch(pMsg->message)
    {
        case MSG_PAINT:
            {
                //get buffer GC for offline drawing...
                PAINT_PARAM * param = (PAINT_PARAM*)pMsg->wParam;
                //DRAWSTYLE * style_list = 0;
                DRAWSTYLE_TYPE ds_type = DS_NORMAL;

                //find all static text => dynamic text
                if (param->bIsDisable)
                {
                    param->dc.u8ConstantAlpha = MApp_ZUI_API_GetDisableAlpha(hWnd);
                    //style_list = GETDISABLEDRAWSTYLE(hWnd);
                    ds_type = DS_DISABLE;
                }
                else if (param->bIsFocus) //the same focus group
                {
                    param->dc.u8ConstantAlpha = MApp_ZUI_API_GetFocusAlpha(hWnd);
                    //style_list = GETFOCUSDRAWSTYLE(hWnd);
                    ds_type = DS_FOCUS;
                }
                else
                {
                    param->dc.u8ConstantAlpha = MApp_ZUI_API_GetNormalAlpha(hWnd);
                    //style_list = GETNORMALDRAWSTYLE(hWnd);
                }

                //if (style_list)
                {
                    //while(style_list->component != CP_NOON)
                    {
                        _MApp_ZUI_API_DefaultOnPaint(hWnd, param, FALSE);
                        //if (style_list->component == CP_TEXT_OUT)
                        {
                            U16 u16TxtComponentIndex = _MApp_ZUI_API_FindFirstComponentIndex(hWnd, ds_type, CP_TEXT_OUT);
                            LPTSTR pStr = MApp_ZUI_ACT_GetDynamicText(hWnd);
                            if (u16TxtComponentIndex != 0xFFFF && pStr)
                            {
                                DRAW_PUNCTUATED_DYNAMIC dyna;
                                //dyna = (DRAW_PUNCTUATED_DYNAMIC*)_ZUI_MALLOC(sizeof(DRAW_PUNCTUATED_DYNAMIC));
                                //if (dyna)
                                {

                                    _MApp_ZUI_API_ConvertTextComponentToPunctuated(u16TxtComponentIndex, &dyna);
                                    dyna.pString = pStr;
                                    dyna.max_row = MApp_ZUI_API_GetWindowData(hWnd);
                                    _MApp_ZUI_API_DrawDynamicComponent(CP_BT_TEXT_DYNAMIC, &dyna, &param->dc, param->rect);
                                    //_ZUI_FREE(dyna);
                                }
                            }
                        }
                        //else
                        //{
                        //    _MApp_ZUI_API_DrawComponent(style_list->component, style_list->u16Index, &param->dc, param->rect);
                        //}
                        //style_list++;
                    }
                }

            }
            return 0;

        default:
            break;

    }
    return DEFAULTWINPROC(hWnd, pMsg);
}


void MApp_ZUI_ACT_TerminateBT(void)
{
    ZUI_MSG(printf("[]term:BT\n"));
    MApp_BT_Main_Exit();
}

LPTSTR MApp_ZUI_ACT_GetBTDynamicText(HWND hwnd)
{
    TorrentFileInfo fileInfo;
    MainLink0Info   link0Info;
    MainLink1Info   link1Info;
    SearchListFileInfo enSearchfileInfo;
    U8 u8ItemIdx;
    CHAR_BUFFER[0] = 0;
    CHAR_BUFFER[1] = 0;
    //printf("Dynamic Text : hwnd(%d)\n", (U16)hwnd);
    switch(hwnd)
    {
    case HWND_BT_DOWNLOAD_DOWNLOAD_ITEM0_FILE_NAME:
    case HWND_BT_DOWNLOAD_DOWNLOAD_ITEM1_FILE_NAME:
    case HWND_BT_DOWNLOAD_DOWNLOAD_ITEM2_FILE_NAME:
    case HWND_BT_DOWNLOAD_DOWNLOAD_ITEM3_FILE_NAME:
    case HWND_BT_DOWNLOAD_DOWNLOAD_ITEM4_FILE_NAME:
        for(u8ItemIdx=0;u8ItemIdx<NUM_OF_TORRENT_FILES_PER_PAGE;u8ItemIdx++)
        {
            if(hwnd == _DownloadPageItemFileNameHwndList[u8ItemIdx])
            {
                break;
            }
        }
#if 1
        if((u8ItemIdx < NUM_OF_TORRENT_FILES_PER_PAGE) && MApp_BT_QueryTorrentFileInfo(u8ItemIdx, &fileInfo))
        {
            U8 u8Count = 0, u8Len = 0;

            snprintf((char*)CHAR_BUFFER, 5, "%2d.  ", (u8ItemIdx+1));
            BT_ASCII2Unicode((U8*)CHAR_BUFFER);
            // Get Sting Len
            for( u8Count = 0; u8Count<255; u8Count++)
            {
                if(CHAR_BUFFER[u8Count]==0)
                {
                    u8Len=u8Count;
                    break;
                }
            }

            MApp_BT_HexToUnicode( fileInfo.u8LongFileName, CHAR_BUFFER+u8Len,sizeof(fileInfo.u8LongFileName), 1000);
        }

#else
        if((u8ItemIdx < NUM_OF_TORRENT_FILES_PER_PAGE) && MApp_BT_QueryTorrentFileInfo(u8ItemIdx, &fileInfo))
        {
            U8 u8Count = 0, u8Len = 0, u8Temp;
            snprintf((char*)CHAR_BUFFER, 5, "%2d.  ", (u8ItemIdx+1));
            // Get Sting Len
            for( u8Count = 0; u8Count<255; u8Count++)
            {
                if((u8Count%2) == 0)
                    u8Temp = (U8)CHAR_BUFFER[u8Count/2];
                else
                    u8Temp = (U8)(CHAR_BUFFER[u8Count/2]>>8);

                if(u8Temp==0)
                {
                    u8Len=u8Count/2;
                    break;
                }
            }
            memcpy(CHAR_BUFFER+u8Len, fileInfo.u8LongFileName, sizeof(fileInfo.u8LongFileName));
        }
        BT_ASCII2Unicode((U8*)CHAR_BUFFER);
#endif

        break;
    case HWND_BT_DOWNLOAD_DOWNLOAD_ITEM0_FILE_SIZE:
    case HWND_BT_DOWNLOAD_DOWNLOAD_ITEM1_FILE_SIZE:
    case HWND_BT_DOWNLOAD_DOWNLOAD_ITEM2_FILE_SIZE:
    case HWND_BT_DOWNLOAD_DOWNLOAD_ITEM3_FILE_SIZE:
    case HWND_BT_DOWNLOAD_DOWNLOAD_ITEM4_FILE_SIZE:
        for(u8ItemIdx=0;u8ItemIdx<NUM_OF_TORRENT_FILES_PER_PAGE;u8ItemIdx++)
        {
            if(hwnd == _DownloadPageItemFileSizeHwndList[u8ItemIdx])
            {
                break;
            }
        }
        if((u8ItemIdx < NUM_OF_TORRENT_FILES_PER_PAGE) && MApp_BT_QueryTorrentFileInfo(u8ItemIdx, &fileInfo))
        {
            if((fileInfo.u32TotalFileSize/1024/1024) >= 1)
                snprintf((char*)CHAR_BUFFER, 10, "%dMB", fileInfo.u32TotalFileSize/1024/1024);
            else if((fileInfo.u32TotalFileSize/1024) >=1)
                snprintf((char*)CHAR_BUFFER, 8, "%dKB", fileInfo.u32TotalFileSize/1024);
            else
                snprintf((char*)CHAR_BUFFER, 8, "%dB", fileInfo.u32TotalFileSize);
            BT_ASCII2Unicode((U8*)CHAR_BUFFER);
        }
        break;
    case HWND_BT_DOWNLOAD_DOWNLOAD_ITEM0_FILE_PERCENT:
    case HWND_BT_DOWNLOAD_DOWNLOAD_ITEM1_FILE_PERCENT:
    case HWND_BT_DOWNLOAD_DOWNLOAD_ITEM2_FILE_PERCENT:
    case HWND_BT_DOWNLOAD_DOWNLOAD_ITEM3_FILE_PERCENT:
    case HWND_BT_DOWNLOAD_DOWNLOAD_ITEM4_FILE_PERCENT:
        for(u8ItemIdx=0;u8ItemIdx<NUM_OF_TORRENT_FILES_PER_PAGE;u8ItemIdx++)
        {
            if(hwnd == _DownloadPageItemFilePercentHwndList[u8ItemIdx])
            {
                break;
            }
        }
        if((u8ItemIdx < NUM_OF_TORRENT_FILES_PER_PAGE) && MApp_BT_QueryTorrentFileInfo(u8ItemIdx, &fileInfo))
        {
            U8 u8Percent;
            u8Percent=100-(fileInfo.u32LeftFileSize/128)*100/(fileInfo.u32TotalFileSize/128);
            if(u8Percent>100)
                u8Percent = 100;
            snprintf((char*)CHAR_BUFFER, 5, "%d%c", u8Percent,'\%');
            BT_ASCII2Unicode((U8*)CHAR_BUFFER);
        }
        break;
    case HWND_BT_DOWNLOAD_DOWNLOAD_ITEM0_DOWNLOAD_SPEED:
    case HWND_BT_DOWNLOAD_DOWNLOAD_ITEM1_DOWNLOAD_SPEED:
    case HWND_BT_DOWNLOAD_DOWNLOAD_ITEM2_DOWNLOAD_SPEED:
    case HWND_BT_DOWNLOAD_DOWNLOAD_ITEM3_DOWNLOAD_SPEED:
    case HWND_BT_DOWNLOAD_DOWNLOAD_ITEM4_DOWNLOAD_SPEED:
        for(u8ItemIdx=0;u8ItemIdx<NUM_OF_TORRENT_FILES_PER_PAGE;u8ItemIdx++)
        {
            if(hwnd == _DownloadPageItemDownloadSpeedHwndList[u8ItemIdx])
            {
                break;
            }
        }
        if((u8ItemIdx < NUM_OF_TORRENT_FILES_PER_PAGE) && MApp_BT_QueryTorrentFileInfo(u8ItemIdx, &fileInfo))
        {
            if((fileInfo.u32DownloadSpeed/1024/1024) >= 1)
                snprintf((char*)CHAR_BUFFER, 10, "%dMB", fileInfo.u32DownloadSpeed/1024/1024);
            else if((fileInfo.u32DownloadSpeed/1024) >=1)
                snprintf((char*)CHAR_BUFFER, 8, "%dKB", fileInfo.u32DownloadSpeed/1024);
            else
                snprintf((char*)CHAR_BUFFER, 8, "%dB", fileInfo.u32DownloadSpeed);
            BT_ASCII2Unicode((U8*)CHAR_BUFFER);
        }
        break;
    case HWND_BT_DOWNLOAD_DOWNLOAD_ITEM0_TIME_LEFT:
    case HWND_BT_DOWNLOAD_DOWNLOAD_ITEM1_TIME_LEFT:
    case HWND_BT_DOWNLOAD_DOWNLOAD_ITEM2_TIME_LEFT:
    case HWND_BT_DOWNLOAD_DOWNLOAD_ITEM3_TIME_LEFT:
    case HWND_BT_DOWNLOAD_DOWNLOAD_ITEM4_TIME_LEFT:
        for(u8ItemIdx=0;u8ItemIdx<NUM_OF_TORRENT_FILES_PER_PAGE;u8ItemIdx++)
        {
            if(hwnd == _DownloadPageItemTimeLeftHwndList[u8ItemIdx])
            {
                break;
            }
        }
        if((u8ItemIdx < NUM_OF_TORRENT_FILES_PER_PAGE) && MApp_BT_QueryTorrentFileInfo(u8ItemIdx, &fileInfo))
        {
            U32 u32TimeLeft;
            u32TimeLeft=(fileInfo.u32LeftFileSize/fileInfo.u32DownloadSpeed);

            if(fileInfo.u32LeftFileSize == 0)
                snprintf((char*)CHAR_BUFFER, 16, " ");
            else if((u32TimeLeft/60/60) >= 100)
                snprintf((char*)CHAR_BUFFER, 16, "99:99:99");
            else if((u32TimeLeft/60/60) >= 1)
                snprintf((char*)CHAR_BUFFER, 16, "%d:%02d:00", u32TimeLeft/60/60,u32TimeLeft%60);
            else if((u32TimeLeft/60) >= 1)
                snprintf((char*)CHAR_BUFFER,18,  "00:%02d:%02d", u32TimeLeft/60,u32TimeLeft%60);
            else
                snprintf((char*)CHAR_BUFFER, 9, "00:00:%02d", u32TimeLeft);
            /*
            if((u32TimeLeft/60/60/24) >= 1)
                snprintf((char*)CHAR_BUFFER, 15, "%dDay:%dHour", u32TimeLeft/60/60/24,(u32TimeLeft/60/60)%24);
            else if((u32TimeLeft/60/60) >= 1)
                snprintf((char*)CHAR_BUFFER, 16, "%dHour:%dMinute", u32TimeLeft/60/60,u32TimeLeft%60);
            else if((u32TimeLeft/60) >= 1)
                snprintf((char*)CHAR_BUFFER,18,  "%dMinute:%dSecond", u32TimeLeft/60,u32TimeLeft%60);
            else
                snprintf((char*)CHAR_BUFFER, 9, "%dSecond", u32TimeLeft);
                */
            BT_ASCII2Unicode((U8*)CHAR_BUFFER);
        }
        break;
    case HWND_BT_DOWNLOAD_TORRENT_SEARCH_IME_ITEM1:
    case HWND_BT_DOWNLOAD_TORRENT_SEARCH_IME_ITEM2:
    case HWND_BT_DOWNLOAD_TORRENT_SEARCH_IME_ITEM3:
    case HWND_BT_DOWNLOAD_TORRENT_SEARCH_IME_ITEM4:
    case HWND_BT_DOWNLOAD_TORRENT_SEARCH_IME_ITEM5:
    case HWND_BT_DOWNLOAD_TORRENT_SEARCH_IME_ITEM6:
    case HWND_BT_DOWNLOAD_TORRENT_SEARCH_IME_ITEM7:
    case HWND_BT_DOWNLOAD_TORRENT_SEARCH_IME_ITEM8:
        if(enBT_IME.uIME_State == STATE_IME_NULL)
            break;
        for(u8ItemIdx=0;u8ItemIdx<NUM_OF_IME_CHARS_PER_PAGE;u8ItemIdx++)
        {
            if(hwnd == _IME_PAGE_HwndList[u8ItemIdx])
            {
                break;
            }
        }
        if((u8ItemIdx < NUM_OF_IME_CHARS_PER_PAGE) && (u8ItemIdx < (enBT_IME.u16SpellCounter - enBT_IME.u16SpellStar)) )
        {
            if(enBT_IME.uIME_State == STATE_IME_SPELL)
            {
                snprintf((char*)CHAR_BUFFER, 11, "%d: %s", u8ItemIdx+1, enBT_IME.u8Sting[u8ItemIdx]);
                BT_ASCII2Unicode((U8*)CHAR_BUFFER);
            }
            else if(enBT_IME.uIME_State == STATE_IME_CHS)
            {
                CHAR_BUFFER[0] = CHAR_0 + (u8ItemIdx+1);
                CHAR_BUFFER[1] = CHAR_COLON;
                CHAR_BUFFER[2] = CHAR_SPACE;
                CHAR_BUFFER[3] = ((enBT_IME.u8Sting[u8ItemIdx][1]<<8) + enBT_IME.u8Sting[u8ItemIdx][0]);
                CHAR_BUFFER[4] = 0;
            }
        }
        break;
    case HWND_BT_DOWNLOAD_SEARCH_STRING:
        {
            U8 u8Count = 0, u8Len = 0;
            // Get Sting Len
            for( u8Count = 0; u8Count<NUM_OF_SEARCH_STRING; u8Count++)
            {
                if(enBT_IME.u16StringName[u8Count]==0)
                {
                    u8Len=u8Count;
                    break;
                }
            }
            if(u8Len > 0)
            {
                for( u8Count = 0; u8Count<u8Len; u8Count++ )
                    CHAR_BUFFER[u8Count] = enBT_IME.u16StringName[u8Count];
            }
            CHAR_BUFFER[u8Len] = CHAR_US;
            CHAR_BUFFER[u8Len + 1] = 0;
            if( enBT_IME.uIME_State == STATE_IME_SETP3)
                enBT_IME.uIME_State = STATE_IME_NULL;
        }
        break;
    case HWND_BT_DOWNLOAD_SEARCHING_LIST_ITEM1_FILE_NAME:
    case HWND_BT_DOWNLOAD_SEARCHING_LIST_ITEM2_FILE_NAME:
    case HWND_BT_DOWNLOAD_SEARCHING_LIST_ITEM3_FILE_NAME:
    case HWND_BT_DOWNLOAD_SEARCHING_LIST_ITEM4_FILE_NAME:
    case HWND_BT_DOWNLOAD_SEARCHING_LIST_ITEM5_FILE_NAME:
        for(u8ItemIdx=0;u8ItemIdx<NUM_OF_TORRENT_FILES_PER_PAGE;u8ItemIdx++)
        {
            if(hwnd == _SearchListPageItemFileNameHwndList[u8ItemIdx])
            {
                break;
            }
        }
        //u8SearchListPage*NUM_OF_TORRENT_FILES_PER_PAGE
        if((u8ItemIdx < NUM_OF_TORRENT_FILES_PER_PAGE) && ((U32)(u8ItemIdx + (u8SearchListPage*NUM_OF_TORRENT_FILES_PER_PAGE)) < MApp_BT_GetSearchFileNum()) && MApp_BT_QuerySearchListFileInfo(u8ItemIdx, &enSearchfileInfo))
        {
            U8 u8Count = 0, u8Len = 0;
            snprintf((char*)CHAR_BUFFER, 7, "%d. ", u8ItemIdx+1 + (u8SearchListPage*NUM_OF_TORRENT_FILES_PER_PAGE));
            BT_ASCII2Unicode((U8*)CHAR_BUFFER);
            // Get Sting Len
            for( u8Count = 0; u8Count<255; u8Count++)
            {
                if(CHAR_BUFFER[u8Count]==0)
                {
                    u8Len=u8Count;
                    break;
                }
            }
            memcpy(CHAR_BUFFER+u8Len, enSearchfileInfo.u16SearchList_FileName, sizeof(enSearchfileInfo.u16SearchList_FileName));
        }
        break;
    case HWND_BT_DOWNLOAD_SEARCHING_LIST_ITEM1_FILE_SIZE:
    case HWND_BT_DOWNLOAD_SEARCHING_LIST_ITEM2_FILE_SIZE:
    case HWND_BT_DOWNLOAD_SEARCHING_LIST_ITEM3_FILE_SIZE:
    case HWND_BT_DOWNLOAD_SEARCHING_LIST_ITEM4_FILE_SIZE:
    case HWND_BT_DOWNLOAD_SEARCHING_LIST_ITEM5_FILE_SIZE:
        for(u8ItemIdx=0;u8ItemIdx<NUM_OF_TORRENT_FILES_PER_PAGE;u8ItemIdx++)
        {
            if(hwnd == _SearchListPageItemFileSizeHwndList[u8ItemIdx])
            {
                break;
            }
        }
        if((u8ItemIdx < NUM_OF_TORRENT_FILES_PER_PAGE) && ((U32)(u8ItemIdx + (u8SearchListPage*NUM_OF_TORRENT_FILES_PER_PAGE)) < MApp_BT_GetSearchFileNum()) && MApp_BT_QuerySearchListFileInfo(u8ItemIdx, &enSearchfileInfo))
        {
            if((enSearchfileInfo.u32TotalFileSize/1024/1024) >= 1)
                snprintf((char*)CHAR_BUFFER,  10, "%dGB", enSearchfileInfo.u32TotalFileSize/1024/1024);
            else if((enSearchfileInfo.u32TotalFileSize/1024) >=1)
                snprintf((char*)CHAR_BUFFER, 8, "%dMB", enSearchfileInfo.u32TotalFileSize/1024);
            else
                snprintf((char*)CHAR_BUFFER, 8, "%dKB", enSearchfileInfo.u32TotalFileSize);
            BT_ASCII2Unicode((U8*)CHAR_BUFFER);
        }
        break;
    case HWND_BT_DOWNLOAD_SEARCHING_LIST_ITEM1_FILE_TYPE:
    case HWND_BT_DOWNLOAD_SEARCHING_LIST_ITEM2_FILE_TYPE:
    case HWND_BT_DOWNLOAD_SEARCHING_LIST_ITEM3_FILE_TYPE:
    case HWND_BT_DOWNLOAD_SEARCHING_LIST_ITEM4_FILE_TYPE:
    case HWND_BT_DOWNLOAD_SEARCHING_LIST_ITEM5_FILE_TYPE:
        for(u8ItemIdx=0;u8ItemIdx<NUM_OF_TORRENT_FILES_PER_PAGE;u8ItemIdx++)
        {
            if(hwnd == _SearchListPageItemFileTypeHwndList[u8ItemIdx])
            {
                break;
            }
        }
        if((u8ItemIdx < NUM_OF_TORRENT_FILES_PER_PAGE) && ((U32)(u8ItemIdx + (u8SearchListPage*NUM_OF_TORRENT_FILES_PER_PAGE)) < MApp_BT_GetSearchFileNum()) && MApp_BT_QuerySearchListFileInfo(u8ItemIdx , &enSearchfileInfo))
        {
            memcpy(CHAR_BUFFER, enSearchfileInfo.u8ExtFileName, sizeof(enSearchfileInfo.u8ExtFileName));
            BT_ASCII2Unicode((U8*)CHAR_BUFFER);
        }
        break;
    case HWND_BT_DOWNLOAD_SEARCHING_LIST_PAGE_VALUE:
        {
            U32 u32Tmp = MApp_BT_GetSearchFileNum();
            if(u32Tmp>0)
                u32Tmp = (u32Tmp -1)/NUM_OF_TORRENT_FILES_PER_PAGE;
            snprintf((char*)CHAR_BUFFER, 8, "%d/%d", u8SearchListPage+1, u32Tmp+1);
            BT_ASCII2Unicode((U8*)CHAR_BUFFER);
        }
        break;
    case HWND_BT_DOWNLOAD_SETUP_PORT_VALUE:
                snprintf((char*)CHAR_BUFFER, 6, "%d", stGenSetting.TorrentSetupInfo.u16port);
                //printf("\r\n stGenSetting.TorrentSetupInfo.u16port = %d", stGenSetting.TorrentSetupInfo.u16port);
                BT_ASCII2Unicode((U8*)CHAR_BUFFER);
        break;
    case HWND_BT_DOWNLOAD_SETUP_DOWNLOADLIMIT_VALUE:
                snprintf((char*)CHAR_BUFFER, 5, "%d", stGenSetting.TorrentSetupInfo.u16DownloadLimit);
                //printf("\r\n stGenSetting.TorrentSetupInfo.u16DownloadLimit = %d", stGenSetting.TorrentSetupInfo.u16DownloadLimit);
                BT_ASCII2Unicode((U8*)CHAR_BUFFER);
        break;
    case HWND_BT_DOWNLOAD_SETUP_MAXSESSION_VALUE:
                snprintf((char*)CHAR_BUFFER, 3, "%d", stGenSetting.TorrentSetupInfo.u8MaxSession);
                BT_ASCII2Unicode((U8*)CHAR_BUFFER);
        break;
    case HWND_BT_DOWNLOAD_SETUP_UPLOAD_VALUE:
                snprintf((char*)CHAR_BUFFER, 6, "%d", stGenSetting.TorrentSetupInfo.u16UploadLimit);
                BT_ASCII2Unicode((U8*)CHAR_BUFFER);
        break;
    case HWND_BT_DOWNLOAD_SETUP_SERVER_ADDRESS:
                memcpy(CHAR_BUFFER, stGenSetting.TorrentSetupInfo.u8ServerName, sizeof(stGenSetting.TorrentSetupInfo.u8ServerName));
                BT_ASCII2Unicode((U8*)CHAR_BUFFER);
        break;
    case HWND_BT_DOWNLOAD_TORRENT_SEARCH_HELP_GREEN:
                if(enBT_IME.bIsCAPs)
                    return MApp_ZUI_API_GetString(en_str_BT_IME_Caps_Uppercase);
                else
                    return MApp_ZUI_API_GetString(en_str_BT_IME_Caps_Lowercase);
        break;
    case HWND_BT_DOWNLOAD_TORRENT_SEARCH_HELP_YELLOW:
                if(enBT_IME.bIsEnglish)
                    return MApp_ZUI_API_GetString(en_str_BT_IME_English);
                else
                    return MApp_ZUI_API_GetString(en_str_BT_IME_Chinese);
        break;
    case HWND_BT_DOWNLOAD_KEYBOARD_SYMBOL_ITEMS:
                memcpy(CHAR_BUFFER, u8_Array_BTKeyboard_Symbol[0], sizeof(u8_Array_BTKeyboard_Symbol[0]));
                BT_ASCII2Unicode((U8*)CHAR_BUFFER);
        break;
    case HWND_BT_DOWNLOAD_KEYBOARD_SYMBOL_LINE0:
                memcpy(CHAR_BUFFER, u8_Array_BTKeyboard_Symbol[1], sizeof(u8_Array_BTKeyboard_Symbol[1]));
                BT_ASCII2Unicode((U8*)CHAR_BUFFER);
        break;
    case HWND_BT_DOWNLOAD_KEYBOARD_SYMBOL_LINE1:
                memcpy(CHAR_BUFFER, u8_Array_BTKeyboard_Symbol[2], sizeof(u8_Array_BTKeyboard_Symbol[2]));
                BT_ASCII2Unicode((U8*)CHAR_BUFFER);
        break;
    case HWND_BT_DOWNLOAD_KEYBOARD_SYMBOL_LINE2:
                memcpy(CHAR_BUFFER, u8_Array_BTKeyboard_Symbol[3], sizeof(u8_Array_BTKeyboard_Symbol[3]));
                BT_ASCII2Unicode((U8*)CHAR_BUFFER);
        break;
    case HWND_BT_DOWNLOAD_MAINLINK0_ITEM0_NAME:
    case HWND_BT_DOWNLOAD_MAINLINK0_ITEM1_NAME:
    case HWND_BT_DOWNLOAD_MAINLINK0_ITEM2_NAME:
    case HWND_BT_DOWNLOAD_MAINLINK0_ITEM3_NAME:
    case HWND_BT_DOWNLOAD_MAINLINK0_ITEM4_NAME:
    case HWND_BT_DOWNLOAD_MAINLINK0_ITEM5_NAME:
        for(u8ItemIdx=0;u8ItemIdx<NUM_OF_MAINLINK0_PHOTO_PER_PAGE;u8ItemIdx++)
        {
            if(hwnd == _MainLink0PageItemNameHwndList[u8ItemIdx])
            {
                break;
            }
        }
        if((u8ItemIdx < NUM_OF_MAINLINK0_PHOTO_PER_PAGE) && MApp_BT_QueryMainLink0Info(u8ItemIdx, &link0Info))
        {
            memcpy(CHAR_BUFFER, link0Info.u8LinkFile_FileName, sizeof(link0Info.u8LinkFile_FileName));
        }
        break;
    case HWND_BT_DOWNLOAD_MAINLINK0_DESCRIPT:
    case HWND_BT_DOWNLOAD_MAINLINK1_DESCRIPT:
        if( MApp_BT_GetDescriptionFileState() == STATE_GET_DESCRIPTION_OK )
        {
            U32 u32SrcAddr = MApp_BT_GetDescriptionBuffAddr();
            U32 u32Size;
            U8 *pSrc;

            pSrc = (U8 *)u32SrcAddr;

            if(MApp_BT_GetDescriptionFileSize() > DESCRIPTION_MAX_SIZE)
                u32Size = DESCRIPTION_MAX_SIZE;
            else
                u32Size = MApp_BT_GetDescriptionFileSize();

            if(u32Size > 0)
            {
                MApp_BT_MappingToUnicode( pSrc, CHAR_BUFFER,u32Size, DESCRIPTION_MAX_SIZE);
            }

            MApp_BT_SetDescriptionFileState(STATE_GET_DESCRIPTION_NONE);

            // for No description file
            if(u32Size == 0)
                return MApp_ZUI_API_GetString(en_str_BT_No_Description_File);

        }
        else
        {
            CHAR_BUFFER[0] = 0;
        }
#if 0
        //for  test
        for(u8ItemIdx=0;u8ItemIdx<NUM_OF_MAINLINK0_PHOTO_PER_PAGE;u8ItemIdx++)
        {
            if(MApp_ZUI_API_GetFocus() == _MainLink0PageItemNameHwndList[u8ItemIdx])
            {
                break;
            }
        }
        if((u8ItemIdx < NUM_OF_MAINLINK0_PHOTO_PER_PAGE) && MApp_BT_QueryMainLink0Info(u8ItemIdx, &link0Info))
        {
            memcpy(CHAR_BUFFER, link0Info.u8LinkFileDes_FileName, sizeof(link0Info.u8LinkFileDes_FileName));//need modify late
        }
#endif
        break;
    case HWND_BT_DOWNLOAD_MAINLINK1_ITEM0_NAME:
    case HWND_BT_DOWNLOAD_MAINLINK1_ITEM1_NAME:
    case HWND_BT_DOWNLOAD_MAINLINK1_ITEM2_NAME:
    case HWND_BT_DOWNLOAD_MAINLINK1_ITEM3_NAME:
    case HWND_BT_DOWNLOAD_MAINLINK1_ITEM4_NAME:
    case HWND_BT_DOWNLOAD_MAINLINK1_ITEM5_NAME:
        for(u8ItemIdx=0;u8ItemIdx<NUM_OF_MAINLINK1_PHOTO_PER_PAGE;u8ItemIdx++)
        {
            if(hwnd == _MainLink1PageItemNameHwndList[u8ItemIdx])
            {
                break;
            }
        }
        if((u8ItemIdx < NUM_OF_MAINLINK1_PHOTO_PER_PAGE) && MApp_BT_QueryMainLink1Info(u8ItemIdx, &link1Info))
        {
            memcpy(CHAR_BUFFER, link1Info.u8LinkFile_FileName, sizeof(link1Info.u8LinkFile_FileName));
        }
        break;
 #if 0
    case HWND_BT_DOWNLOAD_MAINLINK1_DESCRIPT:
        for(u8ItemIdx=0;u8ItemIdx<NUM_OF_MAINLINK1_PHOTO_PER_PAGE;u8ItemIdx++)
        {
            if(MApp_ZUI_API_GetFocus() == _MainLink1PageItemNameHwndList[u8ItemIdx])
            {
                break;
            }
        }
        if((u8ItemIdx < NUM_OF_MAINLINK1_PHOTO_PER_PAGE) && MApp_BT_QueryMainLink1Info(u8ItemIdx, &link1Info))
        {
            memcpy(CHAR_BUFFER, link1Info.u8LinkFileDes_FileName, sizeof(link1Info.u8LinkFileDes_FileName));//need modify late
        }
        break;
  #endif
    case HWND_BT_SEARCH_SEARCHING_STRING:
        switch(enBTSearchState)
        {
            case BT_SEARCH_STATE_WAIT:
                    return MApp_ZUI_API_GetString(en_str_BT_Search_Info_Wait);
                break;
            case BT_SEARCH_STATE_TIME_OUT:
                    return MApp_ZUI_API_GetString(en_str_BT_Search_Info_Time_Out);
                break;
            case BT_SEARCH_STATE_NOTHING:
                    return MApp_ZUI_API_GetString(en_str_BT_Search_Info_Search_Nothing);
                break;
            case BT_SEARCH_STATE_INPUT_ERROR:
                    return MApp_ZUI_API_GetString(en_str_BT_Search_Info_Input_Error);
                break;
            default:
                    printf("None\n ");
                break;
        }
        break;

    case HWND_BT_SYSTEM_INFO_STRING:
        switch(MApp_Get_System_ErrorState())
        {
            case MB_BTC_ERR_NETWORK:
                    return MApp_ZUI_API_GetString(en_str_BT_System_Info_NetWorkError);
                break;
            case MB_BTC_ERR_STORAGE:
                    return MApp_ZUI_API_GetString(en_str_BT_System_Info_UsbStorageError);
                break;
            case MB_BTC_ERR_UNRESOLVED_HOST:
                    return MApp_ZUI_API_GetString(en_str_BT_System_Info_GetHostNameFail);
                break;
            case MB_BTC_ERR_DN_TOR:
            case MB_BTC_ERR_ADD_TOR:
                    return MApp_ZUI_API_GetString(en_str_BT_System_Info_GetTorrentFileFail);
                break;
            default:
                    return MApp_ZUI_API_GetString(en_str_BT_System_Info_UnknownError);
                break;
        }
        break;

    default:
        break;
    }
    return CHAR_BUFFER;
}

U16 MApp_ZUI_ACT_GetBTDynamicBitmap(HWND hwnd, DRAWSTYLE_TYPE ds_type)
{
    TorrentFileInfo fileInfo;
    U8 u8ItemIdx;

    ds_type = ds_type;

    switch(hwnd)
    {
        case HWND_BT_DOWNLOAD_TORRENT_SEARCH_IME_LEFT_ARROW:
            if((!enBT_IME.bIsEnglish) && ( enBT_IME.u16SpellStar >= NUM_OF_IME_CHARS_PER_PAGE) )
                return E_BMP_TRIANGLE_LEFT;
            break;
        case HWND_BT_DOWNLOAD_TORRENT_SEARCH_IME_RIGHT_ARROW:
            if((!enBT_IME.bIsEnglish) && ((enBT_IME.u16SpellCounter - enBT_IME.u16SpellStar) >= NUM_OF_IME_CHARS_PER_PAGE) )
                return E_BMP_TRIANGLE_RIGHT;
            break;

        case HWND_BT_DOWNLOAD_DOWNLOAD_ITEM0_STATE:
        case HWND_BT_DOWNLOAD_DOWNLOAD_ITEM1_STATE:
        case HWND_BT_DOWNLOAD_DOWNLOAD_ITEM2_STATE:
        case HWND_BT_DOWNLOAD_DOWNLOAD_ITEM3_STATE:
        case HWND_BT_DOWNLOAD_DOWNLOAD_ITEM4_STATE:

            for(u8ItemIdx=0;u8ItemIdx<NUM_OF_TORRENT_FILES_PER_PAGE;u8ItemIdx++)
            {
                if(hwnd == _DownloadPageItemFileStateHwndList[u8ItemIdx])
                {
                    break;
                }
            }
            if((u8ItemIdx < NUM_OF_TORRENT_FILES_PER_PAGE) && MApp_BT_QueryTorrentFileInfo(u8ItemIdx, &fileInfo))
            {
                //printf("DownLoad_state: [%02x]\n", fileInfo.u8State);
                switch(fileInfo.u8State)
                {
                    case BT_TORRENT_STATE_INACTIVE:
                        if(fileInfo.u32LeftFileSize == 0)
                            return E_BMP_BT_OK;
                        else if(fileInfo.u32LeftFileSize < fileInfo.u32TotalFileSize)
                            return E_BMP_BT_STOP;
                        break;
                    case BT_TORRENT_STATE_START:
                        return E_BMP_BT_PLAY;
                        break;
                    case BT_TORRENT_STATE_STOP:
                        return E_BMP_BT_STOP;
                        break;
                    case BT_TORRENT_STATE_LEECH:
                        return E_BMP_BT_PLAY;
                        break;
                    case BT_TORRENT_STATE_SEED:
                        return E_BMP_BT_PLAY;
                        break;
                    default:
                        break;
                }
            }
            break;
        case HWND_BT_SYSTEM_INIT_BMP:
            if(_u8BtInitCount>=BT_INIT_BMP_FLASH_COUNT)
                return E_BMP_NETWORK_FOCUS;
            else
                return E_BMP_NETWORK_UNFOCUS;
            break;
        default:
            break;
    }
    return 0xFFFF; //for empty bitmap....
}

void MApp_BT_GetZUIFbAttr(GOP_GwinFBAttr *pFbAttr)
{
    GRAPHIC_DC *dc = MApp_ZUI_API_GetScreenDC();
    MApi_GOP_GWIN_GetFBInfo(dc->u8FbID, pFbAttr);
}

void MApp_ZUI_ACT_AppShowBTSearchResult(void) //HWND sender)
{
        switch(enBTSearchState)
        {
            case BT_SEARCH_STATE_WAIT:
                break;
            case BT_SEARCH_STATE_TIME_OUT:
            case BT_SEARCH_STATE_NOTHING:
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_BT_DOWNLOAD_SEARCHING_INFO_PAGE);
                MApp_ZUI_API_KillTimer(HWND_BT_DOWNLOAD_SEARCHING_INFO_PAGE, 0);
                //enBTSearchState = BT_SEARCH_STATE_INIT;
                break;

            case BT_SEARCH_STATE_INPUT_SHOW:
                MApp_ZUI_API_ShowWindow(HWND_BT_DOWNLOAD_SEARCHING_INFO_PAGE, SW_HIDE);
                MApp_ZUI_API_ShowWindow(HWND_BT_DOWNLOAD_SOFTWARE_KEYBOARD, SW_HIDE);
                MApp_ZUI_API_ShowWindow(HWND_BT_DOWNLOAD_TORRENT_SEARCH, SW_HIDE);
                MApp_ZUI_API_ShowWindow(HWND_BT_DOWNLOAD_SEARCHING_LIST, SW_SHOW);
                MApp_ZUI_API_SetFocus(HWND_BT_DOWNLOAD_SEARCHING_LIST_ITEM1);
                MApp_ZUI_API_KillTimer(HWND_BT_DOWNLOAD_SEARCHING_INFO_PAGE, 0);
                enBTSearchState = BT_SEARCH_STATE_INIT;
                break;

            case BT_SEARCH_STATE_INPUT_ERROR:
                break;
            default:
                break;
        }
}

void MApp_ZUI_ACT_AppShowDownLoadListResult(HWND hwnd)
{
    hwnd = hwnd;
//    if()
//        break;

    if(!MApp_BT_GetDownloadList())
         return;

    MApp_ZUI_API_InvalidateAllSuccessors(HWND_BT_DOWNLOAD_DOWNLOAD_LIST);
}

void MApp_ZUI_ACT_AppShowToporNewListResult(HWND hwnd)
{
    if( MApp_BT_GetSearchFileState() != STATE_SEARCH_GET_LIST_OK )
    {
        if(!MApp_BT_QueryTopListOrNewListResult())
            return;
    }

    switch(hwnd)
    {
        case HWND_BT_DOWNLOAD_MAINLINK0_TITLE:
        case HWND_BT_DOWNLOAD_MAINLINK0_ITEM0_NAME:
        case HWND_BT_DOWNLOAD_MAINLINK0_ITEM1_NAME:
        case HWND_BT_DOWNLOAD_MAINLINK0_ITEM2_NAME:
        case HWND_BT_DOWNLOAD_MAINLINK0_ITEM3_NAME:
        case HWND_BT_DOWNLOAD_MAINLINK0_ITEM4_NAME:
        case HWND_BT_DOWNLOAD_MAINLINK0_ITEM5_NAME:
            MApp_ZUI_API_InvalidateAllSuccessors(HWND_BT_DOWNLOAD_MAINLINK0);
            MApp_ZUI_API_KillTimer(HWND_BT_DOWNLOAD_MAINLINK0_TITLE, 0);
            break;

        case HWND_BT_DOWNLOAD_MAINLINK1_TITLE:
        case HWND_BT_DOWNLOAD_MAINLINK1_ITEM0_NAME:
        case HWND_BT_DOWNLOAD_MAINLINK1_ITEM1_NAME:
        case HWND_BT_DOWNLOAD_MAINLINK1_ITEM2_NAME:
        case HWND_BT_DOWNLOAD_MAINLINK1_ITEM3_NAME:
        case HWND_BT_DOWNLOAD_MAINLINK1_ITEM4_NAME:
        case HWND_BT_DOWNLOAD_MAINLINK1_ITEM5_NAME:
            MApp_ZUI_API_InvalidateAllSuccessors(HWND_BT_DOWNLOAD_MAINLINK1);
            MApp_ZUI_API_KillTimer(HWND_BT_DOWNLOAD_MAINLINK1_TITLE, 0);
            break;

        default:
            break;
        }

}

void MApp_ZUI_ACT_AppShowToporNewListDescription(HWND hwnd)
{
    if(MApp_BT_GetDescriptionFileState() == STATE_GET_DESCRIPTION_INIT)
    {
        U8 u8ItemIdx;
        for(u8ItemIdx=0;u8ItemIdx<NUM_OF_MAINLINK0_PHOTO_PER_PAGE;u8ItemIdx++)
        {
            if(hwnd == _MainLink0PageItemNameHwndList[u8ItemIdx] || hwnd == _MainLink1PageItemNameHwndList[u8ItemIdx])
            {
                break;
            }
        }
        if((u8ItemIdx < NUM_OF_MAINLINK0_PHOTO_PER_PAGE) )
        {
            MApp_BT_QueryDescriptionFile(MApp_BT_GetTorrentFileID(u8ItemIdx));
            MApp_BT_SetDescriptionFileID(MApp_BT_GetTorrentFileID(u8ItemIdx));
        }
        return;
    }
    else if(MApp_BT_GetDescriptionFileState() == STATE_GET_DESCRIPTION_NONE)
    {
        return;
    }
    else if( MApp_BT_GetDescriptionFileState() != STATE_GET_DESCRIPTION_OK )
    {
        if(!MApp_BT_QueryTopListOrNewListDescription())
            return;
    }

    switch(hwnd)
    {
        case HWND_BT_DOWNLOAD_MAINLINK0_ITEM0_NAME:
        case HWND_BT_DOWNLOAD_MAINLINK0_ITEM1_NAME:
        case HWND_BT_DOWNLOAD_MAINLINK0_ITEM2_NAME:
        case HWND_BT_DOWNLOAD_MAINLINK0_ITEM3_NAME:
        case HWND_BT_DOWNLOAD_MAINLINK0_ITEM4_NAME:
        case HWND_BT_DOWNLOAD_MAINLINK0_ITEM5_NAME:
            MApp_ZUI_API_ShowWindow(HWND_BT_DOWNLOAD_MAINLINK0_DESCRIPT, SW_SHOW);
            //MApp_ZUI_API_KillTimer(HWND_BT_DOWNLOAD_MAINLINK0_TITLE, 0);
            break;

        case HWND_BT_DOWNLOAD_MAINLINK1_ITEM0_NAME:
        case HWND_BT_DOWNLOAD_MAINLINK1_ITEM1_NAME:
        case HWND_BT_DOWNLOAD_MAINLINK1_ITEM2_NAME:
        case HWND_BT_DOWNLOAD_MAINLINK1_ITEM3_NAME:
        case HWND_BT_DOWNLOAD_MAINLINK1_ITEM4_NAME:
        case HWND_BT_DOWNLOAD_MAINLINK1_ITEM5_NAME:
            MApp_ZUI_API_ShowWindow(HWND_BT_DOWNLOAD_MAINLINK1_DESCRIPT, SW_SHOW);
            //MApp_ZUI_API_KillTimer(HWND_BT_DOWNLOAD_MAINLINK1_TITLE, 0);
            break;

        default:
            break;
    }
}

void MApp_ZUI_ACT_AppShowBTSystemError(void)
{
    if(!(MApp_ZUI_API_GetFocus() == HWND_BT_SYSTEM_INFO))
    {
        MApp_ZUI_API_StoreFocusCheckpoint();
        MApp_ZUI_API_ShowWindow(HWND_BT_SYSTEM_INFO, SW_SHOW);
        MApp_ZUI_API_SetFocus(HWND_BT_SYSTEM_INFO);
    }

}

void MApp_ZUI_ACT_AppShowBTSystemErrorReturn(void)
{
    MApp_ZUI_API_ShowWindow(HWND_BT_SYSTEM_INFO, SW_HIDE);
    MApp_ZUI_API_RestoreFocusCheckpoint();
}

void MApp_ZUI_ACT_AppShowBT(void)
{
    HWND wnd;
    RECT rect;
    E_OSD_ID osd_id = E_OSD_BT_DOWNLOAD;

    g_GUI_WindowList = GetWindowListOfOsdTable(osd_id);
    g_GUI_WinDrawStyleList = GetWindowStyleOfOsdTable(osd_id);
    g_GUI_WindowPositionList = GetWindowPositionOfOsdTable(osd_id);
#if ZUI_ENABLE_ALPHATABLE
    g_GUI_WinAlphaDataList = GetWindowAlphaDataOfOsdTable(osd_id);
#endif
    HWND_MAX = GetWndMaxOfOsdTable(osd_id);
    OSDPAGE_BLENDING_ENABLE = IsBlendingEnabledOfOsdTable(osd_id);
    OSDPAGE_BLENDING_VALUE = GetBlendingValueOfOsdTable(osd_id);

    if (!_MApp_ZUI_API_AllocateVarData())
    {
        ZUI_DBG_FAIL(printf("[ZUI]ALLOC\n"));
        ABORT();
        return;
    }
    RECT_SET(rect,
        ZUI_BT_DOWNLOAD_XSTART, ZUI_BT_DOWNLOAD_YSTART,
        ZUI_BT_DOWNLOAD_WIDTH, ZUI_BT_DOWNLOAD_HEIGHT);
    if (!MApp_ZUI_API_InitGDI(&rect))
    {
        ZUI_DBG_FAIL(printf("[ZUI]GDIINIT\n"));
        ABORT();
        return;
    }
    for (wnd = 0; wnd < HWND_MAX; wnd++)
    {
        //printf("create msg: %lu\n", (U32)wnd);
        MApp_ZUI_API_SendMessage(wnd, MSG_CREATE, 0);
    }
        _MApp_BT_ShowDefaultPage();
        MApp_ZUI_API_ShowWindow(HWND_MAINFRAME, SW_HIDE);
        MApp_ZUI_API_ShowWindow(HWND_BT_DOWNLOAD_BG, SW_SHOW);
        MApp_ZUI_API_ShowWindow(HWND_BT_DOWNLOAD_MAIN_PAGE, SW_SHOW);
        MApp_ZUI_API_ShowWindow(HWND_BT_DOWNLOAD_DOWNLOAD_LIST, SW_SHOW);
    if(m_hwndFocus != HWND_INVALID)
    {
        MApp_ZUI_API_SetFocus(m_hwndFocus);
        m_hwndFocus = HWND_INVALID;
    }
    else
    {
        MApp_ZUI_API_SetFocus(HWND_BT_DOWNLOAD_DOWNLOAD_LIST_TITLE);
        _MApp_BT_SetPageType(HWND_BT_DOWNLOAD_DOWNLOAD_LIST_TITLE);
        MApp_ZUI_API_StoreFocusCheckpoint();
        MApp_ZUI_API_ShowWindow(HWND_BT_SYSTEM_INIT, SW_SHOW);
        MApp_ZUI_API_SetFocus(HWND_BT_SYSTEM_INIT);
    }
    MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_OPEN, E_ZUI_STATE_RUNNING);
    MApp_BT_IME_Init();
}

//////////////////////////////////////////////////////////
// Key Handler
//////////////////////////////////////////////////////////
BOOLEAN MApp_ZUI_ACT_HandleBTKey(VIRTUAL_KEY_CODE key)
{
    switch(key)
    {
        case VK_RED:
            break;
        case VK_GREEN:
            break;
        case VK_YELLOW:
            break;
        case VK_BLUE:
            break;
        case VK_EXIT:
            break;
        case VK_PLAY:
            MApp_BT_GetDownloadList();
            break;
        case VK_STOP:
            //MDrv_WriteByte(0x1EAA, 0x14);
            break;
        case VK_PAUSE:
            //MDrv_WriteByte(0x1EAA, 0x0C);
            break;

        case VK_SELECT:
            break;
        case VK_NUM_0:
        case VK_NUM_1:
        case VK_NUM_2:
        case VK_NUM_3:
        case VK_NUM_4:
        case VK_NUM_5:
        case VK_NUM_6:
        case VK_NUM_7:
        case VK_NUM_8:
        case VK_NUM_9:
            break;
        case VK_LEFT:
        case VK_RIGHT:
        case VK_UP:
        case VK_DOWN:
            ZUIBT_DBG(printf("VK_LRUD\n"));
            if(u8BTSetting_maxnum != 0xFF)
            {
                u8BTSetting_maxnum = 0xFF;      // reset to default count number for BT net setting
            }
            break;
        case VK_MENU:
            ZUIBT_DBG(printf("VK_MENU\n"));
            _MApp_BT_GotoMenuState();
            return TRUE;
        case VK_INPUT_SOURCE:
            _MApp_BT_GotoInputSourceState();
            return TRUE;
        case VK_POWER:
            MApp_ZUI_ACT_ExecuteBTAction(EN_EXE_POWEROFF);
            return TRUE;
        break;
        default:
            break;
    }
    return FALSE;
}

BOOLEAN MApp_ZUI_ACT_SoftwareKeySelect(U16 act)
{
    HWND wnd;
    U8  u8Char = 0, u8Temp = 0, u8Len = 0;
    act = act;
    wnd = MApp_ZUI_API_GetFocus();
    for (u8Temp = 0; u8Temp < COUNTOF(hwnd2key); u8Temp++)
    {
        if (MApp_ZUI_API_GetFocus()== hwnd2key[u8Temp][0])
        {
            u8Char = hwnd2key[u8Temp][1];
            break;
        }
    }
    printf("u8Char[%bx]\n", u8Char);
    // Input Error!!
    if(u8Char == 0)
        return FALSE;
    // Get Sting Len
    for( u8Temp = 0; u8Temp<NUM_OF_SEARCH_STRING; u8Temp++)
    {
        if(enBT_IME.u16StringName[u8Temp]==0)
        {
            u8Len = u8Temp;
            break;
        }
    }
    switch(_MApp_BT_GetPageType())
    {
            case TYPE_BT_TORRENT_SEARCH:
                    if( wnd == HWND_BT_DOWNLOAD_SOFTWARE_KEY_SYMBOL ) // disable "symbol" key
                        break;
                    switch(u8Char)
                    {
                        case 7: // for Symbol
                            MApp_ZUI_API_ShowWindow(HWND_BT_DOWNLOAD_KEYBOARD_SYMBOL_PAGE, SW_SHOW);
                            MApp_ZUI_API_SetFocus(HWND_BT_DOWNLOAD_KEYBOARD_SYMBOL_LINE0);
                            return TRUE;
                            break;
                        case 8: // for BackSpace
                            if(u8Len>0)
                                enBT_IME.u16StringName[u8Len - 1] = 0;
                            MApp_ZUI_API_ShowWindow(HWND_BT_DOWNLOAD_SEARCH_STRING, SW_SHOW);
                            return TRUE;
                            break;
                        case CHAR_SPACE:
                        case CHAR_0:
                        case CHAR_1:
                        case CHAR_2:
                        case CHAR_3:
                        case CHAR_4:
                        case CHAR_5:
                        case CHAR_6:
                        case CHAR_7:
                        case CHAR_8:
                        case CHAR_9:
                            enBT_IME.u16StringName[u8Len] = (U16)u8Char;
                            enBT_IME.u16StringName[u8Len + 1] = 0;
                            enBT_IME.uIME_State = STATE_IME_NULL;
                            MApp_ZUI_API_ShowWindow(HWND_BT_DOWNLOAD_SEARCH_STRING, SW_SHOW);
                            break;
                        default:
                            break;
                    }
                    if(enBT_IME.bIsEnglish)
                    {
                        if( (enBT_IME.bIsCAPs) && (u8Char >= CHAR_a) && (u8Char <= CHAR_z))
                            u8Char -= (CHAR_a - CHAR_A);
                        if( ((u8Char >= CHAR_a) && (u8Char <= CHAR_z)) || ((u8Char >= CHAR_A) && (u8Char <= CHAR_Z)) )
                        {
                            enBT_IME.u16StringName[u8Len] = (U16)u8Char;
                            enBT_IME.u16StringName[u8Len + 1] = 0;
                            enBT_IME.uIME_State = STATE_IME_NULL;
                            MApp_ZUI_API_ShowWindow(HWND_BT_DOWNLOAD_SEARCH_STRING, SW_SHOW);
                        }
                    }
                    else
                    {
                        enBT_IME.u8Char = u8Char;
                        //printf("IME_CHAR[%x]", enBT_IME.u8Char);
                        if( enBT_IME.u8Char >= CHAR_a  &&  enBT_IME.u8Char <= CHAR_z )
                        {
                            MApp_ZUI_API_GetPinYinInfoByFistChar(enBT_IME.u8Char, &(enBT_IME.u16SpellStar), &(enBT_IME.u16SpellCounter));
                            printf("\r\n start: %x   number: %x", enBT_IME.u16SpellStar, enBT_IME.u16SpellCounter);
                            if(enBT_IME.u16SpellCounter == 0 ) // is No use key for chinese IME
                            {
                                enBT_IME.uIME_State = STATE_IME_NULL;
                                return TRUE;
                            }
                            enBT_IME.u16SpellStar = 0;
                            enBT_IME.uIME_State = STATE_IME_SPELL;
                            for(u8Temp= 0; u8Temp < NUM_OF_IME_CHARS_PER_PAGE; u8Temp++)
                            {
                                MApp_ZUI_API_GetStringByFirstChar(enBT_IME.u8Char, u8Temp, enBT_IME.u8Sting[u8Temp]);
                                //printf("PinYin:[%s]\n", enBT_IME.u8Sting[u8Temp]);
                            }
                            MApp_ZUI_API_ShowWindow(HWND_BT_DOWNLOAD_TORRENT_SEARCH_IME, SW_SHOW);
                            MApp_ZUI_API_SetFocus(HWND_BT_DOWNLOAD_TORRENT_SEARCH_IME);
                        }
                    }
            break;
        case TYPE_BT_SETUP:
            if( wnd == HWND_BT_DOWNLOAD_SOFTWARE_KEY_BLANK ) // disable "speace" key
                break;
            if(MApp_ZUI_API_IsWindowVisible(HWND_BT_DOWNLOAD_SOFTWARE_KEYBOARD) && (u8BTSetting_Servername_Inputcount < 49))
            {
                if((wnd >= HWND_BT_DOWNLOAD_SOFTWARE_KEY_Q) && (wnd <= HWND_BT_DOWNLOAD_SOFTWARE_KEY_BLANK))
                {
                            stGenSetting.TorrentSetupInfo.u8ServerName[u8BTSetting_Servername_Inputcount] = u8Char;
                            stGenSetting.TorrentSetupInfo.u8ServerName[u8BTSetting_Servername_Inputcount+1] = '\0';
                            u8BTSetting_Servername_Inputcount++;
                            MApp_ZUI_API_InvalidateAllSuccessors(HWND_BT_DOWNLOAD_SETUP_SERVER_ADDRESS);
                }
                else if(wnd == HWND_BT_DOWNLOAD_SOFTWARE_KEY_BACKSPACE)
                {
                    if(u8BTSetting_Servername_Inputcount > 0)
                            u8BTSetting_Servername_Inputcount--;
                    stGenSetting.TorrentSetupInfo.u8ServerName[u8BTSetting_Servername_Inputcount] = '\0';
                    MApp_ZUI_API_InvalidateAllSuccessors(HWND_BT_DOWNLOAD_SETUP_SERVER_ADDRESS);
                }
                else if(wnd == HWND_BT_DOWNLOAD_SOFTWARE_KEY_SYMBOL)
                {
                    MApp_ZUI_API_ShowWindow(HWND_BT_DOWNLOAD_KEYBOARD_SYMBOL_PAGE, SW_SHOW);
                    MApp_ZUI_API_SetFocus(HWND_BT_DOWNLOAD_KEYBOARD_SYMBOL_LINE0);
                }
            }
            break;
        default:
            break;
    }
    return TRUE;
}

BOOLEAN MApp_ZUI_ACT_Adjust_IME_Page(U16 act)
{
    U16 u16Temp, i, u16Num;
    U8 u8Max, u8Min;
    if(enBT_IME.uIME_State == STATE_IME_NULL)
        return TRUE;
    if(act == EN_EXE_IME_PAGE_INC)
    {
        //printf("IME_PAGE_INC\n");
        if((enBT_IME.u16SpellCounter - enBT_IME.u16SpellStar) >= NUM_OF_IME_CHARS_PER_PAGE)//(enBT_IME.u16SpellStar < enBT_IME.u16SpellCounter)
        {
            if((enBT_IME.u16SpellStar + NUM_OF_IME_CHARS_PER_PAGE)> enBT_IME.u16SpellCounter)
                u8Max = enBT_IME.u16SpellCounter%NUM_OF_IME_CHARS_PER_PAGE;
            else
                u8Max = NUM_OF_IME_CHARS_PER_PAGE;
            enBT_IME.u16SpellStar += u8Max;
            for(u16Temp= enBT_IME.u16SpellStar, i = 0; u16Temp < (enBT_IME.u16SpellStar + u8Max); u16Temp++,i++)
            {
                if(enBT_IME.uIME_State == STATE_IME_SPELL)
                {
                    MApp_ZUI_API_GetStringByFirstChar(enBT_IME.u8Char, u16Temp, enBT_IME.u8Sting[i]);
                    //printf("PinYin:[%s]\n", enBT_IME.u8Sting[i]);
                }
                else if(enBT_IME.uIME_State == STATE_IME_CHS)
                {
                    u16Num = MApp_ZUI_API_GetWordsByPinYin(enBT_IME.u8Char, enBT_IME.u16CHS_Offset, u16Temp);
                    enBT_IME.u8Sting[i][0] = u16Num&0xFF;
                    enBT_IME.u8Sting[i][1] = (u16Num>>8)&0xFF;
                    enBT_IME.u8Sting[i][3] = 0;
                    //printf("CHS_[%x][%x]\n", enBT_IME.u8Sting[i][1], enBT_IME.u8Sting[i][0]);
                }
            }
            MApp_ZUI_API_InvalidateAllSuccessors(HWND_BT_DOWNLOAD_TORRENT_SEARCH_IME);
        }
    }
    else
    {
        //printf("IME_PAGE_DEC\n");
        if( enBT_IME.u16SpellStar >=  NUM_OF_IME_CHARS_PER_PAGE )
        {
            u8Min = enBT_IME.u16SpellStar%NUM_OF_IME_CHARS_PER_PAGE;
            if(u8Min == 0)
                u8Min = NUM_OF_IME_CHARS_PER_PAGE;
            enBT_IME.u16SpellStar -= u8Min;
            for(u16Temp= enBT_IME.u16SpellStar, i = 0; u16Temp < (enBT_IME.u16SpellStar + u8Min); u16Temp++, i++)
            {
                if(enBT_IME.uIME_State == STATE_IME_SPELL)
                {
                    MApp_ZUI_API_GetStringByFirstChar(enBT_IME.u8Char, u16Temp, enBT_IME.u8Sting[i]);
                    //printf("PinYin:[%s]\n", enBT_IME.u8Sting[i]);
                }
                else if(enBT_IME.uIME_State == STATE_IME_CHS)
                {
                    u16Num = MApp_ZUI_API_GetWordsByPinYin(enBT_IME.u8Char, enBT_IME.u16CHS_Offset, u16Temp);
                    enBT_IME.u8Sting[i][0] = u16Num&0xFF;
                    enBT_IME.u8Sting[i][1] = (u16Num>>8)&0xFF;
                    enBT_IME.u8Sting[i][3] = 0;
                    //printf("CHS_[%x][%x]\n", enBT_IME.u8Sting[i][1], enBT_IME.u8Sting[i][0]);
                }
            }
            MApp_ZUI_API_InvalidateAllSuccessors(HWND_BT_DOWNLOAD_TORRENT_SEARCH_IME);
        }
    }
    return TRUE;
}

BOOLEAN MApp_ZUI_ACT_IME_SPELL_CHS_Select(U16 act)
{
    U16 u16Num = 0;
    U8 u8Count = 0, u8Len = 0;
    //printf("IME_NUM[%d]\n", act);
    if(enBT_IME.bIsEnglish)
    {}
    else
    {
        if(enBT_IME.uIME_State == STATE_IME_SPELL)
        {
            u16Num = enBT_IME.u16SpellStar + (act - EN_EXE_BT_PAGE_NUM1);
            if( u16Num < enBT_IME.u16SpellCounter )
            {
                enBT_IME.uIME_State = STATE_IME_CHS;
                enBT_IME.u16CHS_Offset = u16Num;
                MApp_ZUI_API_GetWordsInfoByFistChar(enBT_IME.u8Char, u16Num, &(enBT_IME.u16SpellStar), &(enBT_IME.u16SpellCounter));
                enBT_IME.u16SpellStar = 0;
                //printf("\r\n IME_SETP1_CHS_start: %x   number: %x\n", enBT_IME.u16SpellStar, enBT_IME.u16SpellCounter);
                for(u8Count= 0; u8Count < NUM_OF_IME_CHARS_PER_PAGE; u8Count++)
                {
                    u16Num = MApp_ZUI_API_GetWordsByPinYin(enBT_IME.u8Char, enBT_IME.u16CHS_Offset, u8Count);
                    enBT_IME.u8Sting[u8Count][0] = u16Num&0xFF;
                    enBT_IME.u8Sting[u8Count][1] = (u16Num>>8)&0xFF;
                    enBT_IME.u8Sting[u8Count][3] = 0;
                    //printf("CHS_[%x][%x]\n", enBT_IME.u8Sting[u8Count][1], enBT_IME.u8Sting[u8Count][0]);
                }
                MApp_ZUI_API_ShowWindow(HWND_BT_DOWNLOAD_TORRENT_SEARCH_IME, SW_SHOW);
            }
        }
        else if(enBT_IME.uIME_State == STATE_IME_CHS)
        {
            u16Num = enBT_IME.u16SpellStar + (act - EN_EXE_BT_PAGE_NUM1);
            if( u16Num < enBT_IME.u16SpellCounter )
            {
                enBT_IME.uIME_State = STATE_IME_SETP3;
                enBT_IME.u16SpellStar = u16Num;
                //printf("\r\n IME_SETP2_CHS_start: %x   number: %x\n", enBT_IME.u16SpellStar, enBT_IME.u16SpellCounter);
                u16Num = MApp_ZUI_API_GetWordsByPinYin(enBT_IME.u8Char, enBT_IME.u16CHS_Offset, enBT_IME.u16SpellStar);
                // Get Sting Len
                for( u8Count = 0; u8Count<NUM_OF_SEARCH_STRING; u8Count++)
                {
                    if(enBT_IME.u16StringName[u8Count]==0)
                    {
                        u8Len=u8Count;
                        break;
                    }
                }
                enBT_IME.u16StringName[u8Len] = u16Num;
                enBT_IME.u16StringName[u8Len + 1] = 0;
                //printf("CHS_A_[%x]\n", enBT_IME.u16StringName[u8Len]);
                MApp_ZUI_API_ShowWindow(HWND_BT_DOWNLOAD_TORRENT_SEARCH_IME, SW_HIDE);
                MApp_ZUI_API_ShowWindow(HWND_BT_DOWNLOAD_SEARCH_STRING, SW_SHOW);
                MApp_ZUI_API_SetFocus(HWND_BT_DOWNLOAD_SOFTWARE_KEY_Q);
                MApp_ZUI_API_ShowWindow(HWND_BT_DOWNLOAD_SOFTWARE_KEY_Q, SW_SHOW);
            }
        }
    }
    return TRUE;
}

BOOLEAN MApp_ZUI_ACT_AdjustSearchListItem(U16 act)
{
    HWND wnd;
    U8 u8ItemIdx, u8Max, u8Cont, u8ItemPage;
    wnd = MApp_ZUI_API_GetFocus();

    for(u8ItemIdx=0;u8ItemIdx<NUM_OF_TORRENT_FILES_PER_PAGE;u8ItemIdx++)
    {
        if(wnd == _SearchListPageItemHwndList[u8ItemIdx])
        {
            break;
        }
    }
    u8ItemIdx += u8SearchListPage*NUM_OF_TORRENT_FILES_PER_PAGE;
    u8Max = (U8)MApp_BT_GetSearchFileNum();
    u8ItemIdx = MApp_ZUI_ACT_DecIncValue((act == EN_EXE_SEARCH_LIST_ITEM_INC), u8ItemIdx, 0, u8Max-1, 1);
    u8ItemPage = u8SearchListPage;
    u8SearchListPage = (u8ItemIdx)/NUM_OF_TORRENT_FILES_PER_PAGE;
    if( u8ItemPage != u8SearchListPage )
    {
        if((u8Max - u8ItemIdx)>5)
            u8Cont = 5;
        else
            u8Cont = (U8)(u8Max - u8ItemIdx);

        //printf("List: S[%d], C[%d]", u8ItemIdx, u8Cont);
        MApp_BT_QuerySearchListResultPage( (U16)u8SearchListPage*NUM_OF_TORRENT_FILES_PER_PAGE, (U16)u8Cont);
    }
    u8ItemIdx -= u8SearchListPage*NUM_OF_TORRENT_FILES_PER_PAGE;
    wnd = _SearchListPageItemHwndList[u8ItemIdx];
    MApp_ZUI_API_ShowWindow(HWND_BT_DOWNLOAD_SEARCHING_LIST, SW_SHOW);
    MApp_ZUI_API_SetFocus(wnd);
    return TRUE;
}

BOOLEAN MApp_ZUI_BTACT_NUM_INPUT(U16 act)
{

    switch(_MApp_BT_GetPageType())
    {
        case TYPE_BT_TORRENT_SEARCH:
                if((act >= EN_EXE_BT_PAGE_NUM1) && (act <= EN_EXE_BT_PAGE_NUM8))
                {
                    MApp_ZUI_ACT_IME_SPELL_CHS_Select(act);
                }
            break;
        case TYPE_BT_SETUP:
            {
                HWND wnd;
                wnd = MApp_ZUI_API_GetFocus();
                switch(wnd)
                {
                        case HWND_BT_DOWNLOAD_SETUP_PORT_VALUE:
                            if(u8BTSetting_maxnum < 5)
                            {
                                u8BTSetting_maxnum ++;
                                stGenSetting.TorrentSetupInfo.u16port = stGenSetting.TorrentSetupInfo.u16port * 10 + (act - EN_EXE_BT_PAGE_NUM0);
                             }
                            MApp_ZUI_API_InvalidateAllSuccessors(HWND_BT_DOWNLOAD_SETUP_PORT_VALUE);
                        break;
                        case HWND_BT_DOWNLOAD_SETUP_DOWNLOADLIMIT_VALUE:
                            if(u8BTSetting_maxnum < 4)
                            {
                                u8BTSetting_maxnum ++;
                                stGenSetting.TorrentSetupInfo.u16DownloadLimit = stGenSetting.TorrentSetupInfo.u16DownloadLimit * 10 + (act - EN_EXE_BT_PAGE_NUM0);
                            }
                            if(stGenSetting.TorrentSetupInfo.u16DownloadLimit > 1000)
                            {
                                stGenSetting.TorrentSetupInfo.u16DownloadLimit = 1000;
                            }
                            MApp_ZUI_API_InvalidateAllSuccessors(HWND_BT_DOWNLOAD_SETUP_DOWNLOADLIMIT_VALUE);
                        break;
                        case HWND_BT_DOWNLOAD_SETUP_MAXSESSION_VALUE:
                            if(u8BTSetting_maxnum < 2)
                            {
                                u8BTSetting_maxnum ++;
                                stGenSetting.TorrentSetupInfo.u8MaxSession = stGenSetting.TorrentSetupInfo.u8MaxSession * 10 + (act - EN_EXE_BT_PAGE_NUM0);
                            }
                            if(stGenSetting.TorrentSetupInfo.u8MaxSession > 10)
                            {
                                stGenSetting.TorrentSetupInfo.u8MaxSession = 10;
                            }
                            MApp_ZUI_API_InvalidateAllSuccessors(HWND_BT_DOWNLOAD_SETUP_MAXSESSION_VALUE);
                        break;
                        case HWND_BT_DOWNLOAD_SETUP_UPLOAD_VALUE:
                            if(u8BTSetting_maxnum < 4)
                            {
                                u8BTSetting_maxnum ++;
                                stGenSetting.TorrentSetupInfo.u16UploadLimit = stGenSetting.TorrentSetupInfo.u16UploadLimit * 10 + (act - EN_EXE_BT_PAGE_NUM0);
                            }
                            if(stGenSetting.TorrentSetupInfo.u16UploadLimit > 1000)
                          {
                                stGenSetting.TorrentSetupInfo.u16UploadLimit = 1000;
                            }
                            MApp_ZUI_API_InvalidateAllSuccessors(HWND_BT_DOWNLOAD_SETUP_UPLOAD_VALUE);
                       break;
                        case HWND_BT_DOWNLOAD_KEYBOARD_SYMBOL_LINE0:
                            if(u8BTSetting_Servername_Inputcount < 49)
                            {
                                stGenSetting.TorrentSetupInfo.u8ServerName[u8BTSetting_Servername_Inputcount] = u8_Array_BTKeyboard_Symbol[1][(act - EN_EXE_BT_PAGE_NUM0)*5];
                                stGenSetting.TorrentSetupInfo.u8ServerName[u8BTSetting_Servername_Inputcount+1] = '\0';
                                u8BTSetting_Servername_Inputcount++;
                                MApp_ZUI_API_InvalidateAllSuccessors(HWND_BT_DOWNLOAD_SETUP_SERVER_ADDRESS);
                            }
                       break;
                        case HWND_BT_DOWNLOAD_KEYBOARD_SYMBOL_LINE1:
                            if(u8BTSetting_Servername_Inputcount < 49)
                            {
                                stGenSetting.TorrentSetupInfo.u8ServerName[u8BTSetting_Servername_Inputcount] = u8_Array_BTKeyboard_Symbol[2][(act - EN_EXE_BT_PAGE_NUM0)*5];
                                stGenSetting.TorrentSetupInfo.u8ServerName[u8BTSetting_Servername_Inputcount+1] = '\0';
                                u8BTSetting_Servername_Inputcount++;
                                MApp_ZUI_API_InvalidateAllSuccessors(HWND_BT_DOWNLOAD_SETUP_SERVER_ADDRESS);
                            }
                       break;
                        case HWND_BT_DOWNLOAD_KEYBOARD_SYMBOL_LINE2:
                            if((u8BTSetting_Servername_Inputcount < 49) && (u8_Array_BTKeyboard_Symbol[3][(act - EN_EXE_BT_PAGE_NUM0)*5] != '\0'))
                            {
                                stGenSetting.TorrentSetupInfo.u8ServerName[u8BTSetting_Servername_Inputcount] = u8_Array_BTKeyboard_Symbol[3][(act - EN_EXE_BT_PAGE_NUM0)*5];
                                stGenSetting.TorrentSetupInfo.u8ServerName[u8BTSetting_Servername_Inputcount+1] = '\0';
                                u8BTSetting_Servername_Inputcount++;
                                MApp_ZUI_API_InvalidateAllSuccessors(HWND_BT_DOWNLOAD_SETUP_SERVER_ADDRESS);
                            }
                       break;
                        default:
                            break;
                    }
                }
            break;

        default:
            break;
    }
    return TRUE;
}


U16 *MApp_GetSearchStingName(void)
{
    return enBT_IME.u16StringName;    // file name

}

BOOLEAN MApp_ZUI_ACT_ExecuteBTAction(U16 act)
{
    U8 u8ItemIdx;
    HWND hwnd = MApp_ZUI_API_GetFocus();

    switch(act)
    {
        case EN_EXE_CLOSE_CURRENT_OSD:
            MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
            _enTargetBTState = STATE_BT_CLEAN_UP;
            return TRUE;
        break;
        case EN_EXE_POWEROFF:
            MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
            _enTargetBTState = STATE_BT_GOTO_STANDBY;
            return TRUE;
        break;
        case EN_EXE_SOFTWARW_KEY_SELECT:
                return MApp_ZUI_ACT_SoftwareKeySelect(act);
            break;
        case EN_EXE_SOFTWARW_KEY_CAPS:
                if(_MApp_BT_GetPageType() == TYPE_BT_TORRENT_SEARCH)
                {
                    enBT_IME.bIsCAPs = !enBT_IME.bIsCAPs;
                    MApp_ZUI_API_InvalidateAllSuccessors(HWND_BT_DOWNLOAD_TORRENT_SEARCH_HELP_GREEN);
                }
            break;
        case EN_EXE_SOFTWARW_KEY_INPUT_LANGUAGE:
                 if (MApp_ZUI_API_IsWindowVisible(HWND_BT_DOWNLOAD_SOFTWARE_KEYBOARD) && (_MApp_BT_GetPageType() == TYPE_BT_SETUP))
                {
                    if (MApp_ZUI_API_IsWindowVisible(HWND_BT_DOWNLOAD_KEYBOARD_SYMBOL_PAGE))
                    {
                        MApp_ZUI_API_ShowWindow(HWND_BT_DOWNLOAD_KEYBOARD_SYMBOL_PAGE, SW_HIDE);
                    }
                    MApp_ZUI_API_ShowWindow(HWND_BT_DOWNLOAD_SOFTWARE_KEYBOARD, SW_HIDE);
                    MApp_ZUI_API_SetFocus(HWND_BT_DOWNLOAD_SETUP_SERVER_ADDRESS);
                }
                 else
                {
                     enBT_IME.bIsEnglish = !enBT_IME.bIsEnglish;
                    MApp_ZUI_API_InvalidateAllSuccessors(HWND_BT_DOWNLOAD_TORRENT_SEARCH_HELP_YELLOW);
                }
            break;
        case EN_EXE_IME_PAGE_INC:
        case EN_EXE_IME_PAGE_DEC:
                return MApp_ZUI_ACT_Adjust_IME_Page(act);
            break;
        case EN_EXE_BT_PAGE_NUM0:
        case EN_EXE_BT_PAGE_NUM1:
        case EN_EXE_BT_PAGE_NUM2:
        case EN_EXE_BT_PAGE_NUM3:
        case EN_EXE_BT_PAGE_NUM4:
        case EN_EXE_BT_PAGE_NUM5:
        case EN_EXE_BT_PAGE_NUM6:
        case EN_EXE_BT_PAGE_NUM7:
        case EN_EXE_BT_PAGE_NUM8:
        case EN_EXE_BT_PAGE_NUM9:
                return MApp_ZUI_BTACT_NUM_INPUT(act);
            break;
        case EN_EXE_IME_PAGE_EXIT:
                printf("\r\n _MApp_BT_GetPageType(%bx)" , _MApp_BT_GetPageType());
                MApp_ZUI_API_ShowWindow(HWND_BT_DOWNLOAD_TORRENT_SEARCH_IME, SW_HIDE);
                MApp_ZUI_API_SetFocus(HWND_BT_DOWNLOAD_SOFTWARE_KEY_Q);
            break;
        case EN_EXE_SEARCH_LIST_ITEM_INC:
        case EN_EXE_SEARCH_LIST_ITEM_DEC:
                return MApp_ZUI_ACT_AdjustSearchListItem(act);
            break;
        case EN_EXE_SEARCH_LIST_PAGE_EXIT:
                printf("Exit BT Search List\n");

                MApp_ZUI_API_ShowWindow(HWND_BT_DOWNLOAD_SEARCHING_LIST, SW_HIDE);
                MApp_ZUI_API_ShowWindow(HWND_BT_DOWNLOAD_TORRENT_SEARCH, SW_SHOW);
                MApp_ZUI_API_ShowWindow(HWND_BT_DOWNLOAD_SOFTWARE_KEYBOARD, SW_SHOW);
                MApp_ZUI_API_SetFocus(HWND_BT_DOWNLOAD_SOFTWARE_KEY_Q);
                return TRUE;
            break;
        case EN_EXE_START_TO_SEARCH:
                //start BT Torrent Search
                if(_MApp_BT_GetPageType() == TYPE_BT_TORRENT_SEARCH)
                {
                    printf("start BT Torrent Search!\n");
                    if(enBT_IME.u16StringName[0] == 0)
                    {
                        enBTSearchState = BT_SEARCH_STATE_INPUT_ERROR;
                    }
                    else
                    {
                        enBTSearchState = BT_SEARCH_STATE_WAIT;
                        _MApp_BT_GotoBTSearchWaitState();
                    }
                    if(HWND_BT_DOWNLOAD_TORRENT_SEARCH_IME == MApp_ZUI_API_GetFocus())
                        MApp_ZUI_API_ShowWindow(HWND_BT_DOWNLOAD_TORRENT_SEARCH_IME, SW_HIDE);
                    MApp_ZUI_API_ShowWindow(HWND_BT_DOWNLOAD_SEARCHING_INFO_PAGE, SW_SHOW);
                    MApp_ZUI_API_SetFocus(HWND_BT_DOWNLOAD_SEARCHING_INFO_PAGE);
                    MApp_ZUI_API_SetTimer(HWND_BT_DOWNLOAD_SEARCHING_INFO_PAGE, 0, 200);
                    MApp_BT_GetMatchTorrentTotal(enBT_IME.u16StringName);
                    u8SearchListPage = 0;
                }
            break;
        case EN_EXE_SEARCH_INFO_PAGE_EXIT:
                printf("Exit BT Searching\n");
                _MApp_BT_GotoBTSearchWaitStateExit();
                MApp_ZUI_API_ShowWindow(HWND_BT_DOWNLOAD_SEARCHING_INFO_PAGE, SW_HIDE);
                MApp_ZUI_API_SetFocus(HWND_BT_DOWNLOAD_SOFTWARE_KEY_Q);
                return TRUE;
            break;
        case EN_EXE_LINK0PAGE_DESC_UPDATE:
                MApp_BT_SetDescriptionFileState( STATE_GET_DESCRIPTION_INIT);
                MApp_ZUI_API_SetTimer(HWND_BT_DOWNLOAD_MAINLINK0_TITLE, 0, 200);
                MApp_ZUI_API_ShowWindow(HWND_BT_DOWNLOAD_MAINLINK0_DESCRIPT, SW_SHOW);  // for Clear Desctription
            break;
        case EN_EXE_LINK1PAGE_DESC_UPDATE:
                MApp_BT_SetDescriptionFileState( STATE_GET_DESCRIPTION_INIT);
                MApp_ZUI_API_SetTimer(HWND_BT_DOWNLOAD_MAINLINK1_TITLE, 0, 200);
                MApp_ZUI_API_ShowWindow(HWND_BT_DOWNLOAD_MAINLINK1_DESCRIPT, SW_SHOW);  // for Clear Desctription
            break;

        case EN_EXE_SETTING_MODIFY:
            {
                switch(hwnd)
                {
                    case HWND_BT_DOWNLOAD_SETUP_PORT_VALUE:
                        u8BTSetting_maxnum = 0;
                        stGenSetting.TorrentSetupInfo.u16port = 0;
                        MApp_ZUI_API_InvalidateAllSuccessors(HWND_BT_DOWNLOAD_SETUP_PORT_VALUE);
                    break;
                    case HWND_BT_DOWNLOAD_SETUP_DOWNLOADLIMIT_VALUE:
                        u8BTSetting_maxnum = 0;
                        stGenSetting.TorrentSetupInfo.u16DownloadLimit = 0;
                        MApp_ZUI_API_InvalidateAllSuccessors(HWND_BT_DOWNLOAD_SETUP_DOWNLOADLIMIT_VALUE);
                    break;
                    case HWND_BT_DOWNLOAD_SETUP_MAXSESSION_VALUE:
                        u8BTSetting_maxnum = 0;
                        stGenSetting.TorrentSetupInfo.u8MaxSession = 0;
                        MApp_ZUI_API_InvalidateAllSuccessors(HWND_BT_DOWNLOAD_SETUP_MAXSESSION_VALUE);
                    break;
                    case HWND_BT_DOWNLOAD_SETUP_UPLOAD_VALUE:
                        u8BTSetting_maxnum = 0;
                         stGenSetting.TorrentSetupInfo.u16UploadLimit= 0;
                        MApp_ZUI_API_InvalidateAllSuccessors(HWND_BT_DOWNLOAD_SETUP_UPLOAD_VALUE);
                    break;
                    default:
                        break;
                }
                return TRUE;
            }
            break;

        case EN_EXE_SETTING_KEYBOARD:
            {
                if(_MApp_BT_GetPageType() == TYPE_BT_SETUP)
                {
                    if((hwnd == HWND_BT_DOWNLOAD_SETUP_SERVER_ADDRESS) && !(MApp_ZUI_API_IsWindowVisible(HWND_BT_DOWNLOAD_SOFTWARE_KEYBOARD)))
                    {
                        memcpy(stGenSetting.TorrentSetupInfo.u8ServerName, "Http://", sizeof("Http://"));
                        u8BTSetting_Servername_Inputcount = 7;
                        MApp_ZUI_API_InvalidateAllSuccessors(HWND_BT_DOWNLOAD_SETUP_SERVER_ADDRESS);
                        MApp_ZUI_API_ShowWindow(HWND_BT_DOWNLOAD_SOFTWARE_KEYBOARD, SW_SHOW);
                        MApp_ZUI_API_SetFocus(HWND_BT_DOWNLOAD_SOFTWARE_KEY_H);
                    }
                    else if (MApp_ZUI_API_IsWindowVisible(HWND_BT_DOWNLOAD_SOFTWARE_KEYBOARD))
                    {
                        if (MApp_ZUI_API_IsWindowVisible(HWND_BT_DOWNLOAD_KEYBOARD_SYMBOL_PAGE))
                        {
                            MApp_ZUI_API_ShowWindow(HWND_BT_DOWNLOAD_KEYBOARD_SYMBOL_PAGE, SW_HIDE);
                        }
                        MApp_ZUI_API_ShowWindow(HWND_BT_DOWNLOAD_SOFTWARE_KEYBOARD, SW_HIDE);
                        MApp_ZUI_API_SetFocus(HWND_BT_DOWNLOAD_SETUP_SERVER_ADDRESS);
                    }
                    return TRUE;
                }
            }
            break;

        case EN_EXE_EXIT:
            {
                switch(_MApp_BT_GetPageType())
                {
                    case TYPE_BT_TORRENT_SEARCH:
                        if((hwnd >= HWND_BT_DOWNLOAD_KEYBOARD_SYMBOL_LINE0) && (hwnd <= HWND_BT_DOWNLOAD_KEYBOARD_SYMBOL_LINE2))
                        {
                            MApp_ZUI_API_ShowWindow(HWND_BT_DOWNLOAD_KEYBOARD_SYMBOL_PAGE, SW_HIDE);
                            MApp_ZUI_API_SetFocus(HWND_BT_DOWNLOAD_SOFTWARE_KEY_SYMBOL);
                        }
                        else
                        {
                            MApp_ZUI_API_SetFocus(HWND_BT_DOWNLOAD_TORRENT_SEARCH_TITLE);
                        }
                        break;

                    case TYPE_BT_TOP_10:
                            MApp_ZUI_API_KillTimer(HWND_BT_DOWNLOAD_MAINLINK0_TITLE, 0);
                            MApp_ZUI_API_SetFocus(HWND_BT_DOWNLOAD_MAINLINK0_TITLE);
                            MApp_ZUI_API_ShowWindow(HWND_BT_DOWNLOAD_MAINLINK0_DESCRIPT, SW_SHOW);
                        break;
                    case TYPE_BT_NEW_10:
                            MApp_ZUI_API_KillTimer(HWND_BT_DOWNLOAD_MAINLINK1_TITLE, 0);
                            MApp_ZUI_API_SetFocus(HWND_BT_DOWNLOAD_MAINLINK1_TITLE);
                            MApp_ZUI_API_ShowWindow(HWND_BT_DOWNLOAD_MAINLINK1_DESCRIPT, SW_SHOW);
                        break;
                    case TYPE_BT_DOWNLOAD_LIST:
                            MApp_ZUI_API_SetFocus(HWND_BT_DOWNLOAD_DOWNLOAD_LIST_TITLE);
                        break;
                    case TYPE_BT_SETUP:
                        if((hwnd >= HWND_BT_DOWNLOAD_KEYBOARD_SYMBOL_LINE0) && (hwnd <= HWND_BT_DOWNLOAD_KEYBOARD_SYMBOL_LINE2))
                        {
                            MApp_ZUI_API_ShowWindow(HWND_BT_DOWNLOAD_KEYBOARD_SYMBOL_PAGE, SW_HIDE);
                            MApp_ZUI_API_SetFocus(HWND_BT_DOWNLOAD_SOFTWARE_KEY_SYMBOL);
                        }
                        else
                        {
                            MApp_ZUI_API_ShowWindow(HWND_BT_DOWNLOAD_SOFTWARE_KEYBOARD, SW_HIDE);
                            MApp_ZUI_API_SetFocus(HWND_BT_DOWNLOAD_SETUP_TITLE);
                        }
                        break;
                        default:
                        break;
                }
                return TRUE;
            }
            break;

        case EN_EXE_SETTING_RESET:
            {
                if(hwnd == HWND_BT_DOWNLOAD_SETUP_RESTORE_DEFAULT)
                {
                    MApp_BT_RestoreDefaultTorrentSetupInfo();
                    MApp_ZUI_API_InvalidateAllSuccessors(HWND_BT_DOWNLOAD_SETUP);
                    return TRUE;
                }
            }
            break;
        case EN_EXE_ADD_TO_DOWNLOADLIST:
            {
                for(u8ItemIdx=0;u8ItemIdx<NUM_OF_TORRENT_FILES_PER_PAGE;u8ItemIdx++)
                {
                    if(hwnd == _SearchListPageItemHwndList[u8ItemIdx])
                    {
                        break;
                    }
                }
                if(u8ItemIdx < NUM_OF_TORRENT_FILES_PER_PAGE )
                {
                    if(MApp_BT_GetTorrentFile(MApp_BT_GetTorrentFileID(u8ItemIdx)))
                    {
                        printf("add Torrent File!\n ");
                        MApp_BT_AddTorrentFileToDownloadList(MApp_BT_GetTorrentFileName(u8ItemIdx));
                        //MApp_BT_SearchList_StartTorrentFileToDownload(MApp_BT_GetTorrentFileName(u8ItemIdx));
                    }
                }

            }
            break;

        case EN_EXE_DOWNLOADLIST_START:
            {
                TorrentFileInfo fileInfo;

                printf("EN_EXE_DOWNLOADLIST_START!\n ");
                for(u8ItemIdx=0;u8ItemIdx<NUM_OF_TORRENT_FILES_PER_PAGE;u8ItemIdx++)
                {
                    if(hwnd == _DownloadPageItemHwndList[u8ItemIdx])
                    {
                        break;
                    }
                }
                if((u8ItemIdx < NUM_OF_TORRENT_FILES_PER_PAGE) && MApp_BT_QueryTorrentFileInfo(u8ItemIdx, &fileInfo))
                {
                    MApp_BT_StartTorrentFileToDownload((U16 *)fileInfo.u8LongFileName);
                }
            }
            break;
        case EN_EXE_DOWNLOADLIST_STOP:
            {
                TorrentFileInfo fileInfo;

                printf("EN_EXE_DOWNLOADLIST_STOP!\n ");
                for(u8ItemIdx=0;u8ItemIdx<NUM_OF_TORRENT_FILES_PER_PAGE;u8ItemIdx++)
                {
                    if(hwnd == _DownloadPageItemHwndList[u8ItemIdx])
                    {
                        break;
                    }
                }
                if((u8ItemIdx < NUM_OF_TORRENT_FILES_PER_PAGE) && MApp_BT_QueryTorrentFileInfo(u8ItemIdx, &fileInfo))
                {
                    MApp_BT_StopTorrentFileToDownload((U16 *)fileInfo.u8LongFileName);
                }
            }
            break;
        case EN_EXE_DOWNLOADLIST_PAUSE:
                printf("EN_EXE_DOWNLOADLIST_PAUSE!\n ");
            break;
        case EN_EXE_DOWNLOADLIST_DEL:
            {
                TorrentFileInfo fileInfo;

                printf("EN_EXE_DOWNLOADLIST_DEL!\n ");
                for(u8ItemIdx=0;u8ItemIdx<NUM_OF_TORRENT_FILES_PER_PAGE;u8ItemIdx++)
                {
                    if(hwnd == _DownloadPageItemHwndList[u8ItemIdx])
                    {
                        break;
                    }
                }
                if((u8ItemIdx < NUM_OF_TORRENT_FILES_PER_PAGE) && MApp_BT_QueryTorrentFileInfo(u8ItemIdx, &fileInfo))
                {
                    MApp_BT_DeleteTorrentFileToDownload((U16 *)fileInfo.u8LongFileName);
                }
            }
            break;

        case EN_EXE_SYSTEM_ERROR_CANCEL:
                printf("EN_EXE_SYSTEM_ERROR_CANCEL!\n ");
                MApp_System_ErrorHandle();
                MApp_ZUI_ACT_AppShowBTSystemErrorReturn();
            break;

        default:
            break;
    }
    return FALSE;
}

/////////////////////////////////////////////////////////
// Customize Window Procedures
/////////////////////////////////////////////////////////
void MApp_BT_ClearTopOrNewListPhotoBG(U8 u8Item)
{
    u8Item = u8Item;

    static U8 u8temp = 0xFF;

    if(u8temp != u8Item)
    {
        //printf("clear BG[%d][%d][\n ", u8temp, u8Item);
        if(_enBtPageType == TYPE_BT_TOP_10)
            MApp_ZUI_API_ShowWindow(_MainLink0PageItemPhotoHwndList[u8Item], SW_HIDE);
        else
            MApp_ZUI_API_ShowWindow(_MainLink1PageItemPhotoHwndList[u8Item], SW_HIDE);
    }
}

/////////////////////////////////////////////////////////
// Customize Window Procedures
void MApp_UiBT_ClearFocusHwnd(void)
{
    m_hwndFocus = HWND_INVALID;
}

/******************************************************************************/
/// Bit-torrent system error handle
/******************************************************************************/
BOOLEAN MApp_ZUI_ACT_BT_SystemErrorCheck(void)
{
    switch(MApp_Get_System_ErrorState())
    {
        case MB_BTC_ERR_DN_TOR: //Error while downloading the torrent file
        case MB_BTC_ERR_START_TOR: //Error while starting the torrent
        case MB_BTC_ERR_STOP_TOR: //Error while stopping the torrent
        case MB_BTC_ERR_ADD_TOR: //Error while adding the torrent
        case MB_BTC_ERR_DEL_TOR: //Error while deleting the torrent
        case MB_BTC_ERR_DEL_TORDATA: //Error while deleting the torrent and downloaded data
        case MB_BTC_ERR_START_DAEM: //Error while starting the daemon
        case MB_BTC_ERR_STOP_DAEM: //Error while stopping the daemon
        case MB_BTC_ERR_SET_PARAM: //Error while setting the daemon parameters
        case MB_BTC_ERR_NETWORK: //Error for network
        case MB_BTC_ERR_STORAGE: //Error for storage
        case MB_BTC_ERR_UNRESOLVED_HOST:  //Error while resolving the host name of the torrent server
        case MB_BTC_ERR_DECODE_IMG: //Error while decoding the image
        case MB_BTC_ERR_UNKNOWN: //Unknown error
            return TRUE;
            break;

        case MB_BTC_ERR_DN_IMG: //Error while downloading the image file
            printf("ERR: DN_IMG! \n");
            MApp_System_ErrorHandle();
            return FALSE;
            break;
        case MB_BTC_ERR_DN_DES: //Error while downloading the description file
            printf("ERR: DN_DES! \n");
            MApp_System_ErrorHandle();
            return FALSE;
            break;

        default:
            return FALSE;
            break;
    }
}

#endif //#if (ENABLE_THUNDER_DOWNLOAD)

#endif
#undef MAPP_ZUI_ACTBT_C
