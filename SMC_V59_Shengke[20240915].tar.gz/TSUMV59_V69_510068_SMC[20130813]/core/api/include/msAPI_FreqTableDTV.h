////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (MStar Confidential Information!�L) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef __API_FREQTABLEDTV_H__
#define __API_FREQTABLEDTV_H__
#if ENABLE_DTV
#include "MApp_GlobalSettingSt.h"
#include "msAPI_Tuner.h"

//****************************************************************************
// Public attributes.
//****************************************************************************

#if ENABLE_SBTVD_BRAZIL_APP
#define MIN_UHF_PHYSICAL_CHANNEL_NUMBER(eCountry)   14
#define MAX_UHF_PHYSICAL_CHANNEL_NUMBER                69
#elif( ENABLE_DVB_TAIWAN_APP )
#define MIN_UHF_PHYSICAL_CHANNEL_NUMBER(eCountry)   14
#define MAX_UHF_PHYSICAL_CHANNEL_NUMBER                69
#elif ( ENABLE_DTMB_CHINA_APP )
#define MIN_UHF_PHYSICAL_CHANNEL_NUMBER(eCountry)   13
#define MAX_UHF_PHYSICAL_CHANNEL_NUMBER                68
#else
#define MIN_UHF_PHYSICAL_CHANNEL_NUMBER(eCountry)   ((eCountry==E_AUSTRALIA)? 27 : 21)
#define MAX_UHF_PHYSICAL_CHANNEL_NUMBER        69
#endif
#define MIN_UHF_PHYSICAL_S_CHANNEL_NUMBER   121
#define MAX_UHF_PHYSICAL_S_CHANNEL_NUMBER   141

#define MAX_PHYSICAL_CHANNEL_NUMBER        MAX_UHF_PHYSICAL_CHANNEL_NUMBER
#define MAX_PHYSICAL_CHANNEL_NUM        99
//****************************************************************************
// Public functions.
//****************************************************************************

BOOLEAN msAPI_DFT_GetTSSetting(BYTE cRFChannelNumber, MS_TP_SETTING * pstTPSetting);
BOOLEAN msAPI_DFT_GetPhysicalChannelName(BYTE cRFChannelNumber, BYTE * sPhysicalChannelName, BYTE cBufferSize);
BYTE msAPI_DFT_GetFirstPhysicalChannelNumber(void);
BYTE msAPI_DFT_GetPrevPhysicalChannelNumber(BYTE cRFChannelNumber);
BYTE msAPI_DFT_GetNextPhysicalChannelNumber(BYTE cRFChannelNumber);
#if 0 //ENABLE_SZ_DTV_ADDCH_SCAN_FUNCTION
BYTE msAPI_GetNextEmptyPhysicalChannelNumber(BYTE cRFChannelNumber);
#endif
BYTE msAPI_DFT_GetPercentWithPhysicalChannelNumber(BYTE cRFChannelNumber);
BOOLEAN msAPI_DFT_Get_PHYSICAL_CHANNEL_NUMBER(U32 u32Frequency, U8 *u8RFIndex);
void msAPI_DFT_SetBandwidth(U8 u8BandWidth);
void msAPI_SetCrossBandwidth(BOOLEAN bIsCross);
#endif
#endif // __API_FREQTABLEDTV_H__

