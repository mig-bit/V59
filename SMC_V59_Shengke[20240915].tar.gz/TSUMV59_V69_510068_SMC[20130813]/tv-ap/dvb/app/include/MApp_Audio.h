///////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// ("MStar Confidential Information") by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
///////////////////////////////////////////////////////////////////////////////

#ifndef _MAPP_AUDIO_H
#define _MAPP_AUDIO_H

#include "datatype.h"
#include "drvXC_HDMI_if.h"
#include "cusModelSet.h"

#ifdef _MAPP_AUDIO_C
#define INTERFACE
#else
#define INTERFACE extern
#endif

#define MAX_NUM_OF_VOL_LEVEL       100
#if EAR_PHONE_POLLING
#define EAR_PHONE_NULL				0
#define EAR_PHONE_INSERTED		1
#endif

// equalizer

// (0xef*50/48+50),   // CUS_XM Sea 20120613: register 0X112D94 32 -> 0xef   Transfered by lib: value = ((int)u8Level-50)*48/50; Max value after transfer is C4
#define SOUND_MODE_STANDARD_BAND1   50
#define SOUND_MODE_STANDARD_BAND2   50
#define SOUND_MODE_STANDARD_BAND3   50
#define SOUND_MODE_STANDARD_BAND4   50
#define SOUND_MODE_STANDARD_BAND5   50
#define SOUND_MODE_STANDARD_BAND6   50
#define SOUND_MODE_STANDARD_BAND7   50

#define SOUND_MODE_MUSIC_BAND1	  0		// CUS_XM Sea 20120725: 0 -> 0xD0
#define SOUND_MODE_MUSIC_BAND2      67		// 0x10
#define SOUND_MODE_MUSIC_BAND3      63		// 0x0c
#define SOUND_MODE_MUSIC_BAND4      59		// 0x08
#define SOUND_MODE_MUSIC_BAND5      50		// 0x00
#define SOUND_MODE_MUSIC_BAND6      70
#define SOUND_MODE_MUSIC_BAND7      73

#define SOUND_MODE_MOVIE_BAND1      45
#define SOUND_MODE_MOVIE_BAND2      50
#define SOUND_MODE_MOVIE_BAND3      48
#define SOUND_MODE_MOVIE_BAND4      50
#define SOUND_MODE_MOVIE_BAND5      45
#define SOUND_MODE_MOVIE_BAND6      50
#define SOUND_MODE_MOVIE_BAND7      45

// CUS_XM Sea 20120725: Speech
#define SOUND_MODE_SPORTS_BAND1     0		// 0xd0
#define SOUND_MODE_SPORTS_BAND2     35		// 0xf2
#define SOUND_MODE_SPORTS_BAND3     48		// 0xff
#define SOUND_MODE_SPORTS_BAND4     35		// 0xf2
#define SOUND_MODE_SPORTS_BAND5     32		// 0xef
#define SOUND_MODE_SPORTS_BAND6     50
#define SOUND_MODE_SPORTS_BAND7     45


#define ENABLE_AUDIO_SURROUND_VDS      DISABLE //ENABLE
#define ENABLE_AUDIO_SURROUND_VSPK     DISABLE  // ENABLE
#define ENABLE_AUDIO_SURROUND_SRS      DISABLE
#define ENABLE_AUDIO_SURROUND_BBE      DISABLE //ENABLE
#define ENABLE_AUDIO_SURROUND_ADVANCE   (ENABLE_AUDIO_SURROUND_VSPK== ENABLE || ENABLE_AUDIO_SURROUND_SRS==ENABLE || ENABLE_AUDIO_SURROUND_BBE==ENABLE )

INTERFACE BOOLEAN bEnableAC3Check;
INTERFACE U32 u32AC3CheckTimer;
INTERFACE U8  u8AC3CheckTimes;
INTERFACE U8 u8PollingStereo;
INTERFACE U8  u8HDMIchkflag;

INTERFACE BOOLEAN MApp_Audio_GetNextAvailableMtsMode(void);
#if ENABLE_DTV
INTERFACE BOOLEAN MApp_Audio_SetAudioLanguage(U8 u8AudSelectedIndex);
INTERFACE void MApp_Audio_SetAdAudio(U8 u8AudSelectedIndex);
INTERFACE void MApp_Audio_SearchAdAudio(void);
#endif
INTERFACE BOOLEAN MApp_Audio_IsAC3AudioExist(void);        // to show "DOLBY DIGITAL" icon in channel info OSD
INTERFACE void MApp_Audio_AdjustSoundMode(void);            // surround mode
INTERFACE BOOLEAN MApp_Audio_SetMtsMode(void);
INTERFACE void  MApp_Aud_Banlace_Init(void);
INTERFACE void MApp_Aud_PEQ_Init(void);
INTERFACE void MApp_Aud_EQ_Init(void);

/*
     MApp_Aud_SetSurroundMode is used to set a specific surround mode.

*/
INTERFACE void MApp_Aud_SetSurroundMode(U8 u8SurroundMode);

#if ENABLE_MADMONITOR
INTERFACE void MApp_Audio_Monitor (void);
#endif

INTERFACE void MApp_Audio_HDMI_MODE_CONFIG(HDMI_POLLING_STATUS_t enHDMIPollingStatus, HDMI_PACKET_INFO_t *enHDMIPackInfo);

//================================================================
// Add audio APP functions here
//================================================================

void MApp_Audio_AdjustPreScale(U8 InputSource);
void MApp_Audio_AdjustAVCThreshold(U8 InputSource);
void MApp_Audio_AdjustMainVolume(U8 VolumePercent);
#if ENABLE_CUS_HEADPHONE_SPEC
void MApp_Audio_AdjustHeadPhoneVolume(BYTE VolumePercent);
#endif

#if ENABLE_ATV_VCHIP
#ifdef LOCK_USE_BLACK_VIDEO
INTERFACE void MApp_MuteAvByLock(U8 u8ScreenMute, BOOLEAN bMuteEnable);
#else
INTERFACE void MApp_MuteAvByLock(BOOLEAN bEnableMute);
#endif
#endif//ENABLE_ATV_VCHIP

#if ENABLE_CUS_AUDIO_DELAY
INTERFACE void MApp_Aud_SetBufferProcess ( U8 DelayTime );
#endif
#if ENABLE_NEW_SPDIF_MUTE_METHOD
INTERFACE void MApp_Audio_SPDIF_SetMute(MS_BOOL bMute_en,MS_BOOL bForceMute);
#endif
INTERFACE MS_BOOL MApp_AUDIO_IsSifSoundModeExist(EN_SOUND_MTS_TYPE enSifSoundMode);
#if EAR_PHONE_POLLING
INTERFACE BOOLEAN GetEarphoneState(void);
INTERFACE void EarPhone_OFF(void);
INTERFACE void EarPhone_ON(void);
#endif

#undef INTERFACE

#endif



