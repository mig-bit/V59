////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////



#define MMI_TITLE_LINE_NUM          1
#define MMI_SUBTITLE_LINE_NUM       3
#define MMI_COICE_LINE_NUM          8
#define MMI_BOTTOM_LINE_NUM         1

/* DEFINE ERROR ***************************************************************/
#define OK          0x00
#define W_SEACH     0x01
#define M_BUSY      0x02
#define M_DATA      0x03
#define T_ERR       0x04
#define RS_ERR      0x05
#define MEM_ERR     0x06
#define KO          0x07
