////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MAPP_ZUI_ACTDRAWDYNAWIN_H
#define _MAPP_ZUI_ACTDRAWDYNAWIN_H

#ifdef __cplusplus
extern "C" {
#endif  /* __cplusplus */

#ifdef MAPP_ZUI_ACTDRAWDYNAWIN_C
#define INTERFACE
#else
#define INTERFACE extern
#endif

#define COWIN_ID_NONE           0xFF   //None
#define COWIN_ID_MUTE           0      //MUTE
#define COWIN_ID_COUNT_DOWN_WIN 1   //Message box
#if ENABLE_CUS_FACTORY_SHOW_T_ICON
#define COWIN_ID_FACTORY_TEST_WIN 2   //show factory 'T' icon
#endif


INTERFACE U8 u8CoexistWinType;  //Mute or count down win

INTERFACE void MApp_KeyProc_Mute(void);
INTERFACE void MApp_UiMenu_MuteWin_Show(void);
INTERFACE void MApp_UiMenu_MuteWin_Hide(void);
INTERFACE void MApp_ZUI_ACTcoexist_Enable(BOOLEAN bEnable);
INTERFACE BOOLEAN MApp_ZUI_ACTcoexist_Create (U8 win_ID, U16 win_x,U16 win_y,U16 win_w,U16 win_h);
INTERFACE void MApp_ZUI_ACTcoexist_Delete( void);
#if (ENABLE_UI_3D_PROCESS)
INTERFACE void MApp_ZUI_ACTcoexist_RealDelete( void);
#endif
INTERFACE void MApp_UiMenu_CountDownWin_Draw(void);
INTERFACE void MApp_UiMenu_CountDownWin_Create(void);
INTERFACE BOOLEAN MApp_UiMenu_GetCoexistWin_State(void);
#if ENABLE_CUS_FACTORY_SHOW_T_ICON
INTERFACE void MApp_UiMenu_T_Icon_Win_Show(void);
INTERFACE void MApp_UiMenu_T_Icon_Win_Hide(void);
INTERFACE void MApp_FactoryIR_TestKeyProc(void);
#endif

INTERFACE void MApp_fpGOP_CB(MS_U32 u32EventID, void* reserved0);
INTERFACE void MApp_MUTE_fpGOP_CB(MS_U32 u32EventID, void* reserved0);
INTERFACE void MApp_KeyProc_DMPMute(void);
INTERFACE void MApp_KeyProc_MuteMonitor(BOOLEAN bSwitch);

#undef INTERFACE

#ifdef __cplusplus
}
#endif  /* __cplusplus */

#endif /* _MAPP_ZUI_ACTDRAWDYNAWIN_H */

