////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////
#define MAPP_ZUI_ACTDMP_C
#define _ZUI_INTERNAL_INSIDE_ //NOTE: for ZUI internal
//-------------------------------------------------------------------------------------------------
// Include Files
//-------------------------------------------------------------------------------------------------
#include "Board.h"
#include "datatype.h"
#include "MsCommon.h"

// Common Definition
#include "MApp_GlobalSettingSt.h"

#include "MApp_ZUI_Main.h"
#include "MApp_ZUI_APIcommon.h"
#include "MApp_ZUI_APIstrings.h"
#include "MApp_ZUI_APIwindow.h"
#include "ZUI_tables_h.inl"
#include "MApp_ZUI_APIgdi.h"
#include "MApp_ZUI_APIcontrols.h"
#include "MApp_ZUI_ACTmainpage.h"
#include "MApp_ZUI_ACTeffect.h"
#include "MApp_ZUI_ACTglobal.h"
#include "MApp_ZUI_ACTepg.h"
#include "OSDcp_String_EnumIndex.h"
#include "OSDcp_Bitmap_EnumIndex.h"
#include "ZUI_exefunc.h"
#include "MApp_GlobalFunction.h"
#include "MApp_ZUI_ACTcoexistWin.h"
#include "MApp_ZUI_APItables.h"
#include "MApp_ZUI_APIgdi.h"
#include "MApp_ZUI_APIdraw.h"
#include "MApp_ZUI_APIcontrols.h"
#include "MApp_ZUI_APIcomponent.h"
#include "MApp_ZUI_APIalphatables.h"
#include "MApp_ZUI_APIstyletables.h"

#ifndef ATSC_SYSTEM
#include "MApp_EpgTimer.h"
#include "MApp_UiPvr.h"
#endif
#include "drvUART.h"
#include "drvGPIO.h"
#include "apiXC.h"
#include "apiXC_Sys.h"
#include "msAPI_Memory.h"
#include "msAPI_OCP.h"
#include "msAPI_MSDCtrl.h"
#include "msAPI_FCtrl.h"
#include "apiGOP.h"
#include "msAPI_MailBox.h"
#include "MsTypes.h"
#include "MApp_DMP_Main.h"
#include "MApp_ZUI_ACTdmp.h"
#include "MApp_UiMediaPlayer_Define.h"
#include "MApp_UiMenuDef.h"
#include "mapp_videoplayer.h"
#include "MApp_Audio.h"
#include "mapp_music.h"
#if (ENABLE_WMA)
#include "mapp_wma.h"
#endif
#include "msAPI_audio.h"
#include "msAPI_Timer.h"
#include "FSUtil.h"
#include "IOUtil.h"
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include "mapp_txt.h"
#include "MApp_CharTable.h"
#include "msAPI_MPEG_Subtitle.h"
#if ENABLE_DRM
#include "MApp_SaveData.h"
#endif
#include "MApp_FileBrowser.h"
#include "MApp_DMP_Main.h"
#include "MApp_InputSource.h"
#include "MApp_ChannelChange.h"
#include "MApp_ZUI_ACTdmp.h"
extern void _MApp_ZUI_API_ConvertTextComponentToDynamic(U16 u16TextOutIndex, DRAW_TEXT_OUT_DYNAMIC *
pComp);

#if 1//minglin0419
extern void MApp_Picture_Setting_SetColor( INPUT_SOURCE_TYPE_t enInputSourceType, SCALER_WIN eWindow );
#endif

#ifdef ENABLE_KTV
extern BOOLEAN MApp_UiMediaPlayer_KTV_Notify(enumMPlayerNotifyType eNotify, void *pInfo);
#endif

#ifndef U64
typedef unsigned long long U64;
#endif

#define DMP_STRING_BUF_SIZE             512
#define DMP_TIMER_PROGRESS_WIN          0
#define DMP_TIME_MS_PROGRESS_WIN        1000
#define DMP_TIMER_PLAY_STATUS_WIN       0
//#define DMP_TIMER_MOVIERESUME_WIN       0

#define DMP_TIMER_MOVIERESUME_WIN           0
#define DMP_TIME_MS_MOVIERESUME             8000

#define DMP_TIMER_PREV_BUTTON_CLICK_WIN     1
#define DMP_TIME_MS_PREV_BUTTON_CLICK_WIN   800


#define DMP_TIME_MS_PLAY_STATUS_WIN     5000
#define DMP_TIMER_BUTTONCLICK           500
#define DMP_INFOBAR_ICON_NUM            8
#define DMP_TIMER_EQ_PLAY               4
#define DMP_TIME_MS_EQ_PLAY             300
#define DMP_TIMER_PREVIEW_WIN           0
#define DMP_TIME_MS_PREVIEW_WIN         500
#define DMP_TIMER_INVALID_WIN           0
#define DMP_TIME_MS_INVALID_WIN         2000
#define DMP_MARQUEE_INITIAL_INTERVAL_MS 1500
#define DMP_MARQUEE_ANIMATION_INTERVAL_MS 500
#define ENABLE_DMP_32X     ENABLE    //add for divx test

#if ( ENABLE_ARABIC_OSD )
extern BOOLEAN MMOsdIsOn;
#endif
static BOOLEAN bResume=TRUE;

#if ENABLE_DRM
static stDRMinfo DrmInfo;

typedef enum
{
    WinAuthError,
    WinViewRental,
    WinRentalExpired,
    WinUnsupported,
}EN_DRM_WIN;
static EN_DRM_WIN DRM_STATUS;

typedef enum
{
    DRM_Bitmap_None,
    DRM_Bitmap_Warning,
    DRM_Bitmap_Error,
}EN_DRM_BITMAP;
static EN_DRM_BITMAP _DrmBitmapIdx = DRM_Bitmap_None;

typedef enum
{
    ViewRental,
    AuthError,
    Unsupported,
    DRM_STR0_MAX,
}EN_DRM_STR0;
static EN_DRM_STR0 _DrmStr0Idx = ViewRental;
static U8 *DRMStrTable0[DRM_STR0_MAX] =
{
    (U8 *)"This DivX(R) rental has used X of X views.",
    (U8 *)"Your device is not authorized to play this DivX(R) protected video.",
    (U8 *)"Unsupported DivX(R) DRM Version"
};
typedef enum
{
    None,
    UseRental,
    RentalExpired,
    DRM_STR1_MAX,
}EN_DRM_STR1;
static EN_DRM_STR1 _DrmStr1Idx = None;

static U8 *DRMStrTable1[DRM_STR1_MAX]=
{
    (U8 *)"",
    (U8 *)"Continue?",
    (U8 *)"This DivX(R) rental has expired.",
};
extern BOOLEAN g_bIsResumePlay;
static U32 u32PrevButtonTimer = 0;

#endif

#ifdef ENABLE_SRC_MENU_AUTOCLOSE_AND_SWITCH_SOURCE
static E_UI_INPUT_SOURCE _enCurrentSelectUIsource = UI_INPUT_SOURCE_ATV;
#endif

extern BOOLEAN g_bUnsupportAudio;  //20100809EL

#if CUS_SMC_ENABLE_HOTEL_MODE
static U8 HotelLockMode;
#endif

typedef enum
{
    DMP_MSG_TYPE_LOADING,
    DMP_MSG_TYPE_UNSUPPORTED_FILE,
    DMP_MSG_TYPE_INVALID_OPERATION,
    DMP_MSG_TYPE_BAD_DRIVE,
    DMP_MSG_TYPE_DISK_FULL,
    DMP_MSG_TYPE_PASTE_FILE_ERROR,
    DMP_MSG_TYPE_PASTE_NOT_SUPPORT_NTFS,
    DMP_MSG_TYPE_ALL_FILES_UNSUPPORTED,
    DMP_MSG_TYPE_UNSUPPORTED_AUDIO_FILE,  //20100809EL
    DMP_MSG_TYPE_UNSUPPORTED_VIDEO_RESOLUTION,
    DMP_MSG_TYPE_MAX,
}EN_DMP_MSG_TYPE;


static HWND _hwndListDriveItem[DMP_DRIVE_NUM_PER_PAGE] =
{
    HWND_DMP_DRIVE_ITEM1,
    HWND_DMP_DRIVE_ITEM2,
    HWND_DMP_DRIVE_ITEM3,
    HWND_DMP_DRIVE_ITEM4
};

static HWND _hwndListDriveItemString[DMP_DRIVE_NUM_PER_PAGE] =
{
    HWND_DMP_DRIVE_ITEM1_STRING,
    HWND_DMP_DRIVE_ITEM2_STRING,
    HWND_DMP_DRIVE_ITEM3_STRING,
    HWND_DMP_DRIVE_ITEM4_STRING
};

#ifdef ENABLE_SMC_UI_NEW     /* smc.qxr 20121029 */
static HWND *_hwndListFileItem;
static HWND *_hwndListFileIcon;
static HWND *_hwndListFileString;
static HWND *_hwndListFileCheckMark;
#if (BOE_PHOTO_DISPLAY)//<<SMC jayden.chen add for compling waning 20130813
static HWND _hwndListFileItemFile[] =
{
    HWND_DMP_FILE_PAGE_THUMB_ITEM1,
    HWND_DMP_FILE_PAGE_THUMB_ITEM2,
    HWND_DMP_FILE_PAGE_THUMB_ITEM3,
    HWND_DMP_FILE_PAGE_THUMB_ITEM4,
    HWND_DMP_FILE_PAGE_THUMB_ITEM5,
    HWND_DMP_FILE_PAGE_THUMB_ITEM6,
    HWND_DMP_FILE_PAGE_THUMB_ITEM7,
    HWND_DMP_FILE_PAGE_THUMB_ITEM8,
};

static HWND _hwndListFileIconFile[] =
{
    HWND_DMP_FILE_PAGE_THUMB_ITEM1_ICON,
    HWND_DMP_FILE_PAGE_THUMB_ITEM2_ICON,
    HWND_DMP_FILE_PAGE_THUMB_ITEM3_ICON,
    HWND_DMP_FILE_PAGE_THUMB_ITEM4_ICON,
    HWND_DMP_FILE_PAGE_THUMB_ITEM5_ICON,
    HWND_DMP_FILE_PAGE_THUMB_ITEM6_ICON,
    HWND_DMP_FILE_PAGE_THUMB_ITEM7_ICON,
    HWND_DMP_FILE_PAGE_THUMB_ITEM8_ICON,
};

static HWND _hwndListFileStringFile[] =
{
    HWND_DMP_FILE_PAGE_THUMB_ITEM1_STRING,
    HWND_DMP_FILE_PAGE_THUMB_ITEM2_STRING,
    HWND_DMP_FILE_PAGE_THUMB_ITEM3_STRING,
    HWND_DMP_FILE_PAGE_THUMB_ITEM4_STRING,
    HWND_DMP_FILE_PAGE_THUMB_ITEM5_STRING,
    HWND_DMP_FILE_PAGE_THUMB_ITEM6_STRING,
    HWND_DMP_FILE_PAGE_THUMB_ITEM7_STRING,
    HWND_DMP_FILE_PAGE_THUMB_ITEM8_STRING,
};

static HWND _hwndListFileCheckMarkFile[] =
{
    HWND_DMP_FILE_PAGE_THUMB_ITEM1_CHECK_ICON,
    HWND_DMP_FILE_PAGE_THUMB_ITEM2_CHECK_ICON,
    HWND_DMP_FILE_PAGE_THUMB_ITEM3_CHECK_ICON,
    HWND_DMP_FILE_PAGE_THUMB_ITEM4_CHECK_ICON,
    HWND_DMP_FILE_PAGE_THUMB_ITEM5_CHECK_ICON,
    HWND_DMP_FILE_PAGE_THUMB_ITEM6_CHECK_ICON,
    HWND_DMP_FILE_PAGE_THUMB_ITEM7_CHECK_ICON,
    HWND_DMP_FILE_PAGE_THUMB_ITEM8_CHECK_ICON,
};
#endif		//<<SMC jayden.chen add for compling waning 20130813

static HWND _hwndListFileItemPhoto[] =
{
    HWND_DMP_PHOTO_PAGE_THUMB_ITEM1,
    HWND_DMP_PHOTO_PAGE_THUMB_ITEM2,
    HWND_DMP_PHOTO_PAGE_THUMB_ITEM3,
    HWND_DMP_PHOTO_PAGE_THUMB_ITEM4,
    HWND_DMP_PHOTO_PAGE_THUMB_ITEM5,
    HWND_DMP_PHOTO_PAGE_THUMB_ITEM6,
    HWND_DMP_PHOTO_PAGE_THUMB_ITEM7,
    HWND_DMP_PHOTO_PAGE_THUMB_ITEM8,
    HWND_DMP_PHOTO_PAGE_THUMB_ITEM9,
    HWND_DMP_PHOTO_PAGE_THUMB_ITEM10,
    HWND_DMP_PHOTO_PAGE_THUMB_ITEM11,
    HWND_DMP_PHOTO_PAGE_THUMB_ITEM12
};

static HWND _hwndListFileIconPhoto[] =
{
    HWND_DMP_PHOTO_PAGE_THUMB_ITEM1_ICON,
    HWND_DMP_PHOTO_PAGE_THUMB_ITEM2_ICON,
    HWND_DMP_PHOTO_PAGE_THUMB_ITEM3_ICON,
    HWND_DMP_PHOTO_PAGE_THUMB_ITEM4_ICON,
    HWND_DMP_PHOTO_PAGE_THUMB_ITEM5_ICON,
    HWND_DMP_PHOTO_PAGE_THUMB_ITEM6_ICON,
    HWND_DMP_PHOTO_PAGE_THUMB_ITEM7_ICON,
    HWND_DMP_PHOTO_PAGE_THUMB_ITEM8_ICON,
    HWND_DMP_PHOTO_PAGE_THUMB_ITEM9_ICON,
    HWND_DMP_PHOTO_PAGE_THUMB_ITEM10_ICON,
    HWND_DMP_PHOTO_PAGE_THUMB_ITEM11_ICON,
    HWND_DMP_PHOTO_PAGE_THUMB_ITEM12_ICON
};

static HWND _hwndListFileStringPhoto[] =
{
    HWND_DMP_PHOTO_PAGE_THUMB_ITEM1_STRING,
    HWND_DMP_PHOTO_PAGE_THUMB_ITEM2_STRING,
    HWND_DMP_PHOTO_PAGE_THUMB_ITEM3_STRING,
    HWND_DMP_PHOTO_PAGE_THUMB_ITEM4_STRING,
    HWND_DMP_PHOTO_PAGE_THUMB_ITEM5_STRING,
    HWND_DMP_PHOTO_PAGE_THUMB_ITEM6_STRING,
    HWND_DMP_PHOTO_PAGE_THUMB_ITEM7_STRING,
    HWND_DMP_PHOTO_PAGE_THUMB_ITEM8_STRING,
    HWND_DMP_PHOTO_PAGE_THUMB_ITEM9_STRING,
    HWND_DMP_PHOTO_PAGE_THUMB_ITEM10_STRING,
    HWND_DMP_PHOTO_PAGE_THUMB_ITEM11_STRING,
    HWND_DMP_PHOTO_PAGE_THUMB_ITEM12_STRING,
};

static HWND _hwndListFileCheckMarkPhoto[] =
{
    HWND_DMP_PHOTO_PAGE_THUMB_ITEM1_CHECK_ICON,
    HWND_DMP_PHOTO_PAGE_THUMB_ITEM2_CHECK_ICON,
    HWND_DMP_PHOTO_PAGE_THUMB_ITEM3_CHECK_ICON,
    HWND_DMP_PHOTO_PAGE_THUMB_ITEM4_CHECK_ICON,
    HWND_DMP_PHOTO_PAGE_THUMB_ITEM5_CHECK_ICON,
    HWND_DMP_PHOTO_PAGE_THUMB_ITEM6_CHECK_ICON,
    HWND_DMP_PHOTO_PAGE_THUMB_ITEM7_CHECK_ICON,
    HWND_DMP_PHOTO_PAGE_THUMB_ITEM8_CHECK_ICON,
    HWND_DMP_PHOTO_PAGE_THUMB_ITEM9_CHECK_ICON,
    HWND_DMP_PHOTO_PAGE_THUMB_ITEM10_CHECK_ICON,
    HWND_DMP_PHOTO_PAGE_THUMB_ITEM11_CHECK_ICON,
    HWND_DMP_PHOTO_PAGE_THUMB_ITEM12_CHECK_ICON
};

#else
static HWND _hwndListFileItem[DMP_NUM_OF_FILES_PER_PAGE] =
{
    HWND_DMP_FILE_PAGE_THUMB_ITEM1,
    HWND_DMP_FILE_PAGE_THUMB_ITEM2,
    HWND_DMP_FILE_PAGE_THUMB_ITEM3,
    HWND_DMP_FILE_PAGE_THUMB_ITEM4,
    HWND_DMP_FILE_PAGE_THUMB_ITEM5,
    HWND_DMP_FILE_PAGE_THUMB_ITEM6,
    HWND_DMP_FILE_PAGE_THUMB_ITEM7,
    HWND_DMP_FILE_PAGE_THUMB_ITEM8,
    HWND_DMP_FILE_PAGE_THUMB_ITEM9,
    HWND_DMP_FILE_PAGE_THUMB_ITEM10,
    HWND_DMP_FILE_PAGE_THUMB_ITEM11,
    HWND_DMP_FILE_PAGE_THUMB_ITEM12
};

static HWND _hwndListFileIcon[DMP_NUM_OF_FILES_PER_PAGE] =
{
    HWND_DMP_FILE_PAGE_THUMB_ITEM1_ICON,
    HWND_DMP_FILE_PAGE_THUMB_ITEM2_ICON,
    HWND_DMP_FILE_PAGE_THUMB_ITEM3_ICON,
    HWND_DMP_FILE_PAGE_THUMB_ITEM4_ICON,
    HWND_DMP_FILE_PAGE_THUMB_ITEM5_ICON,
    HWND_DMP_FILE_PAGE_THUMB_ITEM6_ICON,
    HWND_DMP_FILE_PAGE_THUMB_ITEM7_ICON,
    HWND_DMP_FILE_PAGE_THUMB_ITEM8_ICON,
    HWND_DMP_FILE_PAGE_THUMB_ITEM9_ICON,
    HWND_DMP_FILE_PAGE_THUMB_ITEM10_ICON,
    HWND_DMP_FILE_PAGE_THUMB_ITEM11_ICON,
    HWND_DMP_FILE_PAGE_THUMB_ITEM12_ICON
};

static HWND _hwndListFileString[DMP_NUM_OF_FILES_PER_PAGE] =
{
    HWND_DMP_FILE_PAGE_THUMB_ITEM1_STRING,
    HWND_DMP_FILE_PAGE_THUMB_ITEM2_STRING,
    HWND_DMP_FILE_PAGE_THUMB_ITEM3_STRING,
    HWND_DMP_FILE_PAGE_THUMB_ITEM4_STRING,
    HWND_DMP_FILE_PAGE_THUMB_ITEM5_STRING,
    HWND_DMP_FILE_PAGE_THUMB_ITEM6_STRING,
    HWND_DMP_FILE_PAGE_THUMB_ITEM7_STRING,
    HWND_DMP_FILE_PAGE_THUMB_ITEM8_STRING,
    HWND_DMP_FILE_PAGE_THUMB_ITEM9_STRING,
    HWND_DMP_FILE_PAGE_THUMB_ITEM10_STRING,
    HWND_DMP_FILE_PAGE_THUMB_ITEM11_STRING,
    HWND_DMP_FILE_PAGE_THUMB_ITEM12_STRING,
};

static HWND _hwndListFileCheckMark[DMP_NUM_OF_FILES_PER_PAGE] =
{
    HWND_DMP_FILE_PAGE_THUMB_ITEM1_CHECK_ICON,
    HWND_DMP_FILE_PAGE_THUMB_ITEM2_CHECK_ICON,
    HWND_DMP_FILE_PAGE_THUMB_ITEM3_CHECK_ICON,
    HWND_DMP_FILE_PAGE_THUMB_ITEM4_CHECK_ICON,
    HWND_DMP_FILE_PAGE_THUMB_ITEM5_CHECK_ICON,
    HWND_DMP_FILE_PAGE_THUMB_ITEM6_CHECK_ICON,
    HWND_DMP_FILE_PAGE_THUMB_ITEM7_CHECK_ICON,
    HWND_DMP_FILE_PAGE_THUMB_ITEM8_CHECK_ICON,
    HWND_DMP_FILE_PAGE_THUMB_ITEM9_CHECK_ICON,
    HWND_DMP_FILE_PAGE_THUMB_ITEM10_CHECK_ICON,
    HWND_DMP_FILE_PAGE_THUMB_ITEM11_CHECK_ICON,
    HWND_DMP_FILE_PAGE_THUMB_ITEM12_CHECK_ICON
};
#endif


static HWND _hwndListPlaylistItem[UI_DMP_PLAYLIST_NUMBER] =
{
    HWND_DMP_PLAYBACK_PLAYLIST_ITEM1,
    HWND_DMP_PLAYBACK_PLAYLIST_ITEM2,
    HWND_DMP_PLAYBACK_PLAYLIST_ITEM3,
    HWND_DMP_PLAYBACK_PLAYLIST_ITEM4,
    HWND_DMP_PLAYBACK_PLAYLIST_ITEM5,
    HWND_DMP_PLAYBACK_PLAYLIST_ITEM6,
    HWND_DMP_PLAYBACK_PLAYLIST_ITEM7,
    HWND_DMP_PLAYBACK_PLAYLIST_ITEM8,
    HWND_DMP_PLAYBACK_PLAYLIST_ITEM9,
    HWND_DMP_PLAYBACK_PLAYLIST_ITEM10,
};

static HWND _hwndListInfoBar[DMP_INFOBAR_ICON_NUM]=
{
    HWND_DMP_PLAYBACK_INFOBAR_ITEM1,
    HWND_DMP_PLAYBACK_INFOBAR_ITEM2,
    HWND_DMP_PLAYBACK_INFOBAR_ITEM3,
    HWND_DMP_PLAYBACK_INFOBAR_ITEM4,
    HWND_DMP_PLAYBACK_INFOBAR_ITEM5,
    HWND_DMP_PLAYBACK_INFOBAR_ITEM6,
    HWND_DMP_PLAYBACK_INFOBAR_ITEM7,
    HWND_DMP_PLAYBACK_INFOBAR_ITEM8,
};

static U8 _u8InfoBarIdx;
#if (ENABLE_DIVX_PLUS == 1)
static U8 u8MovieInfoBarMax = 19;
#elif (ENABLE_MPLAYER_CAPTURE_MOVIE== 1)
static U8 u8MovieInfoBarMax = 18;
#else
static U8 u8MovieInfoBarMax = 17;
#endif

/*action bitmap string*/
#define INFOBAR_ACT_IDX     0
#define INFOBAR_BMP_IDX     1
#define INFOBAR_STR_IDX     2

static U32 DMP_MovieInfoBarTable[][3] =
{
    {EN_EXE_DMP_PLAYBACK_MOVIEINFO_PLAY_PAUSE,E_BMP_DMP_BUTTON_ICON_PAUSE,en_str_DMP_Pause},
    {EN_EXE_DMP_PLAYBACK_MOVIEINFO_FB,E_BMP_DMP_BUTTON_ICON_FB,en_str_DMP_FB},
    {EN_EXE_DMP_PLAYBACK_MOVIEINFO_FF,E_BMP_DMP_BUTTON_ICON_FF,en_str_DMP_FF},
#if ENABLE_DRM
    {EN_EXE_DMP_PLAYBACK_MOVIEINFO_PREV_CLICK,E_BMP_DMP_BUTTON_ICON_PREV,en_str_DMP_Prev},
#else
    {EN_EXE_DMP_PLAYBACK_MOVIEINFO_PREV,E_BMP_DMP_BUTTON_ICON_PREV,en_str_DMP_Prev},
#endif
    {EN_EXE_DMP_PLAYBACK_MOVIEINFO_NEXT,E_BMP_DMP_BUTTON_ICON_NEXT,en_str_DMP_Next},
    {EN_EXE_DMP_PLAYBACK_MOVIEINFO_STOP,E_BMP_DMP_BUTTON_ICON_STOP,en_str_DMP_Stop},
    {EN_EXE_DMP_PLAYBACK_MOVIEINFO_REPEAT,E_BMP_DMP_BUTTON_ICON_REPEAT,en_str_Repeat_txt},
    {EN_EXE_DMP_PLAYBACK_MOVIEINFO_AB_REPEAT,E_BMP_DMP_BUTTON_ICON_AB_REPEAT,en_str_DMP_SET_A},
    {EN_EXE_DMP_PLAYBACK_MOVIEINFO_PLAYLIST,E_BMP_DMP_BUTTON_ICON_PLAY_LIST,en_str_DMP_Playlist},
    {EN_EXE_DMP_PLAYBACK_MOVIEINFO_INFO,E_BMP_DMP_BUTTON_ICON_INFO,en_str_DMP_Info},
    {EN_EXE_DMP_PLAYBACK_MOVIEINFO_SF,E_BMP_DMP_BUTTON_ICON_FF,en_str_DMP_SLOW_FORWARD},
    {EN_EXE_DMP_PLAYBACK_MOVIEINFO_SD,E_BMP_DMP_STEP_FORWARD,en_str_DMP_STEP_DISPLAY},
    {EN_EXE_DMP_PLAYBACK_MOVIEINFO_GOTO_TIME,E_BMP_DMP_BUTTON_ICON_TIME,en_str_DMP_Goto_Time},
    {EN_EXE_DMP_PLAYBACK_MOVIEINFO_ZOOMIN,E_BMP_DMP_BUTTON_ICON_ZOOMOUT,en_str_DMP_PhotoInfo_ZoomIn},
    {EN_EXE_DMP_PLAYBACK_MOVIEINFO_ZOOMOUT,E_BMP_DMP_BUTTON_ICON_ZOOMIN,en_str_DMP_PhotoInfo_ZoomOut},
    {EN_EXE_DMP_PLAYBACK_MOVIEINFO_ASPECT_RATIO, E_BMP_DMP_BUTTON_ICON_FUNCTION, en_str_AspectRatio},
    {EN_EXE_DMP_PLAYBACK_MOVIEINFO_MOVEVIEW, E_BMP_DMP_MOVE_VIEW, en_str_DMP_MoveView},
#if (ENABLE_MPLAYER_CAPTURE_MOVIE == 1)
    {EN_EXE_DMP_PLAYBACK_MOVIEINFO_CAPTURE,E_BMP_DMP_BUTTON_ICON_CAPTURE,en_str_DMP_Capture},
#endif
#if (ENABLE_DIVX_PLUS == 1)
    {EN_EXE_DMP_PLAYBACK_MOVIEINFO_DIVX,E_BMP_MAINMENU_IMG_CHANNEL_FOCUS,en_str_DMP_DivxSetting},
#endif
};

typedef enum
{
    MOVIEINFO_PLAY_PAUSE,
    MOVIEINFO_FB,
    MOVIEINFO_FF,
    MOVIEINFO_PREV,
    MOVIEINFO_NEXT,
    MOVIEINFO_STOP,
    MOVIEINFO_REPEAT,
    MOVIEINFO_AB_REPEAT,
    MOVIEINFO_PLAYLIST,
    MOVIEINFO_INFO,
    MOVIEINFO_SF,
    MOVIEINFO_STEP_DISPLAY,
    MOVIEINFO_GOTO_TIME,
    MOVIEINFO_ZOOMIN,
    MOVIEINFO_ZOOMOUT,
    MOVIEINFO_RATIO,
    MOVIEINFO_MOVEVIEW,
#if (ENABLE_MPLAYER_CAPTURE_MOVIE == 1)
    MOVIEINFO_CAPTURE,
#endif
#if (ENABLE_DIVX_PLUS == 1)
    MOVIEINFO_DIVX,
#endif
} MOVIEINFO_ORDER;

#if (ENABLE_MPLAYER_CAPTURE_LOGO== 1)
static const U8 u8PhotoInfoBarMax = 14;
#else
static const U8 u8PhotoInfoBarMax = 13;
#endif
/*action bitmapWnd stringWnd*/

static U32 DMP_PhotoInfoBarTable[][3] =
{
    {EN_EXE_DMP_PLAYBACK_PHOTOINFO_PLAY_PAUSE,E_BMP_DMP_BUTTON_ICON_PAUSE,en_str_DMP_Pause},
    {EN_EXE_DMP_PLAYBACK_PHOTOINFO_PREV,E_BMP_DMP_BUTTON_ICON_PREV,en_str_DMP_Prev},
    {EN_EXE_DMP_PLAYBACK_PHOTOINFO_NEXT,E_BMP_DMP_BUTTON_ICON_NEXT,en_str_DMP_Next},
    {EN_EXE_DMP_PLAYBACK_PHOTOINFO_STOP,E_BMP_DMP_BUTTON_ICON_STOP,en_str_DMP_Stop},
    {EN_EXE_DMP_PLAYBACK_PHOTOINFO_REPEAT,E_BMP_DMP_BUTTON_ICON_REPEAT,en_str_Repeat_txt},
    {EN_EXE_DMP_PLAYBACK_PHOTOINFO_MUSIC,E_BMP_DMP_BUTTON_ICON_BGM,en_str_DMP_MusicOff},
    {EN_EXE_DMP_PLAYBACK_PHOTOINFO_PLAYLIST,E_BMP_DMP_BUTTON_ICON_PLAY_LIST,en_str_DMP_Playlist},
    {EN_EXE_DMP_PLAYBACK_PHOTOINFO_INFO,E_BMP_DMP_BUTTON_ICON_INFO,en_str_DMP_Info},
    {EN_EXE_DMP_PLAYBACK_PHOTOINFO_CLOCKWISE,E_BMP_DMP_BUTTON_ICON_ROTATE_CLOCK,en_str_DMP_PhotoInfo_Rotate},
    {EN_EXE_DMP_PLAYBACK_PHOTOINFO_COUNTERCLOCKWISE,E_BMP_DMP_BUTTON_ICON_ROTATE_ANTICLOCK,en_str_DMP_PhotoInfo_Rotate},
    {EN_EXE_DMP_PLAYBACK_PHOTOINFO_ZOOMIN,E_BMP_DMP_BUTTON_ICON_ZOOMOUT,en_str_DMP_PhotoInfo_ZoomIn},
    {EN_EXE_DMP_PLAYBACK_PHOTOINFO_ZOOMOUT,E_BMP_DMP_BUTTON_ICON_ZOOMIN,en_str_DMP_PhotoInfo_ZoomOut},
    {EN_EXE_DMP_PLAYBACK_PHOTOINFO_MOVEVIEW, E_BMP_DMP_MOVE_VIEW, en_str_DMP_MoveView},
#if (ENABLE_MPLAYER_CAPTURE_LOGO== 1)
    {EN_EXE_DMP_PLAYBACK_PHOTOINFO_CAPTURE,E_BMP_DMP_BUTTON_ICON_CAPTURE,en_str_DMP_Capture}
#endif
};

typedef enum
{
    PHOTOINFO_PLAY_PAUSE,
    PHOTOINFO_PREV,
    PHOTOINFO_NEXT,
    PHOTOINFO_STOP,
    PHOTOINFO_REPEAT,
    PHOTOINFO_MUSIC,
    PHOTOINFO_PLAYLIST,
    PHOTOINFO_INFO,
    PHOTOINFO_CLOCKWISE,
    PHOTOINFO_COUNTERCLOCKWISE,
    PHOTOINFO_ZOOMIN,
    PHOTOINFO_ZOOMOUT,
    PHOTOINFO_MOVEVIEW,
#if (ENABLE_MPLAYER_CAPTURE_LOGO== 1)
    PHOTOINFO_CAPTURE,
#endif
} PHOTOINFO_ORDER;

#if (ENABLE_MPLAYER_CAPTURE_MUSIC== 1)
static const U8 u8MusicInfoBarMax = 12;
#else
static const U8 u8MusicInfoBarMax = 11;
#endif
/*action bitmapWnd stringWnd*/

static U32 DMP_MusicInfoBarTable[][3] =
{
    {EN_EXE_DMP_PLAYBACK_MUSICINFO_PLAY_PAUSE,E_BMP_DMP_BUTTON_ICON_PAUSE,en_str_DMP_Pause},
    {EN_EXE_DMP_PLAYBACK_MUSICINFO_FB,E_BMP_DMP_BUTTON_ICON_FB,en_str_DMP_FB},
    {EN_EXE_DMP_PLAYBACK_MUSICINFO_FF,E_BMP_DMP_BUTTON_ICON_FF,en_str_DMP_FF},
    {EN_EXE_DMP_PLAYBACK_MUSICINFO_PREV,E_BMP_DMP_BUTTON_ICON_PREV,en_str_DMP_Prev},
    {EN_EXE_DMP_PLAYBACK_MUSICINFO_NEXT,E_BMP_DMP_BUTTON_ICON_NEXT,en_str_DMP_Next},
    {EN_EXE_DMP_PLAYBACK_MUSICINFO_STOP,E_BMP_DMP_BUTTON_ICON_STOP,en_str_DMP_Stop},
    {EN_EXE_DMP_PLAYBACK_MUSICINFO_REPEAT,E_BMP_DMP_BUTTON_ICON_REPEAT,en_str_Repeat_txt},
    {EN_EXE_DMP_PLAYBACK_MUSICINFO_MUTE,E_BMP_DMP_BUTTON_ICON_MUTE_MINI,en_strMuteText},
    {EN_EXE_DMP_PLAYBACK_MUSICINFO_PLAYLIST,E_BMP_DMP_BUTTON_ICON_PLAY_LIST,en_str_DMP_Playlist},
    {EN_EXE_DMP_PLAYBACK_MUSICINFO_INFO,E_BMP_DMP_BUTTON_ICON_INFO,en_str_DMP_Info},
#if (ENABLE_MPLAYER_CAPTURE_MUSIC== 1)
    {EN_EXE_DMP_PLAYBACK_MUSICINFO_CAPTURE,E_BMP_DMP_BUTTON_ICON_CAPTURE,en_str_DMP_Capture},
#endif
    {EN_EXE_DMP_PLAYBACK_MUSICINFO_GOTO_TIME,E_BMP_DMP_BUTTON_ICON_TIME,en_str_DMP_Goto_Time}
};

typedef enum
{
    MUSICINFO_PLAY_PAUSE,
    MUSICINFO_FB,
    MUSICINFO_FF,
    MUSICINFO_PREV,
    MUSICINFO_NEXT,
    MUSICINFO_STOP,
    MUSICINFO_REPEAT,
    MUSICINFO_MUTE,
    MUSICINFO_PLAYLIST,
    MUSICINFO_INFO,
#if (ENABLE_MPLAYER_CAPTURE_MUSIC== 1)
    MUSICINFO_CAPTURE,
#endif
    MUSICINFO_GOTO_TIME,
} MUSICINFO_ORDER;

static const U8 u8TextInfoBarMax = 8;
/*action bitmapWnd stringWnd*/

static U32 DMP_TextInfoBarTable[][3] =
{
    {EN_EXE_DMP_PLAYBACK_TEXTINFO_PREV,E_BMP_DMP_BUTTON_ICON_FB,en_str_DMP_PrevPage},
    {EN_EXE_DMP_PLAYBACK_TEXTINFO_NEXT,E_BMP_DMP_BUTTON_ICON_FF,en_str_DMP_NextPage},
    {EN_EXE_DMP_PLAYBACK_TEXTINFO_PREVFILE,E_BMP_DMP_BUTTON_ICON_PREV,en_str_DMP_Prev},
    {EN_EXE_DMP_PLAYBACK_TEXTINFO_NEXTFILE,E_BMP_DMP_BUTTON_ICON_NEXT,en_str_DMP_Next},
    {EN_EXE_DMP_PLAYBACK_TEXTINFO_STOP,E_BMP_DMP_BUTTON_ICON_STOP,en_str_DMP_Stop},
    {EN_EXE_DMP_PLAYBACK_TEXTINFO_MUSIC,E_BMP_DMP_BUTTON_ICON_BGM,en_str_DMP_MusicOff},
    {EN_EXE_DMP_PLAYBACK_TEXTINFO_PLAYLIST,E_BMP_DMP_BUTTON_ICON_PLAY_LIST,en_str_DMP_Playlist},
    {EN_EXE_DMP_PLAYBACK_TEXTINFO_INFO,E_BMP_DMP_BUTTON_ICON_INFO,en_str_DMP_Info},
};

typedef enum
{
    TEXTINFO_PREV,
    TEXTINFO_NEXT,
    TEXTINFO_PREVFILE,
    TEXTINFO_NEXTFILE,
    TEXTINFO_STOP,
    TEXTINFO_MUSIC,
    TEXTINFO_PLAYLIST,
    TEXTINFO_INFO,
} TEXTINFO_ORDER;

typedef enum
{
    PLAY_MODE_ICON_NEXT,
    PLAY_MODE_ICON_PREVIOUS,
    PLAY_MODE_ICON_STOP,
    PLAY_MODE_ICON_PLAY,
    PLAY_MODE_ICON_PAUSE,
    PLAY_MODE_ICON_AB_REPEAT,
    PLAY_MODE_ICON_SETA,
    PLAY_MODE_ICON_AB_LOOP,
    PLAY_MODE_ICON_FF2X,
    PLAY_MODE_ICON_FF4X,
    PLAY_MODE_ICON_FF8X,
    PLAY_MODE_ICON_FF16X,
    PLAY_MODE_ICON_FF32X,
    PLAY_MODE_ICON_FB2X,
    PLAY_MODE_ICON_FB4X,
    PLAY_MODE_ICON_FB8X,
    PLAY_MODE_ICON_FB16X,
    PLAY_MODE_ICON_FB32X,
    PLAY_MODE_ICON_SF2X,
    PLAY_MODE_ICON_SF4X,
    PLAY_MODE_ICON_SF8X,
    PLAY_MODE_ICON_SF16X,
    PLAY_MODE_ICON_SF32X,
    PLAY_MODE_ICON_SD,
    PLAY_MODE_ICON_FB_INVALID,
    PLAY_MODE_ICON_FF_INVALID,
    PLAY_MODE_ICON_RATIO_Panorama,
    PLAY_MODE_ICON_RATIO_Original,
    PLAY_MODE_ICON_RATIO_4X3,
    PLAY_MODE_ICON_RATIO_16X9,
    PLAY_MODE_ICON_RATION_ZOOM1,
    PLAY_MODE_ICON_RATION_ZOOM2,
    PLAY_MODE_ICON_RATION_JUSTSCAN,
	PLAY_MODE_ICON_ZOOM,
    #if 1//minglin0419
    PLAY_MODE_ICON_PICTURE_MODE,
    PLAY_MODE_ICON_SOUND_MODE,
    #endif
    PLAY_MODE_ICON_REPEAT_MODE, 
    PLAY_MODE_ICON_MAX,
}EN_DMP_PLAY_ICON_TYPE;

typedef struct
{
    //BOOLEAN     bFuncAdv;
    BOOLEAN     bSubtitleOff;   //is subtitle OFF mode
    U8          MPlayerSubtitleBuf[DMP_STRING_BUF_SIZE];
    U32         au32MovieRepeatTime[2]; //Repeat A->B
} ST_MOVIE_INFO;

typedef struct
{
    U8          MPlayerLyricBuf[DMP_STRING_BUF_SIZE];
} ST_MUSIC_INFO;

typedef struct
{
    ST_MOVIE_INFO   stMovieInfo;
    ST_MUSIC_INFO   stMusicInfo;
} ST_DMP_PLAYBACK_VAR;

typedef enum
{
    REPEATAB_MODE_NONE,
    REPEATAB_MODE_A,
    REPEATAB_MODE_AB,
    REPEATAB_MODE_MAX,
}EN_DMP_REPEATAB_STATUS;

typedef enum
{
    UART_NONE,
    UART_HK,
    UART_VDEC,
    UART_AEON,
    UART_NUM,
}EN_DMP_UART_MODE;

/////////////////////////////////////
//      Local Variables
/////////////////////////////////////
static EN_DMP_MSG_TYPE _enDmpMsgType = DMP_MSG_TYPE_MAX;
static MPlayerFileInfo _stCopyFileInfo;
static enumMPlayerNotifyType _enNotify = E_MPLAYER_NOTIFY_NUM;
static enumMPlayerMoviePlayMode _enPlayMode_AtNotify;
static EN_DMP_PLAY_ICON_TYPE _enDmpPlayIconType = PLAY_MODE_ICON_MAX;
static EN_DMP_PLAY_ICON_TYPE _enDmpPlayStrType = PLAY_MODE_ICON_MAX;
static U32 _u32MusicCurrentTime;
static U16 _u16MovieCurrentTime = 0;
static U16 _u16MovieTotalTime = 0;
static EN_DMP_REPEATAB_STATUS _enRepeatABStatus;
static U8 _u8Hour = 0, _u8Minute = 0, _u8Second = 0;
static U16 m_u16PlayErrorNum = 0;
#ifndef ATSC_SYSTEM
static EN_DMP_UART_MODE _u8UARTMode;
static HWND hwnd_before;
#endif
#if DMP_UI_BMPSUBTITLE_EXCLUSIVE
/* This flag is used to prevent the E_MPLAYER_NOTIFY_HIDE_SUBTITLE interrupt,
the interrupt will close gwin, hence the ui cant be showed;
*/
static BOOLEAN bUIexist = FALSE;
#endif

#if SH_RESUME_AUTOPLAY
static U8 isMusicResume=0;
#endif

#if (ENABLE_DIVX_PLUS == 1)
typedef enum
{
    DIVX_MENU,
    DIVX_SET_TITLE,
    DIVX_SET_EDITION,
    DIVX_SET_CHAPTER,
    DIVX_SET_AUTOCHAPTER,
    DIVX_MAX,
}EN_DMP_DIVX_STATUS;

static U16 _u16DivxTitleIdx = 0;
static U16 _u16DivxEditionIdx = 0;
static U16 _u16DivxChpIdx = 0;
static U8 _u8DivxAutoChpIdx = 0;
static EN_DMP_DIVX_STATUS _enDmpDivxStatus;
#endif

#if ENABLE_MPLAYER_RECORD_DIR_ENTRY
static U16 _u16FileIdxByDir[NUM_OF_MAX_DIRECTORY_DEPTH];
#endif
static ST_DMP_PLAYBACK_VAR  _stDmpPlayVar;
extern BOOLEAN _MApp_ZUI_API_WindowProcOnIdle(void);
extern BOOLEAN _MApp_ZUI_API_AllocateVarData(void);
extern U16 MApp_Transfer2Unicode(U16 u16Code);


#if (DMP_PHOTO_THUMBNAIL || DMP_MOVIE_THUMBNAIL || DMP_MUSIC_THUMBNAIL)
static U16 _ThumbNOIdx = 0xFFFF;
static U16 _ThumbOKIdx = 0xFFFF;
static U8 _CopyFbId = 0xFF;
static BOOLEAN _InsertQFlag = TRUE;
static BOOLEAN _ThumbLoadPageFlag = TRUE;
static U8 _ThumbInsertNum = 0;
#endif

#if (DMP_PHOTO_THUMBNAIL || DMP_MOVIE_THUMBNAIL || DMP_MUSIC_THUMBNAIL)
static void _MApp_DMP_ThumbCopyRegion_ClearFB(void)
{
    if(_CopyFbId == 0xFF)
    {
        return;
    }
    else
    {
        GOP_GwinFBAttr fbAttr;
        MApi_GOP_GWIN_GetFBInfo(_CopyFbId, &fbAttr);
        MApi_GFX_ClearFrameBuffer(fbAttr.addr, fbAttr.size, 0x0);
    }
}

static void _MApp_DMP_ThumbCopyRegion_Create(void)
{
    GOP_GwinFBAttr fbAttr;
    GRAPHIC_DC *dc = MApp_ZUI_API_GetScreenDC();
    if(_CopyFbId != 0xFF)
    {
        MApi_GOP_GWIN_DeleteFB(_CopyFbId);
    }
    MApi_GOP_GWIN_GetFBInfo(dc->u8FbID, &fbAttr);
    _CopyFbId = MApi_GOP_GWIN_GetFreeFBID();

#if defined(MAD_THUMBNAIL_FB_BUF_LEN) && (MAD_THUMBNAIL_FB_BUF_LEN!=0) //co-buffer to fix photo display
    if(!MApi_GOP_GWIN_CreateFBbyStaticAddr(_CopyFbId, ZUI_DMP_XSTART, ZUI_DMP_YSTART, ZUI_DMP_WIDTH, ZUI_DMP_HEIGHT,  fbAttr.fbFmt, MAD_THUMBNAIL_FB_BUF_ADR ))
#else
    if( !MApi_GOP_GWIN_CreateFB2(_CopyFbId, ZUI_DMP_XSTART, ZUI_DMP_YSTART,
                                    ZUI_DMP_WIDTH, ZUI_DMP_HEIGHT, fbAttr.fbFmt))
#endif
    {
        (printf("\n _MApp_MediaPlayer_ThumbCopyRegion Fail to create buffer %u.\n",_CopyFbId));
        _CopyFbId = 0xFF;
        return;
    }
    _MApp_DMP_ThumbCopyRegion_ClearFB();
}

static void _MApp_DMP_ThumbCopyRegion_Destroy(void)
{
    if(_CopyFbId == 0xFF)
    {
        return;
    }
    MApi_GOP_GWIN_DeleteFB(_CopyFbId);
    _CopyFbId = 0xFF;
}

static void _MApp_DMP_ThumbCopyRegion_CloneRect(U8 fbId, RECT *rect)
{
    MSAPI_OSDRegion CopyFB;
    MSAPI_OSDRegion PasteFB;
    if(_CopyFbId == 0xFF)
    {
        return;
    }
    //printf("[Clone Region] (%d, %d) w = %d, h = %d\n", rect->left, rect->top, rect->width, rect->height);
    msAPI_OSD_SetClipWindow(
                    rect->left, rect->top,
                    rect->left+rect->width-1,
                    rect->top+rect->height-1);
    //Backup n thumbnail region
    PasteFB.fbID=_CopyFbId;
    PasteFB.x=rect->left;
    PasteFB.y=rect->top;
    PasteFB.width=rect->width;
    PasteFB.height=rect->height;
    CopyFB.fbID=fbId;
    CopyFB.x=rect->left;
    CopyFB.y=rect->top;
    CopyFB.width=rect->width;
    CopyFB.height=rect->height;
    msAPI_OSD_CopyRegion(&CopyFB, &PasteFB);
}

static void _MApp_DMP_ThumbCopyRegion_PasteTo(RECT *rect)
{
    MSAPI_OSDRegion CopyFB;
    MSAPI_OSDRegion PasteFB;
    GRAPHIC_DC *dc = MApp_ZUI_API_GetBufferDC();
    if(_CopyFbId == 0xFF)
    {
        return;
    }
    //printf("[Paste Region] (%d, %d) w = %d, h = %d\n", rect->left, rect->top, rect->width, rect->height);
    msAPI_OSD_SetClipWindow(
                    rect->left, rect->top,
                    rect->left+rect->width-1,
                    rect->top+rect->height-1);
    PasteFB.fbID=dc->u8FbID;
    PasteFB.x=rect->left;
    PasteFB.y=rect->top;
    PasteFB.width=rect->width;
    PasteFB.height=rect->height;
    CopyFB.fbID=_CopyFbId;
    CopyFB.x=rect->left;
    CopyFB.y=rect->top;
    CopyFB.width=rect->width;
    CopyFB.height=rect->height;
    msAPI_OSD_CopyRegion(&CopyFB, &PasteFB);
}
static void _MApp_DMP_Thumbnail_ChangePage(void)
{
    MApp_MPlayer_StopThumbnail();
    MApp_DMP_ClearDmpFlag(DMP_FLAG_THUMBNAIL_MODE);
    MApp_DMP_ClearDmpFlag(DMP_FLAG_THUMBNAIL_PLAYING);
    _ThumbNOIdx = 0xFFFF;
    _ThumbOKIdx = 0xFFFF;
    _ThumbLoadPageFlag = TRUE;
    _ThumbInsertNum = 0;
    _MApp_DMP_ThumbCopyRegion_ClearFB();
}
#endif

#if DMP_UI_BMPSUBTITLE_EXCLUSIVE
static void _MApp_ZUI_ACTdmp_RestoreGWINandFB(void)
{
    DMP_DBG(printf("_MApp_ZUI_ACTdmp_RestoreGWINandFB FALSE\n"));
    msAPI_MpegSP_SetShowStatus(FALSE);
    {
        U8 u8GWinId = MApp_ZUI_API_QueryGWinID();
        //if(u8GWinId == 0xFF)
        {
            if(MApp_ZUI_API_IsWindowVisible(HWND_DMP_PLAYBACK_MOVIERESUME_PAGE))
                MApp_ZUI_API_KillTimer(HWND_DMP_PLAYBACK_MOVIERESUME_PAGE, 0);
            //DMP_DBG(printf("close subtitle 5\n"););
            MApp_DMP_BW_Control(TRUE);
            //Reinit MM OSD
            {
                RECT rect;
                RECT_SET(rect,
                    ZUI_DMP_XSTART, ZUI_DMP_YSTART,
                    ZUI_DMP_WIDTH, ZUI_DMP_HEIGHT);
                if (!MApp_ZUI_API_InitGDI(&rect))
                {
                    DMP_DBG(printf("[ZUI]GDI RE-INIT Failed 5!\n"));
                    //ABORT();
                    //return FALSE;
                }
                DMP_DBG(printf("MApp_ZUI_API_InitGDI 8\n"););
            }
        }
        u8GWinId = MApp_ZUI_API_QueryGWinID();
        if(!MApi_GOP_GWIN_IsGWINEnabled(u8GWinId))
        {
            DMP_DBG(printf("MApi_GOP_GWIN_Enable here %u\n",u8GWinId));
            MApi_GOP_GWIN_Enable(u8GWinId, TRUE);
        }
    }
}
#endif

static void _MApp_ZUI_ACTdmp_OperateSubtitle(void)
{
    if(MApp_MPlayer_QueryCurrentMediaType() == E_MPLAYER_TYPE_MOVIE)
    {
        if(_stDmpPlayVar.stMovieInfo.bSubtitleOff)
        {
        #if (ENABLE_SUBTITLE_DMP)
            MApp_MPlayer_DisableSubtitle();
        #endif

            MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_SUBTITLE_PAGE ,SW_HIDE);

            return;
        }
        else
        {
        #if (ENABLE_SUBTITLE_DMP)
            MApp_MPlayer_EnableSubtitle();
        #endif
        }

        {
            // check UI
            U8 u8GWinId = MApp_ZUI_API_QueryGWinID();

            if (u8GWinId == 0xFF)
            {
               return;
            }

            if(! MApi_GOP_GWIN_IsGWINEnabled(u8GWinId)) // UI doesnt exist
            {
                DMP_DBG(printf("_MApp_ZUI_ACTdmp_OperateSubtitle TRUE\n"));
                msAPI_MpegSP_SetShowStatus(TRUE);
            }
            else // UI exist
            {
                 // UI can not be seen
                if(!MApp_DMP_IsOSDVisible())
                {
                    //if(MApi_GOP_GWIN_IsGWINEnabled(u8GWinId))
                    {
                        #if DMP_UI_BMPSUBTITLE_EXCLUSIVE
                        MApi_GOP_GWIN_Enable(u8GWinId, FALSE);
                        #endif
                        MApp_DMP_BW_Control(FALSE);
                        DMP_DBG(printf("MApp_ZUI_API_TerminateGDI actdmp %u\n",u8GWinId););
                        #if DMP_UI_BMPSUBTITLE_EXCLUSIVE
                        MApp_ZUI_API_EmptyMessageQueue();
                        MApp_ZUI_API_TerminateGDI();
                        DMP_DBG(printf("draw subtitle TRUE1\n"););
                        msAPI_MpegSP_SetShowStatus(TRUE);
                        #endif
                    }
                }
                else // UI can be seen
                {
                    DMP_DBG(printf("close subtitle 2 FALSE\n"););
                    #if DMP_UI_BMPSUBTITLE_EXCLUSIVE
                    msAPI_MpegSP_SetShowStatus(FALSE);
                    #endif
                }
            }
        }
    }
}
/*
static void _MApp_MediaPlayer_ProcessVolume(U16 act)
{
    //printf("_MApp_MediaPlayer_ProcessVolume\n");
    if(MApp_ZUI_API_IsSuccessor(HWND_MEDIA_PLAYER_VOLUME_LIST, MApp_ZUI_API_GetFocus()))
    {
        MApp_ZUI_API_ResetTimer(HWND_MEDIA_PLAYER_VOLUME_LIST, MPLAYER_VOLUME_TIMER);
    }
    else
    {
        MApp_ZUI_API_StoreFocusCheckpoint();
        MApp_ZUI_API_SetTimer(HWND_MEDIA_PLAYER_VOLUME_LIST, MPLAYER_VOLUME_TIMER, AUDIO_VOLUME_TIME_OUT_MS);
    }
    if(act == EN_EXE_MEDIA_PLAYER_VOLUME_PLUS)
    {
        if ( stGenSetting.g_SoundSetting.Volume < MAX_NUM_OF_VOL_LEVEL )
        {
            stGenSetting.g_SoundSetting.Volume++;
            msAPI_AUD_AdjustAudioFactor(E_ADJUST_VOLUME, stGenSetting.g_SoundSetting.Volume, 0);
        }
    }
    else
    {
        if ( stGenSetting.g_SoundSetting.Volume > 0 )
        {
            stGenSetting.g_SoundSetting.Volume--;
            msAPI_AUD_AdjustAudioFactor(E_ADJUST_VOLUME, stGenSetting.g_SoundSetting.Volume, 0);
        }
    }
    if(stGenSetting.g_SoundSetting.Volume == 0)
    {
        msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_BYUSER_MUTEON, E_AUDIOMUTESOURCE_ACTIVESOURCE);
    }
    else
    {
        msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_BYUSER_MUTEOFF, E_AUDIOMUTESOURCE_ACTIVESOURCE);
    }
#if EAR_PHONE_POLLING
    if (PreEarphoneState != EAR_PHONE_NULL)
    {
        if(stGenSetting.g_SoundSetting.Volume>0)
        {
            EarPhone_ON();
        }
        else
        {
            EarPhone_OFF();
        }
    }
#endif
    if(stGenSetting.g_SoundSetting.Volume>0)
    {
        MApp_ZUI_API_ShowWindow(HWND_MEDIA_PLAYER_VOLUME_CONFIG_PANE, SW_SHOW);
        MApp_UiMenu_MuteWin_Hide();
        MApp_ZUI_API_SetFocus(HWND_MEDIA_PLAYER_VOLUME_CONFIG_BAR);
        MApp_ZUI_API_InvalidateAllSuccessors(HWND_MEDIA_PLAYER_VOLUME_CONFIG_PANE);
    }
    else
    {
        MApp_ZUI_API_KillTimer(HWND_MEDIA_PLAYER_VOLUME_LIST, MPLAYER_VOLUME_TIMER);
        MApp_ZUI_API_ShowWindow(HWND_MEDIA_PLAYER_VOLUME_CONFIG_PANE, SW_HIDE);
        MApp_UiMenu_MuteWin_Show();
        MApp_ZUI_API_InvalidateAllSuccessors(HWND_MEDIA_PLAYER_VOLUME_LIST);
        MApp_ZUI_API_RestoreFocusCheckpoint();
    }
}

*/

static void _MApp_ZUI_ACT_DMPMarqueeTextEnableAnimation(HWND hwnd, BOOLEAN bEnable)
{
    //note: if enable, try to check string length is long enough, and then start animation
    //          if disable, stop and clear to normal status

    if (hwnd != HWND_INVALID)
    {
        GUI_DATA_MARQUEE_VARDATA * pData =
            (GUI_DATA_MARQUEE_VARDATA*)MApp_ZUI_API_GetWindowData(hwnd);

        if (pData == NULL)
             return;

        if (bEnable)
        {
            pData->u8ShowStartPosition = 0;
            MApp_ZUI_API_SetTimer(hwnd, 0, DMP_MARQUEE_INITIAL_INTERVAL_MS);

        }
        else
        {
            pData->u8ShowStartPosition = 0xFF;
            MApp_ZUI_API_KillTimer(hwnd, 0);
        }
        MApp_ZUI_API_InvalidateWindow(hwnd);
    }
}

static void _MApp_ACTdmp_ShowScrollBar(void)
{
#ifdef ENABLE_SMC_UI_NEW     /* smc.qxr 20121016 */
    RECT rect;
    U16 ymax,y,gap,ballSize=30;


    MApp_ZUI_API_ShowWindow(HWND_DMP_FILE_PAGE_SCROLL_BAR_BALL, SW_HIDE);
    if(MApp_MPlayer_QueryTotalPages()>1)
    {

      MApp_ZUI_API_ShowWindow(HWND_DMP_FILE_PAGE_SCROLL_BAR_BALL, SW_SHOW);

      MApp_ZUI_API_GetWindowRect(HWND_DMP_FILE_PAGE_SCROLL_BAR,&rect);

      ymax = rect.top+rect.height-ballSize;
      gap = rect.height/MApp_MPlayer_QueryTotalPages();
      y = rect.top + 2 + (MApp_MPlayer_QueryCurrentPageIndex()*gap);
      if(y>ymax)y=ymax;

      printf("\nrect: %d,%d,%d,%d, y:%d gap:%d,ymax:%d\n",rect.left,rect.top,rect.width,rect.height,y,gap,ymax);

      MApp_ZUI_API_GetWindowRect(HWND_DMP_FILE_PAGE_SCROLL_BAR_BALL,&rect);
      rect.top = y;
      printf("\n%d,%d,%d,%d\n",rect.left,rect.top,rect.width,rect.height);
      MApp_ZUI_API_MoveWindow(HWND_DMP_FILE_PAGE_SCROLL_BAR_BALL,&rect);

    }
#endif
}
/////////////////////////////////////////////////////////////////////
static void _MApp_ACTdmp_ShowMediaTypePage(void)
{
    MApp_ZUI_API_ShowWindow(HWND_MAINFRAME, SW_HIDE);
    MApp_ZUI_API_ShowWindow(HWND_DMP_ROOT_TRANSPARENT_BG, SW_SHOW);
    MApp_ZUI_API_ShowWindow(HWND_UP_BAR, SW_SHOW);
    MApp_ZUI_API_ShowWindow(HWND_BJ, SW_HIDE);// modified on 20171013 by mig 
    MApp_ZUI_API_ShowWindow(HWND_DOWN_BAR, SW_SHOW);
    MApp_ZUI_API_ShowWindow(HWND_DMP_SEL_BAR_GROUP, SW_SHOW);
    MApp_ZUI_API_ShowWindow(HWND_DMP_MEDIA_TYPE_PAGE, SW_SHOW);
    MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_MEDIA_TYPE_PAGE);
}

static void _MApp_ACTdmp_ShowDrivePage(void)
{
    U8 u8ShowItem;
    U8 u8TotalPageIdx = (MApp_MPlayer_QueryTotalDriveNum() / DMP_DRIVE_NUM_PER_PAGE)+1;
    U8 i;

    if(MApp_DMP_GetDrvPageIdx() == u8TotalPageIdx) //last page
    {
        u8ShowItem = (MApp_MPlayer_QueryTotalDriveNum() % DMP_DRIVE_NUM_PER_PAGE)+1;
    }
    else
    {
        u8ShowItem = DMP_DRIVE_NUM_PER_PAGE;
    }

    MApp_ZUI_API_ShowWindow(HWND_MAINFRAME, SW_HIDE);
    MApp_ZUI_API_ShowWindow(HWND_DMP_ROOT_TRANSPARENT_BG, SW_SHOW);
    MApp_ZUI_API_ShowWindow(HWND_UP_BAR, SW_SHOW);
    MApp_ZUI_API_ShowWindow(HWND_BJ, SW_HIDE); ///modified on 20171013 by mig 
    MApp_ZUI_API_ShowWindow(HWND_DOWN_BAR, SW_SHOW);
    MApp_ZUI_API_ShowWindow(HWND_DMP_SEL_BAR_GROUP, SW_SHOW);
    MApp_ZUI_API_ShowWindow(HWND_DMP_DRIVE_PAGE, SW_SHOW);

    for( i = DMP_DRIVE_NUM_PER_PAGE ; i > u8ShowItem ; i--)
    {
        MApp_ZUI_API_ShowWindow( _hwndListDriveItem[i-1],SW_HIDE);
    }

    MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_DRIVE_PAGE);
}

static void _MApp_ACTdmp_ShowFilePage(void)
{
    U16 u16X = 0;

    MApp_ZUI_API_ShowWindow(HWND_MAINFRAME, SW_HIDE);
    MApp_ZUI_API_ShowWindow(HWND_DMP_ROOT_TRANSPARENT_BG, SW_SHOW);
 //   MApp_ZUI_API_ShowWindow(HWND_DMP_BG_GRADIENT_BOTTOM, SW_SHOW);
    MApp_ZUI_API_ShowWindow(HWND_DMP_FILE_SELECT_PAGE, SW_SHOW);
    MApp_ZUI_API_ShowWindow(HWND_DMP_FILE_PAGE_PREVIEW_GROUP, SW_HIDE);
    MApp_ZUI_API_ShowWindow(HWND_DMP_FILE_PAGE_PREVIEW_INFO_GROUP, SW_HIDE);
    MApp_ZUI_API_ShowWindow(HWND_DMP_FILE_PAGE_PREVIEW_TEXT, SW_HIDE);
    MApp_ZUI_API_ShowWindow(HWND_DMP_FILE_PAGE_SUBMENU_GROUP, SW_HIDE);
  #ifdef ENABLE_SMC_UI_NEW     /* smc.qxr 20121016 */
    MApp_ZUI_API_ShowWindow(HWND_DMP_FILE_PAGE_SCROLL_BAR, SW_SHOW);
    _MApp_ACTdmp_ShowScrollBar();
  #endif
    printf("===>>>1 DMP_NUM_OF_FILES_PER_PAGE:%d\n",DMP_NUM_OF_FILES_PER_PAGE);

#ifdef ENABLE_SMC_UI_NEW     /* smc.qxr 20121029 */
#if (BOE_PHOTO_DISPLAY)//minglin0105//minglin0105
      if(MApp_MPlayer_QueryCurrentMediaType()==E_MPLAYER_TYPE_PHOTO)
#endif	  	
    {
      _hwndListFileItem       = _hwndListFileItemPhoto;
      _hwndListFileIcon       = _hwndListFileIconPhoto;
      _hwndListFileString     = _hwndListFileStringPhoto;
      _hwndListFileCheckMark  = _hwndListFileCheckMarkPhoto;
      MApp_ZUI_API_ShowWindow(HWND_DMP_FILE_PAGE_THUMB_GROUP, SW_HIDE);
    }
 
  #if (BOE_PHOTO_DISPLAY)//minglin0105//minglin0105
     else
    {
      _hwndListFileItem       = _hwndListFileItemFile;
      _hwndListFileIcon       = _hwndListFileIconFile;
      _hwndListFileString     = _hwndListFileStringFile;
      _hwndListFileCheckMark  = _hwndListFileCheckMarkFile;

      MApp_ZUI_API_ShowWindow(HWND_DMP_PHOTO_PAGE_THUMB_GROUP, SW_HIDE);
    }
	#endif
#endif

    for(u16X = 0; u16X < DMP_NUM_OF_FILES_PER_PAGE; u16X++)
    {
        MApp_ZUI_API_EnableWindow(_hwndListFileItem[u16X], ENABLE);
    }

    MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_FILE_SELECT_PAGE);
}

static void _MApp_ACTdmp_ShowPreviewWin(void)
{
    //File type
    switch(MApp_MPlayer_QueryCurrentMediaType() )
    {
        case E_MPLAYER_TYPE_MOVIE: // preview movie only
        // TODO: refine flag
            if(MApp_DMP_GetDmpFlag() & DMP_FLAG_THUMBNAIL_PLAYING)
            {
            }
            else
            {
                #if DMP_MOVIE_PREVIEW
                MApp_MPlayer_BeginPreview();
                #endif
            }
        // move below code to E_MPLAYER_NOTIFY_BEFORE_MOVIE_PREVIEW for movie only
        //MApp_ZUI_API_ShowWindow(HWND_DMP_FILE_PAGE_PREVIEW_GROUP, SW_SHOW);
            break;

        case E_MPLAYER_TYPE_PHOTO:
            if(MApp_DMP_GetDmpFlag() & DMP_FLAG_THUMBNAIL_PLAYING)
            {
            }
            else
            {
                MApp_MPlayer_BeginPreview();
            }
            //MApp_ZUI_API_ShowWindow(HWND_DMP_FILE_PAGE_PREVIEW_GROUP, SW_SHOW);
            //#endif
            break;

        case E_MPLAYER_TYPE_MUSIC:
            #if DMP_MUSIC_PREVIEW
            if(MApp_DMP_GetDmpFlag() & DMP_FLAG_BGM_MODE)
            {
                DMP_DBG(printf("BGM no preview music\n"));
            }
            else
            {
                DMP_DBG(printf("BGM preview music!\n"));
            #if ENABLE_EMBEDDED_PHOTO_DISPLAY
                if(MApp_DMP_GetDmpFlag() & DMP_FLAG_THUMBNAIL_PLAYING)
                {
                }
                else
            #endif
                {
                    MApp_MPlayer_BeginPreview();
                }
            }
            //MApp_ZUI_API_ShowWindow(HWND_DMP_FILE_PAGE_PREVIEW_GROUP, SW_SHOW);
            #endif
            break;

        case E_MPLAYER_TYPE_TEXT:
            MApp_MPlayer_BeginPreview();
            break;

        default:  // plugin
            break;
    }
}

static void _MApp_ACTdmp_HidePreviewWin(void)
{
    //File type
    MApp_MPlayer_StopPreview();
    MApp_ZUI_API_ShowWindow(HWND_DMP_FILE_PAGE_PREVIEW_GROUP, SW_HIDE);
    MApp_ZUI_API_ShowWindow(HWND_DMP_FILE_PAGE_PREVIEW_INFO_GROUP, SW_HIDE);
    MApp_ZUI_API_ShowWindow(HWND_DMP_FILE_PAGE_PREVIEW_TEXT, SW_HIDE);
    MApp_ZUI_API_KillTimer(HWND_DMP_FILE_PAGE_PREVIEW_INFO_GROUP, DMP_TIMER_PREVIEW_WIN);
    _MApp_ZUI_ACT_DMPMarqueeTextEnableAnimation(HWND_DMP_FILE_PAGE_PREVIEW_FILENAME_STRING, FALSE);
}

static void _MApp_ACTdmp_ShowAlertWin(EN_DMP_MSG_TYPE enMsgType)
{
    _enDmpMsgType = enMsgType;

    MApp_ZUI_API_StoreFocusCheckpoint();

    if( MApp_DMP_GetDmpUiState() == DMP_UI_STATE_MEDIA_SELECT)
    {
        // for thumbnail is showing, we remove the usb disk, do not show the
        // alert window

    }
    else
    {
        MApp_ZUI_API_ShowWindow(HWND_DMP_ALERT_WINDOW, SW_SHOW);
        MApp_ZUI_API_SetFocus(HWND_DMP_ALERT_WINDOW);
    }
}

static void _MApp_ACTdmp_HideAlertWin(void)
{
    MApp_ZUI_API_ShowWindow(HWND_DMP_ALERT_WINDOW, SW_HIDE);

    //printf("[Alert] focus check point : %d\n", MApp_ZUI_API_GetFocusCheckpoint());

    MApp_ZUI_API_SetFocus(MApp_ZUI_API_GetFocusCheckpoint());

    _enDmpMsgType = DMP_MSG_TYPE_MAX;
}

static void _MApp_ACTdmp_ShowProgressWin(void)
{
    MApp_ZUI_API_SetTimer(HWND_DMP_PROGRESS_WINDOW, DMP_TIMER_PROGRESS_WIN, DMP_TIME_MS_PROGRESS_WIN);
    MApp_ZUI_API_ShowWindow(HWND_DMP_PROGRESS_WINDOW, SW_SHOW);
    MApp_ZUI_API_SetFocus(HWND_DMP_PROGRESS_WINDOW);
    MApp_ZUI_CTL_PercentProgressBar_SetPercentage(0);
}

static void _MApp_ACTdmp_HideProgressWin(void)
{
    MApp_ZUI_API_KillTimer(HWND_DMP_PROGRESS_WINDOW, DMP_TIMER_PROGRESS_WIN);
    MApp_ZUI_API_ShowWindow(HWND_DMP_PROGRESS_WINDOW, SW_HIDE);

    if(MApp_DMP_GetDmpUiState() == DMP_UI_STATE_FILE_SELECT)
    {
        MApp_ZUI_API_SetFocus(HWND_DMP_FILE_PAGE_SUBMENU_PASTE);
    }
}

static void _MApp_ACTdmp_ShowSubMenu(void)
{
    MPlayerFileInfo fileInfo;
    U16 u16Idx = MApp_MPlayer_QueryCurrentFileIndex(E_MPLAYER_INDEX_CURRENT_PAGE);

    //Set current thumb item to DISABLE attribute for displaying 'fake focus' on it
    MApp_ZUI_API_EnableWindow(MApp_ZUI_API_GetFocus(), DISABLE);
    MApp_ZUI_API_StoreFocusCheckpoint();
    MApp_ZUI_API_ShowWindow(HWND_DMP_FILE_PAGE_SUBMENU_GROUP, SW_SHOW);

    if((MApp_MPlayer_QueryFileInfo(E_MPLAYER_INDEX_CURRENT_PAGE, u16Idx, &fileInfo) == E_MPLAYER_RET_OK))
    {
        if(fileInfo.eAttribute & E_MPLAYER_FILE_DIRECTORY)
        {
            #if (ENABLE_COPY_PASTE == DISABLE)
            MApp_ZUI_API_ShowWindow(HWND_DMP_FILE_PAGE_SUBMENU_COPY, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_DMP_FILE_PAGE_SUBMENU_PASTE, SW_HIDE);
            MApp_ZUI_API_SetFocus(HWND_DMP_FILE_PAGE_SUBMENU_GROUP);
            #else
            MApp_ZUI_API_EnableWindow(HWND_DMP_FILE_PAGE_SUBMENU_DELETE, DISABLE);
            MApp_ZUI_API_EnableWindow(HWND_DMP_FILE_PAGE_SUBMENU_COPY, DISABLE);
            if(MApp_MPlayer_IsCopyFileExist())
            {
                //Focus on DIR, only paste file can be done
                MApp_ZUI_API_EnableWindow(HWND_DMP_FILE_PAGE_SUBMENU_PASTE, ENABLE);
                MApp_ZUI_API_SetFocus(HWND_DMP_FILE_PAGE_SUBMENU_PASTE);
            }
            else
            {
                //Nothing can be done: press OK or EXIT to close submenu
                MApp_ZUI_API_EnableWindow(HWND_DMP_FILE_PAGE_SUBMENU_PASTE, DISABLE);
                MApp_ZUI_API_SetFocus(HWND_DMP_FILE_PAGE_SUBMENU_GROUP);
            }
	    #endif
        }
        else
        {
            MApp_ZUI_API_EnableWindow(HWND_DMP_FILE_PAGE_SUBMENU_DELETE, ENABLE);
            #if (ENABLE_COPY_PASTE == DISABLE)
            MApp_ZUI_API_ShowWindow(HWND_DMP_FILE_PAGE_SUBMENU_COPY, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_DMP_FILE_PAGE_SUBMENU_PASTE, SW_HIDE);
            #else
            MApp_ZUI_API_EnableWindow(HWND_DMP_FILE_PAGE_SUBMENU_COPY, DISABLE);
            if(MApp_MPlayer_IsCopyFileExist())
            {
                MApp_ZUI_API_EnableWindow(HWND_DMP_FILE_PAGE_SUBMENU_PASTE, ENABLE);
            }
            else
            {
                MApp_ZUI_API_EnableWindow(HWND_DMP_FILE_PAGE_SUBMENU_PASTE, DISABLE);
            }
	     #endif
            MApp_ZUI_API_SetFocus(HWND_DMP_FILE_PAGE_SUBMENU_DELETE);
        }
    }
}
static void _MApp_ACTdmp_HideSubMenu(void)
{
    MPlayerFileInfo fileInfo;
    U16 u16Idx = MApp_MPlayer_QueryCurrentFileIndex(E_MPLAYER_INDEX_CURRENT_PAGE);
    U16 u16X = 0;

    //Clear 'fake focus' status firstly
    for(u16X = 0; u16X < DMP_NUM_OF_FILES_PER_PAGE; u16X++)
    {
        MApp_ZUI_API_EnableWindow(_hwndListFileItem[u16X], ENABLE);
    }

    MApp_ZUI_API_ShowWindow(HWND_DMP_FILE_PAGE_SUBMENU_GROUP, SW_HIDE);
    MApp_ZUI_API_SetFocus(_hwndListFileItem[u16Idx]);

    //printf("    >> set focus to %d (hwnd=%d)\n", u16Idx, _hwndListFileItem[u16Idx]);

    if((MApp_MPlayer_QueryFileInfo(E_MPLAYER_INDEX_CURRENT_PAGE, u16Idx, &fileInfo) == E_MPLAYER_RET_OK))
    {
        if(!(fileInfo.eAttribute & E_MPLAYER_FILE_DIRECTORY))
        {
            //File type
            _MApp_ACTdmp_ShowPreviewWin();
        }
    }
}
/////////////////////////////////////////////////////////////////////
static void _MApp_ACTdmp_TextToFilePage(void)
{
      U16 u16PlayingIdx = 0;

     MApp_MPlayer_Stop();
     MApp_MPlayer_StopMusic();
     MApp_DMP_ClearDmpFlag(DMP_FLAG_MEDIA_FILE_PLAYING_ERROR);
     MApp_DMP_ClearDmpFlag(DMP_FLAG_MEDIA_FILE_PLAYING);
     if (!MApp_MPlayer_Change2TargetPath(MApp_MPlayer_QueryCurrentPlayingList()))
     {
         DMP_DBG(printf("--MApp_MPlayer_Change2TargetPath fail--\n");)
     }
      u16PlayingIdx = MApp_MPlayer_QueryCurrentPlayingFileIndex();
      MApp_MPlayer_SetCurrentPageIndex(u16PlayingIdx / NUM_OF_PHOTO_FILES_PER_PAGE);
      DMP_DBG(printf("\n-- Current playing idx : %d\n", u16PlayingIdx););
      if (MApp_MPlayer_SetCurrentFile(E_MPLAYER_INDEX_CURRENT_DIRECTORY, u16PlayingIdx) != E_MPLAYER_RET_OK)
      {
           DMP_DBG(printf("--MApp_MPlayer_SetCurrentFile fail--\n"););
           MApp_MPlayer_SetCurrentFile(E_MPLAYER_INDEX_CURRENT_DIRECTORY, 0);
           MApp_MPlayer_SetCurrentPageIndex(0);
      }
     #if DMP_UI_BMPSUBTITLE_EXCLUSIVE
            // enable UI
      _MApp_ZUI_ACTdmp_RestoreGWINandFB();
     #endif //DMP_UI_BMPSUBTITLE_EXCLUSIVE
      MApp_ZUI_API_EnableFullScreenRelease(FALSE);
       {
            _MApp_ACTdmp_ShowFilePage();
            #if (DMP_PHOTO_THUMBNAIL || DMP_MOVIE_THUMBNAIL)
                _ThumbNOIdx = 0xFFFF;
                _ThumbOKIdx = 0xFFFF;
                _ThumbLoadPageFlag = TRUE;
                _InsertQFlag = TRUE;
                _ThumbInsertNum = 0;
                _MApp_DMP_ThumbCopyRegion_Create();
            #endif
            MApp_ZUI_API_SetFocus(_hwndListFileItem[MApp_MPlayer_QueryCurrentFileIndex(E_MPLAYER_INDEX_CURRENT_PAGE)]);
            if( MApp_DMP_GetDmpFlag() & DMP_FLAG_MEDIA_FILE_PLAYING_ERROR)
            {
               DMP_DBG(printf("DMP_UI_STATE_FILE_SELECT playing error mode\n"););
               _MApp_ACTdmp_ShowAlertWin(_enDmpMsgType);
                    // playing error mode
            }
            else if(MApp_DMP_IsFileTypeByIdx(MApp_MPlayer_QueryCurrentFileIndex(E_MPLAYER_INDEX_CURRENT_DIRECTORY)))
           {
                    //File type
                _MApp_ACTdmp_ShowPreviewWin();
           }
       }
      MApp_DMP_SetDmpUiState(DMP_UI_STATE_FILE_SELECT);
 }

///
static U16 _MApp_DMP_QueryTotalPlayListNum(void)
{
    U16 u16PlayListNum = MApp_MPlayer_QuerySelectedFileNum(MApp_MPlayer_QueryCurrentMediaType());

    DMP_DBG(printf("_MApp_DMP_QueryTotalPlayListNum %u\n",u16PlayListNum););

    if(MApp_MPlayer_QueryPlayMode() == E_MPLAYER_PLAY_ONE_DIRECTORY
        || MApp_MPlayer_QueryPlayMode() == E_MPLAYER_PLAY_ONE_DIRECTORY_FROM_CURRENT)
    {
        u16PlayListNum = MApp_MPlayer_QueryTotalFileNum() - MApp_MPlayer_QueryDirectoryNumber();
    }

    return u16PlayListNum;
}

static void _MApp_DMP_ErrorHandling_GotoDefaultPage(enumMPlayerMediaType eMediaType)
{
    DMP_DBG(printf("[ERROR HANDLE] Back to default page\n"));

    MApp_MPlayer_Stop();
    MApp_MPlayer_StopMusic();

    msAPI_Scaler_SetBlueScreen_Origin(TRUE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
    MApi_XC_GenerateBlackVideo( ENABLE, MAIN_WINDOW );

    switch(eMediaType)
    {
        case E_MPLAYER_TYPE_MOVIE:
#if (ENABLE_SUBTITLE_DMP)
            if(MApp_MPlayer_QueryCurrentFileMediaSubType() == E_MPLAYER_SUBTYPE_MPEG4)
            {
                MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_SUBTITLE_PAGE ,SW_HIDE);
                MApp_MPlayer_DisableSubtitle();
                _stDmpPlayVar.stMovieInfo.bSubtitleOff = TRUE;
            }
#endif //#if (ENABLE_SUBTITLE_DMP)
            break;

        case E_MPLAYER_TYPE_MUSIC:
            _u32MusicCurrentTime = 0; //initial value for drawing 'MUSIC' current time
            if(MApp_MPlayer_IsCurrentLRCLyricAvailable() == E_MPLAYER_RET_OK)
            {
                MApp_MPlayer_DisableLRCLyric();
                memset((U8*)_stDmpPlayVar.stMusicInfo.MPlayerLyricBuf, 0, DMP_STRING_BUF_SIZE);
                MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_LYRIC_PAGE, SW_HIDE);
            }
            MApp_ZUI_API_KillTimer(HWND_DMP_PLAYBACK_MUSIC_EQ_GROUP, DMP_TIMER_EQ_PLAY);
            MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_MUSIC_EQ_GROUP, SW_HIDE);
            break;

        case E_MPLAYER_TYPE_PHOTO:
            _MApp_ACTdmp_ShowAlertWin(DMP_MSG_TYPE_UNSUPPORTED_FILE);
            MApp_ZUI_API_SetTimer(HWND_DMP_ALERT_WINDOW, DMP_TIMER_INVALID_WIN, DMP_TIME_MS_INVALID_WIN);
            break;

        default:
            break;
    }

    //To do: set focus item
    //_MApp_MediaPlayer_SetDefaultFocus();
    //To do: Need to reset MM State flag??
    if(MApp_DMP_GetDmpFlag()& DMP_FLAG_MEDIA_FILE_PLAYING)
    {
        MApp_DMP_ClearDmpFlag(DMP_FLAG_MEDIA_FILE_PLAYING);
    }

    //MApp_DMP_ClearDmpFlag(DMP_FLAG_MEDIA_FILE_PLAYING_ERROR);

    if (m_u16PlayErrorNum <= 1)
    {
        _enDmpMsgType = DMP_MSG_TYPE_UNSUPPORTED_FILE;
    }
    else
    {
        _enDmpMsgType = DMP_MSG_TYPE_ALL_FILES_UNSUPPORTED;
    }
    //MApp_DMP_UiStateTransition(DMP_UI_STATE_FILE_SELECT);
}

static void _MApp_DMP_ErrorHandling_GotoFileSelectPage(enumMPlayerMediaType eMediaType)
{
    DMP_DBG(printf("[ERROR HANDLE] Back to FileSelect page\n"));

    MApp_MPlayer_Stop();
    MApp_MPlayer_StopMusic();

    msAPI_Scaler_SetBlueScreen_Origin(TRUE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
    MApi_XC_GenerateBlackVideo( ENABLE, MAIN_WINDOW );

    switch(eMediaType)
    {
        case E_MPLAYER_TYPE_MOVIE:
#if (ENABLE_SUBTITLE_DMP)
            if(MApp_MPlayer_QueryCurrentFileMediaSubType() == E_MPLAYER_SUBTYPE_MPEG4)
            {
                MApp_MPlayer_DisableSubtitle();
                _stDmpPlayVar.stMovieInfo.bSubtitleOff = TRUE;
            }
#endif //#if (ENABLE_SUBTITLE_DMP)
            break;

        case E_MPLAYER_TYPE_MUSIC:
            _u32MusicCurrentTime = 0; //initial value for drawing 'MUSIC' current time
            if(MApp_MPlayer_IsCurrentLRCLyricAvailable() == E_MPLAYER_RET_OK)
            {
                MApp_MPlayer_DisableLRCLyric();
                memset((U8*)_stDmpPlayVar.stMusicInfo.MPlayerLyricBuf, 0, DMP_STRING_BUF_SIZE);
            }
            break;

        case E_MPLAYER_TYPE_PHOTO:
            break;

        default:
            break;
    }

    if(MApp_DMP_GetDmpFlag()& DMP_FLAG_MEDIA_FILE_PLAYING)
    {
        MApp_DMP_ClearDmpFlag(DMP_FLAG_MEDIA_FILE_PLAYING);
    }

}
void _MApp_ACTdmp_MovieCancelRepeatAB(void)
{
    _enRepeatABStatus = REPEATAB_MODE_NONE;
    _stDmpPlayVar.stMovieInfo.au32MovieRepeatTime[0]= 0xFFFFFFFF;
    _stDmpPlayVar.stMovieInfo.au32MovieRepeatTime[1] = 0xFFFFFFFF;

    MApp_MPlayer_MovieSetRepeatAB(E_MPLAYER_MOVIE_SET_REPEAT_AB_NONE, 0);
    MApp_DMP_ClearDmpFlag(DMP_FLAG_MOVIE_REPEATAB_MODE);

    DMP_MovieInfoBarTable[MOVIEINFO_AB_REPEAT][2] = en_str_DMP_SET_A;
}

void _MApp_ACTdmp_MovieResetRepeatAB(void)
{
    _enRepeatABStatus = REPEATAB_MODE_NONE;
    _stDmpPlayVar.stMovieInfo.au32MovieRepeatTime[0]= 0xFFFFFFFF;
    _stDmpPlayVar.stMovieInfo.au32MovieRepeatTime[1] = 0xFFFFFFFF;

    MApp_DMP_ClearDmpFlag(DMP_FLAG_MOVIE_REPEATAB_MODE);

    DMP_MovieInfoBarTable[MOVIEINFO_AB_REPEAT][2] = en_str_DMP_SET_A;
}

////
static BOOLEAN _MApp_DMP_GB2Unicode(U8 *pu8SrcString, U8 *pu8DstString, U16 u16StringMax)
{
    U16 u16SrcIdx, u16DstIdx;
    U16 pu16StrSrcTemp, pu16StrDstTemp;

    u16SrcIdx = 0;
    u16DstIdx = 0;

    while(u16SrcIdx < u16StringMax)
    {
        if(isprint(pu8SrcString[u16SrcIdx]))
        {
            pu8DstString[u16DstIdx] = pu8SrcString[u16SrcIdx];
            pu8DstString[u16DstIdx+1] = '\0';
            u16SrcIdx++;
            u16DstIdx+=2;
        }
        else if(pu8SrcString[u16SrcIdx] == '\0')
        {
            pu8DstString[u16DstIdx] = '\0';
            pu8DstString[u16DstIdx+1] = '\0';
            u16SrcIdx++;
            u16DstIdx+=2;
            break;
        }
        else if(MApp_GetMenuLanguage() == LANGUAGE_RUSSIAN)
        {
            pu16StrDstTemp = MApp_CharTable_MappingCharToUCS2(WINDOWS_CP1251, pu8SrcString[u16SrcIdx]);
            memcpy(&pu8DstString[u16DstIdx],&pu16StrDstTemp,2);
            u16SrcIdx++;
            u16DstIdx+=2;
        }
        else
        {
            memcpy(&pu16StrSrcTemp,&pu8SrcString[u16SrcIdx],2);
            pu16StrSrcTemp=Swap16(pu16StrSrcTemp);
            pu16StrDstTemp = MApp_Transfer2Unicode(pu16StrSrcTemp);
            memcpy(&pu8DstString[u16DstIdx],&pu16StrDstTemp,2);
            u16SrcIdx+=2;
            u16DstIdx+=2;
        }
    }

    return TRUE;
}



///////////////
//this function will reset the focus, hence some notify need to restore the
// focus while calling...
///////////////
static U8 u8CurrentPlaylistPageIdx; // zero base
static U8 u8CurrentPlaylistTotalPage; // non-zero base

static void _MApp_ACTdmp_Playback_ShowPlaylistWin(enumMPlayerMediaType eMediaType, bool bSetFoucsOnCurrentPlayingIdx)
{
    #define PLAYLIST_ARROW_UP_CURRENT_WIDTH 21
    #define PLAYLIST_ARROW_UP_CURRENT_HEIGHT 21
    #define PLAYLIST_ARROW_UP_CURRENT_LOFFSET 5
    #define PLAYLIST_ARROW_UP_CURRENT_TOFFSET 5

    U32 i;
    U16 u16CurrentPlayingIdx = 0;
    U16 u16SelectedFileNum; // non-zero base

    MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_PLAYLIST_GROUP,SW_SHOW);

    for(i = 0; i < UI_DMP_PLAYLIST_NUMBER; i++)
    {
        MApp_ZUI_API_ShowWindow(_hwndListPlaylistItem[i],SW_HIDE);
    }

    //calculate how many selected files in playlist
    u16SelectedFileNum = MApp_MPlayer_QueryPlayListFileNum(eMediaType);

    DMP_DBG(printf(" u16SelectedFileNum %u\n",u16SelectedFileNum););

    if(u16SelectedFileNum == 0) // these is no selected files
    {
        U16 u16CurrentDirFileNum;
        U16 u16CurrentDirMediaFileNum;

        u16CurrentDirFileNum = MApp_MPlayer_QueryTotalFileNum();

        DMP_DBG(printf("u16currentDirFileNum %u==========\n",u16CurrentDirFileNum););

        u16CurrentDirMediaFileNum = u16CurrentDirFileNum - MApp_MPlayer_QueryDirectoryNumber();

        if(u16CurrentDirMediaFileNum == 0)
        {
            MApp_ZUI_API_SetFocus(HWND_DMP_PLAYBACK_PLAYLIST_BUTTON_CANCEL);
            u8CurrentPlaylistTotalPage = 1;
        }
        else
        {
            u8CurrentPlaylistTotalPage = (u16CurrentDirMediaFileNum + UI_DMP_PLAYLIST_NUMBER - 1) / UI_DMP_PLAYLIST_NUMBER;
            if (bSetFoucsOnCurrentPlayingIdx)
            {
                u16CurrentPlayingIdx = MApp_MPlayer_QueryCurrentPlayingFileIndex();
                u16CurrentPlayingIdx = u16CurrentPlayingIdx - MApp_MPlayer_QueryDirectoryNumber();
                u8CurrentPlaylistPageIdx = u16CurrentPlayingIdx/UI_DMP_PLAYLIST_NUMBER;
            }
            if(u8CurrentPlaylistPageIdx+1 == u8CurrentPlaylistTotalPage) //last page
            {
                U16 u16CurrentPageMediaFileNum; //non-zero base
                u16CurrentPageMediaFileNum = u16CurrentDirMediaFileNum % UI_DMP_PLAYLIST_NUMBER;
                if (u16CurrentPageMediaFileNum == 0)
                {
                    u16CurrentPageMediaFileNum = UI_DMP_PLAYLIST_NUMBER;
                }
                DMP_DBG(printf("!!!!!u16CurrentPageFileNum %u\n",u16CurrentPageMediaFileNum););

                for(i = 0;i < u16CurrentPageMediaFileNum; i++)
                {
                    MApp_ZUI_API_ShowWindow(_hwndListPlaylistItem[i],SW_SHOW);
                }

                MApp_ZUI_API_SetFocus(_hwndListPlaylistItem[u16CurrentPlayingIdx%UI_DMP_PLAYLIST_NUMBER]);
            }
            else
            {
                // show all items
                MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_PLAYLIST_GROUP,SW_SHOW);
                MApp_ZUI_API_SetFocus(_hwndListPlaylistItem[u16CurrentPlayingIdx%UI_DMP_PLAYLIST_NUMBER]);
            }
        }
        //buttonclick or show arrow
        {
            //u16CurrentPlayingIdx = MApp_MPlayer_QueryCurrentPlayingFileIndex();
            u16CurrentPlayingIdx = MApp_MPlayer_QueryCurrentPlayingFileIndex() - MApp_MPlayer_QueryDirectoryNumber();
            U8 u8CurrentPlayingPageIdx = u16CurrentPlayingIdx/UI_DMP_PLAYLIST_NUMBER;
            if (u8CurrentPlayingPageIdx == u8CurrentPlaylistPageIdx)
            {
                // this playlist page has current playing file
                //MApp_ZUI_API_SetTimer(_hwndListPlaylistItem[u16CurrentPlayingIdx%UI_DMP_PLAYLIST_NUMBER], 0, DMP_TIMER_BUTTONCLICK);
                U16  height = 67;//91;
                i = u16CurrentPlayingIdx % UI_DMP_PLAYLIST_NUMBER;
                //height += i * 42;
                height += i * 29;
                RECT rc;
                //RECT_SET(rc, 850,height,PLAYLIST_ARROW_UP_CURRENT_WIDTH,PLAYLIST_ARROW_UP_CURRENT_HEIGHT);// 35,35);
                RECT_SET(rc, 596,height,PLAYLIST_ARROW_UP_CURRENT_WIDTH,PLAYLIST_ARROW_UP_CURRENT_HEIGHT);// 35,35);
                MApp_ZUI_API_MoveWindow(HWND_DMP_PLAYBACK_PLAYLIST_ARROW_UP_CURRENT, &rc );
                MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_PLAYLIST_ARROW_UP_CURRENT, SW_SHOW);
            }
            else
            {
                MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_PLAYLIST_ARROW_UP_CURRENT, SW_HIDE);
            }
        }
    }
    else  // there are some selected files, using playlist
    {
        u8CurrentPlaylistTotalPage = (u16SelectedFileNum + UI_DMP_PLAYLIST_NUMBER - 1) / UI_DMP_PLAYLIST_NUMBER;
        if (bSetFoucsOnCurrentPlayingIdx)
        {
            u16CurrentPlayingIdx = MApp_MPlayer_QueryCurrentPlayingList();
            u8CurrentPlaylistPageIdx = u16CurrentPlayingIdx/UI_DMP_PLAYLIST_NUMBER;
        }
        if(u8CurrentPlaylistPageIdx+1 == u8CurrentPlaylistTotalPage) //last page
        {
            U16 u16CurrentPageFileNum; //non-zero base
            u16CurrentPageFileNum = u16SelectedFileNum % UI_DMP_PLAYLIST_NUMBER;
            if (u16CurrentPageFileNum == 0)
            {
                u16CurrentPageFileNum = UI_DMP_PLAYLIST_NUMBER;
            }
            DMP_DBG(printf("u16CurrentPageFileNum %u\n",u16CurrentPageFileNum););

            for(i = 0;i < u16CurrentPageFileNum; i++)
            {
                MApp_ZUI_API_ShowWindow(_hwndListPlaylistItem[i],SW_SHOW);
            }

            MApp_ZUI_API_SetFocus(_hwndListPlaylistItem[u16CurrentPlayingIdx%UI_DMP_PLAYLIST_NUMBER]);
        }
        else
        {
            // show all items
            MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_PLAYLIST_GROUP,SW_SHOW);
            MApp_ZUI_API_SetFocus(_hwndListPlaylistItem[u16CurrentPlayingIdx%UI_DMP_PLAYLIST_NUMBER]);
        }
        {
            u16CurrentPlayingIdx = MApp_MPlayer_QueryCurrentPlayingList();
            U8 u8CurrentPlayingPageIdx = u16CurrentPlayingIdx/UI_DMP_PLAYLIST_NUMBER;
            if (u8CurrentPlayingPageIdx == u8CurrentPlaylistPageIdx)
            {
                // this playlist page has current playing file
                //MApp_ZUI_API_SetTimer(_hwndListPlaylistItem[u16CurrentPlayingIdx%UI_DMP_PLAYLIST_NUMBER], 0, DMP_TIMER_BUTTONCLICK);
                U16  top =
                _GUI_WindowPositionList_Zui_Dmp[HWND_DMP_PLAYBACK_PLAYLIST_ITEM1].rect.top;
                i = u16CurrentPlayingIdx%UI_DMP_PLAYLIST_NUMBER;
                top += i *
                (_GUI_WindowPositionList_Zui_Dmp[HWND_DMP_PLAYBACK_PLAYLIST_ITEM2].rect.top
                - _GUI_WindowPositionList_Zui_Dmp[HWND_DMP_PLAYBACK_PLAYLIST_ITEM1].rect.top);
                top += PLAYLIST_ARROW_UP_CURRENT_TOFFSET;

                RECT rc;
                RECT_SET(rc,
                _GUI_WindowPositionList_Zui_Dmp[HWND_DMP_PLAYBACK_PLAYLIST_ITEM1].rect.left + PLAYLIST_ARROW_UP_CURRENT_LOFFSET,
                top,PLAYLIST_ARROW_UP_CURRENT_WIDTH,PLAYLIST_ARROW_UP_CURRENT_HEIGHT);// 35,35);
                MApp_ZUI_API_MoveWindow(HWND_DMP_PLAYBACK_PLAYLIST_ARROW_UP_CURRENT, &rc );
                MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_PLAYLIST_ARROW_UP_CURRENT, SW_SHOW);
            }
            else
            {
                MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_PLAYLIST_ARROW_UP_CURRENT, SW_HIDE);
            }
        }
    }

    MApp_ZUI_API_InvalidateWindow(HWND_DMP_PLAYBACK_PLAYLIST_GROUP);
}

static void _MApp_ACTdmp_Playback_ShowInfoWin(enumMPlayerMediaType eMediaType)
{
    DMP_DBG(printf("_MApp_ACTdmp_Playback_ShowInfoWin: %u\n",eMediaType););

    MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_INFO_PANE, SW_SHOW);
    if(MApp_ZUI_API_IsWindowVisible(HWND_DMP_BAR))
        MApp_ZUI_API_ShowWindow(HWND_DMP_BAR, SW_HIDE);

    switch(eMediaType)
    {
        case E_MPLAYER_TYPE_MOVIE:
        {
            U32 currentTime;
            U8 u8Min, u8Sec;
            S8 s8Hour = 0;
            RECT rect;

            if(_enNotify == E_MPLAYER_NOTIFY_END_OF_PLAY_ONE_FILE
                || _enNotify == E_MPLAYER_NOTIFY_END_OF_PLAY_ALL_FILE
              #ifdef MEDIA_PLAYER_HIGHLIGHT_CHANGE
                || _enNotify == E_MPLAYER_NOTIFY_PLAY_NEXT_FILE
              #endif
                )
            {
                if ((_enPlayMode_AtNotify >= E_MPLAYER_MOVIE_FB_2X) &&
                    (_enPlayMode_AtNotify <= E_MPLAYER_MOVIE_FB_32X))
                {
                    // If FB to beginning of file, still show current time, it should be 0.
                    currentTime = MApp_VDPlayer_GetInfo(E_VDPLAYER_INFO_CUR_TIME)/1000;
                }
                else
                {
                    currentTime = MApp_VDPlayer_GetInfo(E_VDPLAYER_INFO_TOTAL_TIME)/1000;
                }

            }
            else
            {
                currentTime = MApp_VDPlayer_GetInfo(E_VDPLAYER_INFO_CUR_TIME)/1000;
            }

            currentTime = currentTime>0 ? currentTime:0;
            s8Hour = (currentTime/3600);
            u8Min = (U8)(currentTime/60-s8Hour*60);
            u8Sec = (U8)(currentTime-s8Hour*3600-u8Min*60);
            _u16MovieCurrentTime = ((s8Hour*60)+u8Min)*60+u8Sec;
            if(_u16MovieTotalTime != 0xFFFF && _u16MovieTotalTime != 0)
            {
                U32 u32Percent = _u16MovieCurrentTime*100 /_u16MovieTotalTime;

                if(u32Percent>100)
                    u32Percent=100;

                MApp_ZUI_CTL_PercentProgressBar_SetPercentage(u32Percent);
            }
            else if(_u16MovieTotalTime == 0)
            {
                MApp_ZUI_CTL_PercentProgressBar_SetPercentage(0);
            }
            else
            {
                MApp_ZUI_CTL_PercentProgressBar_SetPercentage(0);
                DMP_DBG(printf("[Error] Get total time failed! (0x%lx)\n", _u16MovieTotalTime););
            }

            MApp_ZUI_API_InvalidateWindow(HWND_DMP_PLAYBACK_PAGE_TIME_GROUP);

            if(MApp_ZUI_API_IsWindowVisible(HWND_DMP_PLAYBACK_MOVIEINFO_INFO_GROUP))
            {
                MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_MOVIEINFO_INFO_GROUP,SW_SHOW);
                // marquee
                _MApp_ZUI_ACT_DMPMarqueeTextEnableAnimation(HWND_DMP_PLAYBACK_MOVIEINFO_INFO_FILENAME_TEXT, TRUE);
                //
            }
            else if (MApp_ZUI_API_IsWindowVisible(HWND_DMP_PLAYBACK_MOVIEINFO_GOTOTIME_GROUP))
            {
                MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_MOVIEINFO_GOTOTIME_GROUP, SW_HIDE);
                MApp_ZUI_API_SetFocus(_hwndListInfoBar[MOVIEINFO_GOTO_TIME%DMP_INFOBAR_ICON_NUM]);
                MApp_ZUI_API_StoreFocusCheckpoint();
            }
            else if (MApp_ZUI_API_IsWindowVisible(HWND_DMP_PLAYBACK_MOVEVIEW_GROUP))
            {
                MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_MOVEVIEW_GROUP, SW_HIDE);
                MApp_ZUI_API_SetFocus(_hwndListInfoBar[MOVIEINFO_MOVEVIEW%DMP_INFOBAR_ICON_NUM]);
                MApp_ZUI_API_StoreFocusCheckpoint();
            }
        #if (ENABLE_MPLAYER_CAPTURE_MOVIE == 1)
            else if (MApp_ZUI_API_IsWindowVisible(HWND_DMP_PLAYBACK_CONFIRM_DIALOG))
            {
                MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_CONFIRM_DIALOG, SW_HIDE);
                MApp_ZUI_API_SetFocus(_hwndListInfoBar[MOVIEINFO_CAPTURE%DMP_INFOBAR_ICON_NUM]);
                MApp_ZUI_API_StoreFocusCheckpoint();
            }
        #endif
        #if (ENABLE_DIVX_PLUS != 1)
            else if (MApp_ZUI_API_IsWindowVisible(HWND_DMP_PLAYBACK_MOVIEINFO_DIVX_GROUP))
            {
                MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_MOVIEINFO_DIVX_GROUP, SW_HIDE);
            }
        #endif

            MApp_ZUI_API_GetWindowRect(HWND_DMP_PLAYBACK_SUBTITLE_TEXT,&rect);
            rect.top=10;
            MApp_ZUI_API_MoveWindow(HWND_DMP_PLAYBACK_SUBTITLE_PAGE,&rect);
            MApp_ZUI_API_MoveWindow(HWND_DMP_PLAYBACK_SUBTITLE_TEXT,&rect);
        }
            break;


        case E_MPLAYER_TYPE_MUSIC:
        {
            U32 u32CurTime = _u32MusicCurrentTime;
            U32 u32TotalTime = MApp_MPlayer_QueryMusicFilePlayTime();
            _u32MusicCurrentTime = MApp_MPlayer_QueryMusicFileCurrentTime();

            if(u32TotalTime == 0)
            {
                DMP_DBG(printf("u32TotalTime == 0\n"););
                //u32TotalTime = 1;
                MApp_ZUI_CTL_PercentProgressBar_SetPercentage(0);
            }
            else if(u32TotalTime != 0xFFFFFFFF && u32TotalTime != 0)
            {
                U32 u32Percent = u32CurTime*100 / (u32TotalTime);
                if(u32Percent>100)
                    u32Percent=100;
                MApp_ZUI_CTL_PercentProgressBar_SetPercentage(u32Percent);
            }
            else
            {
                DMP_DBG(printf("[Error] Get music total time failed! (0x%lx)\n", u32TotalTime););
            }

            if(MApp_ZUI_API_IsWindowVisible(HWND_DMP_PLAYBACK_MUSICINFO_INFO_GROUP))
            {
                MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_MUSICINFO_INFO_GROUP,SW_SHOW);
                // marquee
                _MApp_ZUI_ACT_DMPMarqueeTextEnableAnimation(HWND_DMP_PLAYBACK_MUSICINFO_INFO_FILENAME_TEXT, TRUE);
                //
            }
        #if (ENABLE_MPLAYER_CAPTURE_MUSIC== 1)
            else if (MApp_ZUI_API_IsWindowVisible(HWND_DMP_PLAYBACK_CONFIRM_DIALOG))
            {
                MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_CONFIRM_DIALOG, SW_HIDE);
                MApp_ZUI_API_SetFocus(_hwndListInfoBar[MUSICINFO_CAPTURE%DMP_INFOBAR_ICON_NUM]);
                MApp_ZUI_API_StoreFocusCheckpoint();
            }
        #endif
            else if (MApp_ZUI_API_IsWindowVisible(HWND_DMP_PLAYBACK_MOVIEINFO_GOTOTIME_GROUP))
            {
                MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_MOVIEINFO_GOTOTIME_GROUP, SW_HIDE);
                MApp_ZUI_API_SetFocus(_hwndListInfoBar[MUSICINFO_GOTO_TIME%DMP_INFOBAR_ICON_NUM]);
                MApp_ZUI_API_StoreFocusCheckpoint();
            }
        }
            break;


        case E_MPLAYER_TYPE_PHOTO:
            MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_PAGE_TIME_GROUP,SW_HIDE);
            if(MApp_ZUI_API_IsWindowVisible(HWND_DMP_PLAYBACK_PHOTOINFO_INFO_GROUP))
            {
                MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_PHOTOINFO_INFO_GROUP,SW_SHOW);
                // marquee
                _MApp_ZUI_ACT_DMPMarqueeTextEnableAnimation(HWND_DMP_PLAYBACK_PHOTOINFO_INFO_FILENAME_TEXT, TRUE);
                //
            }
            else if (MApp_ZUI_API_IsWindowVisible(HWND_DMP_PLAYBACK_MOVEVIEW_GROUP))
            {
                MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_MOVEVIEW_GROUP, SW_HIDE);
                MApp_ZUI_API_SetFocus(_hwndListInfoBar[PHOTOINFO_MOVEVIEW%DMP_INFOBAR_ICON_NUM]);
                MApp_ZUI_API_StoreFocusCheckpoint();
            }
            #if (ENABLE_MPLAYER_CAPTURE_LOGO== 1)
            else if (MApp_ZUI_API_IsWindowVisible(HWND_DMP_PLAYBACK_CONFIRM_DIALOG))
            {
                MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_CONFIRM_DIALOG, SW_HIDE);
                MApp_ZUI_API_SetFocus(_hwndListInfoBar[PHOTOINFO_CAPTURE%DMP_INFOBAR_ICON_NUM]);
                MApp_ZUI_API_StoreFocusCheckpoint();
            }
            #endif
            break;
        case E_MPLAYER_TYPE_TEXT:
            MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_PAGE_TIME_GROUP,SW_HIDE);
            if(MApp_ZUI_API_IsWindowVisible(HWND_DMP_PLAYBACK_TEXTINFO_INFO_GROUP))
            {
                MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_TEXTINFO_INFO_GROUP,SW_SHOW);
                _MApp_ZUI_ACT_DMPMarqueeTextEnableAnimation(
                HWND_DMP_PLAYBACK_TEXTINFO_INFO_FILENAME_TEXT, TRUE);
            }
            break;
        default:
            break;
    }
    if(MApp_ZUI_API_IsWindowVisible(HWND_DMP_PLAYBACK_PLAYLIST_GROUP))
    {
        _MApp_ACTdmp_Playback_ShowPlaylistWin(eMediaType, FALSE);
    }

    // TODO: Judge which to focus
    HWND hWnd = MApp_ZUI_API_GetFocusCheckpoint();
    if (MApp_ZUI_API_IsWindowVisible(hWnd))
    {
        if (MApp_ZUI_API_IsSuccessor(HWND_DMP_PLAYBACK_PLAYLIST_GROUP, hWnd) ||
            MApp_ZUI_API_IsSuccessor(HWND_DMP_PLAYBACK_MOVIEINFO_INFO_GROUP, hWnd) ||
            MApp_ZUI_API_IsSuccessor(HWND_DMP_PLAYBACK_MUSICINFO_INFO_GROUP, hWnd) ||
            MApp_ZUI_API_IsSuccessor(HWND_DMP_PLAYBACK_PHOTOINFO_INFO_GROUP, hWnd) ||
            MApp_ZUI_API_IsSuccessor(HWND_DMP_PLAYBACK_TEXTINFO_INFO_GROUP, hWnd) ||
#if (ENABLE_DIVX_PLUS == 1)
            MApp_ZUI_API_IsSuccessor(HWND_DMP_PLAYBACK_MOVIEINFO_DIVX_GROUP,hWnd) ||
#endif
            MApp_ZUI_API_IsSuccessor(HWND_DMP_PLAYBACK_INFO_PANE, hWnd) )
        {
            MApp_ZUI_API_RestoreFocusCheckpoint();
        }
        else
        {
            MApp_ZUI_API_SetFocus(_hwndListInfoBar[_u8InfoBarIdx%DMP_INFOBAR_ICON_NUM]);
        }
    }
    else
    {
        MApp_ZUI_API_SetFocus(_hwndListInfoBar[_u8InfoBarIdx%DMP_INFOBAR_ICON_NUM]);
    }
    MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_INFO_PANE);
}

static void _MApp_ACTdmp_Playback_HideInfoWin(void)
{
    DMP_DBG(printf("_MApp_ACTdmp_Playback_HideInfoWin \n"););
	
	//<<--A-- SMC 20101209
	if(MApp_ZUI_API_IsWindowVisible(HWND_DMP_PLAYBACK_PLAYLIST_GROUP))
	{
		MApp_ZUI_ACT_ExecuteDmpAction(EN_EXE_DMP_PLAYBACK_PLAYLIST_CANCEL);
	}	
	if(MApp_ZUI_API_IsWindowVisible(HWND_DMP_PLAYBACK_MOVIEINFO_INFO_GROUP))
	{
		MApp_ZUI_ACT_ExecuteDmpAction(EN_EXE_DMP_PLAYBACK_MOVIEINFO_INFOCLOSE);
	}
	if(MApp_ZUI_API_IsWindowVisible(HWND_DMP_PLAYBACK_PHOTOINFO_INFO_GROUP))
	{
		MApp_ZUI_ACT_ExecuteDmpAction(EN_EXE_DMP_PLAYBACK_PHOTOINFO_INFOCLOSE);
	}
	if(MApp_ZUI_API_IsWindowVisible(HWND_DMP_PLAYBACK_MUSICINFO_INFO_GROUP))
	{
		MApp_ZUI_ACT_ExecuteDmpAction(EN_EXE_DMP_PLAYBACK_MUSICINFO_INFOCLOSE);
	}
	if(MApp_ZUI_API_IsWindowVisible(HWND_DMP_PLAYBACK_TEXTINFO_INFO_GROUP))
	{
		MApp_ZUI_ACT_ExecuteDmpAction(EN_EXE_DMP_PLAYBACK_TEXTINFO_INFOCLOSE);
	}
	if(MApp_ZUI_API_IsWindowVisible(HWND_DMP_PLAYBACK_MOVIEINFO_GOTOTIME_GROUP))
	{
		
		MApp_ZUI_ACT_ExecuteDmpAction(EN_EXE_DMP_MOVIEINFO_GOTOTIME_WIN_EXIT);	
	}
	
	//<<--A-- SMC 20101209
    MApp_ZUI_API_StoreFocusCheckpoint();
    MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_INFO_PANE, SW_HIDE);
#if ENABLE_MPLAYER_MUSIC
    if(MApp_MPlayer_QueryCurrentMediaType() == E_MPLAYER_TYPE_MUSIC)
    {
        if(MApp_MPlayer_QueryMusicFilePlayTime() == MApp_MPlayer_QueryMusicFileCurrentTime())
        {
            MApp_ZUI_API_KillTimer(HWND_DMP_PLAYBACK_MUSIC_EQ_GROUP, DMP_TIMER_EQ_PLAY);
            MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_MUSIC_EQ_GROUP, SW_HIDE);
        }
    }
#endif
    if(MApp_MPlayer_QueryCurrentMediaType() != E_MPLAYER_TYPE_TEXT)
    {
    #if DMP_UI_BMPSUBTITLE_EXCLUSIVE
      if(MApp_MPlayer_QueryCurrentMediaType() == E_MPLAYER_TYPE_MOVIE)
      {
          //MApp_ZUI_API_ShowWindow(HWND_MAINFRAME,SW_HIDE);
          MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_TRANSPARENT_BG,SW_SHOW);
      }
    #endif
        MApp_ZUI_API_SetFocus(HWND_DMP_PLAYBACK_TRANSPARENT_BG);
    }
    else
    {
        //MApp_Text_CurPageReload();
        MApp_ZUI_API_SetFocus(HWND_DMP_PLAYBACK_TEXT_FULL_WINDOW);
    }
    MApp_ZUI_API_MoveWindowByOffset(HWND_DMP_PLAYBACK_SUBTITLE_PAGE,0,0,0,0);
    MApp_ZUI_API_MoveWindowByOffset(HWND_DMP_PLAYBACK_SUBTITLE_TEXT,0,0,0,0);

}

#if (ENABLE_DIVX_PLUS == 1)
static void _MApp_ACTdmp_Playback_ShowDivxWin(void)
{
    MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_MOVIEINFO_DIVX_GROUP, SW_SHOW);
    HWND hwnd;
    hwnd = MApp_ZUI_API_GetFocus();
    switch(_enDmpDivxStatus)
    {
        case DIVX_MENU:
            _u16DivxTitleIdx = 0;
            _u16DivxEditionIdx = 0;
            _u16DivxChpIdx = 0;
            _u8DivxAutoChpIdx = 0;
            if (MApp_ZUI_API_IsSuccessor(HWND_DMP_PLAYBACK_MOVIEINFO_DIVX_SETTITLE_WINDOW, hwnd))
            {
                MApp_ZUI_API_SetFocus(HWND_DMP_PLAYBACK_MOVIEINFO_DIVX_MENU_SETTITLE);
            }
            else if (MApp_ZUI_API_IsSuccessor(HWND_DMP_PLAYBACK_MOVIEINFO_DIVX_SETEDTION_WINDOW, hwnd))
            {
                MApp_ZUI_API_SetFocus(HWND_DMP_PLAYBACK_MOVIEINFO_DIVX_MENU_SETEDITION);
            }
            else if(MApp_ZUI_API_IsSuccessor(HWND_DMP_PLAYBACK_MOVIEINFO_DIVX_SETCHAPTER_WINDOW, hwnd))
            {
                MApp_ZUI_API_SetFocus(HWND_DMP_PLAYBACK_MOVIEINFO_DIVX_MENU_SETCHAPTER);
            }
            else if(MApp_ZUI_API_IsSuccessor(HWND_DMP_PLAYBACK_MOVIEINFO_DIVX_SETAUTOCHAPTER_WINDOW, hwnd))
            {
                MApp_ZUI_API_SetFocus(HWND_DMP_PLAYBACK_MOVIEINFO_DIVX_MENU_SETAUTOCHAPTER);
            }
            else
            {
                MApp_ZUI_API_SetFocus(HWND_DMP_PLAYBACK_MOVIEINFO_DIVX_MENU_SETTITLE);
            }
            MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_MOVIEINFO_DIVX_SETTITLE_WINDOW, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_MOVIEINFO_DIVX_SETEDTION_WINDOW, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_MOVIEINFO_DIVX_SETCHAPTER_WINDOW, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_MOVIEINFO_DIVX_SETAUTOCHAPTER_WINDOW, SW_HIDE);
            break;
        case DIVX_SET_TITLE:
            MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_MOVIEINFO_DIVX_MENU_WINDOW, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_MOVIEINFO_DIVX_SETEDTION_WINDOW, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_MOVIEINFO_DIVX_SETCHAPTER_WINDOW, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_MOVIEINFO_DIVX_SETAUTOCHAPTER_WINDOW, SW_HIDE);
            MApp_ZUI_API_SetFocus(HWND_DMP_PLAYBACK_MOVIEINFO_DIVX_SETTITLE_TITLE_TEXT);
            break;
        case DIVX_SET_EDITION:
            MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_MOVIEINFO_DIVX_MENU_WINDOW, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_MOVIEINFO_DIVX_SETTITLE_WINDOW, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_MOVIEINFO_DIVX_SETCHAPTER_WINDOW, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_MOVIEINFO_DIVX_SETAUTOCHAPTER_WINDOW, SW_HIDE);
            MApp_ZUI_API_SetFocus(HWND_DMP_PLAYBACK_MOVIEINFO_DIVX_SETEDTION_TEXT);
            break;
        case DIVX_SET_CHAPTER:
            MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_MOVIEINFO_DIVX_MENU_WINDOW, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_MOVIEINFO_DIVX_SETTITLE_WINDOW, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_MOVIEINFO_DIVX_SETEDTION_WINDOW, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_MOVIEINFO_DIVX_SETAUTOCHAPTER_WINDOW, SW_HIDE);
            MApp_ZUI_API_SetFocus(HWND_DMP_PLAYBACK_MOVIEINFO_DIVX_SETCHAPTER_TEXT);
            break;
        case DIVX_SET_AUTOCHAPTER:
            MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_MOVIEINFO_DIVX_MENU_WINDOW, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_MOVIEINFO_DIVX_SETTITLE_WINDOW, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_MOVIEINFO_DIVX_SETEDTION_WINDOW, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_MOVIEINFO_DIVX_SETCHAPTER_WINDOW, SW_HIDE);
            MApp_ZUI_API_SetFocus(HWND_DMP_PLAYBACK_MOVIEINFO_DIVX_SETAUTOCHAPTER_TEXT);
            break;
        default:
            MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_MOVIEINFO_DIVX_GROUP, SW_HIDE);
            MApp_ZUI_API_SetFocus(_hwndListInfoBar[MOVIEINFO_DIVX%DMP_INFOBAR_ICON_NUM]);
            break;
    }
    MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_MOVIEINFO_DIVX_GROUP);
}
#endif

static BOOLEAN _MApp_ACTdmp_File_Delete(void)
{
    U16 u16NewIdx = MApp_MPlayer_QueryCurrentFileIndex(E_MPLAYER_INDEX_CURRENT_DIRECTORY);

    if(MApp_MPlayer_DeleteFile(E_MPLAYER_INDEX_CURRENT_PAGE,
                MApp_MPlayer_QueryCurrentFileIndex(E_MPLAYER_INDEX_CURRENT_PAGE)) == E_MPLAYER_RET_OK)
    {
//        MApp_MPlayer_DeleteFile(E_MPLAYER_INDEX_CURRENT_PAGE,
//                MApp_MPlayer_QueryCurrentFileIndex(E_MPLAYER_INDEX_CURRENT_PAGE));
        if(u16NewIdx > (MApp_MPlayer_QueryTotalFileNum()-1))
        {
            MApp_ZUI_API_EnableWindow(_hwndListFileItem[u16NewIdx%DMP_NUM_OF_FILES_PER_PAGE], ENABLE);
            MApp_ZUI_API_EnableWindow(_hwndListFileItem[(MApp_MPlayer_QueryTotalFileNum()-1)%DMP_NUM_OF_FILES_PER_PAGE], DISABLE);
            MApp_MPlayer_SetCurrentFile(E_MPLAYER_INDEX_CURRENT_DIRECTORY, (MApp_MPlayer_QueryTotalFileNum()-1));
        }
#ifdef ENABLE_SMC_UI_NEW     /* smc.qxr 20121016 */
        _MApp_ACTdmp_ShowScrollBar();
#endif
        MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_FILE_SELECT_PAGE);
        return TRUE;
    }
    return FALSE;
}
static BOOLEAN _MApp_ACTdmp_File_Copy(void)
{
    //to remember current file name
    MApp_MPlayer_QueryFileInfo(E_MPLAYER_INDEX_CURRENT_PAGE,
                                MApp_MPlayer_QueryCurrentFileIndex(E_MPLAYER_INDEX_CURRENT_PAGE),
                                &_stCopyFileInfo);
    MApp_MPlayer_SetCopyFile(E_MPLAYER_INDEX_CURRENT_PAGE,
                               MApp_MPlayer_QueryCurrentFileIndex(E_MPLAYER_INDEX_CURRENT_PAGE));
    if(MApp_MPlayer_IsCopyFileExist())
    {
        if(!MApp_ZUI_API_IsWindowEnabled(HWND_DMP_FILE_PAGE_SUBMENU_PASTE))
        {
            MApp_ZUI_API_EnableWindow(HWND_DMP_FILE_PAGE_SUBMENU_PASTE, ENABLE);
            MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_FILE_PAGE_SUBMENU_GROUP);
        }
        return TRUE;
    }
    return FALSE;
}
static BOOLEAN _MApp_ACTdmp_Func_PasteFile(void)
{
    U8 u8Filename[FILE_INFO_LONG_FILENAME_SIZE];
    U8 u8NameStr[FILE_INFO_LONG_FILENAME_SIZE];
    U16 u16CaptureIdx = 1;
    U8  u8Len;
    U32 *pu32ptr=NULL;
    memset(u8Filename, 0, FILE_INFO_LONG_FILENAME_SIZE);
    // Truncate long string name

    pu32ptr = (U32*)msAPI_Memory_Allocate(FILE_INFO_LONG_FILENAME_SIZE, BUF_ID_FILEBROWER);
    if(pu32ptr == NULL)
    {
        __ASSERT(0);
        return FALSE;
    }
    memcpy(pu32ptr, _stCopyFileInfo.u8LongFileName, FILE_INFO_LONG_FILENAME_SIZE);
    if(FS_strlen_U((U16*)pu32ptr) >= ((FILE_INFO_LONG_FILENAME_SIZE/2)-7))
    {
        _stCopyFileInfo.u8LongFileName[FILE_INFO_LONG_FILENAME_SIZE-9] = 0x2E; //'.'
        _stCopyFileInfo.u8LongFileName[FILE_INFO_LONG_FILENAME_SIZE-8] = 0x00;
        _stCopyFileInfo.u8LongFileName[FILE_INFO_LONG_FILENAME_SIZE-7] = _stCopyFileInfo.u8ExtFileName[0];
        _stCopyFileInfo.u8LongFileName[FILE_INFO_LONG_FILENAME_SIZE-6] = 0x00;
        _stCopyFileInfo.u8LongFileName[FILE_INFO_LONG_FILENAME_SIZE-5] = _stCopyFileInfo.u8ExtFileName[1];
        _stCopyFileInfo.u8LongFileName[FILE_INFO_LONG_FILENAME_SIZE-4] = 0x00;
        _stCopyFileInfo.u8LongFileName[FILE_INFO_LONG_FILENAME_SIZE-3] = _stCopyFileInfo.u8ExtFileName[2];
        _stCopyFileInfo.u8LongFileName[FILE_INFO_LONG_FILENAME_SIZE-2] = 0x00;
        _stCopyFileInfo.u8LongFileName[FILE_INFO_LONG_FILENAME_SIZE-1] = 0x00;
    }
    memcpy(u8Filename, _stCopyFileInfo.u8LongFileName, FILE_INFO_LONG_FILENAME_SIZE);
    memcpy(pu32ptr, u8Filename, FILE_INFO_LONG_FILENAME_SIZE);
    u8Len = FS_strlen_U((U16*)pu32ptr);
    memset(u8NameStr, 0, FILE_INFO_LONG_FILENAME_SIZE);
    u8NameStr[0] = 0x30+(u16CaptureIdx/10);
    u8NameStr[1] = 0x00;
    u8NameStr[2] = 0x30+(u16CaptureIdx++%10);
    u8NameStr[3] = 0x00;
    u8NameStr[4] = 0x5F; // '_'
    u8NameStr[5] = 0x00;
    UnicodeCat((S8*)u8NameStr, (S8*)u8Filename);
     if (u8Len < ((FILE_INFO_LONG_FILENAME_SIZE/2)-3))
    u8Len+=3;   //String cat "xx_".  ex:"01_"
    /*
    if(u8Len<=12)     //Convert short name("filename.txt" 8+1+3) toupper
    {
        U16 i;
        for(i=0;i<u8Len*2;i++)
        {
            if(u8NameStr[i]>='a' && u8NameStr[i]<='z')
            {
                u8NameStr[i]=u8NameStr[i]-32;
            }
        }
    }
    */
    memcpy(pu32ptr, u8NameStr, FILE_INFO_LONG_FILENAME_SIZE);
    if(FS_strlen_U((U16*)pu32ptr) >= ((FILE_INFO_LONG_FILENAME_SIZE/2)-7))
    {
        u8NameStr[FILE_INFO_LONG_FILENAME_SIZE-9] = 0x2E; //'.'
        u8NameStr[FILE_INFO_LONG_FILENAME_SIZE-8] = 0x00;
        u8NameStr[FILE_INFO_LONG_FILENAME_SIZE-7] = _stCopyFileInfo.u8ExtFileName[0];
        u8NameStr[FILE_INFO_LONG_FILENAME_SIZE-6] = 0x00;
        u8NameStr[FILE_INFO_LONG_FILENAME_SIZE-5] = _stCopyFileInfo.u8ExtFileName[1];
        u8NameStr[FILE_INFO_LONG_FILENAME_SIZE-4] = 0x00;
        u8NameStr[FILE_INFO_LONG_FILENAME_SIZE-3] = _stCopyFileInfo.u8ExtFileName[2];
        u8NameStr[FILE_INFO_LONG_FILENAME_SIZE-2] = 0x00;
        u8NameStr[FILE_INFO_LONG_FILENAME_SIZE-1] = 0x00;
        memcpy(pu32ptr, u8NameStr, FILE_INFO_LONG_FILENAME_SIZE);
    }
    while(MApp_MPlayer_IsFilenameExistInCurrentDirectory((U16*)pu32ptr, u8Len))
    {
        msAPI_Timer_ResetWDT();
        if(u16CaptureIdx == 99)
        { // maximum captured number
            //sprintf(u8Digit, "_%02d", u16CaptureIdx);
            break;
        }
        u8NameStr[0] = 0x30+(u16CaptureIdx/10);
        u8NameStr[1] = 0x00;
        u8NameStr[2] = 0x30+(u16CaptureIdx++%10);
        u8NameStr[3] = 0x00;
        u8NameStr[4] = 0x5F; // '_'
        u8NameStr[5] = 0x00;
        memcpy(pu32ptr, u8NameStr, FILE_INFO_LONG_FILENAME_SIZE);
    }
    msAPI_Memory_Free(pu32ptr, BUF_ID_FILEBROWER);
    if(MApp_MPlayer_BeginPasteFile(u8NameStr)==E_MPLAYER_RET_OK)
    {
        DMP_DBG(printf("MApp_MPlayer_BeginPasteFile success\n"););
        return TRUE;
    }
    else
    {
        DMP_DBG(printf("MApp_MPlayer_BeginPasteFile fail\n"););
        return FALSE;
    }
}
static BOOLEAN _MApp_ACTdmp_File_Paste(void)
{
    {
        U32 u32UnsuedSize = MApp_MPlayer_QueryUsbDiskUnusedSizeInKB(MApp_DMP_GetDriveFromMappingTable(MApp_DMP_GetCurDrvIdx()));
        // Check disk space first.
        //printf("[USB] Total Size : %ld KB\n", MApp_MPlayer_QueryUsbDiskTotalSizeInKB(g_u8CurrentDriveIdx));
        //printf("[USB] Unused Size : %ld KB\n", u32UnsuedSize);
        //printf("[File] %lu KB\n", _stCopyFileInfo.u32FileSize/1024);
        if(u32UnsuedSize > _stCopyFileInfo.u64FileSize.Lo/1024)
        {
            if(_MApp_ACTdmp_Func_PasteFile())
            {
                _MApp_ACTdmp_ShowProgressWin();
            }
            else
            {// Paste file error!
                _MApp_ACTdmp_ShowAlertWin(DMP_MSG_TYPE_PASTE_FILE_ERROR);
            }
        }
        else
        {
            _MApp_ACTdmp_ShowAlertWin(DMP_MSG_TYPE_DISK_FULL);
        }
    }
    return TRUE;
}
static void _MApp_ACTdmp_HandleUsbStatusChanged(void)
{
    msAPI_Scaler_SetBlueScreen_Origin(TRUE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
    MApi_XC_GenerateBlackVideo( ENABLE, MAIN_WINDOW );

    if(MApp_ZUI_GetActiveOSD() == E_OSD_MAIN_MENU
        || MApp_ZUI_GetActiveOSD() == E_OSD_INPUT_SOURCE)
    {
        MApp_DMP_Reset();
        MApp_DMP_SetDmpUiState(DMP_UI_STATE_MEDIA_SELECT);
        if(MApp_DMP_RecalculateDriveMappingTable())
        {
            if(MApp_MPlayer_ConnectDrive(MApp_DMP_GetDriveFromMappingTable(MApp_DMP_GetCurDrvIdx())) == E_MPLAYER_RET_OK)
            {
                DMP_DBG(printf("[1] connect drive %d OK ^_^\n", (int)MApp_DMP_GetCurDrvIdx()));
                MApp_DMP_SetDmpFlag(DMP_FLAG_DRIVE_CONNECT_OK);
                MApp_MPlayer_SetCurrentMediaType(E_MPLAYER_TYPE_PHOTO, TRUE);
            }
        }
        else
        {
            MApp_DMP_ClearDmpFlag(DMP_FLAG_DRIVE_CONNECT_OK);
            MApp_MPlayer_SetCurrentMediaType(E_MPLAYER_TYPE_PHOTO, FALSE);
        }
        return;
    }
    //Transit UI state to media type select page
    MApp_DMP_UiStateTransition(DMP_UI_STATE_MEDIA_SELECT);

    if (MApp_ZUI_API_IsExistTimer(HWND_DMP_PLAYBACK_MUSIC_EQ_GROUP, DMP_TIMER_EQ_PLAY))
    {
        MApp_ZUI_API_KillTimer(HWND_DMP_PLAYBACK_MUSIC_EQ_GROUP, DMP_TIMER_EQ_PLAY);
        MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_MUSIC_EQ_GROUP,SW_HIDE);
    }
   #if ENABLE_EMBEDDED_PHOTO_DISPLAY
        MApp_MPlayer_StopEmbeddedPhoto();
   #endif

    if(MApp_DMP_RecalculateDriveMappingTable())
    {
        MApp_DMP_Reset();
        if(MApp_MPlayer_ConnectDrive(MApp_DMP_GetDriveFromMappingTable(MApp_DMP_GetCurDrvIdx())) == E_MPLAYER_RET_OK)
        {
            DMP_DBG(printf("[2] connect drive %d OK ^_^\n", (int)MApp_DMP_GetCurDrvIdx()));
            MApp_DMP_SetDmpFlag(DMP_FLAG_DRIVE_CONNECT_OK);
            MApp_MPlayer_SetCurrentMediaType(E_MPLAYER_TYPE_PHOTO, TRUE);
        }
        else
        {
            MApp_MPlayer_SetCurrentMediaType(E_MPLAYER_TYPE_PHOTO, FALSE);
        }
    }
    else
    {
        if(MApp_DMP_GetDmpFlag() & DMP_FLAG_MEDIA_FILE_PLAYING
            || MApp_DMP_GetDmpFlag() & DMP_FLAG_BGM_MODE)
        {
            MApp_MPlayer_Stop();
            MApp_MPlayer_StopMusic();
        }
        MApp_DMP_LoadCOPRO();
        MApp_DMP_ClearDmpFlag(DMP_FLAG_DRIVE_CONNECT_OK);
        MApp_DMP_ClearDmpFlag(DMP_FLAG_MEDIA_FILE_PLAYING);
        MApp_DMP_ClearDmpFlag(DMP_FLAG_BGM_MODE);
        MApp_DMP_Reset();
        MApp_MPlayer_SetCurrentMediaType(E_MPLAYER_TYPE_PHOTO, FALSE);
    }

    // thumbnail
    #if (DMP_PHOTO_THUMBNAIL || DMP_MOVIE_THUMBNAIL || DMP_MUSIC_THUMBNAIL)
    {
        _MApp_DMP_ThumbCopyRegion_Destroy();
        MApp_MPlayer_LeaveThumbnailMode();
        MApp_DMP_ClearDmpFlag(DMP_FLAG_THUMBNAIL_MODE);
        MApp_DMP_ClearDmpFlag(DMP_FLAG_THUMBNAIL_PLAYING);
    }
    #endif
}

#ifdef ENABLE_SRC_MENU_AUTOCLOSE_AND_SWITCH_SOURCE
static BOOLEAN MApp_DMP_HotkeyChangeSRC(VIRTUAL_KEY_CODE Dmpkey)
{
    switch(Dmpkey)
    {
    case VK_TV:
        _enCurrentSelectUIsource=UI_INPUT_SOURCE_ATV;
        break;
    case VK_AV:
        _enCurrentSelectUIsource=UI_INPUT_SOURCE_AV;
        break;
    case VK_COMPONENT:
        _enCurrentSelectUIsource=UI_INPUT_SOURCE_COMPONENT;
        break;
    case VK_HDMI:
        _enCurrentSelectUIsource=UI_INPUT_SOURCE_HDMI;
        break;
    case VK_PC:
        _enCurrentSelectUIsource=UI_INPUT_SOURCE_RGB;
        break;
    case VK_DMP:
		//<<SMC jayden.chen  modify only usb port 20130322
		#if(ENABLE_DMP_SWITCH)
		#if ENABLE_USB2_SOURCE
        if(UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_DMP1)
        {
            _enCurrentSelectUIsource=UI_INPUT_SOURCE_DMP2;
        }
        else
        {
            _enCurrentSelectUIsource=UI_INPUT_SOURCE_DMP1;
        }
		#else
        if(UI_INPUT_SOURCE_TYPE != UI_INPUT_SOURCE_DMP1)
        {
            _enCurrentSelectUIsource=UI_INPUT_SOURCE_DMP1;
        }
		else
		return FALSE;
		#endif
		#else
		_enCurrentSelectUIsource=UI_INPUT_SOURCE_DMP;
		#endif
        break;
    default:
        return FALSE;
    }
    MApp_DMP_GotoCurSrc();
    return TRUE;
}
#endif

void MApp_ZUI_ACT_AppShowDmp(void)
{
    HWND wnd;
    E_OSD_ID osd_id = E_OSD_DMP;
    RECT rect;
    g_GUI_WindowList = GetWindowListOfOsdTable(osd_id);
    g_GUI_WinDrawStyleList = GetWindowStyleOfOsdTable(osd_id);
    g_GUI_WindowPositionList = GetWindowPositionOfOsdTable(osd_id);
#if ZUI_ENABLE_ALPHATABLE
    g_GUI_WinAlphaDataList = GetWindowAlphaDataOfOsdTable(osd_id);
#endif
    HWND_MAX = GetWndMaxOfOsdTable(osd_id);
    OSDPAGE_BLENDING_ENABLE = IsBlendingEnabledOfOsdTable(osd_id);
    OSDPAGE_BLENDING_VALUE = GetBlendingValueOfOsdTable(osd_id);

    if (!_MApp_ZUI_API_AllocateVarData())
    {
        ZUI_DBG_FAIL(printf("[ZUI]ALLOC\n"));
        ABORT();
        return;
    }
    RECT_SET(rect,
        ZUI_DMP_XSTART, ZUI_DMP_YSTART,
        ZUI_DMP_WIDTH, ZUI_DMP_HEIGHT);

    if (!MApp_ZUI_API_InitGDI(&rect))
    {
        ZUI_DBG_FAIL(printf("[ZUI]GDIINIT\n"));
        ABORT();
        return;
    }

    for (wnd = 0; wnd < HWND_MAX; wnd++)
    {
        //printf("create msg: %lu\n", (U32)wnd);
        MApp_ZUI_API_SendMessage(wnd, MSG_CREATE, 0);
    }

    #if ( ENABLE_ARABIC_OSD )
    MMOsdIsOn = TRUE;
    #endif

    //To show "Loading..." symbol
    MApp_ZUI_API_ShowWindow(HWND_MAINFRAME, SW_HIDE);
    MApp_ZUI_API_ShowWindow(HWND_DMP_ROOT_TRANSPARENT_BG, SW_SHOW);
    DMP_DBG(printf("show DMP_MSG_TYPE_LOADING\n"););
    if (DMP_STATE_UI != MApp_DMP_GetDMPStat())
    {
        _MApp_ACTdmp_ShowAlertWin(DMP_MSG_TYPE_LOADING);
    }

    //Do not show transition effect to avoid a small block show up before entering MM main page.
    MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_PAGE_EXIT, E_ZUI_STATE_RUNNING);
}

S32 MApp_ZUI_ACT_DMPMarqueeTextWinProc(HWND hWnd, PMSG pMsg)
{
    GUI_DATA_MARQUEE_VARDATA * pData =
        (GUI_DATA_MARQUEE_VARDATA*)MApp_ZUI_API_GetWindowData(hWnd);
    switch(pMsg->message)
    {
        case MSG_TIMER:
            if (pData)
            {
                if (pData->u8ShowStartPosition == 0)
                    MApp_ZUI_API_SetTimer(hWnd, pMsg->wParam, DMP_MARQUEE_ANIMATION_INTERVAL_MS);
                pData->u8ShowStartPosition++;
                MApp_ZUI_API_InvalidateWindow(hWnd);
            }
            return 0;

        case MSG_PAINT:
            {
                //get buffer GC for offline drawing...
                PAINT_PARAM * param = (PAINT_PARAM*)pMsg->wParam;
                DRAWSTYLE_TYPE ds_type = DS_NORMAL;

                if (param->bIsDisable)
                {
                    param->dc.u8ConstantAlpha = MApp_ZUI_API_GetDisableAlpha(hWnd);
                    ds_type = DS_DISABLE;
                }
                else if (param->bIsFocus) //the same focus group
                {
                    param->dc.u8ConstantAlpha = MApp_ZUI_API_GetFocusAlpha(hWnd);
                    ds_type = DS_FOCUS;
                }
                else
                {
                    param->dc.u8ConstantAlpha = MApp_ZUI_API_GetNormalAlpha(hWnd);
                }

                _MApp_ZUI_API_DefaultOnPaint(hWnd, param, FALSE);
                {
                    U16 u16TxtComponentIndex = _MApp_ZUI_API_FindFirstComponentIndex(hWnd, ds_type, CP_TEXT_OUT);
                    LPTSTR pStr = MApp_ZUI_ACT_GetDynamicText(hWnd);
                    if (u16TxtComponentIndex != 0xFFFF && pStr)
                    {
                        DRAW_TEXT_OUT_DYNAMIC dyna;

                        _MApp_ZUI_API_ConvertTextComponentToDynamic(u16TxtComponentIndex, &dyna);
                        dyna.pString = pStr;
                        dyna.TextColor = MApp_ZUI_ACT_GetDynamicColor(hWnd, ds_type, dyna.TextColor);

                        //marquee animation:
                        // different here!!

                        if (/*ds_type == DS_FOCUS &&*/ pData != NULL &&
                            pData->u8ShowStartPosition != 0xFF)
                        {
                            if (pData->u8ShowStartPosition >= MApp_ZUI_API_Strlen(pStr))
                            {
                                pData->u8ShowStartPosition = 0xFF;
                                MApp_ZUI_API_KillTimer(hWnd, 0);
                            }
                            else if (pData->u8ShowStartPosition == 0)
                            {
                                U16 width;
                                clrBtn1.Fontfmt.flag = dyna.flag;
                                clrBtn1.Fontfmt.ifont_gap = dyna.u8dis;
                                clrBtn1.bStringIndexWidth = CHAR_IDX_2BYTE;
                                width = msAPI_OSD_GetStrWidth(Font[dyna.eSystemFont].fHandle, (U8*)pStr, &clrBtn1);
                                //note: add border for a little truncate case..
                                if (width+BTN_TEXT_GAP*2 <= param->rect->width)
                                {
                                    pData->u8ShowStartPosition = 0xFF;
                                    MApp_ZUI_API_KillTimer(hWnd, 0);
                                }
                            }
                            else
                            {
                                dyna.eTextAttrib = eTextAlignLeft;
                                dyna.pString += pData->u8ShowStartPosition;
                                dyna.u8dots = 0; //note: don't show dots for animation..
                            }
                        }
                        else
                        {
                            //note: pData may be shared with others, so don't clear them
                            //      but we need to stop the timer if animation still going
                            MApp_ZUI_API_KillTimer(hWnd, 0);
                        }

                        _MApp_ZUI_API_DrawDynamicComponent(CP_TEXT_OUT_DYNAMIC, &dyna, &param->dc, param->rect);
                    }

                }

            }
            return 0;

            default:
                break;
    }

    return DEFAULTWINPROC(hWnd, pMsg);
}

///////////////////////////////////////////////////////////////
// methods


S32 MApp_ZUI_ACT_DMPVolumeWinProc(HWND hwnd, PMSG msg)
{
    switch(msg->message)
    {
        case MSG_TIMER:
            MApp_ZUI_API_KillTimer(HWND_DMP_VOLUME_LIST, DMP_VOLUME_TIMER);
            MApp_ZUI_API_ShowWindow(HWND_DMP_VOLUME_LIST, SW_HIDE);
        //    MApp_ZUI_API_RestoreFocusCheckpoint();
        break;
        default:
            break;
    }
    return DEFAULTWINPROC(hwnd, msg);
}

#if CUS_SMC_ENABLE_HOTEL_MODE
static void _MApp_ZUI_ACT_DMPHotelPasswordHandler(VIRTUAL_KEY_CODE key)
{
    HWND hwnd = MApp_ZUI_API_GetFocus();
	#if(UI_SKIN_SEL==UI_SKIN_1366X768X565_HAIER_CN)  // CUS_xm zHIHE 20120807 modify
    if(HWND_MENU_LOCK_ENTER_PASSWORD == hwnd||
		HWND_MENU_LOCK_NEWPSW == hwnd||
		HWND_MENU_LOCK_CONFIMNEWPSW == hwnd
        ||HWND_MENU_LOCK_ENTER_PASSWORD_OPTION==hwnd
        ||HWND_MENU_LOCK_ENTER_PASSWORD_OPTION_1==hwnd
        ||HWND_MENU_LOCK_ENTER_PASSWORD_OPTION_2==hwnd
        ||HWND_MENU_LOCK_ENTER_PASSWORD_OPTION_3==hwnd
	)
	#else
	if(HWND_DMP_HOTEL_PASSWD_PANEL_OPTION == hwnd)
	#endif
    {
        printf("Position:%d\n",g_u8PasswordPosition);
        g_u8PasswordCount++;
        g_u8PasswordPosition++;
        g_u16Password = (g_u16Password<<4)|(key-VK_NUM_0);
        if (g_u8PasswordCount == PASSWORD_SIZE)
        {
            #if(UI_SKIN_SEL==UI_SKIN_1366X768X565_HAIER_CN)  // CUS_xm zHIHE 20120807 modify
			if(HWND_MENU_LOCK_ENTER_PASSWORD == hwnd||HWND_MENU_LOCK_ENTER_PASSWORD_OPTION_3==hwnd)
            #else
            if(HWND_DMP_HOTEL_PASSWD_PANEL_OPTION == hwnd)
		    #endif
     //       MApp_ZUI_API_IsSuccessor(HWND_MENU_LOCK_CHANGEPWSUBPAGE_ITEM_OLDPW, hwnd))
            {
				U16 u16SuperPassword = 0;
				U16 u16SuperPassword_1 = 0;
				U32 u32SuperPassword_Macro = SUPER_PASSWORD;
				U32 u32SuperPassword_Macro_1 = SUPER_PASSWORD_1;
				u16SuperPassword = (u32SuperPassword_Macro/1000)<<12;
				u16SuperPassword = u16SuperPassword | (((u32SuperPassword_Macro%1000)/100)<<8);
				u16SuperPassword = u16SuperPassword | (((u32SuperPassword_Macro%100)/10)<<4);
				u16SuperPassword = u16SuperPassword | ((u32SuperPassword_Macro%10));
				
				u16SuperPassword_1= (u32SuperPassword_Macro_1/1000)<<12;
				u16SuperPassword_1= u16SuperPassword_1| (((u32SuperPassword_Macro_1%1000)/100)<<8);
				u16SuperPassword_1= u16SuperPassword_1| (((u32SuperPassword_Macro_1%100)/10)<<4);
				u16SuperPassword_1= u16SuperPassword_1| ((u32SuperPassword_Macro_1%10));
				
				if ((g_u16Password == stGenSetting.g_VChipSetting.u16VChipPassword) ||
					(g_u16Password == u16SuperPassword) || (g_u16Password == u16SuperPassword_1))
                {
                    #if(UI_SKIN_SEL==UI_SKIN_1366X768X565_HAIER_CN)  // CUS_xm zHIHE 20120807 modify
					if(HWND_MENU_LOCK_ENTER_PASSWORD == hwnd||HWND_MENU_LOCK_ENTER_PASSWORD_OPTION_3==hwnd)
                    #else
                    if(HWND_DMP_HOTEL_PASSWD_PANEL_OPTION == hwnd )
				    #endif
                    {
                        g_u8PasswordPosition = 0;
						MApp_DMP_GotoHotel();
                    }
                    else //HWND_MENU_LOCK_CHANGEPWSUBPAGE_ITEM_OLDPW
                    {

           //             MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_CHANGEPWSUBPAGE_ITEM_OLDPW, FALSE);
                   //     MApp_ZUI_API_SetFocus(HWND_MENU_LOCK_CHANGEPWSUBPAGE_PW1_1);
                    }
                }
                else
                {
                    g_u8PasswordPosition = 0;
					#if(UI_SKIN_SEL==UI_SKIN_1366X768X565_HAIER_CN)  // CUS_xm zHIHE 20120807 modify
					if(HWND_MENU_LOCK_ENTER_PASSWORD == hwnd||HWND_MENU_LOCK_ENTER_PASSWORD_OPTION_3==hwnd)
					 {
                        MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_PAGE_CHECKPWD_ERROR_MSG, SW_SHOW);
                        MApp_ZUI_API_SetTimer(HWND_MENU_LOCK_PAGE_CHECKPWD_ERROR_MSG,1, 3000);
                        g_u8PasswordPosition = 4;
    					MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_LOCK_ENTER_PASSWORD);
						MApp_ZUI_API_SetFocus(HWND_MENU_LOCK_ENTER_PASSWORD);
                    }
                    #else
                    if(HWND_DMP_HOTEL_PASSWD_PANEL_OPTION == hwnd )

                    {
                        g_u8PasswordPosition = 4;
    					//MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_HOTEL_PASSWD_PANEL_OPTION);
						MApp_ZUI_API_ShowWindow(HWND_DMP_HOTEL_PASSWD_PANEL_OPTION,SW_HIDE);
						MApp_ZUI_API_ShowWindow(HWND_DMP_HOTEL_PASSWD_WRONG,SW_SHOW);
						MApp_ZUI_API_SetFocus(HWND_DMP_HOTEL_PASSWD_WRONG);
                    }
					#endif
                    else
                    {
					;
					}
                }
            }
            g_u16Password = 0;
            g_u8PasswordCount = 0;
        }
        else
        {;
        }
		MApp_ZUI_API_InvalidateAllSuccessors(hwnd);
		MApp_ZUI_API_ResetTimer(HWND_DMP_HOTEL_PASSWD_PANEL,1);
}
}
#endif
extern void MApp_InputSource_SetStateFromUSB(void);

//////////////////////////////////////////////////////////
// Key Handler
BOOLEAN MApp_ZUI_ACT_HandleDmpKey(VIRTUAL_KEY_CODE key)
{
    //Deal with DMP hotkeys here.

#if ENABLE_PLAYBACK_INFO_AUTO_CLOSE
	if(MApp_ZUI_API_IsSuccessor(HWND_DMP_PLAYBACK_INFO_PANE,MApp_ZUI_API_GetFocus()) \
		|| MApp_ZUI_API_IsWindowVisible(HWND_DMP_PLAYBACK_INFO_PANE))
		{
		if(MApp_ZUI_API_IsExistTimer(HWND_DMP_PLAYBACK_INFO_PANE,0))
			MApp_ZUI_API_ResetTimer(HWND_DMP_PLAYBACK_INFO_PANE,0);
		}
#endif

	if(MApp_ZUI_API_IsWindowVisible(HWND_DMP_PLAYBACK_MOVIERESUME_PAGE))
		MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_MOVIERESUME_PAGE, DMP_TIMER_MOVIERESUME_WIN, DMP_TIME_MS_MOVIERESUME);
    switch(key)
    {
//#if (ENABLE_DIVX_PLUS == 1)
        case VK_NUM_0:
        case VK_NUM_1:
        case VK_NUM_2:
        case VK_NUM_3:
        case VK_NUM_4:
        case VK_NUM_5:
        case VK_NUM_6:
        case VK_NUM_7:
        case VK_NUM_8:
        case VK_NUM_9:
#if (ENABLE_DIVX_PLUS == 1)
        {
            if (_enDmpDivxStatus == DIVX_SET_AUTOCHAPTER)
            {
                VIRTUAL_KEY_CODE i = key - VK_NUM_0;
                _u8DivxAutoChpIdx = i; // 0~9
                _MApp_ACTdmp_MovieCancelRepeatAB();
                MApp_MPlayer_MovieChangeAutoGenChapter(_u8DivxAutoChpIdx);
                MApp_ZUI_API_InvalidateWindow(HWND_DMP_PLAYBACK_MOVIEINFO_DIVX_SETAUTOCHAPTER_TEXT);
            }
        }
#endif
#if CUS_SMC_ENABLE_HOTEL_MODE
   if(MApp_ZUI_API_GetFocus()==HWND_DMP_HOTEL_PASSWD_WRONG)
   	{
   	 MApp_ZUI_API_ShowWindow(HWND_DMP_HOTEL_PASSWD_WRONG,SW_HIDE);
   	 MApp_ZUI_API_ShowWindow(HWND_DMP_HOTEL_PASSWD_PANEL_OPTION,SW_SHOW);
	 MApp_ZUI_API_SetFocus(HWND_DMP_HOTEL_PASSWD_PANEL_OPTION);
     return TRUE;
    }
   else if(MApp_ZUI_API_GetFocus()==HWND_DMP_HOTEL_PASSWD_PANEL_OPTION)
   	{
     _MApp_ZUI_ACT_DMPHotelPasswordHandler(key);
     return TRUE;
    }
#endif
        break;
//#endif

#if CUS_SMC_ENABLE_HOTEL_MODE
		case VK_KEY_REMOTE_CONTROL_LOCK:
			{
			if(MApp_ZUI_API_GetFocus()==HWND_DMP_HOTEL_PASSWD_PANEL_OPTION || MApp_ZUI_API_GetFocus()==HWND_DMP_HOTEL_PASSWD_WRONG)
			  {
			  MApp_ZUI_API_KillTimer(HWND_DMP_HOTEL_PASSWD_PANEL, 1);
			  MApp_ZUI_API_ShowWindow(HWND_DMP_HOTEL_PASSWD_PANEL,SW_HIDE);
			  MApp_ZUI_API_RestoreFocusCheckpoint();
			  }
			 HotelLockMode=0;
			 MApp_ZUI_API_ShowWindow(HWND_DMP_HOTEL_MSG_NOTE,SW_SHOW);
			 MApp_ZUI_API_SetTimer(HWND_DMP_HOTEL_MSG_NOTE,1,5000);
			 return TRUE;
			}
			break;
		case VK_BUTTON_UNLOCK_HOTEL_MODE:
			{
			if(MApp_ZUI_API_GetFocus()==HWND_DMP_HOTEL_PASSWD_PANEL_OPTION || MApp_ZUI_API_GetFocus()==HWND_DMP_HOTEL_PASSWD_WRONG)
			  {
			  MApp_ZUI_API_KillTimer(HWND_DMP_HOTEL_PASSWD_PANEL, 1);
			  MApp_ZUI_API_ShowWindow(HWND_DMP_HOTEL_PASSWD_PANEL,SW_HIDE);
			  MApp_ZUI_API_RestoreFocusCheckpoint();
			  }
			 HotelLockMode=1;
			 MApp_ZUI_API_ShowWindow(HWND_DMP_HOTEL_MSG_NOTE,SW_SHOW);
			 MApp_ZUI_API_SetTimer(HWND_DMP_HOTEL_MSG_NOTE,1,5000);
			 return TRUE;
			}
			break;
		case VK_BUTTON_LOCK_HOTEL_MODE:
			{
			if(MApp_ZUI_API_GetFocus()==HWND_DMP_HOTEL_PASSWD_PANEL_OPTION || MApp_ZUI_API_GetFocus()==HWND_DMP_HOTEL_PASSWD_WRONG)
			  {
			  MApp_ZUI_API_KillTimer(HWND_DMP_HOTEL_PASSWD_PANEL, 1);
			  MApp_ZUI_API_ShowWindow(HWND_DMP_HOTEL_PASSWD_PANEL,SW_HIDE);
			  MApp_ZUI_API_RestoreFocusCheckpoint();
			  }
			 HotelLockMode=2;
			 MApp_ZUI_API_ShowWindow(HWND_DMP_HOTEL_MSG_NOTE,SW_SHOW);
			 MApp_ZUI_API_SetTimer(HWND_DMP_HOTEL_MSG_NOTE,1,5000);
			 return TRUE;
			}
			break;
#endif
case VK_SELECT:
#if CUS_SMC_ENABLE_HOTEL_MODE
	   if(MApp_ZUI_API_GetFocus()==HWND_DMP_HOTEL_PASSWD_WRONG)
		{
		 MApp_ZUI_API_ShowWindow(HWND_DMP_HOTEL_PASSWD_WRONG,SW_HIDE);
		 MApp_ZUI_API_ShowWindow(HWND_DMP_HOTEL_PASSWD_PANEL_OPTION,SW_SHOW);
		 MApp_ZUI_API_SetFocus(HWND_DMP_HOTEL_PASSWD_PANEL_OPTION);
		 return TRUE;
		}
#endif
	break;
          case VK_LOCK:
		   #if CUS_SMC_ENABLE_HOTEL_MODE
            //if(MApp_MPlayer_QueryCurrentMediaType()==E_MPLAYER_TYPE_PHOTO)
            {
              //if(MApp_DMP_GetDmpUiState()==DMP_UI_STATE_PLAYING_STAGE)
              	{
			   if(MApp_ZUI_API_IsWindowVisible(HWND_DMP_HOTEL_MSG_NOTE))
				 {
				 MApp_ZUI_API_KillTimer(HWND_DMP_HOTEL_MSG_NOTE, 1);
				 MApp_ZUI_API_ShowWindow(HWND_DMP_HOTEL_MSG_NOTE,SW_HIDE);
			  	 }
              	 MApp_ZUI_API_StoreFocusCheckpoint();
                 MApp_ZUI_API_ShowWindow(HWND_DMP_HOTEL_PASSWD_PANEL,SW_SHOW);
				 MApp_ZUI_API_ShowWindow(HWND_DMP_HOTEL_PASSWD_WRONG,SW_HIDE);
				 MApp_ZUI_API_SetTimer(HWND_DMP_HOTEL_PASSWD_PANEL,1,5000);
				 MApp_ZUI_API_SetFocus(HWND_DMP_HOTEL_PASSWD_PANEL_OPTION);
				 return TRUE;
			    }
			}
		   #endif
			break;
		  case VK_AB:
		  printf("\r\nVK AB");
		  #if BOE_MT_NEW_IR_KEY_VALUE
		  if(MApp_MPlayer_IsMediaFileInPlaying() && (MApp_DMP_GetDmpFlag()& DMP_FLAG_MEDIA_FILE_PLAYING))
		  {
		  	switch(MApp_MPlayer_QueryCurrentMediaType())
		  	{
		  		case E_MPLAYER_TYPE_MUSIC:
		  			MApp_ZUI_ACT_ExecuteDmpAction(EN_EXE_DMP_HOTKEY_REPEAT);
		  			break;
		  		case E_MPLAYER_TYPE_MOVIE:
		  			MApp_ZUI_ACT_ExecuteDmpAction(EN_EXE_DMP_HOTKEY_AB);
		  			break;
		  		case E_MPLAYER_TYPE_TEXT:
		  			break;
		  		default:
		  			break;
		  	}
		  }
		  #else
		  MApp_ZUI_ACT_ExecuteDmpAction(EN_EXE_DMP_HOTKEY_AB);
		  #endif
		  break;
        case VK_PREVIOUS:
            DMP_DBG(printf("hotkey VK_PREVIOUS\n"););
            if(MApp_MPlayer_IsMediaFileInPlaying() && (MApp_DMP_GetDmpFlag()& DMP_FLAG_MEDIA_FILE_PLAYING))
            {
                switch(MApp_MPlayer_QueryCurrentMediaType())
                {
                    case E_MPLAYER_TYPE_MUSIC:
                        MApp_ZUI_ACT_ExecuteDmpAction( EN_EXE_DMP_PLAYBACK_MUSICINFO_PREV);
                        break;
                    case E_MPLAYER_TYPE_MOVIE:
                    #if ENABLE_DRM
                        if (msAPI_Timer_DiffTimeFromNow(u32PrevButtonTimer) > DMP_TIME_MS_PREV_BUTTON_CLICK_WIN)
                        {
                            MApp_ZUI_ACT_ExecuteDmpAction( EN_EXE_DMP_PLAYBACK_MOVIEINFO_BEGIN);
                        }
                        else
                        {
                            MApp_ZUI_ACT_ExecuteDmpAction( EN_EXE_DMP_PLAYBACK_MOVIEINFO_PREV);
                            MApp_ZUI_API_KillTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PREV_BUTTON_CLICK_WIN);
                        }
                        u32PrevButtonTimer = msAPI_Timer_GetTime0();
                     #else
                        MApp_ZUI_ACT_ExecuteDmpAction( EN_EXE_DMP_PLAYBACK_MOVIEINFO_PREV);
                     #endif
                        break;
                    case E_MPLAYER_TYPE_PHOTO:
                        MApp_ZUI_ACT_ExecuteDmpAction( EN_EXE_DMP_PLAYBACK_PHOTOINFO_PREV);
                        break;
                    case E_MPLAYER_TYPE_TEXT:
                        //MApp_ZUI_ACT_ExecuteDmpAction( EN_EXE_DMP_PLAYBACK_TEXTINFO_PREVFILE);
                        break;
                    default:
                        break;
                }
            }
            if (MApp_ZUI_API_IsWindowVisible(HWND_DMP_PLAYBACK_TEXT_FULL_WINDOW))
            {
                MApp_ZUI_ACT_ExecuteDmpAction( EN_EXE_DMP_PLAYBACK_TEXTINFO_PREVFILE);
            }

            if(MApp_ZUI_API_IsWindowVisible(HWND_DMP_PLAYBACK_PAGE_INFOBAR))
            {
                MApp_ZUI_ACT_FunctionHotkeyUIMapping(VK_PREVIOUS);
            }
            return TRUE;
        case VK_NEXT:
            DMP_DBG(printf("hotkey VK_NEXT\n"););
            if(MApp_MPlayer_IsMediaFileInPlaying() && (MApp_DMP_GetDmpFlag()& DMP_FLAG_MEDIA_FILE_PLAYING))
            {
                switch(MApp_MPlayer_QueryCurrentMediaType())
                {
                    case E_MPLAYER_TYPE_MUSIC:
                        MApp_ZUI_ACT_ExecuteDmpAction( EN_EXE_DMP_PLAYBACK_MUSICINFO_NEXT);
                        break;
                    case E_MPLAYER_TYPE_MOVIE:
                        MApp_ZUI_ACT_ExecuteDmpAction( EN_EXE_DMP_PLAYBACK_MOVIEINFO_NEXT);
                        break;
                    case E_MPLAYER_TYPE_PHOTO:
                        MApp_ZUI_ACT_ExecuteDmpAction( EN_EXE_DMP_PLAYBACK_PHOTOINFO_NEXT);
                        break;
                    case E_MPLAYER_TYPE_TEXT:
                        //MApp_ZUI_ACT_ExecuteDmpAction( EN_EXE_DMP_PLAYBACK_TEXTINFO_NEXTFILE);
                        break;
                    default:
                        break;
                }
            }
            if (MApp_ZUI_API_IsWindowVisible(HWND_DMP_PLAYBACK_TEXT_FULL_WINDOW))
            {
                MApp_ZUI_ACT_ExecuteDmpAction( EN_EXE_DMP_PLAYBACK_TEXTINFO_NEXTFILE);
            }

            if(MApp_ZUI_API_IsWindowVisible(HWND_DMP_PLAYBACK_PAGE_INFOBAR))
            {
                MApp_ZUI_ACT_FunctionHotkeyUIMapping(VK_NEXT);
            }
            return TRUE;
        case VK_STOP:
            DMP_DBG(printf("hotkey VK_STOP\n"););
            if(MApp_MPlayer_IsMediaFileInPlaying() && (MApp_DMP_GetDmpFlag()& DMP_FLAG_MEDIA_FILE_PLAYING))
            {
                switch(MApp_MPlayer_QueryCurrentMediaType())
                {
                    case E_MPLAYER_TYPE_MUSIC:
                        MApp_ZUI_ACT_ExecuteDmpAction( EN_EXE_DMP_PLAYBACK_MUSICINFO_STOP);
                        MApp_DMP_ClearDmpFlag(DMP_FLAG_BGM_MODE);
                        MApp_MPlayer_Stop(); // for bgm
                        break;
                    case E_MPLAYER_TYPE_MOVIE:
                        MApp_ZUI_ACT_ExecuteDmpAction( EN_EXE_DMP_PLAYBACK_MOVIEINFO_STOP);
                        break;
                    case E_MPLAYER_TYPE_PHOTO:
                        MApp_ZUI_ACT_ExecuteDmpAction( EN_EXE_DMP_PLAYBACK_PHOTOINFO_STOP);
                        break;
                    case E_MPLAYER_TYPE_TEXT:
                        //MApp_ZUI_ACT_ExecuteDmpAction( EN_EXE_DMP_PLAYBACK_TEXTINFO_STOP);
                        break;
                    default:
                        break;
                }
            }
            if (MApp_ZUI_API_IsWindowVisible(HWND_DMP_PLAYBACK_TEXT_FULL_WINDOW))
            {
                MApp_ZUI_ACT_ExecuteDmpAction( EN_EXE_DMP_PLAYBACK_TEXTINFO_STOP);
            }
            return TRUE;
        case VK_PLAY:
            DMP_DBG(printf("hotkey VK_PLAY \n"););
            //MApp_ZUI_API_EnableWindow(HWND_DMP_PLAYBACK_INFOBAR_GROUP,TRUE);
            if(MApp_MPlayer_IsMediaFileInPlaying() && (MApp_DMP_GetDmpFlag()& DMP_FLAG_MEDIA_FILE_PLAYING))
            {
                switch(MApp_MPlayer_QueryCurrentMediaType())
                {
                    case E_MPLAYER_TYPE_MUSIC:
                    {
                        if(MApp_MPlayer_QueryMusicPlayMode() == E_MPLAYER_MUSIC_NORMAL)
                        {
                            // do nothing
                        }
                        else // some FF FB ...
                        {
                            MApp_MPlayer_MusicChangePlayMode(E_MPLAYER_MUSIC_NORMAL);
                            _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_PLAY;
                            MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_SHOW);
                            MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN, DMP_TIME_MS_PLAY_STATUS_WIN);
                            DMP_MusicInfoBarTable[MUSICINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PAUSE;
                            DMP_MusicInfoBarTable[MUSICINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Pause;
                        }
                        MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_INFOBAR_GROUP);
                        if(!MApp_ZUI_API_IsExistTimer(HWND_DMP_PLAYBACK_MUSIC_EQ_GROUP, DMP_TIMER_EQ_PLAY))
                        {
                            MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_MUSIC_EQ_GROUP, DMP_TIMER_EQ_PLAY, DMP_TIME_MS_EQ_PLAY);
                        }
                    }
                    break;
                    case E_MPLAYER_TYPE_MOVIE:
                    {
                        enumMPlayerMoviePlayMode eMoviePlayMode = MApp_MPlayer_QueryMoviePlayMode();
                        if(eMoviePlayMode == E_MPLAYER_MOVIE_STOP)
                        {
                            break;
                        }
                        /*if(eMoviePlayMode == E_MPLAYER_MOVIE_NORMAL)
                        {
                            _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_PLAY;
                            DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PLAY;
                            DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Play;
                        }
                        else*/
                        {
                            MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_NORMAL);
                            _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_PLAY;
                            DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PAUSE;
                            DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Pause;
                        }
                        MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_INFOBAR_GROUP);
                        MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_SHOW);
                        MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN, DMP_TIME_MS_PLAY_STATUS_WIN);
                    }
                    break;
                    case E_MPLAYER_TYPE_PHOTO:
                    {
                        if(MApp_MPlayer_QueryPhotoPlayMode() == E_MPLAYER_PHOTO_PAUSE)
                        {
                            MApp_MPlayer_PhotoChangePlayMode(E_MPLAYER_PHOTO_NORMAL);
                            _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_PLAY;
                            MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_SHOW);
                            MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN, DMP_TIME_MS_PLAY_STATUS_WIN);
                            DMP_PhotoInfoBarTable[PHOTOINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PAUSE;
                            DMP_PhotoInfoBarTable[PHOTOINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Pause;
                        }
                        else if(MApp_MPlayer_QueryPhotoPlayMode() == E_MPLAYER_PHOTO_NORMAL)
                        {
                            //do nothing;
                        }
                    }
                    MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_INFOBAR_GROUP);
                    break;
                    case E_MPLAYER_TYPE_TEXT:
                         break;
                    default:
                        break;
                }
                if(MApp_ZUI_API_IsWindowVisible(HWND_DMP_PLAYBACK_PAGE_INFOBAR))
                {
                    MApp_ZUI_ACT_FunctionHotkeyUIMapping(VK_PLAY);
                }
                return TRUE;
            }
            return FALSE;
        case VK_PAUSE:
            DMP_DBG(printf("hotkey VK_PAUSE \n"););
            if(MApp_MPlayer_IsMediaFileInPlaying() && (MApp_DMP_GetDmpFlag()& DMP_FLAG_MEDIA_FILE_PLAYING))
            {
#if ENABLE_DVD
                if (MApp_MPlayer_QueryCurrentFileMediaSubType() == E_MPLAYER_SUBTYPE_DVD)
                {
                    U8 ret;

                    if (!MApp_VDPlayer_DVD_IsAllowed(E_MPLAYER_DVD_CMD_PLAY_PAUSE))
                    {
                        return TRUE;
                    }

                    ret = MApp_MPlayer_DVD_Command(E_MPLAYER_DVD_CMD_PLAY_PAUSE);
                }
#endif

                switch(MApp_MPlayer_QueryCurrentMediaType())
                {
                    case E_MPLAYER_TYPE_MUSIC:
                        {
                            switch(MApp_MPlayer_QueryMusicPlayMode())
                            {
                                case E_MPLAYER_MUSIC_STOP:
                                case E_MPLAYER_MUSIC_PAUSE:
                                    //do nothing
                                    break;
                                default:
                                    //normal, FF, FB
                                    MApp_MPlayer_MusicChangePlayMode(E_MPLAYER_MUSIC_PAUSE);
                                    _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_PAUSE;
                                    MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_SHOW);
                                    MApp_ZUI_API_KillTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN);
                                    //MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN, DMP_TIME_MS_PLAY_STATUS_WIN);
                                    DMP_MusicInfoBarTable[MUSICINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PLAY;
                                    DMP_MusicInfoBarTable[MUSICINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Play;
                                    MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_INFOBAR_GROUP);
                                    break;
                            }
                            if(MApp_ZUI_API_IsExistTimer(HWND_DMP_PLAYBACK_MUSIC_EQ_GROUP, DMP_TIMER_EQ_PLAY))
                            {
                                MApp_ZUI_API_KillTimer(HWND_DMP_PLAYBACK_MUSIC_EQ_GROUP, DMP_TIMER_EQ_PLAY);
                            }
                        }
                        break;
                    case E_MPLAYER_TYPE_MOVIE:
                        {
                            enumMPlayerMoviePlayMode eMoviePlayMode = MApp_MPlayer_QueryMoviePlayMode();
                            if(eMoviePlayMode == E_MPLAYER_MOVIE_STOP)
                            {
                                break;
                            }
                            if((eMoviePlayMode != E_MPLAYER_MOVIE_PAUSE) &&
                               (eMoviePlayMode != E_MPLAYER_MOVIE_STEP) )
                            {
                                MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_PAUSE);
                                DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PLAY;
                                DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Play;
                                _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_PAUSE;
                                MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_INFOBAR_GROUP);
                                MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_SHOW);
                                MApp_ZUI_API_KillTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN);
                                //MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN, DMP_TIME_MS_PLAY_STATUS_WIN);
                            }
                            else
                            {
                                //do nothing
                            }
                        }
                        break;
                    case E_MPLAYER_TYPE_PHOTO:
                        {
                            if(MApp_MPlayer_QueryPhotoPlayMode() == E_MPLAYER_PHOTO_PAUSE)
                            {
                                // do nothing
                            }
                            else if(MApp_MPlayer_QueryPhotoPlayMode() == E_MPLAYER_PHOTO_NORMAL)
                            {
                                MApp_MPlayer_PhotoChangePlayMode(E_MPLAYER_PHOTO_PAUSE);
                                _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_PAUSE;
                                MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_SHOW);
                                MApp_ZUI_API_KillTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN);
                               // MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN, DMP_TIME_MS_PLAY_STATUS_WIN);
                                DMP_PhotoInfoBarTable[PHOTOINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PLAY;
                                DMP_PhotoInfoBarTable[PHOTOINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Play;
                                MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_INFOBAR_GROUP);
                                MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_SHOW);
                                //MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN, DMP_TIME_MS_PLAY_STATUS_WIN);
                            }
                        }
                        break;
                    case E_MPLAYER_TYPE_TEXT:
                        break;
                    default:
                        break;
                }

                if(MApp_ZUI_API_IsWindowVisible(HWND_DMP_PLAYBACK_PAGE_INFOBAR))
                {
                    MApp_ZUI_ACT_FunctionHotkeyUIMapping(VK_PAUSE);
                }
                return TRUE;
            }
            return FALSE;
        case VK_FF:
            DMP_DBG(printf("hotkey VK_FF\n"););
            if(MApp_MPlayer_IsMediaFileInPlaying() && (MApp_DMP_GetDmpFlag()& DMP_FLAG_MEDIA_FILE_PLAYING))
            {
                switch(MApp_MPlayer_QueryCurrentMediaType())
                {
                    case E_MPLAYER_TYPE_MUSIC:
                        MApp_ZUI_ACT_ExecuteDmpAction( EN_EXE_DMP_PLAYBACK_MUSICINFO_FF);
                        break;
                    case E_MPLAYER_TYPE_MOVIE:
                        MApp_ZUI_ACT_ExecuteDmpAction( EN_EXE_DMP_PLAYBACK_MOVIEINFO_FF);
                        break;
                    case E_MPLAYER_TYPE_TEXT:
                        break;
                    default:
                        break;
                }
            }
            if (MApp_ZUI_API_IsWindowVisible(HWND_DMP_PLAYBACK_TEXT_FULL_WINDOW))
            {
                MApp_ZUI_ACT_ExecuteDmpAction( EN_EXE_DMP_PLAYBACK_TEXTINFO_NEXT);
            }

            if(MApp_ZUI_API_IsWindowVisible(HWND_DMP_PLAYBACK_PAGE_INFOBAR))
            {
                MApp_ZUI_ACT_FunctionHotkeyUIMapping(VK_FF);
            }
            return TRUE;
        case VK_REWIND:
            DMP_DBG(printf("hotkey VK_REWIND\n"););
            if(MApp_MPlayer_IsMediaFileInPlaying() && (MApp_DMP_GetDmpFlag()& DMP_FLAG_MEDIA_FILE_PLAYING))
            {
                switch(MApp_MPlayer_QueryCurrentMediaType())
                {
                    case E_MPLAYER_TYPE_MUSIC:
                        MApp_ZUI_ACT_ExecuteDmpAction( EN_EXE_DMP_PLAYBACK_MUSICINFO_FB);
                        break;
                    case E_MPLAYER_TYPE_MOVIE:
                        MApp_ZUI_ACT_ExecuteDmpAction( EN_EXE_DMP_PLAYBACK_MOVIEINFO_FB);
                        break;
                    case E_MPLAYER_TYPE_TEXT:
                        break;
                    default:
                        break;
                }
            }
            if (MApp_ZUI_API_IsWindowVisible(HWND_DMP_PLAYBACK_TEXT_FULL_WINDOW))
            {
                MApp_ZUI_ACT_ExecuteDmpAction( EN_EXE_DMP_PLAYBACK_TEXTINFO_PREV);
            }

            if(MApp_ZUI_API_IsWindowVisible(HWND_DMP_PLAYBACK_PAGE_INFOBAR))
            {
                MApp_ZUI_ACT_FunctionHotkeyUIMapping(VK_REWIND);
            }
            return TRUE;
#if 1//minglin0419
   case VK_PICTURE:
            printf("\r\nVK PICTURE");
            MApp_ZUI_ACT_ExecuteDmpAction(EN_EXE_DMP_HOTKEY_PICTURE);
   break;
#endif
        case VK_AUDIO: // movie audio track test
            DMP_DBG(printf("VK_AUDIO\n"););
            if( MApp_MPlayer_QueryCurrentMediaType() == E_MPLAYER_TYPE_MOVIE
                && MApp_MPlayer_IsMoviePlaying())
            {
#if ENABLE_DVD
                if (MApp_MPlayer_QueryCurrentFileMediaSubType() == E_MPLAYER_SUBTYPE_DVD)
                {
                    U8 ret;

                    DMP_DBG(printf("VK_AUDIO in DVD\n"));
                    ret = MApp_MPlayer_DVD_Command(E_MPLAYER_DVD_CMD_LANGUAGE);

                    return TRUE;
                }
                else
#endif  // ENABLE_DVD
                {
                    U16 u16TotalTrk = MApp_MPlayer_QueryMovieAudioChannelNum();
                    if (u16TotalTrk != MPLAYER_INVALID_INDEX && u16TotalTrk != 0)
                    {
                        U16 u16TrkID = MApp_MPlayer_QueryMovieCurAudioTrackIdx();
                        u16TrkID = (u16TrkID+1)%u16TotalTrk;
                        if(MApp_MPlayer_MovieChangeAudioTrack(u16TrkID) != E_MPLAYER_RET_OK)
                        {
                            DMP_DBG(printf("MApp_MPlayer_MovieChangeProgram fail\n"););
                        }
                        //_enDmpPlayIconType = _enDmpPlayStrType = PLAY_MODE_ICON_CHANGE_AUDIOTRACK;
                        MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_SHOW);
                        MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN, DMP_TIME_MS_PLAY_STATUS_WIN);
                    }
                    else
                    {
                        DMP_DBG(printf("MApp_MPlayer_QueryMovieAudioChannelNum fail or 0\n"););
                    }
                    MApp_ZUI_API_InvalidateWindow(HWND_DMP_PLAYBACK_MOVIEINFO_INFO_AUDIOTRACK_TEXT);
                }
            }
            return TRUE;
        case VK_CHANNEL_MINUS:
        case VK_CHANNEL_PLUS:// movie program test
            DMP_DBG(printf("VK_CHANNEL_PLUS or VK_CHANNEL_MINUS\n"););
            if(MApp_MPlayer_QueryCurrentMediaType()== E_MPLAYER_TYPE_MOVIE
            && MApp_MPlayer_IsMoviePlaying())
            {
                U16 u16TotalPgm = MApp_MPlayer_QueryMovieProgramNum();
                if (u16TotalPgm != MPLAYER_INVALID_INDEX && u16TotalPgm != 0)
                {
                    U16 u16PgmIdx = MApp_MPlayer_QueryMovieCurProgramIdx();
                    if(key == VK_CHANNEL_PLUS)
                    {
                        if( u16PgmIdx < u16TotalPgm -1)
                        {
                            DMP_DBG(printf("channel++\n"););
                            u16PgmIdx++;
                            if (MApp_MPlayer_MovieChangeProgram(u16PgmIdx) == E_MPLAYER_RET_OK)
                            {
                                _MApp_ACTdmp_MovieCancelRepeatAB();
                            }
                            else
                            {
                                DMP_DBG(printf("channel++ fail\n"););
                            }
                        }
                    }
                    else  // VK_CHANNEL_MINUS
                    {
                        if(u16PgmIdx > 0)
                        {
                            DMP_DBG(printf("channel--\n"););
                            u16PgmIdx--;
                            if (MApp_MPlayer_MovieChangeProgram(u16PgmIdx) == E_MPLAYER_RET_OK)
                            {
                                _MApp_ACTdmp_MovieCancelRepeatAB();
                            }
                            else
                            {
                                DMP_DBG(printf("channel-- fail\n"););
                            }
                        }
                    }
                }
                else
                {
                    DMP_DBG(printf("MApp_MPlayer_QueryMovieProgramNum fail or 0\n"););
                }
                MApp_ZUI_API_InvalidateWindow(HWND_DMP_PLAYBACK_MOVIEINFO_INFO_PROGRAM_TEXT);
            }
            return TRUE;
        case VK_POWER:
            {
            // care
                
				Adj_Volume_Off();
				Panel_Backlight_VCC_OFF();
				msAPI_Timer_Delayms(20);
				Panel_VCC_OFF();
			
                MApp_DMP_SetDMPStat(DMP_STATE_GOTO_STANDBY);
                #ifdef ATSC_SYSTEM
                if(MApp_MPlayer_IsMediaFileInPlaying())
                {
                    MApp_MPlayer_Stop();
                    MApp_MPlayer_StopMusic();
                }
                MApp_MPlayer_ExitMediaPlayer();
                //MApp_ZUI_API_ShowWindow(HWND_MAINFRAME,SW_HIDE);
                MApp_ZUI_ACT_TerminateDmp();
    #if (DMP_PHOTO_THUMBNAIL || DMP_MOVIE_THUMBNAIL || DMP_MUSIC_THUMBNAIL)
                _MApp_DMP_ThumbCopyRegion_Destroy();
    #endif
                #else
                MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
                #endif
                return TRUE;
            }
            break;
#ifndef ATSC_SYSTEM
        case VK_HOME:
                hwnd_before = MApp_ZUI_API_GetFocus();
                MApp_ZUI_API_ShowWindow(HWND_DMP_BAR_TRANS, SW_SHOW);
                MApp_ZUI_API_SetFocus(HWND_DMP_BAR);
                MApp_ZUI_API_SetTimer(HWND_DMP_BAR, 0, 3000);
            return TRUE;
#endif
        case VK_VOLUME_PLUS:
        case VK_VOLUME_MINUS:
            {
                DMP_DBG(printf("VK_VOLUME_PLUS MINUS\n"););
                if(MApp_ZUI_API_IsSuccessor(HWND_DMP_VOLUME_LIST, MApp_ZUI_API_GetFocus()))
                {
                    MApp_ZUI_API_ResetTimer(HWND_DMP_VOLUME_LIST, DMP_VOLUME_TIMER);
                }
                else
                {
                //    MApp_ZUI_API_StoreFocusCheckpoint();
                    MApp_ZUI_API_SetTimer(HWND_DMP_VOLUME_LIST, DMP_VOLUME_TIMER, AUDIO_VOLUME_TIME_OUT_MS);
                }
                if(key == VK_VOLUME_PLUS){
#if CUS_SMC_ENABLE_HOTEL_MODE
						if (stGenSetting.g_FactorySetting.HotelMenuHotelModeOperationEnable == ENABLE)
						{
							if ( stGenSetting.g_SoundSetting.Volume < g_u8HotelVolMax) //if ( stGenSetting.g_SoundSetting.Volume < stGenSetting.g_FactorySetting.HotelMenuMaxVolumeSetting)
							{
								stGenSetting.g_SoundSetting.Volume++;
								msAPI_AUD_AdjustAudioFactor(E_ADJUST_VOLUME, stGenSetting.g_SoundSetting.Volume, 0);
							}
						}
						else
#endif
                    if ( stGenSetting.g_SoundSetting.Volume < MAX_NUM_OF_VOL_LEVEL )
                    {
                        stGenSetting.g_SoundSetting.Volume++;
                        msAPI_AUD_AdjustAudioFactor(E_ADJUST_VOLUME, stGenSetting.g_SoundSetting.Volume, 0);
                    }
                    msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_BYUSER_MUTEOFF, E_AUDIOMUTESOURCE_ACTIVESOURCE);
                }
                else
                {
                    // TPV_XM Xue 20120720: if mute on volume dec  unlock mute status
                    if(msAPI_AUD_IsAudioMutedByUser())
                    {
                        MW_AUD_SetSoundMute(SOUND_MUTE_ALL,E_MUTE_ON);
                    }

                    if( stGenSetting.g_SoundSetting.Volume > 0 )
                    {
                        stGenSetting.g_SoundSetting.Volume--;
                        msAPI_AUD_AdjustAudioFactor(E_ADJUST_VOLUME, stGenSetting.g_SoundSetting.Volume, 0);
                    }
                }
#if !ENABLE_NO_AUDIO_INPUT_AUTO_MUTE
                if(stGenSetting.g_SoundSetting.Volume == 0)
                {
#if !(AUDIO_EN_CONTROL_DISABLE)
                    MUTE_On();
#endif
                    //msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_BYUSER_MUTEON, E_AUDIOMUTESOURCE_ACTIVESOURCE);
                }
                else
                {
                    MUTE_Off();
                    //msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_BYUSER_MUTEOFF, E_AUDIOMUTESOURCE_ACTIVESOURCE);
                }
#endif
                /*
#if EAR_PHONE_POLLING
                if (PreEarphoneState != EAR_PHONE_NULL)
                {
                    if(stGenSetting.g_SoundSetting.Volume>0)
                    {
                        EarPhone_ON();
                    }
                    else
                    {
                        EarPhone_OFF();
                    }
                }
#endif*/
#if 0
                if(stGenSetting.g_SoundSetting.Volume>0)
                {
                    MApp_ZUI_API_ShowWindow(HWND_DMP_VOLUME_CONFIG_PANE, SW_SHOW);
                    MApp_UiMenu_MuteWin_Hide();
                //    MApp_ZUI_API_SetFocus(HWND_DMP_VOLUME_CONFIG_BAR);
                    MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_VOLUME_CONFIG_PANE);
                }
                else
                {
                    MApp_ZUI_API_KillTimer(HWND_DMP_VOLUME_LIST, DMP_VOLUME_TIMER);
                    MApp_ZUI_API_ShowWindow(HWND_DMP_VOLUME_CONFIG_PANE, SW_HIDE);
                    MApp_UiMenu_MuteWin_Show();
                    MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_VOLUME_LIST);
                //    MApp_ZUI_API_RestoreFocusCheckpoint();
                }
#else
                MApp_ZUI_API_ShowWindow(HWND_DMP_VOLUME_CONFIG_PANE, SW_SHOW);
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_VOLUME_CONFIG_PANE);
#endif
            }
            break;
        case VK_MENU:
             DMP_DBG(printf("VK_MENU\n"););
            {
                if(MApp_ZUI_API_IsWindowVisible(HWND_DMP_BAR))
                {
                    MApp_ZUI_API_ShowWindow(HWND_DMP_BAR, SW_HIDE);
                    MApp_ZUI_API_SetFocus(hwnd_before);
                }
                else
                {
                    if (MApp_DMP_GetDmpUiState() == DMP_UI_STATE_FILE_SELECT)
                    {
                        MApp_MPlayer_StopPreview();
                    }
                    #if (DMP_PHOTO_THUMBNAIL || DMP_MOVIE_THUMBNAIL || DMP_MUSIC_THUMBNAIL)
                    {
                        _MApp_DMP_ThumbCopyRegion_Destroy();
                        MApp_MPlayer_LeaveThumbnailMode();
                        MApp_DMP_ClearDmpFlag(DMP_FLAG_THUMBNAIL_MODE);
                        MApp_DMP_ClearDmpFlag(DMP_FLAG_THUMBNAIL_PLAYING);
                    }
                    #endif

#if EN_DMP_SEARCH_ALL
                    if (MApp_DMP_GetDmpUiState() == DMP_UI_STATE_FILE_SELECT)
                   {
                       printf("Go to DMP_UI_STATE_MEDIA_SELECT menu \n ");
                       MApp_DMP_UiStateTransition(DMP_UI_STATE_DRIVE_SELECT);
                        return TRUE;
                   }
#endif

                    MApp_DMP_GotoMainMenu();

                }

            }
            return TRUE;
        case VK_INPUT_SOURCE:
            {
                if (MApp_DMP_GetDmpUiState() == DMP_UI_STATE_FILE_SELECT)
                {
                    MApp_MPlayer_StopPreview();
                }
                #if (DMP_PHOTO_THUMBNAIL || DMP_MOVIE_THUMBNAIL || DMP_MUSIC_THUMBNAIL)
                {
                    _MApp_DMP_ThumbCopyRegion_Destroy();
                    MApp_MPlayer_LeaveThumbnailMode();
                    MApp_DMP_ClearDmpFlag(DMP_FLAG_THUMBNAIL_MODE);
                    MApp_DMP_ClearDmpFlag(DMP_FLAG_THUMBNAIL_PLAYING);
                }
                #endif
                MApp_DMP_GotoInputSrcMenu();
            }
            return TRUE;
        case VK_MUTE:
            {
                DMP_DBG(printf("hot key mute\n"););
            #if 0
                MApp_KeyProc_Mute();
            #else
                MApp_KeyProc_DMPMute();
                MApp_DMP_MuteState(TRUE);
                if(MApp_ZUI_API_IsWindowVisible(HWND_DMP_MUTE_PANEL) && MApp_ZUI_API_IsWindowVisible(HWND_DMP_VOLUME_CONFIG_PANE))
                {
                    MApp_ZUI_API_ShowWindow(HWND_DMP_VOLUME_CONFIG_PANE, SW_HIDE);
                }
            #endif
            }
            return TRUE;

        /*
        case VK_BLUE:
            _MApp_ACTdmp_ShowAlertWin(DMP_MSG_TYPE_INVALID_OPERATION);
            return TRUE;
        */
#if ENABLE_DVD
        case VK_BLUE:
            DMP_DBG(printf("VK_BLUE\n"));

            if (MApp_MPlayer_QueryCurrentFileMediaSubType() == E_MPLAYER_SUBTYPE_DVD)
            {
                U8 ret;

                DMP_DBG(printf("VK_BLUE in DVD\n"));
                ret = MApp_MPlayer_DVD_Command(E_MPLAYER_DVD_CMD_TITLE);
            }
            return TRUE;
        case VK_RED:
            DMP_DBG(printf("VK_RED\n"));
            return TRUE;
#endif  // ENABLE_DVD

        case VK_SUBTITLE:
            DMP_DBG(printf("hot VK_SUBTITLE\n"););
            {
                MApp_ZUI_ACT_ExecuteDmpAction(EN_EXE_DMP_PLAYBACK_MOVIEINFO_INFO_SUBTITLE_TEXT_R);
            }
            break;

    #if ENABLE_DVD
        case VK_LEFT:
        case VK_RIGHT:
        case VK_UP:
        case VK_DOWN:
            if(MApp_MPlayer_IsMediaFileInPlaying() &&
                (MApp_DMP_GetDmpFlag() & DMP_FLAG_MEDIA_FILE_PLAYING))
            {
                if ((MApp_ZUI_API_GetFocus() == HWND_DMP_PLAYBACK_TRANSPARENT_BG) &&
                    (MApp_MPlayer_QueryCurrentFileMediaSubType() == E_MPLAYER_SUBTYPE_DVD))
                {
                    U8 ret;

                    switch(key)
                    {
                        case VK_LEFT:
                            DMP_DBG(printf("VK_LEFT in DVD\n"));
                            ret = MApp_MPlayer_DVD_Command(E_MPLAYER_DVD_CMD_LEFT);
                            break;
                        case VK_RIGHT:
                            DMP_DBG(printf("VK_RIGHT in DVD\n"));
                            ret = MApp_MPlayer_DVD_Command(E_MPLAYER_DVD_CMD_RIGHT);
                            break;
                        case VK_UP:
                            DMP_DBG(printf("VK_UP in DVD\n"));
                            ret = MApp_MPlayer_DVD_Command(E_MPLAYER_DVD_CMD_KEYUP);
                            break;
                        case VK_DOWN:
                            DMP_DBG(printf("VK_DOWN in DVD\n"));
                            ret = MApp_MPlayer_DVD_Command(E_MPLAYER_DVD_CMD_DOWN);
                            break;
                        default:
                            break;
                    }

                    return TRUE;
                }
            }
            break;
    #endif  // ENABLE_DVD

    #ifdef ENABLE_SRC_MENU_AUTOCLOSE_AND_SWITCH_SOURCE
        case VK_TV:
        //case VK_AV:
        case VK_HDMI:
        case VK_COMPONENT:
        case VK_PC:
        case VK_DMP:
            MApp_DMP_HotkeyChangeSRC(key);
        return TRUE;
    #endif
	case VK_AV:
			//if(UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_HDMI)
			#if 0
		  	{
			   if(E_OSD_EMPTY != MApp_ZUI_GetActiveOSD())
				 {
					 MApp_ZUI_ACT_ShutdownOSD();
				 }
			   UI_INPUT_SOURCE_TYPE=UI_INPUT_SOURCE_AV;
			   printf("!!~~~~~~~~~~~~~~~INTO AV!~~~~~~~~~~~~~~~~~~~~\n");
			   /*
			   UI_INPUT_SOURCE_TYPE=(E_UI_INPUT_SOURCE)MApp_ZUI_ACT_DecIncValue_Cycle(1,UI_INPUT_SOURCE_TYPE,
									 UI_INPUT_SOURCE_HDMI, UI_INPUT_SOURCE_HDMI+INPUT_HDMI_VIDEO_COUNT-1, 1);
									 */
			   MApp_InputSource_ChangeInputSource(MAIN_WINDOW);
			   MApp_ChannelChange_VariableInit();
			   MApp_TopStateMachine_SetTopState(STATE_TOP_ANALOG_SHOW_BANNER);
			   
		   }
	      #endif
            //if( MApp_GetValiadSource(UI_INPUT_SOURCE_AV))//add lt 130705
            {
                UI_PREV_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_AV;
                if(MApp_MPlayer_IsMusicPlaying())
                {
                    MApp_MPlayer_StopMusic();
                }
                MApp_MPlayer_Stop();
                MApp_DMP_Exit();
                MApp_DMP_GotoPreSrc();
                MApp_InputSource_SetStateFromUSB();
                return TRUE;
            }
        break;

	//BEGIN*********************************************************
	//SMC jayden.chen add for EXIT OSD volume when DMP volume  20130308
        case VK_EXIT:
            //printf("hot VK_EXIT1\n");
		   if(MApp_ZUI_API_IsWindowVisible(HWND_DMP_VOLUME_CONFIG_PANE))
                {
                 		//printf("hot VK_EXIT2\n");
               		MApp_ZUI_API_ShowWindow(HWND_DMP_VOLUME_CONFIG_PANE, SW_HIDE);
   	 			return TRUE;
                }
		   #if CUS_SMC_ENABLE_HOTEL_MODE
		   else if(MApp_ZUI_API_GetFocus()==HWND_DMP_HOTEL_PASSWD_PANEL_OPTION || MApp_ZUI_API_GetFocus()==HWND_DMP_HOTEL_PASSWD_WRONG)
			 {
			 MApp_ZUI_API_KillTimer(HWND_DMP_HOTEL_PASSWD_PANEL, 1);
			 MApp_ZUI_API_ShowWindow(HWND_DMP_HOTEL_PASSWD_PANEL,SW_HIDE);
			 MApp_ZUI_API_RestoreFocusCheckpoint();
			 return TRUE;
			 }
		   else if(MApp_ZUI_API_IsWindowVisible(HWND_DMP_HOTEL_MSG_NOTE))
			 {
			 MApp_ZUI_API_KillTimer(HWND_DMP_HOTEL_MSG_NOTE, 1);
			 MApp_ZUI_API_ShowWindow(HWND_DMP_HOTEL_MSG_NOTE,SW_HIDE);
			 return TRUE;
			 }
		   #endif
	 break;	
	//END*********************************************************
        default:
            break;
    }
    return FALSE;
}
void MApp_ZUI_ACT_TerminateDmp(void)
{
    ZUI_MSG(printf("[]term:mplayer\n");)
    //enMediaPlayerState = _enTargetMediaPlayerState;
    #if ( ENABLE_ARABIC_OSD )
    MMOsdIsOn = FALSE;
    #endif

}
//extern void MApp_Mplayer_SearchFileTypeCount(void);
//static U32 playinfo_bar_key_rep_time=0;

BOOLEAN MApp_ZUI_ACT_ExecuteDmpAction(U16 act)
{
#if ENABLE_PLAYBACK_INFO_AUTO_CLOSE
	if(MApp_ZUI_API_IsSuccessor(HWND_DMP_PLAYBACK_INFO_PANE,MApp_ZUI_API_GetFocus()) \
		|| MApp_ZUI_API_IsWindowVisible(HWND_DMP_PLAYBACK_INFO_PANE))
		{
		if(MApp_ZUI_API_IsExistTimer(HWND_DMP_PLAYBACK_INFO_PANE,0))
			MApp_ZUI_API_ResetTimer(HWND_DMP_PLAYBACK_INFO_PANE,0);
		}
#endif

    switch(act)
    {
    #ifndef ATSC_SYSTEM
        case EN_EXE_DEC_UART_MODE:
        case EN_EXE_INC_UART_MODE:
            DMP_DBG(printf("###   EXE INC/DEC UART\n"));
            _u8UARTMode= (EN_DMP_UART_MODE)MApp_ZUI_ACT_DecIncValue_Cycle(
            act==EN_EXE_INC_UART_MODE,
            _u8UARTMode, UART_NONE, UART_NUM-1, 1);
            DMP_DBG(printf("@@ _u8UARTMode = %d\n",_u8UARTMode));

            if(_u8UARTMode == UART_HK)
              #if (CHIP_FAMILY_TYPE == CHIP_FAMILY_M10) || (CHIP_FAMILY_TYPE == CHIP_FAMILY_M12)
                mdrv_uart_connect(E_UART_PORT0, E_UART_AEON_R2);
              #else
                mdrv_uart_connect(E_UART_PORT0, E_UART_PIU_UART0);
              #endif
            else if(_u8UARTMode == UART_VDEC)
                mdrv_uart_connect(E_UART_PORT0, E_UART_VDEC);
            else if(_u8UARTMode == UART_AEON)
                mdrv_uart_connect(E_UART_PORT0, E_UART_AEON);
            else
                mdrv_uart_connect(E_UART_PORT0, E_UART_TSP); //tmp solution

            MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_BAR_OPTION);
            break;

        case EN_EXE_GOTO_THUMBNAIL:
            DMP_DBG(printf("## EN_EXE_GOTO_THUMBNAIL\n"));
            MApp_ZUI_API_ShowWindow(HWND_DMP_BAR, SW_HIDE);
            MApp_ZUI_API_SetFocus(hwnd_before);
            return TRUE;
    #endif // #ifndef ATSC_SYSTEM

    #if (ENABLE_DRM)
        case EN_EXE_DMP_DRM_WINDOW_DONE:
            DMP_DBG(printf("EN_EXE_DMP_DRM_WINDOW_DONE\n"););
            MApp_MPlayer_PlayDRMFile(FALSE);
            switch(DRM_STATUS)
            {
            case WinViewRental:
                MApp_ZUI_API_ShowWindow(HWND_DMP_DRM_WINDOW, SW_HIDE);
                MApp_ZUI_API_RestoreFocusCheckpoint();
                MApp_DMP_UiStateTransition(DMP_UI_STATE_FILE_SELECT);
            break;
            case WinUnsupported:
                MApp_DMP_UiStateTransition(DMP_UI_STATE_FILE_SELECT);
                break;
            case WinAuthError:
                MApp_DMP_UiStateTransition(DMP_UI_STATE_FILE_SELECT);
                break;
            case WinRentalExpired:
                MApp_DMP_UiStateTransition(DMP_UI_STATE_FILE_SELECT);
                break;
            }
            break;

        case EN_EXE_DMP_DRM_WINDOW_YES:
            DMP_DBG(printf("EN_EXE_DMP_DRM_WINDOW_YES\n"););
            switch(DRM_STATUS)
            {
                case WinViewRental:
                    MApp_ZUI_API_ShowWindow(HWND_DMP_DRM_WINDOW, SW_HIDE);
                    MApp_ZUI_API_RestoreFocusCheckpoint();

                    MApp_MPlayer_PlayDRMFile(TRUE);
                    MApp_SaveDrmSetting();
                    break;
                case WinUnsupported:
                    MApp_DMP_UiStateTransition(DMP_UI_STATE_FILE_SELECT);
                    break;
                case WinAuthError:
                    MApp_DMP_UiStateTransition(DMP_UI_STATE_FILE_SELECT);
                    break;
                case WinRentalExpired:
                    MApp_DMP_UiStateTransition(DMP_UI_STATE_FILE_SELECT);
                    break;
            }
            break;

        case EN_EXE_DMP_DRM_WINDOW_NO:
            if(MApp_VDPlayer_GetInfo(E_VDPLAYER_INFO_ERROR_INFO)==0)
                MApp_MPlayer_PlayDRMFile(FALSE);
            DMP_DBG(printf("EN_EXE_DMP_DRM_WINDOW_NO\n"););
        g_bIsResumePlay = FALSE;
            MApp_MPlayer_PlayDRMFile(FALSE);
            switch(DRM_STATUS)
            {
                default:
                case WinViewRental:
                    MApp_ZUI_API_ShowWindow(HWND_DMP_DRM_WINDOW, SW_HIDE);
                    MApp_DMP_UiStateTransition(DMP_UI_STATE_FILE_SELECT);
                break;
                case WinUnsupported:
                    MApp_DMP_UiStateTransition(DMP_UI_STATE_FILE_SELECT);
                    break;
                case WinAuthError:
                    MApp_DMP_UiStateTransition(DMP_UI_STATE_FILE_SELECT);
                    break;
                case WinRentalExpired:
                    MApp_DMP_UiStateTransition(DMP_UI_STATE_FILE_SELECT);
                    break;
            }
            break;
    #endif //ENABLE_DRM

	case EN_EXE_DMP_HOTKEY_AB:
		switch(MApp_MPlayer_QueryCurrentMediaType())
		{
			case E_MPLAYER_TYPE_MOVIE:
				if(MApp_MPlayer_QueryMoviePlayMode() != E_MPLAYER_MOVIE_NORMAL)
				{
					//error handling
					_MApp_ACTdmp_ShowAlertWin(DMP_MSG_TYPE_INVALID_OPERATION);
					break;
				}
				if(MApp_MPlayer_IsMediaFileInPlaying() &&
					MApp_DMP_GetDmpFlag() & DMP_FLAG_MEDIA_FILE_PLAYING
					&& MApp_MPlayer_QueryCurrentMediaType() == E_MPLAYER_TYPE_MOVIE)
				{
			#if ENABLE_DVD
					if (MApp_MPlayer_QueryCurrentFileMediaSubType() == E_MPLAYER_SUBTYPE_DVD)
					{
						if (!MApp_VDPlayer_DVD_IsAllowed(E_MPLAYER_DVD_CMD_REPEATAB))
						{
							_MApp_ACTdmp_MovieCancelRepeatAB();
							_MApp_ACTdmp_ShowAlertWin(DMP_MSG_TYPE_INVALID_OPERATION);
							return TRUE;
						}
					}
					else
			#endif
					{
						if(!MApp_MPlayer_IsMovieIndexTableExist())
						{
							//error handling
							_MApp_ACTdmp_ShowAlertWin(DMP_MSG_TYPE_INVALID_OPERATION);
							return TRUE;
						}
					}
	
					//FOR TEST - Movie Repeat A->B
					_enDmpPlayStrType =_enDmpPlayIconType =PLAY_MODE_ICON_AB_REPEAT;
					DMP_MovieInfoBarTable[MOVIEINFO_AB_REPEAT][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_AB_REPEAT;
					DMP_MovieInfoBarTable[MOVIEINFO_AB_REPEAT][INFOBAR_STR_IDX] = en_str_DMP_SET_A;
	
					if(_stDmpPlayVar.stMovieInfo.au32MovieRepeatTime[0] == 0xFFFFFFFF
						&& _stDmpPlayVar.stMovieInfo.au32MovieRepeatTime[1] == 0xFFFFFFFF)
					{
					}
					if(_stDmpPlayVar.stMovieInfo.au32MovieRepeatTime[0] == 0xFFFFFFFF)
					{// Repeat A
						_enRepeatABStatus = REPEATAB_MODE_A;
						_enDmpPlayStrType =_enDmpPlayIconType =PLAY_MODE_ICON_SETA;
						DMP_MovieInfoBarTable[MOVIEINFO_AB_REPEAT][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_AB_REPEAT;
						DMP_MovieInfoBarTable[MOVIEINFO_AB_REPEAT][INFOBAR_STR_IDX] = en_str_DMP_SET_B;
						_stDmpPlayVar.stMovieInfo.au32MovieRepeatTime[0] = MApp_VDPlayer_GetInfo(E_VDPLAYER_INFO_CUR_TIME);
						MApp_MPlayer_MovieSetRepeatAB(E_MPLAYER_MOVIE_SET_REPEAT_A, _stDmpPlayVar.stMovieInfo.au32MovieRepeatTime[0] );
						//MApp_DMP_SetDmpFlag(DMP_FLAG_MOVIE_REPEATAB_MODE);
					}
					else if(_stDmpPlayVar.stMovieInfo.au32MovieRepeatTime[1] == 0xFFFFFFFF)
					{// Repeat B
						_enRepeatABStatus = REPEATAB_MODE_AB;
						_enDmpPlayStrType =_enDmpPlayIconType =PLAY_MODE_ICON_AB_LOOP;
						DMP_MovieInfoBarTable[MOVIEINFO_AB_REPEAT][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_AB_REPEAT;
						DMP_MovieInfoBarTable[MOVIEINFO_AB_REPEAT][INFOBAR_STR_IDX] = en_str_DMP_AB_NONE;
						_stDmpPlayVar.stMovieInfo.au32MovieRepeatTime[1] = MApp_VDPlayer_GetInfo(E_VDPLAYER_INFO_CUR_TIME);
						if(_stDmpPlayVar.stMovieInfo.au32MovieRepeatTime[1] > _stDmpPlayVar.stMovieInfo.au32MovieRepeatTime[0])
						{
							MApp_MPlayer_MovieSetRepeatAB(E_MPLAYER_MOVIE_SET_REPEAT_B, _stDmpPlayVar.stMovieInfo.au32MovieRepeatTime[1] );
							MApp_DMP_SetDmpFlag(DMP_FLAG_MOVIE_REPEATAB_MODE);
						}
						else
						{ //Invalid time : B <= A
							//error handling
	
							_MApp_ACTdmp_MovieCancelRepeatAB();
							_MApp_ACTdmp_ShowAlertWin(DMP_MSG_TYPE_INVALID_OPERATION);
						}
					}
					else
					{// Clear A->B
						_MApp_ACTdmp_MovieCancelRepeatAB();
					}
					MApp_ZUI_API_InvalidateWindow(HWND_DMP_PLAYBACK_INFOBAR_GROUP);
					MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_SHOW);
					MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN, DMP_TIME_MS_PLAY_STATUS_WIN);
	
				}
				break;
			case E_MPLAYER_TYPE_MUSIC:
				break;
			case E_MPLAYER_TYPE_PHOTO:
				break;
			case E_MPLAYER_TYPE_TEXT:
				break;
			default:
				break;
		}
		break;
	
	case EN_EXE_DMP_HOTKEY_REPEAT:
	    
				  
		switch(MApp_MPlayer_QueryCurrentMediaType())
		{
			case E_MPLAYER_TYPE_MOVIE:	   
				{
					enumMPlayerRepeatMode eRepeatMode = MApp_MPlayer_QueryRepeatMode();
					 _enDmpPlayStrType =_enDmpPlayIconType =PLAY_MODE_ICON_REPEAT_MODE;
					if(eRepeatMode == E_MPLAYER_REPEAT_NONE)
					{
						MApp_MPlayer_SetRepeatMode(E_MPLAYER_REPEAT_1);
					}
					else if(eRepeatMode == E_MPLAYER_REPEAT_1)
					{
						MApp_MPlayer_SetRepeatMode(E_MPLAYER_REPEAT_ALL);
					}
					else
					{
						MApp_MPlayer_SetRepeatMode(E_MPLAYER_REPEAT_NONE);
					}
				}
				MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_INFOBAR_GROUP);
				//	TODO: need to show the repeat mode on screen?
				 MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_SHOW);
				MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN, DMP_TIME_MS_PLAY_STATUS_WIN);
				break;
				
			case E_MPLAYER_TYPE_MUSIC:
				{
					enumMPlayerRepeatMode eRepeatMode = MApp_MPlayer_QueryRepeatMode();
					 _enDmpPlayStrType =_enDmpPlayIconType =PLAY_MODE_ICON_REPEAT_MODE;
					if(eRepeatMode == E_MPLAYER_REPEAT_NONE)
					{
						MApp_MPlayer_SetRepeatMode(E_MPLAYER_REPEAT_1);
					}
					else if(eRepeatMode == E_MPLAYER_REPEAT_1)
					{
						MApp_MPlayer_SetRepeatMode(E_MPLAYER_REPEAT_ALL);
					}
					else
					{
						MApp_MPlayer_SetRepeatMode(E_MPLAYER_REPEAT_NONE);
					}
				}
				MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_INFOBAR_GROUP);
				// // TODO: need to show the repeat mode on screen?
				 MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_SHOW);
				MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN, DMP_TIME_MS_PLAY_STATUS_WIN);
			 
				break;
			case E_MPLAYER_TYPE_PHOTO:
				{
					enumMPlayerRepeatMode eRepeatMode = MApp_MPlayer_QueryRepeatMode();
					 _enDmpPlayStrType =_enDmpPlayIconType =PLAY_MODE_ICON_REPEAT_MODE;
					if(eRepeatMode == E_MPLAYER_REPEAT_NONE)
					{
						MApp_MPlayer_SetRepeatMode(E_MPLAYER_REPEAT_1);
					}
					else if(eRepeatMode == E_MPLAYER_REPEAT_1)
					{
						MApp_MPlayer_SetRepeatMode(E_MPLAYER_REPEAT_ALL);
					}
					else
					{
						MApp_MPlayer_SetRepeatMode(E_MPLAYER_REPEAT_NONE);
					}
				}
				MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_INFOBAR_GROUP);
	
				//MApp_MPlayer_PhotoChangePlayMode(E_MPLAYER_PHOTO_NORMAL);
				
			// TODO: need to show the repeat mode on screen?
				 MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_SHOW);
				MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN, DMP_TIME_MS_PLAY_STATUS_WIN);
				break;
			case E_MPLAYER_TYPE_TEXT:
				break;
			default:
				break;
		}
	
	   
		break;

        case EN_EXE_CLOSE_CURRENT_OSD:
          #ifdef ATSC_SYSTEM
            MApp_ZUI_API_ShowWindow(HWND_MAINFRAME,SW_HIDE);
          #else
            MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
          #endif
            //_enTargetMediaPlayerState = STATE_MEDIA_PLAYER_CLEAN_UP;
            return TRUE;
        break;

        case EN_EXE_POWEROFF:
            //_enTargetMediaPlayerState = STATE_MEDIA_PLAYER_GOTO_STANDBY;
          #ifdef ATSC_SYSTEM
            if(MApp_MPlayer_IsMediaFileInPlaying())
            {
                MApp_MPlayer_Stop();
                MApp_MPlayer_StopMusic();
            }
            MApp_MPlayer_ExitMediaPlayer();
            //MApp_ZUI_API_ShowWindow(HWND_MAINFRAME,SW_HIDE);
            MApp_ZUI_ACT_TerminateDmp();
          #else
            MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
          #endif
            return TRUE;
        break;

        case EN_EXE_DMP_ALERT_EXIT:
            if(MApp_DMP_GetDmpUiState() == DMP_UI_STATE_LOADING)
            {
                MApp_DMP_UiStateTransition(DMP_UI_STATE_FILE_SELECT);
            }

            if( MApp_DMP_GetDmpFlag() & DMP_FLAG_MEDIA_FILE_PLAYING_ERROR)
            {
                MApp_DMP_UiStateTransition(DMP_UI_STATE_FILE_SELECT);
                MApp_DMP_ClearDmpFlag(DMP_FLAG_MEDIA_FILE_PLAYING_ERROR);
            //    _MApp_DMP_ErrorHandling_GotoDefaultPage(MApp_MPlayer_QueryCurrentMediaType());
            }

            _MApp_ACTdmp_HideAlertWin();
            MApp_ZUI_API_KillTimer(HWND_DMP_ALERT_WINDOW, DMP_TIMER_INVALID_WIN);

            MApp_ZUI_API_ShowWindow(HWND_DMP_FILE_PAGE_PREVIEW_GROUP, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_DMP_FILE_PAGE_PREVIEW_INFO_GROUP, SW_HIDE);
            return TRUE;

        case EN_EXE_DMP_MEDIA_PAGE_SEL:
            DMP_DBG(printf("EN_EXE_DMP_MEDIA_PAGE_SEL >> (%d)\n", MApp_ZUI_API_GetFocus()));
            if(!(MApp_DMP_GetDmpFlag() & DMP_FLAG_DRIVE_CONNECT_OK))
            {
                return TRUE;
            }
            if(HWND_DMP_MEDIA_TYPE_PHOTO == MApp_ZUI_API_GetFocus())
            {
                MApp_MPlayer_SetCurrentMediaType(E_MPLAYER_TYPE_PHOTO, TRUE);
                MApp_DMP_UiStateTransition(DMP_UI_STATE_DRIVE_SELECT);
            }
            else if(HWND_DMP_MEDIA_TYPE_MUSIC == MApp_ZUI_API_GetFocus())
            {
                MApp_MPlayer_SetCurrentMediaType(E_MPLAYER_TYPE_MUSIC, TRUE);
                MApp_DMP_UiStateTransition(DMP_UI_STATE_DRIVE_SELECT);
            }
            else if(HWND_DMP_MEDIA_TYPE_MOVIE == MApp_ZUI_API_GetFocus())
            {
            // stop bgm
                if(MApp_DMP_GetDmpFlag()  & DMP_FLAG_BGM_MODE)
                {
                    MApp_MPlayer_StopMusic();
                    MApp_DMP_ClearDmpFlag(DMP_FLAG_BGM_MODE);
                }
                MApp_MPlayer_SetCurrentMediaType(E_MPLAYER_TYPE_MOVIE, TRUE);
                MApp_DMP_UiStateTransition(DMP_UI_STATE_DRIVE_SELECT);
            }
            else if(HWND_DMP_MEDIA_TYPE_TEXT == MApp_ZUI_API_GetFocus())
            {
                MApp_MPlayer_SetCurrentMediaType(E_MPLAYER_TYPE_TEXT, TRUE);
                MApp_DMP_UiStateTransition(DMP_UI_STATE_DRIVE_SELECT);
            }
            else
            {
                DMP_DBG(printf("[DMP] Failed to set media type!\n"));
                return FALSE;
            }
            return TRUE;
        case EN_EXE_DMP_MEDIA_PAGE_EXIT:
        // clear BGM
            if(MApp_DMP_GetDmpFlag() & DMP_FLAG_BGM_MODE)
            {
                MApp_MPlayer_StopMusic();
                MApp_DMP_ClearDmpFlag(DMP_FLAG_BGM_MODE);
            }
       #if (ENABLE_DMP_SWITCH)
            #else
            MApp_DMP_GotoPreSrc();
            #endif
            return TRUE;
        case EN_EXE_DMP_DRIVE_PAGE_RIGHT:
            {
                if ((_hwndListDriveItem[0]==MApp_ZUI_API_GetFocus()) && (MApp_DMP_GetDrvPageIdx() <= 1))
                {
                    break;
                }
                else
                {
                    U8 u8Idx = MApp_DMP_GetCurDrvIdx();
                    if(u8Idx+1 == MApp_MPlayer_QueryTotalDriveNum())
                    {
                        return TRUE;
                    }
                    else
                    {
                        MApp_DMP_SetCurDrvIdxAndCalPageIdx(u8Idx+1);
                    }
                }
                _MApp_ACTdmp_ShowDrivePage();
            }
            break;
        case EN_EXE_DMP_DRIVE_PAGE_LEFT:
            {
                if (MApp_DMP_GetDrvPageIdx() <= 1)
                {
                    if (_hwndListDriveItem[1]==MApp_ZUI_API_GetFocus())
                    {
                        break;
                    }
                    else if (_hwndListDriveItem[0]==MApp_ZUI_API_GetFocus())
                    {
                        return TRUE;
                    }
                }
                U8 u8Idx = MApp_DMP_GetCurDrvIdx();
                MApp_DMP_SetCurDrvIdxAndCalPageIdx(u8Idx-1);
               _MApp_ACTdmp_ShowDrivePage();
            }
            break;
        case EN_EXE_DMP_DRIVE_PAGE_SEL:
            {
                U8 u8Item = 0;
                for(u8Item = 0; u8Item < DMP_DRIVE_NUM_PER_PAGE; u8Item++)
                {
                    if(_hwndListDriveItem[u8Item] == MApp_ZUI_API_GetFocus())
                    {
                        break;
                    }
                }
                if(u8Item < DMP_DRIVE_NUM_PER_PAGE)
                {
                    U8 u8Idx = (MApp_DMP_GetDrvPageIdx()-1) * DMP_DRIVE_NUM_PER_PAGE + u8Item;
                    //printf("[Drive] %d was selected.\n", u8Idx);
                    if(u8Idx == 0)
                    {
                        MApp_DMP_UiStateTransition(DMP_UI_STATE_MEDIA_SELECT);
                    }
                    else
                    {
                        if(MApp_DMP_RecalculateDriveMappingTable())
                        {
                            if(MApp_MPlayer_ConnectDrive(MApp_DMP_GetDriveFromMappingTable(u8Idx-1)) == E_MPLAYER_RET_OK)
                            {
                                #if EN_DMP_SEARCH_ALL
                                MApp_MPlayer_GetAllFilesInCurDrive();
                                #endif

                                MApp_DMP_UiStateTransition(DMP_UI_STATE_FILE_SELECT);
                            }
                        }
                        else
                        {
                            //Failed to connect drive, back to media type select page
                            MApp_DMP_ClearDmpFlag(DMP_FLAG_DRIVE_CONNECT_OK);
                            MApp_DMP_UiStateTransition(DMP_UI_STATE_MEDIA_SELECT);
                        }
                    }
                }
            }
            break;
        case EN_EXE_DMP_DRIVE_PAGE_EXIT:
            {
                MApp_DMP_UiStateTransition(DMP_UI_STATE_MEDIA_SELECT);
            }
            break;
        case EN_EXE_DMP_FILE_PAGE_RIGHT:
            {
                HWND hwndFocus = MApp_ZUI_API_GetFocus();
                U16 u16ItemIdx = 0;
                DMP_DBG(printf("EN_EXE_DMP_FILE_PAGE_RIGHT\n"););

                if(MApp_MPlayer_QueryCurrentFileIndex(E_MPLAYER_INDEX_CURRENT_DIRECTORY) < MApp_MPlayer_QueryTotalFileNum() - 1)
                {
                }
                else
                {
                    //Already reach to the last item
                    return TRUE;
                }
                for(u16ItemIdx = 0; u16ItemIdx < NUM_OF_PHOTO_FILES_PER_PAGE; u16ItemIdx++)
                {
                    if(hwndFocus == _hwndListFileItem[u16ItemIdx])
                    {
                        break;
                    }
                }
                _MApp_ACTdmp_HidePreviewWin();
                if(u16ItemIdx == NUM_OF_PHOTO_FILES_PER_PAGE-1)
                {
                    if((MApp_MPlayer_QueryCurrentPageIndex() < MApp_MPlayer_QueryTotalPages()-1) &&
                       (MApp_MPlayer_NextPage() == E_MPLAYER_RET_OK))
                    {
                        #if (DMP_PHOTO_THUMBNAIL || DMP_MOVIE_THUMBNAIL || DMP_MUSIC_THUMBNAIL)
                        _MApp_DMP_Thumbnail_ChangePage();
                        #endif
                        MApp_MPlayer_SetCurrentFile(E_MPLAYER_INDEX_CURRENT_PAGE, 0);
                        if(MApp_DMP_IsFileTypeByIdx(MApp_MPlayer_QueryCurrentFileIndex(E_MPLAYER_INDEX_CURRENT_DIRECTORY)))
                        {
                            //File type
                            _MApp_ACTdmp_ShowPreviewWin();
                        }
#ifdef ENABLE_SMC_UI_NEW     /* smc.qxr 20121016 */
                        _MApp_ACTdmp_ShowScrollBar();
#endif
                    }
                    else
                    {
                        //Cannot process 'Next Page'
                        return TRUE;
                    }
                    MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_FILE_SELECT_PAGE);
                }
                else if(u16ItemIdx < NUM_OF_PHOTO_FILES_PER_PAGE)
                {
                    if(MApp_MPlayer_QueryCurrentFileIndex(E_MPLAYER_INDEX_CURRENT_DIRECTORY) <
                       MApp_MPlayer_QueryTotalFileNum() - 1)
                    {
                        _MApp_ACTdmp_HidePreviewWin();
                        MApp_MPlayer_SetCurrentFile(E_MPLAYER_INDEX_CURRENT_PAGE, u16ItemIdx+1);
                        if(MApp_DMP_IsFileTypeByIdx(MApp_MPlayer_QueryCurrentFileIndex(E_MPLAYER_INDEX_CURRENT_DIRECTORY)))
                        {
                            //File type
                            _MApp_ACTdmp_ShowPreviewWin();
                        }
                    }
                    else
                    {
                        //The last item
                        return TRUE;
                    }
                }
                DMP_DBG(printf("[File Page] Current Idx = %u\n", MApp_MPlayer_QueryCurrentFileIndex(E_MPLAYER_INDEX_CURRENT_DIRECTORY)));
                DMP_DBG(printf("[File Page] Current Page = %u\n", MApp_MPlayer_QueryCurrentPageIndex()));
            }
            break;
        case EN_EXE_DMP_FILE_PAGE_LEFT:
            {
                HWND hwndFocus = MApp_ZUI_API_GetFocus();
                U16 u16ItemIdx = 0;
                DMP_DBG(printf("EN_EXE_DMP_FILE_PAGE_LEFT\n"););
                for(u16ItemIdx=0;u16ItemIdx<NUM_OF_PHOTO_FILES_PER_PAGE;u16ItemIdx++)
                {
                    if(hwndFocus == _hwndListFileItem[u16ItemIdx])
                    {
                        break;
                    }
                }
                _MApp_ACTdmp_HidePreviewWin();
                if(u16ItemIdx == 0)
                {
                    if((MApp_MPlayer_QueryCurrentPageIndex() > 0) &&
                       (MApp_MPlayer_PrevPage() == E_MPLAYER_RET_OK))
                    {
                        #if (DMP_PHOTO_THUMBNAIL || DMP_MOVIE_THUMBNAIL || DMP_MUSIC_THUMBNAIL)
                        _MApp_DMP_Thumbnail_ChangePage();
                        #endif
                        MApp_MPlayer_SetCurrentFile(E_MPLAYER_INDEX_CURRENT_PAGE,
                                                    NUM_OF_PHOTO_FILES_PER_PAGE-1);
#ifdef ENABLE_SMC_UI_NEW     /* smc.qxr 20121016 */
                        _MApp_ACTdmp_ShowScrollBar();
#endif
                        if(MApp_DMP_IsFileTypeByIdx(MApp_MPlayer_QueryCurrentFileIndex(E_MPLAYER_INDEX_CURRENT_DIRECTORY)))
                        {
                            //File type
                            _MApp_ACTdmp_ShowPreviewWin();
                        }
                        MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_FILE_SELECT_PAGE);
                    }
                    else if(MApp_MPlayer_QueryCurrentPageIndex() == 0)
                    {
                        return TRUE;
                    }
                }
                else if(u16ItemIdx < NUM_OF_PHOTO_FILES_PER_PAGE)
                {
                    _MApp_ACTdmp_HidePreviewWin();
                    MApp_MPlayer_SetCurrentFile(E_MPLAYER_INDEX_CURRENT_PAGE, u16ItemIdx-1);
                    if(MApp_DMP_IsFileTypeByIdx(MApp_MPlayer_QueryCurrentFileIndex(E_MPLAYER_INDEX_CURRENT_DIRECTORY)))
                    {
                        //File type
                        _MApp_ACTdmp_ShowPreviewWin();
                    }
                }
                DMP_DBG(printf("[File Page] Current Idx = %u\n", MApp_MPlayer_QueryCurrentFileIndex(E_MPLAYER_INDEX_CURRENT_DIRECTORY)));
                DMP_DBG(printf("[File Page] Current Page = %u\n", MApp_MPlayer_QueryCurrentPageIndex()));
            }
            break;
        case EN_EXE_DMP_FILE_PAGE_DOWN:
            {
                HWND hwndFocus = MApp_ZUI_API_GetFocus();
                U16 u16ItemIdx = 0, u16NewIdx = 0, u16FocusIdx = 0;
                #ifdef ENABLE_SMC_UI_NEW     /* smc.qxr 20121016 */
                U8 u8ColumnNum=4;
                #endif
                DMP_DBG(printf("EN_EXE_DMP_FILE_PAGE_DOWN\n"););
                if(MApp_MPlayer_QueryCurrentFileIndex(E_MPLAYER_INDEX_CURRENT_DIRECTORY) < MApp_MPlayer_QueryTotalFileNum() - 1)
                {
                }
                else
                {
                    //Already reach to the last item
                    return TRUE;
                }
                #ifdef ENABLE_SMC_UI_NEW     /* smc.qxr 20121016 */
                    if(MApp_MPlayer_QueryCurrentMediaType()==E_MPLAYER_TYPE_PHOTO)
                    {
                        for(u16ItemIdx=0;u16ItemIdx<NUM_OF_PHOTO_FILES_PER_PAGE;u16ItemIdx++)
                        {
                            if(hwndFocus == _hwndListFileItem[u16ItemIdx])
                            {
                                break;
                            }
                        }
                    }
                    else
                    {
                        for(u16ItemIdx=0;u16ItemIdx<NUM_OF_MUSIC_FILES_PER_PAGE;u16ItemIdx++)
                        {
                            if(hwndFocus == _hwndListFileItem[u16ItemIdx])
                            {
                                break;
                            }
                        }
                    }
                #else
                    for(u16ItemIdx=0;u16ItemIdx<NUM_OF_PHOTO_FILES_PER_PAGE;u16ItemIdx++)
                    {
                        if(hwndFocus == _hwndListFileItem[u16ItemIdx])
                        {
                            break;
                        }
                    }
                #endif

          	   #if (BOE_PHOTO_DISPLAY)//minglin0104// #ifdef ENABLE_SMC_UI_NEW     /* smc.qxr 20121016 */
		   	
			   if(MApp_MPlayer_QueryCurrentMediaType()==E_MPLAYER_TYPE_PHOTO)
                {
                    u16FocusIdx = u16ItemIdx + MApp_MPlayer_QueryCurrentPageIndex()*DMP_NUM_OF_FILES_PER_PAGE;
                    u16NewIdx = u16FocusIdx + DMP_FILE_PAGE_COLUMN_NUM;
                }
                else
			   {
                    u16FocusIdx = u16ItemIdx + MApp_MPlayer_QueryCurrentPageIndex()*DMP_MUSIC_NUM_OF_FILES_PER_PAGE;
                    u16NewIdx = u16FocusIdx + DMP_MUSIC_FILE_PAGE_COLUMN_NUM;
                }
                #else
                    u16FocusIdx = u16ItemIdx + MApp_MPlayer_QueryCurrentPageIndex()*DMP_NUM_OF_FILES_PER_PAGE;
                    u16NewIdx = u16FocusIdx + DMP_FILE_PAGE_COLUMN_NUM;
                #endif
                DMP_DBG(printf("    >> focus idx = %u, new idx = %u [total = %u]\n", u16FocusIdx, u16NewIdx, MApp_MPlayer_QueryTotalFileNum()););
                _MApp_ACTdmp_HidePreviewWin();
                if(u16FocusIdx >= MApp_MPlayer_QueryTotalFileNum()-1)
                {
                    return TRUE;
                }

                #ifdef ENABLE_SMC_UI_NEW     /* smc.qxr 20121016 */
                if(MApp_MPlayer_QueryCurrentMediaType()==E_MPLAYER_TYPE_PHOTO)
                    u8ColumnNum=(NUM_OF_PHOTO_FILES_PER_PAGE-DMP_FILE_PAGE_COLUMN_NUM);
                else
                    u8ColumnNum=(DMP_MUSIC_NUM_OF_FILES_PER_PAGE-DMP_MUSIC_FILE_PAGE_COLUMN_NUM);//DMP_MUSIC_FILE_PAGE_COLUMN_NUM;

                #endif
                #ifdef ENABLE_SMC_UI_NEW     /* smc.qxr 20121016 */
                if(u16ItemIdx >= u8ColumnNum)
                #else
                if(u16ItemIdx >= NUM_OF_PHOTO_FILES_PER_PAGE-DMP_FILE_PAGE_COLUMN_NUM)
                #endif
                {
                    //Need to do 'Next Page'
                    if((MApp_MPlayer_QueryCurrentPageIndex() < MApp_MPlayer_QueryTotalPages()-1) &&
                       (MApp_MPlayer_NextPage() == E_MPLAYER_RET_OK))
                    {
                    #if (DMP_PHOTO_THUMBNAIL || DMP_MOVIE_THUMBNAIL || DMP_MUSIC_THUMBNAIL)
                        _MApp_DMP_Thumbnail_ChangePage();
                    #endif
                        if(u16NewIdx > MApp_MPlayer_QueryTotalFileNum()-1)
                        {
                            //The last item
                            u16NewIdx = MApp_MPlayer_QueryTotalFileNum()-1;
                        }
                        MApp_MPlayer_SetCurrentFile(E_MPLAYER_INDEX_CURRENT_DIRECTORY, u16NewIdx);
                        if(MApp_DMP_IsFileTypeByIdx(MApp_MPlayer_QueryCurrentFileIndex(E_MPLAYER_INDEX_CURRENT_DIRECTORY)))
                        {
                            //File type
                            _MApp_ACTdmp_ShowPreviewWin();
                        }
#ifdef ENABLE_SMC_UI_NEW     /* smc.qxr 20121016 */
                        _MApp_ACTdmp_ShowScrollBar();
#endif
                    }
                    else
                    {
                        //Cannot process 'Next Page' - the last page
                        if(u16NewIdx != u16FocusIdx)
                        {
                            if(u16NewIdx > MApp_MPlayer_QueryTotalFileNum()-1)
                            {
                                //The last item
                                u16NewIdx = MApp_MPlayer_QueryTotalFileNum()-1;
                            }
                            MApp_MPlayer_SetCurrentFile(E_MPLAYER_INDEX_CURRENT_DIRECTORY, u16NewIdx);
                            if(MApp_DMP_IsFileTypeByIdx(MApp_MPlayer_QueryCurrentFileIndex(E_MPLAYER_INDEX_CURRENT_DIRECTORY)))
                            {
                                //File type
                                _MApp_ACTdmp_ShowPreviewWin();
                            }
                        }
                        else
                        {
                            return TRUE;
                        }
                    }
                }
                else// if(u16ItemIdx < NUM_OF_PHOTO_FILES_PER_PAGE)
                {
                    if(u16NewIdx > MApp_MPlayer_QueryTotalFileNum() - 1)
                    {
                        u16NewIdx = MApp_MPlayer_QueryTotalFileNum() - 1;
                    }
                    _MApp_ACTdmp_HidePreviewWin();
                    MApp_MPlayer_SetCurrentFile(E_MPLAYER_INDEX_CURRENT_DIRECTORY, u16NewIdx);
                    if(MApp_DMP_IsFileTypeByIdx(MApp_MPlayer_QueryCurrentFileIndex(E_MPLAYER_INDEX_CURRENT_DIRECTORY)))
                    {
                        //File type
                        _MApp_ACTdmp_ShowPreviewWin();
                    }
                }

                #ifdef ENABLE_SMC_UI_NEW     /* smc.qxr 20121016 */
                if(MApp_MPlayer_QueryCurrentMediaType()==E_MPLAYER_TYPE_PHOTO)
                    MApp_ZUI_API_SetFocus(_hwndListFileItem[u16NewIdx%DMP_NUM_OF_FILES_PER_PAGE]);
                else
                    MApp_ZUI_API_SetFocus(_hwndListFileItem[u16NewIdx%DMP_MUSIC_NUM_OF_FILES_PER_PAGE]);
                #else
                MApp_ZUI_API_SetFocus(_hwndListFileItem[u16NewIdx%DMP_NUM_OF_FILES_PER_PAGE]);
                #endif
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_FILE_SELECT_PAGE);
                DMP_DBG(printf("[File Page] Current Idx = %u\n", MApp_MPlayer_QueryCurrentFileIndex(E_MPLAYER_INDEX_CURRENT_DIRECTORY)));
                DMP_DBG(printf("[File Page] New Idx = %d (set focus to %d item)\n", u16NewIdx, u16NewIdx%DMP_NUM_OF_FILES_PER_PAGE));
                DMP_DBG(printf("[File Page] Current Page = %u\n", MApp_MPlayer_QueryCurrentPageIndex()));
                return TRUE;
            }
            break;
        case EN_EXE_DMP_FILE_PAGE_UP:
            {
                HWND hwndFocus = MApp_ZUI_API_GetFocus();
                U16 u16ItemIdx = 0, u16NewIdx = 0, u16FocusIdx = 0;
                #ifdef ENABLE_SMC_UI_NEW     /* smc.qxr 20121016 */
                U8 u8ColumnNum=4;
                #endif
                DMP_DBG(printf("EN_EXE_DMP_FILE_PAGE_UP\n"););
            #ifdef ENABLE_SMC_UI_NEW     /* smc.qxr 20121016 */
                if(MApp_MPlayer_QueryCurrentMediaType()==E_MPLAYER_TYPE_PHOTO)
                {
                    for(u16ItemIdx=0;u16ItemIdx<NUM_OF_PHOTO_FILES_PER_PAGE;u16ItemIdx++)
                    {
                        if(hwndFocus == _hwndListFileItem[u16ItemIdx])
                        {
                            break;
                        }
                    }
                }
                else
                {
                    for(u16ItemIdx=0;u16ItemIdx<NUM_OF_MUSIC_FILES_PER_PAGE;u16ItemIdx++)
                    {
                        if(hwndFocus == _hwndListFileItem[u16ItemIdx])
                        {
                            break;
                        }
                    }
                }
            #else
                for(u16ItemIdx=0;u16ItemIdx<NUM_OF_PHOTO_FILES_PER_PAGE;u16ItemIdx++)
                {
                    if(hwndFocus == _hwndListFileItem[u16ItemIdx])
                    {
                        break;
                    }
                }
            #endif

            #ifdef ENABLE_SMC_UI_NEW     /* smc.qxr 20121016 */
                if(MApp_MPlayer_QueryCurrentMediaType()==E_MPLAYER_TYPE_PHOTO)
                {
                    u16FocusIdx = u16ItemIdx + MApp_MPlayer_QueryCurrentPageIndex()*DMP_NUM_OF_FILES_PER_PAGE;
                    u16NewIdx = ((u16FocusIdx<DMP_FILE_PAGE_COLUMN_NUM)?0:(u16FocusIdx - DMP_FILE_PAGE_COLUMN_NUM));
                }
                else
                {
                    u16FocusIdx = u16ItemIdx + MApp_MPlayer_QueryCurrentPageIndex()*DMP_MUSIC_NUM_OF_FILES_PER_PAGE;
                    if(MApp_MPlayer_QueryCurrentPageIndex()>0)
                        u16NewIdx = ((u16FocusIdx<DMP_MUSIC_NUM_OF_FILES_PER_PAGE/*DMP_MUSIC_FILE_PAGE_COLUMN_NUM*/)?0:(u16FocusIdx - DMP_MUSIC_FILE_PAGE_COLUMN_NUM));
                    else
                        u16NewIdx = (u16FocusIdx - DMP_MUSIC_FILE_PAGE_COLUMN_NUM);
                }
            #else
                u16FocusIdx = u16ItemIdx + MApp_MPlayer_QueryCurrentPageIndex()*DMP_NUM_OF_FILES_PER_PAGE;
                u16NewIdx = ((u16FocusIdx<DMP_FILE_PAGE_COLUMN_NUM)?0:(u16FocusIdx - DMP_FILE_PAGE_COLUMN_NUM));
            #endif
                DMP_DBG(printf("    >> focus idx = %u, new idx = %u [total = %u]\n", u16FocusIdx, u16NewIdx, MApp_MPlayer_QueryTotalFileNum()););
                _MApp_ACTdmp_HidePreviewWin();
            #ifdef ENABLE_SMC_UI_NEW     /* smc.qxr 20121016 */
            if(MApp_MPlayer_QueryCurrentMediaType()==E_MPLAYER_TYPE_PHOTO)
                u8ColumnNum= DMP_FILE_PAGE_COLUMN_NUM;
            else
                u8ColumnNum= DMP_MUSIC_FILE_PAGE_COLUMN_NUM;
            #endif

                #ifdef ENABLE_SMC_UI_NEW     /* smc.qxr 20121016 */
                if(u16ItemIdx < u8ColumnNum)
                #else
                if(u16ItemIdx < DMP_FILE_PAGE_COLUMN_NUM)
                #endif
                {
                    if((MApp_MPlayer_QueryCurrentPageIndex() > 0) &&
                       (MApp_MPlayer_PrevPage() == E_MPLAYER_RET_OK))
                    {
                        #if (DMP_PHOTO_THUMBNAIL || DMP_MOVIE_THUMBNAIL || DMP_MUSIC_THUMBNAIL)
                        _MApp_DMP_Thumbnail_ChangePage();
                        #endif
                        //MApp_MPlayer_SetCurrentFile(E_MPLAYER_INDEX_CURRENT_DIRECTORY, u16NewIdx);
                    }
                    else// if(MApp_MPlayer_QueryCurrentPageIndex() == 0)
                    {
                        //The first page
                        u16NewIdx = 0;
                    }
                }
                else// if(u16ItemIdx < NUM_OF_PHOTO_FILES_PER_PAGE)
                {
                }
            	_MApp_ACTdmp_HidePreviewWin();
                MApp_MPlayer_SetCurrentFile(E_MPLAYER_INDEX_CURRENT_DIRECTORY, u16NewIdx);
#ifdef ENABLE_SMC_UI_NEW     /* smc.qxr 20121016 */
                _MApp_ACTdmp_ShowScrollBar();
#endif
           #ifdef ENABLE_SMC_UI_NEW     /* smc.qxr 20121016 */
                if(MApp_MPlayer_QueryCurrentMediaType()==E_MPLAYER_TYPE_PHOTO)
                    MApp_ZUI_API_SetFocus(_hwndListFileItem[u16NewIdx%DMP_NUM_OF_FILES_PER_PAGE]);
                else
                    MApp_ZUI_API_SetFocus(_hwndListFileItem[u16NewIdx%DMP_MUSIC_NUM_OF_FILES_PER_PAGE]);
           #else
               MApp_ZUI_API_SetFocus(_hwndListFileItem[u16NewIdx%DMP_NUM_OF_FILES_PER_PAGE]);
           #endif
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_FILE_SELECT_PAGE);
                if(MApp_DMP_IsFileTypeByIdx(MApp_MPlayer_QueryCurrentFileIndex(E_MPLAYER_INDEX_CURRENT_DIRECTORY)))
                {
                    //File type
                    _MApp_ACTdmp_ShowPreviewWin();
                }
                DMP_DBG(printf("[File Page] Current Idx = %u\n", MApp_MPlayer_QueryCurrentFileIndex(E_MPLAYER_INDEX_CURRENT_DIRECTORY)));
                DMP_DBG(printf("[File Page] Current Page = %u\n", MApp_MPlayer_QueryCurrentPageIndex()));
                return TRUE;
            }
            break;
        case EN_EXE_DMP_FILE_PAGE_PAGE_DOWN:
            // TODO: fixme
            DMP_DBG(printf("EN_EXE_DMP_FILE_PAGE_PAGE_DOWN\n"););
            {
                if(MApp_MPlayer_QueryCurrentPageIndex() < MApp_MPlayer_QueryTotalPages()-1)
                {
                    // nextpage exist
                    HWND hwndFocus = MApp_ZUI_API_GetFocus();
                    U16 u16ItemIdx = 0, u16NewIdx = 0, u16FocusIdx = 0;
                    for(u16ItemIdx=0;u16ItemIdx<NUM_OF_PHOTO_FILES_PER_PAGE;u16ItemIdx++)
                    {
                        if(hwndFocus == _hwndListFileItem[u16ItemIdx])
                        {
                            break;
                        }
                    }
                    u16FocusIdx = u16ItemIdx + MApp_MPlayer_QueryCurrentPageIndex()*DMP_NUM_OF_FILES_PER_PAGE;
                    u16NewIdx = u16FocusIdx + NUM_OF_PHOTO_FILES_PER_PAGE;
                    DMP_DBG(printf("    >> focus idx = %u, new idx = %u [total = %u]\n", u16FocusIdx, u16NewIdx, MApp_MPlayer_QueryTotalFileNum()););
                    _MApp_ACTdmp_HidePreviewWin();
                    if(u16NewIdx <= MApp_MPlayer_QueryTotalFileNum()-1)
                    {
                        if(MApp_MPlayer_NextPage() == E_MPLAYER_RET_OK)
                        {
                            #if (DMP_PHOTO_THUMBNAIL || DMP_MOVIE_THUMBNAIL || DMP_MUSIC_THUMBNAIL)
                            _MApp_DMP_Thumbnail_ChangePage();
                            #endif
#ifdef ENABLE_SMC_UI_NEW     /* smc.qxr 20121016 */
                            _MApp_ACTdmp_ShowScrollBar();
#endif
                            MApp_MPlayer_SetCurrentFile(E_MPLAYER_INDEX_CURRENT_DIRECTORY, u16NewIdx);
                            MApp_ZUI_API_SetFocus(_hwndListFileItem[u16NewIdx%DMP_NUM_OF_FILES_PER_PAGE]);
                            if(MApp_DMP_IsFileTypeByIdx(MApp_MPlayer_QueryCurrentFileIndex(E_MPLAYER_INDEX_CURRENT_DIRECTORY)))
                            {
                                //File type
                                _MApp_ACTdmp_ShowPreviewWin();
                            }
                        }
                        else
                        {
                            DMP_DBG(printf("MApp_MPlayer_NextPage fail\n"););
                        }
                    }
                    else
                    {
                        // set index to last file
                        if(MApp_MPlayer_NextPage() == E_MPLAYER_RET_OK)
                        {
                            #if (DMP_PHOTO_THUMBNAIL || DMP_MOVIE_THUMBNAIL || DMP_MUSIC_THUMBNAIL)
                            _MApp_DMP_Thumbnail_ChangePage();
                            #endif
                            U16 u16LastFileIdx = MApp_MPlayer_QueryTotalFileNum()-1;
	                    _MApp_ACTdmp_HidePreviewWin();
                            MApp_MPlayer_SetCurrentFile(E_MPLAYER_INDEX_CURRENT_DIRECTORY, u16LastFileIdx);
                            MApp_ZUI_API_SetFocus(_hwndListFileItem[u16LastFileIdx%DMP_NUM_OF_FILES_PER_PAGE]);
                            if(MApp_DMP_IsFileTypeByIdx(MApp_MPlayer_QueryCurrentFileIndex(E_MPLAYER_INDEX_CURRENT_DIRECTORY)))
                            {
                                //File type
                                _MApp_ACTdmp_ShowPreviewWin();
                            }
                        }
                        else
                        {
                            DMP_DBG(printf("MApp_MPlayer_NextPage fail 1\n"););
                        }
                    }
                }
            }
            MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_FILE_SELECT_PAGE);
            break;
        case EN_EXE_DMP_FILE_PAGE_PAGE_UP:
            DMP_DBG(printf("EN_EXE_DMP_FILE_PAGE_PAGE_UP\n"););
            {
                if(MApp_MPlayer_QueryCurrentPageIndex() > 0)
                {
                    // prepage exist
                    HWND hwndFocus = MApp_ZUI_API_GetFocus();
                    U16 u16ItemIdx = 0, u16NewIdx = 0, u16FocusIdx = 0;
                    for(u16ItemIdx=0;u16ItemIdx<NUM_OF_PHOTO_FILES_PER_PAGE;u16ItemIdx++)
                    {
                        if(hwndFocus == _hwndListFileItem[u16ItemIdx])
                        {
                            break;
                        }
                    }
                    u16FocusIdx = u16ItemIdx + MApp_MPlayer_QueryCurrentPageIndex()*DMP_NUM_OF_FILES_PER_PAGE;
                    u16NewIdx = u16FocusIdx - NUM_OF_PHOTO_FILES_PER_PAGE;
                    DMP_DBG(printf("    >> focus idx = %u, new idx = %u [total = %u]\n", u16FocusIdx, u16NewIdx, MApp_MPlayer_QueryTotalFileNum()););
                    _MApp_ACTdmp_HidePreviewWin();
                    if(MApp_MPlayer_PrevPage() == E_MPLAYER_RET_OK)
                    {
                        #if (DMP_PHOTO_THUMBNAIL || DMP_MOVIE_THUMBNAIL || DMP_MUSIC_THUMBNAIL)
                        _MApp_DMP_Thumbnail_ChangePage();
                        #endif
                    	_MApp_ACTdmp_HidePreviewWin();
#ifdef ENABLE_SMC_UI_NEW     /* smc.qxr 20121016 */
                        _MApp_ACTdmp_ShowScrollBar();
#endif
                        MApp_MPlayer_SetCurrentFile(E_MPLAYER_INDEX_CURRENT_DIRECTORY, u16NewIdx);
                        MApp_ZUI_API_SetFocus(_hwndListFileItem[u16NewIdx%DMP_NUM_OF_FILES_PER_PAGE]);
                        if(MApp_DMP_IsFileTypeByIdx(MApp_MPlayer_QueryCurrentFileIndex(E_MPLAYER_INDEX_CURRENT_DIRECTORY)))
                        {
                            //File type
                            _MApp_ACTdmp_ShowPreviewWin();
                        }
                    }
                    else
                    {
                        DMP_DBG(printf("MApp_MPlayer_PrevPage fail\n"););
                    }
                }
            }
            MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_FILE_SELECT_PAGE);
            break;
		case EN_EXE_DMP_FILE_PAGE_GOBACK:
			{
				DMP_DBG(printf("EN_EXE_DMP_FILE_PAGE_SEL :\n"););
				U16 u16FileIdx = MApp_MPlayer_QueryCurrentFileIndex(E_MPLAYER_INDEX_CURRENT_DIRECTORY);
				MPlayerFileInfo fileInfo;
                _MApp_ACTdmp_HidePreviewWin();
				if(MApp_MPlayer_QueryDirectoryDepth()>0)
				{
						u16FileIdx=1;
				}
				else
				{
						u16FileIdx=0;
				}

				if(u16FileIdx == 0)
				{
					MApp_DMP_UiStateTransition(DMP_UI_STATE_DRIVE_SELECT);
				}
				else if(MApp_MPlayer_QueryFileInfo(E_MPLAYER_INDEX_CURRENT_DIRECTORY,
											  u16FileIdx,
											  &fileInfo) == E_MPLAYER_RET_OK)
				{
						// TODO: refine here
        #if (DMP_PHOTO_THUMBNAIL || DMP_MOVIE_THUMBNAIL || DMP_MUSIC_THUMBNAIL)
						_MApp_DMP_Thumbnail_ChangePage();
        #endif

        #if ENABLE_MPLAYER_RECORD_DIR_ENTRY
						U16 u16DirDepth = MApp_MPlayer_QueryDirectoryDepth();
						if(!(u16DirDepth > 0 && u16FileIdx == 1))
						{
							//printf("Record DIR info ...\n");
							_u16FileIdxByDir[u16DirDepth] = u16FileIdx;
						}
        #endif

						if(MApp_MPlayer_EnterDirectory(E_MPLAYER_INDEX_CURRENT_DIRECTORY,
													   u16FileIdx) == E_MPLAYER_RET_OK)
						{
#ifdef ENABLE_SMC_UI_NEW     /* smc.qxr 20121016 */
							_MApp_ACTdmp_ShowScrollBar();
#endif
							MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_FILE_SELECT_PAGE);
            #if ENABLE_MPLAYER_RECORD_DIR_ENTRY
							if(u16DirDepth > 0 && u16FileIdx == 1)
							{//Go to prev. directory...
								//printf("Go to prev. directory ... (idx = %d)\n", _u16FileIdxByDir[MApp_MPlayer_QueryDirectoryDepth()]);
								MApp_MPlayer_SetCurrentFile(E_MPLAYER_INDEX_CURRENT_DIRECTORY, _u16FileIdxByDir[MApp_MPlayer_QueryDirectoryDepth()]);
                    #ifdef ENABLE_SMC_UI_NEW     /* smc.qxr 20121016 */
								if(MApp_MPlayer_QueryCurrentMediaType()==E_MPLAYER_TYPE_PHOTO)
								{
									MApp_MPlayer_SetCurrentPageIndex(_u16FileIdxByDir[MApp_MPlayer_QueryDirectoryDepth()]/NUM_OF_PHOTO_FILES_PER_PAGE);
									MApp_ZUI_API_SetFocus(_hwndListFileItem[_u16FileIdxByDir[MApp_MPlayer_QueryDirectoryDepth()]%NUM_OF_PHOTO_FILES_PER_PAGE]);
								}
								else
								{
									MApp_MPlayer_SetCurrentPageIndex(_u16FileIdxByDir[MApp_MPlayer_QueryDirectoryDepth()]/NUM_OF_MUSIC_FILES_PER_PAGE);
									MApp_ZUI_API_SetFocus(_hwndListFileItem[_u16FileIdxByDir[MApp_MPlayer_QueryDirectoryDepth()]%NUM_OF_MUSIC_FILES_PER_PAGE]);
								}
                    #else
								MApp_MPlayer_SetCurrentPageIndex(_u16FileIdxByDir[MApp_MPlayer_QueryDirectoryDepth()]/NUM_OF_PHOTO_FILES_PER_PAGE);
								MApp_ZUI_API_SetFocus(_hwndListFileItem[_u16FileIdxByDir[MApp_MPlayer_QueryDirectoryDepth()]%NUM_OF_PHOTO_FILES_PER_PAGE]);
                    #endif
							}
							else
							{
								MApp_MPlayer_StopPreview();
#if ENABLE_BGM
								if(MApp_MPlayer_IsMusicPlaying())
								{
									MApp_MPlayer_StopMusic();
								}
#endif
								MApp_DMP_UiStateTransition(DMP_UI_STATE_DRIVE_SELECT);
							}
            #endif
						}
				}
			return TRUE;
			}
			break;
        case EN_EXE_DMP_FILE_PAGE_SEL:
            {
                DMP_DBG(printf("EN_EXE_DMP_FILE_PAGE_SEL :\n"););
                U16 u16FileIdx = MApp_MPlayer_QueryCurrentFileIndex(E_MPLAYER_INDEX_CURRENT_DIRECTORY);
                MPlayerFileInfo fileInfo;

            #if EN_DMP_SEARCH_ALL
               MApp_ZUI_ACT_ExecuteDmpAction(EN_EXE_DMP_FILE_PAGE_PLAYBACK);
               return TRUE;
            #endif

                if(u16FileIdx == 0)
                {
                    MApp_DMP_UiStateTransition(DMP_UI_STATE_DRIVE_SELECT);
                }
                else if(MApp_MPlayer_QueryFileInfo(E_MPLAYER_INDEX_CURRENT_DIRECTORY,
                                              u16FileIdx,
                                              &fileInfo) == E_MPLAYER_RET_OK)
                {
                    if(fileInfo.eAttribute & E_MPLAYER_FILE_DIRECTORY)
                    {
                        // TODO: refine here
                    #if (DMP_PHOTO_THUMBNAIL || DMP_MOVIE_THUMBNAIL || DMP_MUSIC_THUMBNAIL)
                        _MApp_DMP_Thumbnail_ChangePage();
                    #endif

                    #if ENABLE_MPLAYER_RECORD_DIR_ENTRY
                        U16 u16DirDepth = MApp_MPlayer_QueryDirectoryDepth();
                        if(!(u16DirDepth > 0 && u16FileIdx == 1))
                        {
                            //printf("Record DIR info ...\n");
                            _u16FileIdxByDir[u16DirDepth] = u16FileIdx;
                        }
                    #endif

                        if(MApp_MPlayer_EnterDirectory(E_MPLAYER_INDEX_CURRENT_DIRECTORY,
                                                       u16FileIdx) == E_MPLAYER_RET_OK)
                        {
#ifdef ENABLE_SMC_UI_NEW     /* smc.qxr 20121016 */
                            _MApp_ACTdmp_ShowScrollBar();
#endif
                            MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_FILE_SELECT_PAGE);
                        #if ENABLE_MPLAYER_RECORD_DIR_ENTRY
                            if(u16DirDepth > 0 && u16FileIdx == 1)
                            {//Go to prev. directory...
                                //printf("Go to prev. directory ... (idx = %d)\n", _u16FileIdxByDir[MApp_MPlayer_QueryDirectoryDepth()]);
                                MApp_MPlayer_SetCurrentFile(E_MPLAYER_INDEX_CURRENT_DIRECTORY, _u16FileIdxByDir[MApp_MPlayer_QueryDirectoryDepth()]);
                                #ifdef ENABLE_SMC_UI_NEW     /* smc.qxr 20121016 */
                                if(MApp_MPlayer_QueryCurrentMediaType()==E_MPLAYER_TYPE_PHOTO)
                                {
                                    MApp_MPlayer_SetCurrentPageIndex(_u16FileIdxByDir[MApp_MPlayer_QueryDirectoryDepth()]/NUM_OF_PHOTO_FILES_PER_PAGE);
                                    MApp_ZUI_API_SetFocus(_hwndListFileItem[_u16FileIdxByDir[MApp_MPlayer_QueryDirectoryDepth()]%NUM_OF_PHOTO_FILES_PER_PAGE]);
                                }
                                else
                                {
                                    MApp_MPlayer_SetCurrentPageIndex(_u16FileIdxByDir[MApp_MPlayer_QueryDirectoryDepth()]/NUM_OF_MUSIC_FILES_PER_PAGE);
                                    MApp_ZUI_API_SetFocus(_hwndListFileItem[_u16FileIdxByDir[MApp_MPlayer_QueryDirectoryDepth()]%NUM_OF_MUSIC_FILES_PER_PAGE]);
                                }
                                #else
                                MApp_MPlayer_SetCurrentPageIndex(_u16FileIdxByDir[MApp_MPlayer_QueryDirectoryDepth()]/NUM_OF_PHOTO_FILES_PER_PAGE);
                                MApp_ZUI_API_SetFocus(_hwndListFileItem[_u16FileIdxByDir[MApp_MPlayer_QueryDirectoryDepth()]%NUM_OF_PHOTO_FILES_PER_PAGE]);
                                #endif
                            }
                            else
                        #endif
                            {
                            
#if !BOE_PHOTO_DISPLAY
                                   MApp_ZUI_API_SetFocus(HWND_DMP_PHOTO_PAGE_THUMB_ITEM1);
#else
#ifdef ENABLE_SMC_UI_NEW     /* smc.qxr 20121029 */
                                if(MApp_MPlayer_QueryCurrentMediaType()==E_MPLAYER_TYPE_PHOTO)
                                  MApp_ZUI_API_SetFocus(HWND_DMP_PHOTO_PAGE_THUMB_ITEM1);
                                else
#endif
                                MApp_ZUI_API_SetFocus(HWND_DMP_FILE_PAGE_THUMB_ITEM1);
#endif
                            }
                        }
                    }
                    else
                    {
                        if(fileInfo.eAttribute & E_MPLAYER_FILE_SELECT)
                        {
                            MApp_MPlayer_SetFileUnselected(E_MPLAYER_INDEX_CURRENT_DIRECTORY, u16FileIdx);
                            MApp_ZUI_API_InvalidateAllSuccessors(MApp_ZUI_API_GetFocus());
                        }
                        else
                        {
                            MApp_MPlayer_SetFileSelected(E_MPLAYER_INDEX_CURRENT_DIRECTORY, u16FileIdx);
                            MApp_ZUI_API_InvalidateAllSuccessors(MApp_ZUI_API_GetFocus());
                        }
                    }
                    return TRUE;
                }
            }
            break;
        case EN_EXE_DMP_FILE_PAGE_EXIT:
            {
                MApp_MPlayer_StopPreview();
        #if ENABLE_BGM
            if(MApp_MPlayer_IsMusicPlaying())
            {
                MApp_MPlayer_StopMusic();
            }
        #endif
                MApp_DMP_UiStateTransition(DMP_UI_STATE_DRIVE_SELECT);
            }
            break;
			PLAYBACK:
        case EN_EXE_DMP_FILE_PAGE_PLAYBACK:
            {
                MApp_ZUI_API_EnableWindow(HWND_DMP_PLAYBACK_INFOBAR_GROUP,TRUE);
                // check if there is files need to be played
                // put some initial variable or initial call before mapp_mplayer_play
                m_u16PlayErrorNum = 0;
                U16 u16LastFileIdx = MApp_MPlayer_QueryTotalFileNum() - 1;
                MPlayerFileInfo FileInfo;
                MApp_DMP_ClearDmpFlag(DMP_FLAG_MEDIA_FILE_PLAYING_ERROR);
                MApp_MPlayer_QueryFileInfo(E_MPLAYER_INDEX_CURRENT_DIRECTORY,u16LastFileIdx,&FileInfo);
                if( !(FileInfo.eAttribute & E_MPLAYER_FILE_DIRECTORY) /*for no-select files*/
                    || MApp_MPlayer_QuerySelectedFileNum(MApp_MPlayer_QueryCurrentMediaType() /*for selected files*/))
                {
                    _u8InfoBarIdx = 0;

                    MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_PAGE,SW_HIDE);
                    _MApp_ACTdmp_HidePreviewWin();
                    // TODO: set this flag earlier!!! care this
                    MApp_DMP_SetDmpFlag(DMP_FLAG_MEDIA_FILE_PLAYING);

                    enumMPlayerMediaType eMediaType = MApp_MPlayer_QueryCurrentMediaType();
                    //MApp_MPlayer_SetRepeatMode(E_MPLAYER_REPEAT_NONE);
                    MApp_DMP_UiStateTransition(DMP_UI_STATE_LOADING);
                    DMP_DBG(printf("EN_EXE_DMP_FILE_PAGE_PLAYBACK type %u\n",eMediaType););

                    if(MApp_MPlayer_QuerySelectedFileNum(eMediaType))
                    {
                        MApp_MPlayer_SetPlayMode(E_MPLAYER_PLAY_SELECTED_FROM_CURRENT);
                    }
                    else
                    {
                        MApp_MPlayer_SetPlayMode(E_MPLAYER_PLAY_ONE_DIRECTORY_FROM_CURRENT);
                    }
                    // TODO: repeat mode?
                    if ((MApp_MPlayer_QueryRepeatMode() != E_MPLAYER_REPEAT_ALL) && (MApp_MPlayer_QueryRepeatMode() != E_MPLAYER_REPEAT_NONE) && (MApp_MPlayer_QueryRepeatMode() != E_MPLAYER_REPEAT_1))
                    {
                        MApp_MPlayer_SetRepeatMode(E_MPLAYER_REPEAT_ALL);
                    }

                    switch(eMediaType)
                    {
                        // TODO: fix me: every type of media
                        case E_MPLAYER_TYPE_PHOTO:
                        {
				 MApp_DMP_SetDmpFlag(DMP_FLAG_MEDIA_FILE_PLAYING);
                            // put here or notify:"before play one file"?
                            if(MApp_MPlayer_QueryPhotoPlayMode() != E_MPLAYER_PHOTO_NORMAL)
                            {
                                MApp_MPlayer_PhotoChangePlayMode(E_MPLAYER_PHOTO_NORMAL);
                            }
                            // reset slide show timer(in MPlayer)

                            MApp_MPlayer_SetPhotoSlideShowDelayTime(DEFAULT_PHOTO_SLIDESHOW_DELAY_TIME);
                        }
                        break;
                        case E_MPLAYER_TYPE_MUSIC:
                        {
                            // TODO: fix me
                            if(MApp_MPlayer_QueryMusicPlayMode() != E_MPLAYER_MUSIC_NORMAL)
                            {
                                MApp_MPlayer_MusicChangePlayMode(E_MPLAYER_MUSIC_NORMAL);
                                // open music info page
                            }
		#if ENABLE_BGM
		              if(MApp_MPlayer_IsMusicPlaying())
			        {
			             MApp_MPlayer_StopMusic();
		               }
		#endif

                            MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_MUSIC_EQ_GROUP, DMP_TIMER_EQ_PLAY, DMP_TIME_MS_EQ_PLAY);
                        }
                        break;
                        case E_MPLAYER_TYPE_MOVIE:
                        {
                             switch(MApp_GetMenuLanguage())
                             {
                                  case LANGUAGE_POLISH:
                                       MApp_MPlayer_SetSubtitleCharsetType(SUBTITLE_CHARSET_CP1250);
                                       break;
                                  case LANGUAGE_RUSSIAN:
                                       MApp_MPlayer_SetSubtitleCharsetType(SUBTITLE_CHARSET_CP1251);
                                       break;
                                  case LANGUAGE_PORTUGUESE:
                                  case LANGUAGE_SPANISH:
                                       MApp_MPlayer_SetSubtitleCharsetType(SUBTITLE_CHARSET_CP1252);
                                       break;
                               #if (ENABLE_DTMB_CHINA_APP || ENABLE_ATV_CHINA_APP || ENABLE_DVBC_PLUS_DTMB_CHINA_APP||CHINESE_SIMP_FONT_ENABLE ||CHINESE_BIG5_FONT_ENABLE)
                                  case LANGUAGE_CHINESE:
                                       MApp_MPlayer_SetSubtitleCharsetType(SUBTITLE_CHARSET_GBK);
                                       break;
                               #endif
                                  default:
                                       MApp_MPlayer_SetSubtitleCharsetType(SUBTITLE_CHARSET_DEFAULT);
                                       break;
                            }

                            // TODO : need to find a time or stage to initialize
                            // these variables....
                            // dont touch vdplayer before mapp_mplayer_play()!!
                            //MApp_MPlayer_MovieSetRepeatAB(E_MPLAYER_MOVIE_SET_REPEAT_AB_NONE);

                        }
                        break;
                        default:
                            break;
                    }
                }
                else
                {
                    // there is no media files...
                }
            }
            break;
        case EN_EXE_DMP_FILE_PAGE_SUBMENU:
            {
                _MApp_ACTdmp_HidePreviewWin();
                MApp_ZUI_API_ShowWindow(HWND_DMP_FILE_PAGE_SUB_MENU_RED,SW_HIDE);
                _MApp_ACTdmp_ShowSubMenu();
            }
            break;
        case EN_EXE_DMP_SUBMENU_EXIT:
            {
                _MApp_ACTdmp_HideSubMenu();
                MApp_ZUI_API_ShowWindow(HWND_DMP_FILE_PAGE_SUB_MENU_RED,SW_SHOW);
            }
            break;
        case EN_EXE_DMP_SUBMENU_SEL:
            {
                if(MApp_ZUI_API_GetFocus() == HWND_DMP_FILE_PAGE_SUBMENU_DELETE)
                {
                    if(_MApp_ACTdmp_File_Delete())
                    {
                        #if (DMP_PHOTO_THUMBNAIL || DMP_MOVIE_THUMBNAIL || DMP_MUSIC_THUMBNAIL)
                        _MApp_DMP_Thumbnail_ChangePage();
                        #endif
                    }
                    else
                    {
                        //Failed to delete file
                        _MApp_ACTdmp_ShowAlertWin(DMP_MSG_TYPE_INVALID_OPERATION);
                    }
                }
                else if(MApp_ZUI_API_GetFocus() == HWND_DMP_FILE_PAGE_SUBMENU_COPY)
                {
                    if(MApp_MPlayer_QueryCurrentFileSystemType() == FILE_SYSTEM_TYPE_NTFS)
                    { //NTFS
                        _MApp_ACTdmp_ShowAlertWin(DMP_MSG_TYPE_INVALID_OPERATION);
                    }
                    else
                    {
                          if(_MApp_ACTdmp_File_Copy())
                          {
                          }
                          else
                          {
                             //Failed to copy file
                            _MApp_ACTdmp_ShowAlertWin(DMP_MSG_TYPE_INVALID_OPERATION);
                          }
                    }
                }
                else if(MApp_ZUI_API_GetFocus() == HWND_DMP_FILE_PAGE_SUBMENU_PASTE)
                {
                    //_MApp_ACTdmp_File_Paste will handle error cases by itself.
                    _MApp_ACTdmp_File_Paste();
                }
                else
                {
                    _MApp_ACTdmp_HideSubMenu();
                    MApp_ZUI_API_ShowWindow(HWND_DMP_FILE_PAGE_SUB_MENU_RED,SW_SHOW);
                }
            }
            break;
        case EN_EXE_DMP_PROGRESS_EXIT:
            if(MApp_DMP_GetDmpUiState() == DMP_UI_STATE_FILE_SELECT)
            {
                MApp_MPlayer_CopyPaste_UserBreak();
            }
            break;

        /*PLAYBACK_INFOBAR*/
        case EN_EXE_DMP_PLAYBACK_INFOBAR_LEFT:
        DMP_DBG(printf(" - EN_EXE_DMP_PLAYBACK_INFOBAR_LEFT\n"));
        {
            U8 u8InfoBarMax=0;
            switch(MApp_MPlayer_QueryCurrentMediaType())
            {
                case E_MPLAYER_TYPE_MOVIE:
                    u8InfoBarMax = u8MovieInfoBarMax;
                    break;
                case E_MPLAYER_TYPE_MUSIC:
                    u8InfoBarMax = u8MusicInfoBarMax;
                    break;
                case E_MPLAYER_TYPE_PHOTO:
                    u8InfoBarMax = u8PhotoInfoBarMax;
                    break;
                case E_MPLAYER_TYPE_TEXT:
                    u8InfoBarMax = u8TextInfoBarMax;
                    break;
                default:
                    break;
            }
            if (_u8InfoBarIdx >= DMP_INFOBAR_ICON_NUM)
            {
                if (_u8InfoBarIdx+DMP_INFOBAR_ICON_NUM > u8InfoBarMax)
                {
                    S32 i;
                    for (i = DMP_INFOBAR_ICON_NUM; i > u8InfoBarMax -_u8InfoBarIdx; i--)
                    {
                        MApp_ZUI_API_EnableWindow(_hwndListInfoBar[i-1], TRUE);
                    }
                }
                _u8InfoBarIdx-= DMP_INFOBAR_ICON_NUM;
                 MApp_ZUI_API_SetFocus(HWND_DMP_PLAYBACK_INFOBAR_ITEM8);
            }
            MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_INFOBAR_GROUP);
            return TRUE;
        }
        break;
        case EN_EXE_DMP_PLAYBACK_INFOBAR_RIGHT:
        DMP_DBG(printf(" - EN_EXE_DMP_PLAYBACK_INFOBAR_RIGHT\n"));
        {
            U8 u8InfobarIdx = _u8InfoBarIdx + 1; // 1 base
            u8InfobarIdx += (MApp_ZUI_API_GetFocus() - HWND_DMP_PLAYBACK_INFOBAR_ITEM1)/3;
            U8 u8InfoBarMax=0;
            switch(MApp_MPlayer_QueryCurrentMediaType())
            {
                case E_MPLAYER_TYPE_MOVIE:
                    u8InfoBarMax = u8MovieInfoBarMax;
                    break;
                case E_MPLAYER_TYPE_MUSIC:
                    u8InfoBarMax = u8MusicInfoBarMax;
                    break;
                case E_MPLAYER_TYPE_PHOTO:
                    u8InfoBarMax = u8PhotoInfoBarMax;
                    break;
                case E_MPLAYER_TYPE_TEXT:
                    u8InfoBarMax = u8TextInfoBarMax;
                    break;
                default:
                    break;
            }
            //last term
            if (u8InfobarIdx == u8InfoBarMax)
            {
                return TRUE;
            }
            //not 8th term in current infobar page, do navigation
            else if(u8InfobarIdx < (_u8InfoBarIdx + DMP_INFOBAR_ICON_NUM))
            {
                return FALSE;
            }
            //8th  term in current infobar page
            else
            {
                S32 i;
                _u8InfoBarIdx+=DMP_INFOBAR_ICON_NUM;
                // if next page is last page
                if (_u8InfoBarIdx+DMP_INFOBAR_ICON_NUM > u8InfoBarMax)
                {
                    for ( i = DMP_INFOBAR_ICON_NUM; i > u8InfoBarMax -_u8InfoBarIdx; i--)
                    {
                        MApp_ZUI_API_EnableWindow(_hwndListInfoBar[i-1], FALSE);
                    }
                }
                MApp_ZUI_API_SetFocus(HWND_DMP_PLAYBACK_INFOBAR_ITEM1);
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_INFOBAR_GROUP);
                return TRUE;
            }
        }
        break;
        case EN_EXE_DMP_PLAYBACK_INFOBAR_SELECT:
        {
            U16 focushwnd = MApp_ZUI_API_GetFocus();
            U32 i,j;
            for( i = 0; i < DMP_INFOBAR_ICON_NUM ; i++)
            {
                if(focushwnd == _hwndListInfoBar[i])
                {
                    break;
                }
            }
            switch(MApp_MPlayer_QueryCurrentMediaType())
            {
                case E_MPLAYER_TYPE_MOVIE:
                    j = (_u8InfoBarIdx+i);
                    return MApp_ZUI_ACT_ExecuteDmpAction(DMP_MovieInfoBarTable[j][INFOBAR_ACT_IDX]);
                case E_MPLAYER_TYPE_MUSIC:
                    j = (_u8InfoBarIdx+i);
                    return MApp_ZUI_ACT_ExecuteDmpAction(DMP_MusicInfoBarTable[j][INFOBAR_ACT_IDX]);
                case E_MPLAYER_TYPE_PHOTO:
                    j = (_u8InfoBarIdx+i);
                    return MApp_ZUI_ACT_ExecuteDmpAction(DMP_PhotoInfoBarTable[j][INFOBAR_ACT_IDX]);
                case E_MPLAYER_TYPE_TEXT:
                    j = (_u8InfoBarIdx+i);
                    return MApp_ZUI_ACT_ExecuteDmpAction(DMP_TextInfoBarTable[j][INFOBAR_ACT_IDX]);
                default:
                    break;
            }
        }
        break;
   //
        case EN_EXE_DMP_PLAYBACK_BG_EXIT:
            DMP_DBG(printf("EN_EXE_DMP_PLAYBACK_BG_EXIT\n"););
            _u8InfoBarIdx = 0;
          #if ENABLE_DVD
            if (MApp_MPlayer_QueryCurrentFileMediaSubType() == E_MPLAYER_SUBTYPE_DVD)
            {
                DMP_DBG(printf("VK_STOP in DVD\n"));

                MApp_MPlayer_Stop();
                MApp_MPlayer_StopMusic();
                MApp_DMP_ClearDmpFlag(DMP_FLAG_MEDIA_FILE_PLAYING);
                msAPI_Scaler_SetBlueScreen_Origin(TRUE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
                MApi_XC_GenerateBlackVideo( ENABLE, MAIN_WINDOW );
                MApp_DMP_UiStateTransition(DMP_UI_STATE_FILE_SELECT);
            }
            else
          #endif  // ENABLE_DVD
            {
                switch(MApp_MPlayer_QueryCurrentMediaType())
                {
                    case E_MPLAYER_TYPE_MOVIE:
                        _MApp_ACTdmp_MovieCancelRepeatAB();
                        MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_NORMAL);//bruce.lee add for test 20120619
                        MApp_MPlayer_Stop();
                        //if(MApp_MPlayer_IsCurrentExternalSubtitleAvailable() == E_MPLAYER_RET_OK)
                        {
#if (ENABLE_SUBTITLE_DMP)
                            MApp_MPlayer_DisableSubtitle();
#endif
                            MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_SUBTITLE_PAGE, SW_HIDE);
                            MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_SUBTITLE_PAGE);
                        }
                    break;
                    case E_MPLAYER_TYPE_MUSIC:
                        // go into BGM mode !!
                        //MApp_DMP_SetDmpFlag(DMP_FLAG_BGM_MODE);
                         MApp_MPlayer_StopMusic();
                        if(MApp_MPlayer_IsCurrentLRCLyricAvailable() == E_MPLAYER_RET_OK)
                        {
                            MApp_MPlayer_DisableLRCLyric();
                            memset((U8*)_stDmpPlayVar.stMusicInfo.MPlayerLyricBuf, 0, DMP_STRING_BUF_SIZE);
                            MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_LYRIC_PAGE, SW_HIDE);
                            MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_LYRIC_PAGE);
                        }
                        _u32MusicCurrentTime = 0;
                        MApp_ZUI_API_InvalidateWindow(HWND_DMP_PLAYBACK_PAGE_TIME_GROUP);
                        MApp_ZUI_CTL_PercentProgressBar_SetPercentage(0);
                        MApp_ZUI_API_KillTimer(HWND_DMP_PLAYBACK_MUSIC_EQ_GROUP, DMP_TIMER_EQ_PLAY);
                        MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_MUSIC_EQ_GROUP,SW_HIDE);
                        MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_LYRIC_PAGE, SW_HIDE);

                    break;
                    default:
	     	      //SCM jayden.chen add for not exit BG mp3 play when photo Backgroud play 20130308	
	     	  	//USBͨ���£�ͼƬ���ʱ�������֣�ֱ�Ӱ������ء������޷�ֹͣ
	     		if(MApp_MPlayer_IsMusicPlaying())
	     		{
	     			//	printf("MApp_MPlayer_Stop1\n");		
	     				MApp_MPlayer_StopMusic();
	     		}	
                        MApp_MPlayer_Stop();
                        break;
                }
                msAPI_Scaler_SetBlueScreen_Origin(TRUE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);

                //MApp_MPlayer_StopMusic();
                MApp_DMP_ClearDmpFlag(DMP_FLAG_MEDIA_FILE_PLAYING);
                //MApi_XC_GenerateBlackVideo( ENABLE, MAIN_WINDOW );
                MApp_DMP_UiStateTransition(DMP_UI_STATE_FILE_SELECT);
                MApp_ZUI_API_InvalidateWindow(HWND_MAINFRAME);
            }
            // set the file_select index and current page index
            // TODO: across dir, across drive?
            {
                U16 u16PlayingIdx = 0;
                // TODO: fix photo type
                if (!MApp_MPlayer_Change2TargetPath(MApp_MPlayer_QueryCurrentPlayingList()))
                {
                    DMP_DBG(printf("MApp_MPlayer_Change2TargetPath fail EXIT\n");)
                }

                u16PlayingIdx = MApp_MPlayer_QueryCurrentPlayingFileIndex();
                MApp_MPlayer_SetCurrentPageIndex(u16PlayingIdx/NUM_OF_PHOTO_FILES_PER_PAGE);
                DMP_DBG(printf("\n### Current playing idx : %d\n", u16PlayingIdx););
                if(MApp_MPlayer_SetCurrentFile(E_MPLAYER_INDEX_CURRENT_DIRECTORY, u16PlayingIdx) != E_MPLAYER_RET_OK)
                {
                    DMP_DBG(printf("MApp_MPlayer_SetCurrentFile fail 1\n"););
                    MApp_MPlayer_SetCurrentFile(E_MPLAYER_INDEX_CURRENT_DIRECTORY, 0);
                    MApp_MPlayer_SetCurrentPageIndex(0);
                }
            }
            break;
        case EN_EXE_DMP_PLAYBACK_BG_INFO:
            {
                DMP_DBG(printf("EN_EXE_DMP_PLAYBACK_BG_INFO\n"););
              #if ENABLE_DVD
                if (MApp_MPlayer_QueryCurrentFileMediaSubType() == E_MPLAYER_SUBTYPE_DVD)
                {
                    U8 ret;

                    DMP_DBG(printf("VK_ENTER in DVD\n"));
                    ret = MApp_MPlayer_DVD_Command(E_MPLAYER_DVD_CMD_ENTER);
                    if (!ret)
                        _MApp_ACTdmp_Playback_ShowInfoWin(MApp_MPlayer_QueryCurrentMediaType());
                }
                else
              #endif  // ENABLE_DVD
                _MApp_ACTdmp_Playback_ShowInfoWin(MApp_MPlayer_QueryCurrentMediaType());
                //_MApp_ZUI_ACTdmp_OperateSubtitle();
            }
            break;

        case EN_EXE_DMP_PLAYBACK_INFO_CLOSE:
            DMP_DBG(printf("EN_EXE_DMP_PLAYBACK_INFO_CLOSE\n"););
            {
                _MApp_ACTdmp_Playback_HideInfoWin();
               // _MApp_ZUI_ACTdmp_OperateSubtitle();
            }
            break;

//=========MOVIEINFO_info key=============
        case EN_EXE_DMP_PLAYBACK_MOVIEINFO_PLAYLIST:
            {
                DMP_DBG(printf("EN_EXE_DMP_PLAYBACK_INFO_PLAYLIST\n"););
                u8CurrentPlaylistPageIdx = 0;
                u8CurrentPlaylistTotalPage = 1;
                _MApp_ACTdmp_Playback_ShowPlaylistWin(E_MPLAYER_TYPE_MOVIE, TRUE);
            }
            break;
        case EN_EXE_DMP_PLAYBACK_MOVIEINFO_NEXT:
          #if ENABLE_DVD
            if (MApp_MPlayer_QueryCurrentFileMediaSubType() == E_MPLAYER_SUBTYPE_DVD)
            {
                U8 ret;

                DMP_DBG(printf("VK_NEXT in DVD\n"));
                ret = MApp_MPlayer_DVD_Command(E_MPLAYER_DVD_CMD_NEXT);
            }
            else
          #endif  // ENABLE_DVD
            {
                //if(MApp_MPlayer_IsCurrentExternalSubtitleAvailable() == E_MPLAYER_RET_OK)
                {
#if (ENABLE_SUBTITLE_DMP)
                   MApp_MPlayer_DisableSubtitle();
#endif
                   MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_SUBTITLE_PAGE, SW_HIDE);
                }
                MApp_MPlayer_PlayNextFile();
            }
            m_u16PlayErrorNum = 0;
            DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PAUSE;
            DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Pause;
            _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_NEXT;
            MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_SHOW);
            MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN, DMP_TIME_MS_PLAY_STATUS_WIN);
            MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_INFOBAR_GROUP);
            break;
        case EN_EXE_DMP_PLAYBACK_MOVIEINFO_PREV:
          #if ENABLE_DVD
            if (MApp_MPlayer_QueryCurrentFileMediaSubType() == E_MPLAYER_SUBTYPE_DVD)
            {
                U8 ret;

                DMP_DBG(printf("VK_PREV1 in DVD\n"));
                ret = MApp_MPlayer_DVD_Command(E_MPLAYER_DVD_CMD_PREV);
            }
            else
          #endif  // ENABLE_DVD
            {
                //if(MApp_MPlayer_IsCurrentExternalSubtitleAvailable() == E_MPLAYER_RET_OK)
                {
#if (ENABLE_SUBTITLE_DMP)
                    MApp_MPlayer_DisableSubtitle();
#endif
                    MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_SUBTITLE_PAGE, SW_HIDE);
                }
                g_bPlayPrev = TRUE;
                MApp_MPlayer_PlayPrevFile();
            }
            m_u16PlayErrorNum = 0;
            DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PAUSE;
            DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Pause;
            _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_PREVIOUS;
            MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_SHOW);
            MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN, DMP_TIME_MS_PLAY_STATUS_WIN);
            MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_INFOBAR_GROUP);
            break;
#if ENABLE_DRM
        case EN_EXE_DMP_PLAYBACK_MOVIEINFO_BEGIN:
            m_u16PlayErrorNum = 0;
            DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PAUSE;
            DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Pause;
            _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_PREVIOUS;
            MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_SHOW);
            MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN, DMP_TIME_MS_PLAY_STATUS_WIN);
            MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PREV_BUTTON_CLICK_WIN, DMP_TIME_MS_PREV_BUTTON_CLICK_WIN);
            MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_INFOBAR_GROUP);
            break;

        case EN_EXE_DMP_PLAYBACK_MOVIEINFO_PREV_CLICK:
            if (msAPI_Timer_DiffTimeFromNow(u32PrevButtonTimer) > DMP_TIME_MS_PREV_BUTTON_CLICK_WIN)
            {
                MApp_ZUI_ACT_ExecuteDmpAction( EN_EXE_DMP_PLAYBACK_MOVIEINFO_BEGIN);
            }
            else
            {
                MApp_ZUI_ACT_ExecuteDmpAction( EN_EXE_DMP_PLAYBACK_MOVIEINFO_PREV);
                MApp_ZUI_API_KillTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PREV_BUTTON_CLICK_WIN);
            }
            u32PrevButtonTimer = msAPI_Timer_GetTime0();
            break;
#endif
        case EN_EXE_DMP_PLAYBACK_MOVIEINFO_SF:
        #if DMP_UI_BMPSUBTITLE_EXCLUSIVE
            bUIexist = TRUE;
        #endif
            {
                enumMPlayerMoviePlayMode ePlayMode = MApp_MPlayer_QueryMoviePlayMode();
                 _MApp_ACTdmp_MovieCancelRepeatAB();
                DMP_MovieInfoBarTable[MOVIEINFO_AB_REPEAT][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_AB_REPEAT;
                DMP_MovieInfoBarTable[MOVIEINFO_AB_REPEAT][INFOBAR_STR_IDX] = en_str_DMP_SET_A;
                if(!(ePlayMode >= E_MPLAYER_MOVIE_SF_2X && ePlayMode <= E_MPLAYER_MOVIE_SF_32X))
                {
                    MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_SF_2X);
                    _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_SF2X;
                    DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PAUSE;
                    DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Pause;
                }
                else if(ePlayMode == E_MPLAYER_MOVIE_SF_2X)
                {
                    MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_SF_4X);
                    _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_SF4X;
                }
                else if(ePlayMode == E_MPLAYER_MOVIE_SF_4X)
                {
                    MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_SF_8X);
                    _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_SF8X;
                }
                else if(ePlayMode == E_MPLAYER_MOVIE_SF_8X)
                {
                    MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_SF_16X);
                    _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_SF16X;
                }
                else if(ePlayMode == E_MPLAYER_MOVIE_SF_16X)
                {
                    MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_NORMAL);
                    _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_PLAY;
                }
                if (MApp_ZUI_API_IsExistTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN))
                {
                    MApp_ZUI_API_KillTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN);
                }
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_INFOBAR_GROUP);
                MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_SHOW);
                if (_enDmpPlayIconType == PLAY_MODE_ICON_PLAY)
                {
                    MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN, DMP_TIME_MS_PLAY_STATUS_WIN);
                }
            }
        #if DMP_UI_BMPSUBTITLE_EXCLUSIVE
            bUIexist = FALSE;
        #endif
            break;

        case EN_EXE_DMP_PLAYBACK_MOVIEINFO_SD:
        #if DMP_UI_BMPSUBTITLE_EXCLUSIVE
            bUIexist = TRUE;
        #endif
            {
                _MApp_ACTdmp_MovieCancelRepeatAB();
                DMP_MovieInfoBarTable[MOVIEINFO_AB_REPEAT][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_AB_REPEAT;
                DMP_MovieInfoBarTable[MOVIEINFO_AB_REPEAT][INFOBAR_STR_IDX] = en_str_DMP_SET_A;
                DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PLAY;
                DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Play;
                _enDmpPlayStrType = _enDmpPlayIconType = PLAY_MODE_ICON_SD;
                MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_STEP);
                MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_SHOW);
                MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN, DMP_TIME_MS_PLAY_STATUS_WIN);
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_INFOBAR_GROUP);
            }
        #if DMP_UI_BMPSUBTITLE_EXCLUSIVE
            bUIexist = FALSE;
        #endif
            break;

        case EN_EXE_DMP_PLAYBACK_MOVIEINFO_FF:
        #if DMP_UI_BMPSUBTITLE_EXCLUSIVE
            bUIexist = TRUE;
        #endif
          #if ENABLE_DVD
            if (MApp_MPlayer_QueryCurrentFileMediaSubType() == E_MPLAYER_SUBTYPE_DVD)
            {
                U8 ret;

                DMP_DBG(printf("VK_FF in DVD\n"));

                if (!MApp_VDPlayer_DVD_IsAllowed(E_MPLAYER_DVD_CMD_FF))
                    break;

                ret = MApp_MPlayer_DVD_Command(E_MPLAYER_DVD_CMD_FF);

                switch (ret)
                {
                    case 1:
                    _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_FF2X;
                    DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PAUSE;
                    DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Pause;
                        break;
                    case 2:
                    _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_FF4X;
                    DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PAUSE;
                    DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Pause;
                        break;
                    case 3:
                    _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_FF8X;
                    DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PAUSE;
                    DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Pause;
                        break;
                    case 4:
                    _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_FF16X;
                    DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PAUSE;
                    DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Pause;
                        break;
                     case 5:
                    _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_FF32X;
                    DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PAUSE;
                    DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Pause;
                        break;
                    case 6:
                    _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_PLAY;
                    DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PAUSE;
                    DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Pause;
                        break;
                }
                if (MApp_ZUI_API_IsExistTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN))
                {
                    MApp_ZUI_API_KillTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN);
                }
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_INFOBAR_GROUP);
                MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_SHOW);
                if (_enDmpPlayIconType == PLAY_MODE_ICON_PLAY)
                {
                    MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN, DMP_TIME_MS_PLAY_STATUS_WIN);
                }
            }
            else
          #endif  // ENABLE_DVD
            {
                enumMPlayerMoviePlayMode ePlayMode = MApp_MPlayer_QueryMoviePlayMode();
                 _MApp_ACTdmp_MovieCancelRepeatAB();
                DMP_MovieInfoBarTable[MOVIEINFO_AB_REPEAT][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_AB_REPEAT;
                DMP_MovieInfoBarTable[MOVIEINFO_AB_REPEAT][INFOBAR_STR_IDX] = en_str_DMP_SET_A;
                if(!(ePlayMode >= E_MPLAYER_MOVIE_FF_2X && ePlayMode <= E_MPLAYER_MOVIE_FF_32X))
                {
                    MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_FF_2X);
                    _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_FF2X;
                    DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PAUSE;
                    DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Pause;
                }
                else if(ePlayMode == E_MPLAYER_MOVIE_FF_2X)
                {
                    MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_FF_4X);
                    _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_FF4X;
                    DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PAUSE;
                    DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Pause;
                }
                else if(ePlayMode == E_MPLAYER_MOVIE_FF_4X)
                {
                    MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_FF_8X);
                    _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_FF8X;
                    DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PAUSE;
                    DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Pause;
                }
                else if(ePlayMode == E_MPLAYER_MOVIE_FF_8X)
                {
                    MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_FF_16X);
                    _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_FF16X;
                    DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PAUSE;
                    DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Pause;
                }
#if ENABLE_DMP_32X
                else if(ePlayMode == E_MPLAYER_MOVIE_FF_16X)
                {
                    MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_FF_32X);
                    _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_FF32X;
                    DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PAUSE;
                    DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Pause;
                }
                 else if(ePlayMode == E_MPLAYER_MOVIE_FF_32X)
                {
                    MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_NORMAL);
                    _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_PLAY;
                    DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PAUSE;
                    DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Pause;
                }
#else
                else if(ePlayMode == E_MPLAYER_MOVIE_FF_16X)
                {
                    MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_NORMAL);
                    _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_PLAY;
                    DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PAUSE;
                    DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Pause;
                }

#endif
                {
                    MApp_ZUI_API_KillTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN);
                }
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_INFOBAR_GROUP);
                MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_SHOW);
                if (_enDmpPlayIconType == PLAY_MODE_ICON_PLAY)
                {
                    MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN, DMP_TIME_MS_PLAY_STATUS_WIN);
                }
            }
            #if DMP_UI_BMPSUBTITLE_EXCLUSIVE
            bUIexist = FALSE;
            #endif
            break;

        case EN_EXE_DMP_PLAYBACK_MOVIEINFO_FB:
        #if DMP_UI_BMPSUBTITLE_EXCLUSIVE
            bUIexist = TRUE;
        #endif
          #if ENABLE_DVD
            if (MApp_MPlayer_QueryCurrentFileMediaSubType() == E_MPLAYER_SUBTYPE_DVD)
            {
                U8 ret;

                DMP_DBG(printf("VK_FB in DVD\n"));

                if (!MApp_VDPlayer_DVD_IsAllowed(E_MPLAYER_DVD_CMD_FF))
                    break;

                ret = MApp_MPlayer_DVD_Command(E_MPLAYER_DVD_CMD_FB);

                switch (ret)
                {
                    case 1:
                        _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_FB2X;
                        DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PAUSE;
                        DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Pause;
                        break;
                    case 2:
                        _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_FB4X;
                        DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PAUSE;
                        DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Pause;
                        break;
                    case 3:
                        _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_FB8X;
                        DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PAUSE;
                        DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Pause;
                        break;
                    case 4:
                        _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_FB16X;
                        DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PAUSE;
                        DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Pause;
                        break;
                    case 5:
                        _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_FB32X;
                        DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PAUSE;
                        DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Pause;
                        break;
                    case 6:
                        _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_PLAY;
                        DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PAUSE;
                        DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Pause;
                        break;
                    default:
                        break;
                }
                if (MApp_ZUI_API_IsExistTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN))
                {
                    MApp_ZUI_API_KillTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN);
                }
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_INFOBAR_GROUP);
                MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_SHOW);
                if (_enDmpPlayIconType == PLAY_MODE_ICON_PLAY || _enDmpPlayIconType == PLAY_MODE_ICON_FB_INVALID)
                {
                    MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN, DMP_TIME_MS_PLAY_STATUS_WIN);
                }
            }
            else
          #endif
            {
                if(MApp_MPlayer_IsMovieIndexTableExist())
                {
                    enumMPlayerMoviePlayMode ePlayMode = MApp_MPlayer_QueryMoviePlayMode();
                    _MApp_ACTdmp_MovieCancelRepeatAB();
                    DMP_MovieInfoBarTable[MOVIEINFO_AB_REPEAT][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_AB_REPEAT;
                    DMP_MovieInfoBarTable[MOVIEINFO_AB_REPEAT][INFOBAR_STR_IDX] = en_str_DMP_SET_A;
                    if(!(ePlayMode >= E_MPLAYER_MOVIE_FB_2X && ePlayMode <= E_MPLAYER_MOVIE_FB_32X))
                    {
                        MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_FB_2X);
                        _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_FB2X;
                        DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PAUSE;
                        DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Pause;
                    }
                    else if(ePlayMode == E_MPLAYER_MOVIE_FB_2X)
                    {
                        MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_FB_4X);
                        _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_FB4X;
                        DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PAUSE;
                        DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Pause;
                    }
                    else if(ePlayMode == E_MPLAYER_MOVIE_FB_4X)
                    {
                        MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_FB_8X);
                        _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_FB8X;
                        DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PAUSE;
                        DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Pause;
                    }
                    else if(ePlayMode == E_MPLAYER_MOVIE_FB_8X)
                    {
                        MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_FB_16X);
                        _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_FB16X;
                        DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PAUSE;
                        DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Pause;
                    }
#if ENABLE_DMP_32X
                    else if(ePlayMode == E_MPLAYER_MOVIE_FB_16X)
                    {
                        MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_FB_32X);
                        _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_FB32X;
                        DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PAUSE;
                        DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Pause;
                    }
                    else if(ePlayMode == E_MPLAYER_MOVIE_FB_32X)
                    {
                        MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_NORMAL);
                        _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_PLAY;
                        DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PAUSE;
                        DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Pause;
                    }
#else
                    else if(ePlayMode == E_MPLAYER_MOVIE_FB_16X)
                    {
                        MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_NORMAL);
                        _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_PLAY;
                        DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PAUSE;
                        DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Pause;
                    }
#endif

                }
                else
                {
                    MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_NORMAL);
                    _enDmpPlayStrType = _enDmpPlayIconType = PLAY_MODE_ICON_FB_INVALID;
                    DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PAUSE;
                    DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Pause;
                }
                if (MApp_ZUI_API_IsExistTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN))
                {
                    MApp_ZUI_API_KillTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN);
                }
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_INFOBAR_GROUP);
                MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_SHOW);
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_STATUS_GROUP);
                if ((_enDmpPlayIconType == PLAY_MODE_ICON_PLAY) || (_enDmpPlayIconType == PLAY_MODE_ICON_FB_INVALID))
                {
                    MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN, DMP_TIME_MS_PLAY_STATUS_WIN);
                }
            }
            #if DMP_UI_BMPSUBTITLE_EXCLUSIVE
            bUIexist = FALSE;
            #endif
            break;
        case EN_EXE_DMP_PLAYBACK_MOVIEINFO_PLAY_PAUSE:
            {
                enumMPlayerMoviePlayMode eMoviePlayMode = MApp_MPlayer_QueryMoviePlayMode();

            #if ENABLE_DVD
                if (MApp_MPlayer_QueryCurrentFileMediaSubType() == E_MPLAYER_SUBTYPE_DVD)
                {
                    U8 ret;

                    if (!MApp_VDPlayer_DVD_IsAllowed(E_MPLAYER_DVD_CMD_PLAY_PAUSE))
                        break;

                    ret = MApp_MPlayer_DVD_Command(E_MPLAYER_DVD_CMD_PLAY_PAUSE);
                    if (ret == 1)
                    {
                        _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_PAUSE;
                        DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PLAY;
                        DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Play;
                    }
                    else if (ret == 2)
                    {
                        _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_PLAY;
                        DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PAUSE;
                        DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Pause;
                    }
                }
                else
            #endif
                {
                if(eMoviePlayMode == E_MPLAYER_MOVIE_STOP)
                {
                    break;
                }
                if((eMoviePlayMode != E_MPLAYER_MOVIE_PAUSE) &&
                   (eMoviePlayMode != E_MPLAYER_MOVIE_STEP) )
                {
                    MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_PAUSE);
                    _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_PAUSE;
                    DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PLAY;
                    DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Play;
                    MApp_ZUI_API_KillTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN);
                    MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_INFOBAR_GROUP);
                    MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_SHOW);
                }
                else
                {
                    MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_NORMAL);
                    _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_PLAY;
                    DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PAUSE;
                    DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Pause;
                    MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_INFOBAR_GROUP);
                    MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_SHOW);
                    MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN, DMP_TIME_MS_PLAY_STATUS_WIN);
                }
            	}
            }
            break;
        case EN_EXE_DMP_PLAYBACK_MOVIEINFO_STOP:
            DMP_DBG(printf("EN_EXE_DMP_PLAYBACK_MOVIEINFO_STOP\n"););
            MApp_ZUI_ACT_ExecuteDmpAction(EN_EXE_DMP_PLAYBACK_BG_EXIT);
/*
            _u8InfoBarIdx = 0;
        #if ENABLE_DVD
            if (MApp_MPlayer_QueryCurrentFileMediaSubType() == E_MPLAYER_SUBTYPE_DVD)
            {
                DMP_DBG(printf("VK_STOP in DVD\n"));
                MApp_MPlayer_Stop();
                MApp_MPlayer_StopMusic();
                MApp_DMP_ClearDmpFlag(DMP_FLAG_MEDIA_FILE_PLAYING);
                msAPI_Scaler_SetBlueScreen(TRUE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
                MApi_XC_GenerateBlackVideo( ENABLE, MAIN_WINDOW );
                MApp_DMP_UiStateTransition(DMP_UI_STATE_FILE_SELECT);
            }
            else
        #endif  // ENABLE_DVD
            {
                _MApp_ACTdmp_MovieCancelRepeatAB();
                if(MApp_MPlayer_IsCurrentExternalSubtitleAvailable() == E_MPLAYER_RET_OK)
                {
                    MApp_MPlayer_DisableSubtitle();
                    MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_SUBTITLE_PAGE, SW_HIDE);
                    MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_SUBTITLE_PAGE);
                }
                msAPI_Scaler_SetBlueScreen(TRUE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
                MApp_MPlayer_Stop();
                MApp_MPlayer_StopMusic();
                MApp_DMP_ClearDmpFlag(DMP_FLAG_MEDIA_FILE_PLAYING);
                MApp_DMP_UiStateTransition(DMP_UI_STATE_FILE_SELECT);
                MApp_ZUI_API_InvalidateWindow(HWND_MAINFRAME);
            }
            // set the file_select index and current page index
            // TODO: across dir, across drive?
            {
                U16 u16PlayingIdx = 0;
                if (!MApp_MPlayer_Change2TargetPath(MApp_MPlayer_QueryCurrentPlayingList()))
                {
                    DMP_DBG(printf("MApp_MPlayer_Change2TargetPath fail EXIT\n");)
                }
                u16PlayingIdx = MApp_MPlayer_QueryCurrentPlayingFileIndex();
                MApp_MPlayer_SetCurrentPageIndex(u16PlayingIdx/NUM_OF_MOVIE_FILES_PER_PAGE);
                DMP_DBG(printf("\n### Current playing idx : %d\n", u16PlayingIdx););
                if(MApp_MPlayer_SetCurrentFile(E_MPLAYER_INDEX_CURRENT_DIRECTORY, u16PlayingIdx) != E_MPLAYER_RET_OK)
                {
                    DMP_DBG(printf("MApp_MPlayer_SetCurrentFile fail 1\n"););
                    MApp_MPlayer_SetCurrentFile(E_MPLAYER_INDEX_CURRENT_DIRECTORY, 0);
                    MApp_MPlayer_SetCurrentPageIndex(0);
                }
            }
*/
            break;
        case EN_EXE_DMP_PLAYBACK_MOVIEINFO_GOTO_TIME:
        {
            _u8Hour = 0;
            _u8Minute = 0;
            _u8Second = 0;
            MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_MOVIEINFO_GOTOTIME_GROUP, SW_SHOW);
            MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_MOVIEINFO_GOTOTIME_GROUP);
            MApp_ZUI_API_SetFocus(HWND_DMP_PLAYBACK_MOVIEINFO_GOTOTIME_HOUR_DIGIT1);
        }
            break;
        case EN_EXE_DMP_MOVIEINFO_GOTOTIME_WIN_NUM0:
        case EN_EXE_DMP_MOVIEINFO_GOTOTIME_WIN_NUM1:
        case EN_EXE_DMP_MOVIEINFO_GOTOTIME_WIN_NUM2:
        case EN_EXE_DMP_MOVIEINFO_GOTOTIME_WIN_NUM3:
        case EN_EXE_DMP_MOVIEINFO_GOTOTIME_WIN_NUM4:
        case EN_EXE_DMP_MOVIEINFO_GOTOTIME_WIN_NUM5:
        case EN_EXE_DMP_MOVIEINFO_GOTOTIME_WIN_NUM6:
        case EN_EXE_DMP_MOVIEINFO_GOTOTIME_WIN_NUM7:
        case EN_EXE_DMP_MOVIEINFO_GOTOTIME_WIN_NUM8:
        case EN_EXE_DMP_MOVIEINFO_GOTOTIME_WIN_NUM9:
            {
            U8 u8digit = 0;
            if(MApp_ZUI_API_GetFocus() == HWND_DMP_PLAYBACK_MOVIEINFO_GOTOTIME_HOUR_DIGIT1)
            {
                u8digit = _u8Hour % 10;
                _u8Hour = (U8)(act - EN_EXE_DMP_MOVIEINFO_GOTOTIME_WIN_NUM0) * 10 + u8digit;
            }
            else if(MApp_ZUI_API_GetFocus() == HWND_DMP_PLAYBACK_MOVIEINFO_GOTOTIME_HOUR_DIGIT2)
            {
                u8digit = (_u8Hour / 10) * 10;
                _u8Hour = (U8)(act - EN_EXE_DMP_MOVIEINFO_GOTOTIME_WIN_NUM0) + u8digit;
            }
            else if(MApp_ZUI_API_GetFocus() == HWND_DMP_PLAYBACK_MOVIEINFO_GOTOTIME_MINUTE_DIGIT1)
            {
                u8digit = _u8Minute % 10;
                _u8Minute = (U8)(act - EN_EXE_DMP_MOVIEINFO_GOTOTIME_WIN_NUM0) * 10 + u8digit;
            }
            else if(MApp_ZUI_API_GetFocus() == HWND_DMP_PLAYBACK_MOVIEINFO_GOTOTIME_MINUTE_DIGIT2)
            {
                u8digit = (_u8Minute / 10) * 10;
                _u8Minute = (U8)(act - EN_EXE_DMP_MOVIEINFO_GOTOTIME_WIN_NUM0) + u8digit;
            }
            else if(MApp_ZUI_API_GetFocus() == HWND_DMP_PLAYBACK_MOVIEINFO_GOTOTIME_SEC_DIGIT1)
            {
                u8digit = _u8Second % 10;
                _u8Second = (U8)(act - EN_EXE_DMP_MOVIEINFO_GOTOTIME_WIN_NUM0) * 10 + u8digit;
            }
            else if(MApp_ZUI_API_GetFocus() == HWND_DMP_PLAYBACK_MOVIEINFO_GOTOTIME_SEC_DIGIT2)
            {
                u8digit = (_u8Second / 10) * 10;
                _u8Second = (U8)(act - EN_EXE_DMP_MOVIEINFO_GOTOTIME_WIN_NUM0) + u8digit;
            }
            //invalid time?
            if(_u8Minute >= 60) //simon:20120425
            {
                _u8Minute = 59;
            }
            if(_u8Second >= 60) //simon:20120425
            {
                _u8Second = 59;
            }
            //printf("[Time] %02d:%02d:%02d\n", _u8Hour, _u8Minute, _u8Second);
            if(MApp_ZUI_API_GetFocus() != HWND_DMP_PLAYBACK_MOVIEINFO_GOTOTIME_OK)
            {
                MApp_ZUI_API_SetFocus((HWND)(MApp_ZUI_API_GetFocus()+1));
            }
        }
        break;
        case EN_EXE_DMP_MOVIEINFO_GOTOTIME_WIN_EXIT:
        {
            enumMPlayerMediaType eMediaType= MApp_MPlayer_QueryCurrentMediaType();
            switch (eMediaType)
            {
                case E_MPLAYER_TYPE_MOVIE:
                    {
                        _u8Hour = 0;
                        _u8Minute = 0;
                        _u8Second = 0;
                        MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_MOVIEINFO_GOTOTIME_GROUP, SW_HIDE);
                        _MApp_ACTdmp_MovieCancelRepeatAB();
                        DMP_MovieInfoBarTable[MOVIEINFO_AB_REPEAT][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_AB_REPEAT;
                        DMP_MovieInfoBarTable[MOVIEINFO_AB_REPEAT][INFOBAR_STR_IDX] = en_str_DMP_SET_A;
                        MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_INFO_PANE, SW_SHOW);

                        if(MOVIEINFO_GOTO_TIME< _u8InfoBarIdx)
                        {
                            MApp_ZUI_API_SetFocus(_hwndListInfoBar[MOVIEINFO_GOTO_TIME+u8MovieInfoBarMax -_u8InfoBarIdx]);
                        }
                        else
                        {
                            MApp_ZUI_API_SetFocus(_hwndListInfoBar[MOVIEINFO_GOTO_TIME - _u8InfoBarIdx]);
                        }
                    }
                    break;
                case E_MPLAYER_TYPE_MUSIC:
                    {
                        _u8Hour = 0;
                        _u8Minute = 0;
                        _u8Second = 0;
                        MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_MOVIEINFO_GOTOTIME_GROUP, SW_HIDE);
                        MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_INFO_PANE, SW_SHOW);

                        if(MUSICINFO_GOTO_TIME< _u8InfoBarIdx)
                        {
                            MApp_ZUI_API_SetFocus(_hwndListInfoBar[MUSICINFO_GOTO_TIME+u8MusicInfoBarMax -_u8InfoBarIdx]);
                        }
                        else
                        {
                            MApp_ZUI_API_SetFocus(_hwndListInfoBar[MUSICINFO_GOTO_TIME - _u8InfoBarIdx]);
                        }
                    }
                    break;
                default:
                    break;
            }
        }
            break;
        case EN_EXE_DMP_MOVIEINFO_GOTOTIME_WIN_SELECT:
        {
            if(MApp_ZUI_API_GetFocus() == HWND_DMP_PLAYBACK_MOVIEINFO_GOTOTIME_OK)
            {
                enumMPlayerMediaType eMediaType= MApp_MPlayer_QueryCurrentMediaType();
                switch (eMediaType)
                {
                    case E_MPLAYER_TYPE_MOVIE:
                    {
                        _MApp_ACTdmp_MovieCancelRepeatAB();
                        DMP_MovieInfoBarTable[MOVIEINFO_AB_REPEAT][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_AB_REPEAT;
                        DMP_MovieInfoBarTable[MOVIEINFO_AB_REPEAT][INFOBAR_STR_IDX] = en_str_DMP_SET_A;
                        MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_INFO_PANE, SW_SHOW);
                        U32 u32GotoTimeMs = (_u8Second+_u8Minute*60+_u8Hour*3600)*1000;
                        MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_MOVIEINFO_GOTOTIME_GROUP, SW_HIDE);
                        if(MOVIEINFO_GOTO_TIME< _u8InfoBarIdx)
                        {
                            MApp_ZUI_API_SetFocus(_hwndListInfoBar[MOVIEINFO_GOTO_TIME+u8MovieInfoBarMax -_u8InfoBarIdx]);
                        }
                        else
                        {
                            MApp_ZUI_API_SetFocus(_hwndListInfoBar[MOVIEINFO_GOTO_TIME - _u8InfoBarIdx]);
                        }
                        // To do : process GOTO TIME.
                        //printf("[Time] Go : %02d:%02d:%02d (%ld)\n", _u8Hour, _u8Minute, _u8Second, u32GotoTimeMs);
                        _u8Hour = 0;
                        _u8Minute = 0;
                        _u8Second = 0;

                        if(u32GotoTimeMs > MApp_VDPlayer_GetInfo(E_VDPLAYER_INFO_TOTAL_TIME))
                        { // Invalid operation
                            //_MApp_MediaPlayer_ShowMessageBox(MOVIE_MESSAGE_TYPE_GOTO_TIME_EXCEED);
                            // TODO: error handling
                            _MApp_ACTdmp_ShowAlertWin(DMP_MSG_TYPE_INVALID_OPERATION);
                           MApp_ZUI_API_SetTimer(HWND_DMP_ALERT_WINDOW, DMP_TIMER_INVALID_WIN, DMP_TIME_MS_INVALID_WIN);
                        }
                        else
                        {
                            // 1. Cancel Repeat AB Mode
                            enumMPlayerRet eRet=E_MPLAYER_RET_FAIL;
                            if(MApp_DMP_GetDmpFlag()& DMP_FLAG_MOVIE_REPEATAB_MODE)
                            {
                                _MApp_ACTdmp_MovieCancelRepeatAB();
                            //    MApp_ZUI_API_ShowWindow(HWND_DMP_MOVIE_INFO_ICON_ADVENCE_GROUP, SW_SHOW);
                            }
                            // 2. Disable trick play --> Normal play
                            if(MApp_MPlayer_QueryMoviePlayMode() != E_MPLAYER_MOVIE_NORMAL)
                            {
                                MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP,SW_HIDE);
                                MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_NORMAL);
                            }

                            eRet=MApp_MPlayer_SetPlayPosition(u32GotoTimeMs,FALSE);
                            if(eRet==E_MPLAYER_RET_FAIL)
                            {
                                // TODO: error handling
                               _MApp_ACTdmp_ShowAlertWin(DMP_MSG_TYPE_INVALID_OPERATION);
                                MApp_ZUI_API_SetTimer(HWND_DMP_ALERT_WINDOW, DMP_TIMER_INVALID_WIN, DMP_TIME_MS_INVALID_WIN);
                            }
                        }
                    }
                        break;

                    case E_MPLAYER_TYPE_MUSIC:
                    {
                        MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_INFO_PANE, SW_SHOW);
                        U32 u32GotoTime = _u8Second+_u8Minute*60+_u8Hour*3600;
                        U32 u32GotoTimeMs = u32GotoTime*1000;
                        MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_MOVIEINFO_GOTOTIME_GROUP, SW_HIDE);
                        if(MUSICINFO_GOTO_TIME< _u8InfoBarIdx)
                        {
                            MApp_ZUI_API_SetFocus(_hwndListInfoBar[MUSICINFO_GOTO_TIME+u8MusicInfoBarMax -_u8InfoBarIdx]);
                        }
                        else
                        {
                            MApp_ZUI_API_SetFocus(_hwndListInfoBar[MUSICINFO_GOTO_TIME - _u8InfoBarIdx]);
                        }
                        // To do : process GOTO TIME.
                        //printf("[Time] Go : %02d:%02d:%02d (%ld)\n", _u8Hour, _u8Minute, _u8Second, u32GotoTimeMs);
                        _u8Hour = 0;
                        _u8Minute = 0;
                        _u8Second = 0;
                        if(u32GotoTime > MApp_MPlayer_QueryMusicFilePlayTime())
                        { // Invalid operation
                            _MApp_ACTdmp_ShowAlertWin(DMP_MSG_TYPE_INVALID_OPERATION);
                            MApp_ZUI_API_SetTimer(HWND_DMP_ALERT_WINDOW, DMP_TIMER_INVALID_WIN, DMP_TIME_MS_INVALID_WIN);
                        }
                        else
                        {
                            switch(MApp_MPlayer_QueryCurrentFileMediaSubType())
                            {
                            #if (ENABLE_WMA)
                                case E_MPLAYER_SUBTYPE_WMA:
                                    MApp_WMA_ProcessTimeOffset(u32GotoTimeMs);
                                    break;
                            #endif

                                case E_MPLAYER_SUBTYPE_MP3:
                                case E_MPLAYER_SUBTYPE_AAC:
                                case E_MPLAYER_SUBTYPE_WAV:
                                case E_MPLAYER_SUBTYPE_OGG:
                                    MApp_Music_ProcessTimeOffset(u32GotoTimeMs);
                                    break;
                                default:
                                    break;
                            }
                        }
                    }
                        break;
                    default:
                        break;
                }
            }
            else
            {
                MApp_ZUI_API_SetFocus(HWND_DMP_PLAYBACK_MOVIEINFO_GOTOTIME_OK);
            }
        }
            break;
        case EN_EXE_DMP_MOVIEINFO_GOTOTIME_WIN_UP:
        {
            if(MApp_ZUI_API_GetFocus() == HWND_DMP_PLAYBACK_MOVIEINFO_GOTOTIME_OK)
            {
                MApp_ZUI_API_SetFocus((HWND)(MApp_ZUI_API_GetFocus()-1));
            }
        }
        break;
        case EN_EXE_DMP_MOVIEINFO_GOTOTIME_WIN_DOWN:
        {
            if(MApp_ZUI_API_GetFocus() != HWND_DMP_PLAYBACK_MOVIEINFO_GOTOTIME_OK)
            {
                MApp_ZUI_API_SetFocus(HWND_DMP_PLAYBACK_MOVIEINFO_GOTOTIME_OK);
            }
        }
        break;
        case EN_EXE_DMP_MOVIEINFO_GOTOTIME_WIN_LEFT:
        {
            if(MApp_ZUI_API_GetFocus() > HWND_DMP_PLAYBACK_MOVIEINFO_GOTOTIME_HOUR_DIGIT1)
            {
                MApp_ZUI_API_SetFocus((HWND)(MApp_ZUI_API_GetFocus()-1));
            }
        }
        break;
        case EN_EXE_DMP_MOVIEINFO_GOTOTIME_WIN_RIGHT:
        {
            if(MApp_ZUI_API_GetFocus() < HWND_DMP_PLAYBACK_MOVIEINFO_GOTOTIME_OK)
            {
                MApp_ZUI_API_SetFocus((HWND)(MApp_ZUI_API_GetFocus()+1));
            }
        }
        break;
// this EN_EXE_DMP_PLAYBACK_PLAYLIST_CANCEL is shared for movie photo music...
        case EN_EXE_DMP_PLAYBACK_PLAYLIST_CANCEL:
        {
            MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_PLAYLIST_GROUP, SW_HIDE);
            enumMPlayerMediaType eMediaType= MApp_MPlayer_QueryCurrentMediaType();
            switch (eMediaType)
            {
                case E_MPLAYER_TYPE_PHOTO:
                    if(PHOTOINFO_PLAYLIST< _u8InfoBarIdx)
                    {
                        MApp_ZUI_API_SetFocus(_hwndListInfoBar[PHOTOINFO_PLAYLIST+u8PhotoInfoBarMax -_u8InfoBarIdx]);
                    }
                    else
                    {
                        MApp_ZUI_API_SetFocus(_hwndListInfoBar[PHOTOINFO_PLAYLIST - _u8InfoBarIdx]);
                    }
                    break;
                case E_MPLAYER_TYPE_MOVIE:
                    if(MOVIEINFO_PLAYLIST< _u8InfoBarIdx)
                    {
                        MApp_ZUI_API_SetFocus(_hwndListInfoBar[MOVIEINFO_PLAYLIST+u8MovieInfoBarMax -_u8InfoBarIdx]);
                    }
                    else
                    {
                        MApp_ZUI_API_SetFocus(_hwndListInfoBar[MOVIEINFO_PLAYLIST - _u8InfoBarIdx]);
                    }
                    break;
                case E_MPLAYER_TYPE_MUSIC:
                    if(MUSICINFO_PLAYLIST< _u8InfoBarIdx)
                    {
                        MApp_ZUI_API_SetFocus(_hwndListInfoBar[MUSICINFO_PLAYLIST+u8MusicInfoBarMax -_u8InfoBarIdx]);
                    }
                    else
                    {
                        MApp_ZUI_API_SetFocus(_hwndListInfoBar[MUSICINFO_PLAYLIST - _u8InfoBarIdx]);
                    }
                    break;
                case E_MPLAYER_TYPE_TEXT:
                    if(TEXTINFO_PLAYLIST< _u8InfoBarIdx)
                    {
                        MApp_ZUI_API_SetFocus(_hwndListInfoBar[TEXTINFO_PLAYLIST+u8TextInfoBarMax -_u8InfoBarIdx]);
                    }
                    else
                    {
                        MApp_ZUI_API_SetFocus(_hwndListInfoBar[TEXTINFO_PLAYLIST - _u8InfoBarIdx]);
                    }
                    break;
                default:
                    DMP_DBG(printf("=.=.=.=.=.=.=\n"););
                    break;
            }
        }
            break;
        case EN_EXE_DMP_PLAYBACK_MOVIEINFO_INFO:
        {
            MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_MOVIEINFO_INFO_GROUP, SW_SHOW);
            MApp_ZUI_API_SetFocus(HWND_DMP_PLAYBACK_MOVIEINFO_INFO_AUDIOTRACK_TEXT);
            _MApp_ZUI_ACT_DMPMarqueeTextEnableAnimation(
            HWND_DMP_PLAYBACK_MOVIEINFO_INFO_FILENAME_TEXT,TRUE);
        }
            break;

        case EN_EXE_DMP_PLAYBACK_MOVIEINFO_INFO_AUDIOTRACK_TEXT_R:
        {
            if( MApp_MPlayer_QueryCurrentMediaType() == E_MPLAYER_TYPE_MOVIE
                && MApp_MPlayer_IsMoviePlaying())
            {
            #if ENABLE_DVD
                if (MApp_MPlayer_QueryCurrentFileMediaSubType() == E_MPLAYER_SUBTYPE_DVD)
                {
                    U8 ret;

                    DMP_DBG(printf("VK_AUDIO in DVD\n"));
                    ret = MApp_MPlayer_DVD_Command(E_MPLAYER_DVD_CMD_LANGUAGE);

                    return TRUE;
                }
                else
            #endif  // ENABLE_DVD
                {
                    U16 u16TotalTrk = MApp_MPlayer_QueryMovieAudioChannelNum();
                    if (u16TotalTrk != MPLAYER_INVALID_INDEX && u16TotalTrk != 0)
                    {
                        U16 u16TrkID = MApp_MPlayer_QueryMovieCurAudioTrackIdx();
                        if(u16TrkID < u16TotalTrk-1)
                        {
                            u16TrkID++;
                            if(MApp_MPlayer_MovieChangeAudioTrack(u16TrkID) != E_MPLAYER_RET_OK)
                            {
                                DMP_DBG(printf("MApp_MPlayer_MovieChangeProgram fail\n"););
                            }
                           // _enDmpPlayIconType = _enDmpPlayStrType = PLAY_MODE_ICON_CHANGE_AUDIOTRACK;
                            MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_SHOW);
                            MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN, DMP_TIME_MS_PLAY_STATUS_WIN);
                        }
                    }
                    else
                    {
                        DMP_DBG(printf("MApp_MPlayer_QueryMovieAudioChannelNum fail or 0\n"););
                    }
                    MApp_ZUI_API_InvalidateWindow(HWND_DMP_PLAYBACK_MOVIEINFO_INFO_AUDIOTRACK_TEXT);
                }
            }
            return TRUE;
        }
            break;
        case EN_EXE_DMP_PLAYBACK_MOVIEINFO_INFO_AUDIOTRACK_TEXT_L:
        {

            if( MApp_MPlayer_QueryCurrentMediaType() == E_MPLAYER_TYPE_MOVIE
                && MApp_MPlayer_IsMoviePlaying())
            {
            #if ENABLE_DVD
                if (MApp_MPlayer_QueryCurrentFileMediaSubType() == E_MPLAYER_SUBTYPE_DVD)
                {
                    U8 ret;

                    DMP_DBG(printf("VK_AUDIO in DVD\n"));
                    ret = MApp_MPlayer_DVD_Command(E_MPLAYER_DVD_CMD_LANGUAGE);

                    return TRUE;
                }
                else
            #endif  // ENABLE_DVD
                {
                    U16 u16TotalTrk = MApp_MPlayer_QueryMovieAudioChannelNum();
                    if (u16TotalTrk != MPLAYER_INVALID_INDEX && u16TotalTrk != 0)
                    {
                        U16 u16TrkID = MApp_MPlayer_QueryMovieCurAudioTrackIdx();
                        if(u16TrkID != 0 && u16TrkID <= u16TotalTrk)
                        {
                            u16TrkID--;
                            if(MApp_MPlayer_MovieChangeAudioTrack(u16TrkID) != E_MPLAYER_RET_OK)
                            {
                                DMP_DBG(printf("MApp_MPlayer_MovieChangeProgram fail\n"););
                            }
                            //_enDmpPlayIconType = _enDmpPlayStrType = PLAY_MODE_ICON_CHANGE_AUDIOTRACK;
                            MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_SHOW);
                            MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN, DMP_TIME_MS_PLAY_STATUS_WIN);
                        }
                    }
                    else
                    {
                        DMP_DBG(printf("MApp_MPlayer_QueryMovieAudioChannelNum fail or 0\n"););
                    }
                    MApp_ZUI_API_InvalidateWindow(HWND_DMP_PLAYBACK_MOVIEINFO_INFO_AUDIOTRACK_TEXT);
                }
            }
            return TRUE;
        }
            break;
        case EN_EXE_DMP_PLAYBACK_MOVIEINFO_INFO_SUBTITLE_TEXT_R:
        {
            DMP_DBG(printf("hot VK_SUBTITLE_R\n"););
            if(MApp_MPlayer_QueryCurrentMediaType()== E_MPLAYER_TYPE_MOVIE
            && MApp_MPlayer_IsMoviePlaying())
            {
            #if (ENABLE_SUBTITLE_DMP)
                if(MApp_MPlayer_IsMediaFileInPlaying() &&
                    (MApp_DMP_GetDmpFlag() & DMP_FLAG_MEDIA_FILE_PLAYING))
                {
                #if ENABLE_DVD
                    if (MApp_MPlayer_QueryCurrentFileMediaSubType() == E_MPLAYER_SUBTYPE_DVD)
                    {
                        U8 ret;

                        DMP_DBG(printf("VK_SUBTITLE in DVD\n"));
                        ret = MApp_MPlayer_DVD_Command(E_MPLAYER_DVD_CMD_SUBTITLE);

                        return TRUE;
                    }
                #endif  // ENABLE_DVD
                    U16 u16TrkID,u16TotalTrk;
                    u16TrkID=MApp_MPlayer_QueryMovieCurSubtitleTrackIdx() ;
                    u16TotalTrk=MApp_MPlayer_QueryMovieSubtitleNum();

                    if (u16TotalTrk == 0)
                    {
                        DMP_DBG(printf("No SUBTITLE exist!!\n"););
                        break;
                    }
                    else if(_stDmpPlayVar.stMovieInfo.bSubtitleOff)
                    {
                        DMP_DBG(printf("Turn ON SUBTITLE 1\n"););
                        //_enDmpPlayIconType = _enDmpPlayStrType = PLAY_MODE_ICON_CHANGE_SUBTITLETRACK;
                        MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_SHOW);
                        MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN, DMP_TIME_MS_PLAY_STATUS_WIN);
                        _stDmpPlayVar.stMovieInfo.bSubtitleOff = FALSE;
                        MApp_MPlayer_MovieChangeSubtitleTrack(0);
                        _MApp_ZUI_ACTdmp_OperateSubtitle();
                    }
                    else if((u16TrkID+1)<u16TotalTrk)
                    {
                        DMP_DBG(printf("change subtitle \n"));
                        MApp_MPlayer_MovieChangeSubtitleTrack((u16TrkID+1)%u16TotalTrk);
                        //_enDmpPlayIconType = _enDmpPlayStrType = PLAY_MODE_ICON_CHANGE_SUBTITLETRACK;
                        MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_SHOW);
                        MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN, DMP_TIME_MS_PLAY_STATUS_WIN);
                        _MApp_ZUI_ACTdmp_OperateSubtitle();
                    }
                    else
                    {
                        DMP_DBG(printf("Turn OFF SUBTITLE R\n"););
                       // _enDmpPlayIconType = _enDmpPlayStrType = PLAY_MODE_ICON_CHANGE_SUBTITLETRACK;
                        MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_SHOW);
                        MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN, DMP_TIME_MS_PLAY_STATUS_WIN);
                        _stDmpPlayVar.stMovieInfo.bSubtitleOff = TRUE;
                        
                        _MApp_ZUI_ACTdmp_OperateSubtitle();
                    }
                    // clear previous subtitle?
                    memset((U8*)_stDmpPlayVar.stMovieInfo.MPlayerSubtitleBuf, 0, DMP_STRING_BUF_SIZE);
                    MApp_ZUI_API_InvalidateWindow(HWND_DMP_PLAYBACK_SUBTITLE_PAGE);
                    MApp_ZUI_API_InvalidateWindow(HWND_DMP_PLAYBACK_MOVIEINFO_INFO_SUBTITLE_TEXT);
                }
            #endif // #if (ENABLE_SUBTITLE_DMP)
            }
        }
            break;

        case EN_EXE_DMP_PLAYBACK_MOVIEINFO_INFO_SUBTITLE_TEXT_L:
        {
            DMP_DBG(printf("hot VK_SUBTITLE_L\n"););
            if(MApp_MPlayer_QueryCurrentMediaType()== E_MPLAYER_TYPE_MOVIE
            && MApp_MPlayer_IsMoviePlaying())
            {
            #if (ENABLE_SUBTITLE_DMP)
                if(MApp_MPlayer_IsMediaFileInPlaying() &&
                    (MApp_DMP_GetDmpFlag() & DMP_FLAG_MEDIA_FILE_PLAYING))
                {
                #if ENABLE_DVD
                    if (MApp_MPlayer_QueryCurrentFileMediaSubType() == E_MPLAYER_SUBTYPE_DVD)
                    {
                        U8 ret;

                        DMP_DBG(printf("VK_SUBTITLE left is not supported in DVD\n"));
                        ret = MApp_MPlayer_DVD_Command(E_MPLAYER_DVD_CMD_SUBTITLE);

                        return TRUE;
                    }
                #endif  // ENABLE_DVD
                    U16 u16TrkID,u16TotalTrk;
                    u16TrkID=MApp_MPlayer_QueryMovieCurSubtitleTrackIdx() ;
                    u16TotalTrk=MApp_MPlayer_QueryMovieSubtitleNum();
                    if (u16TotalTrk == 0)
                    {
                        DMP_DBG(printf("No SUBTITLE exist!!\n"););
                        break;
                    }
                    else if(_stDmpPlayVar.stMovieInfo.bSubtitleOff)
                    {
                        DMP_DBG(printf("Turn ON SUBTITLE\n"););
                        //_enDmpPlayIconType = _enDmpPlayStrType = PLAY_MODE_ICON_CHANGE_SUBTITLETRACK;
                        MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_SHOW);
                        MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN, DMP_TIME_MS_PLAY_STATUS_WIN);
                        _stDmpPlayVar.stMovieInfo.bSubtitleOff = FALSE;
                        MApp_MPlayer_MovieChangeSubtitleTrack(u16TotalTrk-1);
                        _MApp_ZUI_ACTdmp_OperateSubtitle();

                    }
                    else if(u16TrkID!=0)
                    {
                        MApp_MPlayer_MovieChangeSubtitleTrack((u16TrkID-1)%u16TotalTrk);
                        //_enDmpPlayIconType = _enDmpPlayStrType = PLAY_MODE_ICON_CHANGE_SUBTITLETRACK;
                        MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_SHOW);
                        MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN, DMP_TIME_MS_PLAY_STATUS_WIN);
                        _MApp_ZUI_ACTdmp_OperateSubtitle();
                    }
                    else
                    {
                        DMP_DBG(printf("Turn OFF SUBTITLE_L\n"););
                       // _enDmpPlayIconType = _enDmpPlayStrType = PLAY_MODE_ICON_CHANGE_SUBTITLETRACK;
                        MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_SHOW);
                        MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN, DMP_TIME_MS_PLAY_STATUS_WIN);
                       _stDmpPlayVar.stMovieInfo.bSubtitleOff = TRUE;
                       
                        _MApp_ZUI_ACTdmp_OperateSubtitle();
                     }
                    // clear previous subtitle?
                    memset((U8*)_stDmpPlayVar.stMovieInfo.MPlayerSubtitleBuf, 0, DMP_STRING_BUF_SIZE);
                    MApp_ZUI_API_InvalidateWindow(HWND_DMP_PLAYBACK_SUBTITLE_PAGE);
                    MApp_ZUI_API_InvalidateWindow(HWND_DMP_PLAYBACK_MOVIEINFO_INFO_SUBTITLE_TEXT);
                }
            #endif // #if (ENABLE_SUBTITLE_DMP)
            }
        }
            break;

        case EN_EXE_DMP_PLAYBACK_MOVIEINFO_INFO_PROGRAM_TEXT_R:
        {
            DMP_DBG(printf("VK_CHANNEL_MINUS\n"););
            if(MApp_MPlayer_QueryCurrentMediaType()== E_MPLAYER_TYPE_MOVIE
            && MApp_MPlayer_IsMoviePlaying())
            {
                U16 u16TotalPgm = MApp_MPlayer_QueryMovieProgramNum();
                if (u16TotalPgm != MPLAYER_INVALID_INDEX && u16TotalPgm != 0)
                {
                    U16 u16PgmIdx = MApp_MPlayer_QueryMovieCurProgramIdx();
                    {
                        if( u16PgmIdx < u16TotalPgm -1)
                        {
                            DMP_DBG(printf("channel++\n"););
                            u16PgmIdx++;
                            if (MApp_MPlayer_MovieChangeProgram(u16PgmIdx) == E_MPLAYER_RET_OK)
                            {
                                _MApp_ACTdmp_MovieCancelRepeatAB();
                            }
                            else
                            {
                                DMP_DBG(printf("channel++ fail\n"););
                            }
                        }
                    }
                }
                else
                {
                    DMP_DBG(printf("MApp_MPlayer_QueryMovieProgramNum fail or 0\n"););
                }
                MApp_ZUI_API_InvalidateWindow(HWND_DMP_PLAYBACK_MOVIEINFO_INFO_PROGRAM_TEXT);
            }
            return TRUE;
        }
            break;
        case EN_EXE_DMP_PLAYBACK_MOVIEINFO_INFO_PROGRAM_TEXT_L:
        {
            DMP_DBG(printf("VK_CHANNEL_MINUS\n"););
            if(MApp_MPlayer_QueryCurrentMediaType()== E_MPLAYER_TYPE_MOVIE
            && MApp_MPlayer_IsMoviePlaying())
            {
                U16 u16TotalPgm = MApp_MPlayer_QueryMovieProgramNum();
                if (u16TotalPgm != MPLAYER_INVALID_INDEX && u16TotalPgm != 0)
                {
                    U16 u16PgmIdx = MApp_MPlayer_QueryMovieCurProgramIdx();
                    {
                        if(u16PgmIdx > 0)
                        {
                            DMP_DBG(printf("channel--\n"););
                            u16PgmIdx--;
                            if (MApp_MPlayer_MovieChangeProgram(u16PgmIdx) == E_MPLAYER_RET_OK)
                            {
                                _MApp_ACTdmp_MovieCancelRepeatAB();
                            }
                            else
                            {
                                DMP_DBG(printf("channel-- fail\n"););
                            }
                        }
                    }
                }
                else
                {
                    DMP_DBG(printf("MApp_MPlayer_QueryMovieProgramNum fail or 0\n"););
                }
                MApp_ZUI_API_InvalidateWindow(HWND_DMP_PLAYBACK_MOVIEINFO_INFO_PROGRAM_TEXT);
            }
            return TRUE;
        }
        break;
    #if (ENABLE_DIVX_PLUS == 1)
        case EN_EXE_DMP_PLAYBACK_MOVIEINFO_DIVX:
        case EN_EXE_DMP_PLAYBACK_MOVIEINFO_DIVX_MENU:
        {
            _enDmpDivxStatus= DIVX_MENU;
            _MApp_ACTdmp_Playback_ShowDivxWin();
        }
        break;
        case EN_EXE_DMP_PLAYBACK_MOVIEINFO_DIVX_SELECT:
        {
            switch (MApp_ZUI_API_GetFocus())
            {
                case HWND_DMP_PLAYBACK_MOVIEINFO_DIVX_MENU_SETTITLE:
                    _enDmpDivxStatus = DIVX_SET_TITLE;
                    break;
                case HWND_DMP_PLAYBACK_MOVIEINFO_DIVX_MENU_SETEDITION:
                    _enDmpDivxStatus = DIVX_SET_EDITION;
                    break;
                case HWND_DMP_PLAYBACK_MOVIEINFO_DIVX_MENU_SETCHAPTER:
                    _enDmpDivxStatus = DIVX_SET_CHAPTER;
                    break;
                case HWND_DMP_PLAYBACK_MOVIEINFO_DIVX_MENU_SETAUTOCHAPTER:
                    _enDmpDivxStatus = DIVX_SET_AUTOCHAPTER;
                    break;
                default:
                    _enDmpDivxStatus = DIVX_MAX;
                    break;
            }
            _MApp_ACTdmp_Playback_ShowDivxWin();
        }
        break;
        case EN_EXE_DMP_PLAYBACK_MOVIEINFO_DIVX_TITLE_TEXT_R:
        {
            DMP_DBG(printf("EN_EXE_DMP_PLAYBACK_MOVIEINFO_DIVX_TITLE_TEXT_R\n"););
            if(MApp_MPlayer_QueryCurrentMediaType()== E_MPLAYER_TYPE_MOVIE && MApp_MPlayer_IsMoviePlaying())
            {
                U16 u16TotalTitle = MApp_MPlayer_QueryMovieTitleNum();
                if (u16TotalTitle != MPLAYER_INVALID_INDEX && u16TotalTitle!= 0)
                {
                    if( _u16DivxTitleIdx < u16TotalTitle-1)
                    {
                        _u16DivxTitleIdx++;
                    }
                }
                MApp_ZUI_API_InvalidateWindow(HWND_DMP_PLAYBACK_MOVIEINFO_DIVX_SETTITLE_TITLE_TEXT);
            }
            return TRUE;
        }
        break;
        case EN_EXE_DMP_PLAYBACK_MOVIEINFO_DIVX_TITLE_TEXT_L:
        {
            DMP_DBG(printf("EN_EXE_DMP_PLAYBACK_MOVIEINFO_DIVX_TITLE_TEXT_L\n"););
            if(MApp_MPlayer_QueryCurrentMediaType()== E_MPLAYER_TYPE_MOVIE && MApp_MPlayer_IsMoviePlaying())
            {
                U16 u16TotalTitle = MApp_MPlayer_QueryMovieTitleNum();
                if (u16TotalTitle != MPLAYER_INVALID_INDEX && u16TotalTitle!= 0)
                {
                    if( _u16DivxTitleIdx >0)
                    {
                        _u16DivxTitleIdx--;
                    }
                }
                MApp_ZUI_API_InvalidateWindow(HWND_DMP_PLAYBACK_MOVIEINFO_DIVX_SETTITLE_TITLE_TEXT);
            }
            return TRUE;
        }
        break;
        case EN_EXE_DMP_PLAYBACK_MOVIEINFO_DIVX_EDITION_TEXT_R:
        {
            DMP_DBG(printf("EN_EXE_DMP_PLAYBACK_MOVIEINFO_DIVX_EDITION_TEXT_R\n"););
            if(MApp_MPlayer_QueryCurrentMediaType()== E_MPLAYER_TYPE_MOVIE && MApp_MPlayer_IsMoviePlaying())
            {
                U16 u16TotalTitle = MApp_MPlayer_QueryMovieTitleNum();
                U16 u16TotalEdition = MApp_MPlayer_QueryMovieEditionNum();
                if (u16TotalTitle == 0)
                {
                    return TRUE;
                }
                if (u16TotalEdition!= MPLAYER_INVALID_INDEX && u16TotalEdition!= 0)
                {
                    if( _u16DivxEditionIdx < u16TotalEdition-1)
                    {
                        _u16DivxEditionIdx++;
                    }
                }
                MApp_ZUI_API_InvalidateWindow(HWND_DMP_PLAYBACK_MOVIEINFO_DIVX_SETEDTION_TEXT);
            }
            return TRUE;
        }
        break;
        case EN_EXE_DMP_PLAYBACK_MOVIEINFO_DIVX_EDITION_TEXT_L:
        {
            DMP_DBG(printf("EN_EXE_DMP_PLAYBACK_MOVIEINFO_DIVX_EDITION_TEXT_L\n"););
            if(MApp_MPlayer_QueryCurrentMediaType()== E_MPLAYER_TYPE_MOVIE && MApp_MPlayer_IsMoviePlaying())
            {
                U16 u16TotalTitle = MApp_MPlayer_QueryMovieTitleNum();
                U16 u16TotalEdition = MApp_MPlayer_QueryMovieEditionNum();
                if (u16TotalTitle == 0)
                {
                    return TRUE;
                }
                if (u16TotalEdition!= MPLAYER_INVALID_INDEX && u16TotalEdition!= 0)
                {
                    if( _u16DivxEditionIdx > 0)
                    {
                        _u16DivxEditionIdx--;
                    }
                }
                MApp_ZUI_API_InvalidateWindow(HWND_DMP_PLAYBACK_MOVIEINFO_DIVX_SETEDTION_TEXT);
            }
            return TRUE;
        }
        break;
        case EN_EXE_DMP_PLAYBACK_MOVIEINFO_DIVX_CHAPTER_TEXT_R:
        {
            DMP_DBG(printf("EN_EXE_DMP_PLAYBACK_MOVIEINFO_DIVX_CHAPTER_TEXT_R\n"););
            if(MApp_MPlayer_QueryCurrentMediaType()== E_MPLAYER_TYPE_MOVIE && MApp_MPlayer_IsMoviePlaying())
            {
                U16 u16TotalTitle = MApp_MPlayer_QueryMovieTitleNum();
                U16 u16TotalEdition = MApp_MPlayer_QueryMovieEditionNum();
                U16 u16TotalChp = MApp_MPlayer_QueryMovieChapterNum();
                if ((u16TotalTitle == 0) || (u16TotalEdition == 0))
                {
                    return TRUE;
                }
                if (u16TotalChp!= MPLAYER_INVALID_INDEX && u16TotalChp!= 0)
                {
                    if( _u16DivxChpIdx < u16TotalChp-1)
                    {
                        _u16DivxChpIdx++;
                    }
                }
                MApp_ZUI_API_InvalidateWindow(HWND_DMP_PLAYBACK_MOVIEINFO_DIVX_SETCHAPTER_TEXT);
            }
            return TRUE;
        }
        break;
        case EN_EXE_DMP_PLAYBACK_MOVIEINFO_DIVX_CHAPTER_TEXT_L:
        {
            DMP_DBG(printf("EN_EXE_DMP_PLAYBACK_MOVIEINFO_DIVX_CHAPTER_TEXT_L\n"););
            if(MApp_MPlayer_QueryCurrentMediaType()== E_MPLAYER_TYPE_MOVIE && MApp_MPlayer_IsMoviePlaying())
            {
                U16 u16TotalTitle = MApp_MPlayer_QueryMovieTitleNum();
                U16 u16TotalEdition = MApp_MPlayer_QueryMovieEditionNum();
                U16 u16TotalChp = MApp_MPlayer_QueryMovieChapterNum();
                if ((u16TotalTitle == 0) || (u16TotalEdition == 0))
                {
                    return TRUE;
                }
                if (u16TotalChp!= MPLAYER_INVALID_INDEX && u16TotalChp!= 0)
                {
                    if( _u16DivxChpIdx > 0)
                    {
                        _u16DivxChpIdx--;
                    }
                }
                MApp_ZUI_API_InvalidateWindow(HWND_DMP_PLAYBACK_MOVIEINFO_DIVX_SETCHAPTER_TEXT);
            }
            return TRUE;
        }
        break;
        case EN_EXE_DMP_PLAYBACK_MOVIEINFO_DIVX_AUTOCHAPTER_TEXT_L:
        {
            DMP_DBG(printf("EN_EXE_DMP_PLAYBACK_MOVIEINFO_DIVX_AUTOCHAPTER_TEXT_L\n"););
            if(MApp_MPlayer_QueryCurrentMediaType()== E_MPLAYER_TYPE_MOVIE && MApp_MPlayer_IsMoviePlaying())
            {
                if( _u8DivxAutoChpIdx > 0) // 0~9
                {
                    _u8DivxAutoChpIdx--;
                        _MApp_ACTdmp_MovieCancelRepeatAB();
                        if(E_MPLAYER_RET_OK == MApp_MPlayer_MovieChangeAutoGenChapter(_u8DivxAutoChpIdx))
                        {
                        }
                        else
                        {
                            _u8DivxAutoChpIdx++;
                            DMP_DBG(printf("MApp_MPlayer_MovieChangeAutoGenChapter fail\n"););
                        }
                }
                MApp_ZUI_API_InvalidateWindow(HWND_DMP_PLAYBACK_MOVIEINFO_DIVX_SETAUTOCHAPTER_TEXT);
            }
            return TRUE;
        }
        break;

        case EN_EXE_DMP_PLAYBACK_MOVIEINFO_DIVX_AUTOCHAPTER_TEXT_R:
        {
            DMP_DBG(printf("EN_EXE_DMP_PLAYBACK_MOVIEINFO_DIVX_AUTOCHAPTER_TEXT_R\n"););
            if(MApp_MPlayer_QueryCurrentMediaType()== E_MPLAYER_TYPE_MOVIE && MApp_MPlayer_IsMoviePlaying())
            {
                if( _u8DivxAutoChpIdx < 9) // 0~9
                {
                    _u8DivxAutoChpIdx++;
                        _MApp_ACTdmp_MovieCancelRepeatAB();
                        if(E_MPLAYER_RET_OK == MApp_MPlayer_MovieChangeAutoGenChapter(_u8DivxAutoChpIdx))
                        {
                        }
                        else
                        {
                            _u8DivxAutoChpIdx--;
                            DMP_DBG(printf("MApp_MPlayer_MovieChangeAutoGenChapter fail !\n"););
                        }
                }
                MApp_ZUI_API_InvalidateWindow(HWND_DMP_PLAYBACK_MOVIEINFO_DIVX_SETAUTOCHAPTER_TEXT);
            }
            return TRUE;
        }
        break;
        case EN_EXE_DMP_PLAYBACK_MOVIEINFO_DIVX_OK:
        {
            DMP_DBG(printf("EN_EXE_DMP_PLAYBACK_MOVIEINFO_DIVX_OK\n"););
            if(MApp_MPlayer_QueryCurrentMediaType()== E_MPLAYER_TYPE_MOVIE && MApp_MPlayer_IsMoviePlaying())
            {
                switch (_enDmpDivxStatus)
                {
                    case DIVX_SET_TITLE:
                            {
                                _MApp_ACTdmp_MovieCancelRepeatAB();
                                if (MApp_MPlayer_MovieChangeTitle((U8)_u16DivxTitleIdx) == E_MPLAYER_RET_OK)
                                {
                                    //printf("Change Title set PLAY ICON\n");
                                    MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_NORMAL);
                                    MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_HIDE);
                                    //_enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_PLAY;
                                    //DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PAUSE;
                                    //DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Pause;
                                }
                               else
                                {
                                    DMP_DBG(printf("MApp_MPlayer_MovieChangeTitle(%u)\n",_u16DivxTitleIdx););
                                }
                            }
                            break;
                        case DIVX_SET_EDITION:
                            _MApp_ACTdmp_MovieCancelRepeatAB();
                            if (MApp_MPlayer_MovieChangeEdition(_u16DivxEditionIdx) == E_MPLAYER_RET_OK)
                            {
                                printf("Change Edition set PLAY ICON\n");
                                MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_NORMAL);
                                MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_HIDE);
                                //_enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_PLAY;
                                //DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PAUSE;
                                //DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Pause;
                            }
                           else
                            {
                                DMP_DBG(printf("MApp_MPlayer_MovieChangeEdition(%u)\n",_u16DivxEditionIdx););
                            }
                            break;
                    case DIVX_SET_CHAPTER:
                        _MApp_ACTdmp_MovieCancelRepeatAB();
                        if (MApp_MPlayer_MovieChangeChapter(_u16DivxChpIdx) == E_MPLAYER_RET_FAIL)
                        {
                            // TODO: Error handling
                            DMP_DBG(printf("MApp_MPlayer_MovieChangeChapter(%u)\n",_u16DivxChpIdx););
                        }
                        break;

                    case DIVX_SET_AUTOCHAPTER:
                        _MApp_ACTdmp_MovieCancelRepeatAB();
                        MApp_MPlayer_MovieChangeAutoGenChapter(_u8DivxAutoChpIdx);
                        break;
                    default:
                        break;
                }
                _enDmpDivxStatus = DIVX_MENU;
                _MApp_ACTdmp_Playback_ShowDivxWin();
            }
        }
        break;
        case EN_EXE_DMP_PLAYBACK_MOVIEINFO_DIVX_CLOSE:
        {
            _enDmpDivxStatus = DIVX_MAX;
            _MApp_ACTdmp_Playback_ShowDivxWin();
        }
        break;
    #endif  // (ENABLE_DIVX_PLUS == 1)
        case EN_EXE_DMP_PLAYBACK_MOVIEINFO_INFOCLOSE:
        {
            _MApp_ZUI_ACT_DMPMarqueeTextEnableAnimation(
            HWND_DMP_PLAYBACK_MOVIEINFO_INFO_FILENAME_TEXT,FALSE);
            MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_MOVIEINFO_INFO_GROUP,SW_HIDE);
            if(MOVIEINFO_INFO < _u8InfoBarIdx)
            {
                MApp_ZUI_API_SetFocus(_hwndListInfoBar[MOVIEINFO_INFO+u8MovieInfoBarMax -_u8InfoBarIdx]);
            }
            else
            {
                MApp_ZUI_API_SetFocus(_hwndListInfoBar[MOVIEINFO_INFO - _u8InfoBarIdx]);
            }
        }
        break;

    #if (ENABLE_MPLAYER_CAPTURE_MOVIE == 1)
        case EN_EXE_DMP_PLAYBACK_MOVIEINFO_CAPTURE:
            DMP_DBG(printf("EN_EXE_DMP_PLAYBACK_MOVIEINFO_CAPTURE\n"););
            {
                switch(MApp_MPlayer_QueryMoviePlayMode())
                {
                    case E_MPLAYER_MOVIE_NORMAL:
                        _enDmpPlayStrType = PLAY_MODE_ICON_PLAY;
                        break;
                    case E_MPLAYER_MOVIE_PAUSE:
                        _enDmpPlayStrType = PLAY_MODE_ICON_PAUSE;
                        break;
                    case E_MPLAYER_MOVIE_FF_2X:
                        _enDmpPlayStrType = PLAY_MODE_ICON_FF2X;
                        break;
                    case E_MPLAYER_MOVIE_FF_4X:
                        _enDmpPlayStrType = PLAY_MODE_ICON_FF4X;
                        break;
                    case E_MPLAYER_MOVIE_FF_8X:
                        _enDmpPlayStrType = PLAY_MODE_ICON_FF8X;
                        break;
                    case E_MPLAYER_MOVIE_FF_16X:
                        _enDmpPlayStrType = PLAY_MODE_ICON_FF16X;
                        break;
                    case E_MPLAYER_MOVIE_FF_32X:
                        _enDmpPlayStrType = PLAY_MODE_ICON_FF32X;
                        break;
                    case E_MPLAYER_MOVIE_FB_2X:
                        _enDmpPlayStrType = PLAY_MODE_ICON_FB2X;
                        break;
                    case E_MPLAYER_MOVIE_FB_4X:
                        _enDmpPlayStrType = PLAY_MODE_ICON_FB4X;
                        break;
                    case E_MPLAYER_MOVIE_FB_8X:
                        _enDmpPlayStrType = PLAY_MODE_ICON_FB8X;
                        break;
                    case E_MPLAYER_MOVIE_FB_16X:
                        _enDmpPlayStrType = PLAY_MODE_ICON_FB16X;
                        break;
                    case E_MPLAYER_MOVIE_FB_32X:
                        _enDmpPlayStrType = PLAY_MODE_ICON_FB32X;
                        break;
                    case E_MPLAYER_MOVIE_SF_2X:
                        _enDmpPlayStrType = PLAY_MODE_ICON_SF2X;
                        break;
                    case E_MPLAYER_MOVIE_SF_4X:
                        _enDmpPlayStrType = PLAY_MODE_ICON_SF4X;
                        break;
                    case E_MPLAYER_MOVIE_SF_8X:
                        _enDmpPlayStrType = PLAY_MODE_ICON_SF8X;
                        break;
                    case E_MPLAYER_MOVIE_SF_16X:
                        _enDmpPlayStrType = PLAY_MODE_ICON_SF16X;
                        break;
                    case E_MPLAYER_MOVIE_SF_32X:
                        _enDmpPlayStrType = PLAY_MODE_ICON_SF32X;
                        break;
                    case E_MPLAYER_MOVIE_STEP:
                        _enDmpPlayStrType = PLAY_MODE_ICON_SD;
                        break;
                    default:
                        break;
                }
                MApp_ZUI_API_StoreFocusCheckpoint();
                MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_CONFIRM_DIALOG,SW_SHOW);
                MApp_ZUI_API_SetFocus(HWND_DMP_PLAYBACK_CONFIRM_YES);
                MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_PAUSE);
            }
        break;
    #endif // #if (ENABLE_MPLAYER_CAPTURE_MOVIE == 1)

        case EN_EXE_DMP_PLAYBACK_MOVIEINFO_REPEAT:
            DMP_DBG(printf("EN_EXE_DMP_PLAYBACK_MOVIEINFO_REPEAT\n"););
            {
                enumMPlayerRepeatMode eRepeatMode = MApp_MPlayer_QueryRepeatMode();
                if(eRepeatMode == E_MPLAYER_REPEAT_NONE)
                {
                    MApp_MPlayer_SetRepeatMode(E_MPLAYER_REPEAT_1);
                }
                else if(eRepeatMode == E_MPLAYER_REPEAT_1)
                {
                    MApp_MPlayer_SetRepeatMode(E_MPLAYER_REPEAT_ALL);
                }
                else
                {
                    MApp_MPlayer_SetRepeatMode(E_MPLAYER_REPEAT_NONE);
                }
            }
            MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_INFOBAR_GROUP);
        // TODO: need to show the repeat mode on screen?
            break;

        case EN_EXE_DMP_PLAYBACK_MOVIEINFO_AB_REPEAT:
            if(MApp_MPlayer_QueryMoviePlayMode() != E_MPLAYER_MOVIE_NORMAL)
            {
                //error handling
                _MApp_ACTdmp_ShowAlertWin(DMP_MSG_TYPE_INVALID_OPERATION);
                MApp_ZUI_API_SetTimer(HWND_DMP_ALERT_WINDOW, DMP_TIMER_INVALID_WIN, DMP_TIME_MS_INVALID_WIN);
                break;
            }
            if(MApp_MPlayer_IsMediaFileInPlaying() &&
                MApp_DMP_GetDmpFlag() & DMP_FLAG_MEDIA_FILE_PLAYING
                && MApp_MPlayer_QueryCurrentMediaType() == E_MPLAYER_TYPE_MOVIE)
            {
            #if ENABLE_DVD
                if (MApp_MPlayer_QueryCurrentFileMediaSubType() == E_MPLAYER_SUBTYPE_DVD)
                {
                    if (!MApp_VDPlayer_DVD_IsAllowed(E_MPLAYER_DVD_CMD_REPEATAB))
                    {
                        _MApp_ACTdmp_MovieCancelRepeatAB();
                        _MApp_ACTdmp_ShowAlertWin(DMP_MSG_TYPE_INVALID_OPERATION);
                        return TRUE;
                    }
                }
                else
            #endif
                {
                    if(!MApp_MPlayer_IsMovieIndexTableExist())
                    {
                        //error handling
                        _MApp_ACTdmp_ShowAlertWin(DMP_MSG_TYPE_INVALID_OPERATION);
                        return TRUE;
                    }
                }

                //FOR TEST - Movie Repeat A->B
                _enDmpPlayStrType =_enDmpPlayIconType =PLAY_MODE_ICON_AB_REPEAT;
                DMP_MovieInfoBarTable[MOVIEINFO_AB_REPEAT][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_AB_REPEAT;
                DMP_MovieInfoBarTable[MOVIEINFO_AB_REPEAT][INFOBAR_STR_IDX] = en_str_DMP_SET_A;

                if(_stDmpPlayVar.stMovieInfo.au32MovieRepeatTime[0] == 0xFFFFFFFF
                    && _stDmpPlayVar.stMovieInfo.au32MovieRepeatTime[1] == 0xFFFFFFFF)
                {
                }
                if(_stDmpPlayVar.stMovieInfo.au32MovieRepeatTime[0] == 0xFFFFFFFF)
                {// Repeat A
                    _enRepeatABStatus = REPEATAB_MODE_A;
                    _enDmpPlayStrType =_enDmpPlayIconType =PLAY_MODE_ICON_SETA;
                    DMP_MovieInfoBarTable[MOVIEINFO_AB_REPEAT][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_AB_REPEAT;
                    DMP_MovieInfoBarTable[MOVIEINFO_AB_REPEAT][INFOBAR_STR_IDX] = en_str_DMP_SET_B;
                    _stDmpPlayVar.stMovieInfo.au32MovieRepeatTime[0] = MApp_VDPlayer_GetInfo(E_VDPLAYER_INFO_CUR_TIME);
                    MApp_MPlayer_MovieSetRepeatAB(E_MPLAYER_MOVIE_SET_REPEAT_A, _stDmpPlayVar.stMovieInfo.au32MovieRepeatTime[0] );
                    //MApp_DMP_SetDmpFlag(DMP_FLAG_MOVIE_REPEATAB_MODE);
                }
                else if(_stDmpPlayVar.stMovieInfo.au32MovieRepeatTime[1] == 0xFFFFFFFF)
                {// Repeat B
                    _enRepeatABStatus = REPEATAB_MODE_AB;
                    _enDmpPlayStrType =_enDmpPlayIconType =PLAY_MODE_ICON_AB_LOOP;
                    DMP_MovieInfoBarTable[MOVIEINFO_AB_REPEAT][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_AB_REPEAT;
                    DMP_MovieInfoBarTable[MOVIEINFO_AB_REPEAT][INFOBAR_STR_IDX] = en_str_DMP_AB_NONE;
                    _stDmpPlayVar.stMovieInfo.au32MovieRepeatTime[1] = MApp_VDPlayer_GetInfo(E_VDPLAYER_INFO_CUR_TIME);
                    if(_stDmpPlayVar.stMovieInfo.au32MovieRepeatTime[1] > _stDmpPlayVar.stMovieInfo.au32MovieRepeatTime[0])
                    {
                        MApp_MPlayer_MovieSetRepeatAB(E_MPLAYER_MOVIE_SET_REPEAT_B, _stDmpPlayVar.stMovieInfo.au32MovieRepeatTime[1] );
                        MApp_DMP_SetDmpFlag(DMP_FLAG_MOVIE_REPEATAB_MODE);
                    }
                    else
                    { //Invalid time : B <= A
                        //error handling

                        _MApp_ACTdmp_MovieCancelRepeatAB();
                        _MApp_ACTdmp_ShowAlertWin(DMP_MSG_TYPE_INVALID_OPERATION);
                    }
                }
                else
                {// Clear A->B
                    _MApp_ACTdmp_MovieCancelRepeatAB();
                }
                MApp_ZUI_API_InvalidateWindow(HWND_DMP_PLAYBACK_INFOBAR_GROUP);
                MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_SHOW);
                MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN, DMP_TIME_MS_PLAY_STATUS_WIN);

            }
            break;
        case EN_EXE_DMP_PLAYBACK_MOVIEINFO_ZOOMIN:
            DMP_DBG(printf("EN_EXE_DMP_PLAYBACK_MOVIEINFO_ZOOMIN\n"););
            {
            #if (FBL_ZOOM==1)
                if(MApi_XC_IsCurrentFrameBufferLessMode() )
                {
                    DMP_DBG(printf("FrameBuffer less mode\n"));
                    _enDmpPlayStrType= PLAY_MODE_ICON_FF_INVALID;
                    _enDmpPlayIconType = PLAY_MODE_ICON_MAX;
                    MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_INFOBAR_GROUP);
                    MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_SHOW);
                    MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN, DMP_TIME_MS_PLAY_STATUS_WIN);
                    break;
                }
            #endif

                if(MApp_MPlayer_IsMediaFileInPlaying() &&
                   (MApp_DMP_GetDmpFlag() & DMP_FLAG_MEDIA_FILE_PLAYING))
                {
                    enumMPlayerZoom eZoomScale;
                    enumMPlayerMediaType eMediaType;
                    eZoomScale = MApp_MPlayer_QueryZoomScale();
                    eMediaType = MApp_MPlayer_QueryCurrentMediaType();
                    switch(eMediaType)
                    {
                        case E_MPLAYER_TYPE_MOVIE:
                            //MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_PAUSE);
                            if(eZoomScale < E_MPLAYER_ZOOM_8)
                            {
                                eZoomScale++;
                                MApp_MPlayer_Zoom(eZoomScale);
                               _enDmpPlayStrType= PLAY_MODE_ICON_ZOOM;
                               _enDmpPlayIconType = PLAY_MODE_ICON_MAX;
                                MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_INFOBAR_GROUP);
                                MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_SHOW);
                                MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN, DMP_TIME_MS_PLAY_STATUS_WIN);

                            }
                            break;
                        default:
                            DMP_DBG(printf("unsupport type for zoomin now!!"););
                            break;
                    }
                }
            }
            break;
        case EN_EXE_DMP_PLAYBACK_MOVIEINFO_ZOOMOUT:
            DMP_DBG(printf("EN_EXE_DMP_PLAYBACK_MOVIEINFO_ZOOMOUT\n"););
            {
            #if (FBL_ZOOM==1)
                if(MApi_XC_IsCurrentFrameBufferLessMode() )
                {
                    DMP_DBG(printf("FrameBuffer less mode\n"));
                    _enDmpPlayStrType = PLAY_MODE_ICON_FF_INVALID;
                    _enDmpPlayIconType = PLAY_MODE_ICON_MAX;
                    MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_INFOBAR_GROUP);
                    MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_SHOW);
                    MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN, DMP_TIME_MS_PLAY_STATUS_WIN);
                    break;
                }
            #endif
                if(MApp_MPlayer_IsMediaFileInPlaying() &&
                    ((MApp_DMP_GetDmpFlag() & DMP_FLAG_MEDIA_FILE_PLAYING)
                    /*|| (MApp_MediaPlayer_GetMediaPlayerStateFlag() & E_FLAG_THUMBNAIL_PLAYING)*/))
                {
                    enumMPlayerZoom eZoomScale;
                    enumMPlayerMediaType eMediaType;
                    eZoomScale = MApp_MPlayer_QueryZoomScale();
                    eMediaType = MApp_MPlayer_QueryCurrentMediaType();
                    switch(eMediaType)
                    {
                        case E_MPLAYER_TYPE_MOVIE:
                            //MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_PAUSE);
                            if(eZoomScale > E_MPLAYER_ZOOM_1_DIV4)
                            {
                                eZoomScale--;
                                MApp_MPlayer_Zoom(eZoomScale);
                               _enDmpPlayStrType= PLAY_MODE_ICON_ZOOM;
                               _enDmpPlayIconType = PLAY_MODE_ICON_MAX;
                                MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_INFOBAR_GROUP);
                                MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_SHOW);
                                MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN, DMP_TIME_MS_PLAY_STATUS_WIN);
                            }
                            break;
                        default:
                            DMP_DBG(printf("unsupport type for zoomout now!!"););
                            break;
                    }
                }
            }
            break;

        case EN_EXE_DMP_PLAYBACK_MOVIEINFO_ASPECT_RATIO:

            if (MApp_MPlayer_QueryMoviePlayMode() == E_MPLAYER_MOVIE_PAUSE)
            {
                _MApp_ACTdmp_ShowAlertWin(DMP_MSG_TYPE_INVALID_OPERATION);
                MApp_ZUI_API_SetTimer(HWND_DMP_ALERT_WINDOW, DMP_TIMER_INVALID_WIN, DMP_TIME_MS_INVALID_WIN);
                break;
            }

            DMP_DBG(printf("EN_EXE_DMP_PLAYBACK_MOVIEINFO_ASPECT_RATIO\n"););
            {
            #if !ENABLE_FBL_ASPECT_RATIO_BY_MVOP
                if(MApi_XC_IsCurrentFrameBufferLessMode() )
                {
                    DMP_DBG(printf("FrameBuffer less mode\n"));
                    _enDmpPlayStrType = PLAY_MODE_ICON_FF_INVALID;
                    _enDmpPlayIconType = PLAY_MODE_ICON_MAX;
                    MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_INFOBAR_GROUP);
                    MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_SHOW);
                    MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN, DMP_TIME_MS_PLAY_STATUS_WIN);
                    break;
                }
            #endif
                if(MApp_MPlayer_IsMediaFileInPlaying() &&
                   (MApp_DMP_GetDmpFlag() & DMP_FLAG_MEDIA_FILE_PLAYING))
                {
                #ifndef ATSC_SYSTEM
                    switch(ST_VIDEO.eAspectRatio)
                    {
                        case EN_AspectRatio_Original:
                            _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_RATIO_4X3;
                            ST_VIDEO.eAspectRatio = EN_AspectRatio_4X3;
                            stSystemInfo[MAIN_WINDOW].enAspectRatio = VIDEOSCREEN_MM_4_3; // Display window: H:V=4:3
                            break;

                        case EN_AspectRatio_4X3:
                            _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_RATIO_16X9;
                            ST_VIDEO.eAspectRatio = EN_AspectRatio_16X9;
                            stSystemInfo[MAIN_WINDOW].enAspectRatio = VIDEOSCREEN_MM_16_9; // Display window: H:V=16:9
                            break;
                        case EN_AspectRatio_16X9:
                            _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_RATIO_Original;
                            ST_VIDEO.eAspectRatio = EN_AspectRatio_Original;
                            stSystemInfo[MAIN_WINDOW].enAspectRatio = VIDEOSCREEN_MM_KEEP_RATIO_AND_SCALE; // H and V scale to fit panel
                            break;
                        default:
                            MS_DEBUG_MSG(printf("Unsupported ST_VIDEO.eAspectRatio %u!!\n",ST_VIDEO.eAspectRatio));
                            MS_DEBUG_MSG(printf("Force to FULL\n"));
                            _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_RATIO_Original;
                            ST_VIDEO.eAspectRatio = EN_AspectRatio_Original;
                            stSystemInfo[MAIN_WINDOW].enAspectRatio = VIDEOSCREEN_MM_KEEP_RATIO_AND_SCALE; // H and V scale to fit panel
                            break;
                    }
                    MApp_MPlayer_Zoom(E_MPLAYER_ZOOM_1); //set normal zoom before adjust aspect ratio
		   #else
                    DMP_DBG(printf("ATSC not support NOW!!!!\n"));
                #endif

                    MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_INFOBAR_GROUP);
                    MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_SHOW);
                    MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN, DMP_TIME_MS_PLAY_STATUS_WIN);
                }
            }
            break;

//=========PHOTO and MOVIE MOVEVIEW==========
            case EN_EXE_DMP_PLAYBACK_MOVIEINFO_MOVEVIEW:
            case EN_EXE_DMP_PLAYBACK_PHOTOINFO_MOVEVIEW:
            DMP_DBG(printf("EN_EXE_DMP_PLAYBACK_MOVIEINFO_MOVEVIEW or EN_EXE_DMP_PLAYBACK_PHOTO_INFO_MOVEVIEW\n"););
            {
                if (MApp_MPlayer_QueryZoomScale() > E_MPLAYER_ZOOM_1)
                {
                    MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_MOVEVIEW_GROUP,SW_SHOW);
                    MApp_ZUI_API_SetFocus(HWND_DMP_PLAYBACK_MOVEVIEW_EXIT);
                }
                else
                {
                    DMP_DBG(printf("Zoom Scale <= 1\n"););
                }
            }
            break;
            case EN_EXE_DMP_PLAYBACK_MOVEVIEW_EXIT:
            DMP_DBG(printf("EN_EXE_DMP_PLAYBACK_MOVEVIEW_EXIT\n"););
            {
                if (MApp_MPlayer_QueryCurrentMediaType() == E_MPLAYER_TYPE_MOVIE)
                {
                    if(MOVIEINFO_MOVEVIEW< _u8InfoBarIdx)
                    {
                        MApp_ZUI_API_SetFocus(_hwndListInfoBar[MOVIEINFO_MOVEVIEW+u8MovieInfoBarMax -_u8InfoBarIdx]);
                    }
                    else
                    {
                        MApp_ZUI_API_SetFocus(_hwndListInfoBar[MOVIEINFO_MOVEVIEW - _u8InfoBarIdx]);
                    }
                    MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_MOVEVIEW_GROUP,SW_HIDE);
                }
                else if (MApp_MPlayer_QueryCurrentMediaType() == E_MPLAYER_TYPE_PHOTO)
                {
                    if(PHOTOINFO_MOVEVIEW < _u8InfoBarIdx)
                    {
                        MApp_ZUI_API_SetFocus(_hwndListInfoBar[PHOTOINFO_MOVEVIEW+u8MovieInfoBarMax -_u8InfoBarIdx]);
                    }
                    else
                    {
                        MApp_ZUI_API_SetFocus(_hwndListInfoBar[PHOTOINFO_MOVEVIEW - _u8InfoBarIdx]);
                    }
                    MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_MOVEVIEW_GROUP,SW_HIDE);
                }
            }
            break;
            case EN_EXE_DMP_PLAYBACK_MOVEVIEW_UP:
            {
                DMP_DBG(printf("EN_EXE_DMP_PLAYBACK_MOVEVIEW_UP\n"););
                MApp_ZUI_API_StoreFocusCheckpoint();
                MApp_ZUI_API_SetFocus(HWND_DMP_PLAYBACK_MOVEVIEW_ARROW_UP);
                if (MApp_MPlayer_QueryCurrentMediaType() == E_MPLAYER_TYPE_MOVIE)
                {
                    MApp_MPlayer_MovieMove(E_MPLAYER_DIRECTION_UP, 100);
                }
                else if (MApp_MPlayer_QueryCurrentMediaType() == E_MPLAYER_TYPE_PHOTO)
                {
                    MApp_MPlayer_PhotoMove(E_MPLAYER_DIRECTION_UP, 100);
                }
                MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_MOVEVIEW_ARROW_UP, 0, 500);
                MApp_ZUI_API_RestoreFocusCheckpoint();
            }
            break;
            case EN_EXE_DMP_PLAYBACK_MOVEVIEW_DOWN:
            {
                DMP_DBG(printf("EN_EXE_DMP_PLAYBACK_MOVEVIEW_DOWN\n"););
                MApp_ZUI_API_StoreFocusCheckpoint();
                MApp_ZUI_API_SetFocus(HWND_DMP_PLAYBACK_MOVEVIEW_ARROW_DOWN);
                if (MApp_MPlayer_QueryCurrentMediaType() == E_MPLAYER_TYPE_MOVIE)
                {
                    MApp_MPlayer_MovieMove(E_MPLAYER_DIRECTION_DOWN, 100);
                }
                else if (MApp_MPlayer_QueryCurrentMediaType() == E_MPLAYER_TYPE_PHOTO)
                {
                    MApp_MPlayer_PhotoMove(E_MPLAYER_DIRECTION_DOWN, 100);
                }
                MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_MOVEVIEW_ARROW_DOWN, 0, 500);
                MApp_ZUI_API_RestoreFocusCheckpoint();
            }
            break;
            case EN_EXE_DMP_PLAYBACK_MOVEVIEW_LEFT:
            {
                DMP_DBG(printf("EN_EXE_DMP_PLAYBACK_MOVEVIEW_LEFT\n"););
                MApp_ZUI_API_StoreFocusCheckpoint();
                MApp_ZUI_API_SetFocus(HWND_DMP_PLAYBACK_MOVEVIEW_ARROW_LEFT);
                if (MApp_MPlayer_QueryCurrentMediaType() == E_MPLAYER_TYPE_MOVIE)
                {
                    MApp_MPlayer_MovieMove(E_MPLAYER_DIRECTION_LEFT, 100);
                }
                else if (MApp_MPlayer_QueryCurrentMediaType() == E_MPLAYER_TYPE_PHOTO)
                {
                    MApp_MPlayer_PhotoMove(E_MPLAYER_DIRECTION_LEFT, 100);
                }
                MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_MOVEVIEW_ARROW_LEFT, 0, 500);
                MApp_ZUI_API_RestoreFocusCheckpoint();
            }
            break;
            case EN_EXE_DMP_PLAYBACK_MOVEVIEW_RIGHT:
            {
                DMP_DBG(printf("EN_EXE_DMP_PLAYBACK_MOVEVIEW_RIGHT\n"););
                MApp_ZUI_API_StoreFocusCheckpoint();
                MApp_ZUI_API_SetFocus(HWND_DMP_PLAYBACK_MOVEVIEW_ARROW_RIGHT);
                if (MApp_MPlayer_QueryCurrentMediaType() == E_MPLAYER_TYPE_MOVIE)
                {
                    MApp_MPlayer_MovieMove(E_MPLAYER_DIRECTION_RIGHT, 100);
                }
                else if (MApp_MPlayer_QueryCurrentMediaType() == E_MPLAYER_TYPE_PHOTO)
                {
                    MApp_MPlayer_PhotoMove(E_MPLAYER_DIRECTION_RIGHT, 100);
                }
                MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_MOVEVIEW_ARROW_RIGHT, 0, 500);
                MApp_ZUI_API_RestoreFocusCheckpoint();
            }
            break;
//=========PHOTOINFO_INFO key===============
        case EN_EXE_DMP_PLAYBACK_PHOTOINFO_PLAY_PAUSE:
            DMP_DBG(printf("EN_EXE_DMP_PLAYBACK_PHOTOINFO_PLAY_PAUSE"););
            {
                if(MApp_MPlayer_QueryPhotoPlayMode() == E_MPLAYER_PHOTO_PAUSE)
                {
                    MApp_MPlayer_PhotoChangePlayMode(E_MPLAYER_PHOTO_NORMAL);
                    _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_PLAY;
                    MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_SHOW);
                    MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN, DMP_TIME_MS_PLAY_STATUS_WIN);
                    DMP_PhotoInfoBarTable[PHOTOINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PAUSE;
                    DMP_PhotoInfoBarTable[PHOTOINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Pause;
                }
                else if(MApp_MPlayer_QueryPhotoPlayMode() == E_MPLAYER_PHOTO_NORMAL)
                {
                    MApp_MPlayer_PhotoChangePlayMode(E_MPLAYER_PHOTO_PAUSE);
                    _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_PAUSE;
                    MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_SHOW);
                    MApp_ZUI_API_KillTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN);
                   // MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN, DMP_TIME_MS_PLAY_STATUS_WIN);
                    DMP_PhotoInfoBarTable[PHOTOINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PLAY;
                    DMP_PhotoInfoBarTable[PHOTOINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Play;
                }
            }
            MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_INFOBAR_GROUP);

            break;
        case EN_EXE_DMP_PLAYBACK_PHOTOINFO_NEXT:
            DMP_DBG(printf("EN_EXE_DMP_PLAYBACK_PHOTOINFO_NEXT"););
            {
                 if (MApp_MPlayer_QueryPhotoPlayMode() == E_MPLAYER_PHOTO_PAUSE)
                {
                    DMP_PhotoInfoBarTable[PHOTOINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PAUSE;
                    DMP_PhotoInfoBarTable[PHOTOINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Pause;
                }
                MApp_MPlayer_PlayNextFile();
                m_u16PlayErrorNum = 0;
                MApp_MPlayer_SetPhotoSlideShowDelayTime(DEFAULT_PHOTO_SLIDESHOW_DELAY_TIME);
                _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_NEXT;
                MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_SHOW);
                MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN, DMP_TIME_MS_PLAY_STATUS_WIN);
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_INFOBAR_GROUP);
            }
            break;
        case EN_EXE_DMP_PLAYBACK_PHOTOINFO_PREV:
            DMP_DBG(printf("EN_EXE_DMP_PLAYBACK_PHOTOINFO_PREV"););
            {
                if (MApp_MPlayer_QueryPhotoPlayMode() == E_MPLAYER_PHOTO_PAUSE)
                {
                    DMP_PhotoInfoBarTable[PHOTOINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PAUSE;
                    DMP_PhotoInfoBarTable[PHOTOINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Pause;
                }
                MApp_MPlayer_PlayPrevFile();
                m_u16PlayErrorNum = 0;
                MApp_MPlayer_SetPhotoSlideShowDelayTime(DEFAULT_PHOTO_SLIDESHOW_DELAY_TIME);
                _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_PREVIOUS;
                MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_SHOW);
                MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN, DMP_TIME_MS_PLAY_STATUS_WIN);
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_INFOBAR_GROUP);
            }
            break;
        case EN_EXE_DMP_PLAYBACK_PHOTOINFO_STOP:
            DMP_DBG(printf("EN_EXE_DMP_PLAYBACK_STOP\n"););
            MApp_ZUI_ACT_ExecuteDmpAction(EN_EXE_DMP_PLAYBACK_BG_EXIT);
/*
            {
                msAPI_Scaler_SetBlueScreen(TRUE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
                MApp_MPlayer_Stop();
                MApp_MPlayer_StopMusic();
                MApp_DMP_ClearDmpFlag(DMP_FLAG_MEDIA_FILE_PLAYING);
                MApp_DMP_UiStateTransition(DMP_UI_STATE_FILE_SELECT);
                MApp_ZUI_API_InvalidateWindow(HWND_MAINFRAME);
                U16 u16PlayingIdx = 0;
                // TODO: fix photo type
                if (!MApp_MPlayer_Change2TargetPath(MApp_MPlayer_QueryCurrentPlayingList()))
                {
                    DMP_DBG(printf("MApp_MPlayer_Change2TargetPath fail EXIT\n");)
                }
                u16PlayingIdx = MApp_MPlayer_QueryCurrentPlayingFileIndex();
                MApp_MPlayer_SetCurrentPageIndex(u16PlayingIdx/NUM_OF_PHOTO_FILES_PER_PAGE);
                DMP_DBG(printf("\n### Current playing idx : %d\n", u16PlayingIdx););
                if(MApp_MPlayer_SetCurrentFile(E_MPLAYER_INDEX_CURRENT_DIRECTORY, u16PlayingIdx) != E_MPLAYER_RET_OK)
                {
                    DMP_DBG(printf("MApp_MPlayer_SetCurrentFile fail 1\n"););
                    MApp_MPlayer_SetCurrentFile(E_MPLAYER_INDEX_CURRENT_DIRECTORY, 0);
                    MApp_MPlayer_SetCurrentPageIndex(0);
                }
            }
*/
            break;
        case EN_EXE_DMP_PLAYBACK_PHOTOINFO_INFO:
            DMP_DBG(printf("EN_EXE_DMP_PLAYBACK_PHOTOINFO_INFO\n"););
            {
                _MApp_ZUI_ACT_DMPMarqueeTextEnableAnimation(
                HWND_DMP_PLAYBACK_PHOTOINFO_INFO_FILENAME_TEXT,TRUE);
                MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_PHOTOINFO_INFO_GROUP, SW_SHOW);
                MApp_ZUI_API_SetFocus(HWND_DMP_PLAYBACK_PHOTOINFO_INFO_INFOCLOSE);
            }
            break;
        case EN_EXE_DMP_PLAYBACK_PHOTOINFO_INFOCLOSE:
            DMP_DBG(printf("EN_EXE_DMP_PLAYBACK_PHOTOINFO_INFOCLOSE\n"););
            {
                _MApp_ZUI_ACT_DMPMarqueeTextEnableAnimation(
                HWND_DMP_PLAYBACK_PHOTOINFO_INFO_FILENAME_TEXT,FALSE);
                MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_PHOTOINFO_INFO_GROUP,SW_HIDE);
                if(PHOTOINFO_INFO < _u8InfoBarIdx)
                {
                    MApp_ZUI_API_SetFocus(_hwndListInfoBar[PHOTOINFO_INFO+u8PhotoInfoBarMax -_u8InfoBarIdx]);
                }
                else
                {
                    MApp_ZUI_API_SetFocus(_hwndListInfoBar[PHOTOINFO_INFO - _u8InfoBarIdx]);
                }
            }
            break;

    #if (ENABLE_MPLAYER_CAPTURE_LOGO== 1)
        // TODO: fix me
        case EN_EXE_DMP_PLAYBACK_PHOTOINFO_CAPTURE:
            DMP_DBG(printf("EN_EXE_DMP_PLAYBACK_PHOTOINFO_CAPTURE\n"););
            {
                switch(MApp_MPlayer_QueryPhotoPlayMode())
                {
                    case E_MPLAYER_PHOTO_NORMAL:
                        _enDmpPlayStrType = PLAY_MODE_ICON_PLAY;
                        break;
                    case E_MPLAYER_PHOTO_PAUSE:
                        _enDmpPlayStrType = PLAY_MODE_ICON_PAUSE;
                        break;
                    default:
                        break;
                }
                MApp_ZUI_API_StoreFocusCheckpoint();
                MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_CONFIRM_DIALOG,SW_SHOW);
                MApp_ZUI_API_SetFocus(HWND_DMP_PLAYBACK_CONFIRM_YES);
                MApp_MPlayer_PhotoChangePlayMode(E_MPLAYER_PHOTO_PAUSE);
            }
            break;
    #endif

        case EN_EXE_DMP_PLAYBACK_PHOTOINFO_ZOOMIN:
            DMP_DBG(printf("EN_EXE_DMP_PLAYBACK_PHOTOINFO_ZOOMIN\n"););
            {
                if(MApp_MPlayer_IsMediaFileInPlaying() &&
                    (MApp_DMP_GetDmpFlag() & DMP_FLAG_MEDIA_FILE_PLAYING))
                {
                    enumMPlayerZoom eZoomScale;
                    enumMPlayerMediaType eMediaType;
                    eZoomScale = MApp_MPlayer_QueryZoomScale();
                    eMediaType = MApp_MPlayer_QueryCurrentMediaType();
                    switch(eMediaType)
                    {
                        case E_MPLAYER_TYPE_PHOTO:
                            if (MApp_MPlayer_QueryPhotoPlayMode() == E_MPLAYER_PHOTO_NORMAL)
                            {
                                _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_PAUSE;
                                MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_SHOW);
                                MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN, DMP_TIME_MS_PLAY_STATUS_WIN);
                                DMP_PhotoInfoBarTable[PHOTOINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PLAY;
                                DMP_PhotoInfoBarTable[PHOTOINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Play;
                                MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_INFOBAR_GROUP);
                                MApp_MPlayer_PhotoChangePlayMode(E_MPLAYER_PHOTO_PAUSE);
                            }
                            if(eZoomScale < E_MPLAYER_ZOOM_8)
                            {
                                eZoomScale++;
                                MApp_MPlayer_Zoom(eZoomScale);
								_enDmpPlayStrType= PLAY_MODE_ICON_ZOOM;
								_enDmpPlayIconType = PLAY_MODE_ICON_MAX;
								 MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_INFOBAR_GROUP);
								 MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_SHOW);
								 MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN, DMP_TIME_MS_PLAY_STATUS_WIN);
                            }
                            break;
                        default:
                            DMP_DBG(printf("unsupport type for zoomin now!!"););
                            break;
                    }
                }
            }
            break;
        case EN_EXE_DMP_PLAYBACK_PHOTOINFO_ZOOMOUT:
            DMP_DBG(printf("EN_EXE_DMP_PLAYBACK_PHOTOINFO_ZOOMOUT\n"););
            {
                if(MApp_MPlayer_IsMediaFileInPlaying() &&
                    ((MApp_DMP_GetDmpFlag() & DMP_FLAG_MEDIA_FILE_PLAYING)
                    /*|| (MApp_MediaPlayer_GetMediaPlayerStateFlag() & E_FLAG_THUMBNAIL_PLAYING)*/))
                {
                    enumMPlayerZoom eZoomScale;
                    enumMPlayerMediaType eMediaType;
                    eZoomScale = MApp_MPlayer_QueryZoomScale();
                    eMediaType = MApp_MPlayer_QueryCurrentMediaType();
                    switch(eMediaType)
                    {
                        case E_MPLAYER_TYPE_PHOTO:
                            if (MApp_MPlayer_QueryPhotoPlayMode() == E_MPLAYER_PHOTO_NORMAL)
                            {
                                _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_PAUSE;
                                MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_SHOW);
                                MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN, DMP_TIME_MS_PLAY_STATUS_WIN);
                                DMP_PhotoInfoBarTable[PHOTOINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PLAY;
                                DMP_PhotoInfoBarTable[PHOTOINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Play;
                                MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_INFOBAR_GROUP);
                                MApp_MPlayer_PhotoChangePlayMode(E_MPLAYER_PHOTO_PAUSE);
                            }
                            if(eZoomScale > E_MPLAYER_ZOOM_1_DIV4)
                            {
                                eZoomScale--;
                                MApp_MPlayer_Zoom(eZoomScale);
								_enDmpPlayStrType= PLAY_MODE_ICON_ZOOM;
								_enDmpPlayIconType = PLAY_MODE_ICON_MAX;
								 MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_INFOBAR_GROUP);
								 MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_SHOW);
								 MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN, DMP_TIME_MS_PLAY_STATUS_WIN);
                            }
                            break;
                        default:
                            DMP_DBG(printf("unsupport type for zoomout now!!"););
                            break;
                    }
                }
            }
            break;
        case EN_EXE_DMP_PLAYBACK_PHOTOINFO_REPEAT:
            DMP_DBG(printf("EN_EXE_DMP_PLAYBACK_PHOTOINFO_REPEAT\n"););
            {
                enumMPlayerRepeatMode eRepeatMode = MApp_MPlayer_QueryRepeatMode();
                if(eRepeatMode == E_MPLAYER_REPEAT_NONE)
                {
                    MApp_MPlayer_SetRepeatMode(E_MPLAYER_REPEAT_1);
                }
                else if(eRepeatMode == E_MPLAYER_REPEAT_1)
                {
                    MApp_MPlayer_SetRepeatMode(E_MPLAYER_REPEAT_ALL);
                }
                else
                {
                    MApp_MPlayer_SetRepeatMode(E_MPLAYER_REPEAT_NONE);
                }
            }
            MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_INFOBAR_GROUP);
        // TODO: need to show the repeat mode on screen?
            break;
        case EN_EXE_DMP_PLAYBACK_PHOTOINFO_MUSIC:
            DMP_DBG(printf("EN_EXE_DMP_PLAYBACK_PHOTOINFO_MUSIC\n"););
            {
                // TODO:  need enhance?
                enumMPlayerRet ret;
                if(MApp_MPlayer_IsMusicPlaying())
                {
                    MApp_MPlayer_StopMusic();
                }
                else
                {
                    MApp_DMP_SetDmpFlag(DMP_FLAG_BGM_MODE);
                    ret = MApp_MPlayer_PlayMusic();
                    if( ret == E_MPLAYER_RET_FAIL)
                        MApp_DMP_ClearDmpFlag(DMP_FLAG_BGM_MODE);
                }
            }
            MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_INFOBAR_GROUP);
            break;
        case EN_EXE_DMP_PLAYBACK_PHOTOINFO_CLOCKWISE:
            DMP_DBG(printf("EN_EXE_DMP_PLAYBACK_PHOTOINFO_CLOCKWISE\n"););
            {
                enumMPlayerPhotoRotate eRotate;

                if(MApp_MPlayer_IsMediaFileInPlaying() &&
                ((MApp_DMP_GetDmpFlag() & DMP_FLAG_MEDIA_FILE_PLAYING)
                /*|| (MApp_DMP_GetDmpFlag() & E_FLAG_THUMBNAIL_PLAYING)*/))
                {
                    enumMPlayerMediaType eMediaType = MApp_MPlayer_QueryCurrentMediaType();
                    switch(eMediaType)
                    {
                        case E_MPLAYER_TYPE_PHOTO:
                            eRotate = MApp_MPlayer_QueryPhotoRotateMode();
                            if(eRotate < E_MPLAYER_PHOTO_ROTATE_270)
                            {
                                eRotate++;
                            }
                            else
                            {
                                eRotate = E_MPLAYER_PHOTO_ROTATE_0;
                            }
                            //UI_DBG(printf(" - (2) Rotate Mode : %bu\n", (U8)eRotate));
                            // TODO: need to refine , pause and play key?
                            if (MApp_MPlayer_QueryPhotoPlayMode() == E_MPLAYER_PHOTO_NORMAL)
                            {
                                MApp_MPlayer_PhotoChangePlayMode(E_MPLAYER_PHOTO_PAUSE);
                                _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_PAUSE;
                                MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_SHOW);
                                MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN, DMP_TIME_MS_PLAY_STATUS_WIN);
                                DMP_PhotoInfoBarTable[PHOTOINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PLAY;
                                DMP_PhotoInfoBarTable[PHOTOINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Play;
                            }
                            MApp_MPlayer_PhotoRotate(eRotate);
                            MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_INFOBAR_GROUP);
                        break;
                        default:
                            break;
                    }
                    //return TRUE;
                }
            }
            break;
        case EN_EXE_DMP_PLAYBACK_PHOTOINFO_COUNTERCLOCKWISE:
            DMP_DBG(printf("EN_EXE_DMP_PLAYBACK_PHOTOINFO_COUNTERCLOCKWISE\n"););
            {
                enumMPlayerPhotoRotate eRotate;

                if(MApp_MPlayer_IsMediaFileInPlaying() &&
                ((MApp_DMP_GetDmpFlag() & DMP_FLAG_MEDIA_FILE_PLAYING)
                /*|| (MApp_MediaPlayer_GetMediaPlayerStateFlag() &
                E_FLAG_THUMBNAIL_PLAYING)*/))
                {
                    enumMPlayerMediaType eMediaType = MApp_MPlayer_QueryCurrentMediaType();
                    switch(eMediaType)
                    {
                        case E_MPLAYER_TYPE_PHOTO:
                            eRotate = MApp_MPlayer_QueryPhotoRotateMode();
                            if(eRotate > E_MPLAYER_PHOTO_ROTATE_0)
                            {
                                eRotate--;
                            }
                            else
                            {
                                eRotate = E_MPLAYER_PHOTO_ROTATE_270;
                            }
                            //UI_DBG(printf(" - (2) Rotate Mode : %bu\n", (U8)eRotate));
                            // TODO: need to refine , pause and play key?
                            if (MApp_MPlayer_QueryPhotoPlayMode() == E_MPLAYER_PHOTO_NORMAL)
                            {
                                MApp_MPlayer_PhotoChangePlayMode(E_MPLAYER_PHOTO_PAUSE);
                                _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_PAUSE;
                                MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_SHOW);
                                MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN, DMP_TIME_MS_PLAY_STATUS_WIN);
                                DMP_PhotoInfoBarTable[PHOTOINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PLAY;
                                DMP_PhotoInfoBarTable[PHOTOINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Play;
                            }
                            MApp_MPlayer_PhotoRotate(eRotate);
                            MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_INFOBAR_GROUP);
                        break;
                        default:
                            break;
                    }
                    //return TRUE;
                }
            }
            break;
        case EN_EXE_DMP_PLAYBACK_PHOTOINFO_PLAYLIST:
            DMP_DBG(printf("EN_EXE_DMP_PLAYBACK_PHOTOINFO_PLAYLIST\n"););
            {
                u8CurrentPlaylistPageIdx = 0;
                u8CurrentPlaylistTotalPage = 1;
                // TODO:calculate how many files in playlist?
                _MApp_ACTdmp_Playback_ShowPlaylistWin(E_MPLAYER_TYPE_PHOTO, TRUE);
            }
            break;
//=====================MUSICINFO key=====================
        case EN_EXE_DMP_PLAYBACK_MUSICINFO_INFO:
            DMP_DBG(printf("EN_EXE_DMP_PLAYBACK_MUSICINFO_INFO"););
            {
                _MApp_ZUI_ACT_DMPMarqueeTextEnableAnimation(
                HWND_DMP_PLAYBACK_MUSICINFO_INFO_FILENAME_TEXT,TRUE);
                MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_MUSICINFO_INFO_GROUP, SW_SHOW);
                MApp_ZUI_API_SetFocus(HWND_DMP_PLAYBACK_MUSICINFO_INFO_INFOCLOSE);
            }
            break;
        case EN_EXE_DMP_PLAYBACK_MUSICINFO_INFOCLOSE:
            DMP_DBG(printf("EN_EXE_DMP_PLAYBACK_MUSICINFO_INFOCLOSE"););
            _MApp_ZUI_ACT_DMPMarqueeTextEnableAnimation(
            HWND_DMP_PLAYBACK_MUSICINFO_INFO_FILENAME_TEXT,FALSE);
            {
                MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_MUSICINFO_INFO_GROUP,SW_HIDE);
                if(MUSICINFO_INFO < _u8InfoBarIdx)
                {
                    MApp_ZUI_API_SetFocus(_hwndListInfoBar[MUSICINFO_INFO+u8MusicInfoBarMax -_u8InfoBarIdx]);
                }
                else
                {
                    MApp_ZUI_API_SetFocus(_hwndListInfoBar[MUSICINFO_INFO - _u8InfoBarIdx]);
                }
            }
            break;
        case EN_EXE_DMP_PLAYBACK_MUSICINFO_NEXT:
            DMP_DBG(printf("EN_EXE_DMP_PLAYBACK_MUSICINFO_NEXT"););
            {
                if (MApp_MPlayer_QueryMusicPlayMode() != E_MPLAYER_MUSIC_NORMAL)
                {
                    DMP_MusicInfoBarTable[MUSICINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PAUSE;
                    DMP_MusicInfoBarTable[MUSICINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Pause;
                    MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_MUSIC_EQ_GROUP, DMP_TIMER_EQ_PLAY, DMP_TIME_MS_EQ_PLAY);
                }
                if(MApp_MPlayer_IsCurrentLRCLyricAvailable() == E_MPLAYER_RET_OK)
                {
                    memset((U8*)_stDmpPlayVar.stMusicInfo.MPlayerLyricBuf, 0, DMP_STRING_BUF_SIZE);
                    MApp_MPlayer_DisableLRCLyric();
                    MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_LYRIC_PAGE,SW_HIDE);
                }
                MApp_MPlayer_PlayNextFile();
                m_u16PlayErrorNum = 0;
                _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_NEXT;
                MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_SHOW);
                MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN, DMP_TIME_MS_PLAY_STATUS_WIN);
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_INFOBAR_GROUP);
            }
            break;
        case EN_EXE_DMP_PLAYBACK_MUSICINFO_PREV:
            DMP_DBG(printf("EN_EXE_DMP_PLAYBACK_MUSICINFO_PREV"););
            {
                if (MApp_MPlayer_QueryMusicPlayMode() != E_MPLAYER_MUSIC_NORMAL)
                {
                    DMP_MusicInfoBarTable[MUSICINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PAUSE;
                    DMP_MusicInfoBarTable[MUSICINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Pause;
                    MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_MUSIC_EQ_GROUP, DMP_TIMER_EQ_PLAY, DMP_TIME_MS_EQ_PLAY);
                }
                if(MApp_MPlayer_IsCurrentLRCLyricAvailable() == E_MPLAYER_RET_OK)
                {
                    memset((U8*)_stDmpPlayVar.stMusicInfo.MPlayerLyricBuf, 0, DMP_STRING_BUF_SIZE);
                    MApp_MPlayer_DisableLRCLyric();
                    MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_LYRIC_PAGE,SW_HIDE);
                }
                g_bPlayPrev = TRUE;
                MApp_MPlayer_PlayPrevFile();
                m_u16PlayErrorNum = 0;
                _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_PREVIOUS;
                MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_SHOW);
                MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN, DMP_TIME_MS_PLAY_STATUS_WIN);
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_INFOBAR_GROUP);
            }
            break;
        case EN_EXE_DMP_PLAYBACK_MUSICINFO_PLAY_PAUSE:
            DMP_DBG(printf("EN_EXE_DMP_PLAYBACK_MUSICINFO_PLAY_PAUSE\n"););
            {
                if(MApp_MPlayer_QueryMusicPlayMode() == E_MPLAYER_MUSIC_PAUSE)
                {
                    MApp_MPlayer_MusicChangePlayMode(E_MPLAYER_MUSIC_NORMAL);
                    _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_PLAY;
                    MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_SHOW);
                    MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN, DMP_TIME_MS_PLAY_STATUS_WIN);
                    DMP_MusicInfoBarTable[MUSICINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PAUSE;
                    DMP_MusicInfoBarTable[MUSICINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Pause;

                    MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_MUSIC_EQ_GROUP, DMP_TIMER_EQ_PLAY, DMP_TIME_MS_EQ_PLAY);
                }
                else if(MApp_MPlayer_QueryMusicPlayMode() == E_MPLAYER_MUSIC_STOP)
                {
                    MApp_MPlayer_MusicChangePlayMode(E_MPLAYER_MUSIC_NORMAL);
                    _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_PLAY;
                    MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_SHOW);
                    MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN, DMP_TIME_MS_PLAY_STATUS_WIN);
                    DMP_MusicInfoBarTable[MUSICINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PAUSE;
                    DMP_MusicInfoBarTable[MUSICINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Pause;
                }
                else if(MApp_MPlayer_QueryMusicPlayMode() == E_MPLAYER_MUSIC_NORMAL)
                {
                    MApp_MPlayer_MusicChangePlayMode(E_MPLAYER_MUSIC_PAUSE);
                    _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_PAUSE;
                    MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_SHOW);
                    MApp_ZUI_API_KillTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN);
                   // MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN, DMP_TIME_MS_PLAY_STATUS_WIN);
                    DMP_MusicInfoBarTable[MUSICINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PLAY;
                    DMP_MusicInfoBarTable[MUSICINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Play;

                    MApp_ZUI_API_KillTimer(HWND_DMP_PLAYBACK_MUSIC_EQ_GROUP, DMP_TIMER_EQ_PLAY);
                }
                else // some FF FB ...
                {
                    MApp_MPlayer_MusicChangePlayMode(E_MPLAYER_MUSIC_NORMAL);
                    _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_PLAY;
                    MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_SHOW);
                    MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN, DMP_TIME_MS_PLAY_STATUS_WIN);
                    DMP_MusicInfoBarTable[MUSICINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PAUSE;
                    DMP_MusicInfoBarTable[MUSICINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Pause;
                    MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_MUSIC_EQ_GROUP, DMP_TIMER_EQ_PLAY, DMP_TIME_MS_EQ_PLAY);
                }
            }
            MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_INFOBAR_GROUP);
            break;
            case EN_EXE_DMP_PLAYBACK_MUSICINFO_PLAYLIST:
                DMP_DBG(printf("EN_EXE_DMP_PLAYBACK_MUSICINFO_PLAYLIST\n"););
                {
                    u8CurrentPlaylistPageIdx = 0;
                    u8CurrentPlaylistTotalPage = 1;
                    _MApp_ACTdmp_Playback_ShowPlaylistWin(E_MPLAYER_TYPE_MUSIC, TRUE);
                }
                break;
                /*
            case EN_EXE_DMP_PLAYBACK_MUSICINFO_PLAYLISTCLOSE:
                DMP_DBG(printf("EN_EXE_DMP_PLAYBACK_MUSICINFO_PLAYLISTCLOSE"););
                break;
                */
        case EN_EXE_DMP_PLAYBACK_MUSICINFO_STOP:
            DMP_DBG(printf("EN_EXE_DMP_PLAYBACK_MUSICINFO_STOP\n"););
            MApp_ZUI_ACT_ExecuteDmpAction(EN_EXE_DMP_PLAYBACK_BG_EXIT);
			MApp_DMP_ClearDmpFlag(DMP_FLAG_BGM_MODE); //minglin0121
			MApp_MPlayer_Stop(); // for bgm
            break;
        case EN_EXE_DMP_PLAYBACK_MUSICINFO_FF:
            DMP_DBG(printf("EN_EXE_DMP_PLAYBACK_MUSICINFO_FF\n"););
            {
                U8 *pu8FfSpeed=MApp_MPlayer_QueryMusicInfo(MP3_INFO_CHECK_FF_FB,NULL);

                if(*pu8FfSpeed != 0)
                {
                    switch(MApp_MPlayer_QueryMusicPlayMode())
                    {
                        case E_MPLAYER_MUSIC_PAUSE:
                            MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_MUSIC_EQ_GROUP, DMP_TIMER_EQ_PLAY,DMP_TIME_MS_EQ_PLAY);
                        case E_MPLAYER_MUSIC_NORMAL:
                        case E_MPLAYER_MUSIC_FB_2X:
                        case E_MPLAYER_MUSIC_FB_4X:
                        case E_MPLAYER_MUSIC_FB_8X:
                        case E_MPLAYER_MUSIC_FB_16X:
                            MApp_MPlayer_MusicChangePlayMode(E_MPLAYER_MUSIC_FF_2X);
                            _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_FF2X;
                            DMP_MusicInfoBarTable[MUSICINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PLAY;
                            DMP_MusicInfoBarTable[MUSICINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Play;
                            break;
                        case E_MPLAYER_MUSIC_FF_2X:
                            MApp_MPlayer_MusicChangePlayMode(E_MPLAYER_MUSIC_FF_4X);
                            _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_FF4X;
                            DMP_MusicInfoBarTable[MUSICINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PLAY;
                            DMP_MusicInfoBarTable[MUSICINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Play;
                            break;
                        case E_MPLAYER_MUSIC_FF_4X:
                            MApp_MPlayer_MusicChangePlayMode(E_MPLAYER_MUSIC_FF_8X);
                            _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_FF8X;
                            DMP_MusicInfoBarTable[MUSICINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PLAY;
                            DMP_MusicInfoBarTable[MUSICINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Play;
                            break;
                        case E_MPLAYER_MUSIC_FF_8X:
                            MApp_MPlayer_MusicChangePlayMode(E_MPLAYER_MUSIC_FF_16X);
                            _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_FF16X;
                            DMP_MusicInfoBarTable[MUSICINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PLAY;
                            DMP_MusicInfoBarTable[MUSICINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Play;
                            break;
                        case E_MPLAYER_MUSIC_FF_16X:
                            MApp_MPlayer_MusicChangePlayMode(E_MPLAYER_MUSIC_NORMAL);
                            _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_PLAY;
                            DMP_MusicInfoBarTable[MUSICINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PAUSE;
                            DMP_MusicInfoBarTable[MUSICINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Pause;
                            MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_MUSIC_EQ_GROUP, DMP_TIMER_EQ_PLAY, DMP_TIME_MS_EQ_PLAY);
                            break;
                        default:
                            DMP_DBG(printf("Current state do not allow trick play!\n"););
                            break;
                    }
                    MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_INFOBAR_GROUP);
                    if (MApp_ZUI_API_IsExistTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN))
                    {
                        MApp_ZUI_API_KillTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN);
                    }
                    MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_SHOW);
                    if (_enDmpPlayIconType == PLAY_MODE_ICON_PLAY)
                    {
                        MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN, DMP_TIME_MS_PLAY_STATUS_WIN);
                    }
                }
                else
                {
                //    _enMediaPlayerIconType = PLAY_MODE_ICON_FF_INVALID;
                //    MApp_ZUI_API_SetTimer(HWND_MEDIA_PLAYER_MUSIC_PLAY_STATUS_ICON, MPLAYER_MUSIC_ICON_TIMER, MUSIC_ICON_PERIOD);
                //    MApp_ZUI_API_InvalidateWindow(HWND_MEDIA_PLAYER_MUSIC_PLAY_STATUS_ICON);
                }
            }
            break;
        case EN_EXE_DMP_PLAYBACK_MUSICINFO_FB:
            DMP_DBG(printf("EN_EXE_DMP_PLAYBACK_MUSICINFO_FB\n"););
            {
                U8 *pu8FfSpeed=MApp_MPlayer_QueryMusicInfo(MP3_INFO_CHECK_FF_FB,NULL);
                if(MApp_MPlayer_QueryMusicFileCurrentTime() < 2) // 2 sec
                {
                    break;
                }
                if(*pu8FfSpeed != 0)
                {
                    switch(MApp_MPlayer_QueryMusicPlayMode())
                    {
                        case E_MPLAYER_MUSIC_PAUSE:
                            MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_MUSIC_EQ_GROUP, DMP_TIMER_EQ_PLAY, DMP_TIME_MS_EQ_PLAY);
                        case E_MPLAYER_MUSIC_NORMAL:
                        case E_MPLAYER_MUSIC_FF_2X:
                        case E_MPLAYER_MUSIC_FF_4X:
                        case E_MPLAYER_MUSIC_FF_8X:
                        case E_MPLAYER_MUSIC_FF_16X:
                            MApp_MPlayer_MusicChangePlayMode(E_MPLAYER_MUSIC_FB_2X);
                            _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_FB2X;
                            DMP_MusicInfoBarTable[MUSICINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PLAY;
                            DMP_MusicInfoBarTable[MUSICINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Play;
                            break;
                        case E_MPLAYER_MUSIC_FB_2X:
                            MApp_MPlayer_MusicChangePlayMode(E_MPLAYER_MUSIC_FB_4X);
                            _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_FB4X;
                            DMP_MusicInfoBarTable[MUSICINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PLAY;
                            DMP_MusicInfoBarTable[MUSICINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Play;
                            break;
                        case E_MPLAYER_MUSIC_FB_4X:
                            MApp_MPlayer_MusicChangePlayMode(E_MPLAYER_MUSIC_FB_8X);
                            _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_FB8X;
                            DMP_MusicInfoBarTable[MUSICINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PLAY;
                            DMP_MusicInfoBarTable[MUSICINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Play;
                            break;
                        case E_MPLAYER_MUSIC_FB_8X:
                            MApp_MPlayer_MusicChangePlayMode(E_MPLAYER_MUSIC_FB_16X);
                            _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_FB16X;
                            DMP_MusicInfoBarTable[MUSICINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PLAY;
                            DMP_MusicInfoBarTable[MUSICINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Play;
                            break;
                        case E_MPLAYER_MUSIC_FB_16X:
                            MApp_MPlayer_MusicChangePlayMode(E_MPLAYER_MUSIC_NORMAL);
                            _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_PLAY;
                            DMP_MusicInfoBarTable[MUSICINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PAUSE;
                            DMP_MusicInfoBarTable[MUSICINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Pause;
                            MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_MUSIC_EQ_GROUP, DMP_TIMER_EQ_PLAY, DMP_TIME_MS_EQ_PLAY);
                            break;
                        default:
                            DMP_DBG(printf("Current state do not allow trick play!\n"););
                            break;
                    }
                    MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_INFOBAR_GROUP);
                    if (MApp_ZUI_API_IsExistTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN))
                    {
                        MApp_ZUI_API_KillTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN);
                    }
                    MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_SHOW);
                    if (_enDmpPlayIconType == PLAY_MODE_ICON_PLAY)
                    {
                        MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN, DMP_TIME_MS_PLAY_STATUS_WIN);
                    }
                }
                else
                {
                //    _enMediaPlayerIconType = PLAY_MODE_ICON_FB_INVALID;
                //    MApp_ZUI_API_SetTimer(HWND_MEDIA_PLAYER_MUSIC_PLAY_STATUS_ICON, MPLAYER_MUSIC_ICON_TIMER, MUSIC_ICON_PERIOD);
                //    MApp_ZUI_API_InvalidateWindow(HWND_MEDIA_PLAYER_MUSIC_PLAY_STATUS_ICON);
                }
            }
            break;
        case EN_EXE_DMP_PLAYBACK_MUSICINFO_MUTE:
            DMP_DBG(printf("EN_EXE_DMP_PLAYBACK_MUSICINFO_MUTE\n"););
            if(MApp_ZUI_API_IsWindowVisible(HWND_DMP_VOLUME_CONFIG_PANE))
                {
                    MApp_ZUI_API_KillTimer(HWND_DMP_VOLUME_LIST, DMP_VOLUME_TIMER);
                    MApp_ZUI_API_ShowWindow(HWND_DMP_VOLUME_LIST, SW_HIDE);
                //    MApp_ZUI_API_RestoreFocusCheckpoint();
                }
            {
            #if 0
                MApp_KeyProc_Mute();
            #else
                MApp_KeyProc_DMPMute();
                MApp_DMP_MuteState(TRUE);
            #endif
            }
            break;
        case EN_EXE_DMP_PLAYBACK_MUSICINFO_REPEAT:
            DMP_DBG(printf("EN_EXE_DMP_PLAYBACK_MUSICINFO_REPEAT\n"););
            {
                // TODO: need test
                enumMPlayerRepeatMode eRepeatMode = MApp_MPlayer_QueryRepeatMode();
                if(eRepeatMode == E_MPLAYER_REPEAT_NONE)
                {
                    MApp_MPlayer_SetRepeatMode(E_MPLAYER_REPEAT_1);

                    //DMP_MusicInfoBarTable[MUSICINFO_REPEAT][INFOBAR_STR_IDX] = en_str_dmp;
                }
                else if(eRepeatMode == E_MPLAYER_REPEAT_1)
                {
                    MApp_MPlayer_SetRepeatMode(E_MPLAYER_REPEAT_ALL);
                }
                else
                {
                    MApp_MPlayer_SetRepeatMode(E_MPLAYER_REPEAT_NONE);
                }
            }
            if(MUSICINFO_REPEAT < _u8InfoBarIdx)
            {
                MApp_ZUI_API_SetFocus(_hwndListInfoBar[MUSICINFO_REPEAT+u8MusicInfoBarMax -_u8InfoBarIdx]);
            }
            else
            {
                MApp_ZUI_API_SetFocus(_hwndListInfoBar[MUSICINFO_REPEAT - _u8InfoBarIdx]);
            };
            MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_INFOBAR_GROUP);
            break;
        #if (ENABLE_MPLAYER_CAPTURE_MUSIC== 1)
        case EN_EXE_DMP_PLAYBACK_MUSICINFO_CAPTURE:
            DMP_DBG(printf("EN_EXE_DMP_PLAYBACK_MUSICINFO_CAPTURE\n"););
            {
                if(MApp_MPlayer_IsMusicRecording() == FALSE)
                {
                    if (MApp_MPlayer_StartCaptureBootUpMusic() == E_MPLAYER_RET_OK)
                    {
                        DMP_MusicInfoBarTable[MUSICINFO_CAPTURE][INFOBAR_STR_IDX] = en_str_DMP_Capture_Stop;
                    }
                }
                else if(MApp_MPlayer_IsMusicRecording() == TRUE)
                {
                    if (MApp_MPlayer_EndCaptureBootUpMusic() == E_MPLAYER_RET_OK)
                    {
                        DMP_MusicInfoBarTable[MUSICINFO_CAPTURE][INFOBAR_STR_IDX] = en_str_DMP_Capture;
                    }
                }
            }
            MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_INFOBAR_GROUP);
            break;
        #endif
        case EN_EXE_DMP_PLAYBACK_MUSICINFO_GOTO_TIME:
            DMP_DBG(printf("EN_EXE_DMP_PLAYBACK_MUSICINFO_GOTO_TIME\n"););
            {
                _u8Hour = 0;
                _u8Minute = 0;
                _u8Second = 0;
                MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_MOVIEINFO_GOTOTIME_GROUP, SW_SHOW);
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_MOVIEINFO_GOTOTIME_GROUP);
                MApp_ZUI_API_SetFocus(HWND_DMP_PLAYBACK_MOVIEINFO_GOTOTIME_HOUR_DIGIT1);
            }
            break;
 //========================TEXTINFO============================//

        case EN_EXE_DMP_PLAYBACK_TEXTINFO_MUSIC:
            DMP_DBG(printf("EN_EXE_DMP_PLAYBACK_TEXTINFO_MUSIC\n"););
            {
                enumMPlayerRet ret;
                if(MApp_MPlayer_IsMusicPlaying())
                {
                    MApp_MPlayer_StopMusic();
                }
                else
                {
                    MApp_DMP_SetDmpFlag(DMP_FLAG_BGM_MODE);
                    ret = MApp_MPlayer_PlayMusic();
                    if( ret == E_MPLAYER_RET_FAIL)
                        MApp_DMP_ClearDmpFlag(DMP_FLAG_BGM_MODE);
                    //if(E_MPLAYER_RET_OK==MApp_MPlayer_PlayMusic())
                    //    MApp_DMP_SetDmpFlag(DMP_FLAG_BGM_MODE);
                }
            }
            MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_INFOBAR_GROUP);
            break;
        case EN_EXE_DMP_PLAYBACK_TEXTINFO_INFO:
            DMP_DBG(printf("EN_EXE_DMP_PLAYBACK_TEXTINFO_INFO\n"););
            _MApp_ZUI_ACT_DMPMarqueeTextEnableAnimation(
            HWND_DMP_PLAYBACK_TEXTINFO_INFO_FILENAME_TEXT,TRUE);
            {
                MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_TEXTINFO_INFO_GROUP, SW_SHOW);
                MApp_ZUI_API_SetFocus(HWND_DMP_PLAYBACK_TEXTINFO_INFO_INFOCLOSE);
            }
            break;
        case EN_EXE_DMP_PLAYBACK_TEXTINFO_INFOCLOSE:
            DMP_DBG(printf("EN_EXE_DMP_PLAYBACK_TEXTINFO_INFOCLOSE\n"););
            _MApp_ZUI_ACT_DMPMarqueeTextEnableAnimation(
            HWND_DMP_PLAYBACK_TEXTINFO_INFO_FILENAME_TEXT,FALSE);
            {
                MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_TEXTINFO_INFO_GROUP,SW_HIDE);
                if(TEXTINFO_INFO < _u8InfoBarIdx)
                {
                    MApp_ZUI_API_SetFocus(_hwndListInfoBar[TEXTINFO_INFO+u8TextInfoBarMax -_u8InfoBarIdx]);
                }
                else
                {
                    MApp_ZUI_API_SetFocus(_hwndListInfoBar[TEXTINFO_INFO - _u8InfoBarIdx]);
                }
            }
            break;
        case EN_EXE_DMP_PLAYBACK_TEXTINFO_PLAYLIST:

            DMP_DBG(printf("EN_EXE_DMP_PLAYBACK_TEXTINFO_PLAYLIST\n"););
            {
                u8CurrentPlaylistPageIdx = 0;
                u8CurrentPlaylistTotalPage = 1;
                _MApp_ACTdmp_Playback_ShowPlaylistWin(E_MPLAYER_TYPE_TEXT, TRUE);
            }
            break;
        // text control===============================
        //Previous Page
        case EN_EXE_DMP_PLAYBACK_TEXTINFO_PREV:
            DMP_DBG(printf("EN_EXE_DMP_PLAYBACK_TEXTINFO_PREV\n"););
            {
                if (MApp_TEXT_GetPageIndex() > 0)
                {
                    if(MApp_MPlayer_TextPrevPage() == E_MPLAYER_RET_OK)
                    {
                        MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_TEXT_FULL_WINDOW);
                    }
                }
            }
            DMP_DBG(printf("EN_EXE_DMP_PLAYBACK_TEXTINFO_PREV %lu %lu\n",MApp_TEXT_GetPageIndex(),MApp_TEXT_GetTotalPage()));
            break;
        case EN_EXE_DMP_PLAYBACK_TEXT_FULL_WIN_PAGE_UP:
            DMP_DBG(printf("EN_EXE_DMP_PLAYBACK_TEXT_FULL_WIN_PAGE_UP\n"););
            {
                if (MApp_TEXT_GetPageIndex() > 0)
                {
                    if(MApp_MPlayer_TextPrevPage() == E_MPLAYER_RET_OK)
                    {
                        MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_TEXT_FULL_WINDOW);
                    }
                }
            }
            DMP_DBG(printf("EN_EXE_DMP_PLAYBACK_TEXT_FULL_WIN_PAGE_UP %lu %lu\n",MApp_TEXT_GetPageIndex(),MApp_TEXT_GetTotalPage()));
            break;
        case EN_EXE_DMP_PLAYBACK_TEXTINFO_NEXT:
            DMP_DBG(printf("EN_EXE_DMP_PLAYBACK_TEXTINFO_NEXT\n"););
            {
                if (MApp_TEXT_GetPageIndex() < MApp_TEXT_GetTotalPage())
                {
                    if(MApp_MPlayer_TextNextPage() == E_MPLAYER_RET_OK)
                    {
                        MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_TEXT_FULL_WINDOW);
                    }
                }
            }
            DMP_DBG(printf("EN_EXE_DMP_PLAYBACK_TEXTINFO_NEXT %lu %lu\n",MApp_TEXT_GetPageIndex(),MApp_TEXT_GetTotalPage()));
            break;
        case EN_EXE_DMP_PLAYBACK_TEXT_FULL_WIN_PAGE_DOWN:
            DMP_DBG(printf("EN_EXE_DMP_PLAYBACK_TEXT_FULL_WIN_PAGE_DOWN\n"););
            {
                if (MApp_TEXT_GetPageIndex() < MApp_TEXT_GetTotalPage())
                {
                    if(MApp_MPlayer_TextNextPage() == E_MPLAYER_RET_OK)
                    {
                        MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_TEXT_FULL_WINDOW);
                    }
                }
            }
            DMP_DBG(printf("EN_EXE_DMP_PLAYBACK_TEXT_FULL_WIN_PAGE_DOWN %lu %lu\n",MApp_TEXT_GetPageIndex(),MApp_TEXT_GetTotalPage()));
            break;
        case EN_EXE_DMP_PLAYBACK_TEXT_FULL_WIN_EXIT:
        case EN_EXE_DMP_PLAYBACK_TEXT_FULL_WIN_STOP:
        case EN_EXE_DMP_PLAYBACK_TEXTINFO_STOP:
            DMP_DBG(printf("EN_EXE_DMP_PLAYBACK_TEXT_FULL_WIN_EXIT\n"););
            {
                // TODO: need refine
                MApp_MPlayer_Stop();
                MApp_MPlayer_StopMusic();
                MApp_DMP_ClearDmpFlag(DMP_FLAG_MEDIA_FILE_PLAYING);
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_MAINFRAME);

                if (!MApp_MPlayer_Change2TargetPath(MApp_MPlayer_QueryCurrentPlayingList()))
                {
                    DMP_DBG(printf("MApp_MPlayer_Change2TargetPath fail EXIT\n");)
                }

                U16 u16PlayingIdx = 0;

                u16PlayingIdx = MApp_MPlayer_QueryCurrentPlayingFileIndex();

                MApp_MPlayer_SetCurrentPageIndex(u16PlayingIdx / NUM_OF_PHOTO_FILES_PER_PAGE);

                DMP_DBG(printf("\n### Current playing idx : %d\n", u16PlayingIdx););

                if (MApp_MPlayer_SetCurrentFile(E_MPLAYER_INDEX_CURRENT_DIRECTORY, u16PlayingIdx) != E_MPLAYER_RET_OK)
                {
                    DMP_DBG(printf("MApp_MPlayer_SetCurrentFile fail 1\n"););
                    MApp_MPlayer_SetCurrentFile(E_MPLAYER_INDEX_CURRENT_DIRECTORY, 0);
                    MApp_MPlayer_SetCurrentPageIndex(0);
                }
                MApp_DMP_UiStateTransition(DMP_UI_STATE_FILE_SELECT);
            }
            break;
        case EN_EXE_DMP_PLAYBACK_TEXTINFO_NEXTFILE:
        case EN_EXE_DMP_PLAYBACK_TEXT_FULL_WIN_NEXT:
            DMP_DBG(printf("EN_EXE_DMP_PLAYBACK_TEXT_FULL_WIN_NEXT\n"););
            {
                MApp_MPlayer_PlayNextFile();
                m_u16PlayErrorNum = 0;
                _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_NEXT;
                MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_SHOW);
                MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN, DMP_TIME_MS_PLAY_STATUS_WIN);
            }
            break;
        case EN_EXE_DMP_PLAYBACK_TEXTINFO_PREVFILE:
        case EN_EXE_DMP_PLAYBACK_TEXT_FULL_WIN_PREVIOUS:
            DMP_DBG(printf("EN_EXE_DMP_PLAYBACK_TEXT_FULL_WIN_PREVIOUS\n"););
            {
                MApp_MPlayer_PlayPrevFile();
                m_u16PlayErrorNum = 0;
                _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_PREVIOUS;
                MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_SHOW);
                MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN, DMP_TIME_MS_PLAY_STATUS_WIN);
            }
            break;
            // TODO: fix below 2 action!?
        case EN_EXE_DMP_PLAYBACK_MAIN_PAGE_ITEM_MENU:
            break;
        case EN_EXE_DMP_PLAYBACK_MAIN_PAGE_ITEM_INPUTSOURCE:
            break;
//==================PLAYLIST ========================//
        case EN_EXE_DMP_PLAYBACK_PLAYLIST_NAV_PAGEUP:
            DMP_DBG(printf("EN_EXE_DMP_PLAYBACK_PLAYLIST_NAV_PAGEUP\n"););
            {
                enumMPlayerMediaType eMediaType = MApp_MPlayer_QueryCurrentMediaType();
                if(u8CurrentPlaylistPageIdx == 0) // first page
                {
                    // do nothing
                }
                else
                {
                    u8CurrentPlaylistPageIdx--;
                    _MApp_ACTdmp_Playback_ShowPlaylistWin(eMediaType, FALSE);
                    MApp_ZUI_API_SetFocus(_hwndListPlaylistItem[UI_DMP_PLAYLIST_NUMBER-1]);
                }
            }
            return TRUE;
        case EN_EXE_DMP_PLAYBACK_PLAYLIST_PAGEUP:
            DMP_DBG(printf("EN_EXE_DMP_PLAYBACK_PLAYLIST_PAGEUP\n"););
            {
                enumMPlayerMediaType eMediaType = MApp_MPlayer_QueryCurrentMediaType();
                if(u8CurrentPlaylistPageIdx == 0) // first page
                {
                    // do nothing
                }
                else
                {
                    u8CurrentPlaylistPageIdx--;
                    _MApp_ACTdmp_Playback_ShowPlaylistWin(eMediaType, FALSE);
                }
            }
            return TRUE;
        case EN_EXE_DMP_PLAYBACK_PLAYLIST_DOWN:
            DMP_DBG(printf("EN_EXE_DMP_PLAYBACK_PLAYLIST_PAGEUP\n"););
            {
                enumMPlayerMediaType eMediaType = MApp_MPlayer_QueryCurrentMediaType();
                U16 u16PlaylistTotalFileNum = 0;
                u16PlaylistTotalFileNum = MApp_MPlayer_QueryPlayListFileNum(eMediaType);
                U16 u16FocusIdx;
                u16FocusIdx = (MApp_ZUI_API_GetFocus() - _hwndListPlaylistItem[0])/2;
                u16FocusIdx += u8CurrentPlaylistPageIdx * UI_DMP_PLAYLIST_NUMBER;

                if(u16PlaylistTotalFileNum == 0) // no selected files
                {
                    u16PlaylistTotalFileNum = MApp_MPlayer_QueryTotalFileNum();
                    u16PlaylistTotalFileNum -= MApp_MPlayer_QueryDirectoryNumber();
                }
                if (u16FocusIdx == u16PlaylistTotalFileNum-1)
                {
                    //last turn;
                    return TRUE;
                }
            }
            break;
        case EN_EXE_DMP_PLAYBACK_PLAYLIST_PAGEDOWN:
            DMP_DBG(printf("EN_EXE_DMP_PLAYBACK_PLAYLIST_PAGEDOWN\n"););
            {
                enumMPlayerMediaType eMediaType = MApp_MPlayer_QueryCurrentMediaType();
                U16 u16PlaylistTotalFileNum = 0;
                u16PlaylistTotalFileNum = MApp_MPlayer_QueryPlayListFileNum(eMediaType);

                // 2 case: has selected files or none
                if(u16PlaylistTotalFileNum == 0) // no selected files
                {
                    U16 u16TotalFileNum = MApp_MPlayer_QueryTotalFileNum();
                    u16TotalFileNum -= MApp_MPlayer_QueryDirectoryNumber();
                    u8CurrentPlaylistTotalPage = (u16TotalFileNum + UI_DMP_PLAYLIST_NUMBER - 1)/UI_DMP_PLAYLIST_NUMBER;
                    if(u8CurrentPlaylistPageIdx == u8CurrentPlaylistTotalPage - 1)
                    {
                        //do nothing
                        return TRUE;
                    }
                    else
                    {
                        u8CurrentPlaylistPageIdx++;
                    }
                }
                else
                {
                    u8CurrentPlaylistTotalPage = (u16PlaylistTotalFileNum + UI_DMP_PLAYLIST_NUMBER - 1)/UI_DMP_PLAYLIST_NUMBER;
                    if(u8CurrentPlaylistPageIdx == u8CurrentPlaylistTotalPage - 1)
                    {
                        //do nothing
                        return TRUE;
                    }
                    else
                    {
                        u8CurrentPlaylistPageIdx++;
                    }
                }
                _MApp_ACTdmp_Playback_ShowPlaylistWin(eMediaType, FALSE);
            }
            return TRUE;

        case EN_EXE_DMP_PLAYBACK_PLAYLIST_SELECT:
            // TODO: can not across different directories, need to change
            // directories, change dirves.......;
            // refer MApp_MPlayer_MusicPlayList_PlayByIdx()
            DMP_DBG(printf("EN_EXE_DMP_PLAYBACK_PLAYLIST_SELECT"););
            {
                enumMPlayerMediaType eMediaType = MApp_MPlayer_QueryCurrentMediaType();
                switch(eMediaType)
                {
                    // TODO: fix every mediaType
                    case E_MPLAYER_TYPE_PHOTO:
                        {
                            //need to check if there is selected files...
                            U16 u16FileIdx;
                            U16 u16PlayingIdx;
                            U32 i;
                            i = (MApp_ZUI_API_GetFocus() - _hwndListPlaylistItem[0])/2;
                            u16PlayingIdx = (u8CurrentPlaylistPageIdx*UI_DMP_PLAYLIST_NUMBER)+ i;
                            if(MApp_MPlayer_QueryPhotoPlayMode() != E_MPLAYER_PHOTO_NORMAL)
                            {
                               _enDmpPlayStrType = _enDmpPlayIconType = PLAY_MODE_ICON_PLAY;
                               MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_SHOW);
                               MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN, DMP_TIME_MS_PLAY_STATUS_WIN);
                            }
                            if(MApp_MPlayer_QueryPlayListFileNum(E_MPLAYER_TYPE_PHOTO) == 0)
                            {
                                //there is no selected file
                                u16PlayingIdx += MApp_MPlayer_QueryDirectoryNumber();
                                //MApp_MPlayer_QueryFileInfo(E_MPLAYER_INDEX_CURRENT_DIRECTORY,u16FileIdx,&FileInfo);
                                MApp_MPlayer_Stop();
                                MApp_MPlayer_SetCurrentFile(E_MPLAYER_INDEX_CURRENT_DIRECTORY,u16PlayingIdx);
                                MApp_MPlayer_Play();
                                MApp_MPlayer_SetPhotoSlideShowDelayTime(DEFAULT_PHOTO_SLIDESHOW_DELAY_TIME);
                            }
                            else
                            {
                                //there are some selected files
                                MApp_MPlayer_Stop();
                                if(!MApp_MPlayer_Change2TargetPath(u16PlayingIdx))
                                {
                                    DMP_DBG(printf("MApp_MPlayer_Change2TargetPath fail PHOTO\n"););
                                }
                                u16FileIdx = MApp_MPlayer_QueryFileIdxByPlayingIdx(u16PlayingIdx);
                                if(MApp_MPlayer_SetCurrentFile(E_MPLAYER_INDEX_CURRENT_DIRECTORY,u16FileIdx)!=E_MPLAYER_RET_OK )
                                {
                                    DMP_DBG(printf("MApp_MPlayer_SetCurrentFile fail PHOTO\n"););
                                }
                                MApp_MPlayer_Play();

                                MApp_MPlayer_SetCurrentPlayingList(u16PlayingIdx);

                                //reset timer
                                MApp_MPlayer_SetPhotoSlideShowDelayTime(DEFAULT_PHOTO_SLIDESHOW_DELAY_TIME);
                            }
                            DMP_PhotoInfoBarTable[PHOTOINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PAUSE;
                            DMP_PhotoInfoBarTable[PHOTOINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Pause;
                            MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_INFOBAR_GROUP);
                        }
                        break;
                    case E_MPLAYER_TYPE_MOVIE:
                        {
                            //need to check if there is selected files...
                            U16 u16FileIdx;
                            U16 u16PlayingIdx;
                            //if(MApp_MPlayer_IsCurrentExternalSubtitleAvailable() == E_MPLAYER_RET_OK)
                            {
#if (ENABLE_SUBTITLE_DMP)
                                MApp_MPlayer_DisableSubtitle();
#endif
                                MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_SUBTITLE_PAGE, SW_HIDE);
                            }

                            U32 i;
                            i = (MApp_ZUI_API_GetFocus() - _hwndListPlaylistItem[0])/2;
                            u16PlayingIdx = (u8CurrentPlaylistPageIdx*UI_DMP_PLAYLIST_NUMBER)+ i;
                            if(MApp_MPlayer_QueryMoviePlayMode() != E_MPLAYER_MOVIE_NORMAL)
                            {
                               _enDmpPlayStrType = _enDmpPlayIconType = PLAY_MODE_ICON_PLAY;
                               MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_SHOW);
                               MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN, DMP_TIME_MS_PLAY_STATUS_WIN);
                            }
                            if(MApp_MPlayer_QueryPlayListFileNum(E_MPLAYER_TYPE_MOVIE) == 0)
                            {
                                //there is no selected file
                                u16PlayingIdx += MApp_MPlayer_QueryDirectoryNumber();
                                //MApp_MPlayer_QueryFileInfo(E_MPLAYER_INDEX_CURRENT_DIRECTORY,u16FileIdx,&FileInfo);
                                MApp_MPlayer_Stop();
                                MApp_MPlayer_SetCurrentFile(E_MPLAYER_INDEX_CURRENT_DIRECTORY,u16PlayingIdx);
                                MApp_MPlayer_Play();
                            }
                            else
                            {
                                //there are some selected files
                                MApp_MPlayer_Stop();
                                if(!MApp_MPlayer_Change2TargetPath(u16PlayingIdx))
                                {
                                    DMP_DBG(printf("MApp_MPlayer_Change2TargetPath fail MOVIE\n"););
                                }
                                  u16FileIdx = MApp_MPlayer_QueryFileIdxByPlayingIdx(u16PlayingIdx);

                                if(MApp_MPlayer_SetCurrentFile(E_MPLAYER_INDEX_CURRENT_DIRECTORY,u16FileIdx)!=E_MPLAYER_RET_OK )
                                {
                                    DMP_DBG(printf("MApp_MPlayer_SetCurrentFile fail MOVIE\n"););
                                }
                                MApp_MPlayer_Play();
                            }


                            DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PAUSE;
                            DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Pause;


                            MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_INFOBAR_GROUP);
                        }
                        break;
                    case E_MPLAYER_TYPE_MUSIC:
                        {
                            if(MApp_MPlayer_QueryMusicPlayMode() != E_MPLAYER_MUSIC_NORMAL)
                            {
                               _enDmpPlayStrType = _enDmpPlayIconType = PLAY_MODE_ICON_PLAY;
                               MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_SHOW);
                               MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN, DMP_TIME_MS_PLAY_STATUS_WIN);
                            }
                            MApp_MPlayer_StopMusic();
                            if(MApp_MPlayer_IsCurrentLRCLyricAvailable() == E_MPLAYER_RET_OK)
                            {
                                MApp_MPlayer_DisableLRCLyric();
                                memset((U8*)_stDmpPlayVar.stMusicInfo.MPlayerLyricBuf, 0, DMP_STRING_BUF_SIZE);
                                MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_LYRIC_PAGE, SW_HIDE);
                            }
                            msAPI_Timer_Delayms(50);
                            U32 i;
                            i = (MApp_ZUI_API_GetFocus() - _hwndListPlaylistItem[0])/2;

                            if((MApp_MPlayer_QueryPlayMode() == E_MPLAYER_PLAY_SELECTED) ||
                                (MApp_MPlayer_QueryPlayMode() == E_MPLAYER_PLAY_SELECTED_FROM_CURRENT))
                            {
                                //there are some selected files
                                U16 u16Idx = (u8CurrentPlaylistPageIdx*UI_DMP_PLAYLIST_NUMBER) + i;

                                MApp_MPlayer_Stop();
                                if(!MApp_MPlayer_Change2TargetPath(u16Idx))
                                {
                                    DMP_DBG(printf("MApp_MPlayer_Change2TargetPath fail music\n"););
                                }
                                U16 u16FileIdx = MApp_MPlayer_QueryFileIdxByPlayingIdx(u16Idx);

                                if(MApp_MPlayer_SetCurrentFile(E_MPLAYER_INDEX_CURRENT_DIRECTORY,u16FileIdx)!=E_MPLAYER_RET_OK )
                                {
                                    DMP_DBG(printf("MApp_MPlayer_SetCurrentFile fail MUSIC\n"););
                                }
                                MApp_MPlayer_Play();
                            }
                            else if(MApp_MPlayer_QueryPlayMode() == E_MPLAYER_PLAY_ONE_DIRECTORY_FROM_CURRENT ||
                                    MApp_MPlayer_QueryPlayMode() == E_MPLAYER_PLAY_ONE_DIRECTORY)
                            {
                                U16 u16PlayingIdx;
                                u16PlayingIdx = (u8CurrentPlaylistPageIdx*UI_DMP_PLAYLIST_NUMBER)+ i;
                                if(MApp_MPlayer_QueryPlayListFileNum(E_MPLAYER_TYPE_MUSIC) == 0)
                                {
                                    //there is no selected file
                                    u16PlayingIdx += MApp_MPlayer_QueryDirectoryNumber();
                                    MApp_MPlayer_Stop();
                                    MApp_MPlayer_SetCurrentFile(E_MPLAYER_INDEX_CURRENT_DIRECTORY,u16PlayingIdx);
                                    MApp_MPlayer_Play();
                                }
                            }
                            DMP_MusicInfoBarTable[MUSICINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PAUSE;
                            DMP_MusicInfoBarTable[MUSICINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Pause;
                            MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_INFOBAR_GROUP);
                        }
                        break;
                    case E_MPLAYER_TYPE_TEXT:
                        {
                            //need to check if there is selected files...
                            U16 u16FileIdx;
                            U16 u16PlayingIdx;
                            U32 i;
                            i = (MApp_ZUI_API_GetFocus() - _hwndListPlaylistItem[0])/2;
                            u16PlayingIdx = (u8CurrentPlaylistPageIdx*UI_DMP_PLAYLIST_NUMBER)+ i;

                            if(MApp_MPlayer_QueryPlayListFileNum(E_MPLAYER_TYPE_TEXT) == 0)
                            {
                                //there is no selected file
                                u16PlayingIdx += MApp_MPlayer_QueryDirectoryNumber();
                                //MApp_MPlayer_QueryFileInfo(E_MPLAYER_INDEX_CURRENT_DIRECTORY,u16FileIdx,&FileInfo);
                                MApp_MPlayer_Stop();
                                MApp_MPlayer_SetCurrentFile(E_MPLAYER_INDEX_CURRENT_DIRECTORY,u16PlayingIdx);
                                MApp_MPlayer_Play();

                            }
                            else
                            {
                                //there are some selected files
                                MApp_MPlayer_Stop();
                                if(!MApp_MPlayer_Change2TargetPath(u16PlayingIdx))
                                {
                                    DMP_DBG(printf("MApp_MPlayer_Change2TargetPath fail text\n"););
                                }
                                u16FileIdx = MApp_MPlayer_QueryFileIdxByPlayingIdx(u16PlayingIdx);

                                if(MApp_MPlayer_SetCurrentFile(E_MPLAYER_INDEX_CURRENT_DIRECTORY,u16FileIdx)!=E_MPLAYER_RET_OK )
                                {
                                    DMP_DBG(printf("MApp_MPlayer_SetCurrentFile fail text\n"););
                                }
                                MApp_MPlayer_Play();
                            }
                        }
                        break;
                    default:
                        DMP_DBG(printf("unsupport EN_EXE_DMP_PLAYBACK_PLAYLIST_SELECT"););
                        break;
                }
            }
            break;
// dialog=================
            case EN_EXE_DMP_PLAYBACK_CONFIRM_DIALOG_YES:
            {
                MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_CONFIRM_DIALOG,SW_HIDE);
                switch(MApp_MPlayer_QueryCurrentMediaType())
                {
                    case E_MPLAYER_TYPE_PHOTO:
                        #if (DISPLAY_LOGO)
                        {
                            if(MApp_MPlayer_CaptureLogo() != E_MPLAYER_RET_OK)
                            {
                                DMP_DBG(printf("save logo fail\n"););
                            }
                        }
                        #endif
                        switch(_enDmpPlayStrType)
                        {
                            case PLAY_MODE_ICON_PLAY:
                                MApp_MPlayer_PhotoChangePlayMode(E_MPLAYER_PHOTO_NORMAL);
                                break;
                            case PLAY_MODE_ICON_PAUSE:
                                MApp_MPlayer_PhotoChangePlayMode(E_MPLAYER_PHOTO_PAUSE);
                                break;
                            default:
                                break;
                        }
                        _enDmpPlayStrType = _enDmpPlayIconType;
                        MApp_ZUI_API_RestoreFocusCheckpoint();
                        MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_INFOBAR_GROUP, SW_SHOW);
                        break;
                    case E_MPLAYER_TYPE_MOVIE:
                        if(MApp_MPlayer_IsMediaFileInPlaying() &&
                            (MApp_DMP_GetDmpFlag() & DMP_FLAG_MEDIA_FILE_PLAYING))
                        {
                            U8 *pu8Filename;
                            pu8Filename = (U8*)msAPI_Memory_Allocate(FILE_INFO_LONG_FILENAME_SIZE, BUF_ID_FILEBROWER);

                            if(pu8Filename == NULL)
                            {
                                __ASSERT(0);
                                return FALSE;
                            }

                            if(MApp_MPlayer_GenCaptureFileName(pu8Filename, FILE_INFO_LONG_FILENAME_SIZE) == E_MPLAYER_RET_OK)
                            {
                                GOP_GwinFBAttr fbAttr;
                                GRAPHIC_DC *dc = MApp_ZUI_API_GetBufferDC();
                                MApi_GOP_GWIN_GetFBInfo(dc->u8FbID, &fbAttr);
                                // Hide all window
                                MApp_ZUI_API_ShowWindow(HWND_MAINFRAME, SW_HIDE);
                                MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_TRANSPARENT_BG, SW_SHOW);
                            #if ENABLE_MPLAYER_VIDEO_CAPTURE
                                if(MApp_MPlayer_CaptureVideo(pu8Filename, &fbAttr) != E_MPLAYER_RET_OK)
                                {
                                    DMP_DBG(printf("MApp_MPlayer_CaptureVideo fail\n"););
                                }
                            #endif
                                MApp_ZUI_API_SetFocus(HWND_DMP_PLAYBACK_TRANSPARENT_BG);
                            }
                            MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_INFO_PANE, SW_SHOW);
                            MApp_ZUI_API_RestoreFocusCheckpoint();
                            msAPI_Memory_Free(pu8Filename, BUF_ID_FILEBROWER);

                            switch(_enDmpPlayStrType)
                            {
                                case PLAY_MODE_ICON_PLAY:
                                    MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_NORMAL);
                                    break;
                                case PLAY_MODE_ICON_PAUSE:
                                    MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_PAUSE);
                                    break;
                                case PLAY_MODE_ICON_FF2X:
                                    MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_FF_2X);
                                    break;
                                case PLAY_MODE_ICON_FF4X:
                                    MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_FF_4X);
                                    break;
                                case PLAY_MODE_ICON_FF8X:
                                    MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_FF_8X);
                                    break;
                                case PLAY_MODE_ICON_FF16X:
                                    MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_FF_16X);
                                    break;
                                case PLAY_MODE_ICON_FF32X:
                                    MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_FF_32X);
                                    break;
                                case PLAY_MODE_ICON_FB2X:
                                    MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_FB_2X);
                                    break;
                                case PLAY_MODE_ICON_FB4X:
                                    MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_FB_4X);
                                    break;
                                case PLAY_MODE_ICON_FB8X:
                                    MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_FB_8X);
                                    break;
                                case PLAY_MODE_ICON_FB16X:
                                    MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_FB_16X);
                                    break;
                                case PLAY_MODE_ICON_FB32X:
                                    MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_FB_32X);
                                    break;
                                case PLAY_MODE_ICON_SF2X:
                                    MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_SF_2X);
                                    break;
                                case PLAY_MODE_ICON_SF4X:
                                    MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_SF_4X);
                                    break;
                                case PLAY_MODE_ICON_SF8X:
                                    MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_SF_8X);
                                    break;
                                case PLAY_MODE_ICON_SF16X:
                                    MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_SF_16X);
                                    break;
                                case PLAY_MODE_ICON_SF32X:
                                    MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_SF_32X);
                                    break;
                                case PLAY_MODE_ICON_SD:
                                    MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_STEP);
                                    break;
                                default:
                                    break;
                            }
                            _enDmpPlayStrType = _enDmpPlayIconType;
                            return TRUE;
                        }
                        break;
                    default:
                        break;

                }
                MApp_ZUI_API_RestoreFocusCheckpoint();
                MApp_ZUI_API_InvalidateWindow(HWND_DMP_PLAYBACK_STATUS_GROUP);
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_INFOBAR_GROUP);
            }
                break;
            case EN_EXE_DMP_PLAYBACK_CONFIRM_DIALOG_NO:
            {
                MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_CONFIRM_DIALOG,SW_HIDE);

                switch(MApp_MPlayer_QueryCurrentMediaType())
                {
                    case E_MPLAYER_TYPE_PHOTO:
                        //MApp_MPlayer_CaptureLogo();
                        switch(_enDmpPlayStrType)
                        {
                            case PLAY_MODE_ICON_PLAY:
                                MApp_MPlayer_PhotoChangePlayMode(E_MPLAYER_PHOTO_NORMAL);
                                break;
                            case PLAY_MODE_ICON_PAUSE:
                                MApp_MPlayer_PhotoChangePlayMode(E_MPLAYER_PHOTO_PAUSE);
                                break;
                             default:
                                break;
                        }
                        _enDmpPlayStrType = _enDmpPlayIconType;
                        break;
                    case E_MPLAYER_TYPE_MOVIE:
                        switch(_enDmpPlayStrType)
                        {
                            case PLAY_MODE_ICON_PLAY:
                                MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_NORMAL);
                                break;
                            case PLAY_MODE_ICON_PAUSE:
                                MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_PAUSE);
                                break;
                            case PLAY_MODE_ICON_FF2X:
                                MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_FF_2X);
                                break;
                            case PLAY_MODE_ICON_FF4X:
                                MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_FF_4X);
                                break;
                            case PLAY_MODE_ICON_FF8X:
                                MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_FF_8X);
                                break;
                            case PLAY_MODE_ICON_FF16X:
                                MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_FF_16X);
                                break;
                            case PLAY_MODE_ICON_FF32X:
                                MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_FF_32X);
                                break;
                            case PLAY_MODE_ICON_FB2X:
                                MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_FB_2X);
                                break;
                            case PLAY_MODE_ICON_FB4X:
                                MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_FB_4X);
                                break;
                            case PLAY_MODE_ICON_FB8X:
                                MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_FB_8X);
                                break;
                            case PLAY_MODE_ICON_FB16X:
                                MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_FB_16X);
                                break;
                            case PLAY_MODE_ICON_FB32X:
                                MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_FB_32X);
                                break;
                            case PLAY_MODE_ICON_SF2X:
                                MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_SF_2X);
                                break;
                            case PLAY_MODE_ICON_SF4X:
                                MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_SF_4X);
                                break;
                            case PLAY_MODE_ICON_SF8X:
                                MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_SF_8X);
                                break;
                            case PLAY_MODE_ICON_SF16X:
                                MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_SF_16X);
                                break;
                            case PLAY_MODE_ICON_SF32X:
                                MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_SF_32X);
                                break;
                            case PLAY_MODE_ICON_SD:
                                MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_STEP);
                                break;
                            default:
                                break;
                        }
                        _enDmpPlayStrType = _enDmpPlayIconType;
                        break;
                    default:
                        break;

                }
                MApp_ZUI_API_RestoreFocusCheckpoint();
                MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_INFOBAR_GROUP, SW_SHOW);
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_INFOBAR_GROUP);
                MApp_ZUI_API_InvalidateWindow(HWND_DMP_PLAYBACK_STATUS_GROUP);
            }
            break;

        #if (CHIP_FAMILY_TYPE==CHIP_FAMILY_M10) || (CHIP_FAMILY_TYPE==CHIP_FAMILY_M12)//compiling error free -- check later
        case EN_EXE_DEC_DMP_MOVIERESUME:
        case EN_EXE_INC_DMP_MOVIERESUME:
            {
                bResume = !bResume;
                MApp_ZUI_API_InvalidateWindow(HWND_DMP_PLAYBACK_MOVIERESUME_PAGE);
                MApp_ZUI_API_ResetTimer(HWND_DMP_PLAYBACK_MOVIERESUME_PAGE, DMP_TIMER_MOVIERESUME_WIN);
            }
            break;
        #endif

        case EN_EXE_DMP_MOVIERESUME_YES:
        {
#if SH_RESUME_AUTOPLAY
			bResume=1;

            if (bResume)
            {
                #if ENABLE_LAST_MEMORY
                //U32 TimeMs,PosL,PosH;
                //MApp_MPlayer_LastMemory_GetResumePos(&TimeMs, &PosL, &PosH);
                stLastMemoryInfo LastMemoryInfo;
                stLastMemoryAttribute* pstAttribute;

                MApp_MPlayer_LastMemory_GetResumePlayInfo(&LastMemoryInfo);
                pstAttribute = &LastMemoryInfo.stLastMemAttribute;
                // need to set _u8Second,_u8Minute,_u8Hour correctly
                //U32 u32GotoTimeMs = (_u8Second+_u8Minute*60+_u8Hour*3600)*1000;
                if(MApp_MPlayer_QueryCurrentMediaType()==E_MPLAYER_TYPE_MUSIC)
                {
                        
                        printf("VVVVVVPTS=%d\r\n",pstAttribute->u32LastMemorySeekPTS);
                        if(0)//(pstAttribute->u32LastMemorySeekPTS > MApp_MPlayer_QueryMusicFilePlayTime())
                        { // Invalid operation
                           // _MApp_ACTdmp_ShowAlertWin(DMP_MSG_TYPE_INVALID_OPERATION);
                            //MApp_ZUI_API_SetTimer(HWND_DMP_ALERT_WINDOW, DMP_TIMER_INVALID_WIN, DMP_TIME_MS_INVALID_WIN);
                        }
                        else
                        {
                            switch(MApp_MPlayer_QueryCurrentFileMediaSubType())
                            {
                            #if (ENABLE_WMA)
                                case E_MPLAYER_SUBTYPE_WMA:
                                    MApp_WMA_ProcessTimeOffset(pstAttribute->u32LastMemorySeekPTS);
                                    break;
                            #endif

                                case E_MPLAYER_SUBTYPE_MP3:
#if 0//(ENABLE_AAC)
                                case E_MPLAYER_SUBTYPE_AAC:
#endif
#if (ENABLE_WAV)
                                case E_MPLAYER_SUBTYPE_WAV:
#endif
#if (ENABLE_OGG)
                                case E_MPLAYER_SUBTYPE_OGG:
#endif
#if 0//( ENABLE_AMR )
                                case E_MPLAYER_SUBTYPE_AMR:
                                case E_MPLAYER_SUBTYPE_AWB:
#endif
#if 0//(ENABLE_FLAC)
                                case E_MPLAYER_SUBTYPE_FLAC:
#endif
printf("VVVVVVPTS222222=%d\r\n",pstAttribute->u32LastMemorySeekPTS);
                                    MApp_Music_ProcessTimeOffset(pstAttribute->u32LastMemorySeekPTS);
                                    break;
                                default:
                                    break;
                            }
                        }
                    }
                else
                	{
                MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_MOVIERESUME_PAGE,SW_HIDE);
                MApp_ZUI_API_KillTimer(HWND_DMP_PLAYBACK_MOVIERESUME_PAGE, DMP_TIMER_MOVIERESUME_WIN);
                if(MApp_ZUI_API_IsWindowVisible(HWND_DMP_PLAYBACK_PAGE_INFOBAR))
                    MApp_ZUI_API_RestoreFocusCheckpoint();
                else
                    MApp_ZUI_API_SetFocus(HWND_DMP_PLAYBACK_TRANSPARENT_BG);

                if(g_bUnsupportAudio)  //20100809EL
                {
                    DMP_DBG(printf(">>>>>>>>>>>222   EN_EXE_DMP_MOVIERESUME_YES   Unsupport audio\n"););
                    _MApp_ACTdmp_ShowAlertWin(DMP_MSG_TYPE_UNSUPPORTED_AUDIO_FILE);
                    MApp_ZUI_API_SetTimer(HWND_DMP_ALERT_WINDOW, DMP_TIMER_INVALID_WIN, DMP_TIME_MS_INVALID_WIN);
                    g_bUnsupportAudio = FALSE;
                }

                //MApp_ZUI_ACT_ExecuteDmpAction(EN_EXE_DMP_MOVIEINFO_GOTOTIME_WIN_SELECT);
                _MApp_ACTdmp_MovieCancelRepeatAB();
                DMP_MovieInfoBarTable[MOVIEINFO_AB_REPEAT][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_AB_REPEAT;
                DMP_MovieInfoBarTable[MOVIEINFO_AB_REPEAT][INFOBAR_STR_IDX] = en_str_DMP_SET_A;
                // To do : process GOTO TIME.
                //printf("[Time] Go : %02d:%02d:%02d (%ld)\n", _u8Hour, _u8Minute, _u8Second, u32GotoTimeMs);
                _u8Hour = 0;
                _u8Minute = 0;
                _u8Second = 0;
                if(pstAttribute->u32LastMemorySeekPTS > MApp_VDPlayer_GetInfo(E_VDPLAYER_INFO_TOTAL_TIME))
                { // Invalid operation
                    //_MApp_MediaPlayer_ShowMessageBox(MOVIE_MESSAGE_TYPE_GOTO_TIME_EXCEED);
                    // TODO: error handling
                    _MApp_ACTdmp_ShowAlertWin(DMP_MSG_TYPE_INVALID_OPERATION);
                    MApp_ZUI_API_SetTimer(HWND_DMP_ALERT_WINDOW, DMP_TIMER_INVALID_WIN, DMP_TIME_MS_INVALID_WIN);
                }
                else
                {
                    // 1. Cancel Repeat AB Mode
                    enumMPlayerRet eRet=E_MPLAYER_RET_FAIL;
                    if(MApp_DMP_GetDmpFlag()& DMP_FLAG_MOVIE_REPEATAB_MODE)
                    {
                        _MApp_ACTdmp_MovieCancelRepeatAB();
                        //    MApp_ZUI_API_ShowWindow(HWND_DMP_MOVIE_INFO_ICON_ADVENCE_GROUP, SW_SHOW);
                    }
                    // 2. Disable trick play --> Normal play
                    if(MApp_MPlayer_QueryMoviePlayMode() != E_MPLAYER_MOVIE_NORMAL)
                    {
                        MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP,SW_HIDE);
                        MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_NORMAL);
                    }
                    eRet=MApp_MPlayer_SetPlayPosition(pstAttribute->u32LastMemorySeekPTS, TRUE);

                    if(eRet==E_MPLAYER_RET_OK)
                    {
                        MApp_MPlayer_MovieChangeAudioTrack(pstAttribute->u16LastAudioTrack);
                    #if ENABLE_SUBTITLE_DMP
                        if(pstAttribute->bSubtitleShow == TRUE)
                        {
                            _stDmpPlayVar.stMovieInfo.bSubtitleOff = FALSE;
                        }
                        else
                        {
                            _stDmpPlayVar.stMovieInfo.bSubtitleOff = TRUE;
                        }
                        MApp_MPlayer_MovieChangeSubtitleTrack(pstAttribute->u16LastSubtitleTrack);
                        _MApp_ZUI_ACTdmp_OperateSubtitle();
                    #endif
                    }
                    else
                    {
                        // TODO: error handling
                        _MApp_ACTdmp_ShowAlertWin(DMP_MSG_TYPE_INVALID_OPERATION);
                        MApp_ZUI_API_SetTimer(HWND_DMP_ALERT_WINDOW, DMP_TIMER_INVALID_WIN, DMP_TIME_MS_INVALID_WIN);
                    }
                }
                #endif
                	}
            }	
            else
            {
                MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_TRANSPARENT_BG,SW_SHOW);
                MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_MOVIERESUME_PAGE,SW_HIDE);
                MApp_ZUI_API_KillTimer(HWND_DMP_PLAYBACK_MOVIERESUME_PAGE, DMP_TIMER_MOVIERESUME_WIN);
                if(MApp_ZUI_API_IsWindowVisible(HWND_DMP_PLAYBACK_PAGE_INFOBAR))
                    MApp_ZUI_API_RestoreFocusCheckpoint();
                else
                    MApp_ZUI_API_SetFocus(HWND_DMP_PLAYBACK_TRANSPARENT_BG);

                if(g_bUnsupportAudio)  //20100809EL
                {
                    DMP_DBG(printf(">>>>>>>>>>>111   EN_EXE_DMP_MOVIERESUME_NO   Unsupport audio\n"););
                    _MApp_ACTdmp_ShowAlertWin(DMP_MSG_TYPE_UNSUPPORTED_AUDIO_FILE);
                    MApp_ZUI_API_SetTimer(HWND_DMP_ALERT_WINDOW, DMP_TIMER_INVALID_WIN, DMP_TIME_MS_INVALID_WIN);
                    g_bUnsupportAudio = FALSE;
                }
            }
            bResume = TRUE; // always reset -> True for next time.
   #endif	         
        }
	
	    //SCM jayden.chen add for not exit playlist OSD, when play playlist moive play	20130308
	   //USBͨ���£�������Ƶ�����������ϵĲ����б���������ʾ�Ƿ��������ѡ����޷��˳������б��˵�
	if(MApp_ZUI_API_IsWindowVisible(HWND_DMP_PLAYBACK_PLAYLIST_GROUP))
	{
		MApp_ZUI_ACT_ExecuteDmpAction(EN_EXE_DMP_PLAYBACK_MOVIEINFO_PLAYLIST);
	}	
        break;

        case EN_EXE_DMP_MOVIERESUME_NO:
            MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_TRANSPARENT_BG,SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_MOVIERESUME_PAGE,SW_HIDE);
            MApp_ZUI_API_KillTimer(HWND_DMP_PLAYBACK_MOVIERESUME_PAGE, DMP_TIMER_MOVIERESUME_WIN);
            if(MApp_ZUI_API_IsWindowVisible(HWND_DMP_PLAYBACK_PAGE_INFOBAR))
                MApp_ZUI_API_RestoreFocusCheckpoint();
            else
                MApp_ZUI_API_SetFocus(HWND_DMP_PLAYBACK_TRANSPARENT_BG);

            if(g_bUnsupportAudio)  //20100809EL
            {
                DMP_DBG(printf(">>>>>>>>>>>111   EN_EXE_DMP_MOVIERESUME_EXIT   Unsupport audio\n"););
                _MApp_ACTdmp_ShowAlertWin(DMP_MSG_TYPE_UNSUPPORTED_AUDIO_FILE);
                MApp_ZUI_API_SetTimer(HWND_DMP_ALERT_WINDOW, DMP_TIMER_INVALID_WIN, DMP_TIME_MS_INVALID_WIN);
                g_bUnsupportAudio = FALSE;
            }
            bResume = TRUE; // always reset -> True for next time.
			
	    //SCM jayden.chen add for not exit playlist OSD, when play playlist moive play		20130308	
	//USBͨ���£�������Ƶ�����������ϵĲ����б���������ʾ�Ƿ��������ѡ����޷��˳������б��˵�
 	if(MApp_ZUI_API_IsWindowVisible(HWND_DMP_PLAYBACK_PLAYLIST_GROUP))
   	{
   		MApp_ZUI_ACT_ExecuteDmpAction(EN_EXE_DMP_PLAYBACK_MOVIEINFO_PLAYLIST);
   	}	
            break;
#if 1//minglin0419
case EN_EXE_DMP_HOTKEY_PICTURE:

            if(MApp_MPlayer_IsMediaFileInPlaying() && (MApp_DMP_GetDmpFlag() & DMP_FLAG_MEDIA_FILE_PLAYING))
            {
                 _enDmpPlayStrType =_enDmpPlayIconType =PLAY_MODE_ICON_PICTURE_MODE;
                ST_VIDEO.ePicture = (EN_MS_PICTURE) MApp_ZUI_ACT_DecIncValue_Cycle(
                    act==EN_EXE_INC_PICTURE_HOTKEY_OPTION,
                    ST_VIDEO.ePicture, PICTURE_MIN, PICTURE_NUMS-1, 1);
                MApp_Picture_Setting_SetColor(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW), MAIN_WINDOW);

                MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_INFOBAR_GROUP);
                // // TODO: need to show the repeat mode on screen?
                MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_SHOW);
                MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN, DMP_TIME_MS_PLAY_STATUS_WIN);
            }
            break;

        case EN_EXE_DMP_HOTKEY_SOUND:
              if(MApp_MPlayer_IsMediaFileInPlaying() && (MApp_DMP_GetDmpFlag() & DMP_FLAG_MEDIA_FILE_PLAYING))
            {
                 _enDmpPlayStrType =_enDmpPlayIconType =PLAY_MODE_ICON_SOUND_MODE;
                 stGenSetting.g_SoundSetting.SoundMode =
                       (EN_SOUND_MODE) MApp_ZUI_ACT_DecIncValue_Cycle(
                            act==EN_EXE_INC_AUDIO_HOTKEY_OPTION,
                            stGenSetting.g_SoundSetting.SoundMode,
                            EN_SoundMode_Standard, EN_SoundMode_Num-1, 1);

                MApi_AUDIO_EnableEQ(FALSE);
                MApi_AUDIO_EnableTone(TRUE);
                MApi_AUDIO_SetBass(stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].Bass);
                MApi_AUDIO_SetTreble(stGenSetting.g_SoundSetting.astSoundModeSetting[stGenSetting.g_SoundSetting.SoundMode].Treble);

                MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_INFOBAR_GROUP);
                // // TODO: need to show the repeat mode on screen?
                MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_SHOW);
                MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN, DMP_TIME_MS_PLAY_STATUS_WIN);
            }
            break;

#endif
        default:
            break;
    }
    return FALSE;
}

// TODO: fix me
extern U32* MApp_TEXT_GetCurrentLineText(BOOLEAN);

LPTSTR MApp_ZUI_ACT_GetDmpDynamicText(HWND hwnd)
{
    memset((void*)CHAR_BUFFER, '\0', 128);
#ifndef ATSC_SYSTEM
    U16 u16TempID = Empty;
#endif
    switch(hwnd)
    {
    #ifndef ATSC_SYSTEM
    //===========================UART BAR
        case HWND_DMP_BAR_OPTION:
            switch(MApp_ZUI_ACT_GetCurrentUARTMode())
            {
                case E_UART_PIU_UART0:
                    u16TempID =(U16)en_str_uart_dbg_HK;
                    break;
                case E_UART_VDEC:
                    u16TempID =(U16)en_str_uart_dbg_VDEC;
                    break;
                case E_UART_AEON:
                    u16TempID =(U16)en_str_uart_dbg_AEON;
                    break;
                default:
                    u16TempID =(U16)en_str_DMP_AB_NONE;
                    break;
            }
            if (u16TempID != Empty)
                return MApp_ZUI_API_GetString(u16TempID);
            break;
    #endif

#if CUS_SMC_ENABLE_HOTEL_MODE
    case HWND_DMP_HOTEL_PASSWD_PANEL_OPTION:
		{
		U8 u16Value = 0;
		for(u16Value = 0; u16Value < PASSWORD_SIZE; u16Value++)
		{
			if(u16Value < g_u8PasswordCount)
				CHAR_BUFFER[u16Value] = '*';
			else
				CHAR_BUFFER[u16Value] = ' ';
		}
		CHAR_BUFFER[PASSWORD_SIZE] = 0;
		return CHAR_BUFFER;
		}
	
	case HWND_DMP_HOTEL_MSG_NOTE_TXT:
        if(HotelLockMode==2)
			u16TempID =(U16)en_strKeyLockMSG;
		else if(HotelLockMode==1)
			u16TempID =(U16)en_strLocalKeyUnlockMSG;
		else
			u16TempID =(U16)en_str_Remote_Control_Lock_MSG;
		return MApp_ZUI_API_GetString(u16TempID);
		break;
#endif

	case HWND_DMP_PLAYBACK_MOVIERESUME_TEXT:
		{
                #if 0
			snprintf((char*)CHAR_BUFFER, 40, "Do you want to resume play?");
			FS_ASCII2Unicode((U8*)CHAR_BUFFER);
			return CHAR_BUFFER;
                #else
                    return MApp_ZUI_API_GetString(en_str_DMP_Movie_Resume);
                #endif
		}
	//===========================INFOBAR
        case HWND_DMP_PLAYBACK_INFOBAR_ITEM1_STRING:
        case HWND_DMP_PLAYBACK_INFOBAR_ITEM2_STRING:
        case HWND_DMP_PLAYBACK_INFOBAR_ITEM3_STRING:
        case HWND_DMP_PLAYBACK_INFOBAR_ITEM4_STRING:
        case HWND_DMP_PLAYBACK_INFOBAR_ITEM5_STRING:
        case HWND_DMP_PLAYBACK_INFOBAR_ITEM6_STRING:
        case HWND_DMP_PLAYBACK_INFOBAR_ITEM7_STRING:
        case HWND_DMP_PLAYBACK_INFOBAR_ITEM8_STRING:
        {
            U32 i;
            for( i = 0; i < DMP_INFOBAR_ICON_NUM; i++)
            {
                if( MApp_ZUI_API_IsSuccessor(_hwndListInfoBar[i], hwnd))
                {
                    break;
                }
            }
            U8 u8InfobarIdx = _u8InfoBarIdx+i;
            switch(MApp_MPlayer_QueryCurrentMediaType())
            {
                case E_MPLAYER_TYPE_MOVIE:
                    //u8InfobarIdx = u8InfobarIdx %u8MovieInfoBarMax;
                    if(u8InfobarIdx >= u8MovieInfoBarMax)
                    {
                        if (MApp_ZUI_API_IsWindowEnabled(MApp_ZUI_API_GetParent(hwnd)))
                        {
                            MApp_ZUI_API_EnableWindow(MApp_ZUI_API_GetParent(hwnd), FALSE);
                        }
                        return 0;
                    }
                    else
                    {
                        if (DMP_MovieInfoBarTable[u8InfobarIdx][INFOBAR_ACT_IDX] == EN_EXE_DMP_PLAYBACK_MOVIEINFO_REPEAT)
                        {
                            DMP_DBG(printf("- Movie Repeat String\n"));

                            if  (MApp_MPlayer_QueryRepeatMode() == E_MPLAYER_REPEAT_ALL)
                            {
                            #if 0
                                snprintf((char*)CHAR_BUFFER, 10, "R_ALL");
                            #else
                                return MApp_ZUI_API_GetString(en_str_DMP_Repeat_All);
                            #endif
                            }
                            else if (MApp_MPlayer_QueryRepeatMode() == E_MPLAYER_REPEAT_1)
                            {
                            #if 0
                                snprintf((char*)CHAR_BUFFER, 9, "R_One");
                            #else
                                return MApp_ZUI_API_GetString(en_str_DMP_Repeat_One);
                            #endif
                            }
                            else
                            {
                            #if 0
                                snprintf((char*)CHAR_BUFFER, 11, "R_None");
                            #else
                                return MApp_ZUI_API_GetString(en_str_DMP_Repeat_None);
                            #endif
                            }
                        #if 0
                            FS_ASCII2Unicode((U8*)CHAR_BUFFER);
                            return CHAR_BUFFER;
                        #endif
                        }
			//BEGIN*********************************************************			
			//SMC jayden.chen add for movi info bar Reapeat AB as the same as playstaus bar 20130308	
			//USBͨ���£���ң���������ü���������ϵ����ò�ͬ��
   			 else if (DMP_MovieInfoBarTable[u8InfobarIdx][INFOBAR_ACT_IDX] == EN_EXE_DMP_PLAYBACK_MOVIEINFO_AB_REPEAT)
   			{
   
   			    //  DMP_DBG(printf("- en_str_DMP_SET_A String=%d \n",DMP_MovieInfoBarTable[u8InfobarIdx][INFOBAR_STR_IDX] ));
   
   				 if (DMP_MovieInfoBarTable[u8InfobarIdx][INFOBAR_STR_IDX] == en_str_DMP_SET_A)
                                   return MApp_ZUI_API_GetString(en_str_DMP_AB_NONE);
  			       else if (DMP_MovieInfoBarTable[u8InfobarIdx][INFOBAR_STR_IDX] == en_str_DMP_SET_B)
   	                                   return MApp_ZUI_API_GetString(en_str_DMP_SET_A);
   			       else if (DMP_MovieInfoBarTable[u8InfobarIdx][INFOBAR_STR_IDX] == en_str_DMP_AB_NONE)
     	                                   return MApp_ZUI_API_GetString(en_str_DMP_SET_B);
			}
			 //END*********************************************************
                        else
                        {
                            //MApp_ZUI_API_EnableWindow(MApp_ZUI_API_GetParent(hwnd), TRUE);
                            return MApp_ZUI_API_GetString(DMP_MovieInfoBarTable[u8InfobarIdx][INFOBAR_STR_IDX]);
                        };
                    }
                    break;
                case E_MPLAYER_TYPE_PHOTO:
                    //u8InfobarIdx = u8InfobarIdx %u8PhotoInfoBarMax;
                    if(u8InfobarIdx >= u8PhotoInfoBarMax)
                    {
                        if (MApp_ZUI_API_IsWindowEnabled(MApp_ZUI_API_GetParent(hwnd)))
                        {
                            MApp_ZUI_API_EnableWindow(MApp_ZUI_API_GetParent(hwnd), FALSE);
                        }
                        return 0;
                    }
                    else
                    {
                        if (DMP_PhotoInfoBarTable[u8InfobarIdx][INFOBAR_ACT_IDX] == EN_EXE_DMP_PLAYBACK_PHOTOINFO_REPEAT)
                        {
                            DMP_DBG(printf("- Photo Repeat String\n"));
                            if  (MApp_MPlayer_QueryRepeatMode() == E_MPLAYER_REPEAT_ALL)
                            {
                            #if 0
                                snprintf((char*)CHAR_BUFFER, 10, "R_ALL");
                            #else
                                return MApp_ZUI_API_GetString(en_str_DMP_Repeat_All);
                            #endif
                            }
                            else if (MApp_MPlayer_QueryRepeatMode() == E_MPLAYER_REPEAT_1)
                            {
                            #if 0
                                snprintf((char*)CHAR_BUFFER, 9, "R_One");
                            #else
                                return MApp_ZUI_API_GetString(en_str_DMP_Repeat_One);
                            #endif
                            }
                            else
                            {
                            #if 0
                                snprintf((char*)CHAR_BUFFER, 11, "R_None");
                            #else
                                return MApp_ZUI_API_GetString(en_str_DMP_Repeat_None);
                            #endif
                            }
                        #if 0
                            FS_ASCII2Unicode((U8*)CHAR_BUFFER);
                            return CHAR_BUFFER;
                        #endif
                        }
                       else if (DMP_PhotoInfoBarTable[u8InfobarIdx][INFOBAR_ACT_IDX] == EN_EXE_DMP_PLAYBACK_PHOTOINFO_MUSIC)
                        {
							if(MApp_MPlayer_IsMusicPlaying())
                            {
                                return MApp_ZUI_API_GetString(en_str_DMP_MusicOn);
                            }
                            {
                                return MApp_ZUI_API_GetString(en_str_DMP_MusicOff);
                            }
                        }
                        else
                        {
                            //MApp_ZUI_API_EnableWindow(MApp_ZUI_API_GetParent(hwnd), TRUE);
                            //MApp_ZUI_API_ShowWindow(MApp_ZUI_API_GetParent(hwnd), SW_SHOW);
                            return MApp_ZUI_API_GetString(DMP_PhotoInfoBarTable[u8InfobarIdx][INFOBAR_STR_IDX]);
                        }
                    }
                    break;
                case E_MPLAYER_TYPE_MUSIC:
                    //u8InfobarIdx = u8InfobarIdx %u8MusicInfoBarMax;
                    if(u8InfobarIdx >= u8MusicInfoBarMax)
                    {
                        if (MApp_ZUI_API_IsWindowEnabled(MApp_ZUI_API_GetParent(hwnd)))
                        {
                            MApp_ZUI_API_EnableWindow(MApp_ZUI_API_GetParent(hwnd), FALSE);
                        }
                        return 0;
                    }
                    else
                    {
                       if (DMP_MusicInfoBarTable[u8InfobarIdx][INFOBAR_ACT_IDX] == EN_EXE_DMP_PLAYBACK_MUSICINFO_REPEAT)
                        {
                            DMP_DBG(printf("- Music Repeat String\n"));
                            if  (MApp_MPlayer_QueryRepeatMode() == E_MPLAYER_REPEAT_ALL)
                            {
                            #if 0
                                snprintf((char*)CHAR_BUFFER, 10, "R_ALL");
                            #else
                                return MApp_ZUI_API_GetString(en_str_DMP_Repeat_All);
                            #endif
                            }
                            else if (MApp_MPlayer_QueryRepeatMode() == E_MPLAYER_REPEAT_1)
                            {
                            #if 0
                                snprintf((char*)CHAR_BUFFER, 9, "R_One");
                            #else
                                return MApp_ZUI_API_GetString(en_str_DMP_Repeat_One);
                            #endif
                            }
                            else
                            {
                            #if 0
                                snprintf((char*)CHAR_BUFFER, 11, "R_None");
                            #else
                                return MApp_ZUI_API_GetString(en_str_DMP_Repeat_None);
                            #endif
                            }
                        #if 0
                            FS_ASCII2Unicode((U8*)CHAR_BUFFER);
                            return CHAR_BUFFER;
                        #endif
                        }
                        else
                        {
                            //MApp_ZUI_API_EnableWindow(MApp_ZUI_API_GetParent(hwnd), TRUE);
                            return MApp_ZUI_API_GetString(DMP_MusicInfoBarTable[u8InfobarIdx][INFOBAR_STR_IDX]);
                        }
                    }
                    break;
                case E_MPLAYER_TYPE_TEXT:
                    //u8InfobarIdx = u8InfobarIdx %u8TextInfoBarMax;
                    if(u8InfobarIdx >u8TextInfoBarMax)
                    {
                        if (MApp_ZUI_API_IsWindowEnabled(MApp_ZUI_API_GetParent(hwnd)))
                        {
                            MApp_ZUI_API_EnableWindow(MApp_ZUI_API_GetParent(hwnd), FALSE);
                        }
                        return 0;
                    }
					else if (DMP_TextInfoBarTable[u8InfobarIdx][INFOBAR_ACT_IDX] == EN_EXE_DMP_PLAYBACK_TEXTINFO_MUSIC)
					 {
						 if(MApp_MPlayer_IsMusicPlaying())
						 {
							 return MApp_ZUI_API_GetString(en_str_DMP_MusicOn);
						 }
						 {
							 return MApp_ZUI_API_GetString(en_str_DMP_MusicOff);
						 }
					 }
                    else
                    {
                        //MApp_ZUI_API_EnableWindow(MApp_ZUI_API_GetParent(hwnd), TRUE);
                        return MApp_ZUI_API_GetString(DMP_TextInfoBarTable[u8InfobarIdx][INFOBAR_STR_IDX]);
                    }
                    break;
                    default:
                        break;
            }
            break;
        }
        //================ [Media Select Page] ==================
        case HWND_DMP_MEDIA_TYPE_USB_STATUS_STRING:
        {
            enumMPlayerUSBDeviceStatus eUSBDeviceStatus;
            if(msAPI_MSDCtrl_IsPortOpened(MSD_PORT_1))
            {
                eUSBDeviceStatus = (enumMPlayerUSBDeviceStatus)msAPI_GetUsbDeviceStatus();
            }
        #if ENABLE_USB_2
            else if(msAPI_MSDCtrl_IsPortOpened(MSD_PORT_2))
            {
                eUSBDeviceStatus = (enumMPlayerUSBDeviceStatus)msAPI_GetUsbDeviceStatusPort2();
            }
        #endif
            else
            {
                eUSBDeviceStatus = E_MPLAYER_USB_NO_DEVICE;
            }
            switch (eUSBDeviceStatus)
            {
                case E_MPLAYER_USB_NO_DEVICE:
                    snprintf((char*)CHAR_BUFFER, 10, "No Device");
                    break;
                case E_MPLAYER_USB_USB11_DEVICE:
                    snprintf((char*)CHAR_BUFFER, 8, "USB 1.1");
                    break;
                case E_MPLAYER_USB_USB20_DEVICE:
                    snprintf((char*)CHAR_BUFFER, 8, "USB 2.0");
                    break;
                case E_MPLAYER_USB_BAD_DEVICE:
                    snprintf((char*)CHAR_BUFFER, 11, "Bad Device");
                    break;
                default:
                    break;
            }
            FS_ASCII2Unicode((U8*)CHAR_BUFFER);
        }
        break;
        //================ [Drive Select Page] ==================
        case HWND_DMP_DRIVE_ITEM1_STRING:
        case HWND_DMP_DRIVE_ITEM2_STRING:
        case HWND_DMP_DRIVE_ITEM3_STRING:
        case HWND_DMP_DRIVE_ITEM4_STRING:
        {
            U8 u8Item = 0;
            for(u8Item = 0; u8Item < DMP_DRIVE_NUM_PER_PAGE; u8Item++)
            {
                if(_hwndListDriveItemString[u8Item] == hwnd)
                {
                    break;
                }
            }
            if(u8Item == 0 && MApp_DMP_GetDrvPageIdx() <= 1)
            {
                return MApp_ZUI_API_GetString(en_str_DMP_Return);
            }
            else
            {
                U8 u8Idx = (MApp_DMP_GetDrvPageIdx()-1) * DMP_DRIVE_NUM_PER_PAGE + u8Item-1;
                if((u8Item < DMP_DRIVE_NUM_PER_PAGE) &&
                    u8Idx < MApp_MPlayer_QueryTotalDriveNum())
                {
                  #if FILE_SYSTEM_GET_VOLUME_LABEL_ENABLE
                    U8 u8VolNm=0;
                    u8VolNm=MApp_MPlayer_GetVolumName(MApp_DMP_GetDriveFromMappingTable(u8Idx),(U8*)CHAR_BUFFER);
                    if(u8VolNm>0)
                    {
                        CHAR_BUFFER[u8VolNm++] = 0x28;
                        CHAR_BUFFER[u8VolNm++] =  'C' + MApp_DMP_GetDriveFromMappingTable(u8Idx);
                        CHAR_BUFFER[u8VolNm++] = 0x3A;
                        CHAR_BUFFER[u8VolNm++] = 0x29;
                        CHAR_BUFFER[u8VolNm++] = 0x00;
                    }
                    else
                  #endif
                    {
                        CHAR_BUFFER[0] = 'C' + MApp_DMP_GetDriveFromMappingTable(u8Idx);
                        CHAR_BUFFER[1] = 0;
                        CHAR_BUFFER[2] = 0;
                        CHAR_BUFFER[3] = 0;
                    }
                }
            }
        }
        break;
        case HWND_DMP_DRIVE_INDEX_CUR_IDX:
        {
            snprintf((char*)CHAR_BUFFER, 3, "%u", MApp_DMP_GetDrvPageIdx());
            FS_ASCII2Unicode((U8*)CHAR_BUFFER);
        }
        break;
        case HWND_DMP_DRIVE_INDEX_TOTAL_NUM:
        {
            snprintf((char*)CHAR_BUFFER, 3, "%u", MApp_MPlayer_QueryTotalDriveNum()/DMP_DRIVE_NUM_PER_PAGE+1);
            FS_ASCII2Unicode((U8*)CHAR_BUFFER);
        }
        break;
        //================ [File Select Page] ==================
        case HWND_DMP_FILE_PAGE_DIR_PATH_STRING:
        {
            U16 au16TmpStr[128];
            U8 au8DrvId[8];

            au8DrvId[0] = 'C' + MApp_DMP_GetDriveFromMappingTable(MApp_DMP_GetCurDrvIdx());
            au8DrvId[1] = 0;
            au8DrvId[2] = 0x3A;
            au8DrvId[3] = 0;
            au8DrvId[4] = 0x5C;
            au8DrvId[5] = 0;
            au8DrvId[6] = 0;
            au8DrvId[7] = 0;
            MApp_MPlayer_GetFullPath(au16TmpStr, 128);
            U16 tmp[8];
            memcpy(tmp,au8DrvId,8);
            MApp_ZUI_API_Strcat(CHAR_BUFFER, tmp);
            MApp_ZUI_API_Strcat(CHAR_BUFFER, au16TmpStr+1);
        }
        break;
        case HWND_DMP_FILE_PAGE_CUR_PAGE_IDX:
        {
            U16 u16PageIdx = MApp_MPlayer_QueryCurrentPageIndex()+1;
            MApp_ZUI_API_GetU16String(u16PageIdx);
        }
        break;
        case HWND_DMP_FILE_PAGE_TOTAL_PAGE_NUM:
        {
            U16 u16PageNum = (MApp_MPlayer_QueryTotalPages() > 0) ?
                                MApp_MPlayer_QueryTotalPages() : 1;
            MApp_ZUI_API_GetU16String(u16PageNum);
        }
        break;
        case HWND_DMP_FILE_PAGE_THUMB_ITEM1_STRING:
        case HWND_DMP_FILE_PAGE_THUMB_ITEM2_STRING:
        case HWND_DMP_FILE_PAGE_THUMB_ITEM3_STRING:
        case HWND_DMP_FILE_PAGE_THUMB_ITEM4_STRING:
        case HWND_DMP_FILE_PAGE_THUMB_ITEM5_STRING:
        case HWND_DMP_FILE_PAGE_THUMB_ITEM6_STRING:
        case HWND_DMP_FILE_PAGE_THUMB_ITEM7_STRING:
        case HWND_DMP_FILE_PAGE_THUMB_ITEM8_STRING:
#ifdef ENABLE_SMC_UI_NEW     /* smc.qxr 20121029 */
        case HWND_DMP_PHOTO_PAGE_THUMB_ITEM1_STRING:
        case HWND_DMP_PHOTO_PAGE_THUMB_ITEM2_STRING:
        case HWND_DMP_PHOTO_PAGE_THUMB_ITEM3_STRING:
        case HWND_DMP_PHOTO_PAGE_THUMB_ITEM4_STRING:
        case HWND_DMP_PHOTO_PAGE_THUMB_ITEM5_STRING:
        case HWND_DMP_PHOTO_PAGE_THUMB_ITEM6_STRING:
        case HWND_DMP_PHOTO_PAGE_THUMB_ITEM7_STRING:
        case HWND_DMP_PHOTO_PAGE_THUMB_ITEM8_STRING:
        case HWND_DMP_PHOTO_PAGE_THUMB_ITEM9_STRING:
        case HWND_DMP_PHOTO_PAGE_THUMB_ITEM10_STRING:
        case HWND_DMP_PHOTO_PAGE_THUMB_ITEM11_STRING:
        case HWND_DMP_PHOTO_PAGE_THUMB_ITEM12_STRING:
#else
        case HWND_DMP_FILE_PAGE_THUMB_ITEM9_STRING:
        case HWND_DMP_FILE_PAGE_THUMB_ITEM10_STRING:
        case HWND_DMP_FILE_PAGE_THUMB_ITEM11_STRING:
        case HWND_DMP_FILE_PAGE_THUMB_ITEM12_STRING:
#endif
        {
            U16 u16ItemIdx = 0;
            MPlayerFileInfo fileInfo;
            for(u16ItemIdx=0;u16ItemIdx<NUM_OF_PHOTO_FILES_PER_PAGE;u16ItemIdx++)
            {
                if(hwnd == _hwndListFileString[u16ItemIdx])
                {
                    break;
                }
            }
            //printf("[%d]\n", u16ItemIdx);
            if((u16ItemIdx < NUM_OF_PHOTO_FILES_PER_PAGE) &&
                (MApp_MPlayer_QueryFileInfo(E_MPLAYER_INDEX_CURRENT_PAGE, u16ItemIdx, &fileInfo) == E_MPLAYER_RET_OK))
            {
                //printf("%d. EXT Name : %s\n", u16ItemIdx, fileInfo.u8ExtFileName);
                if(fileInfo.eAttribute & E_MPLAYER_FILE_DIRECTORY)
                {
                    if(fileInfo.u8LongFileName[0] == 0x2e &&
                       fileInfo.u8LongFileName[1] == 0x00 &&
                       fileInfo.u8LongFileName[2] == 0x00 &&
                       fileInfo.u8LongFileName[3] == 0x00)
                    {
                        return MApp_ZUI_API_GetString(en_str_DMP_Return);
                    }
                    else if(fileInfo.u8LongFileName[0] == 0x2e &&
                           fileInfo.u8LongFileName[1] == 0x00 &&
                           fileInfo.u8LongFileName[2] == 0x2e &&
                           fileInfo.u8LongFileName[3] == 0x00 &&
                           fileInfo.u8LongFileName[4] == 0x00)
                    {
                        return MApp_ZUI_API_GetString(en_str_DMP_UpFolderText);
                    }
                }
                memcpy(CHAR_BUFFER, fileInfo.u8LongFileName, sizeof(fileInfo.u8LongFileName));
            }
        }
        break;
        case HWND_DMP_FILE_PAGE_PREVIEW_FILENAME_STRING:
        {
            U16 u16ItemIdx = 0;
            MPlayerFileInfo fileInfo;

            for(u16ItemIdx=0;u16ItemIdx<NUM_OF_PHOTO_FILES_PER_PAGE;u16ItemIdx++)
            {
                if(MApp_ZUI_API_GetFocus() == _hwndListFileItem[u16ItemIdx])
                {
                    break;
                }
            }

            if (u16ItemIdx == NUM_OF_PHOTO_FILES_PER_PAGE)
            {
                //Focus on AlertWin
                for(u16ItemIdx=0;u16ItemIdx<NUM_OF_PHOTO_FILES_PER_PAGE;u16ItemIdx++)
                {
                    if(MApp_ZUI_API_GetFocusCheckpoint() == _hwndListFileItem[u16ItemIdx])
                    {
                        break;
                    }
                }
            }
            //printf("[%d] focus = %d\n", u16ItemIdx);
            if((u16ItemIdx < NUM_OF_PHOTO_FILES_PER_PAGE) &&
               (MApp_MPlayer_QueryFileInfo(E_MPLAYER_INDEX_CURRENT_PAGE, u16ItemIdx, &fileInfo) == E_MPLAYER_RET_OK))
            {
                if(fileInfo.eAttribute & E_MPLAYER_FILE_DIRECTORY)
                {
                    if(fileInfo.u8LongFileName[0] == 0x2e &&
                       fileInfo.u8LongFileName[1] == 0x00 &&
                       fileInfo.u8LongFileName[2] == 0x00 &&
                       fileInfo.u8LongFileName[3] == 0x00)
                    {
                        return MApp_ZUI_API_GetString(en_str_DMP_Return);
                    }
                }
                memcpy(CHAR_BUFFER, fileInfo.u8LongFileName, sizeof(fileInfo.u8LongFileName));
            }
        }
        break;
        case HWND_DMP_ALERT_STRING:
        {
            switch(_enDmpMsgType)
            {
                case DMP_MSG_TYPE_LOADING:
                #if 0
                    snprintf((char*)CHAR_BUFFER, 11, "Loading...");
                    break;
                #else
                    return MApp_ZUI_API_GetString(en_str_USB_Loadingfile);
                #endif
                case DMP_MSG_TYPE_UNSUPPORTED_FILE:
                #if ENABLE_DRM
                    if (MApp_VDPlayer_GetInfo(E_VDPLAYER_INFO_DRM_FILE_FORMAT)==TRUE)
                    {
                    #if 0
                        snprintf((char*)CHAR_BUFFER, 25, "DRM file can not preview");
                    #else
                        return MApp_ZUI_API_GetString(en_str_USB_DRMfileNotPreview);
                    #endif
                    }
                    else
                    {
                    #if 0
                        snprintf((char*)CHAR_BUFFER, 17, "Unsupported File");
                    #else
                        return MApp_ZUI_API_GetString(en_str_USB_UnsupportedFile);
                    #endif
                    }
                #else
                    snprintf((char*)CHAR_BUFFER, 17, "Unsupported File");
                #endif
                    break;
                case DMP_MSG_TYPE_INVALID_OPERATION:
                #if 0
                    snprintf((char*)CHAR_BUFFER, 18, "Invalid Operation");
                    break;
                #else
                    return MApp_ZUI_API_GetString(en_str_USB_InvalidOperation);
                #endif
                case DMP_MSG_TYPE_PASTE_NOT_SUPPORT_NTFS:
                #if 0
                    snprintf((char*)CHAR_BUFFER, 22, "NTFS is not supported");
                    break;
                #else
                    return MApp_ZUI_API_GetString(en_str_USB_NTFSnotSupported);
                #endif
                case DMP_MSG_TYPE_PASTE_FILE_ERROR:
                #if 0
                    snprintf((char*)CHAR_BUFFER, 18, "Paste file failed");
                    break;
                #else
                    return MApp_ZUI_API_GetString(en_str_USB_PasteFileFailed);
                #endif
                case DMP_MSG_TYPE_DISK_FULL:
                #if 0
                    snprintf((char*)CHAR_BUFFER, 10, "Disk Full");
                #else
                    return MApp_ZUI_API_GetString(en_str_USB_DiskFull);
                #endif
                    break;
                case DMP_MSG_TYPE_ALL_FILES_UNSUPPORTED:
                #if 0
                    snprintf((char*)CHAR_BUFFER, 22, "All Files Unsupported");
                    break;
                #else
                    return MApp_ZUI_API_GetString(en_str_USB_AllFilesUnsupported);
                #endif
                case DMP_MSG_TYPE_UNSUPPORTED_AUDIO_FILE:  //20100809EL
                #if 0
                    snprintf((char*)CHAR_BUFFER, 25, "Unsupported Audio Format");
                    break;
                #else
                    return MApp_ZUI_API_GetString(en_str_USB_UnsupportedAudioFormat);
                #endif
		case DMP_MSG_TYPE_UNSUPPORTED_VIDEO_RESOLUTION:
                #if 0
		   snprintf((char*)CHAR_BUFFER, 25, "Video res. not supported");
		   break;
                #else
                    return MApp_ZUI_API_GetString(en_str_USB_VideoResNotSupported);
                #endif
                default:
                #if 0
                    snprintf((char*)CHAR_BUFFER, 8, "Unknown");
                    break;
                #else
                    return MApp_ZUI_API_GetString(en_str_USB_Unknown);
                #endif
            }
            FS_ASCII2Unicode((U8*)CHAR_BUFFER);
        }
        break;
        case HWND_DMP_PROGRESS_MSG:
        {
            if(MApp_DMP_GetDmpUiState() == DMP_UI_STATE_FILE_SELECT)
            {
            #if 0
                snprintf((char*)CHAR_BUFFER, 11, "Pasting...");
            #else
                return MApp_ZUI_API_GetString(en_str_USB_Pasting);
            #endif
            }
        #if 0
          #if (ENABLE_POWERON_MUSIC)
            else if(MApp_DMP_GetDmpUiState() == DMP_UI_STATE_PLAYING_STAGE)
            {
                snprintf((char*)CHAR_BUFFER, 12, "Recording...");
            }
          #endif
        #endif
            FS_ASCII2Unicode((U8*)CHAR_BUFFER);
        }
        break;

        case HWND_DMP_PROGRESS_PERCENT:
        {
            if(MApp_DMP_GetDmpUiState() == DMP_UI_STATE_FILE_SELECT)
            {
                snprintf((char*)CHAR_BUFFER, 5, "%u%c", MApp_MPlayer_QueryPasteFileStatus(), '%');
            }
        #if 0
          #if (ENABLE_POWERON_MUSIC)
            else if(MApp_DMP_GetDmpUiState() == DMP_UI_STATE_PLAYING_STAGE)
            {
                U32 u32Percent = MApp_Music_GetRecordingTime()/(USER_MP3_CAPTURE_TIMEOUT/100);
                snprintf((char*)CHAR_BUFFER, 5, "%d%c", (U16)u32Percent, '%');
            }
          #endif
        #endif
            FS_ASCII2Unicode((U8*)CHAR_BUFFER);
        }
        break;
        case HWND_DMP_PLAYBACK_PAGE_TIME_TOTAL:
        {
            switch(MApp_MPlayer_QueryCurrentMediaType())
            {
                case E_MPLAYER_TYPE_MOVIE:
                {
                    if (!MApp_MPlayer_IsMoviePlaying())
                    {
                        snprintf((char*)CHAR_BUFFER, 9, "00:00:00");
                    }
                    else
                    {
                        U32 totalTime;
                        U8 u8Hour, u8Min, u8Sec;

                        totalTime = MApp_VDPlayer_GetInfo(E_VDPLAYER_INFO_TOTAL_TIME);

                        if(totalTime != 0xFFFFFFFF
                            && totalTime != 0)
                        {
                            totalTime /= 1000;
                            totalTime = totalTime>0 ? totalTime:0;
                            u8Hour = (U8)(totalTime/3600);
                            u8Min = (U8)(totalTime/60-u8Hour*60);
                            u8Sec = (U8)(totalTime-u8Hour*3600-u8Min*60);
                            _u16MovieTotalTime = ((u8Hour*60)+u8Min)*60+u8Sec;
                            snprintf((char*)CHAR_BUFFER, 9, "%02d:%02d:%02d", u8Hour,u8Min,u8Sec);
                        }
                        else if(totalTime == 0)
                        {
                             snprintf((char*)CHAR_BUFFER, 9, "00:00:00");
                        }
                        else
                        {
                            snprintf((char*)CHAR_BUFFER, 9, "--:--:--");
                        }
                    }
                }
                break;
                case E_MPLAYER_TYPE_MUSIC:
                {
                    if (!MApp_MPlayer_IsMusicPlaying())
                    {
                        snprintf((char*)CHAR_BUFFER, 9, "00:00:00");
                    }
                    else
                    {
                        U32 totalTime;
                        U8 u8Hour, u8Min, u8Sec;

                        totalTime = MApp_MPlayer_QueryMusicFilePlayTime();

                        if(totalTime != 0xFFFFFFFF
                            && totalTime != 0)
                        {

                            u8Hour = (U8)(totalTime/3600);
                            u8Min = (U8)(totalTime/60-u8Hour*60);
                            u8Sec = (U8)(totalTime-u8Hour*3600-u8Min*60);
                            snprintf((char*)CHAR_BUFFER, 9, "%02d:%02d:%02d", u8Hour,u8Min,u8Sec);
                        }
                        else
                        {
                            snprintf((char*)CHAR_BUFFER, 9, "--:--:--");
                        }
                    }
                }
                break;
                default:
                    break;
            }
            FS_ASCII2Unicode((U8*)CHAR_BUFFER);
        }
        break;

        case HWND_DMP_PLAYBACK_PAGE_TIME_CURRENT:
        {
            switch(MApp_MPlayer_QueryCurrentMediaType())
            {
                case E_MPLAYER_TYPE_MOVIE:
                    if (!MApp_MPlayer_IsMoviePlaying())
                    {
                        snprintf((char*)CHAR_BUFFER, 9, "00:00:00");
                    }
                    else
                    {
                        U32 currentTime;
                        U8 u8Min, u8Sec;
                        S8 s8Hour = 0;

                        if(_enNotify == E_MPLAYER_NOTIFY_END_OF_PLAY_ONE_FILE
                            || _enNotify == E_MPLAYER_NOTIFY_END_OF_PLAY_ALL_FILE
                          #ifdef MEDIA_PLAYER_HIGHLIGHT_CHANGE
                            || _enNotify == E_MPLAYER_NOTIFY_PLAY_NEXT_FILE
                          #endif
                            )
                        {
                            if ((_enPlayMode_AtNotify >= E_MPLAYER_MOVIE_FB_2X) &&
                                (_enPlayMode_AtNotify <= E_MPLAYER_MOVIE_FB_32X))
                            {
                                // If FB to beginning of file, still show current time, it should be 0.
                                currentTime = MApp_VDPlayer_GetInfo(E_VDPLAYER_INFO_CUR_TIME)/1000;
                            }
                            else
                            {
                                currentTime = MApp_VDPlayer_GetInfo(E_VDPLAYER_INFO_TOTAL_TIME)/1000;
                            }

                        }
                        else
                        {
                            currentTime = MApp_VDPlayer_GetInfo(E_VDPLAYER_INFO_CUR_TIME)/1000;
                        }

                        currentTime = currentTime>0 ? currentTime:0;
                        s8Hour = (currentTime/3600);
                        u8Min = (U8)(currentTime/60-s8Hour*60);
                        u8Sec = (U8)(currentTime-s8Hour*3600-u8Min*60);
                        _u16MovieCurrentTime = ((s8Hour*60)+u8Min)*60+u8Sec;
                        if(s8Hour >= 0 && s8Hour <= 48)
                        {
                            snprintf((char*)CHAR_BUFFER, 9, "%02d:%02d:%02d", s8Hour,u8Min,u8Sec);
                        }
                        else
                        {// If we get an invalid time, reset time info.
                            snprintf((char*)CHAR_BUFFER, 9, "00:00:00");
                        }
                    }
                    break;
                    case E_MPLAYER_TYPE_MUSIC:
                    {
                        if (!MApp_MPlayer_IsMusicPlaying())
                        {
                            snprintf((char*)CHAR_BUFFER, 9, "00:00:00");
                        }
                        else
                        {
                            U32 currentTime;
                            U8 u8Min, u8Sec;
                            S8 s8Hour = 0;
                            currentTime =_u32MusicCurrentTime ;

                            currentTime = currentTime>0 ? currentTime:0;
                            s8Hour = (currentTime/3600);
                            u8Min = (U8)(currentTime/60-s8Hour*60);
                            u8Sec = (U8)(currentTime-s8Hour*3600-u8Min*60);
                            if(s8Hour >= 0 && s8Hour <= 99)
                            {
                                snprintf((char*)CHAR_BUFFER, 9, "%02d:%02d:%02d", s8Hour,u8Min,u8Sec);
                            }
                            else if(s8Hour >= 100)
                            {
                                snprintf((char*)CHAR_BUFFER, 10, "%03d:%02d:%02d", s8Hour,u8Min,u8Sec);
                            }
                            else
                            {// If we get an invalid time, reset time info.
                                snprintf((char*)CHAR_BUFFER, 9, "00:00:00");
                            }
                        }
                    }
                    break;
                    default:
                        break;
                }
            FS_ASCII2Unicode((U8*)CHAR_BUFFER);
        }
        break;
        case HWND_DMP_PLAYBACK_STATUS_STRING:
        {
            DMP_DBG(printf("HWND_DMP_PLAYBACK_STATUS_STRING %u\n",_enDmpPlayStrType););
            U16 u16StringId = E_ZUI_STR_MAX;
            // TODO: need to contorl _enDmpPlayIconType!?
            switch(_enDmpPlayStrType)
            {
                case PLAY_MODE_ICON_NEXT:
                    u16StringId = en_str_DMP_Next;
                    break;
                case PLAY_MODE_ICON_PREVIOUS:
                    u16StringId = en_str_DMP_Prev;
                    break;
                case PLAY_MODE_ICON_STOP:
                    u16StringId = en_str_DMP_Stop;
                    break;
                case PLAY_MODE_ICON_PLAY:
                    u16StringId = en_str_DMP_Play;
                    break;
                case PLAY_MODE_ICON_PAUSE:
                    u16StringId = en_str_DMP_Pause;
                    break;
                case PLAY_MODE_ICON_AB_REPEAT:
                    u16StringId = en_str_DMP_AB_NONE;
                    break;
				case PLAY_MODE_ICON_REPEAT_MODE:
					if	(MApp_MPlayer_QueryRepeatMode() == E_MPLAYER_REPEAT_ALL)
					{
						u16StringId = en_str_RepeatAll;
						//snprintf((char*)CHAR_BUFFER, 10, "Repeat A"); //"RepeatALL");
					}
					else if (MApp_MPlayer_QueryRepeatMode() == E_MPLAYER_REPEAT_1)
					{
						u16StringId = en_str_RepeatOne;
						//snprintf((char*)CHAR_BUFFER, 9, "Repeat 1");
					}
					else
					{
						u16StringId = en_str_Off;
						//snprintf((char*)CHAR_BUFFER, 11, "Repeat N"); //"RepeatNone");
					}
					//FS_ASCII2Unicode((U8*)CHAR_BUFFER);
					//return CHAR_BUFFER;					 
					break;
                case PLAY_MODE_ICON_SETA:
                    //u16StringId = en_str_DMP_SET_A;
                    snprintf((char*)CHAR_BUFFER, 6, "A-set");
                    FS_ASCII2Unicode((U8*)CHAR_BUFFER);
                    return CHAR_BUFFER;
                    break;
                case PLAY_MODE_ICON_AB_LOOP:
                    //u16StringId = en_str_DMP_AB_Loop;
                    snprintf((char*)CHAR_BUFFER,7, "AB-set");
                    FS_ASCII2Unicode((U8*)CHAR_BUFFER);
                    return CHAR_BUFFER;
                    break;
                case PLAY_MODE_ICON_SD:;
                    snprintf((char*)CHAR_BUFFER, 5, "Step");
                    FS_ASCII2Unicode((U8*)CHAR_BUFFER);
                    return CHAR_BUFFER;
                    break;
                case PLAY_MODE_ICON_FB_INVALID:
                case PLAY_MODE_ICON_FF_INVALID:
                #if 0
                    snprintf((char*)CHAR_BUFFER, 11, "NotSupport");
                    FS_ASCII2Unicode((U8*)CHAR_BUFFER);
                    return CHAR_BUFFER;
                    break;
                #else
                    return MApp_ZUI_API_GetString(en_str_DMP_Not_Support);
                #endif
                case PLAY_MODE_ICON_ZOOM:
                   {
                      enumMPlayerZoom eZoomScale;
                      eZoomScale = MApp_MPlayer_QueryZoomScale();
                      switch(eZoomScale)
                      {
                           case E_MPLAYER_ZOOM_1_DIV2:
                              snprintf((char*)CHAR_BUFFER, 11, "ZOOM_1/2");
                              FS_ASCII2Unicode((U8*)CHAR_BUFFER);
                              return CHAR_BUFFER;
                             break;
                           case E_MPLAYER_ZOOM_1_DIV4:
                              snprintf((char*)CHAR_BUFFER, 11, "ZOOM_1/4");
                              FS_ASCII2Unicode((U8*)CHAR_BUFFER);
                              return CHAR_BUFFER;
                             break;
                           case E_MPLAYER_ZOOM_2:
                              snprintf((char*)CHAR_BUFFER, 11, "ZOOM_2");
                              FS_ASCII2Unicode((U8*)CHAR_BUFFER);
                              return CHAR_BUFFER;
                             break;
                           case E_MPLAYER_ZOOM_4:
                              snprintf((char*)CHAR_BUFFER, 11, "ZOOM_4");
                              FS_ASCII2Unicode((U8*)CHAR_BUFFER);
                              return CHAR_BUFFER;
                             break;
                           case E_MPLAYER_ZOOM_8:
                              snprintf((char*)CHAR_BUFFER, 11, "ZOOM_8");
                              FS_ASCII2Unicode((U8*)CHAR_BUFFER);
                              return CHAR_BUFFER;
                             break;
                           case E_MPLAYER_ZOOM_1:
                           default:
                              snprintf((char*)CHAR_BUFFER, 11, "ZOOM_1");
                              FS_ASCII2Unicode((U8*)CHAR_BUFFER);
                              return CHAR_BUFFER;
                             break;
                      }
                    }
                    break;
                default:
                {
                    U8 u8Str[8] = {0};
                    U16 tmp[8];
                    switch(_enDmpPlayStrType)
                    {
                        case PLAY_MODE_ICON_FF2X:
                            u16StringId = en_str_DMP_FF;
                            snprintf((char*)u8Str, 3, "2X");
                            break;
                        case PLAY_MODE_ICON_FB2X:
                            u16StringId = en_str_DMP_FB;
                            snprintf((char*)u8Str, 3, "2X");
                            break;
                        case PLAY_MODE_ICON_SF2X:
                            u16StringId = en_str_DMP_SF;
                            snprintf((char*)u8Str, 3, "2X");
                            break;
                        case PLAY_MODE_ICON_FF4X:
                            u16StringId = en_str_DMP_FF;
                            snprintf((char*)u8Str, 3, "4X");
                            break;
                        case PLAY_MODE_ICON_FB4X:
                            u16StringId = en_str_DMP_FB;
                            snprintf((char*)u8Str, 3, "4X");
                            break;
                        case PLAY_MODE_ICON_SF4X:
                            u16StringId = en_str_DMP_SF;
                            snprintf((char*)u8Str, 3, "4X");
                            break;
                        case PLAY_MODE_ICON_FF8X:
                            u16StringId = en_str_DMP_FF;
                            snprintf((char*)u8Str, 3, "8X");
                            break;
                        case PLAY_MODE_ICON_FB8X:
                            u16StringId = en_str_DMP_FB;
                            snprintf((char*)u8Str, 3, "8X");
                            break;
                        case PLAY_MODE_ICON_SF8X:
                            u16StringId = en_str_DMP_SF;
                            snprintf((char*)u8Str, 3, "8X");
                            break;
                        case PLAY_MODE_ICON_FF16X:
                            u16StringId = en_str_DMP_FF;
                            snprintf((char*)u8Str, 4, "16X");
                            break;
                        case PLAY_MODE_ICON_FB16X:
                            u16StringId = en_str_DMP_FB;
                            snprintf((char*)u8Str, 4, "16X");
                            break;
                        case PLAY_MODE_ICON_SF16X:
                            u16StringId = en_str_DMP_SF;
                            snprintf((char*)u8Str, 4, "16X");
                            break;
                        case PLAY_MODE_ICON_FF32X:
                            u16StringId = en_str_DMP_FF;
                            snprintf((char*)u8Str, 4, "32X");
                            break;
                        case PLAY_MODE_ICON_FB32X:
                            u16StringId = en_str_DMP_FB;
                            snprintf((char*)u8Str, 4, "32X");
                            break;
                        case PLAY_MODE_ICON_SF32X:
                            u16StringId = en_str_DMP_SF;
                            snprintf((char*)u8Str, 4, "32X");
                            break;
                  #ifndef ATSC_SYSTEM
                        case PLAY_MODE_ICON_RATIO_Original:
                            u16StringId = en_str_AspectRatio_Original;  //auto
                            break;
                        case PLAY_MODE_ICON_RATIO_4X3:
                            u16StringId = en_str_AspectRatio_4X3;
                            break;
                        case PLAY_MODE_ICON_RATIO_16X9:
                            u16StringId = en_str_AspectRatio_16X9;
                            break;
			case PLAY_MODE_ICON_RATION_ZOOM1:
                            u16StringId = en_str_AspectRatio_Zoom1;
							break;
			case PLAY_MODE_ICON_RATION_ZOOM2:
                            u16StringId = en_str_AspectRatio_Zoom2;
							break;
			case PLAY_MODE_ICON_RATION_JUSTSCAN:
                            u16StringId = en_str_AspectRatio_JustScan;
							break;
                        case PLAY_MODE_ICON_RATIO_Panorama:
                            u16StringId = en_str_AspectRatio_Panorama;
                            break;
                  #endif
                        default:
                            break;
                    }
                    MApp_ZUI_API_GetString(u16StringId);
                    FS_ASCII2Unicode((U8*)u8Str);
                    memcpy(tmp,u8Str,8);
                    MApp_ZUI_API_Strcat(CHAR_BUFFER, tmp);
                    return CHAR_BUFFER;
                    break;
                }
            }
            //if (MApp_MPlayer_QueryCurrentMediaType()!= E_MPLAYER_TYPE_PHOTO) _enDmpPlayStrType = PLAY_MODE_ICON_MAX;
            return MApp_ZUI_API_GetString(u16StringId);
        }
        break;
//===========================MOVIEINFO====//

        case HWND_DMP_PLAYBACK_MOVIEINFO_GOTOTIME_HOUR_DIGIT1:
        {
            CHAR_BUFFER[0] = (_u8Hour / 10) + 0x30;
            CHAR_BUFFER[1] = 0;
            CHAR_BUFFER[2] = 0;
            CHAR_BUFFER[3] = 0;
        }
        break;
        case HWND_DMP_PLAYBACK_MOVIEINFO_GOTOTIME_HOUR_DIGIT2:
        {
            CHAR_BUFFER[0] = (_u8Hour % 10) + 0x30;
            CHAR_BUFFER[1] = 0;
            CHAR_BUFFER[2] = 0;
            CHAR_BUFFER[3] = 0;
        }
        break;
        case HWND_DMP_PLAYBACK_MOVIEINFO_GOTOTIME_MINUTE_DIGIT1:
        {
            CHAR_BUFFER[0] = (_u8Minute / 10) + 0x30;
            CHAR_BUFFER[1] = 0;
            CHAR_BUFFER[2] = 0;
            CHAR_BUFFER[3] = 0;
        }
        break;
        case HWND_DMP_PLAYBACK_MOVIEINFO_GOTOTIME_MINUTE_DIGIT2:
        {
            CHAR_BUFFER[0] = (_u8Minute % 10) + 0x30;
            CHAR_BUFFER[1] = 0;
            CHAR_BUFFER[2] = 0;
            CHAR_BUFFER[3] = 0;
        }
        break;
        case HWND_DMP_PLAYBACK_MOVIEINFO_GOTOTIME_SEC_DIGIT1:
        {
            CHAR_BUFFER[0] = (_u8Second / 10) + 0x30;
            CHAR_BUFFER[1] = 0;
            CHAR_BUFFER[2] = 0;
            CHAR_BUFFER[3] = 0;
        }
        break;
        case HWND_DMP_PLAYBACK_MOVIEINFO_GOTOTIME_SEC_DIGIT2:
        {
            CHAR_BUFFER[0] = (_u8Second % 10) + 0x30;
            CHAR_BUFFER[1] = 0;
            CHAR_BUFFER[2] = 0;
            CHAR_BUFFER[3] = 0;
        }
        break;

    #if 0
        case HWND_DMP_MOVIE_INFO_AB_REPEAT_STRING:
            if(_enRepeatABStatus == REPEATAB_MODE_NONE)
            {
                snprintf((char*)CHAR_BUFFER, 6, "Set A");
            }
            else if(_enRepeatABStatus == REPEATAB_MODE_A)
            {
                snprintf((char*)CHAR_BUFFER, 6, "Set B");
            }
            else if(_enRepeatABStatus == REPEATAB_MODE_AB)
            {
                snprintf((char*)CHAR_BUFFER, 8, "AB None");
            }
            FS_ASCII2Unicode((U8*)CHAR_BUFFER);
            break;
    #endif
        case HWND_DMP_PLAYBACK_MOVIEINFO_INFO_FILENAME_TEXT:
            {
                if (!MApp_MPlayer_IsMoviePlaying())
                {
                    snprintf((char*)CHAR_BUFFER, 3, "--");
                    FS_ASCII2Unicode((U8*)CHAR_BUFFER);
                }
                else
                {
                    MApp_MPlayer_QueryCurrentPlayingFileName((U8*)CHAR_BUFFER);
                }
            }
            //FS_ASCII2Unicode((U8*)CHAR_BUFFER);
            break;
        case HWND_DMP_PLAYBACK_MOVIEINFO_INFO_WHX_TEXT:
            {
                if (!MApp_MPlayer_IsMoviePlaying() && (MApp_MPlayer_QueryPreviewState(E_MPLAYER_TYPE_MOVIE) !=E_MOVIE_PREVIEW_RUNNING))
                {
                    snprintf((char*)CHAR_BUFFER, 3, "--");
                }
                else
                {
                    U32 w = MApp_VDPlayer_GetInfo(E_VDPLAYER_INFO_H_SIZE);
                    U32 h = MApp_VDPlayer_GetInfo(E_VDPLAYER_INFO_V_SIZE);

                    snprintf((char*)CHAR_BUFFER, 20, "%ld x %ld", w, h);
                }
            }
            FS_ASCII2Unicode((U8*)CHAR_BUFFER);
            break;
        case HWND_DMP_PLAYBACK_MOVIEINFO_INFO_AUDIOTRACK_TEXT:
            {
                if (!MApp_MPlayer_IsMoviePlaying() && (MApp_MPlayer_QueryPreviewState(E_MPLAYER_TYPE_MOVIE) !=E_MOVIE_PREVIEW_RUNNING))
                {
                    snprintf((char*)CHAR_BUFFER, 7, "-- / 0");
                }
                else
                {
                    U16 u16TrkID, u16TotalTrk;
                    u16TotalTrk = MApp_MPlayer_QueryMovieAudioChannelNum();
                    u16TrkID = MApp_MPlayer_QueryMovieCurAudioTrackIdx()+1;
                    if(u16TotalTrk > 0)
                    {
                        snprintf((char*)CHAR_BUFFER, 11, "%u / %u", u16TrkID, u16TotalTrk);
                    }
                    else
                    {
                        snprintf((char*)CHAR_BUFFER, 7, "-- / 0");
                    }
                }
            }
            FS_ASCII2Unicode((U8*)CHAR_BUFFER);
            break;
        case HWND_DMP_PLAYBACK_MOVIEINFO_INFO_SUBTITLE_TEXT:
            {
                #if (ENABLE_SUBTITLE_DMP)
                if (!MApp_MPlayer_IsMoviePlaying() && (MApp_MPlayer_QueryPreviewState(E_MPLAYER_TYPE_MOVIE) !=E_MOVIE_PREVIEW_RUNNING))
                {
                    snprintf((char*)CHAR_BUFFER, 7, "-- / 0");
                }
                else
                {
                    U16 u16TotalSub = MApp_MPlayer_QueryMovieSubtitleNum();
                    U16 u16SubIdx = MApp_MPlayer_QueryMovieCurSubtitleTrackIdx();
                    enumMPlayerLanguage enSubLan = E_MPLAYER_LANGUAGE_UNDEFINED;
                    
                    if(_stDmpPlayVar.stMovieInfo.bSubtitleOff)
                    {
                        snprintf((char*)CHAR_BUFFER, 4, "OFF");
                    }
                    else
                    {
                        if(u16TotalSub > 0)
                        {
                            enSubLan = MApp_MPlayer_QueryMovieSubtitleLanguageByTrackIndex(u16SubIdx);

                            switch(enSubLan)
                            {
                                case E_MPLAYER_LANGUAGE_CZECH:// 0
                                    snprintf((char*)CHAR_BUFFER, 4+5, "%d.Czech", u16SubIdx+1);
                                break;
                                case E_MPLAYER_LANGUAGE_DANISH:// 1
                                    snprintf((char*)CHAR_BUFFER, 4+6, "%d.Danish", u16SubIdx+1);
                                break;
                                case E_MPLAYER_LANGUAGE_GERMAN:// 2
                                    snprintf((char*)CHAR_BUFFER, 4+6, "%d.German", u16SubIdx+1);
                                break;
                                case E_MPLAYER_LANGUAGE_ENGLISH:// 3
                                    snprintf((char*)CHAR_BUFFER, 4+7, "%d.English", u16SubIdx+1);
                                break;
                                case E_MPLAYER_LANGUAGE_SPANISH:// 4
                                    snprintf((char*)CHAR_BUFFER, 4+7, "%d.Spanish", u16SubIdx+1);
                                break;
                                case E_MPLAYER_LANGUAGE_GREEK:// 5
                                    snprintf((char*)CHAR_BUFFER, 4+5, "%d.Greek", u16SubIdx+1);
                                break;
                                case E_MPLAYER_LANGUAGE_FRENCH:// 6
                                    snprintf((char*)CHAR_BUFFER, 4+6, "%d.French", u16SubIdx+1);
                                break;
                                case E_MPLAYER_LANGUAGE_CROATIAN:// 7
                                    snprintf((char*)CHAR_BUFFER, 4+8, "%d.Croatian", u16SubIdx+1);
                                break;
                                case E_MPLAYER_LANGUAGE_ITALIAN:// 8
                                    snprintf((char*)CHAR_BUFFER, 4+7, "%d.Italian", u16SubIdx+1);
                                break;
                                case E_MPLAYER_LANGUAGE_HUNGARIAN:// 9
                                    snprintf((char*)CHAR_BUFFER, 4+9, "%d.Hungarian", u16SubIdx+1);
                                break;
                                case E_MPLAYER_LANGUAGE_DUTCH:// 10
                                    snprintf((char*)CHAR_BUFFER, 4+5, "%d.Dutch", u16SubIdx+1);
                                break;
                                case E_MPLAYER_LANGUAGE_NORWEGIAN:// 11
                                    snprintf((char*)CHAR_BUFFER, 4+9, "%d.Norwegian", u16SubIdx+1);
                                break;
                                case E_MPLAYER_LANGUAGE_POLISH:// 12
                                    snprintf((char*)CHAR_BUFFER, 4+6, "%d.Polish", u16SubIdx+1);
                                break;
                                case E_MPLAYER_LANGUAGE_PORTUGUESE:// 13
                                    snprintf((char*)CHAR_BUFFER, 4+10, "%d.Portuguese", u16SubIdx+1);
                                break;
                                case E_MPLAYER_LANGUAGE_RUSSIAN:// 14
                                    snprintf((char*)CHAR_BUFFER, 4+7, "%d.Russian", u16SubIdx+1);
                                break;
                                case E_MPLAYER_LANGUAGE_ROMANIAN:// 15
                                    snprintf((char*)CHAR_BUFFER, 4+8, "%d.Romanian", u16SubIdx+1);
                                break;
                                case E_MPLAYER_LANGUAGE_SLOVENIAN:// 16
                                    snprintf((char*)CHAR_BUFFER, 4+9, "%d.Slovenian", u16SubIdx+1);
                                break;
                                case E_MPLAYER_LANGUAGE_SERBIAN:// 17
                                    snprintf((char*)CHAR_BUFFER, 4+7, "%d.Serbian", u16SubIdx+1);
                                break;
                                case E_MPLAYER_LANGUAGE_FINNISH:// 18
                                    snprintf((char*)CHAR_BUFFER, 4+7, "%d.Finnish", u16SubIdx+1);
                                break;
                                case E_MPLAYER_LANGUAGE_SWEDISH:// 19
                                    snprintf((char*)CHAR_BUFFER, 4+7, "%d.Swedish", u16SubIdx+1);
                                break;
                                case E_MPLAYER_LANGUAGE_BULGARIAN:// 20
                                    snprintf((char*)CHAR_BUFFER, 4+9, "%d.Bulgarian", u16SubIdx+1);
                                break;
                                case E_MPLAYER_LANGUAGE_GAELIC:// 21
                                    snprintf((char*)CHAR_BUFFER, 4+6, "%d.Gaelic", u16SubIdx+1);
                                break;
                                case E_MPLAYER_LANGUAGE_WELSH:// 22
                                    snprintf((char*)CHAR_BUFFER, 4+5, "%d.Welsh", u16SubIdx+1);
                                break;
                                case E_MPLAYER_LANGUAGE_IRISH:// 23
                                    snprintf((char*)CHAR_BUFFER, 4+5, "%d.Irish", u16SubIdx+1);
                                break;
                                case E_MPLAYER_LANGUAGE_ARABIC:// 24
                                    snprintf((char*)CHAR_BUFFER, 4+6, "%d.Arabic", u16SubIdx+1);
                                break;
                                case E_MPLAYER_LANGUAGE_CATALAN:// 25
                                    snprintf((char*)CHAR_BUFFER, 4+7, "%d.Catalan", u16SubIdx+1);
                                break;
                                case E_MPLAYER_LANGUAGE_CHINESE:// 26
                                    snprintf((char*)CHAR_BUFFER, 4+7, "%d.Chinese", u16SubIdx+1);
                                break;
                                case E_MPLAYER_LANGUAGE_KOREAN:// 27
                                    snprintf((char*)CHAR_BUFFER, 4+6, "%d.Korean", u16SubIdx+1);
                                break;
                                case E_MPLAYER_LANGUAGE_JAPAN:// 28
                                    snprintf((char*)CHAR_BUFFER, 4+5, "%d.Japan", u16SubIdx+1);
                                break;
                                case E_MPLAYER_LANGUAGE_TURKISH:// 29
                                    snprintf((char*)CHAR_BUFFER, 4+7, "%d.Turkish", u16SubIdx+1);
                                break;
                                case E_MPLAYER_LANGUAGE_HEBREW:// 30
                                    snprintf((char*)CHAR_BUFFER, 4+6, "%d.Hebrew", u16SubIdx+1);
                                break;
                                case E_MPLAYER_LANGUAGE_GALLEGAN:// 31
                                    snprintf((char*)CHAR_BUFFER, 4+8, "%d.Gallegan", u16SubIdx+1);
                                break;
                                case E_MPLAYER_LANGUAGE_BASQUE:// 32
                                    snprintf((char*)CHAR_BUFFER, 4+6, "%d.Basque", u16SubIdx+1);
                                break;
                                case E_MPLAYER_LANGUAGE_LUXEMBOURGISH:// 33
                                    snprintf((char*)CHAR_BUFFER, 4+13, "%d.Luxembourgish", u16SubIdx+1);
                                break;
                                case E_MPLAYER_LANGUAGE_ICELANDIC:// 34
                                    snprintf((char*)CHAR_BUFFER, 4+9, "%d.Icelandic", u16SubIdx+1);
                                break;
                                case E_MPLAYER_LANGUAGE_LATVIAN:// 35
                                    snprintf((char*)CHAR_BUFFER, 4+7, "%d.Latvian", u16SubIdx+1);
                                break;
                                case E_MPLAYER_LANGUAGE_ESTONIAN:// 36
                                    snprintf((char*)CHAR_BUFFER, 4+8, "%d.Estonian", u16SubIdx+1);
                                break;
                                case E_MPLAYER_LANGUAGE_LITHUANIAN:// 37
                                    snprintf((char*)CHAR_BUFFER, 4+10, "%d.Lithuanian", u16SubIdx+1);
                                break;
                                case E_MPLAYER_LANGUAGE_UKRAINIAN:// 38
                                    snprintf((char*)CHAR_BUFFER, 4+9, "%d.Ukrainian", u16SubIdx+1);
                                break;
                                case E_MPLAYER_LANGUAGE_BELARUSIAN:// 39
                                    snprintf((char*)CHAR_BUFFER, 4+10, "%d.Belarusian", u16SubIdx+1);
                                break;
                                case E_MPLAYER_LANGUAGE_HINDI:// 40
                                    snprintf((char*)CHAR_BUFFER, 4+5, "%d.Hindi", u16SubIdx+1);
                                break;
                                case E_MPLAYER_LANGUAGE_KIRUNDI:// 41
                                    snprintf((char*)CHAR_BUFFER, 4+7, "%d.Kirundi", u16SubIdx+1);
                                break;
                                case E_MPLAYER_LANGUAGE_MAORI:// 42
                                    snprintf((char*)CHAR_BUFFER, 4+5, "%d.Maori", u16SubIdx+1);
                                break;
                                case E_MPLAYER_LANGUAGE_SLOVAK:// 43
                                    snprintf((char*)CHAR_BUFFER, 4+6, "%d.Slovak", u16SubIdx+1);
                                break;
                                case E_MPLAYER_LANGUAGE_VOLAPUK:// 44
                                    snprintf((char*)CHAR_BUFFER, 4+7, "%d.Volapuk", u16SubIdx+1);
                                break;
                                case E_MPLAYER_LANGUAGE_MANDARIN:// 45
                                    snprintf((char*)CHAR_BUFFER, 4+8, "%d.Mandarin", u16SubIdx+1);
                                break;
                                case E_MPLAYER_LANGUAGE_CANTONESE:// 46
                                    snprintf((char*)CHAR_BUFFER, 4+9, "%d.Cantonese", u16SubIdx+1);
                                break;
                                case E_MPLAYER_LANGUAGE_SAMI:// 47
                                    snprintf((char*)CHAR_BUFFER, 4+4, "%d.Sami", u16SubIdx+1);
                                break;
                                case E_MPLAYER_LANGUAGE_QAA:// 48
                                    snprintf((char*)CHAR_BUFFER, 4+3, "%d.Qaa", u16SubIdx+1);
                                break;
                                default:
                                    snprintf((char*)CHAR_BUFFER, 4+9, "%d.Undefined", u16SubIdx+1);
                                break;
                            }
                        }
                        else
                        {
                            snprintf((char*)CHAR_BUFFER, 7, "-- / 0");
                        }
                    }
                }
                #else
                if (!MApp_MPlayer_IsMoviePlaying() && (MApp_MPlayer_QueryPreviewState(E_MPLAYER_TYPE_MOVIE) !=E_MOVIE_PREVIEW_RUNNING))
                {
                    snprintf((char*)CHAR_BUFFER, 7, "-- / 0");
                }
                else
                {
                    snprintf((char*)CHAR_BUFFER, 4, "OFF");
                }
                #endif //#if (ENABLE_SUBTITLE_DMP)

            }
            FS_ASCII2Unicode((U8*)CHAR_BUFFER);
            break;
        case HWND_DMP_PLAYBACK_MOVIEINFO_INFO_PROGRAM_TEXT:
            {
                if (!MApp_MPlayer_IsMoviePlaying() && (MApp_MPlayer_QueryPreviewState(E_MPLAYER_TYPE_MOVIE) !=E_MOVIE_PREVIEW_RUNNING))
                {
                    snprintf((char*)CHAR_BUFFER, 7, "-- / 0");
                }
                else
                {
                    U16 u16TotalPgm = MApp_MPlayer_QueryMovieProgramNum();
                    U16 u16PgmIdx = MApp_MPlayer_QueryMovieCurProgramIdx();
                    if(u16TotalPgm > 0)
                    {
                        snprintf((char*)CHAR_BUFFER, 11, "%d / %d", u16PgmIdx+1, u16TotalPgm);
                    }
                    else
                    {
                        snprintf((char*)CHAR_BUFFER, 7, "-- / 0");
                    }
                }
            }
            FS_ASCII2Unicode((U8*)CHAR_BUFFER);
            break;

    #if (ENABLE_DIVX_PLUS==1)
        case HWND_DMP_PLAYBACK_MOVIEINFO_DIVX_SETTITLE_TITLE_TEXT:
            {
                if (!MApp_MPlayer_IsMoviePlaying())
                {
                    snprintf((char*)CHAR_BUFFER, 7, "-- / 0");
                }
                else
                {
                    U16 u16TotalTitle = MApp_MPlayer_QueryMovieTitleNum();
                    if(u16TotalTitle>= 1)
                    {
                        snprintf((char*)CHAR_BUFFER, 11, "%d / %d", _u16DivxTitleIdx+1, u16TotalTitle);
                    }
                    else
                    {
                        snprintf((char*)CHAR_BUFFER, 7, "-- / 0");
                    }
                }
            }
            FS_ASCII2Unicode((U8*)CHAR_BUFFER);
            break;
        case HWND_DMP_PLAYBACK_MOVIEINFO_DIVX_SETEDTION_TEXT:
            {
                if (!MApp_MPlayer_IsMoviePlaying())
                {
                    snprintf((char*)CHAR_BUFFER, 7, "-- / 0");
                }
                else
                {
                    U16 u16TotalTitle = MApp_MPlayer_QueryMovieTitleNum();
                    U16 u16TotalEdition = MApp_MPlayer_QueryMovieEditionNum();
                    if((u16TotalTitle != 0) && (u16TotalEdition>= 1))
                    {
                        snprintf((char*)CHAR_BUFFER, 11, "%d / %d", _u16DivxEditionIdx+1, u16TotalEdition);
                    }
                    else
                    {
                        snprintf((char*)CHAR_BUFFER, 7, "-- / 0");
                    }
                }
            }
            FS_ASCII2Unicode((U8*)CHAR_BUFFER);
            break;
        case HWND_DMP_PLAYBACK_MOVIEINFO_DIVX_SETCHAPTER_TEXT:
            {
                if (!MApp_MPlayer_IsMoviePlaying() && (MApp_MPlayer_QueryPreviewState(E_MPLAYER_TYPE_MOVIE) != E_MOVIE_PREVIEW_RUNNING))
                {
                    snprintf((char*)CHAR_BUFFER, 7, "-- / 0");
                }
                else
                {
                    U16 u16TotalTitle = MApp_MPlayer_QueryMovieTitleNum();
                    U16 u16TotalEdition = MApp_MPlayer_QueryMovieEditionNum();
                    U16 u16TotalChp = MApp_MPlayer_QueryMovieChapterNum();
                    //U16 u16ChpIdx = MApp_MPlayer_QueryMovieCurChapterIdx();
                    if((u16TotalTitle != 0) && (u16TotalEdition!= 0) && (u16TotalChp>= 1))
                    {
                        snprintf((char*)CHAR_BUFFER, 11, "%d / %d", _u16DivxChpIdx+1, u16TotalChp);
                    }
                    else
                    {
                        snprintf((char*)CHAR_BUFFER, 7, "-- / 0");
                    }
                }
            }
            FS_ASCII2Unicode((U8*)CHAR_BUFFER);
            break;
         case HWND_DMP_PLAYBACK_MOVIEINFO_DIVX_SETAUTOCHAPTER_TEXT:
            {
                {
                    snprintf((char*)CHAR_BUFFER, 8, "%d / 9", _u8DivxAutoChpIdx);
                }
            }
            FS_ASCII2Unicode((U8*)CHAR_BUFFER);
            break;
    #endif  // divx
// =====================DMP_PLAYBACK_PLAYLIST_GROUP!?=================
        case HWND_DMP_PLAYBACK_PLAYLIST_PAGE_TOTAL_NUM:
            snprintf((char*)CHAR_BUFFER, 4, "%d",u8CurrentPlaylistTotalPage);
            FS_ASCII2Unicode((U8*)CHAR_BUFFER);
            break;
        case HWND_DMP_PLAYBACK_PLAYLIST_PAGE_IDX_NUM:
            snprintf((char*)CHAR_BUFFER, 4, "%d",u8CurrentPlaylistPageIdx+1);
            FS_ASCII2Unicode((U8*)CHAR_BUFFER);
            break;
        case HWND_DMP_PLAYBACK_PLAYLIST_ITEM1_STRING:
        case HWND_DMP_PLAYBACK_PLAYLIST_ITEM2_STRING:
        case HWND_DMP_PLAYBACK_PLAYLIST_ITEM3_STRING:
        case HWND_DMP_PLAYBACK_PLAYLIST_ITEM4_STRING:
        case HWND_DMP_PLAYBACK_PLAYLIST_ITEM5_STRING:
        case HWND_DMP_PLAYBACK_PLAYLIST_ITEM6_STRING:
        case HWND_DMP_PLAYBACK_PLAYLIST_ITEM7_STRING:
        case HWND_DMP_PLAYBACK_PLAYLIST_ITEM8_STRING:
        case HWND_DMP_PLAYBACK_PLAYLIST_ITEM9_STRING:
        case HWND_DMP_PLAYBACK_PLAYLIST_ITEM10_STRING:
        {
            U32 i;
            for( i = 0 ; i < UI_DMP_PLAYLIST_NUMBER ; i++)
            {
                if( MApp_ZUI_API_IsSuccessor(_hwndListPlaylistItem[i], hwnd))
                {
                    break;
                }
            }
            // i from 0 to 9
            U16 u16FileIdx = (u8CurrentPlaylistPageIdx*UI_DMP_PLAYLIST_NUMBER) + i;
            // TODO: need to check there's no selected files?
            enumMPlayerMediaType eMediaType = MApp_MPlayer_QueryCurrentMediaType();
            if(MApp_MPlayer_QueryPlayListFileNum(eMediaType) == 0)
            {
                // there is no selected files ,so need to shift the idx by how many
                // directories
                MPlayerFileInfo FileInfo;
                for( i = 0; i < MApp_MPlayer_QueryTotalFileNum(); i++)
                {
                    MApp_MPlayer_QueryFileInfo(E_MPLAYER_INDEX_CURRENT_DIRECTORY,i,&FileInfo);
                    if(FileInfo.eAttribute & E_MPLAYER_FILE_DIRECTORY)
                    {
                        u16FileIdx++;
                    }
                    else
                    {
                        break;
                    }
                }
                MApp_MPlayer_QueryFileInfo(E_MPLAYER_INDEX_CURRENT_DIRECTORY,u16FileIdx,&FileInfo);
                memcpy(CHAR_BUFFER,FileInfo.u8LongFileName,FILE_INFO_LONG_FILENAME_SIZE);
            }
            else
            {
                        MApp_MPlayer_QueryLongFilenameByPlayingIdx(u16FileIdx, (U8 *)CHAR_BUFFER,0);
            }
        }
            break;


//===========================MUSICINFO====//

/*        case HWND_DMP_MUSIC_INFO_CAPTURE_STRING:
            {
                if(MApp_MPlayer_IsMusicRecording() == FALSE)
                {
                    snprintf((char*)CHAR_BUFFER, 8, "Capture");
                }
                else if (MApp_MPlayer_IsMusicRecording() == TRUE)
                {
                    snprintf((char*)CHAR_BUFFER, 13, "Stop Capture");
                }
            }
            FS_ASCII2Unicode((U8*)CHAR_BUFFER);
            break;
*/
        case HWND_DMP_PLAYBACK_MUSICINFO_INFO_FILENAME_TEXT:
            {
                MPlayerFileInfo stFileInfo;
                if((MApp_MPlayer_QueryPlayMode() == E_MPLAYER_PLAY_SELECTED) ||
                    (MApp_MPlayer_QueryPlayMode() == E_MPLAYER_PLAY_SELECTED_FROM_CURRENT))
                {
                    U8 u8Len = 0;
                    MApp_MPlayer_QueryLongFilenameByPlayingIdx(MApp_MPlayer_QueryCurrentPlayingList(), (U8*)CHAR_BUFFER, u8Len);
                }
                else if(MApp_MPlayer_QueryPlayMode() == E_MPLAYER_PLAY_ONE_DIRECTORY_FROM_CURRENT ||
                        MApp_MPlayer_QueryPlayMode() == E_MPLAYER_PLAY_ONE_DIRECTORY)
                {
                    MApp_MPlayer_QueryFileInfo(E_MPLAYER_INDEX_CURRENT_DIRECTORY, MApp_MPlayer_QueryCurrentPlayingFileIndex(), &stFileInfo);
                    memcpy((void*)CHAR_BUFFER, (void*)stFileInfo.u8LongFileName, FILE_INFO_LONG_FILENAME_SIZE);
                }
            }
            break;
        case HWND_DMP_PLAYBACK_MUSICINFO_INFO_ALBUM_TEXT:
            {
                U8 *pu8Data;
                U8 u8Length;
                pu8Data = MApp_MPlayer_QueryMusicInfo(MP3_INFO_ALBUM,&u8Length);
                //memset((U8 *)CHAR_BUFFER,0,u8Length*2);

                if(pu8Data[0]==0x00)
                {
                    // TODO: fix me!!
                    _MApp_DMP_GB2Unicode(pu8Data+1, (U8 *)CHAR_BUFFER, u8Length-1); // [u8Length*2-2] = 0 , [u8Length*2-1]=0  String end
                }
                else if(pu8Data[0]==0x03)
                {
                    msAPI_OCP_MappinUTF8ToUCS2(pu8Data+1, CHAR_BUFFER, u8Length-1, u8Length-1);
                }
                else //if(pu8Data[0]==0x01)
                {
                    memcpy(CHAR_BUFFER,pu8Data+1,u8Length-1);  // [u8Length-2] = 0 , [u8Length-1]=0  String end
                }
            }
            break;
        case HWND_DMP_PLAYBACK_MUSICINFO_INFO_TITLE_TEXT:
            {
                U8 *pu8Data;
                U8 u8Length;
                pu8Data=MApp_MPlayer_QueryMusicInfo(MP3_INFO_TITLE,&u8Length);
                memset((U8 *)CHAR_BUFFER,0,u8Length*2);

                if(pu8Data[0]==0x00)
                {
                    // TODO: fixme
                    _MApp_DMP_GB2Unicode(pu8Data+1, (U8 *)CHAR_BUFFER, u8Length-1); // [u8Length*2-2] = 0 , [u8Length*2-1]=0  String end
                }
                else if(pu8Data[0]==0x03)
                {
                    msAPI_OCP_MappinUTF8ToUCS2(pu8Data+1, CHAR_BUFFER, u8Length-1, u8Length-1);
                }
                else //if(pu8Data[0]==0x01)
                {
                    memcpy(CHAR_BUFFER,pu8Data+1,u8Length-1);  // [u8Length-2] = 0 , [u8Length-1]=0  String end
                }
            }
            break;
        case HWND_DMP_PLAYBACK_MUSICINFO_INFO_SAMPLING_TEXT:
            {
                U8 u8Length;
                snprintf((char*)CHAR_BUFFER, 6, "%s", MApp_MPlayer_QueryMusicInfo(MP3_INFO_SAMPLINGRATE,&u8Length));
            }
            FS_ASCII2Unicode((U8*)CHAR_BUFFER);
            break;
        case HWND_DMP_PLAYBACK_MUSICINFO_INFO_BITRATE_TEXT:
            {
                U8 u8Length;
                snprintf((char*)CHAR_BUFFER, 5, "%s", MApp_MPlayer_QueryMusicInfo(MP3_INFO_BITRATE,&u8Length));
            }
            FS_ASCII2Unicode((U8*)CHAR_BUFFER);
            break;
        case HWND_DMP_PLAYBACK_MUSICINFO_INFO_ARTIST_TEXT:
            {
                U8 *pu8Data;
                U8 u8Length;
                pu8Data=MApp_MPlayer_QueryMusicInfo(MP3_INFO_ARTIST,&u8Length);
                memset((U8 *)CHAR_BUFFER,0,u8Length*2);

                if(pu8Data[0]==0x00)
                {
                    // TODO: fix me
                    _MApp_DMP_GB2Unicode(pu8Data+1, (U8 *)CHAR_BUFFER, u8Length-1); // [u8Length*2-2] = 0 , [u8Length*2-1]=0  String end
                }
                else if(pu8Data[0]==0x03)
                {
                    msAPI_OCP_MappinUTF8ToUCS2(pu8Data+1, CHAR_BUFFER, u8Length-1, u8Length-1);
                }
                else //if(pu8Data[0]==0x01)
                {
                    memcpy(CHAR_BUFFER,pu8Data+1,u8Length-1);  // [u8Length-2] = 0 , [u8Length-1]=0  String end
                }
            }
            break;
        case HWND_DMP_PLAYBACK_MUSICINFO_INFO_YEAR_TEXT:
            {
                U8 *pu8Data;
                U8 u8Length;
                pu8Data=MApp_MPlayer_QueryMusicInfo(MP3_INFO_YEAR,&u8Length);
                memset((U8 *)CHAR_BUFFER,0,u8Length*2);
                if(pu8Data != NULL)
                {
                    if(pu8Data[0]==0x00)
                    {
                        // TODO: fix me
                        _MApp_DMP_GB2Unicode(pu8Data+1, (U8 *)CHAR_BUFFER, u8Length-1); // [u8Length*2-2] = 0 , [u8Length*2-1]=0  String end
                    }
                    else if(pu8Data[0]==0x03)
                    {
                        msAPI_OCP_MappinUTF8ToUCS2(pu8Data+1, CHAR_BUFFER, u8Length-1, u8Length-1);
                    }
                    else //if(pu8Data[0]==0x01)
                    {
                        memcpy(CHAR_BUFFER,pu8Data+1,u8Length-1);  // [u8Length-2] = 0 , [u8Length-1]=0  String end
                    }
                }
            }
            break;
//=======================playback_photoinfo==================
// TODO: there is still some useful info in MPlayerPhotoInfo... fix me
        case HWND_DMP_PLAYBACK_PHOTOINFO_INFO_FILENAME_TEXT:

            {
                 MApp_MPlayer_QueryCurrentPlayingFileName((U8*)CHAR_BUFFER);
            }
            //attention!! MApp_MPlayer_QueryCurrentPlayingFileName return unicode
            //FS_ASCII2Unicode((U8*)CHAR_BUFFER);

            break;
        case HWND_DMP_PLAYBACK_PHOTOINFO_INFO_WXH_TEXT:
            {
                MPlayerPhotoInfo stPhotoInfo;
                MApp_MPlayer_QueryPhotoInfo(&stPhotoInfo);
                if(stPhotoInfo.u16Width == 0 && stPhotoInfo.u16Height == 0)
                {
                    snprintf((char*)CHAR_BUFFER, 7, "-- X --");
                }
                else
                {
                    snprintf((char*)CHAR_BUFFER,14, "%d X %d", stPhotoInfo.u16Width, stPhotoInfo.u16Height);
                }

            }
            FS_ASCII2Unicode((U8*)CHAR_BUFFER);
            break;
        case HWND_DMP_PLAYBACK_PHOTOINFO_INFO_DATE_TEXT:
            {
                MPlayerPhotoInfo stPhotoInfo;
                MPlayerFileInfo stFileInfo;
                U16 u16ItemIdx;
                U16 u16PageIdx = MApp_MPlayer_QueryCurrentPageIndex();

                for(u16ItemIdx=0;u16ItemIdx<NUM_OF_PHOTO_FILES_PER_PAGE;u16ItemIdx++)
                {
                    if(MApp_ZUI_API_IsSuccessor(MApp_ZUI_API_GetFocus(), _hwndListFileString[u16ItemIdx]) )
                    {
                        break;
                    }
                }
                if (u16ItemIdx < NUM_OF_PHOTO_FILES_PER_PAGE)
                {
                    //preview
                    u16ItemIdx += u16PageIdx * NUM_OF_PHOTO_FILES_PER_PAGE;
                    MApp_MPlayer_QueryFileInfo(E_MPLAYER_INDEX_CURRENT_DIRECTORY, u16ItemIdx, &stFileInfo);
                }
                else  if((MApp_MPlayer_QueryPlayMode() == E_MPLAYER_PLAY_SELECTED) ||
                    (MApp_MPlayer_QueryPlayMode() == E_MPLAYER_PLAY_SELECTED_FROM_CURRENT))
                {
                    if(!MApp_MPlayer_Change2TargetPath(MApp_MPlayer_QueryCurrentPlayingList()))
                    {
                        DMP_DBG(printf("MApp_MPlayer_Change2TargetPath fail EXIT\n");)
                    }
                    MApp_MPlayer_QueryFileInfo(E_MPLAYER_INDEX_CURRENT_DIRECTORY, MApp_MPlayer_QueryCurrentPlayingFileIndex(), &stFileInfo);
                }
               else if(MApp_MPlayer_QueryPlayMode() == E_MPLAYER_PLAY_ONE_DIRECTORY_FROM_CURRENT ||
                    MApp_MPlayer_QueryPlayMode() == E_MPLAYER_PLAY_ONE_DIRECTORY)
                {
                    MApp_MPlayer_QueryFileInfo(E_MPLAYER_INDEX_CURRENT_DIRECTORY, MApp_MPlayer_QueryCurrentPlayingFileIndex(), &stFileInfo);
                }
    // printf(" FileBrowser u16Year : %d\n",  stFileInfo.u16Year);
     //printf(" FileBrowser u8Month : %d\n",    stFileInfo.u8Month);
    // printf(" FileBrowser u8Day : %d\n",    stFileInfo.u8Day);
    // printf(" FileBrowser u8Hour : %d\n",    stFileInfo.u8Hour);
    // printf(" FileBrowser u8Minute : %d\n",    stFileInfo.u8Minute);
    // printf(" FileBrowser u8Second : %d\n",    stFileInfo.u8Second);
                MApp_MPlayer_QueryPhotoInfo(&stPhotoInfo);
                if (stPhotoInfo.bHasDateTime == FALSE)
                {
                    snprintf((char*)CHAR_BUFFER, 15, "%04lu / %02lu / %02lu", stFileInfo.u16Year, stFileInfo.u8Month, stFileInfo.u8Day);
                   // snprintf((char*)CHAR_BUFFER, 15, "---- / -- / --");
                }
                else
                {
                    snprintf((char*)CHAR_BUFFER, 15, "%04lu / %02lu / %02lu", stPhotoInfo.u32Year, stPhotoInfo.u32Month, stPhotoInfo.u32Day);
                }
            }
            FS_ASCII2Unicode((U8*)CHAR_BUFFER);
            break;
        case HWND_DMP_PLAYBACK_PHOTOINFO_INFO_TIME_TEXT:
            {
                MPlayerPhotoInfo stPhotoInfo;
                MPlayerFileInfo stFileInfo;
                U16 u16ItemIdx;
                U16 u16PageIdx = MApp_MPlayer_QueryCurrentPageIndex();

                for(u16ItemIdx=0;u16ItemIdx<NUM_OF_PHOTO_FILES_PER_PAGE;u16ItemIdx++)
                {
                    if(MApp_ZUI_API_IsSuccessor(MApp_ZUI_API_GetFocus(), _hwndListFileString[u16ItemIdx]) )
                    {
                        break;
                    }
                }
                if (u16ItemIdx < NUM_OF_PHOTO_FILES_PER_PAGE)
                {
                    //preview
                    u16ItemIdx += u16PageIdx * NUM_OF_PHOTO_FILES_PER_PAGE;
                    MApp_MPlayer_QueryFileInfo(E_MPLAYER_INDEX_CURRENT_DIRECTORY, u16ItemIdx, &stFileInfo);
                }
                else if((MApp_MPlayer_QueryPlayMode() == E_MPLAYER_PLAY_SELECTED) ||
                    (MApp_MPlayer_QueryPlayMode() == E_MPLAYER_PLAY_SELECTED_FROM_CURRENT))
                {
                    if(!MApp_MPlayer_Change2TargetPath(MApp_MPlayer_QueryCurrentPlayingList()))
                    {
                        DMP_DBG(printf("MApp_MPlayer_Change2TargetPath fail EXIT\n");)
                    }
                    MApp_MPlayer_QueryFileInfo(E_MPLAYER_INDEX_CURRENT_DIRECTORY, MApp_MPlayer_QueryCurrentPlayingFileIndex(), &stFileInfo);
                }
               else if(MApp_MPlayer_QueryPlayMode() == E_MPLAYER_PLAY_ONE_DIRECTORY_FROM_CURRENT ||
                    MApp_MPlayer_QueryPlayMode() == E_MPLAYER_PLAY_ONE_DIRECTORY)
                {
                    MApp_MPlayer_QueryFileInfo(E_MPLAYER_INDEX_CURRENT_DIRECTORY, MApp_MPlayer_QueryCurrentPlayingFileIndex(), &stFileInfo);
                }
                MApp_MPlayer_QueryPhotoInfo(&stPhotoInfo);
                if (stPhotoInfo.bHasDateTime == FALSE)
                {
                    snprintf((char*)CHAR_BUFFER, 13, "%02lu : %02lu : %02lu", stFileInfo.u8Hour, stFileInfo.u8Minute, stFileInfo.u8Second);
                   // snprintf((char*)CHAR_BUFFER, 13, "-- : -- : --");
                }
                else
                {
                    snprintf((char*)CHAR_BUFFER, 13, "%02lu : %02lu : %02lu", stPhotoInfo.u32Hour, stPhotoInfo.u32Minute, stPhotoInfo.u32Second);
                }
            }
            FS_ASCII2Unicode((U8*)CHAR_BUFFER);
            break;
        case HWND_DMP_PLAYBACK_MOVIEINFO_INFO_SIZE_TEXT:
        case HWND_DMP_PLAYBACK_MUSICINFO_INFO_SIZE_TEXT:
        case HWND_DMP_PLAYBACK_PHOTOINFO_INFO_SIZE_TEXT:
/*
            {
                MPlayerPhotoInfo stPhotoInfo;
                MApp_MPlayer_QueryPhotoInfo(&stPhotoInfo);
                if(stPhotoInfo.u32FileSize == 0)
                {
                    snprintf((char*)CHAR_BUFFER, 9, "-- KBytes");
                }
                else
                {
                    snprintf((char*)CHAR_BUFFER, 12, "%lu KBytes", (stPhotoInfo.u32FileSize+1023)/1024);
                }
            }
            FS_ASCII2Unicode((U8*)CHAR_BUFFER);
*/
            return MApp_ZUI_ACT_GetDynamicText(HWND_DMP_PLAYBACK_TEXTINFO_INFO_SIZE_TEXT);
            break;
// =======================playback textinfo====================//
        case HWND_DMP_PLAYBACK_TEXT_FULL_WINDOW_PAGE_TOTALPAGE:
            {
                U32 page = MApp_TEXT_GetTotalPage();
                if (page >=100)
                {
                    snprintf((char*)CHAR_BUFFER, 6, "%lu+",100);
                }
                else
                {
                    snprintf((char*)CHAR_BUFFER, 6, "%lu",page+1);
                }
            }
            FS_ASCII2Unicode((U8*)CHAR_BUFFER);
            break;
        case HWND_DMP_PLAYBACK_TEXT_FULL_WINDOW_PAGE_CURRENT:
            {
                U32 page = MApp_TEXT_GetPageIndex();
                snprintf((char*)CHAR_BUFFER, 6, "%lu",page+1);
            }
            FS_ASCII2Unicode((U8*)CHAR_BUFFER);
            break;
        case HWND_DMP_PLAYBACK_TEXT_FULL_WINDOW_TEXT:
            return (LPTSTR)MApp_TEXT_GetCurrentLineText(FALSE);
            break;
        case HWND_DMP_FILE_PAGE_PREVIEW_TEXT:
            return (LPTSTR)MApp_TEXT_GetCurrentLineText(TRUE);
            break;
        case HWND_DMP_PLAYBACK_TEXTINFO_INFO_SIZE_TEXT:
            {
                MPlayerFileInfo stFileInfo;
                stFileInfo.u64FileSize.Lo= 0;
                stFileInfo.u64FileSize.Hi= 0;
                U64 u64FileSize;
                U16 u16ItemIdx;
                U16 u16PageIdx = MApp_MPlayer_QueryCurrentPageIndex();

                for(u16ItemIdx=0;u16ItemIdx<NUM_OF_PHOTO_FILES_PER_PAGE;u16ItemIdx++)
                {
                    if(MApp_ZUI_API_IsSuccessor(MApp_ZUI_API_GetFocus(), _hwndListFileString[u16ItemIdx]) )
                    {
                        break;
                    }
                }
                if (u16ItemIdx < NUM_OF_PHOTO_FILES_PER_PAGE)
                {
                    //preview
                    u16ItemIdx += u16PageIdx * NUM_OF_PHOTO_FILES_PER_PAGE;
                    MApp_MPlayer_QueryFileInfo(E_MPLAYER_INDEX_CURRENT_DIRECTORY, u16ItemIdx, &stFileInfo);
                }
                else if((MApp_MPlayer_QueryPlayMode() == E_MPLAYER_PLAY_SELECTED) ||
                    (MApp_MPlayer_QueryPlayMode() == E_MPLAYER_PLAY_SELECTED_FROM_CURRENT))
                {
                // TODO: fix me
                    if(!MApp_MPlayer_Change2TargetPath(MApp_MPlayer_QueryCurrentPlayingList()))
                    {
                        DMP_DBG(printf("MApp_MPlayer_Change2TargetPath fail EXIT\n");)
                    }
                    MApp_MPlayer_QueryFileInfo(E_MPLAYER_INDEX_CURRENT_DIRECTORY, MApp_MPlayer_QueryCurrentPlayingFileIndex(), &stFileInfo);
                }
                else if(MApp_MPlayer_QueryPlayMode() == E_MPLAYER_PLAY_ONE_DIRECTORY_FROM_CURRENT ||
                        MApp_MPlayer_QueryPlayMode() == E_MPLAYER_PLAY_ONE_DIRECTORY)
                {
                    MApp_MPlayer_QueryFileInfo(E_MPLAYER_INDEX_CURRENT_DIRECTORY, MApp_MPlayer_QueryCurrentPlayingFileIndex(), &stFileInfo);
                    //memcpy((void*)CHAR_BUFFER, (void*)stFileInfo.u8LongFileName, FILE_INFO_LONG_FILENAME_SIZE);
                }

                //printf(" FileSize.hi[%lu]\n", stFileInfo.u64FileSize.Hi);
                //printf(" FileSize.lo[%lu]\n", stFileInfo.u64FileSize.Lo);
                u64FileSize=(unsigned long long)stFileInfo.u64FileSize.Hi<<32|stFileInfo.u64FileSize.Lo;
                //printf(" FileSize[%llu]\n", u64FileSize);
                if((stFileInfo.u64FileSize.Lo== 0)&&(stFileInfo.u64FileSize.Hi== 0))
                {
                    snprintf((char*)CHAR_BUFFER, 9, "-- KBytes");
                }
                else
                {
                    snprintf((char*)CHAR_BUFFER, 20, "%llu KBytes", (u64FileSize+1023)/1024);
                }
            }
            FS_ASCII2Unicode((U8*)CHAR_BUFFER);
            break;

        case HWND_DMP_PLAYBACK_TEXTINFO_INFO_FILENAME_TEXT:
            {
                MPlayerFileInfo stFileInfo;

                if((MApp_MPlayer_QueryPlayMode() == E_MPLAYER_PLAY_SELECTED) ||
                    (MApp_MPlayer_QueryPlayMode() == E_MPLAYER_PLAY_SELECTED_FROM_CURRENT))
                {
                    U8 u8Len = 0;
                    MApp_MPlayer_QueryLongFilenameByPlayingIdx(MApp_MPlayer_QueryCurrentPlayingList(), (U8*)CHAR_BUFFER, u8Len);
                }
                else if(MApp_MPlayer_QueryPlayMode() == E_MPLAYER_PLAY_ONE_DIRECTORY_FROM_CURRENT ||
                        MApp_MPlayer_QueryPlayMode() == E_MPLAYER_PLAY_ONE_DIRECTORY)
                {
                    MApp_MPlayer_QueryFileInfo(E_MPLAYER_INDEX_CURRENT_DIRECTORY, MApp_MPlayer_QueryCurrentPlayingFileIndex(), &stFileInfo);
                    memcpy((void*)CHAR_BUFFER, (void*)stFileInfo.u8LongFileName, FILE_INFO_LONG_FILENAME_SIZE);
                }
            }
            break;

////=================== MISC==================================
    #if 0
        case HWND_DMP_VOLUME_CONFIG_TEXT:
    #else
        case HWND_DMP_VOLUME_CONFIG_VALUE:
    #endif
            return MApp_ZUI_API_GetU16String(stGenSetting.g_SoundSetting.Volume);

        case HWND_DMP_PLAYBACK_CONFIRM_TEXT:
        {
            switch(MApp_MPlayer_QueryCurrentMediaType())
            {
                case E_MPLAYER_TYPE_PHOTO:
                    snprintf((char*)CHAR_BUFFER, 14, "Save as logo?");
                    break;
                case E_MPLAYER_TYPE_MOVIE:
                    snprintf((char*)CHAR_BUFFER, 14, "Save as file?");
                    break;
                case E_MPLAYER_TYPE_MUSIC:
                    snprintf((char*)CHAR_BUFFER, 24, "Save as power on music?");
                    break;
                default:
                    break;
            }
            FS_ASCII2Unicode((U8*)CHAR_BUFFER);
            break;
        }
        case HWND_DMP_PLAYBACK_LYRIC_TEXT:
        {
            memcpy((char*)CHAR_BUFFER,_stDmpPlayVar.stMusicInfo.MPlayerLyricBuf,DMP_STRING_BUF_SIZE);
        }
        //    FS_ASCII2Unicode((U8*)CHAR_BUFFER);
            break;
        case HWND_DMP_PLAYBACK_SUBTITLE_TEXT:
        {
            memcpy((char*)CHAR_BUFFER,_stDmpPlayVar.stMovieInfo.MPlayerSubtitleBuf,DMP_STRING_BUF_SIZE);
        }
        //FS_ASCII2Unicode((U8*)CHAR_BUFFER);
            break;
// =================== Preview Info ===================
        case HWND_DMP_FILE_PAGE_PREVIEW_INFO_INFO1:
        {
            switch(MApp_MPlayer_QueryCurrentMediaType())
            {
                case E_MPLAYER_TYPE_MUSIC:
                    return MApp_ZUI_API_GetString(en_str_MediaPlayerMp3InfoAlbumText);
                    break;
                case E_MPLAYER_TYPE_MOVIE:
                    return MApp_ZUI_API_GetString(en_str_DMP_MovieInfo_WxH);
                    break;
                case E_MPLAYER_TYPE_PHOTO:
                    return MApp_ZUI_API_GetString(en_str_DMP_MovieInfo_WxH);
                    break;
                case E_MPLAYER_TYPE_TEXT:
                    return MApp_ZUI_API_GetString(en_str_DMP_Size);
                    break;
                default:
                    break;
            }
            break;
        }
        case HWND_DMP_FILE_PAGE_PREVIEW_INFO_TEXT1:
        {
            switch(MApp_MPlayer_QueryCurrentMediaType())
            {
                case E_MPLAYER_TYPE_MUSIC:
                    return MApp_ZUI_ACT_GetDmpDynamicText(HWND_DMP_PLAYBACK_MUSICINFO_INFO_ALBUM_TEXT);
                    break;
                case E_MPLAYER_TYPE_MOVIE:
                    return MApp_ZUI_ACT_GetDmpDynamicText(HWND_DMP_PLAYBACK_MOVIEINFO_INFO_WHX_TEXT);
                    break;
                case E_MPLAYER_TYPE_PHOTO:
                    return MApp_ZUI_ACT_GetDmpDynamicText(HWND_DMP_PLAYBACK_PHOTOINFO_INFO_WXH_TEXT);
                    break;
                case E_MPLAYER_TYPE_TEXT:
                    return MApp_ZUI_ACT_GetDmpDynamicText(HWND_DMP_PLAYBACK_TEXTINFO_INFO_SIZE_TEXT);
                    break;
                default:
                    break;
            }
            break;
        }
        case HWND_DMP_FILE_PAGE_PREVIEW_INFO_INFO2:
        {
            switch(MApp_MPlayer_QueryCurrentMediaType())
            {
                case E_MPLAYER_TYPE_MUSIC:
                    return MApp_ZUI_API_GetString(en_str_MediaPlayerMp3InfoTitleText);
                    break;
                case E_MPLAYER_TYPE_MOVIE:
                    return MApp_ZUI_API_GetString(en_str_DMP_MovieInfo_AudioTrack);
                    break;
                case E_MPLAYER_TYPE_PHOTO:
                    return MApp_ZUI_API_GetString(en_str_DMP_Size);
                    break;
                case E_MPLAYER_TYPE_TEXT:
                default:
                    break;
            }
            break;
        }
        case HWND_DMP_FILE_PAGE_PREVIEW_INFO_TEXT2:
        {
            switch(MApp_MPlayer_QueryCurrentMediaType())
            {
                case E_MPLAYER_TYPE_MUSIC:
                    return MApp_ZUI_ACT_GetDmpDynamicText(HWND_DMP_PLAYBACK_MUSICINFO_INFO_TITLE_TEXT);
                    break;
                case E_MPLAYER_TYPE_MOVIE:
                    return MApp_ZUI_ACT_GetDmpDynamicText(HWND_DMP_PLAYBACK_MOVIEINFO_INFO_AUDIOTRACK_TEXT);
                    break;
                case E_MPLAYER_TYPE_PHOTO:
                    return MApp_ZUI_ACT_GetDmpDynamicText(HWND_DMP_PLAYBACK_TEXTINFO_INFO_SIZE_TEXT);
                    break;
                case E_MPLAYER_TYPE_TEXT:
                default:
                    break;
            }
            break;
        }
        case HWND_DMP_FILE_PAGE_PREVIEW_INFO_INFO3:
        {
            switch(MApp_MPlayer_QueryCurrentMediaType())
            {
                case E_MPLAYER_TYPE_MUSIC:
                    return MApp_ZUI_API_GetString(en_str_MediaPlayerMp3InfoBitRateText);
                    break;
                case E_MPLAYER_TYPE_MOVIE:
                    return MApp_ZUI_API_GetString(en_str_DMP_MovieInfo_Subtitle);
                    break;
                case E_MPLAYER_TYPE_PHOTO:
                    return MApp_ZUI_API_GetString(en_str_DMP_Date);
                    break;
                case E_MPLAYER_TYPE_TEXT:
                default:
                    break;
            }
            break;
        }
        case HWND_DMP_FILE_PAGE_PREVIEW_INFO_TEXT3:
        {
            switch(MApp_MPlayer_QueryCurrentMediaType())
            {
                case E_MPLAYER_TYPE_MUSIC:
                    return
                    MApp_ZUI_ACT_GetDmpDynamicText(HWND_DMP_PLAYBACK_MUSICINFO_INFO_BITRATE_TEXT);
                    break;
                case E_MPLAYER_TYPE_MOVIE:
                    return MApp_ZUI_ACT_GetDmpDynamicText(HWND_DMP_PLAYBACK_MOVIEINFO_INFO_SUBTITLE_TEXT);
                    break;
                case E_MPLAYER_TYPE_PHOTO:
                    return MApp_ZUI_ACT_GetDmpDynamicText(HWND_DMP_PLAYBACK_PHOTOINFO_INFO_DATE_TEXT);
                    break;
                case E_MPLAYER_TYPE_TEXT:
                default:
                    break;
            }
            break;
        }
        case HWND_DMP_FILE_PAGE_PREVIEW_INFO_INFO4:
        {
            switch(MApp_MPlayer_QueryCurrentMediaType())
            {
                case E_MPLAYER_TYPE_MUSIC:
                    return MApp_ZUI_API_GetString(en_str_MediaPlayerMp3InfoArtistText);
                    break;
                case E_MPLAYER_TYPE_MOVIE:
                    return MApp_ZUI_API_GetString(en_str_DMP_MovieInfo_Program);
                    break;
                case E_MPLAYER_TYPE_PHOTO:
                    return MApp_ZUI_API_GetString(en_str_DMP_Time);
                    break;
                case E_MPLAYER_TYPE_TEXT:
                default:
                    break;
            }
            break;
        }
        case HWND_DMP_FILE_PAGE_PREVIEW_INFO_TEXT4:
        {
            switch(MApp_MPlayer_QueryCurrentMediaType())
            {
                case E_MPLAYER_TYPE_MUSIC:
                    return MApp_ZUI_ACT_GetDmpDynamicText(HWND_DMP_PLAYBACK_MUSICINFO_INFO_ARTIST_TEXT);
                    break;
                case E_MPLAYER_TYPE_MOVIE:
                    return MApp_ZUI_ACT_GetDmpDynamicText(HWND_DMP_PLAYBACK_MOVIEINFO_INFO_PROGRAM_TEXT);
                    break;
                case E_MPLAYER_TYPE_PHOTO:
                    return MApp_ZUI_ACT_GetDmpDynamicText(HWND_DMP_PLAYBACK_PHOTOINFO_INFO_TIME_TEXT);
                    break;
                case E_MPLAYER_TYPE_TEXT:
                default:
                    break;
            }
            break;
        }
        case HWND_DMP_FILE_PAGE_PREVIEW_INFO_INFO5:
        {
            switch(MApp_MPlayer_QueryCurrentMediaType())
            {
                case E_MPLAYER_TYPE_MUSIC:
                    return MApp_ZUI_API_GetString(en_str_MediaPlayerMp3InfoSamplingRateText);
                    break;
                case E_MPLAYER_TYPE_MOVIE:
                    return MApp_ZUI_API_GetString(en_str_DMP_Size);
                    break;
                case E_MPLAYER_TYPE_PHOTO:
                case E_MPLAYER_TYPE_TEXT:
                default:
                    break;
            }
            break;
        }
        case HWND_DMP_FILE_PAGE_PREVIEW_INFO_TEXT5:
        {
            switch(MApp_MPlayer_QueryCurrentMediaType())
            {
                case E_MPLAYER_TYPE_MUSIC:
                    return MApp_ZUI_ACT_GetDmpDynamicText(HWND_DMP_PLAYBACK_MUSICINFO_INFO_SAMPLING_TEXT);
                    break;
                case E_MPLAYER_TYPE_MOVIE:
                    return MApp_ZUI_ACT_GetDmpDynamicText(HWND_DMP_PLAYBACK_TEXTINFO_INFO_SIZE_TEXT);
                    break;
                case E_MPLAYER_TYPE_PHOTO:
                case E_MPLAYER_TYPE_TEXT:
                default:
                    break;
            }
            break;
        }
        case HWND_DMP_FILE_PAGE_PREVIEW_INFO_INFO6:
        {
            switch(MApp_MPlayer_QueryCurrentMediaType())
            {
                case E_MPLAYER_TYPE_MUSIC:
                    return MApp_ZUI_API_GetString(en_str_MediaPlayerMp3InfoYearText);
                    break;
                case E_MPLAYER_TYPE_MOVIE:
                case E_MPLAYER_TYPE_PHOTO:
                case E_MPLAYER_TYPE_TEXT:
                default:
                    break;
            }
            break;
        }
        case HWND_DMP_FILE_PAGE_PREVIEW_INFO_TEXT6:
        {
            switch(MApp_MPlayer_QueryCurrentMediaType())
            {
                case E_MPLAYER_TYPE_MUSIC:
                    return MApp_ZUI_ACT_GetDmpDynamicText(HWND_DMP_PLAYBACK_MUSICINFO_INFO_YEAR_TEXT);
                    break;
                case E_MPLAYER_TYPE_MOVIE:
                case E_MPLAYER_TYPE_PHOTO:
                case E_MPLAYER_TYPE_TEXT:
                default:
                    break;
            }
            break;
        }
        case HWND_DMP_FILE_PAGE_PREVIEW_INFO_INFO7:
        {
            switch(MApp_MPlayer_QueryCurrentMediaType())
            {
                case E_MPLAYER_TYPE_MUSIC:
                    return MApp_ZUI_API_GetString(en_str_DMP_Size);
                    break;
                case E_MPLAYER_TYPE_MOVIE:
                case E_MPLAYER_TYPE_PHOTO:
                case E_MPLAYER_TYPE_TEXT:
                default:
                    break;
            }
            break;
        }

        case HWND_DMP_FILE_PAGE_PREVIEW_INFO_TEXT7:
        {
            switch(MApp_MPlayer_QueryCurrentMediaType())
            {
                case E_MPLAYER_TYPE_MUSIC:
                    return MApp_ZUI_ACT_GetDmpDynamicText(HWND_DMP_PLAYBACK_TEXTINFO_INFO_SIZE_TEXT);
                    break;
                case E_MPLAYER_TYPE_MOVIE:
                case E_MPLAYER_TYPE_PHOTO:
                case E_MPLAYER_TYPE_TEXT:
                default:
                    break;
            }
            break;
        }
        case HWND_DMP_FILE_PAGE_PREVIEW_INFO_INFO8:
        case HWND_DMP_FILE_PAGE_PREVIEW_INFO_TEXT8:
            break;

// =================== Drm ===================
    #if ENABLE_DRM
        case HWND_DMP_DRM_STRING_0:
            if(_DrmStr0Idx == ViewRental)
            {
                if(_DrmStr1Idx != RentalExpired)
                {
                    snprintf((char*)CHAR_BUFFER, 49, "This DivX(R) rental has used %u of %u views.",
                    DrmInfo.u32DrmRentalUseCount,DrmInfo.u32DrmRentalLimit);
                }
                else
                {
                    snprintf((char*)CHAR_BUFFER, 49, "This DivX(R) rental has used %u of %u views.",
                    DrmInfo.u32DrmRentalLimit,DrmInfo.u32DrmRentalLimit);
                }
            }
            else
            {
                strcpy((char *)CHAR_BUFFER,(char *)DRMStrTable0[_DrmStr0Idx]);
            }
            DMP_DBG(printf("%s\n",CHAR_BUFFER););
            FS_ASCII2Unicode((U8 *)CHAR_BUFFER);
            break;

        case HWND_DMP_DRM_STRING_1:
            strcpy((char *)CHAR_BUFFER,(char *)DRMStrTable1[_DrmStr1Idx]);
            DMP_DBG(printf("%s\n",CHAR_BUFFER););
            FS_ASCII2Unicode((U8 *)CHAR_BUFFER);
            break;
    #endif

        case HWND_DMP_COUNTDOWN_TEXT1:
            {
                LPTSTR str = CHAR_BUFFER;
                MApp_ZUI_API_GetU16String((U16)MApp_Sleep_DisplayCountDownTimer());
                str += MApp_ZUI_API_Strlen(str);
                *str = CHAR_SPACE;
                str++;
                MApp_ZUI_API_LoadString(en_str_Dialog_Counter_Down_Text, str);
                return CHAR_BUFFER;
            }
            break;

        default:
            break;
    }
    return CHAR_BUFFER;
}


#if ENABLE_DRM

void _MApp_ACTdmp_ShowDrmWin(EN_DRM_WIN win)
{
    DRM_STATUS = win;
    switch(win)
    {
        case WinUnsupported:
            MApp_ZUI_API_ShowWindow(HWND_DMP_DRM_WINDOW, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_DMP_DRM_ICON_YES, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_DMP_DRM_ICON_NO, SW_HIDE);

            MApp_ZUI_API_SetFocus(HWND_DMP_DRM_ICON_DONE);
            _DrmStr0Idx = Unsupported;
            _DrmStr1Idx = None;
            _DrmBitmapIdx = DRM_Bitmap_None;
            break;
        case WinAuthError:
            //Authorization Error
            MApp_ZUI_API_ShowWindow(HWND_DMP_DRM_WINDOW, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_DMP_DRM_ICON_YES, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_DMP_DRM_ICON_NO, SW_HIDE);

            MApp_ZUI_API_SetFocus(HWND_DMP_DRM_ICON_DONE);
            _DrmStr0Idx = AuthError;
            _DrmStr1Idx = None;
            _DrmBitmapIdx = DRM_Bitmap_Error;
            break;
        case WinViewRental:
            //View DivX(R) VOD Rental
            MApp_ZUI_API_ShowWindow(HWND_DMP_DRM_WINDOW, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_DMP_DRM_ICON_DONE, SW_HIDE);
            MApp_ZUI_API_SetFocus(HWND_DMP_DRM_ICON_YES);
            _DrmStr0Idx = ViewRental;
            _DrmStr1Idx = UseRental;
            _DrmBitmapIdx = DRM_Bitmap_None;
            break;
        case WinRentalExpired:
            //Rental Expired
            MApp_ZUI_API_ShowWindow(HWND_DMP_DRM_WINDOW, SW_SHOW);

            MApp_ZUI_API_ShowWindow(HWND_DMP_DRM_ICON_YES, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_DMP_DRM_ICON_NO, SW_HIDE);

            MApp_ZUI_API_SetFocus(HWND_DMP_DRM_ICON_DONE);
            _DrmStr0Idx = ViewRental;
            _DrmStr1Idx = RentalExpired;
            _DrmBitmapIdx = DRM_Bitmap_Warning;
            break;
    }
}
#endif


U16 MApp_ZUI_ACT_GetDmpDynamicBitmap(HWND hwnd, DRAWSTYLE_TYPE ds_type)
{
    U16 u16BtimapIdx=0xFFFF;
    switch(hwnd)
    {
        case HWND_DMP_PLAYBACK_INFOBAR_ITEM1_ICON:
        case HWND_DMP_PLAYBACK_INFOBAR_ITEM2_ICON:
        case HWND_DMP_PLAYBACK_INFOBAR_ITEM3_ICON:
        case HWND_DMP_PLAYBACK_INFOBAR_ITEM4_ICON:
        case HWND_DMP_PLAYBACK_INFOBAR_ITEM5_ICON:
        case HWND_DMP_PLAYBACK_INFOBAR_ITEM6_ICON:
        case HWND_DMP_PLAYBACK_INFOBAR_ITEM7_ICON:
        case HWND_DMP_PLAYBACK_INFOBAR_ITEM8_ICON:
        {
            U32 i;
            for( i = 0; i < DMP_INFOBAR_ICON_NUM; i++)
            {
                if( MApp_ZUI_API_IsSuccessor(_hwndListInfoBar[i], hwnd))
                {
                    break;
                }
            }
            U8 u8InfobarIdx = _u8InfoBarIdx+i;
            switch(MApp_MPlayer_QueryCurrentMediaType())
            {
                case E_MPLAYER_TYPE_MOVIE:
                    //u8InfobarIdx = u8InfobarIdx %u8MovieInfoBarMax;
                    if(u8InfobarIdx >= u8MovieInfoBarMax)
                    {
                        if (MApp_ZUI_API_IsWindowEnabled(MApp_ZUI_API_GetParent(hwnd)))
                        {
                            MApp_ZUI_API_EnableWindow(MApp_ZUI_API_GetParent(hwnd), FALSE);
			    break;
                        }
                        return E_ZUI_BMP_MAX;
                    }
                    else
                    {
                        //MApp_ZUI_API_EnableWindow(MApp_ZUI_API_GetParent(hwnd), TRUE);
                        return DMP_MovieInfoBarTable[u8InfobarIdx][INFOBAR_BMP_IDX];
                    }
                    break;
                case E_MPLAYER_TYPE_PHOTO:
                    //u8InfobarIdx = u8InfobarIdx %u8PhotoInfoBarMax;
                    if(u8InfobarIdx >= u8PhotoInfoBarMax)
                    {
                        if (MApp_ZUI_API_IsWindowEnabled(MApp_ZUI_API_GetParent(hwnd)))
                        {
                            MApp_ZUI_API_EnableWindow(MApp_ZUI_API_GetParent(hwnd), FALSE);
			    break;
                        }
                        return E_ZUI_BMP_MAX;
                    }
                    else
                    {
                        //MApp_ZUI_API_EnableWindow(MApp_ZUI_API_GetParent(hwnd), TRUE);
                        return DMP_PhotoInfoBarTable[u8InfobarIdx][INFOBAR_BMP_IDX];
                    }
                    break;
                case E_MPLAYER_TYPE_MUSIC:
                    //u8InfobarIdx = u8InfobarIdx %u8MusicInfoBarMax;
                    if(u8InfobarIdx >= u8MusicInfoBarMax)
                    {
                        if (MApp_ZUI_API_IsWindowEnabled(MApp_ZUI_API_GetParent(hwnd)))
                        {
                            MApp_ZUI_API_EnableWindow(MApp_ZUI_API_GetParent(hwnd), FALSE);
			    break;
                        }
                        return E_ZUI_BMP_MAX;
                    }
                    else
                    {
                        //MApp_ZUI_API_EnableWindow(MApp_ZUI_API_GetParent(hwnd), TRUE);
                        return DMP_MusicInfoBarTable[u8InfobarIdx][INFOBAR_BMP_IDX];
                    }
                    break;
                case E_MPLAYER_TYPE_TEXT:
                    //u8InfobarIdx = u8InfobarIdx %u8TextInfoBarMax;
                    if(u8InfobarIdx >= u8TextInfoBarMax)
                    {
                        if (MApp_ZUI_API_IsWindowEnabled(MApp_ZUI_API_GetParent(hwnd)))
                        {
                            MApp_ZUI_API_EnableWindow(MApp_ZUI_API_GetParent(hwnd), FALSE);
			    break;
                        }
                        return E_ZUI_BMP_MAX;
                    }
                    else
                    {
                        //MApp_ZUI_API_EnableWindow(MApp_ZUI_API_GetParent(hwnd), TRUE);
                        return DMP_TextInfoBarTable[u8InfobarIdx][INFOBAR_BMP_IDX];
                    }
                    break;
                default:
                    break;
            }
            break;
        }
        case HWND_DMP_MEDIA_TYPE_USB1_ICON:
            {
                MPlayerDeviceStatus *pDeviceStatus;
                MApp_MPlayer_QueryDeviceConnectionStatus(&pDeviceStatus);
                if(pDeviceStatus[0].u16LunValid != 0)
                {
                    return E_BMP_DMP_MEDIA_TYPE_USB1_ICON_COLOUR;
                }
                else
                {
                    return E_BMP_DMP_MEDIA_TYPE_USB1_ICON_GREY;
                }
            }
        break;
        case HWND_DMP_MEDIA_TYPE_USB2_ICON:
            {
                MPlayerDeviceStatus *pDeviceStatus;
                MApp_MPlayer_QueryDeviceConnectionStatus(&pDeviceStatus);
                if(pDeviceStatus[1].u16LunValid != 0)
                {
                    return E_BMP_DMP_MEDIA_TYPE_USB2_ICON_COLOUR;
                }
                else
                {
                    return E_BMP_DMP_MEDIA_TYPE_USB2_ICON_GREY;
                }
            }
        break;
        case HWND_DMP_DRIVE_ITEM1_ICON:
            {
                if(MApp_DMP_GetDrvPageIdx() <= 1)
                {
                    return E_BMP_DMP_DRIVE_PAGE_RETURN_SMALL;
                }
                else
                {
                    return E_BMP_DMP_DRIVE_ICON_SMALL;
                }
            }
        break;
        case HWND_DMP_FILE_PAGE_INFO_MEDIA_ICON:
            switch(MApp_MPlayer_QueryCurrentMediaType())
            {
                case E_MPLAYER_TYPE_PHOTO:
                    u16BtimapIdx = E_BMP_DMP_FILE_SELECT_ICON_PICTURE;
                    break;
                case E_MPLAYER_TYPE_MUSIC:
                    u16BtimapIdx = E_BMP_DMP_FILE_SELECT_ICON_MUSIC;
                    break;
                case E_MPLAYER_TYPE_MOVIE:
                    u16BtimapIdx = E_BMP_DMP_FILE_SELECT_ICON_MOVIE;
                    break;
                case E_MPLAYER_TYPE_TEXT:
                    u16BtimapIdx = E_BMP_DMP_FILE_SELECT_ICON_TXT;
                    break;
                default:
                    break;
            }
        break;
        case HWND_DMP_FILE_PAGE_THUMB_ITEM1_ICON:
        case HWND_DMP_FILE_PAGE_THUMB_ITEM2_ICON:
        case HWND_DMP_FILE_PAGE_THUMB_ITEM3_ICON:
        case HWND_DMP_FILE_PAGE_THUMB_ITEM4_ICON:
        case HWND_DMP_FILE_PAGE_THUMB_ITEM5_ICON:
        case HWND_DMP_FILE_PAGE_THUMB_ITEM6_ICON:
        case HWND_DMP_FILE_PAGE_THUMB_ITEM7_ICON:
        case HWND_DMP_FILE_PAGE_THUMB_ITEM8_ICON:
#ifdef ENABLE_SMC_UI_NEW     /* smc.qxr 20121029 */
        case HWND_DMP_PHOTO_PAGE_THUMB_ITEM1_ICON:
        case HWND_DMP_PHOTO_PAGE_THUMB_ITEM2_ICON:
        case HWND_DMP_PHOTO_PAGE_THUMB_ITEM3_ICON:
        case HWND_DMP_PHOTO_PAGE_THUMB_ITEM4_ICON:
        case HWND_DMP_PHOTO_PAGE_THUMB_ITEM5_ICON:
        case HWND_DMP_PHOTO_PAGE_THUMB_ITEM6_ICON:
        case HWND_DMP_PHOTO_PAGE_THUMB_ITEM7_ICON:
        case HWND_DMP_PHOTO_PAGE_THUMB_ITEM8_ICON:
        case HWND_DMP_PHOTO_PAGE_THUMB_ITEM9_ICON:
        case HWND_DMP_PHOTO_PAGE_THUMB_ITEM10_ICON:
        case HWND_DMP_PHOTO_PAGE_THUMB_ITEM11_ICON:
        case HWND_DMP_PHOTO_PAGE_THUMB_ITEM12_ICON:
#else
        case HWND_DMP_FILE_PAGE_THUMB_ITEM9_ICON:
        case HWND_DMP_FILE_PAGE_THUMB_ITEM10_ICON:
        case HWND_DMP_FILE_PAGE_THUMB_ITEM11_ICON:
        case HWND_DMP_FILE_PAGE_THUMB_ITEM12_ICON:
#endif
        {
            MPlayerFileInfo fileInfo;
            U16 u16ItemIdx = 0;
            for(u16ItemIdx=0;u16ItemIdx<NUM_OF_PHOTO_FILES_PER_PAGE;u16ItemIdx++)
            {
                if(hwnd == _hwndListFileIcon[u16ItemIdx])
                {
                    break;
                }
            }
            if((u16ItemIdx<NUM_OF_PHOTO_FILES_PER_PAGE) &&
               (MApp_MPlayer_QueryFileInfo(E_MPLAYER_INDEX_CURRENT_PAGE, u16ItemIdx, &fileInfo) == E_MPLAYER_RET_OK))
            {
                if(fileInfo.eAttribute & E_MPLAYER_FILE_DIRECTORY)
                {
                    if(fileInfo.u8LongFileName[0] == 0x2e &&
                       fileInfo.u8LongFileName[1] == 0x00 &&
                       fileInfo.u8LongFileName[2] == 0x00 &&
                       fileInfo.u8LongFileName[3] == 0x00)
                    {
                        u16BtimapIdx = E_BMP_DMP_FILE_SELECT_ICON_RETURN;
                    }
                    else if(fileInfo.u8LongFileName[0] == 0x2e &&
                            fileInfo.u8LongFileName[1] == 0x00 &&
                            fileInfo.u8LongFileName[2] == 0x2e &&
                            fileInfo.u8LongFileName[3] == 0x00 &&
                            fileInfo.u8LongFileName[4] == 0x00 &&
                            fileInfo.u8LongFileName[5] == 0x00)
                    {
                        u16BtimapIdx = E_BMP_DMP_FILE_SELECT_ICON_BACK;
                    }
                    else if(ds_type == DS_FOCUS)
                    {
                        u16BtimapIdx = E_BMP_DMP_FILE_SELECT_ICON_DIR;
                    }
                    else
                    {
                        u16BtimapIdx = E_BMP_DMP_FILE_SELECT_ICON_DIR;
                    }
                }
                else
                {
                    //if(fileInfo.eAttribute & E_MPLAYER_FILE_SELECT)
                    {
                        switch(MApp_MPlayer_QueryCurrentMediaType())
                        {
                            case E_MPLAYER_TYPE_PHOTO:
                                u16BtimapIdx = E_BMP_DMP_FILE_SELECT_ICON_PICTURE;
                                break;
                            case E_MPLAYER_TYPE_MUSIC:
                                u16BtimapIdx = E_BMP_DMP_FILE_SELECT_ICON_MUSIC;
                                break;
                            case E_MPLAYER_TYPE_MOVIE:
                                u16BtimapIdx = E_BMP_DMP_FILE_SELECT_ICON_MOVIE;
                                break;
                            case E_MPLAYER_TYPE_TEXT:
                                u16BtimapIdx = E_BMP_DMP_FILE_SELECT_ICON_TXT;
                                break;
                            default:
                                break;
                        }
                    }
                }
            }
        }
        break;
        case HWND_DMP_FILE_PAGE_THUMB_ITEM1_CHECK_ICON:
        case HWND_DMP_FILE_PAGE_THUMB_ITEM2_CHECK_ICON:
        case HWND_DMP_FILE_PAGE_THUMB_ITEM3_CHECK_ICON:
        case HWND_DMP_FILE_PAGE_THUMB_ITEM4_CHECK_ICON:
        case HWND_DMP_FILE_PAGE_THUMB_ITEM5_CHECK_ICON:
        case HWND_DMP_FILE_PAGE_THUMB_ITEM6_CHECK_ICON:
        case HWND_DMP_FILE_PAGE_THUMB_ITEM7_CHECK_ICON:
        case HWND_DMP_FILE_PAGE_THUMB_ITEM8_CHECK_ICON:
#ifdef ENABLE_SMC_UI_NEW     /* smc.qxr 20121029 */
        case HWND_DMP_PHOTO_PAGE_THUMB_ITEM1_CHECK_ICON:
        case HWND_DMP_PHOTO_PAGE_THUMB_ITEM2_CHECK_ICON:
        case HWND_DMP_PHOTO_PAGE_THUMB_ITEM3_CHECK_ICON:
        case HWND_DMP_PHOTO_PAGE_THUMB_ITEM4_CHECK_ICON:
        case HWND_DMP_PHOTO_PAGE_THUMB_ITEM5_CHECK_ICON:
        case HWND_DMP_PHOTO_PAGE_THUMB_ITEM6_CHECK_ICON:
        case HWND_DMP_PHOTO_PAGE_THUMB_ITEM7_CHECK_ICON:
        case HWND_DMP_PHOTO_PAGE_THUMB_ITEM8_CHECK_ICON:
        case HWND_DMP_PHOTO_PAGE_THUMB_ITEM9_CHECK_ICON:
        case HWND_DMP_PHOTO_PAGE_THUMB_ITEM10_CHECK_ICON:
        case HWND_DMP_PHOTO_PAGE_THUMB_ITEM11_CHECK_ICON:
        case HWND_DMP_PHOTO_PAGE_THUMB_ITEM12_CHECK_ICON:
#else
        case HWND_DMP_FILE_PAGE_THUMB_ITEM9_CHECK_ICON:
        case HWND_DMP_FILE_PAGE_THUMB_ITEM10_CHECK_ICON:
        case HWND_DMP_FILE_PAGE_THUMB_ITEM11_CHECK_ICON:
        case HWND_DMP_FILE_PAGE_THUMB_ITEM12_CHECK_ICON:
#endif
        {
            MPlayerFileInfo fileInfo;
            U16 u16ItemIdx = 0;
            for(u16ItemIdx=0;u16ItemIdx<NUM_OF_PHOTO_FILES_PER_PAGE;u16ItemIdx++)
            {
                if(hwnd == _hwndListFileCheckMark[u16ItemIdx])
                {
                    break;
                }
            }
            if((u16ItemIdx<NUM_OF_PHOTO_FILES_PER_PAGE) &&
               (MApp_MPlayer_QueryFileInfo(E_MPLAYER_INDEX_CURRENT_PAGE, u16ItemIdx, &fileInfo) == E_MPLAYER_RET_OK))
            {
                if(fileInfo.eAttribute & E_MPLAYER_FILE_SELECT)
                {
                    u16BtimapIdx = E_BMP_DMP_FILE_SELECT_ICON_CHECK;
                }
            }
        }
        break;
        case HWND_DMP_ALERT_ICON:
        {
            switch(_enDmpMsgType)
            {
                case DMP_MSG_TYPE_LOADING:
                    u16BtimapIdx = E_BMP_DMP_ALERT_ICON_LOADING_BG;
                    break;
                case DMP_MSG_TYPE_UNSUPPORTED_FILE:
                    u16BtimapIdx = E_BMP_DMP_ALERT_ICON_UNSUPPORTED;
                    break;
                case DMP_MSG_TYPE_INVALID_OPERATION:
                    u16BtimapIdx = E_BMP_DMP_ALERT_ICON_INVALID_OPERATION;
                    break;
                default:
                    u16BtimapIdx = E_BMP_DMP_ALERT_ICON_UNSUPPORTED;
                    break;
            }
        }
        break;
        case HWND_DMP_PLAYBACK_STATUS_ICON:
        {
            DMP_DBG(printf("HWND_DMP_PLAYBACK_STATUS_ICON, %u\n", _enDmpPlayIconType););
            switch(_enDmpPlayIconType)
            {
                case PLAY_MODE_ICON_NEXT:
                    u16BtimapIdx = E_BMP_DMP_BUTTON_ICON_NEXT;
                    break;
                case PLAY_MODE_ICON_PREVIOUS:
                    u16BtimapIdx = E_BMP_DMP_BUTTON_ICON_PREV;
                    break;
                case PLAY_MODE_ICON_STOP:
                    u16BtimapIdx = E_BMP_DMP_BUTTON_ICON_STOP;
                    break;
                case PLAY_MODE_ICON_PLAY:
                    u16BtimapIdx = E_BMP_DMP_BUTTON_ICON_PLAY;
                    break;
                case PLAY_MODE_ICON_PAUSE:
                    u16BtimapIdx = E_BMP_DMP_BUTTON_ICON_PAUSE;
                    break;
                case PLAY_MODE_ICON_AB_REPEAT:
                case PLAY_MODE_ICON_SETA:
                case PLAY_MODE_ICON_AB_LOOP:
                    u16BtimapIdx = E_BMP_DMP_BUTTON_ICON_AB_REPEAT;
                    break;
				case PLAY_MODE_ICON_REPEAT_MODE:
					u16BtimapIdx = E_BMP_DMP_BUTTON_ICON_REPEAT;
					break;
                case PLAY_MODE_ICON_FF2X:
                case PLAY_MODE_ICON_FF4X:
                case PLAY_MODE_ICON_FF8X:
                case PLAY_MODE_ICON_FF16X:
                case PLAY_MODE_ICON_FF32X:
                case PLAY_MODE_ICON_SF2X:
                case PLAY_MODE_ICON_SF4X:
                case PLAY_MODE_ICON_SF8X:
                case PLAY_MODE_ICON_SF16X:
                case PLAY_MODE_ICON_SF32X:
                    u16BtimapIdx = E_BMP_DMP_BUTTON_ICON_FF;
                    break;
                case PLAY_MODE_ICON_FB2X:
                case PLAY_MODE_ICON_FB4X:
                case PLAY_MODE_ICON_FB8X:
                case PLAY_MODE_ICON_FB16X:
                case PLAY_MODE_ICON_FB32X:
                    u16BtimapIdx = E_BMP_DMP_BUTTON_ICON_FB;
                    break;
                case PLAY_MODE_ICON_SD:
                    u16BtimapIdx = E_BMP_DMP_STEP_FORWARD;
                    break;
                case PLAY_MODE_ICON_FB_INVALID:
                    u16BtimapIdx = E_BMP_DMP_BUTTON_ICON_FB_INVALID;
                    break;
                case PLAY_MODE_ICON_FF_INVALID:
                    u16BtimapIdx = E_BMP_DMP_BUTTON_ICON_FF_INVALID;
                    break;

            #if (ENABLE_DRM)
                case HWND_DMP_DRM_ALERT_ICON:
                    switch(_DrmBitmapIdx)
                    {
                        case DRM_Bitmap_None:
                            //u16BtimapIdx = 0xFFFF;
                            break;
                        case DRM_Bitmap_Warning:
                            u16BtimapIdx = E_BMP_DMP_ALERT_ICON_INVALID_OPERATION;
                            break;
                        case DRM_Bitmap_Error:
                            u16BtimapIdx = E_BMP_DMP_ALERT_ICON_UNSUPPORTED;
                            break;
                    }
                    break;
            #endif //ENABLE_DRM

                default:
                    break;
            }
           // if (MApp_MPlayer_QueryCurrentMediaType()!= E_MPLAYER_TYPE_PHOTO) _enDmpPlayIconType = PLAY_MODE_ICON_MAX;
        }
        break;

        default:
            break;
    }
    return u16BtimapIdx;
}
S16 MApp_ZUI_ACT_GetDmpDynamicValue(HWND hwnd)
{
    switch(hwnd)
    {
        case HWND_DMP_VOLUME_CONFIG_BAR:
            return stGenSetting.g_SoundSetting.Volume;
        default:
            break;
    }
    return 0; //for empty  data
}

#if (ENABLE_DRM)

extern BOOLEAN MApp_VDPlayer_CheckDRMActivationFile(void);

static void _MApp_ACTdmp_CheckDRMActivation(void)
{
    if(MApp_VDPlayer_CheckDRMActivationFile() == TRUE)
    {
        DMP_DBG(printf("activation!\n"););
        MApp_LoadGenSetting();
        if(stGenSetting.g_VDplayerDRMInfo.bIsActivated==FALSE)
        {
            stGenSetting.g_VDplayerDRMInfo.bIsActivated = TRUE;
            stGenSetting.g_VDplayerDRMInfo.bIsDeactivated = FALSE;
            MApp_SaveGenSetting();
        }
    }
    else
    {
        DMP_DBG(printf("MApp_VDPlayer_CheckDRMActivationFile() == FALSE\n"););
    }
}

void _MApp_ZUI_ACTdmp_AppShowDRM(void)
{
    DrmInfo = MApp_VDPlayer_GetDRMInfo();
    DMP_DBG(printf(" >>>      FILE_FORMAT= %lu  \n",DrmInfo.u8DrmFileFormat););
    DMP_DBG(printf(" >>>    AUTHORIZATION_STATUS=%lu \n",DrmInfo.u8DrmAuthorization););
    DMP_DBG(printf(" >>>     RENTAL_EXPIRE_STATUS=%lu  \n",DrmInfo.u8DrmRentalStatus););
    DMP_DBG(printf(" >>>      RENTAL_USE_LIMIT=%lu  \n",DrmInfo.u32DrmRentalLimit););
    DMP_DBG(printf(" >>>     E_SHAREMEM_DRM_RENTAL_USE_COUNT=%lu  \n",DrmInfo.u32DrmRentalUseCount););
    DMP_DBG(printf(" >>>     E_VDPLAYER_ERROR_INFO=%lu  \n",DrmInfo.u32VDPlayerErrCode););

    if(MApp_ZUI_API_IsWindowVisible(HWND_DMP_ALERT_WINDOW))
    {
	MApp_ZUI_API_ShowWindow(HWND_DMP_ALERT_WINDOW,SW_HIDE);
    }

    if(DrmInfo.u32VDPlayerErrCode == EN_VDP_ERRORCODE_DRM_ERR_VERSION_EXPIRED)
    {
        _MApp_ACTdmp_ShowDrmWin(WinUnsupported);
    }
    else
    {
        if(DrmInfo.u8DrmFileFormat)// Check if it is DRM file
        {
            DMP_DBG(printf("DrmInfo.u8DrmFileFormat true\n"););
            if(!DrmInfo.u8DrmAuthorization) // init fail
            {
                DMP_DBG(printf("V03\n"););
                //MENU_DLG_DRM_AUTHORIZATION Error PAGE
                _MApp_ACTdmp_ShowDrmWin(WinAuthError);
            }
            else
            {
                DMP_DBG(printf("DrmInfo.u8DrmAuthorization TRUE\n"););
            //can play drm
                if(DrmInfo.u8DrmRentalStatus)
                {
                    DMP_DBG(printf("show show user expired\n"););
                    //MENU_DLG_DRM_RETAL_EXPIRE
                    //show user expired
                    _MApp_ACTdmp_ShowDrmWin(WinRentalExpired);
                }
                else
                {
                    //RENTAL_EXPIRE_STATUS
                    //show user limit
                    DMP_DBG(printf("V04\n"););
                    _MApp_ACTdmp_CheckDRMActivation();
                    _MApp_ACTdmp_ShowDrmWin(WinViewRental);
                }
            }
        }
        else
        {
            DMP_DBG(printf("DrmInfo.u8DrmFileFormat false\n"););
        }
    }
}
#endif

#if SH_RESUME_AUTOPLAY
void MApp_ZUI_ACT_ExecuteDmpAction_EN_EXE_DMP_MOVIERESUME_YES(void)
{
//MApp_ZUI_ACT_ExecuteDmpAction(EN_EXE_DMP_MOVIERESUME_YES);
isMusicResume=2;
msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_BYUSER_MUTEON, E_AUDIOMUTESOURCE_ACTIVESOURCE);
}
#endif

/////////////////////////////////////////////////////////
// Customize Window Procedures

BOOLEAN MApp_UiMediaPlayer_Notify(enumMPlayerNotifyType eNotify, void *pInfo)
{
    if (IsStorageInUse())
    {
        #ifdef ENABLE_KTV
        if(MApp_ZUI_GetActiveOSD() == E_OSD_KTV)
        {
            return MApp_UiMediaPlayer_KTV_Notify(eNotify, pInfo);
        }
        #endif

        if (MApp_ZUI_GetActiveOSD() == E_OSD_DMP)
        {
            // notification accepted
        }
        else if (((MApp_ZUI_GetActiveOSD() == E_OSD_MAIN_MENU)
                        || (MApp_ZUI_GetActiveOSD() == E_OSD_INPUT_SOURCE))
                && ((eNotify == E_MPLAYER_NOTIFY_USB_DEVICE_STATUS_CHANGE)
                        || (eNotify == E_MPLAYER_NOTIFY_USB_ACTIVE_DEVICE_STATUS_CHANGE)
                        ||(eNotify == E_MPLAYER_NOTIFY_END_OF_PLAY_ALL_FILE)
                        ||(eNotify == E_MPLAYER_NOTIFY_END_OF_PLAY_ONE_FILE)
                        ||(eNotify == E_MPLAYER_NOTIFY_PLAY_NEXT_FILE)
                        ||(eNotify == E_MPLAYER_NOTIFY_PLAY_PREVIOUS_FILE)
                        ||(eNotify == E_MPLAYER_NOTIFY_ERROR_OF_PLAY_FILE)
                        ))
        {
            // notification accepted
        }
        else if((MApp_DMP_GetDMPStat()==DMP_STATE_RETURN_FROM_MENU)
                   &&((eNotify == E_MPLAYER_NOTIFY_ERROR_OF_PLAY_FILE)
                        ))
        {
            // notification accepted
        }
        else
        {
            // notification not accepted
            // DMP_DBG(printf("Notification (%d) doesn't accept\n", eNotify));
            return FALSE;
        }
    }

    _enNotify = eNotify; //backup notify event.
    _enPlayMode_AtNotify = MApp_MPlayer_QueryMoviePlayMode();

    switch(eNotify)
    {
    #if ENABLE_DRM
        case E_MPLAYER_NOTIFY_DRM_INIT:
        {
            DMP_DBG(printf("E_MPLAYER_NOTIFY_DRM_INIT\n"););
            _MApp_ZUI_ACTdmp_AppShowDRM();
        }
        break;
    #endif

        case E_MPLAYER_NOTIFY_USB_DEVICE_STATUS_CHANGE:
            DMP_DBG(printf("E_MPLAYER_NOTIFY_USB_DEVICE_STATUS_CHANGE\n"));
            break;

        case E_MPLAYER_NOTIFY_USB_ACTIVE_DEVICE_STATUS_CHANGE:
            DMP_DBG(printf("E_MPLAYER_NOTIFY_USB_ACTIVE_DEVICE_STATUS_CHANGE\n"));
            {
                _MApp_ACTdmp_HandleUsbStatusChanged();
            }
            break;
        case E_MPLAYER_NOTIFY_DRIVE_CHANGE:
            DMP_DBG(printf("E_MPLAYER_NOTIFY_DRIVE_CHANGE\n"));
            {
                if(MApp_DMP_RecalculateDriveMappingTable())
                {
                    MApp_DMP_SetDmpFlag(DMP_FLAG_DRIVE_CONNECT_OK);
                    U8 i;
                    // Search previous mapped drive

                    for(i=0; i<NUM_OF_MAX_DRIVE; i++)
                    {
                        if(MApp_MPlayer_QueryCurrentDriveIndex() == MApp_DMP_GetDriveFromMappingTable(i))
                        {
                            MApp_DMP_SetCurDrvIdxAndCalPageIdx(i);
                        }
                        //printf("[Mappings] %bu. --> drive %bu\n", i, MApp_MediaPlayer_GetDriveFromMappingTable(i));
                    }

                    if(MApp_ZUI_GetActiveOSD() == E_OSD_MAIN_MENU
                        || MApp_ZUI_GetActiveOSD() == E_OSD_INPUT_SOURCE)
                    {
                        return FALSE;;
                    }

                    if(MApp_DMP_GetDmpUiState() == DMP_UI_STATE_DRIVE_SELECT)
                    {
                        U8 u8Idx = (MApp_DMP_GetCurDrvIdx()+1) % DMP_DRIVE_NUM_PER_PAGE;
                        MApp_ZUI_API_SetFocus(_hwndListDriveItem[u8Idx]);
                        MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_DRIVE_PAGE);
                    }
                    else
                    {
                        MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_MEDIA_TYPE_USB_GROUP);
                    }
                }
                else
                {
                    MApp_DMP_ClearDmpFlag(DMP_FLAG_DRIVE_CONNECT_OK);
                    MApp_DMP_UiStateTransition(DMP_UI_STATE_MEDIA_SELECT);
                    MApp_MPlayer_Stop(); // for bgm
                }
            }
            break;
        case E_MPLAYER_NOTIFY_SHOW_MUSIC_NFO:
            DMP_DBG(printf("    - E_MPLAYER_NOTIFY_SHOW_MUSIC_NFO\n"));
            {
                // do nothing
                MApp_ZUI_API_ShowWindow(HWND_DMP_FILE_PAGE_PREVIEW_INFO_GROUP, SW_SHOW);
            }
            break;
        case E_MPLAYER_NOTIFY_HIDE_SUBTITLE:
            DMP_DBG(printf("    - E_MPLAYER_NOTIFY_HIDE_SUBTITLE\n"));
            {
                memset(_stDmpPlayVar.stMovieInfo.MPlayerSubtitleBuf,0, DMP_STRING_BUF_SIZE);
                MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_SUBTITLE_PAGE,SW_HIDE);
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_SUBTITLE_PAGE);
            }
            #if DMP_UI_BMPSUBTITLE_EXCLUSIVE
            if( !MApp_DMP_IsOSDVisible()&& !bUIexist
                && !MApp_MPlayer_IsCurSubtitleText()
                )
                {
                    U8 u8GWinId = MApp_ZUI_API_QueryGWinID();
                    if(u8GWinId == 0xFF)
                    {
                        MApp_ZUI_API_EmptyMessageQueue();
                        return FALSE;
                   }
                   if(MApi_GOP_GWIN_IsGWINEnabled(u8GWinId))
                  {
                        MApi_GOP_GWIN_Enable(u8GWinId, FALSE);
                        MApp_DMP_BW_Control(FALSE);
                        MApp_ZUI_API_EmptyMessageQueue();
                        MApp_ZUI_API_TerminateGDI();
                        msAPI_MpegSP_SetShowStatus(TRUE);
                    DMP_DBG(printf("MApp_ZUI_API_TerminateGDI 3\n"););
                  }
                }
            #endif

            break;
        case E_MPLAYER_NOTIFY_SHOW_SUBTITLE:
            DMP_DBG(printf("    - E_MPLAYER_NOTIFY_SHOW_SUBTITLE\n"));

            if(!_stDmpPlayVar.stMovieInfo.bSubtitleOff)
                {
                #if DMP_UI_BMPSUBTITLE_EXCLUSIVE
                    _MApp_ZUI_ACTdmp_RestoreGWINandFB();
                #endif
                    memcpy(_stDmpPlayVar.stMovieInfo.MPlayerSubtitleBuf,(U8*)pInfo, DMP_STRING_BUF_SIZE);
                    MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_SUBTITLE_PAGE,SW_SHOW);
                    MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_SUBTITLE_PAGE);

            }
            break;

        case E_MPLAYER_NOTIFY_SHOW_LYRIC:
            DMP_DBG(printf("    - E_MPLAYER_NOTIFY_SHOW_LYRIC\n"));
            {
                MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_LYRIC_PAGE,SW_SHOW);
                memcpy(_stDmpPlayVar.stMusicInfo.MPlayerLyricBuf,(U8*)pInfo, DMP_STRING_BUF_SIZE);
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_LYRIC_PAGE);
            }
            break;

        case E_MPLAYER_NOTIFY_PLAYING_TIME_TICK:
			DMP_DBG(printf("    - E_MPLAYER_NOTIFY_PLAYING_TIME_TICK\n"));
            {
                if(MApp_MPlayer_QueryCurrentMediaType() == E_MPLAYER_TYPE_MOVIE)
                {
                    U16 u16MovieCurrentTime = *(U16*)pInfo;
                    // Todo: update movie info window - current time
                    if(MApp_ZUI_API_IsWindowVisible(HWND_DMP_PLAYBACK_INFO_PANE))
                    {
                        if(_u16MovieTotalTime != 0xFFFF && _u16MovieTotalTime != 0)
                        {
                            U32 u32Percent = _u16MovieCurrentTime*100 /_u16MovieTotalTime;
								if(u32Percent>100)
									u32Percent=100;
			    				MApp_ZUI_CTL_PercentProgressBar_SetPercentage(u32Percent);
                        }
                        else if(_u16MovieTotalTime == 0)
                        {
                            MApp_ZUI_CTL_PercentProgressBar_SetPercentage(0);
                        }
                        else
                        {
                             MApp_ZUI_CTL_PercentProgressBar_SetPercentage(0);
                            DMP_DBG(printf("[Error] Get total time failed! (0x%lx)\n", _u16MovieTotalTime););
                        }
                            MApp_ZUI_API_InvalidateWindow(HWND_DMP_PLAYBACK_PAGE_TIME_GROUP);
                    }

                    if(u16MovieCurrentTime <= 1)
                    {
                        //need reset movie status
                        if(MApp_MPlayer_QueryMoviePlayMode() != E_MPLAYER_MOVIE_NORMAL)
                         {
                          //  if(MApp_MPlayer_QueryMoviePlayMode() != E_MPLAYER_MOVIE_NORMAL)
                            MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_NORMAL);
                            _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_PLAY;
                            MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_SHOW);
                            MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN, DMP_TIME_MS_PLAY_STATUS_WIN);
                            DMP_MusicInfoBarTable[MUSICINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PAUSE;
                            DMP_MusicInfoBarTable[MUSICINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Pause;
                        }
                    }

                }
                else if(MApp_MPlayer_QueryCurrentMediaType() == E_MPLAYER_TYPE_MUSIC)
                {
                
#if SH_RESUME_AUTOPLAY
									if(isMusicResume)
									{
										 if(--isMusicResume==0)
											{
										  isMusicResume=0;
										  
										  MApp_ZUI_ACT_ExecuteDmpAction(EN_EXE_DMP_MOVIERESUME_YES);
										  msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_BYUSER_MUTEOFF, E_AUDIOMUTESOURCE_ACTIVESOURCE);
											}
									}
#endif
                    if(MApp_ZUI_API_IsWindowVisible(HWND_DMP_PLAYBACK_INFO_PANE))
                    {
                        U32 u32MusicCurrentTime = *(U32*)pInfo;
                        _u32MusicCurrentTime = u32MusicCurrentTime;
                        //printf("===============%u\n",MApp_MPlayer_QueryMusicFilePlayTime());
                        if(MApp_MPlayer_QueryMusicFilePlayTime() == u32MusicCurrentTime)
                        { // to the end of file
                            //printf("################%u\n",u16MusicCurrentTime);
                            if(MApp_MPlayer_IsCurrentLRCLyricAvailable() == E_MPLAYER_RET_OK)
                            {
                                MApp_MPlayer_DisableLRCLyric();
                                memset((U8*)_stDmpPlayVar.stMusicInfo.MPlayerLyricBuf, 0, DMP_STRING_BUF_SIZE);
                                MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_LYRIC_PAGE, SW_HIDE);
                            }
                            /*
                            MApp_ZUI_API_KillTimer(HWND_MEDIA_PLAYER_EQ_LIST, MPLAYER_EQ_TIMER);
                            MApp_ZUI_API_ShowWindow(HWND_MEDIA_PLAYER_EQ_LIST, SW_HIDE);
                            MApp_ZUI_API_ShowWindow(HWND_MEDIA_PLAYER_LYRIC_STATUS, SW_HIDE);
                            MApp_ZUI_API_ShowWindow(HWND_MEDIA_PLAYER_PREVIEW_TIME, SW_HIDE);
                            MApp_ZUI_API_ShowWindow(HWND_MEDIA_PLAYER_PLAY_STATUS, SW_HIDE);

                            if(MApp_MPlayer_QueryMusicPlayMode() != E_MPLAYER_MUSIC_NORMAL)
                            {
                                MApp_MPlayer_MusicChangePlayMode(E_MPLAYER_MUSIC_NORMAL);
                            }
                            */
                        }
                        if(MApp_MPlayer_QueryMusicFilePlayTime() >= u32MusicCurrentTime)
                        {
                            // Todo: update music preview window - current time
                            U32 u32TotalTime = MApp_MPlayer_QueryMusicFilePlayTime();
                            if(u32TotalTime == 0)
                            {
                                DMP_DBG(printf("u32TotalTime == 0\n"););
                                //u32TotalTime = 1;
                                MApp_ZUI_CTL_PercentProgressBar_SetPercentage(0);
                            }
                            else if(u32TotalTime != 0xFFFFFFFF)
                            {
                                //printf("%d\n", (U8)u32Percent);
                                U32 u32CurTime = u32MusicCurrentTime;
                                U32 u32Percent = u32CurTime*100 / (u32TotalTime);
									if(u32Percent>100)
										u32Percent=100;
									MApp_ZUI_CTL_PercentProgressBar_SetPercentage(u32Percent);
                            }
                            else
                            {
                                MApp_ZUI_CTL_PercentProgressBar_SetPercentage(0);
                                DMP_DBG(printf("[Error] Get total time failed! (0x%lx)\n", u32TotalTime););
                            }
                            MApp_ZUI_API_InvalidateWindow(HWND_DMP_PLAYBACK_PAGE_TIME_GROUP);
                        }
                        if(u32MusicCurrentTime == 0)
                        {
                            //need reset music status
                            if(MApp_MPlayer_QueryMusicPlayMode() != E_MPLAYER_MUSIC_NORMAL)
                            {
                                MApp_MPlayer_MusicChangePlayMode(E_MPLAYER_MUSIC_NORMAL);
                                _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_PLAY;
                                MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_SHOW);
                                MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN, DMP_TIME_MS_PLAY_STATUS_WIN);
                                DMP_MusicInfoBarTable[MUSICINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PAUSE;
                                DMP_MusicInfoBarTable[MUSICINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Pause;
                            }
                        }
                    }
                }
            }
            break;
        case E_MPLAYER_NOTIFY_BEFORE_PHOTO_PREVIEW:
            DMP_DBG(printf("    - E_MPLAYER_NOTIFY_BEFORE_PHOTO_PREVIEW\n"));
            {
                MApi_GOP_GWIN_SwitchGOP(E_GOP_OSD);
                MApp_ZUI_API_ShowWindow(HWND_DMP_FILE_PAGE_PREVIEW_GROUP, SW_SHOW);
                MApp_ZUI_API_ShowWindow(HWND_DMP_FILE_PAGE_PREVIEW_INFO_GROUP, SW_SHOW);
                _MApp_ZUI_ACT_DMPMarqueeTextEnableAnimation(HWND_DMP_FILE_PAGE_PREVIEW_FILENAME_STRING, TRUE);
            }
            break;
        case E_MPLAYER_NOTIFY_END_OF_PHOTO_PREVIEW:
            DMP_DBG(printf("    - E_MPLAYER_NOTIFY_END_OF_PHOTO_PREVIEW\n"));
            // TODO: refine here
            //MApi_GOP_GWIN_SwitchGOP(E_GOP_OSD);
            //MApp_ZUI_API_ShowWindow(HWND_DMP_FILE_PAGE_PREVIEW_GROUP, SW_SHOW);
            //MApp_ZUI_API_ShowWindow(HWND_DMP_FILE_PAGE_PREVIEW_INFO_GROUP, SW_SHOW);
            //_MApp_ACTdmp_HidePreviewWin();
            break;
        case E_MPLAYER_NOTIFY_BEFORE_MUSIC_PREVIEW:
            DMP_DBG(printf("    - E_MPLAYER_NOTIFY_BEFORE_MUSIC_PREVIEW\n"));
            break;
        case E_MPLAYER_NOTIFY_END_OF_MUSIC_PREVIEW:
            DMP_DBG(printf("    - E_MPLAYER_NOTIFY_END_OF_MUSIC_PREVIEW\n"));
            {
                _MApp_ACTdmp_HidePreviewWin();
            }
            break;
        case E_MPLAYER_NOTIFY_BEFORE_MOVIE_PREVIEW:
            DMP_DBG(printf("    - E_MPLAYER_NOTIFY_BEFORE_MOVIE_PREVIEW\n"));
            {
                MApp_ZUI_API_ShowWindow(HWND_DMP_FILE_PAGE_PREVIEW_GROUP, SW_SHOW);
                MApp_ZUI_API_ShowWindow(HWND_DMP_FILE_PAGE_PREVIEW_INFO_GROUP, SW_SHOW);
                _MApp_ZUI_ACT_DMPMarqueeTextEnableAnimation(
                HWND_DMP_FILE_PAGE_PREVIEW_FILENAME_STRING, TRUE);
		   //don't set timer to keep preview info
                //MApp_ZUI_API_SetTimer(HWND_DMP_FILE_PAGE_PREVIEW_INFO_GROUP, DMP_TIMER_PREVIEW_WIN, DMP_TIME_MS_PREVIEW_WIN);
            }
            break;
        case E_MPLAYER_NOTIFY_END_OF_MOVIE_PREVIEW:
            DMP_DBG(printf("    - E_MPLAYER_NOTIFY_END_OF_MOVIE_PREVIEW\n"));
           // printf("dmp_movie_preview");
            {
                MApp_ZUI_API_KillTimer(HWND_DMP_FILE_PAGE_PREVIEW_INFO_GROUP, DMP_TIMER_PREVIEW_WIN);
                // don't call stop preview here to leave last frame on screen
                // MApp_MPlayer_StopPreview();
                //MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_FILE_PAGE_PREVIEW_INFO_GROUP);
                // special case, leave preview window here
                //MApp_ZUI_API_ShowWindow(HWND_DMP_FILE_PAGE_PREVIEW_GROUP, SW_HIDE);
            }
            break;
        case E_MPLAYER_NOTIFY_END_OF_TEXT_PREVIEW:
            DMP_DBG(printf("    - E_MPLAYER_NOTIFY_END_OF_TEXT_PREVIEW\n"));
            MApp_ZUI_API_ShowWindow(HWND_DMP_FILE_PAGE_PREVIEW_GROUP, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_DMP_FILE_PAGE_PREVIEW_INFO_GROUP, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_DMP_FILE_PAGE_PREVIEW_TEXT, SW_SHOW);
            break;
        case E_MPLAYER_NOTIFY_MEDIA_PREDECODE_OK:
        DMP_DBG(printf("    - E_MPLAYER_NOTIFY_MEDIA_PREDECODE_OK\n"));
            break;
        #if ENABLE_LAST_MEMORY
        case E_MPLAYER_NOTIFY_LAST_MEMORY_RESUME_PLAY:
        // this notify is behind the E_MPLAYER_NOTIFY_BEFORE_PLAY_ONE_FILE immediately
        //popup the resume dialog
            DMP_DBG(printf("    - E_MPLAYER_NOTIFY_LAST_MEMORY_RESUME_PLAY\n"));
		#if SH_RESUME_AUTOPLAY
            if(MApp_MPlayer_QueryCurrentMediaType() == E_MPLAYER_TYPE_MOVIE||MApp_MPlayer_QueryCurrentMediaType() == E_MPLAYER_TYPE_MUSIC)
            {
                MApp_ZUI_ACT_ExecuteDmpAction(EN_EXE_DMP_MOVIERESUME_YES);
                break;
                //if(MApp_ZUI_API_IsWindowVisible(HWND_DMP_PLAYBACK_PAGE_INFOBAR))
                //    MApp_ZUI_API_StoreFocusCheckpoint();
                //MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_MOVIERESUME_PAGE, SW_SHOW);
                //MApp_ZUI_API_SetFocus(HWND_DMP_PLAYBACK_MOVIERESUME_YES);
            }
		#endif	
            break;
        #endif //ENABLE_LAST_MEMORY
        case E_MPLAYER_NOTIFY_BEFORE_PLAY_ONE_FILE:
        DMP_DBG(printf("    - E_MPLAYER_NOTIFY_BEFORE_PLAY_ONE_FILE\n"));
        {
#if ENABLE_DRM
            if(pInfo == NULL)
            {
                MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_HIDE);
                break;
            }
#endif
            if(MApp_DMP_GetDmpUiState() == DMP_UI_STATE_FILE_SELECT)
            {
                // for movie thumbnail, do nothing
            }
            else if(MApp_DMP_GetDmpUiState() == DMP_UI_STATE_LOADING)
            {
                // TODO: need refine
                m_u16PlayErrorNum = 0;
                MApp_DMP_UiStateTransition(DMP_UI_STATE_PLAYING_STAGE);
                DMP_DBG(printf("    - change to PLAYING_STAGE\n"));
            }
            else if(MApp_DMP_GetDmpUiState() == DMP_UI_STATE_PLAYING_STAGE)
            {
                //m_u16PlayErrorNum = 0;
                DMP_DBG(printf("    -PLAYING_STAGE--\n"));
                // put some initial variable or initial call after mapp_mplayer_play

                BOOLEAN bInfoShow = FALSE; // this is for info page
                enumMPlayerMediaType eMediaType = MApp_MPlayer_QueryCurrentMediaType();
                g_bPlayPrev = FALSE;
                if(MApp_ZUI_API_IsWindowVisible(HWND_DMP_PLAYBACK_INFO_PANE))
                {
                    bInfoShow = TRUE;
                }
#if CUS_SMC_ENABLE_HOTEL_MODE
			if(MApp_ZUI_API_GetFocus()!=HWND_DMP_HOTEL_PASSWD_PANEL_OPTION && MApp_ZUI_API_GetFocus()!=HWND_DMP_HOTEL_PASSWD_WRONG)
#endif
                MApp_ZUI_API_StoreFocusCheckpoint();
                DMP_DBG(printf("playing eMediaType %u\n",eMediaType););
                switch(eMediaType)
                {
                    case E_MPLAYER_TYPE_MOVIE:
                    {
                       _MApp_ACTdmp_MovieResetRepeatAB();
                    #if (ENABLE_DIVX_PLUS == 1)
                        _u16DivxTitleIdx = 0;
                        _u16DivxEditionIdx = 0;
                        _u16DivxChpIdx = 0;
                        _u8DivxAutoChpIdx = 0;
                    #endif
                        MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_TRANSPARENT_BG, SW_SHOW);
                        DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PAUSE;
                        DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Pause;
                        if(bInfoShow)
                        {
                            _MApp_ACTdmp_Playback_ShowInfoWin(E_MPLAYER_TYPE_MOVIE);
                        }
                        else
                        {
                            MApp_ZUI_API_SetFocus(HWND_DMP_PLAYBACK_TRANSPARENT_BG);
                        }

                        //MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_NORMAL);

                        _stDmpPlayVar.stMovieInfo.bSubtitleOff = FALSE;
#if (ENABLE_SUBTITLE_DMP)
                       // MApp_MPlayer_MovieChangeSubtitleTrack(0);
#endif
                        _MApp_ZUI_ACTdmp_OperateSubtitle();
                        DMP_DBG(printf("Turn ON external SUBTITLE\n"););
                        //MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_SUBTITLE_PAGE ,SW_SHOW);
                        //MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_SUBTITLE_PAGE);

                        _stDmpPlayVar.stMovieInfo.au32MovieRepeatTime[0] = 0xFFFFFFFF;
                        _stDmpPlayVar.stMovieInfo.au32MovieRepeatTime[1] = 0xFFFFFFFF;
                        memset((U8*)_stDmpPlayVar.stMovieInfo.MPlayerSubtitleBuf, 0, DMP_STRING_BUF_SIZE);
                    }
                        break;

                    case E_MPLAYER_TYPE_PHOTO:
                        MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_TRANSPARENT_BG, SW_SHOW);
                        if(MApp_MPlayer_QueryPhotoPlayMode() == E_MPLAYER_PHOTO_NORMAL)
                        {
                            DMP_PhotoInfoBarTable[PHOTOINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PAUSE;
                            DMP_PhotoInfoBarTable[PHOTOINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Pause;
                        }
                        else if(MApp_MPlayer_QueryPhotoPlayMode() == E_MPLAYER_PHOTO_PAUSE)
                        {
                            DMP_PhotoInfoBarTable[PHOTOINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PLAY;
                            DMP_PhotoInfoBarTable[PHOTOINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Play;
                        }
#if CUS_SMC_ENABLE_HOTEL_MODE
						if(MApp_ZUI_API_GetFocus()==HWND_DMP_HOTEL_PASSWD_PANEL_OPTION || MApp_ZUI_API_GetFocus()==HWND_DMP_HOTEL_PASSWD_WRONG)
						   ;
						else
#endif
                        if(bInfoShow)
                        {
                            _MApp_ACTdmp_Playback_ShowInfoWin(E_MPLAYER_TYPE_PHOTO);
                        }
                        else
                        {
                            MApp_ZUI_API_SetFocus(HWND_DMP_PLAYBACK_TRANSPARENT_BG);
                        }

                        break;

                    case E_MPLAYER_TYPE_MUSIC:
                        if(MApp_DMP_GetDmpFlag() & DMP_FLAG_BGM_MODE)
                        {
                        }
                        else
                        {
                            MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_TRANSPARENT_BG, SW_SHOW);
                            DMP_MusicInfoBarTable[MUSICINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PAUSE;
                            DMP_MusicInfoBarTable[MUSICINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Pause;
                            MApp_ZUI_CTL_PercentProgressBar_SetPercentage(0);
                            if(bInfoShow)
                            {
                                _MApp_ACTdmp_Playback_ShowInfoWin(E_MPLAYER_TYPE_MUSIC);
                            }
                            else
                            {
                                MApp_ZUI_API_SetFocus(HWND_DMP_PLAYBACK_TRANSPARENT_BG);
                            }
                            // lyrics
                            if(MApp_MPlayer_IsCurrentLRCLyricAvailable() == E_MPLAYER_RET_OK)
                            {
                                MApp_MPlayer_EnableLRCLyric();
                                //MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_LYRIC_PAGE,SW_SHOW);
                            }
                            else
                            {
                                DMP_DBG(printf("MApp_MPlayer_IsCurrentLRCLyricAvailable fail playing stage\n"););
                            }
                            MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_MUSIC_EQ_GROUP, DMP_TIMER_EQ_PLAY, DMP_TIME_MS_EQ_PLAY);
                        }
                        break;
                    case E_MPLAYER_TYPE_TEXT:
                        MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_TEXT_FULL_WINDOW, SW_SHOW);
                        if(bInfoShow)
                        {
                            _MApp_ACTdmp_Playback_ShowInfoWin(eMediaType);
                        }
                        else
                        {
                            MApp_ZUI_API_SetFocus(HWND_DMP_PLAYBACK_TEXT_FULL_WINDOW);
                        }
                        //
                        MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_TEXT_FULL_WINDOW);
                        break;
                    default:
                        break;
                }
                #if 0//DMP_UI_BMPSUBTITLE_EXCLUSIVE
                U8 u8GWinId = MApp_ZUI_API_QueryGWinID();
                if(u8GWinId == 0xFF)
                {
                    MApp_ZUI_API_EmptyMessageQueue();
                }
                #endif
                #if DMP_UI_BMPSUBTITLE_EXCLUSIVE
                 // enable UI
                _MApp_ZUI_ACTdmp_RestoreGWINandFB();
                #endif //DMP_UI_BMPSUBTITLE_EXCLUSIVE

            }
            else
            {
                DMP_DBG(printf("    - UI state entered an unknown state! (%d)\n", MApp_DMP_GetDmpUiState()));
                MApp_MPlayer_Stop();
                MApp_MPlayer_StopMusic();
                MApp_DMP_UiStateTransition(DMP_UI_STATE_FILE_SELECT);
            }
        }
        break;
        case E_MPLAYER_NOTIFY_END_OF_PLAY_ONE_FILE:
        DMP_DBG(printf("    - E_MPLAYER_NOTIFY_END_OF_PLAY_ONE_FILE\n"));
        {
            m_u16PlayErrorNum = 0;
            switch(MApp_MPlayer_QueryCurrentMediaType())
            {
                case E_MPLAYER_TYPE_MOVIE:
                {

                    if(_u16MovieTotalTime != 0xFFFF && _u16MovieTotalTime != 0)
                    {
                        U32 u32Percent = _u16MovieCurrentTime*100 /_u16MovieTotalTime;
                        if(u32Percent>100)
                            u32Percent=100;
                        MApp_ZUI_CTL_PercentProgressBar_SetPercentage(u32Percent);
                    }
                    else if(_u16MovieTotalTime == 0)
                    {
                        MApp_ZUI_CTL_PercentProgressBar_SetPercentage(0);
                    }
                    else
                    {
                        MApp_ZUI_CTL_PercentProgressBar_SetPercentage(0);
                        DMP_DBG(printf("[Error] Get total time failed! (0x%lx)\n", _u16MovieTotalTime););
                    }
                    MApp_ZUI_API_InvalidateWindow(HWND_DMP_PLAYBACK_PAGE_TIME_GROUP);

                        memset((U8*)_stDmpPlayVar.stMovieInfo.MPlayerSubtitleBuf, 0, DMP_STRING_BUF_SIZE);
                        MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_SUBTITLE_PAGE, SW_HIDE);

                    // update movie info window - current time
                    if(MApp_ZUI_API_IsWindowVisible(HWND_DMP_PLAYBACK_INFO_PANE))
                    {
                        MApp_ZUI_API_InvalidateWindow(HWND_DMP_PLAYBACK_PAGE_TIME_GROUP);
                    }
                    MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_HIDE);
                    MApp_ZUI_API_KillTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN);
                }
                #if DMP_UI_BMPSUBTITLE_EXCLUSIVE
                U8 u8GWinId = MApp_ZUI_API_QueryGWinID();
                if(u8GWinId == 0xFF)
                {
                    MApp_ZUI_API_EmptyMessageQueue();
                }
                #endif

                break;
                case E_MPLAYER_TYPE_MUSIC:
                    if(MApp_MPlayer_IsCurrentLRCLyricAvailable() == E_MPLAYER_RET_OK)
                    {
                        memset((U8*)_stDmpPlayVar.stMusicInfo.MPlayerLyricBuf, 0, DMP_STRING_BUF_SIZE);
                        MApp_MPlayer_DisableLRCLyric();
                        MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_LYRIC_PAGE,SW_HIDE);
                    }
                    MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_HIDE);
                    MApp_ZUI_API_KillTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN);
                    break;
                default:
                    break;
            }
        }
        break;
        case E_MPLAYER_NOTIFY_END_OF_PLAY_ALL_FILE:
        DMP_DBG(printf("    - E_MPLAYER_NOTIFY_END_OF_PLAY_ALL_FILE\n"));
        {
            switch(MApp_MPlayer_QueryCurrentMediaType())
            {
                case E_MPLAYER_TYPE_PHOTO:
                case E_MPLAYER_TYPE_TEXT:
                    MApp_MPlayer_StopMusic();
                    break;
                case E_MPLAYER_TYPE_MOVIE:
                    break;
                case E_MPLAYER_TYPE_MUSIC:
                    MApp_ZUI_API_KillTimer(HWND_DMP_PLAYBACK_MUSIC_EQ_GROUP, DMP_TIMER_EQ_PLAY);
                    MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_MUSIC_EQ_GROUP, SW_HIDE);
                    break;
                default:
                    break;
            }
            U16 u16PlayingIdx = 0;
            if (!MApp_MPlayer_Change2TargetPath(MApp_MPlayer_QueryCurrentPlayingList()))
            {
                DMP_DBG(printf("MApp_MPlayer_Change2TargetPath fail EXIT\n");)
            }
            u16PlayingIdx = MApp_MPlayer_QueryCurrentPlayingFileIndex();
            MApp_MPlayer_SetCurrentPageIndex(u16PlayingIdx/NUM_OF_PHOTO_FILES_PER_PAGE);
            DMP_DBG(printf("\n### Current playing idx : %d\n", u16PlayingIdx););
            if(MApp_MPlayer_SetCurrentFile(E_MPLAYER_INDEX_CURRENT_DIRECTORY, u16PlayingIdx) != E_MPLAYER_RET_OK)
            {
                DMP_DBG(printf("MApp_MPlayer_SetCurrentFile fail 1\n"););
                MApp_MPlayer_SetCurrentFile(E_MPLAYER_INDEX_CURRENT_DIRECTORY, 0);
                MApp_MPlayer_SetCurrentPageIndex(0);
            }
            msAPI_Scaler_SetBlueScreen_Origin(TRUE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
            MApi_XC_GenerateBlackVideo( ENABLE, MAIN_WINDOW );
            if( MApp_DMP_GetDMPStat()==DMP_STATE_RETURN_FROM_MENU)
            {
                MApp_MPlayer_Stop();
                MApp_DMP_ClearDmpFlag(DMP_FLAG_MEDIA_FILE_PLAYING);
                MApp_DMP_ClearDmpFlag(DMP_FLAG_MEDIA_FILE_PLAYING_ERROR);
                MApp_DMP_ClearDmpFlag(DMP_FLAG_MEDIA_FILE_PLAYING);
                MApp_DMP_SetDmpUiState(DMP_UI_STATE_FILE_SELECT);

            }
            else
           {
               MApp_DMP_UiStateTransition(DMP_UI_STATE_FILE_SELECT);
            }
        }
        break;
        case E_MPLAYER_NOTIFY_TEXT_PREV_PAGE:
            MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_TEXT_FULL_WINDOW);
            DMP_DBG(printf("    - E_MPLAYER_NOTIFY_TEXT_PREV_PAGE\n"));
            break;
        case E_MPLAYER_NOTIFY_TEXT_NEXT_PAGE:
            MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_TEXT_FULL_WINDOW);
            DMP_DBG(printf("    - E_MPLAYER_NOTIFY_TEXT_NEXT_PAGE\n"));
            break;
        case E_MPLAYER_NOTIFY_END_OF_ONE_THUMBNAIL:
            DMP_DBG(printf("    - E_MPLAYER_NOTIFY_END_OF_ONE_THUMBNAIL\n"));
          #if (DMP_PHOTO_THUMBNAIL || DMP_MOVIE_THUMBNAIL || DMP_MUSIC_THUMBNAIL)
            {
                MPlayerNotifyOneThumbnail *pThumb = (MPlayerNotifyOneThumbnail*)pInfo;
                if(!pThumb->bOK)
                {
                    _ThumbNOIdx = pThumb->u16FileIdx;
                    _ThumbNOIdx = _ThumbNOIdx + MApp_MPlayer_QueryCurrentPageIndex()*NUM_OF_PHOTO_FILES_PER_PAGE;
                    DMP_DBG(printf("_ThumbNOIdx %u\n",_ThumbNOIdx););
                    MApp_ZUI_API_InvalidateWindow((HWND)(_hwndListFileIcon[pThumb->u16FileIdx%NUM_OF_PHOTO_FILES_PER_PAGE] ));
                    _InsertQFlag = FALSE;
                }
                else
                {
                    _ThumbOKIdx = pThumb->u16FileIdx;
                    _ThumbOKIdx = _ThumbOKIdx + MApp_MPlayer_QueryCurrentPageIndex()*NUM_OF_PHOTO_FILES_PER_PAGE;
                    DMP_DBG(printf("_ThumbOKIdx ok %u\n",_ThumbOKIdx););
                    MApp_ZUI_API_InvalidateWindow((HWND)(_hwndListFileIcon[pThumb->u16FileIdx%NUM_OF_PHOTO_FILES_PER_PAGE] ));
                    _InsertQFlag = FALSE;
                }
            }
          #endif
            break;

        case E_MPLAYER_NOTIFY_END_OF_THUMBNAIL:
            DMP_DBG(printf("    - E_MPLAYER_NOTIFY_END_OF_THUMBNAIL\n"));
            MApp_DMP_ClearDmpFlag(DMP_FLAG_THUMBNAIL_PLAYING);
            if(MApp_DMP_IsFileTypeByIdx(MApp_MPlayer_QueryCurrentFileIndex(E_MPLAYER_INDEX_CURRENT_DIRECTORY))
                && !MApp_ZUI_API_IsWindowVisible(HWND_DMP_FILE_PAGE_SUBMENU_GROUP)
                && !MApp_ZUI_API_IsWindowVisible(HWND_DMP_ALERT_WINDOW))
            {
                _MApp_ACTdmp_ShowPreviewWin();
            }
            break;

        case E_MPLAYER_NOTIFY_ERROR_OF_PLAY_FILE:
        DMP_DBG(printf("    - E_MPLAYER_NOTIFY_ERROR_OF_PLAY_FILE\n"));
        {
            // thumbnail
            {
                if(MApp_DMP_GetDmpFlag()& DMP_FLAG_THUMBNAIL_PLAYING)
                {
                    return FALSE;
                }
            }
            enumMPlayerMediaType eMediaType = *(enumMPlayerMediaType *)pInfo;

            if(MApp_DMP_GetDmpFlag() & DMP_FLAG_MEDIA_FILE_PLAYING
                || MApp_DMP_GetDmpFlag() & DMP_FLAG_THUMBNAIL_PLAYING)
            {
                DMP_DBG(printf("    - _MApp_DMP_ErrorHandling_PLAYING \n"));
/*
                if(_MApp_DMP_QueryTotalPlayListNum() == 1)
                {
                    DMP_DBG(printf("    - _MApp_DMP_ErrorHandling_GotoDefaultPage 1\n"));
                    MApp_DMP_SetDmpFlag(DMP_FLAG_MEDIA_FILE_PLAYING_ERROR);
                    _MApp_DMP_ErrorHandling_GotoDefaultPage(eMediaType);
                    //    _MApp_ACTdmp_ShowAlertWin(DMP_MSG_TYPE_UNSUPPORTED_FILE);
                }
*/
                m_u16PlayErrorNum++;
                if (MApp_MPlayer_QueryRepeatMode() ==E_MPLAYER_REPEAT_1)
                {
                    DMP_DBG(printf("    - _MApp_DMP_ErrorHandling_GotoDefaultPage: Repeat_1\n"));
                    MApp_DMP_SetDmpFlag(DMP_FLAG_MEDIA_FILE_PLAYING_ERROR);
                    _MApp_DMP_ErrorHandling_GotoDefaultPage(eMediaType);
                    return FALSE;
                    //    _MApp_ACTdmp_ShowAlertWin(DMP_MSG_TYPE_UNSUPPORTED_FILE);
                }
                else
                {// N files in the play list.
                    DMP_DBG(printf("[check] Play file error number = %d, Total Files : %d\n", m_u16PlayErrorNum, _MApp_DMP_QueryTotalPlayListNum()));
                    if(m_u16PlayErrorNum >= _MApp_DMP_QueryTotalPlayListNum())
                    {// All selected files are decoded error!
                        MApp_DMP_SetDmpFlag(DMP_FLAG_MEDIA_FILE_PLAYING_ERROR);
                        if( MApp_DMP_GetDMPStat()==DMP_STATE_RETURN_FROM_MENU)
                        {
                            _MApp_DMP_ErrorHandling_GotoFileSelectPage(eMediaType);
                        }
                        else
                        {
                           _MApp_DMP_ErrorHandling_GotoDefaultPage(eMediaType);
                        }
                        DMP_DBG(printf(" All selected files are decoded error!\n"));
                        return FALSE;
                    }
                    if( eMediaType == E_MPLAYER_TYPE_PHOTO ) // Error at play photo
                    {
                        // Let MApp_mplayer.c decide what to do~
                        return TRUE; // Continue play
                        //return FALSE; // Stop play
                    }
                    else
                    {
                        if(g_bPlayPrev)
                        {
                            if(MApp_DMP_GetDmpFlag()&DMP_FLAG_MEDIA_FILE_PLAYING)
                            {
                                DMP_DBG(printf("    - MApp_MPlayer_PlayPrevFile()\n"));
                                MApp_MPlayer_PlayPrevFile();
                            }
                        }
                        else
                        {
                            DMP_DBG(printf("    - MApp_MPlayer_PlayNextFile()\n"));
                            MApp_MPlayer_PlayNextFile();
                        }
                        return TRUE;
                    }
                }
            }
            else
            {//Error occured in default page - Preview Mode or BGM Mode(error occured in !MUSIC type)
                EN_DMP_MSG_TYPE errMSG = DMP_MSG_TYPE_UNSUPPORTED_FILE;
                DMP_DBG(printf("    - _MApp_DMP_ErrorHandling_NOT playing \n"));
                MApp_MPlayer_StopPreview();

                switch(eMediaType)
                {
                    case E_MPLAYER_TYPE_MUSIC:
                        if(MApp_MPlayer_IsCurrentLRCLyricAvailable() == E_MPLAYER_RET_OK)
                        {
                            MApp_MPlayer_DisableLRCLyric();
                            memset((U8*)_stDmpPlayVar.stMusicInfo.MPlayerLyricBuf, 0, DMP_STRING_BUF_SIZE);
                            MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_LYRIC_PAGE,SW_HIDE);
                        }
                        break;
                    case E_MPLAYER_TYPE_TEXT:
                        MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_TEXT_FULL_WINDOW, SW_HIDE);
                        break;
                    case E_MPLAYER_TYPE_MOVIE:
                        {
                            U32 u32ErrorMsg;
                            u32ErrorMsg = MApp_VDPlayer_GetInfo(E_VDPLAYER_INFO_ERROR_INFO);
                            DMP_DBG(printf("VDPlayerbin Err Msg=%d\n", u32ErrorMsg));
                            if (u32ErrorMsg == EN_VDP_ERRORCODE_NOT_SUPPORT_SCREANSIZE)
                            {
                                DMP_DBG(printf("Set errMsg to video resolution not show\n"));
                                errMSG = DMP_MSG_TYPE_UNSUPPORTED_VIDEO_RESOLUTION;
                            }
                            break;
                        }
                    default:
                        break;
                }
                _MApp_ACTdmp_ShowAlertWin(DMP_MSG_TYPE_UNSUPPORTED_FILE);
            }
        }
            break;

        case E_MPLAYER_NOTIFY_PHOTO_INFO_OK:
            DMP_DBG(printf("    - E_MPLAYER_NOTIFY_PHOTO_INFO_OK\n"));
            if (MApp_ZUI_API_IsWindowVisible(HWND_DMP_PLAYBACK_PHOTOINFO_INFO_GROUP))
            {
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_PHOTOINFO_INFO_GROUP);
            }
            break;
        case E_MPLAYER_NOTIFY_PLAY_NEXT_FILE:
            DMP_DBG(printf("    - E_MPLAYER_NOTIFY_PLAY_NEXT_FILE\n"));
            #if ENABLE_LAST_MEMORY
                if(MApp_MPlayer_QueryCurrentMediaType() == E_MPLAYER_TYPE_MOVIE)
                {
                    if(MApp_ZUI_API_IsWindowVisible(HWND_DMP_PLAYBACK_MOVIERESUME_PAGE))
                    {
                        //printf("<<<>>>111\n");
                        MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_MOVIERESUME_PAGE,SW_HIDE);
                        MApp_ZUI_API_KillTimer(HWND_DMP_PLAYBACK_MOVIERESUME_PAGE, DMP_TIMER_MOVIERESUME_WIN);
                        if(MApp_ZUI_API_IsWindowVisible(HWND_DMP_PLAYBACK_PAGE_INFOBAR))
                            MApp_ZUI_API_RestoreFocusCheckpoint();
                        else
                            MApp_ZUI_API_SetFocus(HWND_DMP_PLAYBACK_TRANSPARENT_BG);
                    }
                }
            #endif
            break;
        case E_MPLAYER_NOTIFY_PLAY_PREVIOUS_FILE:
            DMP_DBG(printf("    - E_MPLAYER_NOTIFY_PLAY_PREVIOUS_FILE\n"));
            #if ENABLE_LAST_MEMORY
                if(MApp_MPlayer_QueryCurrentMediaType() == E_MPLAYER_TYPE_MOVIE)
                {
                    if(MApp_ZUI_API_IsWindowVisible(HWND_DMP_PLAYBACK_MOVIERESUME_PAGE))
                    {
                        //printf("<<<>>>222\n");
                        MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_MOVIERESUME_PAGE,SW_HIDE);
                        MApp_ZUI_API_KillTimer(HWND_DMP_PLAYBACK_MOVIERESUME_PAGE, DMP_TIMER_MOVIERESUME_WIN);
                        if(MApp_ZUI_API_IsWindowVisible(HWND_DMP_PLAYBACK_PAGE_INFOBAR))
                            MApp_ZUI_API_RestoreFocusCheckpoint();
                        else
                            MApp_ZUI_API_SetFocus(HWND_DMP_PLAYBACK_TRANSPARENT_BG);
                    }
                }
            #endif
            break;
        case E_MPLAYER_NOTIFY_SETUP_DISPLAY:
            DMP_DBG(printf("    - E_MPLAYER_NOTIFY_SETUP_DISPLAY\n"));
            {
                // hence while movie playing, press channel+-, the vdplayer need a little time to change program
                // so need to wait the E_MPLAYER_NOTIFY_SETUP_DISPLAY notify then get the correct text
                if (MApp_ZUI_API_IsWindowVisible(HWND_DMP_PLAYBACK_MOVIEINFO_INFO_GROUP))
                {
                    MApp_ZUI_API_InvalidateWindow(HWND_DMP_PLAYBACK_MOVIEINFO_INFO_GROUP);
                }
            }
            break;

    #if ENABLE_DVD
        case E_MPLAYER_NOTIFY_DVD_RESUME_NORMAL_PLAY:
            DMP_DBG(printf("    - E_MPLAYER_NOTIFY_DVD_RESUME_NORMAL_PLAY\n"));
            if (MApp_MPlayer_QueryCurrentFileMediaSubType() == E_MPLAYER_SUBTYPE_DVD)
            {
                MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_NORMAL);
                _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_PLAY;
                DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PAUSE;
                DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Pause;
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_INFOBAR_GROUP);
                MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_SHOW);
                MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN, DMP_TIME_MS_PLAY_STATUS_WIN);
            }
            break;
    #endif
    #if ENABLE_EMBEDDED_PHOTO_DISPLAY
        case E_MPLAYER_NOTIFY_BEFORE_EMBEDDED_PHOTO_DISPLAY:
            DMP_DBG(printf("    - E_MPLAYER_NOTIFY_BEFORE_EMBEDDED_PHOTO_DISPLAY\n"));
            {
                if (*(enumMusicPreviewState*)pInfo == E_MUSIC_PREVIEW_RUNNING)
                {
                    MApi_GOP_GWIN_SwitchGOP(E_GOP_OSD);
                    MApp_ZUI_API_ShowWindow(HWND_DMP_FILE_PAGE_PREVIEW_GROUP, SW_SHOW);
                    _MApp_ZUI_ACT_DMPMarqueeTextEnableAnimation(HWND_DMP_FILE_PAGE_PREVIEW_FILENAME_STRING, TRUE);
                }
            }
            break;
        break;
        case E_MPLAYER_NOTIFY_END_OF_EMBEDDED_PHOTO_DISPLAY:
            DMP_DBG(printf("    - E_MPLAYER_NOTIFY_END_OF_EMBEDDED_PHOTO_DISPLAY\n"));
        break;
        case E_MPLAYER_NOTIFY_ERROR_OF_EMBEDDED_PHOTO_DISPLAY:
            DMP_DBG(printf("    - E_MPLAYER_NOTIFY_ERROR_OF_EMBEDDED_PHOTO_DISPLAY\n"));
            {
                MApp_MPlayer_StopEmbeddedPhoto();
                MApp_ZUI_API_ShowWindow(HWND_DMP_FILE_PAGE_PREVIEW_GROUP, SW_HIDE);
                _MApp_ZUI_ACT_DMPMarqueeTextEnableAnimation(HWND_DMP_FILE_PAGE_PREVIEW_FILENAME_STRING, FALSE);
            }
        break;
    #endif

        default:
            DMP_DBG(printf("    - Unknown notify (%d)\n", (U16)eNotify));
            break;
    }
    return FALSE;
}

extern BOOLEAN _MApp_ZUI_API_WindowProcOnTimer(void);
void MApp_DMP_NotifyUiState(EN_DMP_UI_STATE enDmpUiState)
{
  #if EN_DMP_SEARCH_ALL
    if(enDmpUiState == DMP_UI_STATE_FILE_SELECT)
        MApp_DMP_SetDmpFlag(DMP_FLAG_BROWSER_ALL);
    else
        MApp_DMP_ClearDmpFlag(DMP_FLAG_BROWSER_ALL);
  #endif

    switch(enDmpUiState)
    {
        case DMP_UI_STATE_MEDIA_SELECT:
          #if DMP_UI_BMPSUBTITLE_EXCLUSIVE
            // enable UI
            _MApp_ZUI_ACTdmp_RestoreGWINandFB();
          #endif //DMP_UI_BMPSUBTITLE_EXCLUSIVE

            enumMPlayerMediaType enMediaType = MApp_MPlayer_QueryCurrentMediaType();

            DMP_DBG(printf("DMP_UI_STATE_MEDIA_SELECT\n"););

            _MApp_ACTdmp_HideAlertWin();

            MApp_ZUI_API_KillTimer(HWND_DMP_ALERT_WINDOW, DMP_TIMER_INVALID_WIN);

            _MApp_ACTdmp_ShowMediaTypePage();

            switch(enMediaType)
            {
                case E_MPLAYER_TYPE_PHOTO:
                    MApp_ZUI_API_SetFocus(HWND_DMP_MEDIA_TYPE_PHOTO);
                    break;
                case E_MPLAYER_TYPE_MUSIC:
                    MApp_ZUI_API_SetFocus(HWND_DMP_MEDIA_TYPE_MUSIC);
                    break;
                case E_MPLAYER_TYPE_MOVIE:
                    MApp_ZUI_API_SetFocus(HWND_DMP_MEDIA_TYPE_MOVIE);
                    break;
                case E_MPLAYER_TYPE_TEXT:
                    MApp_ZUI_API_SetFocus(HWND_DMP_MEDIA_TYPE_TEXT);
                    break;
                default:
                    MApp_ZUI_API_SetFocus(HWND_DMP_MEDIA_TYPE_PHOTO);
                    break;
            }
            break;

        case DMP_UI_STATE_DRIVE_SELECT:
            {
            #if (DMP_PHOTO_THUMBNAIL || DMP_MOVIE_THUMBNAIL || DMP_MUSIC_THUMBNAIL)
                {
                    _MApp_DMP_ThumbCopyRegion_Destroy();
                    MApp_MPlayer_LeaveThumbnailMode();
                    MApp_DMP_ClearDmpFlag(DMP_FLAG_THUMBNAIL_MODE);
                    MApp_DMP_ClearDmpFlag(DMP_FLAG_THUMBNAIL_PLAYING);
                }
            #endif
                DMP_DBG(printf("DMP_UI_STATE_DRIVE_SELECT\n"););
                //_MApp_ACTdmp_ShowDrivePage();    //move down
                U8 i;
                for(i=0; i<NUM_OF_MAX_DRIVE; i++)
                {
                    if(MApp_MPlayer_QueryCurrentDriveIndex() == MApp_DMP_GetDriveFromMappingTable(i))
                    {
                        MApp_DMP_SetCurDrvIdxAndCalPageIdx(i);
                    }
                }
                _MApp_ACTdmp_ShowDrivePage();
                U8 u8Idx = (MApp_DMP_GetCurDrvIdx()+1) % DMP_DRIVE_NUM_PER_PAGE;
                MApp_ZUI_API_SetFocus(_hwndListDriveItem[u8Idx]);
            }
            break;

        case DMP_UI_STATE_FILE_SELECT:
            #if DMP_UI_BMPSUBTITLE_EXCLUSIVE
            // enable UI
            _MApp_ZUI_ACTdmp_RestoreGWINandFB();
            #endif //DMP_UI_BMPSUBTITLE_EXCLUSIVE
            MApp_ZUI_API_EnableFullScreenRelease(FALSE);
            {
                DMP_DBG(printf("DMP_UI_STATE_FILE_SELECT\n"););
                _MApp_ACTdmp_ShowFilePage();

              #if (DMP_PHOTO_THUMBNAIL || DMP_MOVIE_THUMBNAIL || DMP_MUSIC_THUMBNAIL)
                _ThumbNOIdx = 0xFFFF;
                _ThumbOKIdx = 0xFFFF;
                _ThumbLoadPageFlag = TRUE;
                _InsertQFlag = TRUE;
                _ThumbInsertNum = 0;
                _MApp_DMP_ThumbCopyRegion_Create();
              #endif

                MApp_ZUI_API_SetFocus(_hwndListFileItem[MApp_MPlayer_QueryCurrentFileIndex(E_MPLAYER_INDEX_CURRENT_PAGE)]);
                if( MApp_DMP_GetDmpFlag() & DMP_FLAG_MEDIA_FILE_PLAYING_ERROR)
                {
                    DMP_DBG(printf("DMP_UI_STATE_FILE_SELECT playing error mode\n"););
                    _MApp_ACTdmp_ShowAlertWin(_enDmpMsgType);
                    // playing error mode
                }
                else if(MApp_DMP_IsFileTypeByIdx(MApp_MPlayer_QueryCurrentFileIndex(E_MPLAYER_INDEX_CURRENT_DIRECTORY)))
                {
                    //File type
                    _MApp_ACTdmp_ShowPreviewWin();
                }
            }
            break;

        case DMP_UI_STATE_LOADING:
            {
                #if (DMP_PHOTO_THUMBNAIL || DMP_MOVIE_THUMBNAIL || DMP_MUSIC_THUMBNAIL)
                _MApp_DMP_ThumbCopyRegion_Destroy();
                MApp_MPlayer_LeaveThumbnailMode();
                MApp_DMP_ClearDmpFlag(DMP_FLAG_THUMBNAIL_MODE);
                MApp_DMP_ClearDmpFlag(DMP_FLAG_THUMBNAIL_PLAYING);
                #endif

                if( MApp_DMP_GetDmpFlag() & DMP_FLAG_MEDIA_FILE_PLAYING_ERROR)
                {
                    DMP_DBG(printf("DMP_UI_STATE_LOADING playing error mode\n"););
                    MApp_ZUI_API_ShowWindow(HWND_MAINFRAME, SW_HIDE);
                    MApp_ZUI_API_ShowWindow(HWND_DMP_ROOT_TRANSPARENT_BG, SW_SHOW);
                    _MApp_ACTdmp_ShowAlertWin(DMP_MSG_TYPE_UNSUPPORTED_FILE);
                    // playing error mode
                }
                else
                {
                    // normal mode
                    DMP_DBG(printf("DMP_UI_STATE_LOADING normal mode\n"););
                    MApp_ZUI_API_ShowWindow(HWND_MAINFRAME, SW_HIDE);
                    MApp_ZUI_API_ShowWindow(HWND_DMP_ROOT_TRANSPARENT_BG, SW_SHOW);
                    _MApp_ACTdmp_ShowAlertWin(DMP_MSG_TYPE_LOADING);
                    if(MApp_DMP_GetDmpFlag() & DMP_FLAG_BGM_MODE)
                    {
                        MApp_MPlayer_StopMusic();
                        MApp_DMP_ClearDmpFlag(DMP_FLAG_BGM_MODE);
                    }
                    MApp_MPlayer_Play();
                }
            }
            break;

        case DMP_UI_STATE_PLAYING_STAGE:
            //MApp_ZUI_API_EnableFullScreenRelease(FALSE);
            {
                DMP_DBG(printf("hahah DMP_UI_STATE_PLAYING_STAGE\n"););
                if(MApp_ZUI_API_IsWindowVisible(HWND_DMP_ALERT_WINDOW))
                {
                    MApp_ZUI_API_ShowWindow(HWND_DMP_ALERT_WINDOW,SW_HIDE);
                }

                MApp_DMP_SetDmpFlag(DMP_FLAG_MEDIA_FILE_PLAYING);
                _enDmpPlayStrType =_enDmpPlayIconType = PLAY_MODE_ICON_PLAY;
                switch(MApp_MPlayer_QueryCurrentMediaType())
                {
                    case E_MPLAYER_TYPE_MOVIE:
                    {
                    #if DMP_UI_BMPSUBTITLE_EXCLUSIVE
                        bUIexist = TRUE;
                    #endif
                        // case NEW_notify
                        // patch the focus, because the "last memory" feature
                    #if ENABLE_LAST_MEMORY
                        if(MApp_ZUI_API_IsWindowVisible(HWND_DMP_PLAYBACK_MOVIERESUME_PAGE))
                        {
                            MApp_ZUI_API_StoreFocusCheckpoint();

                            MApp_ZUI_API_ShowWindow(HWND_MAINFRAME, SW_HIDE);
                            MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_TRANSPARENT_BG, SW_SHOW);
                            MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_SHOW);
                            MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_MOVIERESUME_PAGE, SW_SHOW);
							MApp_ZUI_API_SetFocus(HWND_DMP_PLAYBACK_MOVIERESUME_YES);
                            //MApp_ZUI_API_RestoreFocusCheckpoint();
                            _MApp_ZUI_API_WindowProcOnTimer();
                            MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_MOVIERESUME_PAGE, DMP_TIMER_MOVIERESUME_WIN, DMP_TIME_MS_MOVIERESUME);
                            MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN, DMP_TIME_MS_PLAY_STATUS_WIN);

                        }
                        else
                        {

				    MApp_ZUI_API_RestoreFocusCheckpoint();
	                        MApp_ZUI_API_ShowWindow(HWND_MAINFRAME, SW_HIDE);
	                        MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_TRANSPARENT_BG, SW_SHOW);
	                        MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_SHOW);
	                        _MApp_ZUI_API_WindowProcOnTimer();
	                        MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN, DMP_TIME_MS_PLAY_STATUS_WIN);
	                        MApp_ZUI_API_SetFocus(HWND_DMP_PLAYBACK_TRANSPARENT_BG);
                        }
                    #else

                        MApp_ZUI_API_ShowWindow(HWND_MAINFRAME, SW_HIDE);
                        MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_TRANSPARENT_BG, SW_SHOW);
                        MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_SHOW);
                        _MApp_ZUI_API_WindowProcOnTimer();
                        MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN, DMP_TIME_MS_PLAY_STATUS_WIN);
                        MApp_ZUI_API_SetFocus(HWND_DMP_PLAYBACK_TRANSPARENT_BG);

                    #endif //ENABLE_LAST_MEMORY
                        DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PAUSE;
                        DMP_MovieInfoBarTable[MOVIEINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Pause;
                        _MApp_ACTdmp_MovieResetRepeatAB();
                        _stDmpPlayVar.stMovieInfo.bSubtitleOff = FALSE;
#if (ENABLE_SUBTITLE_DMP)
//Thomas mask 20120412 for Mantis 0236863 Keep user setting subtitle
//                        MApp_MPlayer_MovieChangeSubtitleTrack(0);
#endif
                        _MApp_ZUI_ACTdmp_OperateSubtitle();
                        DMP_DBG(printf("Turn ON SUBTITLE DMP_UI_STATE_PLAYING_STAGE\n"););
                        MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_SUBTITLE_PAGE);

                        //_MApp_ACTdmp_Playback_ShowInfoWin(E_MPLAYER_TYPE_MOVIE);

                        if(g_bUnsupportAudio)  //20100809EL
                        {
                        #if ENABLE_LAST_MEMORY
                        #ifndef UI2_OBAMA
                            if(!MApp_ZUI_API_IsWindowVisible(HWND_DMP_PLAYBACK_MOVIERESUME_PAGE))
                            {
                        #endif
                        #endif
                                DMP_DBG(printf("Unsupport audio\n"););
                                _MApp_ACTdmp_ShowAlertWin(DMP_MSG_TYPE_UNSUPPORTED_AUDIO_FILE);
                                MApp_ZUI_API_SetTimer(HWND_DMP_ALERT_WINDOW, DMP_TIMER_INVALID_WIN, DMP_TIME_MS_INVALID_WIN);
                                g_bUnsupportAudio = FALSE;
#if ENABLE_LAST_MEMORY
#ifndef UI2_OBAMA
                            }
#endif
#endif
                        }
                        MApp_ZUI_CTL_PercentProgressBar_SetPercentage(0);
                        MApp_ZUI_API_InvalidateWindow(HWND_DMP_PLAYBACK_PAGE_TIME_GROUP);
                    #if DMP_UI_BMPSUBTITLE_EXCLUSIVE
                        bUIexist = FALSE;
                    #endif
                    }
                    break;
                    case E_MPLAYER_TYPE_PHOTO:
                    {
                        if(MApp_MPlayer_QueryPhotoPlayMode() == E_MPLAYER_PHOTO_PAUSE)
                        {
                            MApp_MPlayer_PhotoChangePlayMode(E_MPLAYER_PHOTO_NORMAL);
                        }
                        else if(MApp_MPlayer_QueryPhotoPlayMode() == E_MPLAYER_PHOTO_NORMAL)
                        {
                            //do nothing;
                        }

                        DMP_PhotoInfoBarTable[PHOTOINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PAUSE;
                        DMP_PhotoInfoBarTable[PHOTOINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Pause;
                        MApp_ZUI_API_ShowWindow(HWND_MAINFRAME, SW_HIDE);
                        MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_TRANSPARENT_BG, SW_SHOW);
                        MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_SHOW);
                        MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN, DMP_TIME_MS_PLAY_STATUS_WIN);
                        MApp_ZUI_API_SetFocus(HWND_DMP_PLAYBACK_TRANSPARENT_BG);
                    }
                    break;

                    // because there is no other screen while playing music
                    // hence show the info page for music start
                    case E_MPLAYER_TYPE_MUSIC:
                    {
                        if(MApp_MPlayer_QueryMusicPlayMode() == E_MPLAYER_MUSIC_NORMAL)
                        {
                            // do nothing
                        }
                        else // some FF FB ...
                        {
                            MApp_MPlayer_MusicChangePlayMode(E_MPLAYER_MUSIC_NORMAL);
                        }

                        DMP_MusicInfoBarTable[MUSICINFO_PLAY_PAUSE][INFOBAR_BMP_IDX] = E_BMP_DMP_BUTTON_ICON_PAUSE;
                        DMP_MusicInfoBarTable[MUSICINFO_PLAY_PAUSE][INFOBAR_STR_IDX] = en_str_Pause;
                        MApp_ZUI_API_ShowWindow(HWND_MAINFRAME, SW_HIDE);
                        MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_TRANSPARENT_BG, SW_SHOW);
                        MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_SHOW);
                        MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN, DMP_TIME_MS_PLAY_STATUS_WIN);
                        MApp_ZUI_API_SetFocus(HWND_DMP_PLAYBACK_TRANSPARENT_BG);
                        _MApp_ACTdmp_Playback_ShowInfoWin(E_MPLAYER_TYPE_MUSIC);
                        MApp_ZUI_CTL_PercentProgressBar_SetPercentage(0);
                        MApp_ZUI_API_InvalidateWindow(HWND_DMP_PLAYBACK_PAGE_TIME_GROUP);
                        if(MApp_MPlayer_IsCurrentLRCLyricAvailable() == E_MPLAYER_RET_OK)
                        {
                            MApp_MPlayer_EnableLRCLyric();
                            MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_LYRIC_PAGE, SW_SHOW);
                        }
                        else
                        {
                            DMP_DBG(printf("MApp_MPlayer_IsCurrentLRCLyricAvailable lyric fail\n"););
                        }
                        // EQ
                        MApp_ZUI_API_SetTimer(HWND_DMP_PLAYBACK_MUSIC_EQ_GROUP, DMP_TIMER_EQ_PLAY, DMP_TIME_MS_EQ_PLAY);
                    }
                    break;
                    case E_MPLAYER_TYPE_TEXT:
                    {
                        if(MApp_Text_GetUserExitMode())
                        {
                             _MApp_ACTdmp_TextToFilePage();
                             MApp_Text_SetUserExitMode(FALSE);
                             u8KeyCode = KEY_NULL;
                         }
                        else
                        {
                            MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_TEXT_FULL_WINDOW,SW_SHOW);
                            MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_TEXT_FULL_WINDOW_PAGE,SW_SHOW);
                            MApp_ZUI_API_SetFocus(HWND_DMP_PLAYBACK_TEXT_FULL_WINDOW);
                            MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_TEXT_FULL_WINDOW);
                       }
                     }
                    break;
                    default:
                        break;
                }
            }
            break;
    }
}

////////////////////////////////////////////
//  if( isPhotoFile)
//  {
//      if( decode finish)
//      {
//          if( have showed)
//          {
//              do nothing
//          }
//          else
//          {
//              show on screen
//          }
//      }
//      else
//      {
//          starting decoding
//          show default directory bitmap
//      }
//  }
//  else
//  {
//    show directory bitmap or "return arrow" bitmap
//  }
//
//  // problem : if UI doesnt move; middleware will send notify to UI?
//
////////////////////////////////////////////
S32 MApp_ZUI_ACT_DmpFileSelectThumbnailWinProc(HWND hwnd, PMSG msg)
{
#if (DMP_PHOTO_THUMBNAIL || DMP_MOVIE_THUMBNAIL || DMP_MUSIC_THUMBNAIL)
    if(( DMP_PHOTO_THUMBNAIL&&(MApp_MPlayer_QueryCurrentMediaType() == E_MPLAYER_TYPE_PHOTO))
        || (DMP_MOVIE_THUMBNAIL&&(MApp_MPlayer_QueryCurrentMediaType() == E_MPLAYER_TYPE_MOVIE))
     || (DMP_MUSIC_THUMBNAIL&&(MApp_MPlayer_QueryCurrentMediaType() == E_MPLAYER_TYPE_MUSIC))
    )
    {
        switch(msg->message)
        {
            case MSG_PAINT:
            {
                if(_CopyFbId == 0xFF)
                {
                    return DYNAMICBITMAP_WINPROC(hwnd, msg);
                }
                PAINT_PARAM * param = (PAINT_PARAM *)msg->wParam;
                U32 i;
                for(i = 0; i < NUM_OF_PHOTO_FILES_PER_PAGE; i++)
                {
                    if (_hwndListFileIcon[i] == hwnd)
                        break;
                }
                U16 u16FileIdx = i + MApp_MPlayer_QueryCurrentPageIndex()*NUM_OF_PHOTO_FILES_PER_PAGE;

                if(!(MApp_DMP_GetDmpFlag()& DMP_FLAG_THUMBNAIL_MODE))
                {
                    GOP_GwinFBAttr fbAttr;
                    MApi_GOP_GWIN_GetFBInfo(param->dc.u8FbID, &fbAttr);

                    if(MApp_MPlayer_EnterThumbnailMode(&fbAttr) == E_MPLAYER_RET_OK)
                    {
                        DMP_DBG(printf("MApp_MPlayer_EnterThumbnailMode success\n"););
                        //MApp_MPlayer_BeginThumbnail();
                        _InsertQFlag = TRUE;
                    }
                    /*
                    GRAPHIC_DC *dc = MApp_ZUI_API_GetScreenDC();
                    GOP_GwinFBAttr FbAttr;
                    MApi_GOP_GWIN_GetFBInfo(dc->u8FbID, &FbAttr);
                    MApp_MPlayer_SetZUIFbAttr(FbAttr);
                    */
                    MApp_DMP_SetDmpFlag(DMP_FLAG_THUMBNAIL_MODE);
                }
                if((_ThumbNOIdx != 0xFFFF)&&(_ThumbNOIdx==u16FileIdx))
                {
                    DMP_DBG(printf("decode fail %d\n",_ThumbNOIdx););
                    MApp_ZUI_CTL_DynamicBitmapWinProc(hwnd, msg);

                    GRAPHIC_DC *dc = MApp_ZUI_API_GetBufferDC();
                    //printf("[Clone] %d item to tmp buffer.\n", u8Idx);
                    _MApp_DMP_ThumbCopyRegion_CloneRect(dc->u8FbID, param->rect);
                    _MApp_DMP_ThumbCopyRegion_PasteTo(param->rect);
                    _ThumbNOIdx = 0xFFFF;
                    return 0;
                }
                if(! MApp_DMP_IsFileTypeByIdx(u16FileIdx) ) // not a photo
                {
                    break;
                }
                else // is photo or movie file
                {
                    if(_InsertQFlag)
                    {
                        if(_ThumbLoadPageFlag)
                        {
                            if( !(MApp_DMP_GetDmpFlag()&DMP_FLAG_THUMBNAIL_PLAYING))
                            {
                                MApp_DMP_SetDmpFlag(DMP_FLAG_THUMBNAIL_PLAYING);
                            }
                            DMP_DBG(printf("A. insert Queue (%d)\n", u16FileIdx););
                            MApp_MPlayer_DrawThumbnailByIdx(u16FileIdx%NUM_OF_PHOTO_FILES_PER_PAGE);
                            _ThumbInsertNum++;

                            if(_ThumbInsertNum == NUM_OF_PHOTO_FILES_PER_PAGE)
                            {
                                _ThumbLoadPageFlag = FALSE;
                            }
                            if((u16FileIdx%NUM_OF_PHOTO_FILES_PER_PAGE) == NUM_OF_PHOTO_FILES_PER_PAGE-1)
                            {
                                _ThumbLoadPageFlag = FALSE;
                            }
                            if(MApp_MPlayer_QueryCurrentPageIndex()+1 ==MApp_MPlayer_QueryTotalPages()) // last page
                            {
                                if(u16FileIdx == MApp_MPlayer_QueryTotalFileNum()-1 )
                                {
                                    _ThumbLoadPageFlag = FALSE;
                                }
                            }
                        }
                        else
                        {
                            DMP_DBG(printf("B. Paste to (%d)\n",u16FileIdx););
                            _MApp_DMP_ThumbCopyRegion_PasteTo(param->rect);
                        }
                    }
                    else if( !_InsertQFlag &&(_ThumbOKIdx != 0xFFFF)&&(_ThumbOKIdx==u16FileIdx))// decode finish
                    {
                        GRAPHIC_DC *dc = MApp_ZUI_API_GetScreenDC();
                        //printf("[Clone] %d item to tmp buffer.\n", u8Idx);
                        _MApp_DMP_ThumbCopyRegion_CloneRect(dc->u8FbID, param->rect);
                        _MApp_DMP_ThumbCopyRegion_PasteTo(param->rect);
                        //_InsertQFlag = TRUE;
                        _ThumbLoadPageFlag = FALSE;
                        DMP_DBG(printf(" decode finish %u\n",u16FileIdx););
                        _ThumbOKIdx = 0xFFFF;
                        //MApp_ZUI_API_InvalidateWindow(HWND_DMP_FILE_SELECT_PAGE);
                    }
                    else
                    {
                        //GRAPHIC_DC *dc = MApp_ZUI_API_GetScreenDC();
                        //printf("[Clone] %d item to tmp buffer.\n", u8Idx);
                        //_MApp_DMP_ThumbCopyRegion_CloneRect(dc->u8FbID, param->rect);
                        _MApp_DMP_ThumbCopyRegion_PasteTo(param->rect);
                        //_InsertQFlag = TRUE;
                        _ThumbLoadPageFlag = FALSE;
                        DMP_DBG(printf(" decode haha %u\n",u16FileIdx););

                    }
                    return 0;
                }
            }

            default:
                break;
        }
    }
#endif
    return DYNAMICBITMAP_WINPROC(hwnd, msg);
}

S32 MApp_ZUI_ACT_DmpProgressWinProc(HWND hwnd, PMSG msg)
{
    switch(msg->message)
    {
        case MSG_TIMER:
            if(MApp_DMP_GetDmpUiState() == DMP_UI_STATE_FILE_SELECT)
            {
                if(MApp_MPlayer_QueryPasteFileStatus() >= 100)
                {
                    _MApp_ACTdmp_HideProgressWin();
#ifdef ENABLE_SMC_UI_NEW     /* smc.qxr 20121016 */
                    _MApp_ACTdmp_ShowScrollBar();
#endif
                    MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_FILE_SELECT_PAGE);
                }
                else
                {
                    MApp_ZUI_API_ResetTimer(HWND_DMP_PROGRESS_WINDOW, DMP_TIMER_PROGRESS_WIN);
                    MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PROGRESS_WINDOW);
                    MApp_ZUI_CTL_PercentProgressBar_SetPercentage((U8)MApp_MPlayer_QueryPasteFileStatus());
                }
            }
        #if 0 //Implement code when playback is finished
          #if (ENABLE_POWERON_MUSIC)
            else if(MApp_DMP_GetDmpUiState() == DMP_UI_STATE_PLAYING_STAGE)
            {
                U32 u32Percent = 0;
                if(MApp_Music_GetRecordingTime() >= USER_MP3_CAPTURE_TIMEOUT)
                {
                    MApp_ZUI_API_KillTimer(HWND_MEDIA_PLAYER_PROGRESS_DIALOG, MPLAYER_PROGRESS_BAR_TIMER);
                    MApp_ZUI_API_ShowWindow(HWND_MEDIA_PLAYER_PROGRESS_DIALOG, SW_HIDE);
                    MApp_ZUI_API_RestoreFocusCheckpoint();
                }
                else
                {
                    u32Percent = MApp_Music_GetRecordingTime()/(USER_MP3_CAPTURE_TIMEOUT/100);
                    MApp_ZUI_API_ResetTimer(HWND_MEDIA_PLAYER_PROGRESS_DIALOG, MPLAYER_PROGRESS_BAR_TIMER);
                    MApp_ZUI_API_InvalidateAllSuccessors(HWND_MEDIA_PLAYER_PROGRESS_DIALOG);
                    MApp_ZUI_CTL_PercentProgressBar_SetPercentage((U8)u32Percent);
                }
            }
          #endif
        #endif
            break;

        default:
            break;
    }
    return DEFAULTWINPROC(hwnd, msg);
}

S32 MApp_ZUI_CTL_DMP_BARTIMER_WinProc(HWND hwnd, PMSG msg)
{
    switch(msg->message)
    {
        case MSG_TIMER:
            DMP_DBG(printf("\nRun MApp_ZUI_CTL_DMP_BARTIMER_WinProc(,)\n"));
            MApp_ZUI_API_KillTimer(HWND_DMP_BAR, 0);
            MApp_ZUI_API_ShowWindow(HWND_DMP_BAR, SW_HIDE);
            MApp_ZUI_API_SetFocus(hwnd_before);
            break;
        default:
            break;
    }
    return DEFAULTWINPROC(hwnd, msg);
}

S32 MApp_ZUI_ACT_DmpPlayStatusWinProc(HWND hwnd, PMSG msg)
{
    switch(msg->message)
    {
        case MSG_TIMER:
            DMP_DBG(printf("\nRun MApp_ZUI_ACT_DmpPlayStatusWinProc(,)\n"));
#if ENABLE_DRM
            if (msg->wParam == DMP_TIMER_PLAY_STATUS_WIN)
            {
                _enDmpPlayIconType = _enDmpPlayStrType = PLAY_MODE_ICON_MAX;
                MApp_ZUI_API_KillTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN);
                MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_HIDE);
            }
            else if (msg->wParam == DMP_TIMER_PREV_BUTTON_CLICK_WIN)
            {
                // 1. Cancel Repeat AB Mode
                if(MApp_DMP_GetDmpFlag()& DMP_FLAG_MOVIE_REPEATAB_MODE)
                {
                    _MApp_ACTdmp_MovieCancelRepeatAB();
                    //    MApp_ZUI_API_ShowWindow(HWND_DMP_MOVIE_INFO_ICON_ADVENCE_GROUP, SW_SHOW);
                }
                // 2. Disable trick play --> Normal play
                if(MApp_MPlayer_QueryMoviePlayMode() != E_MPLAYER_MOVIE_NORMAL)
                {
                    MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP,SW_HIDE);
                    MApp_MPlayer_MovieChangePlayMode(E_MPLAYER_MOVIE_NORMAL);
                }
                MApp_MPlayer_SetPlayPosition(0, FALSE);
                MApp_ZUI_API_KillTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PREV_BUTTON_CLICK_WIN);
            }
#else
            _enDmpPlayIconType = _enDmpPlayStrType = PLAY_MODE_ICON_MAX;
            MApp_ZUI_API_KillTimer(HWND_DMP_PLAYBACK_STATUS_GROUP, DMP_TIMER_PLAY_STATUS_WIN);
            MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_STATUS_GROUP, SW_HIDE);
#endif
            break;
        default:
            break;
    }
    return DEFAULTWINPROC(hwnd, msg);
}
S32 MApp_ZUI_ACT_DmpAlertWinProc(HWND hwnd, PMSG msg)
{
    switch(msg->message)
    {
        case MSG_TIMER:
            DMP_DBG(printf("\nRun MApp_ZUI_ACT_DmpInvalidWinProc(,)\n"));
		#if CUS_SMC_ENABLE_HOTEL_MODE
		  if(MApp_ZUI_API_GetFocus()==HWND_DMP_HOTEL_PASSWD_PANEL_OPTION || MApp_ZUI_API_GetFocus()==HWND_DMP_HOTEL_PASSWD_WRONG)
		  	{
		    MApp_ZUI_API_KillTimer(HWND_DMP_HOTEL_PASSWD_PANEL, 1);
			MApp_ZUI_API_ShowWindow(HWND_DMP_HOTEL_PASSWD_PANEL,SW_HIDE);
			MApp_ZUI_API_RestoreFocusCheckpoint();
            break;
		    }
		  else if(MApp_ZUI_API_IsWindowVisible(HWND_DMP_HOTEL_MSG_NOTE))
			{
			MApp_ZUI_API_KillTimer(HWND_DMP_HOTEL_MSG_NOTE, 1);
			MApp_ZUI_API_ShowWindow(HWND_DMP_HOTEL_MSG_NOTE,SW_HIDE);
  		   break;
  		   }
		#endif
            MApp_ZUI_API_KillTimer(HWND_DMP_ALERT_WINDOW, DMP_TIMER_INVALID_WIN);
            MApp_ZUI_ACT_ExecuteDmpAction(EN_EXE_DMP_ALERT_EXIT);
            break;

        default:
            break;
    }
    return DEFAULTWINPROC(hwnd, msg);
}

static void _MApp_ACTdmp_EqPlay(void)
{
    static U8 eq_bar[10] = {0};
    U8 ran_bar_num, i, j;

    for(i = 0; i < 10; i++)
    {
        ran_bar_num = rand() % 10;
        j = eq_bar[i];
        U8 k = i * 10;
        if(ran_bar_num > eq_bar[i])
        {
            for(j = 0; j < ran_bar_num; j++)
                MApp_ZUI_API_ShowWindow((HWND_DMP_PLAYBACK_MUSIC_EQ_BAR_00 + k + j), SW_SHOW);
        }
        else if(ran_bar_num < eq_bar[i])
        {
            for(; j > ran_bar_num; j--)
                MApp_ZUI_API_ShowWindow((HWND_DMP_PLAYBACK_MUSIC_EQ_BAR_00 + k + j), SW_HIDE);
        }
        eq_bar[i] = ran_bar_num;
    }
    MApp_ZUI_API_InvalidateWindow(HWND_DMP_PLAYBACK_MUSIC_EQ_GROUP);
}

S32 MApp_ZUI_ACT_DmpEqPlayWinProc(HWND hwnd, PMSG msg)
{
    switch(msg->message)
    {
        case MSG_TIMER:
            _MApp_ACTdmp_EqPlay();
            break;
        default:
            break;
    }
    return DEFAULTWINPROC(hwnd, msg);
}

S32 MApp_ZUI_ACT_DmpPreviewWinProc(HWND hwnd, PMSG msg)
{
    switch(msg->message)
    {
        case MSG_TIMER:
            MApp_ZUI_API_InvalidateAllSuccessors(hwnd);
            MApp_ZUI_API_SetTimer(hwnd, DMP_TIMER_PREVIEW_WIN, DMP_TIME_MS_PREVIEW_WIN);
            break;
        default:
            break;
    }
    return DEFAULTWINPROC(hwnd, msg);
}

S32 MApp_ZUI_ACT_DMPMovieResumeWinProc(HWND hwnd, PMSG msg)
{
    switch(msg->message)
    {
        case MSG_TIMER:
            MApp_ZUI_ACT_ExecuteDmpAction(EN_EXE_DMP_MOVIERESUME_NO);
            MApp_ZUI_API_KillTimer(hwnd, DMP_TIMER_MOVIERESUME_WIN);
            break;
        default:
            break;
    }
    return DEFAULTWINPROC(hwnd, msg);
}

U8 MApp_ZUI_ACT_GetCurrentUARTMode(void)
{
    U8 _u8CurrentUART = (U8)mdrv_uart_get_connection(E_UART_PORT0);
    return _u8CurrentUART;
}

#if (DMP_PHOTO_THUMBNAIL || DMP_MOVIE_THUMBNAIL || DMP_MUSIC_THUMBNAIL)
void MApp_ZUI_ACT_ExitThumbnailMode(void)
{
    _MApp_DMP_ThumbCopyRegion_Destroy();
    MApp_MPlayer_LeaveThumbnailMode();
    MApp_DMP_ClearDmpFlag(DMP_FLAG_THUMBNAIL_MODE);
    MApp_DMP_ClearDmpFlag(DMP_FLAG_THUMBNAIL_PLAYING);
}
#endif

BOOLEAN MApp_UiMediaPlayer_IsSubtitleEnabled(void)
{
    return !(_stDmpPlayVar.stMovieInfo.bSubtitleOff);
}

void MApp_ZUI_ACT_FunctionHotkeyUIMapping(VIRTUAL_KEY_CODE VK_KEY)
{
    enumMPlayerMediaType enMediatype = MApp_MPlayer_QueryCurrentMediaType();
    printf("#####################\n");
    // Photo mode not support these two hotkey
    if(enMediatype == E_MPLAYER_TYPE_PHOTO)
    {
        if(VK_KEY == VK_FF || VK_KEY == VK_REWIND )
            return;
    }
    // Text mode not support these two hotkey
    else if(enMediatype == E_MPLAYER_TYPE_TEXT)
    {
        if(VK_KEY == VK_PAUSE || VK_KEY == VK_PLAY )
            return;
    }

    if(MApp_ZUI_API_IsWindowVisible(HWND_DMP_PLAYBACK_PLAYLIST_GROUP))
        MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_PLAYLIST_GROUP,SW_HIDE);

    if(enMediatype == E_MPLAYER_TYPE_PHOTO)
    {
        if(MApp_ZUI_API_IsWindowVisible(HWND_DMP_PLAYBACK_PHOTOINFO_INFO_GROUP))
            MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_PHOTOINFO_INFO_GROUP,SW_HIDE);
    }
    else if(enMediatype == E_MPLAYER_TYPE_MUSIC)
    {
        if(MApp_ZUI_API_IsWindowVisible(HWND_DMP_PLAYBACK_MUSICINFO_INFO_GROUP))
            MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_MUSICINFO_INFO_GROUP,SW_HIDE);
        else if(MApp_ZUI_API_IsWindowVisible(HWND_DMP_PLAYBACK_MOVIEINFO_GOTOTIME_GROUP))
            MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_MOVIEINFO_GOTOTIME_GROUP,SW_HIDE);
    }
    else if(enMediatype == E_MPLAYER_TYPE_MOVIE)
    {
        if(MApp_ZUI_API_IsWindowVisible(HWND_DMP_PLAYBACK_MOVIEINFO_INFO_GROUP))
            MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_MOVIEINFO_INFO_GROUP,SW_HIDE);
        else if(MApp_ZUI_API_IsWindowVisible(HWND_DMP_PLAYBACK_MOVIEINFO_GOTOTIME_GROUP))
            MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_MOVIEINFO_GOTOTIME_GROUP,SW_HIDE);
    }
    else if(enMediatype == E_MPLAYER_TYPE_TEXT)
    {
            if(MApp_ZUI_API_IsWindowVisible(HWND_DMP_PLAYBACK_TEXTINFO_INFO_GROUP))
            MApp_ZUI_API_ShowWindow(HWND_DMP_PLAYBACK_TEXTINFO_INFO_GROUP,SW_HIDE);
    }

    _u8InfoBarIdx = 0;
    MApp_ZUI_API_EnableWindow(HWND_DMP_PLAYBACK_INFOBAR_GROUP, TRUE);

    switch(VK_KEY)
    {
        case VK_PAUSE:
            MApp_ZUI_API_SetFocus(HWND_DMP_PLAYBACK_INFOBAR_ITEM1);
            break;
        case VK_PLAY:
            MApp_ZUI_API_SetFocus(HWND_DMP_PLAYBACK_INFOBAR_ITEM1);
            break;
        case VK_NEXT:
            if(enMediatype == E_MPLAYER_TYPE_PHOTO)
                MApp_ZUI_API_SetFocus(HWND_DMP_PLAYBACK_INFOBAR_ITEM3);
            else if(enMediatype == E_MPLAYER_TYPE_TEXT)
                MApp_ZUI_API_SetFocus(HWND_DMP_PLAYBACK_INFOBAR_ITEM4);
            else
                MApp_ZUI_API_SetFocus(HWND_DMP_PLAYBACK_INFOBAR_ITEM5);
            break;
        case VK_PREVIOUS:
            if(enMediatype == E_MPLAYER_TYPE_PHOTO)
                MApp_ZUI_API_SetFocus(HWND_DMP_PLAYBACK_INFOBAR_ITEM2);
            else if(enMediatype == E_MPLAYER_TYPE_TEXT)
                MApp_ZUI_API_SetFocus(HWND_DMP_PLAYBACK_INFOBAR_ITEM3);
            else
                MApp_ZUI_API_SetFocus(HWND_DMP_PLAYBACK_INFOBAR_ITEM4);
            break;
        case VK_FF:
            if(enMediatype == E_MPLAYER_TYPE_TEXT)
                MApp_ZUI_API_SetFocus(HWND_DMP_PLAYBACK_INFOBAR_ITEM2);
            else
                MApp_ZUI_API_SetFocus(HWND_DMP_PLAYBACK_INFOBAR_ITEM3);
            break;
        case VK_REWIND:
            if(enMediatype == E_MPLAYER_TYPE_TEXT)
                MApp_ZUI_API_SetFocus(HWND_DMP_PLAYBACK_INFOBAR_ITEM1);
            else
                MApp_ZUI_API_SetFocus(HWND_DMP_PLAYBACK_INFOBAR_ITEM2);
            break;
        default:
            break;
    }

    MApp_ZUI_API_InvalidateAllSuccessors(HWND_DMP_PLAYBACK_PAGE_INFOBAR);
}


void MApp_ZUI_ACT_DmpShowCountDownWin(void)
{
    printf("---Show CuntWin DMP!---\n");
    MApp_ZUI_API_ShowWindow(HWND_DMP_COUNTDOWN_PANEL, SW_SHOW);
}

void MApp_ZUI_ACT_DmpHideCountDownWin(void)
{
    MApp_ZUI_API_ShowWindow(HWND_DMP_COUNTDOWN_PANEL, SW_HIDE);
}

BOOLEAN MApp_DMP_IsMovieApp(void)
{
    if(MApp_MPlayer_QueryCurrentMediaType()== E_MPLAYER_TYPE_MOVIE)
        return TRUE;
    else
        return FALSE;
}

BOOLEAN MApp_DMP_IsMediaType(void)
{
switch(MApp_ZUI_API_GetFocus())
    {
    case HWND_DMP_MEDIA_TYPE_PHOTO:
    case HWND_DMP_MEDIA_TYPE_MUSIC:
    case HWND_DMP_MEDIA_TYPE_MOVIE:
    case HWND_DMP_MEDIA_TYPE_TEXT:
        return TRUE;
    default:
        return FALSE;
    }
}

void MApp_DMP_MuteState(BOOLEAN bSwitch)
{
    if(bSwitch)
    {
        if(msAPI_AUD_IsAudioMutedByUser())
        {
          if(!MApp_ZUI_API_IsWindowVisible(HWND_DMP_MUTE_PANEL))
            MApp_ZUI_API_ShowWindow(HWND_DMP_MUTE_PANEL, SW_SHOW);
        }
        else
        {
          if(MApp_ZUI_API_IsWindowVisible(HWND_DMP_MUTE_PANEL))
            MApp_ZUI_API_ShowWindow(HWND_DMP_MUTE_PANEL, SW_HIDE);
        }
    }
    else
    {
        if(MApp_ZUI_API_IsWindowVisible(HWND_DMP_MUTE_PANEL))
          MApp_ZUI_API_ShowWindow(HWND_DMP_MUTE_PANEL, SW_HIDE);
    }
}


//smc.chy 2010/03/29
U8 MApp_ZUI_ACT_GetCurrentMediaPlayingFlag(void)
{
    if(MApp_MPlayer_IsMediaFileInPlaying() && (MApp_DMP_GetDmpFlag()& DMP_FLAG_MEDIA_FILE_PLAYING))
    {
        switch(MApp_MPlayer_QueryCurrentMediaType())
        {
            case E_MPLAYER_TYPE_MUSIC:
                {
                    if (MApp_MPlayer_QueryMusicPlayMode()  ==  E_MPLAYER_MUSIC_NORMAL)
                    {
                        return TRUE;
                    }
                }
                break;
            case E_MPLAYER_TYPE_MOVIE:
                {
                    if (MApp_MPlayer_QueryMoviePlayMode() == E_MPLAYER_MOVIE_NORMAL)
                    {
                        return TRUE;
                    }
                }
                break;
            case E_MPLAYER_TYPE_PHOTO:
                {
                    if(MApp_MPlayer_QueryPhotoPlayMode() == E_MPLAYER_PHOTO_NORMAL)
                    {
                        return TRUE;
                    }
                }
                break;
            case E_MPLAYER_TYPE_TEXT:
                {
                    return FALSE;
                }
                break;
            default:
                return FALSE;
                break;
        }
    }
    return FALSE;
}

E_UI_INPUT_SOURCE _MApp_ZUI_ACT_DmpGetSourceType(void)
{
#ifdef ENABLE_SRC_MENU_AUTOCLOSE_AND_SWITCH_SOURCE
    return _enCurrentSelectUIsource;
#else
    return UI_INPUT_SOURCE_ATV;
#endif
}

#undef MAPP_ZUI_ACTDMP_C
