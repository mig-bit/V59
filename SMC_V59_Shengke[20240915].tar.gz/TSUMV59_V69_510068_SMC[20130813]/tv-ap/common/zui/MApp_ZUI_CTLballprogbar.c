////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#define MAPP_ZUI_CTL_BALLPROGBAR_C
#define _ZUI_INTERNAL_INSIDE_ //NOTE: for ZUI internal


//-------------------------------------------------------------------------------------------------
// Include Files
//-------------------------------------------------------------------------------------------------
#include "stdlib.h"
#include "stdio.h"
#include "string.h"
#include "datatype.h"
#include "debug.h"
#include "msAPI_OSD.h"
#include "msAPI_Memory.h"
#include "MApp_ZUI_Main.h"
#include "MApp_ZUI_APIcommon.h"
#include "MApp_ZUI_APIstrings.h"
#include "MApp_ZUI_APIwindow.h"
#include "MApp_ZUI_APItables.h"
#include "MApp_ZUI_APIgdi.h"
#include "MApp_ZUI_APIdraw.h"
#include "MApp_ZUI_APIcontrols.h"
#include "MApp_ZUI_APIcomponent.h"
#include "MApp_ZUI_APIalphatables.h"
#include "MApp_ZUI_ACTglobal.h"
#include "OSDcp_Bitmap_EnumIndex.h"

////////////////////////////////////////////////////
// Ball Progress Bar

/*
    FOCUS:
                                                   gradient (y) round rectangle (white)
    /----------------------------------------------\
   |ooooooooooooooooooooooooooooooooooooooooo       |
    \----------------------------------------------/                            (gray)


        blue     |     purple      |     red




    NORMAL:
                                                   gradient (y) round rectangle (light-gray)
    /----------------------------------------------\
   |ooooooooooooooooooooooooooooooooooooooooo       |
    \----------------------------------------------/                            (light-gray)


                        gray





    DISABLED:
                                                   gradient (y) round rectangle (dark-gray)
    /----------------------------------------------\
   |ooooooooooooooooooooooooooooooooooooooooo       |
    \----------------------------------------------/                            (dark-gray)


                    gray-hide


*/

#define BALL_PROGRESS_BAR_RADIUS 8
#define BALL_PROGRESS_BAR_BALL_W 12
#define BALL_PROGRESS_BAR_BALL_H 12
#define BALL_PROGRESS_BAR_LR_BORDER 6
#define BALL_PROGRESS_BAR_BALL_GAP 1


typedef enum
{
    EN_BALL_COLOR_BULE,
    EN_BALL_COLOR_GRAY,
    EN_BALL_COLOR_GRAY_HIDE,
    EN_BALL_COLOR_PURPLE,
    EN_BALL_COLOR_RED
} EN_BALL_COLOR;

static DRAW_BITMAP _ZUI_TBLSEG DrawProgressBarBallBlue =
{
    //BMPHANDLE handle;
    E_BMP_VOLUME_BALL_BLUE, //U16 u16BitmapIndex;
    TRUE, //BOOLEAN bSrcColorKey;
    0xFFFFFF, //OSD_COLOR srcColorKeyFrom;
    0xFFFFFF, //OSD_COLOR srcColorKeyEnd;
    255, //U8 u8Constant_Alpha;
};

static DRAW_BITMAP _ZUI_TBLSEG DrawProgressBarBallGray =
{
    //BMPHANDLE handle;
    E_BMP_VOLUME_BALL_GRAY, //U16 u16BitmapIndex;
    TRUE, //BOOLEAN bSrcColorKey;
    0xFFFFFF, //OSD_COLOR srcColorKeyFrom;
    0xFFFFFF, //OSD_COLOR srcColorKeyEnd;
    255, //U8 u8Constant_Alpha;
};

static DRAW_BITMAP _ZUI_TBLSEG DrawProgressBarBallGrayHide =
{
    //BMPHANDLE handle;
    E_BMP_VOLUME_BALL_GRAY_HIDE, //U16 u16BitmapIndex;
    TRUE, //BOOLEAN bSrcColorKey;
    0xFF00FF, //OSD_COLOR srcColorKeyFrom;
    0xFF00FF, //OSD_COLOR srcColorKeyEnd;
    255, //U8 u8Constant_Alpha;
};

static DRAW_BITMAP _ZUI_TBLSEG DrawProgressBarBallPurple =
{
    //BMPHANDLE handle;
    E_BMP_VOLUME_BALL_PURPLE, //U16 u16BitmapIndex;
    TRUE, //BOOLEAN bSrcColorKey;
    0xFFFFFF, //OSD_COLOR srcColorKeyFrom;
    0xFFFFFF, //OSD_COLOR srcColorKeyEnd;
    255, //U8 u8Constant_Alpha;
};

static DRAW_BITMAP _ZUI_TBLSEG DrawProgressBarBallRed =
{
    //BMPHANDLE handle;
    E_BMP_VOLUME_BALL_RED, //U16 u16BitmapIndex;
    TRUE, //BOOLEAN bSrcColorKey;
    0xFFFFFF, //OSD_COLOR srcColorKeyFrom;
    0xFFFFFF, //OSD_COLOR srcColorKeyEnd;
    255, //U8 u8Constant_Alpha;
};

///////////////////////////////////////////////////////////////////////////////
///  private  _MApp_ZUI_CTL_BallProgressBar_DrawBall
///  drawing function for "ball progress bar" control,
///
///  @param [in]       x U16     X-axis position
///  @param [in]       y U16     Y-axis position
///  @param [in]       percent U16     percent of the progress bar
///  @param [in]       param const PAINT_PARAM *       DC drawing parameter
///
///  @return no result value
///
///  @author MStarSemi @date 2007/1/25
///////////////////////////////////////////////////////////////////////////////

static void _MApp_ZUI_CTL_BallProgressBar_DrawBall(U16 x, U16 y, U16 percent, const PAINT_PARAM * param)
{
    //DRAW_BITMAP * pBmp = 0;
    RECT rect;

    //2007/12/22: for bank issue, we prepare it in XDATA
    DRAW_BITMAP * pDraw = (DRAW_BITMAP*)_ZUI_MALLOC(sizeof(DRAW_BITMAP));
    if (pDraw)
    {

        RECT_SET(rect, x, y, BALL_PROGRESS_BAR_BALL_W, BALL_PROGRESS_BAR_BALL_H);

        if (param->bIsDisable)
        {
            memcpy(pDraw, &DrawProgressBarBallGrayHide, sizeof(DRAW_BITMAP)); //pBmp = &DrawProgressBarBallGrayHide;
        }
        else if (param->bIsFocus) //the same focus group
        {
            //printf("[]left=%u,percent=%u\n", x, percent);
            if (percent < 33)
                memcpy(pDraw, &DrawProgressBarBallBlue, sizeof(DRAW_BITMAP)); //pBmp = &DrawProgressBarBallBlue;
            else if (percent < 66)
                memcpy(pDraw, &DrawProgressBarBallPurple, sizeof(DRAW_BITMAP)); //pBmp = &DrawProgressBarBallPurple;
            else
                memcpy(pDraw, &DrawProgressBarBallRed, sizeof(DRAW_BITMAP)); //pBmp = &DrawProgressBarBallRed;
        }
        else
        {
            memcpy(pDraw, &DrawProgressBarBallGray, sizeof(DRAW_BITMAP)); //pBmp = &DrawProgressBarBallGray;
        }


        _MApp_ZUI_API_DrawDynamicComponent(CP_BITMAP, pDraw, &param->dc, &rect);
        _ZUI_FREE(pDraw);
    }
    else
    {
        __ASSERT(0);
    }

}


///////////////////////////////////////////////////////////////////////////////
///  public  MApp_ZUI_CTL_BallProgressBarWinProc
///  Window Proc for "ball progress bar" control,
///     which a round rectangle in background, and use red, purple, red balls as progress
///     change value by calling
///
///  @param [in]       hWnd HWND     window handle
///  @param [in]       pMsg PMSG     message
///
///  @return S32 event handler result
///
///  @author MStarSemi @date 2007/1/25
///////////////////////////////////////////////////////////////////////////////

S32 MApp_ZUI_CTL_BallProgressBarWinProc(HWND hWnd, PMSG pMsg)
{

    static  DRAW_RECT _ZUI_TBLSEG _DrawProgressBarBgFocus =
    {
        0xFFFFFF, //OSD_COLOR RcolorFrom;
        0xFFFFFF, //OSD_COLOR RcolorTo;
        OSD_GRADIENT_DISABLE, //OSD_GRADIENT eRectGradient;
        0, //OSD_COLOR BroderColor;
        eRectBorderRound, //RECT_ATTRIB attrib;
        BALL_PROGRESS_BAR_RADIUS, //U8 sizeBorder;
        //FALSE, //BOOLEAN bShadow;
        BALL_PROGRESS_BAR_RADIUS, //radius
    };

    static  DRAW_RECT _ZUI_TBLSEG _DrawProgressBarBgNormal =
    {
        0xFFFFFF, //OSD_COLOR RcolorFrom;
        0xFFFFFF, //OSD_COLOR RcolorTo;
        OSD_GRADIENT_DISABLE, //OSD_GRADIENT eRectGradient;
        0, //OSD_COLOR BroderColor;
        eRectBorderRound, //RECT_ATTRIB attrib;
        BALL_PROGRESS_BAR_RADIUS, //U8 sizeBorder;
        //FALSE, //BOOLEAN bShadow;
        BALL_PROGRESS_BAR_RADIUS, //radius
    };

    static  DRAW_RECT _ZUI_TBLSEG _DrawProgressBarBgDisabled =
    {
        0x606060, //OSD_COLOR RcolorFrom;
        0x606060, //OSD_COLOR RcolorTo;
        OSD_GRADIENT_DISABLE, //OSD_GRADIENT eRectGradient;
        0, //OSD_COLOR BroderColor;
        eRectBorderRound, //RECT_ATTRIB attrib;
        BALL_PROGRESS_BAR_RADIUS, //U8 sizeBorder;
        //FALSE, //BOOLEAN bShadow;
        BALL_PROGRESS_BAR_RADIUS, //radius
    };

    switch(pMsg->message)
    {
        case MSG_PAINT:
            {
                //get buffer GC for offline drawing...
                PAINT_PARAM * param = (PAINT_PARAM*)pMsg->wParam;
                S16 value;

                //2007/12/22: for bank issue, we prepare it in XDATA
                DRAW_RECT * pDraw = (DRAW_RECT*)_ZUI_MALLOC(sizeof(DRAW_RECT));
                if (pDraw)
                {

                    //find all static text => dynamic text
                    if (param->bIsDisable)
                    {
                        param->dc.u8ConstantAlpha = MApp_ZUI_API_GetDisableAlpha(hWnd);
                        memcpy(pDraw, &_DrawProgressBarBgDisabled, sizeof(DRAW_RECT));
                    }
                    else if (param->bIsFocus) //the same focus group
                    {
                        param->dc.u8ConstantAlpha = MApp_ZUI_API_GetFocusAlpha(hWnd);
                        memcpy(pDraw, &_DrawProgressBarBgFocus, sizeof(DRAW_RECT));
                    }
                    else
                    {
                        param->dc.u8ConstantAlpha = MApp_ZUI_API_GetNormalAlpha(hWnd);
                        memcpy(pDraw, &_DrawProgressBarBgNormal, sizeof(DRAW_RECT));
                    }
                    _MApp_ZUI_API_DrawDynamicComponent(CP_RECT, pDraw, &param->dc, param->rect);
                    _ZUI_FREE(pDraw);
                }
                else
                {
                    __ASSERT(0);
                }

                value = MApp_ZUI_ACT_GetDynamicValue(hWnd);
                if (value < 0) value = 0;
                if (value > 100) value = 100;

                if (value)
                {
                    RECT rect_border;
                    S16 left_add, fill_left, fill_count, all_count, i;
                    rect_border = *param->rect;
                    rect_border.left += BALL_PROGRESS_BAR_LR_BORDER;
                    rect_border.width -= BALL_PROGRESS_BAR_LR_BORDER*2;
                    rect_border.top += (rect_border.height-BALL_PROGRESS_BAR_BALL_H)/2;
                    rect_border.height = BALL_PROGRESS_BAR_BALL_H;
                    left_add = 0;

                    //note: we always have at least one ball when value > 0
                    _MApp_ZUI_CTL_BallProgressBar_DrawBall(rect_border.left, rect_border.top, 0, param);

                    left_add += BALL_PROGRESS_BAR_BALL_W;
                    fill_left = (S32)(rect_border.width)*value/100;
                    fill_count = fill_left/(BALL_PROGRESS_BAR_BALL_W+BALL_PROGRESS_BAR_BALL_GAP);
                    all_count = rect_border.width/(BALL_PROGRESS_BAR_BALL_W+BALL_PROGRESS_BAR_BALL_GAP);
                    //printf("[]count=%u,%u\n", (U16)fill_count, (U16)all_count);

                    for (i = 1; i < fill_count; i++)
                    {
                        left_add += (rect_border.width-left_add-(all_count-i)*(BALL_PROGRESS_BAR_BALL_W+BALL_PROGRESS_BAR_BALL_GAP)) / (all_count-i); //additional gap, when width can not be divided by BALL_PROGRESS_BAR_BALL_W+BALL_PROGRESS_BAR_BALL_GAP
                        left_add += BALL_PROGRESS_BAR_BALL_GAP;
                        _MApp_ZUI_CTL_BallProgressBar_DrawBall(
                            rect_border.left+left_add,
                            rect_border.top,
                            (S32)(left_add+BALL_PROGRESS_BAR_BALL_W/2)*100/rect_border.width, param);
                        left_add += BALL_PROGRESS_BAR_BALL_W;

                    }
                }

            }
            return 0;
        default:
            break;

    }
    return DEFAULTWINPROC(hWnd, pMsg);
}

///////////////////////////////////////////////////////////////////////////////
///  public  MApp_ZUI_CTL_BallProgressBarFocusStyleWinProc
///  Window Proc for "ball progress bar" control,
///     Change the style to focus
///
///
///  @param [in]       hWnd HWND     window handle
///  @param [in]       pMsg PMSG     message
///
///  @return S32 event handler result
///
///  @author MStarSemi @date 2008/10/24
///////////////////////////////////////////////////////////////////////////////

S32 MApp_ZUI_CTL_BallProgressBarFocusStyleWinProc(HWND hWnd, PMSG pMsg)
{
    if(pMsg->message == MSG_PAINT)
    {
        PAINT_PARAM * param = (PAINT_PARAM*)pMsg->wParam;

        param->bIsDisable = 0;
        param->bIsFocus   = 1;
        param->bIsVisible = 0;

        pMsg->wParam = (WPARAM)param;

        MApp_ZUI_CTL_BallProgressBarWinProc(hWnd, pMsg);

        return 0;
    }

    return DEFAULTWINPROC(hWnd, pMsg);
}
#if 0 //def ENABLE_SMC_UI_NEW     /* smc.qxr 20121023 */
#define BMP_SLIDER_RECT_W 10
#define BMP_SLIDER_RECT_H 4
#define SLIDER_BAR_H 4
#else
#define BMP_SLIDER_RECT_W 4
#define BMP_SLIDER_RECT_H 10
#define SLIDER_BAR_H 4
#endif

///////////////////////////////////////////////////////////////////////////////
///  private  _MApp_ZUI_ACT_BallProgressBar_DrawBall
///  drawing function for "ball progress bar" control,
///
///  @param [in]       x U16     X-axis position
///  @param [in]       y U16     Y-axis position
///  @param [in]       percent U16     percent of the progress bar
///  @param [in]       param const PAINT_PARAM *       DC drawing parameter
///
///  @return no result value
///
///  @author MStarSemi @date 2007/1/25
///////////////////////////////////////////////////////////////////////////////
#if ENABLE_CUS_UI_SPEC
#define BMP_SLIEDE_BAR_MEASURE E_BMP_BMP_SLIDE_MEASURE_SEL
#else
#define BMP_SLIEDE_BAR_MEASURE 0xffff
#endif
static void _MApp_ZUI_ACT_SliderProgressBar_Draw(U16 x, U16 y, const PAINT_PARAM * param)
{
    static const DRAW_BITMAP _ZUI_TBLSEG DrawProgressBarRectNormal =
    {
         //BMPHANDLE handle;
         BMP_SLIEDE_BAR_MEASURE, //U16 u16BitmapIndex;
         TRUE, //BOOLEAN bSrcColorKey;
         0xFF00FF, //OSD_COLOR srcColorKeyFrom;
         0xFF00FF, //OSD_COLOR srcColorKeyEnd;
         255, //U8 u8Constant_Alpha;
    };

    static const DRAW_BITMAP _ZUI_TBLSEG DrawProgressBarRectFocus =
    {
         //BMPHANDLE handle;
         BMP_SLIEDE_BAR_MEASURE, //U16 u16BitmapIndex;
         TRUE, //BOOLEAN bSrcColorKey;
         0xFFFFFF, //OSD_COLOR srcColorKeyFrom;
         0xFFFFFF, //OSD_COLOR srcColorKeyEnd;
         255, //U8 u8Constant_Alpha;
    };

    //DRAW_BITMAP * pBmp = 0;
    RECT rect;

    //2007/12/22: for bank issue, we prepare it in XDATA
    DRAW_BITMAP * pDraw = (DRAW_BITMAP*)_ZUI_MALLOC(sizeof(DRAW_BITMAP));
    if (pDraw)
    {

        RECT_SET(rect, x, y, BMP_SLIDER_RECT_W, BMP_SLIDER_RECT_H);

        if (param->bIsDisable)
        {
            memcpy(pDraw, &DrawProgressBarRectNormal, sizeof(DRAW_BITMAP)); //pBmp = &DrawProgressBarBallGrayHide;
        }
        else if (param->bIsFocus) //the same focus group
        {
            memcpy(pDraw, &DrawProgressBarRectFocus, sizeof(DRAW_BITMAP)); //pBmp = &DrawProgressBarBallRed;
        }
        else
        {
            memcpy(pDraw, &DrawProgressBarRectNormal, sizeof(DRAW_BITMAP)); //pBmp = &DrawProgressBarBallGray;
        }


        _MApp_ZUI_API_DrawDynamicComponent(CP_BITMAP, pDraw, &param->dc, &rect);
        _ZUI_FREE(pDraw);
    }

}



///////////////////////////////////////////////////////////////////////////////
///  public  MApp_ZUI_ACT_BallProgressBarWinProc
///  Window Proc for "ball progress bar" control,
///     which a round rectangle in background, and use red, purple, red balls as progress
///     change value by calling
///
///  @param [in]       hWnd HWND     window handle
///  @param [in]       pMsg PMSG     message
///
///  @return S32 event handler result
///
///  @author MStarSemi @date 2007/1/25
///////////////////////////////////////////////////////////////////////////////

//melon
S32 MApp_ZUI_ACT_SliderProgressBarWinProc(HWND hWnd, PMSG pMsg)
{
#if 1 //def ENABLE_SMC_UI_NEW     /* smc.qxr 20121023 */
    static OSD_COLOR Bar_Normal_Bg = 0x070707;//0xC0C0C0; //0X333415;//0xFFFFFF;//0x888888;
    static OSD_COLOR Bar_Normal_Value =0X333415;//0xC0C0C0; //0x888888;//0x555555;
 //   static OSD_COLOR Bar_color_Rect_Bg = 0X000000;
    static OSD_COLOR Bar_Focus_Bg = 0X000040;
    static OSD_COLOR Bar_Focus_Value = 0XFFFF21;
#else
    static OSD_COLOR Bar_Normal_Bg = 0X333415;//0xFFFFFF;//0x888888;
    static OSD_COLOR Bar_Normal_Value =0X333415; //0x888888;//0x555555;
    #if(UI_SKIN_SEL == UI_SKIN_1366X768X565_FAN_India)
    static OSD_COLOR Bar_Focus_Bg =0XFFFF21; //0xC0C0C0;//0xFFFFFF;
    static OSD_COLOR Bar_Focus_Value =0XFFFF21; //0xC0C0C0;//0xFFFFFF;
    #else
    static OSD_COLOR Bar_Focus_Bg = 0xFFFFFF;
    static OSD_COLOR Bar_Focus_Value = 0xFFFFFF;
    #endif
    static OSD_COLOR Bar_color_Rect_Bg = 0X000000;
#endif
  //  static OSD_COLOR Bar_Disable_Bg =0X //0xFFFFFF;//0x888888;
  //  static OSD_COLOR Bar_Disable_Value =0X; //0x888888;//0x555555;

    static DRAW_RECT _DrawBar =
    {
        0x888888, //OSD_COLOR RcolorFrom;
        0x888888, //OSD_COLOR RcolorTo;
        OSD_GRADIENT_DISABLE, //OSD_GRADIENT eRectGradient;
        0, //OSD_COLOR BroderColor;
        eRectBorderRound, //RECT_ATTRIB attrib;
        0, //U8 sizeBorder;
        1, //BOOLEAN bShadow;
    };

/*
    DRAW_RECT_BORDER _DrawBorder  =
    {   // CP_RECT_BORDER_INDEX_0
           0x888888, // colorLeftTop;
           0x888888, // colorRightDown;
           1, // thickness;
           eSolidLine, // lt;
    };
*/
    switch(pMsg->message)
    {
        case MSG_PAINT:
            {
                //get buffer GC for offline drawing...
                PAINT_PARAM * param = (PAINT_PARAM*)pMsg->wParam;
                S16 value;
                S32 value_width;
                OSD_COLOR bar_bg_color, bar_value_color;
		        S16 s16TempWidth;


                //2007/12/22: for bank issue, we prepare it in XDATA
                DRAW_RECT * pDraw = (DRAW_RECT*)_ZUI_MALLOC(sizeof(DRAW_RECT));
                value = MApp_ZUI_ACT_GetDynamicValue(hWnd);
		        s16TempWidth = param->rect->width;

#if 0 //def ENABLE_SMC_UI_NEW     /* smc.qxr 20121023 */
                param->rect->top +=4;
#endif

            //    param->bIsFocus = TRUE;

                if (value < 0) value = 0;
                if (value > 100) value = 100;
              //  value_width = (S32)(param->rect->width)*value/100;
                value_width = (S32)(param->rect->width-BMP_SLIDER_RECT_W)*value/100;

                if (pDraw)
                {
                    //Draw Clear Background
                    //MApp_ZUI_API_InvalidateAllSuccessors(hWnd);

                    param->dc.u8ConstantAlpha = MApp_ZUI_API_GetNormalAlpha(hWnd);
                    param->rect->top += (BMP_SLIDER_RECT_H-SLIDER_BAR_H)/2;
                    param->rect->height = SLIDER_BAR_H;

                    //find all static text => dynamic text
                    if (param->bIsDisable)
                    {
                        param->dc.u8ConstantAlpha = MApp_ZUI_API_GetDisableAlpha(hWnd);
                        bar_bg_color = Bar_Normal_Bg;
                        bar_value_color = Bar_Normal_Value;
                    }
                    else if (param->bIsFocus) //the same focus group
                    {
                        param->dc.u8ConstantAlpha = MApp_ZUI_API_GetFocusAlpha(hWnd);
                        bar_bg_color = Bar_Focus_Bg;
                        bar_value_color = Bar_Focus_Value;
                    }
                    else
                    {
                        param->dc.u8ConstantAlpha = MApp_ZUI_API_GetNormalAlpha(hWnd);
                        bar_bg_color = Bar_Normal_Bg;
                        bar_value_color = Bar_Normal_Value;
                    }
#if 0 //def ENABLE_SMC_UI_NEW     /* smc.qxr 20121023 */
                    {
                    //Draw Rect bg
                      _DrawBar.RcolorFrom = Bar_color_Rect_Bg;
                      _DrawBar.RcolorTo= Bar_color_Rect_Bg;
                      memcpy(pDraw, &_DrawBar, sizeof(DRAW_RECT));
                      param->rect->left -=2;
                      param->rect->top -=2;
                      param->rect->width +=4;
                      param->rect->height +=4;
                      _MApp_ZUI_API_DrawDynamicComponent(CP_RECT, pDraw, &param->dc, param->rect);
                      param->rect->left +=2;
                      param->rect->top +=2;
                      param->rect->width -=4;
                      param->rect->height -=4;
                    }
#endif
                #if 0
                    if(param->rect->width < value_width)
                    {
                        printf("$$ -- >> 000 -- <<\n");
                        bar_bg_color = Bar_Normal_Bg;
                        bar_value_color = Bar_Normal_Value;
                    }
                    else
                    {
                        printf("$$ -- >> 111 -- <<\n");
                        bar_bg_color = Bar_Focus_Bg;
                        bar_value_color = Bar_Focus_Value;
                    }
                #endif
                    // Draw Bar
                    _DrawBar.RcolorFrom = bar_bg_color;
                    _DrawBar.RcolorTo= bar_bg_color;
                    memcpy(pDraw, &_DrawBar, sizeof(DRAW_RECT));
                    _MApp_ZUI_API_DrawDynamicComponent(CP_RECT, pDraw, &param->dc, param->rect);
                    // Draw Bar Value
                    param->rect->width= value_width;
                    _DrawBar.RcolorFrom = bar_value_color;
                    _DrawBar.RcolorTo= bar_value_color;
                    memcpy(pDraw, &_DrawBar, sizeof(DRAW_RECT));
                    _MApp_ZUI_API_DrawDynamicComponent(CP_RECT, pDraw, &param->dc, param->rect);
		            //Draw Bar Border
                    {
                        //param->rect->width = s16TempWidth;
                        //_MApp_ZUI_API_DrawDynamicComponent(CP_RECT_BORDER, &_DrawBorder, &param->dc, param->rect);
                    }

                    _ZUI_FREE(pDraw);
                }


                {
                    #if 1
                    RECT rect_border;
                    rect_border = *param->rect;
                    rect_border.left += value_width;
                    rect_border.width -= BMP_SLIDER_RECT_W*2;
                    rect_border.top += (rect_border.height-BMP_SLIDER_RECT_H)/2;
                    rect_border.height = BMP_SLIDER_RECT_H;
                    _MApp_ZUI_ACT_SliderProgressBar_Draw(rect_border.left, rect_border.top, param);
                    #endif
                }
            }
            return 0;
        default:
            break;
    }
    return DEFAULTWINPROC(hWnd, pMsg);
}



///////////////////////////////////////////////////////////////////////////////
///
///////////////////////////////////////////////////////////////////////////////

//XM ZHIQIN

static void _MApp_ZUI_ACT_1_SliderProgressBar_Draw(U16 x, U16 y, const PAINT_PARAM * param)
{
    static const DRAW_BITMAP _ZUI_TBLSEG DrawProgressBarRectNormal =
    {
         //BMPHANDLE handle;
         BMP_SLIEDE_BAR_MEASURE, //U16 u16BitmapIndex;
         TRUE, //BOOLEAN bSrcColorKey;
         0xFF00FF, //OSD_COLOR srcColorKeyFrom;
         0xFF00FF, //OSD_COLOR srcColorKeyEnd;
         255, //U8 u8Constant_Alpha;
    };

    static const DRAW_BITMAP _ZUI_TBLSEG DrawProgressBarRectFocus =
    {
         //BMPHANDLE handle;
         BMP_SLIEDE_BAR_MEASURE, //U16 u16BitmapIndex;
         TRUE, //BOOLEAN bSrcColorKey;
         0xFFFFFF, //OSD_COLOR srcColorKeyFrom;
         0xFFFFFF, //OSD_COLOR srcColorKeyEnd;
         255, //U8 u8Constant_Alpha;
    };

    //DRAW_BITMAP * pBmp = 0;
    RECT rect;

    //2007/12/22: for bank issue, we prepare it in XDATA
    DRAW_BITMAP * pDraw = (DRAW_BITMAP*)_ZUI_MALLOC(sizeof(DRAW_BITMAP));
    if (pDraw)
    {
        RECT_SET(rect, x, y, 6, 10);

        if (param->bIsDisable)
        {
            memcpy(pDraw, &DrawProgressBarRectNormal, sizeof(DRAW_BITMAP)); //pBmp = &DrawProgressBarBallGrayHide;
        }
        else if (param->bIsFocus) //the same focus group
        {
            memcpy(pDraw, &DrawProgressBarRectFocus, sizeof(DRAW_BITMAP)); //pBmp = &DrawProgressBarBallRed;
        }
        else
        {
            memcpy(pDraw, &DrawProgressBarRectNormal, sizeof(DRAW_BITMAP)); //pBmp = &DrawProgressBarBallGray;
        }


        _MApp_ZUI_API_DrawDynamicComponent(CP_BITMAP, pDraw, &param->dc, &rect);
        _ZUI_FREE(pDraw);
    }

}


S32 MApp_ZUI_ACT_1_SliderProgressBarWinProc(HWND hWnd, PMSG pMsg)
{
  //  static OSD_COLOR Bar_Normal_Bg = 0xFFFFFF;//0x888888;
  //  static OSD_COLOR Bar_Normal_Value = 0x888888;//0x555555;
    #if((UI_SKIN_SEL == UI_SKIN_1366X768X565_SMC_India)||(UI_SKIN_SEL==UI_SKIN_1366X768X565_HAIER_CN))
    static OSD_COLOR Bar_Focus_Bg = 0xC0C0C0;//0xFFFFFF;
    static OSD_COLOR Bar_Focus_Value = 0xC0C0C0;//0xFFFFFF;
    #else
    static OSD_COLOR Bar_Focus_Bg = 0xFFFFFF;
    static OSD_COLOR Bar_Focus_Value = 0xFFFFFF;
    #endif
    static DRAW_RECT _DrawBar =
    {
        0x888888, //OSD_COLOR RcolorFrom;
        0x888888, //OSD_COLOR RcolorTo;
        OSD_GRADIENT_DISABLE, //OSD_GRADIENT eRectGradient;
        0, //OSD_COLOR BroderColor;
        eRectBorderRound, //RECT_ATTRIB attrib;
        0, //U8 sizeBorder;
        1, //BOOLEAN bShadow;
    };

/*
    DRAW_RECT_BORDER _DrawBorder  =
    {   // CP_RECT_BORDER_INDEX_0
           0x888888, // colorLeftTop;
           0x888888, // colorRightDown;
           1, // thickness;
           eSolidLine, // lt;
    };
*/
    switch(pMsg->message)
    {
        case MSG_PAINT:
            {
                //get buffer GC for offline drawing...
                PAINT_PARAM * param = (PAINT_PARAM*)pMsg->wParam;
                S16 value;
                S32 value_width;
                OSD_COLOR bar_bg_color, bar_value_color;
		        S16 s16TempWidth;


                //2007/12/22: for bank issue, we prepare it in XDATA
                DRAW_RECT * pDraw = (DRAW_RECT*)_ZUI_MALLOC(sizeof(DRAW_RECT));
                value = MApp_ZUI_ACT_GetDynamicValue(hWnd);
		        s16TempWidth = param->rect->height;
                printf("s16TempWidth =%d\n",s16TempWidth);

                param->bIsFocus = TRUE;

                if (value < 0) value = 0;
              //  if (value > 100) value = 100;
                if (value > 120) value = 120;
               // value_width = (S32)(param->rect->height-BMP_SLIDER_RECT_W)*value/100;
               // value_width = (S32)(param->rect->height)*value/100;
                value_width = (S32)(param->rect->height)*value/125;
                printf("value_width =%d\n",value_width);

                if (pDraw)
                {
                    //Draw Clear Background
                    //MApp_ZUI_API_InvalidateAllSuccessors(hWnd);

                    param->dc.u8ConstantAlpha = MApp_ZUI_API_GetNormalAlpha(hWnd);
                    param->rect->top += 1; //(BMP_SLIDER_RECT_H-SLIDER_BAR_H)/2;
                    printf("param->rect->top =%d\n",param->rect->top);

                    param->rect->height =1;  ///3;//SLIDER_BAR_H;
                    printf("param->rect->height =%d\n",param->rect->height);

                    //find all static text => dynamic text
                    if (param->bIsDisable)
                    {
                        #if 0
                        param->dc.u8ConstantAlpha = MApp_ZUI_API_GetDisableAlpha(hWnd);
                        bar_bg_color = Bar_Normal_Bg;
                        bar_value_color = Bar_Normal_Value;
                        #endif

                        param->dc.u8ConstantAlpha = MApp_ZUI_API_GetFocusAlpha(hWnd);
                        bar_bg_color = Bar_Focus_Bg;
                        bar_value_color = Bar_Focus_Value;
                    }
                    else if (param->bIsFocus) //the same focus group
                    {
                        param->dc.u8ConstantAlpha = MApp_ZUI_API_GetFocusAlpha(hWnd);
                        bar_bg_color = Bar_Focus_Bg;
                        bar_value_color = Bar_Focus_Value;
                    }
                    else
                    {
                        #if 0
                        param->dc.u8ConstantAlpha = MApp_ZUI_API_GetNormalAlpha(hWnd);
                        bar_bg_color = Bar_Normal_Bg;
                        bar_value_color = Bar_Normal_Value;
                        #endif

                        param->dc.u8ConstantAlpha = MApp_ZUI_API_GetFocusAlpha(hWnd);
                        bar_bg_color = Bar_Focus_Bg;
                        bar_value_color = Bar_Focus_Value;
                    }
                    // Draw Bar
                    _DrawBar.RcolorFrom = bar_bg_color;
                    _DrawBar.RcolorTo= bar_bg_color;
                    memcpy(pDraw, &_DrawBar, sizeof(DRAW_RECT));
                    _MApp_ZUI_API_DrawDynamicComponent(CP_RECT, pDraw, &param->dc, param->rect);
                    // Draw Bar Value
                    param->rect->height= value_width;
                    _DrawBar.RcolorFrom = bar_value_color;
                    _DrawBar.RcolorTo= bar_value_color;
                    memcpy(pDraw, &_DrawBar, sizeof(DRAW_RECT));
                    _MApp_ZUI_API_DrawDynamicComponent(CP_RECT, pDraw, &param->dc, param->rect);
		            //Draw Bar Border
                    {
                        //param->rect->width = s16TempWidth;
                        //_MApp_ZUI_API_DrawDynamicComponent(CP_RECT_BORDER, &_DrawBorder, &param->dc, param->rect);
                    }

                    _ZUI_FREE(pDraw);
                }


                {
                    RECT rect_border;
                    rect_border = *param->rect;
                    //rect_border.left += value_width;
                    rect_border.height-= 1;//5;//10;//BMP_SLIDER_RECT_W*2;
                    printf("rect_border.height =%d\n",rect_border.height);

                   // rect_border.top += (rect_border.height-BMP_SLIDER_RECT_H)/2;
                   // rect_border.top += (rect_border.height-BMP_SLIDER_RECT_H);
                    rect_border.top += rect_border.height;
                    printf("rect_border.top =%d\n",rect_border.top);

                    //rect_border.height = BMP_SLIDER_RECT_H;
                    rect_border.height = 2;//BMP_SLIDER_RECT_H;
                    printf("rect_border.height =%d\n",rect_border.height);

                    _MApp_ZUI_ACT_1_SliderProgressBar_Draw(rect_border.left, rect_border.top, param);

                }
            }
            return 0;
        default:
            break;
    }
    return DEFAULTWINPROC(hWnd, pMsg);
}


#undef MAPP_ZUI_CTL_BALLPROGBAR_C
