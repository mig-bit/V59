///////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2008-2010 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// ("MStar Confidential Information") by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
///////////////////////////////////////////////////////////////////////////////

#ifndef _MSAPI_DATA_STREAM_IO_H_
#define _MSAPI_DATA_STREAM_IO_H_

#ifdef __cplusplus
extern "C" {
#endif  // #ifdef __cplusplus

///////////////////////////////////////////////////////////////////////////////
/// @file   msAPI_DataStreamIO.h
/// This file contains the interface of data stream I/O
/// @author MStar Semiconductor Inc.
/// @brief  APIs for data stream I/O
///////////////////////////////////////////////////////////////////////////////

//------------------------------------------------------------------------------
// Include Files
//------------------------------------------------------------------------------
#include "MsCommon.h"

#include "msAPI_FSCommon.h" // for LongLong

//------------------------------------------------------------------------------
// Defines
//------------------------------------------------------------------------------
#undef INTERFACE
#ifdef _MSAPI_DATA_STREAM_IO_C_
#define INTERFACE
#else
#define INTERFACE extern
#endif // #ifdef _MSAPI_DATA_STREAM_IO_C_

//------------------------------------------------------------------------------
// Macros
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Type and Structure Declaration
//------------------------------------------------------------------------------
#define INVALID_DATA_STREAM_HDL (0xffffffff)

typedef enum
{
    E_DATA_STREAM_SEEK_SET    = 0,
    E_DATA_STREAM_SEEK_CUR    = 1,
} E_DATA_STREAM_SEEK_OPTION;

typedef enum
{
    E_DATA_STREAM_TYPE_IGNORE     = 0,

    E_DATA_STREAM_TYPE_PHOTO,

    E_DATA_STREAM_TYPE_MUSIC,
    E_DATA_STREAM_TYPE_MUSIC2,
    E_DATA_STREAM_TYPE_LYRIC,

    E_DATA_STREAM_TYPE_VIDEO,
    E_DATA_STREAM_TYPE_AUDIO,
    E_DATA_STREAM_TYPE_IN_SUB,
    E_DATA_STREAM_TYPE_EX_SUB0,
    E_DATA_STREAM_TYPE_EX_SUB1,
    E_DATA_STREAM_TYPE_ATTACHMENT,

    E_DATA_STREAM_TYPE_NUM,
} E_DATA_STREAM_TYPE;

typedef struct
{
    U32         (*pfnOpen)  (void *pPrivate, U8 u8Mode, E_DATA_STREAM_TYPE eType);
    BOOLEAN     (*pfnClose) (U32 u32Hdl);
    U32         (*pfnRead)  (U32 u32Hdl, void *pBuffAddr, U32 u32Length);
    BOOLEAN     (*pfnSeek)  (U32 u32Hdl, LongLong u64Pos, E_DATA_STREAM_SEEK_OPTION eOption);
    LongLong    (*pfnTell)  (U32 u32Hdl);
    LongLong    (*pfnLength)    (U32 u32Hdl);
} FN_DATA_STRM_IO;

//------------------------------------------------------------------------------
// Extern Global Variabls
//------------------------------------------------------------------------------
INTERFACE U32       msAPI_DataStreamIO_Open(void *pPrivate, U8 u8Mode, E_DATA_STREAM_TYPE eType);
INTERFACE BOOLEAN   msAPI_DataStreamIO_Close(U32 u32Hdl);
INTERFACE U32       msAPI_DataStreamIO_Read(U32 u32Hdl, void *pBuffAddr, U32 u32Length);
INTERFACE BOOLEAN   msAPI_DataStreamIO_Seek(U32 u32Hdl, U32 u32Pos, E_DATA_STREAM_SEEK_OPTION eOption);
INTERFACE BOOLEAN   msAPI_DataStreamIO_Seek_LongLong(U32 u32Hdl, LongLong u64Pos, E_DATA_STREAM_SEEK_OPTION option);
INTERFACE U32       msAPI_DataStreamIO_Tell(U32 u32Hdl);
INTERFACE LongLong  msAPI_DataStreamIO_Tell_LongLong(U32 u32Hdl);
INTERFACE U32       msAPI_DataStreamIO_Length(U32 u32Hdl);
INTERFACE LongLong  msAPI_DataStreamIO_Length_LongLong(U32 u32Hdl);

INTERFACE BOOLEAN   msAPI_DataStreamIO_OptionRegistation(FN_DATA_STRM_IO *pfnIO);


//------------------------------------------------------------------------------
// Extern Functions
//------------------------------------------------------------------------------

#undef INTERFACE

#ifdef __cplusplus
}
#endif  // #ifdef __cplusplus

#endif  // #ifndef _MSAPI_DATA_STREAM_IO_H_


