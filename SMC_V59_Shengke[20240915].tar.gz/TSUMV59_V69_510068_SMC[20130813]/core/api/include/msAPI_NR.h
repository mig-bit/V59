#ifndef MSAPI_NR_H
#define MSAPI_NR_H

/********************************************************************************/
/*                  Macro                                                       */
/* ******************************************************************************/

/********************************************************************************/
/*                  Struct                                                      */
/* ******************************************************************************/
#define DYNAMIC_NR_TBL_MOTION_LEVEL_NUM    6
#define DYNAMIC_NR_TBL_LUMA_LEVEL_NUM      8
#define DYNAMIC_NR_TBL_NOISE_LEVEL_NUM     5

#define DYNAMIC_NR_TBL_REG_NUM      8

#define  NoiseMagTh0    0
#define  NoiseMagTh1    1
#define  NoiseMagTh2    2
#define  NoiseMagTh3    3
#define  NoiseMagTh4    4
#define  NoiseMagTh5    5
#define  NoiseMagTh6    6
#define  NoiseMagTh7    7
#define  NoiseMagTh8    8


#if (ENABLE_NEW_AUTO_NR == 1)
    typedef enum
    {
        E_MAPI_AUTO_NR_STATUS_OFF = 0x00,
        E_MAPI_AUTO_NR_STATUS_LOW = 0x01,
        E_MAPI_AUTO_NR_STATUS_MID = 0x02,
        E_MAPI_AUTO_NR_STATUS_HIGH = 0x03,
    } MAPI_PQL_AUTO_NR_STATUS;
#endif


typedef struct
{
    MS_U8 u8CoringOffset;
    MS_U8 u8SNROffset;
}MS_DYNAMIC_NR_MISC_PARAM_LUMA;

typedef struct
{
    MS_U8 u8Spike_NR_0;
    MS_U8 u8Spike_NR_1;
    MS_U8 u8Gray_Guard_En;
    MS_U8 u8Gray_Guard_Gain;
}MS_DYNAMIC_NR_MISC_PARAM;

typedef struct
{
    MS_U8 u8CoringOffset;
    MS_U8 u8SharpnessOffset;
    MS_U8 u8NM_V;
    MS_U8 u8NM_H_0;
    MS_U8 u8NM_H_1;
    MS_U8 u8SC_Coring;
    MS_U8 u8GNR_0;
    MS_U8 u8GNR_1;
    MS_U8 u8SpikeNR_0;
    MS_U8 u8SpikeNR_1;
    MS_U8 u8CP;
    MS_U8 u8DP;
    MS_U8 u8AGC_Gain_Offset;
    MS_U8 u8Gray_Guard_En;
    MS_U8 u8Gray_Guard_Gain;
}MS_DYNAMIC_NR_MISC_PARAM_NOISE;


typedef struct
{
    MS_U8 u8DeFlicker_Step1;
    MS_U8 u8DeFlicker_Step2;
    MS_U8 u8M_DeFi_Th;
    MS_U8 u8L_DeFi_Th;
    MS_U8 u8NoiseThreshold[DYNAMIC_NR_TBL_NOISE_LEVEL_NUM-1];
    MS_U8 u8NoiseMag;
    MS_BOOL bMotionEn;
    MS_BOOL bLumaEn;
    MS_U8 u8MotionStartLvl;
    MS_U8 u8MotionEndLvl;
    MS_U8 u8LumaStartLvl;
    MS_U8 u8LumaEndLvl;
}MS_DYNAMIC_NR_PARAM;

/********************************************************************************/
/*                  Global varialbe                                             */
/********************************************************************************/

/********************************************************************************/
/*                  Function Prototypes                                         */
/********************************************************************************/
extern void mAPI_DynamicNR_GetGuassinSNR(void);
extern void msAPI_DynamicNR_GetSharpness(void);
extern void msAPI_DynamicNR_GetCoring(void);
extern void msAPI_DynamicNR_Handler(E_XC_PQ_3D_NR en3DNRType);
#if (ENABLE_NEW_AUTO_NR == 1)
extern void msAPI_NR_SetDNRDefault(void);
extern void msAPI_NR_SetDNRStatus(MAPI_PQL_AUTO_NR_STATUS Status_NR,MAPI_PQL_AUTO_NR_STATUS PreStatus_NR);
extern void DNR_Handler(void);
#endif

#endif
