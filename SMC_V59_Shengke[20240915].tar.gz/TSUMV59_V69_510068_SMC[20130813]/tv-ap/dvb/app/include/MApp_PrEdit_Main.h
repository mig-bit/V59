////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MAPP_PREDIT_MAIN_H
#define _MAPP_PREDIT_MAIN_H

#include "datatype.h"
#include "MApp_Exit.h"

#ifdef MAPP_PREDIT_MAIN_C
#define INTERFACE
#else
#define INTERFACE extern
#endif

typedef enum
{
    MODE_PREDIT_NORMAL,
    MODE_PREDIT_DELETE,
    MODE_PREDIT_MOVE,
    MODE_PREDIT_RENAME,
#if ENABLE_CUS_CHANNEL_SWAP_INSERT
    MODE_PREDIT_SWAP,
    MODE_PREDIT_INSERT,
#endif
    MODE_PREDIT_BLOCK,
    MODE_PREDIT_ONTIME_CHANNEL,
} EN_PREDIT_MODE;

INTERFACE void MApp_ProgramEdit_SetMode(EN_PREDIT_MODE mode);

#undef INTERFACE

#endif  // _MAPP_PREDIT_MAIN_H

