////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#define MAPP_BLOCKSYS_C

#include <string.h>
#include "Board.h"
#include "datatype.h"

// Common Definition
#include "MsCommon.h"

#include "apiXC.h"
#include "apiXC_Adc.h"
#include "apiXC_Sys.h"
#include "msAPI_DTVSystem.h"
#include "msAPI_ATVSystem.h"
#include "msAPI_audio.h"

#include "MApp_Key.h"
#include "MApp_GlobalSettingSt.h"
#include "MApp_GlobalVar.h"
#include "MApp_Audio.h"
#include "MApp_UiMenuDef.h"
#include "MApp_TV.h"// For parental block
#include "MApp_ChannelChange.h"// For parental block
#include "MApp_BlockSys.h"
#include "MApp_ATVProc.h"
#include "msAPI_Timer.h"
#include "MApp_GlobalFunction.h"
#include "MApp_SignalMonitor.h"
#include "MApp_ZUI_Main.h"
#include "MApp_TV.h"
#include "msAPI_ChProc.h"
#include "MApp_ChannelList.h"
#include "MApp_ZUI_ACTglobal.h"
#include "ZUI_exefunc.h"
#include "MApp_XC_PQ.h"
#include "MApp_GlobalFunction.h"
#include "MApp_PCMode.h"
#include "MApp_ZUI_ACTfactorymenu.h"
#include "MApp_ZUI_ACTmenudlgfunc.h"
#include "MApp_ZUI_ACTmsgbox.h"
#include "MApp_ZUI_ACTmenufunc.h"

#define BLOCKSYSDBG(x)  //x
//#define ENABLE_PRINTF_PasswordCheckSource
/********************************************************************************/
/*                    Local                                                     */
/********************************************************************************/
#define BLOCKSYS_MONITOR_PERIOD 100 //ms
static BOOLEAN fParentalControlStatus;
extern BOOLEAN bStopMonitorBlock;
//ZUI: unused...#if BLOCK_SYSTEM
#if MHEG5_ENABLE
MEMBER_SERVICETYPE _eCurServiceType=E_SERVICETYPE_INVALID;
WORD _wCurPosition=0;
#endif

#ifdef ENABLE_PRINTF_PasswordCheckSource
static U32 u32printfPWDCheckSourceTimer = 0;
#endif
static U32 u32PwdMsgToScreensaverMonitorTimer = 0;

void MApp_BlockSys_SetBlockStatus(BOOLEAN bBlockSysBlockStatus)
{
#if (!ENABLE_DTV)
    UNUSED(bBlockSysBlockStatus);
#else
    if(bBlockSysBlockStatus)
    { //block
        BLOCKSYSDBG(printf("BLOCKSY>> Blcok!\n"));
        if( IsSrcTypeDTV( SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW) ) )
        {
            msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_BYVCHIP_MUTEON, E_AUDIOMUTESOURCE_ACTIVESOURCE);
            msAPI_Scaler_SetScreenMute(E_SCREEN_MUTE_RATING, ENABLE, NULL, MAIN_WINDOW);
        }
        else
        {
            //TO DO : sub window
        }

    }
    else
    {
        //unblock
        BLOCKSYSDBG(printf("BLOCKSY>> UnBlcok!\n"));
        if( IsSrcTypeDTV( SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW) ) )
        {
            msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_BYVCHIP_MUTEOFF, E_AUDIOMUTESOURCE_ACTIVESOURCE);
            msAPI_Scaler_SetScreenMute(E_SCREEN_MUTE_RATING, DISABLE, NULL, MAIN_WINDOW);
        }
        else
        {
            //TO DO : sub window
        }
    }
#endif
}

void MApp_ParentalControl_SetBlockStatus(BOOLEAN bBlockSysBlockStatus)
{
#if (!ENABLE_DTV)
    UNUSED(bBlockSysBlockStatus);
#else
    fParentalControlStatus=bBlockSysBlockStatus;
    MApp_BlockSys_SetBlockStatus(bBlockSysBlockStatus);
#endif
}
BOOLEAN MApp_ParentalControl_GetBlockStatus(void)
{
    return fParentalControlStatus;
}


void MApp_CheckBlockProgramme(void)
{
#if ENABLE_DTV
    MEMBER_SERVICETYPE bServiceType;
    WORD wCurPosition;
#endif
    BYTE cCurrentProgramNumber;

#if 0
    if(!stGenSetting.g_BlockSysSetting.u8BlockSysLockMode)
    {
        if (MApp_GetSignalStatus() == SIGNAL_LOCK)
        {
            SYS_SCREEN_SAVER_TYPE(MAIN_WINDOW) = EN_SCREENSAVER_NULL;
            #if (ENABLE_PIP)
            if(IsPIPSupported())
            {
                SYS_SCREEN_SAVER_TYPE(SUB_WINDOW) = EN_SCREENSAVER_NULL;
            }
            #endif
        }
        return;
    }
#endif

#if ENABLE_DTV
        if(IsDTVInUse())
        {
#if MHEG5_ENABLE
            if(_eCurServiceType != E_SERVICETYPE_INVALID)
            {
                bServiceType=_eCurServiceType;
                wCurPosition=_wCurPosition;
            }
            else
#endif
            {
                bServiceType = msAPI_CM_GetCurrentServiceType();
                wCurPosition = msAPI_CM_GetCurrentPosition(bServiceType);
            }

            bIsBlocked = msAPI_CM_GetProgramAttribute(bServiceType, wCurPosition, E_ATTRIBUTE_IS_LOCKED);
        }
        else
#endif
        if(IsATVInUse())
        {
            cCurrentProgramNumber = msAPI_ATV_GetCurrentProgramNumber();
            #if ENABLE_CUS_BLOCK_SYS
            if(stGenSetting.g_VChipSetting.u8InputBlockItem & INPUT_BLOCK_TV)
            {
                if((g_u16PasswordCheckSource & INPUT_BLOCK_TV))
                {
                    bIsBlocked = TRUE;
                }
                else
                {
                    bIsBlocked = FALSE;
                }
            }
            else
            {
                if((msAPI_ATV_IsProgramLocked((BYTE)cCurrentProgramNumber) == TRUE) && (msAPI_ATV_IsLockedCHCheckPwdSucess((BYTE)cCurrentProgramNumber) == FALSE))
                {
                    bIsBlocked = TRUE;
                }
                else
                {
                    bIsBlocked = FALSE;
                }
            }
            #else
            bIsBlocked = msAPI_ATV_IsProgramLocked((BYTE)cCurrentProgramNumber);
            #endif
        }
        else
        {
            msAPI_Scaler_SetScreenMute(E_SCREEN_MUTE_BLOCK, DISABLE, NULL, MAIN_WINDOW);
            msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_BYBLOCK_MUTEOFF, E_AUDIOMUTESOURCE_ACTIVESOURCE);
            bIsBlocked = FALSE;
        }
        if (FALSE ==bStopMonitorBlock)
            MApp_EnableBlockProgramme(bIsBlocked);
    }

void MApp_EnableBlockProgramme(BOOLEAN bEnableBlock)
{
  #if (ENABLE_SWITCH_CHANNEL_TIME)
    #define PT_MApp_EBP_SetBeginTime()      u32TimeBegin = msAPI_Timer_GetTime0()
    #define PT_MApp_EBP_PrintfTime(x)       u32TimeEnd = msAPI_Timer_DiffTimeFromNow(u32TimeBegin);\
                                            printf(x, u32TimeEnd);\
                                            u32TimeBegin = msAPI_Timer_GetTime0()

    U32 u32TimeBegin = 0x00;
    U32 u32TimeEnd   = 0x00;
  #else
    #define PT_MApp_EBP_SetBeginTime()
    #define PT_MApp_EBP_PrintfTime(x)
  #endif

    //printf("Blcok program [%bu]\n",bEnableBlock);
#if 0//(!ENABLE_DTV)
    UNUSED(bEnableBlock);
#else
    if(bEnableBlock == TRUE)
    {
        if(IsSrcTypeDTV(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)) || IsSrcTypeATV(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)))
        {
            SwitchChannelTimePrintf("[SwitchChannelTime][EBP]Blocked --- %ld\n");
            PT_MApp_EBP_SetBeginTime();
            msAPI_Scaler_SetScreenMute(E_SCREEN_MUTE_BLOCK, ENABLE, NULL, MAIN_WINDOW);
            msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_BYBLOCK_MUTEON, E_AUDIOMUTESOURCE_ACTIVESOURCE);
            PT_MApp_EBP_PrintfTime("[EBP]MApp_EnableBlockProgramme(TRUE) -- %ld\n");
        }
        else
        {
            //TO DO : for sub window
        }
    }
    else
    {
        if(IsSrcTypeDTV(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)) || IsSrcTypeATV(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)))
        {
            msAPI_Scaler_SetScreenMute(E_SCREEN_MUTE_BLOCK, DISABLE, NULL, MAIN_WINDOW);
            msAPI_Scaler_SetScreenMute(E_SCREEN_MUTE_INPUT, DISABLE, NULL, MAIN_WINDOW);
            msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_BYBLOCK_MUTEOFF, E_AUDIOMUTESOURCE_ACTIVESOURCE);
        }
        else
        {
            //TO DO : for sub window
        }
    }
#endif
}


#if MHEG5_ENABLE
void MApp_BlockSysSetCurrentService(MEMBER_SERVICETYPE eServiceType, WORD wPosition)
{
     _eCurServiceType=eServiceType;
    _wCurPosition=wPosition;
}
#endif
#if ENABLE_CUS_BLOCK_SYS
#define TIMER_DELAY_PWD_TO_SCREENSAVER      5000 //5s
extern void MApp_MuteAvByLock(U8 u8ScreenMute, BOOLEAN bMuteEnable);
static BOOLEAN _bPreInputLock = FALSE;
void MApp_BlockSys_Monitor(SCALER_WIN eWindow,U8 u8CheckMode,BOOLEAN bChangeInputSrc)
{

#ifdef ENABLE_PRINTF_PasswordCheckSource
    if(msAPI_Timer_DiffTimeFromNow(u32printfPWDCheckSourceTimer) >1000)
    {
        u32printfPWDCheckSourceTimer = msAPI_Timer_GetTime0();
        printf("\n PasswordCheckSource: %x,", g_u16PasswordCheckSource);
        printf("CH(%u):%d,",msAPI_ATV_GetCurrentProgramNumber(),(msAPI_ATV_IsLockedCHCheckPwdSucess(msAPI_ATV_GetCurrentProgramNumber())));
        printf("TV:%d,",((g_u16PasswordCheckSource&INPUT_BLOCK_TV)?1:0));
        printf("AV1:%d,",((g_u16PasswordCheckSource&INPUT_BLOCK_AV1)?1:0));
        printf("AV2:%d,",((g_u16PasswordCheckSource&INPUT_BLOCK_AV2)?1:0));
        printf("YP1:%d,",((g_u16PasswordCheckSource&INPUT_BLOCK_YPBPR1)?1:0));
        printf("YP2:%d,",((g_u16PasswordCheckSource&INPUT_BLOCK_YPBPR1)?1:0));
        printf("PC:%d,",((g_u16PasswordCheckSource&INPUT_BLOCK_PC)?1:0));
        printf("USB:%d,",((g_u16PasswordCheckSource&INPUT_BLOCK_USB)?1:0));
        printf("HM1:%d,",((g_u16PasswordCheckSource&INPUT_BLOCK_HDMI1)?1:0));
        printf("HM2:%d,",((g_u16PasswordCheckSource&INPUT_BLOCK_HDMI2)?1:0));
        printf("HM3:%d \n", ((g_u16PasswordCheckSource&INPUT_BLOCK_HDMI3)?1:0));
        printf("HM4:%d \n", ((g_u16PasswordCheckSource&INPUT_BLOCK_HDMI4)?1:0));
        printf("u8InputBlockItem: %x,", stGenSetting.g_VChipSetting.u8InputBlockItem);
        printf("CH(%u):%d,",msAPI_ATV_GetCurrentProgramNumber(),(msAPI_ATV_IsProgramLocked(msAPI_ATV_GetCurrentProgramNumber())));
        printf("TV:%d,",((stGenSetting.g_VChipSetting.u8InputBlockItem&INPUT_BLOCK_TV)?1:0));
        printf("AV1:%d,",((stGenSetting.g_VChipSetting.u8InputBlockItem&INPUT_BLOCK_AV1)?1:0));
        printf("AV2:%d,",((stGenSetting.g_VChipSetting.u8InputBlockItem&INPUT_BLOCK_AV2)?1:0));
        printf("YP1:%d,",((stGenSetting.g_VChipSetting.u8InputBlockItem&INPUT_BLOCK_YPBPR1)?1:0));
        printf("YP2:%d,",((stGenSetting.g_VChipSetting.u8InputBlockItem&INPUT_BLOCK_YPBPR1)?1:0));
        printf("PC:%d,",((stGenSetting.g_VChipSetting.u8InputBlockItem&INPUT_BLOCK_PC)?1:0));
        printf("USB:%d,",((stGenSetting.g_VChipSetting.u8InputBlockItem&INPUT_BLOCK_USB)?1:0));
        printf("HM1:%d,",((stGenSetting.g_VChipSetting.u8InputBlockItem&INPUT_BLOCK_HDMI1)?1:0));
        printf("HM2:%d,",((stGenSetting.g_VChipSetting.u8InputBlockItem&INPUT_BLOCK_HDMI2)?1:0));
        printf("HM3:%d \n", ((stGenSetting.g_VChipSetting.u8InputBlockItem&INPUT_BLOCK_HDMI3)?1:0));
        printf("HM4:%d \n", ((stGenSetting.g_VChipSetting.u8InputBlockItem&INPUT_BLOCK_HDMI4)?1:0));
    }
#endif

    if(IsAnyTVSourceInUse())
    {
        if(u8CheckMode & BLOCKSYS_CHECK_AV)
        {
            MApp_CheckBlockProgramme();
        }
        // parental blocked
        if(IsATVInUse())
        {
            if(stGenSetting.g_VChipSetting.u8InputBlockItem&INPUT_BLOCK_TV) //TV source block
            {
                if(g_u16PasswordCheckSource & INPUT_BLOCK_TV)
                {
                    if(u8CheckMode & BLOCKSYS_CHECK_OSD)
                    {
                        if(E_OSD_MESSAGE_BOX == MApp_ZUI_GetActiveOSD())
                        {
                            if(msAPI_Timer_DiffTimeFromNow(u32PwdMsgToScreensaverMonitorTimer) >TIMER_DELAY_PWD_TO_SCREENSAVER)
                            {
                                u32PwdMsgToScreensaverMonitorTimer = msAPI_Timer_GetTime0();
                                MApp_ZUI_ACT_StartupOSD(E_OSD_SCREEN_SAVER);
                                SYS_SCREEN_SAVER_TYPE(eWindow) = EN_SCREENSAVER_BLOCKRATING;

                            }
                        }
                        if(MApp_ZUI_GetActiveOSD()==E_OSD_EMPTY)
                        {
                            u32PwdMsgToScreensaverMonitorTimer = msAPI_Timer_GetTime0();
                            MApp_ZUI_ACT_StartupOSD(E_OSD_MESSAGE_BOX);
                            MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_SHOW_PASSWORD_INPUT_MSGBOX);
                        }
                    }
                    else
                    {
                        u32PwdMsgToScreensaverMonitorTimer = msAPI_Timer_GetTime0();
                    }
                }
            }
            else
            {
                if(msAPI_ATV_IsProgramLocked(msAPI_ATV_GetCurrentProgramNumber())) //channel block
                {
                    if(msAPI_ATV_IsLockedCHCheckPwdSucess(msAPI_ATV_GetCurrentProgramNumber()) == FALSE)
                    {
                        if(u8CheckMode & BLOCKSYS_CHECK_OSD)
                        {
                            if(E_OSD_MESSAGE_BOX == MApp_ZUI_GetActiveOSD())
                            {
                                if(msAPI_Timer_DiffTimeFromNow(u32PwdMsgToScreensaverMonitorTimer) >TIMER_DELAY_PWD_TO_SCREENSAVER)
                                {
                                    u32PwdMsgToScreensaverMonitorTimer = msAPI_Timer_GetTime0();
                                    MApp_ZUI_ACT_StartupOSD(E_OSD_SCREEN_SAVER);
                                    SYS_SCREEN_SAVER_TYPE(eWindow) = EN_SCREENSAVER_LOCKED_PROGRAM;

                                }
                            }
                            if(MApp_ZUI_GetActiveOSD()==E_OSD_EMPTY)
                            {
                                u32PwdMsgToScreensaverMonitorTimer = msAPI_Timer_GetTime0();
                                MApp_ZUI_ACT_StartupOSD(E_OSD_MESSAGE_BOX);
                                MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_SHOW_PASSWORD_INPUT_MSGBOX);
                            }
                        }
                        else
                        {
                            u32PwdMsgToScreensaverMonitorTimer = msAPI_Timer_GetTime0();
                        }
                    }
                }
            }

        }
    }
    else if(IsStorageInUse())
    {

    }
    else
    {
        if(MApp_UiMenuFunc_CheckInputLockAudioVideo())
        {
            if(u8CheckMode & BLOCKSYS_CHECK_AV)
            {
                MApp_MuteAvByLock(E_SCREEN_MUTE_INPUT, TRUE);
            }

            if(u8CheckMode & BLOCKSYS_CHECK_OSD)
            {
                if(E_OSD_EMPTY == MApp_ZUI_GetActiveOSD())
                {
                    u32PwdMsgToScreensaverMonitorTimer = msAPI_Timer_GetTime0();
                    MApp_ZUI_ACT_StartupOSD(E_OSD_MESSAGE_BOX);
                    MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_SHOW_PASSWORD_INPUT_MSGBOX);
                }

                if(E_OSD_MESSAGE_BOX == MApp_ZUI_GetActiveOSD())
                {
                    if(msAPI_Timer_DiffTimeFromNow(u32PwdMsgToScreensaverMonitorTimer) >TIMER_DELAY_PWD_TO_SCREENSAVER)
                    {
                        u32PwdMsgToScreensaverMonitorTimer = msAPI_Timer_GetTime0();
                        MApp_ZUI_ACT_StartupOSD(E_OSD_SCREEN_SAVER);
                        SYS_SCREEN_SAVER_TYPE(eWindow) = EN_SCREENSAVER_BLOCKRATING;

                    }
                }
            }
            else
            {
                u32PwdMsgToScreensaverMonitorTimer = msAPI_Timer_GetTime0();
            }
        }
        else
        {
            if(u8CheckMode & BLOCKSYS_CHECK_AV)
            {
                if((_bPreInputLock != MApp_UiMenuFunc_CheckInputLockAudioVideo()) || (bChangeInputSrc == TRUE))
                {
                    _bPreInputLock = MApp_UiMenuFunc_CheckInputLockAudioVideo();
                    if(_bPreInputLock == FALSE)
                    {
                        msAPI_Scaler_SetScreenMute(E_SCREEN_MUTE_BLOCK, DISABLE, NULL, MAIN_WINDOW);
                        MApp_MuteAvByLock(E_SCREEN_MUTE_INPUT, FALSE);
                    }
                }
            }
        }

    }
}
void MApp_BlockSys_ResetMsgbox2ScreenSaverTimer(void)
{
    u32PwdMsgToScreensaverMonitorTimer = msAPI_Timer_GetTime0();
}
#endif
//ZUI: unused...#endif

