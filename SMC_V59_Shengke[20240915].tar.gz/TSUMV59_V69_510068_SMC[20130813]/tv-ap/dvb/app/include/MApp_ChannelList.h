////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef MAPP_CHANNEL_LIST_H
#define MAPP_CHANNEL_LIST_H

#include "MApp_UiMenuDef.h"

//*************************************************************************
//              Defines
//*************************************************************************
//ZUI: #define CHANNEL_LIST_PAGE_NUM          10
//ZUI: #define SIMILAR_LIST_PAGE_NUM          5
//ZUI: #define RECENT_LIST_PAGE_NUM           5

#define CHANNEL_LIST_INVALID_PROGINDEX     0xFFFF

//*************************************************************************
//              Enums
//*************************************************************************
#ifdef MAPP_CHANNEL_LIST_C
#define INTERFACE
#else
#define INTERFACE extern
#endif
//*************************************************************************
//              Global variables
//*************************************************************************
//*************************************************************************
//              Function prototypes
//*************************************************************************
INTERFACE void _MApp_ChannelList_ChannelChange(U16 u16ListOrdinal, U8 u8CMType, BOOLEAN bHide, E_MEMBER_PROGRAM_ACCESSIBLE_BOUNDARY eProgramAccessibleBoundary);

// ========== temp, wait for CM to give this value ==========
INTERFACE void dmSetLastWatchedOrdinal(void);
INTERFACE U16 dmGetLastWatchOrdinal(void);

#undef INTERFACE
#endif
