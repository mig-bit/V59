////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////


#define MAPP_ZUI_ACTATVMANUALTUNING_C
#define _ZUI_INTERNAL_INSIDE_ //NOTE: for ZUI internal

//-------------------------------------------------------------------------------------------------
// Include Files
//-------------------------------------------------------------------------------------------------
#include "Board.h"
#include "datatype.h"
#include "MsCommon.h"
#include "apiXC.h"
#include "apiXC_Adc.h"

#include "MApp_ZUI_Main.h"
#include "MApp_ZUI_APIcommon.h"
#include "MApp_ZUI_APIstrings.h"
#include "MApp_ZUI_APIgdi.h"
#include "MApp_ZUI_APIwindow.h"
#include "ZUI_tables_h.inl"
#include "MApp_ZUI_APIcontrols.h"
#include "MApp_ZUI_APIdraw.h"

#include "MApp_ZUI_ACTeffect.h"
#include "MApp_ZUI_ACTglobal.h"
#include "OSDcp_String_EnumIndex.h"
#include "OSDcp_Bitmap_EnumIndex.h"
#include "ZUI_exefunc.h"
#include "MApp_SignalMonitor.h"
#include "MApp_ATV_ManualTuning_Main.h"
#include "MApp_ATV_Scan.h"
#include "MApp_GlobalSettingSt.h"
#include "MApp_SaveData.h"
#include "MApp_UiMenuDef.h"
#include "msAPI_Memory.h"
#include "msAPI_FreqTableDTV.h"
#include "msAPI_ChProc.h"
#include "msAPI_ATVSystem.h"
#include "msAPI_audio.h"
#include "msAPI_Tuning.h"
#include "msAPI_VD.h"
#include "MApp_BlockSys.h"
#include "msAPI_FreqTableATV.h"
#include "msAPI_Timer.h"

#if (ENABLE_DTV)
#include "mapp_demux.h"
#include"MApp_BlockSys.h"
#include"MApp_MultiTasks.h"
#endif

#include "MApp_ChannelChange.h"
#include "MApp_ChannelList.h"
#include "MApp_GlobalFunction.h"
#include "MApp_TopStateMachine.h"
#include <stdio.h>
#include <string.h>
#include "msAPI_ATVSystem.h"
#include "msAPI_FreqTableATV.h"
#include "MApp_TopStateMachine.h"
#include "MApp_Menu_Main.h"
#include "MApp_TV.h"
#include "MApp_InputSource.h"
#include "MApp_ZUI_ACTinputsource.h"
#include "MApp_ZUI_ACTmainpage.h"
#include "msAPI_Video.h"

/////////////////////////////////////////////////////////////////////


extern EN_ATV_MANUALTUNING_STATE enAtvManualTuningState;
static EN_ATV_MANUALTUNING_STATE _enTargetAtvManualTuningState;
static U8 u8ManualScan_StoreChannel_Value;
static BOOLEAN bManualScan_Skip_IsChange;
extern BOOLEAN bIsAtuneActive;
#if ENABLE_SBTVD_BRAZIL_APP
extern E_ANTENNA_SOURCE_TYPE enLastWatchAntennaType;
#endif

//*************************************************************************
//              Defines
//*************************************************************************

typedef enum
{
    ATV_MANUAL_TUNING_COMMAND_INIT,
    ATV_MANUAL_TUNING_COMMAND_UP,
    ATV_MANUAL_TUNING_COMMAND_DOWN,
} EN_ATV_MANUAL_TUNING_COMMAND_TYPE;

typedef struct _MENU_KEY2BTN_STRUCT
{
    VIRTUAL_KEY_CODE key;
    HWND hwnd;
} MENU_KEY2BTN_STRUCT;

#define ATV_MANUAL_SCAN_DELAY 200
/********************************************************************************/
/*                    Macro                                                     */
/********************************************************************************/
#define ATV_MANUAL_TUNING_DBINFO(y)    //y
#define ATV_FREQUENCE_TENTUNING ENABLE

extern BOOLEAN _MApp_ZUI_API_AllocateVarData(void);

/********************************************************************************/
/*                      Local                                                   */
/********************************************************************************/

static void MApp_ZUI_ACT_AtvManualTuningChangeCurrentCH(U16 Value )
{
    dmSetLastWatchedOrdinal();
    MApp_ChannelChange_DisableAV(MAIN_WINDOW);

    //Cancel Freeze
    if(g_bIsImageFrozen)
    {
        g_bIsImageFrozen = FALSE;
        MApi_XC_FreezeImg(g_bIsImageFrozen, MAIN_WINDOW);
    }
    if(Value <= (msAPI_ATV_GetChannelMax()-1) && Value >= (msAPI_ATV_GetChannelMin()-1))
    {
        u8ManualScan_StoreChannel_Value = (U8)Value;
    }

    msAPI_ATV_SetCurrentProgramNumber(u8ManualScan_StoreChannel_Value);
    msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE_DURING_LIMITED_TIME, DELAY_FOR_STABLE_SIF, E_AUDIOMUTESOURCE_ACTIVESOURCE);
    //BY 20090406 msAPI_VD_AdjustVideoFactor(E_ADJUST_VIDEOMUTE_DURING_LIMITED_TIME, DELAY_FOR_STABLE_TUNER);
    msAPI_AVD_TurnOffAutoAV();
    msAPI_Tuner_ChangeProgram();
    //msAPI_VD_ClearSyncCheckCounter();
    msAPI_AVD_ClearAspectRatio();
    MApp_ChannelChange_CheckForceMode();
    MApp_CheckBlockProgramme();
    MApp_ZUI_API_InvalidateWindow(HWND_ATUNE_STORAGE_TO_OPTION);
    MApp_ZUI_API_InvalidateWindow(HWND_ATUNE_CURRENT_CH_OPTION);
    MApp_ZUI_API_InvalidateWindow(HWND_ATUNE_FREQUENCY_VALUE_TXT);
    MApp_ZUI_API_InvalidateWindow(HWND_ATUNE_SYSTEM_OPTION);
    u16IdleInputValue = 0;
    u8IdleDigitCount = 0;

}


S32 MApp_ZUI_ACT_AtvManualTuningWinProc(HWND hwnd, PMSG msg)
{
    switch(msg->message)
    {
        case MSG_CREATE:
            {

            }
            break;

        case MSG_TIMER:
            {
                MApp_ZUI_API_KillTimer(hwnd, 0);
                switch(hwnd)
                {
                    case HWND_ATUNE_FINE_TUNE_LARROW1:
                    case HWND_ATUNE_FINE_TUNE_RARROW1:
                        MApp_ZUI_API_ShowWindow(hwnd, SW_SHOW);
                    break;

                    case HWND_ATUNE_FINE_TUNE_LARROW2:
                    case HWND_ATUNE_FINE_TUNE_RARROW2:
                        MApp_ZUI_API_ShowWindow(hwnd, SW_HIDE);
                    break;
                }
                MApp_ZUI_API_InvalidateWindow(HWND_ATUNE_FREQUENCY_VALUE_TXT);
            }
            break;
        default:
            break;

    }
    return DEFAULTWINPROC(hwnd, msg);

}

BOOLEAN MApp_ZUI_ACT_ExecuteAtvManualTuningAction(U16 act)
{
    switch(act)
    {
        case EN_EXE_POWEROFF:
            MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
            _enTargetAtvManualTuningState = STATE_ATV_MANUALTUNING_GOTO_STANDBY;
            return TRUE;

        case EN_EXE_CLOSE_CURRENT_OSD:
            MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
            _enTargetAtvManualTuningState = STATE_ATV_MANUALTUNING_CLEAN_UP;
            return TRUE;

        case EN_EXE_GOTO_MAINMENU:
            MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
            _enTargetAtvManualTuningState = STATE_ATV_MANUALTUNING_GOTO_MAIN_MENU;
            return TRUE;

        case EN_EXE_DEC_STORAGE_TO_OPTION:
        case EN_EXE_INC_STORAGE_TO_OPTION:
            u8ManualScan_StoreChannel_Value =
            MApp_ZUI_ACT_DecIncValue_Cycle(
                    act==EN_EXE_INC_STORAGE_TO_OPTION,
                    u8ManualScan_StoreChannel_Value, msAPI_ATV_GetChannelMin()-1, msAPI_ATV_GetChannelMax()-1, 1);
            MApp_ZUI_API_InvalidateWindow(HWND_ATUNE_STORAGE_TO_OPTION);
            return TRUE;

        case EN_EXE_DEC_SYSTEM_OPTION:
        case EN_EXE_INC_SYSTEM_OPTION:
            {
                AUDIOSTANDARD_TYPE eSoundSystem;
                bIsAtuneActive = TRUE;
            #if ( ENABLE_DVB_TAIWAN_APP || ENABLE_SBTVD_BRAZIL_APP )
                stGenSetting.stScanMenuSetting.u8SoundSystem = EN_ATV_SystemType_M;
            #else
                stGenSetting.stScanMenuSetting.u8SoundSystem=
                        (U8) MApp_ZUI_ACT_DecIncValue_Cycle(
                                    act==EN_EXE_INC_SYSTEM_OPTION,
                                    stGenSetting.stScanMenuSetting.u8SoundSystem,
                                    EN_ATV_SystemType_BG,
                                    EN_ATV_SystemType_MAX-1,
                                    1);
            #endif

                //printf("stGenSetting.stScanMenuSetting.u8SoundSystem=%u\n", stGenSetting.stScanMenuSetting.u8SoundSystem);

                switch (stGenSetting.stScanMenuSetting.u8SoundSystem)
                {
                    case EN_ATV_SystemType_BG:
                         eSoundSystem = E_AUDIOSTANDARD_BG;
                        break;

                    case EN_ATV_SystemType_I:
                         eSoundSystem = E_AUDIOSTANDARD_I;
                        break;

                    case EN_ATV_SystemType_DK:
                         eSoundSystem = E_AUDIOSTANDARD_DK;
                        break;

                    case EN_ATV_SystemType_M:
                         eSoundSystem = E_AUDIOSTANDARD_M;
                        break;
                    case EN_ATV_SystemType_L:
                         eSoundSystem = E_AUDIOSTANDARD_L;
                        break;

                    default:
                      #if ( ENABLE_DTMB_CHINA_APP || ENABLE_ATV_CHINA_APP )
                         eSoundSystem = E_AUDIOSTANDARD_DK;
                      #else
                         eSoundSystem = E_AUDIOSTANDARD_BG;
                      #endif
                         break;
                }

                msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_INTERNAL_4_MUTEON, E_AUDIOMUTESOURCE_ATV);

                msAPI_Timer_Delayms(DELAY_FOR_ENTERING_MUTE);
                msAPI_AUD_EnableRealtimeAudioDetection(FALSE);
                msAPI_AUD_ForceAudioStandard((AUDIOSTANDARD_TYPE)eSoundSystem);
                msAPI_Tuner_UpdateMediumAndChannelNumber();
                msAPI_ATV_SetAudioStandard(msAPI_ATV_GetCurrentProgramNumber(), msAPI_AUD_GetAudioStandard());
                msAPI_Tuner_SetIF();

                msAPI_SetTunerPLL_KeepFreq();

        #if 0//((FRONTEND_IF_DEMODE_TYPE == MSTAR_VIF_MSB1210)||(FRONTEND_IF_DEMODE_TYPE == MSTAR_VIF)||(FRONTEND_IF_DEMODE_TYPE == MSTAR_INTERN_VIF))
                msAPI_SetTunerPLL();
        #endif
                msAPI_Timer_Delayms(DELAY_FOR_STABLE_SIF);
                msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_INTERNAL_4_MUTEOFF, E_AUDIOMUTESOURCE_ATV);

                stGenSetting.stScanMenuSetting.u8RFChannelNumber = msAPI_Tuner_GetChannelNumber();
                stGenSetting.stScanMenuSetting.u8ATVMediumType = (EN_ATV_BAND_TYPE)msAPI_Tuner_GetMedium();

            #if ( ENABLE_DTMB_CHINA_APP || ENABLE_DVB_TAIWAN_APP || ENABLE_ATV_CHINA_APP || ENABLE_SBTVD_BRAZIL_APP || ENABLE_DVBC_PLUS_DTMB_CHINA_APP || (TV_SYSTEM == TV_NTSC) )
                ;
            #else
                if (stGenSetting.stScanMenuSetting.u8SoundSystem == EN_ATV_SystemType_L)
                {
                    stGenSetting.stScanMenuSetting.u8LSystem = TRUE;
                }
                else
            #endif
                {
                    stGenSetting.stScanMenuSetting.u8LSystem = FALSE;
                }
                MApp_ZUI_API_InvalidateWindow(HWND_ATUNE_SYSTEM_OPTION);
            }
            return TRUE;
        case EN_EXE_DEC_COLORSYSTEM_OPTION:
        case EN_EXE_INC_COLORSYSTEM_OPTION:
            {
                #if (TV_FREQ_SHIFT_CLOCK)
                msAPI_Tuner_Patch_ResetTVShiftClk();
                #endif
            #if ( ENABLE_DVB_TAIWAN_APP || ENABLE_SBTVD_BRAZIL_APP )
                if(msAPI_ATV_IsProgramAutoColorSystem(msAPI_ATV_GetCurrentProgramNumber()))
                {
                    stGenSetting.stScanMenuSetting.u8VideoSystem_Brazil=E_VIDEOSTANDARD_BRAZIL_AUTO;
                }
                else
                {
                    switch(msAPI_ATV_GetVideoStandardOfProgram(msAPI_ATV_GetCurrentProgramNumber()))
                    {
                        case E_VIDEOSTANDARD_NTSC_M:
                            stGenSetting.stScanMenuSetting.u8VideoSystem_Brazil=E_VIDEOSTANDARD_BRAZIL_NTSC_M;
                            break;
                        case E_VIDEOSTANDARD_PAL_N:
                            stGenSetting.stScanMenuSetting.u8VideoSystem_Brazil=E_VIDEOSTANDARD_BRAZIL_PAL_N;
                            break;
                        case E_VIDEOSTANDARD_PAL_M:
                            stGenSetting.stScanMenuSetting.u8VideoSystem_Brazil=E_VIDEOSTANDARD_BRAZIL_PAL_M;
                            break;
                        default:
                            ASSERT(0);
                            stGenSetting.stScanMenuSetting.u8VideoSystem_Brazil=E_VIDEOSTANDARD_BRAZIL_NTSC_M;
                            break;
                    }
                }
                stGenSetting.stScanMenuSetting.u8VideoSystem_Brazil=
                   (U8) MApp_ZUI_ACT_DecIncValue_Cycle(
                        act==EN_EXE_INC_SYSTEM_OPTION,
                        stGenSetting.stScanMenuSetting.u8VideoSystem_Brazil,
                        E_VIDEOSTANDARD_BRAZIL_NTSC_M,
                        E_VIDEOSTANDARD_BRAZIL_AUTO,
                        1);

                if(stGenSetting.stScanMenuSetting.u8VideoSystem_Brazil==E_VIDEOSTANDARD_BRAZIL_AUTO)
                    msAPI_ATV_SetProgramAutoColorSystem(msAPI_ATV_GetCurrentProgramNumber(),TRUE);
                else
                    msAPI_ATV_SetProgramAutoColorSystem(msAPI_ATV_GetCurrentProgramNumber(),FALSE);

                msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_INTERNAL_4_MUTEON, E_AUDIOMUTESOURCE_ATV);
                msAPI_Timer_Delayms(DELAY_FOR_ENTERING_MUTE);

                switch(stGenSetting.stScanMenuSetting.u8VideoSystem_Brazil)
                {
                    case E_VIDEOSTANDARD_BRAZIL_NTSC_M:
                       msAPI_AVD_SetVideoStandard (E_VIDEOSTANDARD_NTSC_M);
                       msAPI_ATV_SetVideoStandardOfProgram(msAPI_ATV_GetCurrentProgramNumber(),E_VIDEOSTANDARD_NTSC_M);
                    break;

                    case E_VIDEOSTANDARD_BRAZIL_PAL_M:
                       msAPI_AVD_SetVideoStandard (E_VIDEOSTANDARD_PAL_M);
                       msAPI_ATV_SetVideoStandardOfProgram(msAPI_ATV_GetCurrentProgramNumber(),E_VIDEOSTANDARD_PAL_M);
                    break;

                    case E_VIDEOSTANDARD_BRAZIL_PAL_N:
                       msAPI_AVD_SetVideoStandard (E_VIDEOSTANDARD_PAL_N);
                       msAPI_ATV_SetVideoStandardOfProgram(msAPI_ATV_GetCurrentProgramNumber(),E_VIDEOSTANDARD_PAL_N);
                    break;

                    default:
                       msAPI_AVD_StartAutoStandardDetection();
                       msAPI_AVD_GetResultOfAutoStandardDetection();
                       msAPI_ATV_SetVideoStandardOfProgram(msAPI_ATV_GetCurrentProgramNumber(),msAPI_AVD_GetResultOfAutoStandardDetection());
                    break;
                }

                msAPI_Tuner_UpdateMediumAndChannelNumber();
                msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_INTERNAL_4_MUTEOFF, E_AUDIOMUTESOURCE_ATV);

                stGenSetting.stScanMenuSetting.u8RFChannelNumber = msAPI_Tuner_GetChannelNumber();
                stGenSetting.stScanMenuSetting.u8ATVMediumType = (EN_ATV_BAND_TYPE)msAPI_Tuner_GetMedium();
                stGenSetting.stScanMenuSetting.u8LSystem = FALSE;
                MApp_ZUI_API_InvalidateWindow(HWND_ATUNE_VIDEOSYSTEM_OPTION);
 #else
                AVD_VideoStandardType eVideoStandard;
                EN_ATV_COLOR_SYSTEM eColorSystem = ATV_COLOR_PAL;
                eVideoStandard = msAPI_AVD_GetVideoStandard();
               // eVideoStandard = msAPI_ATV_GetVideoStandardOfProgram(msAPI_ATV_GetCurrentProgramNumber());
                    switch( eVideoStandard )
                    {
                        case E_VIDEOSTANDARD_PAL_BGHI:
                            eColorSystem = ATV_COLOR_PAL;
                            break;
                        case E_VIDEOSTANDARD_PAL_M:
                            eColorSystem = ATV_COLOR_PAL_M;
                            break;
                        case E_VIDEOSTANDARD_PAL_N:
                            eColorSystem = ATV_COLOR_PAL_N;
                            break;
                        case E_VIDEOSTANDARD_PAL_60:
                            eColorSystem = ATV_COLOR_PAL_60;
                            break;
                        case E_VIDEOSTANDARD_NTSC_M:
                            eColorSystem = ATV_COLOR_NTSC;
                            break;
                        case E_VIDEOSTANDARD_NTSC_44:
                            eColorSystem = ATV_COLOR_NTSC_44;
                            break;
                        case E_VIDEOSTANDARD_SECAM:
                            eColorSystem = ATV_COLOR_SECAM;
                            break;
                        case E_VIDEOSTANDARD_AUTO:
                            eColorSystem = ATV_COLOR_AUTO;
                            break;
                        default:
                            break;

                    }
                eColorSystem = (EN_ATV_COLOR_SYSTEM)MApp_ZUI_ACT_DecIncValue_Cycle(
                        (BOOLEAN)(act==EN_EXE_INC_COLORSYSTEM_OPTION),(U16)eColorSystem,
                        (U16)ATV_COLOR_PAL,(U16)ATV_COLOR_SECAM,1);
                      //printf("==eColorSystem=%d==\n",eColorSystem);
                 switch(eColorSystem)
                {
                    case ATV_COLOR_PAL:
                        eVideoStandard = E_VIDEOSTANDARD_PAL_BGHI;
                        break;
                    case ATV_COLOR_PAL_M:
                        eVideoStandard = E_VIDEOSTANDARD_PAL_M;
                        break;
                    case ATV_COLOR_PAL_N:
                        eVideoStandard = E_VIDEOSTANDARD_PAL_N;
                        break;
                    case ATV_COLOR_PAL_60:
                        eVideoStandard = E_VIDEOSTANDARD_PAL_60;
                        break;
                    case ATV_COLOR_NTSC:
                        eVideoStandard = E_VIDEOSTANDARD_NTSC_M;
                        break;
                    case ATV_COLOR_NTSC_44:
                        eVideoStandard = E_VIDEOSTANDARD_NTSC_44;
                        break;
                    case ATV_COLOR_SECAM:
                        eVideoStandard = E_VIDEOSTANDARD_SECAM;
                        break;
                    case ATV_COLOR_AUTO:
                    default:
                        eVideoStandard = E_VIDEOSTANDARD_AUTO;
                        break;
                }

                if(eVideoStandard == E_VIDEOSTANDARD_AUTO)
                {
                    AVD_VideoStandardType eStandard;
                    MDrv_AVD_SetVideoStandard(eVideoStandard, FALSE);
                    msAPI_AVD_StartAutoStandardDetection();
                    eStandard = msAPI_AVD_GetStandardDetection();
                 #if ENABLE_CH_FORCEVIDEOSTANDARD
                    msAPI_ATV_SetForceVideoStandardFlag(msAPI_ATV_GetCurrentProgramNumber(), FALSE);
                 #endif
                }
                else
                {
                    msAPI_AVD_ForceVideoStandard(eVideoStandard);
                    MDrv_AVD_SetVideoStandard(eVideoStandard, FALSE );
                    msAPI_ATV_SetVideoStandardOfProgram(msAPI_ATV_GetCurrentProgramNumber(), eVideoStandard);
                 #if ENABLE_CH_FORCEVIDEOSTANDARD
                    msAPI_ATV_SetForceVideoStandardFlag(msAPI_ATV_GetCurrentProgramNumber(), TRUE);
                 #endif
                }
                MApp_ZUI_API_InvalidateWindow(HWND_ATUNE_VIDEOSYSTEM_OPTION);
#endif
            }
            return TRUE;
        case EN_EXE_DEC_CURRENT_CH_OPTION:
        case EN_EXE_INC_CURRENT_CH_OPTION:
            {
                bIsAtuneActive = FALSE;
                dmSetLastWatchedOrdinal();
                MApp_ChannelChange_DisableAV(MAIN_WINDOW);

                //Cancel Freeze
                if(g_bIsImageFrozen)
                {
                    g_bIsImageFrozen = FALSE;
                    MApi_XC_FreezeImg(g_bIsImageFrozen, MAIN_WINDOW);
                }

                u8ManualScan_StoreChannel_Value =
                MApp_ZUI_ACT_DecIncValue_Cycle(
                        act==EN_EXE_INC_CURRENT_CH_OPTION,
                        msAPI_ATV_GetCurrentProgramNumber(), msAPI_ATV_GetChannelMin()-1, msAPI_ATV_GetChannelMax()-1, 1);
                MApp_ZUI_API_InvalidateWindow(HWND_ATUNE_CURRENT_CH_OPTION);

                msAPI_ATV_SetCurrentProgramNumber(u8ManualScan_StoreChannel_Value);
                msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE_DURING_LIMITED_TIME, DELAY_FOR_STABLE_SIF, E_AUDIOMUTESOURCE_ACTIVESOURCE);
                //BY 20090406 msAPI_VD_AdjustVideoFactor(E_ADJUST_VIDEOMUTE_DURING_LIMITED_TIME, DELAY_FOR_STABLE_TUNER);
                msAPI_AVD_TurnOffAutoAV();
                msAPI_Tuner_ChangeProgram();
                //msAPI_VD_ClearSyncCheckCounter();
                msAPI_AVD_ClearAspectRatio();
                MApp_CheckBlockProgramme();
                MApp_ChannelChange_CheckForceMode();
                MApp_ZUI_API_InvalidateWindow(HWND_ATUNE_STORAGE_TO_OPTION);
                MApp_ZUI_API_InvalidateWindow(HWND_ATUNE_CURRENT_CH_OPTION);
                MApp_ZUI_API_InvalidateWindow(HWND_ATUNE_VIDEOSYSTEM_OPTION);
                MApp_ZUI_API_InvalidateWindow(HWND_ATUNE_FREQUENCY_VALUE_TXT);
                MApp_ZUI_API_InvalidateWindow(HWND_ATUNE_SYSTEM_OPTION);
            }
            return TRUE;

        case EN_EXE_GOTO_SCAN_DEC:
            enAtvManualTuningState = STATE_ATV_MANUALTUNING_GOTO_ATV_SCAN;
            bIsAtuneActive = FALSE;
            MApp_ATV_Scan_State_Init();
          #if ( ENABLE_DVB_TAIWAN_APP || ENABLE_SBTVD_BRAZIL_APP )
            msAPI_ATV_SetDirectTuneFlag(FALSE);
          #endif
            stGenSetting.stScanMenuSetting.u8ScanType = SCAN_TYPE_MANUAL;
            stGenSetting.stScanMenuSetting.u8ATVManScanType = ATV_MAN_SCAN_TYPE_ONECH;
            stGenSetting.stScanMenuSetting.u8ATVManScanDir = ATV_MAN_SCAN_DOWN;
            MApp_ZUI_API_ShowWindow(HWND_ATUNE_SEARCH_RARROW1, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_ATUNE_SEARCH_LARROW2, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_ATUNE_FREQUENCY_VALUE_TXT, SW_SHOW);
            u8IdleDigitCount = 0;
            u16IdleInputValue = 0;
            MApp_ZUI_API_KillTimer(HWND_ATUNE_BG_PANE, 0);
            return TRUE;

        case EN_EXE_GOTO_SCAN_INC:
            enAtvManualTuningState = STATE_ATV_MANUALTUNING_GOTO_ATV_SCAN;
            bIsAtuneActive = FALSE;
            MApp_ATV_Scan_State_Init();
          #if ( ENABLE_DVB_TAIWAN_APP || ENABLE_SBTVD_BRAZIL_APP )
            msAPI_ATV_SetDirectTuneFlag(FALSE);
          #endif
            stGenSetting.stScanMenuSetting.u8ScanType = SCAN_TYPE_MANUAL;
            stGenSetting.stScanMenuSetting.u8ATVManScanType = ATV_MAN_SCAN_TYPE_ONECH;
            stGenSetting.stScanMenuSetting.u8ATVManScanDir = ATV_MAN_SCAN_UP;
            MApp_ZUI_API_ShowWindow(HWND_ATUNE_SEARCH_LARROW1, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_ATUNE_SEARCH_RARROW2, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_ATUNE_FREQUENCY_VALUE_TXT, SW_SHOW);
            u8IdleDigitCount = 0;
            u16IdleInputValue = 0;
            MApp_ZUI_API_KillTimer(HWND_ATUNE_BG_PANE, 0);
            return TRUE;

        case EN_EXE_ATV_MANUAL_SCAN_SHOW_INFO:
            MApp_ZUI_API_InvalidateWindow(HWND_ATUNE_FREQUENCY_VALUE_TXT);
            return TRUE;

        case EN_EXE_ATV_MANUAL_SCAN_END:
            MApp_ZUI_API_ShowWindow(HWND_ATUNE_SEARCH_LARROW1, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_ATUNE_SEARCH_RARROW1, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_ATUNE_SEARCH_LARROW2, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_ATUNE_SEARCH_RARROW2, SW_HIDE);
            MApp_ZUI_API_InvalidateWindow(HWND_ATUNE_SYSTEM_OPTION);
            MApp_ZUI_API_InvalidateWindow(HWND_ATUNE_VIDEOSYSTEM_OPTION);
            MApp_ZUI_API_InvalidateWindow(HWND_ATUNE_FREQUENCY_VALUE_TXT);
            MApp_ZUI_API_SetTimer(HWND_ATUNE_BG_PANE, 0, MENU_TIME_OUT_MS);
            msAPI_Scaler_SetBlueScreen( DISABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
            return TRUE;

        case EN_EXE_ATV_MANUAL_SCAN_FINETUNE_UP:
            bIsAtuneActive = FALSE;
            MApp_ZUI_API_ShowWindow(HWND_ATUNE_FINE_TUNE_LARROW1, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_ATUNE_FINE_TUNE_RARROW2, SW_SHOW);
            if(g_bIsImageFrozen)
            {
                g_bIsImageFrozen = FALSE;
                MApi_XC_FreezeImg(g_bIsImageFrozen, MAIN_WINDOW);
            }
            msAPI_Tuner_AdjustUnlimitedFineTune(DIRECTION_UP);
            MApp_ZUI_API_SetTimer(HWND_ATUNE_FINE_TUNE_LARROW1, 0, ATV_MANUAL_SCAN_DELAY);
            MApp_ZUI_API_SetTimer(HWND_ATUNE_FINE_TUNE_RARROW2, 0, ATV_MANUAL_SCAN_DELAY);
            MApp_ZUI_API_InvalidateWindow(HWND_ATUNE_FREQUENCY_VALUE_TXT);
            return TRUE;

        case EN_EXE_ATV_MANUAL_SCAN_FINETUNE_DOWN:
            bIsAtuneActive = FALSE;
            MApp_ZUI_API_ShowWindow(HWND_ATUNE_FINE_TUNE_RARROW1, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_ATUNE_FINE_TUNE_LARROW2, SW_SHOW);
            if(g_bIsImageFrozen)
            {
                g_bIsImageFrozen = FALSE;
                MApi_XC_FreezeImg(g_bIsImageFrozen, MAIN_WINDOW);
            }
            msAPI_Tuner_AdjustUnlimitedFineTune(DIRECTION_DOWN);
            MApp_ZUI_API_SetTimer(HWND_ATUNE_FINE_TUNE_RARROW1, 0, ATV_MANUAL_SCAN_DELAY);
            MApp_ZUI_API_SetTimer(HWND_ATUNE_FINE_TUNE_LARROW2, 0, ATV_MANUAL_SCAN_DELAY);
            MApp_ZUI_API_InvalidateWindow(HWND_ATUNE_FREQUENCY_VALUE_TXT);
            return TRUE;

        case EN_EXE_CHANGE_CURRENT_CH:
        {
            U16 InputValue;
            if( u8IdleDigitCount != 0 )
            {
                InputValue = u16IdleInputValue ;

                //SHIFT 1 Start channl is 1 not 0,
                if(InputValue != 0)
                    InputValue = InputValue -1;

                MApp_ZUI_ACT_AtvManualTuningChangeCurrentCH(InputValue);

                u8IdleDigitCount =0;
            }
        }
        return TRUE;

        case EN_EXE_CHANGE_CURRENT_CH_KEY_0:
        case EN_EXE_CHANGE_CURRENT_CH_KEY_1:
        case EN_EXE_CHANGE_CURRENT_CH_KEY_2:
        case EN_EXE_CHANGE_CURRENT_CH_KEY_3:
        case EN_EXE_CHANGE_CURRENT_CH_KEY_4:
        case EN_EXE_CHANGE_CURRENT_CH_KEY_5:
        case EN_EXE_CHANGE_CURRENT_CH_KEY_6:
        case EN_EXE_CHANGE_CURRENT_CH_KEY_7:
        case EN_EXE_CHANGE_CURRENT_CH_KEY_8:
        case EN_EXE_CHANGE_CURRENT_CH_KEY_9:
        {
            if(MApp_ZUI_API_GetFocus() == HWND_ATUNE_CURRENT_CH)
            {
                 if (u8IdleDigitCount == 0)
                     u16IdleInputValue = 0;

                u16IdleInputValue = u16IdleInputValue * 10 + (act - EN_EXE_CHANGE_CURRENT_CH_KEY_0);
                u8IdleDigitCount++;

		#if ENABLE_SBTVD_BRAZIL_APP
		//CABLE:CH 13~ CH 100 direct change,CH 1 ~ CH 12 Must press Enter to Change
		if(msAPI_ATV_GetCurrentAntenna() == ANT_CATV)
		{
			if (u8IdleDigitCount >= 3 || (u8IdleDigitCount >= 2 && u16IdleInputValue >12))
	                {
	                    U16 InputValue;
	                    InputValue = u16IdleInputValue ;
	                    //SHIFT 1 Start channl is 1 not 0,
	                    if(InputValue != 0)
	                    {
	                        InputValue = InputValue -1;
	                    }

	                    MApp_ZUI_ACT_AtvManualTuningChangeCurrentCH(InputValue);
	                }
		}
		else
		#endif
                // CH 11~ CH 100 direct change,CH 1 ~ CH 10 Must press Enter to Change
		{
                if (u8IdleDigitCount >= 3 || (u8IdleDigitCount >= 2 && u16IdleInputValue >10))
                {
                    U16 InputValue;
                    InputValue = u16IdleInputValue ;
                    //SHIFT 1 Start channl is 1 not 0,
                    if(InputValue != 0)
                    {
                        InputValue = InputValue -1;
                    }

                    MApp_ZUI_ACT_AtvManualTuningChangeCurrentCH(InputValue);
                }
                }

                MApp_ZUI_API_InvalidateWindow(HWND_ATUNE_STORAGE_TO_OPTION);
                MApp_ZUI_API_InvalidateWindow(HWND_ATUNE_CURRENT_CH_OPTION);
                MApp_ZUI_API_InvalidateWindow(HWND_ATUNE_FREQUENCY_VALUE_TXT);
            }

        #if ATV_FREQUENCE_TENTUNING
            if(MApp_ZUI_API_GetFocus() == HWND_ATUNE_SEARCH)
            {
                if (u8IdleDigitCount == 0)
                    u16IdleInputValue = 0;

                u16IdleInputValue = u16IdleInputValue * 10 + (act - EN_EXE_CHANGE_CURRENT_CH_KEY_0);
                u8IdleDigitCount++;

                if(u8IdleDigitCount > 3)
                {
                    u16IdleInputValue = u16IdleInputValue%10;
                    u8IdleDigitCount = 1;
                }

                MApp_ZUI_API_InvalidateWindow(HWND_ATUNE_FREQUENCY_VALUE_TXT);
            }
        #endif
        }
        return TRUE;

    #if ATV_FREQUENCE_TENTUNING
        case EN_EXE_SET_MANUAL_SCAN:
            if (u8IdleDigitCount > 0 )
            {
                u16IdleInputValue = msAPI_Tuner_SetSearchManualTune(u16IdleInputValue);
                u8IdleDigitCount = 0;
                MApp_ZUI_API_InvalidateWindow(HWND_ATUNE_FREQUENCY_VALUE_TXT);
            }
            break;
    #endif

        case EN_EXE_SAVE_ATV_MANUAL_SCAN:
            {
                BOOLEAN bSkipFlag;

                if((BYTE)u8ManualScan_StoreChannel_Value != msAPI_ATV_GetCurrentProgramNumber())
                {
                    msAPI_ATV_SaveProgram((BYTE) u8ManualScan_StoreChannel_Value);
                }
                else
                {
                    bSkipFlag = msAPI_ATV_IsProgramSkipped(u8ManualScan_StoreChannel_Value);
                    msAPI_ATV_SaveProgram(u8ManualScan_StoreChannel_Value);

                    if(bManualScan_Skip_IsChange == TRUE)
                        msAPI_ATV_SkipProgram(u8ManualScan_StoreChannel_Value, bSkipFlag);
                    else
                        msAPI_ATV_SkipProgram(u8ManualScan_StoreChannel_Value, FALSE);
                }
            #if ENABLE_SBTVD_BRAZIL_CM_APP
                if(ANT_AIR == msAPI_ATV_GetCurrentAntenna())
                    msAPI_CHPROC_CM_InitOridial();
            #endif
                bManualScan_Skip_IsChange = FALSE;
                MApp_ZUI_API_InvalidateWindow(HWND_ATUNE_CURRENT_CH_OPTION);
            }
            return TRUE;

        default:
            break;


    }
    return FALSE;
}

void MApp_ZUI_ACT_TerminateAtvManualTuning(void)
{
    //printf("[]term:atv manual tuning\n");
   #if ( ENABLE_DVB_TAIWAN_APP || ENABLE_SBTVD_BRAZIL_APP || (TV_SYSTEM == TV_NTSC) )
    msAPI_ATV_SaveProgram_Exit_Menu((BYTE) msAPI_ATV_GetCurrentProgramNumber());
   #endif
    enAtvManualTuningState = _enTargetAtvManualTuningState;
}

BOOLEAN MApp_ZUI_ACT_HandleAtvManualTuningKey(VIRTUAL_KEY_CODE key)
{
    //reset timer if any key
    MApp_ZUI_API_ResetTimer(HWND_ATUNE_BG_PANE, 0);

    switch(key)
    {
        case VK_EXIT:
            MApp_ZUI_ACT_ExecuteAtvManualTuningAction(EN_EXE_CLOSE_CURRENT_OSD);
            return TRUE;

        case VK_POWER:
            MApp_ZUI_ACT_ExecuteAtvManualTuningAction(EN_EXE_POWEROFF);
            return TRUE;

        case VK_MENU:
            MApp_ZUI_ACT_ExecuteAtvManualTuningAction(EN_EXE_GOTO_MAINMENU);
            _enReturnMenuItem = STATE_RETURN_ATV_MANUAL_TUNING;
            return TRUE;

        case VK_UP:
            if( u8IdleDigitCount != 0 )
            {
                u8IdleDigitCount = 0;
                u16IdleInputValue = 0;
                MApp_ZUI_API_InvalidateWindow(HWND_ATUNE_FREQUENCY_VALUE_TXT);
            }
            return FALSE;

        case VK_DOWN:
            if( u8IdleDigitCount != 0 )
            {
                u8IdleDigitCount = 0;
                u16IdleInputValue = 0;
                MApp_ZUI_API_InvalidateWindow(HWND_ATUNE_FREQUENCY_VALUE_TXT);
            }
            return FALSE;
        default:
            break;

    }
    return FALSE;
}

static U16 _MApp_ZUI_ACT_AtvManualTuningGetProgramNumber(void)
{
    return ((U16)msAPI_ATV_GetCurrentProgramNumber());
}

LPTSTR MApp_ZUI_ACT_GetAtvManualTuningDynamicText(HWND hwnd)
{
    switch(hwnd)
    {
        case HWND_ATUNE_STORAGE_TO_OPTION:
            {
                U16 curStringLen = 0;
                U8 digit;

                MApp_ZUI_API_Strcpy(&CHAR_BUFFER[0], MApp_ZUI_API_GetString(en_strChannel_AtvScan_StorageTo));
                curStringLen = MApp_ZUI_API_Strlen(CHAR_BUFFER);
                CHAR_BUFFER[curStringLen] = CHAR_SPACE;
                curStringLen +=1;
                digit = MApp_GetNoOfDigit(u8ManualScan_StoreChannel_Value+1);
                __MApp_UlongToString(u8ManualScan_StoreChannel_Value+1, (CHAR_BUFFER+curStringLen), digit);
                curStringLen +=digit;
                CHAR_BUFFER[curStringLen] = 0;
                return (LPTSTR) CHAR_BUFFER;
            }
            break;

        case HWND_ATUNE_CURRENT_CH_OPTION:
            {
                U16 curStringLen = 0;
                U8 digit;

                MApp_ZUI_API_Strcpy(&CHAR_BUFFER[0], MApp_ZUI_API_GetString(en_strChannel_AtvScan_CurrentChText));
                curStringLen = MApp_ZUI_API_Strlen(CHAR_BUFFER);
                CHAR_BUFFER[curStringLen] = CHAR_SPACE;
                curStringLen +=1;

                if( IsATVInUse() )
                {
                    if( u8IdleDigitCount == 0 )
                    {
                        digit = MApp_GetNoOfDigit(_MApp_ZUI_ACT_AtvManualTuningGetProgramNumber()+1);
                        __MApp_UlongToString(_MApp_ZUI_ACT_AtvManualTuningGetProgramNumber()+1, (CHAR_BUFFER+curStringLen), digit);
                    }
                    else
                    {
                        digit = MApp_GetNoOfDigit(u16IdleInputValue);
                        __MApp_UlongToString(u16IdleInputValue, (CHAR_BUFFER+curStringLen), digit);
                    }
                    curStringLen +=digit;
                    CHAR_BUFFER[curStringLen] = 0;
                    return (LPTSTR) CHAR_BUFFER;
                }
                else
                {
                    __MApp_UlongToString(0, (CHAR_BUFFER+curStringLen), 1);
                    curStringLen += 1;
                    CHAR_BUFFER[curStringLen] = 0;
                    return (LPTSTR) CHAR_BUFFER;
                }
            }
            break;

        case HWND_ATUNE_SYSTEM_OPTION:
        {
            U16 u16StrID = Empty;
            U16 curStringLen=0;
            U16 u16StrBuf[32];

            //printf("HWND_ATUNE_SYSTEM_OPTION:\n");
            //printf("stGenSetting.stScanMenuSetting.u8SoundSystem=%u\n", stGenSetting.stScanMenuSetting.u8SoundSystem);

           if( stGenSetting.stScanMenuSetting.u8SoundSystem == EN_ATV_SystemType_BG )
               u16StrID=en_str_BG;
           else if( stGenSetting.stScanMenuSetting.u8SoundSystem == EN_ATV_SystemType_I )
               u16StrID=en_str_I;
           else if( stGenSetting.stScanMenuSetting.u8SoundSystem == EN_ATV_SystemType_DK )
               u16StrID=en_str_DK;
        //#if ( ENABLE_DTMB_CHINA_APP || ENABLE_DVB_TAIWAN_APP || ENABLE_ATV_CHINA_APP || ENABLE_SBTVD_BRAZIL_APP || ENABLE_DVBC_PLUS_DTMB_CHINA_APP || (TV_SYSTEM == TV_NTSC) )
           else if( stGenSetting.stScanMenuSetting.u8SoundSystem == EN_ATV_SystemType_M )
               u16StrID=en_str_M;
       //#else
           else if( stGenSetting.stScanMenuSetting.u8SoundSystem == EN_ATV_SystemType_L )
               u16StrID=en_str_L;
        //#endif

            //printf("u16StrID=%u;\n", u16StrID);

           MApp_ZUI_API_Strcpy(u16StrBuf, MApp_ZUI_API_GetString(en_strManualScan_SystemText));
           curStringLen = MApp_ZUI_API_Strlen(u16StrBuf);
           u16StrBuf[curStringLen] = CHAR_SPACE;
           curStringLen +=1;
           MApp_ZUI_API_Strcpy(&u16StrBuf[curStringLen], MApp_ZUI_API_GetString(u16StrID));
           MApp_ZUI_API_Strcpy(CHAR_BUFFER, u16StrBuf);
           curStringLen = MApp_ZUI_API_Strlen(CHAR_BUFFER);
           CHAR_BUFFER[curStringLen] = 0;
           return (LPTSTR) CHAR_BUFFER;
           }
            break;

        case HWND_ATUNE_VIDEOSYSTEM_OPTION:
            {
                U16 u16StrID = Empty;
                U16 curStringLen=0;
                AVD_VideoStandardType eVideoStandard;
                eVideoStandard = msAPI_AVD_GetVideoStandard();
               // eVideoStandard = msAPI_ATV_GetVideoStandardOfProgram(msAPI_ATV_GetCurrentProgramNumber());
                switch( eVideoStandard )
                {
                    case E_VIDEOSTANDARD_PAL_BGHI:
                        u16StrID=en_str_PAL;
                        break;
                    case E_VIDEOSTANDARD_PAL_M:
                        u16StrID=en_str_PAL_M;
                        break;
                    case E_VIDEOSTANDARD_PAL_N:
                        u16StrID=en_str_PAL_N;
                        break;
                    case E_VIDEOSTANDARD_PAL_60:
                        u16StrID=en_str_PAL_60;
                        break;
                    case E_VIDEOSTANDARD_NTSC_M:
                        u16StrID=en_str_NTSC;
                        break;
                    case E_VIDEOSTANDARD_NTSC_44:
                        u16StrID=en_str_NTSC_44;
                        break;
                    case E_VIDEOSTANDARD_SECAM:
                        u16StrID=en_str_SECAM;
                        break;
                    default:
                        u16StrID=en_str_AUTO;
                        break;
                }
                MApp_ZUI_API_GetString(u16StrID);
                curStringLen = MApp_ZUI_API_Strlen(CHAR_BUFFER);
                CHAR_BUFFER[curStringLen] = 0;
                return (LPTSTR) CHAR_BUFFER;
            }
            break;

        case HWND_ATUNE_FREQUENCY_VALUE_TXT:
            {
                WORD wTunerPLL,wTunerPLLI,wTunerPLLF;
                LPTSTR str = CHAR_BUFFER;
                U8 u8Index;
                WORD wPLL;
                U8 u8CurrentProgramNumber;

                u8CurrentProgramNumber = msAPI_ATV_GetCurrentProgramNumber();

                wPLL = msAPI_ATV_GetProgramPLLData(u8CurrentProgramNumber);

                MApp_ZUI_API_Strcpy(&str[0], MApp_ZUI_API_GetString(en_strManualScan_FrequencyText));
                u8Index = MApp_ZUI_API_Strlen(str);
                str[u8Index] = CHAR_SPACE;
                u8Index += 1;

                wTunerPLL = msAPI_Tuner_GetCurrentChannelPLL();
                wTunerPLLI = msAPI_CFT_ConvertPLLtoIntegerOfFrequency(wTunerPLL);
                wTunerPLLF = msAPI_CFT_ConvertPLLtoFractionOfFrequency(wTunerPLL);

            #if ATV_FREQUENCE_TENTUNING
                if(MApp_ZUI_API_GetFocus() == HWND_ATUNE_SEARCH && u8IdleDigitCount != 0)
                {
                    __MApp_UlongToString((U32)u16IdleInputValue, (str+(U16)(u8Index)), u8IdleDigitCount);
                    u8Index += u8IdleDigitCount;

                    str[u8Index++] = '.';
                    str[u8Index++] = '0';
                    str[u8Index++] = '0';
                    str[u8Index++] = CHAR_SPACE;
                    str[u8Index++] = CHAR_M;
                    str[u8Index++] = CHAR_H;
                    str[u8Index++] = CHAR_z;
                }
                else if( MApp_TopStateMachine_GetTopState()!= STATE_TOP_ATV_SCAN  &&
                    wTunerPLL == DEFAULT_PLL ) //DEFAULT_PLL
            #else
                if( MApp_TopStateMachine_GetTopState()!= STATE_TOP_ATV_SCAN  &&
                    wTunerPLL == DEFAULT_PLL ) //DEFAULT_PLL
            #endif
                { /* Unregistered */ // if support multi OSD languages, the string need be add to string file
                    str[u8Index++] = 'U';
                    str[u8Index++] = 'n';
                    str[u8Index++] = 'r';
                    str[u8Index++] = 'e';
                    str[u8Index++] = 'g';
                    str[u8Index++] = 'i';
                    str[u8Index++] = 's';
                    str[u8Index++] = 't';
                    str[u8Index++] = 'e';
                    str[u8Index++] = 'r';
                    str[u8Index++] = 'e';
                    str[u8Index++] = 'd';
                }
                else
                {
                    str[u8Index++] = ((wTunerPLLI/100) == 0) ? ' ' : '0'+(wTunerPLLI/100);
                    str[u8Index++] = '0'+((wTunerPLLI%100)/10);
                    str[u8Index++] = '0'+(wTunerPLLI%10);
                    str[u8Index++] = '.';
                    str[u8Index++] = '0'+(wTunerPLLF/100);
                    str[u8Index++] = '0'+((wTunerPLLF%100)/10);
                    str[u8Index++] = CHAR_SPACE;
                    str[u8Index++] = CHAR_M;
                    str[u8Index++] = CHAR_H;
                    str[u8Index++] = CHAR_z;
                }
                str[u8Index++] = 0;
                return CHAR_BUFFER;
            }
            break;
        default:
            break;
    }

// Market it by coverity_0514
#if 0//UI2 NoNeed
    if (u16TempID != Empty)
        return MApp_ZUI_API_GetString(u16TempID);
#endif

    return 0; //for empty string....
}

void MApp_ZUI_ACT_AppShowAtvManualTuning(void)
{
    HWND wnd;
    RECT rect;
    E_OSD_ID osd_id = E_OSD_ATV_MANUAL_TUNING;

    g_GUI_WindowList = GetWindowListOfOsdTable(osd_id);
    g_GUI_WinDrawStyleList = GetWindowStyleOfOsdTable(osd_id);
    g_GUI_WindowPositionList = GetWindowPositionOfOsdTable(osd_id);
#if ZUI_ENABLE_ALPHATABLE
    g_GUI_WinAlphaDataList = GetWindowAlphaDataOfOsdTable(osd_id);
#endif
    HWND_MAX = GetWndMaxOfOsdTable(osd_id);
    OSDPAGE_BLENDING_ENABLE = IsBlendingEnabledOfOsdTable(osd_id);
    OSDPAGE_BLENDING_VALUE = GetBlendingValueOfOsdTable(osd_id);

    // clean digital key count and buffer
    u8IdleDigitCount = 0;
    u16IdleInputValue = 0;

    if (!_MApp_ZUI_API_AllocateVarData())
    {
        ZUI_DBG_FAIL(printf("[ZUI]ALLOC\n"));
        ABORT();
        return;
    }

    RECT_SET(rect,
        ZUI_ATV_MANUAL_TUNING_XSTART, ZUI_ATV_MANUAL_TUNING_YSTART,
        ZUI_ATV_MANUAL_TUNING_WIDTH, ZUI_ATV_MANUAL_TUNING_HEIGHT);

    if (!MApp_ZUI_API_InitGDI(&rect))
    {
        ZUI_DBG_FAIL(printf("[ZUI]GDIINIT\n"));
        ABORT();
        return;
    }
#if (ENABLE_DTV)
    if(TRUE == MApp_Get_ParentalBlock_state())
    {
        MApp_ParentalControl_SetBlockStatus(FALSE);
        MApp_Set_ParentalBlock_state(DISABLE);
    }
#endif
#if ENABLE_SBTVD_BRAZIL_APP
    if ( UI_INPUT_SOURCE_TYPE != UI_INPUT_SOURCE_ATV&&IsDTVInUse())
    {
        if(UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_DTV && msAPI_VID_GetPlayMode()== MSAPI_VID_PLAY)
        {
             msAPI_VID_Command(MSAPI_VID_STOP);
        }
       // msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_MOMENT_MUTEON, E_AUDIOMUTESOURCE_ACTIVESOURCE);
        if(msAPI_ATV_GetCurrentAntenna()==ANT_CATV)
        {
            msAPI_ATV_SetCurrentAntenna(ANT_AIR);
        }
        UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_ATV;
        enLastWatchAntennaType = ANTENNA_ATV_TYPE;
        MApp_InputSource_SwitchSource(UI_INPUT_SOURCE_ATV, MAIN_WINDOW);
        //msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_MOMENT_MUTEOFF, E_AUDIOMUTESOURCE_ACTIVESOURCE);
    }
#else
    if ( UI_INPUT_SOURCE_TYPE != UI_INPUT_SOURCE_ATV )
    {
        if(UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_DTV && msAPI_VID_GetPlayMode()== MSAPI_VID_PLAY)
        {
             msAPI_VID_Command(MSAPI_VID_STOP);
        }

        MApp_ZUI_ACT_InputSourceSwitch( UI_INPUT_SOURCE_ATV );
    }
#endif
    u8ManualScan_StoreChannel_Value = _MApp_ZUI_ACT_AtvManualTuningGetProgramNumber();

    for (wnd = 0; wnd < HWND_MAX; wnd++)
    {
        MApp_ZUI_API_SendMessage(wnd, MSG_CREATE, 0);
    }

    MApp_ZUI_API_ShowWindow(HWND_MAINFRAME, SW_SHOW);
    MApp_ZUI_API_ShowWindow(HWND_ATUNE_PAGE_LIST,SW_HIDE);
    MApp_ZUI_API_ShowWindow(HWND_ATUNE_SEARCH_LARROW2, SW_HIDE);
    MApp_ZUI_API_ShowWindow(HWND_ATUNE_SEARCH_RARROW2, SW_HIDE);
    MApp_ZUI_API_ShowWindow(HWND_ATUNE_FINE_TUNE_LARROW2, SW_HIDE);
    MApp_ZUI_API_ShowWindow(HWND_ATUNE_FINE_TUNE_RARROW2, SW_HIDE);
    MApp_ZUI_API_ShowWindow(HWND_ATUNE_PAGE_LIST,SW_SHOW);
    MApp_ZUI_API_SetFocus(HWND_ATUNE_STORAGE_TO);

    //MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_PAGE_SHOWUP, E_ZUI_STATE_RUNNING);
}
GUI_ENUM_DYNAMIC_LIST_STATE MApp_ZUI_ACT_QueryAtvManualTuningStatus(HWND hwnd)
{
    switch(hwnd)
    {
        case HWND_ATUNE_STORAGE_TO:
        case HWND_ATUNE_SYSTEM:
        case HWND_ATUNE_CURRENT_CH:
		case HWND_ATUNE_FINE_TUNE:
		   return EN_DL_STATE_NORMAL;
		   break;
		case HWND_ATUNE_SEARCH:
		#if(ENABLE_SBTVD_BRAZIL_APP)
		   return EN_DL_STATE_HIDDEN;
		#else
			return EN_DL_STATE_NORMAL;
		#endif
		   break;
        default:
            return EN_DL_STATE_NORMAL;
			break;
    }
}


#undef MAPP_ZUI_ACTATVMANUALTUNING_C
