////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef MAPP_GLOBAL_FUNCTION_H
#define MAPP_GLOBAL_FUNCTION_H

#include "datatype.h"
#include "MApp_GlobalSettingSt.h"
#include "msAPI_DTVSystem.h"

#if (ENABLE_DTV)
#include "mapp_si.h"
#endif

#if ENABLE_TTX // helen add for TTX
#include "msAPI_TTX.h"
#endif

#include "msAPI_Power.h"
/********************************************************************************/
/*                     Macro                    */
/* ******************************************************************************/
#define SECONDS_PER_HALF_MIN    30L
#define SECONDS_PER_MIN         60L
#define SECONDS_PER_HOUR        3600L
#define SECONDS_PER_HALF_HOUR   1800L
#define SECONDS_PER_DAY         86400L
#define SECONDS_PER_30DAYS      (30*SECONDS_PER_DAY)
#define MINS_PER_HOUR           60
#define HOURS_PER_DAY           24

#define XDATA_WIN1_SIZE         0x1000

#define OSD_COUNTRY_SETTING     MApp_GetOSDCountrySetting()

//*************************************************************************
//          Function prototypes
//*************************************************************************
#ifdef MAPP_GLOBAL_FUNCTION_C
#define INTERFACE
#else
#define INTERFACE extern
#endif


#if (KEEP_UNUSED_FUNC == 1)
INTERFACE U16 msAPI_OSD_u16Strlen ( U16 *pu16Str );
//INTERFACE void msAPI_OSD_u16Strcpy ( U16 *pu16Dest, U16 *pu16Src );
INTERFACE S8 msAPI_OSD_u16Strcmp ( U16 *u16strA, U16 *u16strB );
#endif
INTERFACE U8 MApp_GetNoOfDigit ( U32 u32Data );
INTERFACE void MApp_UlongToU16String ( U32 ulValue, U16 *pArrOutput, S8 NoOfDigit );
INTERFACE void MApp_UlongToU8String ( U32 ulValue, U8 *pArrOutput, S8 NoOfDigit );
INTERFACE void MApp_U8StringToU16String ( U8 *pu8Str, U16 *pu16Str, U8 u8Strlen );

INTERFACE U32 MApp_U8StringToUlong(U8* InputStr, U8 len);

INTERFACE U8 MApp_GetNoOfHexDigit ( U32 u32Data );
INTERFACE void MApp_HexUlongToU16String ( U32 ulValue, U16 *pArrOutput, S8 NoOfDigit );
INTERFACE void MApp_HexUlongToU8String ( U32 ulValue, U8 *pArrOutput, S8 NoOfDigit );


INTERFACE U8 MApp_GetLeap ( U16 u16year );
INTERFACE void MApp_SetToDefaultSystemTime ( ST_TIME *pstTime );
//INTERFACE void MApp_MJDUTC2Date(U8 *pau8TDTData, ST_TIME *pstTime);
//INTERFACE U32 MApp_MJDUTC2Seconds ( U8 *pau8TDTData );
INTERFACE U32 MApp_ConvertStTime2Seconds ( ST_TIME *pstTime );
INTERFACE void MApp_ConvertSeconds2StTime ( U32 u32SystemTime, ST_TIME *pstTime);

INTERFACE S32 MApp_GetTimeZoneOffset ( U8 u8TimeZone );
INTERFACE U32 MApp_GetLocalSystemTime (void);
INTERFACE void MApp_SetLocalSystemTime (U32 u32LocalSystemTime);
INTERFACE U32 MApp_GetLocalWakeUpTime (void);
INTERFACE void MApp_SetLocalWakeUpTime (U32 u32LocalWakeUpTime);

INTERFACE U8 MApp_CalSummerTimeOffset(U8 *L_MJDUTC);
INTERFACE void MApp_CalDefaultTimeOffest(void);
INTERFACE U8 MApp_GetDaysOfThisMonth ( U16 u16Year, U8 u8Month );
INTERFACE U8 MApp_GetDayOfWeek(U16 u16Year, U8 u8Month, U8 u8Day);

INTERFACE BOOLEAN MApp_IsSrcHasSignal(SCALER_WIN eWindow);
INTERFACE U32 MApp_MJD2Sec(U8 *pu8MJD);
INTERFACE U32 MApp_MJDUTC2Seconds(U8 *pau8TDTData);
INTERFACE void MApp_Seconds2MJDUTC ( U32 u32TotalSeconds, U8 *pau8TDTData );
INTERFACE U32 MApp_UTC2Seconds ( U8 *pau8TDTData );
INTERFACE void MApp_Seconds2UTC ( U32 u32TotalSeconds, U8 *pau8TDTData );
INTERFACE EN_OSD_COUNTRY_SETTING MApp_GetOSDCountrySetting(void);
INTERFACE void MApp_SetOSDCountrySetting(EN_OSD_COUNTRY_SETTING eCountry, BOOLEAN bSave);
INTERFACE void MApp_SetTimezoneOfCurrentCountry(U8 u8Country);

INTERFACE void MApp_SetOnTimer(MENU_OnTimer eOnTimerDate);
INTERFACE MENU_OnTimer MApp_GetOnTimer(void);
INTERFACE void MApp_SetDayOfWeek(DAYOFWEEK eDayOfWeek);

INTERFACE EN_LANGUAGE MApp_GetMenuLanguage(void);
INTERFACE EN_LANGUAGE MApp_GetMenuLanguage_DTG(void);
INTERFACE EN_MENU_TIMEZONE MApp_GetTimeZone_DTG(void);
INTERFACE EN_LANGUAGE MApp_GetAudioLangMenuLanguage_DTG(void);
INTERFACE EN_LANGUAGE MApp_GetSubLangMenuLanguage_DTG(void);
INTERFACE void MApp_SetMenuLanguage(EN_LANGUAGE eLanguage);
INTERFACE void MApp_SetTimeZone(EN_MENU_TIMEZONE eTimezone);
INTERFACE void MApp_SetAudioLangMenuLanguage(EN_LANGUAGE eLanguage);
INTERFACE void MApp_SetSubLangMenuLanguage(EN_LANGUAGE eLanguage);
INTERFACE U8 MApp_ASCII2INT(U8 buf);
INTERFACE void MApp_AddDay2StTime ( U16 u16DaysToAdd, ST_TIME *pstTime );
#if ENABLE_DTV
INTERFACE BOOLEAN MApp_UiMenuFunc_IsSystemClockSet(void);
INTERFACE EN_SI_Clock_TimeZone MApp_GetSIClockTimeZone(EN_MENU_Clock_TimeZone eClockTimeZone);
INTERFACE void MApp_SetClockTimezoneByTimezone(EN_MENU_TIMEZONE eTimezone);
INTERFACE EN_SI_TIMEZONE MApp_GetSITimeZone(EN_MENU_TIMEZONE eTimeZone);
INTERFACE EN_SI_LANGUAGE MApp_GetSILanguage(EN_LANGUAGE eLanguage);
INTERFACE EN_LANGUAGE MApp_GetLanguageBySILanguage(EN_SI_LANGUAGE eLanguage);
#endif
INTERFACE void MApp_SetVCOM(BYTE bvalue);
#if ENABLE_TTX // helen add for TTX
INTERFACE TT_Charset_Group MApp_GetTTXLang(void) ;
INTERFACE void MApp_SetTTXLang(TT_Charset_Group eLanguage);

#endif

#if (ENABLE_NONLINEAR_CURVE)
INTERFACE U8 MApp_NonLinearCalculate(P_MS_USER_NONLINEAR_CURVE pNonLinearCurve, U8 AdjustValue);
INTERFACE P_MS_USER_NONLINEAR_CURVE MApp_GetNonLinearCurve(EN_MS_NONLINEAR_CURVE eNonLinearCurveIndex);
#if (ENABLE_SOUND_NONLINEAR_CURVE_TEN)
INTERFACE P_MS_USER_NONLINEAR_CURVE_TEN MApp_GetNonLinearCurveTen(EN_MS_NONLINEAR_CURVE eNonLinearCurveIndex);
#endif

#endif

#if ENABLE_DTV
INTERFACE EN_SI_COUNTRY_SETTING MApp_GetSICountry(EN_OSD_COUNTRY_SETTING eOSDCountrySetting);
#endif

#if (BOE_VOLUME_CURVE)
INTERFACE U8 MApp_NonLinearVOLCalculate(P_MS_USER_NONLINEAR_VOLCURVE pNonLinearVOLCurve, U8 AdjustValue);
INTERFACE P_MS_USER_NONLINEAR_VOLCURVE MApp_GetNonLinearVOLCurve(EN_MS_NONLINEAR_VOLCURVE eNonLinearVOLCurveIndex);
#endif

#undef INTERFACE
#endif
