////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#define MAPP_ZUI_ACTMENUDLGFUNC_C
#define _ZUI_INTERNAL_INSIDE_ //NOTE: for ZUI internal


//-------------------------------------------------------------------------------------------------
// Include Files
//-------------------------------------------------------------------------------------------------
#include "Board.h"
#include "datatype.h"
#include "MsCommon.h"
#include "GPIO.h"                   //For audio
#include "apiXC.h"
#include "apiXC_Adc.h"
#include "apiXC_Sys.h"
#include "msAPI_audio.h"
#include "MApp_GlobalSettingSt.h"
#include "MApp_ZUI_Main.h"
#include "MApp_ZUI_APIcommon.h"
#include "MApp_ZUI_APIstrings.h"
#include "MApp_ZUI_APIwindow.h"
#include "ZUI_tables_h.inl"
#include "MApp_ZUI_APIgdi.h"
#include "MApp_ZUI_APIcontrols.h"
#include "MApp_ZUI_APIcomponent.h"

#include "MApp_ZUI_APIalphatables.h"
#include "MApp_ZUI_ACTmainpage.h"
#include "MApp_ZUI_ACTeffect.h"
#include "MApp_ZUI_APIdraw.h"
#include "MApp_ZUI_ACTglobal.h"
#include "drvUART.h"


#include "OSDcp_String_EnumIndex.h"
#include "ZUI_exefunc.h"

#include "MApp_ZUI_ACTmenudlgfunc.h"
#include "MApp_UiMenuDef.h"
#include "MApp_RestoreToDefault.h"
#include "MApp_Scaler.h"
#include "MApp_XC_PQ.h"
#include "MApp_SaveData.h"
#include "MApp_ATVProc.h"
#include "msAPI_Global.h"
#include "MApp_ChannelChange.h"
#include "SysInit.h"
#include <stdio.h>
#include <string.h>
#include "msAPI_Memory.h"
#include "msAPI_MIU.h"
#include "MApp_DataBase.h"
#include "MApp_USBDownload.h"
#include "msAPI_Bootloader.h"
#include "msAPI_OCP.h"
#include "drvGPIO.h"
#include "msAPI_Timer.h"
#if ENABLE_DMP
#include "MApp_DMP_Main.h"
#endif
#include "MApp_InputSource.h"
#include "MApp_TopStateMachine.h"
#include "MApp_CADTV_Proc.h"
#include "MApp_Menu_Main.h"
#include "MApp_ZUI_ACTcoexistWin.h"
#include "msAPI_Flash.h"
#include "MApp_ChannelList.h"
#include "MApp_ZUI_ACTmainpage_predit.h"
#if ENABLE_CUS_RS232_FUNC
#include "afm.h"
#endif
#include "msAPI_Tuning.h"

#define FACTORY_RESET_USER      0x04
#define FACTORY_RESET_INCLUDE_ADC      0x10
#define FACTORY_RESET_INCLUDE_WB      0x20
#define FACTORY_RESET_ALL      0x30
#define FACTORY_RESET_EXCEPT_WB_ADC      0x40
#define FACTORY_RESET_CUSTOMER_MODE     0x80

///////////////////////////////////////////////////
extern EN_MENU_STATE enMainMenuState;
extern COMMON_DLG_MODE _eCommonDlgMode;
extern U16 _MApp_ZUI_API_FindFirstComponentIndex(HWND hWnd, DRAWSTYLE_TYPE type, DRAWCOMPONENT comp);
extern void _MApp_ZUI_API_ConvertTextComponentToDynamic(U16 u16TextOutIndex, DRAW_TEXT_OUT_DYNAMIC * pComp);
extern void _MApp_ZUI_ACT_OpenCommonDialog(COMMON_DLG_MODE dlg);
void _MApp_ZUI_API_ForceUpdateWindows(HWND aUpdateWindows[],U8 WinCount);
void MApp_ZUI_SwUpdate_ProgressBar(U8 percent);
extern void  MApp_ZUI_ACT_SetTargetMenuState(EN_MENU_STATE MenuState);
extern void msAPI_ATV_Factory_CH_Preset(void);

static U8 USB_Upgrade_Percent = 0xFF;
//static U8 USB_Upgrade_Percent1 = 0;

//////////////////////////////////////////
//for factory reset
static BOOLEAN MApp_ZUI_ACT_FactoryReset_VideoReset(void)
{
    MApp_DataBase_RestoreDefaultVideo(DATA_INPUT_SOURCE_TYPE(MAIN_WINDOW));

    //MApp_DataBase_PictureResetWhiteBalance(DATA_INPUT_SOURCE_TYPE(MAIN_WINDOW));

    MApp_Picture_Setting_SetColor(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW), MAIN_WINDOW);  //MApp_PicSetVideo(SYS_INPUT_SOURCE_TYPE, &ST_VIDEO );

    MApp_Scaler_Setting_SetVDScale(ST_VIDEO.eAspectRatio, MAIN_WINDOW);

#if (IR_TYPE_SEL == IR_TYPE_SZ_ALC1)//ALC 20071109
    SET_OSD_MENU_LANGUAGE(LANGUAGE_DEFAULT); // menu language
#endif
       if(g_bIsImageFrozen)//zsx-20100519
            {
                g_bIsImageFrozen = FALSE;
                MApi_XC_FreezeImg(g_bIsImageFrozen, MAIN_WINDOW);
            }
    return TRUE;
}

static BOOLEAN MApp_ZUI_ACT_FactoryReset_SoundReset(void)
{
    MApp_DataBase_RestoreDefaultAudio();
    return TRUE;
}


//static void MApp_ZUI_ACT_FactoryReset(BOOLEAN bRunInstallguide)
void MApp_ZUI_ACT_FactoryReset(U8 u8ResetType)
{

    MS_DEBUG_MSG(printf(">>>>>>>MApp_ZUI_ACT_FactoryReset\n"));

    // set Audio Mute
    msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_PERMANENT_MUTEON, E_AUDIOMUTESOURCE_ACTIVESOURCE);
    msAPI_Timer_Delayms(10);//DELAY_FOR_ENTERING_MUTE);

#if !(AUDIO_EN_CONTROL_DISABLE) // CUS_XM Sea 20120615
    MUTE_On();
#endif


#if !(AUDIO_EN_CONTROL_DISABLE) // CUS_XM Sea 20120615
    Audio_Amplifier_OFF();
#endif


    // set Video Mute
    msAPI_Scaler_SetScreenMute(E_SCREEN_MUTE_PERMANENT, ENABLE, 0, MAIN_WINDOW);
    msAPI_Scaler_SetScreenMute(E_SCREEN_MUTE_PERMANENT, ENABLE, 0, SUB_WINDOW);
    MS_DEBUG_MSG(printf(">>>>>>>msAPI_Scaler_SetScreenMute(E_SCREEN_MUTE_PERMANENT, ENABLE, 100, MAIN_WINDOW);  \n"));
	msAPI_ATV_SetCurrentProgramNumber(msAPI_ATV_GetChannelMin()-1);//set first channel num

    if (u8ResetType == FACTORY_RESET_INCLUDE_ADC)
    {
        MApp_DataBase_RestoreFactoryDefault(RESTORE_GENSETTING);
        MS_DEBUG_MSG(printf(">>>>>>> MApp_DataBase_RestoreFactoryDefault(RESTORE_GENSETTING);\n"));

        MApp_DataBase_RestoreFactoryDefault(RESTORE_DATABASE_INCLUDE_ADC);
        MS_DEBUG_MSG(printf(">>>>>>> MApp_DataBase_RestoreFactoryDefault(RESTORE_DATABASE_EXCEPT_ADC);\n"));
    }
    else if (u8ResetType == FACTORY_RESET_INCLUDE_WB)
    {
        MApp_DataBase_RestoreFactoryDefault(RESTORE_GENSETTING);
        MS_DEBUG_MSG(printf(">>>>>>> MApp_DataBase_RestoreFactoryDefault(RESTORE_GENSETTING);\n"));

        MApp_DataBase_RestoreFactoryDefault(RESTORE_DATABASE_INCLUDE_WB);
        MS_DEBUG_MSG(printf(">>>>>>> MApp_DataBase_RestoreFactoryDefault(RESTORE_DATABASE_EXCEPT_ADC);\n"));
    }
    else if (u8ResetType == FACTORY_RESET_EXCEPT_WB_ADC)
    {
		 //if(stGenSetting.g_SysSetting.uUartPortConect!=3)
		 {
			 stGenSetting.g_SysSetting.uUartPortConect = 3;
			 MDrv_UART_Init(E_UART_AEON_R2, 115200);
			 #if (CHIP_FAMILY_TYPE == CHIP_FAMILY_M10 || CHIP_FAMILY_TYPE == CHIP_FAMILY_M12)
			 mdrv_uart_connect(E_UART_PORT0, E_UART_OFF);
			 #else
			 mdrv_uart_connect(E_UART_PORT0, E_UART_OFF);
			 #endif
			 MApp_SaveSysSetting();
		 }		
#ifdef ENABLE_CUS_FACTORY_ATV_CH_PRSET
	   stGenSetting.g_SysSetting.uFactoryChannelFlag = FALSE;
	   msAPI_ATV_ResetATVDataManager();
	   msAPI_ATV_SetCurrentProgramNumber(msAPI_ATV_GetChannelMin()-1);//set first channel num		 
	   printf("msAPI_ATV_ResetATVDataManager");
	   //msAPI_Tuner_ChangeProgram();
#endif
        MApp_DataBase_RestoreFactoryDefault(RESTORE_GENSETTING);
        MS_DEBUG_MSG(printf(">>>>>>> MApp_DataBase_RestoreFactoryDefault(RESTORE_GENSETTING);\n"));

        MApp_DataBase_RestoreFactoryDefault(RESTORE_DATABASE_EXCEPT_WB_ADC);
        MS_DEBUG_MSG(printf(">>>>>>> MApp_DataBase_RestoreFactoryDefault(RESTORE_DATABASE_EXCEPT_ADC);\n"));
		
    }
    else if (u8ResetType == FACTORY_RESET_ALL)
    {
		//if(stGenSetting.g_SysSetting.uUartPortConect)
		{
		stGenSetting.g_SysSetting.uUartPortConect = 0;
		MDrv_UART_Init(E_UART_AEON_R2, 115200);
#if (CHIP_FAMILY_TYPE == CHIP_FAMILY_M10 || CHIP_FAMILY_TYPE == CHIP_FAMILY_M12)
		mdrv_uart_connect(E_UART_PORT0, E_UART_AEON_R2);
#else
		mdrv_uart_connect(E_UART_PORT0, E_UART_PIU_UART0);
#endif
		}		
#ifdef ENABLE_CUS_FACTORY_ATV_CH_PRSET
		msAPI_ATV_Factory_CH_Preset();
		stGenSetting.g_SysSetting.uFactoryChannelFlag = TRUE;
		//printf("\nMin chan num  %d \n", msAPI_ATV_GetChannelMin());	
		msAPI_ATV_SetCurrentProgramNumber(msAPI_ATV_GetChannelMin()-1);//set first channel num		  
#endif
        MApp_DataBase_RestoreFactoryDefault(RESTORE_GENSETTING);
        MS_DEBUG_MSG(printf(">>>>>>> MApp_DataBase_RestoreFactoryDefault(RESTORE_GENSETTING);\n"));

        MApp_DataBase_RestoreFactoryDefault(RESTORE_DATABASE);
		

        MS_DEBUG_MSG(printf(">>>>>>> MApp_DataBase_RestoreFactoryDefault(RESTORE_DATABASE);\n"));
    }
    else if (u8ResetType == FACTORY_RESET_CUSTOMER_MODE)
    {
        MApp_DataBase_RestoreFactoryDefault(RESTORE_GENSETTING_CUSTOMER_MODE);
        MS_DEBUG_MSG(printf(">>>>>>> MApp_DataBase_RestoreFactoryDefault(RESTORE_GENSETTING_TCL_MODE);\n"));

        MApp_DataBase_RestoreFactoryDefault(RESTORE_DATABASE_CUSTOMER_MODE);
        MS_DEBUG_MSG(printf(">>>>>>> MApp_DataBase_RestoreFactoryDefault(RESTORE_DATABASE_EXCEPT_ADC);\n"));
    }
    MApp_ZUI_ACT_ShutdownOSD();
    MS_DEBUG_MSG(printf(">>>>>>>MApp_ZUI_ACT_ShutdownOSD\n"));
  #if (EEPROM_DB_STORAGE == EEPROM_SAVE_NONE)
    //store to flash immediately
    MApp_DB_SaveNowGenSetting();
  #endif

    //smc.chy 2010/10/12 for factory reset have white flash
    MApi_PNL_SetBackLight(DISABLE);  
    msAPI_Timer_Delayms(300);

    MDrv_Sys_WholeChipReset();
}
static void MApp_ZUI_ACT_FactorySystemReset(void)
{
    //Factory default
    MApp_ZUI_ACT_FactoryReset_VideoReset();
			// CUS_XM Xue 20120811: XF112PIOCNMS0-781
			 //MUTE_On();
#if 0
		msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_BYUSER_MUTEON, E_AUDIOMUTESOURCE_ACTIVESOURCE);//Mute before reset audio
#endif
	MApp_ZUI_ACT_FactoryReset_SoundReset();
    MApp_ZUI_ACT_FactoryReset(0x30);

}
//static void MApp_ZUI_ACT_UserSettingReset(void)
void MApp_ZUI_ACT_UserSettingReset(void)
{
    MS_DEBUG_MSG(printf(">>>>>>>MApp_ZUI_ACT_UserSettingReset\n"));
	
         //if(stGenSetting.g_SysSetting.uUartPortConect!=3)
		 {
			stGenSetting.g_SysSetting.uUartPortConect = 3;
			MDrv_UART_Init(E_UART_AEON_R2, 115200);
#if (CHIP_FAMILY_TYPE == CHIP_FAMILY_M10 || CHIP_FAMILY_TYPE == CHIP_FAMILY_M12)
            mdrv_uart_connect(E_UART_PORT0, E_UART_OFF);
#else
            mdrv_uart_connect(E_UART_PORT0, E_UART_OFF);
#endif
			MApp_SaveSysSetting();
         }			
	
    //menu default
    MApp_ZUI_ACT_FactoryReset_VideoReset();

		msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_BYUSER_MUTEON, E_AUDIOMUTESOURCE_ACTIVESOURCE);//Mute before reset audio

	//MApp_ZUI_ACT_FactoryReset_SoundReset();
	MApp_DataBase_RestoreUserSettingDefault(RESTORE_USERSETTING);

		msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_BYUSER_MUTEOFF, E_AUDIOMUTESOURCE_ACTIVESOURCE);//Mute before reset audio

    #if ENABLE_T_C_COMBO
    MApp_CATV_RestoreManutuning_settingDefault();
    #endif
    //*************************************************************************
    // Restore default source
    //*************************************************************************
/*
       UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_ATV;
	UI_PREV_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_ATV;
	#if ENABLE_DMP
        if(UI_INPUT_SOURCE_TYPE != UI_INPUT_SOURCE_DMP
            && IsStorageInUse())
        {
            MApp_DMP_Exit();
        }
    #if( ENABLE_DMP_SWITCH )
        if(UI_INPUT_SOURCE_TYPE != UI_INPUT_SOURCE_DMP1
            && IsStorageInUse())
        {
            MApp_DMP_Exit();
        }
        if(UI_INPUT_SOURCE_TYPE != UI_INPUT_SOURCE_DMP2
            && IsStorageInUse())
        {
            MApp_DMP_Exit();
        }
   #endif
   #endif
    MApp_InputSource_ChangeInputSource(MAIN_WINDOW);
    MApp_ChannelChange_VariableInit();
*/
    #if (ENABLE_DTV)
    stGenSetting.fRunInstallationGuide =TRUE;
    if( stGenSetting.fRunInstallationGuide )
    {
        MApp_TopStateMachine_SetTopState(STATE_TOP_INSTALLGUIDE);
    }
    #else
    //stGenSetting.fRunInstallationGuide =FALSE;
    //MApp_TopStateMachine_SetTopState(STATE_TOP_CHANNELCHANGE);
    #endif
    //enMainMenuState=STATE_MENU_INIT;
    //MApp_ZUI_ACT_SetTargetMenuState(STATE_MENU_INIT);

    #if ENABLE_CI_PLUS
    //for clear CI key setting informations
    MApp_DataBase_RestoreDefaultCI();
    MApp_SaveCISetting();
    #endif

}

//CUS_XM:xue add for factory RC RST key 2012-6-14
/*
void Mapp_FactoryRCRST(void)
{
	printf("handle FactoryRC RST key/r/n");

    if(MApp_ZUI_ACT_ExecuteMenuCommonDialogAction(EN_EXE_FACTORY_SYSTEM_RESET))
    {

    	printf("factory reset OK");
    }
    else
    {
        printf("factory reset fail");
    }


}

*/

BOOLEAN MApp_ZUI_ACT_ExecuteMenuCommonDialogAction(U16 act)
{
    //mapping generic command to specific action...
    if (act == EN_EXE_CLOSE_CURRENT_OSD)
    {
        switch(_eCommonDlgMode)
        {
            case EN_COMMON_DLG_MODE_FACTORY_RESET:
            case EN_COMMON_DLG_MODE_FACTORY_RESET_CONFIRM:
                act = EN_EXE_CLOSE_FACTORY_RESET_CONFIRM_DLG;
                break;
			case EN_COMMON_DLG_MODE_CLEAN_LOCK:
                act = EN_EXE_CLOSE_CLEAN_ALL_DLG;
				break;
            case EN_COMMON_DLG_MODE_CH_LIST_CLEAN_ALL_CONFIRM:
                act = EN_EXE_CLOSE_CH_LIST_CLEAN_ALL_DLG;
                break;
            case EN_COMMON_DLG_MODE_CHANNEL_INFO_SAVE_CHANGED:
                act = EN_EXE_CLOSE_CH_INFO_SAVE_CHANGED_DLG;
                break;
            case EN_COMMON_DLG_MODE_USB_UPDATE_CONFIRM:
                act = EN_EXE_CLOSE_USB_UPGRADE_CONFIRM_DLG;
                break;
            case EN_COMMON_DLG_MODE_DIVX:
                act = EN_EXE_CLOSE_DIVX_CONFIRM_DLG;
                break;
            case EN_COMMON_DLG_MODE_DEACTIVATION:
            case EN_COMMON_DLG_MODE_DEACTIVATION_CONFIRM:
                act = EN_EXE_CLOSE_DEACTIVATION_CONFIRM_DLG;
                break;

            case EN_COMMON_DLG_MODE_MISMATCH_PASSWORD:
                act = EN_EXE_CLOSE_MISMATCH_PASSWORD_DLG;
                break;

            case EN_COMMON_DLG_MODE_WRONG_PASSWORD:
                act = EN_EXE_CLOSE_WRONG_PASSWORD_DLG;
                break;

            case EN_COMMON_DLG_MODE_SET_PASSWORD:
                act = EN_EXE_CLOSE_SET_PASSWORD_DLG;
                break;

            case EN_COMMON_DLG_MODE_INPUT_PASSWORD:
            case EN_COMMON_DLG_MODE_SCAN_INPUT_PASSWORD:
            case EN_COMMON_DLG_MODE_DTV_TUNING_INPUT_PASSWORD:
            case EN_COMMON_DLG_MODE_ATV_TUNING_INPUT_PASSWORD:
            case EN_COMMON_DLG_MODE_FACTORY_RESET_INPUT_PASSWORD:
            case EN_COMMON_DLG_MODE_ENTER_MENU_LOCK_PAGE_INPUT_PASSWORD:
                act = EN_EXE_CLOSE_INPUT_PASSWORD_DLG;
                break;
            default:
                break;
        }
    }

    switch(act)
    {
        case EN_EXE_CLOSE_FACTORY_RESET_CONFIRM_DLG:
            //if (_eCommonDlgMode != EN_COMMON_DLG_MODE_FACTORY_RESET_CONFIRM)
            //    return TRUE;

            _eCommonDlgMode = EN_COMMON_DLG_MODE_INVALID;
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_BACKGROUND, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_MENU_MASK_BACKGROUND, SW_SHOW);
            MApp_ZUI_ACT_InitializeMainMenu();
            MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_SETUP, FALSE);
            //////////////////////////////////////////
            #if(UI_SKIN_SEL==UI_SKIN_1366X768X565_HAIER_CN)  // CUS_xm zHIHE 20120807 modify
			MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_SETUP_BIG, FALSE);// CUS_xm zHIHE 20120807 modify
			#endif
            MApp_ZUI_API_ShowWindow(HWND_MENU_OPTION_PAGE, SW_SHOW);
            //MApp_ZUI_API_SetFocus(HWND_MENU_OPTION_FACTORY_RESET);
            MApp_ZUI_CTL_DynamicListSetItemFocus(HWND_MENU_OPTION_PAGE_LIST,HWND_MENU_OPTION_FACTORY_RESET);
            //MApp_ZUI_API_SetFocus(_hwndCommonDlgPrevFocus);
            //MApp_ZUI_API_RestoreFocusCheckpoint();
            return TRUE;
		case EN_EXE_CLOSE_CLEAN_ALL_DLG:
            _eCommonDlgMode = EN_COMMON_DLG_MODE_INVALID;
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_BACKGROUND, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_MENU_MASK_BACKGROUND, SW_SHOW);
            MApp_ZUI_ACT_InitializeMainMenu();
            MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_LOCK, FALSE);
			#if(UI_SKIN_SEL==UI_SKIN_1366X768X565_HAIER_CN)  // CUS_xm zHIHE 20120807 modify
			MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_LOCK_BIG, FALSE); // CUS_xm zHIHE 20120807 modify
			#endif
            MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_SUBPAGE, SW_SHOW);
            MApp_ZUI_API_SetFocus(HWND_MENU_LOCK_MAINSUBPAGE_ITEM_CLEAN_ALL);
            //MApp_ZUI_API_SetFocus(_hwndCommonDlgPrevFocus);
            //MApp_ZUI_API_RestoreFocusCheckpoint();
            return TRUE;
		case EN_EXE_CLEAN_ALL_LOCK:

            _eCommonDlgMode = EN_COMMON_DLG_MODE_INVALID;
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON, SW_HIDE);
            MApp_ChannelChange_VariableInit();
			if(IsAnyTVSourceInUse())
			    MApp_TopStateMachine_SetTopState(STATE_TOP_CHANNELCHANGE);
			else
			    MApp_TopStateMachine_SetTopState(STATE_TOP_ANALOG_SHOW_BANNER);
            enMainMenuState=STATE_MENU_INIT;
            MApp_ZUI_ACT_SetTargetMenuState(STATE_MENU_INIT);
            return TRUE;
        case EN_EXE_CLOSE_CH_LIST_CLEAN_ALL_DLG:
            _eCommonDlgMode = EN_COMMON_DLG_MODE_INVALID;
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON, SW_HIDE);
            //MApp_ZUI_ACT_ShowMainMenuBackground(HWND_MENU_BOTTOM_BALL_FOCUS_OPTION);
            MApp_ZUI_API_ShowWindow(HWND_MENU_BACKGROUND, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_MENU_MASK_BACKGROUND, SW_SHOW);
            MApp_ZUI_ACT_InitializeMainMenu();
            MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_CHANNEL, FALSE);
			#if(UI_SKIN_SEL==UI_SKIN_1366X768X565_HAIER_CN)  // CUS_xm zHIHE 20120807 modify
			MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_CHANNEL_BIG, FALSE); //CUS_XM ZHIHE 20120809
			#endif
            MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_PAGE, SW_SHOW);
            MApp_ZUI_API_SetFocus(HWND_MENU_CHANNEL_CLEAN_CH_LIST);
            return TRUE;
        case EN_EXE_CLOSE_CH_INFO_SAVE_CHANGED_DLG:
            _eCommonDlgMode = EN_COMMON_DLG_MODE_INVALID;
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_BACKGROUND, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_MENU_MASK_BACKGROUND, SW_SHOW);
            MApp_ZUI_ACT_InitializeMainMenu();
            MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_CHANNEL, FALSE);
			#if(UI_SKIN_SEL==UI_SKIN_1366X768X565_HAIER_CN)  // CUS_xm zHIHE 20120807 modify
			MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_CHANNEL_BIG, FALSE); //CUS_XM ZHIHE 20120809
			#endif
            MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_INFO_PAGE, SW_HIDE);
            //MApp_ZUI_ACT_ShowMainMenuBackground(HWND_MENU_BOTTOM_BALL_FOCUS_OPTION);
            MApp_ZUI_API_ShowWindow(HWND_MENU_PREDIT_CHANNEL_LIST_PAGE, SW_SHOW);
            MApp_ZUI_ACT_Mainpage_AppShowProgramEdit();
            return TRUE;

#if (ENABLE_CUS_UI_SPEC == DISABLE) /*Creass.liu at 2012-06-02*/
        case EN_EXE_CLOSE_DIVX_CONFIRM_DLG:
            _eCommonDlgMode = EN_COMMON_DLG_MODE_INVALID;
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON, SW_HIDE);
            //MApp_ZUI_ACT_ShowMainMenuBackground(HWND_MENU_BOTTOM_BALL_FOCUS_OPTION);
            MApp_ZUI_API_ShowWindow(HWND_MENU_OPTION_PAGE, SW_SHOW);
            MApp_ZUI_API_SetFocus(HWND_MENU_OPTION_DIVX);
            return TRUE;

        case EN_EXE_CLOSE_DEACTIVATION_CONFIRM_DLG:
            _eCommonDlgMode = EN_COMMON_DLG_MODE_INVALID;
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON, SW_HIDE);
            //MApp_ZUI_ACT_ShowMainMenuBackground(HWND_MENU_BOTTOM_BALL_FOCUS_OPTION);
            MApp_ZUI_API_ShowWindow(HWND_MENU_OPTION_PAGE, SW_SHOW);
            MApp_ZUI_API_SetFocus(HWND_MENU_OPTION_DEACTIVATION);
            return TRUE;
#endif
        case EN_EXE_CLOSE_USB_UPGRADE_CONFIRM_DLG:
            _eCommonDlgMode = EN_COMMON_DLG_MODE_INVALID;
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON, SW_HIDE);
            //MApp_ZUI_ACT_ShowMainMenuBackground(HWND_MENU_BOTTOM_BALL_FOCUS_CHANNEL);
            MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_PAGE, SW_SHOW);
            MApp_ZUI_API_SetFocus(HWND_MENU_CHANNEL_SW_USB_UPGRADE);
            {
                     MS_VE_Output_Ctrl OutputCtrl;
                     // enable VE
                     OutputCtrl.bEnable = TRUE;
                     msAPI_VE_SetOutputCtrl(&OutputCtrl);
                     // enable DNR buffer
                     MApi_XC_DisableInputSource(FALSE, MAIN_WINDOW);
                     MW_AUD_SetSoundMute(SOUND_MUTE_ALL, E_MUTE_OFF);
                 }
            return TRUE;
        case EN_EXE_FACTORY_RESET_ALL:
            if (_eCommonDlgMode != EN_COMMON_DLG_MODE_FACTORY_RESET)
                return TRUE;

            {//Factory default
                MApp_ZUI_ACT_FactoryReset_VideoReset();
                msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_BYUSER_MUTEON, E_AUDIOMUTESOURCE_ACTIVESOURCE);//Mute before reset audio
                MApp_ZUI_ACT_FactoryReset_SoundReset();
            }

            MApp_ZUI_ACT_FactoryReset(FACTORY_RESET_ALL);

            _eCommonDlgMode = EN_COMMON_DLG_MODE_INVALID;
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON, SW_HIDE);

            MApp_ZUI_API_RestoreFocusCheckpoint();
            return TRUE;


        case EN_EXE_FACTORY_RESET:
            if (_eCommonDlgMode != EN_COMMON_DLG_MODE_FACTORY_RESET)
                return TRUE;

            {//Factory default
                MApp_ZUI_ACT_FactoryReset_VideoReset();
	// CUS_XM Xue 20120811: ���빤����EEPROM Init/System Reset�����muteͼ�� XF112PIOCNMS0-793
	
     Audio_Amplifier_OFF();
 	 //MUTE_On();
	
	
#if 0
				  msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_BYUSER_MUTEON, E_AUDIOMUTESOURCE_ACTIVESOURCE);//Mute before reset audio
#endif
MApp_ZUI_ACT_FactoryReset_SoundReset();
            }

			MApp_ZUI_ACT_FactoryReset(FACTORY_RESET_EXCEPT_WB_ADC);

            _eCommonDlgMode = EN_COMMON_DLG_MODE_INVALID;
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON, SW_HIDE);

            MApp_ZUI_API_RestoreFocusCheckpoint();
            return TRUE;

	    //cus_xm gary 20120614 add for systemreset
	    case EN_EXE_FACTORY_SYSTEM_RESET:
            g_bFactoryResetMode=FALSE;
            MApp_ZUI_ACT_FactorySystemReset();
            return TRUE;

        case EN_EXE_RS232_CMD_FACTORY_SYSTEM_RESET:
            #if ENABLE_CUS_RS232_FUNC
            if(IsAfmMode())
            {
                MApp_ZUI_ACT_FactoryReset_VideoReset();
                msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_BYUSER_MUTEON, E_AUDIOMUTESOURCE_ACTIVESOURCE);//Mute before reset audio
                MApp_ZUI_ACT_FactoryReset_SoundReset();

                MApp_ZUI_ACT_FactoryReset(FALSE);
                return TRUE;
            }
            #endif
            break;
        case EN_EXE_RS232_CMD_FACTORY_USER_RESET:
            #if ENABLE_CUS_RS232_FUNC
            if(IsAfmMode())
            {
                MApp_ZUI_ACT_UserSettingReset();
                return TRUE;
            }
            #endif
            break;
        case EN_EXE_USER_SETTING_RESET:
            if (_eCommonDlgMode != EN_COMMON_DLG_MODE_FACTORY_RESET)
                return TRUE;
            MApp_ZUI_ACT_UserSettingReset();

            _eCommonDlgMode = EN_COMMON_DLG_MODE_INVALID;
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON, SW_HIDE);
			MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_CLOSE_CURRENT_OSD);
            //enMainMenuState=STATE_MENU_CLEAN_UP;
            //MApp_ZUI_ACT_SetTargetMenuState(STATE_MENU_INIT);
            return TRUE;
        case EN_EXE_DO_CLEAN_CH_LIST:
            if(IsAnyTVSourceInUse())
            {
                #if (ENABLE_DTV)
                msAPI_CM_ResetDTVDataManager();
                #endif
                msAPI_ATV_ResetATVDataManager();
                msAPI_ATV_SetFoundCHCount(0);
                #if (EEPROM_DB_STORAGE != EEPROM_SAVE_ALL)
                    //store to flash immediately
                MApp_DB_SaveDataBase();
                #endif
                _eCommonDlgMode = EN_COMMON_DLG_MODE_INVALID;
                MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON, SW_HIDE);

                UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_ATV;
                MApp_InputSource_ChangeInputSource(MAIN_WINDOW);
                MApp_ChannelChange_VariableInit();
                stGenSetting.fRunInstallationGuide =FALSE;
                MApp_TopStateMachine_SetTopState(STATE_TOP_CHANNELCHANGE);
                enMainMenuState=STATE_MENU_INIT;
                MApp_ZUI_ACT_SetTargetMenuState(STATE_MENU_INIT);
            }
            return TRUE;
        case EN_EXE_DO_SAVE_CHANNEL_INFO_CHANGED:
            if(IsAnyTVSourceInUse())
            {
                g_u8PreditFocusATVProgramNumber = (msAPI_ATV_ChannelInfoEdit_GetCHNum()-1);
                if((BYTE)g_u8PreditFocusATVProgramNumber != msAPI_ATV_GetCurrentProgramNumber())
                {
                    msAPI_ATV_DeleteProgram( msAPI_ATV_GetCurrentProgramNumber());
                    //_MApp_ChannelList_ChannelChange(g_u8PreditFocusATVProgramNumber, E_SERVICETYPE_ATV, FALSE, E_PROGACESS_INCLUDE_VISIBLE_ONLY);
                }
                msAPI_ATV_ChannelInfoEdit_SaveProgram(g_u8PreditFocusATVProgramNumber);
            #if ENABLE_SBTVD_BRAZIL_CM_APP
                if(ANT_AIR == msAPI_ATV_GetCurrentAntenna())
                    msAPI_CHPROC_CM_InitOridial();
            #endif
                _eCommonDlgMode = EN_COMMON_DLG_MODE_INVALID;
                MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON, SW_HIDE);
                MApp_ZUI_API_ShowWindow(HWND_MENU_BACKGROUND, SW_SHOW);
                MApp_ZUI_API_ShowWindow(HWND_MENU_MASK_BACKGROUND, SW_SHOW);
                MApp_ZUI_ACT_InitializeMainMenu();
		  #if(UI_SKIN_SEL==UI_SKIN_1366X768X565_HAIER_CN)  // CUS_xm zHIHE 20120807 modify
		  MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_CHANNEL_BIG, FALSE);
		  #endif
                MApp_ZUI_API_EnableWindow(HWND_MENU_TOP_ICON_CHANNEL, FALSE);
                MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_INFO_PAGE, SW_HIDE);
                //MApp_ZUI_ACT_ShowMainMenuBackground(HWND_MENU_BOTTOM_BALL_FOCUS_OPTION);
                MApp_ZUI_API_ShowWindow(HWND_MENU_PREDIT_CHANNEL_LIST_PAGE, SW_SHOW);
                MApp_ZUI_ACT_Mainpage_AppShowProgramEdit();
                return TRUE;

            }
            return TRUE;
        case EN_EXE_CLOSE_MISMATCH_PASSWORD_DLG:
            if (_eCommonDlgMode != EN_COMMON_DLG_MODE_MISMATCH_PASSWORD)
                return TRUE;

            _eCommonDlgMode = EN_COMMON_DLG_MODE_INVALID;
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON, SW_HIDE);
            //MApp_ZUI_ACT_ShowMainMenuBackground(HWND_MENU_BOTTOM_BALL_FOCUS_LOCK);
            MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_PAGE, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_PAGE_CHECKPWD_ERROR_MSG, SW_HIDE);
        #if 0//fix compiling error  //Roger.li###
            MApp_ZUI_API_SetFocus(HWND_MENU_LOCK_SET_PASSWORD);
        #endif
            MApp_ZUI_API_RestoreFocusCheckpoint();
            return TRUE;

        case EN_EXE_CLOSE_WRONG_PASSWORD_DLG:
        {
            HWND hwnd = (HWND)0;//NULL; // Move it by coverity_0530
            if (_eCommonDlgMode != EN_COMMON_DLG_MODE_WRONG_PASSWORD)
                return TRUE;

            _eCommonDlgMode = EN_COMMON_DLG_MODE_INVALID;
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON, SW_HIDE);
            hwnd = MApp_ZUI_API_GetFocusCheckpoint();
            if(MApp_ZUI_API_IsSuccessor(HWND_MENU_CHANNEL_PAGE, hwnd))
            {
               //MApp_ZUI_ACT_ShowMainMenuBackground(HWND_MENU_BOTTOM_BALL_FOCUS_CHANNEL);
               MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_PAGE, SW_SHOW);
            }
            else if (MApp_ZUI_API_IsSuccessor(HWND_MENU_LOCK_PAGE, hwnd))
            {
               //MApp_ZUI_ACT_ShowMainMenuBackground(HWND_MENU_BOTTOM_BALL_FOCUS_LOCK);
               MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_PAGE, SW_SHOW);
               MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_PAGE_CHECKPWD_ERROR_MSG, SW_HIDE);
               stGenSetting.g_BlockSysSetting.u8EnterLockPage = 0;
        #if 0//fix compiling error  //Roger.li###
               MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_SET_PASSWORD, DISABLE);
               MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_BLOCK_PROGRAM, DISABLE);
               MApp_ZUI_API_EnableWindow(HWND_MENU_LOCK_PARENTAL_GUIDANCE, DISABLE);
        #endif
               MApp_ZUI_API_InvalidateWindow(HWND_MENU_LOCK_PAGE_LIST);
            }
            else
            {
               //MApp_ZUI_ACT_ShowMainMenuBackground(HWND_MENU_BOTTOM_BALL_FOCUS_OPTION);
               MApp_ZUI_API_ShowWindow(HWND_MENU_OPTION_PAGE, SW_SHOW);
            }
            MApp_ZUI_API_RestoreFocusCheckpoint();
        }
            return TRUE;

        case EN_EXE_CLOSE_SET_PASSWORD_DLG:
            if (_eCommonDlgMode != EN_COMMON_DLG_MODE_SET_PASSWORD)
                return TRUE;

            _eCommonDlgMode = EN_COMMON_DLG_MODE_INVALID;
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON, SW_HIDE);
            //MApp_ZUI_ACT_ShowMainMenuBackground(HWND_MENU_BOTTOM_BALL_FOCUS_LOCK);
            MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_PAGE, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_PAGE_CHECKPWD_ERROR_MSG, SW_HIDE);
            MApp_ZUI_API_EnableWindow(HWND_MENU_DLG_PASSWORD_INPUT1_TEXT, ENABLE);
            MApp_ZUI_API_EnableWindow(HWND_MENU_DLG_PASSWORD_INPUT1_1, ENABLE);
            MApp_ZUI_API_EnableWindow(HWND_MENU_DLG_PASSWORD_INPUT1_2, ENABLE);
            MApp_ZUI_API_EnableWindow(HWND_MENU_DLG_PASSWORD_INPUT1_3, ENABLE);
            MApp_ZUI_API_EnableWindow(HWND_MENU_DLG_PASSWORD_INPUT1_4, ENABLE);
            MApp_ZUI_API_EnableWindow(HWND_MENU_DLG_PASSWORD_INPUT2_TEXT, ENABLE);
            MApp_ZUI_API_EnableWindow(HWND_MENU_DLG_PASSWORD_INPUT2_1, ENABLE);
            MApp_ZUI_API_EnableWindow(HWND_MENU_DLG_PASSWORD_INPUT2_2, ENABLE);
            MApp_ZUI_API_EnableWindow(HWND_MENU_DLG_PASSWORD_INPUT2_3, ENABLE);
            MApp_ZUI_API_EnableWindow(HWND_MENU_DLG_PASSWORD_INPUT2_4, ENABLE);
        #if 0//fix compiling error  //Roger.li###
            MApp_ZUI_API_SetFocus(HWND_MENU_LOCK_SET_PASSWORD);
        #endif
            MApp_ZUI_API_RestoreFocusCheckpoint();
            return TRUE;

        case EN_EXE_CLOSE_INPUT_PASSWORD_DLG:
            if (_eCommonDlgMode != EN_COMMON_DLG_MODE_INPUT_PASSWORD &&
                 _eCommonDlgMode != EN_COMMON_DLG_MODE_SCAN_INPUT_PASSWORD &&
                 _eCommonDlgMode != EN_COMMON_DLG_MODE_DTV_TUNING_INPUT_PASSWORD &&
                 _eCommonDlgMode != EN_COMMON_DLG_MODE_ATV_TUNING_INPUT_PASSWORD &&
                 _eCommonDlgMode != EN_COMMON_DLG_MODE_FACTORY_RESET_INPUT_PASSWORD &&
                 _eCommonDlgMode != EN_COMMON_DLG_MODE_ENTER_MENU_LOCK_PAGE_INPUT_PASSWORD)
                return TRUE;
            else
            {
               switch(_eCommonDlgMode)
               {
                   case EN_COMMON_DLG_MODE_FACTORY_RESET_INPUT_PASSWORD:
                       //MApp_ZUI_ACT_ShowMainMenuBackground(HWND_MENU_BOTTOM_BALL_FOCUS_OPTION);
                       MApp_ZUI_API_ShowWindow(HWND_MENU_OPTION_PAGE, SW_SHOW);
                       MApp_ZUI_API_SetFocus(HWND_MENU_OPTION_OSD_LANG);
                       break;
                   case EN_COMMON_DLG_MODE_SCAN_INPUT_PASSWORD:
                       //MApp_ZUI_ACT_ShowMainMenuBackground(HWND_MENU_BOTTOM_BALL_FOCUS_CHANNEL);
                       MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_PAGE, SW_SHOW);
                       MApp_ZUI_API_SetFocus(HWND_MENU_CHANNEL_AUTOTUNE);
                       break;
                   case EN_COMMON_DLG_MODE_DTV_TUNING_INPUT_PASSWORD:
                      // MApp_ZUI_ACT_ShowMainMenuBackground(HWND_MENU_BOTTOM_BALL_FOCUS_CHANNEL);
                       MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_PAGE, SW_SHOW);
                       MApp_ZUI_API_SetFocus(HWND_MENU_CHANNEL_DTV_MAN_TUNE);
                       break;
                   case EN_COMMON_DLG_MODE_ATV_TUNING_INPUT_PASSWORD:
                      // MApp_ZUI_ACT_ShowMainMenuBackground(HWND_MENU_BOTTOM_BALL_FOCUS_CHANNEL);
                       MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_PAGE, SW_SHOW);
                       MApp_ZUI_API_SetFocus(HWND_MENU_CHANNEL_ATV_MAN_TUNE);
                       break;
                   case EN_COMMON_DLG_MODE_ENTER_MENU_LOCK_PAGE_INPUT_PASSWORD:
                       //MApp_ZUI_ACT_ShowMainMenuBackground(HWND_MENU_BOTTOM_BALL_FOCUS_LOCK);
                       MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_PAGE, SW_SHOW);
                       MApp_ZUI_API_ShowWindow(HWND_MENU_LOCK_PAGE_CHECKPWD_ERROR_MSG, SW_HIDE);
                       //MApp_ZUI_API_SetFocus(HWND_MENU_LOCK_TITLE);
                      stGenSetting.g_BlockSysSetting.u8EnterLockPage = 0;


                    break;
                   default:
                    break;
               }
            }

            _eCommonDlgMode = EN_COMMON_DLG_MODE_INVALID;
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON, SW_HIDE);
            MApp_ZUI_API_RestoreFocusCheckpoint();
            return TRUE;

        case EN_EXE_CLEAR_PASSWORD:
            if(MApp_ZUI_API_IsSuccessor(HWND_MENU_DLG_PASSWORD_PANE0, MApp_ZUI_API_GetFocus()))
            {
                PasswordInput0 = 0;
                MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PRESSED_PANE0, SW_HIDE);
                MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PANE0, SW_SHOW);
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_DLG_PASSWORD_PANE0);
                MApp_ZUI_API_SetFocus(HWND_MENU_DLG_PASSWORD_INPUT0_1);
            }
            else if(MApp_ZUI_API_IsSuccessor(HWND_MENU_DLG_PASSWORD_PANE1, MApp_ZUI_API_GetFocus()))
            {
                PasswordInput0 = 0;
                MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PRESSED_PANE1, SW_HIDE);
                MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PANE1, SW_SHOW);
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_DLG_PASSWORD_PANE1);
                MApp_ZUI_API_SetFocus(HWND_MENU_DLG_PASSWORD_INPUT1_1);

                if (_eCommonDlgMode == EN_COMMON_DLG_MODE_INPUT_PASSWORD ||
                     _eCommonDlgMode == EN_COMMON_DLG_MODE_SCAN_INPUT_PASSWORD ||
                     _eCommonDlgMode == EN_COMMON_DLG_MODE_DTV_TUNING_INPUT_PASSWORD ||
                     _eCommonDlgMode == EN_COMMON_DLG_MODE_ATV_TUNING_INPUT_PASSWORD ||
                     _eCommonDlgMode == EN_COMMON_DLG_MODE_FACTORY_RESET_INPUT_PASSWORD ||
                     _eCommonDlgMode == EN_COMMON_DLG_MODE_WRONG_PASSWORD ||
                   _eCommonDlgMode ==  EN_COMMON_DLG_MODE_ENTER_MENU_LOCK_PAGE_INPUT_PASSWORD)
                {
                    MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_INPUT1_TEXT, SW_HIDE);
                }
                else
                {
                    MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_INPUT1_TEXT, SW_SHOW);
                }
            }
            else
            {
                PasswordInput1 = PasswordInput2 = 0;

                MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PRESSED_PANE1, SW_HIDE);
                MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PRESSED_PANE2, SW_HIDE);

                MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PANE1, SW_SHOW);
                MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PANE2, SW_SHOW);

                MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_DLG_PASSWORD_PANE0);
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_DLG_PASSWORD_PANE1);
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_DLG_PASSWORD_PANE2);
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_MENU_DLG_COMMON_BTN_OK);
                MApp_ZUI_API_SetFocus(HWND_MENU_DLG_PASSWORD_INPUT1_1);
            }
            return FALSE; //don't eat this key event..

        default:
            ZUI_DBG_FAIL(printf("[ZUI]COMDLGACT\n"));
            ABORT();


    }
    return FALSE;
}

///////////////////////////////////////////////////////////////////////////////

#ifdef NETWORK_CONFIG
extern BOOLEAN bNetworkHWStatus;
extern BOOLEAN bNetworkIntranetStatus;
extern BOOLEAN bNetworkInternetStatus;
extern BOOLEAN bNetworkDNSStatus;
extern BOOLEAN bNetworkIPStatus;

LPTSTR MApp_ZUI_ACT_GetNetworkDynamicText(HWND hwnd)
{
        U16 u16TempID = Empty;

        switch(hwnd)
        {
            case HWND_MENU_NETWORK_HW_STATUS:
               {
                    U8 u8Str[32];
                    if(bNetworkHWStatus)
                        snprintf((char*)u8Str, 27, "Network Hardware :  OK");
                    else
                        snprintf((char*)u8Str, 27, "Network Hardware :  fail");
                    MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, u8Str, strlen((const char *)u8Str));
                    return CHAR_BUFFER;
                }
                break;

            case HWND_MENU_NETWORK_INTRANET_STATUS:
               {
                    U8 u8Str[32];
                    if(bNetworkIntranetStatus&&bNetworkHWStatus&&bNetworkIPStatus)
                    {
                        snprintf((char*)u8Str, 27, "Intranet Status   :  OK");
                    }
                    else
                    {
                        if((bNetworkIPStatus==false)&&(bNetworkHWStatus==true))
                            snprintf((char*)u8Str, 27, "Can't Get IP Address");
                    else
                        snprintf((char*)u8Str, 27, "Intranet Status   :  fail");
                    }
                    MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, u8Str, strlen((const char *)u8Str));
                    return CHAR_BUFFER;
                }
                break;

            case HWND_MENU_NETWORK_INTERNET_STATUS:
               {
                    U8 u8Str[32];
                    if(bNetworkInternetStatus&&bNetworkHWStatus&&bNetworkIPStatus)
                    {
                        snprintf((char*)u8Str, 27, "Internet Status   :  OK");
                    }
                    else
                    {
                        if((bNetworkIPStatus==false)&&(bNetworkHWStatus==true))
                            snprintf((char*)u8Str, 27, " ");
                    else
                        snprintf((char*)u8Str, 27, "Internet Status   :  fail");
                    }
                    MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, u8Str, strlen((const char *)u8Str));
                    return CHAR_BUFFER;
                }
                break;

            case HWND_MENU_NETWORK_DNS_STATUS:
               {
                    U8 u8Str[32];
                    if(bNetworkDNSStatus&&bNetworkHWStatus&&bNetworkIPStatus)
                    {
                        snprintf((char*)u8Str, 27, "Domain Name Server :  OK");
                    }
                    else
                    {
                        if((bNetworkIPStatus==false)&&(bNetworkHWStatus==true))
                            snprintf((char*)u8Str, 27, " ");
                    else
                        snprintf((char*)u8Str, 27, "Domain Name Server :  fail");
                    }
                    MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, u8Str, strlen((const char *)u8Str));
                    return CHAR_BUFFER;
                }
                break;

            default:
                return 0;
                break;
        }
        if (u16TempID != Empty)
            return MApp_ZUI_API_GetString(u16TempID);
        return 0; //for empty string....

}

#endif
LPTSTR MApp_ZUI_ACT_GetMenuCommonDynamicText(HWND hwnd)
{
    U16 u16TempID = Empty;

    switch(hwnd)
    {
        case HWND_MENU_DLG_COMMON_TEXT1:
            switch(_eCommonDlgMode)
            {
                case EN_COMMON_DLG_MODE_CHANNEL_INFO_SAVE_CHANGED:
                case EN_COMMON_DLG_MODE_CH_LIST_CLEAN_ALL_CONFIRM:
                case EN_COMMON_DLG_MODE_FACTORY_RESET_CONFIRM:
                case EN_COMMON_DLG_MODE_USB_UPDATE_CONFIRM:
            	case EN_COMMON_DLG_MODE_CLEAN_LOCK:
                    u16TempID = en_str_AreYouSure;
                    break;
                case EN_COMMON_DLG_MODE_DIVX:
                case EN_COMMON_DLG_MODE_DEACTIVATION:
                case EN_COMMON_DLG_MODE_DEACTIVATION_CONFIRM:
                    u16TempID = Empty;
                    break;
                case EN_COMMON_DLG_MODE_FACTORY_RESET:
                    //u16TempID = en_str_Reseting;
                    break;

                case EN_COMMON_DLG_MODE_WRONG_PASSWORD:
                    //u16TempID = en_strWrongPassword;
                    break;

                case EN_COMMON_DLG_MODE_MISMATCH_PASSWORD:
                    //u16TempID = en_strPasswordDoesNotMatch;
                    break;

                case EN_COMMON_DLG_MODE_SET_PASSWORD:
                case EN_COMMON_DLG_MODE_INPUT_PASSWORD:
                case EN_COMMON_DLG_MODE_SCAN_INPUT_PASSWORD:
                case EN_COMMON_DLG_MODE_DTV_TUNING_INPUT_PASSWORD:
                case EN_COMMON_DLG_MODE_ATV_TUNING_INPUT_PASSWORD:
                case EN_COMMON_DLG_MODE_FACTORY_RESET_INPUT_PASSWORD:
                case EN_COMMON_DLG_MODE_ENTER_MENU_LOCK_PAGE_INPUT_PASSWORD:
                    //u16TempID = en_strEnterPassword;
                    break;
                case EN_COMMON_DLG_MODE_USB_NOT_DETECTED:
                    u16TempID = en_strUsbNotDetected;
                    break;

                case EN_COMMON_DLG_MODE_SW_FILE_NOT_DETECTED:
                    u16TempID = en_strSwFileNotDetected;
                    break;
                case EN_COMMON_DLG_MODE_USB_UPGRADING:
                {
                    /*LPTSTR ptr = CHAR_BUFFER;
                    const char str[] = {"Software upgrading..."};
                    ptr = MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, (U8*)str, strlen(str));
                    return ptr;*/
                    break;
                }
                default:
                    ZUI_DBG_FAIL(printf("[ZUI]COMDLGMODE\n"));
                    ABORT();

            }
            break;

        case HWND_MENU_DLG_COMMON_TEXT2:
            if(_eCommonDlgMode == EN_COMMON_DLG_MODE_USB_UPGRADING
                && USB_Upgrade_Percent != 0xFF)
            {

                if(USB_Upgrade_Percent<=100)
                {
                    MApp_ZUI_API_GetU16String((U16)USB_Upgrade_Percent);
                    if(USB_Upgrade_Percent < 10 )
                    {
                        CHAR_BUFFER[1] = CHAR_SPACE;
                        CHAR_BUFFER[2] = CHAR_SPACE;
                    }
                    else if(USB_Upgrade_Percent < 100)
                    {
                        CHAR_BUFFER[2] = CHAR_SPACE;
                    }
                    CHAR_BUFFER[3] = CHAR_PERCENT;
                    CHAR_BUFFER[4] = '\0';
          #if BOE_USB_UPGRADE_FACTROY//minglin1210
                 }
                else if(USB_Upgrade_Percent == 100) //smc.chy 2010/06/29
                {
                    U8 str[] = {"Update OK"};
                    MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER,str, strlen((const char *)str));
            #endif
                }
                else if(USB_Upgrade_Percent == 0xFE)
                {
                    U8 str[] = {"CRC Error"};
                    MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER,str, strlen((const char *)str));
                }
                else if(USB_Upgrade_Percent == 0xFD)
                {
                    U8 str[] = {"Fail to Burn AP Code"};
                    MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, str, strlen((const char *)str));
                }
                else if(USB_Upgrade_Percent == 0xFC)
                {
                    U8 str[] = {"Unknown image type"};
                    MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, str, strlen((const char *)str));
                }
                else if(USB_Upgrade_Percent == 0xFB)
                {
                    U8 str[] = {"Reboot fail"};
                    MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, str, strlen((const char *)str));
                }
                else if(USB_Upgrade_Percent == 0xFA)
                {
                    U8 str[] = {"Failed to update software"};
                    MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, str, strlen((const char *)str));
                }
                else
                {
                    return 0;
                }
                return CHAR_BUFFER;
            }
            else
            {
               return 0;
            }

        case HWND_MENU_DLG_COMMON_TEXT3:
            switch(_eCommonDlgMode)
            {
                case EN_COMMON_DLG_MODE_INPUT_PASSWORD:
                case EN_COMMON_DLG_MODE_SCAN_INPUT_PASSWORD:
                case EN_COMMON_DLG_MODE_DTV_TUNING_INPUT_PASSWORD:
                case EN_COMMON_DLG_MODE_ATV_TUNING_INPUT_PASSWORD:
                case EN_COMMON_DLG_MODE_FACTORY_RESET_INPUT_PASSWORD:
                case EN_COMMON_DLG_MODE_ENTER_MENU_LOCK_PAGE_INPUT_PASSWORD:
                    u16TempID = en_strEnterPassword;
                    break;

                case EN_COMMON_DLG_MODE_WRONG_PASSWORD:
                    u16TempID = en_strWrongPassword;
                    break;
                default:
                    return 0;
            }
            break;

        case HWND_MENU_DLG_COMMON_TEXT4:
            switch(_eCommonDlgMode)
            {
                case EN_COMMON_DLG_MODE_WRONG_PASSWORD:
                    u16TempID = en_strReenterPassword;
                    break;
                case EN_COMMON_DLG_MODE_USB_UPGRADING:
                    u16TempID = en_str_SW_USB_Upgrade;
                    break;
                default:
                    return 0;
            }
            break;

        case HWND_MENU_DLG_COMMON_TEXT5:
            switch(_eCommonDlgMode)
            {
                case EN_COMMON_DLG_MODE_MISMATCH_PASSWORD:
                    u16TempID = en_strPasswordDoesNotMatch;
                    break;
                case EN_COMMON_DLG_MODE_SET_PASSWORD:
                    u16TempID = en_strWrongPassword;
                    break;
                default:
                    return 0;
            }
            break;

        case HWND_MENU_DLG_COMMON_TEXT6:
            switch(_eCommonDlgMode)
            {
                case EN_COMMON_DLG_MODE_FACTORY_RESET:
                    u16TempID = en_str_Reseting;
                    break;
                default:
                    return 0;
            }
            break;
#if ENABLE_DRM
        case HWND_MENU_DLG_COMMON_TEXT7:
        {
            U8 u8Str[64];
            U8 u8Str1[16];
            U8 i;
            switch(_eCommonDlgMode)
            {
                case EN_COMMON_DLG_MODE_DIVX:
                    snprintf((char*)u8Str, 64, "You must register your device to play DivX protected videos.");
                    MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, u8Str, strlen((const char *)u8Str));
                    return CHAR_BUFFER;
                case EN_COMMON_DLG_MODE_DEACTIVATION_CONFIRM:
                    snprintf((char*)u8Str, 35, "Your device is already registered.");
                    MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, u8Str, strlen((const char *)u8Str));
                    return CHAR_BUFFER;
                case EN_COMMON_DLG_MODE_DEACTIVATION:
                    for(i = 0; i < DIVX_DEACT_CODE_LEN; i++)
                    {
                        u8Str1[i] = stGenSetting.g_VDplayerDRMInfo.u8DeActivationCode[i];
                    }
                    u8Str1[DIVX_DEACT_CODE_LEN] = 0;

                    snprintf((char*)u8Str, 60, "Deregistration code:    %s\n",u8Str1);
                    MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, u8Str, strlen((const char *)u8Str));
                    return CHAR_BUFFER;
                    break;
                default:
                    return 0;
            }
            break;
        }
        case HWND_MENU_DLG_COMMON_TEXT8:

            switch(_eCommonDlgMode)
            {
                U8 u8Str[32];
                case EN_COMMON_DLG_MODE_DIVX:
                    snprintf((char*)u8Str, 19, "Registration code:");
                    MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, u8Str, strlen((const char *)u8Str));
                    return CHAR_BUFFER;
                case EN_COMMON_DLG_MODE_DEACTIVATION_CONFIRM:
                    break;
                case EN_COMMON_DLG_MODE_DEACTIVATION:
                    snprintf((char*)u8Str, 14, "Deregister at");
                    MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, u8Str, strlen((const char *)u8Str));
                    return CHAR_BUFFER;
                    break;

                    break;
                default:
                    return 0;
            }
            break;

        case HWND_MENU_DLG_COMMON_TEXT9:
            switch(_eCommonDlgMode)
            {
                U8 u8Str[32];
                case EN_COMMON_DLG_MODE_DIVX:
                    #if ENABLE_DRM
                    {
                        //VDplayerDRMInfo DRM_info;
                        U8 i;
                        //MApp_VDPlayer_OperateDRMData(E_DRM_LOAD, &DRM_info);
                        //snprintf((char*)u8Str, 11, "1234567890");
                        for(i = 0; i < DIVX_REG_CODE_LEN; i++)
                        {
                            u8Str[i] = stGenSetting.g_VDplayerDRMInfo.u8RegistrationCode[i];
                        }
                        u8Str[DIVX_REG_CODE_LEN] = 0;
                        MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, u8Str, strlen((const char *)u8Str));
                        return CHAR_BUFFER;
                    }
                    #else
                        return 0;
                    #endif
                    break;
                case EN_COMMON_DLG_MODE_DEACTIVATION_CONFIRM:
                    snprintf((char*)u8Str, 25, "Are you sure you wish to");
                    MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, u8Str, strlen((const char *)u8Str));
                    return CHAR_BUFFER;
                case EN_COMMON_DLG_MODE_DEACTIVATION:
                    #if ENABLE_DRM
                    {
                        snprintf((char*)u8Str, 20, "http://vod.divx.com");
                        MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, u8Str, strlen((const char *)u8Str));
                        return CHAR_BUFFER;
                    }
                    #else
                        return 0;
                    #endif
                    break;
                default:
                    return 0;
            }
            break;

        case HWND_MENU_DLG_COMMON_TEXT10:
            switch(_eCommonDlgMode)
            {
                U8 u8Str[32];
                case EN_COMMON_DLG_MODE_DEACTIVATION_CONFIRM:
                    snprintf((char*)u8Str, 12, "deregister?");
                    MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, u8Str, strlen((const char *)u8Str));
                    return CHAR_BUFFER;
                case EN_COMMON_DLG_MODE_DEACTIVATION:
                    break;
                default:
                    return 0;
            }
            break;

       case HWND_MENU_DLG_COMMON_TEXT11:
            switch(_eCommonDlgMode)
            {
                U8 u8Str[32];
                case EN_COMMON_DLG_MODE_DIVX:
                    snprintf((char*)u8Str, 12, "Register at");
                    MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, u8Str, strlen((const char *)u8Str));
                    return CHAR_BUFFER;
                case EN_COMMON_DLG_MODE_DEACTIVATION:
                    snprintf((char*)u8Str, 28, "Continue with registration?");
                    MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, u8Str, strlen((const char *)u8Str));
                    return CHAR_BUFFER;
                default:
                    return 0;
            }
            break;

       case HWND_MENU_DLG_COMMON_TEXT12:
            switch(_eCommonDlgMode)
            {
                U8 u8Str[32];
                case EN_COMMON_DLG_MODE_DIVX:
                    snprintf((char*)u8Str, 20, "http://vod.divx.com");
                    MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, u8Str, strlen((const char *)u8Str));
                    return CHAR_BUFFER;
                case EN_COMMON_DLG_MODE_DEACTIVATION:
                    break;
                default:
                    return 0;
            }
            break;
#endif
    }

    if (u16TempID != Empty)
        return MApp_ZUI_API_GetString(u16TempID);
    return 0; //for empty string....
}


/////////////////////////////////////////////////////////
// Customize Window Procedures
S32 MApp_ZUI_ACT_MenuCommonDialogRootWinProc(HWND hwnd, PMSG msg)
{
    switch(msg->message)
    {
        case MSG_NOTIFY_SHOW:
            {
                //for factory reset dialog, execute reset procedure after one second...
                if (_eCommonDlgMode == EN_COMMON_DLG_MODE_FACTORY_RESET)
                {
                    MApp_ZUI_API_SetTimer(hwnd, 0, 1000);
                }
                else if(_eCommonDlgMode == EN_COMMON_DLG_MODE_WRONG_PASSWORD)
                {
                    MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PANE1, SW_SHOW);
                    MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_INPUT1_TEXT, SW_HIDE);
                    MApp_ZUI_API_SetFocus(HWND_MENU_DLG_PASSWORD_INPUT1_1);
                }
                else if(_eCommonDlgMode == EN_COMMON_DLG_MODE_MISMATCH_PASSWORD)
                {
                    MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PANE1, SW_SHOW);
                    MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_INPUT1_TEXT, SW_SHOW);
                    MApp_ZUI_API_SetFocus(HWND_MENU_DLG_PASSWORD_INPUT1_1);
                }
            }
            return 0;

        case MSG_TIMER:
            {
                //for factory reset dialog, execute reset procedure after one second...
                if (_eCommonDlgMode == EN_COMMON_DLG_MODE_FACTORY_RESET)
                {
                    MApp_ZUI_API_KillTimer(hwnd, 0);
                    #if DAILEO_RESET_MANU_CONFIG
                    MApp_ZUI_ACT_ExecuteMenuCommonDialogAction(/*EN_EXE_FACTORY_RESET*/EN_EXE_USER_SETTING_RESET);
                    #else
                    MApp_ZUI_ACT_ExecuteMenuCommonDialogAction(EN_EXE_FACTORY_RESET);
                    #endif
                }
                else if(_eCommonDlgMode == EN_COMMON_DLG_MODE_USB_NOT_DETECTED
                    || _eCommonDlgMode == EN_COMMON_DLG_MODE_SW_FILE_NOT_DETECTED)
                {
                    MApp_ZUI_API_KillTimer(hwnd, 0);
                    MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON, SW_HIDE);
					#if 0//BOE_USB_UPGRADE_FACTROY//minglin1210
					   MApp_ZUI_ACT_ShowMainMenuBackground(HWND_MENU_BOTTOM_BALL_FOCUS_CHANNEL);
					#else
                    //MApp_ZUI_ACT_ShowMainMenuBackground(HWND_MENU_BOTTOM_BALL_FOCUS_CHANNEL);
					#endif
                     MApp_ZUI_API_ShowWindow(HWND_MENU_CHANNEL_PAGE, SW_SHOW);
			        MApp_ZUI_API_SetFocus(HWND_MENU_CHANNEL_SW_USB_UPGRADE);
                }
                else if(_eCommonDlgMode == EN_COMMON_DLG_MODE_USB_UPGRADING)
                {
                    MApp_ZUI_API_KillTimer(hwnd, 0);

                    USB_Upgrade_Percent = 0;

                    if(IsSrcTypeATV(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW))||IsSrcTypeDTV(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)))
                    {
                        MApp_ChannelChange_DisableChannel(TRUE,MAIN_WINDOW);
                    }

#if ENABLE_DMP
                    // for dmp
                    if(( UI_INPUT_SOURCE_TYPE == UI_INPUT_SOURCE_DMP)
	               #if( ENABLE_DMP_SWITCH )
                         ||(UI_INPUT_SOURCE_DMP1 == UI_INPUT_SOURCE_TYPE)
                         ||(UI_INPUT_SOURCE_DMP2 == UI_INPUT_SOURCE_TYPE)
                      #endif
                     )
                    {
                        //MApp_DMP_SetDMPStat(DMP_STATE_GOTO_PREV_SRC);
                        MApp_DMP_Exit();
                    }
#endif // #if ENABLE_DMP

#if ( ENABLE_SW_UPGRADE && ENABLE_FILESYSTEM )
                        if(!_bOCPFromMem)
                        {
                            msAPI_OCP_LoadAllStringToMem();
                        }

#if (OBA2!=1)
                    if (MW_UsbDownload_Start())
                    {
                        msAPI_BLoader_Reboot();
                    }
                    else
                    {
                        //Screen will Blue & Red flash
                    }
#endif
#endif
                }
            }
            break;

        case MSG_NOTIFY_HIDE:
            {
                //note: restore pane1 position...
                MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PRESSED_PANE1, SW_HIDE);
                MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PANE1, SW_HIDE);

                MApp_ZUI_API_RestoreWindowRect(HWND_MENU_DLG_PASSWORD_PANE1);
                MApp_ZUI_API_RestoreWindowRect(HWND_MENU_DLG_PASSWORD_INPUT1_TEXT);
                MApp_ZUI_API_RestoreWindowRect(HWND_MENU_DLG_PASSWORD_INPUT1_1);
                MApp_ZUI_API_RestoreWindowRect(HWND_MENU_DLG_PASSWORD_INPUT1_2);
                MApp_ZUI_API_RestoreWindowRect(HWND_MENU_DLG_PASSWORD_INPUT1_3);
                MApp_ZUI_API_RestoreWindowRect(HWND_MENU_DLG_PASSWORD_INPUT1_4);
            }
            return 0;

        default:
            break;

    }

    return DEFAULTWINPROC(hwnd, msg);
}

//////////////////////////////////////////////////////
U16 _MApp_ZUI_ACT_PasswordConvertToSystemFormat(U16 password)
{
    U16 ret = 0;
    ret += (password>>12)&PASSWORD_INPUT_MASK;
    ret *= 10;
    ret += (password>>8)&PASSWORD_INPUT_MASK;
    ret *= 10;
    ret += (password>>4)&PASSWORD_INPUT_MASK;
    ret *= 10;
    ret += (password)&PASSWORD_INPUT_MASK;
    return ret;
}

typedef struct
{
    HWND hwnd;
    HWND hwndNext;
    HWND hwndPressed;
    U16 * pVar;
    U8 u8ShiftBits;
}PASSWORD_INPUT_DATA_STRUCT;

S32 MApp_ZUI_ACT_MenuPasswordInputWinProc(HWND hwnd, PMSG msg)
{
    static BOOLEAN _bPasswordBlinkBlack = FALSE;

    static  PASSWORD_INPUT_DATA_STRUCT _ZUI_TBLSEG _PasswordData[] =
    {
        {
            HWND_MENU_DLG_PASSWORD_INPUT0_1,
            HWND_MENU_DLG_PASSWORD_INPUT0_2,
            HWND_MENU_DLG_PASSWORD_PRESSED_PANE0_1,
            &PasswordInput0,
            0
        },
        {
            HWND_MENU_DLG_PASSWORD_INPUT0_2,
            HWND_MENU_DLG_PASSWORD_INPUT0_3,
            HWND_MENU_DLG_PASSWORD_PRESSED_PANE0_2,
            &PasswordInput0,
            4
        },
        {
            HWND_MENU_DLG_PASSWORD_INPUT0_3,
            HWND_MENU_DLG_PASSWORD_INPUT0_4,
            HWND_MENU_DLG_PASSWORD_PRESSED_PANE0_3,
            &PasswordInput0,
            8
        },
        {
            HWND_MENU_DLG_PASSWORD_INPUT0_4,
            HWND_MENU_DLG_PASSWORD_INPUT1_1,
            HWND_MENU_DLG_PASSWORD_PRESSED_PANE0_4,
            &PasswordInput0,
            12
        },
        {
            HWND_MENU_DLG_PASSWORD_INPUT1_1,
            HWND_MENU_DLG_PASSWORD_INPUT1_2,
            HWND_MENU_DLG_PASSWORD_PRESSED_PANE1_1,
            &PasswordInput1,
            0
        },
        {
            HWND_MENU_DLG_PASSWORD_INPUT1_2,
            HWND_MENU_DLG_PASSWORD_INPUT1_3,
            HWND_MENU_DLG_PASSWORD_PRESSED_PANE1_2,
            &PasswordInput1,
            4
        },
        {
            HWND_MENU_DLG_PASSWORD_INPUT1_3,
            HWND_MENU_DLG_PASSWORD_INPUT1_4,
            HWND_MENU_DLG_PASSWORD_PRESSED_PANE1_3,
            &PasswordInput1,
            8
        },
        {
            HWND_MENU_DLG_PASSWORD_INPUT1_4,
            HWND_MENU_DLG_PASSWORD_INPUT2_1,
            HWND_MENU_DLG_PASSWORD_PRESSED_PANE1_4,
            &PasswordInput1,
            12
        },
        {
            HWND_MENU_DLG_PASSWORD_INPUT2_1,
            HWND_MENU_DLG_PASSWORD_INPUT2_2,
            HWND_MENU_DLG_PASSWORD_PRESSED_PANE2_1,
            &PasswordInput2,
            0
        },
        {
            HWND_MENU_DLG_PASSWORD_INPUT2_2,
            HWND_MENU_DLG_PASSWORD_INPUT2_3,
            HWND_MENU_DLG_PASSWORD_PRESSED_PANE2_2,
            &PasswordInput2,
            4
        },
        {
            HWND_MENU_DLG_PASSWORD_INPUT2_3,
            HWND_MENU_DLG_PASSWORD_INPUT2_4,
            HWND_MENU_DLG_PASSWORD_PRESSED_PANE2_3,
            &PasswordInput2,
            8
        },
        {
            HWND_MENU_DLG_PASSWORD_INPUT2_4,
            HWND_MENU_DLG_PASSWORD_INPUT2_4,
            HWND_MENU_DLG_PASSWORD_PRESSED_PANE2_4,
            &PasswordInput2,
            12
        },

    };

    U8 i;
    for (i = 0; i < COUNTOF(_PasswordData); i++)
    {
        if (hwnd == _PasswordData[i].hwnd)
            break;
    }
    if (i == COUNTOF(_PasswordData)) //if not in the data list, we do nothing...
        return DEFAULTWINPROC(hwnd, msg);

    switch(msg->message)
    {
        case MSG_NOTIFY_SETFOCUS:
            {
                //enable blinking
                MApp_ZUI_API_SetTimer(hwnd, 0, 500);
                MApp_ZUI_API_InvalidateWindow(hwnd);
            }
            return 0;

        case MSG_TIMER:
            {
                //blinking
                _bPasswordBlinkBlack = !_bPasswordBlinkBlack;
                MApp_ZUI_API_InvalidateWindow(hwnd);
            }
            break;

        case MSG_NOTIFY_KILLFOCUS:
        case MSG_NOTIFY_HIDE:
            {
                //disable blinking
                MApp_ZUI_API_KillTimer(hwnd, 0);
            }
            return 0;

        case MSG_KEYDOWN:
            {
                if (VK_NUM_0 <= msg->wParam && msg->wParam <= VK_NUM_9)
                {
                    *(_PasswordData[i].pVar) &= ~(PASSWORD_INPUT_MASK<<_PasswordData[i].u8ShiftBits);
                    *(_PasswordData[i].pVar) |= ((msg->wParam-VK_NUM_0)<<_PasswordData[i].u8ShiftBits);

                    if ( _eCommonDlgMode == EN_COMMON_DLG_MODE_INPUT_PASSWORD)
                    {
                        if (i == 7) //last one
                        {
                            MApp_ZUI_API_ShowWindow(_PasswordData[i].hwnd, SW_SHOW);
                            MApp_ZUI_API_ShowWindow(_PasswordData[i].hwndPressed, SW_SHOW);
                            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON, SW_HIDE);
                            MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_CHECK_INPUT_PASSWORD);
                        }
                        else
                        {
                            MApp_ZUI_API_ShowWindow(_PasswordData[i].hwnd, SW_SHOW);
                            MApp_ZUI_API_ShowWindow(_PasswordData[i].hwndPressed, SW_SHOW);
                            MApp_ZUI_API_SetFocus(_PasswordData[i].hwndNext);
                        }
                    }
                    if (_eCommonDlgMode ==  EN_COMMON_DLG_MODE_SCAN_INPUT_PASSWORD)
                    {
                        if (i == 7) //last one
                        {
                            MApp_ZUI_API_ShowWindow(_PasswordData[i].hwnd, SW_SHOW);
                            MApp_ZUI_API_ShowWindow(_PasswordData[i].hwndPressed, SW_SHOW);
                            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON, SW_HIDE);
                            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PANE1, SW_HIDE);
                          #if (ENABLE_ATV_CHINA_APP||ENABLE_SBTVD_BRAZIL_APP)//china will not use country adjust option
                          MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_GOTO_AUTO_TUNING);
                          #else
                          MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_GOTO_TUNING_CONFIRM);
                          #endif
                        }
                        else
                        {
                            MApp_ZUI_API_ShowWindow(_PasswordData[i].hwnd, SW_SHOW);
                            MApp_ZUI_API_ShowWindow(_PasswordData[i].hwndPressed, SW_SHOW);
                            MApp_ZUI_API_SetFocus(_PasswordData[i].hwndNext);
                        }
                    }
                    if(_eCommonDlgMode ==  EN_COMMON_DLG_MODE_DTV_TUNING_INPUT_PASSWORD)
                    {
                         if (i == 7) //last one
                        {
                            MApp_ZUI_API_ShowWindow(_PasswordData[i].hwnd, SW_SHOW);
                            MApp_ZUI_API_ShowWindow(_PasswordData[i].hwndPressed, SW_SHOW);
                            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON, SW_HIDE);
                            MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_GOTO_DTV_TUNING);
                        }
                        else
                        {
                            MApp_ZUI_API_ShowWindow(_PasswordData[i].hwnd, SW_SHOW);
                            MApp_ZUI_API_ShowWindow(_PasswordData[i].hwndPressed, SW_SHOW);
                            MApp_ZUI_API_SetFocus(_PasswordData[i].hwndNext);
                        }
                    }
                    if(_eCommonDlgMode == EN_COMMON_DLG_MODE_ATV_TUNING_INPUT_PASSWORD)
                    {
                        if (i == 7) //last one
                        {
                            MApp_ZUI_API_ShowWindow(_PasswordData[i].hwnd, SW_SHOW);
                            MApp_ZUI_API_ShowWindow(_PasswordData[i].hwndPressed, SW_SHOW);
                            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON, SW_HIDE);
                            MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_GOTO_ATV_TUNING);
                        }
                        else
                        {
                            MApp_ZUI_API_ShowWindow(_PasswordData[i].hwnd, SW_SHOW);
                            MApp_ZUI_API_ShowWindow(_PasswordData[i].hwndPressed, SW_SHOW);
                            MApp_ZUI_API_SetFocus(_PasswordData[i].hwndNext);
                        }
                    }
                    if(_eCommonDlgMode == EN_COMMON_DLG_MODE_FACTORY_RESET_INPUT_PASSWORD)
                    {
                         if (i == 7) //last one
                        {
                            MApp_ZUI_API_ShowWindow(_PasswordData[i].hwnd, SW_SHOW);
                            MApp_ZUI_API_ShowWindow(_PasswordData[i].hwndPressed, SW_SHOW);
                            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON, SW_HIDE);
                            MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_GOTO_FACTORY_RESET_CONFIRM_DLG);
                        }
                        else
                        {
                            MApp_ZUI_API_ShowWindow(_PasswordData[i].hwnd, SW_SHOW);
                            MApp_ZUI_API_ShowWindow(_PasswordData[i].hwndPressed, SW_SHOW);
                            MApp_ZUI_API_SetFocus(_PasswordData[i].hwndNext);
                        }
                    }
                    if(_eCommonDlgMode == EN_COMMON_DLG_MODE_WRONG_PASSWORD)
                    {
                        if (i == 7) //last one
                        {
                            MApp_ZUI_API_ShowWindow(_PasswordData[i].hwnd, SW_SHOW);
                            MApp_ZUI_API_ShowWindow(_PasswordData[i].hwndPressed, SW_SHOW);
                            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON, SW_HIDE);
                            MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_PASS_PASSWORD);
                        }
                        else
                        {
                            MApp_ZUI_API_ShowWindow(_PasswordData[i].hwnd, SW_SHOW);
                            MApp_ZUI_API_ShowWindow(_PasswordData[i].hwndPressed, SW_SHOW);
                            MApp_ZUI_API_SetFocus(_PasswordData[i].hwndNext);
                        }
                    }
                    if (_eCommonDlgMode ==  EN_COMMON_DLG_MODE_ENTER_MENU_LOCK_PAGE_INPUT_PASSWORD)
                    {
                        if (i == 7) //last one
                        {
                            MApp_ZUI_API_ShowWindow(_PasswordData[i].hwnd, SW_SHOW);
                            MApp_ZUI_API_ShowWindow(_PasswordData[i].hwndPressed, SW_SHOW);
                            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_COMMON, SW_HIDE);
                            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PANE1, SW_HIDE);
                            MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_GOTO_MENU_LOCK_PAGE);
                        }
                        else
                        {
                            MApp_ZUI_API_ShowWindow(_PasswordData[i].hwnd, SW_SHOW);
                            MApp_ZUI_API_ShowWindow(_PasswordData[i].hwndPressed, SW_SHOW);
                            MApp_ZUI_API_SetFocus(_PasswordData[i].hwndNext);
                        }
                    }
                    else //set password dialog
                    {
                        if (i == 3)
                        {
                            MApp_ZUI_API_ShowWindow(_PasswordData[i].hwnd, SW_SHOW);
                            MApp_ZUI_API_ShowWindow(_PasswordData[i].hwndPressed, SW_SHOW);
                            MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_CHECK_SET_PASSWORD_CHECKOLDPW);
                        }
                        else if (i== 11) //last one
                        {
                            MApp_ZUI_API_ShowWindow(_PasswordData[i].hwndPressed, SW_SHOW);
                            MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_CHECK_SET_PASSWORD);
                        }
                        else
                        {
                            MApp_ZUI_API_ShowWindow(_PasswordData[i].hwnd, SW_SHOW);
                            MApp_ZUI_API_ShowWindow(_PasswordData[i].hwndPressed, SW_SHOW);
                            MApp_ZUI_API_SetFocus(_PasswordData[i].hwndNext);
                        }
                    }
                    return 0; //don't process default behavior....
                }
            }
            break;

        case MSG_PAINT:
            {
                static  DRAW_RECT _ZUI_TBLSEG _DrawPasswordBlinkBgFocus =
                {
                    0x707070,
                    0x080808,
                    OSD_COLOR_GRADIENT_Y, //OSD_GRADIENT eRectGradient;
                    0, //OSD_COLOR BroderColor;
                    eRectBorder, //RECT_ATTRIB attrib;
                    0, //U8 sizeBorder;
                    0, //radius
                };
                //get buffer GC for offline drawing...
                PAINT_PARAM * param = (PAINT_PARAM*)msg->wParam;
                if (param->bIsFocus && _bPasswordBlinkBlack)
                {

                    //2007/12/22: for bank issue, we prepare it in XDATA
                    DRAW_RECT * pDraw = (DRAW_RECT*)_ZUI_MALLOC(sizeof(DRAW_RECT));
                    if (pDraw)
                    {
                        param->dc.u8ConstantAlpha = MApp_ZUI_API_GetFocusAlpha(hwnd);
                        memcpy(pDraw, &_DrawPasswordBlinkBgFocus, sizeof(DRAW_RECT));
                        _MApp_ZUI_API_DrawDynamicComponent(CP_RECT, pDraw, &param->dc, param->rect);
                        _ZUI_FREE(pDraw);
                    }
                    else
                    {
                        __ASSERT(0);
                    }
                    return DEFAULTWINPROC(hwnd, msg);
                }
                else if (param->bIsFocus)
                {
                    return DEFAULTWINPROC(hwnd, msg);
                }
                else
                {
                    return DEFAULTWINPROC(hwnd, msg);

                    // Market it by coverity_0543
                    /*
                    //if focus is after this, show it as '*'
                    {
                        U8 j;
                        for (j = 0; j < COUNTOF(_PasswordData); j++)
                        {
                            if (MApp_ZUI_API_GetFocus()== _PasswordData[j].hwnd)
                                break;
                        }
                        if (j == COUNTOF(_PasswordData)) //if not in the password input, we do nothing...
                            return DEFAULTWINPROC(hwnd, msg);
                        if (i >= j) //if current password input is after focus (not yet input)
                            return DEFAULTWINPROC(hwnd, msg);
                    }
                    {
                        DRAW_TEXT_OUT_DYNAMIC * dyna;
                        U16 u16TextIndex = _MApp_ZUI_API_FindFirstComponentIndex(hwnd, DS_NORMAL, CP_TEXT_OUT);
                        if (u16TextIndex != 0xFFFF)
                        {
                            param->dc.u8ConstantAlpha = MApp_ZUI_API_GetNormalAlpha(hwnd);

                            dyna = (DRAW_TEXT_OUT_DYNAMIC*)_ZUI_MALLOC(sizeof(DRAW_TEXT_OUT_DYNAMIC));
                            if (dyna)
                            {
                                LPTSTR str = CHAR_BUFFER;
                                _MApp_ZUI_API_ConvertTextComponentToDynamic(u16TextIndex, dyna);
                                str[0] = '*';
                                str[1] = 0;
                                dyna->pString = str;
                                _MApp_ZUI_API_DrawDynamicComponent(CP_TEXT_OUT_DYNAMIC, dyna, &param->dc, param->rect);
                                _ZUI_FREE(dyna);
                            }
                        }
                    }
                    */
                }

            }
            return 0;
        default:
            break;


    }

    return DEFAULTWINPROC(hwnd, msg);
}

void MApp_ZUI_SwUpdate_ProgressBar(U8 percent)
{
    U8 u8tmp = 0;

    if(_eCommonDlgMode == EN_COMMON_DLG_MODE_USB_UPGRADING)
    {
        static const HWND aUpdateWindows[] =
        {
            //HWND_MENU_DLG_COMMON_NEW_BG_C,
            HWND_MENU_DLG_COMMON_ICON,
            HWND_MENU_DLG_COMMON_TEXT4,
            HWND_MENU_DLG_COMMON_TEXT2,
        };

        USB_Upgrade_Percent = percent;
        u8tmp = sizeof(aUpdateWindows)/sizeof(HWND);
        _MApp_ZUI_API_ForceUpdateWindows((HWND*)aUpdateWindows,u8tmp);
    }
    return;
}

#undef MAPP_ZUI_ACTMENUDLGFUNC_C

