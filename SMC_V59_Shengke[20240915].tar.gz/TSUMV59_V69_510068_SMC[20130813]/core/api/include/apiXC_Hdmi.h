////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _API_XC_HDMI_H_
#define _API_XC_HDMI_H_

//-------------------------------------------------------------------------------------------------
//  Include Files
//-------------------------------------------------------------------------------------------------
#include "Board.h"
#include "msAPI_Mode.h"

//-------------------------------------------------------------------------------------------------
//  Macro and Define
//-------------------------------------------------------------------------------------------------

#define HDMI_POLLING_COUNTER   (30)    // 30 ms

//-------------------------------------------------------------------------------------------------
//  Type and Structure
//-------------------------------------------------------------------------------------------------
typedef enum
{
    E_XC_HDMI_FAIL = 0,
    E_XC_HDMI_OK = 1,
    E_XC_HDMI_GET_BASEADDR_FAIL,            ///< get base address failed when initialize panel driver
    E_XC_HDMI_OBTAIN_MUTEX_FAIL,            ///< obtain mutex timeout when calling this function
} XC_HDMI_Result;

typedef enum
{
    E_HDMI_STATUS_UNKNOWN,
    E_HDMI_STATUS_DVI,
    E_HDMI_STATUS_HDMI,
} E_XC_HDMI_Status;

typedef struct
{
    MS_U8   *pu8HDCP_Key;       ///< 289 bytes HDCP Key
    MS_BOOL bHotPlugInverse;    ///< hot plug pin inverse or not
} XC_HDMI_InitData;

//-------------------------------------------------------------------------------------------------
//  Function and Variable
//-------------------------------------------------------------------------------------------------

extern HDMI_PACKET_INFO_t       g_HdmiPacketInfo;


// Init
XC_HDMI_Result MApi_XC_HDMI_Init(XC_HDMI_InitData *pstXC_HDMI_InitData, MS_U32 u32InitDataLen);
void MApi_XC_HDMI_Handler_Init(void);

// Switch Src
void MApi_XC_DVI_SwitchSrc( E_MUX_INPUTPORT enInputPortType );
U16 MApi_XC_HDMI_Func_Caps(void);

// HPD control
void MApi_XC_HDMI_SetHotPlug(MS_BOOL bEnable, E_MUX_INPUTPORT enInputPortType);             ///< ENABLE: high, DISABLE: low
void MApi_XC_HDMI_SetDVIClkPullLow(MS_BOOL bPullLow, E_MUX_INPUTPORT enInputPortType);      ///< TRUE: pull low, FALSE: pull high

// HDCP
void MApi_XC_HDCP_Init(MS_U8 *pu8HDCP_Key);
void MApi_XC_HDCP_Status_Reset(void);
void MApi_XC_HDCP_Enable(MS_BOOL bEnable);

void MApi_XC_HDMI_CheckAndAdjustDVI(INPUT_SOURCE_TYPE_t InputSourceType);

E_XC_HDMI_Status MApi_XC_HDMI_GetHdmiType(INPUT_SOURCE_TYPE_t enInputSourceType);
BOOLEAN MApi_XC_HDMI_Monitor(INPUT_SOURCE_TYPE_t enInputSourceType);
BOOLEAN MApi_XC_HDMI_CheckModeChanged(BOOLEAN bImmediately, SCALER_WIN eWindow);

void MApi_XC_HDCP_Vsync_end_en(MS_BOOL bStable);

void MApi_XC_HDMI_CheckPacketInfo(void);
const HDMI_PACKET_INFO_t *MApi_XC_HDMI_GetPacketInfo(void);
BOOLEAN MApi_XC_HDMI_CheckSumAndBCH(INPUT_SOURCE_TYPE_t enInputSourceType);

#undef INTERFACE
#endif /* _API_XC_HDMI_H_ */
