////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
//  Description: Memory mapping information package
//
///////////////////////////////////////////////////////////////////////////////
#ifndef _MSAPI_MMAP_H_
#define _MSAPI_MMAP_H_

#ifdef MSAPI_MMAP_C
#define INTERFACE
#else
#define INTERFACE extern
#endif

//------------------------------------------------------------------------------
//                               Define
//------------------------------------------------------------------------------
// Utility define
#define PlaceU32(x) x&0xFF, (x>>8)&0xFF, (x>>16)&0xFF, (x>>24)&0xFF
#define PlaceU16(y) y&0xFF, (y>>8)&0xFF
#define PlaceU32_(x) ((x)>>24)&0xFF, ((x)>>16)&0xFF, ((x)>>8)&0xFF, (x)&0xFF
#define PlaceU16_(y) ((y)>>8)&0xFF, (y)&0xFF

// System Information Block ID
#define S_MMAP_ID           0x0000

//-----------------------------------------------
// S_MMAP_ID
//-----------------------------------------------
// Memory block ID define for MCU
#define MEM_HK51_CODE_ID    0x0000
#define MEM_HK51_DATA_ID    0x0001
#define MEM_AEON_MEM_ID     0x0002
// Memory block ID define for HW Engine
#define MEM_MAD_BUF_ID      0x0100
#define MEM_SEC_BUF_ID      0x0101
#define MEM_MVD_BS_ID       0x0102
#define MEM_MVD_FB_ID       0x0103
#define MEM_MAD_BS_ID       0x0104
// Memory block ID define for SW Application
#define MEM_MHEG5_FB_ID     0x0200

#define DYNAMIC_MMAP_FOR_BEON           TRUE

#define MMAP_ID_BEON_A                  0x00
#define MMAP_ID_MAD_DEC_BUF             0x0B
#define MMAP_ID_MAD_SE_BUF              0x0C
#define MMAP_ID_BEON_BUF                0x1E
#define MMAP_ID_CAPE_BUF                0x20
#define MMAP_ID_CAPE_JPEG_BUF           0x21
#define MMAP_ID_CAPE_POOL_BEGIN         0x22 //0x22~0x29 is reserved for CAPE multiple buffer ids
#define MMAP_ID_CAPE_POOL_END           0x29 //do not allocate id in this range

#if DYNAMIC_MMAP_FOR_BEON
INTERFACE BOOLEAN msAPI_MMap_SendMMapAddr(void);
INTERFACE BOOLEAN msAPI_MMap_SendMMapAddr_CAPE(void);
#endif

#endif

