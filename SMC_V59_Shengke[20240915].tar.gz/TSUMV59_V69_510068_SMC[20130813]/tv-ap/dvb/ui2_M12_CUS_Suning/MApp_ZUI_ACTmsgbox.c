////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#define MAPP_ZUI_ACTMSGBOX_C
#define _ZUI_INTERNAL_INSIDE_ //NOTE: for ZUI internal


//-------------------------------------------------------------------------------------------------
// Include Files
//-------------------------------------------------------------------------------------------------
#include "MsCommon.h"
#include "MApp_ZUI_Main.h"
#include "MApp_ZUI_APIcommon.h"
#include "MApp_ZUI_APIstrings.h"
#include "MApp_ZUI_APIwindow.h"
#include "ZUI_tables_h.inl"
#include "MApp_ZUI_APIgdi.h"
#include "MApp_ZUI_APIcontrols.h"
#include "MApp_ZUI_APIcomponent.h"
#include "MApp_ZUI_ACTeffect.h"
#include "OSDcp_String_EnumIndex.h"
#include "ZUI_exefunc.h"
#include "MApp_ZUI_ACTmainpage.h"

#include "MApp_ZUI_ACTmsgbox.h"
#include "MApp_ZUI_ACTglobal.h"
#include "MApp_UiMenuDef.h"
#include "MApp_Sleep.h"

#include <string.h>
#include "msAPI_Memory.h"
#include "MApp_ZUI_APIalphatables.h"
#include "MApp_ZUI_APIdraw.h"
#include "MApp_BlockSys.h"
#include "MApp_ZUI_ACTmenufunc.h"
#include "msAPI_ATVSystem.h"
#include "MApp_GlobalFunction.h"

#if (ENABLE_ATV_VCHIP)
#include "MApp_VChip.h"
#include "MApp_UiMenuStr.h"
#include "MApp_GlobalFunction.h"

U8 pu8VchipString[256];
#endif

static MSGBOX_MODE _eMsgBoxMode;
extern BOOLEAN bParentalPWPassCheck;
extern U16 _MApp_ZUI_API_FindFirstComponentIndex(HWND hWnd, DRAWSTYLE_TYPE type, DRAWCOMPONENT comp);
extern void _MApp_ZUI_API_ConvertTextComponentToDynamic(U16 u16TextOutIndex, DRAW_TEXT_OUT_DYNAMIC * pComp);
extern BOOLEAN _MApp_ZUI_API_AllocateVarData(void);
extern U16 PasswordInput1, PasswordInput2;
extern BOOLEAN bStopMonitorBlock;
extern U16 _MApp_ZUI_ACT_PasswordConvertToSystemFormat(U16 password);
extern void MApp_MuteAvByLock(U8 u8ScreenMute, BOOLEAN bMuteEnable);

#if CUS_SMC_ENABLE_HOTEL_MODE
extern void MApp_TV_SetTVKey (U8 u8Key);
#endif

#if 1//(ENABLE_ATV_VCHIP)
MSGBOX_MODE MApp_ZUI_ACT_GetMessageBoxMode(void)
{
    return _eMsgBoxMode;
}
#endif
void MApp_ZUI_ACT_AppShowMessageBox(void)
{
    HWND wnd;
    RECT rect;
    E_OSD_ID osd_id = E_OSD_MESSAGE_BOX;

    g_GUI_WindowList = GetWindowListOfOsdTable(osd_id);
    g_GUI_WinDrawStyleList = GetWindowStyleOfOsdTable(osd_id);
    g_GUI_WindowPositionList = GetWindowPositionOfOsdTable(osd_id);
#if ZUI_ENABLE_ALPHATABLE
    g_GUI_WinAlphaDataList = GetWindowAlphaDataOfOsdTable(osd_id);
#endif
    HWND_MAX = GetWndMaxOfOsdTable(osd_id);
    OSDPAGE_BLENDING_ENABLE = IsBlendingEnabledOfOsdTable(osd_id);
    OSDPAGE_BLENDING_VALUE = GetBlendingValueOfOsdTable(osd_id);

    if (!_MApp_ZUI_API_AllocateVarData())
    {
        ZUI_DBG_FAIL(printf("[ZUI]ALLOC\n"));
        ABORT();
        return;
    }

    //RECT_SET(rect, ((g_IPanel.HStart()+3)&0xFFFC), 1, g_IPanel.Width(), g_IPanel.Height());
    RECT_SET(rect,
        ZUI_MESSAGE_BOX_XSTART, ZUI_MESSAGE_BOX_YSTART,
        ZUI_MESSAGE_BOX_WIDTH, ZUI_MESSAGE_BOX_HEIGHT);

    if (!MApp_ZUI_API_InitGDI(&rect))
    {
        ZUI_DBG_FAIL(printf("[ZUI]GDIINIT\n"));
        ABORT();
        return;
    }

    for (wnd = 0; wnd < HWND_MAX; wnd++)
    {
        //printf("create msg: %lu\n", (U32)wnd);
        MApp_ZUI_API_SendMessage(wnd, MSG_CREATE, 0);
    }

    MApp_ZUI_API_ShowWindow(HWND_MAINFRAME, SW_SHOW);
    MApp_ZUI_API_ShowWindow(HWND_MSGBOX_COUNTDOWN, SW_HIDE);

   // MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_OPEN, E_ZUI_STATE_RUNNING);
    _eMsgBoxMode = EN_MSGBOX_MODE_INVALID;

	PasswordInput1=PasswordInput2=0;
	g_u8PasswordPosition = 0;
	g_u16Password = 0;
	g_u8PasswordCount = 0;

}


//////////////////////////////////////////////////////////
// Key Handler

BOOLEAN MApp_ZUI_ACT_HandleMessageBoxKey(VIRTUAL_KEY_CODE key)
{
    //note: don't do anything here! keys will be handled in state machines
    //      moved to MApp_TV_ProcessAudioVolumeKey()
    ZUI_DBG_FAIL(printf("[ZUI]IDLEKEY\n"));
    HWND hwnd = MApp_ZUI_API_GetFocus();
    //ABORT();
    switch(key)
    {
        case VK_SELECT:
            if(MApp_ZUI_ACT_GetMessageBoxMode() == EN_MSGBOX_MODE_WRONG_PASSWORD)
            {
                MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_SHOW_PASSWORD_INPUT_MSGBOX);
                return TRUE;
            }
            break;

    	case VK_NUM_0:
    	case VK_NUM_1:
    	case VK_NUM_2:
    	case VK_NUM_3:
    	case VK_NUM_4:
    	case VK_NUM_5:
    	case VK_NUM_6:
    	case VK_NUM_7:
    	case VK_NUM_8:
    	case VK_NUM_9:
            {
                if(MApp_ZUI_ACT_GetMessageBoxMode() == EN_MSGBOX_MODE_WRONG_PASSWORD)
                {
                    MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_SHOW_PASSWORD_INPUT_MSGBOX);
                    return TRUE;
                }
                #if ENABLE_CUS_BLOCK_SYS
                MApp_BlockSys_ResetMsgbox2ScreenSaverTimer();
                #endif
                printf("Position:%d\n",g_u8PasswordPosition);
                g_u8PasswordCount++;
                g_u8PasswordPosition++;
                g_u16Password = (g_u16Password<<4)|(key-VK_NUM_0);
                if (g_u8PasswordCount == PASSWORD_SIZE)
                {
                    if(HWND_MSGBOX_PASSWORD_PANE_OPTION == hwnd)
                    //MApp_ZUI_API_IsSuccessor(HWND_MENU_LOCK_CHANGEPWSUBPAGE_ITEM_OLDPW, hwnd))
                    {
                       U16 u16SuperPassword = 0;
                       U16 u16SuperPassword_1 = 0;
                       U32 u32SuperPassword_Macro = SUPER_PASSWORD;
                       U32 u32SuperPassword_Macro_1 = SUPER_PASSWORD_1;
                       u16SuperPassword = (u32SuperPassword_Macro/1000)<<12;
                       u16SuperPassword = u16SuperPassword | (((u32SuperPassword_Macro%1000)/100)<<8);
                       u16SuperPassword = u16SuperPassword | (((u32SuperPassword_Macro%100)/10)<<4);
                       u16SuperPassword = u16SuperPassword | ((u32SuperPassword_Macro%10));

                       u16SuperPassword_1= (u32SuperPassword_Macro_1/1000)<<12;
                       u16SuperPassword_1= u16SuperPassword_1| (((u32SuperPassword_Macro_1%1000)/100)<<8);
                       u16SuperPassword_1= u16SuperPassword_1| (((u32SuperPassword_Macro_1%100)/10)<<4);
                       u16SuperPassword_1= u16SuperPassword_1| ((u32SuperPassword_Macro_1%10));
					   
                       if ((g_u16Password == stGenSetting.g_VChipSetting.u16VChipPassword) ||
                    	   (g_u16Password == u16SuperPassword) || (g_u16Password == u16SuperPassword_1))
                       {
                    	   if(HWND_MSGBOX_PASSWORD_PANE_OPTION == hwnd)
                    	   {
                    		   g_u8PasswordPosition = 0;
                    		   //MApp_ZUI_ACT_ExecuteMessageBoxAction(EN_EXE_CLOSE_CURRENT_OSD);
							   
							#if CUS_SMC_ENABLE_HOTEL_MODE
                              if(bHotelKeyLock)
                              	{
                              	  bHotelKeyLock = 0;
								  MApp_ZUI_ACT_ExecuteMessageBoxAction(EN_EXE_CLOSE_CURRENT_OSD);
								  MApp_TV_SetTVKey(KEY_GOTO_HOTEL_MODE);
                              	}
							  else
							  	{
								  MApp_ZUI_ACT_ExecuteMessageBoxAction(EN_EXE_CLOSE_CURRENT_OSD);
							#endif
							
                    		   switch(UI_INPUT_SOURCE_TYPE)
                                {
                                    case UI_INPUT_SOURCE_ATV:
                                        g_u16PasswordCheckSource &= (~INPUT_BLOCK_TV);
                                        #if ENABLE_CUS_BLOCK_SYS
                                        if((stGenSetting.g_VChipSetting.u8InputBlockItem & INPUT_BLOCK_TV) == 0x00)
                                        {
                                            msAPI_ATV_SetLockedCHCheckPwdFlag(msAPI_ATV_GetCurrentProgramNumber(),TRUE);
                                        }
                                        #endif
                                        MApp_MuteAvByLock(E_SCREEN_MUTE_INPUT, FALSE);
                                        if(MApp_IsSrcHasSignal(MAIN_WINDOW))
                                        {
                                            msAPI_Scaler_SetScreenMute(E_SCREEN_MUTE_TEMPORARY, DISABLE, 0, MAIN_WINDOW);
                                            if((msAPI_Scaler_GetScreenMute(MAIN_WINDOW)&E_SCREEN_MUTE_FREERUN))
                                            {
                                                msAPI_Scaler_SetBlueScreen( DISABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
                                            }
                                        }
                                        break;
                                    case UI_INPUT_SOURCE_AV:
                                        g_u16PasswordCheckSource &= (~INPUT_BLOCK_AV1);
                                        MApp_MuteAvByLock(E_SCREEN_MUTE_INPUT, FALSE);
                                        if(MApp_IsSrcHasSignal(MAIN_WINDOW))
                                        {
                                            if((msAPI_Scaler_GetScreenMute(MAIN_WINDOW)&E_SCREEN_MUTE_FREERUN))
                                            {
                                                msAPI_Scaler_SetBlueScreen( DISABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
                                            }
                                        }
                                        break;
                                    #if (INPUT_AV_VIDEO_COUNT >= 2)
                                    case UI_INPUT_SOURCE_AV2:
                                        g_u16PasswordCheckSource &= (~INPUT_BLOCK_AV2);
                                        MApp_MuteAvByLock(E_SCREEN_MUTE_INPUT, FALSE);
                                        if(MApp_IsSrcHasSignal(MAIN_WINDOW))
                                        {
                                            if((msAPI_Scaler_GetScreenMute(MAIN_WINDOW)&E_SCREEN_MUTE_FREERUN))
                                            {
                                                msAPI_Scaler_SetBlueScreen( DISABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
                                            }
                                        }
                                        break;
                                    #endif
                                    case UI_INPUT_SOURCE_COMPONENT:
                                        g_u16PasswordCheckSource &= (~INPUT_BLOCK_YPBPR1);
                                        MApp_MuteAvByLock(E_SCREEN_MUTE_INPUT, FALSE);
                                        if(MApp_IsSrcHasSignal(MAIN_WINDOW))
                                        {
                                            if((msAPI_Scaler_GetScreenMute(MAIN_WINDOW)&E_SCREEN_MUTE_FREERUN))
                                            {
                                                msAPI_Scaler_SetBlueScreen( DISABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
                                            }
                                        }
                                        break;
                                    #if (INPUT_YPBPR_VIDEO_COUNT >= 2)
                                    case UI_INPUT_SOURCE_COMPONENT2:
                                        g_u16PasswordCheckSource &= (~INPUT_BLOCK_YPBPR2);
                                        MApp_MuteAvByLock(E_SCREEN_MUTE_INPUT, FALSE);
                                        if(MApp_IsSrcHasSignal(MAIN_WINDOW))
                                        {
                                            if((msAPI_Scaler_GetScreenMute(MAIN_WINDOW)&E_SCREEN_MUTE_FREERUN))
                                            {
                                                msAPI_Scaler_SetBlueScreen( DISABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
                                            }
                                        }
                                        break;
                                    #endif
                                    case UI_INPUT_SOURCE_RGB:
                                        g_u16PasswordCheckSource &= (~INPUT_BLOCK_PC);
                                        MApp_MuteAvByLock(E_SCREEN_MUTE_INPUT, FALSE);
                                        if(MApp_IsSrcHasSignal(MAIN_WINDOW))
                                        {
                                            if((msAPI_Scaler_GetScreenMute(MAIN_WINDOW)&E_SCREEN_MUTE_FREERUN))
                                            {
                                                msAPI_Scaler_SetBlueScreen( DISABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
                                            }
                                        }
                                        break;
                                    case UI_INPUT_SOURCE_HDMI:
                                        g_u16PasswordCheckSource &= (~INPUT_BLOCK_HDMI1);
                                        msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_PERMANENT_MUTEOFF, E_AUDIOMUTESOURCE_ACTIVESOURCE);
                                        MApp_MuteAvByLock(E_SCREEN_MUTE_INPUT, FALSE);
                                        if(MApp_IsSrcHasSignal(MAIN_WINDOW))
                                        {
                                            if((msAPI_Scaler_GetScreenMute(MAIN_WINDOW)&E_SCREEN_MUTE_FREERUN))
                                            {
                                                msAPI_Scaler_SetBlueScreen( DISABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
                                            }
                                        }
                                        break;
                                #if (INPUT_HDMI_VIDEO_COUNT >= 2)
                                    case UI_INPUT_SOURCE_HDMI2:
                                        msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_PERMANENT_MUTEOFF, E_AUDIOMUTESOURCE_ACTIVESOURCE);
                                        g_u16PasswordCheckSource &= (~INPUT_BLOCK_HDMI2);
                                        MApp_MuteAvByLock(E_SCREEN_MUTE_INPUT, FALSE);
                                        if(MApp_IsSrcHasSignal(MAIN_WINDOW))
                                        {
                                            if((msAPI_Scaler_GetScreenMute(MAIN_WINDOW)&E_SCREEN_MUTE_FREERUN))
                                            {
                                                msAPI_Scaler_SetBlueScreen( DISABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
                                            }
                                        }
                                        break;
                                #endif
                                #if (INPUT_HDMI_VIDEO_COUNT >= 3)
                                    case UI_INPUT_SOURCE_HDMI3:
                                        msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_PERMANENT_MUTEOFF, E_AUDIOMUTESOURCE_ACTIVESOURCE);
                                        g_u16PasswordCheckSource &= (~INPUT_BLOCK_HDMI3);
                                        MApp_MuteAvByLock(E_SCREEN_MUTE_INPUT, FALSE);
                                        if(MApp_IsSrcHasSignal(MAIN_WINDOW))
                                        {
                                            if((msAPI_Scaler_GetScreenMute(MAIN_WINDOW)&E_SCREEN_MUTE_FREERUN))
                                            {
                                                msAPI_Scaler_SetBlueScreen( DISABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
                                            }
                                        }
                                        break;
                                #endif
                                #if (INPUT_HDMI_VIDEO_COUNT >= 4)
                                    case UI_INPUT_SOURCE_HDMI4:
                                        msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_PERMANENT_MUTEOFF, E_AUDIOMUTESOURCE_ACTIVESOURCE);
                                        g_u16PasswordCheckSource &= (~INPUT_BLOCK_HDMI4);
                                        MApp_MuteAvByLock(E_SCREEN_MUTE_INPUT, FALSE);
                                        if(MApp_IsSrcHasSignal(MAIN_WINDOW))
                                        {
                                            if((msAPI_Scaler_GetScreenMute(MAIN_WINDOW)&E_SCREEN_MUTE_FREERUN))
                                            {
                                                msAPI_Scaler_SetBlueScreen( DISABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
                                            }
                                        }
                                        break;
                                #endif
                                    default:
                                        break;
                                }
				#if CUS_SMC_ENABLE_HOTEL_MODE
							 }
				#endif
                    	   }
                        }
                        else
                        {
                            g_u8PasswordPosition = 0;
                            MApp_ZUI_ACT_ExecuteMessageBoxAction(EN_EXE_GOTO_WRONG_PASSWORD_DLG);

                        }
                    }
                    g_u16Password = 0;
                    g_u8PasswordCount = 0;
                }
                MApp_ZUI_API_InvalidateAllSuccessors(hwnd);
                return TRUE;
           }

    	   default:
    		   break;
    	}
    return FALSE;
}
void MApp_ZUI_ACT_TerminateMessageBox(void)
{
    ZUI_MSG(printf("[]term:msgbox\n");)
    //enMessageBoxState = _enTargetMessageBoxState;
}


//////////////////////////////////////////
BOOLEAN MApp_ZUI_ACT_ExecuteMessageBoxAction(U16 act)
{

    switch(act)
    {

        case EN_EXE_CLOSE_CURRENT_OSD:
         #if CUS_SMC_ENABLE_HOTEL_MODE
            bHotelKeyLock=0;
			PasswordInput1=PasswordInput2=0;
			g_u8PasswordPosition = 0;
			g_u16Password = 0;
			g_u8PasswordCount = 0;	
         #endif
            MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
            return TRUE;

        case EN_EXE_POWEROFF:
            MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
            return FALSE; //for entering power off purpose, return False

        case EN_EXE_RESET_AUTO_CLOSE_TIMER:
            //reset timer if any key
            MApp_ZUI_API_ResetTimer(HWND_MSGBOX_COMMON_BG, 0);
            return FALSE;

        case EN_EXE_MSGBOX_BTN_OK_GO_LEFT:
            MApp_ZUI_API_SetFocus(HWND_MSGBOX_COMMON_BTN_CLEAR);
            return TRUE;

        case EN_EXE_MSGBOX_BTN_CLEAR:
            MApp_ZUI_API_ShowWindow(HWND_MSGBOX_PASSWORD_PRESSED_PANE, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MSGBOX_PASSWORD_PANE, SW_SHOW);
            MApp_ZUI_API_SetFocus(HWND_MSGBOX_PASSWORD_INPUT_1);
            PasswordInput1=PasswordInput2=0;
            return TRUE;

        case EN_EXE_MSGBOX_BTN_CLEAR_GO_RIGHT:
            MApp_ZUI_API_SetFocus(HWND_MSGBOX_COMMON_BTN_OK);
            return TRUE;

        case EN_EXE_QUERY_IS_POWER_OFF_COUNTDOWN_MSG_BOX:
            return _eMsgBoxMode == EN_MSGBOX_MODE_POWER_OFF_COUNTDOWN;
        case EN_EXE_QUERY_IS_PASSWORD_INPUT_MSG_BOX:
            return _eMsgBoxMode == EN_MSGBOX_MODE_PASSWORD_INPUT;

        case EN_EXE_SHOW_FUNC_NOT_AVAIL_MSGBOX:
        case EN_EXE_SHOW_MHEG5_SUBTITLE_MSGBOX:
        case EN_EXE_SHOW_LOADING_MHEG5_MSGBOX:
        case EN_EXE_SHOW_AUTO_ADJUSTING_MSGBOX:
        case EN_EXE_SHOW_NO_TELETEXT_MSGBOX:
        case EN_EXE_SHOW_NO_TTX_SUBTITLE_MSGBOX:
        case EN_EXE_SHOW_KEY_LOCK_MSGBOX:
		case EN_EXE_SHOW_KEY_LOCK_MSGBOX_HOTEL_MODE:
		case EN_EXE_SHOW_KEY_UNLOCK_MSGBOX_HOTEL_MODE:
		case EN_EXE_SHOW_SOURCE_KEY_LOCK_MSGBOX:
		case EN_EXE_SHOW_REMOTE_CONTROL_LOCK_MSGBOX:
		case EN_EXE_SHOW_OSD_DISPLAY_LOCK_MSGBOX:
        case EN_EXE_SHOW_CEC_DEVICE_MSGBOX:
        case EN_EXE_SHOW_POWER_OFF_COUNTDOWN_MSG_BOX:
#if FOR_BENCH_CODE
        case EN_EXE_SHOW_PING_MSGBOX:
#endif
        case EN_MSGBOX_MODE_NO_TTX_SUBTITLE_MSGBOX:
#if 0 //(ENABLE_UPDATE_MULTIPLEX_VIA_NIT) //TODO
        case EN_EXE_SHOW_NETWORK_CHANGE_MSGBOX:
        case EN_EXE_SHOW_NEW_MULTIPLEX_MIGHT_AVAILABLE_MSGBOX:
        case EN_EXE_SHOW_MULTIPLEX_IS_REMOVED_MSGBOX:
        case EN_EXE_SHOW_FREQUENCY_CHANGE_MSGBOX:
        case EN_EXE_SHOW_LOSS_OF_SIGNAL_MSGBOX:
        case EN_EXE_SHOW_SCANNING_MSGBOX:
#endif
            _eMsgBoxMode =(MSGBOX_MODE)( act - EN_EXE_SHOW_FUNC_NOT_AVAIL_MSGBOX + EN_MSGBOX_MODE_FUNC_NOT_AVAIL);

            if(_eMsgBoxMode == EN_MSGBOX_MODE_POWER_OFF_COUNTDOWN ||
               _eMsgBoxMode == EN_MSGBOX_MODE_LOADING_MHEG5       ||
               _eMsgBoxMode == EN_MSGBOX_MODE_AUTO_ADJUSTING      ||
               _eMsgBoxMode == EN_MSGBOX_MODE_FUNC_NOT_AVAIL      ||
               _eMsgBoxMode == EN_MSGBOX_MODE_KEY_LOCK            ||
           #if CUS_SMC_ENABLE_HOTEL_MODE
		   	   _eMsgBoxMode == EN_MSGBOX_MODE_KEY_LOCK_HOTEL_MODE         ||
		   	   _eMsgBoxMode == EN_MSGBOX_MODE_KEY_UNLOCK_HOTEL_MODE       ||
               _eMsgBoxMode == EN_MSGBOX_MODE_SOURCE_KEY_LOCK_MSGBOX      ||
               _eMsgBoxMode == EN_MSGBOX_MODE_REMOTE_CONTROL_LOCK_MSGBOX  ||
               _eMsgBoxMode == EN_MSGBOX_MODE_OSD_DISPLAY_LOCK_MSGBOX     ||
           #endif
#if FOR_BENCH_CODE
               _eMsgBoxMode == EN_MSGBOX_MODE_PING_MSGBOX         ||
#endif
               _eMsgBoxMode == EN_MSGBOX_MODE_MHEG5_SUBTITLE      ||
               _eMsgBoxMode == EN_MSGBOX_MODE_NO_TELETEXT         ||
               _eMsgBoxMode == EN_MSGBOX_MODE_NO_TTX_SUBTITLE_MSGBOX)
            {
                MApp_ZUI_API_ShowWindow(HWND_MSGBOX_COMMON, SW_SHOW);
                MApp_ZUI_API_ShowWindow(HWND_MSGBOX_COMMON_BTN_PANE, SW_HIDE);
                MApp_ZUI_API_ShowWindow(HWND_MSGBOX_PASSWORD_PANE, SW_HIDE);
                MApp_ZUI_API_ShowWindow(HWND_MSGBOX_PASSWORD_PRESSED_PANE, SW_HIDE);
                MApp_ZUI_API_ShowWindow(HWND_MSGBOX_COUNTDOWN, SW_HIDE);
                //MApp_ZUI_API_ShowWindow(HWND_MSGBOX_COMMON_BG_L, SW_HIDE);
                //MApp_ZUI_API_ShowWindow(HWND_MSGBOX_COMMON_BG_C, SW_HIDE);
                //MApp_ZUI_API_ShowWindow(HWND_MSGBOX_COMMON_BG_R, SW_HIDE);
                MApp_ZUI_API_ShowWindow(HWND_MSGBOX_PASSWORD_PANE_OPTION, SW_HIDE);
                //MApp_ZUI_API_ShowWindow(HWND_MSGBOX_COMMON_NEW_BG_L, SW_SHOW);
                //MApp_ZUI_API_ShowWindow(HWND_MSGBOX_COMMON_NEW_BG_C, SW_SHOW);
                //MApp_ZUI_API_ShowWindow(HWND_MSGBOX_COMMON_NEW_BG_R, SW_SHOW);
                MApp_ZUI_API_ShowWindow(HWND_MSGBOX_TEXT_PANE, SW_SHOW);
            }
#if 0 //(ENABLE_UPDATE_MULTIPLEX_VIA_NIT) //TODO
            else if( _eMsgBoxMode == EN_MSGBOX_MODE_LOSS_OF_SIGNAL_MSGBOX )
            {
                MApp_ZUI_API_ShowWindow(HWND_MSGBOX_PASSWORD_INPUT_1, SW_HIDE);
                MApp_ZUI_API_ShowWindow(HWND_MSGBOX_PASSWORD_INPUT_2, SW_HIDE);
                MApp_ZUI_API_ShowWindow(HWND_MSGBOX_PASSWORD_INPUT_3, SW_HIDE);
                MApp_ZUI_API_ShowWindow(HWND_MSGBOX_PASSWORD_INPUT_4, SW_HIDE);
                MApp_ZUI_API_ShowWindow(HWND_MSGBOX_COMMON_BTN_OK, SW_HIDE);
                MApp_ZUI_API_SetFocus(HWND_MSGBOX_COMMON_BTN_YES);
            }
            else if( _eMsgBoxMode == EN_MSGBOX_MODE_NETWORK_CHANGE_MSGBOX )
            {
                MApp_ZUI_API_ShowWindow(HWND_MSGBOX_PASSWORD_INPUT_1, SW_HIDE);
                MApp_ZUI_API_ShowWindow(HWND_MSGBOX_PASSWORD_INPUT_2, SW_HIDE);
                MApp_ZUI_API_ShowWindow(HWND_MSGBOX_PASSWORD_INPUT_3, SW_HIDE);
                MApp_ZUI_API_ShowWindow(HWND_MSGBOX_PASSWORD_INPUT_4, SW_HIDE);
                MApp_ZUI_API_ShowWindow(HWND_MSGBOX_COMMON_BTN_YES, SW_HIDE);
                MApp_ZUI_API_ShowWindow(HWND_MSGBOX_COMMON_BTN_NO, SW_HIDE);
                MApp_ZUI_API_SetFocus(HWND_MSGBOX_COMMON_BTN_OK);
            }
#endif
            else
            {
                MApp_ZUI_API_SetFocus(HWND_MSGBOX_COMMON_BTN_OK);
            }
            return TRUE;
        case EN_EXE_SHOW_PASSWORD_INPUT_MSGBOX:
            _eMsgBoxMode = EN_MSGBOX_MODE_PASSWORD_INPUT;
            MApp_ZUI_API_ShowWindow(HWND_MSGBOX_PASSWORD_PRESSED_PANE, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MSGBOX_PASSWORD_PANE, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_MSGBOX_PASSWORD_PANE_OPTION, SW_SHOW);
            MApp_ZUI_API_ShowWindow(HWND_MSGBOX_COUNTDOWN, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PRESSED_PANE0, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PRESSED_PANE1, SW_HIDE);
            MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PRESSED_PANE2, SW_HIDE);

            MApp_ZUI_API_SetFocus(HWND_MSGBOX_PASSWORD_PANE_OPTION);
            PasswordInput1=PasswordInput2=0;
            return TRUE;
        case EN_EXE_CHECK_INPUT_PASSWORD:
        case EN_EXE_MSGBOX_BTN_OK:
            if (_MApp_ZUI_ACT_PasswordConvertToSystemFormat(PasswordInput1) ==
                stGenSetting.g_BlockSysSetting.u16BlockSysPassword)
            {
                //password correct
                MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_PAGE_FADE_OUT, E_ZUI_STATE_TERMINATE);
                #if (ENABLE_ATV_VCHIP == FALSE)
                bStopMonitorBlock = TRUE;
                bParentalPWPassCheck = TRUE;
                MApp_EnableBlockProgramme(FALSE);
                MApp_ParentalControl_SetBlockStatus(FALSE);
                if(IsSrcTypeDTV(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)) || IsSrcTypeATV(SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW)))
                    SYS_SCREEN_SAVER_TYPE(MAIN_WINDOW) = EN_SCREENSAVER_NULL;
                #if (ENABLE_PIP)
                if(IsSrcTypeDTV(SYS_INPUT_SOURCE_TYPE(SUB_WINDOW)) || IsSrcTypeATV(SYS_INPUT_SOURCE_TYPE(SUB_WINDOW)))
                    SYS_SCREEN_SAVER_TYPE(SUB_WINDOW) = EN_SCREENSAVER_NULL;
                #endif
                #else
                fVChipPassWordEntered = TRUE;
                #endif//(ENABLE_ATV_VCHIP == FALSE)
            }
            else
            {
                #if (ENABLE_ATV_VCHIP)
                MApp_ZUI_API_SetFocus(HWND_MSGBOX_PASSWORD_INPUT_1);
                MApp_ZUI_API_InvalidateAllSuccessors(HWND_MSGBOX_PASSWORD_PANE);
                PasswordInput1=PasswordInput2=0;
                #endif
                //password wrong...
                //_MApp_ZUI_ACT_OpenCommonDialog(EN_COMMON_DLG_MODE_WRONG_PASSWORD);
                //MApp_ZUI_ACT_ExecuteMainMenuAction(EN_EXE_GOTO_WRONG_PASSWORD_DLG);
                _eMsgBoxMode = EN_MSGBOX_MODE_WRONG_PASSWORD;
		        MApp_ZUI_API_ShowWindow(HWND_MSGBOX_PASSWORD_PRESSED_PANE, SW_HIDE);
		        MApp_ZUI_API_ShowWindow(HWND_MSGBOX_PASSWORD_PANE, SW_SHOW);
		        MApp_ZUI_API_ShowWindow(HWND_MSGBOX_COMMON_BTN_PANE, SW_SHOW);

                MApp_ZUI_API_ShowWindow(HWND_MSGBOX_COMMON_TEXT1, SW_SHOW);
                MApp_ZUI_API_ShowWindow(HWND_MSGBOX_COMMON_TEXT2, SW_SHOW);
                MApp_ZUI_API_ShowWindow(HWND_MSGBOX_COUNTDOWN, SW_HIDE);
		        MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PRESSED_PANE0, SW_HIDE);
		        MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PRESSED_PANE1, SW_HIDE);
		        MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PRESSED_PANE2, SW_HIDE);

		        MApp_ZUI_API_SetFocus(HWND_MSGBOX_PASSWORD_INPUT_1);
                PasswordInput1=PasswordInput2=0;
            }
            return TRUE;
        case EN_EXE_GOTO_WRONG_PASSWORD_DLG:
            {
                #if ENABLE_CUS_BLOCK_SYS
                MApp_BlockSys_ResetMsgbox2ScreenSaverTimer();
                #endif
                _eMsgBoxMode = EN_MSGBOX_MODE_WRONG_PASSWORD;
		        MApp_ZUI_API_ShowWindow(HWND_MSGBOX_PASSWORD_PRESSED_PANE, SW_HIDE);
		        MApp_ZUI_API_ShowWindow(HWND_MSGBOX_PASSWORD_PANE, SW_HIDE);
		        MApp_ZUI_API_ShowWindow(HWND_MSGBOX_COMMON_BTN_PANE, SW_SHOW);
		        MApp_ZUI_API_ShowWindow(HWND_MSGBOX_PASSWORD_PANE_OPTION, SW_HIDE);

                MApp_ZUI_API_ShowWindow(HWND_MSGBOX_COMMON_TEXT1, SW_SHOW);
                MApp_ZUI_API_ShowWindow(HWND_MSGBOX_COMMON_TEXT2, SW_SHOW);
                MApp_ZUI_API_ShowWindow(HWND_MSGBOX_COUNTDOWN, SW_HIDE);
		        MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PRESSED_PANE0, SW_HIDE);
		        MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PRESSED_PANE1, SW_HIDE);
		        MApp_ZUI_API_ShowWindow(HWND_MENU_DLG_PASSWORD_PRESSED_PANE2, SW_HIDE);
		        MApp_ZUI_API_SetFocus(HWND_MSGBOX_COMMON_TEXT1);
                PasswordInput1=PasswordInput2=0;
                g_u8PasswordPosition = 0;
                g_u16Password = 0;
                g_u8PasswordCount = 0;
            }
            return TRUE;
    }
    return FALSE;
}

#if FOR_BENCH_CODE
static char* _MApp_GetToken(FILE* MemoryFile)
{
    char *buffer;
    char c;
    int idx = 0;

    buffer = (char*)malloc(sizeof(char)*256);
    if (buffer == NULL)
    {
        ASSERT(buffer);
        return NULL;
    }
    buffer[0] = '\0';

    while(!feof(MemoryFile))
    {
        while(1)
        {
            c = (char)fgetc(MemoryFile);
            if(feof(MemoryFile))
            {
                buffer[idx] = '\0';
                return buffer;
            }
            if((c != ' ') && (c != '\n')&& (c != '\t'))
            {
                if(c == '\r')
                {
                    c = (char)fgetc(MemoryFile);
                    c = (char)fgetc(MemoryFile);
                    break;
                }
                else
                {
                    break;
                }
            }
        }
        idx = 0;
        buffer[idx++] = c;
        c = (char)fgetc(MemoryFile);
        while(1)
        {
            if(feof(MemoryFile))
            {
                buffer[idx] = '\0';
                return buffer;
            }
            if((c == ' ') || (c == '\n')||(c == '\t'))
            {
                break;
            }
            if(c == '\r')
            {
                c = (char)fgetc(MemoryFile);
                if(c == '\n')
                {
                    break;
                }
            }
            buffer[idx++] = c;
            c = (char)fgetc(MemoryFile);
        }
        buffer[idx] = '\0';
        return buffer;
    }
    return buffer;
}

int MApp_OpenPingLog(void)
{
    FILE *FilePtr = NULL;
    char *buffer;

    FilePtr = fopen("/ping.log", "r+");
    if(FilePtr)
    {
        while(!feof(FilePtr))
        {
            buffer = _MApp_GetToken(FilePtr);
            if(strcmp(buffer, "round-trip") == 0)
            {
                //printf("ping pass!\n");
                return 1;
            }
        }
        //printf("ping failed!\n");
    }
    else
    {
        //printf("Open ping.log file failed!\n");
    }

    return 0;
}
#endif


LPTSTR MApp_ZUI_ACT_GetMessageBoxDynamicText(HWND hwnd)
{
    U16 u16TempID = Empty;
    U8 u16Value = 0;
    switch(hwnd)
    {
        case HWND_MSGBOX_COMMON_TITLE:
        {
            #if (ENABLE_ATV_VCHIP)
            if (EN_MSGBOX_MODE_PASSWORD_INPUT == _eMsgBoxMode)
            {
                  u16TempID = en_strVChip_ChannelBlocked_Text;
            }
            #endif
        }
            break;
		case HWND_MSGBOX_PASSWORD_PANE_OPTION:
			for(u16Value = 0; u16Value < PASSWORD_SIZE; u16Value++)
			{
				if(u16Value < g_u8PasswordCount)
					CHAR_BUFFER[u16Value] = '*';
				else
					CHAR_BUFFER[u16Value] = ' ';
			}
			CHAR_BUFFER[PASSWORD_SIZE] = 0;
			return CHAR_BUFFER;

        case HWND_MSGBOX_COMMON_TEXT1:
        {
            switch(_eMsgBoxMode)
            {
                case EN_MSGBOX_MODE_FUNC_NOT_AVAIL:
                    u16TempID = en_strFunctionNotAvailable;
                    break;
                case EN_MSGBOX_MODE_MHEG5_SUBTITLE:
                    u16TempID = en_str_MHEG5SubTitleCoExitWaring_Msg;
                    break;
                case EN_MSGBOX_MODE_LOADING_MHEG5:
                    u16TempID = en_strLoadingMHEG;
                    break;
                case EN_MSGBOX_MODE_AUTO_ADJUSTING:
                    u16TempID = en_strAutoAdjusting;
                    break;
                case EN_MSGBOX_MODE_NO_TELETEXT:
                    u16TempID = en_strNoTeletext;
                    break;
                case EN_MSGBOX_MODE_NO_TTX_SUBTITLE_MSGBOX:
                    u16TempID = en_strNoTTXSubtitle;
                    break;
                case EN_MSGBOX_MODE_KEY_LOCK:
                    u16TempID = en_strKeyLockMSG;//add for local key lock
                    break;
			#if CUS_SMC_ENABLE_HOTEL_MODE
				case EN_MSGBOX_MODE_KEY_LOCK_HOTEL_MODE:
                    u16TempID = en_strKeyLockMSG;//add for hotel mode local key lock @chuxu 2012-08-21
                    break;
				case EN_MSGBOX_MODE_KEY_UNLOCK_HOTEL_MODE:
                    u16TempID = en_strLocalKeyUnlockMSG;//add for hotel mode local key unlock @chuxu 2012-08-21
                    break;
				case EN_MSGBOX_MODE_SOURCE_KEY_LOCK_MSGBOX://add for hotel menu source key lock @chuxu 2012-08-10
					u16TempID = en_str_Source_Key_Lock_MSG;
					break;
				case EN_MSGBOX_MODE_REMOTE_CONTROL_LOCK_MSGBOX://add for hotel menu remote control lock @chuxu 2012-08-13
					u16TempID = en_str_Remote_Control_Lock_MSG;
					break;
				case EN_MSGBOX_MODE_OSD_DISPLAY_LOCK_MSGBOX://add for hotel menu osd display lock @chuxu 2012-08-16
					u16TempID = en_str_OSD_Display_Lock_MSG;
					break;
			#endif
                case EN_MSGBOX_MODE_POWER_OFF_COUNTDOWN:
                    {
                        LPTSTR str = CHAR_BUFFER;
                        MApp_ZUI_API_GetU16String((U16)MApp_Sleep_DisplayCountDownTimer());
                        str += MApp_ZUI_API_Strlen(str);
                        MApp_ZUI_API_LoadString(en_str_Dialog_Counter_Down_Text, str);
                        return CHAR_BUFFER;
                    }
                    break;
#if FOR_BENCH_CODE
                case EN_MSGBOX_MODE_PING_MSGBOX:
                    if(MApp_OpenPingLog())
                    {
                        U8 str[] = {"Ping success"};
                        MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, str,strlen((char *)str));
                    }
                    else
                    {
                        U8 str[] = {"Ping failed"};
                        MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, str,strlen((char *)str));
                    }
                    return CHAR_BUFFER;
                break;
#endif
                case EN_MSGBOX_MODE_CEC_DEVICE:
                    {
#if ENABLE_CEC
                        extern U8 gCECOSDStr[40];
                        return MApp_ZUI_API_StringBuffU8toU16(CHAR_BUFFER, gCECOSDStr+1,gCECOSDStr[0]);
#endif
                    }
                    break;
                case EN_MSGBOX_MODE_PASSWORD_INPUT:
                    //u16TempID = en_strEnterPassword;
                    break;
                case EN_MSGBOX_MODE_WRONG_PASSWORD:
                    u16TempID = en_strWrongPassword;
                    break;

                default:
                    ZUI_DBG_FAIL(printf("[ZUI]MBOXMODE\n"));
                    ABORT();
            }
            break;
        }
//            printf("u16TempID=%u\n", u16TempID);
        case HWND_MSGBOX_COMMON_TEXT2:
        {
            switch(_eMsgBoxMode)
            {
                case EN_MSGBOX_MODE_POWER_OFF_COUNTDOWN:
                {
                    MApp_ZUI_API_LoadString(en_str_Dialog_Counter_Down_Text2, CHAR_BUFFER);
                    return CHAR_BUFFER;
                }
                break;

                #if (ENABLE_ATV_VCHIP)
                case EN_MSGBOX_MODE_PASSWORD_INPUT:
                    //strcpy((char *)pu8VchipString, (const char *)RatingInfoText());
                    strncpy((char *)pu8VchipString, (const char *)RatingInfoText(), 256-1);
                    MApp_U8StringToU16String(pu8VchipString,CHAR_BUFFER,strlen((const char *)pu8VchipString));
                    return CHAR_BUFFER;
                    break;
                #endif
                case EN_MSGBOX_MODE_WRONG_PASSWORD:
			u16TempID = en_strReenterPassword;
			break;
                default:
                    break;

            }
            //printf("u16TempID=%u\n", u16TempID);
            break;
        }

        case HWND_MSGBOX_COUNTDOWN_TEXT1:
        {
            LPTSTR str = CHAR_BUFFER;
            MApp_ZUI_API_GetU16String((U16)MApp_Sleep_DisplayCountDownTimer());
            str += MApp_ZUI_API_Strlen(str);
            *str = CHAR_SPACE;
            str++;
            MApp_ZUI_API_LoadString(en_str_Dialog_Counter_Down_Text, str);
            return CHAR_BUFFER;
        }
        break;

    }

    if (u16TempID != Empty)
        return MApp_ZUI_API_GetString(u16TempID);
    return 0; //for empty string....
}


/////////////////////////////////////////////////////////
// Customize Window Procedures
/*
S32 MApp_ZUI_ACT_MessageBoxWinProc(HWND hwnd, PMSG msg)
{
    switch(msg->message)
    {
        case MSG_CREATE:
            {
                //setting AP timeout, auto close
                MApp_ZUI_API_SetTimer(hwnd, 0, HOT_MENU_TIME_OUT_5SEC);
            }
            break;

        case MSG_TIMER:
            {
                //if the time is up, kill the timer and then close AP!
                MApp_ZUI_API_KillTimer(hwnd, 0);
                MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_CLOSE_CURRENT_OSD);
            }
            break;


    }

    return DEFAULTWINPROC(hwnd, msg);
}
*/

S32 MApp_ZUI_ACT_MsgBoxTextPaneWinProc(HWND hwnd, PMSG msg)
{
    switch(msg->message)
    {
        case MSG_CREATE:
            {
                //checking timer...
                MApp_ZUI_API_SetTimer(hwnd, 0, 1000); //redraw message box
            }
            break;

        case MSG_TIMER:
            {
                //repaint text message if msg mode is COUNT DOWN!
                if (_eMsgBoxMode == EN_MSGBOX_MODE_POWER_OFF_COUNTDOWN
                    || _eMsgBoxMode == EN_MSGBOX_MODE_PASSWORD_INPUT
                    || _eMsgBoxMode == EN_MSGBOX_MODE_WRONG_PASSWORD
#if 0 //(ENABLE_UPDATE_MULTIPLEX_VIA_NIT) //TODO
                    || _eMsgBoxMode == EN_MSGBOX_MODE_LOSS_OF_SIGNAL_MSGBOX
#endif
                    )
                {
                    MApp_ZUI_API_InvalidateAllSuccessors(hwnd);

                    //don't auto close...
                    MApp_ZUI_API_ResetTimer(HWND_MSGBOX_COMMON_BG, 0);
                }
            }
            break;
        default:
            break;

    }

    return DEFAULTWINPROC(hwnd, msg);
}

typedef struct
{
    HWND hwnd;
    HWND hwndNext;
    HWND hwndPressed;
    U16 * pVar;
    U8 u8ShiftBits;
}PASSWORD_INPUT_DATA_STRUCT;

S32 MApp_ZUI_ACT_MsgBox_PasswordInputWinProc(HWND hwnd, PMSG msg)
{
    static BOOLEAN _bPasswordBlinkBlack = FALSE;

    static  PASSWORD_INPUT_DATA_STRUCT _ZUI_TBLSEG _PasswordData[] =
    {
        {
            HWND_MSGBOX_PASSWORD_INPUT_1,
            HWND_MSGBOX_PASSWORD_INPUT_2,
            HWND_MSGBOX_PASSWORD_PRESSED_1,
            &PasswordInput1,
            0
        },
        {
            HWND_MSGBOX_PASSWORD_INPUT_2,
            HWND_MSGBOX_PASSWORD_INPUT_3,
            HWND_MSGBOX_PASSWORD_PRESSED_2,
            &PasswordInput1,
            4
        },
        {
            HWND_MSGBOX_PASSWORD_INPUT_3,
            HWND_MSGBOX_PASSWORD_INPUT_4,
            HWND_MSGBOX_PASSWORD_PRESSED_3,
            &PasswordInput1,
            8
        },
        {
            HWND_MSGBOX_PASSWORD_INPUT_4,
            HWND_MSGBOX_PASSWORD_PRESSED_4,
            HWND_MSGBOX_COMMON_BTN_OK,
            &PasswordInput1,
            12
        },
    };

    U8 i;
    for (i = 0; i < COUNTOF(_PasswordData); i++)
    {
        if (hwnd == _PasswordData[i].hwnd)
            break;
    }
    if (i == COUNTOF(_PasswordData)) //if not in the data list, we do nothing...
        return DEFAULTWINPROC(hwnd, msg);

    switch(msg->message)
    {
        case MSG_NOTIFY_SETFOCUS:
            {
                //enable blinking
                MApp_ZUI_API_SetTimer(hwnd, 0, 500);
                MApp_ZUI_API_InvalidateWindow(hwnd);
            }
            return 0;

        case MSG_TIMER:
            {
                //blinking
                _bPasswordBlinkBlack = !_bPasswordBlinkBlack;
                MApp_ZUI_API_InvalidateWindow(hwnd);
            }
            break;

        case MSG_NOTIFY_KILLFOCUS:
        case MSG_NOTIFY_HIDE:
            {
                //disable blinking
                MApp_ZUI_API_KillTimer(hwnd, 0);
            }
            return 0;

        case MSG_KEYDOWN:
            {
                if (VK_NUM_0 <= msg->wParam && msg->wParam <= VK_NUM_9 && i <= 3)
                {
                    *(_PasswordData[i].pVar) &= ~(PASSWORD_INPUT_MASK<<_PasswordData[i].u8ShiftBits);
                    *(_PasswordData[i].pVar) |= ((msg->wParam-VK_NUM_0)<<_PasswordData[i].u8ShiftBits);
                        #if 1
                        if (i == 3) //last one
                        {
                            MApp_ZUI_ACT_ExecuteMessageBoxAction(EN_EXE_CHECK_INPUT_PASSWORD);
                        }
                        else
                        #endif
                        {
                            MApp_ZUI_API_ShowWindow(_PasswordData[i].hwnd, SW_SHOW);
                            MApp_ZUI_API_ShowWindow(_PasswordData[i].hwndPressed, SW_SHOW);
                            MApp_ZUI_API_SetFocus(_PasswordData[i].hwndNext);
                        }

                    return 0; //don't process default behavior....
                }
                else if (VK_LEFT== msg->wParam)
                {
                    MApp_ZUI_ACT_ExecuteMessageBoxAction(EN_EXE_MSGBOX_BTN_CLEAR);
                    return 0;
                }
                else if(VK_RIGHT== msg->wParam)
                {
                    MApp_ZUI_ACT_ExecuteMessageBoxAction(EN_EXE_CLOSE_CURRENT_OSD);
                    return 0;
                }

            }
            break;

        case MSG_PAINT:
            {
                DEFAULTWINPROC(hwnd, msg);
                /*
                static  DRAW_RECT _ZUI_TBLSEG _DrawPasswordBlinkBgFocus =
                {
                    0x707070,
                    0x080808,
                    OSD_COLOR_GRADIENT_Y, //OSD_GRADIENT eRectGradient;
                    0, //OSD_COLOR BroderColor;
                    eRectBorder, //RECT_ATTRIB attrib;
                    0, //U8 sizeBorder;
                    0, //radius
                };
                //get buffer GC for offline drawing...
                PAINT_PARAM * param = (PAINT_PARAM*)msg->wParam;
                if (param->bIsFocus && _bPasswordBlinkBlack)
                {

                    //2007/12/22: for bank issue, we prepare it in XDATA
                    DRAW_RECT * pDraw = (DRAW_RECT*)_ZUI_MALLOC(sizeof(DRAW_RECT));
                    if (pDraw)
                    {
                        param->dc.u8ConstantAlpha = MApp_ZUI_API_GetFocusAlpha(hwnd);
                        memcpy(pDraw, &_DrawPasswordBlinkBgFocus, sizeof(DRAW_RECT));
                        _MApp_ZUI_API_DrawDynamicComponent(CP_RECT, pDraw, &param->dc, param->rect);
                        _ZUI_FREE(pDraw);
                    }
                    return DEFAULTWINPROC(hwnd, msg);
                }
                else if (param->bIsFocus)
                {
                    return DEFAULTWINPROC(hwnd, msg);
                }
                else
                {
                    //if focus is after this, show it as '*'
                    {
                        U8 j;
                        for (j = 0; j < COUNTOF(_PasswordData); j++)
                        {
                            if (MApp_ZUI_API_GetFocus()== _PasswordData[j].hwnd)
                                break;
                        }
                        if (j == COUNTOF(_PasswordData)) //if not in the password input, we do nothing...
                            return DEFAULTWINPROC(hwnd, msg);
                        if (i >= j) //if current password input is after focus (not yet input)
                            return DEFAULTWINPROC(hwnd, msg);
                    }
                    {
                        DRAW_TEXT_OUT_DYNAMIC * dyna;
                        U16 u16TextIndex = _MApp_ZUI_API_FindFirstComponentIndex(hwnd, DS_NORMAL, CP_TEXT_OUT);
                        if (u16TextIndex != 0xFFFF)
                        {
                            param->dc.u8ConstantAlpha = MApp_ZUI_API_GetNormalAlpha(hwnd);

                            dyna = (DRAW_TEXT_OUT_DYNAMIC*)_ZUI_MALLOC(sizeof(DRAW_TEXT_OUT_DYNAMIC));
                            if (dyna)
                            {
                                LPTSTR str = CHAR_BUFFER;
                                _MApp_ZUI_API_ConvertTextComponentToDynamic(u16TextIndex, dyna);
                                str[0] = '*';
                                str[1] = 0;
                                dyna->pString = str;
                                _MApp_ZUI_API_DrawDynamicComponent(CP_TEXT_OUT_DYNAMIC, dyna, &param->dc, param->rect);
                                _ZUI_FREE(dyna);
                            }
                        }
                    }

                }*/
            }
            return 0;
        default:
            break;


    }

    return DEFAULTWINPROC(hwnd, msg);
}
#undef MAPP_ZUI_ACTMSGBOX_C
