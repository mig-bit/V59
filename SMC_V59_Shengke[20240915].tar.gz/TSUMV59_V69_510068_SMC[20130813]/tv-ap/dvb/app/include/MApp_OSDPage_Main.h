////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MAPP_OSDPAGE_MAIN_H
#define _MAPP_OSDPAGE_MAIN_H

#include "datatype.h"
#include "MApp_Exit.h"

#ifdef MAPP_OSDPAGE_MAIN_C
#define INTERFACE
#else
#define INTERFACE extern
#endif

typedef enum
{
    STATE_OSDPAGE_INIT,
    STATE_OSDPAGE_WAIT,
    STATE_OSDPAGE_CHANGE_PAGE,
    STATE_OSDPAGE_CLEAN_UP,
#if ENABLE_DMP
    STATE_OSDPAGE_GOTO_DMP,
#endif
    STATE_OSDPAGE_GOTO_BT,
    STATE_OSDPAGE_GOTO_KTV,
    STATE_OSDPAGE_GOTO_MAIN_MENU,
    STATE_OSDPAGE_GOTO_INPUT_SOURCE,
    STATE_OSDPAGE_GOTO_STANDBY,
    STATE_OSDPAGE_EXIT,
#if BOE_USB_UPGRADE_FACTROY//minglin1206  
STATE_OSDPAGE_GOTO_UPDATE_MENU, 
#endif

} EN_OSDPAGE_STATE;

INTERFACE EN_RET MApp_OSDPage_Main(void);
INTERFACE void MApp_OSDPage_SetOSDPage(E_OSD_ID id);
INTERFACE void MApp_OSDPage_SetState(EN_OSDPAGE_STATE enState);

#undef INTERFACE

#endif  // _MAPP_OSDPAGE_MAIN_H

