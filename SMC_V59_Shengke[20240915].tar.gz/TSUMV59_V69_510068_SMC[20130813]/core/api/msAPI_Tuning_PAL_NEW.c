#include "MsCommon.h"
#include "MsIRQ.h"
#include "MsOS.h"

#include "msAPI_ATVSystem.h"
#include "msAPI_Timer.h"
#include "IF_Demodulator.h"


//#define AUTO_TUNING_FLOW_DEBUG
#if defined(AUTO_TUNING_FLOW_DEBUG)
    #define AUTO_TUNING_FLOW_PRINT(x)           printf(x)
    #define AUTO_TUNING_SYNC_LOCK_PRINT(x,y)    printf(x,y)
#else
    #define AUTO_TUNING_FLOW_PRINT(x)  //printf(x)
    #define AUTO_TUNING_SYNC_LOCK_PRINT(x,y)    //printf(x,y)

#endif


#define VD_CHECK_SYNC_LOCKED            BIT15
#define VD_CHECK_HSYNC_LOCKED           BIT14
#define VD_CHECK_RESET_ON               BIT11
#define VD_CHECK_STATUS_RDY             BIT0
#define TN_READ_LOCK                    BIT0
//------------------------------------------------------
//
//------------------------------------------------------
    static AUTO_SEARCH_TYPE eAutoSearchType;
    static U8 u8NoSyncCount;

    static U8 u8StartFrom;
    static U16 _u16PreviousStationTunerPLL;
    U16 u16JumpDistance;
    TUNING_STATUS eTuningStatus;
    U16 u16VdStatus;
    U8 u8SortingPriority;
    static U16 u16Record_FALSE_SIGNAL_TunerPLL;
    static AUDIOSTANDARD_TYPE u8SoundSystem;
    static AVD_VideoStandardType u8VideoSystem;



#if AUTO_SCAN_TIME_PRINT
    static U32 u32StartAutoTuningTime;
#endif

#if ENABLE_AUTOTEST
    extern BOOLEAN g_bAutobuildDebug;
#endif
//------------------------------------------------------
//
//------------------------------------------------------
#if(FRONTEND_TUNER_TYPE == FRESCO_FM2150A_TUNER)
extern U_INT32 GetActualRF(void);
#define NO_SIGNAL_AFC_TIMEOUT   15
static U8 aOffset=0;
static U_INT32 aCorrectedRF;

static const short code a_RfOffsetPos[]={
    -750, 0x38,
    -700, 0x37,
    -650, 0x33,
    -600, 0x2F,
    -550, 0x2B,
    -500, 0x27,
    -450, 0x23,
    -400, 0x1F,
    -350, 0x1B,
    -300, 0x17,
    -250, 0x13,
    -200, 0xF,
    -150, 0xB,
    -100, 0x7,
    -50,  0x3,
    0,    0xFF,
    50,   0xFB,
    100,  0xF7,
    150,  0xF3,
    200,  0xEF,
    250,  0xEB,
    300,  0xE7,
    350,  0xE3,
    400,  0xDF,
    450,  0xDB,
    500,  0xD7,
    550,  0xD3,
    600,  0xCF,
    650,  0xCB,
    700,  0xC7,
    750,  0xC3,
    800,  0xBF,
    850,  0xBB,
    900,  0xB7,
    950,  0xB3,
    3000, 0x1ff
};

//AlexL  finds offset in KHz closest to passed MST offset
static short aFindOffset(U8 MST_offset)
{
    U8 aPtr=0;
    U8 aSavePtr=0;
    U8 aDelta=0;
    U16 aSavedDelta=3000;
    while (a_RfOffsetPos[aPtr] != 3000)
    {
        aDelta = abs(a_RfOffsetPos[aPtr+1] - MST_offset);
        if (aDelta < aSavedDelta) {
            aSavedDelta = aDelta;
            aSavePtr = aPtr;
        }
        aPtr +=2;
    }
    return a_RfOffsetPos[aSavePtr];
}

static U8 _GetTuner_CR_FOE_Status(void)
{
    U8 u8Value;
    u8Value=DRV_VIF_Read_CR_FOE();
    return u8Value;
}

static AFC _GetAFT_TuningStatus(void)
{
    U8 u8Value;

    u8Value=MDrv_VIF_Read_CR_LOCK_STATUS();
    if (!(u8Value&BIT0))
        return E_AFC_OUT_OF_AFCWIN;
    return E_AFC_PLUS_37p5KHz;//just for debug waring ,not use it
}
#endif

static BOOLEAN _GetVIFLockStatus(void)
{

    if(MDrv_VIF_Read_CR_LOCK_STATUS()&TN_READ_LOCK)
        return TRUE;
    else
        return FALSE;

}

static TUNING_STATUS _GetTuningStatus(void)
{
    AFC eFreqDev;

    eFreqDev = MDrv_IFDM_GetFreqDev();
    AUTO_TUNING_PRINT(printf("AFCWIN=%bx\n",eFreqDev));
    #if (FRONTEND_TUNER_TYPE == FRESCO_FM2150A_TUNER)
      return E_TUNING_STATUS_GOOD;
    #endif

    if ( eFreqDev == E_AFC_OUT_OF_AFCWIN )
    {
        return E_TUNING_STATUS_OUT_OF_AFCWIN;
    }
    // else if ( eFreqDev <= E_AFC_MINUS_12p5KHz || eFreqDev >= E_AFC_PLUS_12p5KHz )
    else if ( eFreqDev <= E_AFC_GOOD_MINUS_VALUE || eFreqDev >= E_AFC_GOOD_PLUS_VALUE )
    {
        return E_TUNING_STATUS_GOOD;
    }
    else if ( eFreqDev <= E_AFC_MINUS_112p5KHz)
    {
        return E_TUNING_STATUS_UNDER_LITTLE;
    }
    else if ( eFreqDev >= E_AFC_PLUS_112p5KHz)
    {
        return E_TUNING_STATUS_OVER_LITTLE;
    }
    else if ( eFreqDev <= E_AFC_MINUS_162p5KHz )
    {
        return E_TUNING_STATUS_UNDER;
    }
    else if ( eFreqDev >= E_AFC_PLUS_162p5KHz )
    {
        return E_TUNING_STATUS_OVER;
    }
    else if ( eFreqDev <= E_AFC_BELOW_MINUS_187p5KHz )
    {
        return E_TUNING_STATUS_UNDER_MORE;
    }
  #if 0 // Marked by coverity_0150
    else if ( eFreqDev >= E_AFC_ABOVE_PLUS_187p5KHz )
    {
        return E_TUNING_STATUS_OVER_MORE;
    }

    else
    {
        /* ASSERT */
    }

    return E_TUNING_STATUS_GOOD;
  #else
    else // only 8
    {
        return E_TUNING_STATUS_OVER_MORE;
    }
  #endif
}


#ifdef ENABLE_SUPPORT_ATV_STATION_NAME
void msAPI_Tuning_GetStationName(void) //move to tuning.c
{
    if ( _u16UpdateStationNameTimer >= WAIT_10ms )
    {
        _u16UpdateStationNameTimer--;

        if ( _u16UpdateStationNameTimer == WAIT_10ms )
        {
        #if ENABLE_TTX
            if ( TRUE != msAPI_TTX_GetStationNameFromTeletext(_sCurrentStationName, MAX_STATION_NAME, NULL) )
        #endif
            {
                msAPI_Tuner_ConvertMediumAndChannelNumberToString(_eMedium, _u8ChannelNumber, _sCurrentStationName);
            }

            _u16UpdateStationNameTimer = WAIT_0ms;
        }
    }
}
#endif

#if(FRONTEND_TUNER_TYPE == FRESCO_FM2150A_TUNER)
void _msAPI_Tuning_AutoFineTuning(void)
{
     static U8 uOffset,PreuOffset;
     static U16 RealMonitorTunerPLL,uBaseTunerPll;

     uOffset=_GetTuner_CR_FOE_Status();
        uBaseTunerPll=(aFindOffset(_u8RealtimeAFTBaseOffset)+(GetActualRF()/1000))/50;
     RealMonitorTunerPLL=(aFindOffset(uOffset)+(GetActualRF()/1000))/50;
     //printf("\r\n AFT_Debug: %x,%x,%x,%x",uOffset,_u8RealtimeAFTBaseOffset,RealMonitorTunerPLL,uBaseTunerPll);

     if ((DIFFERENCE(_u16RealtimeAFTBaseTunerPLL,_u16TunerPLL) > TUNER_PLL_PLUS_1p5MHz ))
     {
        u8ScanAFTFlag=TRUE;
     }
     if(u8ScanAFTFlag)
     {
        if (_u16TunerPLL!=_u16RealtimeAFTBaseTunerPLL)
        {
            printf("\r\n Over + - 1.5M\n");
            u8ScanAFTFlag=FALSE;
            _SetTunerPLL(_u16RealtimeAFTBaseTunerPLL);
            msAPI_Tuner_SetIF();
        }
        return;
     }

    if(!(MDrv_AVD_GetStatus()&(VD_CHECK_SYNC_LOCKED|VD_CHECK_HSYNC_LOCKED)))
    {
        if( u8ScanAFTCount > NO_SIGNAL_AFC_TIMEOUT)
        {
            return;
        }
        else if(u8ScanAFTCount <= NO_SIGNAL_AFC_TIMEOUT)
        {
            _SetTunerPLL(_u16RealtimeAFTBaseTunerPLL);
            msAPI_Tuner_SetIF();
            u8ScanAFTCount++;
            printf("\r\n TV no signal time out--AFT Off\n");
            return;
        }
    }
    else
    {
        u8ScanAFTCount = 0;
    }

    if(_GetAFT_TuningStatus()==E_AFC_OUT_OF_AFCWIN)
    {
         //if (_GetVIFLockStatus())
         {
             printf("\r\n waring need +-1Mhz");
             if(uOffset>0x2F)//if offset <=-600K,than need baseTunerPll -1M
             {
                 _u16TunerPLL=uBaseTunerPll+TUNER_PLL_MINUS_1MHz;
                 _SetTunerPLL( _u16TunerPLL);
                 msAPI_Tuner_SetIF();
                 u8ScanAFTCount=0;
             }
             else if(uOffset<0xCF)//if offset >=600K,than need baseTunerPll +1M
             {
                 _u16TunerPLL=uBaseTunerPll+TUNER_PLL_PLUS_1MHz;
                 _SetTunerPLL( _u16TunerPLL);
                 msAPI_Tuner_SetIF();
                 u8ScanAFTCount=0;
             }
         }
         /*else
         {
             //donothing here
             printf("\r\n VIF No LockStatus!\n");
         }*/
         return;
    }
    else if((MDrv_AVD_GetStatus()&(VD_CHECK_HSYNC_LOCKED)))
    {
         if((uOffset!=_u8RealtimeAFTBaseOffset))
         {
            printf("\r\n Auto SetTuner Freq");
            PreuOffset=uOffset;
            u8ScanAFTCount=0;
           _u8RealtimeAFTBaseOffset=uOffset;
           _u16TunerPLL=RealMonitorTunerPLL;
            _SetTunerPLL( _u16TunerPLL);
            msAPI_Tuner_SetIF();
            //msAPI_ATV_SetAutoFineTuneOffset(msAPI_ATV_GetCurrentProgramNumber(),_u8RealtimeAFTBaseOffset);
         }
    }
}
#else
void _msAPI_Tuning_AutoFineTuning(void)
{
    #define MAX_AFT_UPPER_BOUND 30
 #if (FRONTEND_TUNER_TYPE==SILICON_MT2063_TUNER)
    #define MAX_AFT_LOWER_THRES (MAX_AFT_UPPER_BOUND*2/3)
    #define MAX_AFT_UPPER_THRES (MAX_AFT_LOWER_THRES*5/2)
 #else
    #define MAX_AFT_LOWER_THRES (MAX_AFT_UPPER_BOUND/3)
    #define MAX_AFT_UPPER_THRES (MAX_AFT_LOWER_THRES*2)
 #endif
    #define MAX_AFT_GOOD_LEAK   (MAX_AFT_UPPER_BOUND/10)

    AFC eFreqDev;
    if(!msAPI_ATV_ChannelInfoEdit_GetAFT())
       return;
    //msAPI_ATV_ChannelInfoEdit_SetPLL(msAPI_Tuner_GetCurrentChannelPLL());
    if (_GetTuningStatus() == E_TUNING_STATUS_GOOD)
    {
        if (u8ScanAFTCount >= MAX_AFT_GOOD_LEAK)
            u8ScanAFTCount -= MAX_AFT_GOOD_LEAK;
        else
            u8ScanAFTCount =0;

        debugTuningPrint("u8ScanAFTCount=%bd\n", u8ScanAFTCount);
        return;
    }

    #if defined(AUTO_TUNING_DEBUG)
    {
        static eAFTSTEP _ePreTuningState;
        static U32 u32TuningStateTime;
        //if ( _eCurrentTuningState != AFT_IDLE )
        {
            AUTO_TUNING_PRINT( printf("AFT_STATE: 0x%BX -> 0x%BX (%lu)\n",
                                      _ePreTuningState,
                                      _eCurrentTuningState,
                                      msAPI_Timer_DiffTimeFromNow(u32TuningStateTime)) );
            //AUTO_TUNING_PRINT(printf("BaseFre=%3.2f ",(float)_TunerPLLDbg(_u16RealtimeAFTBaseTunerPLL)));
            //AUTO_TUNING_PRINT(printf("CurFre=%3.2f \n",(float)_TunerPLLDbg(_u16TunerPLL)));
            _ePreTuningState = _eCurrentTuningState;
            u32TuningStateTime = msAPI_Timer_GetTime0();
        }
    }
    #endif

    eFreqDev = MDrv_IFDM_GetFreqDev();
    debugTuningPrint("AFT_1: 0x%bx\n", eFreqDev);
    debugTuningPrint("u8ScanAFTCount=%bd\n", u8ScanAFTCount);

    if (!(MDrv_AVD_GetStatus()&(VD_CHECK_SYNC_LOCKED|VD_CHECK_HSYNC_LOCKED)))
    {
        if (u8ScanAFTCount < MAX_AFT_UPPER_BOUND)
            u8ScanAFTCount ++;
    }
    else
    {
        if (u8ScanAFTCount)
            u8ScanAFTCount --;
    }

    if (u8ScanAFTCount>MAX_AFT_UPPER_THRES)
        u8ScanAFTFlag = 1;
    else if (u8ScanAFTCount<MAX_AFT_LOWER_THRES)
        u8ScanAFTFlag = 0;

    if (u8ScanAFTFlag)
    {
        if (_u16TunerPLL!=_u16RealtimeAFTBaseTunerPLL)
        {
            _SetTunerPLL(_u16RealtimeAFTBaseTunerPLL);
            msAPI_Tuner_SetIF();
        }
    }
    else if ((DIFFERENCE(_u16RealtimeAFTBaseTunerPLL,_u16TunerPLL) > TUNER_PLL_PLUS_2MHz )
              &&(eFreqDev == E_AFC_OUT_OF_AFCWIN))
    {   // roll PLL to +/- 2MHz
        if (_u16RealtimeAFTBaseTunerPLL>_u16TunerPLL)
            _u16TunerPLL = _u16RealtimeAFTBaseTunerPLL + TUNER_PLL_PLUS_0p25MHz;
        else
            _u16TunerPLL = _u16RealtimeAFTBaseTunerPLL + TUNER_PLL_MINUS_0p25MHz;

        _SetTunerPLL(_u16TunerPLL);
        msAPI_Tuner_SetIF();
    }
    else if ((DIFFERENCE(_u16RealtimeAFTBaseTunerPLL,_u16TunerPLL) <= TUNER_PLL_PLUS_2MHz))
    {

    #if (FRONTEND_IF_DEMODE_TYPE == MSTAR_VIF_MSB1210)
       int  i;
    #endif
        eFreqDev = MDrv_IFDM_GetFreqDev();
        debugTuningPrint("AFT: 0x%bx\n", eFreqDev);

#if (FRONTEND_IF_DEMODE_TYPE == MSTAR_VIF_MSB1210)
       for ( i = 0; i <= TUNER_PLL_PLUS_2MHz ; i++ )
#endif
       {
        switch ( eFreqDev ) //fine tuning in AFC windows
        {
            case E_AFC_BELOW_MINUS_187p5KHz:    _SetTunerPLL( PLLSTEP(TUNER_PLL_PLUS_187p5KHz) );break;
            case E_AFC_MINUS_162p5KHz:  _SetTunerPLL( PLLSTEP(TUNER_PLL_PLUS_162p5KHz) );   break;
            case E_AFC_MINUS_137p5KHz:  _SetTunerPLL( PLLSTEP(TUNER_PLL_PLUS_137p5KHz) );   break;
            case E_AFC_MINUS_112p5KHz:  _SetTunerPLL( PLLSTEP(TUNER_PLL_PLUS_112p5KHz) );   break;
            case E_AFC_MINUS_87p5KHz:   _SetTunerPLL( PLLSTEP(TUNER_PLL_PLUS_87p5KHz) );    break;
            case E_AFC_MINUS_62p5KHz:   _SetTunerPLL( PLLSTEP(TUNER_PLL_PLUS_62p5KHz) );    break;
            case E_AFC_MINUS_37p5KHz:
#if (FRONTEND_IF_DEMODE_TYPE == MSTAR_VIF_MSB1210)
                        return;
#else
                _SetTunerPLL( PLLSTEP(TUNER_PLL_PLUS_37p5KHz) );
#endif
                break;
            case E_AFC_MINUS_12p5KHz:   return;
            case E_AFC_PLUS_12p5KHz:    return;
            case E_AFC_PLUS_37p5KHz:
#if (FRONTEND_IF_DEMODE_TYPE == MSTAR_VIF_MSB1210)
                      //To do the SW patch for Gemini-VIF
                      //Good signal = -2 ~ 1
                      // "2" is not good
                       _SetTunerPLL( PLLSTEP(-1) );
#else
                _SetTunerPLL( PLLSTEP(TUNER_PLL_MINUS_37p5KHz) );
#endif
                break;
            case E_AFC_PLUS_62p5KHz:    _SetTunerPLL( PLLSTEP(TUNER_PLL_MINUS_62p5KHz) );   break;
            case E_AFC_PLUS_87p5KHz:    _SetTunerPLL( PLLSTEP(TUNER_PLL_MINUS_87p5KHz) );   break;
            case E_AFC_PLUS_112p5KHz:   _SetTunerPLL( PLLSTEP(TUNER_PLL_MINUS_112p5KHz) );  break;
            case E_AFC_PLUS_137p5KHz:   _SetTunerPLL( PLLSTEP(TUNER_PLL_MINUS_137p5KHz) );  break;
            case E_AFC_PLUS_162p5KHz:   _SetTunerPLL( PLLSTEP(TUNER_PLL_MINUS_162p5KHz) );  break;
            case E_AFC_ABOVE_PLUS_187p5KHz:_SetTunerPLL( PLLSTEP(TUNER_PLL_MINUS_187p5KHz) );   break;
#if (FRONTEND_IF_DEMODE_TYPE == MSTAR_VIF_MSB1210)
             case E_AFC_OUT_OF_AFCWIN :

                        if(_u16TunerPLL > (_u16RealtimeAFTBaseTunerPLL+TUNER_PLL_PLUS_1MHz))             //+800KHz
                        {
                            _SetTunerPLL(_u16RealtimeAFTBaseTunerPLL+TUNER_PLL_PLUS_1MHz);
                        }
                        else if(_u16TunerPLL < (_u16RealtimeAFTBaseTunerPLL-TUNER_PLL_PLUS_1MHz))    //-500K
                        {
                            //_SetTunerPLL(PLLSTEP(22));// +1.3MHz
                            _SetTunerPLL(PLLSTEP(TUNER_PLL_PLUS_2MHz));// +2.0MHz
                        }
                        else
                        {
                                            _SetTunerPLL( PLLSTEP(-6) );
                                            i += (TUNER_PLL_PLUS_187p5KHz *2);
                        }

                break;

                    default:
                        return;
                        break;
#else
            default://E_AFC_OUT_OF_AFCWIN
                //_SetTunerPLL( PLLSTEP(TUNER_PLL_MINUS_0p5MHz) );
                if (_u16RealtimeAFTBaseTunerPLL>_u16TunerPLL)
                    _SetTunerPLL( PLLSTEP(TUNER_PLL_MINUS_0p5MHz) );
                else
                    _SetTunerPLL( PLLSTEP(TUNER_PLL_PLUS_0p5MHz) );
                break;
#endif
        }
        msAPI_Tuner_SetIF();

#if (FRONTEND_IF_DEMODE_TYPE == MSTAR_VIF_MSB1210)
                    MsOS_DelayTask(100);
                    eFreqDev = MDrv_IFDM_GetFreqDev();
#endif
        }
#if (FRONTEND_IF_DEMODE_TYPE == MSTAR_VIF_MSB1210)
                    u8ScanAFTFlag=1;
                    u8ScanAFTCount = MAX_AFT_UPPER_BOUND;
#endif
    }
}
#endif //FRESCO_FM2150A_TUNER


void _msAPI_Tuning_Start_SEARCHALL_PAL(void)
{
    printf("\r\n >> _msAPI_Tuning_Start_SEARCHALL_PAL() \n");

#if (TV_FREQ_SHIFT_CLOCK)
    msAPI_Tuner_Patch_TVShiftClk(FALSE);
#endif
    msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE,E_AUDIO_INTERNAL_2_MUTEON,E_AUDIOMUTESOURCE_ATV);

    msAPI_Timer_Delayms(DELAY_FOR_ENTERING_MUTE);

    eAutoSearchType = E_AUTO_SEARCH_TYPE_ALLWAYUP;

    u8StartFrom = msAPI_ATV_GetCurrentProgramNumber();


    _bIsAFTNeeded = TRUE;

    msAPI_AVD_TurnOffAutoAV();

#if ENABLE_TTX
    msAPI_TTX_ResetAcquisition();
#endif
    msAPI_AUD_EnableRealtimeAudioDetection(FALSE);

    //printf("_bIsLSearch=%u\n", (U16)_bIsLSearch);

    if (_bIsLSearch)
    {
        msAPI_AUD_SetAudioStandard((AUDIOSTANDARD_TYPE)E_AUDIOSTANDARD_L);
        u8SoundSystem = E_AUDIOSTANDARD_L;
    }
    else
    {
        msAPI_AUD_SetAudioStandard((AUDIOSTANDARD_TYPE)E_AUDIOSTANDARD_DK);
        u8SoundSystem = E_AUDIOSTANDARD_DK;
    }

#if 0 // daniel
    _u16TunerPLL = (WORD) ((452250 ) / 50);
#else
    if ( eAutoSearchType == E_AUTO_SEARCH_TYPE_ALLWAYUP )
        _u16TunerPLL = (VHF_LOWMIN_PLL);
    else
        _u16TunerPLL = (UHF_MAX_PLL);
#endif


    msAPI_Tuner_SetIF();

    _SetTunerPLL( _u16TunerPLL );


    _u8TVScanStepDownCount = 0;
    _bIsSpeedUp = TRUE;

    // Disable force mode
    msAPI_AVD_StartAutoStandardDetection();

    msAPI_AVD_SetHsyncDetectionForTuning(TRUE);

#ifdef ENABLE_CUS_AUTO_AUDIO_SYSTEM_DETECT
    _bAutoDetectAudioMode = AUDIO_AUTO_STATUS_EXIT;
#endif

#if AUTO_SCAN_TIME_PRINT
    u32StartAutoTuningTime = msAPI_Timer_GetTime0();
#endif
}

void _msAPI_Tuning_Start_SEARCHONETOUP_DOWN_PAL(void)
{
    U32 _eTempCurrentTuningState = _eCurrentTuningState;

#if (TV_FREQ_SHIFT_CLOCK)
    msAPI_Tuner_Patch_TVShiftClk(FALSE);
#endif
    msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE,E_AUDIO_INTERNAL_2_MUTEON,E_AUDIOMUTESOURCE_ATV);

    msAPI_Timer_Delayms(DELAY_FOR_ENTERING_MUTE);

    if(_eTempCurrentTuningState == AFT_EXT_STEP_SEARCHONETOUP)
        eAutoSearchType = E_AUTO_SEARCH_TYPE_ONETOUP;
    else
        eAutoSearchType = E_AUTO_SEARCH_TYPE_ONETODOWN;

    if ( msAPI_AVD_IsAutoAVActive(E_AUTOAV_SOURCE_ALL) == TRUE )
    {
        msAPI_AVD_TurnOffAutoAV();
        msAPI_AVD_WaitForVideoSyncLock();
        msAPI_AVD_DetectVideoStandard(OPERATIONMETHOD_MANUALLY);
    }

#if ENABLE_TTX
    msAPI_TTX_ResetAcquisition();
#endif
    msAPI_AUD_EnableRealtimeAudioDetection(FALSE);

#if (VIF_TUNER_TYPE==1)
    if (_bIsLSearch)
    {
        msAPI_AUD_SetAudioStandard((AUDIOSTANDARD_TYPE)E_AUDIOSTANDARD_L);
        u8SoundSystem = E_AUDIOSTANDARD_L;
        MDrv_IFDM_SetIF(IF_FREQ_L);
    }
    else
    {
        msAPI_AUD_SetAudioStandard((AUDIOSTANDARD_TYPE)E_AUDIOSTANDARD_DK);
        u8SoundSystem = E_AUDIOSTANDARD_DK;
        MDrv_IFDM_SetIF(IF_FREQ_DK);
    }
    _SetTunerPLL(_u16TunerPLL);
#endif

#if ENABLE_CUS_MANUAL_SCAN
    if( stGenSetting.stScanMenuSetting.u8ScanType == SCAN_TYPE_MANUAL )
    {
        _SetTunerPLL(msAPI_Tuner_GetManualScanFreqConvertToPLL(msAPI_Tuner_GetManualScanStartFreq()));
    }
#endif

#if (VD_SYNC_CRITERION_CONFIG_ENABLE)
    if ( TRUE == msAPI_Tuner_VD_IsSyncDetected(SYNC_DETECTED_BASE_NUM, SYNC_DETECTED_PASS_NUM))
#else
    if ( TRUE == msAPI_AVD_IsSyncLocked())
#endif
    {
        if ( msAPI_AUD_GetAudioStandard() == E_AUDIOSTANDARD_M )
        {
            if(_eTempCurrentTuningState == AFT_EXT_STEP_SEARCHONETOUP)
                _SetTunerPLL( PLLSTEP(TUNER_PLL_PLUS_4MHz) );
            else
                _SetTunerPLL( PLLSTEP(TUNER_PLL_MINUS_4MHz) );
        }
        else
        {
            {
                if(_eTempCurrentTuningState == AFT_EXT_STEP_SEARCHONETOUP)
                    _SetTunerPLL( PLLSTEP(TUNER_PLL_NEXT_CHANNEL_JUMP) );
                else
                    _SetTunerPLL( PLLSTEP((TUNER_PLL_NEXT_CHANNEL_JUMP*(-1))) );
            }
        }
    }

    _bIsAFTNeeded = TRUE;
    msAPI_Tuner_SetIF();
    msAPI_AVD_SetHsyncDetectionForTuning(TRUE);

#ifdef ENABLE_CUS_AUTO_AUDIO_SYSTEM_DETECT
    _bAutoDetectAudioMode = AUDIO_AUTO_STATUS_EXIT;
#endif
}

/******************************************************************************/
///- This API is called by MApp_ATVProc_Handler to keep tuning work.
/// @param eState \b IN: AFT_EXT_STEP_PERIODIC - This enum is called by ATVProc_Handler(). Don't call any other place except ATVProc_Handler().
///                  IN: AFT_EXT_STEP_SEARCHALL - This enum will start auto-tuning from VHF low to UHF max.
///                  IN: AFT_EXT_STEP_SEARCHONETOUP - This enum will search up for next one available channel.
///                  IN: AFT_EXT_STEP_SEARCHONETODOWN - This enum will search up for next one available channel.
///                  IN: AFT_EXT_STEP_SEARCH_STOP - This enum will stop searching.
/******************************************************************************/
U32 u32Get;
U32 u32Start;
U8 g_u8WaitAudioTime=10; // 100ms per step

#define DEBUG_AUDIO_DETECT_TIME 0

 eAFTSTEP msAPI_Gettuingstatus(void)
{
    //printf("\r\n _eCurrentTuningState = %x", _eCurrentTuningState);
    return _eCurrentTuningState;
}

void msAPI_Tuner_TuningProcessor(eAFTSTEP eState)
{

static U_INT32 u32VifVDLockCheckStart;
static U_INT32 u32CNICheckStart;

#if ATVSCAN_USE_TIMER_DELAY
    static U_INT32 u32DetectVideoStart;
    static U_INT32 u32DetectAudioStart;
#endif

#if (ENABLE_DTMB_CHINA_APP || ENABLE_ATV_CHINA_APP || ENABLE_DVBC_PLUS_DTMB_CHINA_APP)
    AVD_VideoStandardType eVideoStandType;
    static BOOLEAN  bIsAutoTune=TRUE;
#endif

    if ( eState != AFT_EXT_STEP_PERIODIC )
    {
        if ( _eCurrentTuningState == AFT_IDLE && eState == AFT_EXT_STEP_SEARCHSTOP )
        {
            return;
        }

        if (eState == AFT_TUNING_SUSPEND)
        {
            _IsTuningSuspend = TRUE;
            return;
        }
        else if (eState == AFT_TUNING_RESUME)
        {
            _IsTuningSuspend = FALSE;
            return;
        }

        _eCurrentTuningState = eState;
        _u16TuningWaitTimer = WAIT_0ms;
        _IsTuningSuspend = FALSE;

    }

    if (_IsTuningSuspend == TRUE)
        return;

    if ( _eCurrentTuningState != AFT_IDLE )
    {
        if ( _IsTunerStable() == FALSE )
            return;
    }

  #if defined(AUTO_TUNING_DEBUG)
    {
        static eAFTSTEP _ePreTuningState;
        static U32 u32TuningStateTime;

        if ( _eCurrentTuningState != _ePreTuningState )
        {
            AUTO_TUNING_PRINT( printf("\nTUN_STATE: 0x%BX -> 0x%BX (%lu)\n",
                                      _ePreTuningState,
                                      _eCurrentTuningState,
                                      msAPI_Timer_DiffTimeFromNow(u32TuningStateTime)) );

            _ePreTuningState = _eCurrentTuningState;
            u32TuningStateTime = msAPI_Timer_GetTime0();
        }
    }

    if( _eCurrentTuningState != AFT_IDLE )
    {
        U8 u8locked;
        printf("\n---- VIF Lock=%x",(WORD)MDrv_VIF_Read_CR_LOCK_STATUS());
        printf(" FOE=%x; ",(WORD)MDrv_VIF_Read_CR_FOE());

        MDrv_AVD_SetRegValue(0x3504, 0x21);
        u8locked= MDrv_AVD_GetRegValue(0x3501)&BIT3;
        printf(" VD lock=%x; VD_35CC=%X; ",(WORD)u8locked, MDrv_Read2Byte(0x1035CC));
    }
  #endif

    switch ( _eCurrentTuningState )
    {
        case AFT_IDLE:
                if ( E_INPUT_SOURCE_ATV != msAPI_AVD_GetVideoSource()
                     || ( E_INPUT_SOURCE_ATV == msAPI_AVD_GetVideoSource()
                            && TRUE == msAPI_AVD_IsAutoAVActive(E_AUTOAV_SOURCE_ALL) )
                     || _bIsAFTNeeded == FALSE
                     || IS_RT_AFT_ENABLED == FALSE )
                {
                    u8ScanAFTCount = 0;
                    return;
                }
                #ifdef ENABLE_SUPPORT_ATV_STATION_NAME
                msAPI_Tuning_GetStationName();
                #endif

                _u16AFTIdleTimer++;
                if (_u16AFTIdleTimer >= WAIT_190ms)
                {
                    _u16AFTIdleTimer = WAIT_10ms;
                    _msAPI_Tuning_AutoFineTuning();
                }
                return;

        case AFT_EXT_STEP_SEARCHALL:
                #if (ENABLE_DTMB_CHINA_APP || ENABLE_ATV_CHINA_APP || ENABLE_DVBC_PLUS_DTMB_CHINA_APP)
                    bIsAutoTune=TRUE;
                #endif
                _msAPI_Tuning_Start_SEARCHALL_PAL();
                _eCurrentTuningState = AFT_GOTO_CHECK_VIFLOCK;
                AUTO_TUNING_FLOW_PRINT("\r\n AFT_EXT_STEP_SEARCHALL");
                if ( eAutoSearchType == E_AUTO_SEARCH_TYPE_ALLWAYUP )
                {
                  _u16PreviousStationTunerPLL=VHF_LOWMIN_PLL;
                }
                else
                {
                  _u16PreviousStationTunerPLL=UHF_MAX_PLL;
                }
                _u16PreviousStationTunerPLL =0;
                break;

        case AFT_EXT_STEP_SEARCHONETOUP:
        case AFT_EXT_STEP_SEARCHONETODOWN:
                #if (ENABLE_DTMB_CHINA_APP || ENABLE_ATV_CHINA_APP || ENABLE_DVBC_PLUS_DTMB_CHINA_APP)
                    bIsAutoTune= TRUE;//FALSE;
                #endif

                _msAPI_Tuning_Start_SEARCHONETOUP_DOWN_PAL();
                _eCurrentTuningState = AFT_GOTO_CHECK_VIFLOCK;
                AUTO_TUNING_FLOW_PRINT("\r\n AFT_EXT_STEP_SEARCHONETOUP/DOWN");

                break;

    case AFT_GOTO_CHECK_VIFLOCK:
        AUTO_TUNING_FLOW_PRINT("\n [AFT_GOTO_CHECK_VIFLOCK");
        u32VifVDLockCheckStart=msAPI_Timer_GetTime0();
        _eCurrentTuningState = AFT_CHECK_VIFLOCK;
        break;

    case AFT_CHECK_VIFLOCK:
        AUTO_TUNING_FLOW_PRINT("\n [AFT_CHECK_VIFLOCK]");

      #if(FRONTEND_TUNER_TYPE == FRESCO_FM2150A_TUNER)
        aOffset=(U8)DRV_VIF_Read_CR_FOE();
        if(_GetVIFLockStatus())   //check if vif lock or not
        {
           // _eCurrentTuningState = AFT_GOTO_CHECK_VDLOCK;
            if ((aOffset<0x29) || (aOffset>0xd5))   //check if vif lock or not
            {
                _eCurrentTuningState = AFT_GOTO_CHECK_VDLOCK;
            }
            else
            {
                u16JumpDistance = TUNER_PLL_PLUS_1MHz;
                if ( eAutoSearchType == E_AUTO_SEARCH_TYPE_ALLWAYDOWN ||
                     eAutoSearchType == E_AUTO_SEARCH_TYPE_ONETODOWN )
                {
                    _SetTunerPLL( PLLSTEP( (u16JumpDistance*(-1)) ) );
                }
                else
                {
                    _SetTunerPLL( PLLSTEP(u16JumpDistance) );
                }
                //msAPI_Tuner_SetIF();
                _eCurrentTuningState = AFT_GOTO_CHECK_VDLOCK;
                MsOS_DelayTask(5);
            }
            AUTO_TUNING_SYNC_LOCK_PRINT("\n VIF LOCK time %d",msAPI_Timer_DiffTime(u32VifVDLockCheckStart, msAPI_Timer_GetTime0()));
        }
        else
        {
            if((msAPI_Timer_DiffTime(u32VifVDLockCheckStart, msAPI_Timer_GetTime0())) > ATVSCAN_VIFLOCK_TOTAL_CHECK_TIME) //next freq
            {

                if ((_bIsLSearch)&&(u8SoundSystem == E_AUDIOSTANDARD_L))
                {
                    msAPI_AUD_SetAudioStandard((AUDIOSTANDARD_TYPE)E_AUDIOSTANDARD_DK);
                    u8SoundSystem = E_AUDIOSTANDARD_DK;

                    if(_CheckLPrimeBoundary())
                        _SetTunerPLL(_u16TunerPLL);

                    msAPI_Tuner_SetIF();

                    _eCurrentTuningState = AFT_GOTO_CHECK_VIFLOCK;
                }
                else
                {
                    if((_bIsLSearch)&&(u8SoundSystem == E_AUDIOSTANDARD_DK))
                    {
                        msAPI_AUD_SetAudioStandard((AUDIOSTANDARD_TYPE)E_AUDIOSTANDARD_L);
                        u8SoundSystem = E_AUDIOSTANDARD_L;
                    }

                    u16JumpDistance = TUNER_PLL_PLUS_1MHz;
                    if ( eAutoSearchType == E_AUTO_SEARCH_TYPE_ALLWAYDOWN ||
                        eAutoSearchType == E_AUTO_SEARCH_TYPE_ONETODOWN )
                    {
                        _SetTunerPLL( PLLSTEP( (u16JumpDistance*(-1)) ) );
                    }
                    else
                    {
                        _SetTunerPLL( PLLSTEP(u16JumpDistance) );
                    }

                    msAPI_Tuner_SetIF();

                }
                _eCurrentTuningState = AFT_GOTO_CHECK_VIFLOCK;

            }
        }
      #else

        if( _GetVIFLockStatus() )   //check if vif lock or not
        {
            _eCurrentTuningState = AFT_GOTO_CHECK_VDLOCK;
            AUTO_TUNING_SYNC_LOCK_PRINT("\r\n VIF LOCK time %d",msAPI_Timer_DiffTime(u32VifVDLockCheckStart, msAPI_Timer_GetTime0()));
        }
        else
        {
            // VIF is not locked ...

            if( (msAPI_Timer_DiffTime(u32VifVDLockCheckStart, msAPI_Timer_GetTime0())) > ATVSCAN_VIFLOCK_TOTAL_CHECK_TIME ) //next freq
            {
                //printf("\n 1.u8SoundSystem=%u; u32CheckVifTimeoutTime=%lu\n", u8SoundSystem, u32CheckVifTimeoutTime);

                if ((_bIsLSearch)&&(u8SoundSystem == E_AUDIOSTANDARD_L))
                {
                    // Switch IF to DK
                    //printf("cur=L, set to DK\n");
                    msAPI_AUD_SetAudioStandard((AUDIOSTANDARD_TYPE)E_AUDIOSTANDARD_DK);
                    u8SoundSystem = E_AUDIOSTANDARD_DK;

                    msAPI_Tuner_SetIF();

                    _SetTunerPLL( _u16TunerPLL );

                    _eCurrentTuningState = AFT_GOTO_CHECK_VIFLOCK;
                }
                else
                {
                    // Current IF is DK
                    if( (_bIsLSearch)&&(u8SoundSystem == E_AUDIOSTANDARD_DK) )
                    {
                        // Switch IF to L
                        //printf("cur=DK, set to L\n");
                        msAPI_AUD_SetAudioStandard((AUDIOSTANDARD_TYPE)E_AUDIOSTANDARD_L);
                        u8SoundSystem = E_AUDIOSTANDARD_L;
                    }

                    if( (_bIsLSearch)&&((s_u32CurTunerFreq/1000) < (L_PRIME_BOUNDARY_FREQ+1000)) )
                        u16JumpDistance = TUNER_PLL_PLUS_0p75MHz;
                    else
                        u16JumpDistance = TUNER_PLL_PLUS_1MHz;

                    if ( eAutoSearchType == E_AUTO_SEARCH_TYPE_ALLWAYDOWN ||
                         eAutoSearchType == E_AUTO_SEARCH_TYPE_ONETODOWN )
                    {
                        _u16TunerPLL = PLLSTEP( (u16JumpDistance*(-1)) );
                    }
                    else
                    {
                        _u16TunerPLL = PLLSTEP(u16JumpDistance);
                    }

                    msAPI_Tuner_SetIF();

                    _SetTunerPLL( _u16TunerPLL );

                }
                _eCurrentTuningState = AFT_GOTO_CHECK_VIFLOCK;

            }
        }
      #endif
        break;

    case AFT_GOTO_CHECK_VDLOCK:
        AUTO_TUNING_FLOW_PRINT("\r\n AFT_GOTO_CHECK_VDLOCK]");
        u32VifVDLockCheckStart = msAPI_Timer_GetTime0();
        _eCurrentTuningState = AFT_CHECK_VDLOCK;
        break;


    case AFT_CHECK_VDLOCK:
        AUTO_TUNING_FLOW_PRINT("\n[AFT_CHECK_VDLOCK]");
 #if 0
    {
        U8 u8locked;
        printf("\r\n VIF Lock=%x",(WORD)MDrv_VIF_Read_CR_LOCK_STATUS());
        printf(" FOE=%x",(WORD)MDrv_VIF_Read_CR_FOE());

        MDrv_AVD_SetRegValue(0x3504, 0x21);
        u8locked= MDrv_AVD_GetRegValue(0x3501)&BIT3;
        printf("\r\n VD lock=%x",(WORD)u8locked);
    }
#endif

        u16VdStatus = msAPI_AVD_CheckStatusLoop();
        if( u16VdStatus & VD_CHECK_HSYNC_LOCKED )
        {
          #if(FRONTEND_TUNER_TYPE == FRESCO_FM2150A_TUNER)
            _eCurrentTuningState = AFT_TUNING;
            u8NoSyncCount =0;
            aOffset= (U8)DRV_VIF_Read_CR_FOE();
            // for precise RF freq calculations
            printf ("TunerPLL was = %d Offset readback %d \r\n", _u16TunerPLL, aOffset);
            aCorrectedRF = aFindOffset(aOffset)+(GetActualRF()/1000);
            _u16TunerPLL = aCorrectedRF/50;
            printf ("AFT Actual RF = %d TunerPLL = %d\r\n", aCorrectedRF, _u16TunerPLL);
            AUTO_TUNING_SYNC_LOCK_PRINT("\r\n VD LOCK time %d ",msAPI_Timer_DiffTime(u32VifVDLockCheckStart, msAPI_Timer_GetTime0()));
          #else
            //printf("u16VdStatus=%X\n", u16VdStatus);
            _eCurrentTuningState = AFT_TUNING;
            u8NoSyncCount =0;
            AUTO_TUNING_SYNC_LOCK_PRINT("\r\n VD LOCK time %d ",msAPI_Timer_DiffTime(u32VifVDLockCheckStart, msAPI_Timer_GetTime0()));
          #endif
        }
        else
        {
#if ENABLE_VD_PACH_IN_CHINA
          U16 u16ATVSCAN_VDLOCK_TOTAL_CHECK_TIME=ATVSCAN_VDLOCK_TOTAL_CHECK_TIME+stGenSetting.g_FactorySetting.SCAN_DELAY;
#else
          U16 u16ATVSCAN_VDLOCK_TOTAL_CHECK_TIME=ATVSCAN_VDLOCK_TOTAL_CHECK_TIME;
#endif

            if((msAPI_Timer_DiffTime(u32VifVDLockCheckStart, msAPI_Timer_GetTime0()))>u16ATVSCAN_VDLOCK_TOTAL_CHECK_TIME) //next freq
            {
                AUTO_TUNING_SYNC_LOCK_PRINT("\r\nVD no Lock Freq %d Mh.",msAPI_CFT_ConvertPLLtoIntegerOfFrequency(_u16TunerPLL));
                //printf(" _bIsLSearch=%u; u8SoundSystem=%u; ", _bIsLSearch, u8SoundSystem);
                //printf(" u16VdStatus=%X; ", u16VdStatus);

                if ((_bIsLSearch)&&(u8SoundSystem == E_AUDIOSTANDARD_L))
                {
                    //printf(" 2.set to DK; ");
                    msAPI_AUD_SetAudioStandard((AUDIOSTANDARD_TYPE)E_AUDIOSTANDARD_DK);
                    u8SoundSystem = E_AUDIOSTANDARD_DK;

                    msAPI_Tuner_SetIF();

                    _SetTunerPLL(_u16TunerPLL);

                    _eCurrentTuningState = AFT_GOTO_CHECK_VIFLOCK;
                }
                else
                {
                    // Current IF is DK
                    if ((_bIsLSearch)&&(u8SoundSystem == E_AUDIOSTANDARD_DK))
                    {
                        //printf(" 2.set to L; ");
                        msAPI_AUD_SetAudioStandard((AUDIOSTANDARD_TYPE)E_AUDIOSTANDARD_L);
                        u8SoundSystem = E_AUDIOSTANDARD_L;
                    }

                    if( (_bIsLSearch)&&((s_u32CurTunerFreq/1000) < (L_PRIME_BOUNDARY_FREQ+1000)) )
                        u16JumpDistance = TUNER_PLL_PLUS_0p75MHz;
                    else
                        u16JumpDistance = TUNER_PLL_PLUS_1MHz;

                    if ( eAutoSearchType == E_AUTO_SEARCH_TYPE_ALLWAYDOWN ||
                        eAutoSearchType == E_AUTO_SEARCH_TYPE_ONETODOWN )
                    {
                        _u16TunerPLL = PLLSTEP( (u16JumpDistance*(-1)) );
                    }
                    else
                    {
                        _u16TunerPLL = PLLSTEP(u16JumpDistance);
                    }

                    msAPI_Tuner_SetIF();

                    _SetTunerPLL( _u16TunerPLL );
                }
                _eCurrentTuningState = AFT_GOTO_CHECK_VIFLOCK;
            }
        }
        break;

        case AFT_JUMPNEAR:
            AUTO_TUNING_FLOW_PRINT("\r\n AFT_JUMPNEAR");

        case AFT_JUMPNEARHALF:
            if( _eCurrentTuningState == AFT_JUMPNEARHALF )
            {
          #if(FRONTEND_IF_DEMODE_TYPE == MSTAR_VIF_MSB1210)
                u16JumpDistance = TUNER_PLL_PLUS_0p25MHz;
          #else
                u16JumpDistance = TUNER_PLL_PLUS_0p5MHz;
          #endif
            }
            else
            {
          #if((FRONTEND_IF_DEMODE_TYPE == MSTAR_VIF)||(FRONTEND_IF_DEMODE_TYPE == MSTAR_VIF_MSB1210||(FRONTEND_IF_DEMODE_TYPE == MSTAR_INTERN_VIF)))
                u16JumpDistance = TUNER_PLL_PLUS_1MHz;//TUNER_PLL_PLUS_1p5MHz;
          #else
                u16JumpDistance = TUNER_PLL_PLUS_1p5MHz;//TUNER_PLL_PLUS_1p5MHz;
          #endif
            }

            if ( _IsLPrime() == TRUE )
            {
                if( _eCurrentTuningState == AFT_JUMPNEARHALF )
                    u16JumpDistance = TUNER_PLL_PLUS_0p2MHz;
                else
                    u16JumpDistance = TUNER_PLL_PLUS_0p75MHz;
            }

            if ( eAutoSearchType == E_AUTO_SEARCH_TYPE_ALLWAYDOWN ||
                 eAutoSearchType == E_AUTO_SEARCH_TYPE_ONETODOWN )
            {
                _SetTunerPLL( PLLSTEP( (u16JumpDistance*(-1)) ) );
            }
            else
            {
                _SetTunerPLL( PLLSTEP(u16JumpDistance) );
            }

            msAPI_Tuner_SetIF();

            _eCurrentTuningState = AFT_GOTO_CHECK_VIFLOCK;
            AUTO_TUNING_FLOW_PRINT("\r\n AFT_JUMPNEARHALF");

            break;

#ifdef ENABLE_CUS_AUTO_AUDIO_SYSTEM_DETECT
    case AFT_AUDIO_AUTODETECT:
        AUTO_TUNING_FLOW_PRINT("\r\n AFT_AUDIO_AUTODETECT]");
        //printf("---Start Audio Detect!---\n");
        bIsAutoTune=FALSE;
        _bAutoDetectAudioMode = AUDIO_AUTO_STATUS_ENTER;
        _eCurrentTuningState = AFT_TUNING;
        break;
#endif

    case AFT_TUNING:
        AUTO_TUNING_FLOW_PRINT("\r\n AFT_TUNING]");

        //u16VdStatus = msAPI_AVD_CheckStatusLoop();
        eTuningStatus = _GetTuningStatus();


        AUTO_TUNING_PRINT(printf("Tuning: 0x%04X, 0x%02BX\n", u16VdStatus, eTuningStatus));

#ifdef ENABLE_CUS_AUTO_AUDIO_SYSTEM_DETECT
        if((_bAutoDetectAudioMode == AUDIO_AUTO_STATUS_ENTER)&&(eTuningStatus != E_TUNING_STATUS_GOOD))
        {
            eAudioStandard_AutoDetect_Result = FALSE;
            _eCurrentTuningState = AFT_IDLE;
            _bAutoDetectAudioMode = AUDIO_AUTO_STATUS_END;
            break;
        }
#endif

        //if ( (eTuningStatus != E_TUNING_STATUS_OUT_OF_AFCWIN) &&
        //     (u16VdStatus & VD_CHECK_HSYNC_LOCKED) )
        {
            switch ( eTuningStatus )
            {
            case E_TUNING_STATUS_GOOD:
#if(ENABLE_AUDIO_AUTO_DETECT)
                // for detect PAL MN
                MDrv_IFDM_BypassDBBAudioFilter(TRUE);
                MApi_AUDIO_SIF_StartAutoStandardDetection();

            #if DEBUG_AUDIO_DETECT_TIME
                u32Start=msAPI_Timer_GetTime0();
                printf(">>> start0 %d", u32Start);
            #endif

                u32CNICheckStart =msAPI_Timer_GetTime0();

            #if ATVSCAN_USE_TIMER_DELAY
                u32DetectAudioStart=msAPI_Timer_GetTime0();
                u32DetectVideoStart=msAPI_Timer_GetTime0();
            #endif
#endif//(ENABLE_AUDIO_AUTO_DETECT)

            #if (ENABLE_DTMB_CHINA_APP || ENABLE_ATV_CHINA_APP || ENABLE_DVBC_PLUS_DTMB_CHINA_APP)
                {
                    if(bIsAutoTune)
                    {
                        msAPI_AVD_StartAutoStandardDetection();
                    }
                    else
                    {
                        eVideoStandType = msAPI_ATV_GetVideoStandardOfProgram(msAPI_ATV_GetCurrentProgramNumber());
                        AUTO_TUNING_PRINT(printf(" eVideoStandType=%u, ", eVideoStandType););
                        if(eVideoStandType == E_VIDEOSTANDARD_AUTO)
                        {
                            msAPI_AVD_StartAutoStandardDetection();
                        }
                        else if(eVideoStandType == E_VIDEOSTANDARD_PAL_BGHI)
                        {
                            msAPI_AVD_ForceVideoStandard(E_VIDEOSTANDARD_PAL_BGHI);
                        }
                        else
                        {
                            msAPI_AVD_ForceVideoStandard(E_VIDEOSTANDARD_NTSC_M);
                        }
                    }
                }
            #else
                msAPI_AVD_StartAutoStandardDetection();
            #endif

#if ENABLE_TTX
                msAPI_TTX_ResetAcquisition();
#endif
                _eCurrentTuningState = AFT_DETECTVIDEO; // AFT_SHOWTIME1;

                return; // <-<<<

            case E_TUNING_STATUS_OVER:
                _SetTunerPLL( PLLSTEP(-2) );
                break;

            case E_TUNING_STATUS_UNDER:
                _SetTunerPLL( PLLSTEP(2) );
                break;
            case E_TUNING_STATUS_OVER_LITTLE:
                _SetTunerPLL( PLLSTEP(-1) );
                break;

            case E_TUNING_STATUS_UNDER_LITTLE:
                _SetTunerPLL( PLLSTEP(1) );
                break;

            case E_TUNING_STATUS_OVER_MORE:
                _SetTunerPLL( PLLSTEP(TUNER_PLL_MINUS_0p25MHz) );
                break;

            case E_TUNING_STATUS_UNDER_MORE:
            #if(FRONTEND_TUNER_TYPE == NXP_TD1616EF_TUNER)
                _SetTunerPLL( PLLSTEP(TUNER_PLL_PLUS_0p5MHz) );
            #else
                _SetTunerPLL( PLLSTEP(TUNER_PLL_PLUS_0p25MHz) );
            #endif
                break;

            default:
                /* ASSERT */
                break;
            }

            if ( (u8NoSyncCount++) == 20 )
            {
            #if ENABLE_TTX
                msAPI_TTX_ResetAcquisition();
                printf("\r\n msAPI_TTX_ResetAcquisition");
            #endif
                _eCurrentTuningState = AFT_DETECTVIDEO; // AFT_SHOWTIME1;
            }
        }
        break;

    case AFT_DETECTVIDEO:
         AUTO_TUNING_FLOW_PRINT("\r\n AFT_DETECTVIDEO]");

#if ATVSCAN_USE_TIMER_DELAY
        if( (msAPI_Timer_DiffTime(u32DetectVideoStart, msAPI_Timer_GetTime0())) > ATVSCAN_VIDEO_WAIT_TIME )
#endif
        {
          //check if lock audio carrier False signal
          //  if(((msAPI_AVD_CheckLockAudioCarrier()==TRUE)&&(_u16TunerPLL<= (_u16PreviousStationTunerPLL+ (TUNER_PLL_PLUS_6p5MHz+TUNER_PLL_PLUS_0p2MHz)))))
            if( msAPI_AVD_CheckLockAudioCarrier() == TRUE )
            {
                AUTO_TUNING_SYNC_LOCK_PRINT("\r\n abandan audio carrier Freq = %d",msAPI_CFT_ConvertPLLtoIntegerOfFrequency(_u16TunerPLL));
                AUTO_TUNING_SYNC_LOCK_PRINT(".%dMHz",msAPI_CFT_ConvertPLLtoFractionOfFrequency(_u16TunerPLL));

#ifdef ENABLE_CUS_AUTO_AUDIO_SYSTEM_DETECT
                if(_bAutoDetectAudioMode == AUDIO_AUTO_STATUS_ENTER)
                {
                    eAudioStandard_AutoDetect_Result = FALSE;
                    _eCurrentTuningState = AFT_IDLE;
                    _bAutoDetectAudioMode = AUDIO_AUTO_STATUS_END;
                    break;
                }
#endif

                if ((_bIsLSearch)&&(u8SoundSystem == E_AUDIOSTANDARD_L))
                {
                    msAPI_AUD_SetAudioStandard((AUDIOSTANDARD_TYPE)E_AUDIOSTANDARD_DK);
                    u8SoundSystem = E_AUDIOSTANDARD_DK;

                    msAPI_Tuner_SetIF();

                    _SetTunerPLL(_u16TunerPLL);

                    _eCurrentTuningState = AFT_GOTO_CHECK_VIFLOCK;
                    break;//return;
                }
                else if ((_bIsLSearch)&&(u8SoundSystem == E_AUDIOSTANDARD_DK))
                {
                    msAPI_AUD_SetAudioStandard((AUDIOSTANDARD_TYPE)E_AUDIOSTANDARD_L);
                    u8SoundSystem = E_AUDIOSTANDARD_L;
                }

                u16JumpDistance = TUNER_PLL_PLUS_1MHz;

                if ( eAutoSearchType == E_AUTO_SEARCH_TYPE_ALLWAYDOWN ||
                    eAutoSearchType == E_AUTO_SEARCH_TYPE_ONETODOWN )
                {
                    _u16TunerPLL = ( PLLSTEP( (u16JumpDistance*(-1)) ) );
                }
                else
                {
                    _u16TunerPLL = ( PLLSTEP(u16JumpDistance) );
                }

                msAPI_Tuner_SetIF();

                _SetTunerPLL(_u16TunerPLL);

                _eCurrentTuningState = AFT_GOTO_CHECK_VIFLOCK;
                break;
            }

            if ( MDrv_AVD_GetStatus() & VD_CHECK_STATUS_RDY )
            {
                //AUTO_TUNING_FLOW_PRINT("\r\n AFT_DETECTVIDEO]");

            #if (ENABLE_DTMB_CHINA_APP || ENABLE_ATV_CHINA_APP || ENABLE_DVBC_PLUS_DTMB_CHINA_APP)
                {
                    u8VideoSystem = u8VideoSystem;
                    //printf("u8VideoSystem=%u\n", u8VideoSystem);
                    if( bIsAutoTune )
                    {
                        AVD_VideoStandardType vdStd;
                        vdStd= msAPI_AVD_GetResultOfAutoStandardDetection();
                        //printf(" ResultOfAutoStandardDetection=%u\n", vdStd);
                    }
                    else
                    {
                        eVideoStandType = msAPI_ATV_GetVideoStandardOfProgram(msAPI_ATV_GetCurrentProgramNumber());
                        //printf("eVideoStandType=%u\n", eVideoStandType);
                        if(eVideoStandType == E_VIDEOSTANDARD_AUTO)
                        {
                            msAPI_AVD_GetResultOfAutoStandardDetection();
                        }
                        else if(eVideoStandType == E_VIDEOSTANDARD_PAL_BGHI)
                        {
                            eVideoStandType=msAPI_AVD_GetStandardDetection();
                            if(eVideoStandType != E_VIDEOSTANDARD_PAL_BGHI &&
                               eVideoStandType != E_VIDEOSTANDARD_PAL_M &&
                               eVideoStandType != E_VIDEOSTANDARD_PAL_N &&
                               eVideoStandType != E_VIDEOSTANDARD_PAL_60)
                            {
                                msAPI_AVD_SetVideoStandard(E_VIDEOSTANDARD_PAL_BGHI);
                            }
                            else
                            {
                                msAPI_AVD_SetVideoStandard(eVideoStandType);
                            }
                            msAPI_AVD_StartAutoStandardDetection();
                        }
                        else if(eVideoStandType == E_VIDEOSTANDARD_NTSC_M)
                        {
                            eVideoStandType=msAPI_AVD_GetStandardDetection();
                            if(eVideoStandType != E_VIDEOSTANDARD_NTSC_M &&
                               eVideoStandType != E_VIDEOSTANDARD_NTSC_44)
                            {
                                msAPI_AVD_SetVideoStandard(E_VIDEOSTANDARD_NTSC_M);
                            }
                            else
                            {
                                msAPI_AVD_SetVideoStandard(eVideoStandType);
                            }
                            //msAPI_VD_DisableForceMode();
                            msAPI_AVD_StartAutoStandardDetection();
                        }
                    }
                }
            #else
            {
                u8VideoSystem =  msAPI_AVD_GetResultOfAutoStandardDetection();

                if(_bIsLSearch)
                {
                    if (u8VideoSystem != E_VIDEOSTANDARD_SECAM) // PAL detect
                    {
                        if(u8SoundSystem == E_AUDIOSTANDARD_L)
                        {
                            msAPI_AUD_SetAudioStandard((AUDIOSTANDARD_TYPE)E_AUDIOSTANDARD_DK);
                            u8SoundSystem = E_AUDIOSTANDARD_DK;
                            msAPI_Tuner_SetIF();
                            _SetTunerPLL(_u16TunerPLL);
                            _eCurrentTuningState = AFT_GOTO_CHECK_VIFLOCK;
                        }
                    }
                    else // SECAM_LL detect // SECAM_L detect
                    {
                        if(u8SoundSystem == E_AUDIOSTANDARD_DK)
                        {
                            msAPI_AUD_SetAudioStandard((AUDIOSTANDARD_TYPE)E_AUDIOSTANDARD_L);
                            u8SoundSystem = E_AUDIOSTANDARD_L;

                            msAPI_Tuner_SetIF();
                            _SetTunerPLL(_u16TunerPLL);
                            _eCurrentTuningState = AFT_GOTO_CHECK_VIFLOCK;
                        }
                    }
                }
            }
            #endif

              #if ATVSCAN_USE_TIMER_DELAY
              #else
                _u16AFTIdleTimer = WAIT_0ms;
              #endif
                _eCurrentTuningState = AFT_SHOWTIME2;
                _bIsPreProgramDetected = TRUE;
            }
            else
            {
                //printf(" (VD(%X) not ready!) ", MDrv_AVD_GetStatus());

                // Wait VD ready
                if( (msAPI_Timer_DiffTime(u32DetectVideoStart, msAPI_Timer_GetTime0())) > ATVSCAN_VIDEO_WAIT_TIME_MAX)
                {
                  #if ATVSCAN_USE_TIMER_DELAY
                  #else
                    _u16AFTIdleTimer = WAIT_0ms;
                  #endif
                    _eCurrentTuningState = AFT_SHOWTIME2;
                    _bIsPreProgramDetected = TRUE;
                }
            }
        }

        break;

    case AFT_SHOWTIME2:
#if(ENABLE_AUDIO_AUTO_DETECT)
      #if ATVSCAN_USE_TIMER_DELAY
        if((msAPI_Timer_DiffTime(u32DetectAudioStart, msAPI_Timer_GetTime0()))>ATVSCAN_AUDIO_WAIT_TIME2)
      #endif
#endif//(ENABLE_AUDIO_AUTO_DETECT)
        {

            {
#if(ENABLE_AUDIO_AUTO_DETECT)
                _eCurrentTuningState = AFT_DETECTAUDIO;
#else
                _eCurrentTuningState = AFT_CHECK_CNI;
#endif//(ENABLE_AUDIO_AUTO_DETECT)
            }

        }
        _bIsOneProgramDetected = FALSE;
        break;

    case AFT_DETECTAUDIO:
        {
            AUDIOSTANDARD_TYPE auStd;

            AUTO_TUNING_FLOW_PRINT("\r\n AFT_DETECTAUDIO]");
#if DEBUG_AUDIO_DETECT_TIME
            u32Get=msAPI_Timer_GetTime0();

            printf("\n >>> Get0 %d",u32Get );
            if((msAPI_Timer_DiffTime(u32Start, u32Get))< (U32)g_u8WaitAudioTime*100)
            {
                break;
            }
#endif

            auStd = msAPI_AUD_GetResultOfAutoStandardDetection();
            printf(" auStd=0x%X\n", auStd);

            // for detect PAL MN
            MDrv_IFDM_BypassDBBAudioFilter(FALSE);
            if( msAPI_AUD_IsAudioDetected() == FALSE )
            {
                printf(" Audio detect failed!\n");
                #ifdef ENABLE_CUS_AUTO_AUDIO_SYSTEM_DETECT
                if(_bAutoDetectAudioMode == AUDIO_AUTO_STATUS_ENTER)
                {
                    eAudioStandard_AutoDetect_Result = FALSE;
                    _eCurrentTuningState = AFT_IDLE;
                    _bAutoDetectAudioMode = AUDIO_AUTO_STATUS_END;
                    //printf("---END Audio Detect Faile!---\n");
                }
                else
                #endif
                {
                #if (SILICON_R620D_TUNER==FRONTEND_TUNER_TYPE)
                    _eCurrentTuningState = AFT_CHECK_CNI;
                #else
                    u16Record_FALSE_SIGNAL_TunerPLL = _u16TunerPLL;
                    u16JumpDistance = TUNER_PLL_PLUS_0p25MHz;
                    if ( eAutoSearchType == E_AUTO_SEARCH_TYPE_ALLWAYDOWN ||
                        eAutoSearchType == E_AUTO_SEARCH_TYPE_ONETODOWN )
                    {
                        _SetTunerPLL( PLLSTEP( (u16JumpDistance*(-1)) ) );
                    }
                    else
                    {
                        _SetTunerPLL( PLLSTEP(u16JumpDistance) );
                    }
                    _eCurrentTuningState = AFT_CHECK_FALSESIGNAL;
                #endif
                }
            }
            else
            {
                #ifdef ENABLE_CUS_AUTO_AUDIO_SYSTEM_DETECT
                if(_bAutoDetectAudioMode == AUDIO_AUTO_STATUS_ENTER)
                {
                    eAudioStandard_AutoDetect = auStd;
                    eAudioStandard_AutoDetect_Result = TRUE;
                    _eCurrentTuningState = AFT_IDLE;
                    _bAutoDetectAudioMode = AUDIO_AUTO_STATUS_END;
                    //printf("---END Audio Detect OK!---\n");
                }
                else
                #endif
                {
                #if 1 // daniel
                    if( (E_VIDEOSTANDARD_NTSC_M == msAPI_AVD_GetStandardDetection())
                      &&((auStd == E_AUDIOSTANDARD_I)||(auStd == E_AUDIOSTANDARD_BG) )
                      )
                    {
                        // Set audio std to M
                        printf("Set audio std to M\n");
                        //---->Added by smc jack.lin 20120824
                        if(auStd == E_AUDIOSTANDARD_I)
                        {
                          msAPI_AUD_SetAudioStandard((AUDIOSTANDARD_TYPE)E_AUDIOSTANDARD_I);
                          printf("\r\n==============Set audio std to E_AUDIOSTANDARD_I===============\n");
                        }
                        else
                        //<-----------
                        msAPI_AUD_SetAudioStandard((AUDIOSTANDARD_TYPE)E_AUDIOSTANDARD_M);
                    }
                #endif
                    _eCurrentTuningState = AFT_CHECK_CNI;
                }
            }
        }
        break;

    case AFT_CHECK_FALSESIGNAL:
        AUTO_TUNING_FLOW_PRINT("\r\n AFT_CHECK_FALSESIGNAL");
        //printf("AFT_CHECK_FALSESIGNAL");

        u16VdStatus = msAPI_AVD_CheckStatusLoop();

        if( u16VdStatus & VD_CHECK_HSYNC_LOCKED)
        {
            _u16TunerPLL = u16Record_FALSE_SIGNAL_TunerPLL;
            msAPI_Tuner_SetIF();
            _SetTunerPLL(_u16TunerPLL);
            _eCurrentTuningState = AFT_CHECK_CNI;
            //printf("Goto AFT_CHECK_CNI\n");
        }
        else
        {
            printf("\r\n Abandon FALSE SIGNAL");


            if ((_bIsLSearch)&&(u8SoundSystem == E_AUDIOSTANDARD_L))
            {
                msAPI_AUD_SetAudioStandard((AUDIOSTANDARD_TYPE)E_AUDIOSTANDARD_DK);
                u8SoundSystem = E_AUDIOSTANDARD_DK;
                _u16TunerPLL = u16Record_FALSE_SIGNAL_TunerPLL;
                msAPI_Tuner_SetIF();
                _SetTunerPLL(_u16TunerPLL);
                _eCurrentTuningState = AFT_GOTO_CHECK_VIFLOCK;
                //printf("\r\n Abandon SOUND L");
            }
            else if ((_bIsLSearch)&&(u8SoundSystem == E_AUDIOSTANDARD_DK))
            {
                msAPI_AUD_SetAudioStandard((AUDIOSTANDARD_TYPE)E_AUDIOSTANDARD_L);
                u8SoundSystem = E_AUDIOSTANDARD_L;
                u16JumpDistance = TUNER_PLL_PLUS_1MHz;
                if ( eAutoSearchType == E_AUTO_SEARCH_TYPE_ALLWAYDOWN ||
                    eAutoSearchType == E_AUTO_SEARCH_TYPE_ONETODOWN )
                {
                    _u16TunerPLL = ( PLLSTEP( (u16JumpDistance*(-1)) ) );
                }
                else
                {
                    _u16TunerPLL = ( PLLSTEP(u16JumpDistance) );
                }

                msAPI_Tuner_SetIF();
                _SetTunerPLL(_u16TunerPLL);

                _eCurrentTuningState = AFT_GOTO_CHECK_VIFLOCK;
                //printf("\r\n Abandon SOUND DK");

            }
            else
            {
                u16JumpDistance = TUNER_PLL_PLUS_1MHz;
                if ( eAutoSearchType == E_AUTO_SEARCH_TYPE_ALLWAYDOWN ||
                    eAutoSearchType == E_AUTO_SEARCH_TYPE_ONETODOWN )
                {
                    _u16TunerPLL = ( PLLSTEP( (u16JumpDistance*(-1)) ) );
                }
                else
                {
                    _u16TunerPLL = ( PLLSTEP(u16JumpDistance) );
                }

                msAPI_Tuner_SetIF();
                _SetTunerPLL(_u16TunerPLL);

                _eCurrentTuningState = AFT_GOTO_CHECK_VIFLOCK;

                //printf("\r\n Abandon SOUND other");

            }

        }

        break;

    case AFT_CHECK_CNI:
#if ENABLE_TTX
        if (msAPI_TTX_GetStationNameFromTeletext(_sCurrentStationName, MAX_STATION_NAME, &u8SortingPriority) )
        {
            _eCurrentTuningState = AFT_MEMORIZEPRDATA;
            //AUTO_TUNING_SYNC_LOCK_PRINT("\r\n CNI get time %d",msAPI_Timer_DiffTime(u32CNICheckStart, msAPI_Timer_GetTime0()));
            //printf("\r\n CNI get time %d",msAPI_Timer_DiffTime(u32CNICheckStart, msAPI_Timer_GetTime0()));
        }
        else if((msAPI_Timer_DiffTime(u32CNICheckStart, msAPI_Timer_GetTime0()))>ATVSCAN_CNI_TOTAL_CHECK_TIME)
#endif
        {
            msAPI_Tuner_UpdateMediumAndChannelNumber();
            #ifdef ENABLE_SUPPORT_ATV_STATION_NAME
            msAPI_Tuner_ConvertMediumAndChannelNumberToString(_eMedium, _u8ChannelNumber, _sCurrentStationName);
            #endif
            u8SortingPriority = LOWEST_SORTING_PRIORITY;
            _eCurrentTuningState = AFT_MEMORIZEPRDATA;
        }

        break;

    case AFT_MEMORIZECHDATA:
        break;

    case AFT_MEMORIZEPRDATA:
        AUTO_TUNING_FLOW_PRINT("\r\n AFT_MEMORIZEPRDATA]");
        #if(FRONTEND_TUNER_TYPE == FRESCO_FM2150A_TUNER)
        aOffset= (U8)DRV_VIF_Read_CR_FOE();
        aCorrectedRF = aFindOffset(aOffset)+(GetActualRF()/1000);
        _u16TunerPLL = aCorrectedRF/50;
        #endif
        _u16PreviousStationTunerPLL = _u16TunerPLL;
        switch ( eAutoSearchType )
        {
        case E_AUTO_SEARCH_TYPE_ALLWAYUP:
        case E_AUTO_SEARCH_TYPE_ALLWAYDOWN:
          {

            //msAPI_Tuner_UpdateMediumAndChannelNumber();
            #if ENABLE_CUS_UPDATE_SCAN
            if(msAPI_ATV_UpdateScan_NeedSaveProgram(msAPI_ATV_GetCurrentProgramNumber(),_u16TunerPLL) == FALSE)
            {
                printf("-->Update scan:DON'T save current program!! \n");/*Creass.liu at 2012-06-12*/
                {
                    if ( _IsLPrime() == TRUE )
                    {
                        _SetTunerPLL( PLLSTEP(TUNER_PLL_PLUS_2p75MHz) );
                    }
                    else
                    {
                        _SetTunerPLL( PLLSTEP(TUNER_PLL_NEXT_CHANNEL_JUMP) );
                    }
                    if ((_bIsLSearch)&&(u8SoundSystem == E_AUDIOSTANDARD_DK))
                    {
                        msAPI_AUD_SetAudioStandard((AUDIOSTANDARD_TYPE)E_AUDIOSTANDARD_L);
                        u8SoundSystem = E_AUDIOSTANDARD_L;
                        msAPI_Tuner_SetIF();
                    }
#if (VIF_TUNER_TYPE==1)
                    else if ((_bIsLSearch)&&(u8SoundSystem == E_AUDIOSTANDARD_L))
                    {
                        msAPI_AUD_SetAudioStandard((AUDIOSTANDARD_TYPE)E_AUDIOSTANDARD_DK);
                        u8SoundSystem = E_AUDIOSTANDARD_DK;
                        MDrv_IFDM_SetIF(IF_FREQ_DK);
                        msAPI_Tuner_SetIF();
                    }
                    else
                    {
                        msAPI_AUD_SetAudioStandard((AUDIOSTANDARD_TYPE)E_AUDIOSTANDARD_DK);
                        u8SoundSystem = E_AUDIOSTANDARD_DK;
                        MDrv_IFDM_SetIF(IF_FREQ_DK);
                        msAPI_Tuner_SetIF();
                    }
#endif
                    _eCurrentTuningState = AFT_GOTO_CHECK_VIFLOCK;

                    }
                    msAPI_Tuner_SetIF();
                break;
            }
            #endif
            msAPI_ATV_SetProgramPLLData(msAPI_ATV_GetCurrentProgramNumber(), _u16TunerPLL);

            //printf("Save Au = %u\n", msAPI_AUD_GetAudioStandard());
            msAPI_ATV_SetAudioStandard(msAPI_ATV_GetCurrentProgramNumber(), msAPI_AUD_GetAudioStandard());

#if(ENABLE_AUDIO_AUTO_DETECT)
            msAPI_ATV_SetAudioMode(E_AUDIOSOURCE_ATV, (AUDIOMODE_TYPE)MApi_AUDIO_SIF_GetSoundMode());
#else
            msAPI_ATV_SetAudioMode(E_AUDIOSOURCE_ATV, E_AUDIOMODE_MONO);
#endif//(ENABLE_AUDIO_AUTO_DETECT)

            #if(FRONTEND_TUNER_TYPE == FRESCO_FM2150A_TUNER)
            //msAPI_ATV_SetAutoFineTuneOffset(msAPI_ATV_GetCurrentProgramNumber(),aOffset);
            #endif
            msAPI_ATV_SkipProgram(msAPI_ATV_GetCurrentProgramNumber(), FALSE);
#if (CM_MULTI_FAVORITE)
            msAPI_ATV_SetFavoriteProgram(msAPI_ATV_GetCurrentProgramNumber(), FALSE, E_FAVORITE_TYPE_ALL);
#else
            msAPI_ATV_SetFavoriteProgram(msAPI_ATV_GetCurrentProgramNumber(), FALSE);
#endif
            msAPI_ATV_LockProgram(msAPI_ATV_GetCurrentProgramNumber(), FALSE);
#if ENABLE_DVBC_PLUS_DTMB_CHINA_APP
            msAPI_ATV_SetProgramAntenna(msAPI_ATV_GetCurrentProgramNumber(), (!IsCATVInUse()));
#endif
            msAPI_ATV_NeedAFT(msAPI_ATV_GetCurrentProgramNumber(), TRUE);
            msAPI_ATV_EnableRealtimeAudioDetection(msAPI_ATV_GetCurrentProgramNumber(), TRUE);
#if ENABLE_CH_FORCEVIDEOSTANDARD
            msAPI_ATV_SetForceVideoStandardFlag(msAPI_ATV_GetCurrentProgramNumber(), FALSE) ;
#endif

            msAPI_AVD_WaitForVideoSyncLock();

            {
                AVD_VideoStandardType VdStd = msAPI_AVD_GetVideoStandard();
                //printf(" VdStd=%u; ", VdStd);
                msAPI_ATV_SetVideoStandardOfProgram(msAPI_ATV_GetCurrentProgramNumber(), VdStd);
            }

            #ifndef ENABLE_SUPPORT_ATV_STATION_NAME
            #if ENABLE_CUS_UI_SPEC
            _SetDefaultStationName(_sCurrentStationName);
            #endif
            #endif
            msAPI_ATV_SetStationName(msAPI_ATV_GetCurrentProgramNumber(), _sCurrentStationName);


            msAPI_ATV_SetSortingPriority(u8SortingPriority);
            msAPI_ATV_SetMediumAndChannelNumber(msAPI_ATV_GetCurrentProgramNumber(), _eMedium, _u8ChannelNumber);

            _eCurrentTuningState = AFT_INCREASEPRNUMBER;
#if ENABLE_AUTOTEST
            if(g_bAutobuildDebug)
            {
                printf("31_ATV_Tuning\n");
            }
#endif
          }
            break;

        case E_AUTO_SEARCH_TYPE_ONETOUP:
        case E_AUTO_SEARCH_TYPE_ONETODOWN:

            //msAPI_Tuner_UpdateMediumAndChannelNumber();
            #ifdef ENABLE_SUPPORT_ATV_STATION_NAME
            _DetectStationName();
            #endif

             {
            msAPI_ATV_SetProgramPLLData(msAPI_ATV_GetCurrentProgramNumber(), _u16TunerPLL);
            msAPI_ATV_SetAudioStandard(msAPI_ATV_GetCurrentProgramNumber(), msAPI_AUD_GetAudioStandard());
#if(ENABLE_AUDIO_AUTO_DETECT)
            msAPI_ATV_SetAudioMode(E_AUDIOSOURCE_ATV, (AUDIOMODE_TYPE)MApi_AUDIO_SIF_GetSoundMode());
#else
            msAPI_ATV_SetAudioMode(E_AUDIOSOURCE_ATV, E_AUDIOMODE_MONO);
#endif//(ENABLE_AUDIO_AUTO_DETECT)

            msAPI_ATV_SkipProgram(msAPI_ATV_GetCurrentProgramNumber(), FALSE);
#if (CM_MULTI_FAVORITE)
            msAPI_ATV_SetFavoriteProgram(msAPI_ATV_GetCurrentProgramNumber(), FALSE, E_FAVORITE_TYPE_ALL);
#else
            msAPI_ATV_SetFavoriteProgram(msAPI_ATV_GetCurrentProgramNumber(), FALSE);
#endif
            msAPI_ATV_LockProgram(msAPI_ATV_GetCurrentProgramNumber(), FALSE);
#if ENABLE_DVBC_PLUS_DTMB_CHINA_APP
            msAPI_ATV_SetProgramAntenna(msAPI_ATV_GetCurrentProgramNumber(), (!IsCATVInUse()));
#endif

            #if(FRONTEND_TUNER_TYPE == FRESCO_FM2150A_TUNER)
            //msAPI_ATV_SetAutoFineTuneOffset(msAPI_ATV_GetCurrentProgramNumber(),aOffset);
            #endif
            msAPI_ATV_NeedAFT(msAPI_ATV_GetCurrentProgramNumber(), TRUE);
            msAPI_ATV_EnableRealtimeAudioDetection(msAPI_ATV_GetCurrentProgramNumber(), TRUE);
#if ENABLE_CH_FORCEVIDEOSTANDARD
            msAPI_ATV_SetForceVideoStandardFlag(msAPI_ATV_GetCurrentProgramNumber(), FALSE) ;
#endif
            msAPI_ATV_SetVideoStandardOfProgram(msAPI_ATV_GetCurrentProgramNumber(), msAPI_AVD_GetVideoStandard());

            msAPI_AVD_WaitForVideoSyncLock();

            #ifndef ENABLE_SUPPORT_ATV_STATION_NAME
            #if ENABLE_CUS_UI_SPEC
            _SetDefaultStationName(_sCurrentStationName);
            #endif
            #endif
            msAPI_ATV_SetStationName(msAPI_ATV_GetCurrentProgramNumber(), _sCurrentStationName);


            msAPI_ATV_SetSortingPriority(u8SortingPriority);
            msAPI_ATV_SetMediumAndChannelNumber(msAPI_ATV_GetCurrentProgramNumber(), _eMedium, _u8ChannelNumber);


            }
            _eCurrentTuningState = AFT_COMPLETE;
#if ENABLE_AUTOTEST
            if(g_bAutobuildDebug)
            {
                printf("31_ATV_Manual_Tuning\n");
            }
#endif
            break;

        default:
            break;
        }

        _bIsOneProgramDetected = TRUE;
        // TODO
        msAPI_Tuner_PrintTVAVSourceInformation();
        break;

    case AFT_INCREASEPRNUMBER:
        //printf("[AFT_INCREASEPRNUMBER]");

        #if ENABLE_CUS_UPDATE_SCAN
        if(g_bGotoUpdateScan)
        {
            msAPI_ATV_IncFoundCHCount_ByUpdateScan();
        }
        #endif
        if ( eAutoSearchType == E_AUTO_SEARCH_TYPE_ALLWAYUP )
        {
            if (TRUE != msAPI_ATV_IncCurrentProgramNumber())
            {
                _eCurrentTuningState = AFT_COMPLETE;
                break;
            }
            else
            {
                if ( _IsLPrime() == TRUE )
                {
                    _u16TunerPLL = ( PLLSTEP(TUNER_PLL_PLUS_2p75MHz) );
                }
                else
                {
                    _u16TunerPLL = ( PLLSTEP(TUNER_PLL_NEXT_CHANNEL_JUMP) );
                }

                if ((_bIsLSearch)&&(u8SoundSystem == E_AUDIOSTANDARD_DK))
                {
                    msAPI_AUD_SetAudioStandard((AUDIOSTANDARD_TYPE)E_AUDIOSTANDARD_L);
                    u8SoundSystem = E_AUDIOSTANDARD_L;
                    msAPI_Tuner_SetIF();
                }
           #if (VIF_TUNER_TYPE==1)
                else if ((_bIsLSearch)&&(u8SoundSystem == E_AUDIOSTANDARD_L))
                {
                    msAPI_AUD_SetAudioStandard((AUDIOSTANDARD_TYPE)E_AUDIOSTANDARD_DK);
                    u8SoundSystem = E_AUDIOSTANDARD_DK;
                    MDrv_IFDM_SetIF(IF_FREQ_DK);
                    msAPI_Tuner_SetIF();
                }
                else
                {
                    msAPI_AUD_SetAudioStandard((AUDIOSTANDARD_TYPE)E_AUDIOSTANDARD_DK);
                    u8SoundSystem = E_AUDIOSTANDARD_DK;
                    MDrv_IFDM_SetIF(IF_FREQ_DK);
                    msAPI_Tuner_SetIF();
                }
            #endif

                _SetTunerPLL(_u16TunerPLL);

                _eCurrentTuningState = AFT_GOTO_CHECK_VIFLOCK;

            }
        }
        else
        {
            if ( TRUE != msAPI_ATV_DecCurrentProgramNumber() )
            {
                _eCurrentTuningState = AFT_COMPLETE;
                break;
            }
            else
            {
                if ( _IsLPrime() == TRUE )
                {
                    _SetTunerPLL( PLLSTEP(TUNER_PLL_MINUS_2p75MHz) );
                }
                else
                {
                    _SetTunerPLL( PLLSTEP(TUNER_PLL_NEXT_CHANNEL_JUMP) );
                }

                _eCurrentTuningState = AFT_GOTO_CHECK_VIFLOCK;
            }
        }
        msAPI_Tuner_SetIF();
        break;

    case AFT_COMPLETE:
        #if AUTO_SCAN_TIME_PRINT
        printf("\nTotal Auto Tuning Time: %lu\n", msAPI_Timer_DiffTimeFromNow(u32StartAutoTuningTime));
        #endif

        _eCurrentTuningState = AFT_IDLE;

        msAPI_AVD_SuppressAutoAV();

        switch ( eAutoSearchType )
        {
        case E_AUTO_SEARCH_TYPE_ALLWAYUP:
        case E_AUTO_SEARCH_TYPE_ALLWAYDOWN:

        #if ATVSCAN_SORT_BY_STATION_NAME
            msAPI_ATV_SortProgram(u8StartFrom, msAPI_ATV_GetCurrentProgramNumber());
        #endif

            msAPI_ATV_SetCurrentProgramNumber(u8StartFrom);

            if ( _bChangeProgram == TRUE )
            {
                msAPI_Tuner_ChangeProgram();
            }
            break;

        case E_AUTO_SEARCH_TYPE_ONETOUP:
        case E_AUTO_SEARCH_TYPE_ONETODOWN:

            msAPI_Tuner_SetIF();
            _bIsAFTNeeded = TRUE;
            msAPI_Tuner_SetRealtimeAFTBaseTunerPLL(_u16TunerPLL);
            break;

        default:
            break;
        }
		msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE_DURING_LIMITED_TIME, DELAY_FOR_STABLE_SIF, E_AUDIOMUTESOURCE_ACTIVESOURCE);
        msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE,E_AUDIO_INTERNAL_2_MUTEOFF,E_AUDIOMUTESOURCE_ATV);
#if ENABLE_TTX
        msAPI_TTX_ResetAcquisition();
#endif
        //msAPI_VD_ClearSyncCheckCounter();

        msAPI_AVD_ClearAspectRatio();

        //if(msAPI_AVD_IsVideoFormatChanged())//20100330EL
            msAPI_AVD_SetIsVideoFormatChangedAsFalse();//20100330EL

        eAutoSearchType = E_AUTO_SEARCH_TYPE_STOPED;

        msAPI_AVD_SetHsyncDetectionForTuning(FALSE);
        return;

    case AFT_EXT_STEP_SEARCHSTOP:
        msAPI_Timer_Delayms(100);

        _eCurrentTuningState = AFT_IDLE;

        eAutoSearchType = E_AUTO_SEARCH_TYPE_STOPED;

        debugTuningPrint("Stop Auto Program\n", 0);
		msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE_DURING_LIMITED_TIME, DELAY_FOR_STABLE_SIF, E_AUDIOMUTESOURCE_ACTIVESOURCE);
        msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE,E_AUDIO_INTERNAL_2_MUTEOFF,E_AUDIOMUTESOURCE_ATV);
#if ENABLE_TTX
        msAPI_TTX_ResetAcquisition();
#endif
        //msAPI_VD_ClearSyncCheckCounter();

        msAPI_AVD_ClearAspectRatio();

        _bIsAFTNeeded = FALSE;

        msAPI_Tuner_SetRealtimeAFTBaseTunerPLL(_u16TunerPLL);
        #if(FRONTEND_TUNER_TYPE == FRESCO_FM2150A_TUNER)
        //_u8RealtimeAFTBaseOffset=msAPI_ATV_GetAutoFineTuneOffset(msAPI_ATV_GetCurrentProgramNumber());
        #endif

        msAPI_AVD_SuppressAutoAV();

        msAPI_AVD_SetHsyncDetectionForTuning(FALSE);
        break;

    default:
        break;
    }

    switch ( eAutoSearchType )
    {
    case E_AUTO_SEARCH_TYPE_ALLWAYUP:
        if ( _u16TunerPLL >= UHF_MAX_PLL )
        {
            {
                _eCurrentTuningState = AFT_COMPLETE;

                _bChangeProgram = FALSE;
            }
        }
        break;

    case E_AUTO_SEARCH_TYPE_ALLWAYDOWN:
        if ( _u16TunerPLL <= VHF_LOWMIN_PLL )
        {
            {
                _eCurrentTuningState = AFT_COMPLETE;
                _bChangeProgram = FALSE;
            }
        }
        break;

    case E_AUTO_SEARCH_TYPE_ONETOUP:
        #if ENABLE_CUS_MANUAL_SCAN
        {
            if ( _u16TunerPLL > msAPI_Tuner_GetManualScanFreqConvertToPLL(msAPI_Tuner_GetManualScanEndFreq()))
            {
                {
                    _eCurrentTuningState = AFT_COMPLETE;

                    _bChangeProgram = FALSE;
                }
            }
        }
        #else
        if ( _u16TunerPLL >= UHF_MAX_PLL )
        {
            _SetTunerPLL(VHF_LOWMIN_PLL);
            msAPI_Tuner_SetIF();
            _eCurrentTuningState = AFT_GOTO_CHECK_VIFLOCK;
        }
        #endif
        break;

    case E_AUTO_SEARCH_TYPE_ONETODOWN:
        if ( _u16TunerPLL <= VHF_LOWMIN_PLL )
        {
            _SetTunerPLL(UHF_MAX_PLL);
            msAPI_Tuner_SetIF();
            _eCurrentTuningState = AFT_GOTO_CHECK_VIFLOCK;
        }
        break;

    default:
        break;
    }
}


U8 msAPI_Tuner_GetTuningProcessPercent(void)
{
    U8 u8Percent;
    U32 u32UHFMAXPLL;
    U32 u32VHFLOWMINPLL;
    U32 u32TunerPLL;

    if ( _eCurrentTuningState == AFT_IDLE ||
         _eCurrentTuningState == AFT_EXT_STEP_SEARCHALL )
    {
        return 0;
    }

    u8Percent = 0;

    u32UHFMAXPLL = UHF_MAX_PLL;

    u32VHFLOWMINPLL = VHF_LOWMIN_PLL;

    u32TunerPLL = _u16TunerPLL;

    if ( (u32UHFMAXPLL - u32VHFLOWMINPLL) )
    {
        u8Percent = (U8)(((u32TunerPLL - u32VHFLOWMINPLL)+1)*100 / (u32UHFMAXPLL - u32VHFLOWMINPLL)) ;
    }

    return u8Percent;
}

#ifdef ENABLE_CUS_AUTO_AUDIO_SYSTEM_DETECT
U8 msAPI_Tuner_GetAudioAutoDetecStatus(void)
{
    return _bAutoDetectAudioMode;
}

void msAPI_Tuner_SetAudioAutoDetecStatusExit(void)
{
    _bAutoDetectAudioMode = AUDIO_AUTO_STATUS_EXIT;
}
#endif

