////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (MStar Confidential Information) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef MAPP_GLOBALSETTINGST_H
#define MAPP_GLOBALSETTINGST_H

/********************************************************************************/
/*                              Include files                                   */
/********************************************************************************/
#include "Board.h"
#include "datatype.h"
#include "apiXC.h"
#include "apiXC_Adc.h"
#include "apiPNL.h"
#include "Panel.h"
#include "msAPI_Global.h"
#include "msAPI_Tuner.h"
#include "msAPI_Mode.h"
#include "msAPI_Power.h"


#if ((BRAZIL_CC)|| (ATSC_CC == ATV_CC))
#include "msAPI_cc_sysinfo.h"
#endif
#include "msAPI_MW_GlobalSt.h"
#include "msAPI_FreqTableCommon.h"
#include "MApp_GlobalSettingSt_Common.h"

#if (ENABLE_UPDATE_MULTIPLEX_VIA_NIT)
#include "mapp_si.h"
#endif

#if (ENABLE_CI)// || BLOADER)
#include "msAPI_CI.h"
#endif

#if ENABLE_TTX // helen add for TTX
#include "msAPI_TTX.h"
#endif

#include "MApp_UiMediaPlayer_Define.h"//DRM

/********************************************************************************/
/*                                 Macro                                        */
/********************************************************************************/
#define IsAnyTVSourceInUse()        ( IsATVInUse() || IsDTVInUse() )
#define IsAnalogSourceInUse()       ( IsVgaInUse() || IsYPbPrInUse() /*|| IsHDMIInUse()*/ )
#define IsDigitalSourceInUse()      ( IsAVInUse() || IsSVInUse() || IsATVInUse() || IsScartInUse() )

#ifdef DISABLE_COMPONENT_VBI
#define IsVBISrcInUse()        (!IsVgaInUse() && !IsHDMIInUse() && !IsStorageInUse() && !IsYPbPrInUse())
#else
#define IsVBISrcInUse()        (!IsVgaInUse() && !IsHDMIInUse() && !IsStorageInUse() )
#endif

#if ENABLE_DVBC_PLUS_DTMB_CHINA_APP
#define ENABLE_T_C_COMBO ENABLE
#else
#define ENABLE_T_C_COMBO ((FRONTEND_SECOND_DEMOD_TYPE==EMBEDDED_DVBC_DEMOD)&&(FRONTEND_DEMOD_TYPE==EMBEDDED_DVBT_DEMOD))
#endif

#if (DVB_T_C_DIFF_DB || ENABLE_T_C_COMBO)
extern BOOLEAN bDVBC;
#define IsCATVInUse()              ((stGenSetting.stScanMenuSetting.u8DVBCTvConnectionType == EN_DVB_C_TYPE) ? 1 :0)
#endif

#define MAX_DTV_PHYSICAL_CH_NUM        70  // 2~69
#define MAX_ATV_PHYSICAL_CH_NUM         1  // 2~69
#define MAX_PHYSICAL_CH_NUM                (MAX_DTV_PHYSICAL_CH_NUM + MAX_ATV_PHYSICAL_CH_NUM)

#define DTV_BASE_PHYSICAL_IDX              (0)
//#define ATV_BASE_PHYSICAL_IDX              (DTV_BASE_PHYSICAL_IDX+MAX_DTV_PHYSICAL_CH_NUM)

#if ( ENABLE_DVB_TAIWAN_APP || ENABLE_SBTVD_BRAZIL_APP || (TV_SYSTEM == TV_NTSC) )
#define CHAN_AIR_MIN                       24
#define CHAN_AIR_MAX                       36
#elif (  TV_SYSTEM == TV_NTSC )
#define CHAN_AIR_MIN                       1
#define CHAN_AIR_MAX                       99
#else
#define CHAN_AIR_MIN                       21
#define CHAN_AIR_MAX                       69
#endif


#define MAX_STD_MODE_NUM                   (MD_STD_MODE_MAX_INDEX)
#define MAX_USER_MODE_NUM                  20
#define MAX_MODE_NUM                       (MAX_STD_MODE_NUM+MAX_USER_MODE_NUM)

#define MIN_STD_COMPO_NUM                   (YPBPR_MD_START)
#define MAX_STD_COMPO_NUM                   (YPBPR_MD_END)
#if (ENABLE_SBTVD_BRAZIL_APP)
#define MAX_AUD_LANG_NUM                   5//Brazil Prepare for 3 audio language: Eng Spa Por
#else
#define MAX_AUD_LANG_NUM                   8 //NZ default 16
#endif
#define MAX_AUD_LANG_LENGTH                3
#define MAX_VC_PER_PHYSICAL                120//SI_MAX_VC_PER_PHYSICAL//67//62

#define MENU_LANGUAGE_FONT_ENGX2        (1)

#define SCREEN_SAVER_FRAME_WIDTH       300
#define SCREEN_SAVER_FRAME_HEIGHT      100
//#if (ENABLE_PIP)
#define SUB_SCREEN_SAVER_FRAME_WIDTH   200
#define SUB_SCREEN_SAVER_FRAME_HEIGHT  60

#define SCREEN_SAVER_PIP_FRAME_WIDTH   347
#define SCREEN_SAVER_PIP_FRAME_HEIGHT  195
//#endif
#if BOE_UART_FAC_COMMAND//minglin0118
#define MS_COLOR_TEMP_COUNT  4
#else
#define MS_COLOR_TEMP_COUNT 3// 4
#endif
#ifdef MSOS_TYPE_LINUX
#define POLLING_SLEEP_MS            20
#endif

#if ENABLE_CUS_MANUAL_SCAN
#define MIN_MANUAL_START_FREQ       45250 // 43Mhz
#define MAX_MANUAL_END_FREQ         863250 // 873Mhz
#endif
#if ENABLE_NEW_SPDIF_MUTE_METHOD
#define FORCE_MUTE          TRUE
#define NORMAL_MUTE         FALSE
#endif

#define FORCE_SET_VALUE     TRUE
#define NORMAL_SET_VALUE    FALSE
/********************************************************************************/
/*                                 Enum                                         */
/********************************************************************************/
//DVB Source information 
typedef enum
{
        UI_INPUT_SOURCE_DTV,            // VIDEO - DTV Tuner
        UI_INPUT_SOURCE_ATV,            // VIDEO - TV Tuner
#if DVB_C_ENABLE
    #if ENABLE_DVBC_PLUS_DTMB_CHINA_APP
    #else
        UI_INPUT_SOURCE_CADTV,
    #endif
#endif
#if (INPUT_SCART_VIDEO_COUNT >= 1)
        UI_INPUT_SOURCE_SCART,
#endif
#if (INPUT_SCART_VIDEO_COUNT >= 2)
        UI_INPUT_SOURCE_SCART2,
#endif

#if (INPUT_YPBPR_VIDEO_COUNT>=1)
        UI_INPUT_SOURCE_COMPONENT,      // VIDEO - YPbPr
#endif
#if (INPUT_YPBPR_VIDEO_COUNT >= 2)
        UI_INPUT_SOURCE_COMPONENT2,
#endif

        UI_INPUT_SOURCE_RGB,            // PC - VGA

#if (INPUT_HDMI_VIDEO_COUNT >= 1)
        UI_INPUT_SOURCE_HDMI,           // HDMI
#endif
#if (INPUT_HDMI_VIDEO_COUNT >= 2)
        UI_INPUT_SOURCE_HDMI2,
#endif
#if (INPUT_HDMI_VIDEO_COUNT >= 3)
        UI_INPUT_SOURCE_HDMI3,
#endif
#if (INPUT_HDMI_VIDEO_COUNT >= 4)
        UI_INPUT_SOURCE_HDMI4,
#endif

#if (INPUT_AV_VIDEO_COUNT >= 1)
        UI_INPUT_SOURCE_AV,             // VIDEO - CVBS
#endif
#if (INPUT_AV_VIDEO_COUNT >= 2)
        UI_INPUT_SOURCE_AV2,
#endif
#if (INPUT_AV_VIDEO_COUNT >= 3)
        UI_INPUT_SOURCE_AV3,
#endif

#if (INPUT_SV_VIDEO_COUNT >= 1)
        UI_INPUT_SOURCE_SVIDEO,
#endif
#if ((INPUT_SCART_USE_SV2 == 0) && (INPUT_SV_VIDEO_COUNT >= 2))
        UI_INPUT_SOURCE_SVIDEO2,
#endif
#if (ENABLE_DMP || BLOADER)
        UI_INPUT_SOURCE_DMP,
  #if( ENABLE_DMP_SWITCH )
    UI_INPUT_SOURCE_DMP1,
    UI_INPUT_SOURCE_DMP2,
  #endif
        //UI_INPUT_SOURCE_DLNA, //must
#endif
        UI_INPUT_SOURCE_RSS,
        UI_INPUT_SOURCE_BT,
        UI_INPUT_SOURCE_YOUTUBE,
        UI_INPUT_SOURCE_GYM,
        UI_INPUT_SOURCE_KTV,
        UI_INPUT_SOURCE_PLUG_IN,
        //#ifdef ENABLE_NETFLIX
        //UI_INPUT_SOURCE_NETFLIX,
        //#endif
        #if (ENABLE_GAME)
        UI_INPUT_SOURCE_GAME,
        #endif
        #ifdef ENABLE_EXTENSION
        UI_INPUT_SOURCE_EXTENSION,
        #endif
//#if (ENABLE_PIP)
        UI_INPUT_SOURCE_NONE,   //i.e. close specific window(MAIN or SUB) by scaler.
//#endif
#if ENABLE_SBTVD_BRAZIL_APP
        UI_INPUT_SOURCE_ANTENNA = UI_INPUT_SOURCE_DTV,    // for SBTVD system Air source
        UI_INPUT_SOURCE_CABLE = UI_INPUT_SOURCE_ATV,      // for SBTVD system Cable source
#endif
        UI_INPUT_SOURCE_NUM,
} E_UI_INPUT_SOURCE;

#if ENABLE_SBTVD_BRAZIL_APP
typedef enum
{
    ANTENNA_DTV_TYPE,
    ANTENNA_ATV_TYPE,
    ANTENNA_TYPE_NUM
}E_ANTENNA_SOURCE_TYPE;
#endif

typedef enum
{
     SYSMONITOR_FSM_WAIT,
     SYSMONITOR_FSM_DNR_RW_CMD,
     SYSMONITOR_FSM_DNR_RW_CHK,
     SYSMONITOR_FSM_MIU_IP_CMD,
     SYSMONITOR_FSM_MIU_IP_CHK,
     SYSMONITOR_FSM_MIU_OP_CMD,
     SYSMONITOR_FSM_MIU_OP_CHK,
     SYSMONITOR_FSM_EXCEPTION,
} EN_SYSMONITOR_FSM;

typedef enum
{
    SERVICE_TYPE_INVALIDE = E_SERVICETYPE_INVALID,
    SERVICE_TYPE_DTV      = E_SERVICETYPE_DTV,
    SERVICE_TYPE_RADIO    = E_SERVICETYPE_RADIO,
    SERVICE_TYPE_ATV      = E_SERVICETYPE_ATV,
  #if NORDIG_FUNC //for Nordig Spec v2.0
    SERVICE_TYPE_DATA     = E_SERVICETYPE_DATA,
  #endif
    SERVICE_TYPE_TV       = E_SERVICETYPE_UNITED_TV,
} EN_SERVICE_TYPE;

typedef enum
{
    IDLE_MODE,
    ANALOGINPUTS_MODE,
    MENU_MODE
} EN_MODE;

typedef enum _EN_MENU_LANGUAGE
{
    LANGUAGE_MENU_MIN = 0,
 #if (ENABLE_CUS_OSD_LANGUAGE == DISABLE)
    LANGUAGE_CZECH = LANGUAGE_MENU_MIN,       //Minimum of OSD menu, Audio, and Subtitle Language
    LANGUAGE_DANISH,
    LANGUAGE_GERMAN,
    LANGUAGE_ENGLISH,
    LANGUAGE_SPANISH,
    LANGUAGE_GREEK,
    LANGUAGE_FRENCH,
    LANGUAGE_CROATIAN,
    LANGUAGE_ITALIAN,
    LANGUAGE_HUNGARIAN,
    LANGUAGE_DUTCH,
    LANGUAGE_NORWEGIAN,
    LANGUAGE_POLISH,
    LANGUAGE_PORTUGUESE,
    LANGUAGE_RUSSIAN,
    LANGUAGE_ROMANIAN,
    LANGUAGE_SLOVENIAN,
    LANGUAGE_SERBIAN,
    LANGUAGE_FINNISH,
    LANGUAGE_SWEDISH,
    LANGUAGE_BULGARIAN,
    LANGUAGE_SLOVAK,
   #if (ENABLE_DTMB_CHINA_APP || ENABLE_ATV_CHINA_APP || ENABLE_DVBC_PLUS_DTMB_CHINA_APP||CHINESE_SIMP_FONT_ENABLE ||CHINESE_BIG5_FONT_ENABLE)
    LANGUAGE_CHINESE,
    LANGUAGE_MENU_MAX = LANGUAGE_CHINESE,        // OSD Menu Language Maximum
   #else
    LANGUAGE_MENU_MAX = LANGUAGE_SLOVAK,        // OSD Menu Language Maximum
   #endif
#else
    LANGUAGE_ENGLISH = LANGUAGE_MENU_MIN,       //Minimum of OSD menu, Audio, and Subtitle Language
    LANGUAGE_RUSSIAN,
    LANGUAGE_ARABIC,
   
   #if (ENABLE_DTMB_CHINA_APP || ENABLE_ATV_CHINA_APP || ENABLE_DVBC_PLUS_DTMB_CHINA_APP||CHINESE_SIMP_FONT_ENABLE ||CHINESE_BIG5_FONT_ENABLE)
    LANGUAGE_CHINESE,
   #if(UI_SKIN_SEL==UI_SKIN_1366X768X565_HAIER_CN)  // CUS_xm zHIHE 20120814 modify
    LANGUAGE_INDONESIAN,
    LANGUAGE_FARSI,
    LANGUAGE_HEBREW,
    LANGUAGE_THAI,
	LANGUAGE_MENU_MAX = LANGUAGE_THAI,        // OSD Menu Language Maximum
	#else
    LANGUAGE_MENU_MAX = LANGUAGE_CHINESE,        // OSD Menu Language Maximum
    #endif
	
   #else
    LANGUAGE_MENU_MAX = LANGUAGE_RUSSIAN,        // OSD Menu Language Maximum
   #endif
    LANGUAGE_GERMAN,
    LANGUAGE_SPANISH,
    LANGUAGE_FRENCH,
    LANGUAGE_ITALIAN,
    LANGUAGE_PORTUGUESE,
    LANGUAGE_CZECH,       //Minimum of OSD menu, Audio, and Subtitle Language
    LANGUAGE_DANISH,
    //LANGUAGE_GERMAN,
    //LANGUAGE_ENGLISH,
    //LANGUAGE_SPANISH,
    LANGUAGE_GREEK,
    //LANGUAGE_FRENCH,
    LANGUAGE_CROATIAN,
    //LANGUAGE_ITALIAN,
    LANGUAGE_HUNGARIAN,
    LANGUAGE_DUTCH,
    LANGUAGE_NORWEGIAN,
    LANGUAGE_POLISH,
    //LANGUAGE_PORTUGUESE,
    //LANGUAGE_RUSSIAN,
    LANGUAGE_ROMANIAN,
    LANGUAGE_SLOVENIAN,
    LANGUAGE_SERBIAN,
    LANGUAGE_FINNISH,
    LANGUAGE_SWEDISH,
    LANGUAGE_BULGARIAN,
    LANGUAGE_SLOVAK,
#endif
    LANGUAGE_GAELIC,
    LANGUAGE_WELSH,
    LANGUAGE_IRISH,
    LANGUAGE_AUDIO_MAX_EU = LANGUAGE_IRISH,      // Audio Language Europe Maximum
    LANGUAGE_KOREAN,
    LANGUAGE_JAPAN,
    LANGUAGE_HINDI,
    LANGUAGE_MAORI,
    LANGUAGE_MANDARIN,
    LANGUAGE_CANTONESE,
    LANGUAGE_AUDIO_MAX_NZ = LANGUAGE_CANTONESE,      // Audio Language New Zealannd Maximum
    LANGUAGE_TURKISH,
    LANGUAGE_NETHERLANDS,
    LANGUAGE_GALLEGAN,
    LANGUAGE_BASQUE,
    LANGUAGE_LUXEMBOURGISH,
    LANGUAGE_ICELANDIC,
    LANGUAGE_LATVIAN,
    LANGUAGE_ESTONIAN,
    LANGUAGE_LITHUANIAN,
    LANGUAGE_UKRANIAN,
    LANGUAGE_BELARUSIAN,
    LANGUAGE_SPANISH_CAT,
    LANGUAGE_SAMI,
    #if(UI_SKIN_SEL==UI_SKIN_1366X768X565_HAIER_CN)  // CUS_xm zHIHE 20120815 modify
	
    #else
    LANGUAGE_HEBREW,   //cus_xm zhihe 20120815 modify  for HAIER  OSD language
    LANGUAGE_THAI,	     //cus_xm zhihe  20120815  modify for  HAIER  OSD language
    #endif
  //  LANGUAGE_HEBREW, //cus_xm zhihe  20120815  modify for  HAIER  OSD language
    LANGUAGE_KURDISH,
    LANGUAGE_PARSI,
   // LANGUAGE_THAI,   //cus_xm zhihe  20120815  modify for  HAIER  OSD language
    LANGUAGE_QAA,
    LANGUAGE_UND,     //Italy CI Certificate
    LANGUAGE_UNKNOWN, //move to hear to avoid haveing same value as spanish.
    LANGUAGE_AUDIO1,
    LANGUAGE_AUDIO2,
    LANGUAGE_AUDIO3,
    LANGUAGE_AUDIO4,
    LANGUAGE_AUDIO5,
    LANGUAGE_AUDIO6,
    LANGUAGE_ENGX2 = MENU_LANGUAGE_FONT_ENGX2,
    LANGUAGE_NONE = 0xFF,
} EN_LANGUAGE;

#define LANGUAGE_SUBTITLE_MAX_EU LANGUAGE_IRISH        // Subtitle Language Europe Maximum
#define LANGUAGE_SUBTITLE_MAX_NZ LANGUAGE_MAORI   // Subtitle Language New Zealannd Maximum
#if ENABLE_ATV_CHINA_APP
	  #if (CUS_AREA_ID==AREA_ID_CHINA)  //cus_xm:zb add at 2012-7-23
	  	#define  LANGUAGE_DEFAULT  LANGUAGE_ENGLISH//LANGUAGE_CHINESE
	  #else
	  	#define LANGUAGE_DEFAULT  LANGUAGE_ENGLISH
         #endif
#else
#define LANGUAGE_DEFAULT LANGUAGE_ENGLISH
#endif

typedef enum _EN_OSD_COUNTRY_SETTING
{
    OSD_COUNTRY_AUSTRALIA       = E_AUSTRALIA,
    OSD_COUNTRY_AUSTRIA         = E_AUSTRIA,
    OSD_COUNTRY_BELGIUM         = E_BELGIUM,
    OSD_COUNTRY_BULGARIA        = E_BULGARIA,
    OSD_COUNTRY_CROATIA         = E_CROATIA,
    OSD_COUNTRY_CZECH           = E_CZECH,
    OSD_COUNTRY_DENMARK         = E_DENMARK,
    OSD_COUNTRY_FINLAND         = E_FINLAND,
    OSD_COUNTRY_FRANCE          = E_FRANCE,
    OSD_COUNTRY_GERMANY         = E_GERMANY,
    OSD_COUNTRY_GREECE          = E_GREECE,
    OSD_COUNTRY_HUNGARY          = E_HUNGARY,
    OSD_COUNTRY_ITALY           = E_ITALY,
    OSD_COUNTRY_LUXEMBOURG      = E_LUXEMBOURG,
    OSD_COUNTRY_NETHERLANDS     = E_NETHERLANDS,
    OSD_COUNTRY_NORWAY          = E_NORWAY,
    OSD_COUNTRY_POLAND          = E_POLAND,
    OSD_COUNTRY_PORTUGAL        = E_PORTUGAL,
    OSD_COUNTRY_RUMANIA         = E_RUMANIA,
    OSD_COUNTRY_RUSSIA          = E_RUSSIA,
    OSD_COUNTRY_SERBIA          = E_SERBIA,
    OSD_COUNTRY_SLOVENIA        = E_SLOVENIA,
    OSD_COUNTRY_SPAIN           = E_SPAIN,
    OSD_COUNTRY_SWEDEN          = E_SWEDEN,
    OSD_COUNTRY_SWITZERLAND     = E_SWITZERLAND,
    OSD_COUNTRY_UK              = E_UK,
    OSD_COUNTRY_UNITED_ARAB_EMIRATES    = E_UNITED_ARAB_EMIRATES,
    OSD_COUNTRY_NEWZEALAND      = E_NEWZEALAND,
    OSD_COUNTRY_CHINA           = E_CHINA,
    OSD_COUNTRY_ESTONIA         = E_ESTONIA,
    OSD_COUNTRY_TURKEY          = E_TURKEY,
    OSD_COUNTRY_MOROCCO         = E_MOROCCO,
    OSD_COUNTRY_TUNIS           = E_TUNIS,
    OSD_COUNTRY_ALGERIA         = E_ALGERIA,
    OSD_COUNTRY_EGYPT           = E_EGYPT,
    OSD_COUNTRY_SOUTH_AFRICA    = E_SOUTH_AFRICA,
    OSD_COUNTRY_ISRAEL          = E_ISRAEL,
    OSD_COUNTRY_IRAN            = E_IRAN,

    OSD_COUNTRY_SLOVAKIA        		= E_SLOVAKIA,
    #if (ENABLE_DVB_TAIWAN_APP)
    OSD_COUNTRY_TAIWAN          = E_TAIWAN,
    #endif
    #if (ENABLE_SBTVD_BRAZIL_APP)
    OSD_COUNTRY_BRAZIL          = E_BRAZIL,
    #endif
    OSD_COUNTRY_NUMS,
    OSD_COUNTRY_IRELAND          = E_IRELAND, //TODO, wait UI
} EN_OSD_COUNTRY_SETTING;

//Tune Type Index
typedef enum _EN_OSD_TUNE_TYPE_SETTING
{
#if  ENABLE_SBTVD_BRAZIL_APP
    OSD_TUNE_TYPE_AIR_PLUS_CABLE,
    //OSD_TUNE_TYPE_AIR_ONLY,
    //OSD_TUNE_TYPE_CABLE_ONLY,
#else
    OSD_TUNE_TYPE_DTV_PLUS_ATV,
#endif
    OSD_TUNE_TYPE_DTV_ONLY,
    OSD_TUNE_TYPE_ATV_ONLY,
#if DVB_C_ENABLE
    //OSD_TUNE_TYPE_CADTV_ONLY,
#endif
    OSD_TUNE_TYPE_NUMS
}EN_OSD_TUNE_TYPE_SETTING;

//DVBC Scan Type Index
#if ENABLE_T_C_COMBO
typedef enum _EN_OSD_DVBC_SCAN_TYPE
{
    OSD_DVBC_TYPE_FULL,
    OSD_DVBC_TYPE_NETWOEKSCAN,
    OSD_DVBC_TYPE_NUMS
}EN_OSD_DVBC_SCAN_TYPE;
#endif

// ADC setting index
typedef enum _AdcSetIndexType
{
    ADC_SET_VGA,
    ADC_SET_YPBPR_SD,
    ADC_SET_YPBPR_HD,
    ADC_SET_SCART_RGB,
    ADC_SET_NUMS
}E_ADC_SET_INDEX;

#if ((ENABLE_SBTVD_BRAZIL_APP && BRAZIL_CC)||(ATSC_CC == ATV_CC))
typedef enum
{
    ATV_CAPTION_TYPE_OFF,
    ATV_CAPTION_TYPE_CC1,
    ATV_CAPTION_TYPE_CC2,
    ATV_CAPTION_TYPE_CC3,
    ATV_CAPTION_TYPE_CC4,
    ATV_CAPTION_TYPE_TEXT1,
    ATV_CAPTION_TYPE_TEXT2,
    ATV_CAPTION_TYPE_TEXT3,
    ATV_CAPTION_TYPE_TEXT4,
    ATV_CAPTION_TYPE_NUM
} EN_ATV_CAPTION_TYPE;


typedef enum
{
    DTV_CAPTION_OFF,
    DTV_CAPTION_ON
} EN_DTV_CAPTION_TYPE;
#endif

typedef enum
{
    CH_TYPE_DTV,
    CH_TYPE_ATV,
    CH_TYPE_NUMS
} EN_CH_TYPE;


typedef enum
{
    SCAN_TYPE_AUTO,
    SCAN_TYPE_MANUAL,
#if DVB_C_ENABLE
    SCAN_TYPE_NETWORK,
#endif
#if (ENABLE_UPDATE_MULTIPLEX_VIA_NIT)
    SCAN_TYPE_UPDATE_MUX,
#endif
    SCAN_TYPE_NUM
} EN_SCAN_TYPE;


typedef enum
{
    ATV_MAN_SCAN_TYPE_ONECH,
    ATV_MAN_SCAN_TYPE_CHNUM,
} EN_ATV_MAN_SCAN_TYPE;


typedef enum
{
    ATV_MAN_SCAN_UP,
    ATV_MAN_SCAN_DOWN,
} EN_ATV_MAN_SCAN_DIR;

#if  ENABLE_3D_PROCESS
typedef enum
{
    EN_3D_BYPASS,
    EN_3D_FRAME_PARKING,
    EN_3D_SIDE_BY_SIDE,
    EN_3D_TOP_BOTTOM,
    EN_3D_LINE_BY_LINE,
    EN_3D_FRAME_ALTERNATIVE,
    EN_3D_NORMAL_2D,
    EN_3D_3D_TO_2D,
    EN_3D_TYPE_NUM
} EN_3D_TYPE;

typedef enum
{
    EN_3D_DETECT_AUTO,
    EN_3D_DETECT_MANUAL,
    EN_3D_DETECT_NUM
} EN_3D_DETECT_MODE;

typedef enum
{
    EN_3D_LR_L,
    EN_3D_LR_R,
    EN_3D_LR_NUM
} EN_3D_LR_MODE;

#endif

#if (ENABLE_UI_3D_PROCESS)
typedef enum
{
    E_UI_3D_UI_TOP_BOTTOM,           //0110
    E_UI_3D_UI_SIDE_BY_SIDE_HALF,    //1000
    E_UI_3D_UI_MODE_NONE,            //1111
    E_UI_3D_UI_MODE_NUM,
} E_UI_3D_UI_MODE;
#endif


typedef enum
{
    EN_E4_HDMICEC_Off,
    EN_E4_HDMICEC_On,
    EN_E4_HDMICEC_Num
} EN_MENU_E4_HMDICEC;

typedef enum
{
    EN_E5_KeyLock_Off,
    EN_E5_KeyLock_On,
    EN_E5_KeyLock_Num
} EN_MENU_E5_KeyLock;

typedef enum
{
    CLEAR_VCH_DB,
    CLEAR_VCH_DB_AND_SET_FACTORY_VCH,
}EN_VCH_DB_CLEAR_TYPE;

typedef enum
{
    MS_COLOR_TEMP_MIN,
    MS_COLOR_TEMP_COOL = MS_COLOR_TEMP_MIN,
    MS_COLOR_TEMP_MEDIUM,
    MS_COLOR_TEMP_WARM,
#if(MS_COLOR_TEMP_COUNT ==4)
    MS_COLOR_TEMP_USER,
    MS_COLOR_TEMP_MAX = MS_COLOR_TEMP_USER
#else
    MS_COLOR_TEMP_MAX = MS_COLOR_TEMP_WARM
#endif
} EN_MS_COLOR_TEMP;

#ifdef ENABLE_GAMMA_FOR_COLORTEMP
typedef enum
{
    MS_GAMMA_TYPE_MIN,
    MS_GAMMA_TYPE_COOL = MS_COLOR_TEMP_MIN,
    MS_GAMMA_TYPE_MEDIUM,
    MS_GAMMA_TYPE_WARM,
#if(MS_COLOR_TEMP_COUNT ==4)
    MS_GAMMA_TYPE_USER,
#endif
    MS_GAMMA_TYPE_MAX
} EN_MS_GAMMA_TYPE;
#endif

typedef enum
{
    PICTURE_MIN,
    PICTURE_DYNAMIC = PICTURE_MIN,
    PICTURE_NORMAL,
    PICTURE_MILD,
    #if ENABLE_PICTURE_MODE_ENERGY_SAVING
    PICTURE_ENERGY_SAVING,
    #endif
    PICTURE_USER,
    #if PICTURE_USER_2
    PICTURE_USER2,
    #endif
    PICTURE_NUMS
} EN_MS_PICTURE;


typedef enum
{
    MS_BLACK_LEVEL_MIN,
    MS_BLACK_LEVEL_AUTO = MS_BLACK_LEVEL_MIN,
    MS_BLACK_LEVEL_LOW ,
    MS_BLACK_LEVEL_HIGH,
    MS_BLACK_LEVEL_NUM
} EN_MS_BLACK_LEVEL;


//#if (ENABLE_PIP)
typedef enum
{
    EN_PIP_MODE_PIP,
    EN_PIP_MODE_POP_FULL,
    EN_PIP_MODE_POP,
    EN_PIP_MODE_OFF,
    EN_PIP_MODE_INVALID,
} EN_PIP_MODE;

typedef enum
{
    EN_PIP_SIZE_SMALL,
    EN_PIP_SIZE_MEDIUM,
    EN_PIP_SIZE_LARGE,
    EN_PIP_SIZE_INVALID,
} EN_PIP_SIZE;

typedef enum
{
    EN_PIP_SOUND_SRC_MAIN,
    EN_PIP_SOUND_SRC_SUB,
    EN_PIP_SOUND_SRC_INVALID,
} EN_PIP_SOUND_SRC;

typedef enum
{
    EN_PIP_POSITION_LEFT_TOP,
    EN_PIP_POSITION_RIGHT_TOP,
    EN_PIP_POSITION_LEFT_BOTTOM,
    EN_PIP_POSITION_RIGHT_BOTTOM,
    //EN_PIP_POSITION_USER,             /* We do not support user-defined position */
    EN_PIP_POSITION_INVALID,
} EN_PIP_POSITION;
//#endif
#if (ENABLE_SW_CH_FREEZE_SCREEN)
typedef enum
{
    ATV_SWITCH_CH_BLACK_SCREEN,
    ATV_SWITCH_CH_FREEZE_SCREEN,
    ATV_SWITCH_CH_NUMS,
    ATV_SWITCH_CH_DEFAULT=ATV_SWITCH_CH_FREEZE_SCREEN,  //ATV_SWITCH_CH_BLACK_SCREEN,
} EN_ATV_SWITCH_CH_MODE;
#endif

#if (ENABLE_FACTORY_POWER_ON_MODE)
typedef enum
{
    POWERON_MODE_SAVE,
    POWERON_MODE_OFF,
    POWERON_MODE_ON,
    POWERON_MODE_NUMS
}POWERON_MODE_TYPE;
#endif

#if ENABLE_VD_PACH_IN_CHINA
typedef enum
{
    E_AUDIO_HIDEV_OFF,
    E_AUDIO_HIDEV_BW_L1,
    E_AUDIO_HIDEV_BW_L2,
    E_AUDIO_HIDEV_BW_L3,
    E_AUDIO_HIDEV_BW_NUMS
}AUDIO_HIDEV_TYPE;
#endif

#if ENABLE_CUS_OSD_TIMEOUT
typedef enum
{
    EN_OSD_TIME_10=1,
    EN_OSD_TIME_MIN = EN_OSD_TIME_10,
    EN_OSD_TIME_20,
    EN_OSD_TIME_30,
    EN_OSD_TIME_40,
    EN_OSD_TIME_50,
    EN_OSD_TIME_60,
    EN_OSD_TIME_ALWAYS,
    EN_OSD_TIME_NUM
}EN_OSD_TIME;
#else
typedef enum
{
    EN_OSD_TIME_5=1,
    EN_OSD_TIME_MIN = EN_OSD_TIME_5,
    EN_OSD_TIME_10,
    EN_OSD_TIME_15,
    EN_OSD_TIME_ALWAYS,
    EN_OSD_TIME_NUM
}EN_OSD_TIME;
#endif
typedef enum
{
   EN_OSD_TRAN_OFF,
   EN_OSD_TRAN_LOW,
   EN_OSD_TRAN_MIDDLE,
   EN_OSD_TRAN_HIGH,
}EN_OSD_TRAN;
//color_System
///////////////////////////////////////////////////
typedef enum
{
    ATV_COLOR_AUTO,
    ATV_COLOR_PAL,
    ATV_COLOR_PAL_M,
    ATV_COLOR_PAL_N,
    ATV_COLOR_PAL_60,
    ATV_COLOR_NTSC,
    ATV_COLOR_NTSC_44,
    ATV_COLOR_SECAM,
    ATV_COLOR_SYSTEM_NUMS
} EN_ATV_COLOR_SYSTEM;
/********************************************************************************/
/*                              Structure Type                                  */
/********************************************************************************/
/*
    The BBE, SRS, VDS and VSPK mode number is mapped to
    En_DVB_advsndType enumeration in drvAudioProcessor.h
*/
typedef enum
{
    #define SURROUND_SYSTEM_TYPE_MASK 0x07
    SURROUND_SYSTEM_OFF = 0x00,

    #define BBE_MODE_BIT 0x10        //BBE : 0 , Viva : 1
    #define BBE_MODE 0
    #define VIVA_MODE 1
    SURROUND_SYSTEM_BBE = 0x01,

    #define DIALOG_CLARITY_BIT 0x10  //enable : 1 , disable : 0
    #define TRUBASS_BIT 0x20         //enable : 1 , disable : 0
    SURROUND_SYSTEM_SRS = 0x02,

    SURROUND_SYSTEM_VDS = 0x03,

    #define WIDE_MODE_BIT 0x10       // reference : 0 , wind : 1
    #define SURROUND_MODE_BIT 0x20   // movie : 0 , music : 1
    #define WIDE_MODE 1
    #define REFERENCE_MODE 0
    #define SURROUND_MODE_MOVIE 0
    #define SURROUND_MODE_MUSIC 1
    SURROUND_SYSTEM_VSPK = 0x04,

    SURROUND_SYSTEM_SURROUNDMAX = 0x05,

    SURROUND_SYSTEM_NUMS,
} EN_SURROUND_SYSTEM_TYPE;

typedef struct
{
    U8 Bass;					// CUS_XM Sea 20120725: register 0X112D86
    U8 Treble;					// CUS_XM Sea 20120725: register 0X112D88
    U8 u8120HZ;//120HZ			// CUS_XM Sea 20120725: register 0X112D94
    U8 u8500HZ; //500HZ			// CUS_XM Sea 20120725: register 0X112D96
    U8 u8_1_dot_5_KHZ;///1.5KHZ	// CUS_XM Sea 20120725: register 0X112D98
    U8 u8_5KHZ;//5KHZ				// CUS_XM Sea 20120725: register 0X112D9a
    U8 u810KHZ; //10KHZ			// CUS_XM Sea 20120725: register 0X112D9c
    BOOLEAN UserMode;
    U8 Balance;
    EN_AUD_MODE      enSoundAudioChannel;
#if (ENABLE_CUS_SURROUND_FOLLOW_SNDMODE)
    EN_SURROUND_SYSTEM_TYPE SurroundSoundMode;
#endif
} stSoundModeSeting;

#define ST_AUDIO_PEQ stGenSetting.g_SoundSetting.astSoundPEqSetting
typedef struct
{
    U16 u16_Fo1Value;
    //U16 u16_Fo1_2Value;
    U16 u16_Fo2Value;
    //U16 u16_Fo2_2Value;
    U16 u16_Fo3Value;
    //U16 u16_Fo3_2Value;
    U8 u8_Gain1Value;
    U8 u8_Gain2Value;
    U8 u8_Gain3Value;
    U8 u8_Q1Value;
    U8 u8_Q2Value;
    U8 u8_Q3Value;
    U8 u8_PEQOnOff;
} stSoundPEqSetting;

typedef struct _SoundSettingType
{
    U16    soundSettingCS; // check sum <<checksum should be put at top of the struct, do not move it to other place>>

    /* ========================
        Sound Mode Enumeration
        ======================== */
    EN_SOUND_MODE     SoundMode;

    /* ========================
        The settings for each sound mode
        ======================== */
    stSoundModeSeting astSoundModeSetting[SOUND_MODE_NUM];
     /* ========================
        Surround Sound Mode
        ======================== */
 #if (ENABLE_CUS_SURROUND_FOLLOW_SNDMODE == DISABLE)
    EN_SURROUND_SYSTEM_TYPE SurroundSoundMode;
 #endif

    EN_SURROUND_TYPE  Surround;
    BOOLEAN           bEnableAVC;
    U8                Volume;
    U8                Balance;
    U8                Primary_Flag;
    U8                enSoundAudioLan1;  //EN_LANGUAGE
    U8                enSoundAudioLan2;  //EN_LANGUAGE
    U8                MUTE_Flag;     // for ATSC_TRUNK
#ifdef ENABLE_KTV
    U8                KTVBGVolume;
    U8                KTVMicVolume;
    U8                KTVMixVolume;
#endif
    EN_AUD_MODE       enSoundAudioChannel;
    BOOLEAN           bEnableAD;
    U8 ADVolume;
    EN_SOUND_AD_OUTPUT ADOutput;
#if ENABLE_CUS_AUDIO_DELAY
    U8                LipSyncDelayTime;
#endif
    /* ========================
    The settings for PEQ
    ======================== */
    stSoundPEqSetting  astSoundPEqSetting;

} stUserSoundSettingType;

typedef struct
{
    U8 u8Backlight;             //backlilght
    U8 u8Contrast;              // contrast
    U8 u8Brightness;            // brightness
    U8 u8Saturation;            // Saturation
    U8 u8Sharpness;             // Sharpness
    U8 u8Hue;
    EN_MS_COLOR_TEMP eColorTemp; // color temperature
#if ENABLE_FLESH_TONE
    EN_MS_FLESH_TONE_MODE eFleshToneMode;
#endif
#if ENABLE_CUS_DBC
    EN_DBC_STATUS bDBCStatus;
#endif
#if ENABLE_CUS_DLC
    EN_DLC_STATUS bDLCStatus;
#endif
#if ENABLE_CUS_NR_MODE_FOLLOW_PICMODE
    T_MS_NR_MODE eNRMode;
#endif
    U8 PicUserMode;
} T_MS_PICTURE;  //T_MS_PICTURE

// SubColor Setting
typedef struct
{
    U16 u16SubColorDataCS;// check sum <<checksum should be put at top of the struct, do not move it to other place>>

    U8 u8SubBrightness;            // brightness
    U8 u8SubContrast;              // contrast
} T_MS_SUB_COLOR;

#ifdef ENABLE_CUS_SERIAL_NUMBER
// serial num
typedef struct
{
    U16 u16SerialNumCS;// check sum <<checksum should be put at top of the struct, do not move it to other place>>
    U8 u8SerialNumber[CUS_CSM_SN_SIZE];
} T_MS_SERIAL_NUM;

#endif

/// Color temperture
typedef struct
{
#if ENABLE_PRECISE_RGBBRIGHTNESS
    U16 cRedOffset;   ///< red offset
    U16 cGreenOffset; ///< green offset
    U16 cBlueOffset;  ///< blue offset
#else
    U8 cRedOffset;   ///< red offset
    U8 cGreenOffset; ///< green offset
    U8 cBlueOffset;  ///< blue offset
#endif
    U8 cRedColor;   ///< red color
    U8 cGreenColor; ///< green color
    U8 cBlueColor;  ///< blue color

    U8 cRedScaleValue;   ///< scale 100 value of red color
    U8 cGreenScaleValue; ///< scale 100 value of green color
    U8 cBlueScaleValue;  ///< scale 100 value of blue color
} T_MS_COLOR_TEMP;

typedef struct
{
    U16 wVideoDataCS;// check sum <<checksum should be put at top of the struct, do not move it to other place>>

    EN_MS_PICTURE ePicture;
    T_MS_PICTURE astPicture[PICTURE_NUMS];    //24Byte
#if (ENABLE_CUS_NR_MODE_FOLLOW_PICMODE == DISABLE)
    T_MS_NR_MODE eNRMode;
#endif
    EN_MS_BLACK_LEVEL bBlackLevel;

    EN_MENU_AspectRatio eAspectRatio;
} T_MS_VIDEO;

typedef struct
{
    U16 wWhiteBalanceDataCS;// check sum <<checksum should be put at top of the struct, do not move it to other place>>

    T_MS_COLOR_TEMP astColorTemp[MS_COLOR_TEMP_COUNT];    //24Byte
} T_MS_WHITEBALANCE;


//////////////////////////////////////////////////////////////////////////////////////////
//  Network Menu Setting Structure Type
//////////////////////////////////////////////////////////////////////////////////////////
typedef struct
{
    U8 u8Network_Flag;

    U8 u8Net_Addr_Class_A;//Dec value
    U8 u8Net_Addr_Class_B;//Dec value
    U8 u8Net_Addr_Class_C;//Dec value
    U8 u8Net_Addr_Class_D;//Dec value

}MS_NET_ADDRESS;

typedef struct
{
    U8 u8Network_SetFlag;  //0:Not Used;1:Used

    U8 u8MANUFACTURE_ID_1;//Hex value
    U8 u8MANUFACTURE_ID_2;//Hex value
    U8 u8MANUFACTURE_ID_3;//Hex value
    U8 u8NETWORK_CARD_ID_1;//Hex value
    U8 u8NETWORK_CARD_ID_2;//Hex value
    U8 u8NETWORK_CARD_ID_3;//Hex value
} MS_MAC_ADDRESS;

#define NUM_OF_ID_PASSWORD_CHAR (16)
typedef struct
{
    U8 u8ID[NUM_OF_ID_PASSWORD_CHAR];
    U8 u8Password[NUM_OF_ID_PASSWORD_CHAR];
} MS_ID_PASSWORD;

typedef enum
{
    EN_NET_CLOSE,
    EN_NET_DHCP,
    EN_NET_STATIC
}EN_NET_CONFIG_MODE;

typedef struct
{
    #ifdef NETWORK_CONFIG_CHINA
    BOOLEAN bNet_Config_mode;
    #else
    EN_NET_CONFIG_MODE Net_Config_mode;         // 0: auto, 1: Manual
    #endif
    BOOLEAN bProxyMode;         // 0: off Proxy, 1: using Proxy
    MS_NET_ADDRESS g_NetIP;
    MS_NET_ADDRESS g_NetNetmask;
    MS_NET_ADDRESS g_NetGateway;
    MS_NET_ADDRESS g_NetDNS;
    MS_MAC_ADDRESS g_NetMacAddress;

    MS_ID_PASSWORD g_Wifi_ID_PSW;
    MS_ID_PASSWORD g_ADLS_ID_PSW;

    U8 stuff;
    U16 stuff2;
}MS_NETWORK;
//////////////////////////////////////////////////////////////////////////////////////////
//  Scan Menu Setting Structure Type
//////////////////////////////////////////////////////////////////////////////////////////

#if ENABLE_T_C_COMBO
typedef struct
{
    WORD ScanSettingCS;
    U8 u8RFChannelNumber;
    U8 u8PreRFChannelNumber;
    U8 u8ChType : 1;
    U8 u8Antenna : 1;         //0=ANT_CATV, 1=ANT_AIR
    U8 u8ScanType : 2;
    U8 u8LSystem:1;
    U8 u8ATVManScanType:1;
    U8 u8ATVManScanDir:1;
    U8 u8DVBCTvConnectionType:1;//0=DVB-T,1=DVB-C
                                //0=DTMB, 1=DVB-C for DVB-C plus DTMB system.
    U8 u8ATVMediumType : 2;
    U8 u8SoundSystem :2;
    U8 u8BandWidth :2;
    U8 Reserved: 2;
} MS_SCANMENU_SETTING;
#elif DVB_T_C_DIFF_DB
typedef struct
{
    WORD ScanSettingCS;
    U8 u8RFChannelNumber;
    U8 u8PreRFChannelNumber;
    U8 u8ChType : 1;
    U8 u8Antenna : 1;         //0=ANT_CATV, 1=ANT_AIR
    U8 u8ScanType : 1;
    U8 u8LSystem:1;
    U8 u8ATVManScanType:1;
    U8 u8ATVManScanDir:1;
    U8 u8ATVMediumType : 2;
    U8 u8SoundSystem :3;
    U8 u8DVBCTvConnectionType:1;
    U8 u8BandWidth :2;
    U8 Reserved: 2;
} MS_SCANMENU_SETTING;
#else
typedef struct
{
    U16 ScanSettingCS;// check sum <<checksum should be put at top of the struct, do not move it to other place>>

    U8 u8RFChannelNumber;
    U8 u8PreRFChannelNumber;
    U8 u8ChType : 1;
    U8 u8Antenna : 1;         //0=ANT_CATV, 1=ANT_AIR
    U8 u8ScanType : 2;       //0=SCAN_TYPE_AUTO,1=SCAN_TYPE_MANUAL,2=SCAN_TYPE_NETWORK
    U8 u8LSystem:1;
    U8 u8ATVManScanType:1;
    U8 u8ATVMediumType : 2;
    U8 u8ATVManScanDir:1;
    U8 u8SoundSystem :3;
    U8 u8BandWidth :2;
    U8 u8VideoSystem_Brazil: 3;
 } MS_SCANMENU_SETTING;
#endif

#ifdef ENABLE_BT
/// Specify the torrent setup information.
typedef struct
{
    U16 TorrentSetupInfoCS;// check sum <<checksum should be put at top of the struct, do not move it to other place>>

    U8 u8MaxSession;
    U8 u8ServerName[50];                   /// Http://www.mstarsemi.com

    U16 u16port;                              /// TCP port
    U16 u16DownloadLimit;             /// download speed limit,  unit KB/s
    U16 u16UploadLimit;                  /// upload speed limit,  unit KB/s
} MS_TorrentSetupInfo;
#endif


typedef enum
{
    EN_INPUT_LABEL_None,
    EN_INPUT_LABEL_VCR,
    EN_INPUT_LABEL_DVD,
    EN_INPUT_LABEL_PC,
    EN_INPUT_LABEL_GAME,
    EN_INPUT_LABEL_SET_TOP_BOX,
    EN_INPUT_LABEL_Satellite,
    EN_INPUT_LABEL_Num,
} EN_MENU_INPUT_LABEL_NAME;

//////////////////////////////////////////////////////////////////////////////////////////
//  System Setting Structure Type
//////////////////////////////////////////////////////////////////////////////////////////
typedef struct
{
    U16 SystemSettingCS;// check sum <<checksum should be put at top of the struct, do not move it to other place>>

    E_UI_INPUT_SOURCE enUiInputSourceType;   // input source selection
    E_UI_INPUT_SOURCE enUiPrevInputSourceType;   // Previous input source selection
    EN_LANGUAGE Language; // OSD language

	 #if ENABLE_TTX // helen add for TTX
	 TT_Charset_Group TTX_Language;
	 #endif
    EN_LANGUAGE  SubtitleDefaultLanguage;
    EN_LANGUAGE  SubtitleDefaultLanguage_2;
    EN_LANGUAGE  Last_Select_HotKey_SubtitleLanguage;
#if 0
    EN_MENU_INPUT_LABEL_NAME enInputSourceName_AV1;
    EN_MENU_INPUT_LABEL_NAME enInputSourceName_AV2;
#endif
    EN_MENU_INPUT_LABEL_NAME enInputSourceName_SCART;
    EN_MENU_INPUT_LABEL_NAME enInputSourceName_Component;
    EN_MENU_INPUT_LABEL_NAME enInputSourceName_RGB;
    EN_MENU_INPUT_LABEL_NAME enInputSourceName_HDMI;

#if (ENABLE_CEC)
    EN_MENU_E4_HMDICEC      g_enHDMICEC;
    BOOLEAN                 g_bHdmiCecDeviceAutoStandby:1;
#endif

    EN_MENU_E5_KeyLock      g_enKeyLock;
#ifdef ENABLE_BUTTON_LOCK
    EN_MENU_E5_KeyLock      g_enKeyPadLock;
#endif
    U8 NextNewRamIndex;        // User new mode RAM index

    U8 f5VAntennaPower:1;           // 0=Off, 1= On
    U8 fSoftwareUpdate:1;           // 0=Off, 1= On
    U8 fAutoVolume:1;               // 0=Off, 1= On
    U8 fHardOfHearing:1;            // 0=Off, 1= On
    U8 fBackgroundDownload:1;       // 0=Off, 1= On
    U8 fEnableSubTitle:1;           // 0=Off, 1= On
    U8 fEnableTTXSubTitle:1;        // 0=Off, 1= On
    U8 Reserved1 :1;
#ifdef OPTION_RSS
    U8 fRSS;                      // 0=Off, 1= On
#endif
#ifdef OPTION_EXTENSION
    U8 fEXTENSION;                // 0=Off, 1= On
#endif
    U8 fEnableOsdAnimation:2;       // 0=Off, 1= On
    U8 fDCR:1;                      // 0 = Off, 1 = On
    U8 fSCARTInputSel : 1;          // 0=EN_SCART_SEL_AV, 1= EN_SCART_SEL_SV
#if ENABLE_CUS_SPDIF_MODE
    U8 fSPDIFMODE:2;                // 0=PCM, 1= AUTO,2,3 =MUTE
#else
    U8 fSPDIFMODE:1;                // 0=PCM, 1= AUTO
#endif
    U8 fCOLORRANGE:1;               // 0=16~235, 1=0~255
    U8 fSUBLANG_FLAG:1;             // 0=Primary, 1=Secondary
#if (ENABLE_CUS_SPDIF_MODE == DISABLE)
    U8 Reserved2 : 1;
#endif
    U8 fDynamicContrast;          // 0=Off, 1= On
    U8 fDynamicBacklight;         // 0=Off, 1= On
    U8 fFilmMode;                 // 0=Off, 1= On
    MS_NETWORK g_Network;         // network configuration selection
    U8 u8Backlight;
    U8 bPanelVcom;	
   // U16 gId693Cnt;
    U16 gId693FailCnt;	
    EN_OSD_TRAN OsdBlending;
    EN_OSD_TIME OsdDuration;
	//CUS_XM:xue add for check backlight opertatio,ADC infor 2012-7-7
	BOOLEAN bisreaptbacklight: TRUE;
	BOOLEAN bisadccheck;
#if (ENABLE_SBTVD_BRAZIL_APP && BRAZIL_CC)
    EN_ATV_CAPTION_TYPE    enATVCaptionType;
    EN_DTV_CAPTION_TYPE    enDTVCaptionType;
#endif

#if  (ATSC_CC == ATV_CC)
    EN_ATV_CAPTION_TYPE    enATVCaptionType;
#endif

//    U16 u16OverflowLCN;
#if ENABLE_CUS_3D_SOURCE_MEMORY
    #if ENABLE_3D_PROCESS
    EN_3D_DETECT_MODE   en3DDetectMode;
    #endif
#else
    #if ENABLE_3D_PROCESS
    EN_3D_TYPE    en3DType;
    EN_3D_DETECT_MODE   en3DDetectMode;
    EN_3D_LR_MODE   en3DLRMode;
    #if ENABLE_CUS_3D_SETTING
    U8 u83DScene;
    #endif
    #endif
#endif

#if ENABLE_UI_3D_PROCESS
    E_UI_3D_UI_MODE    en3DUIMODE;
#endif

#if (ENABLE_SW_CH_FREEZE_SCREEN)
    U8 u8SwitchMode;
#endif
#if ENABLE_SZ_BLUESCREEN_FUNCTION
    BOOLEAN bIsBluescreenOn;
#endif
#if ENABLE_CUS_HDMI_MODE
    BOOLEAN bIsHDMIVideoMode;
#endif

#if (ENABLE_DMP || BLOADER)
    U8 UsrLogo:2;  //    2:User logo 1:default logo 0:off
    U8 u8UsrLogoCnt:3;  // total number of user logo
    U8 u8UsrLogoIdx:3;  //  current user logo
    U8 UsrPowerOnMusic:2;  //   2:User poweron music 1:default poweron music 0:off
#endif
#if ENABLE_CUS_USB_OSD
	U8 ThumnailSize:2;  // 0,midle;1,small;2,big
	U8 SortType:1;  // 0,name;1,date;
	U8 ShufflePhoto:1;  // 0,off;1,on;
	U8 ShuffleMusic:1;  // 0,off;1,on;
	U8 ShuffleMovie:1;  // 0,off;1,on;
	U8 ShuffleText:1;  // 0,off;1,on;

	U8 Duration:2;  // 0,short;1,middle;2,long;
	U8 Effect:4;  //

	U8 LyricShow:1;  //
	U8 LyricId:2;  //
	U8 PhotoRepeat:2;  //0,none;1,one;2,all;
	U8 MusicRepeat:2;  //
	U8 MovieRepeat:2;  //
	U8 TextRepeat:2;  //

	U8 ShowEQ:1;  //

#endif

#ifdef ENABLE_CUS_FACTORY_ATV_CH_PRSET
	U8 uFactoryChannelFlag:1;
#endif

#if BOE_UART_FAC_COMMAND//minglin0118
U8 uUartPortConect;
#endif


#if    ENABLE_OFFLINE_SIGNAL_DETECTION
    AISEnumType bAIS;
#endif
    PANEL_RESOLUTION_TYPE enPanelResType;
    //U8 u8PanelModel;
#if ENABLE_PVR
    U32 u32PVR_RecordMaxTime;      //second, the max record time of free record
    U8 u8PVR_IsRecordAllChannel;   //0:off  1:record all channel
#endif
#ifdef ENABLE_CUS_AV_COLOR_SYSTEM
    EN_ATV_COLOR_SYSTEM enAVColorSystem;
#endif
#if ENABLE_SZ_FACTORY_LVDS_MODE_FUNCTION                //smc.chy 2010/03/25
    U8 uLvdsTiMode;
    APIPNL_TIBITMODE uLvdsDepth;
    U8 uLvdsPortSwap;
    U8 uLvdsPolSwap;
#endif

#if (GENSETTING_STORE_USE_NEW_METHOD)
    U8  u8ATVProgramNumber;
  #if (ENABLE_DTV)
    U16 u16DTVRFChannelOrder;
    U16 u16DATARFChannelOrder;
    U16 u16RADIORFChannelOrder;
    MEMBER_SERVICETYPE eCurrentServiceType;
  #endif
#endif
} MS_USER_SYSTEM_SETTING;

#if BOE_FACTORY_CHANNEL
	U8 uFactoryChannelFlag:1;
    U8 uFactoryChannelFlag2:1;
#endif


///// V-Chip /////////////////////////////////////////////////////////////////////////////
typedef struct
{
    U16 Start_X;
    U16 Start_Y;
    U8 Blocking_Status;
} MS_TVPG_RATING_ITEM;


#define VCHIP_TVRATING_ALL    BIT5
#define VCHIP_TVRATING_FV     BIT4
#define VCHIP_TVRATING_V      BIT3
#define VCHIP_TVRATING_S      BIT2
#define VCHIP_TVRATING_L      BIT1
#define VCHIP_TVRATING_D      BIT0
#define VCHIP_TVRATING_VSL    0x0E
#define VCHIP_TVRATING_VSLD   0x0F

#define INPUT_BLOCK_PROGRAM    BIT0
#define INPUT_BLOCK_TV         BIT1
#define INPUT_BLOCK_AV1        BIT2
#define INPUT_BLOCK_AV2        BIT3
#define INPUT_BLOCK_YPBPR1     BIT4
#define INPUT_BLOCK_YPBPR2     BIT5
#define INPUT_BLOCK_PC         BIT6
#define INPUT_BLOCK_USB        BIT7
#define INPUT_BLOCK_HDMI1      BIT8
#define INPUT_BLOCK_HDMI2      BIT9
#define INPUT_BLOCK_HDMI3      BIT10
#define INPUT_BLOCK_HDMI4      BIT11

#define SCRAMBLE_AUDIO        BIT0
#define SCRAMBLE_VIDEO        BIT1

typedef struct
{
    U8 Item_TV_Y;
    U8 Item_TV_Y7;
    U8 Item_TV_G;
    U8 Item_TV_PG;
    U8 Item_TV_14;
    U8 Item_TV_MA;
} MS_VCHIP_TV_ITEM;

typedef struct
{
    U16 vchipSettingCS;// check sum <<checksum should be put at top of the struct, do not move it to other place>>
    #if ( ENABLE_ATV_VCHIP)
    U8 u8VChipLockMode:4;
    MS_VCHIP_TV_ITEM stVChipTVItem;
    U8 u8VChipMPAAItem;
    U8 u8VChipCEItem;
    U8 u8VChipCFItem;
    #endif
    U16 u16VChipPassword;
    U16 u8InputBlockItem;
} MS_VCHIP_SETTING;

typedef struct
{
    U8 u8EIA608Data1;
    U8 u8EIA608Data2;
    U8 RatingType;
    U8 RatingLevel;
    U8 TV_FVSLD;
    U8 MPAALevel:4;
    U8 CanEngLevel:4;
    U8 CanFreLevel:4;
#if defined(ENABLE_PARSE_SAME_DIMENSION_IN_RRT5_CAD) && ENABLE_PARSE_SAME_DIMENSION_IN_RRT5_CAD
    U16 u8DimVal0;
    U16 u8DimVal1;
    U16 u8DimVal2;
    U16 u8DimVal3;
    U16 u8DimVal4;
    U16 u8DimVal5;
    U16 u8DimVal6;
    U16 u8DimVal7;
    U16 u8DimVal8;
    U16 u8DimVal9;
#else
    U8 u8DimVal0:4;
    U8 u8DimVal1:4;
    U8 u8DimVal2:4;
    U8 u8DimVal3:4;
    U8 u8DimVal4:4;
    U8 u8DimVal5:4;
    U8 u8DimVal6:4;
    U8 u8DimVal7:4;
    U8 u8DimVal8:4;
    U8 u8DimVal9:4;
#endif
} MS_VCHIP_RATING_INFO;


#ifdef ENABLE_DMP
typedef enum
{
    POWERON_LOGO_OFF,
    POWERON_LOGO_DEFAULT,
    POWERON_LOGO_USER,
    POWERON_LOGO_NUMS,
}LogoEnumType;
typedef enum
{
    POWERON_MUSIC_OFF,
    POWERON_MUSIC_DEFAULT,
    POWERON_MUSIC_USER,
    POWERON_MUSIC_NUMS,
}PowerOnMusicEnumType;
#endif
//#define SET_VCOM_VAULE(x)     Panel_VCOM_PWM_SET(x)//MAPP_SET_PANEL_VOCM_VAULE(x)

#define MENU_TIMEZONE                       stGenSetting.g_Time.enTimeZone
#define GET_OSD_MENU_LANGUAGE()             (MApp_GetMenuLanguage())
#define GET_OSD_MENU_LANGUAGE_DTG()         (MApp_GetMenuLanguage_DTG())
#define GET_TIMEZONE_MENU_LANGUAGE_DTG()    (MApp_GetTimeZone_DTG())
#define GET_AUDIO_MENU_LANGUAGE_DTG()       (MApp_GetAudioLangMenuLanguage_DTG())
#define GET_SUB_MENU_LANGUAGE_DTG()         (MApp_GetSubLangMenuLanguage_DTG())
#define GET_TUNING_MENU_COUNTRY_DTG()       (MApp_GetTuningCountry_DTG())
#define SET_OSD_MENU_LANGUAGE(x)            (MApp_SetMenuLanguage(x))
#define SET_TIME_MENU_ZONE(x)               (MApp_SetTimeZone(x))
#define SET_AUDIO_MENU_LANGUAGE(x)          (MApp_SetAudioLangMenuLanguage(x))
#define SET_SUB_MENU_LANGUAGE(x)            (MApp_SetSubLangMenuLanguage(x))
#define SET_TUNING_MENU_COUNTRY(x)          (MApp_SetTuningMenuCountry(x))
#if ENABLE_TTX // helen add for TTX

#define GET_TTX_LANGUAGE()             (MApp_GetTTXLang())
#define SET_TTX_LANGUAGE(x)             (MApp_SetTTXLang(x))
#endif
#define CMP_OSD_MENU_LANGUAGE(x)            (MApp_CmpMenuLanguage(x))
#define SUBTITLE_DEFAULT_LANGUAGE_1         (stGenSetting.g_SysSetting.SubtitleDefaultLanguage) //current menu language
#define SUBTITLE_DEFAULT_LANGUAGE_2         (stGenSetting.g_SysSetting.SubtitleDefaultLanguage_2) //current menu language
#define LAST_SECLECT_AUDIO_LANGUAGE         (EN_LANGUAGE)(stGenSetting.g_SoundSetting.enSoundAudioLan1) //current menu language
#define LAST_SECLECT_LANGUAGE               (stGenSetting.g_SysSetting.Last_Select_HotKey_SubtitleLanguage)


#define UI_INPUT_SOURCE_TYPE                (stGenSetting.g_SysSetting.enUiInputSourceType)
#define UI_PREV_INPUT_SOURCE_TYPE           (stGenSetting.g_SysSetting.enUiPrevInputSourceType)
#if (ENABLE_PIP)
#define UI_SUB_INPUT_SOURCE_TYPE            (stGenSetting.g_stPipSetting.enSubInputSourceType)
#define UI_IS_AUDIO_SOURCE_IN(WIN)          ( ((stGenSetting.g_stPipSetting.enPipSoundSrc==EN_PIP_SOUND_SRC_MAIN)&&(WIN==MAIN_WINDOW)) || \
                                            ((stGenSetting.g_stPipSetting.enPipSoundSrc==EN_PIP_SOUND_SRC_SUB)&&(WIN==SUB_WINDOW)) )
#endif
#define DATA_INPUT_SOURCE_TYPE(WIN)         g_enDataInputSourceType[WIN]  // 0 --> Main_Window ; 1 --> Sub Window
//#define SERVICE_TYPE                        (stChDataBaseSetting.fLastWatchedSrvType)

#define ST_VIDEO                            stGenSettingExt.g_astVideo[DATA_INPUT_SOURCE_TYPE(MAIN_WINDOW)]
#define ST_WHITEBALANCE                     stGenSettingExt.g_astWhiteBalance[DATA_INPUT_SOURCE_TYPE(MAIN_WINDOW)]
#define ST_PICTURE                          ST_VIDEO.astPicture[ST_VIDEO.ePicture]

#define ST_COLOR_TEMP                       ST_WHITEBALANCE.astColorTemp[ST_PICTURE.eColorTemp]
#define ST_SUBCOLOR                         stGenSettingExt.g_astSubColor[DATA_INPUT_SOURCE_TYPE(MAIN_WINDOW)]

//////////////////////////////////////////////////////////////////////////////////////////
//  Channel Setting Structure Type
//////////////////////////////////////////////////////////////////////////////////////////
typedef struct
{
    U8            tl_numLogs;     /* 0x00: Number of time logs            */
    U8            tl_physChan;    /* 0x01: Physical Channel Number        */
    U8            tl_bPChMove;    /* 0x02: Flag whether Physical change   */
    U8            tl_index[16];   /* 0x04: Stage of channel change        */
    U32           tl_time[16];    /* 0x44: Time stamp of channel change   */
} MS_TIME_LOG_T;


//for test
typedef struct
{
    U8 u8Maker:2;                                   //Tool option 1: Maker:LPL,AUO,CMO,WCG
    U8 u8Tool_Option_1_S_VIDEO_VALUE:1;             //u8Tool_Option_1_S_VIDEO: 0/1
    U8 u8Tool_Option_1_SIDE_AV_VALUE:1;             //u8Tool_Option_1_SIDE_AV_VALUE: 0/1
    U8 u8Tool_Option_1_WOOFER_VALUE:1;              //u8Tool_Option_1_WOOFER_VALUE: 0/1
    U8 u8Tool_Option_1_BOOST_VALUE:1;               //u8Tool_Option_1_BOOST_VALUE: 0/1
    U8 u8Tool_Option_1_B_DEF_VALUE:1;               //u8Tool_Option_1_B_DEF_VALUE: 0/1
    U8 u8Tool_Option_2_TUNER_NUM_VALUE:1;           //u8Tool_Option_2_TUNER_NUM_VALUE: 0/1

    U8 u8Tool_Option_2_EYE_VALUE:1;                 //u8Tool_Option_2_EYE_VALUE: 0/1
    U8 u8Tool_Option_2_INDEX_VALUE:1;               //u8Tool_Option_2_INDEX_VALUE: 0/1
    U8 u8Tool_Option_2_SOFT_TOUCH_VALUE:1;          //u8Tool_Option_2_SOFT_TOUCH_VALUE: 0/1
    U8 u8Tool_Option_2_VFD_VALUE:1;                 //u8Tool_Option_2_VFD_VALUE: 0/1
    U8 u8Tool_Option_2_FULL_VALUE:1;                //u8Tool_Option_2_FULL_VALUE: 0/1
    U8 u8Tool_Option_2_HDMI_TYPE_VALUE:2;           //u8Tool_Option_2_HDMI_TYPE_VALUE:  0 / 1-HDMI / 2-HDMI

    U8 u8Tool_Option_2_FAN_VALUE:1;                 //u8Tool_Option_2_FAN_VALUE: 0/1
    U8 u8Tool_Option_2_S_PDIF_VALUE:1;              //u8Tool_Option_2_S_PDIF_VALUE: 0/1
    U8 u8Tool_Option_2_DIGITAL_AMP_VALUE:1;         //u8Tool_Option_2_S_PDIF_VALUE: 0/1

    U8 u8Option_1_200PR_VALUE:1;                    //u8Option_1_200PR_VALUE: 0/1
    U8 u8Option_1_ACMS_VALUE:1;                     //u8Option_1_ACMS_VALUE: 0/1
    U8 u8Option_1_TEXT:2;                           //option 1 TEXT:TELETEXT:AUTO / OFF/ TOP / FLOP
    U8 u8Option_1_CHAU_VALUE:1;                     //u8Option_1_CHAU_VALUE: 0/1
    U8 u8Option_2_SYS_VALUE:1;                      //u8Option_2_SYS_VALUE: BGIDKM / BGIDKL
    U8 u8Option_2_A2ST_VALUE:1;                     //u8Option_2_A2ST_VALUE: 0/1
    U8 u8Option_2_ABSAVE_VALUE:1;                   //u8Option_2_ABSAVE_VALUE: 0/1

    U8 u8Option_2_HDEV_VALUE:1;                     //u8Option_2_HDEV_VALUE: 0/1
    U8 u8Option_2_V_Curve_VALUE:1;                  //u8Option_2_V_Curve_VALUE: 0/1
    U8 u8Option_2_MONO_VALUE:1;                     //u8Option_2_MONO_VALUE: 0/1
    U8 u8Option_3_SCART_VALUE:1;                    //u8Option_3_SCART_VALUE:  2 Scarts / 2 Components
    U8 u8System_Crl_1_SplitZoomKey:1;               //u8System_Crl_1_SplitZoomKey: 0/1
    U8 u8System_Crl_1_Save_Split_Zoom:1;            //u8System_Crl_1_Save_Split_Zoom: 0/1
    U8 u8System_Crl_1_2HourOFF_Opt_VALUE:1;         //u8System_Crl_1_2HourOFF_Opt_VALUE: 0/1
    U8 u8System_Crl_1_OSD_Rotatet_VALUE:1;          //u8System_Crl_1_OSD_Rotatet_VALUE: 0/1

    U8 u8System_Crl_1_FAVORITEKEY_VALUE:1;          //u8System_Crl_1_FAVORITEKEY_VALUE: 0/1
    U8 u8System_Crl_1_ExitKey_VALUE:1;              //u8System_Crl_1_ExitKey_VALUE: 0/1
    U8 u8System_Crl_1_NavigationKey_VALUE:1;        //u8System_Crl_1_ExitKey_VALUE: 0/1
    U8 u8System_Crl_2_SYSTEM_VALUE:2;               //u8System_Crl_2_SYSTEM_VALUE: NTSC / 3-SYS / 4-SYS / 7-SYS
    U8 u8System_Crl_2_RS232_HOST:1;                 //u8System_Crl_2_RS232_HOST: Gprobe / PC

    U8 u8System_Crl_2_OverScan_VALUE:2;             //u8System_Crl_2_OverScan_VALUE:  1% / 5% / 7%
    U8 u8System_Crl_2_Baud_rate:3;                  //u8System_Crl_2_Baud_rate: 9600 / 14400 / 19200 / 38400 / 57600 / 115200
    U8 u8System_Crl_2_DownLoad:1;                   //u8System_Crl_2_DownLoad: MSD2333L / Commercial

    U8 reserved:2;

    U8 u8Tool_Option_1_Value;                       //Tool option_1 0~31
    U8 u8Tool_Option_2_Value;                       //Tool option_2 0~190
    U8 u8Option_1_Value;                            //Option_1 0~31
    U8 u8Option_2_Value;                            //Option_1 0~63
    U8 u8Option_3_Value;                            //Option_1 0~5
    U16 u16Option_4_Value;                          //Option_1 0~1265
    U8 u8Inch;                                      //Tool option 1:20.23,26,32,37,42,47
    U8 u8Tool_Option_1_Tool_Value;                  //Tool option 1: LS2D,LF65,LY95,LB3DS,LC46,LC55,LE35
    U8 u8System_Crl_2_Audio_Delay;                  //u8System_Crl_2_Audio_Delay:  0 ~ 80 (10 step)
    U8 u8BIKLine_Min;                               //u8BIKLine_Min:  10 ~ 30
    U8 u8BIKLine_Max;                               //u8BIKLine_Max:  30 ~ 80
    U8 u8BIKLine_Gap;                               //u8BIKLine_Gap:  0 ~ 30
    U8 u8BIKLine_Full_Time;                         //u8BIKLine_Full_Time:  1 ~ 30
    U8 u8BIKLine_OriginalTime_Time;                 //u8BIKLine_OriginalTime_Time:  1 ~ 30
    U8 u8_Option_4_LANG;                            //u8BIKLine_Option_4_LANG: EU-13 / others EU5 EU-8 EU-North EU-East NON-EU8 Non-EU etc

    U8 u8DTGMode;   // 0=Off, 1= On
} MS_FACTORY_MODE_SETTING;


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#define IS_COUNTRY_SUPPORT_CI(c)        ( (c==OSD_COUNTRY_BELGIUM)       ||  \
                                          (c==OSD_COUNTRY_FINLAND)       ||  \
                                          (c==OSD_COUNTRY_LUXEMBOURG)    ||  \
                                          (c==OSD_COUNTRY_NETHERLANDS)   ||  \
                                          (c==OSD_COUNTRY_SWEDEN)        ||  \
                                          (c==OSD_COUNTRY_UK) )

#define IS_DTG_COUNTRY(c)        ( (c==OSD_COUNTRY_UK)||(c==OSD_COUNTRY_NEWZEALAND) )
#define IS_EPG_DISABLE_COUNTRY(c)       ( (c==OSD_COUNTRY_NEWZEALAND))
#define IS_EBOOK_COUNTRY(c)             ( (c==OSD_COUNTRY_FRANCE)            ||  \
                                          (c==OSD_COUNTRY_NETHERLANDS))

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
typedef struct
{
    U16 vchipSettingCS;// check sum <<checksum should be put at top of the struct, do not move it to other place>>

    U8 u8BlockSysLockMode:1;
    U8 u8UnratedLoack:4;
    U8 u8VideoBlockMode:2;
    U8 u8BlockSysPWSetStatus:1;
    U8 u8ParentalControl:5;
    U8 u8EnterLockPage: 1;
    U8 Reserved:2;
    U16 u16BlockSysPassword;
} MS_BLOCKSYS_SETTING;

//////////////////////////////////////////////////////////////////////////////////////////
//  General Setting structure type
//////////////////////////////////////////////////////////////////////////////////////////
typedef struct
{
    U16 SscSettingCS;// check sum <<checksum should be put at top of the struct, do not move it to other place>>

    BOOLEAN SscMIUEnable;
    BOOLEAN SscLVDSEnale;
    U16 MIUSscSpanKHzx10;
    U16 MIUSscStepPercentagex100;
    U16 LVDSSscSpanKHzx10;
    U16 LVDSSscStepPercentagex100;
} MS_SSC_SETTING;

#if (ENABLE_CI && ENABLE_CI_PLUS)
typedef struct
{
    U16 CIKeyCS;// check sum <<checksum should be put at top of the struct, do not move it to other place>>

    MS_CI_KEY_SETTING stKeySetting[CI_CC_KEY_NUM];
    U8  u8SystemMJDUTC[5];
} MS_CI_SETTING;
#endif
//////////////////////////////////////////////////////////////////////////////////////////
//  Nonlinear Setting structure type
//////////////////////////////////////////////////////////////////////////////////////////
#if (ENABLE_NONLINEAR_CURVE)
typedef enum
{
#if(ENABLE_PICTURE_NONLINEAR_CURVE)
    NONLINEAR_CURVE_CONTRAST,
    NONLINEAR_CURVE_BRIGHTNESS,
    NONLINEAR_CURVE_SATURATION,
    NONLINEAR_CURVE_SHARPNESS,
    NONLINEAR_CURVE_HUE,
#endif

#if(ENABLE_SOUND_NONLINEAR_CURVE)
    NONLINEAR_CURVE_VOLUME,
#endif

} EN_MS_NONLINEAR_CURVE;
#define PICTURE_CURVE_NUMS  5

typedef struct
{
    U8 u8OSD_0;
    U8 u8OSD_25;
    U8 u8OSD_50;
    U8 u8OSD_75;
    U8 u8OSD_100;
} T_MS_USER_NONLINEAR_CURVE, *P_MS_USER_NONLINEAR_CURVE;

#if ENABLE_SOUND_NONLINEAR_CURVE_TEN
#if ENABLE_SOUND_NEW_NONLINEAR
typedef struct
{
    U16 u8OSD_0;
    U16 u8OSD_10;
    U16 u8OSD_20;
    U16 u8OSD_30;
    U16 u8OSD_40;
    U16 u8OSD_50;
    U16 u8OSD_60;
    U16 u8OSD_70;
    U16 u8OSD_85;
    U16 u8OSD_100;
	U8  Prescale;
	U8  u8AVC_Value;
} T_MS_USER_NONLINEAR_CURVE_TEN, *P_MS_USER_NONLINEAR_CURVE_TEN;
#else
typedef struct
{
    U8 u8OSD_0;
    U8 u8OSD_10;
    U8 u8OSD_20;
    U8 u8OSD_30;
    U8 u8OSD_40;
    U8 u8OSD_50;
    U8 u8OSD_60;
    U8 u8OSD_70;
    U8 u8OSD_85;
    U8 u8OSD_100;
} T_MS_USER_NONLINEAR_CURVE_TEN, *P_MS_USER_NONLINEAR_CURVE_TEN;
#endif
#endif

typedef struct
{
    U16 NonLinearCurveSettingCS;// check sum <<checksum should be put at top of the struct, do not move it to other place>>
#if(ENABLE_PICTURE_NONLINEAR_CURVE)
#if ENABLE_DTV
    T_MS_USER_NONLINEAR_CURVE DTVPictureCurve[PICTURE_CURVE_NUMS];
#endif
    T_MS_USER_NONLINEAR_CURVE ATVPictureCurve[PICTURE_CURVE_NUMS];
    T_MS_USER_NONLINEAR_CURVE AVPictureCurve[PICTURE_CURVE_NUMS];
    T_MS_USER_NONLINEAR_CURVE SVPictureCurve[PICTURE_CURVE_NUMS];
    T_MS_USER_NONLINEAR_CURVE YPbPrPictureCurve[PICTURE_CURVE_NUMS];
    T_MS_USER_NONLINEAR_CURVE HDMIPictureCurve[PICTURE_CURVE_NUMS];
    T_MS_USER_NONLINEAR_CURVE PCPictureCurve[PICTURE_CURVE_NUMS];
    T_MS_USER_NONLINEAR_CURVE StoragePictureCurve[PICTURE_CURVE_NUMS];
#if (BOE_VOLUME_CURVE)
	typedef enum
	{
		NONLINEAR_VOLCURVE_VOLUME,
	} EN_MS_NONLINEAR_VOLCURVE;
	typedef struct
	{
		U8 u8OSD_0;
		U8 u8OSD_1;
		U8 u8OSD_10;
		U8 u8OSD_20;
		U8 u8OSD_30;
		U8 u8OSD_40;
		U8 u8OSD_50;
		U8 u8OSD_60;
		U8 u8OSD_70;
		U8 u8OSD_80;
		U8 u8OSD_90;
		U8 u8OSD_100;
#if BOE_AVC_PRECALE_FUC//minglin1105	
		U8 Prescale;
		U8 u8AVC_Value; 
#endif	
	} T_MS_USER_NONLINEAR_VOLCURVE, *P_MS_USER_NONLINEAR_VOLCURVE;
	typedef struct
	{
		U16 NonLinearVOLCurveSettingCS;// check sum <<checksum should be put at top of the struct, do not move it to other place>>
#if ENABLE_DTV
		T_MS_USER_NONLINEAR_VOLCURVE DTVSoundCurve;
#endif
		T_MS_USER_NONLINEAR_VOLCURVE ATVSoundCurve;
		T_MS_USER_NONLINEAR_VOLCURVE AVSoundCurve;
		T_MS_USER_NONLINEAR_VOLCURVE StorageSoundCurve;
		T_MS_USER_NONLINEAR_VOLCURVE YPbPrSoundCurve;
		T_MS_USER_NONLINEAR_VOLCURVE HDMISoundCurve;
		T_MS_USER_NONLINEAR_VOLCURVE VGASoundCurve;
	} MS_NONLINEAR_VOLCURVE_SETTING;
#endif

#endif

#if(!BOE_VOLUME_CURVE)
#if(ENABLE_SOUND_NONLINEAR_CURVE)
#if ENABLE_SOUND_NONLINEAR_CURVE_TEN
#if ENABLE_DTV
    T_MS_USER_NONLINEAR_CURVE_TEN DTVSoundCurve;
#endif
    T_MS_USER_NONLINEAR_CURVE_TEN ATVSoundCurve;
    T_MS_USER_NONLINEAR_CURVE_TEN AVSoundCurve;
    T_MS_USER_NONLINEAR_CURVE_TEN SVSoundCurve;
    T_MS_USER_NONLINEAR_CURVE_TEN YPbPrSoundCurve;
    T_MS_USER_NONLINEAR_CURVE_TEN HDMISoundCurve;
    T_MS_USER_NONLINEAR_CURVE_TEN PCSoundCurve;
    T_MS_USER_NONLINEAR_CURVE_TEN StorageSoundCurve;
	
#else

#if ENABLE_DTV
    T_MS_USER_NONLINEAR_CURVE DTVSoundCurve;
#endif
    T_MS_USER_NONLINEAR_CURVE ATVSoundCurve;
    T_MS_USER_NONLINEAR_CURVE AVSoundCurve;
    T_MS_USER_NONLINEAR_CURVE StorageSoundCurve;
#endif
#endif
#endif
} MS_NONLINEAR_CURVE_SETTING;

#if (BOE_VOLUME_CURVE)
typedef enum
{
    NONLINEAR_VOLCURVE_VOLUME,
} EN_MS_NONLINEAR_VOLCURVE;
typedef struct
{
    U8 u8OSD_0;
    U8 u8OSD_1;
	U8 u8OSD_10;
	U8 u8OSD_20;
	U8 u8OSD_30;
	U8 u8OSD_40;
	U8 u8OSD_50;
	U8 u8OSD_60;
	U8 u8OSD_70;
	U8 u8OSD_80;
	U8 u8OSD_90;
    U8 u8OSD_100;
#if BOE_AVC_PRECALE_FUC//minglin1105	
	U8 Prescale;
	U8 u8AVC_Value;	
#endif	
} T_MS_USER_NONLINEAR_VOLCURVE, *P_MS_USER_NONLINEAR_VOLCURVE;
typedef struct
{
    U16 NonLinearVOLCurveSettingCS;// check sum <<checksum should be put at top of the struct, do not move it to other place>>
#if ENABLE_DTV
    T_MS_USER_NONLINEAR_VOLCURVE DTVSoundCurve;
#endif
    T_MS_USER_NONLINEAR_VOLCURVE ATVSoundCurve;
    T_MS_USER_NONLINEAR_VOLCURVE AVSoundCurve;
    T_MS_USER_NONLINEAR_VOLCURVE StorageSoundCurve;
	T_MS_USER_NONLINEAR_VOLCURVE YPbPrSoundCurve;
	T_MS_USER_NONLINEAR_VOLCURVE HDMISoundCurve;
	T_MS_USER_NONLINEAR_VOLCURVE VGASoundCurve;
} MS_NONLINEAR_VOLCURVE_SETTING;
#endif

#endif

#if (ENABLE_FACTORY_POWER_ON_MODE)
typedef enum
{
    EN_POWER_DC_ON,
    EN_POWER_DC_OFF,
}EN_POWER_DC_ONOFF;
#endif

//////////////////////////////////////////////////////////////////////////////////////////
//add for hotel menu:hotel menu data struct @chuxu
#if CUS_SMC_ENABLE_HOTEL_MODE
	typedef enum
	{
		HotelMenuUsbCloneModeOFF,
		HotelMenuUsbCloneModeTVTOUSB,
		HotelMenuUsbCloneModeUSBTOTV,
	}HOTEL_MENU_USB_CLONE_MODE;
#endif
///////////////////////////////////////////////////////////////

typedef struct _MS_FACTORY_SETTING
{
    U16                 FactorySettignCS;// check sum <<checksum should be put at top of the struct, do not move it to other place>>

#if ENABLE_VD_PACH_IN_CHINA
    //-------VD adjust----
    U8   u8AFEC_D4;
    U8   u8AFEC_D8_Bit3210;
    U8   u8AFEC_D5_Bit2;
    U8   u8AFEC_D7_LOW_BOUND;//Color kill
    U8   u8AFEC_D7_HIGH_BOUND;//Color kill
    U8   u8AFEC_D9_Bit0;
    U16 u16AFEC_A0_A1; //only debug
    U8 u8AFEC_66_Bit76;//only debug
    U8 u8AFEC_6E_Bit7654;//only debug
    U8 u8AFEC_6E_Bit3210;//only debug
    U8 u8AFEC_43;//auto or Fixed AGC
    U8 u8AFEC_44;//AGC gain
    U8 u8AFEC_CB;
    U8 u8AFEC_CF_BIT2;
    U8 u8AFEC_4E_BIT7;
    U8 u8AFEC_4F;
    //-------VIF adjust----
    U8          Vif_TOP;
    U16         Vif_CR_KP_KI;
    U16         Vif_VGA_MAXIMUM;
    U16         Vif_CR_LOCK_THR;
    U16         Vif_CLAMPGAIN_GAIN_OV_NEGATIVE;
    U16        Vif_CR_THR;
    U8          Vif_CHINA_DESCRAMBLER_BOX;
    U8          Vif_AGCREFNEGATIVE;
    BOOLEAN     Vif_CR_KP_KI_ADJUST;
    BOOLEAN     Vif_OVER_MODULATION;
    BOOLEAN     Vif_ASIA_SIGNAL_OPTION;
    BOOLEAN     Vif_SERIOUS_ACIDETECT;
    AUDIO_HIDEV_TYPE             AUDIO_HIDEV; //0:OFF,1:ON BW_L1 /2:BW_L2/3:BW_L1
    U8          AUDIO_NR;
    U16         SCAN_DELAY;// unit ms
    BOOLEAN     COMBPATCH;
    BOOLEAN     NOTSTANDARDPATCH;
#endif
#if ENABLE_CUS_UI_SPEC
    U32     gFactoryTotaltimeback;
    U32     gFactoryTotaltime;
    U32     gFactoryBackLITtimeback;
#endif
#if ENABLE_FACTORY_POWER_ON_MODE
    EN_POWER_DC_ONOFF g_u8DCOnOff;
    POWERON_MODE_TYPE   u8PowerOnMode;

#endif


#if ENABLE_CUS_BURNING_MODE
    BOOLEAN fBuringMode; //0: off 1:on
#endif
  
#if CUS_SMC_ENABLE_HOTEL_MODE//add for hotel menu setting @chuxu
	BOOLEAN HotelMenuHotelModeOperationEnable;
	BOOLEAN HotelMenuOSDDisplayEnable;
	BOOLEAN HotelMenuOSDDisplayEnableBack;
	BOOLEAN HotelMenuLocalKeyLockEnable;
	BOOLEAN HotelMenuRometeControlLockEnable;
	BOOLEAN HotelMenuRometeControlLockEnableBack;
	BOOLEAN HotelMenuAQPQRestoreEnable;
	BOOLEAN HotelMenuSourceKeyLockEnable;
	BOOLEAN HotelMenuUSBCloneUsedFlag; //cus_xm zhihe add for  usb clone 20120820

	BOOLEAN HotelCaptureLogo; //cus_xm zhihe add for  usb clone 20120820
	BOOLEAN	HotelMenuInstallation;
	EN_LANGUAGE HotelMenuLanguage;
	
	E_HOTEL_MODE_INPUT_SOURCE HotelMenuInputSourceChange;
	HOTEL_MENU_USB_CLONE_MODE HotelMenuUSBCloneMode;
	U8     HotelMenuMaxVolumeSetting;
	U8     HotelMenuVolumeDefault;
	U8     HotelMenuChannelDefault;
	//U8	   HotelMenuInstallation;
    U8     HotelMenuVerticalSliderBarSetting;
	U8     HotelMenuMenuKeyPressFlag;
	U8     HotelMenuMenuKeyPressTime;
#endif
	// CUS_XM Xue 20120803: 
	BOOLEAN isPCSelfAdjusted;
	BOOLEAN isTestPattern;
	
 			
} MS_FACTORY_SETTING;

//////////////////////////////////////////
//  PIP/POP Settings
//////////////////////////////////////////
#if (ENABLE_PIP)
struct  st_MS_PIP_SETTING
{
    U16                   PIPSetupInfoCS;// check sum <<checksum should be put at top of the struct, do not move it to other place>>

    EN_PIP_MODE            enPipMode;
    E_UI_INPUT_SOURCE      enSubInputSourceType;
    EN_PIP_SIZE            enPipSize;
    EN_PIP_POSITION        enPipPosition;
    BOOLEAN                bBolderEnable;
    EN_PIP_SOUND_SRC       enPipSoundSrc;
    //==Used in Factory Menu=========================
    U8                     u8BorderWidth; // 1 ~ 10
    BOOLEAN                bPipEnable;
    //===============================================
};

typedef struct st_MS_PIP_SETTING    MS_PIP_SETTING;

#define IsPIPEnable()    ((BOOLEAN)((MApi_XC_GetInfo()->u8MaxWindowNum > 1) && (stGenSetting.g_stPipSetting.enPipMode < EN_PIP_MODE_OFF) && (stGenSetting.g_stPipSetting.bPipEnable)))
#define IsPIPSupported() ((BOOLEAN)((MApi_XC_GetInfo()->u8MaxWindowNum > 1) && (stGenSetting.g_stPipSetting.bPipEnable)))
#define IsPIPDBCheck() ((BOOLEAN)((MApi_XC_GetInfo()->u8MaxWindowNum > 0)))
#endif

//////////////////////////////////////////
//  DRM
//////////////////////////////////////////
#if ENABLE_DRM
#define DIVX_REG_CODE_LEN                   10
#define DIVX_DEACT_CODE_LEN                 8
#define DIVX_KEY_LEN                        48

typedef enum
{
    E_DRM_INIT,
    E_DRM_SAVE,
    E_DRM_LOAD,
    E_DRM_CLEAR_MEMORY,
    E_DRM_CLEAR_MEMORY_DEMO,
}EN_DRM_OP_MODE;

typedef struct
{
    U16 VDplayerDRMInfoCS;// check sum <<checksum should be put at top of the struct, do not move it to other place>>

    U8 u8RegistrationCode[DIVX_REG_CODE_LEN];
    U8 u8DeActivationCode[DIVX_DEACT_CODE_LEN];
    U8 u8DRM_Data[DIVX_KEY_LEN];

    U8 bIsKeyGenerated;
    U8 bIsActivated;
    U8 bIsDeactivated;

    U8 u8Reserved0[3];
} VDplayerDRMInfo;
#endif

//////////////////////////////////////////
//  MM Last Memory Settings
//////////////////////////////////////////
#if (ENABLE_LAST_MEMORY==1)
typedef struct
{
    U32 EntryType;
    U32 FileLength;
    U32 EntryFileLength;
    U32 EntrySeconds;//since 1980/01/01/0/0/0
    U8 EntryID[8];
    U8 EntryID_Ext[8];
    U8 EnvironmentID;
    U8 FileSystemID;
    U8 EntryAttrib;
} LastMemoryFileEntry;

typedef struct
{
U32 u32LastMemorySeekPosL;
U32 u32LastMemorySeekPosH;
U32 u32LastMemorySeekPTS;//ms
    U16 u16LastAudioTrack;
#if ENABLE_SUBTITLE_DMP
    U16 u16LastSubtitleTrack;
    BOOLEAN bSubtitleShow;
#endif
#if 0//ENABLE_DIVX_PLUS
    U8 u8LastTitle;
    U8 u8LastEdition;
    U8 u8LastChapter;
#endif
#if SH_RESUME_AUTOPLAY
    U16 last_media_type;
    U16 last_media_idex;
	U8 file_entry[8];
#endif

} stLastMemoryAttribute;

typedef struct
{
    stLastMemoryAttribute stLastMemAttribute;

#if ENABLE_LAST_MEMORY_EXT_FILEFULLPATH_COMPARE==1
U16 u16DriveID;
U16 fullpath[32*7];//full path name
#else
LastMemoryFileEntry fEntry;
//FileEntry fileEntry;
#endif
//U8 u8LastMemoryEnable;
} stLastMemoryInfo;

typedef struct _MS_MM_LASTMEMORY_SETTING
{
    U16 MmLastMemorySettignCS;// check sum <<checksum should be put at top of the struct, do not move it to other place>>
    
#if SH_RESUME_AUTOPLAY
		stLastMemoryInfo m_LastMemoryInfo[2];//stLastMemoryInfo m_LastMemoryInfo[LAST_MEMORY_FILENUMBER];
		U16 m_LastMemoryOrderTbl[2]; //U16 m_LastMemoryOrderTbl[LAST_MEMORY_FILENUMBER]; // start from 1,2,3.....
#endif
    //stLastMemoryInfo m_LastMemoryInfo[LAST_MEMORY_FILENUMBER];
    //U16 m_LastMemoryOrderTbl[LAST_MEMORY_FILENUMBER]; // start from 1,2,3.....
} MS_MM_LASTMEMORY_SETTING;
#endif

typedef struct
{
    EN_POWER_ON_MODE g_ucACorDCon;  // Power on status

    U16 wPM_WakeUpDevice;  // set PM Wake-up Devices
    U8  g_ucWakeUpDevice;   // check which Device to wake up PM
}POWER_GENSETTING;

#if (ENABLE_3D_PROCESS&&ENABLE_CUS_3D_SOURCE_MEMORY)
typedef struct
{
    EN_3D_TYPE    en3DType;
    //EN_3D_DETECT_MODE   en3DDetectMode;
    EN_3D_LR_MODE   en3DLRMode;
#if ENABLE_CUS_3D_SETTING
    U8 u83DScene;
#endif
}MS_3DTYPE_USERSETTING;
#endif

//////////////////////////////////////////////////////////////////////////////////////////
//  General Setting structure type
//  NOTE: All components need to follow the checksum mechanism
//            all the struct containing checksum must put the checksum the first member of the struct
//////////////////////////////////////////////////////////////////////////////////////////
typedef struct
{
    //////////////////////////////////////////////////////////////////////////////////////////
    // for General Setting version check, must put at top of this structure
    U8 u8VersionCheck;
    //////////////////////////////////////////////////////////////////////////////////////////

    MS_USER_SYSTEM_SETTING g_SysSetting;
  #if (ENABLE_3D_PROCESS&&ENABLE_CUS_3D_SOURCE_MEMORY)
    MS_3DTYPE_USERSETTING g_3DType_UserSetting[DATA_INPUT_SOURCE_NUM];
  #endif
    stUserSoundSettingType g_SoundSetting;

  #if ((BRAZIL_CC)||(ATSC_CC == ATV_CC))
    stCaptionSettingType g_CaptionSetting;
  #endif

    MS_TIME g_Time;
    MS_SCANMENU_SETTING stScanMenuSetting;
    MS_BLOCKSYS_SETTING g_BlockSysSetting;

  #if ENABLE_SSC
    MS_SSC_SETTING g_SSCSetting;
  #endif


  #if (ENABLE_NONLINEAR_CURVE)
    MS_NONLINEAR_CURVE_SETTING g_NonLinearCurveSetting;
   #if (BOE_VOLUME_CURVE)
  	MS_NONLINEAR_VOLCURVE_SETTING g_NonLinearVOLCurveSetting;
    #endif
  #endif

    MS_FACTORY_SETTING g_FactorySetting;
  #ifdef ENABLE_BT
    MS_TorrentSetupInfo TorrentSetupInfo;
  #endif

  #if ENABLE_DRM
    VDplayerDRMInfo g_VDplayerDRMInfo;
  #endif

  #if (ENABLE_PIP)
    MS_PIP_SETTING g_stPipSetting;
  #endif

    U8 g_u8DRMMemory[48];
    //MS_NETWORK g_Network;
    BOOLEAN fRunInstallationGuide;

  #if (ENABLE_UPDATE_MULTIPLEX_VIA_NIT)
    MS_ALL_NETWORKID_INFO g_Network_TS;
  #endif

  #if 1//(ENABLE_ATV_VCHIP)
    MS_VCHIP_SETTING g_VChipSetting;
  #endif

#if ENABLE_CI_PLUS
    MS_CI_SETTING g_CIKeySetting;
#endif

#if (ENABLE_FACTORY_POWER_ON_MODE)
    EN_POWER_DC_ONOFF g_u8DCOnOff;
#endif

#if (ENABLE_LAST_MEMORY==1)&&(ENABLE_LAST_MEMORY_STORAGE_SAVE==1)
    MS_MM_LASTMEMORY_SETTING g_MmLastMemorySetting;
#endif

#ifdef ENABLE_CUS_DBC
    U8 g_ucDCRMaxBacklight;
#endif
    //////////////////////////////////////////////////////////////////////////////////////////
    // for General Setting version check, must put at button of this structure
    U8 u8VersionCheckCom;
    //////////////////////////////////////////////////////////////////////////////////////////
} MS_GENSETTING;

typedef struct
{
    MS_ADC_SETTING g_AdcSetting[ADC_SET_NUMS];
    T_MS_VIDEO g_astVideo[DATA_INPUT_SOURCE_NUM];
    T_MS_WHITEBALANCE g_astWhiteBalance[DATA_INPUT_SOURCE_NUM];
    T_MS_SUB_COLOR g_astSubColor[DATA_INPUT_SOURCE_NUM];
    #ifdef ENABLE_CUS_SERIAL_NUMBER
    T_MS_SERIAL_NUM g_astSerialNumber;
    #endif
}MS_GENSETTING_EXT;

#if ENABLE_3D_PROCESS
    #if ENABLE_CUS_3D_SOURCE_MEMORY
    #define ST_3D_TYPE      stGenSetting.g_3DType_UserSetting[DATA_INPUT_SOURCE_TYPE(MAIN_WINDOW)].en3DType
    #define ST_3D_LRMODE    stGenSetting.g_3DType_UserSetting[DATA_INPUT_SOURCE_TYPE(MAIN_WINDOW)].en3DLRMode
    #define ST_VGA_3D_TYPE      stGenSetting.g_3DType_UserSetting[DATA_INPUT_SOURCE_RGB].en3DType
    #define ST_VGA_3D_LRMODE    stGenSetting.g_3DType_UserSetting[DATA_INPUT_SOURCE_RGB].en3DLRMode
    #if ENABLE_CUS_3D_SETTING
    #define ST_3D_3DScene   stGenSetting.g_3DType_UserSetting[DATA_INPUT_SOURCE_TYPE(MAIN_WINDOW)].u83DScene
    #define ST_VGA_3DScene   stGenSetting.g_3DType_UserSetting[DATA_INPUT_SOURCE_RGB].u83DScene
    #endif
    #else
    #define ST_3D_TYPE      stGenSetting.g_SysSetting.en3DType
    #define ST_3D_LRMODE    stGenSetting.g_SysSetting.en3DLRMode
    #define ST_VGA_3D_TYPE      stGenSetting.g_SysSetting.en3DType
    #define ST_VGA_LRMODE    stGenSetting.g_SysSetting.en3DLRMode
    #if ENABLE_CUS_3D_SETTING
    #define ST_3D_3DScene   stGenSetting.g_SysSetting.u83DScene
    #define ST_VGA_3DScene   stGenSetting.g_SysSetting.u83DScene
    #endif
    #endif
#endif


#ifdef MAPP_DATABASE_C
#define INTERFACE
#else
#define INTERFACE extern
#endif

#if ENABLE_SZ_FACTORY_OVER_SCAN_FUNCTION

typedef struct
{
    WORD Checksum;
    S8 osOffsetX;       // offset: from start x of the window
    S8 osOffsetY;       // offset: from start y of the window
    S8 osOffsetWidth;   // offset: from width of the window
    S8 osOffsetHeight;  // offset: from height of the window
} MS_OVERSCAN_SETTING;

INTERFACE MS_OVERSCAN_SETTING g_OverScan;
#define G_OVERSCAN_HPOSITION    g_OverScan.OverScanHposition
#define G_OVERSCAN_VPOSITION    g_OverScan.OverScanVposition
#define G_OVERSCAN_HRatio    g_OverScan.OverScanHRatio
#define G_OVERSCAN_VRatio    g_OverScan.OverScanVRatio

typedef enum
{
    EN_FACTORY_OverScan_TVNTSC,
    EN_FACTORY_OverScan_TVPAL,
    EN_FACTORY_OverScan_TVSECAM,
    EN_FACTORY_OverScan_TVNTSC443,
    EN_FACTORY_OverScan_TVPALM,
    EN_FACTORY_OverScan_TVPALN,
    EN_FACTORY_OverScan_AVNTSC,
    EN_FACTORY_OverScan_AVPAL,
    EN_FACTORY_OverScan_AVSECAM,
    EN_FACTORY_OverScan_AVNTSC443,
    EN_FACTORY_OverScan_AVPALM,
    EN_FACTORY_OverScan_AVPALN,
    EN_FACTORY_OverScan_SVNTSC,
    EN_FACTORY_OverScan_SVPAL,
    EN_FACTORY_OverScan_SVSECAM,
    EN_FACTORY_OverScan_SVNTSC443,
    EN_FACTORY_OverScan_SVPALM,
    EN_FACTORY_OverScan_SVPALN,
    EN_FACTORY_OverScan_SCARTRGB_NTSC,
    EN_FACTORY_OverScan_SCARTRGB_PAL,
    EN_FACTORY_OverScan_SCARTRGB_SECAM,
    EN_FACTORY_OverScan_SCARTRGB_NTSC443,
    EN_FACTORY_OverScan_SCARTRGB_PALM,
    EN_FACTORY_OverScan_SCARTRGB_PALN,
    EN_FACTORY_OverScan_HDMI480I,
    EN_FACTORY_OverScan_HDMI480P,
    EN_FACTORY_OverScan_HDMI1440_480I,
    EN_FACTORY_OverScan_HDMI1440_480P,
    EN_FACTORY_OverScan_HDMI576I,
    EN_FACTORY_OverScan_HDMI576P,
    EN_FACTORY_OverScan_HDMI1440_576I,
    EN_FACTORY_OverScan_HDMI1440_576P,
    EN_FACTORY_OverScan_HDMI720P,
    EN_FACTORY_OverScan_HDMI1080I,
    EN_FACTORY_OverScan_HDMI1080P,
    EN_FACTORY_OverScan_HDMIDefault,
   // CUS_XM Xue 20120723: add new HDMI timing
   EN_FACTORY_OverScan_HDMI1080P24,
   EN_FACTORY_OverScan_HDMI1080P25,
   EN_FACTORY_OverScan_HDMI1080P30,
	//2012-7-23
    EN_FACTORY_OverScan_YPBPR480I,
    EN_FACTORY_OverScan_YPBPR480P,
    EN_FACTORY_OverScan_YPBPR576I,
    EN_FACTORY_OverScan_YPBPR576P,
    EN_FACTORY_OverScan_YPBPR720P50,
    EN_FACTORY_OverScan_YPBPR720P60,
    EN_FACTORY_OverScan_YPBPR1080I50,
    EN_FACTORY_OverScan_YPBPR1080I60,
#if (SUPPORT_EURO_HDTV)
    EN_FACTORY_OverScan_YPBPR1080I50EURO,
#endif
    EN_FACTORY_OverScan_YPBPR1080P24,
    EN_FACTORY_OverScan_YPBPR1080P25, //tommy.lv
    EN_FACTORY_OverScan_YPBPR1080P30,
    EN_FACTORY_OverScan_YPBPR1080P50,
    EN_FACTORY_OverScan_YPBPR1080P60,
    EN_FACTORY_OverScan_DTV480I,
    EN_FACTORY_OverScan_DTVR480P,
    EN_FACTORY_OverScan_DTV576I,
    EN_FACTORY_OverScan_DTV576P,
    EN_FACTORY_OverScan_DTV720P,
    EN_FACTORY_OverScan_DTV1080I,
    EN_FACTORY_OverScan_DTV1080P,
    EN_FACTORY_OverScan_NUM
}EN_FACTORY_OVERSCAN;
#endif

#if ENABLE_CUS_RS232_FUNC
typedef enum
{
    AFM_GainOffset_Gain_R,
    AFM_GainOffset_Gain_G,
    AFM_GainOffset_Gain_B,
    AFM_GainOffset_Offset_R,
    AFM_GainOffset_Offset_G,
    AFM_GainOffset_Offset_B,
    AFM_GainOffset_NUMS
}E_AFM_GainOffset_INDEX;
#endif
/////////////////////////////////////////////////////////////////////////////////////////
//  Global Variables of CM
/////////////////////////////////////////////////////////////////////////////////////////

INTERFACE POWER_GENSETTING stPowerGenSetting;

INTERFACE MS_GENSETTING stGenSetting;
INTERFACE MS_GENSETTING_EXT stGenSettingExt;

INTERFACE U8 g_u8AudLangSelected;
INTERFACE U8 g_u8AdAudSelected;
INTERFACE EN_CH_TYPE g_enChType;
INTERFACE EN_SCAN_TYPE g_enScanType;
INTERFACE U16 g_u16CurDummyPchIdx;

INTERFACE BOOLEAN fEnableLCN;
INTERFACE E_DATA_INPUT_SOURCE g_enDataInputSourceType[2];


#if(COMB_2D3D_SWITCH_PATCH)  //For FT unstable Htotal channel in Shanghai 20101013
INTERFACE WORD g_Comb1msCounter;
INTERFACE BYTE g_ucComb2DCnt;
INTERFACE BYTE g_ucComb3DCnt;
//_COMMONDEC_ BYTE g_ucComb2DCntData[10];
//_COMMONDEC_ BYTE g_ucComb3DCntData[10];
INTERFACE BYTE g_ucComb3DSpModeEnable;
INTERFACE BYTE g_ucComb3DSpModeCnt;
INTERFACE BYTE g_ucComb3DSpModeDecCnt;
#endif

#if CUS_SMC_ENABLE_HOTEL_MODE//SMC jayden.chen
INTERFACE U8 g_u8HotelVolMax;
#endif

/////////////////////////////////////////////////////////////////////////////////////////

#undef INTERFACE
#endif

