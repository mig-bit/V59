/*
++++++++++++++++++++++++++++++++++???????????????++++++++++++++++++++++++++++++++++++++++++??????????????????????++++++++++++++++++++++++++++++++++++++++=++????
++++++++++++++++++++++++++++++++++IIIIIIIIIIIIII????????????????????????????????????????????IIIIIIIIIIIIIIIII?III??????????????????????????????????????????IIIII
++++++++++++++++++++++++++++++++++IIIIIIIIIIII????????????????????????????????????????????????IIIIIIIIIIIIIII?III??????????????????????????????????????????IIIII
++++++=+IIIIIIIIIII+++++++++++++++?$$$$$$$$$77II??????????I???????????????????????????????????IIIIIIIIIIIIIII?III??????????????????????????????????????????IIIII
+++++++DMMMMMMMMMMMZI++++++++++++=NMMMMMMMMMMMZ$?I77$$$$$$I?????????????????????????????????????IIIIIIIIIIIII?III??????????????????????????????????????????IIIII
++++++=8MMMMMMMMMMMMD7=+++++++++IMMMMMMMMMMMMM8OZZ$7I???????????????????????????????????????????IIIIIIIIIIIII?III??????????????????????????????????????????IIIII
++++++=8MMMMMMMMMMMMM8++++++++++DMMMMMMMMMMMMMD8$I?????????????????III???????????????????????????IIIIIIIIIIII?III??????????????????????????????????????????IIIII
+++=+?=8MMMMMMMMMMMMMMZZ++++++?DMMMMMMMMMMMMMMZZ???????????????IIIIIIIIIII????????????????????????IIIIIIIIIII?III??????????????????????????????????????????IIIII
+++++I=DMMMMMMMMMMMMMMMN?=++++8MMMMMMMMMMMMMMMZ$??????????????IIIIIIIIIIIIII??????????????????????IIIIIIIIIII?III??????????????????????????????????????????IIIII
+++++I+8MMMMMMMMMMMMMMMMD?=+IDMMMMMMMMMMMMMMMM$$?????????????IIIIIIIIIIIIIIII????????????????????IIIIIIIIIIII?III??????????????????????????????????????????IIIII
++++?I+8MMMMMMMMMMMMMMMMMOI~OMMMMMMMMMMMMMMMMM$$?????????????IIIIIIIIIIIIIIIII????????????IIIIIIIIIIIIIIIIIII?III??????????????????????????????????????????IIIII
++++II+8MMMMMMMMMMMNNMMNMND8MMNNMMNNMMMMMMMMMMZ$????????????IZZ8888OZ7IIIIIIIIIIIIIIIIIIIIIIZD7IIIIIIIIIIIIII?IIIIIIIIIII???????????????????????IIIIIIIIIIIIIIII
++++II+8MMMMMMMMMMII????????OOOOOOZ8MMMMMMMMMMZ$??????????ZDMMMMMDDDNND87IIIIIIIIIIIIIII?Z8MMDIIIIIIIIIIIIIII?IIIIIIIIIII???????????????????????IIIIIIIIIIIIIIII
+++III+8MMMMMMMMMMI++++++7$ZZZZZZZOOMMMMMMMMMMZ$??????IINMMMMMMD+IIII7I7DMMIIIIIIII?I8NMMMMMMD?IIIIIIIIIIIIII?IIIIIIIIIII???????????????????????IIIIIIIIIIIIIIII
+++III+8MMMMMMMMMMI+++++I$ZZZZZZZZ$ZMMMMMMMMMMZ$??????IMMMMMMMMMI??????IIO87IIIIII?DMMMMMMMMMD?IIIIIIIIIIIIII?IIIIIIIIIII???????????????????????IIIIIIIIIIIIIIII
++?III+8MMMMMMMMMMI++=$$ZZZZZZZZZIIZMMMMMMMMMMZ$??????MMMMMMMMMMMZ??????????????IIIMMMMMMMMMMD$ZZZZIIIIIIIIII+Z8DDNMMMDDDOO$I?????????????IIIII$ZZZ7IIII7O8887II
+?IIII+8MMMMMMMMMMI++7ZZZZZZZZZZI+IZMMMMMMMMMMZ$????7ZMMMMMMMMMMMM$????????????OMMMMMMMMMMMMMMMMMMNIIIIIIIII8MMMD888DMMMMMMMND$?????????8MMMMMMMMMMOII78MMMMM8?I
+?IIII+8MMMMMMMMMMI?7ZZZZZZZZZZ?++IZMMMMMMMMMMZ$????7ZMMMMMMMMMMMMMM8??????????+++?MMMMMMMMMM8IIIIIIIIIIIZMMM77IIIIIII8MMMMMMMMND?II????8MMMMMMMMMMOODNZII7Z8I7I
?IIIII+8MMMMMMMMMMZZZZZZZZZZZZI+++IZMMMMMMMMMMZ$??????NMMMMMMMMMMMMMMDII??????????IMMMMMMMMMM8IIIIIIIIIIIO8ZI?IIIIIIIIZDMMMMMMMMMD??????8MMMMMMMMMMN8D7IIIIIIIII
?IIIII+8MMMMMMMMMNZZZZZZZZZZZZ++++?ZMMMMMMMMMMZ$??????ZMMMMMMMMMMMMMMMMN7?????????IMMMMMMMMMM8IIIIIIIIIIIIIII?IIIIIIIIZDMMMMMMMMMMI?????8MMMMMMMMMM8IIIIIIIIIIII
?IIIII+8MMMMMMMMN8ZZZZZZZZZZZ?++++?ZMMMMMMMMMMZ$??????I8MMMMMMMMMMMMMMMM8?????????IMMMMMMMMMMO?IIIIIIIIIIIII7I7777777IODMMMMMMMMMMI?????8MMMMMMMMMMOIIIIIIIIIIII
?IIIII+8MMMMMMMNZZZZZZZZZZZZ7+++++?ZMMMMMMMMMMZ$????????8MMMMMMMMMMMMMMMMDD???????IMMMMMMMMMMO??IIIIIIIII7DMMMMMMMDDMDDNMMMMMMMMMMI?????8MMMMMMMMMMOIIIIIIIIIIII
?IIIII+8MMMMMMNZZZZZZZZZZZZ$++++++?ZMMMMMMMMMMZ$I????????7NMMMMMMMMMMMMMMMMDI?????IMMMMMMMMMMO????IIIIIZ8MMMMMMMM7III7ONMMMMMMMMMMI?????8MMMMMMMMMMOIIIIIIIIIIII
?IIIII+8MMMMMMNOZZZZZZZZZZZ7++++++?ZMMMMMMMMMMZ$III??????+IMMMMMMMMMMMMMMMMN$+????IMMMMMMMMMMO????IIII?NMMMMMMMMN?IIIIZDMMMMMMMMMMI?????8MMMMMMMMMMOIIIIIIIIIIII
?IIIII+8MMMMMMMMMNOZZZZZZZZ?++++++?ZMMMMMMMMMMZ$IIII????????ZMMMMMMMMMMMMMMMO?????IMMMMMMMMMMZ?????III$MMMMMMMMMN?IIIIZDMMMMMMMMMMI?????8MMMMMMMMMMOIIIIIIIIIIII
?IIIII+8MMMMMMMMMM?$ZZZZZZ$+++++++?ZMMMMMMMMMMZ$IIIIIIIIII???ZMMMMMMMMMMMMMMDZ????IMMMMMMMMMMZ?????IIIZMMMMMMMMMN?IIIIZDMMMMMMMMMMI?????8MMMMMMMMMMOIIIIIIIIIIII
?IIIII=DMMMMMMMMMM?++7ZZZ7?+++++++IZMMMMMMMMMMZ$IIIIIIIIIIIIII7OMMMMMMMMMMMM8?????IMMMMMMMMMMZ????IIIIZMMMMMMMMMN?IIIIZDMMMMMMMMMMI?????8MMMMMMMMMMOIIIIIIIIIIII
?II?II+8MMMMMMMMMMI++?ZOZ7?+++++++?ZMMMMMMMMMMZ$IIII7OZIIIIIIIII8MMMMMMMMMMMZ?????IMMMMMMMMMM$???OOD7IIMMMMMMMMMN?IIIIZDMMMMMMMMMMI?????8MMMMMMMMMMOIIIIIIIIIIII
?IIIMMMMMMMMMMMMMMNNNN8O$I++++?NMNNMMMMMMMMMMMMMMD8I77NM8IIIIIIIIOMMMMMMMMMO??????+8MMMMMMMMMZ??$MM$?IIZMMMMMMMMM?IIIZNMMMMMMMMMMMZ?????8MMMMMMMMMMOIIIIIIIIIIII
?II?MMMMMMMMMMMMMMMMMM88??++++?MMMMMMMMMMMMMMMMMMD8II7IDMMOIIIIIIOMMMMMMMDOIIII??I??NMMMMMMMMMO8MZ$?IIIIZMMMMMMMMZIZ8MDMMMMMMMMMMMO?????8MMMMMMMMMMOIIIIIIIIIIII
?II?DDDDDDDDDDDDDDD8DDZ$++++++?D8D8DDDDDDDDDDDDDDOZIIIIII?7ODMMMMMMMNDZ7?IIIIIII??????ZDMMMMN8Z7??I?IIIIIIIZ8MMMMN8Z??7$ZZZZZZZZZZZ+????IZZZZZZZZZZ7IIIIIIIIIIII
?IIIII++++++++++++++++=+++++++++++IIIIIIIIIIIIIIIIII???I?????I77ZZ77IIIIIIIIIIIII????I???II??????????IIIIIIII?777IIIIIIII???????????????????????IIIIIIIIIIIIIIII
*/
////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#define MAPP_PLAYBACK_C

//system
#include "Board.h"                  //For pvr select
#include "sysinfo.h"                //For playback buffer

#include "debug.h"

#if ENABLE_PVR

//api
#include "msAPI_Timer.h"            //For timer
#include "msAPI_DTVSystem.h"        //For audio info
#include "msAPI_PVR.h"              //For pvr
#include "msAPI_Player.h"           //For player
#ifdef S3PLUS
#include "drvCi_Api.h"                //For tuner
#endif

//ap
#ifdef PVR_8051
#include "mapp_demux.h"             //For demux
#else
#include "MApp_GlobalVar.h"         //For demux
#endif
#include "mapp_si.h"                //For SI
#include "MApp_Subtitle.h"          //For subtitle
#ifdef S3PLUS
//#include "MApp_MHEG5_Main.h"        //For MHEG5
#endif
#include "MApp_ChannelChange.h"     //For channel change
#include "MApp_Record.h"            //For record-linkage
#include "MApp_Playback.h"          //For itself

#ifdef S3PLUS
#include "MApp_AVSync.h"
#endif

#ifdef PVR_8051
#ifdef SUBTITLE                     //For subtitle define compatibility
#define ENABLE_SUBTITLE             1
#define ENABLE_SBTVD_BRAZIL_APP     0
#else
#define ENABLE_SUBTITLE             0
#define ENABLE_SBTVD_BRAZIL_APP     0
#endif
#endif
#if OBA2
#include <string.h>
#endif
#if ((BRAZIL_CC )|| (ATSC_CC == ATV_CC))
#include "mapp_closedcaption.h"
#endif
/*************************************************************************************************/
#define JUMPDETECTTIMER       30000
#define JUMPSTEPCOUNTER     1000
#define BEGINJUMPTHRELD     100     // IN  1/10 second

#define DEBUG_PLAYBACK_STATE     0

/*************************************************************************************************/
typedef enum
{
    E_PLAYBACK_NEXTACT_NONE,
    E_PLAYBACK_NEXTACT_ENABLE,
    E_PLAYBACK_NEXTACT_RESUME,
    E_PLAYBACK_NEXTACT_FASTFORWARD,
    E_PLAYBACK_NEXTACT_FASTBACKWARD,
    E_PLAYBACK_NEXTACT_JUMPFORWARD,
    E_PLAYBACK_NEXTACT_JUMPBACKWARD,
} enPlaybackActionAfterPause;

/*************************************************************************************************/
static _msAPI_PVR_RecordPath   * _pstPvrRecordPath;                   //one record   path for playback
static _msAPI_PVR_PlaybackPath * _pstPvrPlaybackPath;                 //one playback path for playback

static enPlaybackState    _enPlaybackState      = E_PLAYBACK_STATE_WAIT;    //playback_state
static enPlaySpeed        _enPlaybackSpeed      = E_PLAY_SPEED_1X;          //playback_speed
static enPlaybackInput    _enPlaybackInput      = E_PLAYBACK_INPUT_NONE;    //playback_input from outside
static U32                _u32PlaybackExtPara   = 0;                        //playback_input from outside
static enPvrApiStatus     _enPlaybackStatus     = E_PVR_API_STATUS_OK;      //playback_status

static U32 _u32PlaybackJumpDetectTimer;    // Detect timer
static U32 _u32PlaybackJumpStepTimer;       // adjust timer
static U32 _u32PlaybackJumpCount;             // the timer difference
static U32 _u32PlaybackJumpDirection;        // the timer difference direction

#ifdef MEASURE_FFFB_TIME //=======================$$$//
static U32                _u32FastForwardStartTime;
static U32                _u32FastBackwardStartTime;
#endif //MEASURE_FFFB_TIME =======================$$$//
#define TIME_CALIBRATION_MACRO      1
#define TIME_CALIBRATION_MICRO      2
static void MApp_Playback_StateMachineTimeCalibration(U8 u8CaliMode);

/*************************************************************************************************/
//@@@Do not control demux/file system/audio/scaler/video directly in this layer

/*************************************************************************************************/
///-----------------------------------------------------------------------------------
///Adjust Timer By file position when FF / FB,
///@param none
///@return none
///-----------------------------------------------------------------------------------
static void _MApp_Playback_PlaybackTimeCalibration(void)
{
    U32 u32RightAroundDistance;
    U32 u32LeftAroundDistance;
    U32 u32RightActualDistance;
    U32 u32LeftActualDistance;
    if ((_enPlaybackState != E_PLAYBACK_STATE_FASTFORWARD)
        && (_enPlaybackState != E_PLAYBACK_STATE_FASTBACKWARD))
    {
        _u32PlaybackJumpCount = 0;
        return;
    }
    if (_pstPvrPlaybackPath->u16PlayedAvgRate == 0)
        return;
    if (msAPI_Timer_DiffTimeFromNow(_u32PlaybackJumpStepTimer) > JUMPSTEPCOUNTER)
    {
        _u32PlaybackJumpStepTimer = msAPI_Timer_GetTime0();
        if (_u32PlaybackJumpCount>0)
        {
            if (_u32PlaybackJumpCount > 10)
                _u32PlaybackJumpCount -= 10;
            else
                _u32PlaybackJumpCount = 0;
            if (_u32PlaybackJumpDirection)
            {
                _pstPvrPlaybackPath->s32JumpPeriod += 10;
            }
            else
            {
                _pstPvrPlaybackPath->s32JumpPeriod -= 10;
            }
        }
    }
    if (msAPI_Timer_DiffTimeFromNow(_u32PlaybackJumpDetectTimer) > JUMPDETECTTIMER)
    {
        _u32PlaybackJumpCount = 0;
        _u32PlaybackJumpDetectTimer = msAPI_Timer_GetTime0();
        /*[00]re-sync =====================================================================*/
        _pstPvrPlaybackPath->u32PlayedPeriod  = msAPI_Timer_DiffTimeFromNow(_pstPvrPlaybackPath->u32PlayedTime)/100;  //[$$02$$]sync play period                //#(1)

        /*[01]calculate left/right distance ===============================================*/
        if(MApp_Playback_GetRecordEndTimeSec() > MApp_Playback_GetPlaybackTimeSec())
        {
            u32RightAroundDistance = (MApp_Playback_GetRecordEndTimeSec() - MApp_Playback_GetPlaybackTimeSec()   )*_pstPvrPlaybackPath->u16PlayedAvgRate;
        }
        else
        {
            u32RightAroundDistance = 0;
        }
        if(MApp_Playback_GetPlaybackTimeSec() > MApp_Playback_GetRecordStartTimeSec())
        {
            u32LeftAroundDistance  = (MApp_Playback_GetPlaybackTimeSec()  - MApp_Playback_GetRecordStartTimeSec())*_pstPvrPlaybackPath->u16PlayedAvgRate;
        }
        else
        {
            u32LeftAroundDistance  = 0;
        }

        /*[02-1][START | END]==============================================================*/
        if(_pstPvrPlaybackPath->u32FileValidPosEndKB > _pstPvrPlaybackPath->u32FileValidPosStrKB)
        {
            if(_pstPvrPlaybackPath->u32FileValidPosEndKB > _pstPvrPlaybackPath->u32FilePositionKB)
            {
                u32RightActualDistance = _pstPvrPlaybackPath->u32FileValidPosEndKB-_pstPvrPlaybackPath->u32FilePositionKB;
            }
            else
            {
                u32RightActualDistance = 0;
            }

            if(_pstPvrPlaybackPath->u32FilePositionKB > _pstPvrPlaybackPath->u32FileValidPosStrKB)
            {
                u32LeftActualDistance  = _pstPvrPlaybackPath->u32FilePositionKB   - _pstPvrPlaybackPath->u32FileValidPosStrKB;
            }
            else
            {
                u32LeftActualDistance = 0;
            }
        }

        /*[02-2][END | START]==============================================================*/
        else
        {
            /*[END | START | POS]==========================================================*/
            if(_pstPvrPlaybackPath->u32FilePositionKB > _pstPvrPlaybackPath->u32FileValidPosEndKB)
            {
                u32RightActualDistance = _pstPvrPlaybackPath->u32FileLimitedSizeKB - _pstPvrPlaybackPath->u32FilePositionKB + _pstPvrPlaybackPath->u32FileValidPosEndKB - PVR_MAX_PROGRAMME_PER_FILE * META_DATA_SIZE/1024;

                if(_pstPvrPlaybackPath->u32FilePositionKB > _pstPvrPlaybackPath->u32FileValidPosStrKB)
                {
                    u32LeftActualDistance  = _pstPvrPlaybackPath->u32FilePositionKB   - _pstPvrPlaybackPath->u32FileValidPosStrKB;
                }
                else
                {
                    u32LeftActualDistance = 0;
                }
            }

            /*[POS | END | START]==========================================================*/
            else
            {
                if(_pstPvrPlaybackPath->u32FileValidPosEndKB > _pstPvrPlaybackPath->u32FilePositionKB)
                {
                    u32RightActualDistance = _pstPvrPlaybackPath->u32FileValidPosEndKB-_pstPvrPlaybackPath->u32FilePositionKB;
                }
                else
                {
                    u32RightActualDistance = 0;
                }

                u32LeftActualDistance  = _pstPvrPlaybackPath->u32FilePositionKB - PVR_MAX_PROGRAMME_PER_FILE * META_DATA_SIZE/1024 + _pstPvrPlaybackPath->u32FileLimitedSizeKB - _pstPvrPlaybackPath->u32FileValidPosStrKB;
            }
        }

        /*[03]start calibration ===========================================================*/
        if(u32LeftAroundDistance > u32LeftActualDistance)
        {
            if(u32RightAroundDistance > u32RightActualDistance)
            {
                #if 0   //=================
                printf("###LEFT: %08lu / %08lu /  %08lu( %02lu s) || %08lu / %08lu / -%08lu(-%02lu s) :RIGHT###\n",
                        u32LeftAroundDistance, u32LeftActualDistance, u32LeftAroundDistance - u32LeftActualDistance, (u32LeftAroundDistance - u32LeftActualDistance)/_pstPvrPlaybackPath->u16PlayedAvgRate,
                        u32RightAroundDistance, u32RightActualDistance, u32RightAroundDistance - u32RightActualDistance, (u32RightAroundDistance -u32RightActualDistance)/ _pstPvrPlaybackPath->u16PlayedAvgRate);
                #endif  //=================
            }
            else
            {
                #if 0   //=================
                printf("###LEFT: %08lu / %08lu /  %08lu( %02lu s) || %08lu / %08lu / -%08lu(-%02lu s) :RIGHT###\n",
                        u32LeftAroundDistance, u32LeftActualDistance, u32LeftAroundDistance - u32LeftActualDistance, (u32LeftAroundDistance - u32LeftActualDistance)/_pstPvrPlaybackPath->u16PlayedAvgRate,
                        u32RightAroundDistance, u32RightActualDistance, u32RightActualDistance - u32RightAroundDistance, (u32RightActualDistance - u32RightAroundDistance)/ _pstPvrPlaybackPath->u16PlayedAvgRate);
                #endif  //=================

                if((u32RightActualDistance - u32RightAroundDistance) >= _pstPvrPlaybackPath->u32GapLengthExtKB)
                {
                    _u32PlaybackJumpDirection = 1;
                    _u32PlaybackJumpCount = (u32RightActualDistance - u32RightAroundDistance)*10/_pstPvrPlaybackPath->u16PlayedAvgRate;       //#(3)
                }
            }
        }
        else
        {
            if(u32RightAroundDistance > u32RightActualDistance)
            {
                #if 0   //=================
                printf("###LEFT: %08lu / %08lu / -%08lu(-%02lu s) || %08lu / %08lu /  %08lu( %02lu s) :RIGHT###\n",
                        u32LeftAroundDistance, u32LeftActualDistance, u32LeftActualDistance - u32LeftAroundDistance, (u32LeftActualDistance - u32LeftAroundDistance)/_pstPvrPlaybackPath->u16PlayedAvgRate,
                        u32RightAroundDistance, u32RightActualDistance, u32RightAroundDistance - u32RightActualDistance, (u32RightAroundDistance - u32RightActualDistance)/ _pstPvrPlaybackPath->u16PlayedAvgRate);
                #endif  //=================

                if((u32RightAroundDistance - u32RightActualDistance) >= _pstPvrPlaybackPath->u32GapLengthExtKB)
                {
                    _u32PlaybackJumpDirection = 0;
                    _u32PlaybackJumpCount = (u32RightAroundDistance - u32RightActualDistance)*10/_pstPvrPlaybackPath->u16PlayedAvgRate;       //#(3)
                }
            }
            else
            {
                #if 0   //=================
                printf("###LEFT: %08lu / %08lu / -%08lu(-%02lu s) || %08lu / %08lu /  %08lu( %02lu s) :RIGHT###\n",
                        u32LeftAroundDistance, u32LeftActualDistance, u32LeftActualDistance - u32LeftAroundDistance, (u32LeftActualDistance - u32LeftAroundDistance)/_pstPvrPlaybackPath->u16PlayedAvgRate,
                        u32RightAroundDistance, u32RightActualDistance, u32RightActualDistance - u32RightAroundDistance, (u32RightActualDistance - u32RightAroundDistance)/ _pstPvrPlaybackPath->u16PlayedAvgRate);
                #endif  //=================
            }
        }
        if (_u32PlaybackJumpCount < BEGINJUMPTHRELD)
            _u32PlaybackJumpCount = 0;
    }
}

/*************************************************************************************************/

/*###############################################################################################*/
/*/////////////////////////////////////// playback path /////////////////////////////////////////*/
/*###############################################################################################*/

/***************************************************************************************/
static BOOLEAN MApp_Playback_Open(U16 *pu16PlaybackFileName)
{
    U8 u8PlaybackOpen = FALSE;

    /*[01]error condition =============================================================*/
    if (_enPlaybackState != E_PLAYBACK_STATE_WAIT)
    {
        return FALSE;
    }
    //printf("MApp_Playback_Open \n");

    /*[02-1]set pvr playback path =====================================================*/
    _pstPvrPlaybackPath = msAPI_PVR_PlaybackPathOpen(pu16PlaybackFileName);

    if(_pstPvrPlaybackPath)
    {
        if(MApp_Record_CheckPlaybackLinkage(RECORD_PATH_DEFAULT, pu16PlaybackFileName))
        {
            _pstPvrPlaybackPath->bLinkRecord = TRUE;    //<---(R-P-1)establish record linkage
        }

        u8PlaybackOpen = TRUE;
    }
    else
    {
        MS_DEBUG_MSG(printf("Playback open fail\n"));
        _enPlaybackStatus = E_PVR_API_STATUS_FILE_READ_ERROR;
        u8PlaybackOpen = FALSE;
    }

    /*[02-2]set audio/scaler/video ====================================================*/



    /*[03]change state ================================================================*/
    if(u8PlaybackOpen)
    {
        _enPlaybackState = E_PLAYBACK_STATE_OPEN;
        return TRUE;
    }
    else
    {
        _enPlaybackState = E_PLAYBACK_STATE_WAIT;
        return FALSE;
    }
}

/***************************************************************************************/
static BOOLEAN MApp_Playback_Enable(void)
{
    #ifndef S3PLUS
    #ifndef PVR_UTOPIA
    msAPI_DMX_Switch2Pinpon(FALSE);
    #endif
    #endif

//    U8 u8PlaybackEnable = FALSE;

    /*[01]error condition =============================================================*/
    if (_enPlaybackState != E_PLAYBACK_STATE_OPEN)
    {
        return FALSE;
    }
    //printf("MApp_Playback_Enable \n");

    /*[02-1]set pvr playback path =====================================================*/
    _pstPvrPlaybackPath->u32BufferStart  = PvrGetReadSdramAdr();                //<--from system

#ifdef PVR_UTOPIA
    #if (PVR_READ_SDRAM_LEN >= (PVR_FILE_IN_SIZE*3))
        //printf("CmdQ num=3\n");
        _pstPvrPlaybackPath->u32BufferLength = PVR_FILE_IN_SIZE*3;                //<--from system
    #elif (PVR_READ_SDRAM_LEN >= (PVR_FILE_IN_SIZE*2))
        //printf("CmdQ num=2\n");
        _pstPvrPlaybackPath->u32BufferLength = PVR_FILE_IN_SIZE*2;                //<--from system
    #else
        {
            printf("\n\nFatal error:Read Buff overflow\n\n");
            return FALSE;
        }
    #endif
#else
    _pstPvrPlaybackPath->u32BufferLength = PVR_READ_SDRAM_LEN;
#endif
    #if BRAZIL_PVR_CC
    MApp_PVR_Playback_SetCCPID(MSAPI_DMX_INVALID_PID);
    #endif

    if ((_enPlaybackStatus=msAPI_PVR_PlaybackPathSet(_pstPvrPlaybackPath)) == E_PVR_API_STATUS_OK)
    {
        //############################ ************************* ############################
        _pstPvrRecordPath = _pstPvrPlaybackPath->pstPvrRecordPath;   //<---Linking to Record Path in Playback Mode
        _pstPvrRecordPath->u32RecordedTime = msAPI_Timer_GetTime0();
        //############################ ************************* ############################

        {
        #ifdef PVR_8051
            //(TYPE1)~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            msAPI_DMX_Stop(u8PcrFid);               //PCR_FID
            msAPI_DMX_Close(u8PcrFid);
            u8PcrFid = MSAPI_DMX_INVALID_FLT_ID;
            msAPI_DMX_Stop(u8VidFid);               //VID_FID
            msAPI_DMX_Close(u8VidFid);
            u8VidFid = MSAPI_DMX_INVALID_FLT_ID;
            msAPI_DMX_Stop(u8AudFid);               //AUD_FID
            msAPI_DMX_Close(u8AudFid);
            u8AudFid = MSAPI_DMX_INVALID_FLT_ID;
            #ifndef S3PLUS
            msAPI_DMX_Stop(u8AdAFid);               //ADA_FID
            msAPI_DMX_Close(u8AdAFid);
            u8AdAFid = MSAPI_DMX_INVALID_FLT_ID;
            #endif
            //(TYPE2)~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            msAPI_DMX_Stop(g_u8PesFID);             //SUBTITLE_FID
            msAPI_DMX_Close(g_u8PesFID);
            g_u8PesFID = MSAPI_DMX_INVALID_FLT_ID;
        #else
            //(TYPE1)~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            msAPI_DMX_Stop(*MApp_Dmx_GetFid(EN_PCR_FID));               //PCR_FID
            msAPI_DMX_Close(*MApp_Dmx_GetFid(EN_PCR_FID));
            MApp_Dmx_SetFid(MSAPI_DMX_INVALID_FLT_ID, EN_PCR_FID);
            msAPI_DMX_Stop(*MApp_Dmx_GetFid(EN_VIDEO_FID) );               //VID_FID
            msAPI_DMX_Close(*MApp_Dmx_GetFid(EN_VIDEO_FID) );
            MApp_Dmx_SetFid(MSAPI_DMX_INVALID_FLT_ID, EN_VIDEO_FID);
            msAPI_DMX_Stop(*MApp_Dmx_GetFid(EN_AUDIO_FID));               //AUD_FID
            msAPI_DMX_Close(*MApp_Dmx_GetFid(EN_AUDIO_FID));
            MApp_Dmx_SetFid(MSAPI_DMX_INVALID_FLT_ID, EN_AUDIO_FID);
            msAPI_DMX_Stop(*MApp_Dmx_GetFid(EN_AD_FID));               //ADA_FID
            msAPI_DMX_Close(*MApp_Dmx_GetFid(EN_AD_FID));
            MApp_Dmx_SetFid(MSAPI_DMX_INVALID_FLT_ID, EN_AD_FID);
            //(TYPE2)~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            msAPI_DMX_Stop(*MApp_Dmx_GetFid(EN_PES_FID));             //SUBTITLE_FID
            msAPI_DMX_Close(*MApp_Dmx_GetFid(EN_PES_FID));
            MApp_Dmx_SetFid(MSAPI_DMX_INVALID_FLT_ID, EN_PES_FID);
        #endif
            //(TYPE3)~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

            //(TYPE4)~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

            //(TYPE5)~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

            //((( )))~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        }
        {
            U8 u8FID;

            for (u8FID = 0; u8FID < MSAPI_DMX_RECORD_FILTER_NUMBER; u8FID++)
            {
                if (_pstPvrRecordPath->u8FilterID[u8FID] != MSAPI_DMX_INVALID_FLT_ID)
                {
                    //(TYPE1)~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    if(_pstPvrRecordPath->enFilterType[u8FID] == MSAPI_DMX_FILTER_TYPE_PCR)             //PCR_FID
                    {
                    #ifndef S3PLUS
                        msAPI_PVR_PlaybackPathAddPID(_pstPvrPlaybackPath, _pstPvrRecordPath->u16PID[u8FID], MSAPI_DMX_FILTER_TYPE_PCR);
                    #else
                        {
                            U8 u8FID;
                            gAvSync_PcrFid = MSAPI_DMX_INVALID_FLT_ID;
                            msAPI_PVR_PlaybackPathAddPID(_pstPvrPlaybackPath, 0x1ffe, MSAPI_DMX_FILTER_TYPE_PCR);
                            for (u8FID = 0; u8FID < MSAPI_DMX_RECORD_FILTER_NUMBER; u8FID++)
                            {
                                if (_pstPvrPlaybackPath->enFilterType[u8FID] == MSAPI_DMX_FILTER_TYPE_PCR)
                                {
                                    gAvSync_PcrFid = _pstPvrPlaybackPath->u8FilterID[u8FID];
                                    //printf("gAvSync_PcrFid=%bd\n",gAvSync_PcrFid);
                                    break;
                                }
                            }
                            if(gAvSync_PcrFid == MSAPI_DMX_INVALID_FLT_ID)
                            {
                                //printf("Invalid gAvSync_PcrFid\n");
                            }
                        }
                    #endif
                    }
                    else if(_pstPvrRecordPath->enFilterType[u8FID] == MSAPI_DMX_FILTER_TYPE_VIDEO)      //VID_FID
                    {
                        msAPI_PVR_PlaybackPathAddPID(_pstPvrPlaybackPath, _pstPvrRecordPath->u16PID[u8FID], MSAPI_DMX_FILTER_TYPE_VIDEO);
                    }
                    else if(_pstPvrRecordPath->enFilterType[u8FID] == MSAPI_DMX_FILTER_TYPE_AUDIO)      //AUD_FID
                    {
                        //msAPI_PVR_PlaybackPathAddPID(_pstPvrPlaybackPath, _pstPvrRecordPath->u16PID[u8FID], MSAPI_DMX_FILTER_TYPE_AUDIO);
                    }
                    #ifndef S3PLUS
                    else if(_pstPvrRecordPath->enFilterType[u8FID] == MSAPI_DMX_FILTER_TYPE_AUDIO2)     //ADA_FID
                    {
                        //msAPI_PVR_PlaybackPathAddPID(_pstPvrPlaybackPath, _pstPvrRecordPath->u16PID[u8FID], MSAPI_DMX_FILTER_TYPE_AUDIO2);
                    }
                    #endif
                    //(TYPE2)~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    else if (_pstPvrRecordPath->enFilterType[u8FID] == MSAPI_DMX_FILTER_TYPE_SUBTITLE)  //SUBTITLE_FID
                    {
                        #if BRAZIL_PVR_CC
                        MApp_PVR_Playback_SetCCPID(_pstPvrRecordPath->u16PID[u8FID]);
                        #endif
                        //msAPI_DMX_SetDataPath(MSAPI_DMX_DATAPATH_MIU, MSAPI_DMX_DATAPATH_IN_MIU, MSAPI_DMX_DATAPATH_SYNCMODE_EXTERNAL);
                        //MApp_Dmx_PES_Monitor(_pstPvrRecordPath->u16PID[u8FID]);
                        //msAPI_DMX_RestoreDataPath();
                    }
                    //(TYPE3)~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

                    //(TYPE4)~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

                    //(TYPE5)~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

                    //((( )))~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                }
            }
        }

        //link record-playback at start up ============================================//
        _pstPvrPlaybackPath->u32FileValidPosStrKB   = _pstPvrRecordPath->u32FileValidPosStrKB;

        _pstPvrPlaybackPath->enVideoType            = _pstPvrRecordPath->enVideoType;
        _pstPvrPlaybackPath->enAudioType            = _pstPvrRecordPath->enAudioType;
        _pstPvrPlaybackPath->enAdAudioType          = _pstPvrRecordPath->enAdAudioType;
        //link record-playback at start up ============================================//

        #ifdef S3PLUS
        MApp_Dmx_DisableTableMonitor();     //<--no table monitor because demux switch to playback
        #endif

        msAPI_PVR_PlaybackPathStart(_pstPvrPlaybackPath);
        //u8PlaybackEnable = TRUE;
    }
    else
    {
        //u8PlaybackEnable = FALSE;
        _enPlaybackState = E_PLAYBACK_STATE_WAIT;
        _enPlaybackSpeed = E_PLAY_SPEED_1X;
        return FALSE;

    }

    /*[02-2]set audio/scaler/video ====================================================*/
    //printf("audio stop->init; scaler freeze; video stop->init; \n");
    msAPI_Player_AudioStop();
    msAPI_Player_ScalerFreeze();
    msAPI_Player_VideoStop();

    #if (defined(S3PLUS) || defined(S4LITE))
    msAPI_Player_AudioInit(_pstPvrPlaybackPath->enAudioType,  E_PLAY_SOURCE_FILE, FALSE, E_PLAY_AUDIO_TYPE_INVALID);
    #else
    msAPI_Player_AudioInit(_pstPvrPlaybackPath->enAudioType,  E_PLAY_SOURCE_FILE, stGenSetting.g_SoundSetting.bEnableAD, _pstPvrPlaybackPath->enAdAudioType);
    #endif

    msAPI_Player_VideoInit(_pstPvrPlaybackPath->enVideoType,  E_PLAY_SOURCE_FILE);

    /*[03]change state ================================================================*/
    //if(u8PlaybackEnable)
    {
        _enPlaybackState = E_PLAYBACK_STATE_OPEN;   //no change
        _enPlaybackSpeed = E_PLAY_SPEED_1X;
        return TRUE;
    }
    //else
    //{
        //_enPlaybackState = E_PLAYBACK_STATE_WAIT;
        //_enPlaybackSpeed = E_PLAY_SPEED_1X;
        //return FALSE;
    //}
}

/***************************************************************************************/
static BOOLEAN  MApp_Playback_Routine(void)
{
    /*[01]error condition =============================================================*/
    if ((_enPlaybackState != E_PLAYBACK_STATE_PLAYBACKING ) &&
        (_enPlaybackState != E_PLAYBACK_STATE_FASTFORWARD ) &&
        (_enPlaybackState != E_PLAYBACK_STATE_FASTBACKWARD)   )
    {
        return TRUE;
    }
    //printf("MApp_Playback_Routine \n");

    /*[02-1]set pvr playback path =====================================================*/
    /*[02-1a]link record-playback =====================================================*/
    _pstPvrPlaybackPath->u32FileLimitedSizeKB   = _pstPvrRecordPath->u32FileLimitedSizeKB;
    _pstPvrPlaybackPath->u32FileValidPosStrKB   = _pstPvrRecordPath->u32FileValidPosStrKB;
    _pstPvrPlaybackPath->u32FileValidPosEndKB   = _pstPvrRecordPath->u32FileValidPosEndKB;
    _pstPvrPlaybackPath->u32FileValidDistanceKB = _pstPvrRecordPath->u32FileValidDistanceKB;
    _pstPvrPlaybackPath->u32FileValidPeriod     = _pstPvrRecordPath->u32FileValidPeriod;

    _pstPvrPlaybackPath->u16PlayedAvgRate       = _pstPvrRecordPath->u16RecordedAvgRate;

    //Special Treatment for Fast Forward when Bump End ================================//
    #if 0
    if(_enPlaybackState == E_PLAYBACK_STATE_FASTFORWARD)
    {
        if((_pstPvrPlaybackPath->u32FileValidPosEndKB - _pstPvrPlaybackPath->u32FilePositionKB) <= (_pstPvrPlaybackPath->u16PlayedAvgRate * (U8)_enPlaybackSpeed))
        {
            if(_pstPvrPlaybackPath->u16PlayedAvgRate > 100)   //suppose <=100 is RADIO, temp solution
            {
                MApp_Record_StopPlaybackLinkage(RECORD_PATH_DEFAULT);
            }
            //printf("FAST_FORWARD_DATA_STOP-1\n");
        }
    }
    #endif
    //Special Treatment for Fast Forward when Bump End ================================//

    /*[02-1b]playback path output routine =============================================*/
    /*[##-1]Fast Backward =============================================================*/
    if(_enPlaybackState == E_PLAYBACK_STATE_FASTBACKWARD)
    {
        U32 playTime = MApp_Playback_GetPlaybackTimeSec();
        U32 recstartTime = MApp_Playback_GetRecordStartTimeSec();
        U16 u16JumpSec = 0;

        switch(_enPlaybackSpeed)
        {
            case E_PLAY_SPEED_1X:
                break;
            case E_PLAY_SPEED_2X:
            case E_PLAY_SPEED_4X:
                u16JumpSec = 1;
                break;
            case E_PLAY_SPEED_8X:
                u16JumpSec = 2;
                break;
            case E_PLAY_SPEED_16X:
                u16JumpSec = 3;
                break;
            case E_PLAY_SPEED_32X:
                u16JumpSec = 4;
                break;
        }

        _enPlaybackStatus = msAPI_PVR_PlaybackPathBackwardOutput(_pstPvrPlaybackPath, 0);
        if(_enPlaybackStatus == E_PVR_API_STATUS_OK)
        {
            if((playTime > recstartTime) && (playTime - recstartTime > 1))
            {
                if((_enPlaybackStatus=msAPI_PVR_PlaybackPathJumpBackward(_pstPvrPlaybackPath, u16JumpSec, E_JUMP_BUFFER_CONTINUOUS)) == E_PVR_API_STATUS_OK)
                {
                    _enPlaybackStatus = msAPI_PVR_PlaybackPathBackwardOutput(_pstPvrPlaybackPath, 1);   //output 1 second stream each jump
                    if((_enPlaybackStatus != E_PVR_API_STATUS_OK) && (_enPlaybackStatus != E_PVR_API_STATUS_FILE_STILL_HAVE_DATA_WAIT))
                    {
                        return FALSE;
                    }
                }
            }
        }
    }

    /*[##-2]Fast Forward ==============================================================*/
    else if(_enPlaybackState == E_PLAYBACK_STATE_FASTFORWARD)
    {
        if( _enPlaybackSpeed > E_PLAY_SPEED_8X)
        {
            U16 u16JumpSec = 0;

            switch(_enPlaybackSpeed)
            {
            /*    case E_PLAY_SPEED_1X:
                    #ifndef S3PLUS
                    u16JumpSec = 0;
                    #else
                    u16JumpSec = 0; //s3p performance is not good enough
                    #endif
                    break;
                case E_PLAY_SPEED_2X:
                    #ifndef S3PLUS
                    u16JumpSec = 0;
                    #else
                    u16JumpSec = 1; //s3p performance is not good enough
                    #endif
                    break;
                case E_PLAY_SPEED_4X:
                    #ifndef S3PLUS
                    u16JumpSec = 0;
                    #else
                    u16JumpSec = 3; //s3p performance is not good enough
                    #endif
                    break;
                    */
                case E_PLAY_SPEED_8X:
                    #ifndef S3PLUS
                    u16JumpSec = 1; // ~ 10x
                    #else
                    u16JumpSec = 5; //s3p performance is not good enough
                    #endif
                    break;
                case E_PLAY_SPEED_16X:
                    #ifndef S3PLUS
                    u16JumpSec = 1; // ~ 20x
                    #else
                    u16JumpSec =10; //s3p performance is not good enough
                    #endif
                    break;
                case E_PLAY_SPEED_32X:
                    #ifndef S3PLUS
                    u16JumpSec = 3; // ~ 30x
                    #else
                    u16JumpSec =20; //s3p performance is not good enough
                    #endif
                    break;
                default:
                    u16JumpSec = 0;
                    break;
            }
            msAPI_PVR_PlaybackPathJumpForward(_pstPvrPlaybackPath, u16JumpSec, E_JUMP_BUFFER_CONTINUOUS);
        }
        if((_enPlaybackStatus=msAPI_PVR_PlaybackPathForwardOutput(_pstPvrPlaybackPath)) != E_PVR_API_STATUS_OK)
        {
            return FALSE;
        }
    }

    /*[##-3]Normal Play ===============================================================*/
    else
    {
        #ifdef S3PLUS
        MApp_AVSync_SetSTC();
        #else
        #ifdef PVR_UTOPIA
        //MApp_AVSync_ForceSync();
        #endif
        #endif

        msAPI_Player_VideoMonitor(FALSE); // Get GOP size info.
        if ((_enPlaybackStatus=msAPI_PVR_PlaybackPathForwardOutput(_pstPvrPlaybackPath)) != E_PVR_API_STATUS_OK)
        {
            return FALSE;
        }
    }

    if ((_enPlaybackStatus=msAPI_PVR_PlaybackPathGatherStatistics(_pstPvrPlaybackPath)) != E_PVR_API_STATUS_OK)
    {
        return FALSE;
    }

    if(MApp_Playback_StateMachineGet() == E_PLAYBACK_STATE_FASTFORWARD )
    {//for 8x 16x FFW can not reach the end > Calibrate JumpPeriod when near the end
        U32 u32RecEndTime = MApp_Playback_GetRecordEndTimeSec();
        U32 u32PlayTime = MApp_Playback_GetPlaybackTimeSec();
        //U32 u32RecStartTime = MApp_Playback_GetRecordStartTimeSec();
        if(u32RecEndTime -u32PlayTime < 30)
        {   //printf("\nRecordEndTime = %lu , PlaybackTime=%lu \n",MApp_TimeShift_GetRecordEndTimeSec(),MApp_TimeShift_GetPlaybackTimeSec());
            MApp_Playback_StateMachineTimeCalibration(TIME_CALIBRATION_MACRO);
        }
    }

    /*[02-1c]playback path rate control ===============================================*/
    #if 0  //if not use time_stamp ====================================================//
    msAPI_PVR_PlaybackPathTuneRate(_pstPvrPlaybackPath, _pstPvrRecordPath->u16RecordedAvgRate);
    #endif //if not use time_stamp ====================================================//

    /*[02-2]set audio/scaler/video ====================================================*/



    /*[03]change state ================================================================*/
    if((_enPlaybackState != E_PLAYBACK_STATE_FASTFORWARD ) &&
       (_enPlaybackState != E_PLAYBACK_STATE_FASTBACKWARD)   )
    {
        _enPlaybackState = E_PLAYBACK_STATE_PLAYBACKING;
    }

    _MApp_Playback_PlaybackTimeCalibration();

    return TRUE;
}

/***************************************************************************************/
static BOOLEAN MApp_Playback_JumpForward(U32 u32JumpSec)
{
    U8 u8BumpEnd;
    U16 u16TimeDiffSec;

    /*[01]error condition =============================================================*/
    if (_enPlaybackState != E_PLAYBACK_STATE_PAUSE)
    {
        return FALSE;
    }
    //printf("MApp_Playback_JumpForward \n");

    /*[02-1]set pvr playback path =====================================================*/
    /*[02-1a]jump forward =============================================================*/
    u16TimeDiffSec = MApp_Playback_GetRecordEndTimeSec() - MApp_Playback_GetPlaybackTimeSec();
    if(u16TimeDiffSec >= u32JumpSec)
    {
        msAPI_PVR_PlaybackPathJumpForward(_pstPvrPlaybackPath, u32JumpSec,      E_JUMP_BUFFER_RESET);
        u8BumpEnd = FALSE;
    }
    else
    {
        msAPI_PVR_PlaybackPathJumpForward(_pstPvrPlaybackPath, u16TimeDiffSec,  E_JUMP_BUFFER_RESET);
        _enPlaybackStatus = E_PVR_API_STATUS_FILE_BUMP_END;
        u8BumpEnd = TRUE;
    }

    /*[02-2]set audio/scaler/video ====================================================*/
    #ifndef S3PLUS
    //printf("audio stop; scaler freeze; video stop->reset; \n");
    msAPI_Player_AudioStop();
    msAPI_Player_ScalerFreeze();
    msAPI_Player_VideoStop();
#ifdef PVR_UTOPIA  //can't clear bitstream buffer, so, have to reset MVD
    msAPI_Player_VideoInit(_pstPvrPlaybackPath->enVideoType,  E_PLAY_SOURCE_FILE);
#else
    msAPI_Player_VideoReset(E_PLAY_SOURCE_FILE);
#endif
    #else
    //printf("audio stop; scaler freeze; video stop->init; \n");
    msAPI_Player_AudioStop();
    msAPI_Player_ScalerFreeze();
    msAPI_Player_VideoStop();

    msAPI_Player_VideoInit(_pstPvrPlaybackPath->enVideoType,  E_PLAY_SOURCE_FILE);
    #endif

    /*[03]change state ================================================================*/
#ifndef PVR_UTOPIA
    _enPlaybackState = E_PLAYBACK_STATE_STOP;
#endif

    if(u8BumpEnd == TRUE)
    {
        return FALSE;
    }
    else
    {
        return TRUE;
    }
}

/***************************************************************************************/
static BOOLEAN MApp_Playback_JumpBackward(U32 u32JumpSec)
{
    U16 u16TimeDiffSec;

    /*[01]error condition =============================================================*/
    if (_enPlaybackState != E_PLAYBACK_STATE_PAUSE)
    {
        return FALSE;
    }
    //printf("MApp_Playback_JumpBackward \n");

    /*[02-1]set pvr playback path =====================================================*/
    /*[02-1a]jump backward ============================================================*/
    u16TimeDiffSec = MApp_Playback_GetPlaybackTimeSec() - MApp_Playback_GetRecordStartTimeSec();
    if(u16TimeDiffSec >= u32JumpSec)
    {
        msAPI_PVR_PlaybackPathJumpBackward(_pstPvrPlaybackPath, u32JumpSec,     E_JUMP_BUFFER_RESET);
    }
    else
    {
        msAPI_PVR_PlaybackPathJumpBackward(_pstPvrPlaybackPath, u16TimeDiffSec, E_JUMP_BUFFER_RESET);
    }

    /*[02-2]set audio/scaler/video ====================================================*/
    #ifndef S3PLUS
    //printf("audio stop; scaler freeze; video stop->reset; \n");
    msAPI_Player_AudioStop();
    msAPI_Player_ScalerFreeze();
    msAPI_Player_VideoStop();
#ifdef PVR_UTOPIA
    msAPI_Player_VideoInit(_pstPvrPlaybackPath->enVideoType,  E_PLAY_SOURCE_FILE);
#else
    msAPI_Player_VideoReset(E_PLAY_SOURCE_FILE);
#endif
    #else
    //printf("audio stop; scaler freeze; video stop->init; \n");
    msAPI_Player_AudioStop();
    msAPI_Player_ScalerFreeze();
    msAPI_Player_VideoStop();

    msAPI_Player_VideoInit(_pstPvrPlaybackPath->enVideoType,  E_PLAY_SOURCE_FILE);
    #endif

    /*[03]change state ================================================================*/
#ifndef PVR_UTOPIA
    _enPlaybackState = E_PLAYBACK_STATE_STOP;
#endif

    return TRUE;
}

/***************************************************************************************/
static enPlaybackState enPrevPlayDirection = E_PLAYBACK_STATE_FASTFORWARD;
/***************************************************************************************/
static BOOLEAN MApp_Playback_FastForward(void)
{
    /*[01]error condition =============================================================*/
    if (_enPlaybackState != E_PLAYBACK_STATE_PAUSE)
    {
        return FALSE;
    }
    //printf("MApp_Playback_FastForward \n");

    /*[02-1]set pvr playback path =====================================================*/
    msAPI_PVR_PlaybackPathFastForward(_pstPvrPlaybackPath);

    /*[02-2]set audio/scaler/video ====================================================*/
    //printf("audio nop; scaler waitfree; video ffspeed; \n");
    if(enPrevPlayDirection == E_PLAYBACK_STATE_FASTBACKWARD)
    {
      //printf("reverse backward->forward\n");
        enPrevPlayDirection = E_PLAYBACK_STATE_FASTFORWARD;
        _enPlaybackSpeed    = E_PLAY_SPEED_1X;
    }

    if(_enPlaybackSpeed < E_PLAY_SPEED_16X)
    {
        U8 u8PlaybackSpeed = (U8)_enPlaybackSpeed;
        _enPlaybackSpeed = (enPlaySpeed)(u8PlaybackSpeed << 1);
    }
    else
    {
        _enPlaybackSpeed = E_PLAY_SPEED_2X;
    }

#ifdef S3PLUS
    _pstPvrPlaybackPath->enPlaySpeed = _enPlaybackSpeed;
#endif

#ifdef S3PLUS  // I am not sure if need enable in other platform
    msAPI_Player_AudioPlay(E_PLAY_SOURCE_FILE);  //for clean afifo
    MUTE_On();
#endif
    msAPI_Player_VideoConfigForwardSpeed(_enPlaybackSpeed);
    msAPI_Player_ScalerWaitFree(10);

    /*[03]change state ================================================================*/
    _enPlaybackState = E_PLAYBACK_STATE_FASTFORWARD;

    #ifdef MEASURE_FFFB_TIME //=======================$$$//
    _u32FastForwardStartTime = msAPI_Timer_GetTime0();
    #endif //MEASURE_FFFB_TIME =======================$$$//

    return TRUE;
}

/***************************************************************************************/
static BOOLEAN MApp_Playback_FastBackward(void)
{
    /*[01]error condition =============================================================*/
    if (_enPlaybackState != E_PLAYBACK_STATE_PAUSE)
    {
        return FALSE;
    }
    //printf("MApp_Playback_FastBackward \n");

    /*[02-1]set pvr playback path =====================================================*/
    msAPI_PVR_PlaybackPathFastBackward(_pstPvrPlaybackPath);

    /*[02-2]set audio/scaler/video ====================================================*/
    //printf("audio nop; scaler waitfree; video fbspeed; \n");
    if(enPrevPlayDirection == E_PLAYBACK_STATE_FASTFORWARD)
    {
      //printf("reverse forward->backward\n");
        enPrevPlayDirection = E_PLAYBACK_STATE_FASTBACKWARD;
        _enPlaybackSpeed    = E_PLAY_SPEED_1X;
    }

    if(_enPlaybackSpeed < E_PLAY_SPEED_16X)
    {
        U8 u8PlaybackSpeed = (U8)_enPlaybackSpeed;
        _enPlaybackSpeed = (enPlaySpeed)(u8PlaybackSpeed << 1);
    }
    else
    {
        _enPlaybackSpeed = E_PLAY_SPEED_2X;
    }
    msAPI_Player_VideoConfigBackwardSpeed(_enPlaybackSpeed);
    msAPI_Player_ScalerWaitFree(10);

    #ifdef S3PLUS
    msAPI_Aeon_ReInitial( BIN_ID_CODE_AEON_TSSEARCH );
    msAPI_DMX_EnableReserveFlt(FALSE);
    msAPI_Player_AeonPatternSearchInit();
    #endif

    /*[03]change state ================================================================*/
    _enPlaybackState = E_PLAYBACK_STATE_FASTBACKWARD;

    #ifdef MEASURE_FFFB_TIME //=======================$$$//
    _u32FastBackwardStartTime = msAPI_Timer_GetTime0();
    #endif //MEASURE_FFFB_TIME =======================$$$//

    return TRUE;
}

/***************************************************************************************/
static BOOLEAN MApp_Playback_Pause(enPlaybackActionAfterPause eNextAct)
{
    U8 u8PlaybackEnable = FALSE;

    /*[01]error condition =============================================================*/
    if ((_enPlaybackState != E_PLAYBACK_STATE_OPEN        ) &&
        (_enPlaybackState != E_PLAYBACK_STATE_PLAYBACKING ) &&
        (_enPlaybackState != E_PLAYBACK_STATE_FASTFORWARD ) &&
        (_enPlaybackState != E_PLAYBACK_STATE_FASTBACKWARD)   )
    {
        return FALSE;
    }
    //printf("MApp_Playback_Pause \n");

    /*[02-1]set pvr playback path =====================================================*/
    if(_enPlaybackState == E_PLAYBACK_STATE_OPEN)   //live in
    {
        u8PlaybackEnable = FALSE;
    }
    else if (_enPlaybackState == E_PLAYBACK_STATE_FASTFORWARD)
    {
        msAPI_PVR_PlaybackPathPause(_pstPvrPlaybackPath);

        u8PlaybackEnable = TRUE;

        #ifdef MEASURE_FFFB_TIME //=======================$$$//
        printf("Fast Forward used time %04lu S\n",msAPI_Timer_DiffTimeFromNow(_u32FastForwardStartTime)/1000);
        #endif //MEASURE_FFFB_TIME =======================$$$//
    }
    else if (_enPlaybackState == E_PLAYBACK_STATE_FASTBACKWARD)
    {
        msAPI_PVR_PlaybackPathPause(_pstPvrPlaybackPath);

        u8PlaybackEnable = TRUE;

        #ifdef MEASURE_FFFB_TIME //=======================$$$//
        printf("Fast Backward used time %04lu S\n",msAPI_Timer_DiffTimeFromNow(_u32FastBackwardStartTime)/1000);
        #endif //MEASURE_FFFB_TIME =======================$$$//
    }
    else // E_PLAYBACK_STATE_PLAYBACKING            //file in
    {
        msAPI_PVR_PlaybackPathPause(_pstPvrPlaybackPath);

        u8PlaybackEnable = TRUE;
    }

    /*[02-2]set audio/scaler/video ====================================================*/
    if((_enPlaybackState == E_PLAYBACK_STATE_FASTFORWARD) &&
       ((eNextAct == E_PLAYBACK_NEXTACT_RESUME) ||
        (eNextAct == E_PLAYBACK_NEXTACT_NONE  )   )         )
    {
      //printf("audio nop; scaler freeze->mute; video stop->reset->init; \n");
        msAPI_Player_ScalerFreeze();
    #ifndef PVR_UTOPIA  //ther video cant' return after Mute, we need scaler to check this issue to improve the video quality
        msAPI_Player_ScalerMute(50);
    #endif

    #ifndef PVR_UTOPIA_T3
        msAPI_Player_VideoStop();
    #endif

    #ifndef PVR_UTOPIA  //diffenent funciton in utopia
        msAPI_Player_VideoReset(E_PLAY_SOURCE_FILE);
    #endif

    #ifndef PVR_UTOPIA_T3
        msAPI_Player_VideoInit(_pstPvrPlaybackPath->enVideoType,  E_PLAY_SOURCE_FILE);
    #endif
    }
    else if((_enPlaybackState == E_PLAYBACK_STATE_FASTBACKWARD) &&
            ((eNextAct == E_PLAYBACK_NEXTACT_RESUME) ||
             (eNextAct == E_PLAYBACK_NEXTACT_NONE  )   )          )
    {
        //printf("audio nop; scaler freeze->mute; video stop->reset->init; \n");
        msAPI_Player_ScalerFreeze();
    #ifndef PVR_UTOPIA  //ther video cant' return after Mute, we need scaler to check this issue to improve the video quality
        msAPI_Player_ScalerMute(50);
    #endif

    #ifndef PVR_UTOPIA_T3
        msAPI_Player_VideoStop();
    #endif

    #ifndef PVR_UTOPIA  //diffenent funciton in utopia
        msAPI_Player_VideoReset(E_PLAY_SOURCE_FILE);
    #endif

    #ifndef PVR_UTOPIA_T3
        msAPI_Player_VideoInit(_pstPvrPlaybackPath->enVideoType,  E_PLAY_SOURCE_FILE);
    #endif
        #ifdef S3PLUS
        msAPI_Aeon_Disable();                           //<--bandwidth problem, S3P only
        #endif
    }
    else
    {
        //printf("audio pause; scaler freeze; video pause; \n");
        msAPI_Player_AudioPause();
        msAPI_Player_ScalerFreeze();
        msAPI_Player_VideoPause();

        fEnableMvdTimingMonitor = FALSE;
        //printf("[[[fEnableMvdTimingMonitor = FALSE;]]]\n");
    }
#if ((ENABLE_SBTVD_BRAZIL_APP) && (BRAZIL_CC))
    if(*MApp_Dmx_GetFid(EN_PES_FID) != MSAPI_DMX_INVALID_FLT_ID)
    {
        if(MApp_CC_GetInfo(CC_SELECTOR_STATUS_CODE) == STATE_CAPTION_PARSER)
        {
            MApp_CC_StopParser();
        }
        MApp_Dmx_PES_Stop();
    }
#endif
    /*[03]change state ================================================================*/
    if(u8PlaybackEnable)
    {
        _enPlaybackState = E_PLAYBACK_STATE_PAUSE;
        return TRUE;
    }
    else
    {
        //_enPlaybackState = _enPlaybackState;        //no change
        return TRUE;
    }
}

/***************************************************************************************/
static BOOLEAN MApp_Playback_Resume(void)
{
    /*[01]error condition =============================================================*/
    if ((_enPlaybackState != E_PLAYBACK_STATE_OPEN        ) &&
        (_enPlaybackState != E_PLAYBACK_STATE_PAUSE       ) &&
        (_enPlaybackState != E_PLAYBACK_STATE_FASTFORWARD ) &&
        (_enPlaybackState != E_PLAYBACK_STATE_FASTBACKWARD) &&
        (_enPlaybackState != E_PLAYBACK_STATE_STOP        )   )
    {
        if(_enPlaybackState == E_PLAYBACK_STATE_WAIT)
        {
            MS_DEBUG_MSG(printf("_enPlaybackState == E_PLAYBACK_STATE_WAIT \n"));
            msAPI_PVR_PlaybackPathClose(_pstPvrPlaybackPath);
            msAPI_Player_AudioPlay(E_PLAY_SOURCE_FILE);
            msAPI_Player_ScalerWaitFree(50);
            msAPI_Player_ScalerMute(50);
            msAPI_Player_VideoEncoderReset();
            msAPI_Player_VideoPlay(E_PLAY_MODE_NORMAL);
        }
        return FALSE;
    }
  //printf("MApp_Playback_Resume \n");
#ifdef S3PLUS
    _pstPvrPlaybackPath->enPlaySpeed = E_PLAY_SPEED_1X;
#endif
    /*[02-1]set pvr playback path =====================================================*/
    if(_enPlaybackState == E_PLAYBACK_STATE_OPEN)    //live in
    {
        //%%%no-such-case, remove if necessary%%%//
    }
    else // E_PLAYBACK_STATE_PAUSE || E_PLAYBACK_STATE_STOP //file in
    {
        msAPI_PVR_PlaybackPathResume(_pstPvrPlaybackPath);
    }

    /*[02-2]set audio/scaler/video ====================================================*/
    if((_enPlaybackState == E_PLAYBACK_STATE_OPEN) ||
       (_enPlaybackState == E_PLAYBACK_STATE_STOP)   )    //live in
    {
      //printf("audio play; scaler waitfree->mute; video play; \n");
        msAPI_Player_AudioPlay(E_PLAY_SOURCE_FILE);
        msAPI_Player_ScalerWaitFree(100);
        msAPI_Player_ScalerMute(100);
        msAPI_Player_VideoEncoderReset();
        msAPI_Player_VideoPlay(E_PLAY_MODE_NORMAL);

        fEnableMvdTimingMonitor = TRUE;
      //printf("[[[fEnableMvdTimingMonitor = TRUE;]]]\n");
    }
    else
    {
      //printf("audio stop->play; scaler waitfree; video monitor->resume; \n");
        //#ifdef PVR_UTOPIA
        //if(_enPlaybackState != E_PLAYBACK_STATE_PAUSE) //audio "pause-stop-play" will cause pvr "pause->play" without av sync
        //#endif
        msAPI_Player_AudioStop();
        msAPI_Player_AudioPlay(E_PLAY_SOURCE_FILE);
        #ifndef S3PLUS
		#if(ENABLE_SBTVD_BRAZIL_APP)
        	msAPI_Player_ScalerWaitFree(500);
		#else
        msAPI_Player_ScalerWaitFree(10);
		#endif
        #else
        msAPI_Player_ScalerWaitFree(50);
        #endif
        msAPI_Player_VideoEncoderReset();
        msAPI_Player_VideoMonitor(TRUE); // Reset GOP size info

    #ifdef PVR_UTOPIA
        msAPI_Player_VideoPlay(E_PLAY_MODE_NORMAL);
        _enPlaybackSpeed = E_PLAY_SPEED_1X;
        msAPI_Player_VideoConfigForwardSpeed(_enPlaybackSpeed);
    #else
        msAPI_Player_VideoResume();
    #endif
        fEnableMvdTimingMonitor = TRUE;
      //printf("[[[fEnableMvdTimingMonitor = TRUE;]]]\n");
    }
    //start CC
#if ((ENABLE_SBTVD_BRAZIL_APP) && (BRAZIL_CC))
    U16 u16CCPid = MApp_PVR_Playback_GetCCPID();
    if(*MApp_Dmx_GetFid(EN_PES_FID) != MSAPI_DMX_INVALID_FLT_ID)
    {
        if(MApp_CC_GetInfo(CC_SELECTOR_STATUS_CODE) == STATE_CAPTION_PARSER)
        {
            MApp_CC_StopParser();
        }
        MApp_Dmx_PES_Stop();
    }
    if(u16CCPid!=MSAPI_DMX_INVALID_PID)
    {
        MApp_ClosedCaption_Open_Filter(u16CCPid);
        if (*MApp_Dmx_GetFid(EN_PES_FID) != MSAPI_DMX_INVALID_FLT_ID)
        {
            MApp_CC_CtrlParser(CC_SELECTOR_MODE, CC_MODE_DTV);
            MApp_CC_CtrlParser(CC_SELECTOR_SERVICE, CC_SERVICE_SERVICE1);
            MApp_CC_StartParser();
        }
    }
#endif
    /*[03]change state ================================================================*/
    _enPlaybackState = E_PLAYBACK_STATE_PLAYBACKING;
    _enPlaybackSpeed  = E_PLAY_SPEED_1X;

    return TRUE;
}

/***************************************************************************************/
static BOOLEAN MApp_Playback_Disable(void)
{
    U8 u8PlaybackEnable = FALSE;

    /*[01]error condition =============================================================*/
    //printf("MApp_Playback_Disable \n");

    /*[02-1]set pvr playback path =====================================================*/
    if (_enPlaybackState == E_PLAYBACK_STATE_WAIT)
    {
        u8PlaybackEnable = FALSE;
    }
    else
    {
        msAPI_PVR_PlaybackPathStop(_pstPvrPlaybackPath);

        #ifdef S3PLUS
        gAvSync_PcrFid = MSAPI_DMX_INVALID_FLT_ID;
        #endif

        u8PlaybackEnable = TRUE;
    }
    /*[02-1-2]InIt TSP and set TSP filter  =====================================================*/
    #ifdef S3PLUS
    //Init TSP and set Tuner to serial mode
    if(MApp_Record_StateMachineGet()==E_RECORD_STATE_WAIT)
    {
        msAPI_DMX_Initial();//Init TSP

        if(bCardAInside) //Set Tuner to serial mode
        {msAPI_Tuner_Serial_Control(FALSE);}
        else
        {msAPI_Tuner_Serial_Control(TRUE);}
    }
    else
    {
        //We don't init TSP if the the record process is still running
    }
    #endif
    //Set TSP filter
    //(TYPE1)~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #ifdef PVR_8051
    msAPI_DMX_StartFilter( g_u16Current_PCRPID,             MSAPI_DMX_FILTER_TYPE_PCR,    &u8PcrFid );
    msAPI_DMX_StartFilter( g_u16Current_PVR_VideoPID,       MSAPI_DMX_FILTER_TYPE_VIDEO,  &u8VidFid );
    msAPI_DMX_StartFilter( g_u16Current_PVR_AudioPID,       MSAPI_DMX_FILTER_TYPE_AUDIO,  &u8AudFid );
    #ifndef S3PLUS
    msAPI_DMX_StartFilter( g_u16Current_AudioDescriptorPID, MSAPI_DMX_FILTER_TYPE_AUDIO2, &u8AdAFid );
    #endif
    #else
    msAPI_DMX_StartFilter( g_u16Current_PCRPID,             MSAPI_DMX_FILTER_TYPE_PCR,    MApp_Dmx_GetFid(EN_PCR_FID));
    msAPI_DMX_StartFilter( g_u16Current_PVR_VideoPID,       MSAPI_DMX_FILTER_TYPE_VIDEO,  MApp_Dmx_GetFid(EN_VIDEO_FID) );
    msAPI_DMX_StartFilter( g_u16Current_PVR_AudioPID,       MSAPI_DMX_FILTER_TYPE_AUDIO,  MApp_Dmx_GetFid(EN_AUDIO_FID) );
    msAPI_DMX_StartFilter( g_u16Current_AudioDescriptorPID, MSAPI_DMX_FILTER_TYPE_AUDIO2, MApp_Dmx_GetFid(EN_AD_FID) );
    #endif
    //(TYPE2)~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #if (ENABLE_SUBTITLE && ENABLE_SBTVD_BRAZIL_APP == 0)
    #ifndef S3PLUS
    MApp_Subtitle_PID_Updated();
    #endif
    #endif
    //(TYPE3)~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    //(TYPE4)~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    //(TYPE5)~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    //((( )))~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    /*[02-2]set audio/scaler/video ====================================================*/
  //printf("audio stop->restore->play; scaler freeze->waitfree; video stop->reset->restore->play; \n");
    msAPI_Player_AudioStop();
    msAPI_Player_ScalerFreeze();
    msAPI_Player_VideoStop();
    msAPI_Player_VideoReset(E_PLAY_SOURCE_LIVE);

    #if (defined(S3PLUS) || defined(S4LITE))
    msAPI_Player_AudioRestore(FALSE);
    #else
    msAPI_Player_AudioRestore(stGenSetting.g_SoundSetting.bEnableAD);
    #endif

    msAPI_Player_AudioPlay(E_PLAY_SOURCE_LIVE);
    msAPI_Player_ScalerWaitFree(50);
    msAPI_Player_ScalerMute(50);
    msAPI_Player_VideoRestore();
    msAPI_Player_VideoPlay(E_PLAY_MODE_NORMAL);

    #ifdef S3PLUS
    MApp_Dmx_EnableTableMonitor();          //<--restore table monitor because demux switch to live
    #endif
#ifdef PVR_UTOPIA
#if ENABLE_CI
    if (!MApp_PVR_IsRecording())
        {
        if (msAPI_CI_CardDetect())
        {
            msAPI_Tuner_Serial_Control(TRUE);
        }
        else
        {
            msAPI_Tuner_Serial_Control(FALSE);
        }
    }
#else

       #if (FRONTEND_DEMOD_TYPE == TOSHIBA_TC90512XBG_DEMOD ||\
             FRONTEND_DEMOD_TYPE == TOSHIBA_TC90517FG_DEMOD ||\
             FRONTEND_DEMOD_TYPE == TOSHIBA_TC90527FG_DEMOD)
            MApi_DMX_FlowSet(DMX_FLOW_PLAYBACK, DMX_FLOW_INPUT_EXT_INPUT0, FALSE, TRUE, TS_PARALLEL_OUTPUT?TRUE:FALSE);
        #elif (FRONTEND_DEMOD_TYPE == ALTOBEAM_883X || FRONTEND_DEMOD_TYPE == ALTOBEAM_884X)
            MApi_DMX_FlowSet(DMX_FLOW_PLAYBACK, DMX_FLOW_INPUT_EXT_INPUT0, FALSE, TRUE, TS_PARALLEL_OUTPUT?TRUE:FALSE);
	  #else
            MApi_DMX_FlowSet(DMX_FLOW_PLAYBACK, DMX_FLOW_INPUT_EXT_INPUT0, FALSE, TRUE, TS_PARALLEL_OUTPUT?TRUE:FALSE);
        #endif

        //#if (CHIP_FAMILY_TYPE==CHIP_FAMILY_M12)
        //    MApi_DMX_FlowSet(DMX_FLOW_PLAYBACK, DMX_FLOW_INPUT_EXT_INPUT0, FALSE, TRUE, TS_PARALLEL_OUTPUT?TRUE:FALSE);
        //#endif

#endif
#endif

    #ifdef MEASURE_FFFB_TIME //=======================$$$//
    if(_enPlaybackState == E_PLAYBACK_STATE_FASTFORWARD)
    {
        printf("Fast Forward used time %04lu S\n",msAPI_Timer_DiffTimeFromNow(_u32FastForwardStartTime)/1000);
    }
    #endif //MEASURE_FFFB_TIME =======================$$$//

#if ((ENABLE_SBTVD_BRAZIL_APP) && (BRAZIL_CC))
    if(*MApp_Dmx_GetFid(EN_PES_FID) != MSAPI_DMX_INVALID_FLT_ID)
    {
        if(MApp_CC_GetInfo(CC_SELECTOR_STATUS_CODE) == STATE_CAPTION_PARSER)
        {
            MApp_CC_StopParser();
        }
        MApp_Dmx_PES_Stop();
    }
#endif
    /*[03]change state ================================================================*/
    if(u8PlaybackEnable)
    {
        _enPlaybackState = E_PLAYBACK_STATE_STOP;
        _enPlaybackSpeed = E_PLAY_SPEED_1X;
        return TRUE;
    }
    else
    {
        _enPlaybackState = E_PLAYBACK_STATE_WAIT;    //no change
        _enPlaybackSpeed = E_PLAY_SPEED_1X;
        return TRUE;
    }
}

/***************************************************************************************/
static BOOLEAN MApp_Playback_Close(void)
{
    /*[01]error condition =============================================================*/
    if (_enPlaybackState != E_PLAYBACK_STATE_STOP)
    {
        return FALSE;
    }
    //printf("MApp_Playback_Close \n");

    /*[02-1]set pvr playback path =====================================================*/
    msAPI_PVR_PlaybackPathClose(_pstPvrPlaybackPath);

    /*[02-2]set audio/scaler/video ====================================================*/



    /*[03]change state ================================================================*/
    _enPlaybackState = E_PLAYBACK_STATE_WAIT;

    return TRUE;
}

/***************************************************************************************/

/*###############################################################################################*/
/*///////////////////////////// playback ap (time-bar-related) //////////////////////////////////*/
/*###############################################################################################*/

/***************************************************************************************/
U32 MApp_Playback_GetRecordStartTimeSec(void)
{
    U32 u32StartTime;

    /*[01]error condition =============================================================*/
    if ((_enPlaybackState != E_PLAYBACK_STATE_PLAYBACKING ) &&
        (_enPlaybackState != E_PLAYBACK_STATE_PAUSE       ) &&
        (_enPlaybackState != E_PLAYBACK_STATE_FASTFORWARD ) &&
        (_enPlaybackState != E_PLAYBACK_STATE_FASTBACKWARD)   )
    {
        return 0;
    }
  //printf("MApp_Playback_GetRecordStartTimeSec \n");

    /*[02-1]set pvr record path =======================================================*/
    if((_pstPvrRecordPath->u32RecordedPeriod - _pstPvrRecordPath->u32PausedPeriod) < _pstPvrRecordPath->u32FileValidPeriod)
    {
        u32StartTime = _pstPvrRecordPath->u32RecordedTime/1000;
    }
    else
    {
        u32StartTime = _pstPvrRecordPath->u32RecordedTime/1000  +   //in 1/1000 SECOND
                       _pstPvrRecordPath->u32RecordedPeriod/10  -   //in 1/10   SECOND
                       _pstPvrRecordPath->u32PausedPeriod/10    -   //in 1/10   SECOND
                       _pstPvrRecordPath->u32FileValidPeriod/10;    //in 1/10   SECOND
    }
    return u32StartTime;

    /*[02-2]set audio/scaler/video ====================================================*/



    /*[03]change state ================================================================*/


}

/***************************************************************************************/
U32 MApp_Playback_GetRecordEndTimeSec(void)
{
    U32 u32EndTime;

    /*[01]error condition =============================================================*/
    if ((_enPlaybackState != E_PLAYBACK_STATE_PLAYBACKING ) &&
        (_enPlaybackState != E_PLAYBACK_STATE_PAUSE       ) &&
        (_enPlaybackState != E_PLAYBACK_STATE_FASTFORWARD ) &&
        (_enPlaybackState != E_PLAYBACK_STATE_FASTBACKWARD)   )
    {
        return 0;
    }
  //printf("MApp_Playback_GetRecordEndTimeSec \n");

    /*[02-1]set pvr record path =======================================================*/
    u32EndTime = _pstPvrRecordPath->u32RecordedTime/1000 +        //in 1/1000 SECOND
                 _pstPvrRecordPath->u32RecordedPeriod/10 -        //in 1/10   SECOND
                 _pstPvrRecordPath->u32PausedPeriod/10;           //in 1/10   SECOND

    return u32EndTime;

    /*[02-2]set audio/scaler/video ====================================================*/



    /*[03]change state ================================================================*/


}

/***************************************************************************************/
U32 MApp_Playback_GetRecordValidPeriodSec(void)
{
    U32 u32ValidPeriod = 0;

    /*[01]error condition =============================================================*/
    if ((_enPlaybackState != E_PLAYBACK_STATE_PLAYBACKING ) &&
        (_enPlaybackState != E_PLAYBACK_STATE_PAUSE       ) &&
        (_enPlaybackState != E_PLAYBACK_STATE_FASTFORWARD ) &&
        (_enPlaybackState != E_PLAYBACK_STATE_FASTBACKWARD)   )
    {
        return 0;
    }
  //printf("MApp_Playback_GetRecordValidPeriodSec \n");

    /*[02-1]set pvr record path =======================================================*/
    u32ValidPeriod = _pstPvrRecordPath->u32RecordedPeriod/10 -
                     _pstPvrRecordPath->u32PausedPeriod/10;

    return u32ValidPeriod;

    /*[02-2]set audio/scaler/video ====================================================*/



    /*[03]change state ================================================================*/


}

/***************************************************************************************/
U32 MApp_Playback_GetPlaybackTimeSec(void)
{
    U32 u32PlayTime;

    /*[01]error condition =============================================================*/
    if ((_enPlaybackState != E_PLAYBACK_STATE_PLAYBACKING ) &&
        (_enPlaybackState != E_PLAYBACK_STATE_PAUSE       ) &&
        (_enPlaybackState != E_PLAYBACK_STATE_FASTFORWARD ) &&
        (_enPlaybackState != E_PLAYBACK_STATE_FASTBACKWARD)   )
    {
        return 0;
    }
  //printf("MApp_Playback_GetPlaybackTimeSec \n");

    /*[02-1]set pvr playback path =====================================================*/
    if(((S32)_pstPvrPlaybackPath->u32PlayedPeriod) <=
       (_pstPvrPlaybackPath->s32JumpPeriod + (S32)_pstPvrPlaybackPath->u32PausedPeriod))
    {
        u32PlayTime = _pstPvrRecordPath->u32RecordedTime/1000;
    }

    //Special Treatment for Fast Forward when Bump End ================================//
    else if((_pstPvrRecordPath->u32RecordedPeriod != 0) &&  //not get record_info yet
            (((S32)_pstPvrPlaybackPath->u32PlayedPeriod -
             (_pstPvrPlaybackPath->s32JumpPeriod + (S32)_pstPvrPlaybackPath->u32PausedPeriod)) >= (S32)(_pstPvrRecordPath->u32RecordedPeriod-_pstPvrRecordPath->u32PausedPeriod)))
    {
        u32PlayTime = (_pstPvrRecordPath->u32RecordedTime/100 +
                      _pstPvrRecordPath->u32RecordedPeriod -
                      _pstPvrRecordPath->u32PausedPeriod)/10;
    }
    //Special Treatment for Fast Forward when Bump End ================================//

    else
    {
        u32PlayTime = (_pstPvrRecordPath->u32RecordedTime/100 +         //in 1/1000 SECOND
                      _pstPvrPlaybackPath->u32PlayedPeriod -         //in 1/10   SECOND
                      _pstPvrPlaybackPath->s32JumpPeriod   -         //in 1/10   SECOND
                      _pstPvrPlaybackPath->u32PausedPeriod)/10;          //in 1/10   SECOND
    }

    return u32PlayTime;

    /*[02-2]set audio/scaler/video ====================================================*/



    /*[03]change state ================================================================*/


}

/***************************************************************************************/
enPlaySpeed MApp_Playback_GetPlaybackSpeed(void)
{
    /*[01]error condition =============================================================*/
    if ((_enPlaybackState != E_PLAYBACK_STATE_PLAYBACKING ) &&
        (_enPlaybackState != E_PLAYBACK_STATE_PAUSE       ) &&
        (_enPlaybackState != E_PLAYBACK_STATE_FASTFORWARD ) &&
        (_enPlaybackState != E_PLAYBACK_STATE_FASTBACKWARD)   )
    {
        return E_PLAY_SPEED_1X;
    }
  //printf("MApp_Playback_GetPlaybackSpeed \n");

    /*[02-1]set pvr playback path =====================================================*/
    return _enPlaybackSpeed;

    /*[02-2]set audio/scaler/video ====================================================*/



    /*[03]change state ================================================================*/


}

/***************************************************************************************/
U16 MApp_Playback_GetAvgPlaybackRateKB(void)
{
    /*[01]error condition =============================================================*/
    if ((_enPlaybackState != E_PLAYBACK_STATE_PLAYBACKING ) &&
        (_enPlaybackState != E_PLAYBACK_STATE_PAUSE       ) &&
        (_enPlaybackState != E_PLAYBACK_STATE_FASTFORWARD ) &&
        (_enPlaybackState != E_PLAYBACK_STATE_FASTBACKWARD)   )
    {
        return 0;
    }
  //printf("MApp_Playback_GetAvgPlaybackRateKB \n");

    /*[02-1]set pvr playback path =====================================================*/
    return _pstPvrPlaybackPath->u16PlayedAvgRate;

    /*[02-2]set audio/scaler/video ====================================================*/



    /*[03]change state ================================================================*/


}

/***************************************************************************************/

/*###############################################################################################*/
/*////////////////////////////// playback ap (link to record) ///////////////////////////////////*/
/*###############################################################################################*/

/***************************************************************************************/
BOOLEAN MApp_Playback_StopRecordLinkage(void)
{
    if(_enPlaybackState != E_PLAYBACK_STATE_WAIT)
    {
        _pstPvrPlaybackPath->bLinkRecord = FALSE;
      //printf("StopRecordLinkage \n");
        return TRUE;
    }
    return FALSE;
}

/***************************************************************************************/

/*###############################################################################################*/
/*////////////////////////////// playback ap (link to audio) ///////////////////////////////////*/
/*###############################################################################################*/

/***************************************************************************************/
U8 MApp_Playback_AudioGetLanguageSelection(void)
{
    return _pstPvrRecordPath->u8audioLangSel;
}

/***************************************************************************************/
U8 MApp_Playback_AudioGetLanguageTotal(void)
{
    return _pstPvrRecordPath->u8audioLangTotal;
}

/***************************************************************************************/
BYTE MApp_Playback_AudioGetLanguageInfo(void)
{
    return  _pstPvrRecordPath->PVRAudioInfo[g_u8AudLangSelected].aISOLangInfo[0].bISOLanguageInfo;
}

/***************************************************************************************/
BOOLEAN MApp_Playback_AudioGetStreamInfo(AUD_INFO* pstAudioStreamInfo, U8 u8Idx)
{
    if (u8Idx < _pstPvrRecordPath->u8audioLangTotal)
    {
        memcpy(pstAudioStreamInfo, &_pstPvrRecordPath->PVRAudioInfo[u8Idx], sizeof(_pstPvrRecordPath->PVRAudioInfo[u8Idx]));
        return TRUE;
    }
    else
        return FALSE;
}

/***************************************************************************************/
void MApp_Playback_AudioSelectLanguage(U8 u8AudSelectedIndex)
{
    msAPI_PVR_PlaybackPathAddPID(_pstPvrPlaybackPath, _pstPvrRecordPath->PVRAudioInfo[u8AudSelectedIndex].wAudPID, MSAPI_DMX_FILTER_TYPE_AUDIO);
}

/***************************************************************************************/
void MApp_Playback_AudioStopLanguage(U8 u8AudSelectedIndex)
{
    msAPI_PVR_PlaybackPathDelPID(_pstPvrPlaybackPath, _pstPvrRecordPath->PVRAudioInfo[u8AudSelectedIndex].wAudPID, MSAPI_DMX_FILTER_TYPE_AUDIO);
}

/***************************************************************************************/
#ifndef S3PLUS
void MApp_Playback_AdAudioSelectLanguage(U8 u8AudSelectedIndex)
{
    msAPI_PVR_PlaybackPathAddPID(_pstPvrPlaybackPath, _pstPvrRecordPath->PVRAudioInfo[u8AudSelectedIndex].wAudPID, MSAPI_DMX_FILTER_TYPE_AUDIO2);
}

/***************************************************************************************/
void MApp_Playback_AdAudioStopLanguage(U8 u8AudSelectedIndex)
{
    msAPI_PVR_PlaybackPathDelPID(_pstPvrPlaybackPath, _pstPvrRecordPath->PVRAudioInfo[u8AudSelectedIndex].wAudPID, MSAPI_DMX_FILTER_TYPE_AUDIO2);
}
#endif
/***************************************************************************************/

/*###############################################################################################*/
/*///////////////////////////// playback ap (link to subtitle) //////////////////////////////////*/
/*###############################################################################################*/

/***************************************************************************************/
void MApp_Playback_Subtitle_LoadServices(U8* pu8SelIdx, U8* pu8Num, DVB_SUBTITLE_SERVICE* options)
{
    *pu8Num    = _pstPvrRecordPath->u8DVBSubtitleServiceNum;
    *pu8SelIdx = _pstPvrRecordPath->u8SubtitleMenuSelectedIdx;
    memcpy(options, _pstPvrRecordPath->PVRDVBSubtitleServices, sizeof(_pstPvrRecordPath->PVRDVBSubtitleServices));
}

/***************************************************************************************/
void MApp_Playback_Subtitle_LoadMenu(U8* pu8SelIdx, U8* pu8Num, SUBTITLE_MENU* options, U8* pu8fEnableSubtitle, U8* pu8fEnableTTXSubtitle)
{
    *pu8Num    = _pstPvrRecordPath->u8SubtitleMenuNum;
    *pu8SelIdx = _pstPvrRecordPath->u8SubtitleMenuSelectedIdx;
    memcpy(options, _pstPvrRecordPath->PVRSubtitleMenu, sizeof(_pstPvrRecordPath->PVRSubtitleMenu));
    *pu8fEnableSubtitle    = _pstPvrRecordPath->u8EnableSubtitle;
    *pu8fEnableTTXSubtitle = _pstPvrRecordPath->u8EnableTTXSubtitle;
}

/***************************************************************************************/
void MApp_Playback_TTXSubtitle_GetNum(U8* pu8Num)
{
    *pu8Num =_pstPvrRecordPath->u8TTXSubtitleServiceNum;
}

/***************************************************************************************/

/*###############################################################################################*/
/*////////////////////////////////// playback ap (AB Loop) //////////////////////////////////////*/
/*###############################################################################################*/

/***************************************************************************************/
void MApp_Playback_ABLoop_SetA(void)
{
    if(_enPlaybackState != E_PLAYBACK_STATE_WAIT)
    {
        _pstPvrPlaybackPath->u32FilePosAKB = _pstPvrPlaybackPath->u32FilePositionKB;
        if(_pstPvrPlaybackPath->u32FilePosAKB > _pstPvrPlaybackPath->u32GapLengthExtKB)
        {
            #define READ_LENGTH_UNIT        3       //3K
            #define ALIGNLENGTHUNIT(x)      ((x/READ_LENGTH_UNIT)*READ_LENGTH_UNIT)
            _pstPvrPlaybackPath->u32FilePosAKB -= ALIGNLENGTHUNIT(_pstPvrPlaybackPath->u32GapLengthExtKB);
        }
    }
}

/***************************************************************************************/
void MApp_Playback_ABLoop_SetB(void)
{
    if(_enPlaybackState != E_PLAYBACK_STATE_WAIT)
    {
        _pstPvrPlaybackPath->bABLoopSwitch = TRUE;
    }
}

/***************************************************************************************/
void MApp_Playback_ABLoop_Off(void)
{
    if(_enPlaybackState != E_PLAYBACK_STATE_WAIT)
    {
        if(_pstPvrPlaybackPath != NULL)
        {
            _pstPvrPlaybackPath->bABLoopSwitch = FALSE;
        }
    }
}

/***************************************************************************************/

/*###############################################################################################*/
/*/////////////////////////// playback ap (finite state machine) ////////////////////////////////*/
/*###############################################################################################*/

/***************************************************************************************/

static void MApp_Playback_StateMachineTimeCalibration(U8 u8CaliMode)
{
    U32 u32RightAroundDistance;
    U32 u32LeftAroundDistance;
    U32 u32RightActualDistance;
    U32 u32LeftActualDistance;

    if (_pstPvrPlaybackPath->u16PlayedAvgRate == 0)
        return;
    /*[00]re-sync =====================================================================*/
    _pstPvrPlaybackPath->u32PlayedPeriod  = msAPI_Timer_DiffTimeFromNow(_pstPvrPlaybackPath->u32PlayedTime)/100;  //[$$02$$]sync play period                //#(1)

    /*[01]calculate left/right distance ===============================================*/
    if(MApp_Playback_GetRecordEndTimeSec() > MApp_Playback_GetPlaybackTimeSec())
    {
        u32RightAroundDistance = (MApp_Playback_GetRecordEndTimeSec() - MApp_Playback_GetPlaybackTimeSec()   )*_pstPvrPlaybackPath->u16PlayedAvgRate;
    }
    else
    {
        u32RightAroundDistance = 0;
    }
    if(MApp_Playback_GetPlaybackTimeSec() > MApp_Playback_GetRecordStartTimeSec())
    {
        u32LeftAroundDistance  = (MApp_Playback_GetPlaybackTimeSec()  - MApp_Playback_GetRecordStartTimeSec())*_pstPvrPlaybackPath->u16PlayedAvgRate;
    }
    else
    {
        u32LeftAroundDistance  = 0;
    }

    /*[02-1][START | END]==============================================================*/
    if(_pstPvrPlaybackPath->u32FileValidPosEndKB > _pstPvrPlaybackPath->u32FileValidPosStrKB)
    {
        if(_pstPvrPlaybackPath->u32FileValidPosEndKB > _pstPvrPlaybackPath->u32FilePositionKB)
        {
            u32RightActualDistance = _pstPvrPlaybackPath->u32FileValidPosEndKB-_pstPvrPlaybackPath->u32FilePositionKB;
        }
        else
        {
            u32RightActualDistance = 0;
        }

        if(_pstPvrPlaybackPath->u32FilePositionKB > _pstPvrPlaybackPath->u32FileValidPosStrKB)
        {
            u32LeftActualDistance  = _pstPvrPlaybackPath->u32FilePositionKB   - _pstPvrPlaybackPath->u32FileValidPosStrKB;
        }
        else
        {
            u32LeftActualDistance = 0;
        }
    }

    /*[02-2][END | START]==============================================================*/
    else
    {
        /*[END | START | POS]==========================================================*/
        if(_pstPvrPlaybackPath->u32FilePositionKB > _pstPvrPlaybackPath->u32FileValidPosEndKB)
        {
            u32RightActualDistance = _pstPvrPlaybackPath->u32FileLimitedSizeKB - _pstPvrPlaybackPath->u32FilePositionKB + _pstPvrPlaybackPath->u32FileValidPosEndKB - PVR_MAX_PROGRAMME_PER_FILE * META_DATA_SIZE/1024;

            if(_pstPvrPlaybackPath->u32FilePositionKB > _pstPvrPlaybackPath->u32FileValidPosStrKB)
            {
                u32LeftActualDistance  = _pstPvrPlaybackPath->u32FilePositionKB   - _pstPvrPlaybackPath->u32FileValidPosStrKB;
            }
            else
            {
                u32LeftActualDistance = 0;
            }
        }

        /*[POS | END | START]==========================================================*/
        else
        {
            if(_pstPvrPlaybackPath->u32FileValidPosEndKB > _pstPvrPlaybackPath->u32FilePositionKB)
            {
                u32RightActualDistance = _pstPvrPlaybackPath->u32FileValidPosEndKB-_pstPvrPlaybackPath->u32FilePositionKB;
            }
            else
            {
                u32RightActualDistance = 0;
            }

            u32LeftActualDistance  = _pstPvrPlaybackPath->u32FilePositionKB - PVR_MAX_PROGRAMME_PER_FILE * META_DATA_SIZE/1024 + _pstPvrPlaybackPath->u32FileLimitedSizeKB - _pstPvrPlaybackPath->u32FileValidPosStrKB;
        }
    }

    /*[03]start calibration ===========================================================*/
    if(u32LeftAroundDistance > u32LeftActualDistance)
    {
        if(u32RightAroundDistance > u32RightActualDistance)
        {
            #if 0   //=================
            printf("###LEFT: %08lu / %08lu /  %08lu( %02lu s) || %08lu / %08lu / -%08lu(-%02lu s) :RIGHT###\n",
                    u32LeftAroundDistance, u32LeftActualDistance, u32LeftAroundDistance - u32LeftActualDistance, (u32LeftAroundDistance - u32LeftActualDistance)/_pstPvrPlaybackPath->u16PlayedAvgRate,
                    u32RightAroundDistance, u32RightActualDistance, u32RightAroundDistance - u32RightActualDistance, (u32RightAroundDistance -u32RightActualDistance)/ _pstPvrPlaybackPath->u16PlayedAvgRate);
            #endif  //=================
        }
        else
        {
            #if 0   //=================
            printf("###LEFT: %08lu / %08lu /  %08lu( %02lu s) || %08lu / %08lu / -%08lu(-%02lu s) :RIGHT###\n",
                    u32LeftAroundDistance, u32LeftActualDistance, u32LeftAroundDistance - u32LeftActualDistance, (u32LeftAroundDistance - u32LeftActualDistance)/_pstPvrPlaybackPath->u16PlayedAvgRate,
                    u32RightAroundDistance, u32RightActualDistance, u32RightActualDistance - u32RightAroundDistance, (u32RightActualDistance - u32RightAroundDistance)/ _pstPvrPlaybackPath->u16PlayedAvgRate);
            #endif  //=================

            if((u32RightActualDistance - u32RightAroundDistance) >= _pstPvrPlaybackPath->u32GapLengthExtKB)
            {
                if(u8CaliMode == TIME_CALIBRATION_MICRO)
                {
                    _pstPvrPlaybackPath->s32JumpPeriod +=1;  //<---Calibration+++                                                                           //#(3)
                }
                else //if(u8CaliMode == TIME_CALIBRATION_MACRO)
                {
                    _pstPvrPlaybackPath->s32JumpPeriod += (u32RightActualDistance - u32RightAroundDistance)*10/_pstPvrPlaybackPath->u16PlayedAvgRate;       //#(3)
                }
            }
        }
    }
    else
    {
        if(u32RightAroundDistance > u32RightActualDistance)
        {
            #if 0   //=================
            printf("###LEFT: %08lu / %08lu / -%08lu(-%02lu s) || %08lu / %08lu /  %08lu( %02lu s) :RIGHT###\n",
                    u32LeftAroundDistance, u32LeftActualDistance, u32LeftActualDistance - u32LeftAroundDistance, (u32LeftActualDistance - u32LeftAroundDistance)/_pstPvrPlaybackPath->u16PlayedAvgRate,
                    u32RightAroundDistance, u32RightActualDistance, u32RightAroundDistance - u32RightActualDistance, (u32RightAroundDistance - u32RightActualDistance)/ _pstPvrPlaybackPath->u16PlayedAvgRate);
            #endif  //=================

            if((u32RightAroundDistance - u32RightActualDistance) >= _pstPvrPlaybackPath->u32GapLengthExtKB)
            {
                if(u8CaliMode == TIME_CALIBRATION_MICRO)
                {
                    _pstPvrPlaybackPath->s32JumpPeriod -=1;  //<---Calibration---                                                                           //#(3)
                }
                else //if(u8CaliMode == TIME_CALIBRATION_MACRO)
                {
                    _pstPvrPlaybackPath->s32JumpPeriod -= (u32RightAroundDistance - u32RightActualDistance)*10/_pstPvrPlaybackPath->u16PlayedAvgRate;       //#(3)
                }
            }
        }
        else
        {
            #if 0   //=================
            printf("###LEFT: %08lu / %08lu / -%08lu(-%02lu s) || %08lu / %08lu /  %08lu( %02lu s) :RIGHT###\n",
                    u32LeftAroundDistance, u32LeftActualDistance, u32LeftActualDistance - u32LeftAroundDistance, (u32LeftActualDistance - u32LeftAroundDistance)/_pstPvrPlaybackPath->u16PlayedAvgRate,
                    u32RightAroundDistance, u32RightActualDistance, u32RightActualDistance - u32RightAroundDistance, (u32RightActualDistance - u32RightAroundDistance)/ _pstPvrPlaybackPath->u16PlayedAvgRate);
            #endif  //=================
        }
    }
}

/***************************************************************************************/
void MApp_Playback_StateMachineRunning(void)
{
    #if DEBUG_PLAYBACK_STATE  //=======================================================//
    {
        static U8 preState = 0xFF;
        if(preState != _enPlaybackState)
        {
            //printf("Playback [%d]->[%d]\n", (int)preState, (int)_enPlaybackState);
            preState = _enPlaybackState;
        }
    }
    #endif  //=========================================================================//

    switch (_enPlaybackState)
    {
        /*[01]WAIT state (channel change) =============================================*/
        case E_PLAYBACK_STATE_WAIT:
        {
            if(_enPlaybackInput == E_PLAYBACK_INPUT_PLAYBACK_OPEN)
            {
                #ifdef PVR_8051
                U16   u16PlaybackExtPara        = (U16        )_u32PlaybackExtPara;   //type casting
                U16 xdata * pu16PlaybackExtPara = (U16 xdata *) u16PlaybackExtPara;   //typp casting
                #else
                U16 * pu16PlaybackExtPara       = (U16       *)_u32PlaybackExtPara;   //typp casting
                #endif

                if(!MApp_Playback_Open(pu16PlaybackExtPara))
                {
                    //printf("STCH[[PLAYBACK]]@WAIT->WAIT\n");
                    _enPlaybackState = E_PLAYBACK_STATE_WAIT;                   //<--exception-1
                    _enPlaybackInput = E_PLAYBACK_INPUT_NONE;
                    break;
                }
                MApp_Playback_Pause(E_PLAYBACK_NEXTACT_ENABLE);
                if(MApp_Playback_Enable())
                {
                    MApp_Playback_Resume();
                    //printf("STCH[[PLAYBACK]]@WAIT->PLAYBACKING\n");
                    _enPlaybackState = E_PLAYBACK_STATE_PLAYBACKING;
                    _enPlaybackInput = E_PLAYBACK_INPUT_NONE;
                }
                else
                {
                    MApp_Playback_Resume();
                    //printf("STCH[[PLAYBACK]]@WAIT->E_PLAYBACK_STATE_WAIT\n");
                    _enPlaybackState = E_PLAYBACK_STATE_WAIT;
                    _enPlaybackInput = E_PLAYBACK_INPUT_NONE;
                }
            }
            else if(_enPlaybackInput != E_PLAYBACK_INPUT_NONE)
            {
                MS_DEBUG_MSG(printf("ERROR_INPUT_TO_WAIT\n"));
                _enPlaybackInput = E_PLAYBACK_INPUT_NONE;
            }

            break;
        }

        case E_PLAYBACK_STATE_OPEN:
            break;

        /*[02]PLAYBACKING state =========================================================*/
        case E_PLAYBACK_STATE_PLAYBACKING:
        case E_PLAYBACK_STATE_PAUSE:
        case E_PLAYBACK_STATE_FASTFORWARD:
        case E_PLAYBACK_STATE_FASTBACKWARD:
        {
            /*[02-1]playback on/off =====================================================*/
            if(_enPlaybackInput == E_PLAYBACK_INPUT_PLAYBACK_CLOSE)
            {
                msAPI_PVR_PlaybackPathWaitAVFifoClean();//reset CmdQ ,and wait AVFifo clean to prevent TSP from going in the block state
                MApp_Playback_Pause(E_PLAYBACK_NEXTACT_RESUME);
                MApp_Playback_Resume();
                MApp_Playback_Disable();
                MApp_Playback_Close();
              //printf("STCH[[PLAYBACK]]@PLAYBACKING->WAIT\n");
                _enPlaybackState = E_PLAYBACK_STATE_WAIT;
                _enPlaybackInput = E_PLAYBACK_INPUT_NONE;
            }
            else if(_enPlaybackInput == E_PLAYBACK_INPUT_PLAYBACK_PAUSE)
            {
                MApp_Playback_Pause(E_PLAYBACK_NEXTACT_NONE);
                _enPlaybackState = E_PLAYBACK_STATE_PAUSE;
                _enPlaybackInput = E_PLAYBACK_INPUT_NONE;
            }
            else if(_enPlaybackInput == E_PLAYBACK_INPUT_PLAYBACK_JUMP_FORWARD)
            {
                //msAPI_PVR_ClearBitStreamBuff(_pstPvrPlaybackPath);
                MApp_Playback_Pause(E_PLAYBACK_NEXTACT_JUMPFORWARD);
                if(!MApp_Playback_JumpForward(_u32PlaybackExtPara))
                {
                    MApp_Playback_Resume();
                    MApp_Playback_Disable();
                    MApp_Playback_Close();
                  //printf("STCH[[PLAYBACK]]@PLAYBACKING->STOP\n");
                    _enPlaybackState = E_PLAYBACK_STATE_STOP;
                    _enPlaybackInput = E_PLAYBACK_INPUT_NONE;
                }
                else
                {
                    MApp_Playback_Resume();
                    _enPlaybackInput = E_PLAYBACK_INPUT_NONE;
                }
            }
            else if(_enPlaybackInput == E_PLAYBACK_INPUT_PLAYBACK_JUMP_BACKWARD)
            {
                MApp_Playback_Pause(E_PLAYBACK_NEXTACT_JUMPBACKWARD);
                MApp_Playback_JumpBackward(_u32PlaybackExtPara);
                MApp_Playback_Resume();
                _enPlaybackInput = E_PLAYBACK_INPUT_NONE;
            }
            else if(_enPlaybackInput == E_PLAYBACK_INPUT_PLAYBACK_FAST_FORWARD)
            {
                MApp_Playback_Pause(E_PLAYBACK_NEXTACT_FASTFORWARD);
                MApp_Playback_FastForward();
                _enPlaybackInput = E_PLAYBACK_INPUT_NONE;
            }
            else if(_enPlaybackInput == E_PLAYBACK_INPUT_PLAYBACK_FAST_BACKWARD)
            {
                MApp_Playback_Pause(E_PLAYBACK_NEXTACT_FASTBACKWARD);
                MApp_Playback_FastBackward();
                _enPlaybackInput = E_PLAYBACK_INPUT_NONE;
            }
            else if(_enPlaybackInput == E_PLAYBACK_INPUT_PLAYBACK_RESUME)
            {
                MApp_Playback_Pause(E_PLAYBACK_NEXTACT_RESUME);  //fast forward / fast backward
                MApp_Playback_Resume();
                _enPlaybackState = E_PLAYBACK_STATE_PLAYBACKING;
                _enPlaybackInput = E_PLAYBACK_INPUT_NONE;

                #if 1   //TIME CALIBRATION ============================================//
                MApp_Playback_Routine();        //[$$01$$]record/playback sync
                MApp_Playback_StateMachineTimeCalibration(TIME_CALIBRATION_MACRO);
                #endif  //TIME CALIBRATION ============================================//
            }
            else if(_enPlaybackInput != E_PLAYBACK_INPUT_NONE)
            {
                MS_DEBUG_MSG(printf("ERROR_INPUT_TO_PLAYBACKING\n"));
                _enPlaybackInput = E_PLAYBACK_INPUT_NONE;
            }

            /*[02-2]playback running ====================================================*/
            if(!MApp_Playback_Routine())
            {
                if(_enPlaybackStatus != E_PVR_API_STATUS_PLAYBACK_NO_OUTPUT)    //wait data runout
                {
                    msAPI_PVR_PlaybackPathWaitAVFifoClean();////reset CmdQ ,and wait AVFifo clean to prevent TSP from going in the block state
                    MApp_Playback_Pause(E_PLAYBACK_NEXTACT_RESUME);
                    MApp_Playback_Resume();
                    MApp_Playback_Disable();
                  //printf("STCH[[PLAYBACK]]@PLAYBACKING->STOP\n");
                    _enPlaybackState = E_PLAYBACK_STATE_STOP;                   //<--exception-2
                    _enPlaybackInput = E_PLAYBACK_INPUT_NONE;
                }
            }

            #if 1 //AP LAYER MONITORING ===============================================//
            {
                static U32 u32TimerToDisplay = 0;
                if(msAPI_Timer_DiffTimeFromNow(u32TimerToDisplay)>=1000)
                {
                    #if 0   //DISPLAY TIME ============================================//
                    printf("########################################\n");
                    printf("###[%10lu|%10lu|%10lu]###\n", MApp_Playback_GetRecordStartTimeSec(),
                                                          MApp_Playback_GetPlaybackTimeSec(),
                                                          MApp_Playback_GetRecordEndTimeSec());
                    printf("########################################\n");
                    #endif  //DISPLAY TIME ============================================//

                    #if 0   //TIME CALIBRATION ========================================//
                    if(_enPlaybackState == E_PLAYBACK_STATE_PLAYBACKING)
                    {
                        MApp_Playback_StateMachineTimeCalibration(TIME_CALIBRATION_MICRO);
                    }
                    #endif  //TIME CALIBRATION ========================================//

                    u32TimerToDisplay = msAPI_Timer_GetTime0();
                }
            }
            #endif //AP LAYER MONITORING ==============================================//

            break;
        }

        /*[03]STOP state ==============================================================*/
        case E_PLAYBACK_STATE_STOP:
        {
            /*[03-1]playback on/off =====================================================*/
            if(_enPlaybackInput == E_PLAYBACK_INPUT_PLAYBACK_CLOSE)
            {
                MApp_Playback_Close();
              //printf("STCH[[PLAYBACK]]@STOP->WAIT\n");
                _enPlaybackState = E_PLAYBACK_STATE_WAIT;
                _enPlaybackInput = E_PLAYBACK_INPUT_NONE;
            }
            else if(_enPlaybackInput != E_PLAYBACK_INPUT_NONE)
            {
                MS_DEBUG_MSG(printf("ERROR_INPUT_TO_STOP\n"));
                _enPlaybackInput = E_PLAYBACK_INPUT_NONE;
            }
            break;
        }
    }
}

/***************************************************************************************/
void MApp_Playback_StateMachineInput(enPlaybackInput enSMInput, U32 u32ExtParameter)
{
    _enPlaybackInput    = enSMInput;
    _u32PlaybackExtPara = u32ExtParameter;

    switch (_enPlaybackInput)
    {
        //(1)playback open ============================================================//
        case E_PLAYBACK_INPUT_PLAYBACK_OPEN:
        {
          //printf("E_PLAYBACK_INPUT_PLAYBACK_OPEN\n");
            break;
        }

        //(2)playback pause ===========================================================//
        case E_PLAYBACK_INPUT_PLAYBACK_PAUSE:
        {
          //printf("E_PLAYBACK_INPUT_PLAYBACK_PAUSE\n");
            break;
        }

        //(3)playback resume ==========================================================//
        case E_PLAYBACK_INPUT_PLAYBACK_RESUME:
        {
          //printf("E_PLAYBACK_INPUT_PLAYBACK_RESUME\n");
            break;
        }

        //(4)jump forward =============================================================//
        case E_PLAYBACK_INPUT_PLAYBACK_JUMP_FORWARD:
        {
          //printf("E_PLAYBACK_INPUT_PLAYBACK_JUMP_FORWARD\n");
            break;
        }

        //(5)jump backward ===========================================================//
        case E_PLAYBACK_INPUT_PLAYBACK_JUMP_BACKWARD:
        {
          //printf("E_PLAYBACK_INPUT_PLAYBACK_JUMP_BACKWARD\n");
            break;
        }

        //(6)fast forward =============================================================//
        case E_PLAYBACK_INPUT_PLAYBACK_FAST_FORWARD:
        {
          //printf("E_PLAYBACK_INPUT_PLAYBACK_FAST_FORWARD\n");
            break;
        }

        //(7)fast backward ===========================================================//
        case E_PLAYBACK_INPUT_PLAYBACK_FAST_BACKWARD:
        {
          //printf("E_PLAYBACK_INPUT_PLAYBACK_FAST_BACKWARD\n");
            break;
        }

        //(8)playback close ===========================================================//
        case E_PLAYBACK_INPUT_PLAYBACK_CLOSE:
        {
          //printf("E_PLAYBACK_INPUT_PLAYBACK_CLOSE\n");
            break;
        }

        //(0)default ==================================================================//
        default:
        {
          //printf("MApp_Playback Unknown Input: %x\n", enSMInput);
            break;
        }

        //=============================================================================//
    }

    MApp_Playback_StateMachineRunning();

    _enPlaybackInput    = E_PLAYBACK_INPUT_NONE;    //ensure to consume any input
    _u32PlaybackExtPara = 0;                        //ensure to consume any parameter

}

/***************************************************************************************/
enPlaybackState MApp_Playback_StateMachineGet(void)
{
    return _enPlaybackState;
}

/***************************************************************************************/
enPvrApiStatus  MApp_Playback_StatusGet(void)
{
    enPvrApiStatus enPlaybackStatus = _enPlaybackStatus;
    _enPlaybackStatus = E_PVR_API_STATUS_OK;    //read clear
    return enPlaybackStatus;
}

/***************************************************************************************/


#else
BOOLEAN code compile_mapp_playback;
#endif//ENABLE_PVR
#undef MAPP_PLAYBACK_C
