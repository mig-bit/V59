////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (MStar Confidential Information) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
/// @file   drvdma.c
/// @brief  DRAM BDMA control driver
/// @author MStar Semiconductor Inc.
///
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
// Include List
////////////////////////////////////////////////////////////////////////////////
#include "drvGlobal.h"
#include "Board.h"
#include "SW_Config.h"
#include "default_option_define.h"
#include "SysInit.h"
#include "debug.h"

#include "msAPI_DrvInit.h"
#include "msAPI_Flash.h"
#include "msAPI_BDMA.h"
#include "ms_decompress.h"
#include "MsCommon.h"
#include "msAPI_Global.h"
#include "msAPI_Timer.h"

#include "Utl.h"

#ifdef MSOS_TYPE_LINUX
#include <stdlib.h>
#endif
#if defined(MIPS_CHAKRA)
#include <stdlib.h>
#endif
////////////////////////////////////////////////////////////////////////////////
// Local defines & local structures
////////////////////////////////////////////////////////////////////////////////
#define DECOMPRESS_BLOCK_SIZE   (32*1024)

////////////////////////////////////////////////////////////////////////////////
// Local Global Variables
////////////////////////////////////////////////////////////////////////////////
static BOOLEAN bMIU_XCopy_FWStatus = FALSE; /* TRUE: Nand Flash; FALSE: SPI Flash; */

////////////////////////////////////////////////////////////////////////////////
// External Funciton
////////////////////////////////////////////////////////////////////////////////
//extern void mhal_dcache_flush(U32 u32Base, U32 u32Size);

////////////////////////////////////////////////////////////////////////////////
// Global Funciton
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/// @brief \b Function \b Name: _MApi_BDMA_Convert_Type()
/// @brief \b Function \b Description : convert type to bdma copy type
/// @param <IN>        \b eType       : MEMCOPYTYPE
/// @param <OUT>       \b None :
/// @param <RET>       \b BDMA_CpyType : BDMA copy type
/// @param <GLOBAL>    \b None        :
////////////////////////////////////////////////////////////////////////////////
static BDMA_CpyType _MApi_BDMA_Convert_Type(MEMCOPYTYPE eType)
{
    switch(eType)
    {
    case MIU_FLASH2SDRAM:
        return E_BDMA_FLASH2SDRAM;

    case MIU_SDRAM2SRAM:
        return E_BDMA_SDRAM2SRAM1K_HK51;

    case MIU_SDRAM2SDRAM:
    case MIU_SDRAM2SDRAM_I:
        return E_BDMA_SDRAM2SDRAM;

    case MIU_SDRAM02SDRAM1:
        return E_BDMA_SDRAM2SDRAM1;

    case MIU_SDRAM12SDRAM0:
        return E_BDMA_SDRAM12SDRAM;

    case MIU_SDRAM12SDRAM1:
        return E_BDMA_SDRAM12SDRAM1;

    case MIU_FLASH2VDMCU:
        return E_BDMA_FLASH2VDMCU;

    default:
        return E_BDMA_CPYTYPE_MAX;
    }

}

////////////////////////////////////////////////////////////////////////////////
/// @brief \b Function \b Name: MApi_BDMA_XCopySetFWStatus()
/// @brief \b Function \b Description : Set MIU XCOPY F/W Source Status
/// @param <IN>        \b bFWStatus   : F/W source status
///                                      - -TRUE:   F/W is on Nand Flash
///                                      - -FALSE:  F/W is on SPI Flash
/// @param <OUT>       \b None    :
/// @param <RET>       \b None    :
/// @param <GLOBAL>    \b None    :
////////////////////////////////////////////////////////////////////////////////
BDMA_Result MApi_BDMA_XCopySetFWStatus(BOOLEAN bFWStatus)
{
    bMIU_XCopy_FWStatus = bFWStatus;
    return E_BDMA_OK;
}

BOOL MApi_BDMA_XCopyGetFWStatus(void)
{
    return bMIU_XCopy_FWStatus;
}

////////////////////////////////////////////////////////////////////////////////
/// @brief \b Function \b Name: MApi_BDMA_Copy()
/// @brief \b Function \b Description : Get Specific Bin information
/// @param <IN>        \b None        :
/// @param <OUT>       \b pBinInfo    : Get Bin Information
/// @param <RET>       \b BOOL     : Success or Fail
/// @param <GLOBAL>    \b None        :
////////////////////////////////////////////////////////////////////////////////
BDMA_Result MApi_BDMA_Copy(MS_PHYADDR u32Srcaddr, MS_PHYADDR u32Dstaddr, U32 u32Len, MEMCOPYTYPE eType)
{
    U8 u8OpCfg = (MIU_SDRAM2SDRAM_I == eType) ? BDMA_OPCFG_INV_COPY : BDMA_OPCFG_DEF;

    switch( eType )
    {
        case MIU_FLASH2SDRAM:
            MDrv_SERFLASH_CopyHnd(u32Srcaddr, u32Dstaddr, u32Len, E_SPIDMA_DEV_MIU0, SPIDMA_OPCFG_DEF);
            break;
        case MIU_FLASH2VDMCU:
            MDrv_SERFLASH_CopyHnd(u32Srcaddr, u32Dstaddr, u32Len, E_SPIDMA_DEV_VDMCU, SPIDMA_OPCFG_DEF);
            break;
        default:
            MDrv_BDMA_CopyHnd(u32Srcaddr, u32Dstaddr, u32Len, _MApi_BDMA_Convert_Type(eType), u8OpCfg);
            break;
    }
    return E_BDMA_OK;
}

////////////////////////////////////////////////////////////////////////////////
/// @brief \b Function \b Name: MApi_BDMA_XCopy
/// @brief \b Function \b Description : Memory copy for specific operation
/// @param <IN>        \b type    : Memory copy operation type
/// @param <IN>        \b u32Srcaddr : Source address
/// @param <IN>        \b u32Dstaddr : Destination address
/// @param <IN>        \b u32Len     : Length of data
/// @param <OUT>       \b None    :
/// @param <RET>       \b None    :
/// @param <GLOBAL>    \b None    :
////////////////////////////////////////////////////////////////////////////////
BDMA_Result MApi_BDMA_XCopy(MCPY_TYPE eType, U32 u32Srcaddr, U32 u32Dstaddr, U32 u32Len)
{
    switch (eType)
    {
    case MCPY_LOADFONT:
    case MCPY_LOADBITMAP:
        MApi_BDMA_CopyFromResource(u32Srcaddr,_PA2VA(u32Dstaddr),u32Len);
        break;

    case MCPY_LOADVDMCUFW:
        MApi_BDMA_Copy(u32Srcaddr, u32Dstaddr, u32Len, MIU_FLASH2VDMCU);
        break;

    case MCPY_LOADLOGO:
        MApi_BDMA_Copy(u32Srcaddr, u32Dstaddr, u32Len, MIU_FLASH2SDRAM);
        break;

    case MCPY_CCS:
        MApi_BDMA_Copy(u32Srcaddr, u32Dstaddr, u32Len, MIU_SDRAM2SDRAM);
        break;

    default:
        MS_DEBUG_MSG(printf("BDMA Xcopy not support:%u", eType));
        break;
    }
    return E_BDMA_OK;
}

BOOLEAN (*DoDecompressionFunc)(U8 *pSrc, U8 *pDst, U8 *pTmp, U32 srclen);

eRETCODE MDrv_DMA_LoadBin(BININFO *pBinInfo, U32 u32DstVA, U32 u32DecVA, U32 u32TmpVA)
{
    U32 u32BinLen;
    U32 u32BinAddr;
    #ifndef MSOS_TYPE_LINUX
    int i;
    #endif


    //if( pBinInfo->B_ID == BIN_ID_CODE_DEC_AUDIO
      //||pBinInfo->B_ID == BIN_ID_CODE_DEC_AUDIO_COMP )
      /*
    {
        printf("MDrv_DMA_LoadBin(u32DstVA=%lX, u32DecVA=%lX, u32TmpVA=%lX)\n", u32DstVA, u32DecVA, u32TmpVA);
        printf("BinId=%X, B_IsComp=%bu\n", pBinInfo->B_ID, pBinInfo->B_IsComp);
    }*/

    u32BinLen = pBinInfo->B_Len;
    u32BinAddr = pBinInfo->B_FAddr;

//20091127EL
    switch(pBinInfo->B_IsComp)
    {
    case LZSS_COMPRESS:

        // fixme: need to find a buffer to put compressed data => u32DecAddr

        #if (ENABLE_BOOTTIME)
             gU32CompressStepTime = msAPI_Timer_GetTime0();
        #endif

        MApi_BDMA_CopyFromResource(u32BinAddr,u32DecVA,u32BinLen);

        if (ms_DecompressInit((U8*)u32DstVA) == FALSE)
        {
            MS_DEBUG_MSG(printf("decompress fail!\n"));
            return FAILURE;
        }

        ms_Decompress((U8*)u32DecVA, u32BinLen);
        ms_DecompressDeInit();

        #if (ENABLE_BOOTTIME)
            gU32TmpTime = msAPI_Timer_DiffTimeFromNow(gU32CompressStepTime);
            gU32CompressTotalStepTime += gU32TmpTime;
            printf("[boot step time][Decompress time]Bin ID = %x, Decompress time = %ld\n", pBinInfo->B_ID, gU32TmpTime);
        #endif

        break;

    #ifndef MSOS_TYPE_LINUX
    case MS_COMPRESS:
    case MS_COMPRESS7:

        #if (ENABLE_BOOTTIME)
             gU32CompressStepTime = msAPI_Timer_GetTime0();
        #endif
        //printf("t1=%ld,", msAPI_Timer_GetTime0());

        MApi_BDMA_CopyFromResource(u32BinAddr,u32DecVA,u32BinLen);

        //search compressed file real length
        for(i=3;i<12;i++)
        {
            if ( *((U8 *)(u32DecVA+u32BinLen-i)) == 0xEF )
            {
                if ( *((U8 *)(u32DecVA+u32BinLen-i-1)) == 0xBE )
                    u32BinLen -= (i+1);
            }
        }

        // restore the real length of decompressed bin to Bininfo 20100108EL
        if ( pBinInfo->B_IsComp == MS_COMPRESS7 )
        {
            U32 OriginalFileLength = 0;

            DoDecompressionFunc = DoMsDecompression7;

            for (i = 0; i < 8; i++)
            OriginalFileLength += ( (U32)((U8 *)u32DecVA)[5 + i] << (i << 3) );

            pBinInfo->B_Len = OriginalFileLength;
        }
        else
        {
            DoDecompressionFunc = DoMsDecompression;
            memcpy(&(pBinInfo->B_Len), (void*)(u32DecVA+u32BinLen-4), 4);
            //printf("^^^G3^^^ pBinInfo->B_Len = %ld\n", pBinInfo->B_Len);
        }

        if ( !DoDecompressionFunc((U8 *)(u32DecVA & NON_CACHEABLE_TO_CACHEABLE_MASK), (U8 *)(u32DstVA & NON_CACHEABLE_TO_CACHEABLE_MASK), (U8 *)(u32TmpVA & NON_CACHEABLE_TO_CACHEABLE_MASK), u32BinLen) )
        {
            MS_DEBUG_MSG(printf("msdecompress fail!\n"));
            return FAILURE;
        }

        MsOS_Dcache_Flush((MS_U32)((u32DstVA & NON_CACHEABLE_TO_CACHEABLE_MASK) & (~15)),(MS_U32)((pBinInfo->B_Len+15) & (~15)));
        MsOS_FlushMemory();

        //printf("t2=%ld\n", msAPI_Timer_GetTime0());

        #if (ENABLE_BOOTTIME)
            gU32TmpTime = msAPI_Timer_DiffTimeFromNow(gU32CompressStepTime);
            gU32CompressTotalStepTime += gU32TmpTime;
            printf("[boot step time][Decompress time]Bin ID = %x, Decompress time = %ld\n", pBinInfo->B_ID, gU32TmpTime);
        #endif

        break;
  #endif // #ifndef MSOS_TYPE_LINUX

    default:    //no compressed bin
      #if (!BLOADER)
        if((pBinInfo->B_ID == BIN_ID_OSDCP_TEXT)
           ||(pBinInfo->B_ID == BIN_ID_CODE_DEC_AUDIO)
         #ifdef BIN_ID_CODE_SE_AUDIO
           || (pBinInfo->B_ID == BIN_ID_CODE_SE_AUDIO)
         #endif
         #ifdef BIN_ID_CODE_ADVSND_AUDIO
           || (pBinInfo->B_ID == BIN_ID_CODE_ADVSND_AUDIO)
         #endif
         #ifdef NON_COMPRESS_AUDIO_DSP
           ||(pBinInfo->B_ID == BIN_ID_CODE_DEC_AUDIO_UZIP)
           || (pBinInfo->B_ID == BIN_ID_CODE_SE_AUDIO_UZIP)
           || (pBinInfo->B_ID == BIN_ID_CODE_ADVSND_AUDIO_UZIP)
         #endif
           || (pBinInfo->B_ID == BIN_ID_CODE_AEON_MVD)
           || (pBinInfo->B_ID == BIN_ID_CODE_AEON_H264)  //20100422EL Add
         #ifdef BIN_ID_CODE_AUDIO_SRS
           || (pBinInfo->B_ID == BIN_ID_CODE_AUDIO_SRS)
         #endif
           || (pBinInfo->B_ID == FONT_MSTAR_UNICODE_MVF) )  //20100301EL
        {
            //printf("~~~~~~~~Do nothing at these bins !!\n");
        }
        else
            MApi_BDMA_CopyFromResource(u32BinAddr,u32DstVA,u32BinLen);
      #else
        MApi_BDMA_CopyFromResource(u32BinAddr,u32DstVA,u32BinLen);
      #endif
        break;
    }

    return SUCCESS;

}

eRETCODE MDrv_DMA_Copy(U32 u32Srcaddr, U32 u32Dstaddr, U32 u32Len, MEMCOPYTYPE eType)
{
    MApi_BDMA_Copy(u32Srcaddr, u32Dstaddr, u32Len, eType);
    return SUCCESS;
}

#ifdef MSOS_TYPE_LINUX
static char RES_FILE[]="/chakra/RES.bin";
#endif

eRETCODE MApi_BDMA_CopyFromResource(U32 offset,U32 destVA,U32 len)
{
    if(bMIU_XCopy_FWStatus)
    {
#ifdef MSOS_TYPE_LINUX
        extern BOOLEAN ReadFromFile(const char* fname,U32 offset,void* dest,U32 len);
//        printf("[CopyFromResource] from RES.bin 0x%08X to 0x%08X(VA)\n", offset, (U32)destVA);
        if(!ReadFromFile(RES_FILE,offset,(void *)destVA,len))
        {
            return FAILURE;
        }
#else
        //UNUSED(RES_FILE);
        MS_DEBUG_MSG(printf("ERROR: MApi_BDMA_CopyFromResource() has not yet implemented for No NAND system"));
        return FAILURE;
#endif
    }
    else
    {
        //printf("[CopyFromResource] from FLASH 0x%08X to 0x%08X(VA)\n", offset, (U32)destVA);
//      change to use msAPI_Flash_Read due to strange stuck problems when BDMA small amount of data
      //MApi_BDMA_Copy(offset, destVA, len, MIU_FLASH2SDRAM);
      msAPI_Flash_Read(offset, len, (U8 *)destVA);
    }
    return SUCCESS;
}
