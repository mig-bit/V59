////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#include "datatype.h"
#include "MApp_GlobalSettingSt.h"
#ifndef MAPP_BLOCKSYS_H
#define MAPP_BLOCKSYS_H

#ifdef MAPP_BLOCKSYS_C
#define INTERFACE
#else
#define INTERFACE extern
#endif

#define BLOCKSYS_CHECK_AV         BIT0
#define BLOCKSYS_CHECK_OSD        BIT1
#define BLOCKSYS_CHECK_NONE       0x00

INTERFACE void MApp_BlockSys_SetBlockStatus(BOOLEAN bBlockSysBlockStatus);
INTERFACE void MApp_ParentalControl_SetBlockStatus(BOOLEAN bBlockSysBlockStatus);
INTERFACE  BOOLEAN MApp_ParentalControl_GetBlockStatus(void);
INTERFACE void MApp_CheckBlockProgramme(void);
INTERFACE void MApp_EnableBlockProgramme(BOOLEAN bEnableBlock);
INTERFACE void MApp_BlockSysSetCurrentService(MEMBER_SERVICETYPE eServiceType, WORD wPosition);
#if ENABLE_CUS_BLOCK_SYS
INTERFACE void MApp_BlockSys_Monitor(SCALER_WIN eWindow,U8 u8CheckMode,BOOLEAN bChangeInputSrc);
INTERFACE void MApp_BlockSys_ResetMsgbox2ScreenSaverTimer(void);
#endif
#undef INTERFACE
#endif
