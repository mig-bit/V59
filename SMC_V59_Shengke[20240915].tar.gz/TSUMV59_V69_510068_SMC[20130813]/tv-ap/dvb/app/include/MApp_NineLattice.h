#ifndef MAPP_NINELATTICE_H
#define MAPP_NINELATTICE_H

typedef enum
{
    STATE_NL_IDLE,
    STATE_NL_INIT,
    STATE_NL_SWITCH,
    STATE_NL_SCALER_SETWINDOW,
    STATE_NL_EXIT,
} EN_NL_STATE;

#ifdef MAPP_NINE_LATTICE_C
#define INTERFACE
#else
#define INTERFACE extern
#endif

INTERFACE void MApp_NineLattice(void);
INTERFACE void MApp_NineLattice_Set(EN_NL_STATE eState);
INTERFACE MS_BOOL MApp_NineLattice_IsEnabled(void);


#undef INTERFACE

#endif

