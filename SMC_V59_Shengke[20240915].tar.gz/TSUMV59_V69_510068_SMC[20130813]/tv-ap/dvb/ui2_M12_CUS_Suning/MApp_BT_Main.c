////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#define MAPP_BT_MAIN_C

/******************************************************************************/
/*                 Header Files                                               */
/* ****************************************************************************/
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#include "datatype.h"
#include "debug.h"

#ifdef ENABLE_BT
#include "MApp_BT_config.h"

#if (ENABLE_THUNDER_DOWNLOAD)
#include "MApp_Thunder_Main.c"
#else
#include "MApp_Exit.h"
#include "MApp_Key.h"
#include "MApp_UiMenuDef.h"
#include "MApp_ZUI_Main.h"
#include "MApp_BT_Main.h"
#include "MApp_BT.h"

#include "IOUtil.h"

///////////////////////////////////////////////////////////
#define UI_DBG(x)   x

static enumBTFlags m_eBTFlags = E_BT_FLAG_NONE;

//////////////////////////////////////////////////////////
static void _MApp_BT_Main_Init(void)
{
    if(!(m_eBTFlags&E_BT_FLAG_INITED))
    {
        MApp_BT_Init();
        m_eBTFlags |= E_BT_FLAG_INITED;
    }
    MApp_BT_SetSystemInitState(STATE_SYSTEM_INIT_NONE);
    enBTSearchState = BT_SEARCH_STATE_INIT;
}

static void _MApp_BT_Switch2BT(void)
{
    //add switch BT AP code in here
    if(m_eBTFlags & E_BT_FLAG_INITED)
    {
        UI_DBG(printf("\n\n\n*******************BT has inited\n"));
    }
    else
    {
        UI_DBG(printf("\n\n\n*******************BT_Init\n"));
        _MApp_BT_Main_Init();
    }
}

EN_RET MApp_BT_Main(void)
{
    EN_RET enRetVal =EXIT_NULL;

    switch(enBTState)
    {
        case STATE_BT_INIT:
            MApp_ZUI_ACT_StartupOSD(E_OSD_BT);
            _MApp_BT_Switch2BT();
            enBTState = STATE_BT_WAIT;
            break;

        case STATE_BT_WAIT:
            MApp_ZUI_ProcessKey(u8KeyCode);
            u8KeyCode = KEY_NULL;
            break;

        case STATE_BT_CLEAN_UP:
            MApp_ZUI_ACT_ShutdownOSD();
            enBTState = STATE_BT_INIT;
            enRetVal =EXIT_CLOSE;
            break;

        case STATE_BT_GOTO_STANDBY:
            MApp_ZUI_ACT_ShutdownOSD();
            u8KeyCode = KEY_POWER;
            enRetVal =EXIT_GOTO_STANDBY;
            break;

        case STATE_BT_GOTO_MENU:
            MApp_ZUI_ACT_ShutdownOSD();
            enBTState = STATE_BT_RETURN_FROM_MENU;
            enRetVal = EXIT_BT_TRAN_MENU;
            break;
        case STATE_BT_GOTO_INPUTSOURCE:
            MApp_ZUI_ACT_ShutdownOSD();
            enBTState = STATE_BT_RETURN_FROM_MENU;
            enRetVal = EXIT_GOTO_INPUTSOURCE;
            break;
        case STATE_BT_RETURN_FROM_MENU:
            enBTState = STATE_BT_WAIT;
            MApp_ZUI_ACT_StartupOSD(E_OSD_BT);
            break;
        case STATE_BT_SEARCH_WAIT:
            MApp_ZUI_ProcessKey(u8KeyCode);
            u8KeyCode = KEY_NULL;
            if(MApp_BT_SearchWait_GetSearchResult())
                enBTState = STATE_BT_WAIT;
            else
                enBTState = STATE_BT_SEARCH_WAIT;
            break;

        default:
            enBTState = STATE_BT_WAIT;
            break;
    }
    return enRetVal;
}

void MApp_BT_SetLink0PhotoFlags(BOOLEAN bEnable)
{
    if(bEnable)
    {
        m_eBTFlags |= E_BT_FLAG_LINK0PHOTO_MODE;
        MApp_BT_MainLink0_Init();
    }
    else
        m_eBTFlags &= (enumBTFlags)(~E_BT_FLAG_LINK0PHOTO_MODE);

}

void MApp_BT_SetLink1PhotoFlags(BOOLEAN bEnable)
{
    if(bEnable)
    {
        m_eBTFlags |= E_BT_FLAG_LINK1PHOTO_MODE;
        MApp_BT_MainLink1_Init();
    }
    else
        m_eBTFlags &= (enumBTFlags)(~E_BT_FLAG_LINK1PHOTO_MODE);
}

enumBTFlags MApp_BT_GetBTFlags(void)
{
    return m_eBTFlags;
}

void MApp_BT_Main_Exit(void)
{
    m_eBTFlags = E_BT_FLAG_NONE;
    enBTState = STATE_BT_INIT;
}

/******************************************************************************/
/// Bit-torrent Search Result
/******************************************************************************/
BOOLEAN MApp_BT_SearchWait_GetSearchResult(void)
{
    if(msAPI_Timer_DiffTimeFromNow(u32MonitorBTSearchTimer) > BT_SEARCH_WAIT_MONITOR_TIME)
    {
        enBTSearchState = BT_SEARCH_STATE_TIME_OUT;
        return TRUE;
    }
    else
    {
        //if(msAPI_Timer_DiffTimeFromNow(u32MonitorBTSearchTimer) > 3000) //only for test.
        if(MApp_BT_QuerySearchListResult())
        {
            if(MApp_BT_GetSearchFileNum() == 0)
            {
                enBTSearchState = BT_SEARCH_STATE_NOTHING;
            }
            else
            {
                enBTSearchState = BT_SEARCH_STATE_INPUT_SHOW;
            }
            return TRUE;
        }
    }

    return FALSE;
}

#endif //#if (ENABLE_THUNDER_DOWNLOAD)

#endif

#undef MAPP_BT_MAIN_C

