////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MSAPI_POWER_H_
#define _MSAPI_POWER_H_

#include "drvpower_if.h"

#ifdef _MSAPI_POWER_C_
#define INTERFACE
#else
#define INTERFACE extern
#endif

//================== On Timer ====================
typedef enum
{
    SUN        = 0,
    MON        = 1,
    TUE        = 2,
    WED        = 3,
    THU        = 4,
    FRI        = 5,
    SAT        = 6,
    MAX_DAYOFWEEK,
} DAYOFWEEK;

typedef enum
{
    EN_OnTimer_Off,
    EN_OnTimer_Once,
    EN_OnTimer_Everyday,
    EN_OnTimer_Mon2Fri,
    EN_OnTimer_Mon2Sat,
    EN_OnTimer_Sat2Sun,
    EN_OnTimer_Sun,
    EN_OnTimer_Num
} MENU_OnTimer;

typedef enum
{
    EN_POWER_AC_BOOT    = 0,
    EN_POWER_DC_BOOT    = 1,
}EN_POWER_ON_MODE;

#define PM_MODE_STANBY          0x01
#define PM_MODE_DEEPSLEEP       0x02

#define PM_MODE_DEFAULT         0xFF


////////////////////////////////////////////////////////////////////////////////

#if (PM_MODE_SELECT == PM_MODE_DEEPSLEEP)

typedef struct _PMTblType
{
    U32 dwReg;
    U8  ucValue;
    U8  ucMask;
    U16 wAct;
}PMTblType;

/// Wake-up device
enum
{
    PM_WAKEUP_BY_KEYPAD         = (1 << 0),
    PM_WAKEUP_BY_CEC            = (1 << 1),
    PM_WAKEUP_BY_RTC            = (1 << 2),
    PM_WAKEUP_BY_DDC            = (1 << 3),

    PM_WAKEUP_BY_VGA            = (1 << 4),
    PM_WAKEUP_BY_DVI            = (1 << 5),
    PM_WAKEUP_BY_GPI            = (1 << 6),

    PM_WAKEUP_BY_IR_NEC         = (1 << 7),
    PM_WAKEUP_BY_IR_RC          = (1 << 8),
    PM_WAKEUP_BY_IR             = PM_WAKEUP_BY_IR_NEC | PM_WAKEUP_BY_IR_RC,

    PM_WAKEUP_BY_ALL_xIR        = PM_WAKEUP_BY_KEYPAD
                                | PM_WAKEUP_BY_CEC
                                | PM_WAKEUP_BY_RTC
                                | PM_WAKEUP_BY_DDC
                                | PM_WAKEUP_BY_VGA
                                | PM_WAKEUP_BY_DVI
                                | PM_WAKEUP_BY_GPI,

    PM_WAKEUP_BY_ALL            = PM_WAKEUP_BY_ALL_xIR | PM_WAKEUP_BY_IR_NEC,
};

////////////////////////////////////////////////////////////////////////////////

#else //#if (PM_MODE_SELECT == PM_MODE_STANBY)

// Wake-up device
enum
{
    PM_WAKEUP_BY_KEYPAD         = (1 << 0),
    PM_WAKEUP_BY_CEC            = (1 << 1),
    PM_WAKEUP_BY_RTC            = (1 << 2),
    PM_WAKEUP_BY_DDC            = (1 << 3),

    PM_WAKEUP_BY_VGA            = (1 << 4),
    PM_WAKEUP_BY_DVI            = (1 << 5),
    PM_WAKEUP_BY_GPI            = (1 << 6),
    PM_WAKEUP_BY_IR             = (1 << 7),

    PM_WAKEUP_BY_UART           = (1 << 8),
    PM_WAKEUP_BY_USB            = (1 << 9),
    PM_WAKEUP_BY_MHL            = (1 << 10),

    PM_WAKEUP_BY_PART            = PM_WAKEUP_BY_KEYPAD
                                //| PM_WAKEUP_BY_CEC
                                | PM_WAKEUP_BY_RTC
                                | PM_WAKEUP_BY_DDC
                                //| PM_WAKEUP_BY_VGA
                                //| PM_WAKEUP_BY_DVI
                                | PM_WAKEUP_BY_GPI
                                | PM_WAKEUP_BY_IR
                                | PM_WAKEUP_BY_UART
                                | PM_WAKEUP_BY_USB
                                | PM_WAKEUP_BY_MHL,

    PM_WAKEUP_BY_ALL            = PM_WAKEUP_BY_KEYPAD
                                | PM_WAKEUP_BY_CEC
                                | PM_WAKEUP_BY_RTC
                                | PM_WAKEUP_BY_DDC
                                | PM_WAKEUP_BY_VGA
                                | PM_WAKEUP_BY_DVI
                                | PM_WAKEUP_BY_GPI
                                | PM_WAKEUP_BY_IR
                                | PM_WAKEUP_BY_UART
                                | PM_WAKEUP_BY_USB
                                | PM_WAKEUP_BY_MHL,
};

INTERFACE void msAPI_Power_SetWakeUpDevice(void);
#endif

////////////////////////////////////////////////////////////////////////////////


#define WakeUp_by_IR        0
#define WakeUp_by_CEC       BIT0
#define WakeUp_by_GPIO      BIT1
#define WakeUp_by_RTC       BIT2
#define WakeUp_by_SAR       BIT3
#define WakeUp_by_DDCD      BIT4
#define WakeUp_by_DVI       BIT5
#define WakeUp_by_SYNC      BIT6
#if (PM_MODE_SELECT == PM_MODE_STANBY)
#define WakeUp_by_USB       BIT7
#endif
#define WakeUp_by_MHL       BIT8
#define WakeUp_by_None      0xFF
INTERFACE U16 msAPI_Power_CheckWakeupDevice(void);

//-------------------------------------------------------------------------------------------------
// Extern Functions
//-------------------------------------------------------------------------------------------------
INTERFACE MENU_OnTimer msAPI_Power_GetOnTimer(void);
//INTERFACE BOOLEAN msAPI_Power_Is1STBootUp(void);
//INTERFACE BOOLEAN msAPI_Power_IsPowerDown(void);
INTERFACE void msAPI_ReSetTimerOnFlag(void);
INTERFACE void msAPI_Power_SetOnTimer(MENU_OnTimer eOnTimerDate);
INTERFACE void msAPI_Power_SetDayOfWeek(DAYOFWEEK eDayOfWeek);
//INTERFACE void msAPI_Power_Saving_ADC(BOOLEAN bFlag);

INTERFACE void msAPI_Power_Panel1stPowerOn(void);
INTERFACE void msAPI_Power_Panel2ndPowerOn(void);
INTERFACE void msAPI_Power_PanelPowerOff(void);
INTERFACE void msAPI_Power_EnableBacklight(BOOLEAN bEnable);

INTERFACE EN_POWER_ON_MODE msAPI_Power_QueryPowerOnMode(void);
INTERFACE BOOLEAN  msAPI_Power_IswakeupsourceRTC(void);
INTERFACE BOOLEAN  msAPI_Power_IswakeupsourceCEC(void);
INTERFACE void msAPI_Power_SetPowerMode(void);
INTERFACE void msAPI_PowerSetting_Init(void);






////////////////////////////////////////////////////////////////////////////////

#undef INTERFACE
#endif // _DRVPOWER_H_
