//<MStar Software>
//******************************************************************************
// MStar Software
// Copyright (c) 2010 - 2012 MStar Semiconductor, Inc. All rights reserved.
// All software, firmware and related documentation herein ("MStar Software") are
// intellectual property of MStar Semiconductor, Inc. ("MStar") and protected by
// law, including, but not limited to, copyright law and international treaties.
// Any use, modification, reproduction, retransmission, or republication of all
// or part of MStar Software is expressly prohibited, unless prior written
// permission has been granted by MStar.
//
// By accessing, browsing and/or using MStar Software, you acknowledge that you
// have read, understood, and agree, to be bound by below terms ("Terms") and to
// comply with all applicable laws and regulations:
//
// 1. MStar shall retain any and all right, ownership and interest to MStar
//    Software and any modification/derivatives thereof.
//    No right, ownership, or interest to MStar Software and any
//    modification/derivatives thereof is transferred to you under Terms.
//
// 2. You understand that MStar Software might include, incorporate or be
//    supplied together with third party`s software and the use of MStar
//    Software may require additional licenses from third parties.
//    Therefore, you hereby agree it is your sole responsibility to separately
//    obtain any and all third party right and license necessary for your use of
//    such third party`s software.
//
// 3. MStar Software and any modification/derivatives thereof shall be deemed as
//    MStar`s confidential information and you agree to keep MStar`s
//    confidential information in strictest confidence and not disclose to any
//    third party.
//
// 4. MStar Software is provided on an "AS IS" basis without warranties of any
//    kind. Any warranties are hereby expressly disclaimed by MStar, including
//    without limitation, any warranties of merchantability, non-infringement of
//    intellectual property rights, fitness for a particular purpose, error free
//    and in conformity with any international standard.  You agree to waive any
//    claim against MStar for any loss, damage, cost or expense that you may
//    incur related to your use of MStar Software.
//    In no event shall MStar be liable for any direct, indirect, incidental or
//    consequential damages, including without limitation, lost of profit or
//    revenues, lost or damage of data, and unauthorized system use.
//    You agree that this Section 4 shall still apply without being affected
//    even if MStar Software has been modified by MStar in accordance with your
//    request or instruction for your use, except otherwise agreed by both
//    parties in writing.
//
// 5. If requested, MStar may from time to time provide technical supports or
//    services in relation with MStar Software to you for your use of
//    MStar Software in conjunction with your or your customer`s product
//    ("Services").
//    You understand and agree that, except otherwise agreed by both parties in
//    writing, Services are provided on an "AS IS" basis and the warranty
//    disclaimer set forth in Section 4 above shall apply.
//
// 6. Nothing contained herein shall be construed as by implication, estoppels
//    or otherwise:
//    (a) conferring any license or right to use MStar name, trademark, service
//        mark, symbol or any other identification;
//    (b) obligating MStar or any of its affiliates to furnish any person,
//        including without limitation, you and your customers, any assistance
//        of any kind whatsoever, or any information; or
//    (c) conferring any license or right under any intellectual property right.
//
// 7. These terms shall be governed by and construed in accordance with the laws
//    of Taiwan, R.O.C., excluding its conflict of law rules.
//    Any and all dispute arising out hereof or related hereto shall be finally
//    settled by arbitration referred to the Chinese Arbitration Association,
//    Taipei in accordance with the ROC Arbitration Law and the Arbitration
//    Rules of the Association by three (3) arbitrators appointed in accordance
//    with the said Rules.
//    The place of arbitration shall be in Taipei, Taiwan and the language shall
//    be English.
//    The arbitration award shall be final and binding to both parties.
//
//******************************************************************************
//<MStar Software>
////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//
/// @file msAPI_Flash.h
/// This file includes MStar Flash control application interface
/// @brief API for Flash
/// @author MStar Semiconductor, Inc.
///
////////////////////////////////////////////////////////////////////////////////

#define MSAPI_FLASH_C

/******************************************************************************/
/*                              Header Files                                  */
/******************************************************************************/
// C Library
#include <stdio.h>

// Global Layer
#include "sysinfo.h"
#include "assert.h"

// Driver Layer
#include "drvSERFLASH.h"

// API Layer
#include "msAPI_Flash.h"
#include "msAPI_Timer.h"
#include "MApp_SaveData.h"
#include "msAPI_MIU.h"
#include "datatype.h"
#include "msAPI_Memory.h"
#include "Utl.h"
/******************************************************************************/
/*                                 Macro                                      */
/******************************************************************************/
#define APIFLASH_DBG(y) //y

#define DB_GEN_STORE_DBG(x)      //x
/******************************************************************************/
/*                                 Local                                      */
/******************************************************************************/
#define MSIF_FLASH_BUILD_VERSION        0x07

#define FLASH_BUF_SIZE                  1024
static U8 u8FlashBlockProtectValue      = 0;
extern U32 u32QuickDatabaseTimer;
/******************************************************************************/
/*                               Functions                                    */
/******************************************************************************/

//-------------------------------------------------------------------------------------------------
/// Description :  Set active flash among multi-spi flashes
/// @param  eFlashChipSel   \b IN: The Flash index, 0 for external #1 spi flash, 1 for external #2 spi flash
/// @return TRUE : succeed
/// @return FALSE : not succeed
/// @note   For Secure booting = 0, please check hw_strapping or e-fuse (the board needs to jump)
//----------------------------------------------------------------------------------------------
BOOLEAN msAPI_Flash_ChipSelect(FLASH_CHIP_SELECT eFlashChipSel)
{
    return msFlash_ChipSelect((U8)eFlashChipSel);
}

//-------------------------------------------------------------------------------------------------
/// Description : Protect whole Flash chip
/// @param  bEnable \b IN: TRUE/FALSE: enable/disable protection
/// @return TRUE : succeed
/// @return FALSE : fail before timeout
/// @note   Not allowed in interrupt context
//-------------------------------------------------------------------------------------------------
BOOLEAN msAPI_Flash_WriteProtect(BOOL bEnable)
{
    return MDrv_FLASH_WriteProtect(bEnable);
}
//-------------------------------------------------------------------------------------------------
/// Description : Erase Flash by the specific Flash address
/// @param  u32StartAddr    \b IN: the start address of the Flash
/// @param  u32EraseSize  \b IN: the Size to erase
/// @param  bWait  \b IN: wait write done or not
/// @return TRUE : succeed
/// @return FALSE : illegal parameters or fail.
/// @note   Not allowed in interrupt context
//-------------------------------------------------------------------------------------------------
BOOLEAN msAPI_Flash_AddressErase(U32 u32StartAddr,U32 u32EraseSize,BOOL bWait)
{
    BOOL bRet = FALSE;
    U32 u32FlashSize = 0;

    MDrv_SERFLASH_DetectSize(&u32FlashSize);

    ASSERT((u32StartAddr < u32FlashSize));
    ASSERT((u32EraseSize < u32FlashSize));

    // review this flow, because it's potential danger to erase important data without any perceive.

    MDrv_FLASH_WriteProtect(DISABLE);

    bRet = MDrv_FLASH_AddressErase(u32StartAddr, u32EraseSize, bWait);

    MDrv_FLASH_WriteProtect(ENABLE);

    return bRet;
}

//-------------------------------------------------------------------------------------------------
/// Description : Erase Flash by the specific Flash block
/// @param  u32StartBlock    \b IN: the start block of the Flash
/// @param  u32EndBlock  \b IN: the end block of the Flash
/// @param  bWait  \b IN: wait write done or not
/// @return TRUE : succeed
/// @return FALSE : illegal parameters or fail.
/// @note   Not allowed in interrupt context
//-------------------------------------------------------------------------------------------------
BOOLEAN msAPI_Flash_BlockErase(U32 u32StartBlock, U32 u32EndBlock, BOOL bWait)
{
    BOOL bRet = FALSE;

    // review this flow, because it's potential danger to erase important data without any perceive.

    MDrv_FLASH_WriteProtect(DISABLE);

    bRet = MDrv_SERFLASH_BlockErase(u32StartBlock, u32EndBlock, bWait);

    MDrv_FLASH_WriteProtect(ENABLE);

    return bRet;
}

//-------------------------------------------------------------------------------------------------
/// Description : Write data to Flash by the sprcific flash address
/// @param  u32StartAddr    \b IN: the start address of the Flash (4-B aligned)
/// @param  u32WriteSize    \b IN: write data size in Bytes (4-B aligned)
/// @param  user_buffer \b IN: Virtual Buffer Address ptr to flash write data
/// @return TRUE : succeed
/// @return FALSE : fail before timeout or illegal parameters
/// @note   Not allowed in interrupt context
//-------------------------------------------------------------------------------------------------
BOOLEAN msAPI_Flash_Write(U32 u32StartAddr, U32 u32WriteSize, U8 * user_buffer)
{
    BOOL bRet = FALSE;
    U32 u32FlashSize = 0;

    MDrv_SERFLASH_DetectSize(&u32FlashSize);

    ASSERT((u32StartAddr < u32FlashSize));
    ASSERT((u32WriteSize < u32FlashSize));

    MDrv_FLASH_WriteProtect(DISABLE);

    bRet = MDrv_SERFLASH_Write(u32StartAddr, u32WriteSize, user_buffer);

    MDrv_FLASH_WriteProtect(ENABLE);

    return bRet;
}

//-------------------------------------------------------------------------------------------------
/// Description : Read data from Flash by the sprcific flash address
/// @param  u32StartAddr    \b IN: the start address of the Flash (4-B aligned)
/// @param  u32ReadSize    \b IN: read data size in Bytes (4-B aligned)
/// @param  user_buffer \b OUT: Virtual Buffer Address ptr to flash write data
/// @return TRUE : succeed
/// @return FALSE : fail before timeout or illegal parameters
/// @note   Not allowed in interrupt context
//-------------------------------------------------------------------------------------------------
BOOLEAN msAPI_Flash_Read(U32 u32StartAddr, U32 u32ReadSize, U8 * user_buffer)
{
    U32 u32FlashSize = 0;

    MDrv_SERFLASH_DetectSize(&u32FlashSize);

    ASSERT((u32StartAddr < u32FlashSize));
    ASSERT((u32ReadSize < u32FlashSize));

    return MDrv_FLASH_Read(u32StartAddr, u32ReadSize, user_buffer);
}

//-------------------------------------------------------------------------------------------------
/// Description : Detect flash type by reading the MID and DID
/// @return TRUE : succeed
/// @return FALSE : unknown flash type (if it occurs, please inform flash maintainer.)
/// @note   Not allowed in interrupt context
//-------------------------------------------------------------------------------------------------
BOOLEAN msAPI_Flash_DetectType(void)
{
    return MDrv_SERFLASH_DetectType();
}

//-------------------------------------------------------------------------------------------------
/// Description : Get flash start block index of the flash address
/// @param  u32FlashAddr    \b IN: flash address
/// @param  pu32BlockIndex    \b OUT: poniter to store the returning block index
/// @return TRUE : succeed
/// @return FALSE : illegal parameters
/// @note   Not allowed in interrupt context
//-------------------------------------------------------------------------------------------------
BOOLEAN msAPI_Flash_AddressToBlock(U32 u32FlashAddr, U32 *pu32BlockIndex)
{
    return MDrv_SERFLASH_AddressToBlock(u32FlashAddr, pu32BlockIndex);
}

//-------------------------------------------------------------------------------------------------
/// Description : Get flash start address of a block index
/// @param  u32BlockIndex    \b IN: block index
/// @param  pu32FlashAddr    \b OUT: pointer to store the returning flash address
/// @return TRUE : succeed
/// @return FALSE : illegal parameters
/// @note   Not allowed in interrupt context
//-------------------------------------------------------------------------------------------------
BOOLEAN msAPI_Flash_BlockToAddress(U32 u32BlockIndex, U32 *pu32FlashAddr)
{
    return MDrv_SERFLASH_BlockToAddress(u32BlockIndex, pu32FlashAddr);
}

//-------------------------------------------------------------------------------------------------
/// Description : Check write done in Serial Flash
/// @return TRUE : Done
/// @return FALSE : Wait until TimeOut
/// @note   Not allowed in interrupt context
//-------------------------------------------------------------------------------------------------
BOOLEAN msAPI_Flash_CheckWriteDone()
{
    return MDrv_SERFLASH_CheckWriteDone();
}

//-------------------------------------------------------------------------------------------------
/// Description  : Check DateBase/GenSetting area whether be protected.
/// @return TRUE : Not be protected
/// @return FALSE: been protected
/// @note
//-------------------------------------------------------------------------------------------------
BOOLEAN msAPI_Flash_WriteProtect_GetBPStatus(void)
{
    U8 u8BPStatus = 0;

    MDrv_FLASH_ReadStatusRegister(&u8BPStatus);
	if(u8FlashBlockProtectValue == (u8BPStatus&0xFC))//don't judge the wip/wel bit of BP Register
    {
        if(g_bOpenGenstStoreDBG)
        {
            printf("[GetBPStatus] TRUE >> u8FlashBlockProtectValue = 0x%X\n", u8FlashBlockProtectValue);
        }
        return TRUE;
    }
    if(g_bOpenGenstStoreDBG)
    {
        printf("[GetBPStatus] FAIL >> u8FlashBlockProtectValue = 0x%X\n", u8FlashBlockProtectValue);
    }
    return FALSE;
}

//-------------------------------------------------------------------------------------------------
/// Description  : Set DateBase/GenSetting area not to be protected.
/// @note
//-------------------------------------------------------------------------------------------------
void msAPI_Flash_WriteProtect_SetBPStatus(void)
{
    U8 u8GetBPStatus = 0;
    if(g_bOpenGenstStoreDBG)
    {
        printf("[WriteProtect_SetBPStatus_1] u8FlashBlockProtectValue =0x%X\n" , u8FlashBlockProtectValue);
    }

    if(g_bGenSettingStoreUseNewMethod)
    {
        msFlash_ActiveFlash_Set_HW_WP(DISABLE);
    }
    MDrv_FLASH_WriteProtect_Disable_Range_Set(g_SYSTEM_BANK_SIZE * g_QUICK_DB_GENSETTING_BANK, (g_FLASH_SIZE - g_QUICK_DB_GENSETTING_BANK*g_SYSTEM_BANK_SIZE));
    MDrv_FLASH_ReadStatusRegister(&u8GetBPStatus);
	u8FlashBlockProtectValue = (u8GetBPStatus&0xFC);//don't judge the wip/wel bit of BP Register
    if(g_bGenSettingStoreUseNewMethod)
    {
        msFlash_ActiveFlash_Set_HW_WP(ENABLE);
    }
    if(g_bOpenGenstStoreDBG)
    {
        printf("[WriteProtect_SetBPStatus_2] u8GetBPStatus =0x%X\n" , u8GetBPStatus);
        printf("[WriteProtect_SetBPStatus_2] u8FlashBlockProtectValue =0x%X\n" , u8FlashBlockProtectValue);
    }
}
//*************************************************************************
//Function name:        MApp_DB_SaveNowGenSetting
//Passing parameter:    none
//Return parameter:     none
//Description:          Save database from SDRAM to FLASH
//*************************************************************************
void MApp_DB_SaveNowGenSetting(void)
{
    U32 u32Timer;
    if(g_bOpenGenstStoreDBG)
    {
        printf("MApp_DB_SaveNowGenSetting()\n");
    }

    u32Timer = msAPI_Timer_GetTime0();
    while( (g_u8QuickDataBase&g_QUICK_DB_GENST_UPDATE) == g_QUICK_DB_GENST_UPDATE )
    {
        MApp_DB_QuickGenSettingMonitor();
        if(g_bOpenGenstStoreDBG)
        {
            printf("[Warming]--g_u8QuickDataBase&g_QUICK_DB_GENST_UPDATE)==g_QUICK_DB_GENST_UPDATE\n");
        }
        if(msAPI_Timer_DiffTimeFromNow(u32Timer) > 1000)
        {
            if(g_bOpenGenstStoreDBG)
            {
                printf("[Warming]SaveNowGenSetting time out --- %ld\n", msAPI_Timer_DiffTimeFromNow(u32Timer));
            }
            break;
        }
    }

    memcpy((void*) _PA2VA((U32)(g_u32DataBaseAddr+g_RM_GENSET_START_ADR)),
           (void*) &stGenSetting, g_RM_SIZE_GENSET);

    if(g_bGenSettingStoreUseNewMethod)
    {
        if(g_bOpenGenstStoreDBG)
        {
            printf("[3]g_u16QuickGenSettingIdx++\n");
        }
        g_u16QuickGenSettingIdx++;

        if(g_u16QuickGenSettingIdx >= (g_QUICK_DB_GENST_NUM - 1))
        {
            msAPI_MIU_QuickGenSettingErase(g_QUICK_DB_GENSETTING_BANK, TRUE);
            g_u16QuickGenSettingIdx = 1;
            g_u8EraseGenSettingBank = ERASE_BANK0;
            if(g_bOpenGenstStoreDBG)
            {
                printf("ERASE_BANK0 >>%0x%X!\n", g_QUICK_DB_GENSETTING_BANK);
            }
        }
        else if(g_u8EraseGenSettingBank == ERASE_BANK0 && g_u16QuickGenSettingIdx == 2)
        {
            msAPI_MIU_QuickGenSettingErase(g_QUICK_DB_GENSETTING_BANK+1, TRUE);
            g_u16QuickGenSettingIdx = 2;
            g_u8EraseGenSettingBank = ERASE_NUM;
            if(g_bOpenGenstStoreDBG)
            {
                printf("ERASE_BANK1 >>%0x%X!\n", g_QUICK_DB_GENSETTING_BANK+1);
            }
        }
        if(g_bOpenGenstStoreDBG)
        {
            printf("Save GenSettingIdx = %d\n", g_u16QuickGenSettingIdx);
        }
        msAPI_MIU_QuickGenSettingWrite((g_u16QuickGenSettingIdx%2) ? (g_QUICK_DB_GENSETTING_BANK) : (g_QUICK_DB_GENSETTING_BANK+1) , g_u32DataBaseAddr, g_RM_GEN_USAGE);
    }
    else
    {
        if(g_bOpenGenstStoreDBG)
        {
            printf("[4]g_u16QuickGenSettingIdx++\n");
        }
        g_u16QuickGenSettingIdx++;

        if(g_u16QuickGenSettingIdx >= g_QUICK_DB_GENST_NUM)
        {
            msAPI_MIU_QuickGenSettingErase(g_QUICK_DB_GENSETTING_BANK, TRUE);
            msAPI_MIU_QuickGenSettingErase(g_QUICK_DB_GENSETTING_BANK + 1, FALSE);
            g_u16QuickGenSettingIdx = 1;
            if(g_bOpenGenstStoreDBG)
            {
                printf("QUICK_DB_GENSETTING_BANK   >>0x%X!\n", g_QUICK_DB_GENSETTING_BANK);
                printf("QUICK_DB_GENSETTING_BANK+1 >>0x%X!\n", g_QUICK_DB_GENSETTING_BANK + 1);
            }
        }
        msAPI_MIU_QuickGenSettingWrite(g_QUICK_DB_GENSETTING_BANK, g_u32DataBaseAddr, g_RM_GEN_USAGE);
    }
    g_u8QuickDataBase &= ~g_QUICK_DB_GENST_MODIFIED;
}

//*************************************************************************
//Function name:        MApp_DB_SaveGenSetting
//Passing parameter:    none
//Return parameter:     none
//Description:          Save database from SDRAM to FLASH
//*************************************************************************
void MApp_DB_SaveGenSetting(void)
{
    if(g_bOpenGenstStoreDBG)
    {
        printf("MApp_DB_SaveGenSetting()\n");
    }

    memcpy((void*) _PA2VA((U32)(g_u32DataBaseAddr+g_RM_GENSET_START_ADR)),
           (void*) &stGenSetting, g_RM_SIZE_GENSET);

    if(g_bGenSettingStoreUseNewMethod)
    {
        if((g_u8QuickDataBase & g_QUICK_DB_GENST_MASK)==g_QUICK_DB_GENST_ERASE_IN_PROGRESS)
        {
            if(g_bOpenGenstStoreDBG)
            {
                printf("[++]ERASE_IN_PROGRESS >> Return\n");
            }
            return;
        }

        if(g_bOpenGenstStoreDBG)
        {
            printf("[1]g_u16QuickGenSettingIdx++\n");
        }

        g_u16QuickGenSettingIdx++;
        if(g_u16QuickGenSettingIdx >= (g_QUICK_DB_GENST_NUM - 1))//Erase Bank0
        {
            if(g_bOpenGenstStoreDBG)
            {
                printf("\r\n Attention Initial BANK0\n");
            }
            g_u8EraseGenSettingBank = ERASE_BANK0;
            g_u8QuickDataBase |= g_QUICK_DB_GENST_UPDATE;
        }
        else if(g_u8EraseGenSettingBank == ERASE_BANK0 && g_u16QuickGenSettingIdx == 2)//Erase Bank1
        {
            if(g_bOpenGenstStoreDBG)
            {
                printf("\r\n Attention Initial BANK1\n");
            }
            g_u8EraseGenSettingBank = ERASE_BANK1;
            g_u8QuickDataBase |= g_QUICK_DB_GENST_UPDATE;
        }
        else
        {
            if(g_bOpenGenstStoreDBG)
            {
                printf("[SaveGenSetting]Save GenSettingIdx = %d\n", g_u16QuickGenSettingIdx);
            }
            msAPI_MIU_QuickGenSettingWrite((g_u16QuickGenSettingIdx%2) ? (g_QUICK_DB_GENSETTING_BANK) : (g_QUICK_DB_GENSETTING_BANK+1) , g_u32DataBaseAddr, g_RM_GEN_USAGE);
        }
    }
    else
    {
        if(g_bOpenGenstStoreDBG)
        {
            printf("[2]g_u16QuickGenSettingIdx++\n");
        }
        g_u16QuickGenSettingIdx++;
        //printf("MApp_DB_SaveGenSetting>> g_u16QuickGenSettingIdx = %d\n", g_u16QuickGenSettingIdx);

        if(g_u16QuickGenSettingIdx >= g_QUICK_DB_GENST_NUM)
        {
            g_u16QuickGenSettingIdx = 0;
            g_u8QuickDataBase |= g_QUICK_DB_GENST_UPDATE;
        }
        else
        {
            msAPI_MIU_QuickGenSettingWrite(g_QUICK_DB_GENSETTING_BANK, g_u32DataBaseAddr, g_RM_GEN_USAGE);
        }
    }
    g_u8QuickDataBase &= ~g_QUICK_DB_GENST_MODIFIED;
}

void MApp_DB_QuickGenSettingMonitor(void)
{
    if (g_u8QuickDataBase & g_QUICK_DB_GENST_MODIFIED)
    {
        if(g_bOpenGenstStoreDBG)
        {
            printf("\n----MApp_DB_QuickGenSettingMonitor[g_QUICK_DB_GENST_MODIFIED]----0x%X\n", g_u8QuickDataBase);
        }

        if((g_u8QuickDataBase & g_QUICK_DB_GENST_MASK)!=g_QUICK_DB_GENST_ERASE_IN_PROGRESS && \
           (g_u8QuickDataBase & g_QUICK_DB_GENST_MASK)!=g_QUICK_DB_GENST_ERASE_DONE )
        {
            MApp_DB_SaveGenSetting();
        }
        else
        {
            printf("[Warming]QuickGenSettingMonitor[IN_PROGRESS,ERASE_DONE]---0x%X\n", g_u8QuickDataBase);
        }
    }
    if ((g_u8QuickDataBase & g_QUICK_DB_GENST_UPDATE) == g_QUICK_DB_GENST_UPDATE)
    {
        U8 u8StatusGen;
        u8StatusGen = (g_u8QuickDataBase & g_QUICK_DB_GENST_MASK);
        if(u8StatusGen == g_QUICK_DB_GENST_READY)
        {
            if(g_bGenSettingStoreUseNewMethod)
            {
                if(g_u8EraseGenSettingBank == ERASE_BANK0)
                {
                    if(g_bOpenGenstStoreDBG)
                    {
                        printf("\r\n ERASE_BANK0 !!!");
                    }
                    msAPI_MIU_QuickGenSettingErase(g_QUICK_DB_GENSETTING_BANK, TRUE);
                }
                else if(g_u8EraseGenSettingBank == ERASE_BANK1)
                {
                    if(g_bOpenGenstStoreDBG)
                    {
                        printf("\r\n ERASE_BANK1 !!!");
                    }
                    msAPI_MIU_QuickGenSettingErase(g_QUICK_DB_GENSETTING_BANK+1, TRUE);
                }
            }
            else
            {
                msAPI_MIU_QuickGenSettingErase(g_QUICK_DB_GENSETTING_BANK, TRUE);
                msAPI_MIU_QuickGenSettingErase(g_QUICK_DB_GENSETTING_BANK+1, FALSE);
            }
            g_u8QuickDataBase = ((g_u8QuickDataBase & ~g_QUICK_DB_GENST_MASK) | g_QUICK_DB_GENST_ERASE_IN_PROGRESS);
        }
        else if(u8StatusGen == g_QUICK_DB_GENST_ERASE_IN_PROGRESS)
        {
            if (msAPI_MIU_QuickDataBaseCheck() == TRUE)
            {
                g_u8QuickDataBase = ((g_u8QuickDataBase & ~g_QUICK_DB_GENST_MASK) | g_QUICK_DB_GENST_ERASE_DONE);
            }
        }
        else if(u8StatusGen == g_QUICK_DB_GENST_ERASE_DONE)
        {
            if(g_bGenSettingStoreUseNewMethod)
            {
                if(g_u8EraseGenSettingBank == ERASE_BANK0)
                {
                    g_u16QuickGenSettingIdx = 0;
                }
                else if(g_u8EraseGenSettingBank == ERASE_BANK1)
                {
                    if(g_bOpenGenstStoreDBG)
                    {
                        printf("if(g_u8EraseGenSettingBank == ERASE_BANK1) g_u16QuickGenSettingIdx = 1\n");
                    }
                    g_u16QuickGenSettingIdx = 1;
                }

                if(g_u8EraseGenSettingBank == ERASE_BANK1)
                {
                    g_u8EraseGenSettingBank = ERASE_NUM;
                }
            }
            else
            {
                g_u16QuickGenSettingIdx = 0;
            }

            if(g_bOpenGenstStoreDBG)
            {
                printf("\n----MApp_DB_QuickGenSettingMonitor[2]----\n");
            }
            MApp_DB_SaveGenSetting();

            g_u8QuickDataBase = ((g_u8QuickDataBase & ~g_QUICK_DB_GENST_MASK) | g_QUICK_DB_GENST_READY);
            g_u8QuickDataBase &= (~g_QUICK_DB_GENST_UPDATE);
            u32QuickDatabaseTimer = msAPI_Timer_GetTime0();
        }
    }
}
/******************************************************************************/
/// API for MIU Store Database::
/// Copy database information from SDRAM to flash
/// @param u8Bank \b IN: bank number
/// @param u32srcaddr \b IN: SDRAM address for Database information
/// @param s32size \b IN: Database information size
/******************************************************************************/
void msAPI_MIU_StoreDataBase2Flash(U8 u8Bank, U32 u32srcaddr, S32 s32size, BOOLEAN bErase)    // SRAM2Flash
{
    U32 dst;
    U32 count;
    U8 *flash_buf;

    msAPI_Flash_ChipSelect((FLASH_CHIP_SELECT)0);

    flash_buf = (U8*)msAPI_Memory_Allocate(FLASH_BUF_SIZE, g_BUF_ID_FLASH);
    if (flash_buf == NULL)
    {
        __ASSERT(0);
        APIFLASH_DBG(printf("malloc flash_buf fail!\r\n"));
        return;
    }

    APIFLASH_DBG(printf("~~~ StoreDataBase2Flash, src=0x%X, dst=0x%X,, size=%d\n", u32srcaddr, (U32)(g_SYSTEM_BANK_SIZE * u8Bank), s32size));

    dst = g_SYSTEM_BANK_SIZE * u8Bank;

    if(g_bGenSettingStoreUseNewMethod)
    {
        if(!msAPI_Flash_WriteProtect_GetBPStatus())
        {
            msAPI_Flash_WriteProtect_SetBPStatus();
        }
    }
    else
    {
        if(g_ENABLE_DVBT_1000_LCN)  //20100707EL
        {
            MDrv_FLASH_WriteProtect_Disable_Range_Set(dst, (g_SYSTEM_BANK_SIZE*2)); // MDrv_FLASH_WriteProtect(DISABLE); // <-@@@
        }
        else
        {
            MDrv_FLASH_WriteProtect_Disable_Range_Set(dst, g_SYSTEM_BANK_SIZE); // MDrv_FLASH_WriteProtect(DISABLE); // <-@@@
        }
    }

    if (g_u8EEPROM_DB_STORAGE != 3)//g_EEPROM_SAVE_ALL)
    {
        if(bErase)
        {
            if(g_ENABLE_DVBT_1000_LCN)
            {
                MDrv_FLASH_AddressErase(dst, (g_SYSTEM_BANK_SIZE*2), TRUE);
            }
            else
            {
                MDrv_FLASH_AddressErase(dst, g_SYSTEM_BANK_SIZE, TRUE);
            }
        }
    }
    else
    {
        UNUSED(bErase);
        MDrv_FLASH_AddressErase(dst, g_SYSTEM_BANK_SIZE, TRUE);
    }

    while (s32size > 0)
    {
        count = MIN(s32size, FLASH_BUF_SIZE);
        memcpy( (flash_buf), (void *)_PA2VA(u32srcaddr),  count);
        u32srcaddr += count;
        MDrv_FLASH_Write(dst,count, flash_buf);
        dst += count;
        s32size -= count;
    }
    if(g_bGenSettingStoreUseNewMethod)
    {
        msFlash_ActiveFlash_Set_HW_WP(ENABLE);
    }
    else
    {
        MDrv_FLASH_WriteProtect(ENABLE);
    }
    MSAPI_MEMORY_FREE(flash_buf, g_BUF_ID_FLASH);
}

#define DATABASE_ID                  0xA55A

void msAPI_MIU_WriteFlashDataBaseVersion(U8 u8Bank, U32 u16Offset, U8 u8Version)
{
    U32 dst;
    U8 flash_buf[3];

    if(g_bGenSettingStoreUseNewMethod)
    {
        if(!msAPI_Flash_WriteProtect_GetBPStatus())
        {
            msAPI_Flash_WriteProtect_SetBPStatus();
        }
    }
    else
    {
        if(g_ENABLE_DVBT_1000_LCN)
        {
            MDrv_FLASH_WriteProtect_Disable_Range_Set(g_SYSTEM_BANK_SIZE * u8Bank, (g_SYSTEM_BANK_SIZE*2)); // MDrv_FLASH_WriteProtect(DISABLE); // <-@@@
        }
        else
        {
            MDrv_FLASH_WriteProtect_Disable_Range_Set(g_SYSTEM_BANK_SIZE * u8Bank, g_SYSTEM_BANK_SIZE); // MDrv_FLASH_WriteProtect(DISABLE); // <-@@@
        }
    }
    flash_buf[0] = (U8)DATABASE_ID;
    flash_buf[1] = (U8)(DATABASE_ID>>8);
    flash_buf[2] = u8Version;
    dst = (g_SYSTEM_BANK_SIZE * u8Bank) + u16Offset;
    MDrv_FLASH_Write(dst, 3, flash_buf);
    /*
    printf("WriteFlashDataBaseVersion\n");
    printf("u8Bank 0x%x, u16Offset 0x%x\n", u8Bank, u16Offset);
    printf("flash_buf: [1]0x%x [2]0x%x [3]0x%x\n", flash_buf[0], flash_buf[1], flash_buf[2]);
    */
    if(g_bGenSettingStoreUseNewMethod)
    {
        msFlash_ActiveFlash_Set_HW_WP(ENABLE);
    }
    else
    {
        MDrv_FLASH_WriteProtect(ENABLE);
    }
}

S8 msAPI_MIU_ReadFlashDataBaseVersion(U8 u8Bank, U32 u16Offfset)
{
    U32 dst;
    U8 flash_buf[3];

    dst = (g_SYSTEM_BANK_SIZE * u8Bank) + u16Offfset;
    MDrv_FLASH_Read(dst, 3, flash_buf);
    /*
    printf("ReadFlashDataBaseVersion:");
    printf("u8Bank 0x%x, u16Offset 0x%x\n", u8Bank, u16Offset);
    printf("flash_buf: [1]0x%x [2]0x%x [3]0x%x\n", flash_buf[0], flash_buf[1], flash_buf[2]);
    */

    if( (flash_buf[0]==(U8)DATABASE_ID) && (flash_buf[1]==(U8)(DATABASE_ID>>8)) )
    {
        return (flash_buf[2]);
    }
    else
    {
        return (-1);
    }
}

/******************************************************************************/
/// API for MIU Store Database::
/// Copy database information from SDRAM to flash
/// @param u32srcaddr \b IN SDRAM address for Database information
/// @param s32size \b IN Database information size
/******************************************************************************/
void msAPI_MIU_QuickDataBaseErase(U8 u8Bank)
{
    U32 dst;

    dst = g_SYSTEM_BANK_SIZE * u8Bank;
    APIFLASH_DBG(printf("msAPI_MIU_QuickDataBaseErase, dst=0x%Lx \r\n", (U32)dst));

    if(g_bGenSettingStoreUseNewMethod)
    {
        if(!msAPI_Flash_WriteProtect_GetBPStatus())
        {
            msAPI_Flash_WriteProtect_SetBPStatus();
        }
        if(g_ENABLE_DVBT_1000_LCN)
        {
                MDrv_FLASH_AddressErase(dst, (g_SYSTEM_BANK_SIZE*2), FALSE);
        }
        else
        {
               MDrv_FLASH_AddressErase(dst, g_SYSTEM_BANK_SIZE, FALSE);
        }
    }
    else
    {
        if(g_ENABLE_DVBT_1000_LCN)
        {
                MDrv_FLASH_WriteProtect_Disable_Range_Set(dst, (g_SYSTEM_BANK_SIZE*2)); // MDrv_FLASH_WriteProtect(DISABLE); // <-@@@
                MDrv_FLASH_AddressErase(dst, (g_SYSTEM_BANK_SIZE*2), FALSE);
        }
        else
        {
               MDrv_FLASH_WriteProtect_Disable_Range_Set(dst, g_SYSTEM_BANK_SIZE); // MDrv_FLASH_WriteProtect(DISABLE); // <-@@@
               MDrv_FLASH_AddressErase(dst, g_SYSTEM_BANK_SIZE, FALSE);
        }
    }
}

/******************************************************************************/
/// API for MIU Store Database::
/// Copy database information from SDRAM to flash
/// @param u32srcaddr \b IN SDRAM address for Database information
/// @param s32size \b IN Database information size
/******************************************************************************/
BOOLEAN msAPI_MIU_QuickDataBaseCheck(void)
{
    return MDrv_FLASH_CheckWriteDone();
}

/******************************************************************************/
/// API for MIU Store Database::
/// Copy database information from SDRAM to flash
/// @param u32srcaddr \b IN SDRAM address for Database information
/// @param s32size \b IN Database information size
/******************************************************************************/
void msAPI_MIU_QuickGenSettingLoad(U8 u8Bank)    // SRAM2Flash
{
    U32 dst0,dst1;
    U32 dst;
    U16 count;
    U8 *flash_buf;
    U8 u8i;

    g_u16QuickGenSettingIdx = g_QUICK_DB_GENST_INVALID_IDX;

    flash_buf = (U8*)msAPI_Memory_Allocate(FLASH_BUF_SIZE, g_BUF_ID_FLASH);
    if (flash_buf == NULL)
    {
        __ASSERT(0);
        APIFLASH_DBG(printf("malloc flash_buf fail!\r\n"));
        return;
    }

    if(g_bGenSettingStoreUseNewMethod)
    {
        dst0 = (g_SYSTEM_BANK_SIZE * u8Bank);
        dst1 = (g_SYSTEM_BANK_SIZE * (u8Bank+1));
        count = g_QUICK_DB_GENST_NUM/2;
    }
    else
    {
        dst = (g_SYSTEM_BANK_SIZE * u8Bank);
        count = g_QUICK_DB_GENST_NUM;
    }

    if(g_bGenSettingStoreUseNewMethod)
    {
        MDrv_FLASH_Read(dst0,count, flash_buf);
        MDrv_FLASH_Read(dst1,count, &flash_buf[count]);
    }
    else
    {
        MDrv_FLASH_Read(dst,count, flash_buf);
    }

    if(g_bGenSettingStoreUseNewMethod)
    {
        if(g_bOpenGenstStoreDBG)
        {
            printf("\nLoadUnitFlag = ");
            for(u8i = 0; u8i<g_QUICK_DB_GENST_NUM; u8i++)
            {
                if(u8i == 0 || u8i == g_QUICK_DB_GENST_NUM/2)
                    printf("\n");
                printf("0x%X ", flash_buf[u8i]);

            }
            printf("\n");
        }

        for(u8i = 1; u8i<g_QUICK_DB_GENST_NUM; u8i++)
        {
            if(u8i == (g_QUICK_DB_GENST_NUM/2))
            {
                u8i = (g_QUICK_DB_GENST_NUM/2) + 1;
            }

            if(flash_buf[u8i] == g_QUICK_DB_GENST_GOOD)
            {
               if(u8i < g_QUICK_DB_GENST_NUM/2)
               {
                   g_u16QuickGenSettingIdx = 2*u8i - 1;
               }
               else
               {
                   g_u16QuickGenSettingIdx = (u8i - g_QUICK_DB_GENST_NUM/2)*2;
               }
               break;
            }
        }
        if(g_bOpenGenstStoreDBG)
        {
            printf("load u8i(%d),GenSettingIdx(%d) \r\n",u8i,g_u16QuickGenSettingIdx);
        }
    }
    else
    {
        for(u8i = 1; u8i<g_QUICK_DB_GENST_NUM; u8i++)
        {
           if(flash_buf[u8i] == g_QUICK_DB_GENST_GOOD)
           {
               g_u16QuickGenSettingIdx = u8i;
               break;
           }
        }
    }
    MSAPI_MEMORY_FREE(flash_buf, g_BUF_ID_FLASH);
}

/******************************************************************************/
/// API for MIU Store Database::
/// Copy database information from SDRAM to flash
/// @param u32srcaddr \b IN SDRAM address for Database information
/// @param s32size \b IN Database information size
/******************************************************************************/
void msAPI_MIU_QuickGenSettingErase(U8 u8Bank, U8 u8Wait)
{
    U32 dst;

    dst = g_SYSTEM_BANK_SIZE * u8Bank;
    APIFLASH_DBG(printf("msAPI_MIU_QuickGenSettingErase, dst=0x%Lx \r\n", (U32)dst));

    if(g_bGenSettingStoreUseNewMethod)
    {
        if(!msAPI_Flash_WriteProtect_GetBPStatus())
        {
            msAPI_Flash_WriteProtect_SetBPStatus();
        }
    }
    else
    {
        MDrv_FLASH_WriteProtect_Disable_Range_Set(dst, g_SYSTEM_BANK_SIZE); // MDrv_FLASH_WriteProtect(DISABLE); // <-@@@
    }
    MDrv_FLASH_AddressErase(dst, g_SYSTEM_BANK_SIZE, u8Wait);
}

void msAPI_MIU_CheckGenStateFlag(U16 u16GenIndex)
{
    U32 dst;
    U8 ucByte;
    U8 u8i;
    U8 u8Bank = g_QUICK_DB_GENSETTING_BANK;

    for(u8i = 1; u8i<g_QUICK_DB_GENST_NUM; u8i++)
    {
        if(u8i%2)
            dst = (g_SYSTEM_BANK_SIZE * u8Bank) + (u8i/2 + 1);
        else
            dst = (g_SYSTEM_BANK_SIZE * (u8Bank + 1)) + (u8i/2);
        MDrv_FLASH_Read(dst, 1, &ucByte);
        if(g_bOpenGenstStoreDBG)
        {
            printf("\nFlag[%d][0x%X] = 0x%X ", u8i, dst, ucByte);
            if(u8i == u16GenIndex)
                printf("----is CurIndex!", ucByte);
        }
        if(u8i == u16GenIndex) continue;

        if(ucByte!=0xFF && ucByte==g_QUICK_DB_GENST_GOOD)
        {
            ucByte = g_QUICK_DB_GENST_OBSOLETE;
            MDrv_FLASH_Write(dst, 1, &ucByte);
            if(g_bOpenGenstStoreDBG)
            {
                printf("\n[WAMING: Find GOOD Index]WamingIndex=%d, CurIndex=%d, Address=0x%X\n", u8i, u16GenIndex, dst);
            }
        }
    }
}

/******************************************************************************/
/// API for MIU Store Database::
/// Copy database information from SDRAM to flash
/// @param u32srcaddr \b IN SDRAM address for Database information
/// @param s32size \b IN Database information size
/******************************************************************************/
void msAPI_MIU_QuickGenSettingWrite(U8 u8Bank, U32 u32srcaddr, S32 s32size)    // SRAM2Flash
{
    U32 dst;
    U32 count;
    U8 *flash_buf;

    flash_buf = (U8*)msAPI_Memory_Allocate(FLASH_BUF_SIZE, g_BUF_ID_FLASH);
    if (flash_buf == NULL)
    {
        __ASSERT(0);
        APIFLASH_DBG(printf("malloc flash_buf fail!\r\n"));
        return;
    }
    if(g_bGenSettingStoreUseNewMethod&&g_bOpenGenstStoreDBG)
    {
        printf("Store2Flash,src=0x%Lx,dst=0x%Lx,sz=0x%Lx\n", u32srcaddr, (U32)(g_SYSTEM_BANK_SIZE * u8Bank), s32size);
    }

    if(g_bGenSettingStoreUseNewMethod)
    {
        if(!msAPI_Flash_WriteProtect_GetBPStatus())
        {
            msAPI_Flash_WriteProtect_SetBPStatus();
        }
    }
    else
    {
        MDrv_FLASH_WriteProtect_Disable_Range_Set(g_SYSTEM_BANK_SIZE * u8Bank, g_SYSTEM_BANK_SIZE); // MDrv_FLASH_WriteProtect(DISABLE); // <-@@@
    }

    if(g_bGenSettingStoreUseNewMethod)
    {
        if(g_u16QuickGenSettingIdx%2)
        {
            dst = (g_SYSTEM_BANK_SIZE * u8Bank) + ((U32)g_QUICK_DB_GENST_SIZE * (U32)(g_u16QuickGenSettingIdx/2 + 1));
        }
        else
        {
            dst = (g_SYSTEM_BANK_SIZE * u8Bank) + ((U32)g_QUICK_DB_GENST_SIZE * (U32)(g_u16QuickGenSettingIdx/2));
        }

        if(g_bOpenGenstStoreDBG)
        {
            printf("\r\n [GenSettingWrite u8Bank_00]:0x%X---dst=0x%X\n", u8Bank, dst);
        }
    }
    else
    {
        dst = (g_SYSTEM_BANK_SIZE * u8Bank) + ((U32)g_QUICK_DB_GENST_SIZE * (U32)g_u16QuickGenSettingIdx);
    }

    while (s32size > 0)
    {
        count = MIN(s32size, FLASH_BUF_SIZE);

        memcpy(flash_buf, (void*)_PA2VA(u32srcaddr), count);
        u32srcaddr += count;
        MDrv_FLASH_Write(dst,count, flash_buf);
        dst += count;
        s32size -= count;
    }

    //=====
    if(g_bGenSettingStoreUseNewMethod)
    {
        if(g_bOpenGenstStoreDBG)
        {
            printf("\r\n Write g_u16QuickGenSettingIdx:%d\n",g_u16QuickGenSettingIdx);
            printf("\r\n [GenSettingWrite u8Bank_11]:0x%X\n", u8Bank);
        }
        if(g_u16QuickGenSettingIdx%2)
        {
            dst = (g_SYSTEM_BANK_SIZE * u8Bank) + (g_u16QuickGenSettingIdx/2 + 1);
            flash_buf[0] = g_QUICK_DB_GENST_GOOD;
            count = 1;
            MDrv_FLASH_Write(dst, count, flash_buf);
            if(g_bOpenGenstStoreDBG)
            {
                printf("\r\n a [GOOD]VersionAddr dst1[%x]\n",dst);
            }

            if(g_u16QuickGenSettingIdx != 1)
                dst = (g_SYSTEM_BANK_SIZE * (u8Bank+1)) + (g_u16QuickGenSettingIdx/2);
            else
                dst = (g_SYSTEM_BANK_SIZE * (u8Bank+1)) + ((g_QUICK_DB_GENST_NUM-2)/2);
            flash_buf[0] = g_QUICK_DB_GENST_OBSOLETE;
            count = 1;
            MDrv_FLASH_Write(dst, count, flash_buf);
            if(g_bOpenGenstStoreDBG)
            {
                printf("\r\n a [OBSOLETE]VersionAddr dst0[%x]\n",dst);
            }
        }
        else
        {
            dst = (g_SYSTEM_BANK_SIZE * u8Bank) + (g_u16QuickGenSettingIdx/2);
            flash_buf[0] = g_QUICK_DB_GENST_GOOD;
            count = 1;
            MDrv_FLASH_Write(dst, count, flash_buf);
            if(g_bOpenGenstStoreDBG)
            {
                printf("\r\n b [GOOD]VersionAddr dst1[%x]\n",dst);
            }

            dst = (g_SYSTEM_BANK_SIZE * (u8Bank-1)) + (g_u16QuickGenSettingIdx/2);
            flash_buf[0] = g_QUICK_DB_GENST_OBSOLETE;
            count = 1;
            MDrv_FLASH_Write(dst, count, flash_buf);
            if(g_bOpenGenstStoreDBG)
            {
                printf("\r\n b [OBSOLETE]VersionAddr dst0[%x]\n",dst);
            }
        }

        msAPI_MIU_CheckGenStateFlag(g_u16QuickGenSettingIdx);
    }
    else
    {
        dst = (g_SYSTEM_BANK_SIZE * u8Bank) + (g_u16QuickGenSettingIdx - 1);
        flash_buf[0] = g_QUICK_DB_GENST_OBSOLETE;
        flash_buf[1] = g_QUICK_DB_GENST_GOOD;
        count = 2;
        MDrv_FLASH_Write(dst, count, flash_buf);
    }
    //=====
    if(g_bGenSettingStoreUseNewMethod)
    {
        msFlash_ActiveFlash_Set_HW_WP(ENABLE);
    }
    else
    {
        MDrv_FLASH_WriteProtect(ENABLE);
    }
    MSAPI_MEMORY_FREE(flash_buf, g_BUF_ID_FLASH);
}

void msAPI_Flash_EraseGensettingBank(void)
{
    if(g_u16QuickGenSettingIdx >= (g_QUICK_DB_GENST_NUM - 1))
    {
        msAPI_MIU_QuickGenSettingErase(g_QUICK_DB_GENSETTING_BANK, TRUE);
        g_u16QuickGenSettingIdx = 0;
        g_u8EraseGenSettingBank = ERASE_BANK0;
    }
    else if(g_u8EraseGenSettingBank == ERASE_BANK0 && g_u16QuickGenSettingIdx == 2)
    {
        msAPI_MIU_QuickGenSettingErase(g_QUICK_DB_GENSETTING_BANK+1, TRUE);
        g_u16QuickGenSettingIdx = 1;
        g_u8EraseGenSettingBank = ERASE_NUM;
    }
}

void msAPI_Flash_CheckFlash(void)
{
    MApp_Printf_Flash_Variable();

    msAPI_MIU_QuickGenSettingLoad(g_QUICK_DB_GENSETTING_BANK);

    if(g_u16QuickGenSettingIdx != g_QUICK_DB_GENST_INVALID_IDX)
    {
        if(g_bOpenGenstStoreDBG)
        {
            printf("GenSetting OK!\n");
        }

        if(g_bGenSettingStoreUseNewMethod)
        {
            if(g_u16QuickGenSettingIdx%2)
            {
                msAPI_MIU_Copy(
                       g_SYSTEM_BANK_SIZE*g_QUICK_DB_GENSETTING_BANK+((U32)g_QUICK_DB_GENST_SIZE * (U32)(g_u16QuickGenSettingIdx/2 + 1)),
                       g_u32DataBaseAddr,
                       g_RM_GEN_USAGE,
                       g_MEMCOPYTYPE);
            }
            else
            {
                 msAPI_MIU_Copy(
                    g_SYSTEM_BANK_SIZE*(g_QUICK_DB_GENSETTING_BANK+1)+((U32)g_QUICK_DB_GENST_SIZE * (U32)(g_u16QuickGenSettingIdx/2)),
                    g_u32DataBaseAddr,
                    g_RM_GEN_USAGE,
                    g_MEMCOPYTYPE);
            }
        }
        else
        {
              msAPI_MIU_Copy(
                g_SYSTEM_BANK_SIZE*g_QUICK_DB_GENSETTING_BANK+((U32)g_QUICK_DB_GENST_SIZE * (U32)(g_u16QuickGenSettingIdx)),
                g_u32DataBaseAddr,
                g_RM_GEN_USAGE,
                g_MEMCOPYTYPE);
        }
        MApp_LoadGenSetting();
    }
    else
    {
        if(g_bOpenGenstStoreDBG)
        {
            printf("GenSetting NG! Reset \r\n");
        }

        MApp_InitGenSetting();

        msAPI_MIU_QuickGenSettingErase(g_QUICK_DB_GENSETTING_BANK, TRUE);
        msAPI_MIU_QuickGenSettingErase(g_QUICK_DB_GENSETTING_BANK+1, TRUE);
        g_u16QuickGenSettingIdx = 0;
        if(g_bOpenGenstStoreDBG)
        {
            printf("\n----msAPI_Flash_CheckFlash----\n");
        }
        MApp_DB_SaveGenSetting();
    }
}

void MApp_Printf_Flash_Variable(void)
{
   // printf("\r\n ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
   // printf(" g_bOpenGenstStoreDBG: %d\n",g_bOpenGenstStoreDBG);
    if(g_bOpenGenstStoreDBG)
   {
    printf(" g_bGenSettingStoreUseNewMethod: %d\n",g_bGenSettingStoreUseNewMethod);
    printf(" g_ENABLE_DVBT_1000_LCN: %d\n",g_ENABLE_DVBT_1000_LCN);
    printf(" g_DB_IN_NAND: %d\n",g_DB_IN_NAND);
    printf(" g_SYSTEM_BANK_SIZE: %d\n",g_SYSTEM_BANK_SIZE);
    printf(" g_QUICK_DB_GENSETTING_BANK: %d\n",g_QUICK_DB_GENSETTING_BANK);
    printf(" g_u8EEPROM_DB_STORAGE: %d\n",g_u8EEPROM_DB_STORAGE);
    printf(" g_u32DataBaseAddr: %d\n",g_u32DataBaseAddr);
    printf(" g_RM_GENSET_START_ADR: %d\n",g_RM_GENSET_START_ADR);
    printf(" g_QUICK_DB_GENST_NUM: %d\n",g_QUICK_DB_GENST_NUM);
    printf(" g_RM_GEN_USAGE: %d\n",g_RM_GEN_USAGE);
    printf(" g_BUF_ID_FLASH: %d\n",g_BUF_ID_FLASH);
    printf(" g_QUICK_DB_GENST_INVALID_IDX: %d\n",g_QUICK_DB_GENST_INVALID_IDX);
    printf(" g_QUICK_DB_GENST_GOOD: %d\n",g_QUICK_DB_GENST_GOOD);
    printf(" g_QUICK_DB_GENST_OBSOLETE: %d\n",g_QUICK_DB_GENST_OBSOLETE);
    printf(" g_MEMCOPYTYPE: %d\n",g_MEMCOPYTYPE);
    printf(" g_RM_SIZE_GENSET: %d\n",g_RM_SIZE_GENSET);
    printf(" g_QUICK_DB_GENST_SIZE: %d\n",g_QUICK_DB_GENST_SIZE);
    printf(" g_QUICK_DB_GENST_MASK: %d\n",g_QUICK_DB_GENST_MASK);
    printf(" g_QUICK_DB_GENST_UPDATE: %d\n",g_QUICK_DB_GENST_UPDATE);
    printf(" g_QUICK_DB_GENST_READY: %d\n",g_QUICK_DB_GENST_READY);
    printf(" g_QUICK_DB_GENST_MODIFIED:%d\n",g_QUICK_DB_GENST_MODIFIED);
    printf(" g_QUICK_DB_GENST_ERASE_DONE: %d\n",g_QUICK_DB_GENST_ERASE_DONE);
    printf(" g_QUICK_DB_GENST_ERASE_IN_PROGRESS: %d\n",g_QUICK_DB_GENST_ERASE_IN_PROGRESS);
    printf("\r\n ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
  }
}

U16  msAPI_Flash_GetVersion(void)
{
     printf(" Flash Build Version=%x\n",MSIF_FLASH_BUILD_VERSION);
     return  MSIF_FLASH_BUILD_VERSION;
}

#undef MSAPI_FLASH_C

