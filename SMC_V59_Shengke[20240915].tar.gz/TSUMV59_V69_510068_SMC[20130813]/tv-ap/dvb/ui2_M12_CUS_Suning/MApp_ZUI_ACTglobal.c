////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (¡§MStar Confidential Information¡¨) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#define MAPP_ZUI_ACTGLOBAL_C
#define _ZUI_INTERNAL_INSIDE_ //NOTE: for ZUI internal

//-------------------------------------------------------------------------------------------------
// Include Files
//-------------------------------------------------------------------------------------------------
#include "Board.h"
#include "datatype.h"
#include "MsCommon.h"
#include "apiXC.h"
#include "apiXC_Adc.h"
#include "MApp_GlobalSettingSt.h"
#include "MApp_ZUI_Main.h"
#include "MApp_ZUI_APIcommon.h"
#include "MApp_ZUI_APIstrings.h"
#include "MApp_ZUI_APIwindow.h"
#include "ZUI_tables_h.inl"
#include "MApp_ZUI_APIgdi.h"
#include "MApp_ZUI_ACTeffect.h"
#include "MApp_ZUI_ACTmainpage.h"

#include "MApp_ZUI_APIcontrols.h"
#include "ZUI_exefunc.h"
#include "MApp_UiMenuDef.h"
#include "MApp_Key.h"
#include "apiGOP.h"
#include "drvUartDebug.h"
#include "MApp_ZUI_CTLbuttonclick.h"
#if DTV_HD_USE_FBL
  #include "apiVDEC.h"
#endif
//osd pages....
#include "MApp_ZUI_ACTmainpage.h"
#include "MApp_ZUI_ACTmenufunc.h"
#include "MApp_ZUI_ACTchannelinfo.h"
#include "MApp_ZUI_ACTchlist.h"
#if DVB_C_ENABLE
#include "MApp_ZUI_ACTcadtvmanualtuning.h"
#endif
#include "MApp_ZUI_ACTdtvmanualtuning.h"
#include "MApp_ZUI_ACTatvmanualtuning.h"
#include "MApp_ZUI_ACTpredit.h"
#include "MApp_ZUI_ACTaudlang.h"
#include "MApp_ZUI_ACTautotuning.h"
#include "MApp_ZUI_ACTscreensaver.h"
#include "MApp_ZUI_ACTinputsource.h"
#include "MApp_ZUI_ACTaudiovolume.h"
#include "MApp_ZUI_ACTinstall.h"
#include "MApp_ZUI_ACThotkey.h"
#if ENABLE_CUS_FACTORY_HOTKEY_MENU
#include "MApp_ZUI_ACTfactoryhotkey.h"
#endif
#include "MApp_ZUI_ACTsublang.h"
#include "MApp_ZUI_ACTmsgbox.h"
#include "MApp_ZUI_ACTmenudlgfunc.h"
#include "MApp_ZUI_ACTepg.h"
#include "MApp_ZUI_ACTcimmi.h"
#include "MApp_ZUI_ACTexpertmenu.h"

#if (ENABLE_OAD)
#include "MApp_ZUI_ACToad.h"
#endif
#if ENABLE_DMP
#include "MApp_ZUI_ACTdmp.h"
#include "mapp_txt.h"
#endif
#ifdef ENABLE_BT
#include "MApp_ZUI_ACTBT.h"
#endif

#ifdef ENABLE_KTV
#include "MApp_ZUI_ACTKTV.h"
#endif

#if ENABLE_PVR
    #include "MApp_ZUI_ACTpvr.h"
    #include "MApp_ZUI_ACTpvrBrowser.h"
#endif

#include "MApp_ZUI_ACTfactorymenu.h"
#include "MApp_ZUI_ACTtenkey.h"
#include "MApp_ZUI_ACTglobal.h"
#include "MApp_ZUI_ACTeffectsetting.h"

#include "MApp_ZUI_ACTflippage.h"
#include "MApp_AnalogInputs.h"

#if  (((ENABLE_SBTVD_BRAZIL_APP) && (BRAZIL_CC))||(ATSC_CC == ATV_CC))
#include "mapp_closedcaption.h"
#endif

#if ( ENABLE_DVB_TAIWAN_APP || ENABLE_SBTVD_BRAZIL_APP || (TV_SYSTEM == TV_NTSC) )
#include "msAPI_ATVSystem.h"
#endif

#if (ENABLE_SUBTITLE)
#include "MApp_Subtitle.h"
#endif
#if ENABLE_TTX
#include "mapp_ttx.h"
#endif
#if ENABLE_CUS_RS232_FUNC
#include "afm.h"
#endif

#if ENABLE_6M30_OSD_PROTECT
#include "drvUrsa6M30.h"
#endif

extern ZUI_STATE _eZUIState;
extern E_OSD_ID _eActiveOSD;



/////////////////////////////////////////////////////////
// for customize

///////////////////////////////////////////////////////////////////////////////
///  global  MApp_ZUI_ACT_DecIncValue
///  increase or decrease a value with min, max and step
///
///  @param [in]       bInc BOOLEAN    increase or not
///  @param [in]       u16Value U16    integer value
///  @param [in]       u16MinValue U16    min value
///  @param [in]       u16MaxValue U16    max value
///  @param [in]       u8Step U8          step value
///
///  @return U16 result integer
///
///  @author MStarSemi @date 2007/1/25
///////////////////////////////////////////////////////////////////////////////
U16 MApp_ZUI_ACT_DecIncValue(BOOLEAN bInc, U16 u16Value, U16 u16MinValue, U16 u16MaxValue, U8 u8Step)
{
    if (bInc) //((action == MIA_INCVALUE)||(action == MIA_INCVALUE_BAR))
    {
        if(u16Value >= u16MaxValue)
            return u16MaxValue;
        u16Value += u8Step;
        if(u16Value > u16MaxValue)
            u16Value = u16MaxValue;
    }
    else //if( (action==MIA_DECVALUE) || (action == MIA_DECVALUE_BAR))
    {
        if(u16Value <= u16MinValue)
            return u16MinValue;
        if(u16Value < u8Step)
            u16Value = 0;
        else
            u16Value -= u8Step;
        if(u16Value < u16MinValue)
            u16Value = u16MinValue;
    }
    return u16Value;
}

S8 MApp_ZUI_ACT_DecIncS8Value(BOOLEAN bInc, S8 s8Value, S8 s8MinValue, S8 s8MaxValue, U8 u8Step)
{
    if (bInc) //((action == MIA_INCVALUE)||(action == MIA_INCVALUE_BAR))
    {
        if((S8)(s8Value + u8Step) >= s8MaxValue)
            return s8MaxValue;
        else
            return (S8)(s8Value + u8Step);
    }
    else //if( (action==MIA_DECVALUE) || (action == MIA_DECVALUE_BAR))
    {
       if((S8)(s8Value - u8Step) <= s8MinValue)
            return s8MinValue;
       else
            return (S8)(s8Value - u8Step);
    }
    return s8Value;
}

///////////////////////////////////////////////////////////////////////////////
///  global  MApp_ZUI_ACT_DecIncValue_Cycle
///  increase or decrease a value with min, max and step
///    if reach to max value => cycle to min value
///
///  @param [in]       bInc BOOLEAN    increase or not
///  @param [in]       u16Value U16    integer value
///  @param [in]       u16MinValue U16    min value
///  @param [in]       u16MaxValue U16    max value
///  @param [in]       u8Step U8          step value
///
///  @return U16 result integer
///
///  @author MStarSemi @date 2007/1/25
///////////////////////////////////////////////////////////////////////////////
U16 MApp_ZUI_ACT_DecIncValue_Cycle(BOOLEAN bInc, U16 u16Value, U16 u16MinValue, U16 u16MaxValue, U8 u8Step)
{
    if (bInc) //action == MIA_INCVALUE)
    {
        if (u16Value >= u16MaxValue)
        {
            return u16MinValue;
        }
        if (u16Value < u16MinValue)
        {
            // Minimun value
            u16Value = u16MinValue;
        }
        else
        {
            u16Value += u8Step;
        }
        if (u16Value > u16MaxValue)
        {
            u16Value = u16MinValue;
        }
    }
    else //if (action == MIA_DECVALUE)
    {
        if (u16Value <= u16MinValue)
        {
            return u16MaxValue;
        }
        if (u16Value < u8Step)
        {
            u16Value = 0;
        }
        else
        {
            u16Value -= u8Step;
        }
        if (u16Value < u16MinValue)
        {
            u16Value = u16MaxValue;
        }
    }
    return u16Value;
}


///////////////////////////////////////////////////////////////////////////////
///  private  _MApp_ZUI_ACT_MapToVirtualKeyCode
///     map system-dependent key code to system-independent key code
///     this mapping might be changed for different project/codebase
///
///  @param [in]       IR_key_code U8          system-dependent key code
///
///  @return VIRTUAL_KEY_CODE    system-independent key code
///
///  @author MStarSemi @date 2007/1/25
///////////////////////////////////////////////////////////////////////////////
VIRTUAL_KEY_CODE _MApp_ZUI_ACT_MapToVirtualKeyCode(U8 IR_key_code)
{
    switch(IR_key_code)
    {
        //case KEY_TV_RADIO:            return VK_TV_RADIO;
        //case KEY_CHANNEL_LIST:        return VK_CHANNEL_LIST;
        case KEY_CHANNEL_FAV_LIST:  return VK_CHANNEL_FAV_LIST;
        case KEY_CHANNEL_RETURN:
            //if(IsStorageInUse())
            //return VK_EXIT;
            //else
            return VK_CHANNEL_RETURN;
        case KEY_CHANNEL_PLUS:
            if(IsStorageInUse())
            return VK_PAGE_UP;
            else
            return VK_CHANNEL_PLUS;
        case KEY_CHANNEL_MINUS:
            if(IsStorageInUse())
            return VK_PAGE_DOWN;
            else
            return VK_CHANNEL_MINUS;

        case KEY_AUDIO:             return VK_AUDIO;
        case KEY_VOLUME_PLUS:       return VK_VOLUME_PLUS;
        case KEY_VOLUME_MINUS:      return VK_VOLUME_MINUS;

        case KEY_UP:                return VK_UP;
        case KEY_POWER:             return VK_POWER;
        case KEY_EXIT:              return VK_EXIT;
        case KEY_MENU:              return VK_MENU;
        case KEY_DOWN:              return VK_DOWN;
        case KEY_LEFT:              return VK_LEFT;
        case KEY_SELECT:            return VK_SELECT;
        case KEY_RIGHT:             return VK_RIGHT;
        case KEY_HOME:              return VK_HOME;
        case KEY_0:             return VK_NUM_0;
        case KEY_1:             return VK_NUM_1;
        case KEY_2:             return VK_NUM_2;
        case KEY_3:             return VK_NUM_3;
        case KEY_4:             return VK_NUM_4;
        case KEY_5:             return VK_NUM_5;
        case KEY_6:             return VK_NUM_6;
        case KEY_7:             return VK_NUM_7;
        case KEY_8:             return VK_NUM_8;
        case KEY_9:             return VK_NUM_9;

        case KEY_MUTE:              return VK_MUTE;
        //case KEY_PAGE_UP:             return VK_PAGE_UP;
        //case KEY_PAGE_DOWN:           return VK_PAGE_DOWN;
        case KEY_INPUT_SOURCE:          return VK_INPUT_SOURCE;
        case KEY_CHANNEL_LIST:          return VK_CHANNEL_LIST;
        case KEY_EPG:                   return VK_EPG;
        case KEY_INFO:                  return VK_INFO;
        case KEY_BACK:                  return VK_BACK;
        case KEY_RED:                   return VK_RED;
        case KEY_GREEN:
            //if(IsStorageInUse())
            //return VK_PAGE_UP;
            //else
            return VK_GREEN;

        case KEY_BLUE:                  return VK_BLUE;
        case KEY_YELLOW:
            //if(IsStorageInUse())
            //return VK_PAGE_DOWN;
            //else
            return VK_YELLOW;

        case KEY_MTS:                   return VK_MTS;
        case KEY_TTX:                   return VK_TTX;
        case KEY_SLEEP:                 return VK_SLEEP;
  //      case KEY_PICTURE:               return VK_PICTURE;
        case KEY_ZOOM:                  return VK_ZOOM;
        case KEY_FREEZE:                return VK_FREEZE;
        case KEY_INDEX:                 return VK_INDEX;

#if ENABLE_DMP
        case KEY_PLAY:                  return VK_PLAY;
        case KEY_PAUSE:                 return VK_PAUSE;
        case KEY_STOP:                  return VK_STOP;
        case KEY_NEXT:                  return VK_NEXT;
        case KEY_PREVIOUS:              return VK_PREVIOUS;
        case KEY_FF:                    return VK_FF;
        case KEY_REWIND:                return VK_REWIND;
        case KEY_PAGE_UP:               return VK_PAGE_UP;
        case KEY_PAGE_DOWN:             return VK_PAGE_DOWN;
        case KEY_CC:                    return VK_CC;
        case KEY_RECORD:                return VK_RECORD;
        case KEY_SUBTITLE:              return VK_SUBTITLE;
        case KEY_UPDATE:                return VK_UPDATE;
        case KEY_TV:                    return VK_TV;
        case KEY_HDMI:                  return VK_HDMI;
        case KEY_AV:                    return VK_AV;
        case KEY_DMP:                   return VK_DMP;
        case KEY_PC:                    return VK_PC;
        case KEY_COMPONENT:             return VK_COMPONENT;
#endif
        case KEY_LOCK:                  return VK_LOCK;
//#if (ENABLE_PIP)
        case KEY_PIP:                   return VK_PIP;
//#endif
#ifdef ENABLE_BUTTON_LOCK
        case KEY_BUTTON_LOCK:           return VK_KEY_BUTTON_LOCK;
#endif

#if CUS_SMC_ENABLE_HOTEL_MODE
		//case KEY_SOURCE_KEY_LOCK:       return VK_KEY_SOURCE_KEY_LOCK;
		case KEY_REMOTE_CONTROL_LOCK:   return VK_KEY_REMOTE_CONTROL_LOCK;
		case KEY_BUTTON_UNLOCK_HOTEL_MODE:       return VK_BUTTON_UNLOCK_HOTEL_MODE;
		case KEY_BUTTON_LOCK_HOTEL_MODE:   return VK_BUTTON_LOCK_HOTEL_MODE;
#endif

#if ENABLE_3D_PROCESS
        case KEY_3D_SETTING:            return VK_3D_SETTING;
#endif

        //fake keys...
        case KEY_COUNTDOWN_EXIT_TT_SUBTITLE: return VK_EXIT;
        case KEY_EPGTIMER_COUNTDOWN:
        {
            #if ENABLE_DMP

            if( MApp_ZUI_GetActiveOSD() == E_OSD_DMP )
            {
                return VK_EPGTIMER_COUNTDOWN;
            }
            else
            #endif
            {
                return VK_EXIT;
            }

        }
		// CUS_XM Xue 20120802: add picture mode key  XF112PIOCNMS0-902
		case KEY_PICTURE:   return VK_VIDEO;
		case KEY_REPEAT:   return VK_REPEAT; // CUS xm helen add
        case KEY_AB:                        return VK_AB;
        default:                    return VK_NULL;
    }
}

///////////////////////////////////////////////////////////////////////////////
///  private  _MApp_ZUI_ACT_AppClose
///  close an application, default procedure
///    NOTE: DO NOT MODIFY THIS FUNCTION!
///
///  @return no return value
///
///  @author MStarSemi @date 2007/1/25
///////////////////////////////////////////////////////////////////////////////
static void _MApp_ZUI_ACT_AppClose(void)
{
    HWND wnd;

    //UNUSED(sender);

    MApp_ZUI_API_SetFocus(HWND_INVALID);

    //for (wnd = HWND_MAX-1; wnd != HWND_INVALID; --wnd) //NOTE: from child to parent
    //  MApp_ZUI_API_PostMessage(wnd, MSG_DESTROYPANES, 0);
    for (wnd = HWND_MAX-1; wnd != HWND_INVALID; --wnd)
        MApp_ZUI_API_SendMessage(wnd, MSG_DESTROY, 0);

    //MApp_Menu_Album_Delete ();

    g_GUI_WindowList = 0;
    g_GUI_WinDrawStyleList =    0;
    g_GUI_WindowPositionList = 0;
    #if ZUI_ENABLE_ALPHATABLE
    g_GUI_WinAlphaDataList = 0;
    #endif
    HWND_MAX = HWND_MAINFRAME+1;
}


///////////////////////////////////////////////////////////////////////////////
///  global  MApp_ZUI_ACT_StartupOSD
///  startup and setup a specific osd page
///    NOTE: DO NOT MODIFY THIS FUNCTION UNLESS YOU WANT TO ADD NEW OSD PAGE HANDLER!
///
///  @param [in]       id E_OSD_ID     osd page index
///
///  @return BOOLEAN success or not
///
///  @author MStarSemi @date 2007/1/25
///////////////////////////////////////////////////////////////////////////////
BOOLEAN MApp_ZUI_ACT_StartupOSD(U32 id)
{
    //2007/12/26: consider gop switching
    U8 u8PrevGopID = MApi_GOP_GWIN_GetCurrentGOP();

    ZUI_MSG(printf("[]startup:%u [now=%u,%u]\n", (U8)id, (U8)_eActiveOSD, (U8)_eZUIState));
#if (ENABLE_CI && ENABLE_CI_PLUS && MHEG5_ENABLE)
    if((id == E_OSD_SCREEN_SAVER)&&(E_MHEG_CI_RUNNING == msAPI_IsCIMHEGRun()))
        return FALSE;
#endif

    #if ENABLE_CUS_RS232_FUNC && ENABLE_CUS_BURNING_MODE
    if((id == E_OSD_SCREEN_SAVER) && (((g_bIsOpenTestPattern == TRUE) && IsAfmMode()) || (stGenSetting.g_FactorySetting.fBuringMode && (g_bDisableBurninMode == FALSE))))
    {
        return FALSE;
    }
    #endif


#if ((ENABLE_SBTVD_BRAZIL_APP) && (BRAZIL_CC))
  if ( (IsDTVInUse() && stGenSetting.g_SysSetting.enDTVCaptionType != DTV_CAPTION_OFF)
     ||(( IsATVInUse() || IsAVInUse() ) && stGenSetting.g_SysSetting.enATVCaptionType != ATV_CAPTION_TYPE_OFF) )
  {
      if ( MApp_CC_GetInfo(CC_SELECTOR_STATUS_CODE) == STATE_CAPTION_PARSER)
      {
          MApp_CC_StopParser();
          MApp_Dmx_PES_Stop();
      }
  }
#endif

#if (ATSC_CC == ATV_CC)
    if ((IsATVInUse()||IsAVInUse())&& stGenSetting.g_SysSetting.enATVCaptionType != ATV_CAPTION_TYPE_OFF)
    {
        if ( MApp_CC_GetInfo(CC_SELECTOR_STATUS_CODE) == STATE_CAPTION_PARSER)
        {
             MApp_CC_StopParser();
             MApp_Set_CCState(FALSE);
        }
    }
#endif

#if (CHIP_FAMILY_TYPE == CHIP_FAMILY_M12)
    #if ENABLE_DTV
    if (IsDTVInUse())
    {
        #if (ENABLE_SUBTITLE)
        if ( MApp_Subtitle_GetStatus() == STATE_SUBTITLE_DECODING)
        {
             MApp_Subtitle_SetShowStatus(FALSE);
        }
        #endif
        #if ENABLE_TTX
        MApp_TTX_ExitDTV_TTXSystem();
        #endif
    }
    #endif
#endif

    if (_eZUIState == E_ZUI_STATE_UNKNOW)
        return FALSE;

    if (_eZUIState == E_ZUI_STATE_RUNNING && _eActiveOSD == id)
        return TRUE; //already init

    if (u8PrevGopID != OSD_GOP_ID)
        MApi_GOP_GWIN_SwitchGOP(OSD_GOP_ID);


    if (_eZUIState != E_ZUI_STATE_STANDBY)
    {
        MApp_ZUI_ACT_ShutdownOSD();
    }

    //printf("sizeof(WINDOWALPHADATA)=%bu\n", (U8)sizeof(WINDOWALPHADATA));
    //printf("sizeof(WINDOWDRAWSTYLEDATA)=%bu\n", (U8)sizeof(WINDOWDRAWSTYLEDATA));
    //printf("sizeof(WINDOWDATA)=%bu\n", (U8)sizeof(WINDOWDATA));

    MApp_ZUI_API_SetFocus(HWND_INVALID);
    _eZUIState = E_ZUI_STATE_RUNNING;
    _eActiveOSD = (E_OSD_ID) id;
    MApp_ZUI_API_EmptyMessageQueue();

    //NOTE: if an new OSD page added, please add here!
    switch(id)
    {
        case E_OSD_MAIN_MENU:
            MApp_ZUI_ACT_AppShowMainMenu();
            break;

        case E_OSD_CHANNEL_INFO:
            MApp_ZUI_ACT_AppShowChannelInfo();
            break;
#if ENABLE_DTV
        case E_OSD_DTV_MANUAL_TUNING:
            MApp_ZUI_ACT_AppShowDtvManualTuning();
            break;
#endif
        case E_OSD_ATV_MANUAL_TUNING:
            MApp_ZUI_ACT_AppShowAtvManualTuning();
            break;

        case E_OSD_PROGRAM_EDIT:
            MApp_ZUI_ACT_AppShowProgramEdit();
            break;

        case E_OSD_AUDIO_LANGUAGE:
            MApp_ZUI_ACT_AppShowAudioLanguage();
            break;

        #if ENABLE_SUBTITLE
        case E_OSD_SUBTITLE_LANGUAGE:
            MApp_ZUI_ACT_AppShowSubtitleLanguage();
            break;
        #endif

        case E_OSD_AUTO_TUNING:
            MApp_ZUI_ACT_AppShowAutoTuning();
            break;

        case E_OSD_SCREEN_SAVER:
	// CUS_XM Xue 20120721: modify burnin on show saver icon
            #if ENABLE_CUS_BURNING_MODE
            if(stGenSetting.g_FactorySetting.fBuringMode)
            {
                return TRUE;
            }

            #endif

			MApp_ZUI_ACT_AppShowScreenSaver();
            break;

        case E_OSD_INPUT_SOURCE:
            MApp_ZUI_ACT_AppShowInputSource();
            break;

        case E_OSD_AUDIO_VOLUME:
            MApp_ZUI_ACT_AppShowAudioVolume();
            break;

        #if OBA2
        case E_OSD_UPGRADE:
            MApp_ZUI_ACT_AppShowUpgrade();
            break;
        #endif

        case E_OSD_INSTALL_GUIDE:
            MApp_ZUI_ACT_AppShowInstallGuide();
            break;

        case E_OSD_HOTKEY_OPTION:
            MApp_ZUI_ACT_AppShowHotkeyOption();
            break;
       #if ENABLE_CUS_FACTORY_HOTKEY_MENU
        case E_OSD_FACTORY_HOTKEY_OPTION:
            MApp_ZUI_ACT_AppShowFactoryHotkeyOption();
            break;
       #endif
        case E_OSD_MESSAGE_BOX:
            MApp_ZUI_ACT_AppShowMessageBox();
            break;

        case E_OSD_CHANNEL_LIST:
            MApp_ZUI_ACT_AppShowChannelList();
            break;
#if (ENABLE_OAD)
        case E_OSD_OAD:
            MApp_ZUI_ACT_AppShowOAD();
            break;
#endif
#if (ENABLE_DTV_EPG)
        case E_OSD_EPG:
            MApp_ZUI_ACT_AppShowEpg();
            break;
#endif  //#if (ENABLE_DTV_EPG)

#if (ENABLE_CI)
        case E_OSD_CIMMI:
            MApp_ZUI_ACT_AppShowCIMMI();
            break;
#endif

#if ENABLE_DMP
        case E_OSD_DMP:
            MApp_ZUI_ACT_AppShowDmp();
            break;
#endif

        case E_OSD_FACTORY_MENU:
            MApp_ZUI_ACT_AppShowFactoryMenu();
            break;

        case E_OSD_EXPERT_MENU:
            MApp_ZUI_ACT_AppShowExpertMenu();
            break;

        case E_OSD_TENKEY_NUMBER:
            MApp_ZUI_ACT_AppShowTenKeyNumber();
            break;

#ifdef ENABLE_BT
        case E_OSD_BT:
            MApp_ZUI_ACT_AppShowBT();
            break;
#endif

#ifdef ENABLE_KTV
        case E_OSD_KTV:
            MApp_ZUI_ACT_AppShowKTV();
            break;
#endif

#if(ENABLE_PVR ==1)
        case E_OSD_PVR:
            MApp_ZUI_ACT_AppShowPVR();
            break;
        case E_OSD_PVR_BROWSER:
            MApp_ZUI_ACT_AppShowPvrBrowser();
            break;
#endif

#if (ENABLE_GAME)
        case E_OSD_GAME_BROWSER:
            {
                extern void MApp_ZUI_ACT_AppShowGameBrowser(void);
                //printf("startup game browser\n");
                MApp_ZUI_ACT_AppShowGameBrowser();
            }
            break;
#endif

#if DVB_C_ENABLE
        case E_OSD_CADTV_MANUAL_TUNING:
            MApp_ZUI_ACT_AppShowCadtvManualTuning();
            break;
#endif

        case E_OSD_EFFECT_SETTING:
            MApp_ZUI_ACT_AppShowEffectSetting();
            break;


        default:
            ZUI_DBG_FAIL(printf("[ZUI]GBLSHOW\n"));
            ABORT();
    }

    if (u8PrevGopID != OSD_GOP_ID)
        MApi_GOP_GWIN_SwitchGOP(u8PrevGopID);

#if ENABLE_6M30_OSD_PROTECT
    MDrv_Ursa_OsdWinHandler(_eActiveOSD, TRUE);
#endif

    return TRUE; //handled
}

///////////////////////////////////////////////////////////////////////////////
///  global  MApp_ZUI_ACT_TerminateOSD
///  terminate current OSD page. default procedure
///    NOTE: DO NOT MODIFY THIS FUNCTION UNLESS YOU WANT TO ADD NEW OSD PAGE HANDLER!
///
///  @return no return value
///
///  @author MStarSemi @date 2007/1/25
///////////////////////////////////////////////////////////////////////////////
void MApp_ZUI_ACT_TerminateOSD(void)
{
    ZUI_MSG(printf("[]terminate\n"));
    //2008-01-31: if (_eZUIState == E_ZUI_STATE_TERMINATE)
    {
        //NOTE: if an new OSD page added, please add here!
        switch(_eActiveOSD)
        {
            case E_OSD_MAIN_MENU:
                MApp_ZUI_ACT_TerminateMainMenu();
                break;

            case E_OSD_CHANNEL_INFO:
                MApp_ZUI_ACT_TerminateChannelInfo();
                break;
#if ENABLE_DTV
            case E_OSD_DTV_MANUAL_TUNING:
                MApp_ZUI_ACT_TerminateDtvManualTuning();
                break;
#endif
            case E_OSD_ATV_MANUAL_TUNING:
                MApp_ZUI_ACT_TerminateAtvManualTuning();
                break;

            case E_OSD_PROGRAM_EDIT:
                MApp_ZUI_ACT_TerminateProgramEdit();
                break;

            case E_OSD_AUDIO_LANGUAGE:
                MApp_ZUI_ACT_TerminateAudioLanguage();
                break;

            #if ENABLE_SUBTITLE
            case E_OSD_SUBTITLE_LANGUAGE:
                MApp_ZUI_ACT_TerminateSubtitleLanguage();
                break;
            #endif

            case E_OSD_AUTO_TUNING:
                MApp_ZUI_ACT_TerminateAutoTuning();
                break;

            case E_OSD_SCREEN_SAVER:
					// CUS_XM Xue 20120721: modify burnin on show saver icon
#if ENABLE_CUS_BURNING_MODE
		if(stGenSetting.g_FactorySetting.fBuringMode)
		{
			return;
		}

#endif

                MApp_ZUI_ACT_TerminateScreenSaver();
                break;

            case E_OSD_INPUT_SOURCE:
                MApp_ZUI_ACT_TerminateInputSource();
                break;

            case E_OSD_AUDIO_VOLUME:
                MApp_ZUI_ACT_TerminateAudioVolume();
                break;

            #if OBA2
            case E_OSD_UPGRADE:
                MApp_ZUI_ACT_TerminateUpgrade();
                break;
            #endif

            case E_OSD_INSTALL_GUIDE:
                MApp_ZUI_ACT_TerminateInstallGuide();
                break;

            case E_OSD_HOTKEY_OPTION:
                MApp_ZUI_ACT_TerminateHotkeyOption();
                break;
           #if ENABLE_CUS_FACTORY_HOTKEY_MENU
            case E_OSD_FACTORY_HOTKEY_OPTION:
                MApp_ZUI_ACT_TerminateFactoryHotkeyOption();
                break;
           #endif

            case E_OSD_MESSAGE_BOX:
                MApp_ZUI_ACT_TerminateMessageBox();
                break;

            case E_OSD_CHANNEL_LIST:
                MApp_ZUI_ACT_TerminateChannelList();
                break;
#if (ENABLE_OAD)
            case E_OSD_OAD:
                MApp_ZUI_ACT_TerminateOAD();
                break;
#endif

#if (ENABLE_DTV_EPG)
            case E_OSD_EPG:
                MApp_ZUI_ACT_TerminateEpg();
                break;
#endif  //#if (ENABLE_DTV_EPG)
#if (ENABLE_CI)
            case E_OSD_CIMMI:
                MApp_ZUI_ACT_TerminateCIMMI();
                break;
#endif
#if ENABLE_DMP
            case E_OSD_DMP:
                MApp_ZUI_ACT_TerminateDmp();
                break;
#endif

            case E_OSD_FACTORY_MENU:
                MApp_ZUI_ACT_TerminateFactoryMenu();
                break;

            case E_OSD_EXPERT_MENU:
                MApp_ZUI_ACT_TerminateExpertMenu();
                break;

            case E_OSD_TENKEY_NUMBER:
                MApp_ZUI_ACT_TerminateTenKeyNumber();
                break;

#ifdef ENABLE_BT
            case E_OSD_BT:
                MApp_ZUI_ACT_TerminateBT();
                break;
#endif
#ifdef ENABLE_KTV
            case E_OSD_KTV:
                MApp_ZUI_ACT_TerminateKTV();
                break;
#endif
#if ENABLE_PVR
            case E_OSD_PVR:
                MApp_ZUI_ACT_TerminatePVR();
                break;

            case E_OSD_PVR_BROWSER:
                MApp_ZUI_ACT_TerminatePvrBrowser();
                break;
#endif
#if (ENABLE_GAME)
            case E_OSD_GAME_BROWSER:
                break;
#endif

#if DVB_C_ENABLE
            case E_OSD_CADTV_MANUAL_TUNING:
                MApp_ZUI_ACT_TerminateCadtvManualTuning();
                break;
#endif

            case E_OSD_EFFECT_SETTING:
                MApp_ZUI_ACT_TerminateEffectSetting();
                break;


            default:
                ZUI_DBG_FAIL(printf("[ZUI]GBLTERM\n"));
                ABORT();

        }
    }
}

///////////////////////////////////////////////////////////////////////////////
///  global  MApp_ZUI_ACT_ShutdownOSD
///  shutdown and destory current osd page. (this function will change ZUI state)
///    NOTE: DO NOT MODIFY THIS FUNCTION UNLESS YOU WANT TO ADD NEW OSD PAGE HANDLER!
///
///  @return no return value
///
///  @author MStarSemi @date 2007/1/25
///////////////////////////////////////////////////////////////////////////////
void MApp_ZUI_ACT_ShutdownOSD(void)
{
    //2007/12/26: consider gop switching
    U8 u8PrevGopID = MApi_GOP_GWIN_GetCurrentGOP();

    ZUI_MSG(printf("[]shutdown [now=%u,%u]\n", (U8)_eActiveOSD, (U8)_eZUIState));

    if (_eZUIState == E_ZUI_STATE_UNKNOW)
        return;
    if (_eZUIState == E_ZUI_STATE_STANDBY )
        return;

    #if ( ENABLE_DVB_TAIWAN_APP || ENABLE_SBTVD_BRAZIL_APP || (TV_SYSTEM == TV_NTSC) )
         if(MApp_ZUI_GetActiveOSD() == E_OSD_TENKEY_NUMBER)
              msAPI_ATV_SetDirectTuneFlag(FALSE);
    #endif

    if (u8PrevGopID != OSD_GOP_ID)
        MApi_GOP_GWIN_SwitchGOP(OSD_GOP_ID);

    _MApp_ZUI_ACT_AppClose();
    MApp_ZUI_ACT_TerminateOSD();

    MApp_ZUI_API_TerminateGDI(); //shutdown right now! destroy gwin and goto standby state!

    #if DTV_HD_USE_FBL
    if(_eActiveOSD==E_OSD_MAIN_MENU && _eZUIState==E_ZUI_STATE_TERMINATE)
    {
        //enable de-blocking when exit Main Menu
        //for single MIU + FBL only
        if( IsDTVInUse() && MApi_XC_IsCurrentFrameBufferLessMode() )
        {
            MApi_VDEC_DisableDeblocking(FALSE); //means enable deblocking, so that VDEC would work as usual
            //printf("\n enable de-blocking \n");
        }
    }
    #endif

#if ENABLE_6M30_OSD_PROTECT
    MDrv_Ursa_OsdWinHandler(_eActiveOSD, FALSE);
#endif

    MApp_ZUI_API_EmptyMessageQueue(); //clear message queue, before leave
    _eZUIState = E_ZUI_STATE_STANDBY;
    _eActiveOSD = E_OSD_EMPTY;

    if (u8PrevGopID != OSD_GOP_ID)
        MApi_GOP_GWIN_SwitchGOP(u8PrevGopID);

}

///////////////////////////////////////////////////////////////////////////////
///  global  MApp_ZUI_ACT_HandleGlobalKey
///  key preprocess handler for each osd page. (will be called before all winproc)
///    NOTE: DO NOT MODIFY THIS FUNCTION UNLESS YOU WANT TO ADD NEW OSD PAGE HANDLER!
///
///  @param [in]       key VIRTUAL_KEY_CODE      key code
///
///  @return BOOLEAN true for handled (don't dispatch continully)
///
///  @author MStarSemi @date 2007/1/25
///////////////////////////////////////////////////////////////////////////////
BOOLEAN MApp_ZUI_ACT_HandleGlobalKey(VIRTUAL_KEY_CODE key)
{
    //note: this function will be called in running state

    //NOTE: if an new OSD page added, please add here!
    switch(_eActiveOSD)
    {
        case E_OSD_MAIN_MENU:
            return MApp_ZUI_ACT_HandleMainPageKey(key);

        case E_OSD_CHANNEL_INFO:
            return MApp_ZUI_ACT_HandleChannelInfoKey(key);
#if ENABLE_DTV
        case E_OSD_DTV_MANUAL_TUNING:
            return MApp_ZUI_ACT_HandleDtvManualTuningKey(key);
#endif
        case E_OSD_ATV_MANUAL_TUNING:
            return MApp_ZUI_ACT_HandleAtvManualTuningKey(key);

        case E_OSD_PROGRAM_EDIT:
            return MApp_ZUI_ACT_HandleProgramEditKey(key);

        case E_OSD_AUDIO_LANGUAGE:
            return MApp_ZUI_ACT_HandleAudioLanguageKey(key);

        #if ENABLE_SUBTITLE
        case E_OSD_SUBTITLE_LANGUAGE:
            return MApp_ZUI_ACT_HandleSubtitleLanguageKey(key);
        #endif

        case E_OSD_AUTO_TUNING:
            return MApp_ZUI_ACT_HandleAutoTuningKey(key);

        case E_OSD_SCREEN_SAVER:
            return MApp_ZUI_ACT_HandleScreenSaverKey(key);

        case E_OSD_INPUT_SOURCE:
            return MApp_ZUI_ACT_HandleInputSourceKey(key);

        case E_OSD_AUDIO_VOLUME:
            return MApp_ZUI_ACT_HandleAudioVolumeKey(key);

        #if OBA2
        case E_OSD_UPGRADE:
            return MApp_ZUI_ACT_HandleUpgradeKey(key);
        #endif

        case E_OSD_INSTALL_GUIDE:
            return MApp_ZUI_ACT_HandleInstallGuideKey(key);

        case E_OSD_HOTKEY_OPTION:
            return MApp_ZUI_ACT_HandleHotkeyOptionKey(key);

       #if ENABLE_CUS_FACTORY_HOTKEY_MENU
        case E_OSD_FACTORY_HOTKEY_OPTION:
            return MApp_ZUI_ACT_HandleFactoryHotkeyOptionKey(key);
       #endif

        case E_OSD_MESSAGE_BOX:
            return MApp_ZUI_ACT_HandleMessageBoxKey(key);

        case E_OSD_CHANNEL_LIST:
            return MApp_ZUI_ACT_HandleChannelListKey(key);

#if (ENABLE_OAD)
        case E_OSD_OAD:
            return MApp_ZUI_ACT_HandleOADKey(key);
#endif

#if (ENABLE_DTV_EPG)
        case E_OSD_EPG:
            return MApp_ZUI_ACT_HandleEpgKey(key);
#endif  //#if (ENABLE_DTV_EPG)
#if (ENABLE_CI)
        case E_OSD_CIMMI:
            return MApp_ZUI_ACT_HandleCIMMIKey(key);
#endif
#if ENABLE_DMP
        case E_OSD_DMP:
            return MApp_ZUI_ACT_HandleDmpKey(key);
#endif

        case E_OSD_FACTORY_MENU:
            return MApp_ZUI_ACT_HandleFactoryMenuKey(key);

        case E_OSD_EXPERT_MENU:
            return MApp_ZUI_ACT_HandleExpertMenuKey(key);

        case E_OSD_TENKEY_NUMBER:
            return MApp_ZUI_ACT_HandleTenKeyNumberKey(key);

#ifdef ENABLE_BT
        case E_OSD_BT:
            return MApp_ZUI_ACT_HandleBTKey(key);
#endif
#ifdef ENABLE_KTV
        case E_OSD_KTV:
            return MApp_ZUI_ACT_HandleKTVKey(key);
#endif
#if ENABLE_PVR
        case E_OSD_PVR:
            return MApp_ZUI_ACT_HandlePvrKey(key);
        case E_OSD_PVR_BROWSER:
            return MApp_ZUI_ACT_HandlePvrBrowserKey(key);
#endif
#if DVB_C_ENABLE
        case E_OSD_CADTV_MANUAL_TUNING:
            return MApp_ZUI_ACT_HandleCadtvManualTuningKey(key);
#endif
#if (ENABLE_GAME)
        case E_OSD_GAME_BROWSER:
        {
            extern BOOLEAN MApp_ZUI_ACT_HandleGameBrowseKey(VIRTUAL_KEY_CODE key);
            return MApp_ZUI_ACT_HandleGameBrowseKey(key);
        }
#endif

        case E_OSD_EFFECT_SETTING:
            return MApp_ZUI_ACT_HandleEffectSettingKey(key);

        default:
            ZUI_DBG_FAIL(printf("[ZUI]GBLKEY\n"));
            ABORT();
    }
    return FALSE;
}

///////////////////////////////////////////////////////////////////////////////
///  global  MApp_ZUI_ACT_PostMessageFilter
///  message filter for each window proc type. (used for reduce number of message in queue)
///    NOTE: DO NOT MODIFY THIS FUNCTION UNLESS YOU WANT TO ADD NEW WINDOW PROC!
///
///  @param [in]       u8WinProcID U8     window proc ID
///  @param [in]       msg MESSAGE_ENUM    message type
///
///  @return BOOLEAN    true for accept, false for ignore
///
///  @author MStarSemi @date 2007/1/25
///////////////////////////////////////////////////////////////////////////////
BOOLEAN MApp_ZUI_ACT_PostMessageFilter(U8 u8WinProcID, MESSAGE_ENUM msg)
{
    //note: to reduce the usage of message queue, we provide a filter for each type of window proc
    //note: you MUST add a switch case if you added a new window proc

    switch (u8WinProcID)
    {
        case EN_ZUI_DEFAULTWINPROC:
            return FALSE; //ignore all notify

        case EN_ZUI_MAINFRAMEWINPROC:
            //NOTE: main frame MUST accept key down message!
            //      otherwise, all key message will lost!
            return (msg == MSG_KEYDOWN);

        //case EN_ZUI_TOPICON_WINPROC:
            //return (msg == MSG_NOTIFY_SETFOCUS||
                //msg == MSG_EFFECT_POPUP||
                //msg == MSG_EFFECT_SLIDEITEM);

        case EN_ZUI_INPUT_SOURCE_WINPROC:
    #if ENABLE_CUS_USB_OSD
        case EN_ZUI_DMP_SOURCE_WINPROC:
    #endif
            return (msg == MSG_NOTIFY_SETFOCUS ||
                msg == MSG_EFFECT_POPUP||
                msg == MSG_EFFECT_SLIDEITEM);

        case EN_ZUI_CHANNELINFOROOT_WINPROC:
            return (msg == MSG_NOTIFY_SHOW);

        //case EN_ZUI_ACT_MAINPAGE_DYNAMICLIST_WINPROC: /*Creass.liu at 2012-06-02*/
        case EN_ZUI_DYNAMICLIST_WINPROC:
            return (msg == MSG_NOTIFY_SHOW ||
                msg == MSG_NOTIFY_HIDE ||
                msg == MSG_NOTIFY_KEYDOWN ||
                msg == MSG_NOTIFY_CONTENT_CHANGED ||
                msg == MSG_USER||
                msg == (MSG_USER1/*MSG_USER+1*/));

        case EN_ZUI_CIMMIMSGBOX_WINPROC:
        case EN_ZUI_MENUCOMMONDLGROOT_WINPROC:
            return (msg == MSG_NOTIFY_SHOW ||
                msg == MSG_NOTIFY_HIDE);
#if(ENABLE_CUS_UI_SPEC == FALSE)
        case EN_ZUI_PREDITRENAMEINPUT_WINPROC:
#endif
        case EN_ZUI_MENUPWDINPUT_WINPROC:
        case EN_ZUI_MSGBOX_PWDINPUT_WINPROC:
        case EN_ZUI_CIMMIPWDINPUT_WINPROC:
            return (
                msg == MSG_NOTIFY_HIDE ||
                msg == MSG_NOTIFY_SETFOCUS ||
                msg == MSG_NOTIFY_KILLFOCUS);
#if (ENABLE_DTV_EPG)
        case EN_ZUI_EPG_TIMER_LIST_ITEM_WINPROC:
            return (
                msg == MSG_NOTIFY_SETFOCUS);

        case EN_ZUI_EPG_TIMER_SAVE_DLG_WINPROC:
            return (
                msg==MSG_NOTIFY_SHOW );
#endif  //#if (ENABLE_DTV_EPG)

#if ENABLE_PVR
        case EN_ZUI_PVR_WINPROC:
            return (msg == MSG_NOTIFY_SETFOCUS);

        case EN_ZUI_PVR_BROWSER_WINPROC:
            return (msg == MSG_NOTIFY_SETFOCUS);
#endif

        case EN_ZUI_EFFECT_WINPROC:
        #if (ENABLE_UI_3D_PROCESS)
            if(MApp_ZUI_API_Is_UI_3D_Mode_ON())
            {
                return FALSE; //ignore all notify
            }
            else
        #endif
            {
            return (msg == MSG_EFFECT_POPUP ||
                        msg == MSG_EFFECT_SLIDEITEM ||
                        msg == MSG_EFFECT_ZOOMIN ||
                        msg == MSG_EFFECT_ZOOMOUT ||
                        msg == MSG_EFFECT_SPREADOUT ||
                        msg == MSG_EFFECT_ROLLUP);
            }

#if 0
        case EN_ZUI_EFFECT_POPUP_WINPROC:
            return (msg == MSG_EFFECT_POPUP);

        case EN_ZUI_EFFECT_SLIDEITEM_WINPROC:
            return (msg == MSG_EFFECT_SLIDEITEM);

        case EN_ZUI_EFFECT_ZOOM_WINPROC:
            return (msg == MSG_EFFECT_ZOOMIN ||
                msg == MSG_EFFECT_ZOOMOUT);

        case EN_ZUI_EFFECT_ROLL_WINPROC:
            return (msg == MSG_EFFECT_SPREADOUT ||
                msg == MSG_EFFECT_ROLLUP);

#endif



#if 0
        case EN_ZUI_DYNAMICTEXTEFFECT_WINPROC:
            return (msg == MSG_NOTIFY_SHOW ||
                    msg == MSG_EFFECT_DYNATEXT_LEFT ||
                    msg == MSG_EFFECT_DYNATEXT_RIGHT ||
                    msg == MSG_NOTIFY_KEYDOWN);
#endif

        case EN_ZUI_FLIPPAGE_WINPROC:
            return (msg == MSG_EFFECT);

        case EN_ZUI_GRID_WINPROC:
            return (msg == MSG_NOTIFY_SETFOCUS ||
                msg == MSG_NOTIFY_KEYDOWN);

        case EN_ZUI_ANIMATION_WINPROC:
            return (msg == MSG_CREATE ||
                msg == MSG_NOTIFY_HIDE||
                msg == MSG_TIMER||
                msg == MSG_PAINT);

        case EN_ZUI_KEYBOARDINPUT_WINPROC:
            return (msg == MSG_CREATE ||
                msg == MSG_NOTIFY_SETFOCUS ||
                msg == MSG_NOTIFY_SHOW ||
                msg == MSG_NOTIFY_HIDE ||
                msg == MSG_NOTIFY_KEYDOWN);
        default:
            return FALSE; //ignore all notify
    }

}

//note: avoid painting loop waste too much time
//please be attention here, if you want input some special function
#if ZUI_EXCEPTION_MULTITASK
void MApp_ZUI_ACT_Exception_MultiTask(void)
{

}
#endif

///////////////////////////////////////////////////////////////////////////////
///  global  MApp_ZUI_ACT_ExecuteWndProc
///  dispatch a window message, depent on window proc ID
///    NOTE: DO NOT MODIFY THIS FUNCTION UNLESS YOU WANT TO ADD NEW WINDOW PROC!
///
///  @param [in]       u8WinProcID U8   window proc ID
///  @param [in]       msg PMSG     message type
///
///  @return S32 message execute result
///
///  @author MStarSemi @date 2007/1/25
///////////////////////////////////////////////////////////////////////////////
S32 MApp_ZUI_ACT_ExecuteWndProc(U8 u8WinProcID, PMSG msg)
{
    //note: don't use function pointer,
    //      so we use a enumeration for all listed controls (included user overrided window proc)

    //note: you MUST add a switch case if you added a new window proc

    /*/WndProc = g_GUI_WindowList[focus].WindowProc;
    if (GETWNDPROC(focus))
    {
        printf("[dispmsg3]focus=%bu,msg=%bu\n", (U8)focus, pMsg->message);
        iRet = GETWNDPROC(focus)(focus, pMsg);

    }*/
    switch (u8WinProcID)
    {
        case EN_ZUI_DEFAULTWINPROC:
            return DEFAULTWINPROC(msg->hwnd, msg);

        case EN_ZUI_MAINFRAMEWINPROC:
            return MAINFRAMEWINPROC(msg->hwnd, msg);

        //case EN_ZUI_TOPICON_WINPROC:
            //return TOPICON_WINPROC(msg->hwnd, msg);

        case EN_ZUI_INPUT_SOURCE_WINPROC:
            return INPUT_SOURCE_WINPROC(msg->hwnd, msg);

        //case EN_ZUI_MAIN_PAGE_DIRECTION_ICON_WINPROC:
            //eturn MAINMENU_TRIICON_WINPROC(msg->hwnd, msg);

        case EN_ZUI_BGTANSPARENT_WINPROC:
            return BGTRANSPARENT_WINPROC(msg->hwnd, msg);

        //case EN_ZUI_MENUITEMBAR_WINPROC:
        //    return MENUITEMBAR_WINPROC(msg->hwnd, msg);

        case EN_ZUI_BUTTONANICLICK_WINPROC:
            return BUTTONANICLICK_WINPROC(msg->hwnd, msg);

        case EN_ZUI_BUTTONANICLICKCHILD_WINPROC:
            return BUTTONANICLICKCHILD_WINPROC(msg->hwnd, msg);

        case EN_ZUI_DYNAMICTEXT_WINPROC:
            return DYNAMICTEXT_WINPROC(msg->hwnd, msg);

        case EN_ZUI_ANIMATION_WINPROC:
            return ANIMATION_WINPROC(msg->hwnd, msg);

        //case EN_ZUI_DYNAMICTEXTEFFECT_WINPROC:
        //    return DYNAMICTEXTEFFECT_WINPROC(msg->hwnd, msg);

        case EN_ZUI_DYNAMICCOLORTEXT_WINPROC:
            return DYNAMICCOLORTEXT_WINPROC(msg->hwnd, msg);

        //case EN_ZUI_MENUROOT_WINPROC:
        //    return MENUROOT_WINPROC(msg->hwnd, msg);

#ifdef EN_ZUI_BALLPROGRESSBAR_WINPROC
        case EN_ZUI_BALLPROGRESSBAR_WINPROC:
            return BALLPROGRESSBAR_WINPROC(msg->hwnd, msg);
#endif

        case EN_ZUI_SLIDERPROGRESSBAR_WINPROC:
            return SLIDERPROGRESSBAR_WINPROC(msg->hwnd, msg);
        #if(UI_SKIN_SEL==UI_SKIN_1366X768X565_HAIER_CN)  // CUS_xm zHIHE 20120823 modify
        #else
        case EN_ZUI_SLIDERPROGRESSBAR_1_WINPROC:  //minglin1231
            return SLIDERPROGRESSBAR_1_WINPROC(msg->hwnd, msg);
        #endif
        //case EN_ZUI_BALLPROGRESSBAR_FOCUSSTYLE_WINPROC:
            //return BALLPROGRESSBAR_FOCUSSTYLE_WINPROC(msg->hwnd, msg);

        case EN_ZUI_RECTPROGRESSBAR_2_WINPROC:
            return RECTPROGRESSBAR_2_WINPROC(msg->hwnd, msg);

        case EN_ZUI_RECTPROGRESSBAR_3_WINPROC:
            return RECTPROGRESSBAR_3_WINPROC(msg->hwnd, msg);
/*
#if(UI_SKIN_SEL==UI_SKIN_1366X768X565_SMC_India) // cus_xm helen add 20120814
        case EN_ZUI_RECTPROGRESSBAR_4_WINPROC:
            return RECTPROGRESSBAR_4_WINPROC(msg->hwnd, msg);
#endif
*/
#if ENABLE_DMP
        case EN_ZUI_BUTTONCLICK_WINPROC:
            return BUTTONCLICK_WINPROC(msg->hwnd, msg);
        case EN_ZUI_DMP_FILE_SELECT_THUMBNAIL_WINPROC:
            return DMP_FILE_SELECT_THUMBNAIL_WINPROC(msg->hwnd, msg);
        case EN_ZUI_DMP_PROGRESS_WINPROC:
            return DMP_PROGRESS_WINPROC(msg->hwnd, msg);
        case EN_ZUI_PERCENTPROGRESSBAR_WINPROC:
            return PERCENTPROGRESSBAR_WINPROC(msg->hwnd, msg);
    #if ENABLE_CUS_USB_OSD
        case EN_ZUI_PERCENTPROGRESSBARMANUAL_WINPROC:
            return PERCENTPROGRESSBARMANUAL_WINPROC(msg->hwnd, msg);
    #endif
        case EN_ZUI_DMP_PLAY_STATUS_WINPROC:
            return DMP_PLAY_STATUS_WINPROC(msg->hwnd, msg);
        case EN_ZUI_DMP_ALERT_WINPROC:
            return DMP_ALERT_WINPROC(msg->hwnd, msg);
        case EN_ZUI_TEXTVIEWER_WINPROC:
            // TODO: fix me, need MApp_Text_CurPageReload?
            MApp_Text_CurPageReload();
            return TEXTVIEWER_WINPROC(msg->hwnd, msg);
        case EN_ZUI_PREVIEW_WINPROC:
            return DMP_PREVIEW_WINPROC(msg->hwnd, msg);
        case EN_ZUI_DMP_VOLUME_WINPROC:
            return DMP_VOLUME_WINPROC(msg->hwnd, msg);
        case EN_ZUI_DMP_EQ_PLAY_WINPROC:
            return DMP_EQ_PLAY_WINPROC(msg->hwnd, msg);
        case EN_ZUI_DMP_MARQUEE_WINPROC:
            return DMP_MARQUEE_WINPROC(msg->hwnd,msg);
        case EN_ZUI_DMP_MOVIERESUME_WINPROC:
            return DMP_MOVIERESUME_WINPROC(msg->hwnd, msg);

    #if ENABLE_CUS_USB_OSD
        case EN_ZUI_DMP_WINCLOSE:
            return DMP_WINCLOSE_WINPROC(msg->hwnd, msg);
        case EN_ZUI_DMP_SOURCE_WINPROC:
            return DMP_SOURCE_WINPROC(msg->hwnd, msg);
    #endif
#endif
#if TXTFONT_ZOOM2X
        case EN_ZUI_DYNAMICZOOM2X_WINPROC:
            return DYNAMICZOOM2XPUNCTEXT_WINPROC(msg->hwnd,msg);
#else
        case EN_ZUI_DYNAMICZOOM2X_WINPROC:
            return DYNAMICEPGPUNCTEXT_WINPROC(msg->hwnd,msg);
#endif

        //case EN_ZUI_MENUPICTUREPAGE1_WINPROC:
            //return MENUPICTUREPAGE1_WINPROC(msg->hwnd, msg);

        case EN_ZUI_CHANNELINFOROOT_WINPROC:
            return CHANNELINFOROOT_WINPROC(msg->hwnd, msg);

        //case EN_ZUI_INPUTSOURCELIST_WINPROC:
        //    return INPUTSOURCELIST_WINPROC(msg->hwnd, msg);
#if ENABLE_DTV
        case EN_ZUI_DTVMANUALTUNING_WINPROC:
            return DTVMANUALTUNING_WINPROC(msg->hwnd, msg);
#endif

#if DVB_C_ENABLE
        case EN_ZUI_CADTVMANUALTUNING_WINPROC:
            return CADTVMANUALTUNING_WINPROC(msg->hwnd, msg);
#endif
        case EN_ZUI_ATVMANUALTUNING_WINPROC:
            return ATVMANUALTUNING_WINPROC(msg->hwnd, msg);

        case EN_ZUI_SCREENSAVER_WINPROC:
            return SCREENSAVER_WINPROC(msg->hwnd, msg);

        //case EN_ZUI_AUDIOVOLUME_WINPROC:
        //    return AUDIOVOLUME_WINPROC(msg->hwnd, msg);

        //case EN_ZUI_PROGRAMEDITROOT_WINPROC:
        //    return PROGRAMEDITROOT_WINPROC(msg->hwnd, msg);

        //case EN_ZUI_AUDIOLANGUAGELIST_WINPROC:
        //    return AUDIOLANGUAGELIST_WINPROC(msg->hwnd, msg);

        //case EN_ZUI_SUBTITLELANGUAGELIST_WINPROC:
        //    return SUBTITLELANGUAGELIST_WINPROC(msg->hwnd, msg);

        //case EN_ZUI_HOTKEYOPTION_WINPROC:
        //    return HOTKEYOPTION_WINPROC(msg->hwnd, msg);

        //case EN_ZUI_MESSAGEBOX_WINPROC:
        //    return MESSAGEBOX_WINPROC(msg->hwnd, msg);

        case EN_ZUI_DYNAMICLIST_WINPROC:
            return DYNAMICLIST_WINPROC(msg->hwnd, msg);

        //case EN_ZUI_ACT_MAINPAGE_DYNAMICLIST_WINPROC: /*Creass.liu at 2012-06-02*/
            //return MApp_ZUI_ACT_Mainpage_DynamicListWinProc(msg->hwnd, msg);

        //case EN_ZUI_INSTALLGUIDEROOT_WINPROC:
        //    return INSTALLGUIDEROOT_WINPROC(msg->hwnd, msg);

        case EN_ZUI_MENUCOMMONDLGROOT_WINPROC:
            return MENUCOMMONDLGROOT_WINPROC(msg->hwnd, msg);

        case EN_ZUI_MENUPWDINPUT_WINPROC:
            return MENUPWDINPUT_WINPROC(msg->hwnd, msg);

        case EN_ZUI_MSGBOX_PWDINPUT_WINPROC:
            return MSGBOXPWDINPUT_WINPROC(msg->hwnd, msg);
#if (ENABLE_CI)
        case EN_ZUI_CIMMIPWDINPUT_WINPROC:
            return CIMMIPWDINPUT_WINPROC(msg->hwnd, msg);
#endif
        //case EN_ZUI_CHANNELLISTROOT_WINPROC:
        //    return CHANNELLISTROOT_WINPROC(msg->hwnd, msg);

        case EN_ZUI_DYNAMICBITMAP_WINPROC:
            return DYNAMICBITMAP_WINPROC(msg->hwnd, msg);

#if(ENABLE_CUS_UI_SPEC == FALSE)
        case EN_ZUI_PREDITRENAMEINPUT_WINPROC:
            return PREDITRENAMEINPUT_WINPROC(msg->hwnd, msg);
#endif

        case EN_ZUI_KEYBOARDINPUT_WINPROC:
            return KEYBOARDINPUT_WINPROC(msg->hwnd, msg);

        //case EN_ZUI_EPGROOT_WINPROC:
        //    return EPGROOT_WINPROC(msg->hwnd, msg);
#if (ENABLE_DTV_EPG)
  //      case EN_ZUI_EPGSERVICEBAR_WINPROC:
  //          return EPGSERVICEBAR_WINPROC(msg->hwnd, msg);
        case EN_ZUI_EPGPROGRAMMEGUIDE_TITLE_WINPROC:
            return EPGPROGRAMMEGUIDE_TITLE_WINPROC(msg->hwnd, msg);
        case EN_ZUI_EPGPROGRAMMEGUIDE_TIMEITEM_WINPROC:
            return EPGPROGRAMMEGUIDE_TIMEITEM_WINPROC(msg->hwnd, msg);
        case EN_ZUI_EPGTIMEITEMEVENT_WINPROC:
            return EPGTIMEITEMEVENT_WINPROC(msg->hwnd, msg);
        case EN_ZUI_EPGPROGRAMMEGUIDE_CHANNELITEM_WINPROC:
            return EPGPROGRAMMEGUIDE_CHANNELITEM_WINPROC(msg->hwnd, msg);
        case EN_ZUI_EPGCHANNELITEMEVENT_WINPROC:
            return EPGCHANNELITEMEVENT_WINPROC(msg->hwnd, msg);
//        case EN_ZUI_EPGTIMEPANE_WINPROC:
 //           return EPGTIMEPANE_WINPROC(msg->hwnd, msg);

        case EN_ZUI_EPGUPDATEALLTIMEITEM_WINPROC:
            return EPG_UPDATEALLTIMEITEM_WINPROC(msg->hwnd, msg);
#endif  //#if (ENABLE_DTV_EPG)
        //case EN_ZUI_DYNAMICPUNCTEXT_WINPROC:
        //    return DYNAMICPUNCTEXT_WINPROC(msg->hwnd, msg);

        case EN_ZUI_DYNAMICEPGPUNCTEXT_WINPROC:
            return DYNAMICEPGPUNCTEXT_WINPROC(msg->hwnd, msg);

        case EN_ZUI_AUTOCLOSE_WINPROC:
            return AUTOCLOSE_WINPROC(msg->hwnd, msg);
#if (ENABLE_CI)
        case EN_ZUI_CIMMIMSGBOX_WINPROC:
            return CIMMIMSGBOX_WINPROC(msg->hwnd, msg);

        case EN_ZUI_CIMMI_WINPROC:
            return CIMMI_WINPROC(msg->hwnd, msg);
#endif
        case EN_ZUI_MSGBOXTEXTPANE_WINPROC:
            return MSGBOXTEXTPANE_WINPROC(msg->hwnd, msg);

        case EN_ZUI_AUTOTUNINGSKIPATV_WINPROC:
            return AUTOTUNINGSKIPATV_WINPROC(msg->hwnd, msg);
        case EN_ZUI_AUTOTUNINGSKIPDTV_WINPROC:
            return AUTOTUNINGSKIPDTV_WINPROC(msg->hwnd, msg);
#if (ENABLE_DTV_EPG)
        case EN_ZUI_EPG_TIMER_LIST_ITEM_WINPROC:
            return EPG_TIMER_LIST_ITEM_WINPROC(msg->hwnd, msg);

        case EN_ZUI_EPG_TIMER_SAVE_DLG_WINPROC:
            return EPG_TIMER_SAVE_DLG_WINPROC(msg->hwnd, msg);
#endif  //#if (ENABLE_DTV_EPG)
#ifdef ENABLE_BT
        case EN_ZUI_BTTOP_WINPROC:
            return MApp_ZUI_ACT_BTTopWinProc(msg->hwnd, msg);
        case EN_ZUI_BTLINKPHOTO_WINPROC:
            return MApp_ZUI_ACT_BTLinkPhotoWinProc(msg->hwnd, msg);
        case EN_ZUI_BT_DESCRIPTION_WINPROC:
            return MApp_ZUI_ACT_BTDescriptionWinProc(msg->hwnd, msg);
#endif

//#ifdef ENABLE_KTV
//        case EN_ZUI_KTV_WINPROC:
//            return MApp_ZUI_ACT_KTVWinProc(msg->hwnd, msg);
//#endif

#if ENABLE_PVR
        case EN_ZUI_PVR_WINPROC:
            return MApp_ZUI_ACT_PvrWinProc(msg->hwnd, msg);

        case EN_ZUI_PVR_BROWSER_WINPROC:
            return MApp_ZUI_ACT_PvrBrowserWinProc(msg->hwnd, msg);

        case EN_ZUI_PVR_BALLPROGRESSBAR_WINPROC:
#if 0 //fix pvr
            return MApp_ZUI_CTL_PvrBallProgressBarWinProc(msg->hwnd, msg);

        case EN_ZUI_PVR_TWOBALLPROGRESSBAR_WINPROC:
            return MApp_ZUI_CTL_PvrTwoBallProgressBarWinProc(msg->hwnd, msg);
#endif
#endif
#if (ENABLE_GAME)
        case EN_ZUI_GAME_BROWSER_WINPROC:
            {
                extern S32 MApp_ZUI_ACT_GameBrowseWinProc(HWND hwnd, PMSG msg);
                return MApp_ZUI_ACT_GameBrowseWinProc(msg->hwnd, msg);
            }
#endif

        case EN_ZUI_EFFECT_WINPROC:
            return EFFECT_WINPROC(msg->hwnd, msg);

#if 0
        case EN_ZUI_EFFECT_POPUP_WINPROC:
            return EFFECTPOPUP_WINPROC(msg->hwnd, msg);

        case EN_ZUI_EFFECT_SLIDEITEM_WINPROC:
            return EFFECTSLIDEITEM_WINPROC(msg->hwnd, msg);

        case EN_ZUI_EFFECT_ZOOM_WINPROC:
            return EFFECTZOOM_WINPROC(msg->hwnd, msg);

        case EN_ZUI_EFFECT_ROLL_WINPROC:
            return EFFECTROLL_WINPROC(msg->hwnd, msg);
#endif

/*
        case EN_ZUI_MOTIONTRANS_ICON_WINPROC:
            return MApp_ZUI_CTL_MotionTrans_Icon_WinProc(msg->hwnd, msg);

        case EN_ZUI_MOTIONTRANS_WINPROC:
            return MApp_ZUI_CTL_MotionTransWinProc(msg->hwnd, msg);

        case EN_ZUI_FAKE3D_ICON_WINPROC:
            return MApp_ZUI_CTL_Fake3D_Icon_WinProc(msg->hwnd, msg);

        case EN_ZUI_FAKE3D_WINPROC:
            return MApp_ZUI_CTL_Fake3D_WinProc(msg->hwnd, msg);
*/


        case EN_ZUI_BARTIMER_WINPROC:
            return MApp_ZUI_CTL_DMP_BARTIMER_WinProc(msg->hwnd, msg);
		case EN_ZUI_TEXTHIDE_WINPROC:
			return HIDEDYMECTEXT_WINDPROC(msg->hwnd, msg);

        case EN_ZUI_FLIPPAGE_WINPROC:
            return FLIPPAGE_WINPROC(msg->hwnd, msg);

        case EN_ZUI_GRID_WINPROC:
            return MApp_ZUI_CTL_GridWinProc(msg->hwnd, msg);

        case EN_ZUI_INSTALL_GUIDE_WINPROC:
            return INSTALL_GUIDE_WINPROC(msg->hwnd, msg);

#ifdef ENABLE_KTV
        case EN_ZUI_SLIDEBAR_WINPROC:
            return MApp_ZUI_CTL_SlideBarWinProc(msg->hwnd, msg);
#endif

        default:
            ZUI_DBG_FAIL(printf("[ZUI]GBLWPROC\n"));
            ABORT();

    }
}

///////////////////////////////////////////////////////////////////////////////
///  global  MApp_ZUI_ACT_ExecuteWndAction
///  execute a specific action. (this will dispatch by osd page)
///    NOTE: DO NOT MODIFY THIS FUNCTION UNLESS YOU WANT TO ADD NEW OSD PAGE HANDLER!
///
///  @param [in]       act U16       action ID
///
///  @return BOOLEAN    true for accept, false for ignore
///
///  @author MStarSemi @date 2007/1/25
///////////////////////////////////////////////////////////////////////////////
BOOLEAN MApp_ZUI_ACT_ExecuteWndAction(U16 act)
{
    if (_eActiveOSD == E_OSD_EMPTY)
    {
        return FALSE;
    }

    //global action....NOTE: don't write special case here!!
    switch (act)
    {
        case EN_EXE_NAV_KEY_UP:
            MApp_ZUI_API_SetFocusByNav(MApp_ZUI_API_GetFocus(), NAV_UP);
            return TRUE;

        case EN_EXE_NAV_KEY_DOWN:
            MApp_ZUI_API_SetFocusByNav(MApp_ZUI_API_GetFocus(), NAV_DOWN);
            return TRUE;

        case EN_EXE_NAV_KEY_LEFT:
            MApp_ZUI_API_SetFocusByNav(MApp_ZUI_API_GetFocus(), NAV_LEFT);
            return TRUE;

        case EN_EXE_NAV_KEY_RIGHT:
            MApp_ZUI_API_SetFocusByNav(MApp_ZUI_API_GetFocus(), NAV_RIGHT);
            return TRUE;


        case EN_EXE_NOTIFY_PARENT_KEY_SELECT:
            MApp_ZUI_API_PostMessage(
                MApp_ZUI_API_GetParent(MApp_ZUI_API_GetFocus()),
                MSG_NOTIFY_KEYDOWN, VK_SELECT);
            return TRUE;
        case EN_EXE_NOTIFY_PARENT_KEY_UP:
            MApp_ZUI_API_PostMessage(
                MApp_ZUI_API_GetParent(MApp_ZUI_API_GetFocus()),
                MSG_NOTIFY_KEYDOWN, VK_UP);
            return TRUE;

        case EN_EXE_NOTIFY_PARENT_KEY_DOWN:
            MApp_ZUI_API_PostMessage(
                MApp_ZUI_API_GetParent(MApp_ZUI_API_GetFocus()),
                MSG_NOTIFY_KEYDOWN, VK_DOWN);
            return TRUE;

        case EN_EXE_NOTIFY_PARENT_KEY_LEFT:
            MApp_ZUI_API_PostMessage(
                MApp_ZUI_API_GetParent(MApp_ZUI_API_GetFocus()),
                MSG_NOTIFY_KEYDOWN, VK_LEFT);
            return TRUE;

        case EN_EXE_NOTIFY_PARENT_KEY_RIGHT:
            MApp_ZUI_API_PostMessage(
                MApp_ZUI_API_GetParent(MApp_ZUI_API_GetFocus()),
                MSG_NOTIFY_KEYDOWN, VK_RIGHT);
            return TRUE;

        case EN_EXE_REPAINT_ALL:
            MApp_ZUI_API_InvalidateRect(NULL);
            return TRUE;

        default:
            break;

    }

    //NOTE: if an new OSD page added, please add here!
    switch(_eActiveOSD)
    {
        case E_OSD_MAIN_MENU:
            return MApp_ZUI_ACT_ExecuteMainMenuAction(act);

        case E_OSD_AUTO_TUNING:
            return MApp_ZUI_ACT_ExecuteAutoTuningAction(act);

        case E_OSD_CHANNEL_INFO:
            return MApp_ZUI_ACT_ExecuteChannelInfoAction(act);

        case E_OSD_INPUT_SOURCE:
            return MApp_ZUI_ACT_ExecuteInputSourceAction(act);

        case E_OSD_AUDIO_VOLUME:
            return MApp_ZUI_ACT_ExecuteAudioVolumeAction(act);

        #if OBA2
        case E_OSD_UPGRADE:
            return MApp_ZUI_ACT_ExecuteUpgradeAction(act);
        #endif

        case E_OSD_SCREEN_SAVER:
            return MApp_ZUI_ACT_ExecuteScreenSaverAction(act);

        case E_OSD_AUDIO_LANGUAGE:
            return MApp_ZUI_ACT_ExecuteAudioLanguageAction(act);

        #if ENABLE_SUBTITLE
        case E_OSD_SUBTITLE_LANGUAGE:
            return MApp_ZUI_ACT_ExecuteSubtitleLanguageAction(act);
        #endif
#if ENABLE_DTV
        case E_OSD_DTV_MANUAL_TUNING:
            return MApp_ZUI_ACT_ExecuteDtvManualTuningAction(act);
#endif
        case E_OSD_ATV_MANUAL_TUNING:
            return MApp_ZUI_ACT_ExecuteAtvManualTuningAction(act);

        case E_OSD_PROGRAM_EDIT:
            return MApp_ZUI_ACT_ExecuteProgramEditAction(act);

        case E_OSD_HOTKEY_OPTION:
            return MApp_ZUI_ACT_ExecuteHotkeyOptionAction(act);

       #if ENABLE_CUS_FACTORY_HOTKEY_MENU
        case E_OSD_FACTORY_HOTKEY_OPTION:
            return MApp_ZUI_ACT_ExecuteFactoryHotkeyOptionAction(act);
       #endif

        case E_OSD_MESSAGE_BOX:
            return MApp_ZUI_ACT_ExecuteMessageBoxAction(act);

        case E_OSD_INSTALL_GUIDE:
            return MApp_ZUI_ACT_ExecuteInstallGuideAction(act);

        case E_OSD_CHANNEL_LIST:
            return MApp_ZUI_ACT_ExecuteChannelListAction(act);
#if (ENABLE_OAD)
        case E_OSD_OAD:
            return MApp_ZUI_ACT_ExecuteOADAction(act);
#endif
#if (ENABLE_DTV_EPG)
        case E_OSD_EPG:
            return MApp_ZUI_ACT_ExecuteEpgAction(act);
#endif  //#if (ENABLE_DTV_EPG)
#if (ENABLE_CI)
        case E_OSD_CIMMI:
            return MApp_ZUI_ACT_ExecuteCIMMIAction(act);
#endif
#if ENABLE_DMP
        case E_OSD_DMP:
            return MApp_ZUI_ACT_ExecuteDmpAction(act);
#endif

        case E_OSD_FACTORY_MENU:
            return MApp_ZUI_ACT_ExecuteFactoryMenuAction(act);

        case E_OSD_EXPERT_MENU:
            return MApp_ZUI_ACT_ExecuteExpertMenuAction(act);

        case E_OSD_TENKEY_NUMBER:
            return MApp_ZUI_ACT_ExecuteTenKeyNumberAction(act);

#ifdef ENABLE_BT
        case E_OSD_BT:
            return MApp_ZUI_ACT_ExecuteBTAction(act);
#endif

#ifdef ENABLE_KTV
        case E_OSD_KTV:
            return MApp_ZUI_ACT_ExecuteKTVAction(act);
#endif

#if ENABLE_PVR
        case E_OSD_PVR:
            return MApp_ZUI_ACT_ExecutePvrAction(act);
        case E_OSD_PVR_BROWSER:
            return MApp_ZUI_ACT_ExecutePvrBrowserAction(act);
#endif
#if DVB_C_ENABLE
        case E_OSD_CADTV_MANUAL_TUNING:
            return MApp_ZUI_ACT_ExecuteCadtvManualTuningAction(act);
#endif

        case E_OSD_EFFECT_SETTING:
            return MApp_ZUI_ACT_ExecuteEffectSettingAction(act);


        default:
          #if 0
            ZUI_DBG_FAIL(printf("[ZUI]GBLACT=%bu,%bu\n", _eActiveOSD, act));
          #else // Modified by coverity_0450
            ZUI_DBG_FAIL(printf("[ZUI]GBLACT=%d,%d\n", (U8)_eActiveOSD, act));
          #endif
            ABORT();

    }
    return FALSE; //false for continue passing key event....
}

///////////////////////////////////////////////////////////////////////////////
///  global  MApp_ZUI_ACT_GetDynamicText
///  dynamic text content provider for "dynamic text" control
///    NOTE: DO NOT MODIFY THIS FUNCTION UNLESS YOU WANT TO ADD NEW OSD PAGE HANDLER!
///
///  @param [in]       hwnd HWND     window handle we are processing
///
///  @return LPTSTR    string content, return 0 if want to display empty string
///
///  @author MStarSemi @date 2007/1/25
///////////////////////////////////////////////////////////////////////////////
LPTSTR MApp_ZUI_ACT_GetDynamicText(HWND hwnd)
{
    //NOTE: if an new OSD page added, please add here!
    switch(_eActiveOSD)
    {
        case E_OSD_MAIN_MENU:
            return MApp_ZUI_ACT_GetMainMenuDynamicText(hwnd);

        case E_OSD_AUTO_TUNING:
            return MApp_ZUI_ACT_GetAutoTuningDynamicText(hwnd);

        case E_OSD_CHANNEL_INFO:
            return MApp_ZUI_ACT_GetChannelInfoDynamicText(hwnd);

        case E_OSD_INPUT_SOURCE:
            return MApp_ZUI_ACT_GetInputSourceDynamicText(hwnd);

        case E_OSD_SCREEN_SAVER:
            return MApp_ZUI_ACT_GetScreenSaverDynamicText(hwnd);

        case E_OSD_AUDIO_VOLUME:
            return MApp_ZUI_ACT_GetAudioVolumeDynamicText(hwnd);

        #if OBA2
        case E_OSD_UPGRADE:
            return MApp_ZUI_ACT_GetUpgradeDynamicText(hwnd);
        #endif

        case E_OSD_AUDIO_LANGUAGE:
            return MApp_ZUI_ACT_GetAudioLanguageDynamicText(hwnd);

       #if ENABLE_SUBTITLE
        case E_OSD_SUBTITLE_LANGUAGE:
            return MApp_ZUI_ACT_GetSubtitleLanguageDynamicText(hwnd);
       #endif

#if ENABLE_DTV
        case E_OSD_DTV_MANUAL_TUNING:
            return MApp_ZUI_ACT_GetDtvManualTuningDynamicText(hwnd);
#endif

        case E_OSD_ATV_MANUAL_TUNING:
            return MApp_ZUI_ACT_GetAtvManualTuningDynamicText(hwnd);

        case E_OSD_PROGRAM_EDIT:
            return MApp_ZUI_ACT_GetProgramEditDynamicText(hwnd);

        case E_OSD_HOTKEY_OPTION:
            return MApp_ZUI_ACT_GetHotkeyOptionDynamicText(hwnd);

       #if ENABLE_CUS_FACTORY_HOTKEY_MENU
        case E_OSD_FACTORY_HOTKEY_OPTION:
            return MApp_ZUI_ACT_GetFactoryHotkeyOptionDynamicText(hwnd);
       #endif

        case E_OSD_MESSAGE_BOX:
            return MApp_ZUI_ACT_GetMessageBoxDynamicText(hwnd);

        case E_OSD_INSTALL_GUIDE:
            return MApp_ZUI_ACT_GetInstallGuideDynamicText(hwnd);

        case E_OSD_CHANNEL_LIST:
            return MApp_ZUI_ACT_GetChannelListDynamicText(hwnd);
#if (ENABLE_OAD)
        case E_OSD_OAD:
            return MApp_ZUI_ACT_GetOADDynamicText(hwnd);
#endif
#if (ENABLE_DTV_EPG)
        case E_OSD_EPG:
            return MApp_ZUI_ACT_GetEpgDynamicText(hwnd);
#endif  //#if (ENABLE_DTV_EPG)
#if (ENABLE_CI)
        case E_OSD_CIMMI:
            return MApp_ZUI_ACT_GetCIMMIDynamicText(hwnd);
#endif
#if ENABLE_DMP
        case E_OSD_DMP:
            return MApp_ZUI_ACT_GetDmpDynamicText(hwnd);
#endif

        case E_OSD_FACTORY_MENU:
            return MApp_ZUI_ACT_GetFactoryMenuDynamicText(hwnd);

        case E_OSD_EXPERT_MENU:
            return MApp_ZUI_ACT_GetExpertMenuDynamicText(hwnd);

        case E_OSD_TENKEY_NUMBER:
            return MApp_ZUI_ACT_GetTenKeyNumberDynamicText(hwnd);

#ifdef ENABLE_BT
        case E_OSD_BT:
            return MApp_ZUI_ACT_GetBTDynamicText(hwnd);
#endif
#ifdef ENABLE_KTV
        case E_OSD_KTV:
            return MApp_ZUI_ACT_GetKTVDynamicText(hwnd);
#endif
#if ENABLE_PVR
        case E_OSD_PVR:
            return MApp_ZUI_ACT_GetPvrDynamicText(hwnd);
        case E_OSD_PVR_BROWSER:
            return MApp_ZUI_ACT_GetPvrBrowserDynamicText(hwnd);
#endif
#if DVB_C_ENABLE
        case E_OSD_CADTV_MANUAL_TUNING:
            return MApp_ZUI_ACT_GetCadtvManualTuningDynamicText(hwnd);
#endif
#if (ENABLE_GAME)
        case E_OSD_GAME_BROWSER:
        {
            extern LPTSTR MApp_ZUI_ACT_GetGameBrowserDynamicText(HWND hwnd);
            //printf("get game browse dynamic txt\n");
            return MApp_ZUI_ACT_GetGameBrowserDynamicText(hwnd);
        }
#endif

        case E_OSD_EFFECT_SETTING:
            return MApp_ZUI_ACT_GetEffectSettingDynamicText(hwnd);

        default:
            ZUI_DBG_FAIL(printf("[ZUI]GBLDTEXT\n"));
            ABORT();
    }
    return 0; //false for empty string

}


///////////////////////////////////////////////////////////////////////////////
///  global  MApp_ZUI_ACT_GetDynamicBitmap
///  dynamic bitmap content provider for "dynamic bitmap" control
///    NOTE: DO NOT MODIFY THIS FUNCTION UNLESS YOU WANT TO ADD NEW OSD PAGE HANDLER!
///
///  @param [in]       hwnd HWND     window handle we are processing
///  @param [in]       type DRAWSTYLE_TYPE     drawing type (normal/focus/disabled)
///
///  @return U16      bitmap index, return 0xFFFF if want to display empty bitmap
///
///  @author MStarSemi @date 2007/1/25
///////////////////////////////////////////////////////////////////////////////
U16 MApp_ZUI_ACT_GetDynamicBitmap(HWND hwnd, DRAWSTYLE_TYPE type)
{
    //NOTE: if an new OSD page added, please add here!
    switch(_eActiveOSD)
    {
        #if 1//(ENABLE_ATV_VCHIP)
        case E_OSD_MAIN_MENU:
            return MApp_ZUI_ACT_GetMainMenuDynamicBitmap(hwnd, type);
        #endif

        case E_OSD_CHANNEL_LIST:
            return MApp_ZUI_ACT_GetChannelListDynamicBitmap(hwnd, type);

        case E_OSD_PROGRAM_EDIT:
            return MApp_ZUI_ACT_GetProgramEditDynamicBitmap(hwnd, type);

        case E_OSD_AUDIO_LANGUAGE:
            return MApp_ZUI_ACT_GetAudioLanguageDynamicBitmap(hwnd, type);

#if ENABLE_DMP
        case E_OSD_DMP:
            return MApp_ZUI_ACT_GetDmpDynamicBitmap(hwnd, type);
#endif

#ifdef ENABLE_BT
        case E_OSD_BT:
            return MApp_ZUI_ACT_GetBTDynamicBitmap(hwnd, type);
#endif

#ifdef ENABLE_KTV
        case E_OSD_KTV:
            return MApp_ZUI_ACT_GetKTVDynamicBitmap(hwnd, type);
#endif

#if ENABLE_PVR
        case E_OSD_PVR_BROWSER:
            return MApp_ZUI_ACT_GetPvrBrowserDynamicBitmap(hwnd, type);
#endif
        case E_OSD_CHANNEL_INFO:
            return MApp_ZUI_ACT_GetChannelInfoDynamicBitmap(hwnd, type);

#if (ENABLE_DTV_EPG)
        case E_OSD_EPG:
            return MApp_ZUI_ACT_GetEpgDynamicBitmap(hwnd, type);
#endif

        case E_OSD_INPUT_SOURCE:
            return MApp_ZUI_ACT_GetInputSourceDynamicBitmap(hwnd, type);

	//cus_xm:zb add at 2012-7-31
	case E_OSD_SCREEN_SAVER:
		return MApp_ZUI_ACT_GetScreenSaverDynamicBitmap(hwnd, type);

       //cus_xm:zb add at 2012-8-2
	case E_OSD_INSTALL_GUIDE:
		return MApp_ZUI_ACT_GetInstallDynamicBitmap(hwnd, type);

        default:
            ZUI_DBG_FAIL(printf("[ZUI]GBLDBMP\n"));
            ABORT();
    }
    return 0xFFFF; //for empty bitmap

}


///////////////////////////////////////////////////////////////////////////////
///  global  MApp_ZUI_ACT_GetDynamicValue
///  integer number provider for progress bar/checkbox/radio button controls
///    NOTE: DO NOT MODIFY THIS FUNCTION UNLESS YOU WANT TO ADD NEW OSD PAGE HANDLER!
///
///  @param [in]       hwnd HWND     window handle we are processing
///
///  @return S16     integer value
///
///  @author MStarSemi @date 2007/1/25
///////////////////////////////////////////////////////////////////////////////
S16 MApp_ZUI_ACT_GetDynamicValue(HWND hwnd)
{

    //NOTE: if an new OSD page added, please add here!
    switch(_eActiveOSD)
    {
        case E_OSD_MAIN_MENU:
            return MApp_ZUI_ACT_GetMainMenuDynamicValue(hwnd);

        case E_OSD_INSTALL_GUIDE:
            return MApp_ZUI_ACT_GetInstallPageDynamicValue(hwnd);

        case E_OSD_AUTO_TUNING:
            return MApp_ZUI_ACT_GetAutoTuningDynamicValue(hwnd);

        case E_OSD_CHANNEL_INFO:
            return MApp_ZUI_ACT_GetChannelInfoDynamicValue(hwnd);

        case E_OSD_AUDIO_VOLUME:
            return MApp_ZUI_ACT_GetAudioVolumeDynamicValue(hwnd);
#if ENABLE_DTV
        case E_OSD_DTV_MANUAL_TUNING:
            return MApp_ZUI_ACT_GetDtvManualTuningDynamicValue(hwnd);
    #if DVB_C_ENABLE
        case E_OSD_CADTV_MANUAL_TUNING:
            return MApp_ZUI_ACT_GetCADtvManualTuningDynamicValue(hwnd);
    #endif
#endif
#if (ENABLE_DTV_EPG)
        //case E_OSD_EPG:
            //return MApp_ZUI_ACT_GetEpgDynamicValue(hwnd);
#endif  //#if (ENABLE_DTV_EPG)
        //case E_OSD_HOTKEY_OPTION:
            //return MApp_ZUI_ACT_GetHotkeyOptionDynamicValue(hwnd);

#if ENABLE_DMP
        case E_OSD_DMP:
            return MApp_ZUI_ACT_GetDmpDynamicValue(hwnd);
#endif

#ifdef ENABLE_KTV
        case E_OSD_KTV:
            return MApp_ZUI_ACT_GetKTVDynamicValue(hwnd);
#endif

#if ENABLE_PVR
        case E_OSD_PVR:
            return MApp_ZUI_ACT_GetPvrDynamicValue(hwnd);
        case E_OSD_PVR_BROWSER:
            return MApp_ZUI_ACT_GetPvrBrowserDynamicValue(hwnd);
#endif
        case E_OSD_INPUT_SOURCE:
            return MApp_ZUI_ACT_GetInputSourceDynamicValue(hwnd);
     //   case E_OSD_INPUT_SOURCE:
         //    return  MApp_ZUI_ACT_GetMenuDynamicValue(hwnd);

	 	//hotel mode @ chuxu 2012-08-01
#if CUS_SMC_ENABLE_HOTEL_MODE
	 	case E_OSD_FACTORY_MENU:
			//printf("========hotel mode===========\n");
            return MApp_ZUI_ACT_GetHotelMenuVolumeDynamicValue(hwnd);
#endif
        default:
            ZUI_DBG_FAIL(printf("[ZUI]GBLDVALUE\n"));
            ABORT();
    }
    return 0; //false for empty string
}

///////////////////////////////////////////////////////////////////////////////
///  global  MApp_ZUI_ACT_GetDynamicValue_2
///  2nd integer number provider for dual progress bar
///    NOTE: DO NOT MODIFY THIS FUNCTION UNLESS YOU WANT TO ADD NEW OSD PAGE HANDLER!
///
///  @param [in]       hwnd HWND     window handle we are processing
///
///  @return S16     integer value
///
///  @author MStarSemi @date 2007/1/25
///////////////////////////////////////////////////////////////////////////////
S16 MApp_ZUI_ACT_GetDynamicValue_2(HWND hwnd)
{
#if !(ENABLE_PVR)
    UNUSED(hwnd);
#endif

    switch(_eActiveOSD)
    {
    #if ENABLE_PVR
        case E_OSD_PVR:
            return MApp_ZUI_ACT_GetPvrDynamicValue_2(hwnd);
    #endif
        default:
            return 100;  //background rect fill the whole line
    }
}

///////////////////////////////////////////////////////////////////////////////
///  global  MApp_ZUI_ACT_QueryDynamicListItemStatus
///  status provider for dynamic list controls
///    NOTE: DO NOT MODIFY THIS FUNCTION UNLESS YOU WANT TO ADD NEW OSD PAGE HANDLER!
///
///  @param [in]       hwnd HWND     window handle we are processing
///
///  @return GUI_ENUM_DYNAMIC_LIST_STATE     item status
///
///  @author MStarSemi @date 2007/1/25
///////////////////////////////////////////////////////////////////////////////
GUI_ENUM_DYNAMIC_LIST_STATE MApp_ZUI_ACT_QueryDynamicListItemStatus(HWND hwnd)
{
    //NOTE: if an new OSD page added, please add here!
    switch(_eActiveOSD)
    {
        case E_OSD_MAIN_MENU:
            return MApp_ZUI_ACT_QueryMainMenuItemStatus(hwnd);

        case E_OSD_INSTALL_GUIDE:
            return MApp_ZUI_ACT_QueryIstallItemStatus(hwnd);

        case E_OSD_INPUT_SOURCE:
            return MApp_ZUI_ACT_QueryInputSourceItemStatus(hwnd);

    #if ENABLE_PVR
        case E_OSD_PVR:
            return MApp_ZUI_ACT_QueryPvrFileSysStatus(hwnd);
    #endif

    #if DVB_C_ENABLE
        case E_OSD_CADTV_MANUAL_TUNING:
            return MApp_ZUI_ACT_QueryCadtvManualTuningStatus(hwnd);
    #endif

        case E_OSD_ATV_MANUAL_TUNING:
            return MApp_ZUI_ACT_QueryAtvManualTuningStatus(hwnd);

    #ifdef ENABLE_KTV
        case E_OSD_KTV:
            return MApp_ZUI_ACT_QueryKTVItemStatus(hwnd);
    #endif

    #if ENABLE_CUS_USB_OSD
        case E_OSD_DMP:
            return MApp_ZUI_ACT_QueryDMPItemStatus(hwnd);
    #endif

        default:
            ZUI_DBG_FAIL(printf("[ZUI]GBLDLIST\n"));
            ABORT();
    }
    return EN_DL_STATE_NORMAL;
}

///////////////////////////////////////////////////////////////////////////////
///  global  MApp_ZUI_ACT_GetDynamicColor
///  status provider for dynamic color text/marquee
///    NOTE: DO NOT MODIFY THIS FUNCTION UNLESS YOU WANT TO ADD NEW OSD PAGE HANDLER!
///
///  @param [in]       hwnd HWND     window handle we are processing
///  @param [in]       type DRAWSTYLE_TYPE     drawing type (normal/focus/disabled)
///  @param [in]       colorOriginal OSD_COLOR     original color
///
///  @return OSD_COLOR     color
///
///  @author MStarSemi @date 2007/1/25
///////////////////////////////////////////////////////////////////////////////
OSD_COLOR MApp_ZUI_ACT_GetDynamicColor(HWND hwnd, DRAWSTYLE_TYPE type, OSD_COLOR colorOriginal)
{
    //NOTE: if an new OSD page added, please add here!
    //UNUSED(hwnd);
    UNUSED(type);

    switch(_eActiveOSD)
    {
        case E_OSD_MAIN_MENU:
            return MApp_ZUI_ACT_GetMenuMainDynamicColor(hwnd, type, colorOriginal);

        case E_OSD_CHANNEL_LIST:
            return MApp_ZUI_ACT_GetChannelListDynamicColor(hwnd, type, colorOriginal);

        case E_OSD_PROGRAM_EDIT:
            return MApp_ZUI_ACT_GetProgramEditDynamicColor(hwnd, type, colorOriginal);

        case E_OSD_EXPERT_MENU:
            return MApp_ZUI_ACT_GetExpertmenuDynamicColor(hwnd, type, colorOriginal);

        case E_OSD_FACTORY_MENU:
            return MApp_ZUI_ACT_GetFactorymenuDynamicColor(hwnd, type, colorOriginal);

        default:
            break;
    }

    return colorOriginal;
}

///////////////////////////////////////////////////////////////////////////////
///  global  MApp_ZUI_ACT_CheckBypassKey
///  in some OSD we have to set it as priority, and bypass some key to it.
///    NOTE: DO NOT MODIFY THIS FUNCTION UNLESS YOU WANT TO ADD NEW OSD PAGE HANDLER!
///
///  @return EN_KEY  :0xFF means bypass all key
///
///  @author MStarSemi @date 2009/1/25
///////////////////////////////////////////////////////////////////////////////
BOOLEAN MApp_ZUI_ACT_CheckBypassKey(U8 checkedKey)
{
    //NOTE: if an new OSD page added, please add here!

    switch(_eActiveOSD)
    {
#if ENABLE_PVR
        case E_OSD_PVR:
            return MApp_ZUI_ACT_CheckPvrBypassKey(checkedKey);
#endif

        default:
            UNUSED(checkedKey);
            break;
    }

    return KEY_NULL;
}



////////////////////////////////////////////////////////////////////////////////
BOOLEAN MApp_ZUI_CEC_ByPass(void)
{
    switch(_eActiveOSD)
    {
        case E_OSD_MAIN_MENU:
        case E_OSD_INPUT_SOURCE:
        case E_OSD_FACTORY_MENU:
            return TRUE;

        default:
            return FALSE;
    }
}

////////////////////////////////////////////////////////////////////////////////




////////////////////////////////////////////////////////////////////////////////
#undef MAPP_ZUI_ACTGLOBAL_C


