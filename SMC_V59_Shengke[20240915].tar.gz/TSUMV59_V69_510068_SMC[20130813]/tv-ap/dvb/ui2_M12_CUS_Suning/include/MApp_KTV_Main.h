////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MAPP_KTV_MAIN_H
#define _MAPP_KTV_MAIN_H

#include "datatype.h"
#include "MApp_Exit.h"
#include "MApp_ZUI_APIcommon.h"
#include "mapp_mplayer.h"

#ifdef MAPP_KTV_MAIN_C
#define INTERFACE
#else
#define INTERFACE extern
#endif

#define KTV_DBG(x)    x

#define KTV_DRIVE_NUM_PER_PAGE          8
#define KTV_FILES_NUM_PER_PAGE          8
#define KTV_SELFILES_NUM_PER_PAGE       8


typedef enum
{
    KTV_STATE_INIT,
    KTV_STATE_CONNECTING,
    KTV_STATE_WAIT,
    KTV_STATE_CLEAN_UP,
    KTV_STATE_GOTO_STANDBY,
    KTV_STATE_GOTO_MENU,
    KTV_STATE_GOTO_INPUTSOURCE,
    KTV_STATE_GOTO_PRESOURCE,
} EN_KTV_STATE;

typedef enum
{
    E_KTV_RET_OK,                   /// Function execution successfully
    E_KTV_RET_FAIL,                 /// Function failed
    E_KTV_RET_USB_FAIL,             /// USB failed
    E_KTV_RET_CREADER_FAIL,         /// Card reader failed
    E_KTV_RET_UNSUPPORT_FILESYSTEM, /// Unsupported file system type
    E_KTV_RET_NOT_FOUND,            /// Item not found
    E_KTV_RET_DISK_FULL,            /// Disk is full
    E_KTV_RET_UNSUPPORT,            /// Unsupported format
    E_KTV_RET_IGNORE,               /// Ignore this call
    E_KTV_RET_GOP_ERROR,            /// GOP error
    E_KTV_RET_DIRECTORY_TOO_DEEP,   /// Do not support this depth of directory
    E_KTV_RET_NUM,
} enumKTVRet;

typedef enum
{
    E_KTV_FLAG_NONE                     = 0,
    E_KTV_FLAG_INITED                   = BIT0,
    E_KTV_FLAG_DRIVE_CONNECT_OK         = BIT1,
    E_KTV_FLAG_MEDIA_FILE_PLAYING       = BIT2,
    E_KTV_FLAG_BGM_MODE                 = BIT3,
    E_KTV_FLAG_THUMBNAIL_MODE           = BIT4,
    E_KTV_FLAG_THUMBNAIL_PLAYING        = BIT5,
    E_KTV_FLAG_MEDIA_FILE_PLAYING_ERROR = BIT6,
    E_KTV_FLAG_MOVIE_REPEATAB_MODE      = BIT7,
} EN_KTV_FLAG;

typedef struct
{
    U8                  u8Idx;                          //Current drive index
    U8                  u8PageIdx;                      //Current drive page index
    U8                  au8MapTbl[NUM_OF_MAX_DRIVE];    //drive mapping table
} ST_KTV_DRV_INFO;

INTERFACE void  MApp_KTV_LoadCOPRO (void);
INTERFACE EN_RET MApp_KTV_Main(void);
INTERFACE void MApp_KTV_SetState(EN_KTV_STATE eKTVState);

INTERFACE void MApp_KTV_SetFlag(EN_KTV_FLAG flag);
INTERFACE void MApp_KTV_ClearFlag(EN_KTV_FLAG flag);
INTERFACE EN_KTV_FLAG MApp_KTV_GetFlag(void);

INTERFACE void MApp_KTV_Exit(void);
INTERFACE void MApp_KTV_Reset(void);
INTERFACE void MApp_KTV_InitKTVStatus(void);
INTERFACE void MApp_KTV_SetBGVolume(U8 u8Volume);
INTERFACE void MApp_KTV_SetMicVolume(U8 u8Volume);
INTERFACE void MApp_KTV_SetMixVolume(U8 u8Volume);


INTERFACE U8 MApp_KTV_GetCurDrvIdx(void);
INTERFACE U8 MApp_KTV_GetDrvPageIdx(void);
INTERFACE void MApp_KTV_SetCurDrvIdxAndCalPageIdx(U8 u8Idx);
INTERFACE void MApp_KTV_SetDrvPageIdx(U8 u8Idx);
INTERFACE U8 MApp_KTV_GetDriveFromMappingTable(U8 u8Idx);
INTERFACE BOOLEAN MApp_KTV_RecalculateDriveMappingTable(void);


#undef INTERFACE

#endif  // _MAPP_KTV_MAIN_H

