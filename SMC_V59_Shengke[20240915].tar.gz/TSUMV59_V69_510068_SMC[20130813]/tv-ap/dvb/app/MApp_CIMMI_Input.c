////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#define MAPP_CIMMI_INPUT_C

#define MMI_SI_MONITOR  1 // MediaSet
/********************************************************************************/
/*                            Header Files                                      */
/********************************************************************************/
#include <string.h>
#include <stdio.h>

#include "sysinfo.h"

// Common Definition
#include "MsCommon.h"
#include "apiXC.h"

#include "MApp_IR.h"
#include "apiGOP.h"
#include "msAPI_Timer.h"
#include "msAPI_Video.h"
//#include "MApp_UiMenu.h"//ZUI
#include "MApp_Sleep.h"
#include "MApp_CIMMI.h"
#include "MApp_CIMMI_Private.h"
#include "msAPI_CI.h"
#if MMI_SI_MONITOR // MediaSet
#include "mapp_demux.h"
#include "MApp_MVDMode.h"
#include "MApp_SignalMonitor.h"
#include "MApp_MultiTasks.h"
#endif

/******************************************************************************/
/*                                 Macro                                      */
/******************************************************************************/
#define MMI_DBG(x) //x


#undef MAPP_CIMMI_INPUT_C
