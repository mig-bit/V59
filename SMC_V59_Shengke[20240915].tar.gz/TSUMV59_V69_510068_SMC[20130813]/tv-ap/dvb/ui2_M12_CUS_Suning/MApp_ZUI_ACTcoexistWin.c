////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#define MAPP_ZUI_ACTDRAWDYNAWIN_C
#define _ZUI_INTERNAL_INSIDE_ //NOTE: for ZUI internal


//-------------------------------------------------------------------------------------------------
// Include Files
//-------------------------------------------------------------------------------------------------
#include "MsCommon.h"

#include "MApp_ZUI_APIgdi.h"
#include "MApp_ZUI_APIcommon.h"
#include "apiXC.h"
#include "apiXC_Adc.h"
#include "MApp_GlobalSettingSt.h"
#include "MApp_ZUI_Main.h"
#include "MApp_ZUI_APIcommon.h"
#include "MApp_ZUI_APIstrings.h"
#include "MApp_ZUI_APIwindow.h"
#include "ZUI_tables_h.inl"
#include "MApp_ZUI_APIgdi.h"
#include "MApp_ZUI_APIcontrols.h"
#include "MApp_ZUI_ACTeffect.h"
#include "MApp_ZUI_ACTglobal.h"
#include "OSDcp_String_EnumIndex.h"
#include "ZUI_exefunc.h"
#include "MApp_ZUI_APIcomponent.h"
#include "msAPI_Memory.h"
#include "MApp_ZUI_APIdraw.h"

#include "MApp_ZUI_ACTcoexistWin.h"
#include "MApp_UiMenuDef.h"
#include "MApp_GlobalSettingSt.h"
#include "msAPI_audio.h"
#include "GPIO.h"
//#include "ZUI_bitmap_EnumIndex.h"
#include "OSDcp_Bitmap_EnumIndex.h"
#include "apiGOP.h"
#include "MApp_TopStateMachine.h"
#if ENABLE_CI
#include "MApp_CIMMI.h"
#include "msAPI_CI.h"
#endif
#if (ENABLE_TTX)
#include "msAPI_TTX.h"
#include "mapp_ttx.h"
#endif
#if(ATSC_CC == ATV_CC)
#include "mapp_closedcaption.h"
#include "MApp_AnalogInputs.h"
#endif

#include "MApp_Key.h"
#include "MApp_EpgTimer.h"
#if MHEG5_ENABLE
#include "MApp_MHEG5_Main.h"
#endif
#include "drvGPIO.h"

#include "cusModelSet.h"
#if (((ENABLE_SBTVD_BRAZIL_APP)&&(BRAZIL_CC))||(ATSC_CC == ATV_CC))
#include "mapp_closedcaption.h"
#endif

#if (ENABLE_SUBTITLE)
#include "MApp_Subtitle.h"
#endif

#if (ENABLE_DMP)
#include "mapp_mplayer.h"
#include "msAPI_MPEG_Subtitle.h"
#endif

#if ENABLE_CUS_FACTORY_SHOW_T_ICON
#include "cusFactoryIR.h"
#endif

#if ENABLE_6M30_OSD_PROTECT
#include "drvUrsa6M30.h"
#endif

/////////////////////////////////////////////////////////////////////
extern BOOLEAN _MApp_ZUI_API_AllocateVarData(void);

extern void _MApp_ZUI_API_ConvertTextComponentToDynamic(U16 u16TextOutIndex, DRAW_TEXT_OUT_DYNAMIC * pComp);
//**************************************************************************
#if ENABLE_CUS_UI_SPEC
#if(UI_SKIN_SEL==UI_SKIN_1366X768X565_HAIER_CN)  // CUS_xm zHIHE 20120807 modify

#define MUTE_GWIN_X    850//=ZUI_AUDIO_MUTE_XSTART
#define MUTE_GWIN_Y    460//=ZUI_AUDIO_MUTE_YSTART
#define MUTE_GWIN_W    100//=ZUI_AUDIO_MUTE_WIDTH
#define MUTE_GWIN_H    64//=ZUI_AUDIO_MUTE_HEIGHT
#else
#define MUTE_GWIN_X    890//=ZUI_AUDIO_MUTE_XSTART
#define MUTE_GWIN_Y    470//=ZUI_AUDIO_MUTE_YSTART
#define MUTE_GWIN_W    60//=ZUI_AUDIO_MUTE_WIDTH
#define MUTE_GWIN_H    60//=ZUI_AUDIO_MUTE_HEIGHT
#endif
#else
#define MUTE_GWIN_X    14
#define MUTE_GWIN_Y    57
#define MUTE_GWIN_W   116
#define MUTE_GWIN_H    39
#endif

#define MBOX_GWIN_X    400//400
#define MBOX_GWIN_Y    350//350
#define MBOX_GWIN_W    148//148
#define MBOX_GWIN_H    42//42

#if ENABLE_CUS_FACTORY_SHOW_T_ICON
#define T_ICON_GWIN_X    890//=ZUI_AUDIO_MUTE_XSTART
#define T_ICON_GWIN_Y    470//=ZUI_AUDIO_MUTE_YSTART
#define T_ICON_GWIN_W    60//=ZUI_AUDIO_MUTE_WIDTH
#define T_ICON_GWIN_H    60//=ZUI_AUDIO_MUTE_HEIGHT
#endif


#define CW_DEBUG(x)     //x

typedef struct _OSD_WIN
{
    U8      u8GwinID;
    U8      u8FBID;
    U16     u16GWin_x;
    U16     u16GWin_y;
    U16     u16GWin_w;
    U16     u16GWin_h;
} ZUI_OSD_WIN;

typedef struct
{
    MS_U32 u32NonMirrorFBAdr;
    MS_U16 u16NonMirrorHStr;
    MS_U16 u16NonMirrorHEnd;
    MS_U16 u16NonMirrorVStr;
    MS_U16 u16NonMirrorVEnd;
}ZUI_MUTE_MirrorInfo;

static ZUI_OSD_WIN CoexistWin;
static U8 u8OriGOP;
static U8 u8OriGwin;
static U8 u8MuteFBID =0xFF;  //we havr to keep Mute FB for CAPE
#if 0 //(MirrorEnable)
static ZUI_MUTE_MirrorInfo sMuteMirInfo;
#endif

#if (ENABLE_UI_3D_PROCESS)
#define CO_GWIN_WIDTH      960
#define CO_GWIN_HEIGHT     540
#endif

static void MApp_UiMenu_MuteWin_Create(void);

extern void _MApp_ZUI_API_DrawStyleList(const GRAPHIC_DC * pdc, const RECT * rect, const DRAWSTYLE * style_list);

////
static void _MApp_MUTE_fpGOP_CB(MS_U32 u32EventID, void* reserved0)
{
    //printf("_MApp_MUTE_fpGOP_CB\n");
    reserved0=reserved0;
    //if(enMainMenuState == STATE_MENU_WAIT)
    {
        if(E_GOP_EVENT_BUF_ARRANGE_BEGIN == u32EventID)
        {

        }
        else if(E_GOP_EVENT_BUF_ARRANGE_END == u32EventID)
        {
#if 0 //(MirrorEnable)
            GOP_GwinInfo sGWININfo;
            MApi_GOP_GWIN_GetWinInfo(CoexistWin.u8GwinID, &sGWININfo);
            sMuteMirInfo.u32NonMirrorFBAdr = sGWININfo.u32DRAMRBlkStart;
            sMuteMirInfo.u16NonMirrorHEnd = sGWININfo.u16DispHPixelEnd;
            sMuteMirInfo.u16NonMirrorHStr = sGWININfo.u16DispHPixelStart;
            sMuteMirInfo.u16NonMirrorVStr = sGWININfo.u16DispVPixelStart;
            sMuteMirInfo.u16NonMirrorVEnd = sGWININfo.u16DispVPixelEnd;
#endif
        }
    }
}

void MApp_fpGOP_CB(MS_U32 u32EventID, void* reserved0)
{
    //printf("_MApp_fpGOP_CB\n");
    #if MHEG5_ENABLE
    MApp_MHEG5_fpGOP_CB(u32EventID, reserved0);
    #endif
    MApp_MUTE_fpGOP_CB(u32EventID, reserved0);
}

void MApp_MUTE_fpGOP_CB(MS_U32 u32EventID, void* reserved0)
{
    _MApp_MUTE_fpGOP_CB(u32EventID, reserved0);
}

//******************************************************************************
void MApp_ZUI_ACTcoexistWin_SwitchGwin(void)
{
    u8OriGOP = MApi_GOP_GWIN_GetCurrentGOP();
    u8OriGwin = MApi_GOP_GWIN_GetCurrentWinId();
    if (u8OriGOP != OSD_GOP_ID)
    {
        MApi_GOP_GWIN_SwitchGOP(OSD_GOP_ID);
    }
    if (u8OriGwin != CoexistWin.u8GwinID)
    {
        MApi_GOP_GWIN_Switch2Gwin(CoexistWin.u8GwinID);
    }
}


void MApp_ZUI_ACTcoexistWin_RestoreGwin(void)
{
    if (u8OriGOP != OSD_GOP_ID)
    {
        MApi_GOP_GWIN_SwitchGOP(u8OriGOP);
    }
    if ((u8OriGwin != CoexistWin.u8GwinID) && (u8OriGwin < MAX_GWIN_SUPPORT))
    {
        MApi_GOP_GWIN_Switch2Gwin(u8OriGwin);
    }
}

void MApp_ZUI_ACTcoexistWin_Init(void)
{
    GFX_Buffer_Format gefmt;
    U8 u8FBID=0xFF;
    MApp_ZUI_ACTcoexistWin_SwitchGwin();

    CoexistWin.u8FBID = 0xFF;
    CoexistWin.u8GwinID = 0xFF;
    u8CoexistWinType = COWIN_ID_NONE;

#if (MPLAYER_BITMAP_FORMAT == MPLAYER_I8)
    gefmt = GFX_FMT_I8;
#elif (MPLAYER_BITMAP_FORMAT == MPLAYER_RGB555)
    gefmt = GFX_FMT_ARGB1555;
#elif (MPLAYER_BITMAP_FORMAT == MPLAYER_ARGB1555)
        gefmt = GFX_FMT_ARGB1555;
#elif (MPLAYER_BITMAP_FORMAT == MPLAYER_RGB565)
    gefmt = GFX_FMT_RGB565;
#elif (MPLAYER_BITMAP_FORMAT == MPLAYER_ARGB4444)
    gefmt = GFX_FMT_ARGB4444;
#elif (MPLAYER_BITMAP_FORMAT == MPLAYER_ARGB8888)
    gefmt = GFX_FMT_ARGB8888;
#else
    #error "unsupported pixel format!"
#endif
    CoexistWin.u8GwinID = MApi_GOP_GWIN_CreateWin(4,8, gefmt); //create default win
    u8MuteFBID = 0xFF;
    u8FBID=MApi_GOP_GWIN_GetFBfromGWIN(CoexistWin.u8GwinID);
    MApi_GOP_GWIN_SetForceWrite(TRUE);
    MApi_GOP_GWIN_DeleteFB(u8FBID);

    if(CoexistWin.u8GwinID == GWIN_NO_AVAILABLE)
    {
        CW_DEBUG(printf("Can't create Coexist win\n");)
    }
    else
    {
        MApi_GOP_GWIN_SwapOverlapWin(OSD_GOP_ID, CoexistWin.u8GwinID); //switch to top layer
    }
    MApi_GOP_RegisterEventNotify(MApp_fpGOP_CB);
}

BOOLEAN MApp_ZUI_ACTcoexist_Create(U8 win_ID, U16 win_x,U16 win_y,U16 win_w,U16 win_h)
{
    U8 u8FbID=0XFF;
    BOOLEAN bEnableAlpha;
    U8 u8GopAlpha;
    GFX_Buffer_Format gefmt;

    MApp_ZUI_ACTcoexistWin_SwitchGwin();

#if (ENABLE_UI_3D_PROCESS)
    if(MApp_ZUI_API_Is_UI_3D_Mode_ON())
    {
        if(MApp_ZUI_Query_UI_3D_Mode() == E_UI_3D_OUTPUT_SIDE_BY_SIDE_HALF)
    {
            win_x /= 2;
            win_y = win_y;
            if(MApp_ZUI_Query_CoexistWin_Half_Mode())
            {
               win_w = (win_w)/2;
            }
            else
            {
                win_w = (CO_GWIN_WIDTH + win_w)/2;
            }
            win_h = win_h;
            //win_w = (win_w + 0x03) & ~(0x03);//align-4
            win_w = (win_w + 0x07) & ~(0x07);//align-8
            if(win_x + win_w > CO_GWIN_WIDTH)
            {
                win_w = CO_GWIN_WIDTH - win_x;
                if((win_w + 0x07) > CO_GWIN_WIDTH)
                    win_w = CO_GWIN_WIDTH;
                else
                    win_w = (win_w + 0x07) & ~(0x07);//align-8
            }
    }
    else
    {
            win_x = win_x;
            win_y /= 2;
            win_w = (win_w + 0x07) & ~(0x07);//align-8
            if(MApp_ZUI_Query_CoexistWin_Half_Mode())
            {
                win_h = (win_h)/2;
            }
            else
        {
                win_h = (CO_GWIN_HEIGHT + win_h)/2;
            }
        }
        printf(" Co-Exit[%d, %d, %d, %d]", win_x, win_y, win_w, win_h);
        }
    //else
#endif
#if (MPLAYER_BITMAP_FORMAT == MPLAYER_I8)
        gefmt = GFX_FMT_I8;
#elif (MPLAYER_BITMAP_FORMAT == MPLAYER_RGB555)
        gefmt = GFX_FMT_ARGB1555;
#elif (MPLAYER_BITMAP_FORMAT == MPLAYER_ARGB1555)
        gefmt = GFX_FMT_ARGB1555;
#elif (MPLAYER_BITMAP_FORMAT == MPLAYER_RGB565)
        gefmt = GFX_FMT_RGB565;
#elif (MPLAYER_BITMAP_FORMAT == MPLAYER_ARGB4444)
        gefmt = GFX_FMT_ARGB4444;
#elif (MPLAYER_BITMAP_FORMAT == MPLAYER_ARGB8888)
        gefmt = GFX_FMT_ARGB8888;
#else
        #error "unsupported pixel format!"
#endif
        u8FbID = MApi_GOP_GWIN_GetFreeFBID();
        if (u8FbID == 0xFF)
        {
            CW_DEBUG(printf("[MUTE]:Create FB failed\n"));
            ABORT();
            return FALSE;
        }
        MApi_GOP_GWIN_CreateFB(u8FbID, 0, 0, win_w, win_h, gefmt);
        MApi_GOP_GWIN_MapFB2Win(u8FbID, CoexistWin.u8GwinID);
        MApi_GOP_GWIN_Switch2FB(u8FbID);
        MApi_GOP_GWIN_SetWinPosition(CoexistWin.u8GwinID, win_x + (MApi_GOP_GWIN_Get_HSTART()), win_y);
        msAPI_OSD_SetClipWindow(0, 0, win_w, win_h);

#if (MPLAYER_BITMAP_FORMAT == MPLAYER_I8)
        bEnableAlpha = TRUE; //alpha table is depend by 256 color table
        u8GopAlpha = 63;
#elif (MPLAYER_BITMAP_FORMAT == MPLAYER_ARGB4444 || MPLAYER_BITMAP_FORMAT == MPLAYER_ARGB8888 || MPLAYER_BITMAP_FORMAT == MPLAYER_I8)
        //for ARGB4444, ARGB8888 disable GOP alpha
        bEnableAlpha = TRUE;
        u8GopAlpha = 63;
#else
        bEnableAlpha = FALSE;
        u8GopAlpha = (63*9/10);
#endif

        MApi_GOP_GWIN_SetBlending(CoexistWin.u8GwinID, bEnableAlpha, u8GopAlpha);
        MApi_GFX_SetAlpha(FALSE, COEF_CONST, ABL_FROM_CONST, 0xFF); //=> msAPI_OSD_DisableAlpha();

        #if (MPLAYER_BITMAP_FORMAT == MPLAYER_I8)
        _MApp_ZUI_API_InitPalette(); //before set palette for GOP
        MApi_GOP_GWIN_SetTransClr(GOPTRANSCLR_FMT1, 0); //NOTE: index color 0 is transparent
        MApi_GOP_GWIN_EnableTransClr(GOPTRANSCLR_FMT1,TRUE);
        #else
        MApi_GOP_GWIN_SetFMT0TransClr(ZUI_COLOR_TRANSPARENT_RGB555);
        #endif
        //if(win_ID != COWIN_ID_MUTE)
        {
            clrBtn1.x = 0;
            clrBtn1.y = 0;
            clrBtn1.width = win_w;
            clrBtn1.height = win_h;
            clrBtn1.b_clr = ZUI_COLOR_TRANSPARENT_RGB8888;
            clrBtn1.u8Gradient = CONSTANT_COLOR;
            clrBtn1.fHighLight = FALSE;
            msAPI_OSD_DrawBlock(&clrBtn1); //clean win
        }
    MApi_GOP_GWIN_SetForceWrite(FALSE);
    /////////////////////////////////////////////////////////
    u8CoexistWinType = win_ID;
    CoexistWin.u8FBID = u8FbID;
    CoexistWin.u16GWin_x = win_x;
    CoexistWin.u16GWin_y = win_y;
    CoexistWin.u16GWin_h = win_h;
    CoexistWin.u16GWin_w = win_w;

    MApp_ZUI_ACTcoexistWin_RestoreGwin();

#if ENABLE_6M30_OSD_PROTECT
    if(u8CoexistWinType == COWIN_ID_COUNT_DOWN_WIN)
    {
        MDrv_Ursa_OsdWinHandler(E_OSD_COUNT_DOWN_WIN, TRUE);
    }
    else
    {
        MDrv_Ursa_OsdWinHandler(E_OSD_MUTE_WIN, TRUE);
    }
#endif

    return TRUE;
}

//not really delete Gwin, just reset u8CoexistWinType
void MApp_ZUI_ACTcoexist_Delete( void)
{
    if(u8CoexistWinType != COWIN_ID_NONE)
    {
        MApp_ZUI_ACTcoexistWin_SwitchGwin();
        MApi_GOP_GWIN_Enable(CoexistWin.u8GwinID, FALSE);

        MApi_GOP_GWIN_DeleteWin(CoexistWin.u8GwinID);
        CoexistWin.u8FBID = 0xFF;
        u8CoexistWinType = COWIN_ID_NONE;

        MApp_ZUI_ACTcoexistWin_RestoreGwin();

#if ENABLE_6M30_OSD_PROTECT
        if(u8CoexistWinType == COWIN_ID_COUNT_DOWN_WIN)
        {
            MDrv_Ursa_OsdWinHandler(E_OSD_COUNT_DOWN_WIN, FALSE);
        }
        else
        {
            MDrv_Ursa_OsdWinHandler(E_OSD_MUTE_WIN, FALSE);
        }
#endif
    }
}

#if (ENABLE_UI_3D_PROCESS)
void MApp_ZUI_ACTcoexist_RealDelete( void)
{
    if(u8CoexistWinType != COWIN_ID_NONE)
        {
        MApp_ZUI_ACTcoexistWin_SwitchGwin();
        MApi_GOP_GWIN_Enable(CoexistWin.u8GwinID, FALSE);

        MApi_GOP_GWIN_DeleteFB(CoexistWin.u8FBID);

        CoexistWin.u8FBID = 0xFF;
        u8CoexistWinType = COWIN_ID_NONE;

        MApp_ZUI_ACTcoexistWin_RestoreGwin();
    }
    u8MuteFBID = 0xFF;
}
#endif

void MApp_ZUI_ACTcoexist_Enable(BOOLEAN bEnable)
{
    MApp_ZUI_ACTcoexistWin_SwitchGwin();
    MApi_GOP_GWIN_Enable(CoexistWin.u8GwinID, bEnable);
    MApp_ZUI_ACTcoexistWin_RestoreGwin();
}

//============================================================================
static void MApp_UiMenu_MuteWin_Create(void)
{
    GRAPHIC_DC Wdc;
    RECT    Wrect;
    WINDOWPOSDATA *t_GUI_WPT;
#if 0 //(MirrorEnable)
    GOP_GwinInfo sGWININfo;
#endif
    BOOLEAN  bCreateOk=FALSE;

#if ENABLE_CUS_UI_SPEC
    DRAWSTYLE * _Zui_Volume_Mute_Pane_Normal_DrawStyle =  _GUI_WindowsDrawStyleList_Zui_Audio_Mute[HWND_AUDIO_MUTE_PANEL].pNormalStyle;
    DRAWSTYLE * _Zui_Volume_Mute_Icon_Normal_DrawStyle =  _GUI_WindowsDrawStyleList_Zui_Audio_Mute[HWND_AUDIO_MUTE_ICON].pNormalStyle;
    DRAWSTYLE * _Zui_Volume_Mute_Text_Normal_DrawStyle =  _GUI_WindowsDrawStyleList_Zui_Audio_Mute[HWND_AUDIO_MUTE_TEXT].pNormalStyle;
    DRAWSTYLE * _Zui_Volume_Mute_BG_Normal_DrawStyle =  _GUI_WindowsDrawStyleList_Zui_Audio_Mute[HWND_AUDIO_MUTE_BG].pNormalStyle;
 #else
     DRAWSTYLE * _Zui_Volume_Mute_Pane_Normal_DrawStyle =  _GUI_WindowsDrawStyleList_Zui_Audio_Volume[HWND_VOLUME_MUTE_PANE].pNormalStyle;
     DRAWSTYLE * _Zui_Volume_Mute_Icon_Normal_DrawStyle =  _GUI_WindowsDrawStyleList_Zui_Audio_Volume[HWND_VOLUME_MUTE_ICON].pNormalStyle;
     DRAWSTYLE * _Zui_Volume_Mute_Text_Normal_DrawStyle =  _GUI_WindowsDrawStyleList_Zui_Audio_Volume[HWND_VOLUME_MUTE_TEXT].pNormalStyle;
     DRAWSTYLE * _Zui_Volume_Mute_BG_Normal_DrawStyle =  _GUI_WindowsDrawStyleList_Zui_Audio_Volume[HWND_VOLUME_MUTE_ICON_BG].pNormalStyle;
     //DRAWSTYLE * _Zui_Volume_Mute_BG_R_Normal_DrawStyle =  _GUI_WindowsDrawStyleList_Zui_Audio_Volume[HWND_VOLUME_MUTE_ICON_BG_R].pNormalStyle;
 #endif
#if (ATSC_CC == ATV_CC)
    if ((IsATVInUse()||IsAVInUse()) && stGenSetting.g_SysSetting.enATVCaptionType != ATV_CAPTION_TYPE_OFF)
    {
        if ( MApp_CC_GetInfo(CC_SELECTOR_STATUS_CODE) == STATE_CAPTION_PARSER)
        {
             MApp_CC_StopParser();
             MApp_Set_CCState(FALSE);
        }
    }
#endif

#if ((ENABLE_SBTVD_BRAZIL_APP)&&(BRAZIL_CC))
    if ((IsDTVInUse() && stGenSetting.g_SysSetting.enDTVCaptionType != DTV_CAPTION_OFF)
        ||((IsATVInUse()||IsAVInUse()) && stGenSetting.g_SysSetting.enATVCaptionType != ATV_CAPTION_TYPE_OFF))
    {
        if ( MApp_CC_GetInfo(CC_SELECTOR_STATUS_CODE) == STATE_CAPTION_PARSER)
        {
             MApp_CC_StopParser();
        }
    }
#endif

#if (CHIP_FAMILY_TYPE == CHIP_FAMILY_M12)
    #if (ENABLE_SUBTITLE)
    if (IsDTVInUse())
    {
        if ( MApp_Subtitle_GetStatus() == STATE_SUBTITLE_DECODING)
        {
             MApp_Subtitle_SetShowStatus(FALSE);
        }
    }
    #endif
#endif
#if ENABLE_DMP
    if (IsStorageInUse())
    {
        if (MApp_MPlayer_IsMoviePlaying())
        {
            msAPI_MpegSP_SetShowStatus(FALSE);
        }
    }
#endif

  //  MApp_ZUI_ACTcoexistWin_SwitchGwin();
#if (ENABLE_UI_3D_PROCESS)
    if(MApp_ZUI_API_Is_UI_3D_Mode_ON())
    {
        MApp_ZUI_API_Set_CoexistWin_Half(TRUE);
    }
#endif

    MApp_ZUI_ACTcoexist_Delete();
    bCreateOk=MApp_ZUI_ACTcoexist_Create(COWIN_ID_MUTE, MUTE_GWIN_X, MUTE_GWIN_Y, MUTE_GWIN_W, MUTE_GWIN_H);
    if(bCreateOk==FALSE)
    {
        printf(" MuteWin_Create  fail\n");
        return;
    }
#if (ENABLE_UI_3D_PROCESS)
    if(MApp_ZUI_API_Is_UI_3D_Mode_ON())
    {
        Wdc = MApp_ZUI_API_CreateDC(MUTE_GWIN_W, MUTE_GWIN_H);
    }
    else
#endif
    {
    Wdc.u8FbID = CoexistWin.u8FBID;
    }

    u8MuteFBID = CoexistWin.u8FBID;
    Wdc.u8ConstantAlpha = 0xFF;

    t_GUI_WPT = g_GUI_WindowPositionList;
#if ENABLE_CUS_UI_SPEC
    g_GUI_WindowPositionList = _GUI_WindowPositionList_Zui_Audio_Mute;

    MApp_ZUI_API_GetWindowInitialRect(HWND_AUDIO_MUTE_PANEL,&Wrect);
    _MApp_ZUI_API_DrawStyleList(&Wdc, &Wrect, _Zui_Volume_Mute_Pane_Normal_DrawStyle);
    MApp_ZUI_API_GetWindowInitialRect(HWND_AUDIO_MUTE_BG,&Wrect);
    _MApp_ZUI_API_DrawStyleList(&Wdc, &Wrect, _Zui_Volume_Mute_BG_Normal_DrawStyle);
    //MApp_ZUI_API_GetWindowInitialRect(HWND_VOLUME_MUTE_ICON_BG_R,&Wrect);
    //_MApp_ZUI_API_DrawStyleList(&Wdc, &Wrect, _Zui_Volume_Mute_BG_R_Normal_DrawStyle);
    MApp_ZUI_API_GetWindowInitialRect(HWND_AUDIO_MUTE_ICON,&Wrect);
    _MApp_ZUI_API_DrawStyleList(&Wdc, &Wrect, _Zui_Volume_Mute_Icon_Normal_DrawStyle);
    MApp_ZUI_API_GetWindowInitialRect(HWND_AUDIO_MUTE_TEXT,&Wrect);
    _MApp_ZUI_API_DrawStyleList(&Wdc, &Wrect, _Zui_Volume_Mute_Text_Normal_DrawStyle);
#else
    g_GUI_WindowPositionList = _GUI_WindowPositionList_Zui_Audio_Volume;

    MApp_ZUI_API_GetWindowInitialRect(HWND_VOLUME_MUTE_PANE,&Wrect);
    _MApp_ZUI_API_DrawStyleList(&Wdc, &Wrect, _Zui_Volume_Mute_Pane_Normal_DrawStyle);
    MApp_ZUI_API_GetWindowInitialRect(HWND_VOLUME_MUTE_ICON_BG,&Wrect);
    _MApp_ZUI_API_DrawStyleList(&Wdc, &Wrect, _Zui_Volume_Mute_BG_Normal_DrawStyle);
    //MApp_ZUI_API_GetWindowInitialRect(HWND_VOLUME_MUTE_ICON_BG_R,&Wrect);
    //_MApp_ZUI_API_DrawStyleList(&Wdc, &Wrect, _Zui_Volume_Mute_BG_R_Normal_DrawStyle);
    MApp_ZUI_API_GetWindowInitialRect(HWND_VOLUME_MUTE_ICON,&Wrect);
    _MApp_ZUI_API_DrawStyleList(&Wdc, &Wrect, _Zui_Volume_Mute_Icon_Normal_DrawStyle);
    MApp_ZUI_API_GetWindowInitialRect(HWND_VOLUME_MUTE_TEXT,&Wrect);
    _MApp_ZUI_API_DrawStyleList(&Wdc, &Wrect, _Zui_Volume_Mute_Text_Normal_DrawStyle);
#endif
    g_GUI_WindowPositionList = t_GUI_WPT;

#if (ENABLE_UI_3D_PROCESS)
    if(MApp_ZUI_API_ConvertTo3DTwinModeOutput(Wdc.u8FbID, CoexistWin.u8FBID, MUTE_GWIN_W, MUTE_GWIN_H) == TRUE)
    {
        MApp_ZUI_API_DeleteDC(Wdc);
    }
    MApp_ZUI_API_Set_CoexistWin_Half(FALSE);
#endif

#if 0//(MirrorEnable)
    MApi_GOP_GWIN_GetWinInfo(CoexistWin.u8GwinID, &sGWININfo);
    sMuteMirInfo.u32NonMirrorFBAdr = sGWININfo.u32DRAMRBlkStart;
    sMuteMirInfo.u16NonMirrorHEnd = sGWININfo.u16DispHPixelEnd;
    sMuteMirInfo.u16NonMirrorHStr = sGWININfo.u16DispHPixelStart;
    sMuteMirInfo.u16NonMirrorVStr = sGWININfo.u16DispVPixelStart;
    sMuteMirInfo.u16NonMirrorVEnd = sGWININfo.u16DispVPixelEnd;
#endif
    //MApp_ZUI_ACTcoexistWin_RestoreGwin();
}


//***************************************************************
//* return: 0 : not show MUTE icon
//*         1 : delete all win and show MUTE icon(due to use same GWIN ID)
//*         2 : show MUTE icon but not delete all GWIN
//***************************************************************
static U8 MApp_UiMenu_NeedShowMuteIcon(void)
{
#if ENABLE_TTX
    if(MApp_TTX_IsTeletextOn()&&MApp_TTX_GetControlMode()==TTX_MODE_NORMAL) //draw nothing in TTX mode
        return 0;
#endif

    if ( (MApp_TopStateMachine_GetTopState()== STATE_TOP_DTV_SCAN)
        || (MApp_TopStateMachine_GetTopState()== STATE_TOP_ATV_SCAN))
        return 0;

    #if ENABLE_CUS_FACTORY_SHOW_T_ICON
    if(u8CoexistWinType == COWIN_ID_FACTORY_TEST_WIN)
    {
        return 3;
    }
    #endif

    if((u8CoexistWinType != COWIN_ID_MUTE)
        && (u8CoexistWinType != 0xFF))
        return 0;
    if(CoexistWin.u8GwinID == 0xFF)
    {
        MS_DEBUG_MSG(printf("CoexistWin.u8GwinID is not created.\n"));
        return 0;
    }

    if(MApp_ZUI_GetActiveOSD() == E_OSD_AUDIO_VOLUME)
        return 1;

    return 2;
}

void MApp_UiMenu_MuteWin_Show(void)
{
    U8 ret = MApp_UiMenu_NeedShowMuteIcon();
#if 0 //(MirrorEnable)
    GOP_GwinInfo sGWININfo;
#endif

    switch(ret)
    {
        #if ENABLE_CUS_FACTORY_SHOW_T_ICON
        case 3:
            // DON'T DO NOTHING because "T" is showing
            return;
        #endif
        case 1:
            MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_CLOSE_CURRENT_OSD); //close current window
            //go on show MUTE win
        case 2:
        default:
            if(u8CoexistWinType != COWIN_ID_MUTE)
            {
                MApp_UiMenu_MuteWin_Create(); //prepare MUTE window, maybe can rewrite to reduce boot up time
            }

#if 0 //(MirrorEnable)
            /*deal with mute fb adr and position when gop mirror on*/
            MApi_GOP_GWIN_GetWinInfo(CoexistWin.u8GwinID, &sGWININfo);
            sGWININfo.u32DRAMRBlkStart = sMuteMirInfo.u32NonMirrorFBAdr;
            sGWININfo.u16DispHPixelStart = sMuteMirInfo.u16NonMirrorHStr;
            sGWININfo.u16DispHPixelEnd = sMuteMirInfo.u16NonMirrorHEnd;
            sGWININfo.u16DispVPixelStart = sMuteMirInfo.u16NonMirrorVStr;
            sGWININfo.u16DispVPixelEnd = sMuteMirInfo.u16NonMirrorVEnd;
            MApi_GOP_GWIN_SetWinInfo(CoexistWin.u8GwinID, &sGWININfo);

#endif
            MApp_ZUI_ACTcoexist_Enable(TRUE);
            break;
    }

#if ENABLE_TTX
    if(MApp_TTX_GetControlMode()==TTX_MODE_SUBTITLE)
    {
            MApp_TTX_BackToTTXMode();
    }
#endif
}

void MApp_UiMenu_MuteWin_Hide(void)
{
     U8 u8FBID=0XFF;

    if(u8CoexistWinType == COWIN_ID_MUTE)
    {
        MApp_ZUI_ACTcoexist_Enable(FALSE);
        u8FBID=MApi_GOP_GWIN_GetFBfromGWIN(CoexistWin.u8GwinID);
        MApi_GOP_GWIN_DeleteFB(u8FBID);
        //MApi_GOP_GWIN_DeleteWin(CoexistWin.u8GwinID);

        CoexistWin.u8FBID = 0xFF;
        u8CoexistWinType = COWIN_ID_NONE;

#if ENABLE_6M30_OSD_PROTECT
        MDrv_Ursa_OsdWinHandler(E_OSD_MUTE_WIN, FALSE);
#endif
    }
}
#if DTG_FREEVIEW_STANDBY
extern BOOLEAN MApp_FreeView_Is_Standby(void);
#endif
#if BOE_POP_MODIFY
#include "msAPI_Timer.h"
#endif
void MApp_KeyProc_Mute(void)
{
    BOOLEAN bIsAudioMuted;

    bIsAudioMuted = msAPI_AUD_IsAudioMutedByUser();
    u8KeyCode = KEY_NULL;


#if DTG_FREEVIEW_STANDBY
    if(MApp_FreeView_Is_Standby())
        return;
#endif
    if (bIsAudioMuted == FALSE)
    {
        msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_BYUSER_MUTEON, E_AUDIOMUTESOURCE_ACTIVESOURCE);
        #if ENABLE_CI
        if(!bActiveMMI) // MediaSet
        #endif
        MApp_UiMenu_MuteWin_Show();
 #if BOE_POP_MODIFY
 		msAPI_Timer_Delayms(300);
        MUTE_On();
#else
#if !(AUDIO_EN_CONTROL_DISABLE) // CUS_XM Sea 20120615
        MUTE_On();
#endif
#endif
    }
    else
    {
    #if ENABLE_TTX
        if(MApp_TTX_GetControlMode()==TTX_MODE_SUBTITLE)
        {
            MApp_TTX_BackToOSDMode();
        }
    #endif
        msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_BYUSER_MUTEOFF, E_AUDIOMUTESOURCE_ACTIVESOURCE);
    #if ENABLE_CI
        if(!bActiveMMI) // MediaSet
    #endif
        MApp_UiMenu_MuteWin_Hide();
 #if (!BOE_POP_MODIFY)
        MUTE_Off();
#endif
    #if ENABLE_TTX
        if(MApp_TTX_GetControlMode()==TTX_MODE_SUBTITLE)
        {
            MApp_TTX_BackToTTXMode();
        }
    #endif
 
#if ENABLE_NO_AUDIO_INPUT_AUTO_MUTE
		 if(IsAVInUse()||IsSVInUse()||IsYPbPrInUse()||IsVgaInUse()||IsATVInUse()||IsHDMIInUse())
		 {
			 BYTE NR_status;
			 
			 //printf("\r\n-4-");
		  if(MApp_IsSrcHasSignal(MAIN_WINDOW))
		    {
			 NR_status = MApi_AUDIO_GetCommAudioInfo(Audio_Comm_infoType_getNR_Status) ;
			 {
				 if(!NR_status)
				 {
					 if(!msAPI_AUD_IsAudioMutedByUser()&&stGenSetting.g_SoundSetting.Volume)
					 	{
						 msAPI_Timer_Delayms(300);
						 MUTE_Off();
					 	}
					 else
						 MUTE_On();
				 }
				 else
				 {
					 MUTE_On();
				 }
			 }
			}
		  else
			  MUTE_On();
		 }
		 else
         { 	
           if(IsStorageInUse()&&MAPP_USBAudioMute())
              MUTE_On();
           else
            {
              msAPI_Timer_Delayms(300);
              MUTE_Off();
            }
         }
  #else
  #if BOE_POP_MODIFY
  {
  msAPI_Timer_Delayms(300);
  MUTE_Off();
  }
  #endif
  #endif
    }
}

//============================================================================
// create countdown box
//============================================================================
//extern WINDOWPOSDATA _MP_TBLSEG _GUI_WindowPositionList_Zui_Message_Box[];
//extern WINDOWDRAWSTYLEDATA _MP_TBLSEG _GUI_WindowsDrawStyleList_Zui_Message_Box[];
/*
extern DRAWSTYLE _MP_TBLSEG _Zui_Msgbox_Bg_Pane_Normal_DrawStyle[];
extern DRAWSTYLE _MP_TBLSEG _Zui_Msgbox_Bg_Icon_Normal_DrawStyle[];
extern DRAWSTYLE _MP_TBLSEG _Zui_Msgbox_Text1_Normal_DrawStyle[];
*/

void MApp_UiMenu_CountDownWin_Draw(void)
{
    GRAPHIC_DC Wdc;
    RECT    Wrect;
    U8 u8DbFbId;
    GFX_Buffer_Format gefmt;
    MSAPI_OSDRegion CopyFB;
    MSAPI_OSDRegion PasteFB;
    WINDOWPOSDATA *t_GUI_WPT;

    DRAWSTYLE * _Zui_Msgbox_New_Bg_C_Normal_DrawStyle =  _GUI_WindowsDrawStyleList_Zui_Message_Box[HWND_MSGBOX_COUNTDOWN_BG_C].pNormalStyle;
    //DRAWSTYLE * _Zui_Msgbox_New_Bg_L_Normal_DrawStyle =  _GUI_WindowsDrawStyleList_Zui_Message_Box[HWND_MSGBOX_COUNTDOWN_BG_L].pNormalStyle;
    //DRAWSTYLE * _Zui_Msgbox_New_Bg_R_Normal_DrawStyle =  _GUI_WindowsDrawStyleList_Zui_Message_Box[HWND_MSGBOX_COUNTDOWN_BG_R].pNormalStyle;
    DRAWSTYLE * _Zui_Msgbox_Text1_Normal_DrawStyle =  _GUI_WindowsDrawStyleList_Zui_Message_Box[HWND_MSGBOX_COUNTDOWN_TEXT1].pNormalStyle;
    DRAWSTYLE * _Zui_Msgbox_Text2_Normal_DrawStyle =  _GUI_WindowsDrawStyleList_Zui_Message_Box[HWND_MSGBOX_COUNTDOWN_TEXT2].pNormalStyle;

    MApp_ZUI_ACTcoexistWin_SwitchGwin();

        u8DbFbId = MApi_GOP_GWIN_GetFreeFBID();
    if (u8DbFbId == 0xFF)
    {
        CW_DEBUG(printf("[MUTE]:Create u8DbFbId failed\n"));
        ABORT();
        return ;
    }

#if (MPLAYER_BITMAP_FORMAT == MPLAYER_I8)
    gefmt = GFX_FMT_I8;
#elif (MPLAYER_BITMAP_FORMAT == MPLAYER_RGB555)
    gefmt = GFX_FMT_ARGB1555;
#elif (MPLAYER_BITMAP_FORMAT == MPLAYER_ARGB1555)
        gefmt = GFX_FMT_ARGB1555;
#elif (MPLAYER_BITMAP_FORMAT == MPLAYER_RGB565)
    gefmt = GFX_FMT_RGB565;
#elif (MPLAYER_BITMAP_FORMAT == MPLAYER_ARGB4444)
    gefmt = GFX_FMT_ARGB4444;
#elif (MPLAYER_BITMAP_FORMAT == MPLAYER_ARGB8888)
    gefmt = GFX_FMT_ARGB8888;
#else
    #error "unsupported pixel format!"
#endif

    MApi_GOP_GWIN_CreateFB(u8DbFbId, 0, 0, MBOX_GWIN_W, MBOX_GWIN_H, gefmt);
    Wdc.u8FbID = u8DbFbId;//CoexistWin.u8FBID;
    Wdc.u8ConstantAlpha = 0xFF;

    t_GUI_WPT = g_GUI_WindowPositionList;
    g_GUI_WindowPositionList = _GUI_WindowPositionList_Zui_Message_Box;

    MApp_ZUI_API_GetWindowInitialRect(HWND_MSGBOX_COUNTDOWN_BG_C,&Wrect);
    _MApp_ZUI_API_DrawStyleList(&Wdc, &Wrect, _Zui_Msgbox_New_Bg_C_Normal_DrawStyle);
    /*MApp_ZUI_API_GetWindowInitialRect(HWND_MSGBOX_COUNTDOWN_BG_L,&Wrect);
    _MApp_ZUI_API_DrawStyleList(&Wdc, &Wrect, _Zui_Msgbox_New_Bg_L_Normal_DrawStyle);
    MApp_ZUI_API_GetWindowInitialRect(HWND_MSGBOX_COUNTDOWN_BG_R,&Wrect);
    _MApp_ZUI_API_DrawStyleList(&Wdc, &Wrect, _Zui_Msgbox_New_Bg_R_Normal_DrawStyle);*/

    MApp_ZUI_API_GetWindowInitialRect(HWND_MSGBOX_COUNTDOWN_TEXT1,&Wrect);
    {
        DRAW_TEXT_OUT_DYNAMIC * dyna;
        U16 u16TextIndex = _Zui_Msgbox_Text1_Normal_DrawStyle[0].u16Index;
        if (u16TextIndex != 0xFFFF)
        {
            dyna = (DRAW_TEXT_OUT_DYNAMIC*)_ZUI_MALLOC(sizeof(DRAW_TEXT_OUT_DYNAMIC));
            if (dyna)
            {
                LPTSTR str = CHAR_BUFFER;
                _MApp_ZUI_API_ConvertTextComponentToDynamic(u16TextIndex, dyna);

                MApp_ZUI_API_GetU16String((U16)MApp_Sleep_DisplayCountDownTimer());

                str += MApp_ZUI_API_Strlen(str);
                *str = CHAR_SPACE;
                str++;
                MApp_ZUI_API_LoadString(en_str_Dialog_Counter_Down_Text, str);

                dyna->pString = CHAR_BUFFER;

                _MApp_ZUI_API_DrawDynamicComponent(CP_TEXT_OUT_DYNAMIC, dyna, &Wdc, &Wrect);
                _ZUI_FREE(dyna);
            }
            else
            {
                __ASSERT(0);
            }
        }
    }

    MApp_ZUI_API_GetWindowInitialRect(HWND_MSGBOX_COUNTDOWN_TEXT2,&Wrect);
    {
        DRAW_TEXT_OUT_DYNAMIC * dyna;
        U16 u16TextIndex = _Zui_Msgbox_Text2_Normal_DrawStyle[0].u16Index;
        if (u16TextIndex != 0xFFFF)
        {
           dyna = (DRAW_TEXT_OUT_DYNAMIC*)_ZUI_MALLOC(sizeof(DRAW_TEXT_OUT_DYNAMIC));
            if (dyna)
            {
                _MApp_ZUI_API_ConvertTextComponentToDynamic(u16TextIndex, dyna);
                MApp_ZUI_API_LoadString(en_str_Dialog_Counter_Down_Text2, CHAR_BUFFER);
                dyna->pString = CHAR_BUFFER;
                _MApp_ZUI_API_DrawDynamicComponent(CP_TEXT_OUT_DYNAMIC, dyna, &Wdc, &Wrect);
                _ZUI_FREE(dyna);
            }
            else
            {
                __ASSERT(0);
            }
        }
    }

#if (ENABLE_UI_3D_PROCESS)
    if(MApp_ZUI_API_ConvertTo3DTwinModeOutput(Wdc.u8FbID, CoexistWin.u8FBID, MBOX_GWIN_W, MBOX_GWIN_H) == FALSE)
#endif
    {
    PasteFB.fbID = CoexistWin.u8FBID;
    PasteFB.x = 0;
    PasteFB.y = 0;
    PasteFB.width = MBOX_GWIN_W;
    PasteFB.height = MBOX_GWIN_H;

    CopyFB.fbID = u8DbFbId;
    CopyFB.x = 0;
    CopyFB.y = 0;
    CopyFB.width = MBOX_GWIN_W;
    CopyFB.height = MBOX_GWIN_H;
    msAPI_OSD_SetClipWindow(0, 0,MBOX_GWIN_W, MBOX_GWIN_H);
    msAPI_OSD_CopyRegion(&CopyFB, &PasteFB);
    }

    MApi_GOP_GWIN_DeleteFB(u8DbFbId);

    g_GUI_WindowPositionList = t_GUI_WPT;

    MApp_ZUI_ACTcoexistWin_RestoreGwin();
}

BOOLEAN MApp_UiMenu_GetCoexistWin_State(void)
{
    if((u8CoexistWinType == COWIN_ID_COUNT_DOWN_WIN) \
        ||(u8CoexistWinType == COWIN_ID_MUTE))
   {
      return FALSE;
   }
    else
   {
      return TRUE;
   }
}


void MApp_UiMenu_CountDownWin_Create(void)
{
    BOOLEAN  bCreateOk=FALSE;

#if (ATSC_CC == ATV_CC)
    if ((IsATVInUse()||IsAVInUse()) && stGenSetting.g_SysSetting.enATVCaptionType != ATV_CAPTION_TYPE_OFF)
    {
        if ( MApp_CC_GetInfo(CC_SELECTOR_STATUS_CODE) == STATE_CAPTION_PARSER)
        {
             MApp_CC_StopParser();
             MApp_Set_CCState(FALSE);
        }
    }
#endif

#if ((ENABLE_SBTVD_BRAZIL_APP)&&(BRAZIL_CC))
    if ((IsDTVInUse() && stGenSetting.g_SysSetting.enDTVCaptionType != DTV_CAPTION_OFF)
        ||((IsATVInUse()||IsAVInUse()) && stGenSetting.g_SysSetting.enATVCaptionType != ATV_CAPTION_TYPE_OFF))
    {
        if ( MApp_CC_GetInfo(CC_SELECTOR_STATUS_CODE) == STATE_CAPTION_PARSER)
        {
             MApp_CC_StopParser();
        }
    }
#endif

#if (CHIP_FAMILY_TYPE == CHIP_FAMILY_M12)
    #if (ENABLE_SUBTITLE)
    if (IsDTVInUse())
    {
        if ( MApp_Subtitle_GetStatus() == STATE_SUBTITLE_DECODING)
        {
             MApp_Subtitle_SetShowStatus(FALSE);
        }
    }
    #endif
#endif

#if ENABLE_DMP
    if (IsStorageInUse())
    {
        if (MApp_MPlayer_IsMoviePlaying())
        {
            msAPI_MpegSP_SetShowStatus(FALSE);
        }
    }
#endif

   // MApp_ZUI_ACTcoexistWin_SwitchGwin();
 #if (ENABLE_UI_3D_PROCESS)
    if(MApp_ZUI_API_Is_UI_3D_Mode_ON())
    {
      //  MApp_ZUI_API_Set_CoexistWin_Half(TRUE);
       if (MApp_ZUI_GetActiveOSD()!=E_OSD_EMPTY)
       {
          MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_CLOSE_CURRENT_OSD);
       }
    }
#endif

    MApp_ZUI_ACTcoexist_Delete();
    bCreateOk=MApp_ZUI_ACTcoexist_Create(COWIN_ID_COUNT_DOWN_WIN, MBOX_GWIN_X, MBOX_GWIN_Y, MBOX_GWIN_W, MBOX_GWIN_H);
    if(bCreateOk==FALSE)
    {
        printf(" CountDownWin_Create  fail\n");
        return;
    }
    MApp_UiMenu_CountDownWin_Draw();

    MApp_ZUI_ACTcoexist_Enable(TRUE);

   // MApp_ZUI_ACTcoexistWin_RestoreGwin();
}

void MApp_UiMenu_ShowCountDownWin(void)
{
    U8 u8TmpCurGOP;

    u8TmpCurGOP = MApi_GOP_GWIN_GetCurrentGOP();
    if (u8TmpCurGOP != OSD_GOP_ID) //GOP of OSD
    {
        MApi_GOP_GWIN_SwitchGOP(OSD_GOP_ID);
    }

    if(u8CoexistWinType != COWIN_ID_COUNT_DOWN_WIN)
    {
        MApp_UiMenu_CountDownWin_Create(); //prepare MUTE window, maybe can rewrite to reduce boot up time
        MApp_ZUI_ACTcoexist_Enable(TRUE);
    }
    else
    {
    }

    if (u8TmpCurGOP != OSD_GOP_ID) //GOP of OSD
    {
            MApi_GOP_GWIN_SwitchGOP(u8TmpCurGOP);
    }
#if ENABLE_TTX
    if(MApp_TTX_GetControlMode()==TTX_MODE_SUBTITLE)
    {
            MApp_TTX_BackToTTXMode();
    }
#endif
}

#if ENABLE_CUS_FACTORY_SHOW_T_ICON
static void MApp_UiMenu_T_Icon_Win_Create(void)
{
    GRAPHIC_DC Wdc;
    RECT    Wrect;
    WINDOWPOSDATA *t_GUI_WPT;
#if 0 //(MirrorEnable)
    GOP_GwinInfo sGWININfo;
#endif
    BOOLEAN  bCreateOk=FALSE;

    DRAWSTYLE * _Zui_T_Icon_Pane_Normal_DrawStyle =  _GUI_WindowsDrawStyleList_Zui_Audio_Mute[HWND_TEST_MODE_WIN_PANEL].pNormalStyle;
    DRAWSTYLE * _Zui_T_Icon_Icon_Normal_DrawStyle =  _GUI_WindowsDrawStyleList_Zui_Audio_Mute[HWND_TEST_MODE_WIN_ICON].pNormalStyle;
    DRAWSTYLE * _Zui_T_Icon_Text_Normal_DrawStyle =  _GUI_WindowsDrawStyleList_Zui_Audio_Mute[HWND_TEST_MODE_WIN_TEXT].pNormalStyle;
    DRAWSTYLE * _Zui_T_Icon_BG_Normal_DrawStyle =  _GUI_WindowsDrawStyleList_Zui_Audio_Mute[HWND_TEST_MODE_WIN_BG].pNormalStyle;
#if (ATSC_CC == ATV_CC)
    if ((IsATVInUse()||IsAVInUse()) && stGenSetting.g_SysSetting.enATVCaptionType != ATV_CAPTION_TYPE_OFF)
    {
        if ( MApp_CC_GetInfo(CC_SELECTOR_STATUS_CODE) == STATE_CAPTION_PARSER)
        {
             MApp_CC_StopParser();
             MApp_Set_CCState(FALSE);
        }
    }
#endif

#if ((ENABLE_SBTVD_BRAZIL_APP)&&(BRAZIL_CC))
    if ((IsDTVInUse() && stGenSetting.g_SysSetting.enDTVCaptionType != DTV_CAPTION_OFF)
        ||((IsATVInUse()||IsAVInUse()) && stGenSetting.g_SysSetting.enATVCaptionType != ATV_CAPTION_TYPE_OFF))
    {
        if ( MApp_CC_GetInfo(CC_SELECTOR_STATUS_CODE) == STATE_CAPTION_PARSER)
        {
             MApp_CC_StopParser();
        }
    }
#endif

#if (CHIP_FAMILY_TYPE == CHIP_FAMILY_M12)
    #if (ENABLE_SUBTITLE)
    if (IsDTVInUse())
    {
        if ( MApp_Subtitle_GetStatus() == STATE_SUBTITLE_DECODING)
        {
             MApp_Subtitle_SetShowStatus(FALSE);
        }
    }
    #endif
#endif

  //  MApp_ZUI_ACTcoexistWin_SwitchGwin();
#if (ENABLE_UI_3D_PROCESS)
    if(MApp_ZUI_API_Is_UI_3D_Mode_ON())
    {
        MApp_ZUI_API_Set_CoexistWin_Half(TRUE);
    }
#endif

    MApp_ZUI_ACTcoexist_Delete();
    bCreateOk=MApp_ZUI_ACTcoexist_Create(COWIN_ID_FACTORY_TEST_WIN, T_ICON_GWIN_X, T_ICON_GWIN_Y, T_ICON_GWIN_W, T_ICON_GWIN_H);
    if(bCreateOk==FALSE)
    {
        printf(" T_ICONWin_Create  fail\n");
        return;
    }
#if (ENABLE_UI_3D_PROCESS)
    if(MApp_ZUI_API_Is_UI_3D_Mode_ON())
    {
        Wdc = MApp_ZUI_API_CreateDC(MUTE_GWIN_W, MUTE_GWIN_H);
    }
    else
#endif
    {
        Wdc.u8FbID = CoexistWin.u8FBID;
    }

    u8MuteFBID = CoexistWin.u8FBID;
    Wdc.u8ConstantAlpha = 0xFF;

    t_GUI_WPT = g_GUI_WindowPositionList;

    g_GUI_WindowPositionList = _GUI_WindowPositionList_Zui_Audio_Mute;
    MApp_ZUI_API_GetWindowInitialRect(HWND_TEST_MODE_WIN_PANEL,&Wrect);
    _MApp_ZUI_API_DrawStyleList(&Wdc, &Wrect, _Zui_T_Icon_Pane_Normal_DrawStyle);
    MApp_ZUI_API_GetWindowInitialRect(HWND_TEST_MODE_WIN_BG,&Wrect);
    _MApp_ZUI_API_DrawStyleList(&Wdc, &Wrect, _Zui_T_Icon_BG_Normal_DrawStyle);
    MApp_ZUI_API_GetWindowInitialRect(HWND_TEST_MODE_WIN_ICON,&Wrect);
    _MApp_ZUI_API_DrawStyleList(&Wdc, &Wrect, _Zui_T_Icon_Icon_Normal_DrawStyle);
    MApp_ZUI_API_GetWindowInitialRect(HWND_TEST_MODE_WIN_TEXT,&Wrect);
    _MApp_ZUI_API_DrawStyleList(&Wdc, &Wrect, _Zui_T_Icon_Text_Normal_DrawStyle);
    g_GUI_WindowPositionList = t_GUI_WPT;

#if (ENABLE_UI_3D_PROCESS)
    if(MApp_ZUI_API_ConvertTo3DTwinModeOutput(Wdc.u8FbID, CoexistWin.u8FBID, MUTE_GWIN_W, MUTE_GWIN_H) == TRUE)
    {
        MApp_ZUI_API_DeleteDC(Wdc);
    }
    MApp_ZUI_API_Set_CoexistWin_Half(FALSE);
#endif

#if 0//(MirrorEnable)
    MApi_GOP_GWIN_GetWinInfo(CoexistWin.u8GwinID, &sGWININfo);
    sMuteMirInfo.u32NonMirrorFBAdr = sGWININfo.u32DRAMRBlkStart;
    sMuteMirInfo.u16NonMirrorHEnd = sGWININfo.u16DispHPixelEnd;
    sMuteMirInfo.u16NonMirrorHStr = sGWININfo.u16DispHPixelStart;
    sMuteMirInfo.u16NonMirrorVStr = sGWININfo.u16DispVPixelStart;
    sMuteMirInfo.u16NonMirrorVEnd = sGWININfo.u16DispVPixelEnd;
#endif
    //MApp_ZUI_ACTcoexistWin_RestoreGwin();
}



//***************************************************************
//* return: 0 : not show MUTE icon
//*         1 : delete all win and show MUTE icon(due to use same GWIN ID)
//*         2 : show MUTE icon but not delete all GWIN
//***************************************************************
static U8 MApp_UiMenu_NeedShow_T_Icon(void)
{
#if ENABLE_TTX
    if(MApp_TTX_IsTeletextOn()&&MApp_TTX_GetControlMode()==TTX_MODE_NORMAL) //draw nothing in TTX mode
        return 0;
#endif

    if((u8CoexistWinType != COWIN_ID_FACTORY_TEST_WIN)
        && (u8CoexistWinType != 0xFF))
        return 0;

    if(CoexistWin.u8GwinID == 0xFF)
    {
        MS_DEBUG_MSG(printf("CoexistWin.u8GwinID is not created.\n"));
        return 0;
    }

    return 2;
}

void MApp_UiMenu_T_Icon_Win_Show(void)
{
    U8 ret = MApp_UiMenu_NeedShow_T_Icon();

    switch(ret)
    {
        case 1:
            MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_CLOSE_CURRENT_OSD); //close current window
            //go on show MUTE win
        case 2:
        default:
            if(u8CoexistWinType != COWIN_ID_FACTORY_TEST_WIN)
            {
                MApp_UiMenu_T_Icon_Win_Create(); //prepare MUTE window, maybe can rewrite to reduce boot up time
            }

            MApp_ZUI_ACTcoexist_Enable(TRUE);
            break;
    }

    #if ENABLE_TTX
    if(MApp_TTX_GetControlMode()==TTX_MODE_SUBTITLE)
    {
        MApp_TTX_BackToTTXMode();
    }
    #endif
}

void MApp_UiMenu_T_Icon_Win_Hide(void)
{
     U8 u8FBID=0XFF;

    if(u8CoexistWinType == COWIN_ID_FACTORY_TEST_WIN)
    {
        MApp_ZUI_ACTcoexist_Enable(FALSE);
        u8FBID=MApi_GOP_GWIN_GetFBfromGWIN(CoexistWin.u8GwinID);
        MApi_GOP_GWIN_DeleteFB(u8FBID);
        //MApi_GOP_GWIN_DeleteWin(CoexistWin.u8GwinID);

        CoexistWin.u8FBID = 0xFF;
        u8CoexistWinType = COWIN_ID_NONE;

#if ENABLE_6M30_OSD_PROTECT
        MDrv_Ursa_OsdWinHandler(E_OSD_MUTE_WIN, FALSE);
#endif
    }
}
void MApp_FactoryIR_TestKeyProc(void)
{
#if DTG_FREEVIEW_STANDBY
    if(MApp_FreeView_Is_Standby())
        return;
#endif
    if (GetCUSFactoryRCEnableStatus() == TRUE)
    {
        #if ENABLE_CI
        if(!bActiveMMI) // MediaSet
        #endif
        {
            MApp_UiMenu_T_Icon_Win_Show();
        }
    }
    else
    {
    #if ENABLE_TTX
        if(MApp_TTX_GetControlMode()==TTX_MODE_SUBTITLE)
        {
            MApp_TTX_BackToOSDMode();
        }
    #endif
    #if ENABLE_CI
        if(!bActiveMMI) // MediaSet
    #endif
        {
            MApp_UiMenu_T_Icon_Win_Hide();
        }

    #if ENABLE_TTX
        if(MApp_TTX_GetControlMode()==TTX_MODE_SUBTITLE)
        {
            MApp_TTX_BackToTTXMode();
        }
    #endif
    }
}
void MApp_KeyProc_DMPMute(void)
{
    BOOLEAN bIsAudioMuted;

    bIsAudioMuted = msAPI_AUD_IsAudioMutedByUser();
    u8KeyCode = KEY_NULL;


#if DTG_FREEVIEW_STANDBY
    if(MApp_FreeView_Is_Standby())
        return;
#endif
    if (bIsAudioMuted == FALSE)
    {
        msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_BYUSER_MUTEON, E_AUDIOMUTESOURCE_ACTIVESOURCE);
        //#if ENABLE_CI
        //if(!bActiveMMI) // MediaSet
        //#endif
        //MApp_UiMenu_MuteWin_Show();

#if BOE_POP_MODIFY
		msAPI_Timer_Delayms(300);
		MUTE_On();
#else
#if !(AUDIO_EN_CONTROL_DISABLE) // CUS_XM Sea 20120615
		MUTE_On();
#endif
#endif

    }
    else
    {
    #if ENABLE_TTX
        if(MApp_TTX_GetControlMode()==TTX_MODE_SUBTITLE)
        {
            MApp_TTX_BackToOSDMode();
        }
    #endif
        msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_BYUSER_MUTEOFF, E_AUDIOMUTESOURCE_ACTIVESOURCE);
    #if ENABLE_CI
        if(!bActiveMMI) // MediaSet
    #endif
        //MApp_UiMenu_MuteWin_Hide();
#if BOE_POP_MODIFY
		msAPI_Timer_Delayms(300);
#endif
#if ENABLE_NO_AUDIO_INPUT_AUTO_MUTE
	if(IsStorageInUse()&&MAPP_USBAudioMute())
		MUTE_On();
    else
#endif
		MUTE_Off();

    #if ENABLE_TTX
        if(MApp_TTX_GetControlMode()==TTX_MODE_SUBTITLE)
        {
            MApp_TTX_BackToTTXMode();
        }
    #endif
    }
}
void MApp_KeyProc_MuteMonitor(BOOLEAN bSwitch)
{
if(bSwitch)
{
    if (msAPI_AUD_IsAudioMutedByUser())
    {
        if(u8CoexistWinType != COWIN_ID_MUTE)
        MApp_UiMenu_MuteWin_Show();
    }
    else
    {
        if(u8CoexistWinType == COWIN_ID_MUTE)
        MApp_UiMenu_MuteWin_Hide();
    }
}
else
{
    if(u8CoexistWinType == COWIN_ID_MUTE)
    MApp_UiMenu_MuteWin_Hide();
}
}

#endif
#undef MAPP_ZUI_ACTAUDIOVOLUME_C
