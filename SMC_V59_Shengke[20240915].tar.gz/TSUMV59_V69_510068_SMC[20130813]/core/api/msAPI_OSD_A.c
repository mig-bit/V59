////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2008 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  [Doxygen]
/// @file msAPI_OSD.h
/// This file includes MStar application interface for OSD
/// @brief API for OSD functions
/// @author MStar Semiconductor, Inc.
//
////////////////////////////////////////////////////////////////////////////////

#define MSAPI_OSD_A_C

/********************************************************************************/
/*                    Header Files                                                */
/********************************************************************************/
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "datatype.h"

#include "msAPI_OSD_A.h"
#include "drvGlobal.h"
#include "MApp_GlobalVar.h"
#include "apiGOP.h"
#include "msAPI_CPU.h"
#include "msAPI_JPEG_MM.h"

#include "msAPI_MIU.h"
#include "sysinfo.h"
#include "msAPI_Timer.h"
#include "mapp_photo.h"
#include "msAPI_OCP_A.h"

#if ENABLE_JPEGPNG_OSD
#define JPGTIME_DBG(x)  x
#define TIME_DBG(x) //x
// Before call this function, must set the u32FlashImgAddr&u32FlashImgSize and
// set the target buf to pJpegPngHandle->u32BuffAddr.
// Notice: MDrv_BEON_Init must be called with BIN_ID_CODE_AEON_VDPLAYER already !!!
//         Only support file size < MAD_JPEG_READBUFF_LEN
extern BOOLEAN bUseFlashSize;
BOOLEAN MApp_PhotoOSD_DecodeToBuf(MSAPI_JPEGPNGHANDLE* pJpegPngHandle)
{
    //JPEG_DECODE_STATUS u8DecodeStatus = JPEG_DECODE_RUNNING;
    U16 u16SrcW, u16SrcH, u16Pitch;
    U32 u32outBufSize;
    TIME_DBG(U32 StartTime);

    BOOLEAN bRet = FALSE;

    MApp_Photo_DoAlphaBlendForPng(DISABLE);

    TIME_DBG(StartTime = msAPI_Timer_GetTime0());

    TIME_DBG(printf("Decode11 time = %lu ms\n",  msAPI_Timer_DiffTimeFromNow(StartTime)));

    // Load image to decode buf
    if(pJpegPngHandle->bFlashBinFlg)
    {
        msAPI_MIU_Copy(pJpegPngHandle->u32FlashImgAddr, MAD_JPEG_DISPLAY_ADR, GE_ALIGNED_VALUE(pJpegPngHandle->u32FlashImgSize, 8), MIU_FLASH2SDRAM);
    }
    else
    {
        msAPI_MIU_Copy(pJpegPngHandle->u32FlashImgAddr, MAD_JPEG_DISPLAY_ADR, GE_ALIGNED_VALUE(pJpegPngHandle->u32FlashImgSize, 8), MIU_SDRAM2SDRAM);
    }
    TIME_DBG(printf("Decode time22 = %lu ms\n",  msAPI_Timer_DiffTimeFromNow(StartTime)));

    JPGTIME_DBG(U32 StartTime = msAPI_Timer_GetTime0());

//---------------------------------------------------------------
    if((msAPI_OCP_JpegPngGetOutBufLen() - (pJpegPngHandle->u32BuffAddr - msAPI_OCP_JpegPngGetOutBufPos()))>((U32)MAD_JPEG_OUT_LEN))
        u32outBufSize = MAD_JPEG_OUT_LEN;
    else
        u32outBufSize = (msAPI_OCP_JpegPngGetOutBufLen() - (pJpegPngHandle->u32BuffAddr - msAPI_OCP_JpegPngGetOutBufPos()));

      if(bUseFlashSize) // temp-debug // for need check
     {
         u32outBufSize=0;
     }
    //printf("\nXXXXXXXXXXX");
    printf("\nu32outBufSize :%d",u32outBufSize);
    printf("\nu32Addr :%d",pJpegPngHandle->u32BuffAddr);
    MApp_Photo_MemCfg(
            ((MAD_JPEG_DISPLAY_MEMORY_TYPE & MIU1) ? (MAD_JPEG_DISPLAY_ADR | MIU_INTERVAL) : (MAD_JPEG_DISPLAY_ADR)), MAD_JPEG_DISPLAY_LEN,
            pJpegPngHandle->u32BuffAddr,u32outBufSize,
            ((MAD_JPEG_INTERBUFF_MEMORY_TYPE & MIU1) ? (MAD_JPEG_INTERBUFF_ADR | MIU_INTERVAL) : (MAD_JPEG_INTERBUFF_ADR)), MAD_JPEG_INTERBUFF_LEN);

    TIME_DBG(printf("Decode time33 = %lu ms\n",  msAPI_Timer_DiffTimeFromNow(StartTime)));
    if (MApp_Photo_DecodeMemory_Init(FALSE, NULL))
    {
        EN_RET enPhotoRet;

        TIME_DBG(printf("Decode time44 = %lu ms\n",  msAPI_Timer_DiffTimeFromNow(StartTime)));
        while ((enPhotoRet = MApp_Photo_Main()) == EXIT_PHOTO_DECODING)
            ;

        TIME_DBG(printf("Decode time55 = %lu ms\n",  msAPI_Timer_DiffTimeFromNow(StartTime)));

        if ((enPhotoRet == EXIT_PHOTO_DECODE_DONE) && (MApp_Photo_GetErrCode() == E_PHOTO_ERR_NONE))
        {
            bRet = TRUE;
             //Set the parameters to pJpegPngHandle
            u16SrcW = MApp_Photo_GetInfo(E_PHOTO_INFO_WIDTH);
            u16SrcH = MApp_Photo_GetInfo(E_PHOTO_INFO_HEIGHT);
            u16Pitch = MApp_Photo_GetInfo(E_PHOTO_INFO_PITCH);
            pJpegPngHandle->u16BufImgWidth = u16SrcW;
            pJpegPngHandle->u16BufImgHeight = u16SrcH;
            pJpegPngHandle->u16BufImgPitch = u16Pitch;
             // printf("\n Image:bJpegFlg =%d\n ",  pJpegPngHandle->bJpegFlg);

            if(pJpegPngHandle->bJpegFlg)
            {
                pJpegPngHandle->u8BufImgFmt = GFX_FMT_YUV422;
                pJpegPngHandle->u32BuffSize = u16SrcH*u16Pitch*2;
            }
            else
            {
                pJpegPngHandle->u8BufImgFmt = GFX_FMT_ARGB8888;
                pJpegPngHandle->u32BuffSize = u16SrcH*u16Pitch*4;
            }
            //printf("\n Image:u32BuffSize = 0x%x,\n ",  pJpegPngHandle->u32BuffSize);

            //printf("\n Image:u16SrcW = %d, u16SrcH = %d, u16Pitch = %d\n", u16SrcW, u16SrcH, u16Pitch);
            JPGTIME_DBG(printf("\n Jpg Decode time: %Lu ms", msAPI_Timer_DiffTimeFromNow(StartTime)));
        }
    }

    MApp_Photo_Stop();

    MApp_Photo_DoAlphaBlendForPng(ENABLE);

    if (bRet == FALSE)
    {
        (printf("logo decode failed\n"));
    }

    TIME_DBG(printf("Decode time66 = %lu ms\n",  msAPI_Timer_DiffTimeFromNow(StartTime)));
    return bRet;

//---------------------------------------------------------------

}

// bSrcAlphaReplaceDstAlpha control the MDrv_GE_SetAlpha's coef(the coef used to generate the cout base on cSrc&cDest) para
// False : COEF_ONE -> Cout equal Csrc
// True  : COEF_SRC -> Cout equal Csrc * apl_src_pixel + Cdst * (1 - apl_src_pixel)
// Cout = Csrc * reg_pe_abl_coef + Cdst * (1 - reg_pe_abl_coef)

void msAPI_OSD_DrawJpegPng(U8 u8Index, U16 u16PosX, U16 u16PosY, U16 u16Width, U16 u16Height, U8 u8Fbid, BOOLEAN bSrcAlphaReplaceDstAlpha, U8 u8JpegAlpha)
{
    GOP_GwinFBAttr fbAttr;
    GFX_Buffer_Format u8ImgBufFmt;
    GEBitBltInfo stBitbltInfo;
    GEPitBaseInfo stPitBaseInfo;

    if(Osdcp_JpegPngHandle[u8Index].bInitFlg == FALSE)
    {
        printf("\n JpegPng[%ld] not load....", u8Index);
        return;
    }
    MApi_GOP_GWIN_GetFBInfo(u8Fbid, &fbAttr);

    msAPI_OSD_GET_resource();

    stBitbltInfo.BitbltCoordinate.v0_x = u16PosX;
    stBitbltInfo.BitbltCoordinate.v0_y = u16PosY;
    stBitbltInfo.BitbltCoordinate.v2_x = 0;
    stBitbltInfo.BitbltCoordinate.v2_y = 0;
    stBitbltInfo.BitbltCoordinate.height = u16Height;
    stBitbltInfo.BitbltCoordinate.width  = (u16Width)&0xfffc;
    stBitbltInfo.BitbltCoordinate.direction = 0;

    stBitbltInfo.src_height = Osdcp_JpegPngHandle[u8Index].u16BufImgHeight&0xFFFE;
    stBitbltInfo.src_width = Osdcp_JpegPngHandle[u8Index].u16BufImgWidth&0xFFFE;
    u8ImgBufFmt = (GFX_Buffer_Format)Osdcp_JpegPngHandle[u8Index].u8BufImgFmt;
    stBitbltInfo.src_fm = u8ImgBufFmt;
    stBitbltInfo.dst_fm = fbAttr.fbFmt;
    stBitbltInfo.BitBltTypeFlag = GEBitbltType_Normal;
    stBitbltInfo.BmpFlag = GFXDRAW_FLAG_DEFAULT;

    stPitBaseInfo.sb_base = Osdcp_JpegPngHandle[u8Index].u32BuffAddr;
    if(u8ImgBufFmt == GFX_FMT_ARGB8888)
        stPitBaseInfo.sb_pit = Osdcp_JpegPngHandle[u8Index].u16BufImgPitch*4;
    else
        stPitBaseInfo.sb_pit = Osdcp_JpegPngHandle[u8Index].u16BufImgPitch*2;

    stPitBaseInfo.db_base = fbAttr.addr;
    stPitBaseInfo.db_pit = fbAttr.pitch;

/*
    printf("\n Photo : u16RectW = 0x%x, %ld", Osdcp_JpegPngHandle[u8Index].u16BufImgWidth, Osdcp_JpegPngHandle[u8Index].u16BufImgWidth);
    printf("\n         u16RectH = 0x%x, %ld", Osdcp_JpegPngHandle[u8Index].u16BufImgHeight, Osdcp_JpegPngHandle[u8Index].u16BufImgHeight);

    printf("\n Src : stBitbltInfo.src_width = 0x%x, %ld", stBitbltInfo.src_width, stBitbltInfo.src_width);
    printf("\n       stBitbltInfo.src_height = 0x%x, %ld", stBitbltInfo.src_height, stBitbltInfo.src_height);
    printf("\n       stBitbltInfo.sb_base = 0x%x, %ld", stPitBaseInfo.sb_base, stPitBaseInfo.sb_base);
    printf("\n       stBitbltInfo.sb_pit = 0x%x, %ld", stPitBaseInfo.sb_pit, stPitBaseInfo.sb_pit);

    printf("\n Tar : stBitbltInfo.BitbltCoordinate.width = 0x%x, %ld", stBitbltInfo.BitbltCoordinate.width, stBitbltInfo.BitbltCoordinate.width);
    printf("\n       stBitbltInfo.BitbltCoordinate.height = 0x%x, %ld", stBitbltInfo.BitbltCoordinate.height, stBitbltInfo.BitbltCoordinate.height);
    printf("\n Tar : stBitbltInfo.BitbltCoordinate.v0_x = %d, ", stBitbltInfo.BitbltCoordinate.v0_x);
    printf("\n       stBitbltInfo.BitbltCoordinate.v0_y = %d, ", stBitbltInfo.BitbltCoordinate.v0_y);
    printf("\n       stPitBaseInfo.db_base = 0x%x, %ld", stPitBaseInfo.db_base, stPitBaseInfo.db_base);
    printf("\n       stPitBaseInfo.db_pit = 0x%x, %ld", stPitBaseInfo.db_pit, stPitBaseInfo.db_pit);

    printf("\n stPitBaseInfo.db_pit = 0x%x", stPitBaseInfo.db_pit);
*/
    if(u8ImgBufFmt == GFX_FMT_ARGB8888)
    {
         MDrv_GE_SetDC_CSC_FMT(GFX_YUV_RGB2YUV_PC, GFX_YUV_OUT_PC, GFX_YUV_IN_255, GFX_YUV_YUYV,  GFX_YUV_YUYV);
        if(bSrcAlphaReplaceDstAlpha)
        {
            MApi_GFX_SetAlpha(TRUE, COEF_ASRC, ABL_FROM_ASRC, 0);
        }
        else
        {
              MApi_GFX_SetAlpha(TRUE, COEF_ASRC, ABL_FROM_ADST, 0);
        }
     }
    else
    {
        MDrv_GE_SetDC_CSC_FMT(GFX_YUV_RGB2YUV_PC, GFX_YUV_OUT_PC, GFX_YUV_IN_255, GFX_YUV_YUYV,  GFX_YUV_YUYV);
        MApi_GFX_SetAlpha(TRUE, COEF_CONST, ABL_FROM_CONST, u8JpegAlpha);
        MApi_GFX_SetPatchMode(TRUE);

    }

    MDrv_GE_BitBlt(&stBitbltInfo, &stPitBaseInfo);
        // after BitBlt, flush cmd
    MApi_GFX_FlushQueue();

    if(u8ImgBufFmt == GFX_FMT_ARGB8888)
    {

    }
    else
    {
        MApi_GFX_SetPatchMode(FALSE);
    }
    msAPI_OSD_Free_resource();
}

#endif
#undef MSAPI_OSD_A_C
