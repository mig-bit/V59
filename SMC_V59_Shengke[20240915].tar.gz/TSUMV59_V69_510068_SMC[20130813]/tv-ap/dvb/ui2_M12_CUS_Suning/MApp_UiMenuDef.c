////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#define MAPP_UIMENUDEF_C

/******************************************************************************/
/*                 Header Files                                               */
/* ****************************************************************************/
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "Board.h"
#include "datatype.h"
#include "MsCommon.h"
#include "apiXC.h"
#include "apiXC_Adc.h"

#include "msAPI_ATVSystem.h"
#include "msAPI_ChProc.h"
#include "msAPI_DTVSystem.h"
#include "msAPI_Memory.h"
#include "msAPI_MIU.h"
#include "msAPI_Timer.h"

#include "MApp_GlobalSettingSt.h"
#include "MApp_Exit.h"
#include "MApp_Key.h"

#if (ENABLE_DTV)
#include "mapp_demux.h"
#endif

//ZUI: #include "MApp_DispMenu.h"
#include "MApp_DataBase.h"
#include "MApp_InputSource.h"
#include "MApp_GlobalVar.h"
#include "MApp_ChannelList.h"
#include "MApp_ChannelChange.h"
#include "MApp_ChannelList.h"
#include "MApp_UiMenuDef.h"

//static U8 code _dummy = 0;

//////////////////////////////////////////////////////////
// From MApp_UiMenuStr.c

//moved to EPG: U16* p_string_buffer = (U16*) au8Section;
//moved to EPG: U16* p_alt_string_buffer = (U16*) au8StringBuffer;
//unused: U16* p_copy_string_buffer = (U16*) au8StringBuffer2;

#undef MAPP_UIMENUDEF_C

