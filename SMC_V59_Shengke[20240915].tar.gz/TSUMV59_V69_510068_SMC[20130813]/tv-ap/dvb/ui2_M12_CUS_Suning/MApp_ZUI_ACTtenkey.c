////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#define MAPP_ZUI_ACTTENKEY_C
#define _ZUI_INTERNAL_INSIDE_ //NOTE: for ZUI internal


//-------------------------------------------------------------------------------------------------
// Include Files
//-------------------------------------------------------------------------------------------------
#include "Board.h"
#include "datatype.h"
#include "MsCommon.h"
#include "apiXC.h"
#include "apiXC_Adc.h"
#include "MApp_GlobalSettingSt.h"
#include "MApp_ZUI_Main.h"
#include "MApp_ZUI_APIcommon.h"
#include "MApp_ZUI_APIstrings.h"
#include "MApp_ZUI_APIwindow.h"
#include "ZUI_tables_h.inl"
#include "MApp_ZUI_APIgdi.h"
#include "MApp_ZUI_APIcontrols.h"
#include "MApp_ZUI_ACTmainpage.h"
#include "MApp_ZUI_ACTeffect.h"
#include "MApp_ZUI_ACTglobal.h"
#include "OSDcp_String_EnumIndex.h"
#include "ZUI_exefunc.h"
#include "MApp_GlobalFunction.h"
#include "MApp_TV.h"

/////////////////////////////////////////////////////////////////////
extern BOOLEAN _MApp_ZUI_API_AllocateVarData(void);

void MApp_ZUI_ACT_AppShowTenKeyNumber(void)
{
    HWND wnd;
    RECT rect;
    E_OSD_ID osd_id = E_OSD_TENKEY_NUMBER;

    g_GUI_WindowList = GetWindowListOfOsdTable(osd_id);
    g_GUI_WinDrawStyleList = GetWindowStyleOfOsdTable(osd_id);
    g_GUI_WindowPositionList = GetWindowPositionOfOsdTable(osd_id);
#if ZUI_ENABLE_ALPHATABLE
    g_GUI_WinAlphaDataList = GetWindowAlphaDataOfOsdTable(osd_id);
#endif
    HWND_MAX = GetWndMaxOfOsdTable(osd_id);
    OSDPAGE_BLENDING_ENABLE = IsBlendingEnabledOfOsdTable(osd_id);
    OSDPAGE_BLENDING_VALUE = GetBlendingValueOfOsdTable(osd_id);

    if (!_MApp_ZUI_API_AllocateVarData())
    {
        ZUI_DBG_FAIL(printf("[ZUI]ALLOC\n"));
        ABORT();
        return;
    }

    RECT_SET(rect,
        ZUI_TENKEY_NUMBER_XSTART, ZUI_TENKEY_NUMBER_YSTART,
        ZUI_TENKEY_NUMBER_WIDTH, ZUI_TENKEY_NUMBER_HEIGHT);

    if (!MApp_ZUI_API_InitGDI(&rect))
    {
        ZUI_DBG_FAIL(printf("[ZUI]GDIINIT\n"));
        ABORT();
        return;
    }

    for (wnd = 0; wnd < HWND_MAX; wnd++)
    {
        //printf("create msg: %lu\n", (U32)wnd);
        MApp_ZUI_API_SendMessage(wnd, MSG_CREATE, 0);
    }

    MApp_ZUI_API_ShowWindow(HWND_MAINFRAME, SW_SHOW);

    MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_NONE, E_ZUI_STATE_RUNNING);

}


//////////////////////////////////////////////////////////
// Key Handler

BOOLEAN MApp_ZUI_ACT_HandleTenKeyNumberKey(VIRTUAL_KEY_CODE key)
{
    //note: don't do anything here! keys will be handled in state machines
    //      moved to MApp_TV_ProcessAudioVolumeKey()
    UNUSED(key);
    ZUI_DBG_FAIL(printf("[ZUI]IDLEKEY\n"));
    //ABORT();
    return FALSE;
}

void MApp_ZUI_ACT_TerminateTenKeyNumber(void)
{
   ZUI_MSG( printf("[]term:tenkey\n");)


}

BOOLEAN MApp_ZUI_ACT_ExecuteTenKeyNumberAction(U16 act)
{
    switch(act)
    {
        case EN_EXE_CLOSE_CURRENT_OSD:
        //case EN_EXE_POWEROFF: //minglin1212
            MApp_ZUI_ACT_TransitionEffectBegin(EN_EFFMODE_CLOSE, E_ZUI_STATE_TERMINATE);
            return TRUE;

        case EN_EXE_RESET_AUTO_CLOSE_TIMER:
            //reset timer if any key
            MApp_ZUI_API_ResetTimer(HWND_TENKEY_BG, 0);
            return FALSE;
    }
    return FALSE;
}

LPTSTR MApp_ZUI_ACT_GetTenKeyNumberDynamicText(HWND hwnd)
{
    // Marked it by coverity_304
    //U16 u16TempID = Empty;

    switch(hwnd)
    {
        case HWND_TENKEY_CHNUMBER:
          #if ENABLE_SBTVD_BRAZIL_APP
                if (enLCNTypeVerified == MAJOR_CH_NUM)
                {
                    return MApp_ZUI_API_GetU16String(u8IdleMajorValue);
                }
                else
                {
                    LPTSTR str = CHAR_BUFFER;

                    MApp_UlongToU16String((U32)u8IdleMajorValue, str, (S8)MApp_GetNoOfDigit((U32)u8IdleMajorValue));
                    str += (MApp_GetNoOfDigit((U32)u8IdleMajorValue));
                    if (u8IdleMinorValue == 0)
                    {
                        if (u8IdleDigitCount  == 1)
                        {
                            *str ++ = CHAR_DOT;
                            *str ++ = CHAR_0;
                            *str ++ = 0;
                        }
                        else if (u8IdleDigitCount  == 2)
                        {
                            *str ++ = CHAR_DOT;
                            *str ++ = CHAR_0;
                            *str ++ = CHAR_0;
                            *str ++ = 0;
                        }
                        else
                        {
                            *str ++ = CHAR_DOT;
                            *str ++ = 0;
                        }
                    }
                    else if (u8IdleMinorValue < 10 && u8IdleDigitCount  == 2)
                    {
                        *str ++ = CHAR_DOT;
                        *str ++ = CHAR_0;
                        MApp_UlongToU16String((U32)u8IdleMinorValue, str, (S8)MApp_GetNoOfDigit((U32)u8IdleMinorValue));
                    }
                    else
                    {
                        *str ++ = CHAR_DOT;
                        MApp_UlongToU16String((U32)u8IdleMinorValue, str, (S8)MApp_GetNoOfDigit((U32)u8IdleMinorValue));
                    }
                    return CHAR_BUFFER;
                }

          #else
                #if ENABLE_CUS_KEY_DASH
                if(g_bPressDashKey)
                {
                    return NULL; //for empty string
                }
                else
                #endif
                {
                    return MApp_ZUI_API_GetU16String(u16IdleInputValue);
                }
          #endif

          case HWND_TENKEY_CHANNEL_TITLE:
            #if ENABLE_CUS_KEY_DASH
            if(g_bPressDashKey)
            {
                CHAR_BUFFER[0] = '-';
                CHAR_BUFFER[1] = '-';
                if(u8MaxDigiKeyNum == 3)
                {
                    CHAR_BUFFER[2] = '-';
                    CHAR_BUFFER[3] = 0;
                }
                else if(u8MaxDigiKeyNum == 1)
                {
                    CHAR_BUFFER[1] = 0;
                }
                else
                {
                    CHAR_BUFFER[2] = 0;
                }
                return CHAR_BUFFER;
            }
            else
            {
                return NULL; //for empty string
            }
            #endif
            break;
    }

    //if (u16TempID != Empty)
    //    return MApp_ZUI_API_GetString(u16TempID);

    return NULL; //for empty string
}



/////////////////////////////////////////////////////////
// Customize Window Procedures

#undef MAPP_ZUI_ACTTENKEY_C
