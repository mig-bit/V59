/*
++++++++++++++++++++++++++++++++++???????????????++++++++++++++++++++++++++++++++++++++++++??????????????????????++++++++++++++++++++++++++++++++++++++++=++????
++++++++++++++++++++++++++++++++++IIIIIIIIIIIIII????????????????????????????????????????????IIIIIIIIIIIIIIIII?III??????????????????????????????????????????IIIII
++++++++++++++++++++++++++++++++++IIIIIIIIIIII????????????????????????????????????????????????IIIIIIIIIIIIIII?III??????????????????????????????????????????IIIII
++++++=+IIIIIIIIIII+++++++++++++++?$$$$$$$$$77II??????????I???????????????????????????????????IIIIIIIIIIIIIII?III??????????????????????????????????????????IIIII
+++++++DMMMMMMMMMMMZI++++++++++++=NMMMMMMMMMMMZ$?I77$$$$$$I?????????????????????????????????????IIIIIIIIIIIII?III??????????????????????????????????????????IIIII
++++++=8MMMMMMMMMMMMD7=+++++++++IMMMMMMMMMMMMM8OZZ$7I???????????????????????????????????????????IIIIIIIIIIIII?III??????????????????????????????????????????IIIII
++++++=8MMMMMMMMMMMMM8++++++++++DMMMMMMMMMMMMMD8$I?????????????????III???????????????????????????IIIIIIIIIIII?III??????????????????????????????????????????IIIII
+++=+?=8MMMMMMMMMMMMMMZZ++++++?DMMMMMMMMMMMMMMZZ???????????????IIIIIIIIIII????????????????????????IIIIIIIIIII?III??????????????????????????????????????????IIIII
+++++I=DMMMMMMMMMMMMMMMN?=++++8MMMMMMMMMMMMMMMZ$??????????????IIIIIIIIIIIIII??????????????????????IIIIIIIIIII?III??????????????????????????????????????????IIIII
+++++I+8MMMMMMMMMMMMMMMMD?=+IDMMMMMMMMMMMMMMMM$$?????????????IIIIIIIIIIIIIIII????????????????????IIIIIIIIIIII?III??????????????????????????????????????????IIIII
++++?I+8MMMMMMMMMMMMMMMMMOI~OMMMMMMMMMMMMMMMMM$$?????????????IIIIIIIIIIIIIIIII????????????IIIIIIIIIIIIIIIIIII?III??????????????????????????????????????????IIIII
++++II+8MMMMMMMMMMMNNMMNMND8MMNNMMNNMMMMMMMMMMZ$????????????IZZ8888OZ7IIIIIIIIIIIIIIIIIIIIIIZD7IIIIIIIIIIIIII?IIIIIIIIIII???????????????????????IIIIIIIIIIIIIIII
++++II+8MMMMMMMMMMII????????OOOOOOZ8MMMMMMMMMMZ$??????????ZDMMMMMDDDNND87IIIIIIIIIIIIIII?Z8MMDIIIIIIIIIIIIIII?IIIIIIIIIII???????????????????????IIIIIIIIIIIIIIII
+++III+8MMMMMMMMMMI++++++7$ZZZZZZZOOMMMMMMMMMMZ$??????IINMMMMMMD+IIII7I7DMMIIIIIIII?I8NMMMMMMD?IIIIIIIIIIIIII?IIIIIIIIIII???????????????????????IIIIIIIIIIIIIIII
+++III+8MMMMMMMMMMI+++++I$ZZZZZZZZ$ZMMMMMMMMMMZ$??????IMMMMMMMMMI??????IIO87IIIIII?DMMMMMMMMMD?IIIIIIIIIIIIII?IIIIIIIIIII???????????????????????IIIIIIIIIIIIIIII
++?III+8MMMMMMMMMMI++=$$ZZZZZZZZZIIZMMMMMMMMMMZ$??????MMMMMMMMMMMZ??????????????IIIMMMMMMMMMMD$ZZZZIIIIIIIIII+Z8DDNMMMDDDOO$I?????????????IIIII$ZZZ7IIII7O8887II
+?IIII+8MMMMMMMMMMI++7ZZZZZZZZZZI+IZMMMMMMMMMMZ$????7ZMMMMMMMMMMMM$????????????OMMMMMMMMMMMMMMMMMMNIIIIIIIII8MMMD888DMMMMMMMND$?????????8MMMMMMMMMMOII78MMMMM8?I
+?IIII+8MMMMMMMMMMI?7ZZZZZZZZZZ?++IZMMMMMMMMMMZ$????7ZMMMMMMMMMMMMMM8??????????+++?MMMMMMMMMM8IIIIIIIIIIIZMMM77IIIIIII8MMMMMMMMND?II????8MMMMMMMMMMOODNZII7Z8I7I
?IIIII+8MMMMMMMMMMZZZZZZZZZZZZI+++IZMMMMMMMMMMZ$??????NMMMMMMMMMMMMMMDII??????????IMMMMMMMMMM8IIIIIIIIIIIO8ZI?IIIIIIIIZDMMMMMMMMMD??????8MMMMMMMMMMN8D7IIIIIIIII
?IIIII+8MMMMMMMMMNZZZZZZZZZZZZ++++?ZMMMMMMMMMMZ$??????ZMMMMMMMMMMMMMMMMN7?????????IMMMMMMMMMM8IIIIIIIIIIIIIII?IIIIIIIIZDMMMMMMMMMMI?????8MMMMMMMMMM8IIIIIIIIIIII
?IIIII+8MMMMMMMMN8ZZZZZZZZZZZ?++++?ZMMMMMMMMMMZ$??????I8MMMMMMMMMMMMMMMM8?????????IMMMMMMMMMMO?IIIIIIIIIIIII7I7777777IODMMMMMMMMMMI?????8MMMMMMMMMMOIIIIIIIIIIII
?IIIII+8MMMMMMMNZZZZZZZZZZZZ7+++++?ZMMMMMMMMMMZ$????????8MMMMMMMMMMMMMMMMDD???????IMMMMMMMMMMO??IIIIIIIII7DMMMMMMMDDMDDNMMMMMMMMMMI?????8MMMMMMMMMMOIIIIIIIIIIII
?IIIII+8MMMMMMNZZZZZZZZZZZZ$++++++?ZMMMMMMMMMMZ$I????????7NMMMMMMMMMMMMMMMMDI?????IMMMMMMMMMMO????IIIIIZ8MMMMMMMM7III7ONMMMMMMMMMMI?????8MMMMMMMMMMOIIIIIIIIIIII
?IIIII+8MMMMMMNOZZZZZZZZZZZ7++++++?ZMMMMMMMMMMZ$III??????+IMMMMMMMMMMMMMMMMN$+????IMMMMMMMMMMO????IIII?NMMMMMMMMN?IIIIZDMMMMMMMMMMI?????8MMMMMMMMMMOIIIIIIIIIIII
?IIIII+8MMMMMMMMMNOZZZZZZZZ?++++++?ZMMMMMMMMMMZ$IIII????????ZMMMMMMMMMMMMMMMO?????IMMMMMMMMMMZ?????III$MMMMMMMMMN?IIIIZDMMMMMMMMMMI?????8MMMMMMMMMMOIIIIIIIIIIII
?IIIII+8MMMMMMMMMM?$ZZZZZZ$+++++++?ZMMMMMMMMMMZ$IIIIIIIIII???ZMMMMMMMMMMMMMMDZ????IMMMMMMMMMMZ?????IIIZMMMMMMMMMN?IIIIZDMMMMMMMMMMI?????8MMMMMMMMMMOIIIIIIIIIIII
?IIIII=DMMMMMMMMMM?++7ZZZ7?+++++++IZMMMMMMMMMMZ$IIIIIIIIIIIIII7OMMMMMMMMMMMM8?????IMMMMMMMMMMZ????IIIIZMMMMMMMMMN?IIIIZDMMMMMMMMMMI?????8MMMMMMMMMMOIIIIIIIIIIII
?II?II+8MMMMMMMMMMI++?ZOZ7?+++++++?ZMMMMMMMMMMZ$IIII7OZIIIIIIIII8MMMMMMMMMMMZ?????IMMMMMMMMMM$???OOD7IIMMMMMMMMMN?IIIIZDMMMMMMMMMMI?????8MMMMMMMMMMOIIIIIIIIIIII
?IIIMMMMMMMMMMMMMMNNNN8O$I++++?NMNNMMMMMMMMMMMMMMD8I77NM8IIIIIIIIOMMMMMMMMMO??????+8MMMMMMMMMZ??$MM$?IIZMMMMMMMMM?IIIZNMMMMMMMMMMMZ?????8MMMMMMMMMMOIIIIIIIIIIII
?II?MMMMMMMMMMMMMMMMMM88??++++?MMMMMMMMMMMMMMMMMMD8II7IDMMOIIIIIIOMMMMMMMDOIIII??I??NMMMMMMMMMO8MZ$?IIIIZMMMMMMMMZIZ8MDMMMMMMMMMMMO?????8MMMMMMMMMMOIIIIIIIIIIII
?II?DDDDDDDDDDDDDDD8DDZ$++++++?D8D8DDDDDDDDDDDDDDOZIIIIII?7ODMMMMMMMNDZ7?IIIIIII??????ZDMMMMN8Z7??I?IIIIIIIZ8MMMMN8Z??7$ZZZZZZZZZZZ+????IZZZZZZZZZZ7IIIIIIIIIIII
?IIIII++++++++++++++++=+++++++++++IIIIIIIIIIIIIIIIII???I?????I77ZZ77IIIIIIIIIIIII????I???II??????????IIIIIIII?777IIIIIIII???????????????????????IIIIIIIIIIIIIIII
*/
////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef MSAPI_PVR_H
#define MSAPI_PVR_H
 #if ENABLE_PVR
#include "datatype.h"
#include "msAPI_DTVSystem.h"
#include "apiDMX.h"
#include "msAPI_Player.h"
#include "MApp_Subtitle.h"      //app <--better not be here
#include "msAPI_FSCommon.h"
/*definition ====================================================================================*/
//#####################very special definition for PARDAI version@MSTARSEMI.COM####################
#define PVR_UTOPIA
#define PVR_UTOPIA_T3    //there are many different between T2 & T3
#if OBA2
#define MIPS_CHAKRA    1
#endif
//#####################very special definition for PARDAI version@MSTARSEMI.COM####################

#ifndef S3PLUS
#define PVR_MAX_RECORD_PATH         3
#else
#define PVR_MAX_RECORD_PATH         1
#endif
#define PVR_MAX_PLAYBACK_PATH       1

#define PVR_RECORD_TIME_INFINITE    (U16)(0xffff)
#define PVR_RECORD_LENGTH_INFINITE  (U32)(0xffffffff)

#ifndef S3PLUS
#define PVR_TS_PACKET_SIZE              192
#define PVR_TS_PACKET_HEADER_SIZE         8
#else
#define PVR_TS_PACKET_SIZE              188
#define PVR_TS_PACKET_HEADER_SIZE         4
#endif

#if (!defined(PVR_8051) && !defined(PVR_UTOPIA)) //Chakra1
#define ENABLE_PVR_AESDMA           0
#else
#define ENABLE_PVR_AESDMA           0
#endif

#ifdef MIPS_CHAKRA
    #define PvrGetWriteMetadataBufAddr()    _PA2VA(PVR_WRITE_METADATA_BUFFER_ADR)
    #define PvrGetReadMetadataBufAddr()     _PA2VA(PVR_READ_METADATA_BUFFER_ADR)
#else
    #define PvrGetWriteMetadataBufAddr()    PVR_WRITE_METADATA_BUFFER_ADR
    #define PvrGetReadMetadataBufAddr()     PVR_READ_METADATA_BUFFER_ADR
#endif

//__________________________________meta_data_of_pvr_read_write____________________________________
#define META_DATA_SIZE                  (U32)(3072)                         //3.0K , don't change this value

#ifdef S3PLUS
#define PVR_MAX_PROGRAMME_PER_FILE  (U32)(1  )
#else
#define PVR_MAX_PROGRAMME_PER_FILE  (U32)(128)
#endif

#if (ENABLE_PVR_AESDMA)
#define TOTAL_META_DATA_SIZEKB  (U32)(PVR_MAX_PROGRAMME_PER_FILE*(META_DATA_SIZE/1024))
#endif

#ifdef PVR_UTOPIA
    #define MSAPI_DMX_INVALID_FLT_TYPE  (MS_U8)0xff
    #define MSAPI_DMX_BYPASS_PID        (MS_U16)0x1fff
    #define PVR_FILE_IN_SIZE          0x48000 //288K for 192
    //#define PVR_FILE_IN_SIZE        0x5E000 //376K for 188
#endif

#ifdef MIPS_CHAKRA
    #define PvrGetWriteSdramAdr() _PA2VA(((PVR_WRITE_SDRAM_MEMORY_TYPE&MIU1)?PVR_WRITE_SDRAM_ADR|MIU_INTERVAL:PVR_WRITE_SDRAM_ADR))
    #define PvrGetReadSdramAdr()  _PA2VA(((PVR_READ_SDRAM_MEMORY_TYPE&MIU1)?PVR_READ_SDRAM_ADR|MIU_INTERVAL:PVR_READ_SDRAM_ADR))

#else
    #define PvrGetWriteSdramAdr() PVR_WRITE_SDRAM_ADR
    #define PvrGetReadSdramAdr()  PVR_READ_SDRAM_ADR
#endif
/*enumeration ===================================================================================*/
typedef enum
{
    E_FILE_MODE_NORMAL = 1,
    E_FILE_MODE_RING
} enPvrFileMode;

typedef enum
{
    E_DECRYPT,
    E_ENCRYPT
} enPvrAESDMAMode;

typedef enum
{
    E_PLAYBACK_PATH_DIRECTION_FORWARD = 1,
    E_PLAYBACK_PATH_DIRECTION_JUMPFORWARD,
    E_PLAYBACK_PATH_DIRECTION_JUMPBACKWARD,
    E_PLAYBACK_PATH_DIRECTION_FASTFORWARD,
    E_PLAYBACK_PATH_DIRECTION_FASTBACKWARD
} enPvrPlaybackPathDirection;

typedef enum
{
    E_JUMP_BUFFER_CONTINUOUS = 1,
    E_JUMP_BUFFER_RESET
} enPvrJumpBufferMode;

typedef enum
{
    E_PVR_API_STATUS_OK                             = 0,  //original
    E_PVR_API_STATUS_ERROR                          = 1,

    E_PVR_API_STATUS_NO_DISK_FOR_WRITE              = 10, //file sys
    E_PVR_API_STATUS_NO_DISK_FOR_READ               = 11,
    E_PVR_API_STATUS_NO_DISK_SPACE                  = 12,
    E_PVR_API_STATUS_DISK_SPEED_SLOW                = 13,
    E_PVR_API_STATUS_TIMESHIFT_BUFFER_NOT_ENOUGH    = 14,
    E_PVR_API_STATUS_FILE_SYS_INIT_FAIL             = 15,
    E_PVR_API_STATUS_FILE_SEEK_FAIL                 = 16,
    E_PVR_API_STATUS_FILE_WRITE_ERROR               = 17,
    E_PVR_API_STATUS_FILE_READ_ERROR                = 18,
    E_PVR_API_STATUS_FILE_BUMP_START                = 19,
    E_PVR_API_STATUS_FILE_BUMP_END                  = 20,
    E_PVR_API_STATUS_FILE_STILL_HAVE_DATA_WAIT      = 21,

    E_PVR_API_STATUS_RECORD_NO_FILTER               = 40, //demux
    E_PVR_API_STATUS_PLAYBACK_NO_FILTER             = 41,
    E_PVR_API_STATUS_INVALID_PID                    = 42,
    E_PVR_API_STATUS_RECORD_NO_INPUT                = 43,
    E_PVR_API_STATUS_PLAYBACK_NO_OUTPUT             = 44,
    E_PVR_API_STATUS_RECORD_BUFFER_ERROR            = 45,
    E_PVR_API_STATUS_PLAYBACK_BUFFER_ERROR          = 46,
    E_PVR_API_STATUS_RECORD_BUFFER_OVERRUN          = 47,
    E_PVR_API_STATUS_PLAYBACK_BUFFER_UNDERRUN       = 48,
    E_PVR_API_STATUS_PLAYBACK_BUFFER_FULL           = 49,
    E_PVR_API_STATUS_RECORD_FILE_OVER_SIZE          = 50,
#if ENABLE_CI_PLUS
    E_PVR_API_STATUS_PROTECTION                     = 51,
#endif
} enPvrApiStatus;

/*data structure ================================================================================*/
//<<record path>>================================================================================//
typedef struct msAPI_PVR_RecordPath
{
    //pvr ===================================================================//
    BOOLEAN bInUse;                                         //api only      --|GROUP0-1 : On/Off
    U8 u8LogicalProgrammeNumber;                            //api only      -//

    //demux =================================================================//
    U8  u8FilterID[MSAPI_DMX_RECORD_FILTER_NUMBER];         //api only      --|GROUP1-1 : Filter
    U16 u16PID[MSAPI_DMX_RECORD_FILTER_NUMBER];             //from ap       -||
    MSAPI_DMX_FILTER_TYPE  enFilterType[MSAPI_DMX_RECORD_FILTER_NUMBER];     //
    BOOLEAN bRecordAll;                                     //from ap       -//

    U32 u32BufferStart;                                     //from ap       --|
    U32 u32BufferLength;                                    //from ap        ||GROUP1-2 : Dram Buffer
    U32 u32BufferReadPointer;                               //api only       ||
    U32 u32BufferWritePointer;                              //api only      -//

    //file system ===========================================================//
    U8  hWriteFile;                                         //api only      --|
    U32 u32FilePositionKB;                                  //api only       ||GROUP2-1 : Opened File
    U32 u32FilePosRmnBytes;                                 //api only       make File position counts as bytes, it stores the remainder of KB
    U32 u32FileLastPosKB;                                   //api only       ||
    U32 u32FileSizeKB;                                      //api only      -//

    U32 u32FileGapSizeKB;                                   //api only      --|
    U32 u32FileLimitedSizeKB;                               //api only       ||
    U32 u32FileValidPosStrKB;                               //api only       ||
    U32 u32FileValidPosEndKB;                               //api only       ||GROUP2-2 : Only for Timeshift
    U32 u32FileValidDistanceKB;                             //api only       ||
    U32 u32FileValidPeriod;     //in 1/10   SECOND          //api only      -//

    U32 u32FileWriteTime;       //in 1/1000 SECOND          //api only      --|GROUP2-3 : Only for Debug
    U32 u32FileWriteSizeKB;                                 //api only      -//

    //media format ==========================================================//
    enPlayVideoType enVideoType;                            //from ap        ]]GROUP3-1 : Video

    enPlayAudioType enAudioType;                            //from ap       --|GROUP3-2 : Audio
    enPlayAudioType enAdAudioType;                          //from ap        ||
    U8 u8audioLangTotal;                                    //from ap        ||
    U8 u8audioLangSel;                                      //from ap        ||
    AUD_INFO PVRAudioInfo[MAX_AUD_LANG_NUM];                //from ap       -//

    U16 u8DVBSubtitleServiceNum;                            //from ap       --|GROUP3-3 : Subtitle
    U16 u8SubtitleMenuNum;                                  //from ap        ||
    U8 u8SubtitleMenuSelectedIdx;                           //from ap        ||
    U8 u8TTXSubtitleServiceNum;                             //from ap        ||
    U8 u8EnableSubtitle;                                    //from ap        ||
    U8 u8EnableTTXSubtitle;                                 //from ap        ||
    DVB_SUBTITLE_SERVICE PVRDVBSubtitleServices[MAX_SUBTITLE_SERVICE_NUM];   //
    SUBTITLE_MENU        PVRSubtitleMenu[MAX_SUBTITLE_SERVICE_NUM];          //

    //system ================================================================//
    U32 u32RecordedTime;        //in 1/1000 SECOND          //api only      --|GROUP4-1 : Recorded Time
    U32 u32RecordedPeriod;      //in 1/10   SECOND          //api only      -//

    U32 u32PausedTime;          //in 1/1000 SECOND          //api only      --|GROUP4-2 : Paused Time
    U32 u32PausedPeriod;        //in 1/10   SECOND          //api only      -//

    U32 u32RecordedKBytes;      //in KBYTE                  //api only      --|
    U16 u16RecordedMaxRate;     //in KBYTE                  //api only       ||
    U16 u16RecordedMinRate;     //in KBYTE                  //api only       ||GROUP4-5 : Recorded Rate
    U16 u16RecordedLstRate;     //in KBYTE                  //api only       ||
    U16 u16RecordedAvgRate;     //in KBYTE                  //api only       ||
    U16 u16RecordedErrCount1;   //in KBYTE                  //api only       ||
    U16 u16RecordedErrCount2;   //in KBYTE                  //api only       ||
    U16 u16RecordedErrCount3;   //in KBYTE                  //api only      -//

    U32 u32RecordedStaCheckTime;//in 1/1000 SECOND          //api only       ]]GROUP4-6 : Period Check

    //############################ ************************* ############################
    BOOLEAN bLinkPlayback;                                  //from ap        ]]GROUP4-7 : Linkage
    //############################ ************************* ############################

} _msAPI_PVR_RecordPath;

//<<playback path>>==============================================================================//
typedef struct msAPI_PVR_PlaybackPath
{
    // pvr ==================================================================//
    BOOLEAN bInUse;                                         //api only      --|
    enPvrPlaybackPathDirection enDirection;                 //api only       ||GROUP0-1 : On/Off
    U8 u8LogicalProgrammeNumber;                            //api only      -//

    //demux =================================================================//
    U8  u8FilterID[MSAPI_DMX_RECORD_FILTER_NUMBER];         //api only      --|GROUP1-1 : Filter
    U16 u16PID[MSAPI_DMX_RECORD_FILTER_NUMBER];             //from ap       -||
    MSAPI_DMX_FILTER_TYPE  enFilterType[MSAPI_DMX_RECORD_FILTER_NUMBER];     //

    U32 u32BufferStart;                                     //from ap       --|
    U32 u32BufferLength;                                    //from ap        ||GROUP1-2 : Dram Buffer
    U32 u32BufferReadPointer;                               //api only       ||
    U32 u32BufferWritePointer;                              //api only      -//

	#ifdef S3PLUS
    U32 u32CurTimerDelay;                                   //api only      --|GROUP1-3 : Delay Control
    U32 u32PrvTimerDelay;                                   //api only      -//
    #endif

    U32 u32STC;                                             //api only       ]]GROUP1-4 : TS Clock

    //file system ===========================================================//
    U8  hReadFile;                                          //api only      --|
    U32 u32FilePositionKB;                                  //api only       ||GROUP2-1 : Opened File
    U32 u32FileLastPosKB;                                   //api only       ||
    U32 u32FileSizeKB;                                      //api only      -//

    U32 u32FileGapSizeKB;                                   //from ap       --|
    U32 u32FileLimitedSizeKB;                               //from ap        ||
    U32 u32FileValidPosStrKB;                               //from ap        ||
    U32 u32FileValidPosEndKB;                               //from ap        ||GROUP2-2 : Only for Timeshift
    U32 u32FileValidDistanceKB;                             //from ap        ||
    U32 u32FileValidPeriod;     //in 1/10   SECOND          //from ap       -//

    U32 u32FileReadTime;        //in 1/10   SECOND          //api only      --|GROUP2-3 : Only for Debug
    U8  u8FileReadCount;                                    //api only      -//

    U16 u16FileReadAccumulatorKB;                           //api only       ]]GROUP2-4 : For Fast Forward

    U8  u8NumOfIFrameFound;                                 //api only       ]]GROUP2-5 : For Fast Backward

    BOOLEAN bABLoopSwitch;                                  //from ap       --|GROUP2-6 : For AB Loop
    U32 u32FilePosAKB;                                      //from ap       -//

    //media format ==========================================================//
    enPlayVideoType enVideoType;                            //from ap        ]]GROUP3-1 : Video

    enPlayAudioType enAudioType;                            //from ap       --|GROUP3-2 : Audio
    enPlayAudioType enAdAudioType;                          //from ap        //

    //system ================================================================//
    U32 u32PlayedTime;          //in 1/1000 SECOND          //api only      --|GROUP4-1 : Played Time
    U32 u32PlayedPeriod;        //in 1/10   SECOND          //api only      -//

    U32 u32PausedTime;          //in 1/1000 SECOND          //api only      --|GROUP4-2 : Paused Time
    U32 u32PausedPeriod;        //in 1/10   SECOND          //api only      -//

    S32 s32JumpPeriod;          //in 1/10   SECOND          //api only       ]]GROUP4-3 : Jump Time

    U32 u32GapTime;             //in 1/1000 SECOND          //api only      --|GROUP4-4 : Gap Time
    U32 u32GapLengthAccKB;                                  //api only       ||
    U32 u32GapLengthExtKB;                                  //api only      -//

    U32 u32PlayedKBytes;        //in KBYTE                  //api only      --|
    U16 u16PlayedMaxRate;       //in KBYTE                  //api only       ||
    U16 u16PlayedMinRate;       //in KBYTE                  //api only       ||GROUP4-5 : Played Rate
    U16 u16PlayedLstRate;       //in KBYTE                  //api only       ||
    U16 u16PlayedAvgRate;       //in KBYTE                  //api only       ||
    U16 u16PlayedErrCount1;     //in KBYTE                  //api only       ||
    U16 u16PlayedErrCount2;     //in KBYTE                  //api only       ||
    U16 u16PlayedErrCount3;     //in KBYTE                  //api only      -//

    U32 u32PlayedStaCheckTime;  //in 1/1000 SECOND          //api only      --|GROUP4-6 : Period Check
#ifdef S3PLUS
    U32 u32PlayedTunCheckTime;  //in 1/1000 SECOND          //api only      -//
    enPlaySpeed enPlaySpeed;
#endif

    //############################ ************************* ############################
    BOOLEAN bLinkRecord;                                    //from ap        ]]GROUP4-7 : Linkage
    _msAPI_PVR_RecordPath * pstPvrRecordPath; //<---Linking to Record Path in Playback Mode
    //############################ ************************* ############################
} _msAPI_PVR_PlaybackPath;

/*function ======================================================================================*/
#ifdef MSAPI_PVR_C
#define INTERFACE
#else
#define INTERFACE extern
#endif

INTERFACE U32 u32RecordLastWriteDataSize;
INTERFACE U32 u32RecordReWriteDataSize;

INTERFACE void msAPI_PVR_InitMetadataBuff(void);

INTERFACE enPvrApiStatus msAPI_PVR_Initial(void);

INTERFACE _msAPI_PVR_RecordPath *   msAPI_PVR_RecordPathOpen(U16 *pu16RecordPathName, enPvrFileMode enFileMode);
INTERFACE enPvrApiStatus msAPI_PVR_RecordPathSet(_msAPI_PVR_RecordPath * pstPvrRecordPath);
INTERFACE enPvrApiStatus msAPI_PVR_RecordPathAddPID(_msAPI_PVR_RecordPath * pstPvrRecordPath, U16 u16PID, MSAPI_DMX_FILTER_TYPE enFltType);
INTERFACE enPvrApiStatus msAPI_PVR_RecordPathStart(_msAPI_PVR_RecordPath * pstPvrRecordPath);
INTERFACE enPvrApiStatus msAPI_PVR_RecordPathInput(_msAPI_PVR_RecordPath * pstPvrRecordPath);
INTERFACE enPvrApiStatus msAPI_PVR_RecordPathGatherStatistics(_msAPI_PVR_RecordPath * pstPvrRecordPath);
INTERFACE enPvrApiStatus msAPI_PVR_RecordPathStop(_msAPI_PVR_RecordPath * pstPvrRecordPath);
INTERFACE enPvrApiStatus msAPI_PVR_RecordPathClose(_msAPI_PVR_RecordPath * pstPvrRecordPath);

INTERFACE _msAPI_PVR_PlaybackPath * msAPI_PVR_PlaybackPathOpen(U16 *pu16PlaybackPathName);
INTERFACE enPvrApiStatus msAPI_PVR_PlaybackPathSet(_msAPI_PVR_PlaybackPath * pstPvrPlaybackPath);
INTERFACE enPvrApiStatus msAPI_PVR_PlaybackPathAddPID(_msAPI_PVR_PlaybackPath * pstPvrPlaybackPath, U16 u16PID, MSAPI_DMX_FILTER_TYPE enFltType);
INTERFACE enPvrApiStatus msAPI_PVR_PlaybackPathDelPID(_msAPI_PVR_PlaybackPath * pstPvrPlaybackPath, U16 u16PID, MSAPI_DMX_FILTER_TYPE enFltType);
INTERFACE enPvrApiStatus msAPI_PVR_PlaybackPathStart(_msAPI_PVR_PlaybackPath * pstPvrPlaybackPath);
INTERFACE enPvrApiStatus msAPI_PVR_PlaybackPathForwardOutput(_msAPI_PVR_PlaybackPath * pstPvrPlaybackPath);
INTERFACE enPvrApiStatus msAPI_PVR_PlaybackPathBackwardOutput(_msAPI_PVR_PlaybackPath * pstPvrPlaybackPath, U16 u16JumpSecond);
INTERFACE enPvrApiStatus msAPI_PVR_PlaybackPathGatherStatistics(_msAPI_PVR_PlaybackPath * pstPvrPlaybackPath);
//#ifdef S3PLUS
//INTERFACE enPvrApiStatus msAPI_PVR_PlaybackPathTuneRate(_msAPI_PVR_PlaybackPath * pstPvrPlaybackPath, U16 u16TargetRate);
//#endif
INTERFACE enPvrApiStatus msAPI_PVR_PlaybackPathJumpForward(_msAPI_PVR_PlaybackPath * pstPvrPlaybackPath, U16 u16JumpSecond, enPvrJumpBufferMode enBufferMode);
INTERFACE enPvrApiStatus msAPI_PVR_PlaybackPathJumpBackward(_msAPI_PVR_PlaybackPath * pstPvrPlaybackPath, U16 u16JumpSecond, enPvrJumpBufferMode enBufferMode);
INTERFACE enPvrApiStatus msAPI_PVR_PlaybackPathFastForward(_msAPI_PVR_PlaybackPath * pstPvrPlaybackPath);
INTERFACE enPvrApiStatus msAPI_PVR_PlaybackPathFastBackward(_msAPI_PVR_PlaybackPath * pstPvrPlaybackPath);
INTERFACE enPvrApiStatus msAPI_PVR_PlaybackPathPause(_msAPI_PVR_PlaybackPath * pstPvrPlaybackPath);
INTERFACE enPvrApiStatus msAPI_PVR_PlaybackPathResume(_msAPI_PVR_PlaybackPath * pstPvrPlaybackPath);
INTERFACE enPvrApiStatus msAPI_PVR_PlaybackPathStop(_msAPI_PVR_PlaybackPath * pstPvrPlaybackPath);
INTERFACE enPvrApiStatus msAPI_PVR_PlaybackPathClose(_msAPI_PVR_PlaybackPath * pstPvrPlaybackPath);
INTERFACE enPvrApiStatus msAPI_PVR_RecordChangeFile(U16 *pu16RecordFileName, _msAPI_PVR_RecordPath * pstPvrRecordPath);
INTERFACE BOOLEAN  msAPI_PVR_IsRecordSpaceEnough(void);
INTERFACE void msAPI_PVR_PlaybackPathWaitAVFifoClean(void);
#ifdef PVR_UTOPIA
    INTERFACE void msAPI_PVR_ClearBitStreamBuff(_msAPI_PVR_PlaybackPath * pstPvrPlaybackPath);
#endif
#if (PVR_TS_PACKET_SIZE == 192)
INTERFACE U32 msAPI_PVR_PlaybackGetTotalTimeByTimeStamp(U8 u8FileHandle);
#endif
INTERFACE void msAPI_PVR_RecoreReset(_msAPI_PVR_RecordPath * pstPvrRecordPath);
INTERFACE enPvrApiStatus msAPI_PVR_GetMetaData(U16 *pFileName, _msAPI_PVR_RecordPath *pMetaData);
INTERFACE BOOL msAPI_PVR_IsMStarPVRFile(U16 *pFileName);
INTERFACE enPvrApiStatus msAPI_PVR_AESDMAEncryptDecrypt(U32 u32VirAddress, U32 u32Length, enPvrAESDMAMode eMode);

#undef INTERFACE
#endif// #if ENABLE_PVR
#endif

