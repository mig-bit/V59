////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MAPP_DMP_MAIN_H
#define _MAPP_DMP_MAIN_H

#include "datatype.h"
#include "MApp_Exit.h"
#include "MApp_ZUI_APIcommon.h"
#include "mapp_mplayer.h"

#ifdef MAPP_DMP_MAIN_C
#define INTERFACE
#else
#define INTERFACE extern
#endif

#define DMP_DBG(x)                     x

#define DMP_DRIVE_NUM_PER_PAGE          4
#if ENABLE_CUS_USB_OSD
//6*4
#define DMP_FILE_PAGE_COLUMN_NUM        6
#define DMP_NUM_OF_FILES_PER_PAGE       24
//7*5
#define DMP_FILE_PAGE_COLUMN_NUM_S        7
#define DMP_NUM_OF_FILES_PER_PAGE_S       35
//5*3
#define DMP_FILE_PAGE_COLUMN_NUM_L        5
#define DMP_NUM_OF_FILES_PER_PAGE_L       15
#else
#define DMP_FILE_PAGE_COLUMN_NUM        4
#define DMP_NUM_OF_FILES_PER_PAGE       12
#endif

#ifdef ENABLE_SMC_UI_NEW     /* smc.qxr 20121016 */
#undef DMP_FILE_PAGE_COLUMN_NUM
#undef DMP_NUM_OF_FILES_PER_PAGE
#define DMP_FILE_PAGE_COLUMN_NUM        4 //(MApp_MPlayer_QueryCurrentMediaType()==E_MPLAYER_TYPE_PHOTO?4:1)
#define DMP_NUM_OF_FILES_PER_PAGE       12 //(MApp_MPlayer_QueryCurrentMediaType()==E_MPLAYER_TYPE_PHOTO?12:8)
#if (!BOE_PHOTO_DISPLAY)//minglin0104
#define DMP_MUSIC_FILE_PAGE_COLUMN_NUM       4
#define DMP_MUSIC_NUM_OF_FILES_PER_PAGE      12
#else
#define DMP_MUSIC_FILE_PAGE_COLUMN_NUM        1
#define DMP_MUSIC_NUM_OF_FILES_PER_PAGE       8
#endif
#endif

#define UI_DMP_PLAYLIST_NUMBER          10
#define DMP_VOLUME_TIMER                0
#define DMP_PHOTO_THUMBNAIL             1
#define DMP_MOVIE_THUMBNAIL             0
#if ENABLE_CUS_USB_OSD
#define DMP_MUSIC_THUMBNAIL             0
#else
#define DMP_MUSIC_THUMBNAIL             1
#endif

#define DMP_MUSIC_PREVIEW               1
#define DMP_MOVIE_PREVIEW               1
#define DMP_TEXT_PREVIEW                0

#ifdef __AEONR2__ // for R2
#define DMP_UI_BMPSUBTITLE_EXCLUSIVE 1
#else
#define DMP_UI_BMPSUBTITLE_EXCLUSIVE 0
#endif

typedef enum
{
    DMP_FLAG_NONE                       = 0,
    DMP_FLAG_INITED                     = BIT0,
    DMP_FLAG_DRIVE_CONNECT_OK           = BIT1,
    DMP_FLAG_MEDIA_FILE_PLAYING         = BIT2,
    DMP_FLAG_BGM_MODE                   = BIT3,
    DMP_FLAG_THUMBNAIL_MODE             = BIT4,
    DMP_FLAG_THUMBNAIL_PLAYING          = BIT5,
    DMP_FLAG_MEDIA_FILE_PLAYING_ERROR   = BIT6,
    DMP_FLAG_MOVIE_REPEATAB_MODE        = BIT7,
  #if EN_DMP_SEARCH_ALL
    DMP_FLAG_BROWSER_ALL                = BIT8,
  #endif
} EN_DMP_FLAG;

typedef enum
{
    DMP_UI_STATE_MEDIA_SELECT,      // 0
    DMP_UI_STATE_DRIVE_SELECT,      // 1
    DMP_UI_STATE_FILE_SELECT,       // 2
#if NEW_BGM
    DMP_UI_STATE_BGM_DRIVE_SELECT,
    DMP_UI_STATE_BGM_FILE_SELECT,
#endif
    DMP_UI_STATE_LOADING,           // 3
    DMP_UI_STATE_PLAYING_STAGE,     // 4
} EN_DMP_UI_STATE;

typedef enum
{
    DMP_STATE_INIT,                 // 0
    DMP_STATE_CONNECTING,           // 1
    DMP_STATE_UI,                   // 2
    DMP_STATE_WAIT,                 // 3
    DMP_STATE_CLEAN_UP,             // 4
    DMP_STATE_GOTO_STANDBY,         // 5
    DMP_STATE_GOTO_MENU,            // 6
    DMP_STATE_GOTO_INPUTSOURCE,     // 7
    DMP_STATE_GOTO_PREV_SRC,        // 8
    DMP_STATE_RETURN_FROM_MENU,     // 9
    DMP_STATE_RESET,                // 10
    DMP_STATE_GOTO_CUR_SRC,
  #if CUS_SMC_ENABLE_HOTEL_MODE
    DMP_STATE_GOTO_HOTEL,
  #endif
} EN_DMP_STATE;

typedef struct
{
    U8                  u8Idx;                          //Current drive index
    U8                  u8PageIdx;                      //Current drive page index
    U8                  au8MapTbl[NUM_OF_MAX_DRIVE];    //drive mapping table
} ST_DRV_INFO;

typedef struct
{
    EN_DMP_STATE        enDmpState;     //DMP main state (ZUI related)
    EN_DMP_UI_STATE     enDmpUiState;   //ACTdmp internal state
    EN_DMP_FLAG         enDmpFlag;      //MPlayer status flag
    ST_DRV_INFO         stDrvInfo;      //Drive info
} ST_DMP_VAR;


INTERFACE EN_RET MApp_DMP_Main(void);
INTERFACE void MApp_DMP_Exit(void);
INTERFACE void MApp_DMP_Reset(void);
INTERFACE BOOLEAN MApp_DMP_RecalculateDriveMappingTable(void);
INTERFACE U8 MApp_DMP_GetDriveFromMappingTable(U8 u8Idx);
INTERFACE U8 MApp_DMP_GetCurDrvIdx(void);
INTERFACE U8 MApp_DMP_GetDrvPageIdx(void);
INTERFACE void MApp_DMP_SetCurDrvIdxAndCalPageIdx(U8 u8Idx);
INTERFACE void MApp_DMP_SetDrvPageIdx(U8 u8Idx);
INTERFACE void MApp_DMP_SetDmpFlag(EN_DMP_FLAG flag);
INTERFACE void MApp_DMP_ClearDmpFlag(EN_DMP_FLAG flag);
INTERFACE EN_DMP_FLAG MApp_DMP_GetDmpFlag(void);
//----------------------- DMP state machine APIs ----------------------------
INTERFACE void MApp_DMP_SetDmpUiState(EN_DMP_UI_STATE state);
INTERFACE EN_DMP_UI_STATE MApp_DMP_GetDmpUiState(void);
INTERFACE void MApp_DMP_UiStateTransition(EN_DMP_UI_STATE enState);
INTERFACE BOOLEAN MApp_DMP_GotoMainMenu(void);
#if CUS_SMC_ENABLE_HOTEL_MODE
INTERFACE BOOLEAN MApp_DMP_GotoHotel(void);
#endif
INTERFACE BOOLEAN MApp_DMP_GotoInputSrcMenu(void);
INTERFACE BOOLEAN MApp_DMP_GotoPreSrc(void);
INTERFACE void MApp_DMP_InitDMPStat(void);
INTERFACE void MApp_DMP_SetDMPStat(EN_DMP_STATE stat);
INTERFACE EN_DMP_STATE MApp_DMP_GetDMPStat(void);
INTERFACE BOOLEAN MApp_DMP_IsSuccessorWinVisible(HWND hWnd);
INTERFACE void MApp_DMP_BW_Control(BOOL bOsdOn);
//----------------------- MISC ------------------------------
INTERFACE BOOLEAN MApp_DMP_IsFileTypeByIdx(U16 u16Idx);
INTERFACE U16 MApp_DMP_QueryTotalPlayListNum(void);
//-----------------------------------------------------------
INTERFACE BOOLEAN MApp_DMP_IsOSDVisible(void);
INTERFACE void  MApp_DMP_LoadCOPRO (void);
INTERFACE BOOLEAN MApp_DMP_GotoCurSrc(void);

#undef INTERFACE

#endif  // _MAPP_DMP_MAIN_H

