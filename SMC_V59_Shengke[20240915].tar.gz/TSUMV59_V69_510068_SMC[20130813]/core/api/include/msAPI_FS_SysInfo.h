////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
//
// @file
// @brief
// @author MStarSemi Inc.
//
//-
//-
//
////////////////////////////////////////////////////////////////////////////////

#ifndef MSAPI_FS_SYSINFO_H
#define MSAPI_FS_SYSINFO_H

#include "Board.h"
#include "datatype.h"

#include <stdlib.h>
#include <ctype.h>
#include <string.h>

#include <stdio.h>
#include <string.h>
#include "sysinfo.h"

#include "hwreg.h"


#ifndef FILE_SYSTEM_SMALL
#define FILE_SYSTEM_SMALL 0
#endif


#ifndef FAT_READ_ONLY
#define FAT_READ_ONLY 1
#endif

#ifndef FILE_SYSTEM_WRITE_ENABLE
    #if ENABLE_DMP
#define FILE_SYSTEM_WRITE_ENABLE 1
    #else
    #if ENABLE_SZ_FACTORY_USB_SAVE_DATABASE_FUNCTION
        #define FILE_SYSTEM_WRITE_ENABLE 1
    #else
        #define FILE_SYSTEM_WRITE_ENABLE 1//0
    #endif
#endif
#endif

#ifndef ENABLE_N51FS
    #if ENABLE_DMP
#define ENABLE_N51FS 1
    #else
#define ENABLE_N51FS 1//0
    #endif
#endif

#ifndef FAT_CACHE_PREV_ENABLE
#define FAT_CACHE_PREV_ENABLE 0
#endif

#if 0//ndef ENABLE_DREC
#define ENABLE_DREC 0
#endif

#if ENABLE_PVR
#define FILE_SYSTEM_FOLDER_CREATE_ENABLE    1
#define ENABLE_BULK_FILE_SYSTEM             1
#else
#define FILE_SYSTEM_FOLDER_CREATE_ENABLE    0
#define ENABLE_BULK_FILE_SYSTEM             0
#endif

//#ifndef MPLAYER_USE_FILEENTRY
//  #ifndef FILE_SYSTEM_GET_FILENAME_BY_FILEENTRY_ENABLE
//    #define FILE_SYSTEM_GET_FILENAME_BY_FILEENTRY_ENABLE 0
//  #endif
//#else
    #define FILE_SYSTEM_GET_FILENAME_BY_FILEENTRY_ENABLE 1
//#endif


#if !FILE_SYSTEM_GET_FILENAME_BY_FILEENTRY_ENABLE
  #ifndef FILE_SYSTEM_SEARCH_BY_SHORT_NAME_ENABLE
    #define FILE_SYSTEM_SEARCH_BY_SHORT_NAME_ENABLE 0
  #elif FILE_SYSTEM_SEARCH_BY_SHORT_NAME_ENABLE
    #error "Conflict N51FS Compile Setting!!"
  #endif
#endif


#define FS_KEEP_UNUSED 0

#define GET_DRAM_ADDR(x) (U32)(x)

#ifdef MSAPI_FS_SYSINFO_C
#define INTERFACE
#else
#define INTERFACE extern
#endif

INTERFACE void msAPI_FS_Init(void);

INTERFACE void FS_MEM_Dump(void *ptr,U8 *str);
INTERFACE void *msAPI_FS_Memory_Allocate(U16 u16Number_of_bytes);
INTERFACE void msAPI_FS_Memory_Free(void * pMem);
INTERFACE void msAPI_FS_MIU_Copy(U32 srcaddr, U32 dstaddr, U32 len);
INTERFACE void msAPI_FS_MIU_Copy_I(U32 srcaddr, U32 dstaddr, U32 len);
INTERFACE void FS_RESET_WDT(void);

#if 0
INTERFACE U32 GET_DRAM_ADDR(void *x);
#endif

#undef INTERFACE
#endif
