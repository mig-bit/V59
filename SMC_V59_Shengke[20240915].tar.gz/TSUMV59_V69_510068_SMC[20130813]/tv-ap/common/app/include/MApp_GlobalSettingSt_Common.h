////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef MAPP_GLOBALSETTINGSTCOMMON_H
#define MAPP_GLOBALSETTINGSTCOMMON_H

/********************************************************************************/
/*                              Include files                                   */
/********************************************************************************/
#include "Board.h"
#include "datatype.h"
#include "msAPI_Global.h"
//#include "ZUI_bitmap_EnumIndex.h"
#include "OSDcp_Bitmap_EnumIndex.h"


/********************************************************************************/
/*                                 Macro                                        */
/********************************************************************************/
#define PICTURE_USER_2  0
#define PASSWORD_SIZE   4
#if ENABLE_CUS_UI_SPEC
#define ENABLE_PICTURE_MODE_ENERGY_SAVING   1
#else
#define ENABLE_PICTURE_MODE_ENERGY_SAVING   0
#endif


#ifdef MAPP_MAIN_C
#define INTERFACE
#else
#define INTERFACE extern
#endif

#define MAX_BITMAP  E_ZUI_BMP_MAX
INTERFACE BMPHANDLE Osdcp_bmpHandle[MAX_BITMAP];

#undef INTERFACE

/********************************************************************************/
/*                                 Enum                                         */
/********************************************************************************/
//Antenna
typedef enum
{
    ANT_CATV,
    ANT_AIR,
    ANT_TYPE_NUM
} EN_ANT_TYPE;

typedef enum
{
    TIME_DST_OFF,
    TIME_DST_ON,
    TIME_DST_ITEM_NUM
} EN_TIME_DST_ITEM;

typedef enum _EN_SUBTITLE_DEFAULT_LANGUAGE
{
    SUBTITLE_DEFAULT_LANGUAGE_CZECH,      // 0
    SUBTITLE_DEFAULT_LANGUAGE_DANISH,     // 1
    SUBTITLE_DEFAULT_LANGUAGE_GERMAN,     // 2
    SUBTITLE_DEFAULT_LANGUAGE_ENGLISH,    // 3
    SUBTITLE_DEFAULT_LANGUAGE_SPANISH,    // 4
    SUBTITLE_DEFAULT_LANGUAGE_GREEK,      // 5
    SUBTITLE_DEFAULT_LANGUAGE_FRENCH,     // 6
    SUBTITLE_DEFAULT_LANGUAGE_CROATIAN,   // 7
    SUBTITLE_DEFAULT_LANGUAGE_ITALIAN,    // 8
    SUBTITLE_DEFAULT_LANGUAGE_HUNGARIAN,  // 9
    SUBTITLE_DEFAULT_LANGUAGE_DUTCH,      //10
    SUBTITLE_DEFAULT_LANGUAGE_NORWEGIAN,  //11
    SUBTITLE_DEFAULT_LANGUAGE_POLISH,     //12
    SUBTITLE_DEFAULT_LANGUAGE_PORTUGUESE, //13
    SUBTITLE_DEFAULT_LANGUAGE_RUSSIAN,    //14
    SUBTITLE_DEFAULT_LANGUAGE_ROMANIAN,   //15
    SUBTITLE_DEFAULT_LANGUAGE_SLOVENE,    //16
    SUBTITLE_DEFAULT_LANGUAGE_SERBIAN,    //17
    SUBTITLE_DEFAULT_LANGUAGE_FINNISH,    //18
    SUBTITLE_DEFAULT_LANGUAGE_SWEDISH,    //19
    SUBTITLE_DEFAULT_LANGUAGE_BULGARIAN,  //20
    SUBTITLE_DEFAULT_LANGUAGE_GAEILC,     //21
    SUBTITLE_DEFAULT_LANGUAGE_WELSH,      //22
    SUBTITLE_DEFAULT_LANGUAGE_UNDEFINED,  //23
    SUBTITLE_DEFAULT_LANGUAGE_IRISH,      //24
    SUBTITLE_DEFAULT_LANGUAGE_ARABIC,     //24
    SUBTITLE_DEFAULT_LANGUAGE_CATALAN,    //25
    SUBTITLE_DEFAULT_LANGUAGE_CZECH_2,    //26
    SUBTITLE_DEFAULT_LANGUAGE_GERMAN_2,   //27
    SUBTITLE_DEFAULT_LANGUAGE_GREEK_2,    //28
    SUBTITLE_DEFAULT_LANGUAGE_FRENCH_2,   //29
    SUBTITLE_DEFAULT_LANGUAGE_CROATIAN_2, //30
    SUBTITLE_DEFAULT_LANGUAGE_DUTCH_2,    //31
    SUBTITLE_DEFAULT_LANGUAGE_ROMANIAN_2, //32
    SUBTITLE_DEFAULT_LANGUAGE_GAEILC_2,   //33
    SUBTITLE_DEFAULT_LANGUAGE_WELSH_2,    //34
    SUBTITLE_DEFAULT_LANGUAGE_GAEILC_3,   //35

    SUBTITLE_DEFAULT_LANGUAGE_NUM,        // Language maximum
} EN_SUBTITLE_DEFAULT_LANGUAGE;


#if ENABLE_OFFLINE_SIGNAL_DETECTION
typedef enum
{
    AIS_OFF,
    AIS_SWITCH,
    AIS_DISPLAY,
    AIS_NUMS,
}AISEnumType;
#endif

typedef enum
{
    DATA_INPUT_SOURCE_MIN,
#if ENABLE_DTV
    DATA_INPUT_SOURCE_DTV = DATA_INPUT_SOURCE_MIN,
    DATA_INPUT_SOURCE_ATV,
#else
    DATA_INPUT_SOURCE_ATV = DATA_INPUT_SOURCE_MIN,
#endif
#if (INPUT_AV_VIDEO_COUNT >= 1)
    DATA_INPUT_SOURCE_AV,
#endif
#if (INPUT_AV_VIDEO_COUNT >= 2)
    DATA_INPUT_SOURCE_AV2,
#endif
#if (INPUT_AV_VIDEO_COUNT >= 3)
    DATA_INPUT_SOURCE_AV3,
#endif
#if (INPUT_YPBPR_VIDEO_COUNT >= 1)
    DATA_INPUT_SOURCE_COMPONENT,
#endif
#if (INPUT_YPBPR_VIDEO_COUNT >= 2)
    DATA_INPUT_SOURCE_COMPONENT2,
#endif
    DATA_INPUT_SOURCE_RGB,
#if (INPUT_HDMI_VIDEO_COUNT >= 1)
#ifdef ATSC_SYSTEM
    DATA_INPUT_SOURCE_DVI,
#endif
    DATA_INPUT_SOURCE_HDMI,
#endif
#if (INPUT_HDMI_VIDEO_COUNT >= 2)
#ifdef ATSC_SYSTEM
    DATA_INPUT_SOURCE_DVI2,
#endif
    DATA_INPUT_SOURCE_HDMI2,
#endif
#if (INPUT_HDMI_VIDEO_COUNT >= 3)
#ifdef ATSC_SYSTEM
    DATA_INPUT_SOURCE_DVI3,
#endif
    DATA_INPUT_SOURCE_HDMI3,
#endif
#if (INPUT_HDMI_VIDEO_COUNT >= 4)
    DATA_INPUT_SOURCE_HDMI4,
#endif
#if (INPUT_SCART_VIDEO_COUNT >= 1)
    DATA_INPUT_SOURCE_SCART,
#endif
#if(INPUT_SCART_VIDEO_COUNT >= 2)
    DATA_INPUT_SOURCE_SCART2,
#endif
#if (INPUT_SV_VIDEO_COUNT >= 1)
    DATA_INPUT_SOURCE_SVIDEO,
#endif
#if (INPUT_SV_VIDEO_COUNT >= 2)
    DATA_INPUT_SOURCE_SVIDEO2,
#endif
#if ((ENABLE_DMP) || (DISPLAY_LOGO) || (BLOADER))
    DATA_INPUT_SOURCE_STORAGE,
#endif
    DATA_INPUT_SOURCE_NUM,
    DATA_INPUT_SOURCE_NONE = DATA_INPUT_SOURCE_NUM,
} E_DATA_INPUT_SOURCE;

//CUS_XM ZHIHE 20120818 ADD FOR HOTEL MODE  START
#if CUS_SMC_ENABLE_HOTEL_MODE
typedef enum
{
    HOTEL_MODE_INPUT_SOURCE_MIN,
    HOTEL_MODE_INPUT_SOURCE_ATV = HOTEL_MODE_INPUT_SOURCE_MIN,
#if (INPUT_AV_VIDEO_COUNT >= 1)
    HOTEL_MODE_INPUT_SOURCE_AV,
#endif
#if (INPUT_AV_VIDEO_COUNT >= 2)
    HOTEL_MODE_INPUT_SOURCE_AV2,
#endif
#if (INPUT_AV_VIDEO_COUNT >= 3)
    HOTEL_MODE_INPUT_SOURCE_AV3,
#endif
#if (INPUT_YPBPR_VIDEO_COUNT >= 1)
    HOTEL_MODE_INPUT_SOURCE_COMPONENT,
#endif
#if (INPUT_YPBPR_VIDEO_COUNT >= 2)
    HOTEL_MODE_INPUT_SOURCE_COMPONENT2,
#endif
    HOTEL_MODE_INPUT_SOURCE_RGB,
#if (INPUT_HDMI_VIDEO_COUNT >= 1)
#ifdef ATSC_SYSTEM
    HOTEL_MODE_INPUT_SOURCE_DVI,
#endif
    HOTEL_MODE_INPUT_SOURCE_HDMI,
#endif
#if (INPUT_HDMI_VIDEO_COUNT >= 2)
#ifdef ATSC_SYSTEM
    HOTEL_MODE_INPUT_SOURCE_DVI2,
#endif
    HOTEL_MODE_INPUT_SOURCE_HDMI2,
#endif
#if (INPUT_HDMI_VIDEO_COUNT >= 3)
#ifdef ATSC_SYSTEM
    HOTEL_MODE_INPUT_SOURCE_DVI3,
#endif
    HOTEL_MODE_INPUT_SOURCE_HDMI3,
#endif
#if (INPUT_HDMI_VIDEO_COUNT >= 4)
    HOTEL_MODE_INPUT_SOURCE_HDMI4,
#endif
#if (INPUT_SCART_VIDEO_COUNT >= 1)
    HOTEL_MODE_INPUT_SOURCE_SCART,
#endif
#if(INPUT_SCART_VIDEO_COUNT >= 2)
    HOTEL_MODE_INPUT_SOURCE_SCART2,
#endif
#if (INPUT_SV_VIDEO_COUNT >= 1)
    HOTEL_MODE_INPUT_SOURCE_SVIDEO,
#endif
#if (INPUT_SV_VIDEO_COUNT >= 2)
    HOTEL_MODE_INPUT_SOURCE_SVIDEO2,
#endif
#if (ENABLE_DMP)
  #if( ENABLE_DMP_SWITCH )	
  #ifndef ENABLE_DMP_ONE_PORT		// CUS_XM Sea 20120629:
		HOTEL_MODE_INPUT_SOURCE_DMP1,	
  #endif
		HOTEL_MODE_INPUT_SOURCE_DMP2,
 #endif
#endif
    HOTEL_MODE_INPUT_SOURCE_AUTO,
    HOTEL_MODE_INPUT_SOURCE_NUM,
} E_HOTEL_MODE_INPUT_SOURCE;	
#endif
//CUS_XM ZHIHE 20120818 ADD FOR HOTEL MODE  END


typedef enum
{
    MS_NR_MIN,
    // ------------------------------------
    MS_NR_OFF = MS_NR_MIN,
    MS_NR_LOW,
    MS_NR_MIDDLE,
    MS_NR_HIGH,
    MS_NR_AUTO,
    MS_NR_DEFAULT,
    // ------------------------------------
    MS_NR_NUM,
}EN_MS_NR;

typedef enum
{
    MS_MPEG_NR_MIN,
    // ------------------------------------
    MS_MPEG_NR_OFF = MS_MPEG_NR_MIN,
    MS_MPEG_NR_LOW,
    MS_MPEG_NR_MIDDLE,
    MS_MPEG_NR_HIGH,
    // ------------------------------------
    MS_MPEG_NR_NUM,
} EN_MS_MPEG_NR;

typedef enum
{
    AD_SPEAKER,
    AD_HEADPHONE,
    AD_BOTH,
} EN_SOUND_AD_OUTPUT;

typedef enum
{
    AUD_MODE_LR,
    AUD_MODE_LL,
    AUD_MODE_RR,
    AUD_MODE_NUM
} EN_AUD_MODE;

typedef enum
{
    SURROUND_MODE_MOUNTAIN,       //0
    SURROUND_MODE_CHAMPAIGN,      //1
    SURROUND_MODE_CITY,           //2
    SURROUND_MODE_THEATER,        //3
    SURROUND_MODE_NUM
} EN_SURROUND_TYPE;

//============ TIME ======================================================
typedef enum
{
    EN_ClockMode_Manual,
    EN_ClockMode_Auto,
    EN_ClockMode_Num
} EN_MENU_ClockMode;


typedef enum
{
    EN_Clock_TimeZone_0,  //GMT - 12:00
    EN_Clock_TimeZone_1,  //GMT - 11:30
    EN_Clock_TimeZone_2,  //GMT - 11:00
    EN_Clock_TimeZone_3,  //GMT - 10:30
    EN_Clock_TimeZone_4,  //GMT - 10:00
    EN_Clock_TimeZone_5,  //GMT - 09:30
    EN_Clock_TimeZone_6,  //GMT - 09:00
    EN_Clock_TimeZone_7,  //GMT - 08:30
    EN_Clock_TimeZone_8,  //GMT - 08:00
    EN_Clock_TimeZone_9,  //GMT - 07:30
    EN_Clock_TimeZone_10, //GMT - 07:00
    EN_Clock_TimeZone_11, //GMT - 06:30
    EN_Clock_TimeZone_12, //GMT - 06:00
    EN_Clock_TimeZone_13, //GMT - 05:30
    EN_Clock_TimeZone_14, //GMT - 05:00
    EN_Clock_TimeZone_15, //GMT - 04:30
    EN_Clock_TimeZone_16, //GMT - 04:00
    EN_Clock_TimeZone_17, //GMT - 03:30
    EN_Clock_TimeZone_18, //GMT - 03:00
    EN_Clock_TimeZone_19, //GMT - 02:30
    EN_Clock_TimeZone_20, //GMT - 02:00
    EN_Clock_TimeZone_21, //GMT - 01:30
    EN_Clock_TimeZone_22, //GMT - 01:00
    EN_Clock_TimeZone_23, //GMT - 00:30
    EN_Clock_TimeZone_24, //GMT + 00:00
    EN_Clock_TimeZone_25, //GMT + 00:30
    EN_Clock_TimeZone_26, //GMT + 01:00
    EN_Clock_TimeZone_27, //GMT + 01:30
    EN_Clock_TimeZone_28, //GMT + 02:00
    EN_Clock_TimeZone_29, //GMT + 02:30
    EN_Clock_TimeZone_30, //GMT + 03:00
    EN_Clock_TimeZone_31, //GMT + 03:30
    EN_Clock_TimeZone_32, //GMT + 04:00
    EN_Clock_TimeZone_33, //GMT + 04:30
    EN_Clock_TimeZone_34, //GMT + 05:00
    EN_Clock_TimeZone_35, //GMT + 05:30
    EN_Clock_TimeZone_36, //GMT + 06:00
    EN_Clock_TimeZone_37, //GMT + 06:30
    EN_Clock_TimeZone_38, //GMT + 07:00
    EN_Clock_TimeZone_39, //GMT + 07:30
    EN_Clock_TimeZone_40, //GMT + 08:00, -> Taipei, Beijing, Hong Kong
    EN_Clock_TimeZone_41, //GMT + 08:30
    EN_Clock_TimeZone_42, //GMT + 09:00
    EN_Clock_TimeZone_43, //GMT + 09:30
    EN_Clock_TimeZone_44, //GMT + 10:00
    EN_Clock_TimeZone_45, //GMT + 10:30
    EN_Clock_TimeZone_46, //GMT + 11:00
    EN_Clock_TimeZone_47, //GMT + 11:30
    EN_Clock_TimeZone_48, //GMT + 12:00
    EN_Clock_TimeZone_Num
} EN_MENU_Clock_TimeZone;

typedef enum
{
    EN_Time_OffTimer_Off,
    EN_Time_OffTimer_Once,
    EN_Time_OffTimer_Everyday,
    EN_Time_OffTimer_Mon2Fri,
    EN_Time_OffTimer_Mon2Sat,
    EN_Time_OffTimer_Sat2Sun,
    EN_Time_OffTimer_Sun,
    EN_Time_OffTimer_Num
} EN_MENU_TIME_OffTimer;

typedef enum
{
    EN_Time_OnTimer_Off,
    EN_Time_OnTimer_Once,
    EN_Time_OnTimer_Everyday,
    EN_Time_OnTimer_Mon2Fri,
    EN_Time_OnTimer_Mon2Sat,
    EN_Time_OnTimer_Sat2Sun,
    EN_Time_OnTimer_Sun,
    EN_Time_OnTimer_Num
} EN_MENU_TIME_OnTimer;

typedef enum
{
    EN_Time_OnTimer_Source_DTV,
    EN_Time_OnTimer_Source_ATV,
    EN_Time_OnTimer_Source_RADIO,

    #if NORDIG_FUNC //for Nordig Spec v2.0
    EN_Time_OnTimer_Source_DATA,
    #endif

    #if (INPUT_AV_VIDEO_COUNT >= 1)
    EN_Time_OnTimer_Source_AV,             // VIDEO - CVBS
    #endif
    #if (INPUT_AV_VIDEO_COUNT >= 2)
    EN_Time_OnTimer_Source_AV2,
    #endif
    #if (INPUT_AV_VIDEO_COUNT >= 3)
    EN_Time_OnTimer_Source_AV3,
    #endif

    #if (INPUT_SV_VIDEO_COUNT >= 1)
    EN_Time_OnTimer_Source_SVIDEO,
    #endif
    #if ((INPUT_SCART_USE_SV2 == 0) && (INPUT_SV_VIDEO_COUNT >= 2))
    EN_Time_OnTimer_Source_SVIDEO2,
    #endif

    #if (INPUT_SCART_VIDEO_COUNT >= 1)
    EN_Time_OnTimer_Source_SCART,
    #endif
    #if (INPUT_SCART_VIDEO_COUNT >= 2)
    EN_Time_OnTimer_Source_SCART2,
    #endif

    #if (INPUT_YPBPR_VIDEO_COUNT>=1)
    EN_Time_OnTimer_Source_COMPONENT,      // VIDEO - YPbPr
    #endif
    #if (INPUT_YPBPR_VIDEO_COUNT >= 2)
    EN_Time_OnTimer_Source_COMPONENT2,
    #endif

    EN_Time_OnTimer_Source_RGB,            // PC - VGA

    #if (INPUT_HDMI_VIDEO_COUNT >= 1)
    EN_Time_OnTimer_Source_HDMI,           // HDMI
    #endif
    #if (INPUT_HDMI_VIDEO_COUNT >= 2)
    EN_Time_OnTimer_Source_HDMI2,
    #endif
    #if (INPUT_HDMI_VIDEO_COUNT >= 3)
    EN_Time_OnTimer_Source_HDMI3,
    #endif
    #if (INPUT_HDMI_VIDEO_COUNT >= 4)
    EN_Time_OnTimer_Source_HDMI4,
    #endif

    #if ENABLE_DMP
    #if( ENABLE_DMP_SWITCH )
    EN_Time_OnTimer_Source_MPLAYER1,
  #if ENABLE_USB2_SOURCE  
    EN_Time_OnTimer_Source_MPLAYER2,
  #endif
    #else
    EN_Time_OnTimer_Source_MPLAYER,
    #endif
    #endif //#if ENABLE_DMP
    EN_Time_OnTimer_Source_MEMORY,
    EN_Time_OnTimer_Source_Num,
} EN_MENU_TIME_OnTimer_Source;

typedef enum
{
    EN_Time_AutoOff_Off,
   #if ENABLE_CUS_AUTO_SLEEP_MODE
    EN_Time_AutoOff_On_1Hour,
    EN_Time_AutoOff_On_2Hours,
    EN_Time_AutoOff_On_5Hours,
   #else
    EN_Time_AutoOff_On,
   #endif
    EN_Time_AutoOff_Num
} EN_MENU_TIME_AutoOff;

typedef enum _EN_MENU_TIMEZONE
{
#if ENABLE_SBTVD_BRAZIL_APP
    //GMT - 5
    TIMEZONE_GMT_Minus5_START,
    TIMEZONE_AM_WEST=TIMEZONE_GMT_Minus5_START,
    TIMEZONE_ACRE,
    TIMEZONE_GMT_Minus5_END=TIMEZONE_ACRE,

    //GMT - 4
    TIMEZONE_GMT_Minus4_START,
    TIMEZONE_M_GROSSO=TIMEZONE_GMT_Minus4_START,
    TIMEZONE_NORTH,
    TIMEZONE_GMT_Minus4_END=TIMEZONE_NORTH,

    //GMT - 3
    TIMEZONE_GMT_Minus3_START,
    TIMEZONE_BRASILIA=TIMEZONE_GMT_Minus3_START,
    TIMEZONE_NORTHEAST,
    TIMEZONE_GMT_Minus3_END=TIMEZONE_NORTHEAST,

    //GMT - 2
    TIMEZONE_GMT_Minus2_START,
    TIMEZONE_F_NORONHA=TIMEZONE_GMT_Minus2_START,
    TIMEZONE_GMT_Minus2_END=TIMEZONE_F_NORONHA,

#endif

    // GMT
    TIMEZONE_GMT_0_START,
    TIMEZONE_CANARY=TIMEZONE_GMT_0_START,
    TIMEZONE_LISBON,
    TIMEZONE_LONDON,
    TIMEZONE_RABAT,
    TIMEZONE_GMT_0_END=TIMEZONE_RABAT,

    // GMT + 1
    TIMEZONE_GMT_1_START,
    TIMEZONE_AMSTERDAM=TIMEZONE_GMT_1_START,
    TIMEZONE_BEOGRAD,
    TIMEZONE_BERLIN,
    TIMEZONE_BRUSSELS,
    TIMEZONE_BUDAPEST,
    TIMEZONE_COPENHAGEN,
    TIMEZONE_LIUBLJANA,
    TIMEZONE_LUXEMBOURG,
    TIMEZONE_MADRID,
    TIMEZONE_OSLO,
    TIMEZONE_PARIS,
    TIMEZONE_PRAGUE,
    TIMEZONE_BRATISLAVA,
    TIMEZONE_BERN,
    TIMEZONE_ROME,
    TIMEZONE_STOCKHOLM,
    TIMEZONE_WARSAW,
    TIMEZONE_VIENNA,
    TIMEZONE_ZAGREB,
    TIMEZONE_TUNIS,
    TIMEZONE_ALGIERS,
    TIMEZONE_GMT_1_END=TIMEZONE_ALGIERS,

    // GMT + 2
    TIMEZONE_GMT_2_START,
    TIMEZONE_ATHENS=TIMEZONE_GMT_2_START,
    TIMEZONE_BUCURESTI,
    TIMEZONE_HELSINKI,
    TIMEZONE_SOFIA,
    TIMEZONE_CAIRO,
    TIMEZONE_CAPE_TOWN,
    TIMEZONE_ESTONIA,
    TIMEZONE_TURKEY,
    TIMEZONE_JERUSSLEM,
    TIMEZONE_GMT_2_END=TIMEZONE_JERUSSLEM,

    // GMT + 3
    TIMEZONE_GMT_3_START,
    TIMEZONE_MOSCOW=TIMEZONE_GMT_3_START,
    TIMEZONE_GMT_3_END=TIMEZONE_MOSCOW,

    // GMT + 3.5
    TIMEZONE_GMT_3Point5_START,
    TIMEZONE_TEHERAN=TIMEZONE_GMT_3Point5_START,
    TIMEZONE_GMT_3Point5_END=TIMEZONE_TEHERAN,

    // GMT + 4
    TIMEZONE_GMT_4_START,
    TIMEZONE_ABU_DHABI=TIMEZONE_GMT_4_START,
    TIMEZONE_GMT_4_END=TIMEZONE_ABU_DHABI,

    //GMT + 8
    TIMEZONE_GMT_8_START,
    TIMEZONE_WA=TIMEZONE_GMT_8_START,
    TIMEZONE_BEIJING,
    TIMEZONE_GMT_8_END=TIMEZONE_BEIJING,

    //GMT + 9.5
    TIMEZONE_GMT_9Point5_START,
    TIMEZONE_SA=TIMEZONE_GMT_9Point5_START,
    TIMEZONE_NT,
    TIMEZONE_GMT_9Point5_END=TIMEZONE_NT,

    //GMT + 10
    TIMEZONE_GMT_10_START,
    TIMEZONE_NSW=TIMEZONE_GMT_10_START,
    TIMEZONE_VIC,
    TIMEZONE_QLD,
    TIMEZONE_TAS,
    TIMEZONE_GMT_10_END=TIMEZONE_TAS,

    //GMT +  12
    TIMEZONE_GMT_12_START,
    TIMEZONE_NZST = TIMEZONE_GMT_12_START,
    TIMEZONE_GMT_12_END =TIMEZONE_NZST,

    //GMT - 1
    TIMEZONE_GMT_Minus1_START,
    TIMEZONE_AZORES=TIMEZONE_GMT_Minus1_START,
    TIMEZONE_GMT_Minus1_END=TIMEZONE_AZORES,

    TIMEZONE_NUM, //TIMEZONE MAX
} EN_MENU_TIMEZONE;

typedef enum
{
#if ENABLE_CUS_UI_SPEC
    SOUND_MODE_STANDARD,
    SOUND_MODE_MUSIC,
    SOUND_MODE_SPORTS,
    SOUND_MODE_USER,
    SOUND_MODE_NUM,
    SOUND_MODE_MOVIE
#else
    SOUND_MODE_STANDARD,
    SOUND_MODE_MUSIC,
    SOUND_MODE_MOVIE,
    SOUND_MODE_SPORTS,
    SOUND_MODE_USER,
    SOUND_MODE_NUM
#endif
} EN_SOUND_MODE;

typedef enum
{
#if (TV_SYSTEM == TV_NTSC)
    SOUND_MTS_MONO,
    SOUND_MTS_STEREO,
    SOUND_MTS_SAP,
#elif ( TV_SYSTEM == TV_PAL )
    SOUND_MTS_MONO,
    SOUND_MTS_STEREO,
    SOUND_MTS_I,
    SOUND_MTS_II,
#endif
    SOUND_MTS_NUM,

    SOUND_MTS_LANG_AB,
    SOUND_MTS_NICAM,
    SOUND_MTS_AUTO,
    SOUND_MTS_NONE
}EN_SOUND_MTS_TYPE;

// This Enum is for UI part, dont use it for Core (Kernel)
typedef enum
{
    EN_AspectRatio_Min,
    //EN_AspectRatio_Full,
    EN_AspectRatio_16X9 = EN_AspectRatio_Min,
    EN_AspectRatio_JustScan,
    EN_AspectRatio_Original,
    EN_AspectRatio_4X3,
    EN_AspectRatio_14X9,
    EN_AspectRatio_Zoom1,
    EN_AspectRatio_Zoom2,
    EN_AspectRatio_Panorama,
    #if VGA_HDMI_YUV_POINT_TO_POINT
    EN_AspectRatio_point_to_point,
    #endif
    EN_AspectRatio_Num,
} EN_MENU_AspectRatio;

//******************************************************************************
//          Structures
//******************************************************************************
typedef struct
{
    U16 u16Year:12;
    U16 u8Month:4;
    U16 u8Day:5;
    U16 u8Hour:5;
    U16 u8Min:6;
    U8 u8Sec;
} ST_TIME;

typedef struct
{
    U16 wTimeDataCS;// check sum <<checksum should be put at top of the struct, do not move it to other place>>

    U16 cOnTimerChannel;
    U16 u16OffTimer_Info_Hour;
    U16 u16OffTimer_Info_Min;
    U16 u16OffTimer_Info_Sec;

    U16 u16OnTimer_Info_Hour;
    U16 u16OnTimer_Info_Min;
    U16 u16OnTimer_Info_Sec;

    U32 u32ElapsedTimeCnt;
    S32 s32Offset_Time;
    EN_MENU_TIMEZONE                enTimeZone;
    EN_MENU_Clock_TimeZone          en_Clock_TimeZone;
    EN_MENU_ClockMode               en_ClockMode;
    EN_MENU_TIME_OffTimer           cOffTimerFlag;
    EN_MENU_TIME_OnTimer            cOnTimerFlag;
    EN_MENU_TIME_OnTimer_Source     cOnTimerSourceFlag;
    EN_MENU_TIME_AutoOff            cAutoSleepFlag;
    U8  cOnTimerVolume;
    U8 NVRAM_g_u8TimeInfo_Flag;
}MS_TIME;

typedef struct
{
    EN_MS_NR eNR;                   // NR
    EN_MS_MPEG_NR eMPEG_NR;         // MPEG NR
} T_MS_NR_MODE;

/// XC - ADC setting
typedef struct
{
    U16 u16ADCDataCS;// check sum <<checksum should be put at top of the struct, do not move it to other place>>

    APIXC_AdcGainOffsetSetting stAdcGainOffsetSetting;
    U8 u8CalibrationMode;  ///calibration mode SW/HW
    U8 u8AdcCalOK;      ///< ADC Cal OK
} MS_ADC_SETTING;

#if ENABLE_FLESH_TONE
typedef enum
{
    MS_FLESH_TONE_MIN,
    // ------------------------------------
    MS_FLESH_TONE_OFF = MS_NR_MIN,
    MS_FLESH_TONE_LOW,
    MS_FLESH_TONE_MIDDLE,
    MS_FLESH_TONE_HIGH,
    // ------------------------------------
    MS_FLESH_TONE_NUM,
}EN_MS_FLESH_TONE_MODE;

#endif

#if ENABLE_CUS_DBC
typedef enum
{
    DBC_STATUS_OFF,
    DBC_STATUS_ON,
    DBC_STATUS_NUM,
}EN_DBC_STATUS;
#endif

#if ENABLE_CUS_DLC
typedef enum
{
    DLC_STATUS_OFF,
    DLC_STATUS_ON,
    DLC_STATUS_NUM,
}EN_DLC_STATUS;
#endif

#endif

