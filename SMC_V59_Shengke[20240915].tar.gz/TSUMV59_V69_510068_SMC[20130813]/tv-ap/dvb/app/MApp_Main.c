////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#define MAPP_MAIN_C

//------------------------------------------------------------------------------
// Includes
//------------------------------------------------------------------------------

#include "Board.h"
#include "datatype.h"
#include "drvSAR.h"

// Common Definition
#include "MsCommon.h"
#include "MsIRQ.h"
#include "MsOS.h"
#include "debug.h"
#include "apiXC.h"
#include "MsTypes.h"
#include "drvBDMA.h"
#include "drvUART.h"
#include "drvUartDebug.h"
#include "msAPI_MIU.h"
#include "msAPI_DrvInit.h"
#include "msAPI_Memory.h"
#include "msAPI_Timer.h"
#include "MApp_MultiTasks.h"
#include "MApp_Main.h"
#include "MApp_Init.h"
#include "MApp_TopStateMachine.h"
#include "MApp_TV.h"
#include "MApp_Scan.h"
#include "GPIO_macro.h"
#include "mapp_videoplayer.h"
#if ENABLE_DMP
#include "MApp_UiMediaPlayer.h"
#include "MApp_InputSource.h"
#endif
#include "drvPWM.h"  //mig add  20171116
#ifdef LOCK_ID693_EN
#include "MApp_Standby.h"   //mig add 20171117
#include "drvIIC.h"     //mig add 2017 1117
#endif
#if ENABLE_SBTVD_BRAZIL_CM_APP
#include "msAPI_ChProc.h"
#include "msAPI_ATVSystem.h"
#else
#include "msAPI_ATVSystem.h"
#endif

#ifdef MSOS_TYPE_LINUX
#include <unistd.h>
#include <string.h>
#include "madp.h"
#include "debug.h"
#endif
#if (ENABLE_MSTV_UART_DEBUG && ENABLE_MMS)
#include "drvMmsDbg_if.h"

#if (OBA2 && defined(ENABLE_ATV_SETTING))
#include "msAPI_TVSetting.h"
#endif
extern void MDrv_Cfg_ActInit(void);
extern void MDrv_Cfg_UserActInit(void);
#endif
#if (OBA2 && ENABLE_DBUS_DEBUG)
#include "dbusdebug.h"
#endif

#ifdef MSOS_TYPE_LINUX
#include "MApp_APEngine.h"
#endif
 #if MHEG5_ENABLE
 #include "msAPI_MHEG5.h"
 #endif
#if (OBA2 && EN_BABAO_COMMUNICATE)
extern void MApp_InitBabaoCommunicateChannel(void);
#endif


#if USER_DEBUG && BUILD_SYSDEBUG
extern void userdebug(void);
#define USERDBG(x) x
#else
#define USERDBG(x)
#endif

#if SYSTEM_DEBUG && BUILD_SYSDEBUG
extern void sysdebug(void);
#define SYSDBG(x) x
#else
#define SYSDBG(x)
#endif

#if 0 // MFC debug
#include "drvMFC.h"
#endif

#if ENABLE_AUTOTEST
extern BOOLEAN g_bAutobuildDebug;
#endif
//------------------------------------------------------------------------------
// Locals
//------------------------------------------------------------------------------

#ifdef ENABLE_MINI_DUMP
extern void   MiniDump_MountDrive(void);
#endif

//------------------------------------------------------------------------------
// Functions
//------------------------------------------------------------------------------

#ifdef MSOS_TYPE_LINUX

#include <sched.h>
#include <sys/time.h>
#include <signal.h>

#include <pthread.h>
U32 g_sleep_ms = 0;
U32 g_check_time=0;
pthread_mutex_t system_polling_mutex = PTHREAD_MUTEX_INITIALIZER;

static void system_polling(void)
{
    // monitor app running status
    MAdp_APMNG_PollingRunningStatus();

    // polling D-BUS message/method call
    MAdp_MSGCH_PollingEvent();

    if (!MAdp_IR_IsEnableDaemon())
    {
        U32 interval_ms=msAPI_Timer_GetTime0()-g_check_time;

        // polling IR
        MAdp_IR_MStarFantasy_Polling();

        if(g_sleep_ms>0 && interval_ms<g_sleep_ms)
        {
            usleep((g_sleep_ms-interval_ms)*1000);
        }

        g_check_time=msAPI_Timer_GetTime0();
    }
}
//
//int start_system_polling(void)
//{
//    struct itimerval t;
//    t.it_interval.tv_usec = 50000;
//    t.it_interval.tv_sec = 0;
//    t.it_value.tv_usec = 50000;
//    t.it_value.tv_sec = 0;
//    if (setitimer(ITIMER_REAL, &t, NULL) < 0)
//    {
//        return -1;
//    }
//    signal(SIGALRM, handler_system_polling);
//    return 0;
//}
//
//void start_sleep(void)
//{
//    if (g_usleep !=0)
//    {
//        pthread_mutex_unlock(&system_polling_mutex);
//        usleep(g_usleep);
//        pthread_mutex_lock(&system_polling_mutex);
//    }
//}


int main(int argc, char** argv)
#else
int main(void)
#endif
{

#ifdef MSOS_TYPE_LINUX
  if (argc > 1 && strcmp(argv[1], "bg") == 0)
  {
      daemon(0, 1);
  }
#endif


#if (ENABLE_AUTOTEST || ENABLE_BOOTTIME)
    gU32BootTime = msAPI_Timer_GetTime0();
    gbBootTimeFinish = FALSE;
  #if (ENABLE_BOOTTIME==DISABLE)
    if (g_bAutobuildDebug == TRUE)
  #endif
    {
        printf("[boot time]start\n");
    }
#endif

#if (ENABLE_USB_DOWNLOAD_BIN)
     gU32PQBootTimer=msAPI_Timer_GetTime0();
     gbPQUpdateFinish=FALSE;
#endif

  #if (ENABLE_CHCHANGETIME)
    gbKeyPress = FALSE;
  #endif

  #if (ENABLE_SELECT_UART && ENABLE_DMP)
    MApp_VDPlayer_UartSwitch(SELECT_UART_PORT);
  #endif

  #if (ENABLE_MSTV_UART_DEBUG && ENABLE_MMS)
    MDrv_Dbg_ActInit();
    MDrv_Dbg_UserActInit();
    MDrv_Cfg_ActInit();
    MDrv_Cfg_UserActInit();
  #endif



    MApp_Preparation();
     MUTE_On();
    MApp_PreInit();
#ifdef VCOM_SET_EN	
    Panel_VCOM_PWM_SET(stGenSetting.g_SysSetting.bPanelVcom);
#endif

  #if (OBA2 && defined(ENABLE_ATV_SETTING))
    msAPI_TVSetting_Init();
    #endif


  #if (ENABLE_AUTOTEST || ENABLE_BOOTTIME)
  #if (ENABLE_BOOTTIME==DISABLE)
    if (g_bAutobuildDebug == TRUE)
  #endif
    {
        gU32TmpTime = msAPI_Timer_DiffTimeFromNow(gU32BootTime);
        printf("[boot time]MApp_PreInit = %ld\n", gU32TmpTime);
        printf("[boot time]MApp_PreInit without decompress = %ld\n" , (gU32TmpTime-gU32CompressTotalStepTime));
    }
  #endif
  #if PANEL_TYPE==USE_1280X640_CONFIG
  i2c_SendByte_LockIC(0x7c, 0xF0,0);
  #else
 //i2c_SendByte_LockIC(0x7c, 0xE0,0); //8����װ
 #endif
//i2c_SendByte_LockIC(0x7c, 0xD0,0);
//i2c_SendByte_LockIC(0x7c, 0xF0,0);
#if(ENABLE_MSTV_UART_DEBUG)
    dbgVersionMessage();
#endif


#ifdef LOCK_ID693_EN
   Init_LockIC();
#endif   

	// CUS_XM Xue 20120822: DMP HDMI2 init
#if (CUS_BRAND_ID == BRAND_ID_EBONY)
	SwitchHDMI2Source=FALSE;
#endif

 #if (OBA2 && PARTIALLY_UPDATE && !defined(UI2_OBAMA))
    Update_DBUS_init();
#endif

    USERDBG(userdebug());

    if(stGenSetting.fRunInstallationGuide && (msAPI_ATV_GetActiveProgramCount() > 0))
    {
        stGenSetting.fRunInstallationGuide = FALSE;
    }

    if( stGenSetting.fRunInstallationGuide && IsAnyTVSourceInUse() )
    {
        MApp_TopStateMachine_SetTopState(STATE_TOP_INSTALLGUIDE);
    }
    else if ( IsAnyTVSourceInUse() )
    {
        MApp_TopStateMachine_SetTopState(STATE_TOP_CHANNELCHANGE);
    }
#if (ENABLE_DMP_POWERON)
    else if ( IsStorageInUse() )
    {
#if( ENABLE_DMP_SWITCH )
        if( UI_INPUT_SOURCE_DMP1 == UI_INPUT_SOURCE_TYPE )
        {
             printf("\n=SET USB 1=\n");
             MDrv_USBSetPortSwitch(INPUT_USB1_PORT);
        }
        if( UI_INPUT_SOURCE_DMP2 == UI_INPUT_SOURCE_TYPE )
        {
            printf("\n=SET USB 2=\n");
            MDrv_USBSetPortSwitch(INPUT_USB2_PORT);
        }
#endif
        MApp_TopStateMachine_SetTopState(STATE_TOP_DMP);
    }
#endif
    else
    {
        MApp_TopStateMachine_SetTopState(STATE_TOP_ANALOG_SHOW_BANNER);
    }

  #if ENABLE_SBTVD_BRAZIL_CM_APP
    if(msAPI_ATV_GetActiveProgramCount()||msAPI_CM_CountProgram(E_SERVICETYPE_DTV, E_PROGACESS_INCLUDE_NOT_VISIBLE_ALSO)||msAPI_CM_CountProgram(E_SERVICETYPE_RADIO, E_PROGACESS_INCLUDE_NOT_VISIBLE_ALSO))
    {
        msAPI_CHPROC_CM_InitOridial();
    }
  #endif

#ifdef MSOS_TYPE_LINUX
    extern void msAPI_FS_Init(void);
    //delay the FS_Init until here
    msAPI_FS_Init();
    //MApp_DM_Wrapped_Init();
#endif

#if (OBA2 && ENABLE_DBUS_DEBUG)
    MApp_InitDebug_MsgChannel();
#endif

#if (OBA2 && EN_BABAO_COMMUNICATE)
    MApp_InitBabaoCommunicateChannel();
#endif

#ifdef OBA_MSTV_DEBUG
    void MApp_MSTV_Debug_Init(void);
    MApp_MSTV_Debug_Init();
#endif

#ifdef NETWORK_CONFIG
        extern BOOLEAN MApp_Network_Config(void);
            MApp_Network_Config();
#endif

	#if !ENABLE_POWERON_MUSIC
    Audio_Amplifier_ON();
	#endif
#if SH_RESUME_AUTOPLAY
		g_ucIsSearchFileCount=0;
		g_ucGotoPlay=0;
#endif
    while ( 1 )
    {
      #if(ENABLE_UI_3D_PROCESS)
        {
            extern void msAPI_Process3Dui(void);
            msAPI_Process3Dui();
        }
      #endif
#if (ENABLE_USB_DOWNLOAD_BIN)
       if(gbPQUpdateFinish&&msAPI_Timer_DiffTimeFromNow(gU32PQBootTimer)>5000)
        {
             gU32PQBootTimer=msAPI_Timer_GetTime0();
             gbPQUpdateFinish=FALSE;
             MDrv_Sys_WholeChipReset();
             printf("\n Chip reset failed!\n");
             printf("\n Please reboot system~~\n");
             while(1){}
       }
#endif

      #if (ENABLE_MSTV_UART_DEBUG)
        if ( msAPI_UART_DecodeCommand() )
        {
          #if ( !CHANNEL_SCAN_AUTO_TEST )

          #if ( WATCH_DOG == ENABLE )
            msAPI_Timer_ResetWDT();
          #endif

            continue; // stop main loop for debug
          #endif
        }
      #endif // #if (ENABLE_MSTV_UART_DEBUG)


          MApp_MultiTasks();

      #if 0 // MFC debug
        MDrv_MFC_PrintMessage();
        if(g_ucRegNums)
            continue;
      #endif


        MApp_TopStateMachine();


      #ifdef ENABLE_MINI_DUMP
        if(!IsStorageInUse())
        {
            MiniDump_MountDrive();
        }
      #endif

      #ifdef MSOS_TYPE_LINUX
        system_polling();
      #endif

    }//main while end

    return 0;
}
#undef MAPP_MAIN_C

