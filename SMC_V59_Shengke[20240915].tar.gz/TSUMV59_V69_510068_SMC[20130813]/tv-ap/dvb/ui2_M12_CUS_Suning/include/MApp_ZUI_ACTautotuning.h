////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MAPP_ZUI_ACTAUTOTUNING_H
#define _MAPP_ZUI_ACTAUTOTUNING_H

#ifdef __cplusplus
extern "C" {
#endif  /* __cplusplus */

#include "MApp_ZUI_APIgdi.h"

#ifdef MAPP_ZUI_ACTAUTOTUNING_C
#define INTERFACE
#else
#define INTERFACE extern
#endif

/////////////////////////////////////////
// Cutomize Window Procedures...

INTERFACE S32 MApp_ZUI_ACT_AutoTuningSkipATVWinProc(HWND hWnd, PMSG pMsg);
INTERFACE S32 MApp_ZUI_ACT_AutoTuningSkipDTVWinProc(HWND hWnd, PMSG pMsg);

#define AUTOTUNINGSKIPATV_WINPROC MApp_ZUI_ACT_AutoTuningSkipATVWinProc
#define AUTOTUNINGSKIPDTV_WINPROC MApp_ZUI_ACT_AutoTuningSkipDTVWinProc

/////////////////////////////////////////
// Event Handlers....
INTERFACE void MApp_ZUI_ACT_AppShowAutoTuning(void);
INTERFACE BOOLEAN MApp_ZUI_ACT_HandleAutoTuningKey(VIRTUAL_KEY_CODE key);
INTERFACE void MApp_ZUI_ACT_TerminateAutoTuning(void);
INTERFACE BOOLEAN MApp_ZUI_ACT_ExecuteAutoTuningAction(U16 act);
INTERFACE LPTSTR MApp_ZUI_ACT_GetAutoTuningDynamicText(HWND hwnd);
INTERFACE S16 MApp_ZUI_ACT_GetAutoTuningDynamicValue(HWND hwnd);
INTERFACE U16 MApp_ZUI_ACT_AutoTuningGetPercentValue(void);



#undef INTERFACE

#ifdef __cplusplus
}
#endif  /* __cplusplus */

#endif /* _MAPP_ZUI_ACTAUTOTUNING_H */

