////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MApp_ATVPROC_H
#define _MApp_ATVPROC_H

#include "drvAVD.h"
#include "msAPI_audio.h"
#include "MApp_UiMenuDef.h" 

//****************************************************************************
// Public attributes.
//****************************************************************************

//****************************************************************************
// Public functions.
//****************************************************************************

void MApp_ATVProc_Initialize(void);
void MApp_ATVProc_Exit(void);
void MApp_ATVProc_Handler( SCALER_WIN eWindow );
void MApp_ATVProc_AdjustFactor(ADJUST_TVAVFACTOR eFactor, WORD wParam1, WORD wParam2);
void MApp_ATVProc_ResetPatch(AVD_VideoStandardType eVideoStandard);
EN_ATV_SYSTEM_TYPE MApp_ATVProc_GetAudioSystem(AUDIOSTANDARD_TYPE eAudioStandard);

#endif // __ATVPROC_H__
