////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#define MAPP_DMP_MAIN_C

/******************************************************************************/
/*                 Header Files                                               */
/* ****************************************************************************/
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#include "Board.h"
#include "datatype.h"
#include "MsCommon.h"
#include "debug.h"

// Common Definition
#include "apiXC.h"
#include "apiXC_Adc.h"
#include "MApp_GlobalSettingSt.h"

#include "drvISR.h"
#include "apiDMX.h"
#if ENABLE_CI
#include "msAPI_CI.h"
#endif
#include "apiXC_Sys.h"

#include "MApp_Exit.h"
#include "MApp_Key.h"
#include "MApp_UiMenuDef.h"
#include "MApp_ZUI_Main.h"
#include "ZUI_tables_h.inl"
#include "MApp_DMP_Main.h"
#include "mapp_mplayer.h"
#include "MApp_UiMediaPlayer_Define.h"
#include "IOUtil.h"
#include "InfoBlock.h"
#include "drvCPU.h"
#include "msAPI_CPU.h"

#include "MApp_APEngine.h"
#include "msAPI_APEngine.h"
#include "msAPI_Timer.h"
#include "msAPI_Memory.h"
#include "msAPI_MIU.h"
#include "MsOS.h"
#include "MApp_InputSource.h"
#include "ZUI_exefunc.h"
#include "mapp_videoplayer.h"
#include "SysInit.h"
#include "msAPI_MPEG_Subtitle.h"
//#include "MApp_ZUI_ACTdmp.h"
#include "MApp_ZUI_ACTcoexistWin.h"
#include "MApp_ZUI_ACTinputsource.h"
#include "MApp_ZUI_ACTdmp.h"


//#include "mapp_mplayer.h"

#if CUS_SMC_ENABLE_HOTEL_MODE
#include "MApp_OSDPage_Main.h"
#endif
#if (ENABLE_DMP)
///////////////////////////////////////////////////////////
#define DMP_WAITCONNECT_MS      3000

static ST_DMP_VAR     m_enDmpVar;
static U8 u8MediaKey=KEY_NULL;

BOOLEAN bPlayingStateEnableOSD = FALSE;
//extern U8 MApp_MPlayer_LastMemory_Search(U16 u16DriveID, U16* pFullPath);


extern void MApp_DMP_NotifyUiState(EN_DMP_UI_STATE enDmpUiState);
#if SH_RESUME_AUTOPLAY

	void setGotoPlayVal(U8 s)
	{
		 g_ucGotoPlay=s;
	}
	U8 getGotoPlayVal(void)
	{
		return g_ucGotoPlay;
	}

#endif
void MApp_DMP_SetMediaKey (U8 u8Key)
{
    u8MediaKey=u8Key;
}
//////////////////////////////////////////////////////////
#if 0
static void _MApp_DMP_StretchOSD(BOOLEAN bEnable)
{
    U8 u8CurGop = MApi_GOP_GWIN_GetCurrentGOP();
    MApi_GOP_GWIN_SwitchGOP(E_GOP_OSD);
    if (bEnable)
    {
        MApi_GOP_GWIN_Set_STRETCHWIN(E_GOP_OSD, E_GOP_DST_OP0,0, 0, ZUI_DMP_WIDTH, ZUI_DMP_HEIGHT);
        MApi_GOP_GWIN_Set_HSCALE(TRUE, ZUI_DMP_WIDTH, PANEL_WIDTH);
        MApi_GOP_GWIN_Set_VSCALE(TRUE, ZUI_DMP_HEIGHT, PANEL_HEIGHT);
    }
    else
    {
        MApi_GOP_GWIN_Set_HSCALE(TRUE, ZUI_DMP_WIDTH, ZUI_DMP_WIDTH);
        MApi_GOP_GWIN_Set_VSCALE(TRUE, ZUI_DMP_HEIGHT, ZUI_DMP_HEIGHT);
        MApi_GOP_GWIN_Set_STRETCHWIN(E_GOP_OSD, E_GOP_DST_OP0,0, 0, PANEL_WIDTH, PANEL_HEIGHT);
    }
    MApi_GOP_GWIN_SwitchGOP(u8CurGop);
}
#endif
void  MApp_DMP_LoadCOPRO (void)
{
      #if defined(MIPS_CHAKRA) || defined(MSOS_TYPE_LINUX) || defined(__AEONR2__)
        msAPI_COPRO_Init(BIN_ID_CODE_VDPLAYER,((AEON_MEM_MEMORY_TYPE & MIU1) ? (AEON_MM_MEM_ADR | MIU_INTERVAL) : (AEON_MM_MEM_ADR)),AEON_MM_MEM_LEN);
      #else
        msAPI_COPRO_Init(BIN_ID_CODE_VDPLAYER,((BEON_MEM_MEMORY_TYPE & MIU1) ? (BEON_MEM_ADR | MIU_INTERVAL) : ( BEON_MEM_ADR)),BEON_MEM_LEN);
      #endif
}

BOOLEAN MApp_DMP_IsSuccessorWinVisible(HWND hWnd)
{
    HWND child, last_succ;
    last_succ = MApp_ZUI_API_GetLastSuccessor(hWnd);
    for (child = hWnd; child <= last_succ; child++)
    {
        if(child != HWND_DMP_PLAYBACK_TRANSPARENT_BG &&
            MApp_ZUI_API_IsWindowVisible(child))
        {
            return TRUE;
        }
    }
    return FALSE;
}
BOOLEAN MApp_DMP_IsOSDVisible(void)
{
      if (  /*MApp_DMP_IsSuccessorWinVisible(HWND_DMP_BG_GRADIENT_TOP)
            ||MApp_DMP_IsSuccessorWinVisible(HWND_DMP_BG_GRADIENT_BOTTOM)
			*/
			MApp_DMP_IsSuccessorWinVisible(HWND_UP_BAR)
            ||MApp_DMP_IsSuccessorWinVisible(HWND_DOWN_BAR)
            ||MApp_DMP_IsSuccessorWinVisible(HWND_BJ)
            ||MApp_DMP_IsSuccessorWinVisible(HWND_DMP_SEL_BAR_GROUP)
            ||MApp_DMP_IsSuccessorWinVisible(HWND_DMP_MEDIA_TYPE_PAGE)
            ||MApp_DMP_IsSuccessorWinVisible(HWND_DMP_DRIVE_PAGE)
            ||MApp_DMP_IsSuccessorWinVisible(HWND_DMP_FILE_SELECT_PAGE)
            ||MApp_DMP_IsSuccessorWinVisible(HWND_DMP_PLAYBACK_PAGE)
            ||MApp_DMP_IsSuccessorWinVisible(HWND_DMP_ALERT_WINDOW)
            ||MApp_DMP_IsSuccessorWinVisible(HWND_DMP_PROGRESS_WINDOW)
            ||MApp_DMP_IsSuccessorWinVisible(HWND_DMP_VOLUME_LIST)
            ||MApp_DMP_IsSuccessorWinVisible(HWND_DMP_DRM_WINDOW)
#if ENABLE_CUS_USB_OSD
            ||MApp_DMP_IsSuccessorWinVisible(HWND_DMP_MAKESURE_WINDOW)
            ||MApp_DMP_IsSuccessorWinVisible(HWND_DMP_SOURCE_PANE)
            ||MApp_DMP_IsSuccessorWinVisible(HWND_DMP_MENU_HANDLE_SUB)
            ||MApp_DMP_IsSuccessorWinVisible(HWND_DMP_MENU_HANDLE_MAIN)
            ||MApp_DMP_IsSuccessorWinVisible(HWND_DMP_MEDIA_TYPE_INFO_GROUP)
            ||MApp_DMP_IsSuccessorWinVisible(HWND_DMP_3D_SETUP_PAGE)
            ||MApp_DMP_IsSuccessorWinVisible(HWND_DMP_MENU_HANDLE_MAIN_FRAME)
            ||MApp_DMP_IsSuccessorWinVisible(HWND_DMP_HOTKEY_PANEL)
            ||MApp_DMP_IsSuccessorWinVisible(HWND_DMP_BG_EIXT_BUTTON)
            ||MApp_DMP_IsSuccessorWinVisible(HWND_DMP_BG_ENTER_BUTTON)
            ||MApp_DMP_IsSuccessorWinVisible(HWND_DMP_BAR_CHOOSE_TEXT)
            ||MApp_DMP_IsSuccessorWinVisible(HWND_DMP_BG_GRADIENT_TOP_LINE)
            ||MApp_DMP_IsSuccessorWinVisible(HWND_DMP_BG_GRADIENT_BOTTOM_LINE)
            ||MApp_DMP_IsSuccessorWinVisible(HWND_DMP_BAR_EXIT_TEXT)
            ||MApp_DMP_IsSuccessorWinVisible(HWND_DMP_BAR_ENTER_TEXT)
            ||MApp_DMP_IsSuccessorWinVisible(HWND_DMP_BG_CHOSE_BUTTON)
#endif
            ||MApp_DMP_IsSuccessorWinVisible(HWND_DMP_MUTE_PANEL)
            ||MApp_DMP_IsSuccessorWinVisible(HWND_DMP_COUNTDOWN_PANEL)
	||MApp_DMP_IsSuccessorWinVisible(HWND_DMP_HOTEL_PASSWD_PANEL)
	||(MApp_ZUI_GetActiveOSD() == HWND_DMP_HOTEL_MSG_NOTE)
            ||(MApp_ZUI_GetActiveOSD() == E_OSD_MAIN_MENU)
            ||(MApp_ZUI_GetActiveOSD() == E_OSD_INPUT_SOURCE)
         )
        {
            return TRUE;
        }
        else
        {
           return FALSE;
        }
}

static void _MApp_DMP_Init(void)
{
    if(!(m_enDmpVar.enDmpFlag & DMP_FLAG_INITED))
    {
        DMP_DBG(printf("MApp_UiMediaPlayer_Init()\n"));

        MApp_MPlayer_InitializeKernel();
        MApp_DMP_SetCurDrvIdxAndCalPageIdx(0);

        m_enDmpVar.enDmpUiState = DMP_UI_STATE_MEDIA_SELECT;
        MApp_MPlayer_InitRepeatMode(E_MPLAYER_REPEAT_ALL);
        MApp_MPlayer_EnableNotify(E_MPLAYER_NOTIFY_ALL, TRUE);
        // TODO: this line may be redundant?
        //MApp_MPlayer_SetCurrentMediaType(E_MPLAYER_TYPE_PHOTO, FALSE);
      #if defined(MIPS_CHAKRA) || defined(MSOS_TYPE_LINUX) || defined(__AEONR2__)
        msAPI_COPRO_Init(BIN_ID_CODE_VDPLAYER,((AEON_MEM_MEMORY_TYPE & MIU1) ? (AEON_MM_MEM_ADR | MIU_INTERVAL) : (AEON_MM_MEM_ADR)),AEON_MM_MEM_LEN);
      #else
        msAPI_COPRO_Init(BIN_ID_CODE_VDPLAYER,((BEON_MEM_MEMORY_TYPE & MIU1) ? (BEON_MEM_ADR | MIU_INTERVAL) : ( BEON_MEM_ADR)),BEON_MEM_LEN);
      #endif
        m_enDmpVar.enDmpFlag |= DMP_FLAG_INITED;
    }
}

void MApp_DMP_Reset(void)
{
    DMP_DBG(printf("MApp_UiMediaPlayer_Reset()\n"));
    MApp_DMP_SetCurDrvIdxAndCalPageIdx(0);
    m_enDmpVar.enDmpFlag = DMP_FLAG_INITED;
    MApp_MPlayer_InitRepeatMode(E_MPLAYER_REPEAT_ALL);
}

void _MApp_DMP_Switch2Dmp(void)
{
   // MApi_AUDIO_AbsoluteBass(0);  // set the bass to 0 to avoid voice broken

    if( MApp_MPlayer_SetCurrentMediaType(E_MPLAYER_TYPE_PHOTO, TRUE) == E_MPLAYER_RET_FAIL)
    {
        DMP_DBG(printf("MApp_MPlayer_SetCurrentMediaType fail"););
    }

    if(m_enDmpVar.enDmpFlag & DMP_FLAG_INITED)
    {
        DMP_DBG(printf("\n *** MApp_DMP_Reset() ***\n"));

        MApp_DMP_Reset();
        MApp_MPlayer_ConnectDrive(m_enDmpVar.stDrvInfo.au8MapTbl[m_enDmpVar.stDrvInfo.u8Idx]);
    }
    else
    {
        DMP_DBG(printf("\n *** _MApp_DMP_Init() ***\n"));
        _MApp_DMP_Init();
    }

    return;
}

BOOLEAN MApp_DMP_RecalculateDriveMappingTable(void)
{
    MPlayerDrive driveInfo;
    BOOLEAN bConnect = FALSE;
    U8 i, /*j,*/ driveIdx, count=0;

    if(MApp_MPlayer_QueryCurrentDeviceIndex() == E_MPLAYER_USB0 ||
        MApp_MPlayer_QueryCurrentDeviceIndex() == E_MPLAYER_USB1)
    {
    // TODO: need to refine for loop!? 20090824
        DMP_DBG(printf("[DMP] Total Drives : %u\n", MApp_MPlayer_QueryTotalDriveNum()));
        memset(m_enDmpVar.stDrvInfo.au8MapTbl, 0xFF, sizeof(U8)*NUM_OF_MAX_DRIVE);
        //for(j = 0; j < NUM_OF_MAX_DRIVE; j++)
        //{//Sorting the partition table.
            for(i = 0; i < NUM_OF_MAX_DRIVE; i++)
            {
                driveIdx = MApp_MPlayer_QueryPartitionIdxInDrive(i, &driveInfo);

                if(driveIdx != 0xFF && driveInfo.eDeviceType != E_MPLAYER_INVALID
                    /*&&j == driveInfo.u8Partition*/)
                {
                    bConnect = TRUE;
                    DMP_DBG(printf("[DMP] %u USB%u  LUN%u   Partition%u\n", driveIdx, (U8)driveInfo.eDeviceType, driveInfo.u8Lun, driveInfo.u8Partition);)
                    {
                        m_enDmpVar.stDrvInfo.au8MapTbl[count++] = driveInfo.u8Partition;
                    }
                }
            } //end of i
        //} //end of j
    }

    return bConnect;
}

U8 MApp_DMP_GetDriveFromMappingTable(U8 u8Idx)
{
    return m_enDmpVar.stDrvInfo.au8MapTbl[u8Idx];
}

void MApp_DMP_InitDMPStat(void)
{
    DMP_DBG(printf("MApp_DMP_InitDMPStat\n"));

    m_enDmpVar.enDmpState = DMP_STATE_INIT;
    m_enDmpVar.enDmpFlag = DMP_FLAG_NONE;
}

void MApp_DMP_Exit(void)
{
    DMP_DBG(printf("MApp_DMP_Exit\n"));

    m_enDmpVar.enDmpState = DMP_STATE_INIT;
    MApp_MPlayer_StopPreview();

    if(m_enDmpVar.enDmpFlag & DMP_FLAG_BGM_MODE)
    {
        MApp_MPlayer_StopMusic();
    }

    if(m_enDmpVar.enDmpFlag & DMP_FLAG_MEDIA_FILE_PLAYING)
    {
        MApp_MPlayer_Stop();
    }

    m_enDmpVar.enDmpFlag = DMP_FLAG_NONE;
    //MApp_ZUI_API_StoreFocusCheckpoint(HWND_DMP_MEDIA_TYPE_PHOTO);
    MApp_MPlayer_ExitMediaPlayer();

#if defined(MIPS_CHAKRA) || defined(__AEONR2__)
    MDrv_COPRO_Disable();
#else
  #if OBA2==0
    MDrv_COPRO_Disable();
  #endif
#endif

    MsOS_EnableInterrupt(E_INT_IRQ_TSP2HK);
    //MApi_DMX_Init();

#if 0//ENABLE_DTV
  #if ENABLE_CI
    if(msAPI_CI_CardDetect() == TRUE)
    {
        msAPI_Tuner_Serial_Control(TRUE);
    }
    else
    {
        msAPI_Tuner_Serial_Control(FALSE);
    }
  #else
    msAPI_Tuner_Serial_Control(FALSE);
  #endif
#endif
   if(MApp_MPlayer_QueryCurrentMediaType()!=E_MPLAYER_TYPE_PHOTO)
    MApp_Photo_Display_Stop(); // SMC add 20120803 for full screen display

}

void MApp_DMP_BW_Control(BOOL bOsdOn)
{
#if (CHIP_FAMILY_TYPE==CHIP_FAMILY_M10) || (CHIP_FAMILY_TYPE==CHIP_FAMILY_M12)
    bOsdOn=bOsdOn;
#else
    if(bOsdOn==TRUE)
    {
        MApp_VDPlayer_QuarterPixel(DISABLE);
        MApp_VDPlayer_DeBlocking(DISABLE);
    }
    else
    {
        MApp_VDPlayer_QuarterPixel(ENABLE);
        MApp_VDPlayer_DeBlocking(ENABLE);
    }
#endif
}
#if SH_RESUME_AUTOPLAY
extern void MApp_Mplayer_SearchFileTypeCount(void);
#endif
EN_RET MApp_DMP_Main(void)
{
    EN_RET enRetVal = EXIT_NULL;
    static U32 u32time = 0;
    static U8 u8GWinId = 0;
    static EN_DMP_STATE eLastDmpState = DMP_STATE_INIT;


    if( m_enDmpVar.enDmpState != eLastDmpState )
    {
        //printf(" DmpMain:DmpState: %u --> %u, \r\n DmpUiState=%u \r\n", eLastDmpState, m_enDmpVar.enDmpState, m_enDmpVar.enDmpUiState );
        eLastDmpState = m_enDmpVar.enDmpState;
    }

    switch (m_enDmpVar.enDmpState)
    {
        case DMP_STATE_INIT:
            srand(msAPI_Timer_GetTime0());
            //_MApp_DMP_StretchOSD(TRUE);
            #if (ENABLE_SOURCECHANGETIME)
            printf("StartupDMP = %ld\n", msAPI_Timer_DiffTimeFromNow(gU32SourceChangeTime));
            #endif
            MApp_ZUI_ACT_StartupOSD(E_OSD_DMP);
            _MApp_DMP_Switch2Dmp();
            u32time = msAPI_Timer_GetTime0();
            m_enDmpVar.enDmpState = DMP_STATE_CONNECTING;
            u8GWinId = MApp_ZUI_API_QueryGWinID();
            MAppSetREAD_NONBLOCKING(FALSE);
            break;

        case DMP_STATE_CONNECTING:
            if(msAPI_Timer_DiffTimeFromNow(u32time) > DMP_WAITCONNECT_MS
                || m_enDmpVar.enDmpFlag & DMP_FLAG_DRIVE_CONNECT_OK)
            {
                m_enDmpVar.enDmpState = DMP_STATE_UI;
                #if (ENABLE_SOURCECHANGETIME)
                    printf("UI Change = %ld\n", msAPI_Timer_DiffTimeFromNow(gU32SourceChangeTime));
                #endif
            }
            break;

        case DMP_STATE_UI:
            #if (ENABLE_SOURCECHANGETIME)
                printf("UI Change1 = %ld\n", msAPI_Timer_DiffTimeFromNow(gU32SourceChangeTime));
            #endif
            MApp_DMP_NotifyUiState(m_enDmpVar.enDmpUiState);
			
            m_enDmpVar.enDmpState = DMP_STATE_WAIT;
            break;

        case DMP_STATE_WAIT:
			
#if SH_RESUME_AUTOPLAY

				   if(getSearchFileCount()==1)
				{
				MApp_Mplayer_SearchFileTypeCount();
				  
				   setSearchFileCount(0);
				   
				}
				
							if(getGotoPlayVal()==1)
							{
							 m_enDmpVar.enDmpState=DMP_STATE_UI;
							 m_enDmpVar.enDmpUiState=DMP_UI_STATE_FILE_SELECT;//DMP_UI_STATE_PLAYING_STAGE;//
							 //MApp_MPlayer_SetPlayMode(E_MPLAYER_PLAY_SELECTED_FROM_CURRENT);
							 //printf("uuuuuuuwerwerwefffffff!!!!sdf=%d\r\n",stGenSetting.g_MmLastMemorySetting.m_LastMemoryInfo[0].stLastMemAttribute.last_media_idex);
							 //MApp_MPlayer_SetCurrentPlayingFileIndex(stGenSetting.g_MmLastMemorySetting.m_LastMemoryInfo[0].stLastMemAttribute.last_media_idex);
							// MApp_MPlayer_SetCurrentFile(E_MPLAYER_INDEX_CURRENT_DIRECTORY,stGenSetting.g_MmLastMemorySetting.m_LastMemoryInfo[0].stLastMemAttribute.last_media_idex);
				
				
							 MApp_ZUI_ACT_ExecuteDmpAction(EN_EXE_DMP_FILE_PAGE_PLAYBACK);
							 setGotoPlayVal(0);
							 
							 break;
							}
#endif
            if(u8MediaKey!=KEY_NULL)
            {
                u8KeyCode=u8MediaKey;
                u8MediaKey=KEY_NULL;
            }
		
          #if DMP_UI_BMPSUBTITLE_EXCLUSIVE
            //Patch for bandwidth issue - disable GOP when no UI on the screen
            if (u8KeyCode == 0xFF &&
                m_enDmpVar.enDmpUiState == DMP_UI_STATE_PLAYING_STAGE &&
                !MApp_DMP_IsOSDVisible()&&
                !MApp_MPlayer_IsCurSubtitleText() &&
                !msAPI_MpegSP_Get_Render_Status()&&
                MApp_UiMenu_GetCoexistWin_State() )
            {
                if(MApi_GOP_GWIN_IsGWINEnabled(u8GWinId))
                {
                    MApi_GOP_GWIN_Enable(u8GWinId, FALSE);
                    MApp_DMP_BW_Control(FALSE);
                    DMP_DBG(printf("MApp_ZUI_API_TerminateGDI dmp_main.c\n"););
                    MApp_ZUI_API_EmptyMessageQueue();
                    MApp_ZUI_API_TerminateGDI();
                    DMP_DBG(printf("draw subtitle 2\n"););
                    msAPI_MpegSP_SetShowStatus(TRUE);
                }
            }

            if ((u8KeyCode != 0xFF ||bPlayingStateEnableOSD) &&
                m_enDmpVar.enDmpUiState == DMP_UI_STATE_PLAYING_STAGE)
            {
                DMP_DBG(printf("close subtitle 0\n"););

                msAPI_MpegSP_SetShowStatus(FALSE);
                MApp_DMP_BW_Control(TRUE);
                MAppProcessREAD_NONBLOCKING();
                if(MApp_DMP_GetDmpFlag()  & DMP_FLAG_BGM_MODE)
               {
                     MApp_Music_InputBackGroundMusicData();
               }
                //Reinit MM OSD
                {
                    RECT rect;

                    RECT_SET(rect,
                        ZUI_DMP_XSTART, ZUI_DMP_YSTART,
                        ZUI_DMP_WIDTH, ZUI_DMP_HEIGHT);

                    if (!MApp_ZUI_API_InitGDI(&rect))
                    {
                        DMP_DBG(printf("[ZUI]GDI RE-INIT Failed!\n"));
                    }
                    DMP_DBG(printf("MApp_ZUI_API_InitGDI \n"););
                }

                MAppProcessREAD_NONBLOCKING();
                MApi_GOP_GWIN_Enable(u8GWinId, TRUE);
            }
            else if (m_enDmpVar.enDmpUiState == DMP_UI_STATE_MEDIA_SELECT)
            {
                if(!MApi_GOP_GWIN_IsGWINEnabled(u8GWinId))
                {
                    DMP_DBG(printf("close subtitle 1\n"););
                    msAPI_MpegSP_SetShowStatus(FALSE);
                    MApp_DMP_BW_Control(TRUE);
                    //Reinit MM OSD
                    {
                        RECT rect;
                        RECT_SET(rect,
                            ZUI_DMP_XSTART, ZUI_DMP_YSTART,
                            ZUI_DMP_WIDTH, ZUI_DMP_HEIGHT);
                        if (!MApp_ZUI_API_InitGDI(&rect))
                        {
                            printf("[ZUI]GDI RE-INIT Failed 1!\n");
                            //ABORT();
                            //return EXIT_NULL;
                        }
                        DMP_DBG(printf("MApp_ZUI_API_InitGDI 1\n"););
                    }
                    MApi_GOP_GWIN_Enable(u8GWinId, TRUE);
                }
            }
            else if(m_enDmpVar.enDmpUiState == DMP_UI_STATE_FILE_SELECT)
            {
                if(!MApi_GOP_GWIN_IsGWINEnabled(u8GWinId))
                {
                    MApp_DMP_BW_Control(TRUE);
                    //Reinit MM OSD
                    {
                        RECT rect;
                        RECT_SET(rect,
                            ZUI_DMP_XSTART, ZUI_DMP_YSTART,
                            ZUI_DMP_WIDTH, ZUI_DMP_HEIGHT);
                        if (!MApp_ZUI_API_InitGDI(&rect))
                        {
                            printf("[ZUI]GDI RE-INIT Failed  2!\n");
                            //ABORT();
                            //return EXIT_NULL;
                        }
                        DMP_DBG(printf("MApp_ZUI_API_InitGDI 2\n"););
                    }
                    MApi_GOP_GWIN_Enable(u8GWinId, TRUE);
                }
            }
            else
            {
                //for debugging
                //printf("m_enDmpVar.enDmpUiState = %d\n", m_enDmpVar.enDmpUiState);
            }
          #endif //DMP_UI_BMPSUBTITLE_EXCLUSIVE

            MAppProcessREAD_NONBLOCKING();
            MApp_ZUI_ProcessKey(u8KeyCode);
            MAppProcessREAD_NONBLOCKING();
            MAppSetREAD_NONBLOCKING(FALSE);

            u8KeyCode = KEY_NULL;
            break;

        case DMP_STATE_CLEAN_UP:
            MApp_ZUI_ACT_ShutdownOSD();
            m_enDmpVar.enDmpState = DMP_STATE_INIT;
            enRetVal =EXIT_MPLAYER_EXIT;
            break;

        case DMP_STATE_GOTO_STANDBY:
            MApp_ZUI_ACT_ShutdownOSD();
            u8KeyCode = KEY_POWER;
            enRetVal =EXIT_MPLAYER_TRAN_STANDBY;
            break;

        case DMP_STATE_GOTO_MENU:
            #if ENABLE_EMBEDDED_PHOTO_DISPLAY
            MApp_MPlayer_StopEmbeddedPhoto();
            #endif
            MApp_ZUI_ACT_ShutdownOSD();
            m_enDmpVar.enDmpState = DMP_STATE_RETURN_FROM_MENU;
            enRetVal = EXIT_MPLAYER_TRAN_MENU;
            break;
	#if CUS_SMC_ENABLE_HOTEL_MODE
        case DMP_STATE_GOTO_HOTEL:
#if ENABLE_EMBEDDED_PHOTO_DISPLAY
            MApp_MPlayer_StopEmbeddedPhoto();
#endif
            MApp_ZUI_ACT_ShutdownOSD();
            m_enDmpVar.enDmpState = DMP_STATE_RETURN_FROM_MENU;
            enRetVal = EXIT_MPLAYER_TRAN_HOTEL;
            g_bGotoCUSMenu=3;
			MApp_OSDPage_SetOSDPage(E_OSD_FACTORY_MENU);
			break;
	#endif
        case DMP_STATE_GOTO_INPUTSOURCE:
            #if ENABLE_EMBEDDED_PHOTO_DISPLAY
            MApp_MPlayer_StopEmbeddedPhoto();
            #endif
            MApp_ZUI_ACT_ShutdownOSD();
            m_enDmpVar.enDmpState = DMP_STATE_RETURN_FROM_MENU;
            enRetVal = EXIT_MPLAYER_TRAN_INPUTSOURCE;
            break;

        case DMP_STATE_GOTO_PREV_SRC:
            MApp_ZUI_ACT_ShutdownOSD();
            m_enDmpVar.enDmpState = DMP_STATE_INIT;
            enRetVal =EXIT_MPLAYER_EXIT;
            MApp_DMP_Exit();
         #if( ENABLE_DMP_SWITCH )		// CUS_XM Sea 20120629:
            if((UI_PREV_INPUT_SOURCE_TYPE==UI_INPUT_SOURCE_DMP1)
                ||(UI_PREV_INPUT_SOURCE_TYPE==UI_INPUT_SOURCE_DMP2))
            {
                UI_PREV_INPUT_SOURCE_TYPE=UI_INPUT_SOURCE_ATV;
            }
         #endif
            MApp_InputSource_RestoreSource();

            //UI_INPUT_SOURCE_TYPE = MApp_InputSource_GetRecordSource();
            //MApp_InputSource_ChangeInputSource();

          #ifdef ATSC_SYSTEM
            MApp_ZUI_ACT_StartupOSD(E_OSD_CHANNEL_INFO);
          #else
            if(IsAnyTVSourceInUse()) //simon:20120425
            {
                MApp_ZUI_ACT_StartupOSD(E_OSD_CHANNEL_INFO);
                MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_SHOW_BRIEF_CH_INFO);
            }
            else//non DTV/ATV sources
            {
                MApp_ZUI_ACT_StartupOSD(E_OSD_CHANNEL_INFO);
                MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_SHOW_SOURCE_BANNER);
            }
          #endif
            break;

        case DMP_STATE_RETURN_FROM_MENU:
            #if ENABLE_EMBEDDED_PHOTO_DISPLAY
            MApp_MPlayer_ResumeEmbeddedPhoto();
            #endif
            //printf("DMP_STATE_RETURN_FROM_MENU\n");
            m_enDmpVar.enDmpState = DMP_STATE_UI;
            MApp_ZUI_ACT_StartupOSD(E_OSD_DMP);
            break;
        case DMP_STATE_GOTO_CUR_SRC:
        #if 0
            MApp_ZUI_ACT_ShutdownOSD();
            m_enDmpVar.enDmpState = DMP_STATE_INIT;
            enRetVal =EXIT_MPLAYER_EXIT;
        #endif
            MApp_DMP_Exit();

            UI_PREV_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_TYPE;
         #if( ENABLE_DMP_SWITCH )
            if( UI_INPUT_SOURCE_DMP1 == _MApp_ZUI_ACT_DmpGetSourceType())
           {
               printf("\n=SET USB 1=\n");
                MDrv_USBSetPortSwitch(INPUT_USB1_PORT);
                MApp_ZUI_ACT_ShutdownOSD();
            }
            if( UI_INPUT_SOURCE_DMP2 == _MApp_ZUI_ACT_DmpGetSourceType())
            {
                printf("\n=SET USB 2=\n");
                MDrv_USBSetPortSwitch(INPUT_USB2_PORT);
                MApp_ZUI_ACT_ShutdownOSD();
            }
        #endif
        #if 1 //ENABLE_CUS_USB_OSD
            MApp_ZUI_ACT_InputSourceSwitch( _MApp_ZUI_ACT_DmpGetSourceType());
        #else
            MApp_ZUI_ACT_InputSourceSwitch(UI_INPUT_SOURCE_ATV);
        #endif

            if(!IsStorageInUse())
            {
                MApp_ZUI_ACT_ShutdownOSD();
                m_enDmpVar.enDmpState = DMP_STATE_INIT;
                enRetVal =EXIT_MPLAYER_EXIT;

                #ifdef ATSC_SYSTEM
                MApp_ZUI_ACT_StartupOSD(E_OSD_CHANNEL_INFO);
                #else
                if(IsAnyTVSourceInUse())
                {
                    MApp_ZUI_ACT_StartupOSD(E_OSD_CHANNEL_INFO);
                    MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_SHOW_BRIEF_CH_INFO);
                }
                else//non DTV/ATV sources
                {
                    MApp_ZUI_ACT_StartupOSD(E_OSD_CHANNEL_INFO);
                    MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_SHOW_SOURCE_BANNER);
                }
                #endif
            }
            break;
        case DMP_STATE_RESET:
            MApp_DMP_Exit();
            break;
    }

    return enRetVal;
}


U8 MApp_DMP_GetCurDrvIdx(void)
{
    return m_enDmpVar.stDrvInfo.u8Idx;      //drive idx is ZERO base
}

U8 MApp_DMP_GetDrvPageIdx(void)
{
    return m_enDmpVar.stDrvInfo.u8PageIdx;  //page idx is NONE-ZERO base
}

void MApp_DMP_SetCurDrvIdxAndCalPageIdx(U8 u8Idx)
{
    m_enDmpVar.stDrvInfo.u8Idx = u8Idx;

    m_enDmpVar.stDrvInfo.u8PageIdx = ((u8Idx+1) / DMP_DRIVE_NUM_PER_PAGE) + 1; //page idx is NONE-ZERO base
}

void MApp_DMP_SetDrvPageIdx(U8 u8Idx)
{
    m_enDmpVar.stDrvInfo.u8PageIdx = u8Idx;
}

void MApp_DMP_SetDmpFlag(EN_DMP_FLAG flag)
{
    DMP_DBG(printf("set Flag %u\n",flag););

    m_enDmpVar.enDmpFlag |= flag;
}

void MApp_DMP_ClearDmpFlag(EN_DMP_FLAG flag)
{
    DMP_DBG(printf("clear Flag %u\n",flag););

    m_enDmpVar.enDmpFlag &= (EN_DMP_FLAG)~flag;
}

EN_DMP_FLAG MApp_DMP_GetDmpFlag(void)
{
    return m_enDmpVar.enDmpFlag;
}

void MApp_DMP_SetDmpUiState(EN_DMP_UI_STATE state)
{
    m_enDmpVar.enDmpUiState = state;
}

EN_DMP_UI_STATE MApp_DMP_GetDmpUiState(void)
{
    return m_enDmpVar.enDmpUiState;
}

void MApp_DMP_UiStateTransition(EN_DMP_UI_STATE enState)
{
    //Before UI state transition, checking status of mplayer firstly!
    DMP_DBG(printf("current UiState %u\n",m_enDmpVar.enDmpUiState););
    DMP_DBG(printf("change to UiState %u\n",enState););

    switch(m_enDmpVar.enDmpUiState)
    {
    #if NEW_BGM
        case DMP_UI_STATE_BGM_FILE_SELECT:
    #endif
        case DMP_UI_STATE_FILE_SELECT:
        {
            MApp_DMP_ClearDmpFlag(DMP_FLAG_MEDIA_FILE_PLAYING);
            MApp_DMP_ClearDmpFlag(DMP_FLAG_MEDIA_FILE_PLAYING_ERROR);

            enumMPlayerMediaType enMediaType = MApp_MPlayer_QueryCurrentMediaType();

            switch(enMediaType)
            {
                case E_MPLAYER_TYPE_PHOTO:
                {
                    if(MApp_MPlayer_QueryPreviewState(enMediaType) == E_PHOTO_PREVIEW_RUNNING)
                    {
                        //printf("stop preview\n");
                        MApp_MPlayer_StopPreview();
                    }

                    DMP_DBG(printf("MApp_DMP_UiStateTransition E_MPLAYER_TYPE_PHOTO\n"););
                    //MApp_MPlayer_LeaveThumbnailMode();
                }
                break;
                case E_MPLAYER_TYPE_MUSIC:
                {
                    if(MApp_MPlayer_QueryPreviewState(enMediaType) == E_MUSIC_PREVIEW_RUNNING)
                    {
                        MApp_MPlayer_StopPreview();
                    }
                }
                break;
                case E_MPLAYER_TYPE_MOVIE:
                {
                    if ( MApp_MPlayer_QueryPreviewState(enMediaType) == E_MOVIE_PREVIEW_RUNNING
                      || MApp_MPlayer_QueryPreviewState(enMediaType) == E_MOVIE_PREVIEW_TIMER_ENABLE
                      || MApp_MPlayer_QueryPreviewState(enMediaType) == E_MOVIE_PREVIEW_1ST_FRAME_PREDECODE
                      || MApp_MPlayer_QueryPreviewState(enMediaType) == E_MOVIE_PREVIEW_1ST_FRAME_DECODE)
                    {
                        MApp_MPlayer_StopPreview();
                    }
                }
                break;
                case E_MPLAYER_TYPE_TEXT:
                {
                    if(MApp_MPlayer_QueryPreviewState(enMediaType) != E_TEXT_PREVIEW_NONE)
                    {
                        MApp_MPlayer_StopPreview();
                    }
                }
                break;
                default:
                    break;
            }
        }
        break;

        case DMP_UI_STATE_PLAYING_STAGE:
        {
        #if SLIDESHOW_STOP_BGM_STOP
            if(m_enDmpVar.enDmpFlag & DMP_FLAG_BGM_MODE)
            {
            #if !ENABLE_CUS_USB_OSD
                MApp_MPlayer_StopMusic();
                MApp_DMP_ClearDmpFlag(DMP_FLAG_BGM_MODE);
            #endif
            }
        #endif
            if(m_enDmpVar.enDmpFlag & DMP_FLAG_MEDIA_FILE_PLAYING)
            {
                MApp_MPlayer_Stop();
                MApp_DMP_ClearDmpFlag(DMP_FLAG_MEDIA_FILE_PLAYING);
            }
        }
        break;

        default:
            break;
    }

    m_enDmpVar.enDmpState = DMP_STATE_UI;
    m_enDmpVar.enDmpUiState = enState;
}

BOOLEAN MApp_DMP_GotoMainMenu(void)
{
    if ( (m_enDmpVar.enDmpState == DMP_STATE_INIT
        ||m_enDmpVar.enDmpState == DMP_STATE_WAIT
        ||m_enDmpVar.enDmpState == DMP_STATE_UI )
        && (m_enDmpVar.enDmpUiState != DMP_UI_STATE_LOADING)
        )
    {
        m_enDmpVar.enDmpState = DMP_STATE_GOTO_MENU;
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}
#if CUS_SMC_ENABLE_HOTEL_MODE
BOOLEAN MApp_DMP_GotoHotel(void)
{
    if ( (m_enDmpVar.enDmpState == DMP_STATE_INIT
        ||m_enDmpVar.enDmpState == DMP_STATE_WAIT
        ||m_enDmpVar.enDmpState == DMP_STATE_UI )
        && (m_enDmpVar.enDmpUiState != DMP_UI_STATE_LOADING)
        )
    {
        m_enDmpVar.enDmpState = DMP_STATE_GOTO_HOTEL;
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}
#endif
BOOLEAN MApp_DMP_GotoInputSrcMenu(void)
{
    if ( (m_enDmpVar.enDmpState == DMP_STATE_INIT
        ||m_enDmpVar.enDmpState == DMP_STATE_WAIT
        ||m_enDmpVar.enDmpState == DMP_STATE_UI)
        && (m_enDmpVar.enDmpUiState != DMP_UI_STATE_LOADING)
        )
    {
        m_enDmpVar.enDmpState = DMP_STATE_GOTO_INPUTSOURCE;
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}

BOOLEAN MApp_DMP_GotoPreSrc(void)
{
    if ( m_enDmpVar.enDmpState == DMP_STATE_INIT
       ||m_enDmpVar.enDmpState == DMP_STATE_WAIT
       ||m_enDmpVar.enDmpState == DMP_STATE_UI )
    {
        m_enDmpVar.enDmpState = DMP_STATE_GOTO_PREV_SRC;
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}

BOOLEAN MApp_DMP_IsFileTypeByIdx(U16 u16Idx)
{
    MPlayerFileInfo stFileInfo;

    if ( E_MPLAYER_RET_OK ==
         MApp_MPlayer_QueryFileInfo(E_MPLAYER_INDEX_CURRENT_DIRECTORY, u16Idx, &stFileInfo) )
    {
        if(!(stFileInfo.eAttribute & E_MPLAYER_FILE_DIRECTORY))
        {
            return TRUE;
        }
    }

    return FALSE;
}

U16 MApp_DMP_QueryTotalPlayListNum(void)
{
    U16 u16PlayListNum = MApp_MPlayer_QuerySelectedFileNum(MApp_MPlayer_QueryCurrentMediaType());

    if (MApp_MPlayer_QueryPlayMode() == E_MPLAYER_PLAY_ONE_DIRECTORY
     || MApp_MPlayer_QueryPlayMode() == E_MPLAYER_PLAY_ONE_DIRECTORY_FROM_CURRENT)
    {
        u16PlayListNum = MApp_MPlayer_QueryTotalFileNum() - MApp_MPlayer_QueryDirectoryNumber();
    }

    return u16PlayListNum;
}

void MApp_DMP_GetZUIFbAttr(GOP_GwinFBAttr *pFbAttr)
{
    GRAPHIC_DC *dc = MApp_ZUI_API_GetScreenDC();

    MApi_GOP_GWIN_GetFBInfo(dc->u8FbID, pFbAttr);
}

void MApp_DMP_SetDMPStat(EN_DMP_STATE stat)
{
    m_enDmpVar.enDmpState = stat;
}

EN_DMP_STATE MApp_DMP_GetDMPStat(void)
{
    return m_enDmpVar.enDmpState;
}

BOOLEAN MApp_DMP_GotoCurSrc(void)
{
    m_enDmpVar.enDmpState = DMP_STATE_GOTO_CUR_SRC;
    return TRUE;
}

#endif // #if (ENABLE_DMP)


#undef MAPP_DMP_MAIN_C

