////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MAPP_ZUI_CTL_SLIDEBAR_H
#define _MAPP_ZUI_CTL_SLIDEBAR_H

#ifdef __cplusplus
extern "C" {
#endif  /* __cplusplus */

#ifdef MAPP_ZUI_CTL_SLIDEBAR_C
#define INTERFACE
#else
#define INTERFACE extern
#endif


typedef enum
{
    E_SLIDEBAR_STYLE_MID,
    E_SLIDEBAR_STYLE_MID_CENTERBALL,
    E_SLIDEBAR_STYLE_L_M_R,
    E_SLIDEBAR_STYLE_L_M_R_CENTERBALL,

    E_SLIDEBAR_STYLE_NONE = 0xFF,
} SLIDEBAR_STYLE;

typedef struct
{
    OSDCP_EN_BITMAP_INDEX enNormalIdx;
    OSDCP_EN_BITMAP_INDEX enFocusIdx;
    OSDCP_EN_BITMAP_INDEX enDisableIdx;
} SLIDEBAR_BITMAP_INDEX;

typedef struct
{
    S16 width;
    S16 height;
    SLIDEBAR_BITMAP_INDEX stValue;
    SLIDEBAR_BITMAP_INDEX stNonValue;
} SLIDEBAR_BITMAP_INFO;

typedef struct
{
    BOOLEAN bVertical;
    SLIDEBAR_STYLE enSlideBarStyle;
    void *pBitmapStyle;
    SLIDEBAR_BITMAP_INFO stLeft;
    SLIDEBAR_BITMAP_INFO stMid;
    SLIDEBAR_BITMAP_INFO stRight;
    SLIDEBAR_BITMAP_INFO stCenterBall;
} ST_SLIDEBAR_PARAM;

//////Slide Bar control////////////////////////////////////////////////////
INTERFACE void MApp_ZUI_CTL_SlideBarSetParam(ST_SLIDEBAR_PARAM stParam);

INTERFACE S32 MApp_ZUI_CTL_SlideBarWinProc(HWND, PMSG);


///////////////////////////////////////////////////////////////////////////////////////
/// MACRO
///

#undef INTERFACE

#ifdef __cplusplus
}
#endif  /* __cplusplus */

#endif /* _MAPP_ZUI_CTL_SLIDEBAR_H */

