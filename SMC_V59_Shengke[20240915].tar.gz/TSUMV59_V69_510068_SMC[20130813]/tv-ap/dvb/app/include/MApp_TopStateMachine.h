////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef MAPP_TOPSTATEMACHINE_H
#define MAPP_TOPSTATEMACHINE_H

typedef enum
{
    STATE_TOP_CHANNELCHANGE,
    STATE_TOP_DTV_SCAN,
    STATE_TOP_ATV_SCAN,

#if ENABLE_SBTVD_BRAZIL_APP
    STATE_TOP_CATV_SCAN,
#endif

    STATE_TOP_DIGITALINPUTS,
    STATE_TOP_MENU,
    STATE_TOP_INSTALLGUIDE,
    STATE_TOP_DTV_MANUAL_TUNING,
    STATE_TOP_ATV_MANUAL_TUNING,
    STATE_TOP_INPUTSOURCE,
    STATE_TOP_STANDBY,
    STATE_TOP_TTX,
    STATE_TOP_ANALOG_SHOW_BANNER,
	STATE_TOP_FATORY_MENU,
#if (ENABLE_DTV_EPG)
    STATE_TOP_EPG,
#endif

    STATE_TOP_OSDPAGE,
    STATE_TOP_USB_DOWNLOAD,

#if ENABLE_OAD
    STATE_TOP_OAD,
#endif

#if (ENABLE_SUBTITLE)
    STATE_TOP_SUBTITLE,
#endif

#if ENABLE_CI
    STATE_TOP_MMI,
#endif

#if ENABLE_DMP
    STATE_TOP_DMP,
    STATE_TOP_APENGINE,
#endif

#ifdef ENABLE_BT
    STATE_TOP_BT,
#endif

#ifdef ENABLE_KTV
    STATE_TOP_KTV,
#endif

#if (ENABLE_GAME)
    STATE_TOP_APGAME,
#endif

#if(ENABLE_PVR ==1)
    STATE_TOP_PVR,
#endif

#if DVB_C_ENABLE
    STATE_TOP_CADTV_MANUAL_TUNING,
#endif

#if ((BRAZIL_CC )|| (ATSC_CC == ATV_CC))
    STATE_TOP_CLOSEDCAPTION,
#endif

#if (ENABLE_UPDATE_MULTIPLEX_VIA_NIT)
    STATE_TOP_SCAN_NEW_MUX,
#endif

#if (OBA2 && PARTIALLY_UPDATE && !defined(UI2_OBAMA))
    STATE_TOP_UPGRADE,
#endif

} EN_TOP_STATE;


#ifdef MAPP_TOPSTATEMACHINE_C
#define INTERFACE
#else
#define INTERFACE extern
#endif

INTERFACE void MApp_TopStateMachine(void);
INTERFACE EN_TOP_STATE MApp_TopStateMachine_GetTopState(void);
INTERFACE char* MApp_TopStateMachine_GetTopStateName(void);
INTERFACE void MApp_TopStateMachine_SetTopState(EN_TOP_STATE enSetTopState);

#undef INTERFACE
#endif

