////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
/// @file MApp_BT.c
/// @brief Bit-torrent download kernel
/// @author MStar Semiconductor Inc.
///
/// Bit-torrent download kernel provide a simple interface to let users implement
/// BT download on MStar chip.
///
///////////////////////////////////////////////////////////////////////////////

#define MAPP_BT_C

#include <stdio.h>
#include <string.h>
#include "ctype.h"
#include "datatype.h"

#ifdef ENABLE_BT

#include "MApp_BT_config.h"

#if (ENABLE_THUNDER_DOWNLOAD)
#include "MApp_Thunder.c"

#else
#include "SysInit.h"
#include "drvCPU.h"
#include "sysinfo.h"
#include "GPIO.h"
#include "BinInfo.h"

//#include "drvMMAP.h"

#include "msAPI_Memory.h"
#include "msAPI_MIU.h"
#include "msAPI_Timer.h"
#include "apiGOP.h"
#include "IOUtil.h"
#include "msAPI_Flash.h"
#include "msAPI_DrvInit.h"
#include "msAPI_JPEG_MM.h"
#include "msAPI_APEngine.h"

#include "MApp_GlobalVar.h"
#include "MApp_BT.h"
#include "MApp_BT_Main.h"
#include "mapp_jpeg_mm.h"
#include "MApp_Exit.h"

#include "mapp_gb2unicode.h"
#include "mapp_big52unicode.h"
#include "MApp_CharTable.h"
#include "MApp_Audio.h"
#include "MApp_Logo.h"
#include "MApp_SaveData.h"
#include "MApp_InputSource.h"

#include "mapp_photo.h"

//*****************************************************************************
//              Definitions
//*****************************************************************************
#define BT_DBG(x)                  x

#define BT_DECODE_JPEG_METHOD_0                  0


//*****************************************************************************
//              enums
//*****************************************************************************


//*****************************************************************************
//              Data structure
//*****************************************************************************


//*****************************************************************************
//              Global variables
//*****************************************************************************
BT_Init_State u8BtInitState = STATE_SYSTEM_INIT_NONE;

U8 u8DownloadListFileNum = 0;

TorrentFileInfo uDownloadListFileInfo[5];

U32 u32ImageFileSize = 0;
U32 u32currentImageFileID = 0;
U32 u32DescriptionFileSize = 0;
U32 u32currentDescriptionFileID = 0;
U8 u8BT_ImageConut = 0;

U32 u32SearchFileNum = NUM_OF_SEARCH_LIST_FILES_MAX; //0;
BT_Search_State u8SearchState = STATE_SEARCH_NONE;
BT_Get_Image_State u8GetImageState = STATE_GET_IMAGE_INIT;
BT_Get_Description_State u8GetDescriptionState = STATE_GET_DESCRIPTION_NONE;

SearchTorrentListFileInfo uSearchTListFileInfo[NUM_OF_TOP_FILES_MAX];
U8 *u8UTF8Sting;
BOOLEAN bBtBuff1Lock = FALSE;
BOOLEAN bBtBuff2Lock = FALSE;
U8 u8DownloadListState = STATE_DOWNLOADLIST_NONE;
U8 u8BTErrorState = 0;
U8 u8BTMailBoxOKState = 0;

#define CHAR_CONVER_BUFFER ((LPTSTR)CHAR_BUFFER)

U8 code _Quesy_CMD1[]={"query_keyword0="};
U8 code _Quesy_CMD2[]={"&query_result_start_index="};
U8 code _Quesy_CMD3[]={"&query_result_tot_cnt="};
U8 code _Quesy_CMD4[]={"get_torrent_path_utf8="};
U8 code _Quesy_CMD5[]={"query_orderby="};
U8 code _Quesy_CMD6[]={"get_image_path_utf8="};
U8 code _Quesy_CMD7[]={"get_description_path_utf8="};
U8 code _Quesy_CMD8[]={"&query_orderdir="};

BT_JPEG_State u8BT_JPEG_State = STATE_BT_JPEG_NONE;

static MainLink0Status m_MainLink0Status[NUM_OF_MAINLINK0_PHOTO_PER_PAGE];
static MainLink1Status m_MainLink1Status[NUM_OF_MAINLINK1_PHOTO_PER_PAGE];

//*****************************************************************************
//              Local variables
//*****************************************************************************
//only for testing
#define TORRENT_FILE_BUFFER_ADR         0x100000 // need move to memory setting file

#if 0
TorrentFileInfo code TorrentFileTest[NUM_OF_TORRENT_FILES_PER_PAGE]=
{
    {
        {0x61,,0x62,,0x63,,'\0'},//abc
        {"tor"},//tor
        0x00,
        0x6400000,//100M
        0xA00000,//10M
        0x400,// 1kb/s
    },
    {
        {0x61,,0x62,,0x63,,0x31,,'\0'},//abc1
        {"tor"},//tor
        0x00,
        0xC800000,//200M
        0x6400000,//100M
        0x200,// 512b/s
    },
    {
        {0x61,,0x62,,0x63,,0x32,,'\0'},//abc2
        {"tor"},//tor
        0x00,
        0x19000000,//400M
        0x6400000,//100M
        0x19000,// 100kb/s
    },
    {
        {0x4E,0x2D,0x2D,0x4E,0x63,0x00,0x31,,'\0'},//�й�c1
        {"tor"},//tor
        0x00,
        0x32000000,//800M
        0xA00000,//10M
        0x19000,// 100kb/s
    },
    {
        {"�й�1"},//�й�
        {"tor"},//tor
        0x00,
        0x64000000,// 1.6G
        0x19000000,//400M
        0x19000,// 100kb/s
    },
};
#endif

#if 0
MainLink0Info code MainLink0Test[NUM_OF_MAINLINK0_PHOTO_PER_PAGE]=
{// must be unicode
    {
        {0x61,0x00,0x62,0x00,0x63,0x00,'\0'},//abc
        {0x61,0x00,0x62,0x00,0x63,0x00,'\0'},//abc
        {0x61,0x00,0x62,0x00,0x63,0x00,'\0'},//abc
    },
    {
        {0x61,0x00,0x62,0x00,0x63,0x00,0x31,0x00,'\0'},//abc1
        {0x61,0x00,0x62,0x00,0x63,0x00,0x31,0x00,'\0'},//abc1
        {0x61,0x00,0x62,0x00,0x63,0x00,0x31,0x00,'\0'},//abc1
    },
    {
        {0x61,0x00,0x62,0x00,0x63,0x00,0x32,0x00,'\0'},//abc2
        {0x61,0x00,0x62,0x00,0x63,0x00,0x32,0x00,'\0'},//abc2
        {0x61,0x00,0x62,0x00,0x63,0x00,0x32,0x00,'\0'},//abc2
    },
    {
        {0x61,0x00,0x62,0x00,0x63,0x00,0x33,0x00,'\0'},//abc3
        {0x61,0x00,0x62,0x00,0x63,0x00,0x33,0x00,'\0'},//abc3
        {0x61,0x00,0x62,0x00,0x63,0x00,0x33,0x00,'\0'},//abc3
    },
    {
        {0x61,0x00,0x62,0x00,0x63,0x00,0x34,0x00,'\0'},//abc4
        {0x61,0x00,0x62,0x00,0x63,0x00,0x34,0x00,'\0'},//abc4
        {0x61,0x00,0x62,0x00,0x63,0x00,0x34,0x00,'\0'},//abc4
    },
    {
        {0x61,0x00,0x62,0x00,0x63,0x00,0x35,0x00,'\0'},//abc5
        {0x61,0x00,0x62,0x00,0x63,0x00,0x35,0x00,'\0'},//abc5
        {0x61,0x00,0x62,0x00,0x63,0x00,0x35,0x00,'\0'},//abc5
    },
};

MainLink1Info code MainLink1Test[NUM_OF_MAINLINK1_PHOTO_PER_PAGE]=
{// must be unicode
    {
        {0x61,0x00,0x62,0x00,0x63,0x00,'\0'},//abc
        {0x61,0x00,0x62,0x00,0x63,0x00,'\0'},//abc
        {0x61,0x00,0x62,0x00,0x63,0x00,'\0'},//abc
    },
    {
        {0x61,0x00,0x62,0x00,0x63,0x00,0x31,0x00,'\0'},//abc1
        {0x61,0x00,0x62,0x00,0x63,0x00,0x31,0x00,'\0'},//abc1
        {0x61,0x00,0x62,0x00,0x63,0x00,0x31,0x00,'\0'},//abc1
    },
    {
        {0x61,0x00,0x62,0x00,0x63,0x00,0x32,0x00,'\0'},//abc2
        {0x61,0x00,0x62,0x00,0x63,0x00,0x32,0x00,'\0'},//abc2
        {0x61,0x00,0x62,0x00,0x63,0x00,0x32,0x00,'\0'},//abc2
    },
    {
        {0x61,0x00,0x62,0x00,0x63,0x00,0x33,0x00,'\0'},//abc3
        {0x61,0x00,0x62,0x00,0x63,0x00,0x33,0x00,'\0'},//abc3
        {0x61,0x00,0x62,0x00,0x63,0x00,0x33,0x00,'\0'},//abc3
    },
    {
        {0x61,0x00,0x62,0x00,0x63,0x00,0x34,0x00,'\0'},//abc4
        {0x61,0x00,0x62,0x00,0x63,0x00,0x34,0x00,'\0'},//abc4
        {0x61,0x00,0x62,0x00,0x63,0x00,0x34,0x00,'\0'},//abc4
    },
    {
        {0x61,0x00,0x62,0x00,0x63,0x00,0x35,0x00,'\0'},//abc5
        {0x61,0x00,0x62,0x00,0x63,0x00,0x35,0x00,'\0'},//abc5
        {0x61,0x00,0x62,0x00,0x63,0x00,0x35,0x00,'\0'},//abc5
    },
};
#endif


#if 0
//NUM_OF_SEARCH_LIST_FILES_MAX
SearchListFileInfo code SearchFileListTest[NUM_OF_SEARCH_LIST_FILES_MAX]=
{// must be unicode
    {
        {0x61,0x62,0x63,0x30,0x31, '\0'},//abc1
        {"RMVB"},
        0x6400000,//100M
    },
    {
        {0x61,0x62,0x63,0x30,0x32, '\0'},//abc2
        {"RM"},
        0x6400000,//100M
    },
    {
        {0x61,0x62,0x63,0x30,0x33, '\0'},//abc3
        {"AVI"},
        0x6400000,//100M
    },
    {
        {0x61,0x62,0x63,0x30,0x34, '\0'},//abc4
        {"MPEG"},
        0x64000000,// 1.6G
    },
    {
        {0x61,0x62,0x63,0x30,0x35, '\0'},//abc5
        {"DAT"},
        0x6400000,//100M
    },
    {
        {0x61,0x62,0x63,0x30,0x36, '\0'},//abc6
        {"MP4"},
        0x6400000,//100M
    },
    {
        {0x61,0x62,0x63,0x30,0x37, '\0'},//abc7
        {"MP3"},
        0x500000,//10M
    },
    {
        {0x61,0x62,0x63,0x30,0x38, '\0'},//abc8
        {"AAC"},
        0x480000,//10M
    },
    {
        {0x61,0x62,0x63,0x30,0x39, '\0'},//abc9
        {"WMA"},
        0x510000,//10M
    },
    {
        {0x61,0x62,0x63,0x31,0x30, '\0'},//abc10
        {"BMP"},
        0x6400000,//100M
    },
    {
        {0x61,0x62,0x63,0x31,0x31, '\0'},//abc11
        {"JEPG"},
        0x6400000,//100M
    },
    {
        {0x61,0x62,0x63,0x31,0x32, '\0'},//abc12
        {"NPG"},
        0x6400000,//100M
    },
};
#endif
//*****************************************************************************
//              Local Functions Prototype
//*****************************************************************************


//*****************************************************************************
//              Local Functions
//*****************************************************************************
extern void FS_ASCII2Unicode(U8 *pu8FileName);
extern U16 *MApp_GetSearchStingName(void);

/******************************************************************************/
///-Convert  UCS2 to UTF8
///@param pu16srcStr \b IN
///@param pu8dstStr \b IN
///@param srcWideCharLen \b IN
///@param dstByteLen \b IN
///- pu16srcStr ...
///- pu8dstStr ...
///- srcWideCharLen ...
///- dstByteLen ...
/******************************************************************************/
void msAPI_MappinUCS2ToUTF8(U16 *pu16srcStr, U8 *pu8dstStr, U16 srcWideCharLen, U16 dstByteLen)
{
    U16 u16Value, i, j;

    if ((pu16srcStr == 0) || (srcWideCharLen == 0) || (pu8dstStr == 0) || (dstByteLen <= 1)) return;

    for (i=0, j=0; i<srcWideCharLen && j<dstByteLen-1; i++, j++)
    {
        u16Value = pu16srcStr[i];
        if (u16Value == 0)
        {
            break;
        }

        if(u16Value < 0x80)
        {
            // 0000 - 007F -> 0xxxxxxx
            pu8dstStr[j] = (U8)u16Value;
        }
        else if( u16Value < 0x800)
        {
            //0080 - 07FF -> 110xxxxx 10xxxxxx
            pu8dstStr[j] = (U8)( (0x80) | (u16Value & 0x3F) );
            pu8dstStr[j+1] = (U8)( (0xC0) | ((u16Value>>6) & 0x1F) );
            j +=1;
        }
        else if(u16Value> 0x7FF)
        {
            //0800 - FFFF - > 1110xxxx 10xxxxxx 10xxxxxx
            pu8dstStr[j+2] = (U8)( (0x80) | (u16Value & 0x3F) );
            pu8dstStr[j+1] = (U8)( (0x80) | ((u16Value>>6) & 0x3F) );
            pu8dstStr[j] = (U8)( (0xE0) | ((u16Value>>12) & 0x0F) );
            j +=2;
        }
        else
        {
            // Unknown, skip
            if( j>0 )
                j--;
        }
    }

    // NULL termination character
    pu8dstStr[j] = 0;
}

/******************************************************************************/
// Function:        msAPI_Mappin_UCS2ToHEX
// Description:     This function will convert UCS2 encoded string to Hex encoded string.
//                        If the UCS2 character is the readable one, convert to one-byte ASCII. If not,
//                        convert to 2 Hex string, such as %4E00.
///@param pu16srcStrUCS2 \b IN          //UCS2 encoded string
///@param pu8dstStrHex \b OUT           // Hex encoded string
/******************************************************************************/
void msAPI_Mappin_UCS2ToHEX(U16 *pu16srcStrUCS2, U8 *pu8dstStrHex)
{
    if(pu16srcStrUCS2)
    {
        int i,j;

        for(i=0,j=0;pu16srcStrUCS2[i]!=0x0000;i++)
        {
            if(((pu16srcStrUCS2[i]>=0x0061)&&(pu16srcStrUCS2[i]<=0x007A))||    /* a~z */
               ((pu16srcStrUCS2[i]>=0x0041)&&(pu16srcStrUCS2[i]<=0x005A))||    /* A~Z */
               ((pu16srcStrUCS2[i]>=0x0030)&&(pu16srcStrUCS2[i]<=0x0039))||    /* 0~9 */
               (pu16srcStrUCS2[i]==0x005F)||(pu16srcStrUCS2[i]==0x002E))       /* _ . */
            {
                pu8dstStrHex[j++]=(char)pu16srcStrUCS2[i];
            }
            else
            {
                snprintf((char *)(pu8dstStrHex+j),  5, "%%%04X", pu16srcStrUCS2[i]);
                j+=5;
            }
        }
        pu8dstStrHex[j]=0x00;
    }
}


//*****************************************************************************
//Sender: AEON
//Receiver: BEON
//@param uBtMailBoxPara \b IN
//*****************************************************************************
BOOLEAN MApp_BT_SendMailBox(MBX_Msg uBtMailBoxPara)
{
    U8 u8Cont, u8Max;
    U32 u32Timer;
    MBX_Msg mbxMsg;

    //printf("MApp_BT_SetDamonParam!\n");
    mbxMsg.eMsgType = E_MBX_MSG_TYPE_NORMAL;
    mbxMsg.u8MsgClass = MB_CLASS_BTPD;
    mbxMsg.u8Index = uBtMailBoxPara.u8Index;
    mbxMsg.u8ParameterCount = uBtMailBoxPara.u8ParameterCount;

    u8Max = uBtMailBoxPara.u8ParameterCount;
    if(u8Max> 10)
        u8Max = 10;
    for(u8Cont = 0; u8Cont<u8Max; u8Cont++)
        mbxMsg.u8Parameters[u8Cont] = uBtMailBoxPara.u8Parameters[u8Cont];

    u32Timer  = msAPI_Timer_GetTime0();
    while(msAPI_Timer_DiffTimeFromNow(u32Timer) < 500)
    {
        #if( WATCH_DOG == ENABLE )
        msAPI_Timer_ResetWDT();
        #endif

        if(E_MBX_SUCCESS == MApi_MBX_SendMsg(&mbxMsg))
        {
            break;
        }
    }
    return FALSE;
}

//*****************************************************************************
//Sender: AEON
//Receiver: BEON
//Receiver requests Sender to unlock memory.
//*****************************************************************************
BOOLEAN MApp_BT_SendUnLockMemory(void)
{
    BOOLEAN bRet;
    MBX_Msg uMailBoxPara;

    uMailBoxPara.u8Index = MB_BTC_UNLOCKMEM_A;
    uMailBoxPara.u8ParameterCount = 0;
    bRet = MApp_BT_SendMailBox(uMailBoxPara);

    if(!bRet)
        printf("MApp_BT_SendUnLockMemoty Failed\n");

    return bRet;
}


//*****************************************************************************
//Sender: AEON
//Receiver: BEON
//ParamCount = 8
//Params[0]~[3] = Memory Size (big-endian)
//Params[4]~[7] = Memory Address (big-endian)
//*****************************************************************************
BOOLEAN MApp_BT_Set_HK_To_Beon_Memory_Addr(void)
{
    BOOLEAN bRet;
    U32 u32addr;
    MBX_Msg uMailBoxPara;

    //printf("MApp_BT_Set_HK_To_Beon_Memory_Addr!\n");
    printf("Addr1[%lx]!\n", BT_HK_TO_BEON_SHAER_BUFFER_ADR);
    printf("Addr1Size[%lx]!\n", BT_HK_TO_BEON_SHAER_BUFFER_LEN);

    u8UTF8Sting = (U8 *)((BT_HK_TO_BEON_SHAER_BUFFER_MEMORY_TYPE & MIU1) ? (BT_HK_TO_BEON_SHAER_BUFFER_ADR | MIU_INTERVAL) : (BT_HK_TO_BEON_SHAER_BUFFER_ADR));

    // set Parameter
    uMailBoxPara.u8Index = MB_BTC_SETMEMADDR1;
    uMailBoxPara.u8ParameterCount = 8;

    // set size
    uMailBoxPara.u8Parameters[0] = (U8)(BT_HK_TO_BEON_SHAER_BUFFER_LEN>>24);
    uMailBoxPara.u8Parameters[1] = (U8)(BT_HK_TO_BEON_SHAER_BUFFER_LEN>>16);
    uMailBoxPara.u8Parameters[2] = (U8)(BT_HK_TO_BEON_SHAER_BUFFER_LEN>>8);
    uMailBoxPara.u8Parameters[3] = (U8)(BT_HK_TO_BEON_SHAER_BUFFER_LEN);

    // set address
    u32addr = (((BT_HK_TO_BEON_SHAER_BUFFER_MEMORY_TYPE & MIU1) ? (BT_HK_TO_BEON_SHAER_BUFFER_ADR | MIU_INTERVAL) : (BT_HK_TO_BEON_SHAER_BUFFER_ADR))|0x80000000UL);// - ((BEON_MEM_MEMORY_TYPE & MIU1) ? (BEON_MEM_ADR | MIU_INTERVAL) : ( BEON_MEM_ADR)))|0x80000000UL;
    uMailBoxPara.u8Parameters[4] = (U8)(u32addr>>24);
    uMailBoxPara.u8Parameters[5] = (U8)(u32addr>>16);
    uMailBoxPara.u8Parameters[6] = (U8)(u32addr>>8);
    uMailBoxPara.u8Parameters[7] = (U8)(u32addr) ;

    bRet = MApp_BT_SendMailBox(uMailBoxPara);

    if(!bRet)
        printf("MApp_BT_Set_HK_To_Beon_Memory_Addr Failed\n");

    return bRet;
}

//*****************************************************************************
//Sender: AEON
//Receiver: BEON
//ParamCount = 8
//Params[0]~[3] = Memory Size (big-endian)
//Params[4]~[7] = Memory Address (big-endian)
//*****************************************************************************
BOOLEAN  MApp_BT_Set_Beon_To_HK_Memory_Addr(void)
{
    BOOLEAN bRet;
    U32 u32addr;
    MBX_Msg uMailBoxPara;

    //printf("MApp_BT_Set_Beon_To_HK_Memory_Addr!\n");
    printf("Addr2[%lx]!\n", ((BT_BEON_TO_HK_SHAER_BUFFER_MEMORY_TYPE & MIU1) ? (BT_BEON_TO_HK_SHAER_BUFFER_ADR | MIU_INTERVAL) : (BT_BEON_TO_HK_SHAER_BUFFER_ADR)));
    printf("Addr2Size[%lx]!\n", BT_BEON_TO_HK_SHAER_BUFFER_LEN);

    // set Parameter
    uMailBoxPara.u8Index = MB_BTC_SETMEMADDR2;
    uMailBoxPara.u8ParameterCount = 8;

    // set size
    uMailBoxPara.u8Parameters[0] = (U8)(BT_BEON_TO_HK_SHAER_BUFFER_LEN>>24);
    uMailBoxPara.u8Parameters[1] = (U8)(BT_BEON_TO_HK_SHAER_BUFFER_LEN>>16);
    uMailBoxPara.u8Parameters[2] = (U8)(BT_BEON_TO_HK_SHAER_BUFFER_LEN>>8);
    uMailBoxPara.u8Parameters[3] = (U8)BT_BEON_TO_HK_SHAER_BUFFER_LEN;

    // set address
    u32addr = (((BT_BEON_TO_HK_SHAER_BUFFER_MEMORY_TYPE & MIU1) ? (BT_BEON_TO_HK_SHAER_BUFFER_ADR | MIU_INTERVAL) : (BT_BEON_TO_HK_SHAER_BUFFER_ADR)) |0x80000000UL);//(BT_BEON_TO_HK_BUFFER_ADR - ((BEON_MEM_MEMORY_TYPE & MIU1) ? (BEON_MEM_ADR | MIU_INTERVAL) : ( BEON_MEM_ADR))) |0x80000000UL;
    uMailBoxPara.u8Parameters[4] = (U8)(u32addr>>24);
    uMailBoxPara.u8Parameters[5] = (U8)(u32addr>>16);
    uMailBoxPara.u8Parameters[6] = (U8)(u32addr>>8);
    uMailBoxPara.u8Parameters[7] = (U8)(u32addr);

    bRet = MApp_BT_SendMailBox(uMailBoxPara);

    if(!bRet)
        printf("MApp_BT_Set_Beon_To_HK_Memory_Addr Failed\n");

    return bRet;
}

//*****************************************************************************
//Sender: AEON
//Receiver: BEON
//ParamCount = 7
//Params[0]~[1] = Port Number (big-endian)
//Params[2]~[3] = Net In BandWidth (big-endian)
//Params[4]~[5] = Net Out BandWidth (big-endian)
//Params[6] = Max tasks
//*****************************************************************************
BOOLEAN MApp_BT_SetDamonParam(MS_TorrentSetupInfo *pTorrentSetup)
{
    BOOLEAN bRet;
    MBX_Msg uMailBoxPara;

    // set Parameter
    uMailBoxPara.u8Index= MB_BTC_SETDAEMONPARAM;
    uMailBoxPara.u8ParameterCount = 7;

    // Port Number (big-endian)
    uMailBoxPara.u8Parameters[0] = (U8)((pTorrentSetup->u16port)>>8) ;
    uMailBoxPara.u8Parameters[1] = (U8)(pTorrentSetup->u16port);
    //Net In BandWidth (big-endian)
    uMailBoxPara.u8Parameters[2] = (U8)((pTorrentSetup->u16DownloadLimit)>>8);
    uMailBoxPara.u8Parameters[3] = (U8)(pTorrentSetup->u16DownloadLimit);
    //Net Out BandWidth (big-endian)
    uMailBoxPara.u8Parameters[4] = (U8)((pTorrentSetup->u16UploadLimit)>>8);
    uMailBoxPara.u8Parameters[5] = (U8)(pTorrentSetup->u16UploadLimit);
    //Max tasks
    uMailBoxPara.u8Parameters[6] = (U8)(pTorrentSetup->u8MaxSession);

    bRet = MApp_BT_SendMailBox(uMailBoxPara);

    if(!bRet)
        printf("MApp_BT_SetDamonParam Failed\n");

    return bRet;
}


//*****************************************************************************
//Sender: AEON
//Receiver: BEON
//ParamCount = 0
//*****************************************************************************
BOOLEAN MApp_BT_StarDamon(void)
{
    BOOLEAN bRet;
    MBX_Msg uMailBoxPara;

    // set Parameter
    uMailBoxPara.u8Index        = MB_BTC_STARTDAEMON;
    uMailBoxPara.u8ParameterCount        = 0;
    bRet = MApp_BT_SendMailBox(uMailBoxPara);

    if(!bRet)
        printf("MApp_BT_StarDamon Failed\n");

    return bRet;
}

//*****************************************************************************
//Sender: AEON
//Receiver: BEON
//ParamCount = 0
//*****************************************************************************
BOOLEAN MApp_BT_StopDamon(void)
{
    BOOLEAN bRet;
    MBX_Msg uMailBoxPara;

    // set Parameter
    uMailBoxPara.u8Index        = MB_BTC_STOPDAEMON;
    uMailBoxPara.u8ParameterCount        = 0;
    bRet = MApp_BT_SendMailBox(uMailBoxPara);

    if(!bRet)
        printf("MApp_BT_StopDamon Failed\n");

    return bRet;
}

//*****************************************************************************
//Sender: AEON
//Receiver: BEON
//ParamCount = 0
//*****************************************************************************
BOOLEAN MApp_BT_CheckNetWork(void)
{
    BOOLEAN bRet;
    MBX_Msg uMailBoxPara;

    // set Parameter
    uMailBoxPara.u8Index        = MB_BTC_CHECK_NETWORK;
    uMailBoxPara.u8ParameterCount        = 0;
    bRet = MApp_BT_SendMailBox(uMailBoxPara);

    if(!bRet)
        printf("MApp_BT_CheckNetWork Failed\n");

    return bRet;
}


//*****************************************************************************
//Sender: AEON
//Receiver: BEON
//ParamCount = 0
//*****************************************************************************
BOOLEAN MApp_BT_CheckStorage(void)
{
    BOOLEAN bRet;
    MBX_Msg uMailBoxPara;

    // set Parameter
    uMailBoxPara.u8Index        = MB_BTC_CHECK_STORAGE;
    uMailBoxPara.u8ParameterCount        = 0;
    bRet = MApp_BT_SendMailBox(uMailBoxPara);

    if(!bRet)
        printf("MApp_BT_CheckStorage Failed\n");

    return bRet;
}

//*****************************************************************************
//Sender: AEON
//Receiver: MIPS
//ParamCount @ Memory buffer.
//Refer to Torrent Client HTTP Commands
//*****************************************************************************
BOOLEAN MApp_BT_SetTorrentServerAddr(U16 *pu16UnicodeString)
{
    BOOLEAN bRet;
    U16 u16Cont, u16Len;
    MBX_Msg uMailBoxPara;

    if(bBtBuff1Lock)
    {
        if(MApp_BT_MailBoxHandle(500, MB_BTC_UNLOCKMEM_M, &uMailBoxPara))
            bBtBuff1Lock = FALSE;
        else
            return FALSE;
    }

    for( u16Cont = 0, u16Len = 0; u16Cont<256; u16Cont++)
    {
        if(pu16UnicodeString[u16Cont]==0)
        {
            u16Len = u16Cont;
            break;
        }
    }

    bBtBuff1Lock = TRUE;

    msAPI_MappinUCS2ToUTF8(pu16UnicodeString, (U8 *)u8UTF8Sting, u16Len, 255);

    // set Parameter
    uMailBoxPara.u8Index        = MB_BTC_SETTORRENTSVR;
    uMailBoxPara.u8ParameterCount        = 0;
    bRet = MApp_BT_SendMailBox(uMailBoxPara);

    if(!bRet)
        printf("MApp_BT_SetTorrentServerAddr Failed\n");

    return bRet;
}


//*****************************************************************************
//Sender: AEON
//Receiver: MIPS
//ParamCount @ Memory buffer.
//Send http command to get the number of the total matched torrents
//Refer to Torrent Client HTTP Commands
//*****************************************************************************
BOOLEAN MApp_BT_GetMatchTorrentTotal(U16 *pu16UnicodeString)
{
    BOOLEAN bRet;
    MBX_Msg uMailBoxPara;
    U16 u16Cont, u16StringLen,u16Len;

    bBtBuff1Lock = FALSE;  //????????????????????????????

    if(bBtBuff1Lock)
    {
        if(MApp_BT_MailBoxHandle(500, MB_BTC_UNLOCKMEM_M, &uMailBoxPara))
            bBtBuff1Lock = FALSE;
        else
        {
            printf("MApp_BT_GetMatchTorrentTotal Failed 0!\n");
            return FALSE;
        }
    }

    for( u16Cont = 0, u16StringLen = 0; u16Cont<256; u16Cont++)
    {
        if(pu16UnicodeString[u16Cont]==0)
        {
            u16StringLen = u16Cont;
            break;
        }
    }

    u16Len = 0;
    for( u16Cont = 0; u16Cont<(sizeof(_Quesy_CMD1)-1); u16Cont++)
        CHAR_CONVER_BUFFER[u16Cont+u16Len] = (U16)(_Quesy_CMD1[u16Cont]);

    u16Len += (sizeof(_Quesy_CMD1)-1);
    for( u16Cont = 0; u16Cont<u16StringLen; u16Cont++)
        CHAR_CONVER_BUFFER[u16Cont+u16Len] = (U16)(pu16UnicodeString[u16Cont]);

    u16Len += u16StringLen;
    for( u16Cont = 0; u16Cont<(sizeof(_Quesy_CMD2)-1); u16Cont++)
        CHAR_CONVER_BUFFER[u16Cont+u16Len] = (U16)(_Quesy_CMD2[u16Cont]);

    u16Len += (sizeof(_Quesy_CMD2)-1);
    CHAR_CONVER_BUFFER[u16Len] = (U16)('0');
    u16Len ++;

    for( u16Cont = 0; u16Cont<(sizeof(_Quesy_CMD3)-1); u16Cont++)
        CHAR_CONVER_BUFFER[u16Cont+u16Len] = (U16)(_Quesy_CMD3[u16Cont]);

    u16Len += (sizeof(_Quesy_CMD3)-1);
    CHAR_CONVER_BUFFER[u16Len] = (U16)('0');
    u16Len ++;

    CHAR_CONVER_BUFFER[u16Len] = (U16)('\0');

/*
    for( u16Cont = 0; u16Cont<=u16Len; u16Cont++)
        printf("P%d_[0x%02x]\n", u16Cont, CHAR_CONVER_BUFFER[u16Cont]);
*/
    bBtBuff1Lock = TRUE;

    msAPI_MappinUCS2ToUTF8((U16 *)CHAR_CONVER_BUFFER, (U8 *)u8UTF8Sting, u16Len, 255);

    // set Parameter
    uMailBoxPara.u8Index        = MB_BTC_HTTPCMD_TTOTAL;
    uMailBoxPara.u8ParameterCount        = 0;
    bRet = MApp_BT_SendMailBox(uMailBoxPara);

    MApp_BT_SetSearchFileState( STATE_SEARCH_GET_RESPONSE_NUM );

    if(!bRet)
        printf("MApp_BT_GetMatchTorrentTotal Failed 1!\n");

    return bRet;
}


//*****************************************************************************
//Sender: AEON
//Receiver: MIPS
//@param pu16UnicodeString \b IN
//@param u16ListStar \b IN
//@param u16ListCont \b IN
//ParamCount @ Memory buffer.
//Send http command to get the number of the total matched torrents
//Refer to Torrent Client HTTP Commands
//*****************************************************************************
BOOLEAN MApp_BT_GetMatchTorrentList(U16 *pu16UnicodeString, U16 u16ListStar, U16 u16ListCont)
{
    BOOLEAN bRet = FALSE;
    U8 u8temp[6];
    MBX_Msg uMailBoxPara;
    U16 u16Cont, u16StringLen, u16Len;


    bBtBuff1Lock = FALSE;  //????????????????????????????
    if(bBtBuff1Lock)
    {
        if(MApp_BT_MailBoxHandle(500, MB_BTC_UNLOCKMEM_M, &uMailBoxPara))
            bBtBuff1Lock = FALSE;
        else
        {
            printf("MApp_BT_GetMatchTorrentList Failed 0 !\n");
            return FALSE;
        }
    }

    for( u16Cont = 0, u16StringLen = 0; u16Cont<256; u16Cont++)
    {
        if(pu16UnicodeString[u16Cont]==0)
        {
            u16StringLen = u16Cont;
            break;
        }
    }

    u16Len = 0;
    for( u16Cont = 0; u16Cont<(sizeof(_Quesy_CMD1)-1); u16Cont++)
        CHAR_CONVER_BUFFER[u16Cont+u16Len] = (U16)(_Quesy_CMD1[u16Cont]);

    u16Len += (sizeof(_Quesy_CMD1)-1);
    for( u16Cont = 0; u16Cont<u16StringLen; u16Cont++)
        CHAR_CONVER_BUFFER[u16Cont+u16Len] = (U16)(pu16UnicodeString[u16Cont]);

    u16Len += u16StringLen;
    for( u16Cont = 0; u16Cont<(sizeof(_Quesy_CMD2)-1); u16Cont++)
        CHAR_CONVER_BUFFER[u16Cont+u16Len] = (U16)(_Quesy_CMD2[u16Cont]);

    u16Len += (sizeof(_Quesy_CMD2)-1);

    snprintf((char*)u8temp, 6, "%d", u16ListStar);
    for( u16Cont = 0; u16Cont<6; u16Cont++)
    {
        if(u8temp[u16Cont] == 0)
            break;

        CHAR_CONVER_BUFFER[u16Len] = (U16)u8temp[u16Cont];
        u16Len ++;
    }

    for( u16Cont = 0; u16Cont<(sizeof(_Quesy_CMD3)-1); u16Cont++)
        CHAR_CONVER_BUFFER[u16Cont+u16Len] = (U16)(_Quesy_CMD3[u16Cont]);

    u16Len += (sizeof(_Quesy_CMD3)-1);
    snprintf((char*)u8temp, 6, "%d", u16ListCont);
    for( u16Cont = 0; u16Cont<6; u16Cont++)
    {
        if(u8temp[u16Cont] == 0)
            break;

        CHAR_CONVER_BUFFER[u16Len] = (U16)u8temp[u16Cont];
        u16Len ++;
    }

    CHAR_CONVER_BUFFER[u16Len] = (U16)('\0');
/*
    for( u16Cont = 0; u16Cont<=u16Len; u16Cont++)
        printf("P%d_[0x%02x]\n", u16Cont, CHAR_CONVER_BUFFER[u16Cont]);
*/

    bBtBuff1Lock = TRUE;

    msAPI_MappinUCS2ToUTF8((U16 *)CHAR_CONVER_BUFFER, (U8 *)u8UTF8Sting, u16Len, 255);

    // set Parameter
    uMailBoxPara.u8Index        = MB_BTC_HTTPCMD_TLIST;
    uMailBoxPara.u8ParameterCount        = 0;
    bRet = MApp_BT_SendMailBox(uMailBoxPara);

    if(!bRet)
        printf("MApp_BT_GetMatchTorrentList Failed\n");

    return bRet;

}


//*****************************************************************************
//Sender: AEON
//Receiver: MIPS
//ParamCount @ Memory buffer.
//Send http command to get the Torrent file
//Refer to Torrent Client HTTP Commands
//*****************************************************************************
BOOLEAN MApp_BT_GetTorrentFile(S32 s32TorrentID)
{
    BOOLEAN bRet = FALSE;
    U8 u8temp[11];
    MBX_Msg uMailBoxPara;
    U16 u16Cont, u16Len;

    MApp_BT_SendUnLockMemory();

    u16Len = 0;
    for( u16Cont = 0; u16Cont<(sizeof(_Quesy_CMD4)-1); u16Cont++)
        CHAR_CONVER_BUFFER[u16Cont+u16Len] = (U16)(_Quesy_CMD4[u16Cont]);

    u16Len += (sizeof(_Quesy_CMD4)-1);

    printf("s32TorrentID = [0x%04x]\n", s32TorrentID);
    snprintf((char*)u8temp, 11, "%d", s32TorrentID);
    for( u16Cont = 0; u16Cont<11; u16Cont++)
    {
        if(u8temp[u16Cont] == 0)
            break;

        CHAR_CONVER_BUFFER[u16Len] = (U16)u8temp[u16Cont];
        u16Len ++;
    }

    bBtBuff1Lock = TRUE;

    msAPI_MappinUCS2ToUTF8((U16 *)CHAR_CONVER_BUFFER, (U8 *)u8UTF8Sting, u16Len, 255);

    // set Parameter
    uMailBoxPara.u8Index        = MB_BTC_HTTPCMD_TGET;
    uMailBoxPara.u8ParameterCount        = 4;

    // set Torrent ID (big-endian)
    uMailBoxPara.u8Parameters[0] = (U8)(s32TorrentID>>24);
    uMailBoxPara.u8Parameters[1] = (U8)(s32TorrentID>>16);
    uMailBoxPara.u8Parameters[2] = (U8)(s32TorrentID>>8);
    uMailBoxPara.u8Parameters[3] = (U8)(s32TorrentID);

    bRet = MApp_BT_SendMailBox(uMailBoxPara);

    if(!bRet)
    {
        printf("MApp_BT_GetTorrentFile Failed\n");
        return bRet;
    }


    // for error handle
    for(u16Cont = 0; u16Cont<100; u16Cont++)
    {
        if(MApp_BT_MailBoxHandle(10, MB_BTC_OK, &uMailBoxPara))
        {

        }
        else if(MApp_BT_MailBoxHandle(10, MB_BTC_FAIL, &uMailBoxPara))
        {

        }
    }

    return bRet;
}


//*****************************************************************************
//Sender: AEON
//Receiver: MIPS
//ParamCount @ Memory buffer.
/// @param  bIsToplist \b IN bIsToplist{1: toplist, 0: Newlist}
//Send http command to get the number of the total matched torrents
//Refer to Torrent Client HTTP Commands
//Toplist: query_order_by=3&query_result_start_index=0&query_result_tot_cnt=6
//Newlist: query_order_by=0&query_result_start_index=0&query_result_tot_cnt=6
//New 10 : query_orderby=0&query_result_start_index=0&query_result_tot_cnt=6&query_orderdir=0
//Top 10: query_orderby=3&query_result_start_index=0&query_result_tot_cnt=6&query_orderdir=0
//*****************************************************************************
BOOLEAN MApp_BT_GetTopListOrNewList(BOOLEAN bIsToplist)
{
    BOOLEAN bRet;
    MBX_Msg uMailBoxPara;
    U16 u16Cont, u16Len;
    U8 u8Temp;

    bBtBuff1Lock = FALSE;  //????????????????????????????

    if(bBtBuff1Lock)
    {
        if(MApp_BT_MailBoxHandle(500, MB_BTC_UNLOCKMEM_M, &uMailBoxPara))
            bBtBuff1Lock = FALSE;
        else
        {
            printf("MApp_BT_GetTopListOrNewList Failed 0!\n");
            return FALSE;
        }
    }

    u16Len = 0;
    for( u16Cont = 0; u16Cont<(sizeof(_Quesy_CMD5)-1); u16Cont++)
        CHAR_CONVER_BUFFER[u16Cont+u16Len] = (U16)(_Quesy_CMD5[u16Cont]);

    u16Len += (sizeof(_Quesy_CMD5)-1);
    if(bIsToplist)
        CHAR_CONVER_BUFFER[u16Len] = (U16)('3');
    else
        CHAR_CONVER_BUFFER[u16Len] = (U16)('0');
    u16Len ++;
    for( u16Cont = 0; u16Cont<(sizeof(_Quesy_CMD2)-1); u16Cont++)
        CHAR_CONVER_BUFFER[u16Cont+u16Len] = (U16)(_Quesy_CMD2[u16Cont]);

    u16Len += (sizeof(_Quesy_CMD2)-1);
    CHAR_CONVER_BUFFER[u16Len] = (U16)('0');
    u16Len ++;

    for( u16Cont = 0; u16Cont<(sizeof(_Quesy_CMD3)-1); u16Cont++)
        CHAR_CONVER_BUFFER[u16Cont+u16Len] = (U16)(_Quesy_CMD3[u16Cont]);

    u16Len += (sizeof(_Quesy_CMD3)-1);

    u8Temp = NUM_OF_TOP_FILES_MAX;
    if(u8Temp<10)
    {
        CHAR_CONVER_BUFFER[u16Len] = (U16)('0' + u8Temp);
        u16Len ++;
    }
    else if(u8Temp<100)
    {
        CHAR_CONVER_BUFFER[u16Len] = (U16)('0' + (u8Temp%10));
        u16Len ++;
        CHAR_CONVER_BUFFER[u16Len] = (U16)('0' + ((u8Temp/10)%10));
        u16Len ++;
    }
    else
    {
        printf("MApp_BT_GetTopListOrNewList error!\n");
    }

#if 1
    for( u16Cont = 0; u16Cont<(sizeof(_Quesy_CMD8)-1); u16Cont++)
        CHAR_CONVER_BUFFER[u16Cont+u16Len] = (U16)(_Quesy_CMD8[u16Cont]);

    u16Len += (sizeof(_Quesy_CMD8)-1);
    CHAR_CONVER_BUFFER[u16Len] = (U16)('0');
    u16Len ++;
#endif

    CHAR_CONVER_BUFFER[u16Len] = (U16)('\0');

/*
    for( u16Cont = 0; u16Cont<=u16Len; u16Cont++)
        printf("P%d_[0x%02x]\n", u16Cont, CHAR_CONVER_BUFFER[u16Cont]);
*/
    bBtBuff1Lock = TRUE;

    msAPI_MappinUCS2ToUTF8((U16 *)CHAR_CONVER_BUFFER, (U8 *)u8UTF8Sting, u16Len, 255);

    // set Parameter
    uMailBoxPara.u8Index        = MB_BTC_HTTPCMD_TTOTAL;
    uMailBoxPara.u8ParameterCount        = 0;
    bRet = MApp_BT_SendMailBox(uMailBoxPara);

    MApp_BT_SetSearchFileState( STATE_SEARCH_GET_RESPONSE_NUM );

    if(!bRet)
        printf("MApp_BT_GetTopListOrNewList Failed 1!\n");

    return bRet;
}


/******************************************************************************/
/// Read back Top/New File list information.
/// @return BOOLEAN
/******************************************************************************/
BOOLEAN MApp_BT_GetTopOrNewListInfo(void)
{
    U32 u32Addr = (U32)(((BT_BEON_TO_HK_SHAER_BUFFER_MEMORY_TYPE & MIU1) ? (BT_BEON_TO_HK_SHAER_BUFFER_ADR | MIU_INTERVAL) : (BT_BEON_TO_HK_SHAER_BUFFER_ADR))|0x80000000UL);
    pTorrentList_st psTList;
    U8 u8FileIdx, u8MaxInd;

    psTList = (pTorrentList_st)u32Addr;

    if(MApp_BT_GetSearchFileNum() > NUM_OF_TOP_FILES_MAX)
        u8MaxInd = NUM_OF_TOP_FILES_MAX;
    else
        u8MaxInd = MApp_BT_GetSearchFileNum();

    for(u8FileIdx=0; u8FileIdx<u8MaxInd; u8FileIdx++)
    {
        memcpy(uSearchTListFileInfo[u8FileIdx].uFileInfo.u16SearchList_FileName, psTList->asNode[u8FileIdx].szTFilename, sizeof(uSearchTListFileInfo[0].uFileInfo.u16SearchList_FileName));
        snprintf((char*)uSearchTListFileInfo[u8FileIdx].uFileInfo.u8ExtFileName, 4, "%s", "DAT");
        uSearchTListFileInfo[u8FileIdx].uFileInfo.u32TotalFileSize = psTList->asNode[u8FileIdx].s32FileSize;
        uSearchTListFileInfo[u8FileIdx].u32Torrent_ID= psTList->asNode[u8FileIdx].s32TID;
        printf("ID[%d]_[0x%04x]\n", u8FileIdx, uSearchTListFileInfo[u8FileIdx].u32Torrent_ID);
    }

    MApp_BT_SendUnLockMemory();

    return TRUE;
}

//*****************************************************************************
//Sender: AEON
//Receiver: MIPS
//ParamCount @ Memory buffer.
//Send http command to get the Image file
//Refer to Torrent Client HTTP Commands
//*****************************************************************************
BOOLEAN MApp_BT_QueryImageFile(S32 s32TorrentID)
{
    BOOLEAN bRet = FALSE;
    U8 u8temp[11];
    MBX_Msg uMailBoxPara;
    U16 u16Cont, u16Len;

    //MApp_BT_SendUnLockMemory();

    u16Len = 0;
    for( u16Cont = 0; u16Cont<(sizeof(_Quesy_CMD6)-1); u16Cont++)
        CHAR_CONVER_BUFFER[u16Cont+u16Len] = (U16)(_Quesy_CMD6[u16Cont]);

    u16Len += (sizeof(_Quesy_CMD6)-1);

    printf("s32TorrentID = [0x%04x]\n", s32TorrentID);
    snprintf((char*)u8temp, 11, "%d", s32TorrentID);
    for( u16Cont = 0; u16Cont<11; u16Cont++)
    {
        if(u8temp[u16Cont] == 0)
            break;

        CHAR_CONVER_BUFFER[u16Len] = (U16)u8temp[u16Cont];
        u16Len ++;
    }

    bBtBuff1Lock = TRUE;

    msAPI_MappinUCS2ToUTF8((U16 *)CHAR_CONVER_BUFFER, (U8 *)u8UTF8Sting, u16Len, 255);

    // set Parameter
    uMailBoxPara.u8Index        = MB_BTC_HTTPCMD_PGET;
    uMailBoxPara.u8ParameterCount        = 4;

    // set Torrent ID (big-endian)
    uMailBoxPara.u8Parameters[0] = (U8)(s32TorrentID>>24);
    uMailBoxPara.u8Parameters[1] = (U8)(s32TorrentID>>16);
    uMailBoxPara.u8Parameters[2] = (U8)(s32TorrentID>>8);
    uMailBoxPara.u8Parameters[3] = (U8)(s32TorrentID);

    bRet = MApp_BT_SendMailBox(uMailBoxPara);

    MApp_BT_SetImageFileState( STATE_GET_IMAGE );

    if(!bRet)
    {
        printf("MApp_BT_GetImageFile Failed\n");
        return bRet;
    }

    return bRet;
}

/******************************************************************************/
/// Read back Top/New File list information.
/// @return BOOLEAN
/******************************************************************************/
BOOLEAN MApp_BT_GetTopOrNewListImageInfo(void)
{
    U32 u32SrcAddr = (U32)(((BT_BEON_TO_HK_SHAER_BUFFER_MEMORY_TYPE & MIU1) ? (BT_BEON_TO_HK_SHAER_BUFFER_ADR | MIU_INTERVAL) : (BT_BEON_TO_HK_SHAER_BUFFER_ADR))|0x80000000UL);
    U32 u32DstAddr = (U32)(((MAD_JPEG_READBUFF_MEMORY_TYPE & MIU1) ? (MAD_JPEG_READBUFF_ADR | MIU_INTERVAL) : (MAD_JPEG_READBUFF_ADR))|0x80000000UL);//(BT_HK_IMAGE_DATA_BUFFER_ADR|0x80000000UL);
    U32 u32Size;
    U16 *pSrc, *pDst;

    pSrc = (U16 *)u32SrcAddr;
    pDst = (U16 *)u32DstAddr;

    //printf("BT_HK_IMAGE_DATA_BUFFER_ADR[%lx]!\n", ((BT_HK_IMAGE_DATA_BUFFER_MEMORY_TYPE & MIU1) ? (BT_HK_IMAGE_DATA_BUFFER_ADR | MIU_INTERVAL) : (BT_HK_IMAGE_DATA_BUFFER_ADR)));

    if(MApp_BT_GetImageFileSize() > IMAGE_MAX_SIZE)
        u32Size = IMAGE_MAX_SIZE;
    else
        u32Size = MApp_BT_GetImageFileSize();

    if(u32Size > 0)
    {
        memcpy(pDst, pSrc, u32Size);
    }
    pDst[u32Size] = 0;

    MApp_BT_SendUnLockMemory();

    return TRUE;
}

/*****************************************************************************/
//Sender: AEON
//Receiver: MIPS
//ParamCount @ Memory buffer.
//Send http command to get the Description file
//Refer to Torrent Client HTTP Commands
//*****************************************************************************
BOOLEAN MApp_BT_QueryDescriptionFile(S32 s32TorrentID)
{
    BOOLEAN bRet = FALSE;
    U8 u8temp[11];
    MBX_Msg uMailBoxPara;
    U16 u16Cont, u16Len;

    //MApp_BT_SendUnLockMemory();

    u16Len = 0;
    for( u16Cont = 0; u16Cont<(sizeof(_Quesy_CMD7)-1); u16Cont++)
        CHAR_CONVER_BUFFER[u16Cont+u16Len] = (U16)(_Quesy_CMD7[u16Cont]);

    u16Len += (sizeof(_Quesy_CMD7)-1);

    printf("Descrip s32TorrentID = [0x%04x]\n", s32TorrentID);
    snprintf((char*)u8temp, 11, "%d", s32TorrentID);
    for( u16Cont = 0; u16Cont<11; u16Cont++)
    {
        if(u8temp[u16Cont] == 0)
            break;

        CHAR_CONVER_BUFFER[u16Len] = (U16)u8temp[u16Cont];
        u16Len ++;
    }

    bBtBuff1Lock = TRUE;

    msAPI_MappinUCS2ToUTF8((U16 *)CHAR_CONVER_BUFFER, (U8 *)u8UTF8Sting, u16Len, 255);

    // set Parameter
    uMailBoxPara.u8Index        = MB_BTC_HTTPCMD_DGET;
    uMailBoxPara.u8ParameterCount        = 4;

    // set Torrent ID (big-endian)
    uMailBoxPara.u8Parameters[0] = (U8)(s32TorrentID>>24);
    uMailBoxPara.u8Parameters[1] = (U8)(s32TorrentID>>16);
    uMailBoxPara.u8Parameters[2] = (U8)(s32TorrentID>>8);
    uMailBoxPara.u8Parameters[3] = (U8)(s32TorrentID);

    bRet = MApp_BT_SendMailBox(uMailBoxPara);

    MApp_BT_SetDescriptionFileState(STATE_GET_DESCRIPTION);

    if(!bRet)
    {
        printf("MApp_BT_QueryDescriptionFile Failed\n");
        return bRet;
    }

    return bRet;
}

/******************************************************************************/
/// Read back Top/New File list information.
/// @return BOOLEAN
/******************************************************************************/
BOOLEAN MApp_BT_GetTopOrNewListDescriptionInfo(void)
{
    U32 u32SrcAddr = (U32)(((BT_BEON_TO_HK_SHAER_BUFFER_MEMORY_TYPE & MIU1) ? (BT_BEON_TO_HK_SHAER_BUFFER_ADR | MIU_INTERVAL) : (BT_BEON_TO_HK_SHAER_BUFFER_ADR))|0x80000000UL);
    U32 u32DstAddr = (U32)(((BT_BEON_TO_HK_SHAER_BUFFER_MEMORY_TYPE & MIU1) ? (BT_BEON_TO_HK_SHAER_BUFFER_ADR | MIU_INTERVAL) : (BT_BEON_TO_HK_SHAER_BUFFER_ADR))|0x80000000UL);
    U32 u32Size;
    U16 *pSrc, *pDst;

    pSrc = (U16 *)u32SrcAddr;
    pDst = (U16 *)u32DstAddr;

    printf("BT_HK_DESCRIP_DATA_BUFFER_ADR[%lx]!\n", ((BT_BEON_TO_HK_SHAER_BUFFER_MEMORY_TYPE & MIU1) ? (BT_BEON_TO_HK_SHAER_BUFFER_ADR | MIU_INTERVAL) : (BT_BEON_TO_HK_SHAER_BUFFER_ADR)));

    if(MApp_BT_GetDescriptionFileSize() > DESCRIPTION_MAX_SIZE)
        u32Size = DESCRIPTION_MAX_SIZE;
    else
        u32Size = MApp_BT_GetDescriptionFileSize();

    if(u32Size > 0)
    {
        memcpy(pDst, pSrc, u32Size);
    }
    pDst[u32Size] = 0;

    MApp_BT_SendUnLockMemory();

    return TRUE;
}

//*****************************************************************************
//Sender: AEON
//Receiver: MIPS
//ParamCount @ Memory buffer.
//Send http command to Add Torrent File to DownloadList
//Refer to Torrent Client HTTP Commands
//*****************************************************************************
BOOLEAN MApp_BT_AddTorrentFileToDownloadList(U16 * pFileName)
{
    BOOLEAN bRet = FALSE;
    MBX_Msg uMailBoxPara;


    bBtBuff1Lock = TRUE;

    msAPI_Mappin_UCS2ToHEX((U16 *)pFileName, (U8 *)u8UTF8Sting);

    // set Parameter
    uMailBoxPara.u8Index        = MB_BTC_ADDTORRENT;
    uMailBoxPara.u8ParameterCount        = 0;
    bRet = MApp_BT_SendMailBox(uMailBoxPara);

    if(!bRet)
        printf("MApp_BT_AddTorrentFileToDownloadList Failed\n");

    return bRet;
}


//*****************************************************************************
//Sender: AEON
//Receiver: MIPS
//ParamCount @ Memory buffer.
//Send http command to Torrent File Start  to Download
//Refer to Torrent Client HTTP Commands
//*****************************************************************************
BOOLEAN MApp_BT_SearchList_StartTorrentFileToDownload(U16 * pFileName)
{
    BOOLEAN bRet = FALSE;
    MBX_Msg uMailBoxPara;


    bBtBuff1Lock = TRUE;

    msAPI_Mappin_UCS2ToHEX((U16 *)pFileName, (U8 *)u8UTF8Sting);

    // set Parameter
    uMailBoxPara.u8Index        = MB_BTC_STARTTORRENT;
    uMailBoxPara.u8ParameterCount        = 0;
    bRet = MApp_BT_SendMailBox(uMailBoxPara);

    if(!bRet)
        printf("MApp_BT_StartTorrentFileToDownload Failed\n");

    return bRet;
}

BOOLEAN MApp_BT_StartTorrentFileToDownload(U16 * pFileName)
{
    BOOLEAN bRet = FALSE;
    MBX_Msg uMailBoxPara;


    bBtBuff1Lock = TRUE;

    //msAPI_Mappin_UCS2ToHEX((U16 *)pFileName, (U8 *)u8UTF8Sting);
    memcpy((U8 *)u8UTF8Sting, pFileName, BTC_TORRENTLIST_ITEM_NAME_LENGTH);

    // set Parameter
    uMailBoxPara.u8Index        = MB_BTC_STARTTORRENT;
    uMailBoxPara.u8ParameterCount        = 0;
    bRet = MApp_BT_SendMailBox(uMailBoxPara);

    if(!bRet)
        printf("MApp_BT_StartTorrentFileToDownload Failed\n");

    return bRet;
}

//*****************************************************************************
//Sender: AEON
//Receiver: MIPS
//ParamCount @ Memory buffer.
//Send http command to Torrent File Stop  to Download
//Refer to Torrent Client HTTP Commands
//*****************************************************************************
BOOLEAN MApp_BT_StopTorrentFileToDownload(U16 * pFileName)
{
    BOOLEAN bRet = FALSE;
    MBX_Msg uMailBoxPara;


    bBtBuff1Lock = TRUE;

    //msAPI_Mappin_UCS2ToHEX((U16 *)pFileName, (U8 *)u8UTF8Sting);
    memcpy((U8 *)u8UTF8Sting, pFileName, BTC_TORRENTLIST_ITEM_NAME_LENGTH);

    // set Parameter
    uMailBoxPara.u8Index        = MB_BTC_STOPTORRENT;
    uMailBoxPara.u8ParameterCount        = 0;
    bRet = MApp_BT_SendMailBox(uMailBoxPara);

    if(!bRet)
        printf("MApp_BT_StopTorrentFileToDownload Failed\n");

    return bRet;
}

//*****************************************************************************
//Sender: AEON
//Receiver: MIPS
//ParamCount @ Memory buffer.
//Send http command to Torrent File Delete  to Download
//Refer to Torrent Client HTTP Commands
//*****************************************************************************
BOOLEAN MApp_BT_DeleteTorrentFileToDownload(U16 * pFileName)
{
    BOOLEAN bRet = FALSE;
    MBX_Msg uMailBoxPara;


    bBtBuff1Lock = TRUE;

    //msAPI_Mappin_UCS2ToHEX((U16 *)pFileName, (U8 *)u8UTF8Sting);
    memcpy((U8 *)u8UTF8Sting, pFileName, BTC_TORRENTLIST_ITEM_NAME_LENGTH);

    // set Parameter
    uMailBoxPara.u8Index        = MB_BTC_DELTORRENT;
    uMailBoxPara.u8ParameterCount        = 0;
    bRet = MApp_BT_SendMailBox(uMailBoxPara);

    if(!bRet)
        printf("MApp_BT_DeleteTorrentFileToDownload Failed\n");

    return bRet;
}

//*****************************************************************************
//Sender: AEON
//Receiver: MIPS
//ParamCount @ Memory buffer.
//Send http command to Delete *.Torrent File and *.*
//Refer to Torrent Client HTTP Commands
//*****************************************************************************
BOOLEAN MApp_BT_DeleteTorrentFileAndData(U16 * pFileName)
{
    BOOLEAN bRet = FALSE;
    MBX_Msg uMailBoxPara;

    bBtBuff1Lock = TRUE;

    //msAPI_Mappin_UCS2ToHEX((U16 *)pFileName, (U8 *)u8UTF8Sting);
    memcpy((U8 *)u8UTF8Sting, pFileName, BTC_TORRENTLIST_ITEM_NAME_LENGTH);

    // set Parameter
    uMailBoxPara.u8Index        = MB_BTC_DELTORDATA;
    uMailBoxPara.u8ParameterCount        = 0;
    bRet = MApp_BT_SendMailBox(uMailBoxPara);

    if(!bRet)
        printf("MApp_BT_DeleteTorrentFileAndData Failed\n");

    return bRet;
}

//*****************************************************************************
//Sender: AEON
//Receiver: MIPS
//ParamCount @ Memory buffer.
//Send http command to Get Get Torrent List Status Information
//Refer to Torrent Client HTTP Commands
//*****************************************************************************
BOOLEAN MApp_BT_GetDownloadList(void)
{
    BOOLEAN bRet = FALSE;
    MBX_Msg uMailBoxPara;

    switch( u8DownloadListState )
    {
        case STATE_DOWNLOADLIST_NONE:
            u8DownloadListState = STATE_DOWNLOADLIST_SEMD_CMMD;
        case STATE_DOWNLOADLIST_SEMD_CMMD:
            {
                MApp_BT_SendUnLockMemory();

                // set Parameter
                uMailBoxPara.u8Index        = MB_BTC_LISTTORRENT;
                uMailBoxPara.u8ParameterCount        = 0;
                bRet = MApp_BT_SendMailBox(uMailBoxPara);

                if(bRet)
                {
                    u8DownloadListState = STATE_DOWNLOADLIST_GET_RESPONSE_LIST;
                }
                else
                {
                    printf("MApp_BT_GetDownloadList Failed\n");
                }
                bRet = FALSE;
            }
            break;

        case STATE_DOWNLOADLIST_GET_RESPONSE_LIST:
            if(MApp_BT_MailBoxHandle(5, MB_BTC_LISTTORRENT_RESPONSE, &uMailBoxPara))
            {
                bRet = MApp_BT_GetDownloadFlieListInfo();
                MApp_BT_SendUnLockMemory();
                u8DownloadListState = STATE_DOWNLOADLIST_SEMD_CMMD;
            }
            else
            {
                //printf("Wait [MB_BTC_LISTTORRENT_RESPONSE]  Failed\n");
            }
            break;
        default:
            break;
    }

    return bRet;

}


BOOLEAN MApp_BT_GetDownloadFlieListInfo(void)
{
    U32 u32Addr = (U32)(((BT_BEON_TO_HK_SHAER_BUFFER_MEMORY_TYPE & MIU1) ? (BT_BEON_TO_HK_SHAER_BUFFER_ADR | MIU_INTERVAL) : (BT_BEON_TO_HK_SHAER_BUFFER_ADR))|0x80000000UL);
    U32 u32Temp = 0;
    pTorrentList_Item_st psTList;
    U8 u8FileIdx, u8Idx,u8MaxInd, u8Cont ,*pu8Addr;

    psTList = (pTorrentList_Item_st)(u32Addr+4);

    pu8Addr = (U8 *)(((BT_BEON_TO_HK_SHAER_BUFFER_MEMORY_TYPE & MIU1) ? (BT_BEON_TO_HK_SHAER_BUFFER_ADR | MIU_INTERVAL) : (BT_BEON_TO_HK_SHAER_BUFFER_ADR))|0x80000000UL);

    for(u8Cont = 1; ; u8Cont --)
    {
        //printf("pu8Addr[%d] = [0x%02x]\n", u8Cont, pu8Addr[u8Cont]);
        if(pu8Addr[u8Cont] != 0)
        {
            if(pu8Addr[u8Cont] < CHAR_0 || pu8Addr[u8Cont] > CHAR_9)
            {
                u8DownloadListFileNum = 0;
                //printf("MApp_BT_GetDownloadFlieListInfo fail!\n");
                return FALSE;
            }
            u32Temp += (pu8Addr[u8Cont] -CHAR_0);

            if(u8Cont > 0)
                u32Temp *= 10;
        }

        if(u8Cont == 0)
            break;
    }

    //printf("u32Temp = [%lx]\n", u32Temp);

    if(u32Temp > NUM_OF_DOWNLOAD_LIST_FILES_MAX)
        u8DownloadListFileNum = NUM_OF_DOWNLOAD_LIST_FILES_MAX;
    else
        u8DownloadListFileNum = (U8)u32Temp;

    printf("u8DownloadListFileNum = [%02x]\n", u8DownloadListFileNum);

    if(MApp_BT_GetDownloadListFileNum() > 5)
        u8MaxInd = 5;
    else
        u8MaxInd = MApp_BT_GetDownloadListFileNum();

    for(u8FileIdx=0; u8FileIdx<u8MaxInd; u8FileIdx++)
    {
        u8Idx = (u8MaxInd -1) -u8FileIdx;//(U8)((U8)(psTList +u8FileIdx)->num);
        memcpy(uDownloadListFileInfo[u8Idx].u8LongFileName, (psTList +u8FileIdx) ->name, sizeof(psTList->name));
        snprintf((char*)uDownloadListFileInfo[u8Idx].u8ExtFileName, 4, "%s", "DAT");
        uDownloadListFileInfo[u8Idx].u8State= (TORRENT_STATE)((psTList +u8FileIdx)->st);
        uDownloadListFileInfo[u8Idx].u32TotalFileSize = (U32)((psTList +u8FileIdx)->csize);
        uDownloadListFileInfo[u8Idx].u32LeftFileSize= (U32)((psTList +u8FileIdx)->csize - (psTList +u8FileIdx)->cgot );
        uDownloadListFileInfo[u8Idx].u32DownloadSpeed= (U32)((psTList +u8FileIdx)->rate_down);
    }

    return TRUE;
}

//*****************************************************************************
//Sender: BEON
//Receiver: AEON
//Get Mail Box Message
//*****************************************************************************
BOOLEAN MApp_BT_MailBoxHandle(U32 u32WaitMs, U8 u8CommandIndex, MBX_Msg *pMsg)
{
    U32 u32Timer  = msAPI_Timer_GetTime0();
    U32 u32Temp;
    U8 i = 0;
    BOOLEAN bRet = FALSE;
    MBX_MSGQ_Status mbxMsgQStatus;

    if(NULL == pMsg)
        return FALSE;

    while(msAPI_Timer_DiffTimeFromNow(u32Timer) < u32WaitMs)
    {
        MApi_MBX_GetMsgQueueStatus(E_MBX_CLASS_BTPD, &mbxMsgQStatus);
        for (i=0; i<mbxMsgQStatus.u32NormalMsgCount; i++)
        {
            #if( WATCH_DOG == ENABLE )
            msAPI_Timer_ResetWDT();
            #endif

            if(MApi_MBX_RecvMsg(E_MBX_CLASS_BTPD, pMsg, 0, MBX_CHECK_NORMAL_MSG) == E_MBX_SUCCESS)
            {
                //printf("MB: [%02x][%02x][%02x][%02x][%02x]\n", u8BT_MainBox[1], u8BT_MainBox[2], u8BT_MainBox[3], u8BT_MainBox[4], u8BT_MainBox[5]);
                // for Usre requst
                if(pMsg->u8Index == u8CommandIndex)
                {
                    bRet = TRUE;
                    break;
                }

                switch(pMsg->u8Index)
                {
                    case MB_BTC_UNLOCKMEM_M:
                        bBtBuff1Lock = FALSE;
                        break;

                    case MB_BTC_OK:
                        printf("MB: [%02x][%02x][%02x][%02x][%02x]\n", pMsg->u8Parameters[0], pMsg->u8Parameters[1], pMsg->u8Parameters[2], pMsg->u8Parameters[3], pMsg->u8Parameters[4]);
                        u8BTMailBoxOKState = pMsg->u8Parameters[0];
                        break;
                    case MB_BTC_FAIL:
                        {
                            u8BTErrorState = pMsg->u8Parameters[0];
                            printf("u8BTErrortState: [%d]\n", u8BTErrorState);
                            printf("MB: [%02x][%02x][%02x][%02x]\n", pMsg->u8Parameters[1], pMsg->u8Parameters[2], pMsg->u8Parameters[3], pMsg->u8Parameters[4]);

                            switch(u8BTErrorState)
                            {
                                case MB_BTC_ERR_DN_IMG: //Error while downloading the image file
                                    MApp_System_ErrorHandle();
                                    break;

                                default :
                                    break;
                            }
                        }
                        break;
                    case MB_BTC_RESPONSE_NUM:

                        break;
                    case MB_BTC_RESPONSE_LIST:

                        break;
                    case MB_BTC_LISTTORRENT_RESPONSE:
                        {
                            MApp_BT_GetDownloadFlieListInfo();
                            MApp_BT_SendUnLockMemory();
                            u8DownloadListState = STATE_DOWNLOADLIST_SEMD_CMMD;
                        }
                        break;

                    case MB_BTC_SENDIMGRAWDATA:
                        {

                            if(MApp_BT_GetImageFileState() == STATE_GET_IMAGE)
                            {
                                u32Temp = ((((U32)pMsg->u8Parameters[0]) << 24)&0xFF000000)|
                                                ((((U32)pMsg->u8Parameters[1]) << 16)&0x00FF0000)|
                                                ((((U32)pMsg->u8Parameters[2]) << 8 )&0x0000FF00)|
                                                ((((U32)pMsg->u8Parameters[3])      )&0x000000FF);
                                printf("Image Size [%lx]\n", u32Temp);

                                MApp_BT_SetImageFileSize(u32Temp);

                                //get Flie content
                                MApp_BT_GetTopOrNewListImageInfo();

                                MApp_BT_SetImageFileState(STATE_GET_IMAGE_OK);
                            }
                        }
                        break;

                    case MB_BTC_SENDDESTXT:
                        {
                            u32Temp = ((((U32)pMsg->u8Parameters[0]) << 24)&0xFF000000)|
                                            ((((U32)pMsg->u8Parameters[1]) << 16)&0x00FF0000)|
                                            ((((U32)pMsg->u8Parameters[2]) << 8 )&0x0000FF00)|
                                            ((((U32)pMsg->u8Parameters[3])      )&0x000000FF);

                            MApp_BT_SetDescriptionFileSize(u32Temp);

                            u32Temp = ((((U32)pMsg->u8Parameters[4]) << 24)&0xFF000000)|
                                            ((((U32)pMsg->u8Parameters[5]) << 16)&0x00FF0000)|
                                            ((((U32)pMsg->u8Parameters[6]) << 8 )&0x0000FF00)|
                                            ((((U32)pMsg->u8Parameters[7])      )&0x000000FF);

                            printf("Description_1 Size [%lx]   ID [%lx]\n", MApp_BT_GetDescriptionFileSize(), u32Temp);

                            // if ID not match, ignore it, return false
                            if(MApp_BT_GetDescriptionFileID() != u32Temp)
                            {
                                MApp_BT_SendUnLockMemory();
                                break;
                            }

                            //get Flie list info
                            MApp_BT_GetTopOrNewListDescriptionInfo();

                            MApp_BT_SetDescriptionFileState(STATE_GET_DESCRIPTION_OK);
                            printf("Description State [%d] \n", MApp_BT_GetDescriptionFileState());
                        }
                        break;

                    default :
                        break;
                }
            }
        }
    }

#if 0
    if(msAPI_Timer_DiffTimeFromNow(u32Timer)  >= u32WaitMs)
    {
        printf("Wait MBX_Msg TimeOut!\n");
        if(i<u8Count)
            printf("MainlBox Item to Large[%d] <-[%d]!\n", u8Count, i);
    }
#endif
    return bRet;

}


/******************************************************************************/
/// Get System Error state
/// @return state
/******************************************************************************/
U8 MApp_Get_System_ErrorState(void)
{
    return u8BTErrorState;
}

/******************************************************************************/
/// Handle System Error
/******************************************************************************/
void MApp_System_ErrorHandle(void)
{
     switch(MApp_Get_System_ErrorState())
     {
        case MB_BTC_ERR_DN_TOR: //Error while downloading the torrent file
        case MB_BTC_ERR_START_TOR: //Error while starting the torrent
        case MB_BTC_ERR_STOP_TOR: //Error while stopping the torrent
        case MB_BTC_ERR_ADD_TOR: //Error while adding the torrent
        case MB_BTC_ERR_DEL_TOR: //Error while deleting the torrent
        case MB_BTC_ERR_DEL_TORDATA: //Error while deleting the torrent and downloaded data
        case MB_BTC_ERR_START_DAEM: //Error while starting the daemon
        case MB_BTC_ERR_STOP_DAEM: //Error while stopping the daemon
        case MB_BTC_ERR_SET_PARAM: //Error while setting the daemon parameters
        case MB_BTC_ERR_NETWORK: //Error for network
        case MB_BTC_ERR_STORAGE: //Error for storage
        case MB_BTC_ERR_UNRESOLVED_HOST:  //Error while resolving the host name of the torrent server
        case MB_BTC_ERR_DECODE_IMG: //Error while decoding the image
        case MB_BTC_ERR_UNKNOWN: //Unknown error
            u8BTErrorState = 0;
            break;

        case MB_BTC_ERR_DN_IMG: //Error while downloading the image file
            printf("Get Image Error Handle!\n");

            MApp_BT_SetImageFileSize(0);

            MApp_BT_SetImageFileState(STATE_GET_IMAGE_OK);
            u8BTErrorState = 0;
            break;
        case MB_BTC_ERR_DN_DES: //Error while downloading the description file
            printf("Get description File Error Handle!\n");

            MApp_BT_SetDescriptionFileSize(0);

            MApp_BT_SetDescriptionFileState(STATE_GET_DESCRIPTION_OK);

            u8BTErrorState = 0;
            break;

        default :
            break;

     }
}

/******************************************************************************/
/// Set  System Init  State.
/// @return None
/******************************************************************************/
void MApp_BT_SetSystemInitState(BT_Init_State uState)
{
    u8BtInitState = uState;
}

/******************************************************************************/
/// Read back System Init State.
/// @return System Init State
/******************************************************************************/
BT_Init_State MApp_BT_GetSystemInitState(void)
{
    return u8BtInitState;
}


/******************************************************************************/
/// Init BT
/******************************************************************************/
void MApp_BT_CoProcesser_Init(void)//Co-processer
{
    MBX_Msg mbxMsg;
#if 0
    printf("msAPI_BT_CoProcesser_Init!\n");
    msAPI_APEngine_AppRunByBinID(BIN_ID_CODE_AEON_BT_CAPE, ((BEON_MEM_MEMORY_TYPE & MIU1) ? (BEON_MEM_ADR | MIU_INTERVAL) : ( BEON_MEM_ADR)), BEON_MEM_LEN);

    // wait for CoProcesser bootup OK
    while (1)
    {
        #if( WATCH_DOG == ENABLE )
        msAPI_Timer_ResetWDT();
        #endif

        if(MDrv_GetMailBoxMsg(Q_BTPD, &u8BT_MainBox[0]) == MB_GET_MSG_OK)
            if ( u8BT_MainBox[0] == MB_CLASS_BTPD) //command class
            {
                if (u8BT_MainBox[1] == MB_BTC_OK)
                {
                        printf("Beon OK!\n");
                        break;
                }
            }
    }

    // set Memory addr and size
    MApp_BT_Set_HK_To_Beon_Memory_Addr();
    MApp_BT_Set_Beon_To_HK_Memory_Addr();

    // set Daemon parameter
    MApp_BT_SetDamonParam((MS_TorrentSetupInfo *) &stGenSetting.TorrentSetupInfo);
    MApp_BT_StarDamon();

    // set Torrent Server address
    memcpy(CHAR_CONVER_BUFFER, stGenSetting.TorrentSetupInfo.u8ServerName, sizeof(stGenSetting.TorrentSetupInfo.u8ServerName));
    FS_ASCII2Unicode((U8*)CHAR_CONVER_BUFFER);
    MApp_BT_SetTorrentServerAddr((U16 *)CHAR_CONVER_BUFFER);

#else

    switch(MApp_BT_GetSystemInitState())
    {
        case STATE_SYSTEM_INIT_LOAD_BIN:
            printf("MApp_BT_CoProcesser_Init!\n");
            #ifdef ENABLE_LOAD_APP_FROM_USB
            U8 name[]="btpd.bin";
            LoadAppbyFileNameFromUSB(name);
            #else
            MApp_APEngine_RegisterByID(BIN_ID_CODE_AEON_BT_CAPE, NONE_HANDLE, ((BEON_MEM_MEMORY_TYPE & MIU1) ? (BEON_MEM_ADR | MIU_INTERVAL) : ( BEON_MEM_ADR)), BEON_MEM_LEN);
            #endif
            MApp_BT_SetSystemInitState(STATE_SYSTEM_INIT_WAIT_LOAD_OK);

            //MsOS_DelayTask(100);
            //MDrv_WriteByte(0x1EAA, 0x0C);
            //MsOS_DelayTask(100);

            break;
        case STATE_SYSTEM_INIT_WAIT_LOAD_OK:
            if(MApp_BT_MailBoxHandle(10, MB_BTC_OK, &mbxMsg))
            {
                printf("Load Bin OK!\n");
                MApp_BT_SetSystemInitState(STATE_SYSTEM_INIT_SET_PARAMETER);
            }
            break;
        case STATE_SYSTEM_INIT_SET_PARAMETER:
            printf("SET PARAMETER!\n");

            // set Memory addr and size
            MApp_BT_Set_HK_To_Beon_Memory_Addr();
            MApp_BT_Set_Beon_To_HK_Memory_Addr();

            // set Daemon parameter
            MApp_BT_SetDamonParam((MS_TorrentSetupInfo *) &stGenSetting.TorrentSetupInfo);
            MApp_BT_StarDamon();

            // set Torrent Server address
            memcpy(CHAR_CONVER_BUFFER, stGenSetting.TorrentSetupInfo.u8ServerName, sizeof(stGenSetting.TorrentSetupInfo.u8ServerName));
            FS_ASCII2Unicode((U8*)CHAR_CONVER_BUFFER);
            MApp_BT_SetTorrentServerAddr((U16 *)CHAR_CONVER_BUFFER);

            MApp_BT_CheckNetWork();
            MApp_BT_SetSystemInitState(STATE_SYSTEM_INIT_CHECK_NETWORK);

            break;
        case STATE_SYSTEM_INIT_CHECK_NETWORK:
            if(MApp_BT_MailBoxHandle(10, MB_BTC_OK, &mbxMsg))
            {
            #if 1
                if( u8BTMailBoxOKState == MB_BTC_CHECK_NETWORK )
                {
                    printf("Check Network OK!\n");
                    MApp_BT_SetSystemInitState(STATE_SYSTEM_INIT_OK);
                }
                else
                {
                    printf("Check Network temp!\n");
                }
            #else
                printf("Check Network OK!\n");
                MApp_BT_SetSystemInitState(STATE_SYSTEM_INIT_OK);
            #endif
            }
            break;
        case STATE_SYSTEM_INIT_OK:
            break;

        default :
            break;
    }
#endif

}

/******************************************************************************/
/// Read the JPEG data & decode it
/******************************************************************************/
#if (BT_DECODE_JPEG_METHOD_0)
static BOOLEAN _MApp_BT_MoviePhoto_Load(void)
{
    JPEG_DECODE_STATUS u8DecodeStatus=JPEG_DECODE_RUNNING;
    U32 u32TimeMarker;
    U32 u32RequestDataAddr, u32RequestDataSize;

#if 0
    U32 u32SrcPhotoAddr;
    U32 u32SrcPhotoLen;
    MEMCOPYTYPE mPhotoCopyType;
    BOOLEAN bResult;

// temperoly load logo jpeg from flash
    BININFO   BinInfo;
    BinInfo.B_ID = BIN_ID_JPEG_BOOT_LOGO;
    MDrv_Sys_Get_BinInfo(&BinInfo, &bResult);
      if ( bResult != PASS)
    {
        BT_DBG(printf( "could not find logo binary on flash.\n" ));
        return FALSE;
    }
    u32SrcPhotoAddr = BinInfo.B_FAddr;
    u32SrcPhotoLen = BinInfo.B_Len;
    mPhotoCopyType = MIU_FLASH2SDRAM;// MIU_SRAM2SDRAM
// temperoly load logo jpeg from flash

    MDrv_BDMA_CopyHnd(u32SrcPhotoAddr, (U32)((MAD_JPEG_READBUFF_MEMORY_TYPE & MIU1) ? (MAD_JPEG_READBUFF_ADR | MIU_INTERVAL) : (MAD_JPEG_READBUFF_ADR)), GE_ALIGNED_VALUE(u32SrcPhotoLen,8), MIU_FLASH2SDRAM);

#else
#endif

    MApp_Photo_MemCfg(
            ((MAD_JPEG_READBUFF_MEMORY_TYPE & MIU1) ? (MAD_JPEG_READBUFF_ADR | MIU_INTERVAL) : (MAD_JPEG_READBUFF_ADR)), MAD_JPEG_READBUFF_LEN,
            ((MAD_JPEG_OUT_MEMORY_TYPE & MIU1) ? (MAD_JPEG_OUT_ADR | MIU_INTERVAL) : (MAD_JPEG_OUT_ADR)), MAD_JPEG_OUT_LEN,
            ((MAD_JPEG_INTERBUFF_MEMORY_TYPE & MIU1) ? (MAD_JPEG_INTERBUFF_ADR | MIU_INTERVAL) : (MAD_JPEG_INTERBUFF_ADR)), MAD_JPEG_INTERBUFF_LEN);

    if (MApp_Photo_DecodeMemory_Init(FALSE, NULL))
    {
        EN_RET enPhotoRet;

        while ((enPhotoRet = MApp_Photo_Main()) == EXIT_PHOTO_DECODING)
        {
#if( WATCH_DOG == ENABLE )
            msAPI_Timer_ResetWDT();
#endif
        }

        if ((enPhotoRet == EXIT_PHOTO_DECODE_DONE) && (MApp_Photo_GetErrCode() == E_PHOTO_ERR_NONE))
        {
            MApp_Photo_Stop();
            return TRUE;
        }
    }

    MApp_Photo_Stop();

    BT_DBG(printf("movie photo decode timeout!\n"));

    return FALSE;

}
#endif

#define BT_MOVIE_PHOTO_X    100
#define BT_MOVIE_PHOTO_Y    160
#define BT_MOVIE_PHOTO_W    (g_IPanel.Width()/6)
#define BT_MOVIE_PHOTO_H    (g_IPanel.Height()/6)
#define BT_MOVIE_PHOTO_X_DIS    10
#define BT_MOVIE_PHOTO_Y_DIS   90
extern void MApp_BT_ClearTopOrNewListPhotoBG(U8 u8Item);
U32 u32BT_time;
//BOOLEAN bBTJpegTest = FALSE;
/******************************************************************************/
/// dispaly JPEG on GOP/VOP
/// @param  u8Idx \b IN Specify the index offset.
/// @param  bEnable \b IN display or un-display on VOP,only valid on VOP mode
/// @return  true or false
/******************************************************************************/
static BOOLEAN _MApp_BT_DisplayMoviePhoto(U8 u8Idx, BOOLEAN bEnable)
{
#if (BT_DECODE_JPEG_METHOD_0)
//if (!bBTJpegTest)
{
    ST_JPEG_CAPTURE_RECT stTo, stFrom;
    EN_JPEG_COLOR_FORMAT eJpegColorFormat=EN_JPEG_COLOR_RGB;
    BOOLEAN bShowOnOtherGWIN=FALSE;// if enable ,please take attention GWIN priority

    if(eJpegColorFormat==EN_JPEG_COLOR_YUV)
    {
        if(!bEnable)
            msAPI_JPEG_CloseDisplayPath();
    }

    if(_MApp_BT_MoviePhoto_Load() == FALSE)
        return FALSE;

    if(bEnable)
    {
        memset(&stTo, 0, sizeof(stTo));
        memset(&stFrom, 0, sizeof(stFrom));
        MApp_Jpeg_GetImageInfo(&stFrom.u16RectW, &stFrom.u16RectH, NULL);
        stTo.u16RectX = BT_MOVIE_PHOTO_X+(u8Idx%3)*(BT_MOVIE_PHOTO_X_DIS+BT_MOVIE_PHOTO_W);
        stTo.u16RectY = BT_MOVIE_PHOTO_Y+(u8Idx/3)*(BT_MOVIE_PHOTO_Y_DIS+BT_MOVIE_PHOTO_H);
        stTo.u16RectW = BT_MOVIE_PHOTO_W;
        stTo.u16RectH = BT_MOVIE_PHOTO_H;
        if(eJpegColorFormat==EN_JPEG_COLOR_YUV)
            stTo.u8FbFmt = GFX_FMT_YUV422;
        else
            stTo.u8FbFmt = GFX_FMT_ARGB1555;

        BT_DBG(printf("\n u16RectX , u16RectY , u8Idx = %d, %d, %d",stTo.u16RectX,stTo.u16RectY,(U16)u8Idx));
        if(!bShowOnOtherGWIN)//get FB firstly,because MApp_Jpeg_Display2 didn't set FB when RGB show on current GWIN
        {
            GOP_GwinFBAttr stFbAttr;
            U8 u8FbId , u8GwinId;

            u8FbId = MApi_GOP_GWIN_GetCurrentFBID();
            u8GwinId = MApi_GOP_GWIN_GetCurrentWinId();
            BT_DBG(printf("\n BT page u8GwinId=%d\n",(U16)u8GwinId));
            if ((u8FbId >= MAX_GWIN_FB_SUPPORT) || (u8GwinId >= MAX_GWIN_SUPPORT))
            {
                BT_DBG(printf("No FB or GW\n"));
                return FALSE;
            }

            MApi_GOP_GWIN_MapFB2Win(u8FbId, u8GwinId);
            MApi_GOP_GWIN_GetFBInfo(u8FbId, &stFbAttr);

            stTo.u16BuffW = stFbAttr.width;
            stTo.u16BuffH = stFbAttr.height;
            stTo.u32BuffAddr = stFbAttr.addr;
        }

        MApp_Jpeg_Display2(TRUE, eJpegColorFormat, bShowOnOtherGWIN, &stTo, &stFrom, EN_JPEG_ALIGN_MIDDLE_CENTERED, EN_JPEG_FIT_BOUNDARY);
    }
    return TRUE;
}
//else
 #else
 {
    BOOLEAN  bRet = FALSE;

    //printf("Jpeg Idx [%d] s:[%d]\n", u8Idx, u8BT_JPEG_State);

    switch(u8BT_JPEG_State)
    {
        case STATE_BT_JPEG_INIT:
            {
                #if 0
                    U32 u32SrcPhotoAddr;
                    U32 u32SrcPhotoLen;
                    MEMCOPYTYPE mPhotoCopyType;
                    BOOLEAN bResult;

                // temperoly load logo jpeg from flash
                    BININFO   BinInfo;
                    BinInfo.B_ID = BIN_ID_JPEG_BOOT_LOGO;
                    MDrv_Sys_Get_BinInfo(&BinInfo, &bResult);
                      if ( bResult != PASS)
                    {
                        BT_DBG(printf( "could not find logo binary on flash.\n" ));
                        return FALSE;
                    }
                    u32SrcPhotoAddr = BinInfo.B_FAddr;
                    u32SrcPhotoLen = BinInfo.B_Len;
                    mPhotoCopyType = MIU_FLASH2SDRAM;// MIU_SRAM2SDRAM
                // temperoly load logo jpeg from flash

                    MDrv_BDMA_CopyHnd(u32SrcPhotoAddr, (U32)((MAD_JPEG_READBUFF_MEMORY_TYPE & MIU1) ? (MAD_JPEG_READBUFF_ADR | MIU_INTERVAL) : (MAD_JPEG_READBUFF_ADR)), GE_ALIGNED_VALUE(u32SrcPhotoLen,8), MIU_FLASH2SDRAM);

                #endif

                // for jpeg Error or No Image file handle
                if(MApp_BT_GetImageFileSize() == 0)
                {
                    u8BT_JPEG_State = STATE_BT_JPEG_NONE;
                    bRet = TRUE;
                    break;
                }

                MApp_Photo_MemCfg(
                        ((MAD_JPEG_READBUFF_MEMORY_TYPE & MIU1) ? (MAD_JPEG_READBUFF_ADR | MIU_INTERVAL) : (MAD_JPEG_READBUFF_ADR)), MAD_JPEG_READBUFF_LEN,
                        ((MAD_JPEG_OUT_MEMORY_TYPE & MIU1) ? (MAD_JPEG_OUT_ADR | MIU_INTERVAL) : (MAD_JPEG_OUT_ADR)), MAD_JPEG_OUT_LEN,
                        ((MAD_JPEG_INTERBUFF_MEMORY_TYPE & MIU1) ? (MAD_JPEG_INTERBUFF_ADR | MIU_INTERVAL) : (MAD_JPEG_INTERBUFF_ADR)), MAD_JPEG_INTERBUFF_LEN);

                if (MApp_Photo_DecodeMemory_Init(FALSE, NULL) == FALSE)
                {
                    u8Thunder_JPEG_State = STATE_BT_JPEG_NONE;
                    bRet = TRUE;
                    break;
                }

                u8BT_JPEG_State = STATE_BT_JPEG_DECODE;
                u32BT_time = msAPI_Timer_GetTime0();
            }
            break;

        case STATE_BT_JPEG_DECODE:
            {
                EN_RET enPhotoRet;

                if ((enPhotoRet = MApp_Photo_Main()) != EXIT_PHOTO_DECODING)
                {
                    if ((enPhotoRet == EXIT_PHOTO_DECODE_DONE) && (MApp_Photo_GetErrCode() == E_PHOTO_ERR_NONE))
                    {
                        u8Thunder_JPEG_State = STATE_BT_JPEG_SHOW;
                        MApp_BT_ClearTopOrNewListPhotoBG(u8Idx);
                    }
                    else
                    {
                        u8Thunder_JPEG_State = STATE_BT_JPEG_NONE;
                        bRet = TRUE;
                    }

                    MApp_Photo_Stop();
                }
            }
            break;

        case STATE_BT_JPEG_SHOW:
            {
                ST_JPEG_CAPTURE_RECT stTo, stFrom;
                EN_JPEG_COLOR_FORMAT eJpegColorFormat=EN_JPEG_COLOR_RGB;
                BOOLEAN bShowOnOtherGWIN=FALSE;// if enable ,please take attention GWIN priority

                if(bEnable)
                {
                    memset(&stTo, 0, sizeof(stTo));
                    memset(&stFrom, 0, sizeof(stFrom));
                    MApp_Jpeg_GetImageInfo(&stFrom.u16RectW, &stFrom.u16RectH, NULL);
                    stTo.u16RectX = BT_MOVIE_PHOTO_X+(u8Idx%3)*(BT_MOVIE_PHOTO_X_DIS+BT_MOVIE_PHOTO_W);
                    stTo.u16RectY = BT_MOVIE_PHOTO_Y+(u8Idx/3)*(BT_MOVIE_PHOTO_Y_DIS+BT_MOVIE_PHOTO_H);
                    stTo.u16RectW = BT_MOVIE_PHOTO_W;
                    stTo.u16RectH = BT_MOVIE_PHOTO_H;
                    if(eJpegColorFormat==EN_JPEG_COLOR_YUV)
                        stTo.u8FbFmt = GFX_FMT_YUV422;
                    else
                        stTo.u8FbFmt = GFX_FMT_ARGB1555;

                    BT_DBG(printf("\n u16RectX , u16RectY , u8Idx = %d, %d, %d",stTo.u16RectX,stTo.u16RectY,(U16)u8Idx));
                    if(!bShowOnOtherGWIN)//get FB firstly,because MApp_Jpeg_Display2 didn't set FB when RGB show on current GWIN
                    {
                        GOP_GwinFBAttr stFbAttr;
                        U8 u8FbId , u8GwinId;

                        u8FbId = MApi_GOP_GWIN_GetCurrentFBID();
                        u8GwinId = MApi_GOP_GWIN_GetCurrentWinId();
                        BT_DBG(printf("\n BT page u8GwinId=%d\n",(U16)u8GwinId));
                        if ((u8FbId >= MAX_GWIN_FB_SUPPORT) || (u8GwinId >= MAX_GWIN_SUPPORT))
                        {
                            BT_DBG(printf("No FB or GW\n"));
                            return FALSE;
                        }

                        MApi_GOP_GWIN_MapFB2Win(u8FbId, u8GwinId);
                        MApi_GOP_GWIN_GetFBInfo(u8FbId, &stFbAttr);

                        stTo.u16BuffW = stFbAttr.width;
                        stTo.u16BuffH = stFbAttr.height;
                        stTo.u32BuffAddr = stFbAttr.addr;
                    }

                    MApp_Jpeg_Display2(TRUE, eJpegColorFormat, bShowOnOtherGWIN, &stTo, &stFrom, EN_JPEG_ALIGN_MIDDLE_CENTERED, EN_JPEG_FIT_BOUNDARY);

                    u8BT_JPEG_State = STATE_BT_JPEG_NONE;
                    bRet = TRUE;
                }
            }
            break;

        default:
            break;

    }

    return bRet;
    }
 #endif
}

static BOOLEAN _MApp_BT_DrawMainLinkPhotoByIndex(U8 u8Index)
{
    return _MApp_BT_DisplayMoviePhoto(u8Index,TRUE);
}


//*****************************************************************************
//              Global Functions
//*****************************************************************************

/******************************************************************************/
/// set mainlink0 photo can show flag.
/// @param  u8Idx \b IN Specify which photo can be set.
/// @param  bShow \b IN Specify the photo can show.
/******************************************************************************/
void MApp_BT_SetMainLink0PhotoShow(U8 u8Idx, BOOLEAN bShow)
{
    if(u8Idx > NUM_OF_MAINLINK0_PHOTO_PER_PAGE)
        BT_DBG(printf("\n Array index overflow!!!"));
    m_MainLink0Status[u8Idx].bLinkPhoto_Show = bShow;
}

/******************************************************************************/
/// set mainlink0 photo can show flag.
/// @param  u8Idx \b IN Specify which photo can be set.
/// @return  True/False
/******************************************************************************/
BOOLEAN MApp_BT_GetMainLink0PhotoReady(U8 u8Idx)
{
    if(u8Idx > NUM_OF_MAINLINK0_PHOTO_PER_PAGE)
        BT_DBG(printf("\n Array index overflow!!!"));
    return m_MainLink0Status[u8Idx].bLinkPhoto_Ready;
}

/******************************************************************************/
/// set mainlink1 photo can show flag.
/// @param  u8Idx \b IN Specify which photo can be set.
/// @param  bShow \b IN Specify the photo can show.
/******************************************************************************/
void MApp_BT_SetMainLink1PhotoShow(U8 u8Idx, BOOLEAN bShow)
{
    if(u8Idx > NUM_OF_MAINLINK1_PHOTO_PER_PAGE)
        BT_DBG(printf("\n Array index overflow!!!"));
    m_MainLink1Status[u8Idx].bLinkPhoto_Show = bShow;
}

/******************************************************************************/
/// set mainlink0 photo can show flag.
/// @param  u8Idx \b IN Specify which photo can be set.
/// @return  True/False
/******************************************************************************/
BOOLEAN MApp_BT_GetMainLink1PhotoReady(U8 u8Idx)
{
    if(u8Idx > NUM_OF_MAINLINK0_PHOTO_PER_PAGE)
        BT_DBG(printf("\n Array index overflow!!!"));
    return m_MainLink1Status[u8Idx].bLinkPhoto_Ready;
}

//=============================================================================/
//============================ Query Interface ================================
//=============================================================================/
/******************************************************************************/
/// Read back Download list File Total Number.
/// @return Download list File Total Number
/******************************************************************************/
U8 MApp_BT_GetDownloadListFileNum(void)
{
    return u8DownloadListFileNum;
}

/******************************************************************************/
/// Read back the file information.
/// @param  u8FileIdx \b IN Specify the file index offset.
/// @param  pInfo      \b OUT Return the file information.
/// @return BOOLEAN
/******************************************************************************/
BOOLEAN MApp_BT_QueryTorrentFileInfo(U8 u8FileIdx, TorrentFileInfo *pInfo)
{
    TorrentFileInfo *pFileInfo;

    if(u8FileIdx >= MApp_BT_GetDownloadListFileNum())
        return FALSE;

    pFileInfo= (TorrentFileInfo *)(uDownloadListFileInfo+u8FileIdx);

    memcpy(pInfo, pFileInfo, sizeof(TorrentFileInfo));

    return TRUE;
}

/******************************************************************************/
/// Read back the main link0 information.
/// @param  u8Idx \b IN Specify the index offset.
/// @param  pInfo      \b OUT Return the link information.
/// @return BOOLEAN
/******************************************************************************/
BOOLEAN MApp_BT_QueryMainLink0Info(U8 u8Idx, MainLink0Info *pInfo)
{
    //U32 u32Addr;
    //MainLink0Info *pMainLinkInfo;

    if( u8Idx >= NUM_OF_TOP_FILES_MAX )
        return FALSE;

    //u32Addr = (U32)MAIN_LINK0_BUFFER_ADR + (U32)u8Idx*sizeof(MainLink0Info);
    //pMainLinkInfo = (MainLink0Info xdata *)(u32Addr);

    //for test
    //pMainLinkInfo= (MainLink0Info *)(MainLink0Test+u8Idx);
    //memcpy(pInfo, pMainLinkInfo, sizeof(MainLink0Info));

    memcpy(pInfo->u8LinkFile_FileName, uSearchTListFileInfo[u8Idx].uFileInfo.u16SearchList_FileName, BTC_TORRENTLIST_ITEM_NAME_LENGTH);

    return TRUE;
}
/******************************************************************************/
/// Read back the main link1 information.
/// @param  u8Idx \b IN Specify the index offset.
/// @param  pInfo      \b OUT Return the link information.
/// @return BOOLEAN
/******************************************************************************/
BOOLEAN MApp_BT_QueryMainLink1Info(U8 u8Idx, MainLink1Info *pInfo)
{
    //U32 u32Addr;
    //MainLink1Info *pMainLinkInfo;

    if( u8Idx >= NUM_OF_TOP_FILES_MAX )
        return FALSE;

    //u32Addr = (U32)MAIN_LINK1_BUFFER_ADR + (U32)u8Idx*sizeof(MainLink1Info);
    //pMainLinkInfo = (MainLink1Info xdata *)(u32Addr);

    //for test
    //pMainLinkInfo= (MainLink1Info *)(MainLink1Test+u8Idx);
    //memcpy(pInfo, pMainLinkInfo, sizeof(MainLink1Info));

    memcpy(pInfo->u8LinkFile_FileName, uSearchTListFileInfo[u8Idx].uFileInfo.u16SearchList_FileName, BTC_TORRENTLIST_ITEM_NAME_LENGTH);

    return TRUE;
}
/******************************************************************************/
/// Read back Search File list information.
/// @return BOOLEAN
/******************************************************************************/
BOOLEAN MApp_BT_GetSearchFlieListInfo(void)
{
    U32 u32Addr = (U32)(((BT_BEON_TO_HK_SHAER_BUFFER_MEMORY_TYPE & MIU1) ? (BT_BEON_TO_HK_SHAER_BUFFER_ADR | MIU_INTERVAL) : (BT_BEON_TO_HK_SHAER_BUFFER_ADR))|0x80000000UL);
    pTorrentList_st psTList;
    U8 u8FileIdx, u8MaxInd;

    psTList = (pTorrentList_st)u32Addr;

    if(MApp_BT_GetSearchFileNum() > 5)
        u8MaxInd = 5;
    else
        u8MaxInd = MApp_BT_GetSearchFileNum();

    for(u8FileIdx=0; u8FileIdx<u8MaxInd; u8FileIdx++)
    {
        memcpy(uSearchTListFileInfo[u8FileIdx].uFileInfo.u16SearchList_FileName, psTList->asNode[u8FileIdx].szTFilename, sizeof(uSearchTListFileInfo[0].uFileInfo.u16SearchList_FileName));
        snprintf((char*)uSearchTListFileInfo[u8FileIdx].uFileInfo.u8ExtFileName, 4, "%s", "DAT");
        uSearchTListFileInfo[u8FileIdx].uFileInfo.u32TotalFileSize = psTList->asNode[u8FileIdx].s32FileSize;
        uSearchTListFileInfo[u8FileIdx].u32Torrent_ID= psTList->asNode[u8FileIdx].s32TID;
        //printf("ID[%d]_[0x%04x]\n", u8FileIdx, uSearchTListFileInfo[u8FileIdx].u32Torrent_ID);
    }

    MApp_BT_SendUnLockMemory();

    return TRUE;
}

/******************************************************************************/
/// Get Torrent File ID
/// @Input File Index
/// @return Torrent File ID
/******************************************************************************/
S32 MApp_BT_GetTorrentFileID(U8 u8Idx)
{
    return uSearchTListFileInfo[u8Idx].u32Torrent_ID;
}

/******************************************************************************/
/// Get Torrent File Name
/// @Input File Index
/// @return Torrent File Name pointer
/******************************************************************************/
U16 *MApp_BT_GetTorrentFileName(U8 u8Idx)
{
    return uSearchTListFileInfo[u8Idx].uFileInfo.u16SearchList_FileName;
}

/******************************************************************************/
/// Read back Search list information.
/// @return BOOLEAN
/******************************************************************************/
BOOLEAN MApp_BT_QuerySearchListResult(void)
{
    U8 u8Cont;
    BOOLEAN bRet = FALSE;
    U32 u32Temp;
    MBX_Msg mbxMsg;

    switch( MApp_BT_GetSearchFileState() )
    {
        case STATE_SEARCH_NONE:
            MApp_BT_SetSearchFileState( STATE_SEARCH_GET_RESPONSE_NUM );
            break;

        case STATE_SEARCH_GET_RESPONSE_NUM:
            if(MApp_BT_MailBoxHandle(10, MB_BTC_RESPONSE_NUM, &mbxMsg))
            {
                u32SearchFileNum = ((((U32)mbxMsg.u8Parameters[0]) << 24)&0xFF000000)|
                                                ((((U32)mbxMsg.u8Parameters[1]) << 16)&0x00FF0000)|
                                                ((((U32)mbxMsg.u8Parameters[2]) << 8 )&0x0000FF00)|
                                                ((((U32)mbxMsg.u8Parameters[3])      )&0x000000FF);

                printf("u32SearchFileNum = %d\n", u32SearchFileNum);
                MApp_BT_SendUnLockMemory();
                if(u32SearchFileNum>0) // get search list!
                {
                    if(u32SearchFileNum>5)
                        u8Cont = 5;
                    else
                        u8Cont = (U8)u32SearchFileNum;

                    MApp_BT_GetMatchTorrentList(MApp_GetSearchStingName(), 0, (U16)u8Cont);
                    MApp_BT_SetSearchFileState( STATE_SEARCH_GET_RESPONSE_LIST );
                }
                else
                { // Find "0" Item for Matched Torrent
                    bRet = TRUE;
                }
            }
            break;

        case STATE_SEARCH_GET_RESPONSE_LIST:
            if(MApp_BT_MailBoxHandle(10, MB_BTC_RESPONSE_LIST, &mbxMsg))
            {
                u32Temp = ((((U32)mbxMsg.u8Parameters[0]) << 24)&0xFF000000)|
                                ((((U32)mbxMsg.u8Parameters[1]) << 16)&0x00FF0000)|
                                ((((U32)mbxMsg.u8Parameters[2]) << 8 )&0x0000FF00)|
                                ((((U32)mbxMsg.u8Parameters[3])      )&0x000000FF);
                //printf("cont [%lx]\n", u32Temp);
                if(u32Temp == 0)
                    u32SearchFileNum = 0;
                else
                {
                    //get Flie list info
                    MApp_BT_GetSearchFlieListInfo();
                }
                MApp_BT_SetSearchFileState( STATE_SEARCH_NONE );
                bRet = TRUE;
            }
            break;
        default:
            break;
    }

    return bRet;

}


/******************************************************************************/
/// Read back Search list information.
/// @return BOOLEAN
/******************************************************************************/
BOOLEAN MApp_BT_QueryTopListOrNewListResult(void)
{
    U8 u8Cont;
    BOOLEAN bRet = FALSE;
    U32 u32Temp;
    MBX_Msg mbxMsg;

    switch( MApp_BT_GetSearchFileState() )
    {
        case STATE_SEARCH_NONE:
            MApp_BT_SetSearchFileState( STATE_SEARCH_GET_RESPONSE_NUM );
            break;

        case STATE_SEARCH_GET_RESPONSE_NUM:
            if(MApp_BT_MailBoxHandle(10, MB_BTC_RESPONSE_NUM, &mbxMsg))
            {
                u32SearchFileNum = ((((U32)mbxMsg.u8Parameters[0]) << 24)&0xFF000000)|
                                                ((((U32)mbxMsg.u8Parameters[1]) << 16)&0x00FF0000)|
                                                ((((U32)mbxMsg.u8Parameters[2]) << 8 )&0x0000FF00)|
                                                ((((U32)mbxMsg.u8Parameters[3])      )&0x000000FF);

                printf("u32SearchFileNum = %d\n", u32SearchFileNum);
                MApp_BT_SendUnLockMemory();
                if(u32SearchFileNum>0) // get search list!
                {
                    if(u32SearchFileNum>NUM_OF_TOP_FILES_MAX)
                        u8Cont = NUM_OF_TOP_FILES_MAX;
                    else
                        u8Cont = (U8)u32SearchFileNum;

                    MApp_BT_GetMatchTorrentList(MApp_GetSearchStingName(), 0, (U16)u8Cont);
                    MApp_BT_SetSearchFileState( STATE_SEARCH_GET_RESPONSE_LIST );
                }
                else
                { // Find "0" Item for Matched Torrent
                    bRet = TRUE;
                }
            }
            break;

        case STATE_SEARCH_GET_RESPONSE_LIST:
            if(MApp_BT_MailBoxHandle(10, MB_BTC_RESPONSE_LIST, &mbxMsg))
            {
                u32Temp = ((((U32)mbxMsg.u8Parameters[0]) << 24)&0xFF000000)|
                                ((((U32)mbxMsg.u8Parameters[1]) << 16)&0x00FF0000)|
                                ((((U32)mbxMsg.u8Parameters[2]) << 8 )&0x0000FF00)|
                                ((((U32)mbxMsg.u8Parameters[3])      )&0x000000FF);
                //printf("cont [%lx]\n", u32Temp);
                if(u32Temp == 0)
                    u32SearchFileNum = 0;
                else
                {
                    //get  Description info
                    MApp_BT_GetTopOrNewListInfo();
                }
                MApp_BT_SetSearchFileState( STATE_SEARCH_GET_LIST_OK );
                MApp_BT_SetImageFileState(STATE_GET_IMAGE_INIT);
                bRet = TRUE;
            }
            break;
        default:
            break;
    }

    return bRet;
}


BOOLEAN MApp_BT_QueryTopListOrNewListImage(void)
{
    BOOLEAN bRet = FALSE;
    U32 u32Temp;
    MBX_Msg mbxMsg;

    switch( MApp_BT_GetImageFileState() )
    {
        case STATE_GET_IMAGE_INIT:
            break;

        case STATE_GET_IMAGE:
            if(MApp_BT_MailBoxHandle(10, MB_BTC_SENDIMGRAWDATA, &mbxMsg))
            {
                u32Temp = ((((U32)mbxMsg.u8Parameters[0]) << 24)&0xFF000000)|
                                ((((U32)mbxMsg.u8Parameters[1]) << 16)&0x00FF0000)|
                                ((((U32)mbxMsg.u8Parameters[2]) << 8 )&0x0000FF00)|
                                ((((U32)mbxMsg.u8Parameters[3])      )&0x000000FF);

                MApp_BT_SetImageFileSize(u32Temp);

                u32Temp = ((((U32)mbxMsg.u8Parameters[4]) << 24)&0xFF000000)|
                                ((((U32)mbxMsg.u8Parameters[5]) << 16)&0x00FF0000)|
                                ((((U32)mbxMsg.u8Parameters[6]) << 8 )&0x0000FF00)|
                                ((((U32)mbxMsg.u8Parameters[7])      )&0x000000FF);

                printf("Image Size [%lx]   ID [%lx]\n", MApp_BT_GetImageFileSize(), u32Temp);
/*
                // if ID not match, ignore it, return false
                if(MApp_BT_GetImageFileID() != u32Temp)
                {
                    MApp_BT_SendUnLockMemory();
                    break;
                }
*/
                //get Flie content
                MApp_BT_GetTopOrNewListImageInfo();

                MApp_BT_SetImageFileState(STATE_GET_IMAGE_OK);

                bRet = TRUE;
            }
            break;

        default:
            break;
    }

    return bRet;
}

BOOLEAN MApp_BT_QueryTopListOrNewListDescription(void)
{
    BOOLEAN bRet = FALSE;
    U32 u32Temp;
    MBX_Msg mbxMsg;

    switch( MApp_BT_GetDescriptionFileState() )
    {
        case STATE_GET_DESCRIPTION_INIT:

            break;

        case STATE_GET_DESCRIPTION:
            if(MApp_BT_MailBoxHandle(10, MB_BTC_SENDDESTXT, &mbxMsg))
            {
                u32Temp = ((((U32)mbxMsg.u8Parameters[0]) << 24)&0xFF000000)|
                                ((((U32)mbxMsg.u8Parameters[1]) << 16)&0x00FF0000)|
                                ((((U32)mbxMsg.u8Parameters[2]) << 8 )&0x0000FF00)|
                                ((((U32)mbxMsg.u8Parameters[3])      )&0x000000FF);

                MApp_BT_SetDescriptionFileSize(u32Temp);

                u32Temp = ((((U32)mbxMsg.u8Parameters[4]) << 24)&0xFF000000)|
                                ((((U32)mbxMsg.u8Parameters[5]) << 16)&0x00FF0000)|
                                ((((U32)mbxMsg.u8Parameters[6]) << 8 )&0x0000FF00)|
                                ((((U32)mbxMsg.u8Parameters[7])      )&0x000000FF);

                printf("Description Size [%lx]   ID [%lx]\n", MApp_BT_GetDescriptionFileSize(), u32Temp);

                // if ID not match, ignore it, return false
                if(MApp_BT_GetDescriptionFileID() != u32Temp)
                {
                    MApp_BT_SendUnLockMemory();
                    break;
                }

                //get Flie list info
                MApp_BT_GetTopOrNewListDescriptionInfo();

                MApp_BT_SetDescriptionFileState(STATE_GET_DESCRIPTION_OK);
                printf("Description State [%d] \n", MApp_BT_GetDescriptionFileState());

                bRet = TRUE;
            }
            break;

        default:
            break;
    }

    return bRet;
}

/******************************************************************************/
/// Get  Image File.
/// @return None
/******************************************************************************/
BOOLEAN MApp_BT_GetImageFile(U8 u8Index)
{
    BOOLEAN bRet = FALSE;

    //printf("Image state: [%d] \n", MApp_BT_GetImageFileState());
    switch(MApp_BT_GetImageFileState())
    {
        case STATE_GET_IMAGE_INIT:
                printf("Image Inedx[%d]\n", u8Index);
                MApp_BT_QueryImageFile(MApp_BT_GetTorrentFileID(u8Index));
                MApp_BT_SetImageFileID(MApp_BT_GetTorrentFileID(u8Index));
            break;

        case STATE_GET_IMAGE:
            if(MApp_BT_QueryTopListOrNewListImage())
                bRet = TRUE;
            break;

        case STATE_GET_IMAGE_OK:
                bRet = TRUE;
            break;

        default:
            break;
    }

    return bRet;
}

/******************************************************************************/
/// Set  Image list File  State.
/// @return None
/******************************************************************************/
void MApp_BT_SetImageFileState(BT_Get_Image_State uState)
{
    u8GetImageState = uState;
}

/******************************************************************************/
/// Read back Image  File State.
/// @return Image File State
/******************************************************************************/
BT_Get_Image_State MApp_BT_GetImageFileState(void)
{
    return u8GetImageState;
}

/******************************************************************************/
/// Read back Image  File Size.
/// @return Image File Size
/******************************************************************************/
void  MApp_BT_SetImageFileSize(U32 u32Size)
{
    u32ImageFileSize = u32Size;
}

/******************************************************************************/
/// Read back Image  File Size.
/// @return Image File Size
/******************************************************************************/
U32 MApp_BT_GetImageFileSize(void)
{
    return u32ImageFileSize;
}

/******************************************************************************/
/// Set  Image list File  ID.
/// @return None
/******************************************************************************/
void MApp_BT_SetImageFileID(U32 u32TorrentID)
{
    u32currentImageFileID = u32TorrentID;
}

/******************************************************************************/
/// Read back Image  File ID.
/// @return Image File ID
/******************************************************************************/
U32 MApp_BT_GetImageFileID(void)
{
    return u32currentImageFileID;
}

/******************************************************************************/
/// Set  Description list File  State.
/// @return None
/******************************************************************************/
void MApp_BT_SetDescriptionFileState(BT_Get_Description_State uState)
{
    u8GetDescriptionState = uState;
}

/******************************************************************************/
/// Read back Description  File State.
/// @return Description File State
/******************************************************************************/
BT_Get_Description_State MApp_BT_GetDescriptionFileState(void)
{
    return u8GetDescriptionState;
}

/******************************************************************************/
/// Read back Description  File Size.
/// @return Description File Size
/******************************************************************************/
U32 MApp_BT_GetDescriptionBuffAddr(void)
{
    return (U32)(((BT_BEON_TO_HK_SHAER_BUFFER_MEMORY_TYPE & MIU1) ? (BT_BEON_TO_HK_SHAER_BUFFER_ADR | MIU_INTERVAL) : (BT_BEON_TO_HK_SHAER_BUFFER_ADR))|0x80000000UL);
}

/******************************************************************************/
/// Set  Description  File Size.
/******************************************************************************/
void  MApp_BT_SetDescriptionFileSize(U32 u32Size)
{
    u32DescriptionFileSize = u32Size;
}


/******************************************************************************/
/// Read back Description  File Size.
/// @return Description File Size
/******************************************************************************/
U32 MApp_BT_GetDescriptionFileSize(void)
{
    return u32DescriptionFileSize;
}

/******************************************************************************/
/// Set  Description list File  ID.
/// @return None
/******************************************************************************/
void MApp_BT_SetDescriptionFileID(U32 u32TorrentID)
{
    u32currentDescriptionFileID = u32TorrentID;
}

/******************************************************************************/
/// Read back Description  File ID.
/// @return Description File ID
/******************************************************************************/
U32 MApp_BT_GetDescriptionFileID(void)
{
    return u32currentDescriptionFileID;
}

/******************************************************************************/
/// Set  Search list File Total State.
/// @return Search list File State
/******************************************************************************/
void MApp_BT_SetSearchFileState(BT_Search_State uState)
{
    u8SearchState = uState;
}


/******************************************************************************/
/// Read back Search list File Total State.
/// @return Search list File State
/******************************************************************************/
BT_Search_State MApp_BT_GetSearchFileState(void)
{
    return u8SearchState;
}

/******************************************************************************/
/// Read back Search list File Total State.
/// @return Search list File State
/******************************************************************************/
BOOLEAN MApp_BT_QuerySearchListResultPage( U16 u16ListStar, U16 u16ListCont)
{
    BOOLEAN bRet = FALSE;
    U32 u32Temp;
    MBX_Msg mbxMsg;

    bRet = MApp_BT_GetMatchTorrentList(MApp_GetSearchStingName(), u16ListStar, u16ListCont);
    if(!bRet)
    {
        printf("MApp_BT_GetMatchTorrentList Fail!\n");
        return FALSE;
    }

    if(MApp_BT_MailBoxHandle(1000, MB_BTC_RESPONSE_LIST))
    {
        u32Temp = ((((U32)mbxMsg.u8Parameters[0]) << 24)&0xFF000000)|
                        ((((U32)mbxMsg.u8Parameters[1]) << 16)&0x00FF0000)|
                        ((((U32)mbxMsg.u8Parameters[2]) << 8 )&0x0000FF00)|
                        ((((U32)mbxMsg.u8Parameters[3])      )&0x000000FF);
        //printf("cont [%lx]\n", u32Temp);
        if(u32Temp == 0)
            u32SearchFileNum = 0;
        else
        {
            //get Flie list info
            MApp_BT_GetSearchFlieListInfo();
        }
        bRet = TRUE;

    }
    return bRet;

}
/******************************************************************************/
/// Read back Search list File Total Number.
/// @return Search list File Total Number
/******************************************************************************/
U32 MApp_BT_GetSearchFileNum(void)
{
    return u32SearchFileNum;
}
/******************************************************************************/
/// Read back the file information.
/// @param  u8FileIdx \b IN Specify the file index offset.
/// @param  pInfo      \b OUT Return the file information.
/// @return BOOLEAN
/******************************************************************************/
BOOLEAN MApp_BT_QuerySearchListFileInfo(U16 u16FileIdx, SearchListFileInfo *pInfo)
{
    SearchTorrentListFileInfo *pFileInfo;

    if(u16FileIdx >= MApp_BT_GetSearchFileNum())
        return FALSE;

    pFileInfo= (SearchTorrentListFileInfo *)(uSearchTListFileInfo+u16FileIdx);

    memcpy(pInfo, pFileInfo->uFileInfo.u16SearchList_FileName, sizeof(SearchListFileInfo));

    return TRUE;
}

/******************************************************************************/
/// Bit-torrent init
/******************************************************************************/
void MApp_BT_MainLink0_Init(void)
{
    U8 i;

    for(i=0;i<NUM_OF_MAINLINK0_PHOTO_PER_PAGE;i++)
    {
        m_MainLink0Status[i].bLinkPhoto_Show=TRUE;
        m_MainLink0Status[i].bLinkPhoto_Ready=FALSE;
    }
    MApp_BT_SetImageFileState(STATE_GET_IMAGE_NONE);
}

void MApp_BT_MainLink1_Init(void)
{
    U8 i;

    for(i=0;i<NUM_OF_MAINLINK1_PHOTO_PER_PAGE;i++)
    {
        m_MainLink1Status[i].bLinkPhoto_Show=TRUE;
        m_MainLink1Status[i].bLinkPhoto_Ready=FALSE;
    }
    MApp_BT_SetImageFileState(STATE_GET_IMAGE_NONE);
}


void MApp_BT_Init(void)
{
    MApp_BT_MainLink0_Init();
    MApp_BT_MainLink1_Init();
    //MApp_BT_CoProcesser_Init();
}

/******************************************************************************/
/// Bit-torrent download task
/******************************************************************************/
void MApp_BT_Task(void)
{
    U8 i;

    if(MApp_BT_GetSystemInitState() != STATE_SYSTEM_INIT_NONE && MApp_BT_GetSystemInitState() != STATE_SYSTEM_INIT_OK)
    {
        MApp_BT_CoProcesser_Init();
        return;
    }

    if(MApp_BT_GetBTFlags()&E_BT_FLAG_LINK0PHOTO_MODE)
    {

#if 1
        for(i=0;i<NUM_OF_MAINLINK0_PHOTO_PER_PAGE;i++)
        {
            if(m_MainLink0Status[i].bLinkPhoto_Show &&  m_MainLink0Status[i].bLinkPhoto_Ready)
            {
                if(_MApp_BT_DrawMainLinkPhotoByIndex(i))
                {
                    m_MainLink0Status[i].bLinkPhoto_Show=FALSE;
                }
                break;//draw next photo on next loop
            }
        }
#endif

#if 1
        for(i=0; i<NUM_OF_MAINLINK0_PHOTO_PER_PAGE; i++)
        {
    #if (BT_DECODE_JPEG_METHOD_0)
            if(!m_MainLink0Status[i].bLinkPhoto_Ready)
    #else
            if(!m_MainLink0Status[i].bLinkPhoto_Ready && (u8BT_JPEG_State == STATE_BT_JPEG_NONE))
    #endif
            {
                if(MApp_BT_GetImageFile(i))
                {
                    MApp_BT_SetImageFileState(STATE_GET_IMAGE_INIT);
                    m_MainLink0Status[i].bLinkPhoto_Ready=TRUE;
                    u8BT_JPEG_State = STATE_BT_JPEG_INIT;
                }
                break;//draw next photo on next loop
            }
        }
#endif
    }
    else if(MApp_BT_GetBTFlags()&E_BT_FLAG_LINK1PHOTO_MODE)
    {

#if 1
        for(i=0; i<NUM_OF_MAINLINK1_PHOTO_PER_PAGE;i++)
        {
            if(m_MainLink1Status[i].bLinkPhoto_Show &&  m_MainLink1Status[i].bLinkPhoto_Ready)
            {
                if(_MApp_BT_DrawMainLinkPhotoByIndex(i))
                {
                    m_MainLink1Status[i].bLinkPhoto_Show=FALSE;
                }
                break;//draw next photo on next loop
            }
        }
#endif

#if 1
        for(i=0; i<NUM_OF_MAINLINK1_PHOTO_PER_PAGE; i++)
        {
    #if (BT_DECODE_JPEG_METHOD_0)
            if(!m_MainLink1Status[i].bLinkPhoto_Ready)
    #else
            if(!m_MainLink1Status[i].bLinkPhoto_Ready && (u8BT_JPEG_State == STATE_BT_JPEG_NONE))
    #endif
            {
                if(MApp_BT_GetImageFile(i))
                {
                    MApp_BT_SetImageFileState(STATE_GET_IMAGE_INIT);
                    m_MainLink1Status[i].bLinkPhoto_Ready=TRUE;
                    u8BT_JPEG_State = STATE_BT_JPEG_INIT;
                }
                break;//draw next photo on next loop
            }
        }
#endif
    }

}

//*****************************************************************************
//Sender: AEON
//Receiver: MIPS
//ParamCount @ Memory buffer.
//Send http command to get the Image file
//Refer to Torrent Client HTTP Commands
//*****************************************************************************
BOOLEAN MApp_BT_GetAnySearch(char *skey,int num,int page)
{
    BOOLEAN bRet = FALSE;
    MBX_Msg uMailBoxPara;
    U16 u16Cont;

    MApp_BT_SendUnLockMemory();

    u8UTF8Sting = (U8 *)(((BT_HK_TO_BEON_SHAER_BUFFER_MEMORY_TYPE & MIU1) ? (BT_HK_TO_BEON_SHAER_BUFFER_ADR | MIU_INTERVAL) : (BT_HK_TO_BEON_SHAER_BUFFER_ADR))|0x80000000);
    memset(u8UTF8Sting,0,128);
    if((num==0)&&(page==0))
        snprintf((char *)u8UTF8Sting,128,"http://ac.gougou.com/ac_box?ac=%s",skey);
    else
        snprintf((char *)u8UTF8Sting,128,"http://dy.gougou.com/btinfo?keyword=%s&num=%d&page=%d",skey,num,page);
    //strncpy((char *)u8UTF8Sting,"http://dy.gougou.com/btinfo?keyword=007&num=5&page=1",128);

    printf("MApp_BT_GetAnySearch cmd=%s\n",(char *)u8UTF8Sting);

    bBtBuff1Lock = TRUE;

    // set Parameter
    uMailBoxPara.u8Index        = MB_BTC_HTTPCMD_ALL;
    uMailBoxPara.u8ParameterCount        = 0;

    bRet = MApp_BT_SendMailBox(uMailBoxPara);

    if(!bRet)
    {
        printf("MApp_BT_GetAnySearch Failed\n");
        return FALSE;
    }

    for(u16Cont = 0; u16Cont<300; u16Cont++)
    {
        if(MApp_BT_MailBoxHandle(10, MB_BTC_SENDALL, &uMailBoxPara))
            break;
    }

    if(u16Cont<300)
    {
        char *p; U32 len;
        len = ((((U32)uMailBoxPara.u8Parameters[0]) << 24)&0xFF000000)|
                ((((U32)uMailBoxPara.u8Parameters[1]) << 16)&0x00FF0000)|
                ((((U32)uMailBoxPara.u8Parameters[2]) << 8 )&0x0000FF00)|
                ((((U32)uMailBoxPara.u8Parameters[3])      )&0x000000FF);
        printf("MApp_BT_GetAnyData Size [%lx]\n", len);

        p=(char *)((BT_BEON_TO_HK_SHAER_BUFFER_MEMORY_TYPE & MIU1) ? (BT_BEON_TO_HK_SHAER_BUFFER_ADR | MIU_INTERVAL) : (BT_BEON_TO_HK_SHAER_BUFFER_ADR));
        //PrintfInfo(p,(char *)(p+len));
        DataParser(p,len);

        printf("DataParser finished!\n");
        #if 0
        {
            int i,j;
            for(i=0;i<10;i++)
            {
                for(j=EN_CID;j<EN_MAX_FILEINFO;j++)
                {
                    PrintfInfo(SearchResult[i][j][EN_START],SearchResult[i][j][EN_END]);
                }
            }
        }
        #endif
    }
    else
    {
        printf("MApp_BT_GetAnySearch Failed0\n");
        return FALSE;
    }

    printf("MApp_BT_GetAnySearch ok\n");
    return TRUE;
}
//*****************************************************************************
//Sender: AEON
//Receiver: MIPS
//ParamCount @ Memory buffer.
//Send http command to get the Image file
//Refer to Torrent Client HTTP Commands
//*****************************************************************************
BOOLEAN MApp_BT_GetAnyData(char *BURL)
{
    BOOLEAN bRet = FALSE;
    MBX_Msg uMailBoxPara;
    U16 u16Cont;
    int i;U32 u32addr;


    MApp_BT_SendUnLockMemory();

    u8UTF8Sting = (U8 *)(((BT_HK_TO_BEON_SHAER_BUFFER_MEMORY_TYPE & MIU1) ? (BT_HK_TO_BEON_SHAER_BUFFER_ADR | MIU_INTERVAL) : (BT_HK_TO_BEON_SHAER_BUFFER_ADR))|0x80000000);
    memset(u8UTF8Sting,0,128);
    //strncpy((char *)u8UTF8Sting,"http://dy.gougou.com/top_movie?num=10",128);
    //strncpy((char *)u8UTF8Sting,"http://dy.gougou.com/rank_list/rank1.xml",128);
    strncpy((char *)u8UTF8Sting,BURL,128);
    printf("MApp_BT_GetAnyData cmd=%s\n",(char *)u8UTF8Sting);

    bBtBuff1Lock = TRUE;

    // set Parameter
    uMailBoxPara.u8Index        = MB_BTC_HTTPCMD_ALL;
    uMailBoxPara.u8ParameterCount        = 0;

    bRet = MApp_BT_SendMailBox(uMailBoxPara);

    if(!bRet)
    {
        printf("MApp_BT_GetAnyData Failed\n");
        return FALSE;
    }

    for(u16Cont = 0; u16Cont<300; u16Cont++)
    {
        if(MApp_BT_MailBoxHandle(10, MB_BTC_SENDALL, &uMailBoxPara))
            break;
    }

    if(u16Cont<300)
    {
        char *p; U32 len;
        len = ((((U32)uMailBoxPara.u8Parameters[0]) << 24)&0xFF000000)|
                ((((U32)uMailBoxPara.u8Parameters[1]) << 16)&0x00FF0000)|
                ((((U32)uMailBoxPara.u8Parameters[2]) << 8 )&0x0000FF00)|
                ((((U32)uMailBoxPara.u8Parameters[3])      )&0x000000FF);
        printf("MApp_BT_GetAnyData Size [%lx]\n", len);

        p=(char *)((BT_BEON_TO_HK_SHAER_BUFFER_MEMORY_TYPE & MIU1) ? (BT_BEON_TO_HK_SHAER_BUFFER_ADR | MIU_INTERVAL) : (BT_BEON_TO_HK_SHAER_BUFFER_ADR));
        //PrintfInfo(p,(char *)(p+len));
        DataParser(p,len);

        printf("DataParser finished!\n");
    }
    else
    {
        printf("MApp_BT_GetAnyData Failed0\n");
        return FALSE;
    }

//------------------------------------------------------------------------------------------
    u32addr = ((BT_HK_IMAGE_DATA_BUFFER_MEMORY_TYPE & MIU1) ? (BT_HK_IMAGE_DATA_BUFFER_ADR | MIU_INTERVAL) : (BT_HK_IMAGE_DATA_BUFFER_ADR));
    for(i=0;i<10;i++)
    {
        MApp_BT_SendUnLockMemory();
        u8UTF8Sting = (U8 *)(((BT_HK_TO_BEON_SHAER_BUFFER_MEMORY_TYPE & MIU1) ? (BT_HK_TO_BEON_SHAER_BUFFER_ADR | MIU_INTERVAL) : (BT_HK_TO_BEON_SHAER_BUFFER_ADR))|0x80000000);
        memset(u8UTF8Sting,0,128);
        CopyString((char *)u8UTF8Sting,MovieList[i][EN_PIC][EN_START],MovieList[i][EN_PIC][EN_END]);
        printf("MApp_BT_GetAnyData cmd[%d]=%s\n",i,(char *)u8UTF8Sting);

        bBtBuff1Lock = TRUE;

        // set Parameter
        uMailBoxPara.u8Index        = MB_BTC_HTTPCMD_ALL;
        uMailBoxPara.u8ParameterCount        = 4;
        uMailBoxPara.u8Parameters[0] = (U8)(u32addr>>24)|0x80;
        uMailBoxPara.u8Parameters[1] = (U8)(u32addr>>16);
        uMailBoxPara.u8Parameters[2] = (U8)(u32addr>>8);
        uMailBoxPara.u8Parameters[3] = (U8)(u32addr) ;

        bRet = MApp_BT_SendMailBox(uMailBoxPara);

        if(!bRet)
        {
            printf("MApp_BT_GetAnyData Failed1\n");
            return FALSE;
        }

        for(u16Cont = 0; u16Cont<300; u16Cont++)
        {
            if(MApp_BT_MailBoxHandle(10, MB_BTC_SENDALL, &uMailBoxPara))
                break;
        }

        if(u16Cont<300)
        {
            U32 len;
            len = ((((U32)uMailBoxPara.u8Parameters[0]) << 24)&0xFF000000)|
                ((((U32)uMailBoxPara.u8Parameters[1]) << 16)&0x00FF0000)|
                ((((U32)uMailBoxPara.u8Parameters[2]) << 8 )&0x0000FF00)|
                ((((U32)uMailBoxPara.u8Parameters[3])      )&0x000000FF);
            printf("MApp_BT_GetPic [%d]Size [%lx]\n",i, len);

            MoviePIC[i][EN_START]=(char *)u32addr;
            u32addr+=len;
            MoviePIC[i][EN_END]=(char *)u32addr;
            u32addr=(u32addr+8)&0xfffffff8;
        }
        else
        {
            printf("MApp_BT_GetAnyData Failed2\n");
            return FALSE;
        }
    }
        printf("MApp_BT_GetAnyData ok\n");
    return TRUE;
}

//----------------------------------------------------------------------
// strstrn --
//     Locate the first instance of a substring in a string before ppstringend
// Results:
//     If string contains substring, the return value is the
//     location of the first matching instance of substring
//     in string. If string doesn't contain substring, the
//     return value is 0. Matching is done on an exact
//     character-for-character basis with no wildcards or special
//     characters.
// Side effects:
//     None.
//----------------------------------------------------------------------
int strstrn(char **ppstringstart,char **ppstringend,char *psubstring)
{
    char *a,*b;
    //First scan quickly through the two strings looking for a
    //single-character match. When it's found, then compare the
    //rest of the substring.
    b = psubstring;
    if(*b==0)
        return 1;
    if(*ppstringstart>=*ppstringend)
        return 0;

    for(;(**ppstringstart!=0)&&(*ppstringstart<*ppstringend);(*ppstringstart)++)
    {
        if(**ppstringstart != *b)
            continue;
        a = *ppstringstart;
        while(1)
        {
            if(*b == 0)
                return 1;

            if(*a++ != *b++)
                break;
        }
        b = psubstring;
    }
    return 0;
}
// find out how many keyword blocks from pstringstart to pstringend
// return the number
int strnum(char *pstringstart,char *pstringend,char *pskeyword)
{
    char key1[32],key2[32];
    char **s1,**s2;
    int counter=0;

    s1=&pstringstart;
    s2=&pstringend;
    snprintf(key1,32,"<%s",pskeyword);
    snprintf(key2,32,"</%s>",pskeyword);
    while(*s1<*s2)
    {
        if(0==strstrn(s1,s2,key1))
            break;

        if(0==strstrn(s1,s2,key2))
            break;
        counter++;
    }

    return counter;
}
// find out which place the No.n keyword blocks is from pstringstart to pstringend
// return the true or false, the start & end pointer.
int strkeyn(char **ppstringstart,char **ppstringend,char *pskeyword,int counter)
{
    char key1[32],key2[32];
    char *pstemp;

    snprintf(key1,32,"<%s",pskeyword);
    snprintf(key2,32,"</%s>",pskeyword);

    if(counter<=0)
        return 0;

    while(--counter>0)
    {
        if(0==strstrn(ppstringstart,ppstringend,key1))
            return 0;

        if(0==strstrn(ppstringstart,ppstringend,key2))
            return 0;
    }

    if(0==strstrn(ppstringstart,ppstringend,key1))
        return 0;

    pstemp=strchr(*ppstringstart,'>');
    if( (unsigned int)(pstemp-*ppstringstart)==(strlen(pskeyword)+1) )
        *ppstringstart=1+pstemp;

    pstemp=*ppstringstart;
    if(strstrn(&pstemp,ppstringend,key2))
    {
        *ppstringend = pstemp;
        return 1;
    }

    return 0;
}
// find out <keyword1 keyword2=" ">
// return the true or false, the start & end pointer.
int strdata(char **ppstringstart,char **ppstringend,char *pskeyword1,char *pskeyword2)
{
    char key1[32],key2[32];

    snprintf(key1,32,"<%s",pskeyword1);
    snprintf(key2,32,"%s=\"",pskeyword2);

    if(0==strstrn(ppstringstart,ppstringend,key1))
        return 0;

    *ppstringend=strchr(*ppstringstart,'>');
    if(*ppstringend==0)
        return 0;

    if(0==strstrn(ppstringstart,ppstringend,key2))
        return 0;
    *ppstringstart+=strlen(key2);

    *ppstringend=strchr(*ppstringstart,'"');

    if(*ppstringend)
        return 1;
    else
        return 0;
}

/////////////////////////////////////////////////////////////////////////////////////
void CopyString(char *dst, char *s1, char *s2)
{
    int i,max;
    max = s2-s1;
    for(i=0;i<max;i++)
        *dst++=*s1++;
    *dst='\0';
}
void PrintfInfo(char *s1,char *s2)
{
    int i=0,max;
    max = s2-s1;
        while((*s1!=0)&&(*(s1+1)!=0)&&(++i<(max+1)))
            putchar((int)(*s1++));
        printf("\n");
}
int StrToInt(char * str)
{
    int value = 0;
    int sign = 1;
    if(*str == '-')
    {
            sign = -1;
            str++;
    }
    while(*str)
    {
            value = value * 10 + *str - '0';
            str++;
    }
    return sign*value;
}

/////////////////////////////////////////////////////////////////////////////////////

int DataParser(char *sInputBuffer, int iLength)
{
    char *sStartBuffer,*sEndBuffer;
    int i,j,total;

    sStartBuffer=sInputBuffer;
    sEndBuffer=sInputBuffer+iLength;

    if(strnum(sStartBuffer,sEndBuffer,"ResultSet"))
    {
        {
            char *pcounterStart,*pcounterEnd;char temp[32];
            pcounterStart=sStartBuffer;
            pcounterEnd=sEndBuffer;
            strdata(&pcounterStart,&pcounterEnd,"Query","Count");
            //PrintfInfo(pcounterStart,pcounterEnd);
            memset(temp,0,32);
            CopyString(temp,pcounterStart,pcounterEnd);
            ResultCounter = StrToInt(temp);
        }
        strkeyn(&sStartBuffer,&sEndBuffer,"ResultSet",1);
        total=strnum(sStartBuffer,sEndBuffer,"FileInfo");
        for(i=0;(i<total)&&(i<10);i++)
        {
            SearchResult[i][EN_BLOCKR][EN_START]=sStartBuffer;
            SearchResult[i][EN_BLOCKR][EN_END]=sEndBuffer;
            strkeyn(&SearchResult[i][EN_BLOCKR][EN_START],&SearchResult[i][EN_BLOCKR][EN_END],"FileInfo",i+1);
            for(j=EN_BLOCKR+1;j<EN_MAX_FILEINFO;j++)
            {
                SearchResult[i][j][EN_START]=SearchResult[i][EN_BLOCKR][EN_START];
                SearchResult[i][j][EN_END]=SearchResult[i][EN_BLOCKR][EN_END];
            }
            strkeyn(&SearchResult[i][EN_CID][EN_START],&SearchResult[i][EN_CID][EN_END],"Cid",1);
            strkeyn(&SearchResult[i][EN_TITLE][EN_START],&SearchResult[i][EN_TITLE][EN_END],"Title",1);
            SearchResult[i][EN_TITLE][EN_START]+=strlen("<![CDATA[");
            SearchResult[i][EN_TITLE][EN_END]-=strlen("]]>");
            strkeyn(&SearchResult[i][EN_SIZE][EN_START],&SearchResult[i][EN_SIZE][EN_END],"Size",1);
            strkeyn(&SearchResult[i][EN_FORMAT][EN_START],&SearchResult[i][EN_FORMAT][EN_END],"Format",1);
            strkeyn(&SearchResult[i][EN_PLAYTIME][EN_START],&SearchResult[i][EN_PLAYTIME][EN_END],"PlayTime",1);
            strkeyn(&SearchResult[i][EN_BITRATE][EN_START],&SearchResult[i][EN_BITRATE][EN_END],"BitRate",1);
            strkeyn(&SearchResult[i][EN_TORRENT][EN_START],&SearchResult[i][EN_TORRENT][EN_END],"Torrent",1);
            strkeyn(&SearchResult[i][EN_TONUM][EN_START],&SearchResult[i][EN_TONUM][EN_END],"TorrentNum",1);
        }
    }
    else if(strnum(sStartBuffer,sEndBuffer,"moviesets"))
    {
        strkeyn(&sStartBuffer,&sEndBuffer,"moviesets",1);
        total=strnum(sStartBuffer,sEndBuffer,"movie");
        for(i=0;(i<total)&&(i<10);i++)
        {
            MovieList[i][EN_BLOCKM][EN_START]=sStartBuffer;
            MovieList[i][EN_BLOCKM][EN_END]=sEndBuffer;
            strkeyn(&MovieList[i][EN_BLOCKM][EN_START],&MovieList[i][EN_BLOCKM][EN_END],"movie",i+1);
            for(j=EN_BLOCKM+1;j<EN_MAX_MOVEINFO;j++)
            {
                MovieList[i][j][EN_START]=MovieList[i][EN_BLOCKM][EN_START];
                MovieList[i][j][EN_END]=MovieList[i][EN_BLOCKM][EN_END];
            }
            strdata(&MovieList[i][EN_MID][EN_START],&MovieList[i][EN_MID][EN_END],"movie","id");
            if(0==strkeyn(&MovieList[i][EN_NAME][EN_START],&MovieList[i][EN_NAME][EN_END],"key",1))
            {
                MovieList[i][EN_NAME][EN_START]=MovieList[i][EN_BLOCKM][EN_START];
                MovieList[i][EN_NAME][EN_END]=MovieList[i][EN_BLOCKM][EN_END];
                strkeyn(&MovieList[i][EN_NAME][EN_START],&MovieList[i][EN_NAME][EN_END],"name",1);
            }
            strkeyn(&MovieList[i][EN_DESC][EN_START],&MovieList[i][EN_DESC][EN_END],"desc",1);
            strkeyn(&MovieList[i][EN_PIC][EN_START],&MovieList[i][EN_PIC][EN_END],"pic",1);
        }
    }
    else if(strnum(sStartBuffer,sEndBuffer,"Suggest"))
    {
        strkeyn(&sStartBuffer,&sEndBuffer,"Suggest",1);
        total=strnum(sStartBuffer,sEndBuffer,"SuggestWord");
        ResultCounter = total;
        for(i=0;(i<total)&&(i<10);i++)
        {
            MovieKeyword[i][EN_START]=sStartBuffer;
            MovieKeyword[i][EN_END]=sEndBuffer;
            strkeyn(&MovieKeyword[i][EN_START],&MovieKeyword[i][EN_END],"SuggestWord",i+1);
            //PrintfInfo(MovieKeyword[i][EN_START],MovieKeyword[i][EN_END]);
        }
    }
    else
    {
            printf("Can not matched!\n");
        return 0;
    }

    return 1;
}
#endif //#if (ENABLE_THUNDER_DOWNLOAD)

#endif //

#undef MAPP_BT_C

