////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (MStar Confidential Information) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////
#define _MAPP_OAD_C_

/******************************************************************************/
/*                              Header Files                                  */
/******************************************************************************/

// Global Layer
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "Board.h"
#include "datatype.h"
#include "sysinfo.h"
#include "debug.h"
#if (OBA2)
#include <unistd.h>
#endif //(OBA2)

#if ENABLE_OAD
#include "msAPI_Bootloader.h"
#include "msAPI_oad_parser.h"
#include "msAPI_oad_process.h"
#include "msAPI_Timer.h"
#include "MApp_OAD.h"
#include "MApp_Scan.h"
#include "MApp_GlobalVar.h"
#include "MApp_Version.h"
#include "MApp_Key.h"
#include "imginfo.h"
#include "drvTVEncoder.h"
#include "MApp_TopStateMachine.h"
#include "SysInit.h"
#include "mapp_swupdate.h"
#include "MApp_InputSource.h"
#include "MApp_ChannelChange.h"
#include "MApp_USBDownload.h"
//#include "mapp_si_private.h"
#include "apiXC.h"
#include "apiXC_Sys.h"
#include "MApp_ZUI_Main.h"
#include "ZUI_tables_h.inl"
#include "ZUI_exefunc.h"
#include "imginfo.h"
#include "msAPI_Ram.h"
#include "msAPI_Bootloader.h"
#include "msAPI_Tuner.h"
#include "msAPI_FreqTableDTV.h"
#include "msAPI_Tuner.h"
#include "msAPI_Global.h"
#include "MApp_GlobalFunction.h"
#include "drvSERFLASH.h"
#include "msAPI_FreqTableDTV.h"
#include "MApp_SaveData.h"
#if (BLOADER)
#include "MApp_BL_SI.h"
#include "MApp_BL_Demux.h"
#endif
/*------------------------------------------------------------------------------
| Define
*-----------------------------------------------------------------------------*/
#define MONITOR_DSI_TIME_OUT    60000//ms
#define MONITOR_DII_TIME_OUT    60000//ms
#define MONITOR_DDB_TIME_OUT    60000*20//ms
#define MONITOR_UNT_TIME_OUT    60000//ms
#define MONITOR_USER_TIME_OUT    60000//ms
#define DATA_BC_ID_SSU          0x000A // DVB-SSU
#define DATA_BC_ID_UK_EC        0x0111 // UK Engineering Channel
#define DVB_OUI                 0x00015A
#define SSU_UPDATETYPE_STANDARD             0x01
#define SSU_UPDATETYPE_UNT_BROADCAST        0x02
#define SSU_UPDATETYPE_UNT_RETCHANNEL       0x03
#define MAX_DDB_MSGSIZE 4066

#if (OBA2)
#define OAD_DMXBUF_ADR_MONITOR      DOWNLOAD_ZIPBUFFER_ADR
#define OAD_DMXBUF_ADR_DOWNLOAD     OAD_DMXBUF_ADR_MONITOR+DMX_BUF_SIZE_MONITOR
#define DOWNLOAD_BUFFER_ADR_OAD     (( DOWNLOAD_BUFFER1_MEMORY_TYPE & MIU1) ? (DOWNLOAD_BUFFER1_ADR | MIU_INTERVAL) : (DOWNLOAD_BUFFER1_ADR))
#define DOWNLOAD_BUFFER_TYPE_OAD     (( DOWNLOAD_BUFFER1_MEMORY_TYPE & MIU1) ? MIU_SDRAM12SDRAM0 : MIU_SDRAM2SDRAM)
#define DOWNLOAD_BUFFER_LEN_OAD      DOWNLOAD_BUFFER1_LEN
#else
#define DOWNLOAD_BUFFER_ADR_OAD     (( DOWNLOAD_BUFFER_MEMORY_TYPE & MIU1) ? (DOWNLOAD_BUFFER_ADR | MIU_INTERVAL) : (DOWNLOAD_BUFFER_ADR))
#define DOWNLOAD_BUFFER_TYPE_OAD     (( DOWNLOAD_BUFFER_MEMORY_TYPE & MIU1) ? MIU_SDRAM12SDRAM0 : MIU_SDRAM2SDRAM)
#define DOWNLOAD_BUFFER_LEN_OAD      DOWNLOAD_BUFFER_LEN
#endif

#define VERSION_CHECK 1
#define FLASH_DIRECT_WRITE 0

#define MEMBER_OFFSET(struct_name, member_name) ( (U32) &(((struct_name *)0)->member_name) )                        // 16-bit Offset
#define EEPROM_OFFSET(member_name)              (RM_ADDR_DOWNLOAD+MEMBER_OFFSET(ST_DOWNLOAD_INFO, member_name))     // ST_DOWNLOAD_INFO member offset on EEPROM

#define SW_UPDATE_BLOCK_SIZE    0x10000    //SIZE_64KB
#define SW_UPDATE_ERASE_SIZE    0x800000
#define OAD_SCAN_WAIT_TABLE_TIME 20000  // 10 seconds
#define LOWER_VERSION_DOWNLOAD  0
#define HW_MODEL_VER_CHECK      0

#if (BLOADER)
#define MAPP_DMX_SET_PID(a,b)   MApp_BL_Dmx_SetFid(a,(EN_BL_FID)b)
#define MAPP_DMX_GET_PID(a)     MApp_BL_Dmx_GetFid((EN_BL_FID)a)
#define MAPP_DMX_GETSI_4K_SECBUFFER()     MApp_BL_Dmx_GetSI4KSectionBuffer()
#define OAD_MONITOR_FID      EN_BL_OAD_MONITOR_FID
#define OAD_DOWNLOAD_FID     EN_BL_OAD_DOWNLOAD_FID
#else
#define MAPP_DMX_SET_PID(a,b)   MApp_Dmx_SetFid(a,(EN_FID)b)
#define MAPP_DMX_GET_PID(a)   MApp_Dmx_GetFid((EN_FID)a)
#define MAPP_DMX_GETSI_4K_SECBUFFER()     MApp_Dmx_GetSI4KSectionBuffer()

#define OAD_MONITOR_FID      EN_OAD_MONITOR_FID
#define OAD_DOWNLOAD_FID     EN_OAD_DOWNLOAD_FID
#endif

#if (OBA2)
FILE *pFile;
FILE *pFile2;
#define MAX_OPEN_COUNT 20
#define OAD_VOLUME "APP"
#define OAD_VOLUME_SIZE 0x1E00000
#define OAD_ENV_FILE "/oad.txt"
#define OAD_BIN_FILE "/application/oad.bin"
#endif //(OBA2)

/*------------------------------------------------------------------------------
| Variable
*-----------------------------------------------------------------------------*/
static U16 wOad_PID;
static MS_TP_SETTING stTPSetting;
static U8 cRFChannelNumber;
static U16 wTransportStream_ID_OAD;
static U16 wOriginalNetwork_ID_OAD;
static U16 wService_ID_OAD;
static U32 tvVersion,tsVersion;
U32 toSaveVersion=0x0;
#if (!BLOADER)
#if (!OBA2)
static struct DEMUXBUF demuxBuf;
#endif
#endif //(!BLOADER)
static U8 versionNum = 0xff;
static U32 u32DownloadSize = 0x0;
static EN_OAD_MONITOR_STATE _enMonitorState;
static EN_OAD_DOWNLOAD_STATE _enDownloadState;
static EN_OAD_APP_STATE _enAppState;
static UNT_DESCRIPTOR untDescriptor ;
static MEMBER_SERVICETYPE bServiceType;
static WORD wCurrentPosition;
static U16 u16StartBlock, u16EndBlock, u16BlockNo;
static U32 u32FlashStartAddr,u32FlashEndAddr;
static MS_TP_SETTING stOadTPSetting;
static U8 u8OadRFCh;
static U32 u32OadScanWaitTableTimer;
static EN_OAD_SCAN_STATE enOADScanState=STATE_OAD_SCAN_INIT;
static U8 oadCH=0 ;
static BOOLEAN _bOAD_AutoScanEnable=FALSE;
static BOOLEAN bNITSignal_DSI;

#if (OBA2)
extern BOOLEAN MApp_Obama_SwUpdate(U32 u32Addr, U32 u32Size);
#else
extern pZUIDrawCB pZUIDrawPercentageCB;
extern void MApp_ZUI_OADSwUpdate_ProgressBar(U8 percent) ;
#endif

#if (BLOADER)
extern void MApp_BL_DisplaySystem(U8 u8Percent);
extern void MApp_BL_DisplaySystem_clear(void);
extern void MApp_BL_DisplaySystem_setStatus(S8 *status);
#endif //(BLOADER)

/*------------------------------------------------------------------------------
| Functions
*-----------------------------------------------------------------------------*/
void MApp_OAD_SetInfo_ForBL(U16 u16PID, U32 u32Freq, U8 u8BandWidth)
{
    //printf("S pid: 0x%x, freq: %ld, bw: 0x%bx\n", u16PID, u32Freq, u8BandWidth);
#if (EEPROM_DB_STORAGE==EEPROM_SAVE_NONE)
   {
        static U32 savedVersion=0;
        U32 dst=0;
        ST_DOWNLOAD_INFO dl_info;

        {
            U16 u16PID_saved=0;
            U32 u32Freq_saved=0;
            U8 u8BandWidth_saved=0;
            void MApp_OAD_GetInfo_BL(U16* u16PID, U32* u32Freq, U8* u8BandWidth);
            MApp_OAD_GetInfo_BL(&u16PID_saved, &u32Freq_saved, &u8BandWidth_saved);
            if((u16PID == u16PID_saved) && (u32Freq == u32Freq_saved) && (u8BandWidth == u8BandWidth_saved))
                return;
        }
        if(VERSION_CHECK)
        {
            if(savedVersion >= toSaveVersion)
                return;
            savedVersion = toSaveVersion;
        }
        MDrv_FLASH_WriteProtect_Disable_Range_Set(SYSTEM_BANK_SIZE * OAD_DB_BANK, SYSTEM_BANK_SIZE); // MDrv_FLASH_WriteProtect(DISABLE); // <-@@@

        dst = (SYSTEM_BANK_SIZE * OAD_DB_BANK);
        OAD_DEBUG( printf("OAD_DB_BANK 0x%x\n", OAD_DB_BANK) );
        OAD_DEBUG( printf("dst 0x%x\n", dst) );

        memset(&dl_info, 0, sizeof(dl_info));
        dl_info.u8DL_OAD_TSFreq1 = (U8)((u32Freq & 0xFF000000)>>24);
        dl_info.u8DL_OAD_TSFreq2 = (U8)((u32Freq & 0x00FF0000)>>16);
        dl_info.u8DL_OAD_TSFreq3 = (U8)((u32Freq & 0x0000FF00)>>8);
        dl_info.u8DL_OAD_TSFreq4 = (U8)((u32Freq & 0x000000FF)>>0);
        dl_info.u8DL_OAD_PID_High =  (U8)(u16PID >> 8);
        dl_info.u8DL_OAD_PID_Low =  (U8)(u16PID &0x00FF);
        dl_info.u8DL_OAD_BW = u8BandWidth;

        MDrv_FLASH_AddressErase(dst, SYSTEM_BANK_SIZE, TRUE);
        MDrv_FLASH_Write(dst, sizeof(dl_info), (U8*)&dl_info);
        MDrv_FLASH_WriteProtect(ENABLE);
    }
    OAD_DEBUG(printf("MApp_OAD_SetInfo_ForBL() ok\n"));
#else
    // OAD PID
    msAPI_rmWriteByte(EEPROM_OFFSET(u8DL_OAD_PID_High), (U8)(u16PID >> 8));
    msAPI_rmWriteByte(EEPROM_OFFSET(u8DL_OAD_PID_Low), (U8)(u16PID &0x00FF));

    // Phyical Frequency
    msAPI_rmWriteByte(EEPROM_OFFSET(u8DL_OAD_TSFreq1), (U8)((u32Freq & 0xFF000000)>>24));
    msAPI_rmWriteByte(EEPROM_OFFSET(u8DL_OAD_TSFreq2), (U8)((u32Freq & 0x00FF0000)>>16));
    msAPI_rmWriteByte(EEPROM_OFFSET(u8DL_OAD_TSFreq3), (U8)((u32Freq & 0x0000FF00)>>8));
    msAPI_rmWriteByte(EEPROM_OFFSET(u8DL_OAD_TSFreq4), (U8)(u32Freq & 0x000000FF));

    // DVB-T System Bandwidth
    msAPI_rmWriteByte(EEPROM_OFFSET(u8DL_OAD_BW), u8BandWidth);
#endif
}

void MApp_OAD_GetInfo_BL(U16* u16PID, U32* u32Freq, U8* u8BandWidth)
{
#if (EEPROM_DB_STORAGE==EEPROM_SAVE_NONE)
    U32 dst=0;
    ST_DOWNLOAD_INFO dl_info;

    dst = (SYSTEM_BANK_SIZE * OAD_DB_BANK);
    memset(&dl_info, 0, sizeof(dl_info));
    MDrv_FLASH_Read(dst, sizeof(dl_info), (U8*)&dl_info);
    *u32Freq = 0;
    *u32Freq |= ((U16)(dl_info.u8DL_OAD_TSFreq1) << 24);
    *u32Freq |= ((U16)(dl_info.u8DL_OAD_TSFreq2) << 16);
    *u32Freq |= ((U16)(dl_info.u8DL_OAD_TSFreq3) << 8);
    *u32Freq |= (U16)(dl_info.u8DL_OAD_TSFreq4);
    *u16PID = 0;
    *u16PID |= ((U16)(dl_info.u8DL_OAD_PID_High) << 8);
    *u16PID |= (U16)(dl_info.u8DL_OAD_PID_Low);
    *u8BandWidth = dl_info.u8DL_OAD_BW;
#else
    U8 u8Temp;

    // OAD PID
    *u16PID = 0;
    msAPI_rmBurstReadBytes(EEPROM_OFFSET(u8DL_OAD_PID_High), &u8Temp, 1);
    *u16PID |= ((U16)(u8Temp) << 8);
    msAPI_rmBurstReadBytes(EEPROM_OFFSET(u8DL_OAD_PID_Low), &u8Temp, 1);
    *u16PID |= (U16)(u8Temp);

    // Phyical Frequency
    *u32Freq = 0;
    msAPI_rmBurstReadBytes(EEPROM_OFFSET(u8DL_OAD_TSFreq1), &u8Temp, 1);
    *u32Freq |= ((U32)(u8Temp)<<24);
    msAPI_rmBurstReadBytes(EEPROM_OFFSET(u8DL_OAD_TSFreq2), &u8Temp, 1);
    *u32Freq |= ((U32)(u8Temp)<<16);
    msAPI_rmBurstReadBytes(EEPROM_OFFSET(u8DL_OAD_TSFreq3), &u8Temp, 1);
    *u32Freq |= ((U32)(u8Temp)<<8);
    msAPI_rmBurstReadBytes(EEPROM_OFFSET(u8DL_OAD_TSFreq4), &u8Temp, 1);
    *u32Freq |= (U32)(u8Temp);


    // DVB-T System Bandwidth
    msAPI_rmBurstReadBytes(EEPROM_OFFSET(u8DL_OAD_BW), &u8Temp, 1);
    *u8BandWidth = u8Temp;
#endif
    //printf("G pid: 0x%x, freq: %ld, bw: 0x%bx\n", *u16PID, *u32Freq, *u8BandWidth);
}

void MApp_OAD_SetInfo(void)
{
#if (EEPROM_DB_STORAGE==EEPROM_SAVE_NONE)
    U32 dst=0;
    ST_DOWNLOAD_INFO dl_info;

    dst = (SYSTEM_BANK_SIZE * OAD_DB_BANK);
    OAD_DEBUG( printf("OAD_DB_BANK 0x%x\n", OAD_DB_BANK) );
    OAD_DEBUG( printf("dst 0x%x\n", dst) );
    memset(&dl_info, 0, sizeof(dl_info));
    MDrv_FLASH_Read(dst, sizeof(dl_info), (U8*)&dl_info);
    if((dl_info.u8DL_OAD_MonitorState == MApp_OAD_GetMonitorState()) &&
        (dl_info.u16DL_OAD_NID == wOriginalNetwork_ID_OAD) &&
        (dl_info.u16DL_OAD_TID == wTransportStream_ID_OAD) &&
        (dl_info.u16DL_OAD_SID == wService_ID_OAD) &&
        (dl_info.u32DL_OAD_StartTime == untDescriptor.untSchedule.u32StartTime) &&
        (dl_info.u32DL_OAD_EndTime == untDescriptor.untSchedule.u32EndTime) &&
        (dl_info.u16DL_OAD_AssociationTag == untDescriptor.untLocation.association_tag))
    {
        return;
    }
    //printf("%s: MonitorState: %x, %x, at %d\n", __func__, (dl_info.u8DL_OAD_MonitorState), (U8)MApp_OAD_GetMonitorState(), __LINE__);

    MDrv_FLASH_WriteProtect_Disable_Range_Set(SYSTEM_BANK_SIZE * OAD_DB_BANK, SYSTEM_BANK_SIZE); // MDrv_FLASH_WriteProtect(DISABLE); // <-@@@
    memset(&dl_info, 0, sizeof(dl_info));
    dl_info.u8DL_OAD_MonitorState = MApp_OAD_GetMonitorState();
    dl_info.u16DL_OAD_NID = wOriginalNetwork_ID_OAD;
    dl_info.u16DL_OAD_TID = wTransportStream_ID_OAD;
    dl_info.u16DL_OAD_SID = wService_ID_OAD;
    dl_info.u32DL_OAD_StartTime = untDescriptor.untSchedule.u32StartTime;
    dl_info.u32DL_OAD_EndTime = untDescriptor.untSchedule.u32EndTime;
    dl_info.u16DL_OAD_AssociationTag = untDescriptor.untLocation.association_tag;
    MDrv_FLASH_AddressErase(dst, SYSTEM_BANK_SIZE, TRUE);
    MDrv_FLASH_Write(dst, sizeof(dl_info), (U8*)&dl_info);
    MDrv_FLASH_WriteProtect(ENABLE);
#else //(EEPROM_DB_STORAGE==EEPROM_SAVE_NONE)
   // monitor state
   msAPI_rmWriteByte(EEPROM_OFFSET(u8DL_OAD_MonitorState),MApp_OAD_GetMonitorState());

   // wOriginalNetwork_ID_OAD
   msAPI_rmBurstWriteBytes(EEPROM_OFFSET(u16DL_OAD_NID), (U8*)&wOriginalNetwork_ID_OAD, 2);

   // wTransportStream_ID_OAD
   msAPI_rmBurstWriteBytes(EEPROM_OFFSET(u16DL_OAD_TID), (U8*)&wTransportStream_ID_OAD, 2);

   // wService_ID_OAD
   msAPI_rmBurstWriteBytes(EEPROM_OFFSET(u16DL_OAD_SID), (U8*)&wService_ID_OAD, 2);

   // untDescriptor.untSchedule.u32StartTime
   msAPI_rmBurstWriteBytes(EEPROM_OFFSET(u32DL_OAD_StartTime), (U8*)&untDescriptor.untSchedule.u32StartTime,4);

   // untDescriptor.untSchedule.u32EndTime
   msAPI_rmBurstWriteBytes(EEPROM_OFFSET(u32DL_OAD_EndTime), (U8*)&untDescriptor.untSchedule.u32EndTime,4);

   // untDescriptor.untLocation.association_tag
   msAPI_rmBurstWriteBytes(EEPROM_OFFSET(u16DL_OAD_AssociationTag),(U8*)&untDescriptor.untLocation.association_tag,2);

   OAD_DEBUG(printf("SetInfo=%x,%x,%x,%x,%x,%x,%x\n",MApp_OAD_GetMonitorState(),wOriginalNetwork_ID_OAD,wTransportStream_ID_OAD,wService_ID_OAD,untDescriptor.untSchedule.u32StartTime,untDescriptor.untSchedule.u32EndTime,untDescriptor.untLocation.association_tag)) ;
#endif //(EEPROM_DB_STORAGE==EEPROM_SAVE_NONE)
}

void MApp_OAD_GetInfo(EN_OAD_EEPROM_STATE state)
{
#if (EEPROM_DB_STORAGE==EEPROM_SAVE_NONE)
    U32 dst=0;
    ST_DOWNLOAD_INFO dl_info;

    dst = (SYSTEM_BANK_SIZE * OAD_DB_BANK);
    memset(&dl_info, 0, sizeof(dl_info));
    MDrv_FLASH_Read(dst, sizeof(dl_info), (U8*)&dl_info);
    if (state==EN_OAD_EEPROM_MONITOR)
    {
        // monitor state
        _enMonitorState = (EN_OAD_MONITOR_STATE)dl_info.u8DL_OAD_MonitorState;
    }
    else
    {
        // wOriginalNetwork_ID_OAD
        wOriginalNetwork_ID_OAD = dl_info.u16DL_OAD_NID;

        // wTransportStream_ID_OAD
        wTransportStream_ID_OAD = dl_info.u16DL_OAD_TID;

        // wService_ID_OAD
        wService_ID_OAD = dl_info.u16DL_OAD_SID;

        // untDescriptor.untSchedule.u32StartTime
        untDescriptor.untSchedule.u32StartTime = dl_info.u32DL_OAD_StartTime;

        // untDescriptor.untSchedule.u32EndTime
        untDescriptor.untSchedule.u32EndTime = dl_info.u32DL_OAD_EndTime;

        // untDescriptor.untLocation.association_tag
        untDescriptor.untLocation.association_tag = dl_info.u16DL_OAD_AssociationTag;
    }
#else //(EEPROM_DB_STORAGE==EEPROM_SAVE_NONE)
   if (state==EN_OAD_EEPROM_MONITOR)
   {
      // monitor state
      msAPI_rmBurstReadBytes(EEPROM_OFFSET(u8DL_OAD_MonitorState),(U8*)&_enMonitorState,1);
   }
   else
   {
      // wOriginalNetwork_ID_OAD
      msAPI_rmBurstReadBytes(EEPROM_OFFSET(u16DL_OAD_NID), (U8*)&wOriginalNetwork_ID_OAD, 2);

      // wTransportStream_ID_OAD
      msAPI_rmBurstReadBytes(EEPROM_OFFSET(u16DL_OAD_TID), (U8*)&wTransportStream_ID_OAD, 2);

     // wService_ID_OAD
     msAPI_rmBurstReadBytes(EEPROM_OFFSET(u16DL_OAD_SID), (U8*)&wService_ID_OAD, 2);

     // untDescriptor.untSchedule.u32StartTime
     msAPI_rmBurstReadBytes(EEPROM_OFFSET(u32DL_OAD_StartTime), (U8*)&untDescriptor.untSchedule.u32StartTime,4);

     // untDescriptor.untSchedule.u32EndTime
     msAPI_rmBurstReadBytes(EEPROM_OFFSET(u32DL_OAD_EndTime), (U8*)&untDescriptor.untSchedule.u32EndTime,4);

     // untDescriptor.untLocation.association_tag
     msAPI_rmBurstReadBytes(EEPROM_OFFSET(u16DL_OAD_AssociationTag), (U8*)&untDescriptor.untLocation.association_tag,2);
   }
#endif //(EEPROM_DB_STORAGE==EEPROM_SAVE_NONE)
   OAD_DEBUG(printf("GetInfo=%x,%x,%x,%x,%x,%x,%x\n",_enMonitorState,wOriginalNetwork_ID_OAD,wTransportStream_ID_OAD,wService_ID_OAD,untDescriptor.untSchedule.u32StartTime,untDescriptor.untSchedule.u32EndTime,untDescriptor.untLocation.association_tag)) ;
}

#if (OBA2)
void MApp_OAD_OBA2_Remove( void )
{
    char cmd[50];

    pFile=fopen(OAD_BIN_FILE,"r+b");
    if(pFile!=NULL)
    {
        fclose(pFile);
        memset(cmd, 0x00, 50);
        snprintf(cmd, sizeof(cmd),"rm -f %s ", OAD_BIN_FILE);
        system(cmd);
    }

    pFile2=fopen(OAD_ENV_FILE,"r+b");
    if(pFile2!=NULL)
    {
        fclose(pFile2);
        memset(cmd, 0x00, 50);
        snprintf(cmd, sizeof(cmd),"rm -f %s ", OAD_ENV_FILE);
        system(cmd);
    }
}
void MApp_OAD_OBA2_Open( void )
{
    U8 i;

    for(i=0;i<MAX_OPEN_COUNT;i++)
    {
        if(pFile==NULL)
        {
            pFile=fopen(OAD_BIN_FILE,"w+b");
        }

        if(pFile2==NULL)
        {
            pFile2=fopen(OAD_ENV_FILE,"w+b");
            fprintf(pFile2, "ubifsmount %s\n", OAD_VOLUME);
        }

        if((pFile!=NULL)&&(pFile2!=NULL))
        {
            printf("oad.bin open file ok ! \n");
            break;
        }
    }

    if((pFile==NULL)||(pFile2==NULL))
    {
        printf("oad.bin open file failed ! \n");
        return;
    }
}
void MApp_OAD_OBA2_Write( U32 u32FileOffset, U32 u32MsgAddr, U16 u16MsgLen )
{
#if 1
    fseek(pFile,u32FileOffset, SEEK_SET);
    fwrite((U8*)u32MsgAddr, u16MsgLen, 1, pFile);
#else
    fseek(pFile,u32DownloadSize, SEEK_SET);
    fwrite((U8*)msgAddr, msgLen, 1, pFile);
#endif
}
void MApp_OAD_OBA2_Close( void )
{
    fflush(pFile);
    fsync(fileno(pFile));
    fclose(pFile);
    fflush(pFile2);
    fsync(fileno(pFile2));
    fclose(pFile2);
}
#endif //(OBA2)

void MApp_OAD_Init( void )
{
   MS_IMG_INFO TempImgInfo;
    EN_OAD_MONITOR_STATE eState;

    eState = _enMonitorState;
    wOad_PID = MSAPI_DMX_INVALID_PID;
    _enDownloadState= EN_OAD_DOWNLOAD_STATE_NONE;
    _enAppState= EN_OAD_APP_STATE_INIT;
#if (!BLOADER)
    #if (!OBA2)
    pZUIDrawPercentageCB = MApp_ZUI_OADSwUpdate_ProgressBar ;
    #endif
#endif
    MAPP_DMX_SET_PID(MSAPI_DMX_INVALID_FLT_ID,OAD_MONITOR_FID);
    MAPP_DMX_SET_PID(MSAPI_DMX_INVALID_FLT_ID,OAD_DOWNLOAD_FID);
#if (!BLOADER)
    #if (OBA2)
    u32OadbufMonitorAddr = ((U32)OAD_DMXBUF_ADR_MONITOR);
    u32OadbufDownloadAddr = ((U32)OAD_DMXBUF_ADR_DOWNLOAD);
    #else
    u32OadbufMonitorAddr = (_VA2PA((U32)demuxBuf.monitor)) ;
    u32OadbufDownloadAddr = (_VA2PA((U32)demuxBuf.download)) ;
    #endif
    u32OadbufMonitorSize = DMX_BUF_SIZE_MONITOR;
    u32OadbufDownloadSize = DMX_BUF_SIZE_DOWNLOAD;
#endif //(!BLOADER)
    msAPI_OAD_ClearData();
    msAPI_OAD_SetOui((U8)(CUSTOMER_OUI>>16), (U8)(CUSTOMER_OUI>>8), (U8)(CUSTOMER_OUI));
#if (!BLOADER)
    msAPI_OAD_SetVersionCheck(MApp_OAD_VersonCheck) ;
#else //(!BLOADER)
    {
        extern BOOLEAN oad_VersonCheck(U16 type,U8 *pPrivateData);
        msAPI_OAD_SetVersionCheck(oad_VersonCheck) ;
    }
#endif //(!BLOADER)

    MApp_ImgInfo_GetAppInfo(&TempImgInfo) ;
    tvVersion = AP_SW_VERSION;
    MApp_OAD_GetInfo(EN_OAD_EEPROM_MONITOR) ;

    if (_enMonitorState == EN_OAD_MONITOR_STATE_UNT_WAIT_SCHEDULE)
    {
       MApp_OAD_GetInfo(EN_OAD_EEPROM_OTHER) ;
    }
    else
    {
        _enMonitorState = EN_OAD_MONITOR_STATE_PMT_DBID_RECEINING ;
        wTransportStream_ID_OAD = wOriginalNetwork_ID_OAD = wService_ID_OAD = 0 ;
        memset(&untDescriptor,0, sizeof(UNT_DESCRIPTOR));
        // Don't need to init related data in EEPROM due to it has no meaning
    }
#if (!BLOADER)
    //MApp_SI_Force_PMT_Parse() ;
    if(eState == EN_OAD_MONITOR_STATE_NIT_SIGNAL)
    {
        MApp_SI_Force_NIT_Parse();
    }
#endif
    OAD_DEBUG( printf("TV=%x\n",tvVersion));
    #if (BLOADER)
    enOADScanState = STATE_OAD_SCAN_INIT;
    #endif //(BLOADER)
#if (OBA2)
    MApp_OAD_OBA2_Remove();
#endif
}

BOOLEAN MApp_OAD_VersonCheck(U16 type,U8 *pPrivateData)
{
    U16  compatibilityLength,descriptorCount,model,version=0x0,i;
    U8  descriptorType, descriptorLength, specifierType,subDescriptorCount;
    U32 specifierData;
    BOOLEAN swPass=FALSE;
#if HW_MODEL_VER_CHECK
    BOOLEAN hwPass=FALSE;
#endif

    if (!VERSION_CHECK) return TRUE ;

    if (type==DATA_BC_ID_UK_EC) // MIS
    {
        U16 model_hw, version_hw;
        model_hw = GET_2BYTE(&pPrivateData[0]);
        version_hw = GET_2BYTE(&pPrivateData[2]);
        model = msAPI_OAD_GetMISVersionId() >> 16;
        version = msAPI_OAD_GetMISVersionId() & 0xff;
#if HW_MODEL_VER_CHECK
        if ((model_hw == HW_MODEL)&&(version_hw == HW_VERSION))
#endif //HW_MODEL_VER_CHECK
        {
#if (LOWER_VERSION_DOWNLOAD)
            if ((model == AP_SW_MODEL)&&(version != AP_SW_VERSION))
#else
            if ((model == AP_SW_MODEL)&&(version > AP_SW_VERSION))
#endif //LOWER_VERSION_DOWNLOAD)
            {
                tsVersion = (U32)version;
                toSaveVersion = tsVersion;
                return TRUE ;
            }
        }
        return FALSE ;
    }
    else if (type==DATA_BC_ID_SSU) // GroupCompatibility()
    {
        compatibilityLength = GET_2BYTE(pPrivateData);
        pPrivateData += 2;

        if ( compatibilityLength < 2 )
        {
            OAD_ASSERT( printf("Error> msAPI_OAD_ProcessDSI : compatibilityLength = 0x%x\n", compatibilityLength) );
            return FALSE ;
        }

        descriptorCount = GET_2BYTE(pPrivateData); pPrivateData += 2;
        OAD_DEBUG( printf("descriptorCount = %u\n", descriptorCount) );

        for ( i = 0; i < descriptorCount; i ++ )
        {
            descriptorType  = *pPrivateData++;
            descriptorLength= *pPrivateData++;

            switch ( descriptorType )
            {
                case 0x02:
                {
                    specifierType = *pPrivateData++;
                    specifierData = GET_3BYTE( pPrivateData ); pPrivateData += 3;
                    model = GET_2BYTE(pPrivateData); pPrivateData += 2;
                    version = GET_2BYTE(pPrivateData); pPrivateData += 2;
                    subDescriptorCount = *pPrivateData++;
                    if(subDescriptorCount == 0)
                    {
                        return FALSE;
                    }
                    tsVersion = (U32)version;
                    OAD_DEBUG( printf("TS=%x\n",tsVersion));
#if (LOWER_VERSION_DOWNLOAD)
                    if ((specifierType==0x01)&&(model == AP_SW_MODEL)&&(version != AP_SW_VERSION)&&(specifierData==CUSTOMER_OUI))
#else
                    if ((specifierType==0x01)&&(model == AP_SW_MODEL)&&(version > AP_SW_VERSION)&&(specifierData==CUSTOMER_OUI))
#endif //LOWER_VERSION_DOWNLOAD)
                    {
                        swPass = TRUE;
                    }
                    else
                    {
                        return FALSE ;
                    }
                    //pPrivateData += (descriptorLength-9) ;
                    //OAD_DEBUG( printf("[OTA] specifierType = 0x%02bx, specifierData = 0x%08lx\n", specifierType, specifierData) );
                    break;
                }
                case 0x01:
#if HW_MODEL_VER_CHECK
                    specifierType = *pPrivateData++;
                    specifierData = GET_3BYTE( pPrivateData ); pPrivateData += 3;
                    model = GET_2BYTE(pPrivateData); pPrivateData += 2;
                    version = GET_2BYTE(pPrivateData); pPrivateData += 2;
                    subDescriptorCount = *pPrivateData++;
                    tsVersion = (U32)version;
                    OAD_DEBUG( printf("TS=%x\n",tsVersion));
                    if ((specifierType==0x01)&&(model == HW_MODEL)&&(version == HW_VERSION)&&(specifierData==CUSTOMER_OUI))
                    {
                        hwPass = TRUE;
                    }
                    else
                    {
                        return FALSE ;
                    }
                    //pPrivateData += (descriptorLength-9) ;
                    //OAD_DEBUG( printf("[OTA] specifierType = 0x%02bx, specifierData = 0x%08lx\n", specifierType, specifierData) );
                    break;
#endif
                default:
                {
                    pPrivateData += descriptorLength;
                    OAD_DEBUG( printf("[OTA] descriptorType = 0x%02bx\n", descriptorType) );
                    break;
                }
            }
       }// End of for
    }
#if HW_MODEL_VER_CHECK
    if((swPass == TRUE) && (hwPass == TRUE))
#else //HW_MODEL_VER_CHECK
    if(swPass == TRUE)
#endif //HW_MODEL_VER_CHECK
    {
        toSaveVersion = (U32)version;
        return TRUE ;
    }
    return FALSE ;
}

void MApp_OAD_SetPmtSignal( WORD wPid, WORD wBDid,BYTE *pSelector ,U8 selectorType)
{
    //MEMBER_SERVICETYPE bServiceType;
    //WORD wCurrentPosition;
    U32 ouiData;
    U8 updateType=0 ;
    EN_OAD_MONITOR_STATE mState = MApp_OAD_GetMonitorState() ;
    //BOOLEAN updateVerFlag=0
    //U8  ouiDataLen=0,updateVersion=0,selectorLength=0;

    if ((selectorType==TAG_DBID)&&(mState==EN_OAD_MONITOR_STATE_PMT_DBID_RECEINING))
    {
       if (wBDid==DATA_BC_ID_UK_EC)
       {
            wOad_PID = wPid ;
            bServiceType = msAPI_CM_GetCurrentServiceType();
            wCurrentPosition = msAPI_CM_GetCurrentPosition(bServiceType);
            wOriginalNetwork_ID_OAD  = msAPI_CM_GetON_ID( bServiceType, wCurrentPosition) ;
            wTransportStream_ID_OAD = msAPI_CM_GetTS_ID( bServiceType, wCurrentPosition) ;
            wService_ID_OAD = msAPI_CM_GetService_ID( bServiceType, wCurrentPosition) ;
            MApp_OAD_SetMonitorState(EN_OAD_MONITOR_STATE_DSI_INIT) ;
       }
       else if (wBDid==DATA_BC_ID_SSU) // section 7.1 table 4
       {
          #if 0
          ouiDataLen = *pSelector++; printf("ouiDataLen=%x\n",ouiDataLen) ;
          ouiData = GET_3BYTE( pSelector ); pSelector += 3; printf("ouiData=%x\n",ouiData) ;
          updateType     = (*pSelector & 0x0F);  pSelector++; printf("updateType=%x\n",updateType) ;
          updateVerFlag  = (*pSelector & 0x20) >> 5; printf("updateVerFlag=%x\n",updateVerFlag) ;
          updateVersion  = (*pSelector & 0x1F); pSelector++; printf("updateVersion=%x\n",updateVersion) ;
          selectorLength = *pSelector ; printf("selectorLength=%x\n",selectorLength) ;
          #else
          ouiData = (pSelector[1]<<16)|(pSelector[2]<<8)|(pSelector[3]) ; //printf("ouiData=%x\n",ouiData) ;
          updateType = pSelector[4]&0x0f ; //printf("updateType=%x\n",updateType) ;
          #endif

          if ((ouiData==CUSTOMER_OUI)||(ouiData==DVB_OUI))
          {
            wOad_PID = wPid ;
            bServiceType = msAPI_CM_GetCurrentServiceType();
            wCurrentPosition = msAPI_CM_GetCurrentPosition(bServiceType);
            wOriginalNetwork_ID_OAD  = msAPI_CM_GetON_ID( bServiceType, wCurrentPosition) ;
            wTransportStream_ID_OAD = msAPI_CM_GetTS_ID( bServiceType, wCurrentPosition) ;
            wService_ID_OAD = msAPI_CM_GetService_ID( bServiceType, wCurrentPosition) ;
            if (updateType==SSU_UPDATETYPE_STANDARD)
            {
               MApp_OAD_SetMonitorState(EN_OAD_MONITOR_STATE_DSI_INIT) ;
            }
            else if ((updateType==SSU_UPDATETYPE_UNT_BROADCAST)||(updateType==SSU_UPDATETYPE_UNT_RETCHANNEL))
            {
               MApp_OAD_SetMonitorState(EN_OAD_MONITOR_STATE_UNT_INIT) ;
            }
            OAD_DEBUG(printf("PMT : SSU ok \n")) ;
          }
       }
    }
    else if ((selectorType==TAG_SID)&&(mState==EN_OAD_MONITOR_STATE_PMT_SID_RECEINING))
    {
        if (*pSelector==untDescriptor.untLocation.association_tag)
        {
            wOad_PID = wPid ;
            MApp_OAD_SetMonitorState(EN_OAD_MONITOR_STATE_DSI_INIT) ;
        }
    }
}

void MApp_OAD_SetNitSignal( WORD wTSId, WORD wONId, WORD wServiceId, BYTE *pSelector )
{
    if (EN_OAD_MONITOR_STATE_PMT_DBID_RECEINING!=MApp_OAD_GetMonitorState()) return ;

    U8 u8Offset;
    U8 u8DataLen;
    U8 u8SelectByteLen;

    u8DataLen = pSelector[0];
    u8Offset = 0;
    if(u8DataLen < 4)
    {
        OAD_DEBUG(printf("NIT : SSU error \n")) ;
    }
    else
    {
        while((u8DataLen-u8Offset)>0)
        {
            if(pSelector[u8Offset+1] == ((U8)(CUSTOMER_OUI>>16)) && pSelector[u8Offset+2] == ((U8)(CUSTOMER_OUI>>8)) && pSelector[u8Offset+3] == ((U8)(CUSTOMER_OUI)))
            {
                u8SelectByteLen = pSelector[u8Offset+4];
#if (LOWER_VERSION_DOWNLOAD)
                if((u8SelectByteLen >= 2) && GET_2BYTE(&pSelector[u8Offset+5])==AP_SW_MODEL && GET_2BYTE(&pSelector[u8Offset+7]) != AP_SW_VERSION)
#else
                if((u8SelectByteLen >= 2) && GET_2BYTE(&pSelector[u8Offset+5])==AP_SW_MODEL && GET_2BYTE(&pSelector[u8Offset+7]) > AP_SW_VERSION)
#endif
                {
                    wTransportStream_ID_OAD = wTSId;
                    wService_ID_OAD = wServiceId ;
                    wOriginalNetwork_ID_OAD = wONId;
                    MApp_OAD_SetMonitorState(EN_OAD_MONITOR_STATE_NIT_SIGNAL) ;
                    //msAPI_BLoader_SetUpdatedStatus(DLSTATUS_NIT_SIGNAL);
                    OAD_DEBUG(printf("NIT : SSU ok \n")) ;
                    break;
                }
            }
            else if(pSelector[u8Offset+1] == ((U8)(DVB_OUI>>16)) && pSelector[u8Offset+2] == ((U8)(DVB_OUI>>8)) && pSelector[u8Offset+3] == ((U8)(DVB_OUI)))
            {
                wTransportStream_ID_OAD = wTSId;
                wService_ID_OAD = wServiceId ;
                wOriginalNetwork_ID_OAD = wONId;
                MApp_OAD_SetMonitorState(EN_OAD_MONITOR_STATE_NIT_SIGNAL) ;
                //msAPI_BLoader_SetUpdatedStatus(DLSTATUS_NIT_SIGNAL);
                OAD_DEBUG(printf("NIT : SSU ok \n")) ;
                //printf("NIT : SSU ok \n");
                break;

            }
            else
            {
                u8SelectByteLen = pSelector[u8Offset+4];
            }
            u8Offset+=(4+u8SelectByteLen);
        }
    }
}

void MApp_OAD_SetMonitorState( EN_OAD_MONITOR_STATE state )
{
    _enMonitorState = state;
}

EN_OAD_MONITOR_STATE MApp_OAD_GetMonitorState( void )
{
    return _enMonitorState;
}

void MApp_OAD_SetDownloadState( EN_OAD_DOWNLOAD_STATE state )
{
    _enDownloadState = state;
}

EN_OAD_DOWNLOAD_STATE MApp_OAD_GetDownloadState( void )
{
    return _enDownloadState;
}

void MApp_OAD_SetAppState( EN_OAD_APP_STATE state )
{
    _enAppState = state;
}

EN_OAD_APP_STATE MApp_OAD_GetAppState( void )
{
    return _enAppState;
}
EN_OAD_SCAN_STATE MApp_OAD_GetScanState( void )
{
    return enOADScanState;
}
void MApp_OAD_SetScanState( EN_OAD_SCAN_STATE state )
{
    enOADScanState = state;
}
void MApp_OAD_Monitor( void )
{
    static UINT32 u32DsmccTimer;
    EN_OAD_MONITOR_STATE eState;
    UINT8 *pu8Buf = NULL;

    eState = MApp_OAD_GetMonitorState();

    OAD_DEBUG( printf("eState_Monitor = %d\n", (U8)eState) );

    switch( eState )
    {
        case EN_OAD_MONITOR_STATE_DSI_INIT:
        {
            if(msAPI_OAD_CreateSectionFilter( MSAPI_DMX_FILTER_TYPE_OAD_MONITOR,OAD_CONTROL_SECTION_TYPE,OAD_DSMCC_MSGID_DSI,wOad_PID,MAPP_DMX_GET_PID(OAD_MONITOR_FID) ) == TRUE)
            {
                MApp_OAD_SetMonitorState(EN_OAD_MONITOR_STATE_DSI_RECEIVING);
                u32DsmccTimer = msAPI_Timer_GetTime0();
            }
            else
            {
                if(MApp_Dmx_GetOADScanMode())
                {
                    MApp_OAD_SetScanState(STATE_OAD_SCAN_NEXT_CHANNEL);
                }
                MApp_OAD_SetMonitorState( EN_OAD_MONITOR_STATE_STOP);
                OAD_DEBUG( printf("Error> msAPI_OAD_CreateSectionFilter(OAD_CONTROL_SECTION_TYPE) : Invalid FID\n") );
            }

            break ;
        }

        case EN_OAD_MONITOR_STATE_DSI_RECEIVING :
        case EN_OAD_MONITOR_STATE_DSI_SIGNAL:
        case EN_OAD_MONITOR_STATE_NIT_DSI_SIGNAL:
        {
            pu8Buf = msAPI_OAD_PollingSectionFilter(*MAPP_DMX_GET_PID(OAD_MONITOR_FID), MAPP_DMX_GETSI_4K_SECBUFFER());

            if(pu8Buf)
            {
                if (OAD_SUCCEED==msAPI_OAD_ProcessDSI(pu8Buf))
                {
                    u32DsmccTimer = msAPI_Timer_GetTime0();
                    if (EN_OAD_MONITOR_STATE_DSI_RECEIVING==MApp_OAD_GetMonitorState())
                    {
                            versionNum = msAPI_OAD_GetDsiVersionNum() ;
                        if(bNITSignal_DSI == TRUE)
                        {
                            MApp_OAD_SetMonitorState(EN_OAD_MONITOR_STATE_NIT_DSI_SIGNAL);
                            bNITSignal_DSI = FALSE;
                        }
                        else
                        {
                            MApp_OAD_SetMonitorState(EN_OAD_MONITOR_STATE_DSI_SIGNAL);
                            #if (!BLOADER)
                            bServiceType = msAPI_CM_GetCurrentServiceType();
                            wCurrentPosition = msAPI_CM_GetCurrentPosition(bServiceType);
                            // Set Current Physical Channel
                            cRFChannelNumber = msAPI_CM_GetPhysicalChannelNumber(bServiceType, wCurrentPosition);
                            // Get Current Frequency & BandWidth
                            msAPI_DFT_GetTSSetting(cRFChannelNumber, &stTPSetting);
                            #else //(!BLOADER)
                            msAPI_DFT_GetTSSetting( u8OadRFCh, &stTPSetting);
                            #endif //(!BLOADER)
                            MApp_OAD_SetInfo_ForBL(wOad_PID, stTPSetting.u32Frequency, stTPSetting.enBandWidth);
                        }
                    }
                    else if (EN_OAD_MONITOR_STATE_DSI_SIGNAL==MApp_OAD_GetMonitorState()
                        || EN_OAD_MONITOR_STATE_NIT_DSI_SIGNAL==MApp_OAD_GetMonitorState())
                    {
                        #if (BLOADER)
                        if(!MApp_OAD_IsDownloading())
                            MApp_OAD_StartDownload();
                        #endif //(BLOADER)
                        if (versionNum!=msAPI_OAD_GetDsiVersionNum())
                        {
                            OAD_DEBUG(printf("versionNum error !!!\n")) ;
                            MApp_OAD_SetMonitorState(EN_OAD_MONITOR_STATE_STOP);
                        }
                    }
                }
                else
                {
                    //MApp_OAD_SetMonitorState(EN_OAD_MONITOR_STATE_STOP);
                }
            }

            if (msAPI_Timer_DiffTimeFromNow(u32DsmccTimer) > MONITOR_DSI_TIME_OUT)
            {
                OAD_DEBUG( printf("Error> Exit DSI\n") );
                #if (!OBA2)
                MApp_OAD_SetMonitorState( EN_OAD_MONITOR_STATE_STOP);
                #endif
            }
            break;
        }

        case EN_OAD_MONITOR_STATE_UNT_INIT:
        {
            if(msAPI_OAD_CreateSectionFilter( MSAPI_DMX_FILTER_TYPE_OAD_MONITOR,OAD_UNT_SECTION_TYPE,0,wOad_PID,MAPP_DMX_GET_PID(OAD_MONITOR_FID) ) == TRUE)
            {
                MApp_OAD_SetMonitorState(EN_OAD_MONITOR_STATE_UNT_RECEIVING);
                u32DsmccTimer = msAPI_Timer_GetTime0();
            }
            else
            {
                MApp_OAD_SetMonitorState( EN_OAD_MONITOR_STATE_STOP);
                OAD_DEBUG( printf("Error> msAPI_OAD_CreateSectionFilter(OAD_CONTROL_SECTION_TYPE) : Invalid FID\n") );
            }

            break ;
        }

        case EN_OAD_MONITOR_STATE_UNT_RECEIVING :
        {
            pu8Buf = msAPI_OAD_PollingSectionFilter(*MAPP_DMX_GET_PID(OAD_MONITOR_FID),MAPP_DMX_GETSI_4K_SECBUFFER());

            if (pu8Buf)
            {
                if (OAD_SUCCEED==msAPI_OAD_ProcessUNT(pu8Buf,&untDescriptor))
                {
                   msAPI_OAD_DeleteSectionFilter(MAPP_DMX_GET_PID(OAD_MONITOR_FID) );
                   MApp_OAD_SetMonitorState(EN_OAD_MONITOR_STATE_UNT_SIGNAL);
                    bServiceType = msAPI_CM_GetCurrentServiceType();
                    wCurrentPosition = msAPI_CM_GetCurrentPosition(bServiceType);
                    // Set Current Physical Channel
                    cRFChannelNumber = msAPI_CM_GetPhysicalChannelNumber(bServiceType, wCurrentPosition);
                    // Get Current Frequency & BandWidth
                    msAPI_DFT_GetTSSetting(cRFChannelNumber, &stTPSetting);
                    MApp_OAD_SetInfo_ForBL(wOad_PID, stTPSetting.u32Frequency, stTPSetting.enBandWidth);
                }
                else
                {
                    MApp_OAD_SetMonitorState(EN_OAD_MONITOR_STATE_STOP);
                }
            }

            if (msAPI_Timer_DiffTimeFromNow(u32DsmccTimer) > MONITOR_UNT_TIME_OUT)
            {
                OAD_DEBUG( printf("Error> Exit UNT RECEIVING \n") );
                MApp_OAD_SetMonitorState( EN_OAD_MONITOR_STATE_STOP);
            }
            break;
        }

#if (!BLOADER)
        case EN_OAD_MONITOR_STATE_UNT_WAIT_SCHEDULE:
        {
            if (MApp_OAD_IsUntSchedule())
            {
                MApp_SI_Force_PMT_Parse() ; // tune to the target srevice first
                MApp_OAD_SetMonitorState(EN_OAD_MONITOR_STATE_PMT_SID_RECEINING) ;
            }
            break ;
        }
#endif
        case EN_OAD_MONITOR_STATE_STOP:
        {
            msAPI_OAD_DeleteSectionFilter(MAPP_DMX_GET_PID(OAD_MONITOR_FID) );
            //MApp_OAD_SetMonitorState( EN_OAD_MONITOR_STATE_NONE);
            MApp_OAD_Init() ;
            break ;
        }
        case EN_OAD_MONITOR_STATE_UNT_SIGNAL:
        case EN_OAD_MONITOR_STATE_NIT_SIGNAL:
        case EN_OAD_MONITOR_STATE_PMT_DBID_RECEINING:
        case EN_OAD_MONITOR_STATE_PMT_SID_RECEINING:
        case EN_OAD_MONITOR_STATE_NONE:
        default:
        {
            break;
        }
    }
}

void MApp_OAD_Download( void )
{
    static U32 u32DsmccTimer=0 ;
    U8 *pu8Buf = NULL;
    U16 blockID=0,msgLen=0,msgType=0 ;
    U32 msgAddr = 0 ;
    OAD_STATUS_REPORT_TYPE ddbStatus ;

    OAD_DEBUG( printf("eState_Download = %d\n", (U8)MApp_OAD_GetDownloadState()) );

    switch (MApp_OAD_GetDownloadState())
    {
        case EN_OAD_DOWNLOAD_STATE_FLASH_ERASEINIT:
        {
            u32FlashStartAddr = 0 ;
            u32FlashEndAddr = u32FlashStartAddr + SW_UPDATE_ERASE_SIZE - 1;
            u16StartBlock = u32FlashStartAddr/SW_UPDATE_BLOCK_SIZE;
            u16EndBlock = u32FlashEndAddr/SW_UPDATE_BLOCK_SIZE;
            u16BlockNo  = u16StartBlock;
            MDrv_FLASH_WriteProtect(DISABLE) ;
            MApp_OAD_SetDownloadState(EN_OAD_DOWNLOAD_STATE_FLASH_ERASING) ;
            break;
        }
        case EN_OAD_DOWNLOAD_STATE_FLASH_ERASING:
        {
            if (u16BlockNo++ <= u16EndBlock)
            {
                MS_DEBUG_MSG(printf("erase=%d\n",u16BlockNo));
                MDrv_FLASH_AddressErase(u16BlockNo*SW_UPDATE_BLOCK_SIZE, SW_UPDATE_BLOCK_SIZE, TRUE);
            }
            else
            {
                MApp_OAD_SetDownloadState(EN_OAD_DOWNLOAD_STATE_DII_INIT) ;
            }
            break;
        }
        case EN_OAD_DOWNLOAD_STATE_DII_INIT:
        {
            if(msAPI_OAD_CreateSectionFilter(MSAPI_DMX_FILTER_TYPE_OAD_DOWNLOAD,OAD_CONTROL_SECTION_TYPE,OAD_DSMCC_MSGID_DII,wOad_PID,MAPP_DMX_GET_PID(OAD_DOWNLOAD_FID)) == TRUE)
            {
                   MApp_OAD_SetDownloadState(EN_OAD_DOWNLOAD_STATE_DII_RECEIVING) ;
                   u32DsmccTimer = msAPI_Timer_GetTime0();
            }
            else
            {
                OAD_DEBUG( printf("Error> msAPI_OAD_CreateSectionFilter(OAD_CONTROL_SECTION_TYPE) : Invalid FID=%x\n",MAPP_DMX_GET_PID(OAD_DOWNLOAD_FID)));
                MApp_OAD_SetDownloadState(EN_OAD_DOWNLOAD_STATE_STOP) ;
            }
            break;
        }
        case EN_OAD_DOWNLOAD_STATE_DII_RECEIVING:
        {
            pu8Buf = msAPI_OAD_PollingSectionFilter(*MAPP_DMX_GET_PID(OAD_DOWNLOAD_FID),MAPP_DMX_GETSI_4K_SECBUFFER());

            if(pu8Buf)
            {
                if (OAD_SUCCEED == msAPI_OAD_ProcessDII(pu8Buf))
                {
                      MApp_OAD_SetDownloadState(EN_OAD_DOWNLOAD_STATE_DDB_INIT) ;
                      msAPI_OAD_DeleteSectionFilter(MAPP_DMX_GET_PID(OAD_DOWNLOAD_FID));
                }
            }

            if (msAPI_Timer_DiffTimeFromNow(u32DsmccTimer) > MONITOR_DII_TIME_OUT)
            {
                OAD_DEBUG( printf("Error> Timeout to receive DII\n") );
                MApp_OAD_SetDownloadState(EN_OAD_DOWNLOAD_STATE_STOP) ;
            }

            break;
        }
        case EN_OAD_DOWNLOAD_STATE_DDB_INIT:
        {
            if(msAPI_OAD_CreateSectionFilter( MSAPI_DMX_FILTER_TYPE_OAD_DOWNLOAD,OAD_DATA_SECTION_TYPE ,OAD_DSMCC_MSGID_DDB,wOad_PID,MAPP_DMX_GET_PID(OAD_DOWNLOAD_FID)) == TRUE)
            {
                MApp_OAD_SetDownloadState(EN_OAD_DOWNLOAD_STATE_DDB_RECEIVING) ;
                u32DownloadSize = 0x0;
                u32DsmccTimer = msAPI_Timer_GetTime0();
#if (BLOADER)
                MApp_BL_DisplaySystem_clear(); //clear screen
                MApp_BL_DisplaySystem_setStatus((S8*)"DOWNLOAD");
                MApp_BL_DisplaySystem(0);
#endif //(BLOADER)
            }
            else
            {
                OAD_DEBUG( printf("Error> msAPI_OAD_CreateSectionFilter(OAD_DATA_SECTION_TYPE) : Invalid FID\n") );
                MApp_OAD_SetDownloadState(EN_OAD_DOWNLOAD_STATE_STOP) ;
            }
            break;
        }
        case EN_OAD_DOWNLOAD_STATE_DDB_RECEIVING:
        {
            pu8Buf = msAPI_OAD_PollingSectionFilter(*MAPP_DMX_GET_PID(OAD_DOWNLOAD_FID),MAPP_DMX_GETSI_4K_SECBUFFER());

            if(pu8Buf)
            {
                ddbStatus = msAPI_OAD_ProcessDDB(pu8Buf,&blockID,&msgLen,&msgAddr,&msgType) ;

                if ((ddbStatus != OAD_FAIL)&&(msgLen))
                {
                   if (msgType==OAD_MODE_OBJCAR)
                   {
                      if (blockID==0)
                      {
#if (!OBA2)
                         #if FLASH_DIRECT_WRITE
                         MDrv_FLASH_Write(u32FlashStartAddr, msgLen, (U8*)msgAddr ) ;
                         #else
                         memcpy((U8*)MsOS_PA2KSEG1(DOWNLOAD_BUFFER_ADR_OAD),(U8*)msgAddr,(U32)msgLen) ;
                         #endif
#else //(!OBA2)
                         MApp_OAD_OBA2_Write(u32DownloadSize, msgAddr, msgLen);
#endif //(!OBA2)
                      }
                      else
                      {
#if (!OBA2)
                         #if FLASH_DIRECT_WRITE
                         MDrv_FLASH_Write(u32FlashStartAddr+(blockID*MAX_DDB_MSGSIZE)-BIOP_HEADER_LEN, msgLen, (U8*)msgAddr ) ;
                         #else
                         memcpy((U8*)MsOS_PA2KSEG1(DOWNLOAD_BUFFER_ADR_OAD+(blockID*MAX_DDB_MSGSIZE)-BIOP_HEADER_LEN),(U8*)msgAddr,(U32)msgLen) ;
                         #endif
#else //(!OBA2)
                         MApp_OAD_OBA2_Write(((blockID*MAX_DDB_MSGSIZE)-BIOP_HEADER_LEN), msgAddr, msgLen);
#endif //(!OBA2)
                      }

                   }
                   else if (msgType==OAD_MODE_DATACAR)
                   {
#if (!OBA2)
                       #if FLASH_DIRECT_WRITE
                       MDrv_FLASH_Write(u32FlashStartAddr+(blockID*MAX_DDB_MSGSIZE), msgLen, (U8*)msgAddr ) ;
                       #else
                       memcpy((U8*)MsOS_PA2KSEG1(DOWNLOAD_BUFFER_ADR_OAD+(blockID*MAX_DDB_MSGSIZE)),(U8*)msgAddr,(U32)msgLen) ;
                       #endif
#else //(!OBA2)
                       MApp_OAD_OBA2_Write((blockID*MAX_DDB_MSGSIZE), msgAddr, msgLen);
#endif //(!OBA2)
                   }
                   u32DownloadSize += msgLen ;
                }

                if (ddbStatus == OAD_COMPLETE)
                {
                    #if OAD_TEST
                    #if FLASH_DIRECT_WRITE
                    #if 0
                    MDrv_Sys_SetWatchDogTimer(0);
                    MDrv_Sys_EnableWatchDog();
                    while(1); // reset
                    #else
                    msAPI_BLoader_Reboot();
                    #endif
                    #else
                    #if (!OBA2)
                    MApp_SwUpdate_Start( SW_UPDATE_MODE_PARTIAL_OAD,FALSE, FALSE, FALSE,DOWNLOAD_BUFFER_ADR_OAD,u32DownloadSize,DOWNLOAD_BUFFER_TYPE_OAD, FALSE);
                    #endif // #if (!OBA2)
                    #endif // #if FLASH_DIRECT_WRITE
                    #else // #if FLASH_DIRECT_WRITE
                    MApp_OAD_SetDownloadState(EN_OAD_DOWNLOAD_STATE_DDB_COMPLETED) ;
                    #endif // #if OAD_TEST

#if (!OBA2)
                    #if FLASH_DIRECT_WRITE
                    MDrv_FLASH_WriteProtect(ENABLE) ;
                    #endif
#else //(!OBA2)
                    MApp_OAD_OBA2_Close();
#endif //(!OBA2)
                    #if (BLOADER)
                    MApp_BL_DisplaySystem_clear(); //clear screen
                    MApp_BL_DisplaySystem_setStatus((S8*)"Software Update(OAD)");
                    MApp_BL_DisplaySystem(0);
                    if (MApp_SwUpdate_Start( SW_UPDATE_MODE_PARTIAL_OAD,FALSE, FALSE, FALSE,DOWNLOAD_BUFFER_ADR_OAD,u32DownloadSize,DOWNLOAD_BUFFER_TYPE_OAD, FALSE))
                        return;
                    #endif //(BLOADER)
                }
                #if (BLOADER)
                {
                    static U8 u8PrevPersentage=0;
                    U8 u8Percentage = MApp_OAD_GetProgress();
                    if (u8Percentage > 100)
                        u8Percentage = 100;
                    if(u8PrevPersentage != u8Percentage)
                    {
                        u8PrevPersentage = u8Percentage;
                        MApp_BL_DisplaySystem(u8Percentage);
                        //printf("u8Percentage: %u, at %d\n", u8Percentage, __LINE__);
                    }
                }
                #endif //(BLOADER)
            }

            if (msAPI_Timer_DiffTimeFromNow(u32DsmccTimer) > MONITOR_DDB_TIME_OUT)
            {
                OAD_DEBUG( printf("Error> Exit DDB\n") );
                #if (!OBA2)
                MApp_OAD_SetDownloadState(EN_OAD_DOWNLOAD_STATE_STOP) ;
                #endif
            }
            break ;

        }
        case EN_OAD_DOWNLOAD_STATE_STOP:
        {
            msAPI_OAD_DeleteSectionFilter(MAPP_DMX_GET_PID(OAD_DOWNLOAD_FID));
            MApp_OAD_SetDownloadState(EN_OAD_DOWNLOAD_STATE_NONE) ;
            break ;
        }
        case EN_OAD_DOWNLOAD_STATE_DDB_COMPLETED:
        case EN_OAD_DOWNLOAD_STATE_NONE:
        case EN_OAD_DOWNLOAD_STATE_WAIT:
        default:
        {
            break;
        }
    }
}

BOOLEAN MApp_OAD_IsAutoScanEnable(void)
{
    return _bOAD_AutoScanEnable;
}
BOOLEAN MApp_OAD_IsDownloadAvailable(void)
{
    EN_OAD_MONITOR_STATE mState = MApp_OAD_GetMonitorState() ;

    return ((mState==EN_OAD_MONITOR_STATE_NIT_DSI_SIGNAL)||(mState==EN_OAD_MONITOR_STATE_DSI_SIGNAL)||(mState==EN_OAD_MONITOR_STATE_NIT_SIGNAL)||(mState==EN_OAD_MONITOR_STATE_UNT_SIGNAL))?TRUE:FALSE;
}

BOOLEAN MApp_OAD_IsDownloadCompleted(void)
{
    EN_OAD_DOWNLOAD_STATE dState = MApp_OAD_GetDownloadState() ;

    return (dState==EN_OAD_DOWNLOAD_STATE_DDB_COMPLETED)?TRUE:FALSE;
}

BOOLEAN MApp_OAD_IsDownloading(void)
{
    EN_OAD_DOWNLOAD_STATE dState = MApp_OAD_GetDownloadState() ;

    return ((dState!=EN_OAD_DOWNLOAD_STATE_NONE)) ? TRUE : FALSE ;
}

BOOLEAN MApp_OAD_IsUntSchedule(void)
{
   U32 u32currentTime = MApp_GetLocalSystemTime() ;
   BOOLEAN ret = 0 ;

   OAD_DEBUG(printf("timeOAD=%x,%x,%x\n",u32currentTime,untDescriptor.untSchedule.u32StartTime,untDescriptor.untSchedule.u32EndTime)) ;

   if ((u32currentTime>untDescriptor.untSchedule.u32StartTime)&&(u32currentTime<untDescriptor.untSchedule.u32EndTime))
   {
      ret = 1 ;
   }
   else
   {
      ret = 0 ;
   }
   return ret ;
}

BOOLEAN MApp_OAD_IsUserSelectOn(void)
{
    return stGenSetting.g_SysSetting.fSoftwareUpdate ;
}

void MApp_OAD_StartDownload(void)
{
    switch(MApp_OAD_GetMonitorState())
    {
        case EN_OAD_MONITOR_STATE_DSI_SIGNAL:
        case EN_OAD_MONITOR_STATE_NIT_DSI_SIGNAL:
        {
            MApp_OAD_SetDownloadState(EN_OAD_DOWNLOAD_STATE_DII_INIT) ;
            break ;
        }
        case EN_OAD_MONITOR_STATE_NIT_SIGNAL:
        {
            MApp_OAD_SetMonitorState(EN_OAD_MONITOR_STATE_PMT_DBID_RECEINING) ;
            break;
        }
        default:
        {
            break;
        }
    }
}

void MApp_OAD_StopDownload(void)
{
    MApp_OAD_SetMonitorState(EN_OAD_MONITOR_STATE_STOP) ;
    MApp_OAD_SetDownloadState(EN_OAD_DOWNLOAD_STATE_STOP) ;
}

void MApp_OAD_GetVersion(U32 *tvVER,U32 *tsVER)
{
    *tvVER = tvVersion ;
    *tsVER = tsVersion ;
}

void MApp_OAD_GetService(U16 *netID,U16 *tsID,U16 *serviceID,MEMBER_SERVICETYPE *type,WORD *position)
{
    *netID = wOriginalNetwork_ID_OAD ;
    *tsID = wTransportStream_ID_OAD ;
    *serviceID = wService_ID_OAD ;
    *type = bServiceType ;
    *position = wCurrentPosition ;
}

U8 MApp_OAD_GetProgress(void)
{
    return msAPI_OAD_GetProgress() ;
}

U32 MApp_OAD_GetScheduleStart(void)
{
    return (MApp_OAD_GetMonitorState()==EN_OAD_MONITOR_STATE_UNT_SIGNAL
       || MApp_OAD_GetMonitorState()== EN_OAD_MONITOR_STATE_UNT_WAIT_SCHEDULE)
          ?untDescriptor.untSchedule.u32StartTime:0;
}

U32 MApp_OAD_GetScheduleEnd(void)
{
    return (MApp_OAD_GetMonitorState()==EN_OAD_MONITOR_STATE_UNT_SIGNAL
       || MApp_OAD_GetMonitorState()== EN_OAD_MONITOR_STATE_UNT_WAIT_SCHEDULE)
          ?untDescriptor.untSchedule.u32EndTime:0;
}

WORD MApp_OAD_GetServiceLcn(void)
{
    MEMBER_SERVICETYPE eGotServiceType;
    U16 u16GotPosition ;
    U8 bResult ;

    bResult = msAPI_CM_GetServiceTypeAndPositionWithIDs(  wTransportStream_ID_OAD, wOriginalNetwork_ID_OAD, wService_ID_OAD, 1,&eGotServiceType, &u16GotPosition, TRUE);

    if(bResult)
    {
        return msAPI_CM_GetLogicalChannelNumber(eGotServiceType,u16GotPosition);
    }
    else
    {
        return INVALID_LOGICAL_CHANNEL_NUMBER;
    }
}


void MApp_OAD_AppTest(void)
{
    if (stGenSetting.g_SysSetting.fSoftwareUpdate==0) return ;

    if (MApp_OAD_GetDownloadState()!=EN_OAD_DOWNLOAD_STATE_NONE) return ;

    switch(MApp_OAD_GetMonitorState())
    {
        case EN_OAD_MONITOR_STATE_DSI_SIGNAL:
        case EN_OAD_MONITOR_STATE_NIT_DSI_SIGNAL:
        {
            #if FLASH_DIRECT_WRITE
            MApp_OAD_SetDownloadState(EN_OAD_DOWNLOAD_STATE_FLASH_ERASEINIT) ;
            #else
            MApp_OAD_SetDownloadState(EN_OAD_DOWNLOAD_STATE_DII_INIT) ;
            #endif
            break ;
        }
        case EN_OAD_MONITOR_STATE_NIT_SIGNAL:
        {
            if( !IsDTVInUse() )
            {
                MApp_Dmx_CloseAllFilters();
                UI_INPUT_SOURCE_TYPE = UI_INPUT_SOURCE_DTV;
                MApp_InputSource_SwitchSource( UI_INPUT_SOURCE_TYPE ,MAIN_WINDOW);
            }

            MApp_TopStateMachine_SetTopState(STATE_TOP_DIGITALINPUTS) ;
            MApp_ChannelChange_ChangeSpeciChannel(wService_ID_OAD, wOriginalNetwork_ID_OAD, wTransportStream_ID_OAD, TYPE_CHANNEL_CHANGE_SER_ID,TRUE) ;

            MApp_OAD_SetMonitorState(EN_OAD_MONITOR_STATE_PMT_DBID_RECEINING) ;
            break;
        }
#if (!BLOADER)
        case EN_OAD_MONITOR_STATE_UNT_SIGNAL:
        {
            if (MApp_OAD_IsUntSchedule())
            {
                MApp_SI_Force_PMT_Parse() ; // tune to the target srevice first
                MApp_OAD_SetMonitorState(EN_OAD_MONITOR_STATE_PMT_SID_RECEINING) ;
            }
            break ;
        }
#endif
        case EN_OAD_MONITOR_STATE_PMT_DBID_RECEINING:
        case EN_OAD_MONITOR_STATE_PMT_SID_RECEINING:
        case EN_OAD_MONITOR_STATE_NONE:
        default:
        {
            break;
        }
    }
}

EN_RET MApp_OAD_AppMain(void)
{
    EN_RET enRetVal =EXIT_NULL;
    static UINT32 u32SignalTimer;

    OAD_DEBUG(printf("eState_OAD_Main = %d\n", MApp_OAD_GetAppState()));

    switch(MApp_OAD_GetAppState())
    {
        case EN_OAD_APP_STATE_INIT:
        {
            MApp_ZUI_ACT_StartupOSD(E_OSD_OAD); // show Signal UI - DSI or UNT or UNT
            MApp_OAD_SetAppState(EN_OAD_APP_STATE_WAIT_USER) ;
            u32SignalTimer = msAPI_Timer_GetTime0();
            break ;
        }
        case EN_OAD_APP_STATE_WAIT_USER:
        {
            MApp_ZUI_ProcessKey(u8KeyCode);
            u8KeyCode = KEY_NULL;
            if (msAPI_Timer_DiffTimeFromNow(u32SignalTimer) > MONITOR_USER_TIME_OUT)
            {
                MApp_OAD_SetAppState(EN_OAD_APP_STATE_STOP);
            }
            else if (MApp_OAD_GetMonitorState()==EN_OAD_MONITOR_STATE_NIT_DSI_SIGNAL)
            {
                MApp_OAD_SetDownloadState(EN_OAD_DOWNLOAD_STATE_DII_INIT) ;
                MApp_OAD_SetAppState(EN_OAD_APP_STATE_DOWNLOADING);
            }
            break;
        }
        case EN_OAD_APP_STATE_YES:
        {
            if (MApp_OAD_GetMonitorState()==EN_OAD_MONITOR_STATE_DSI_SIGNAL)
            {
                extern BOOLEAN fEnableSignalMonitor;
                #if FLASH_DIRECT_WRITE
                MApp_OAD_SetDownloadState(EN_OAD_DOWNLOAD_STATE_FLASH_ERASEINIT) ;
                #else
                MApp_OAD_SetDownloadState(EN_OAD_DOWNLOAD_STATE_DII_INIT) ;
                #endif
                MApp_OAD_SetAppState(EN_OAD_APP_STATE_DOWNLOADING) ;
                MApp_ChannelChange_DisableChannel(TRUE, MAIN_WINDOW);
#if (!BLOADER)
                MApp_Dmx_SetMonitorStatus(TRUE, EN_MONITOR_TABLE_ALL);
#endif
                fEnableSignalMonitor=TRUE;
            }
            else if (MApp_OAD_GetMonitorState()==EN_OAD_MONITOR_STATE_NIT_SIGNAL)
            {
                MApp_ChannelChange_ChangeSpeciChannel(wService_ID_OAD, wOriginalNetwork_ID_OAD, wTransportStream_ID_OAD, TYPE_CHANNEL_CHANGE_SER_ID,TRUE) ;
                MApp_OAD_SetMonitorState(EN_OAD_MONITOR_STATE_PMT_DBID_RECEINING) ;
                MApp_OAD_SetAppState(EN_OAD_APP_STATE_EXIT) ;
                bNITSignal_DSI = TRUE;
            }
            else if (MApp_OAD_GetMonitorState()==EN_OAD_MONITOR_STATE_UNT_SIGNAL)
            {
                MApp_OAD_SetMonitorState(EN_OAD_MONITOR_STATE_UNT_WAIT_SCHEDULE) ;
                MApp_OAD_SetAppState(EN_OAD_APP_STATE_EXIT) ;
            }
            break ;
        }
        case EN_OAD_APP_STATE_NO:
        case EN_OAD_APP_STATE_STOP:
        {
            MApp_OAD_SetMonitorState(EN_OAD_MONITOR_STATE_NONE) ;
            MApp_OAD_SetDownloadState(EN_OAD_DOWNLOAD_STATE_NONE) ;
            MApp_OAD_SetAppState(EN_OAD_APP_STATE_EXIT) ;
            break;
        }
        case EN_OAD_APP_STATE_UPGRADING:
        {
            #if (OBA2)
            if (!MApp_Obama_SwUpdate(_PA2VA(DOWNLOAD_BUFFER_ADR_OAD), u32DownloadSize))
            {
               MApp_OAD_SetAppState(EN_OAD_APP_STATE_EXIT) ;
               OAD_ASSERT(printf("UPGRADING FAIL!!!\n"));
            }
            #else
            //check CRC32 of MERGE.bin
            if(0x0 != MDrv_BDMA_CRC32(DOWNLOAD_BUFFER_ADR_OAD, u32DownloadSize, BDMA_CRC32_POLY, BDMA_CRC_SEED_0, E_BDMA_SRCDEV_MIU0, FALSE))
            {
                OAD_DEBUG( printf("Error> CRC32 Integrity Check failed !!\n") );
                if (pZUIDrawPercentageCB != NULL)
                    pZUIDrawPercentageCB(0xFE); //CRC Error
                break ;
            }
            else
            {
                OAD_DEBUG( printf("CRC32Integrity Check pass !!\n") );
            }
            MApp_SwUpdate_Start( SW_UPDATE_MODE_PARTIAL_OAD,FALSE, FALSE, FALSE,DOWNLOAD_BUFFER_ADR_OAD,u32DownloadSize,DOWNLOAD_BUFFER_TYPE_OAD, FALSE);
            #endif
            break ;
        }

        case EN_OAD_APP_STATE_EXIT:
        {
            MApp_ZUI_ACT_ShutdownOSD();
            enRetVal =EXIT_CLOSE;
            break ;
        }
        case EN_OAD_APP_STATE_DOWNLOADING:
        {
            MApp_ZUI_ProcessKey(u8KeyCode);
            MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_OAD_PAINTPROGRESS);//update data;
            if (MApp_OAD_IsDownloadCompleted())
            {
                #if FLASH_DIRECT_WRITE
                #if 0
                MDrv_Sys_SetWatchDogTimer(0);
                MDrv_Sys_EnableWatchDog();
                while(1); // reset
                #else
                msAPI_BLoader_Reboot();
                #endif
                #else
                #if (!OBA2)
                MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_OAD_GOTOUPGRADE);
                #endif
                MApp_OAD_SetAppState(EN_OAD_APP_STATE_UPGRADING) ;
                #endif
            }
            else if (!MApp_OAD_IsDownloading())
            {
                MApp_OAD_SetAppState(EN_OAD_APP_STATE_STOP) ;
            }
            break ;
        }
#if 0
        case EN_OAD_APP_STATE_SCAN:
        {
            EN_OAD_SCAN_STATE scanState ;
            U8 u8Percentage;
            scanState = MApp_OAD_Scan(&u8Percentage) ;
            if (scanState==STATE_OAD_SCAN_END)
            {
                enOADScanState = STATE_OAD_SCAN_INIT; // Prepare for next time.
                enRetVal =EXIT_CLOSE;
            }
            break ;
        }
#endif
        default:
        {
            break;
        }
    }
    return enRetVal ;
}
#if (BLOADER)
EN_OAD_SCAN_STATE MApp_OAD_Scan( U8* percentage )
{
    BOOLEAN ScanResult;
    switch( enOADScanState )
    {
        case STATE_OAD_SCAN_INIT:
            msAPI_Tuner_PowerOnOff( ENABLE );


            u8OadRFCh = msAPI_DFT_GetFirstPhysicalChannelNumber();
            msAPI_DFT_GetTSSetting( u8OadRFCh, &stOadTPSetting);
            enOADScanState = STATE_OAD_SCAN_SEARCH_RF_CHANNEL;
            break;

        case STATE_OAD_SCAN_NEXT_CHANNEL:
            {
	         oadCH=u8OadRFCh = msAPI_DFT_GetNextPhysicalChannelNumber(u8OadRFCh);
                if( u8OadRFCh == INVALID_PHYSICAL_CHANNEL_NUMBER/*u8MaxRFCh*/ )
                {
                    //printf("Invalid Phy Ch\n");
                    enOADScanState = STATE_OAD_SCAN_END;
                    break;
                }

                enOADScanState = STATE_OAD_SCAN_SEARCH_RF_CHANNEL;
                msAPI_DFT_GetTSSetting( u8OadRFCh, &stOadTPSetting);
                *percentage = msAPI_DFT_GetPercentWithPhysicalChannelNumber(u8OadRFCh);

                if (*percentage>100)
                {
                    enOADScanState = STATE_OAD_SCAN_END; // kk 0319-2 bug
                }
                //printf("Rf %d, percent %d\n",u8OadRFCh,*percentage);
                break;
            }

        case STATE_OAD_SCAN_SEARCH_RF_CHANNEL:
            //wNetworkID = INVALID_ON_ID;
            if ( MApp_DVB_Scan(&stOadTPSetting, &ScanResult) == FALSE )
            {
                break;
            }

            if ( ScanResult == FE_LOCK )
            {
                //printf("FF lock, go to patpmt monitor state\n");

                enOADScanState = STATE_OAD_SCAN_PATPMT_MONITOR;
                u32OadScanWaitTableTimer = msAPI_Timer_GetTime0();
                MApp_OAD_SetMonitorState(EN_OAD_MONITOR_STATE_PMT_DBID_RECEINING);
                MApp_BL_SI_ParseStateInit();
            }
            else
            {
                //printf("Not lock, go to next\n");
                enOADScanState = STATE_OAD_SCAN_NEXT_CHANNEL;
            }

            break;

        case STATE_OAD_SCAN_PATPMT_MONITOR:
            if (MApp_BL_SI_Table_Monitor())
            {
                if(MApp_OAD_GetMonitorState() == EN_OAD_MONITOR_STATE_DSI_INIT)
                {
                    while(1)
                    {
                        EN_OAD_MONITOR_STATE curr_state = MApp_OAD_GetMonitorState();
                        if((curr_state == EN_OAD_MONITOR_STATE_STOP) ||
                            (curr_state == EN_OAD_MONITOR_STATE_NONE))
                        {
                            MApp_BL_SI_DisableTableMonitor();
                            MApp_OAD_Monitor(); //do oad init
                            enOADScanState = STATE_OAD_SCAN_NEXT_CHANNEL;
                            break;
                        }
                        MApp_OAD_Monitor();
                        MsOS_DelayTask(25);
                        if(curr_state == EN_OAD_MONITOR_STATE_DSI_SIGNAL) //done
                        {
                            MApp_OAD_Download();
                        }
                    }
                }
                else
                {
                    MApp_BL_SI_DisableTableMonitor();
                    enOADScanState = STATE_OAD_SCAN_NEXT_CHANNEL;
                }
            }
            else
            {
                if (msAPI_Timer_DiffTimeFromNow(u32OadScanWaitTableTimer) >= OAD_SCAN_WAIT_TABLE_TIME)
                {
                    MApp_BL_SI_DisableTableMonitor();
                    enOADScanState = STATE_OAD_SCAN_NEXT_CHANNEL;
                }
            }
            break;
        default:
            break;
    }
    if(enOADScanState == STATE_OAD_SCAN_END)
    {
        MApp_BL_SI_DisableTableMonitor();
    }
    return enOADScanState;
}
#if 0
EN_OAD_SCAN_STATE MApp_OAD_Scan( U8* percentage )
{
    BOOLEAN ScanResult;
    switch( enOADScanState )
    {
        case STATE_OAD_SCAN_INIT:
            msAPI_Tuner_PowerOnOff( ENABLE );

            MApp_Dmx_GetScanTableStateInit();

            if ( MApp_DTV_Scan_Init() == TRUE )
            {
                u8OadRFCh = msAPI_DFT_GetFirstPhysicalChannelNumber();
                #if (BLOADER)
                msAPI_DFT_GetTSSetting( u8OadRFCh, &stOadTPSetting);
                #endif //(BLOADER)
                enOADScanState = STATE_OAD_SCAN_SEARCH_RF_CHANNEL;
            }
            else
            {
                /* allocate memory failure, maybe need to display warning msg. here */
                enOADScanState = STATE_OAD_SCAN_END;
            }
            break;

        case STATE_OAD_SCAN_NEXT_CHANNEL:
            {
	         oadCH=u8OadRFCh = msAPI_DFT_GetNextPhysicalChannelNumber(u8OadRFCh);
                if( u8OadRFCh == INVALID_PHYSICAL_CHANNEL_NUMBER/*u8MaxRFCh*/ )
                {
                    //printf("Invalid Phy Ch\n");
                    enOADScanState = STATE_OAD_SCAN_END;
                    break;
                }

                enOADScanState = STATE_OAD_SCAN_SEARCH_RF_CHANNEL;
                msAPI_DFT_GetTSSetting( u8OadRFCh, &stOadTPSetting);
                *percentage = msAPI_DFT_GetPercentWithPhysicalChannelNumber(u8OadRFCh);

                if (*percentage>100)
                {
                    enOADScanState = STATE_OAD_SCAN_END; // kk 0319-2 bug
                }
                //printf("Rf %d, percent %d\n",u8OadRFCh,*percentage);
                break;
            }

        case STATE_OAD_SCAN_SEARCH_RF_CHANNEL:
            //wNetworkID = INVALID_ON_ID;
            if ( MApp_DVB_Scan(&stOadTPSetting, &ScanResult) == FALSE )
            {
                break;
            }

            if ( ScanResult == FE_LOCK )
            {
                //printf("FF lock, go to patpmt monitor state\n");
                enOADScanState = STATE_OAD_SCAN_PATPMT_MONITOR;
            }
            else
            {
                //printf("Not lock, go to next\n");
                enOADScanState = STATE_OAD_SCAN_NEXT_CHANNEL;
            }

            break;

        case STATE_OAD_SCAN_PATPMT_MONITOR:
            //printf("STATE_OAD_SCAN_PATPMT_MONITOR\n");
            u32OadScanWaitTableTimer = msAPI_Timer_GetTime0();
            MApp_Dmx_SetOADScanMode(TRUE);
            MApp_SI_Table_Monitor();
            enOADScanState = STATE_OAD_SCAN_WAIT_PATPMT_MONITOR;
            break;

        case STATE_OAD_SCAN_WAIT_PATPMT_MONITOR:
            #if (BLOADER)
            MApp_Dmx_SetOADScanMode(TRUE);
            #endif //(BLOADER)
            MApp_SI_Table_Monitor();
            if(!MApp_Dmx_GetOADScanMode() || msAPI_Timer_DiffTimeFromNow(u32OadScanWaitTableTimer) >= OAD_SCAN_WAIT_TABLE_TIME)
            {
                MApp_Dmx_SetOADScanMode(FALSE);
                #if (BLOADER)
                MApp_Dmx_GetScanTableStateInit();
                #endif //(BLOADER)
                enOADScanState = STATE_OAD_SCAN_NEXT_CHANNEL;
                break;
            }

            if(MApp_OAD_GetMonitorState() == EN_OAD_MONITOR_STATE_DSI_INIT)
            {
                #if (BLOADER)
                while(1)
                {
                    EN_OAD_MONITOR_STATE curr_state = MApp_OAD_GetMonitorState();
                    if((curr_state == EN_OAD_MONITOR_STATE_STOP) ||
                        (curr_state == EN_OAD_MONITOR_STATE_NONE))
                    {
                        break;
                    }
                    MApp_OAD_Monitor();
                    MsOS_DelayTask(25);
                    if(curr_state == EN_OAD_MONITOR_STATE_DSI_SIGNAL) //done
                    {
                        MApp_Dmx_SetOADScanMode(FALSE);
                        enOADScanState = STATE_OAD_SCAN_END;
                        break;
                    }
                }
                #else //(BLOADER)
                // Found OAD information, stop tuning.
                //printf("Found OAD Information\n");
                MApp_Dmx_SetOADScanMode(FALSE);
                enOADScanState = STATE_OAD_SCAN_END;
                #endif //(BLOADER)
            }
            break;
            default:
                break;
    }
    if(enOADScanState == STATE_OAD_SCAN_END)
    {
        MApp_Dmx_SetOADScanMode(FALSE);
        MApp_DTV_Scan_End(FALSE);

        #if (!BLOADER)
        if ( !IsSrcTypeDTV( SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW) ) )
        {
            msAPI_Tuner_PowerOnOff(DISABLE);
        }
        #endif //(!BLOADER)
    }
    return enOADScanState;
}
#endif
#else
static void MApp_OAD_Scan_ProcessUserInput( void )
{
    switch ( u8KeyCode )
    {
        case KEY_POWER:
        case DSC_KEY_PWROFF:
        {
	    u8KeyCode = KEY_POWER;
           MApp_ZUI_ProcessKey(u8KeyCode);
        }
        break;

        case KEY_EXIT:
        case KEY_MENU:
        {
            u8KeyCode = KEY_EXIT;
            enOADScanState = STATE_OAD_SCAN_EXIT;
            MApp_ZUI_ProcessKey(u8KeyCode);
        }
        break;

        default:
            break;
    }
    u8KeyCode = KEY_NULL;
}

EN_RET MApp_OAD_Scan( U8* percentage )
{
    BOOLEAN ScanResult;
    EN_RET bReturnVal = EXIT_NULL;
    BOOLEAN bFound_SSU = FALSE;

    OAD_DEBUG( printf("enOADScanState = %bu\n", enOADScanState) );
    MApp_OAD_Scan_ProcessUserInput();
    switch( enOADScanState )
    {
        case STATE_OAD_SCAN_INIT:
            OAD_DEBUG(printf("STATE_OAD_SCAN_INIT\n"));
            *percentage = 0;
            _bOAD_AutoScanEnable = TRUE;
            msAPI_Tuner_PowerOnOff( ENABLE );
            MApp_Dmx_GetScanTableStateInit();
            bFound_SSU = FALSE;
            if ( MApp_DTV_Scan_Init() == TRUE )
            {
                stGenSetting.stScanMenuSetting.u8ScanType = SCAN_TYPE_AUTO;
                stGenSetting.stScanMenuSetting.u8ChType = CH_TYPE_DTV;
                u8OadRFCh = msAPI_DFT_GetFirstPhysicalChannelNumber();
                enOADScanState = STATE_OAD_SCAN_SEARCH_RF_CHANNEL;
            }
            else
            {
                /* allocate memory failure, maybe need to display warning msg. here */
                enOADScanState = STATE_OAD_SCAN_END;
            }
            #if 0 //wait to do
	        MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_REPAINT_OAD_SCAN);
            #endif
            break;

        case STATE_OAD_SCAN_NEXT_CHANNEL:
            {
	         oadCH=u8OadRFCh = msAPI_DFT_GetNextPhysicalChannelNumber(u8OadRFCh);
                if( u8OadRFCh == INVALID_PHYSICAL_CHANNEL_NUMBER/*u8MaxRFCh*/ )
                {
                    //printf("Invalid Phy Ch\n");
                    enOADScanState = STATE_OAD_SCAN_END;
                    OAD_DEBUG(printf("No found SSU\n"));
                    MApp_ZUI_ACT_ShutdownOSD();
                    MApp_ZUI_ACT_StartupOSD(E_OSD_MESSAGE_BOX);
                    #if 0 //wait to do
                    MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_NO_OAD_AVAILABLE);
                    #endif
                    break;
                }

                enOADScanState = STATE_OAD_SCAN_SEARCH_RF_CHANNEL;
                msAPI_DFT_GetTSSetting( u8OadRFCh, &stOadTPSetting);
                *percentage = msAPI_DFT_GetPercentWithPhysicalChannelNumber(u8OadRFCh);

                if (*percentage==100)
                {
                    MApp_ZUI_ACT_ShutdownOSD();
                    MApp_ZUI_ACT_StartupOSD(E_OSD_MESSAGE_BOX);
                    #if 0 //wait to do
                    MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_NO_OAD_AVAILABLE);
                    #endif
                    enOADScanState = STATE_OAD_SCAN_END; // kk 0319-2 bug
                }
                #if 0 //wait to do
		        MApp_ZUI_ACT_ExecuteWndAction(EN_EXE_REPAINT_OAD_SCAN);
                #endif
                break;
            }

        case STATE_OAD_SCAN_SEARCH_RF_CHANNEL:
            //wNetworkID = INVALID_ON_ID;
            if ( MApp_DVB_Scan(&stOadTPSetting, &ScanResult) == FALSE )
            {
                break;
            }

            if ( ScanResult == FE_LOCK )
            {
                //printf("FF lock, go to patpmt monitor state\n");
                enOADScanState = STATE_OAD_SCAN_PATPMT_MONITOR;
            }
            else
            {
                //printf("Not lock, go to next\n");
                enOADScanState = STATE_OAD_SCAN_NEXT_CHANNEL;
            }

            break;

        case STATE_OAD_SCAN_PATPMT_MONITOR:
            //printf("STATE_OAD_SCAN_PATPMT_MONITOR\n");
            MApp_Dmx_DisableTableMonitor();
            MApp_SI_ResetPATMonitor();
            MApp_Dmx_SetOADScanMode(TRUE);
            u32OadScanWaitTableTimer = msAPI_Timer_GetTime0();
            enOADScanState = STATE_OAD_SCAN_WAIT_PATPMT_MONITOR;
            break;

        case STATE_OAD_SCAN_WAIT_PATPMT_MONITOR:
            MApp_SI_Table_Monitor();
            if(!MApp_Dmx_GetOADScanMode() || msAPI_Timer_DiffTimeFromNow(u32OadScanWaitTableTimer) >= OAD_SCAN_WAIT_TABLE_TIME)
            {
                MApp_Dmx_SetOADScanMode(FALSE);
                enOADScanState = STATE_OAD_SCAN_NEXT_CHANNEL;
                //break;
            }
            if(MApp_OAD_GetMonitorState() == EN_OAD_MONITOR_STATE_DSI_INIT)
            {
                // Found OAD information, stop tuning.
                //printf("Found OAD Information\n");
                OAD_DEBUG(printf("found OUI and wait DSI check version\n"));
                enOADScanState = STATE_OAD_SCAN_WAIT_DSI_CHECK_VERSION;
            }
            break;
        case STATE_OAD_SCAN_WAIT_DSI_CHECK_VERSION:
            {
                //printf("wait check version\n");
                MApp_OAD_Monitor();
                if(MApp_OAD_GetMonitorState() == EN_OAD_MONITOR_STATE_DSI_SIGNAL)
                {
                    //MApp_Dmx_SetOADScanMode(FALSE);
                    //printf("SCAN_END\n");
                enOADScanState = STATE_OAD_SCAN_END;
                    bFound_SSU = TRUE;
                    OAD_DEBUG(printf("found new version\n"));
                }
                else if(MApp_OAD_GetMonitorState() == EN_OAD_MONITOR_STATE_STOP)
                {
                    enOADScanState = STATE_OAD_SCAN_NEXT_CHANNEL;
                    OAD_DEBUG(printf("DSI not found or wrong version\n"));
                }
            }
            break;
        case STATE_OAD_SCAN_EXIT:
            {
                enOADScanState = STATE_OAD_SCAN_END;//modify here if you want back previous menu
            }
            break;
            default:
                break;
    }
    if(enOADScanState == STATE_OAD_SCAN_END)
    {
        bReturnVal=EXIT_GOTO_CHANNELCHANGE;
        MApp_Dmx_SetOADScanMode(FALSE);
        MApp_DTV_Scan_End(FALSE);
        _bOAD_AutoScanEnable = FALSE;
        bShowOadScanPage = FALSE;
        *percentage = 0;
        u8OadRFCh = msAPI_DFT_GetFirstPhysicalChannelNumber();
        if(bFound_SSU == FALSE)
        {
            if(msAPI_CM_CountProgram(msAPI_CM_GetCurrentServiceType(), E_PROGACESS_INCLUDE_NOT_VISIBLE_ALSO) > 0)
            {
                MApp_ChannelChange_EnableChannel(MAIN_WINDOW);
            }
        if ( !IsSrcTypeDTV( SYS_INPUT_SOURCE_TYPE(MAIN_WINDOW) ) )
        {
            msAPI_Tuner_PowerOnOff(DISABLE);
        }
    }
        enOADScanState = STATE_OAD_SCAN_INIT;
    }
    return bReturnVal;
}
#endif
#else
//static code U8 u8Dummy;
#endif //ENABLE_OAD

#undef _MAPP_OAD_C_

