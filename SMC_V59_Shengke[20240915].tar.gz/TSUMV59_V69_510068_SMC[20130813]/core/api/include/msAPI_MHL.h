///////////////////////////////////////////////////////////////////////////////////////////////////
///
/// @file   msAPI_mhl.h
/// @author MStar Semiconductor Inc.
/// @brief  MHL API Function
///////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef _MSAPI_MHL_H_
#define _MSAPI_MHL_H_

#include "Mhl.h"
#include "MsTypes.h"

//#include "MST_MHL_st.h"

//-------------------------------------------------------------------------------------------------
//  Local Structures
//-------------------------------------------------------------------------------------------------


typedef enum
{
    E_MHL_SEND_RCP_SUCCESS,
    E_MHL_SEND_RCP_FAIL,
    E_MHL_SEND_RCP_UNSUPPORT
} E_MHL_SEDN_RCP_RESULT;
#define HDMI_PORT_FOR_MHL UI_INPUT_SOURCE_HDMI


E_MHL_SEDN_RCP_RESULT msAPI_MHL_IRKeyProcess(MS_U8 u8Keycode, MS_BOOL bIsRelease);
MS_U8 msAPI_MHL_CbusRcpProcess (MS_U8 rcpCode);
MS_U8 msAPI_MHL_CbusRapProcess (MS_U8 rapCode);

#endif //_MSAPI_MHL_H_


