////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MAPP_MENU_MAIN_H
#define _MAPP_MENU_MAIN_H

#include "datatype.h"
#include "MApp_Exit.h"

#ifdef MAPP_MENU_MAIN_C
#define INTERFACE
#else
#define INTERFACE extern
#endif

typedef enum
{
    STATE_MENU_INIT,
    STATE_MENU_WAIT,
    STATE_MENU_EPGTIMER_WAIT,
    STATE_MENU_CLEAN_UP,
    STATE_MENU_GOTO_STANDBY,
    STATE_MENU_GOTO_SCAN,
    STATE_MENU_GOTO_EPG,
    STATE_MENU_GOTO_DTV_MANUALTUNING,
    STATE_MENU_GOTO_ATV_MANUALTUNING,
#if DVB_C_ENABLE
    STATE_MENU_GOTO_CADTV_MANUALTUNING,
#endif
    STATE_MENU_GOTO_PREDIT,
    STATE_MENU_GOTO_CHANNELCHANGE,  // To chagne TV<->RADIO when banner is displayed.
    STATE_MENU_GOTO_CIMMI,
#if ENABLE_DMP
    STATE_MENU_GOTO_DMP,
#endif
#ifdef ENABLE_BT
    STATE_MENU_GOTO_BT,
#endif
#ifdef ENABLE_KTV
    STATE_MENU_GOTO_KTV,
#endif
#if(ENABLE_PVR ==1)
    STATE_MENU_GOTO_PVR_CHECK_FS,
#endif
    STATE_MENU_GOTO_OSDPAGE,
    STATE_MENU_GOTO_INPUT_SOURCE,
    STATE_MENU_GOTO_CHANNEL_LIST,
#if 0 //TODO
    STATE_MENU_GOTO_NETWORK_LIST,
    STATE_MENU_GOTO_OAD_SCAN,
#endif
    STATE_MENU_GOTO_INFO,
    STATE_MENU_GOTO_FAVORITE_LIST,
#if OBA2
    STATE_MENU_GOTO_APENGINE,
#endif
#ifdef ENABLE_YOUTUBE
    STATE_MENU_GOTO_YOUTUBE,
#endif
#ifdef ENABLE_RSS
    STATE_MENU_GOTO_RSS,
#endif
//#ifdef ENABLE_NETFLIX
//    STATE_MENU_GOTO_NETFLIX,
//#endif
#if (ENABLE_GAME)
    STATE_MENU_GOTO_GAME,
#endif
#ifdef ENABLE_EXTENSION
    STATE_MENU_GOTO_EXTENSION,
#endif
#if BOE_USB_UPGRADE_FACTROY//minglin1206
STATE_MENU_USB_UPDATE,
STATE_MENU_USB_UPDATE2
#endif
} EN_MENU_STATE;

typedef enum
{
    STATE_RETURN_NULL,
    STATE_RETURN_DTV_MANUAL_TUNING,
    STATE_RETURN_ATV_MANUAL_TUNING,
    STATE_RETURN_CADTV_MANUAL_TUNING,
    STATE_RETURN_CIMMI,
    STATE_RETURN_PROGRAM_BLOCK,
    STATE_RETURN_PROGRAM_EDIT,
    STATE_RETURN_PVR_FILE_SYS,
    STATE_RETURN_DVBC_SCAN_TUNING,
    #ifdef ENABLE_CUS_AUTO_SCAN_HOTKEY
    STATE_RETURN_AUTO_SCAN_PAGE_AND_DO_AUTO_SCAN,
	#endif
    STATE_RETURN_LOCK_PAGE,
} EN_MENU_RETURN_ITEM;

INTERFACE EN_RET MApp_Menu_Main(void);

INTERFACE EN_MENU_RETURN_ITEM _enReturnMenuItem;
#undef INTERFACE

#endif  // _MAPP_MENU_MAIN_H

