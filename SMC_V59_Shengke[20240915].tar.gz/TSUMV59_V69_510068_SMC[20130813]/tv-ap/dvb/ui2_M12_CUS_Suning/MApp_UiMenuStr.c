////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#define MAPP_UI_MENUSTR_C
#include <string.h>
#include "stdio.h"
#include "sysinfo.h"

#include "msAPI_Timer.h"
#include "msAPI_audio.h"
#include "apiXC_Sys.h"
#include "apiXC.h"
#include "apiXC_Adc.h"
#if ( ENABLE_ATV_VCHIP)
#include "MApp_GlobalFunction.h"
#include "MApp_GlobalVar.h"
#include "MApp_VChip.h"
#include "MApp_Audio.h"
#include "MApp_UiMenuStr.h"
#include "MApp_UiMenuFunc.h"
#include "MApp_ZUI_ACTglobal.h"

#include "OSDcp_String_EnumIndex.h"
#define INFO_BANNER_TIME_ALWAYS_BY_STREAM   DISABLE

extern U32 g_u32StreamTime;
extern MS_U8 bPreviousSoundMode, bCurrentSoundMode;
extern U16* MApp_ZUI_API_GetString(U16 id);

static U16 MApp_UiMenu_u16Strlen(U16 *pu16Str)
{
    U16 u16Count;

    u16Count = 0;
    while(*pu16Str++ != 0)
    {
        u16Count++;
    }
    return u16Count;
}

static void MApp_U16StringToU8String ( U16 *pu16Str, U8 *pu8Str, U8 u8Strlen )
{
    U8 u8Index;

    for ( u8Index = 0; u8Index < u8Strlen; u8Index++ )
    {
        pu8Str[u8Index] = (U8)pu16Str[u8Index];
    }
    pu8Str[u8Index] = 0;
}

U8* VChipTVPGMenuItemName_Text(void)//EN_STRING_CANADACE_TEXT
{
    U16 u16TempStringID;

    switch(g_stVChipRatingInfo.RatingLevel)
    {
        default:
        case VCHIP_TVRATING_NONE://MSG_VCHIP_TV_NONE,
           u16TempStringID = en_strVChip_None_Text;
        break;

        case VCHIP_TVRATING_TV_Y://MSG_VCHIP_TV_Y,
           u16TempStringID = en_strVChip_TV_Y_Text;
        break;

        case VCHIP_TVRATING_TV_Y7://MSG_VCHIP_TV_Y7,
            u16TempStringID = en_strVChip_TV_Y7_Text;
        break;

        case VCHIP_TVRATING_TV_G://MSG_VCHIP_TV_G,
            u16TempStringID = en_strVChip_TV_G_Text;
        break;

        case VCHIP_TVRATING_TV_PG://MSG_VCHIP_TV_PG,
            u16TempStringID = en_strVChip_TV_PG_Text;
        break;

        case VCHIP_TVRATING_TV_14://MSG_VCHIP_TV_14,
            u16TempStringID = en_strVChip_TV_14_Text;
        break;


        case VCHIP_TVRATING_TV_MA://MSG_VCHIP_TV_MA,
            u16TempStringID = en_strVChip_TV_MA_Text;
        break;
    }

    MApp_U16StringToU8String(MApp_ZUI_API_GetString(u16TempStringID),(U8*)CHAR_BUFFER,MApp_UiMenu_u16Strlen(MApp_ZUI_API_GetString(u16TempStringID)));
    return  (U8*)CHAR_BUFFER;
}

U8* VChipMPAAOptionName_Text(void)
{
    U16 u16TempStringID;

    switch(g_stVChipRatingInfo.MPAALevel)
    {
        default:
        case VCHIP_MPAARATING_NA:
            u16TempStringID = en_strMPAA_NA_Text;
        break;

        case VCHIP_MPAARATING_G:
            u16TempStringID = en_strMPAA_G_Text;
        break;

        case VCHIP_MPAARATING_PG:
            u16TempStringID = en_strMPAA_PG_Text;
        break;

        case VCHIP_MPAARATING_PG_13:
            u16TempStringID = en_strMPAA_PG13_Text;
        break;
        case VCHIP_MPAARATING_R:
            u16TempStringID = en_strMPAA_R_Text;
        break;
        case VCHIP_MPAARATING_NC_17:
            u16TempStringID = en_strMPAA_NC17_Text;
        break;
        case VCHIP_MPAARATING_X:
            u16TempStringID = en_strMPAA_X_Text;
        break;
    }

    MApp_U16StringToU8String(MApp_ZUI_API_GetString(u16TempStringID),(U8*)CHAR_BUFFER,MApp_UiMenu_u16Strlen(MApp_ZUI_API_GetString(u16TempStringID)));
    return  (U8*)CHAR_BUFFER;
}

U8* VChipCanadaEnglishOptionName_Text(void)
{
    U16 u16TempStringID;

    switch(g_stVChipRatingInfo.CanEngLevel)
    {
        default:
        case VCHIP_ENGRATING_EXEMPT:
           u16TempStringID = en_strCANADA_VChip_E_Text;
        break;

        case VCHIP_ENGRATING_C:
            u16TempStringID = en_strCANADA_VChip_C_Text;
         break;

        case VCHIP_ENGRATING_C8Plus:
           u16TempStringID = en_strCANADA_VChip_C8_Text;
         break;

        case VCHIP_ENGRATING_G:
            u16TempStringID = en_strCANADA_VChip_G_Text;
         break;

        case VCHIP_ENGRATING_PG:
             u16TempStringID = en_strCANADA_VChip_PG_Text;
          break;

        case VCHIP_ENGRATING_14Plus:
           u16TempStringID = en_strCANADA_VChip_14_Text;
         break;


        case VCHIP_ENGRATING_18Plus:
           u16TempStringID = en_strCANADA_VChip_18_Text;
         break;
    }

    MApp_U16StringToU8String(MApp_ZUI_API_GetString(u16TempStringID),(U8*)CHAR_BUFFER,MApp_UiMenu_u16Strlen(MApp_ZUI_API_GetString(u16TempStringID)));
    return  (U8*)CHAR_BUFFER;

}

U8* enVChipCanadaFrenchOptionName_Text(void)//EN_STRING_CANADACF_MODE_SELECT_TEXT_WHITE,
{
    U16 u16TempStringID;

    switch(g_stVChipRatingInfo.CanFreLevel)
    {
        default:
        case VCHIP_FRERATING_EXEMPT:
            u16TempStringID = en_strCANADA_VChip_E_Text;
        break;

        case VCHIP_FRERATING_G:
            u16TempStringID = en_strCANADA_VChip_G_Text;
        break;

        case VCHIP_FRERATING_8ansPlus:
            u16TempStringID = en_strCANADA_VChip_8ans_Text;
        break;

        case VCHIP_FRERATING_13ansPlus:
           u16TempStringID = en_strCANADA_VChip_13ans_Text;
        break;


        case VCHIP_FRERATING_16ansPlus:
            u16TempStringID = en_strCANADA_VChip_16ans_Text;
        break;

        case VCHIP_FRERATING_18ansPlus:
            u16TempStringID = en_strCANADA_VChip_18ans_Text;

        break;
    }
    MApp_U16StringToU8String(MApp_ZUI_API_GetString(u16TempStringID),(U8*)CHAR_BUFFER,MApp_UiMenu_u16Strlen(MApp_ZUI_API_GetString(u16TempStringID)));
    return  (U8*)CHAR_BUFFER;
}


static U8 UiMenuStr_GetTVRatingString(U8 *pu8Str)
{
    U8 u8Strlen;

#if 0
    strcpy((S8 *)pu8Str, (S8 *)VChipTVPGMenuItemName_Text());
    u8Strlen = strlen((S8 *)VChipTVPGMenuItemName_Text());
#else
    strncpy((char *)pu8Str, (char *)VChipTVPGMenuItemName_Text(), strlen((char *)VChipTVPGMenuItemName_Text()));
    u8Strlen = strlen((char *)VChipTVPGMenuItemName_Text());
#endif


    pu8Str += u8Strlen;

    #if (0)
    switch(g_stVChipRatingInfo.RatingLevel)
    {
        case VCHIP_TVRATING_TV_Y7:
            if(g_stVChipRatingInfo.TV_FVSLD & VCHIP_TVRATING_FV)
            {
                strncpy((char *)pu8Str, "-FV", strlen((char *)pu8Str)-1); //strcpy((char *)pu8Str, "-FV");
                u8Strlen += (strlen("-FV"));
            }
            break;
        case VCHIP_TVRATING_TV_PG:
        case VCHIP_TVRATING_TV_14:
            if(g_stVChipRatingInfo.TV_FVSLD & VCHIP_TVRATING_D)
            {
                strncpy((char *)pu8Str, "-D", strlen((char *)pu8Str)-1); //strcpy((char *)pu8Str, "-D");
                u8Strlen += (strlen("-D"));
            }
            // do not break here
        case VCHIP_TVRATING_TV_MA:
            if(g_stVChipRatingInfo.TV_FVSLD & VCHIP_TVRATING_L)
            {
                strncpy((char *)pu8Str, "-L", strlen((char *)pu8Str)-1);//strcpy((S8 *)pu8Str, "-L");
                u8Strlen += (strlen("-L"));
            }
            if(g_stVChipRatingInfo.TV_FVSLD & VCHIP_TVRATING_S)
            {
                strncpy((char *)pu8Str,"-S", strlen((char *)pu8Str)-1);//strcpy((S8 *)pu8Str,"-S");
                u8Strlen += (strlen("-S"));
            }
            if(g_stVChipRatingInfo.TV_FVSLD & VCHIP_TVRATING_V)
            {
                strncpy((char *)pu8Str, "-V", strlen((char *)pu8Str)-1);//strcpy((S8 *)pu8Str, "-V");
                u8Strlen += (strlen("-V"));
            }
            break;
    }
    #else
    switch(g_stVChipRatingInfo.RatingLevel)
    {
            case VCHIP_TVRATING_TV_Y7:
                if(g_stVChipRatingInfo.TV_FVSLD & VCHIP_TVRATING_FV)
                {
                    *pu8Str++ = CHAR_MINUS;
                    strcpy((char *)pu8Str,"FV");
                    u8Strlen += (strlen("FV"));
                }
                break;
            case VCHIP_TVRATING_TV_PG:
            case VCHIP_TVRATING_TV_14:
                if(g_stVChipRatingInfo.TV_FVSLD & VCHIP_TVRATING_D)
                {
                    *pu8Str++ = CHAR_MINUS;
                    strcpy((char *)pu8Str++, "D");
                    u8Strlen += (strlen("D"));
                }
                // do not break here
            case VCHIP_TVRATING_TV_MA:
                if(g_stVChipRatingInfo.TV_FVSLD & VCHIP_TVRATING_L)
                {
                    *pu8Str++ = CHAR_MINUS;
                    strcpy((char *)pu8Str++,"L");
                    u8Strlen += (strlen("L"));
                }
                if(g_stVChipRatingInfo.TV_FVSLD & VCHIP_TVRATING_S)
                {
                    *pu8Str++ = CHAR_MINUS;
                    strcpy((char *)pu8Str++,"S");
                    u8Strlen += (strlen("S"));
                }
                if(g_stVChipRatingInfo.TV_FVSLD & VCHIP_TVRATING_V)
                {
                    *pu8Str++ = CHAR_MINUS;
                    strcpy((char *)pu8Str,"V");
                    u8Strlen += (strlen("V"));
                }
                break;
    }
    #endif
    return u8Strlen;
}
static U8 UiMenuStr_GetVChip1RatingString(U8* pu8Str)
{
    U8 u8Strlen;

    if (!pu8Str)
        return 0;

    pu8Str[0] = 0;
    u8Strlen = 0;

    if (!(g_stVChipRatingInfo.u8EIA608Data1&BIT4) /*&& (g_stUiEvent.stRating.u8TVRatingForEntire != INVALID_TV_RATING_FOR_ENTIRE)*/)
    {
        //if (u8Strlen)
        //{
        //    strcat((char *)pu8Str, " / ");//strcat((S8 *)pu8Str, " / ");
        //}
        u8Strlen += UiMenuStr_GetTVRatingString(pu8Str);
    }

    if (g_stVChipRatingInfo.MPAALevel > VCHIP_MPAARATING_NA
        && g_stVChipRatingInfo.MPAALevel < VCHIP_MPAARATING_NOT_RATED)
    {
        if (u8Strlen)
        {
            strcat((char *)pu8Str, " / ");//strcat((S8 *)pu8Str, " / ");
        }
        strncpy((char *)pu8Str, "MPAA-", strlen("MPAA-")+1);//strcpy((S8 *)pu8Str, "MPAA-");
        u8Strlen += (strlen("MPAA-"));
        //strcat((S8 *)pu8Str, (S8 *)VChipMPAAOptionName_Text());
        //u8Strlen += strlen((S8 *)VChipMPAAOptionName_Text());
        strcat((char *)pu8Str, (char *)VChipMPAAOptionName_Text());
        u8Strlen += strlen((char *)VChipMPAAOptionName_Text());
    }

    if (g_stVChipRatingInfo.CanEngLevel > VCHIP_ENGRATING_EXEMPT && g_stVChipRatingInfo.CanEngLevel <= VCHIP_ENGRATING_MAX_LEVEL)
    {
        if (u8Strlen)
        {
            strcat((char  *)pu8Str, " / ");//strcat((S8 *)pu8Str, " / ");
        }
        //strcat((S8 *)pu8Str, (S8 *)VChipCanadaEnglishOptionName_Text());
        //u8Strlen += strlen((S8 *)VChipCanadaEnglishOptionName_Text());
        strcat((char *)pu8Str, (char *)VChipCanadaEnglishOptionName_Text());
        u8Strlen += strlen((char *)VChipCanadaEnglishOptionName_Text());
    }

    if (g_stVChipRatingInfo.CanFreLevel > VCHIP_FRERATING_EXEMPT && g_stVChipRatingInfo.CanFreLevel <= VCHIP_FRERATING_MAX_LEVEL)
    {
        if (u8Strlen)
        {
            strcat((char  *)pu8Str, " / ");//strcat((S8 *)pu8Str, " / ");
        }
        //strcat((S8 *)pu8Str, (S8 *)enVChipCanadaFrenchOptionName_Text());
        //u8Strlen += strlen((S8 *)enVChipCanadaFrenchOptionName_Text());
        strcat((char *)pu8Str, (char *)enVChipCanadaFrenchOptionName_Text());
        u8Strlen += strlen((char *)enVChipCanadaFrenchOptionName_Text());
    }

    return u8Strlen;
}

static void UiMenuStr_GetRatingString(U8 *pu8Str)
{

    //MS_EPG_EVENT stEventInfo;

    U8 u8Strlen;

    if (!pu8Str)
        return;

    pu8Str[0] = 0;

    if(!IsVBISrcInUse() || g_stVChipRatingInfo.RatingType == VCHIP_RATING_TYPE_NONE)
    {
        return;
    }

    u8Strlen = UiMenuStr_GetVChip1RatingString(pu8Str);

}

U8* RatingInfoText(void)
{
    memset(au8Section,0,256);

    UiMenuStr_GetRatingString((U8*)au8Section);

    return (U8*)au8Section;
}
#endif
#undef  MAPP_UI_MENUSTR_C

