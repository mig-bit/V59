////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#define MAPP_VCHIP_C

//==============================================================================
/*                 Header Files                                                 */
//==============================================================================
#include <string.h>
#include <stdio.h>
#include "Board.h"
#include "datatype.h"
#include "msAPI_Timer.h"
#include "msAPI_audio.h"
#include "apiGOP.h"
#include "apiXC.h"
#include "apiXC_Adc.h"
#include "msAPI_cc_driver.h"
#include "msAPI_VD.h"

#include "MApp_GlobalSettingSt.h"
#include "MApp_GlobalVar.h"
//#include "MApp_ChannelProc_A.h"
#include "MApp_Audio.h"
#include "MApp_VChip.h"
#include "MApp_ChannelChange.h"
#include "MApp_PCMode.h"

#if ( ENABLE_ATV_VCHIP)
#define VCHIP_DBINFO(y) //y
//==============================================================================
/*                    Macro                                                     */
//==============================================================================
#define VCHIP_MONITOR_PERIOD    100 /* ms */
extern BOOLEAN g_bInputBlocked;

//==============================================================================
/*                    Local                                                     */
//==============================================================================
static U32 u32MonitorVChipTimer;
static MS_U8 u32MonitorVChipFlag;
//static U8 g_ucVChipNoRatingCounter;
static MS_U8 fPreVChipBlockStatus, fCurVChipBlockStatus;
static MS_U8 fRatingUpdateStatus;


//==============================================================================
/*                    Functions                                                 */
//==============================================================================
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#if 0
#define DBG_E2R(msg) //msg
void MApp_VChip_EPGRating2RatingInfo(MS_EPG_RATING *pstCurEvn, MS_VCHIP_RATING_INFO *pstVChipRatingInfo)
{
    DBG_E2R(printf("\n[MApp_VChip_EPGRating2RatingInfo] %#lx", (U32)pstCurEvn));
    if (pstVChipRatingInfo)
        memset(pstVChipRatingInfo, 0, sizeof(MS_VCHIP_RATING_INFO));
    else
        return;

    if (pstCurEvn->fRatingRxIsOK)
    {
        if (pstCurEvn->u8TVRatingForEntire != INVALID_TV_RATING_FOR_ENTIRE) // make sure tv rating has received from CAD
        {
            pstVChipRatingInfo->RatingType = VCHIP_RATING_TYPE_TV;

            switch (pstCurEvn->u8TVRatingForEntire)
            {
                case 0:
                    if (pstCurEvn->u8TVRatingForChild == 1)
                    {
                        DBG_E2R(printf("\nRatingLevel = VCHIP_TVRATING_TV_Y"););
                        pstVChipRatingInfo->RatingLevel = VCHIP_TVRATING_TV_Y;
                    }
                    else if (pstCurEvn->u8TVRatingForChild == 2)
                    {
                        DBG_E2R(printf("\nRatingLevel = VCHIP_TVRATING_TV_Y7"););
                        pstVChipRatingInfo->RatingLevel = VCHIP_TVRATING_TV_Y7;

                        if (pstCurEvn->fFantasyViolence == 1)
                        {
                            DBG_E2R(printf("\nVCHIP_TVRATING_FV"););
                            pstVChipRatingInfo->TV_FVSLD |= VCHIP_TVRATING_FV;
                        }
                    }
                    break;
                case 1:
                    pstVChipRatingInfo->RatingLevel = VCHIP_TVRATING_NONE;
                    DBG_E2R(printf("\nRatingLevel = VCHIP_TVRATING_NONE"););
                    break;
                case 2:
                    pstVChipRatingInfo->RatingLevel = VCHIP_TVRATING_TV_G;
                    DBG_E2R(printf("\nRatingLevel = VCHIP_TVRATING_TV_G"););
                    break;
                case 3:
                    pstVChipRatingInfo->RatingLevel = VCHIP_TVRATING_TV_PG;
                    DBG_E2R(printf("\nRatingLevel = VCHIP_TVRATING_TV_PG"););
                    break;
                case 4:
                    pstVChipRatingInfo->RatingLevel = VCHIP_TVRATING_TV_14;
                    DBG_E2R(printf("\nRatingLevel = VCHIP_TVRATING_TV_14"););
                    break;
                case 5:
                    pstVChipRatingInfo->RatingLevel = VCHIP_TVRATING_TV_MA;
                    DBG_E2R(printf("\nRatingLevel = VCHIP_TVRATING_TV_MA"););
                    break;
#if 0
                // Just ignore undefined values. Or TV-NONE is shown. According to CEA-766-A,
                // no message is displayed.
                default:
                    DBG_E2R(printf("\nERROR RatingLevel = VCHIP_TVRATING_NONE"););
                    pstVChipRatingInfo->RatingLevel = VCHIP_TVRATING_NONE;
#endif
            }

            if (pstVChipRatingInfo->RatingLevel == VCHIP_TVRATING_TV_PG
                || pstVChipRatingInfo->RatingLevel == VCHIP_TVRATING_TV_14)
            {
                if (pstCurEvn->fDialog == 1)
                {
                    pstVChipRatingInfo->TV_FVSLD |= VCHIP_TVRATING_D;
                    DBG_E2R(printf("\nVCHIP_TVRATING_D"););
                }
            }

            if (pstVChipRatingInfo->RatingLevel == VCHIP_TVRATING_TV_PG
                || pstVChipRatingInfo->RatingLevel == VCHIP_TVRATING_TV_14
                || pstVChipRatingInfo->RatingLevel == VCHIP_TVRATING_TV_MA)
            {
                if (pstCurEvn->fLanguage == 1)
                {
                    DBG_E2R(printf("\nVCHIP_TVRATING_L"););
                    pstVChipRatingInfo->TV_FVSLD |= VCHIP_TVRATING_L;
                }
                if (pstCurEvn->fSexualContent == 1)
                {
                    DBG_E2R(printf("\nVCHIP_TVRATING_S"););
                    pstVChipRatingInfo->TV_FVSLD |= VCHIP_TVRATING_S;
                }
                if (pstCurEvn->fViolence == 1)
                {
                    DBG_E2R(printf("\nVCHIP_TVRATING_V"););
                    pstVChipRatingInfo->TV_FVSLD |= VCHIP_TVRATING_V;
                }
            }
        }

        if (pstCurEvn->u8MPAAFlag)
        {
            pstVChipRatingInfo->RatingType = VCHIP_RATING_TYPE_MPAA;
            if (pstCurEvn->u8MPAARatingD2)
                pstVChipRatingInfo->MPAALevel = pstCurEvn->u8MPAARatingD2 - 1;
            else
                pstVChipRatingInfo->MPAALevel = 0;
            DBG_E2R(printf("\nRatingType = VCHIP_RATING_TYPE_MPAA %bu", pstVChipRatingInfo->MPAALevel););
        }

        /* Canada */
        if (pstCurEvn->u8CaEngFlag)
        {
            pstVChipRatingInfo->RatingType = VCHIP_RATING_TYPE_CANADA_ENG;
            pstVChipRatingInfo->CanEngLevel = pstCurEvn->u8CaEngRatingD0;
            DBG_E2R(printf("\nRatingType = VCHIP_RATING_TYPE_CANADA_ENG %bu", pstVChipRatingInfo->CanEngLevel););
        }

        if (pstCurEvn->u8CaFreFlag)
        {
            pstVChipRatingInfo->RatingType = VCHIP_RATING_TYPE_CANADA_FRE;
            pstVChipRatingInfo->CanFreLevel = pstCurEvn->u8CaFreRatingD1;
            DBG_E2R(printf("\nRatingType = VCHIP_RATING_TYPE_CANADA_FRE %bu", pstVChipRatingInfo->CanFreLevel););
        }

        DBG_E2R(
        printf("\nCa and MPAA: %bu %bu %bu", pstCurEvn->u8CaEngFlag, pstCurEvn->u8CaFreFlag, pstCurEvn->u8MPAAFlag);
        printf("\nReceived RRT lock info: %#x %#x %#x %#x %#x %#x %#x %#x %#x %#x",
            (U16)pstCurEvn->u8DownloadableRatingD1,
            (U16)pstCurEvn->u8DownloadableRatingD2,
            (U16)pstCurEvn->u8DownloadableRatingD3,
            (U16)pstCurEvn->u8DownloadableRatingD4,
            (U16)pstCurEvn->u8DownloadableRatingD5,
            (U16)pstCurEvn->u8DownloadableRatingD6,
            (U16)pstCurEvn->u8DownloadableRatingD7,
            (U16)pstCurEvn->u8DownloadableRatingD8,
            (U16)pstCurEvn->u8DownloadableRatingD9,
            (U16)pstCurEvn->u8DownloadableRatingD10););

        // This if sentence is marked out. Because
        // there are posibilities that region 1 and region 5 exists at the same time
        // ex. Sarnoff RRT test stream R24MSR.trp
        // if ( (pstCurEvn->u8CaEngFlag==0) && (pstCurEvn->u8CaFreFlag==0) && (pstCurEvn->u8MPAAFlag==0) ) // Downloadable RRT
        {
            if ( (pstCurEvn->u8DownloadableRatingD1 != 0)||
                 (pstCurEvn->u8DownloadableRatingD2 != 0)||
                 (pstCurEvn->u8DownloadableRatingD3 != 0)||
                 (pstCurEvn->u8DownloadableRatingD4 != 0)||
                 (pstCurEvn->u8DownloadableRatingD5 != 0)||
                 (pstCurEvn->u8DownloadableRatingD6 != 0)||
                 (pstCurEvn->u8DownloadableRatingD7 != 0)||
                 (pstCurEvn->u8DownloadableRatingD8 != 0)||
                 (pstCurEvn->u8DownloadableRatingD9 != 0)||
                 (pstCurEvn->u8DownloadableRatingD10 != 0) )
            {
                pstVChipRatingInfo->u8DimVal0 = pstCurEvn->u8DownloadableRatingD1;
                pstVChipRatingInfo->u8DimVal1 = pstCurEvn->u8DownloadableRatingD2;
                pstVChipRatingInfo->u8DimVal2 = pstCurEvn->u8DownloadableRatingD3;
                pstVChipRatingInfo->u8DimVal3 = pstCurEvn->u8DownloadableRatingD4;
                pstVChipRatingInfo->u8DimVal4 = pstCurEvn->u8DownloadableRatingD5;
                pstVChipRatingInfo->u8DimVal5 = pstCurEvn->u8DownloadableRatingD6;
                pstVChipRatingInfo->u8DimVal6 = pstCurEvn->u8DownloadableRatingD7;
                pstVChipRatingInfo->u8DimVal7 = pstCurEvn->u8DownloadableRatingD8;
                pstVChipRatingInfo->u8DimVal8 = pstCurEvn->u8DownloadableRatingD9;
                pstVChipRatingInfo->u8DimVal9 = pstCurEvn->u8DownloadableRatingD10;
                pstVChipRatingInfo->RatingType = VCHIP_RATING_TYPE_REG5;
                DBG_E2R(printf("\npstVChipRatingInfo->RatingType = VCHIP_RATING_TYPE_REG5\n"));
            }
        }
    }
}
#endif
//////////////////////////////////////////////////////////////////////////////////////////////////////////
#ifdef LOCK_USE_BLACK_VIDEO
// for V-Chip and Input-Block use only...........
void MApp_MuteAvByLock(U8 u8ScreenMute, BOOLEAN bMuteEnable)
{
    if ( u8ScreenMute & (E_SCREEN_MUTE_RATING|E_SCREEN_MUTE_INPUT) )
    {
        if (bMuteEnable)
        {
            // mute the aduio.......
            msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_BYBLOCK_MUTEON, E_AUDIOMUTESOURCE_ACTIVESOURCE);
            #if ENABLE_NEW_SPDIF_MUTE_METHOD
            MApp_Audio_SPDIF_SetMute(TRUE, FORCE_MUTE);
            #else
            MApi_AUDIO_SPDIF_SetMute(TRUE);
            #endif
            // mute the video.......
            msAPI_Scaler_SetScreenMute( (E_SCREEN_MUTE_STATUS)u8ScreenMute, ENABLE, NULL, MAIN_WINDOW);

        }
        else
        {
            // mute the aduio.......
            if( (!g_bInputBlocked) && ( !MApp_VChip_GetCurVChipBlockStatus()) )
            {
                #if ENABLE_NEW_SPDIF_MUTE_METHOD
                MApp_Audio_SPDIF_SetMute(FALSE, FORCE_MUTE);
                #else
                MApi_AUDIO_SPDIF_SetMute(FALSE);
                #endif

                if( !MApp_Aud_GetUserMuteStatus() )
                {
                    msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_BYBLOCK_MUTEOFF, E_AUDIOMUTESOURCE_ACTIVESOURCE);
                }
                else
                {
                     msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_BYBLOCK_MUTEOFF, E_AUDIOMUTESOURCE_ACTIVESOURCE);
                }
            }
            // un-mute the video.......
            msAPI_Scaler_SetScreenMute(E_SCREEN_MUTE_STATUS)u8ScreenMute, DISABLE, NULL, MAIN_WINDOW);

        }
    }
}
#else
// for V-Chip and Input-Block use only...........
void MApp_MuteAvByLock(BOOLEAN bEnableMute)
{
    if (bEnableMute)
    {
        // mute the aduio.......
        msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_BYBLOCK_MUTEON, E_AUDIOMUTESOURCE_ACTIVESOURCE);
        //MApi_AUDIO_SPDIF_SetMute(TRUE);

        // mute the video.......
        //if( IsDTVInUse() )
            //msAPI_Scaler_SetBlueScreen( ENABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
        //else
        // msAPI_Scaler_SetScreenMute( E_SCREEN_MUTE_INIT, ENABLE, NULL, MAIN_WINDOW);
        //MApi_XC_GenerateBlackVideo(ENABLE, MAIN_WINDOW );
        msAPI_Scaler_SetBlueScreen( ENABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
    }
    else
    {
        if( (!g_bInputBlocked) && ( !MApp_VChip_GetCurVChipBlockStatus()) )
        {
            if( IsATVInUse() )
            {
                //msAPI_Scaler_SetScreenMute(E_SCREEN_MUTE_TEMPORARY, DISABLE, 0, MAIN_WINDOW);
               //MApi_XC_GenerateBlackVideo( DISABLE, MAIN_WINDOW );
               //MApi_XC_GenerateBlackVideo( DISABLE, MAIN_WINDOW );
                // msAPI_Scaler_SetScreenMute(E_SCREEN_MUTE_CHANNEL, ENABLE, 1000, MAIN_WINDOW);
                msAPI_Scaler_SetBlueScreen( DISABLE, E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);

            }
            else
            {
                // msAPI_Scaler_SetScreenMute(E_SCREEN_MUTE_TEMPORARY, DISABLE, 0, MAIN_WINDOW);
                //MApi_XC_GenerateBlackVideo( DISABLE, MAIN_WINDOW );
                msAPI_Scaler_SetBlueScreen( DISABLE , E_XC_FREE_RUN_COLOR_BLACK, DEFAULT_SCREEN_UNMUTE_TIME, MAIN_WINDOW);
            }

            //MApi_AUDIO_SPDIF_SetMute(FALSE);

            if (!msAPI_AUD_IsAudioMutedByUser()) //( !MApp_Aud_GetUserMuteStatus() )
            {
                msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_BYBLOCK_MUTEOFF, E_AUDIOMUTESOURCE_ACTIVESOURCE);
            }
            else
            {
                msAPI_AUD_AdjustAudioFactor(E_ADJUST_AUDIOMUTE, E_AUDIO_BYBLOCK_MUTEOFF, E_AUDIOMUTESOURCE_ACTIVESOURCE);
            }

        }

    }
}
#endif

//////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////
void MApp_VChip_Init(void)
{
    u32MonitorVChipFlag = TRUE;
    memset(&g_stVChipRatingInfo, 0, sizeof(g_stVChipRatingInfo));
    if(fCurVChipBlockStatus)
    {
        fCurVChipBlockStatus = FALSE;
        MApp_VChip_SetBlockStatus(fCurVChipBlockStatus); //unblock
    }
    fPreVChipBlockStatus = FALSE;

    //if(IsDigitalSourceInUse())
    {
        msAPI_VBI_Init();
    }

    u32MonitorVChipTimer = msAPI_Timer_GetTime0();
    if(IsDTVInUse()==TRUE)
    {
        msAPI_CC_SetSysBuffer();
        msAPI_CC_DrvInit(MSAPI_CC_TYPE_NTSC_TWOFIELD);
    }
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static BOOLEAN MApp_VChip_EIA608DataToVChipRatingInfo(MS_VCHIP_RATING_INFO *pstVChipRatingInfo)
{
    BOOLEAN bReturn = TRUE;
    pstVChipRatingInfo->RatingType = 0;
    pstVChipRatingInfo->u8DimVal0 = 0;
    pstVChipRatingInfo->u8DimVal1 = 0;
    pstVChipRatingInfo->u8DimVal2 = 0;
    pstVChipRatingInfo->u8DimVal3 = 0;
    pstVChipRatingInfo->u8DimVal4 = 0;
    pstVChipRatingInfo->u8DimVal5 = 0;
    pstVChipRatingInfo->u8DimVal6 = 0;
    pstVChipRatingInfo->u8DimVal7 = 0;
    pstVChipRatingInfo->u8DimVal8 = 0;
    pstVChipRatingInfo->u8DimVal9 = 0;
    pstVChipRatingInfo->RatingLevel = 0;
    pstVChipRatingInfo->MPAALevel = 0;
    pstVChipRatingInfo->CanEngLevel = 0;
    pstVChipRatingInfo->CanFreLevel = 0;
    pstVChipRatingInfo->TV_FVSLD = 0;

    // Get RatingType
    if (!(pstVChipRatingInfo->u8EIA608Data1&BIT3))
    {
        pstVChipRatingInfo->RatingType = VCHIP_RATING_TYPE_MPAA;
    }
    else if (!(pstVChipRatingInfo->u8EIA608Data1&BIT4))
    {
        pstVChipRatingInfo->RatingType = VCHIP_RATING_TYPE_TV;
    }
    else if (!(pstVChipRatingInfo->u8EIA608Data1&BIT5))
    {
        if (pstVChipRatingInfo->u8EIA608Data2&BIT3)
            return FALSE;
        pstVChipRatingInfo->RatingType = VCHIP_RATING_TYPE_CANADA_ENG;
    }
    else
    {
        if (pstVChipRatingInfo->u8EIA608Data2&BIT3)
            return FALSE;
        pstVChipRatingInfo->RatingType = VCHIP_RATING_TYPE_CANADA_FRE;
    }

    // Get RatingLevel
    if (pstVChipRatingInfo->RatingType==VCHIP_RATING_TYPE_MPAA)
    {
        pstVChipRatingInfo->MPAALevel = (pstVChipRatingInfo->u8EIA608Data1 & 0x07)%7;
        if ( pstVChipRatingInfo->MPAALevel==VCHIP_MPAARATING_NA )
            bReturn = FALSE;
    }
    else if(pstVChipRatingInfo->RatingType==VCHIP_RATING_TYPE_TV) // English/French
    {
        pstVChipRatingInfo->RatingLevel = (pstVChipRatingInfo->u8EIA608Data2 & 0x07)%7;
        if ( pstVChipRatingInfo->RatingLevel==VCHIP_TVRATING_NONE )
            bReturn = FALSE;
    }
    else if (pstVChipRatingInfo->RatingType==VCHIP_RATING_TYPE_CANADA_ENG) // English
    {
        pstVChipRatingInfo->CanEngLevel = (pstVChipRatingInfo->u8EIA608Data2 & 0x07)%7;
        if ( pstVChipRatingInfo->CanEngLevel==VCHIP_ENGRATING_EXEMPT )
            bReturn = FALSE;
    }
    else if (pstVChipRatingInfo->RatingType==VCHIP_RATING_TYPE_CANADA_FRE) // French
    {
        pstVChipRatingInfo->CanFreLevel = (pstVChipRatingInfo->u8EIA608Data2 & 0x07)%7;
        if ( pstVChipRatingInfo->CanFreLevel==VCHIP_FRERATING_EXEMPT )
            bReturn = FALSE;
    }

    // Get TVRating FVSLD
    if (pstVChipRatingInfo->RatingType==VCHIP_RATING_TYPE_TV)
    {                                                                                    //  b4 3 2 1 0
        pstVChipRatingInfo->TV_FVSLD = (pstVChipRatingInfo->u8EIA608Data1&BIT5) >> 5; //           D
        if(pstVChipRatingInfo->u8EIA608Data2&BIT5)
        {
            if(pstVChipRatingInfo->RatingLevel == VCHIP_TVRATING_TV_Y7)
                pstVChipRatingInfo->TV_FVSLD |= VCHIP_TVRATING_FV;                       //  FV
            else //VCHIP_TVRATING_TV_PG, VCHIP_TVRATING_TV_14 and VCHIP_TVRATING_TV_MA
                pstVChipRatingInfo->TV_FVSLD |= VCHIP_TVRATING_V;                        //     V
        }
        pstVChipRatingInfo->TV_FVSLD |= (pstVChipRatingInfo->u8EIA608Data2&0x18)>> 2; //       S L
    }
    else
    {
        pstVChipRatingInfo->TV_FVSLD = 0;
    }

    return bReturn;
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#ifdef NEW_VCHIP
void VCHIPRATINGINFO(MS_VCHIP_RATING_INFO *pstVChipRatingInfo)
{
    U8 iloop;
    for(iloop =0; iloop < sizeof(MS_VCHIP_RATING_INFO);iloop++)
    {
        printf("[%2x]",(U16)(((U8*)pstVChipRatingInfo)[iloop]));
    }
}
#endif
static EnuVChipDataStatus MApp_VChip_GetRating(MS_VCHIP_RATING_INFO *pstVChipRatingInfo)
{
    EnuVChipDataStatus status = VCHIP_DATA_NONE ;
   // MS_EPG_EVENT    stEventInfo;

#ifdef NEW_VCHIP
    EnuVChipDataStatus status1;
    MS_VCHIP_RATING_INFO stEITRatingInfo,st608RatingInfo;
#else
    //MS_VCHIP_RATING_INFO  stCurEventInfo;
#endif

    if ( IsDigitalSourceInUse()
#ifndef DISABLE_COMPONENT_VBI
         || IsYPbPrInUse()
#endif
       )
    { //analog channel
        status = msAPI_VBI_GetEIA608Data(&(pstVChipRatingInfo->u8EIA608Data1), &(pstVChipRatingInfo->u8EIA608Data2));
        if(status == VCHIP_DATA_CHANGE)
            MApp_VChip_EIA608DataToVChipRatingInfo(pstVChipRatingInfo);
    }
    #if 0
    else
    { //digital channel
        if (MApp_EpgDB_GetCurEvent(&stEventInfo) == TRUE)
        {
#ifdef NEW_VCHIP
#define NEW_VCHIP_DBINFO(y)    //y
            BOOLEAN bResult;
            /*digital 608*/
            status1 = msAPI_VBI_GetEIA608Data(&(pstVChipRatingInfo->u8EIA608Data1), &(pstVChipRatingInfo->u8EIA608Data2));
            st608RatingInfo.u8EIA608Data1 = pstVChipRatingInfo->u8EIA608Data1;
            st608RatingInfo.u8EIA608Data2 = pstVChipRatingInfo->u8EIA608Data2;
            if(status1 != VCHIP_DATA_NONE)
            {
                bResult = MApp_VChip_EIA608DataToVChipRatingInfo(&st608RatingInfo);
                NEW_VCHIP_DBINFO(printf("\r\nEIA608");VCHIPRATINGINFO(&st608RatingInfo);)
            }

            /*Merge & Check VChipData*/
            if(stEventInfo.stRating.fRatingRxIsOK) // having EIT Table Vchip Rating
            {
                /*EIT Table*/
                MApp_VChip_EPGRating2RatingInfo(&stEventInfo.stRating, &stEITRatingInfo);
                NEW_VCHIP_DBINFO(printf("\r\nEIA708");VCHIPRATINGINFO(&stEITRatingInfo);)

                if(status1==VCHIP_DATA_NONE) //no 608 data, 708 only
                {
                    U8 u8RatingType = pstVChipRatingInfo->RatingType;
                    // back up the current ratingtype, for block menu show it.
                    // and for EIT rating info, the rating type is no use for comparasion
                    pstVChipRatingInfo->RatingType = stEITRatingInfo.RatingType;
                    if(memcmp(pstVChipRatingInfo,&stEITRatingInfo,sizeof(MS_VCHIP_RATING_INFO))==0)
                    {
                        NEW_VCHIP_DBINFO(putchar('=');putchar('1');)
                        pstVChipRatingInfo->RatingType = u8RatingType;
                        return VCHIP_DATA_NO_CHANGE;
                    }
                    else
                    {
                        NEW_VCHIP_DBINFO(printf("RaInfo");VCHIPRATINGINFO(pstVChipRatingInfo);)
                        NEW_VCHIP_DBINFO(putchar('!');putchar('1');)
                        memcpy(pstVChipRatingInfo,&stEITRatingInfo,sizeof(MS_VCHIP_RATING_INFO));
                        return VCHIP_DATA_CHANGE;
                    }
                }
                else
                {
                    if(bResult) // 608 data Rating data with Rating Level
                    {
                        switch(st608RatingInfo.RatingType) // 608's type indicated which data should be as referenced.
                        {
                            case VCHIP_RATING_TYPE_TV: // TV Rating use
                                if(stEITRatingInfo.RatingLevel == st608RatingInfo.RatingLevel)
                                    stEITRatingInfo.TV_FVSLD = (stEITRatingInfo.TV_FVSLD | st608RatingInfo.TV_FVSLD);
                                else
                                {
                                    /*// current method:if TV Rating Level is different, use the 608 data
                                        The more reasonable behavior should check the user vchip setting
                                        if current rating should be locked set it.
                                    */
                                    stEITRatingInfo.RatingLevel = st608RatingInfo.RatingLevel;
                                    stEITRatingInfo.TV_FVSLD = st608RatingInfo.TV_FVSLD;
                                }
                                break;
                            case VCHIP_RATING_TYPE_MPAA: // MPAA Rating use Less one
                                if(stEITRatingInfo.MPAALevel>st608RatingInfo.MPAALevel)
                                    stEITRatingInfo.MPAALevel = st608RatingInfo.MPAALevel;
                                break;
                            case VCHIP_RATING_TYPE_CANADA_ENG: // Canada_Eng Rating use less one.
                                if(stEITRatingInfo.CanEngLevel>st608RatingInfo.CanEngLevel)
                                    stEITRatingInfo.CanEngLevel = st608RatingInfo.CanEngLevel;
                                break;
                            case VCHIP_RATING_TYPE_CANADA_FRE: // Canada_FRE Rating use less one.
                                if(stEITRatingInfo.CanFreLevel>st608RatingInfo.CanFreLevel)
                                    stEITRatingInfo.CanFreLevel = st608RatingInfo.CanFreLevel;
                                break;
                            default:
                                break;
                        }

                        // if 608's RatingType is valid, copy RatingType for comparasion.
                        stEITRatingInfo.RatingType = st608RatingInfo.RatingType;

                    }
                    // Just for compare convenience
                    stEITRatingInfo.u8EIA608Data1 = st608RatingInfo.u8EIA608Data1;
                    stEITRatingInfo.u8EIA608Data2 = st608RatingInfo.u8EIA608Data2;

                    NEW_VCHIP_DBINFO(printf("\nMerged");VCHIPRATINGINFO(&stEITRatingInfo);)
                    NEW_VCHIP_DBINFO(printf("\nRaInfo");VCHIPRATINGINFO(pstVChipRatingInfo);)
                    if(memcmp(pstVChipRatingInfo,&stEITRatingInfo,sizeof(MS_VCHIP_RATING_INFO))==0)
                    {
                        NEW_VCHIP_DBINFO(putchar('=');putchar('2');)
                        return VCHIP_DATA_NO_CHANGE;
                    }
                    else
                    {
                        memcpy(pstVChipRatingInfo,&stEITRatingInfo,sizeof(MS_VCHIP_RATING_INFO));
                        NEW_VCHIP_DBINFO(putchar('!');putchar('2');)
                        return VCHIP_DATA_CHANGE;

                    }
                }
            }
            else // 608 only
            {
                if(status1 == VCHIP_DATA_NONE)
                {
                    NEW_VCHIP_DBINFO(putchar('=');putchar('0');)
                    return VCHIP_DATA_NONE;
                }
                else
                {
                    if(memcmp(pstVChipRatingInfo, &st608RatingInfo, sizeof(MS_VCHIP_RATING_INFO))==0)
                    {
                        NEW_VCHIP_DBINFO(putchar('=');putchar('3');)
                        return VCHIP_DATA_NO_CHANGE;
                    }
                    else
                    {
                        NEW_VCHIP_DBINFO(printf("RaInfo");VCHIPRATINGINFO(pstVChipRatingInfo);)
                        memcpy(pstVChipRatingInfo, &st608RatingInfo, sizeof(MS_VCHIP_RATING_INFO));
                        NEW_VCHIP_DBINFO(putchar('!');putchar('3');)
                        return VCHIP_DATA_CHANGE;
                    }
                }

            }

            #else
            {
                /* digital 608 */
                status = msAPI_VBI_GetEIA608Data(&(pstVChipRatingInfo->u8EIA608Data1), &(pstVChipRatingInfo->u8EIA608Data2));
                if(status == VCHIP_DATA_CHANGE)
                {
                    BOOLEAN bResult;
                    U8 u8PreRatingType = pstVChipRatingInfo->RatingType;
                    bResult = MApp_VChip_EIA608DataToVChipRatingInfo(pstVChipRatingInfo);

                    if ( stEventInfo.stRating.fRatingRxIsOK && MApp_VChip_GetCurVChipBlockStatus() ) // is locked by 708 now....
                    {
                        if ( (u8PreRatingType!=pstVChipRatingInfo->RatingType)&&(!bResult) ) // the incoming new 608 rating is null.....
                            return VCHIP_DATA_NO_CHANGE;
                    }
                    return VCHIP_DATA_CHANGE;
                }
                else if ( (status == VCHIP_DATA_NO_CHANGE) && (!stEventInfo.stRating.fRatingRxIsOK) )
                {
                    return status;
                }
            }

            // rating from EIT....
            MApp_VChip_EPGRating2RatingInfo(&stEventInfo.stRating, &stCurEventInfo);
            if(
                stCurEventInfo.RatingType != pstVChipRatingInfo->RatingType ||
                stCurEventInfo.RatingLevel != pstVChipRatingInfo->RatingLevel ||
                stCurEventInfo.TV_FVSLD != pstVChipRatingInfo->TV_FVSLD ||
                stCurEventInfo.u8DimVal0 != pstVChipRatingInfo->u8DimVal0 ||
                stCurEventInfo.u8DimVal1 != pstVChipRatingInfo->u8DimVal1 ||
                stCurEventInfo.u8DimVal2 != pstVChipRatingInfo->u8DimVal2 ||
                stCurEventInfo.u8DimVal3 != pstVChipRatingInfo->u8DimVal3 ||
                stCurEventInfo.u8DimVal4 != pstVChipRatingInfo->u8DimVal4 ||
                stCurEventInfo.u8DimVal5 != pstVChipRatingInfo->u8DimVal5 ||
                stCurEventInfo.u8DimVal6 != pstVChipRatingInfo->u8DimVal6 ||
                stCurEventInfo.u8DimVal7 != pstVChipRatingInfo->u8DimVal7 ||
                stCurEventInfo.u8DimVal8 != pstVChipRatingInfo->u8DimVal8 ||
                stCurEventInfo.u8DimVal9 != pstVChipRatingInfo->u8DimVal9 ||
                stCurEventInfo.MPAALevel != pstVChipRatingInfo->MPAALevel ||
                stCurEventInfo.CanEngLevel != pstVChipRatingInfo->CanEngLevel ||
                stCurEventInfo.CanFreLevel != pstVChipRatingInfo->CanFreLevel )
            {
                pstVChipRatingInfo->RatingType = stCurEventInfo.RatingType;
                pstVChipRatingInfo->u8DimVal0 = stCurEventInfo.u8DimVal0;
                pstVChipRatingInfo->u8DimVal1 = stCurEventInfo.u8DimVal1;
                pstVChipRatingInfo->u8DimVal2 = stCurEventInfo.u8DimVal2;
                pstVChipRatingInfo->u8DimVal3 = stCurEventInfo.u8DimVal3;
                pstVChipRatingInfo->u8DimVal4 = stCurEventInfo.u8DimVal4;
                pstVChipRatingInfo->u8DimVal5 = stCurEventInfo.u8DimVal5;
                pstVChipRatingInfo->u8DimVal6 = stCurEventInfo.u8DimVal6;
                pstVChipRatingInfo->u8DimVal7 = stCurEventInfo.u8DimVal7;
                pstVChipRatingInfo->u8DimVal8 = stCurEventInfo.u8DimVal8;
                pstVChipRatingInfo->u8DimVal9 = stCurEventInfo.u8DimVal9;
                pstVChipRatingInfo->RatingLevel = stCurEventInfo.RatingLevel;
                pstVChipRatingInfo->MPAALevel = stCurEventInfo.MPAALevel;
                pstVChipRatingInfo->CanEngLevel = stCurEventInfo.CanEngLevel;
                pstVChipRatingInfo->CanFreLevel = stCurEventInfo.CanFreLevel;
                pstVChipRatingInfo->TV_FVSLD = stCurEventInfo.TV_FVSLD;
                status = VCHIP_DATA_CHANGE;
            }
            else
            {
                status = VCHIP_DATA_NO_CHANGE;
            }
            #endif
        }
        else
        {
            /* digital 608 */
            status = msAPI_VBI_GetEIA608Data(&(pstVChipRatingInfo->u8EIA608Data1), &(pstVChipRatingInfo->u8EIA608Data2));
            if(status == VCHIP_DATA_CHANGE)
                MApp_VChip_EIA608DataToVChipRatingInfo(pstVChipRatingInfo);
            //status = VCHIP_DATA_NONE;
        }
    }
    #endif
    return status;
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#if 0 //ATSC_FIX_C
static U8 MApp_VChip_RatingType2LockMode(U8 u8RatingType)
{
    switch (u8RatingType)
    {
        case VCHIP_RATING_TYPE_CANADA_ENG:
        case VCHIP_RATING_TYPE_CANADA_FRE:
            return VCHIP_RATING_REGION_CANADA;
        case VCHIP_RATING_TYPE_TV:
        case VCHIP_RATING_TYPE_MPAA:
            return VCHIP_RATING_REGION_US;
        case VCHIP_RATING_TYPE_REG5:
            return VCHIP_RATING_REGION_REG5;
        default:
            return VCHIP_RATING_REGION_NONE;
    }
    return VCHIP_RATING_REGION_NONE;
}
#endif
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#if defined(ENABLE_PARSE_SAME_DIMENSION_IN_RRT5_CAD) && ENABLE_PARSE_SAME_DIMENSION_IN_RRT5_CAD
#define DBG_RRT5(msg) //msg
static BOOLEAN MApp_VChip_CompareRRT5Rating(MS_VCHIP_RATING_INFO *pstVChipRatingInfo)
{
    BOOLEAN bBlockStatus = FALSE;

    // 0 based
    #define ShouldLockDim(n)  ((stGenSetting.g_VchipRegion5.stRegin5Dimension[n].u16CurrentOption) & (pstVChipRatingInfo->u8DimVal ## n))

    // VCHIP_RATING_TYPE_REG5:
    if (ShouldLockDim(0))
    {
        DBG_RRT5(printf("\nlock dim 0 (%#x, %#x)",
            (U16)stGenSetting.g_VchipRegion5.stRegin5Dimension[0].u16CurrentOption,
            (U16)pstVChipRatingInfo->u8DimVal0
            ));
        bBlockStatus = TRUE;
    }

    if (ShouldLockDim(1))
    {
        DBG_RRT5(printf("\nlock dim 1 (%#x, %#x)",
            (U16)stGenSetting.g_VchipRegion5.stRegin5Dimension[1].u16CurrentOption,
            (U16)pstVChipRatingInfo->u8DimVal1
            ));
        bBlockStatus = TRUE;
    }

    if (ShouldLockDim(2))
    {
        DBG_RRT5(printf("\nlock dim 2 (%#x, %#x)",
            (U16)stGenSetting.g_VchipRegion5.stRegin5Dimension[2].u16CurrentOption,
            (U16)pstVChipRatingInfo->u8DimVal2
            ));
        bBlockStatus = TRUE;
    }

    if (ShouldLockDim(3))
    {
        DBG_RRT5(printf("\nlock dim 3 (%#x, %#x)",
            (U16)stGenSetting.g_VchipRegion5.stRegin5Dimension[3].u16CurrentOption,
            (U16)pstVChipRatingInfo->u8DimVal3
            ));
        bBlockStatus = TRUE;
    }

    if (ShouldLockDim(4))
    {
        DBG_RRT5(printf("\nlock dim 4 (%#x, %#x)",
            (U16)stGenSetting.g_VchipRegion5.stRegin5Dimension[4].u16CurrentOption,
            (U16)pstVChipRatingInfo->u8DimVal4
            ));
        bBlockStatus = TRUE;
    }

    if (ShouldLockDim(5))
    {
        DBG_RRT5(printf("\nlock dim 5 (%#x, %#x)",
            (U16)stGenSetting.g_VchipRegion5.stRegin5Dimension[5].u16CurrentOption,
            (U16)pstVChipRatingInfo->u8DimVal5
            ));
        bBlockStatus = TRUE;
    }

    if (ShouldLockDim(6))
    {
        DBG_RRT5(printf("\nlock dim 6 (%#x, %#x)",
            (U16)stGenSetting.g_VchipRegion5.stRegin5Dimension[6].u16CurrentOption,
            (U16)pstVChipRatingInfo->u8DimVal6
            ));
        bBlockStatus = TRUE;
    }

    if (ShouldLockDim(7))
    {
        DBG_RRT5(printf("\nlock dim 7 (%#x, %#x)",
            (U16)stGenSetting.g_VchipRegion5.stRegin5Dimension[7].u16CurrentOption,
            (U16)pstVChipRatingInfo->u8DimVal7
            ));
        bBlockStatus = TRUE;
    }

    if (ShouldLockDim(8))
    {
        DBG_RRT5(printf("\nlock dim 8 (%#x, %#x)",
            (U16)stGenSetting.g_VchipRegion5.stRegin5Dimension[8].u16CurrentOption,
            (U16)pstVChipRatingInfo->u8DimVal8
            ));
        bBlockStatus = TRUE;
    }

    if (ShouldLockDim(9))
    {
        DBG_RRT5(printf("\nlock dim 9 (%#x, %#x)",
            (U16)stGenSetting.g_VchipRegion5.stRegin5Dimension[9].u16CurrentOption,
            (U16)pstVChipRatingInfo->u8DimVal9
            ));
        bBlockStatus = TRUE;
    }

    return bBlockStatus;

    #undef ShouldLockDim
}
#endif
BOOLEAN MApp_VChip_CompareRating(MS_VCHIP_RATING_INFO *pstVChipRatingInfo, MS_VCHIP_SETTING *pstVChipSetting)
{
    BOOLEAN bBlockStatus;

    VCHIP_DBINFO(printf("\npstVChipSetting->u8VChipLockMode %bu\n", (U8)(pstVChipSetting->u8VChipLockMode)));
    VCHIP_DBINFO(printf("pstVChipRatingInfo->RatingType %bu\n\n", (U8)pstVChipRatingInfo->RatingType));

    bBlockStatus = FALSE;
    if((pstVChipSetting->u8VChipLockMode) && (!fVChipPassWordEntered))
    {
            // VCHIP_RATING_TYPE_TV:
                switch(pstVChipRatingInfo->RatingLevel)
                {
                    case VCHIP_TVRATING_TV_Y:
                        if((pstVChipSetting->stVChipTVItem.Item_TV_Y & VCHIP_TVRATING_ALL) ||
                           (pstVChipSetting->stVChipTVItem.Item_TV_Y & pstVChipRatingInfo->TV_FVSLD))
                            bBlockStatus = TRUE;
                        break;
                    case VCHIP_TVRATING_TV_Y7:
                        if((pstVChipSetting->stVChipTVItem.Item_TV_Y7 & VCHIP_TVRATING_ALL) ||
                           (pstVChipSetting->stVChipTVItem.Item_TV_Y7 & pstVChipRatingInfo->TV_FVSLD))
                            bBlockStatus = TRUE;
                        break;
                    case VCHIP_TVRATING_TV_G:
                        if((pstVChipSetting->stVChipTVItem.Item_TV_G & VCHIP_TVRATING_ALL) ||
                           (pstVChipSetting->stVChipTVItem.Item_TV_G & pstVChipRatingInfo->TV_FVSLD))
                            bBlockStatus = TRUE;
                        break;
                    case VCHIP_TVRATING_TV_PG:
                        if((pstVChipSetting->stVChipTVItem.Item_TV_PG & VCHIP_TVRATING_ALL) ||
                           (pstVChipSetting->stVChipTVItem.Item_TV_PG & pstVChipRatingInfo->TV_FVSLD))
                            bBlockStatus = TRUE;
                        break;
                    case VCHIP_TVRATING_TV_14:
                        if((pstVChipSetting->stVChipTVItem.Item_TV_14 & VCHIP_TVRATING_ALL) ||
                           (pstVChipSetting->stVChipTVItem.Item_TV_14 & pstVChipRatingInfo->TV_FVSLD))
                            bBlockStatus = TRUE;
                        break;
                    case VCHIP_TVRATING_TV_MA:
                        if((pstVChipSetting->stVChipTVItem.Item_TV_MA & VCHIP_TVRATING_ALL) ||
                           (pstVChipSetting->stVChipTVItem.Item_TV_MA & pstVChipRatingInfo->TV_FVSLD))
                            bBlockStatus = TRUE;
                        break;
                }
                if (bBlockStatus == TRUE)
                    pstVChipRatingInfo->RatingType = VCHIP_RATING_TYPE_TV;

            // VCHIP_RATING_TYPE_MPAA:
                if(pstVChipRatingInfo->MPAALevel != VCHIP_MPAARATING_NA &&
                   pstVChipSetting->u8VChipMPAAItem != VCHIP_MPAARATING_NA)
                {
                    if(pstVChipRatingInfo->MPAALevel >= pstVChipSetting->u8VChipMPAAItem)
                    {
                        bBlockStatus = TRUE;
                        pstVChipRatingInfo->RatingType = VCHIP_RATING_TYPE_MPAA;
                    }
                }

            // VCHIP_RATING_TYPE_CANADA_ENG:
                if(pstVChipRatingInfo->CanEngLevel > VCHIP_ENGRATING_EXEMPT &&
                   pstVChipRatingInfo->CanEngLevel <= VCHIP_ENGRATING_MAX_LEVEL)
                {
                    if (pstVChipSetting->u8VChipCEItem &&
                        pstVChipRatingInfo->CanEngLevel >= pstVChipSetting->u8VChipCEItem)
                    {
                        bBlockStatus = TRUE;
                        pstVChipRatingInfo->RatingType = VCHIP_RATING_TYPE_CANADA_ENG;
                    }
                }

            // VCHIP_RATING_TYPE_CANADA_FRE:
                if(pstVChipRatingInfo->CanFreLevel > VCHIP_FRERATING_EXEMPT &&
                   pstVChipRatingInfo->CanFreLevel <= VCHIP_FRERATING_MAX_LEVEL)
                {
                    if (pstVChipSetting->u8VChipCFItem &&
                        pstVChipRatingInfo->CanFreLevel >= pstVChipSetting->u8VChipCFItem)
                    {
                        bBlockStatus = TRUE;
                        pstVChipRatingInfo->RatingType = VCHIP_RATING_TYPE_CANADA_FRE;
                    }
                }
            // VCHIP_RATING_TYPE_REG5:

#if 0//defined(ENABLE_PARSE_SAME_DIMENSION_IN_RRT5_CAD) && ENABLE_PARSE_SAME_DIMENSION_IN_RRT5_CAD
            if (MApp_VChip_CompareRRT5Rating(pstVChipRatingInfo))
            {
                bBlockStatus = TRUE;
                pstVChipRatingInfo->RatingType = VCHIP_RATING_TYPE_REG5;
            }
//#else
            if( (pstVChipRatingInfo->u8DimVal0 != 0) &&
                 ((stGenSetting.g_VchipRegion5.stRegin5Dimension[0].u16CurrentOption)>>(pstVChipRatingInfo->u8DimVal0-1)&0x01) )
             {
                    bBlockStatus = TRUE;
                    pstVChipRatingInfo->RatingType = VCHIP_RATING_TYPE_REG5;
            }

            if( (pstVChipRatingInfo->u8DimVal1 != 0) &&
                 ((stGenSetting.g_VchipRegion5.stRegin5Dimension[1].u16CurrentOption)>>(pstVChipRatingInfo->u8DimVal1-1)&0x01) )
            {
                        bBlockStatus = TRUE;
                        pstVChipRatingInfo->RatingType = VCHIP_RATING_TYPE_REG5;
            }

            if( (pstVChipRatingInfo->u8DimVal2 != 0) &&
                 ((stGenSetting.g_VchipRegion5.stRegin5Dimension[2].u16CurrentOption)>>(pstVChipRatingInfo->u8DimVal2-1)&0x01) )
             {
                        bBlockStatus = TRUE;
                        pstVChipRatingInfo->RatingType = VCHIP_RATING_TYPE_REG5;
             }

            if( (pstVChipRatingInfo->u8DimVal3 != 0) &&
                 ((stGenSetting.g_VchipRegion5.stRegin5Dimension[3].u16CurrentOption)>>(pstVChipRatingInfo->u8DimVal3-1)&0x01) )
            {
                        bBlockStatus = TRUE;
                        pstVChipRatingInfo->RatingType = VCHIP_RATING_TYPE_REG5;
            }

            if( (pstVChipRatingInfo->u8DimVal4 != 0) &&
                 ((stGenSetting.g_VchipRegion5.stRegin5Dimension[4].u16CurrentOption)>>(pstVChipRatingInfo->u8DimVal4-1)&0x01) )
             {
                        bBlockStatus = TRUE;
                        pstVChipRatingInfo->RatingType = VCHIP_RATING_TYPE_REG5;
            }

            if( (pstVChipRatingInfo->u8DimVal5 != 0) &&
                 ((stGenSetting.g_VchipRegion5.stRegin5Dimension[5].u16CurrentOption)>>(pstVChipRatingInfo->u8DimVal5-1)&0x01) )
             {
                        bBlockStatus = TRUE;
                        pstVChipRatingInfo->RatingType = VCHIP_RATING_TYPE_REG5;
             }

            if( (pstVChipRatingInfo->u8DimVal6 != 0) &&
                 ((stGenSetting.g_VchipRegion5.stRegin5Dimension[6].u16CurrentOption)>>(pstVChipRatingInfo->u8DimVal6-1)&0x01) )
            {
                        bBlockStatus = TRUE;
                        pstVChipRatingInfo->RatingType = VCHIP_RATING_TYPE_REG5;
            }

            if( (pstVChipRatingInfo->u8DimVal7 != 0) &&
                 ((stGenSetting.g_VchipRegion5.stRegin5Dimension[7].u16CurrentOption)>>(pstVChipRatingInfo->u8DimVal7-1)&0x01) )
             {
                        bBlockStatus = TRUE;
                        pstVChipRatingInfo->RatingType = VCHIP_RATING_TYPE_REG5;
             }

            if( (pstVChipRatingInfo->u8DimVal8 != 0) &&
                 ((stGenSetting.g_VchipRegion5.stRegin5Dimension[8].u16CurrentOption)>>(pstVChipRatingInfo->u8DimVal8-1)&0x01) )
             {
                        bBlockStatus = TRUE;
                        pstVChipRatingInfo->RatingType = VCHIP_RATING_TYPE_REG5;
             }

            if( (pstVChipRatingInfo->u8DimVal9 != 0) &&
                 ((stGenSetting.g_VchipRegion5.stRegin5Dimension[9].u16CurrentOption)>>(pstVChipRatingInfo->u8DimVal9-1)&0x01) )
             {
                        bBlockStatus = TRUE;
                        pstVChipRatingInfo->RatingType = VCHIP_RATING_TYPE_REG5;
             }
#endif
}

    return bBlockStatus;
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void MApp_VChip_SetBlockStatus(BOOLEAN bVChipBlockStatus)
{
    #ifdef LOCK_USE_BLACK_VIDEO
    MApp_MuteAvByLock(E_SCREEN_MUTE_RATING, bVChipBlockStatus);
    #else
    //bVChipBlockStatus = bVChipBlockStatus;
    MApp_MuteAvByLock(bVChipBlockStatus);
    #endif
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void MApp_VChip_MonitorVChip(void)
{
    if(u32MonitorVChipFlag || msAPI_Timer_DiffTimeFromNow(u32MonitorVChipTimer) > VCHIP_MONITOR_PERIOD)
    {
        u32MonitorVChipFlag = FALSE;
        switch( MApp_VChip_GetRating(&g_stVChipRatingInfo) )
        {
            case VCHIP_DATA_NO_CHANGE:
                VCHIP_DBINFO(printf("\nVCHIP_DATA_NO_CHANGE!\r\n"));

                // to avoid a flash black screen after unlock (if taking mixed rating signal). caused by re-Enable AV.
                if (fVChipPassWordEntered)
                {
                    fCurVChipBlockStatus = FALSE;
                    fVChipPassWordEntered = FALSE;
                }
                //g_ucVChipNoRatingCounter = 0;
                break;
            case VCHIP_DATA_CHANGE:
                VCHIP_DBINFO(printf("\nVCHIP_DATA_CHANGE!\r\n"));

                fRatingUpdateStatus = TRUE;
                //g_ucVChipNoRatingCounter = 0;
                fCurVChipBlockStatus = MApp_VChip_CompareRating(&g_stVChipRatingInfo, &stGenSetting.g_VChipSetting);
                break;
            case VCHIP_DATA_NONE:
                VCHIP_DBINFO(printf("\nVCHIP_DATA_NONE!\r\n"));
                /*
                if( g_ucVChipNoRatingCounter < 100 )
                    ++ g_ucVChipNoRatingCounter;
                if( g_ucVChipNoRatingCounter == 100 )
                */
                g_stVChipRatingInfo.RatingType = VCHIP_RATING_TYPE_NONE;
                fCurVChipBlockStatus = FALSE;

                break;
        }

        if(fCurVChipBlockStatus != fPreVChipBlockStatus)
        {
#if (DTV_608_VCHIP_DEBUG == 1)
            printf("\n vc sw, %bd, %bd", (U8)fCurVChipBlockStatus, (U8)fPreVChipBlockStatus);
#endif
            MApp_VChip_SetBlockStatus((BOOLEAN)fCurVChipBlockStatus);
            fPreVChipBlockStatus = fCurVChipBlockStatus;
        }

        u32MonitorVChipTimer = msAPI_Timer_GetTime0();
    }
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
BOOLEAN MApp_VChip_GetCurVChipBlockStatus(void)
{
    return (fCurVChipBlockStatus && (!fVChipPassWordEntered));
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
BOOLEAN MApp_VChip_GetRatingUpdateStatus(void)
{
    BOOLEAN bUpdate = fRatingUpdateStatus;

    fRatingUpdateStatus = FALSE;

    return (fCurVChipBlockStatus && bUpdate);
}
#endif

#undef MAPP_VCHIP_C



